#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
sha256sum --quiet -c SHA256SUMS
r="$(mktemp -d -p "$PWD" replay-XXXXXX)/verified"
(ulimit -v 120000; timeout 14s python3 -B pilot.py generate "$r")
cmp "$r/exact-graph.json" verified81/exact-graph.json
cmp "$r/ordinary-four.cnf" verified81/ordinary-four.cnf
(ulimit -v 120000; timeout 14s python3 -B pilot.py check "$r" solver.out)
cmp "$r/checked-coloring.json" verified81/checked-coloring.json
echo 'Exact coordinates, all edges, CNF, and witness reproduced without a solver.'
