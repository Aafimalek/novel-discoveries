#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
sha256sum --quiet -c SHA256SUMS
r="$(mktemp -d -p "$PWD" replay-XXXXXX)/result"
(ulimit -v 132000; timeout 59s python3 -B fixture.py generate "$r")
cmp "$r/exact-graph.json" verified/exact-graph.json
cmp "$r/equal.cnf" verified/equal.cnf
(ulimit -v 132000; timeout 15s python3 -B fixture.py check "$r" solver.out)
cmp "$r/checked-model.json" verified/checked-model.json
(ulimit -v 132000; timeout 8s python3 -B product_witness.py "$r" "$r/product-witness.json")
cmp "$r/product-witness.json" verified/product-witness.json
echo 'All coordinates, edges and checked coloring vectors reproduced.'
