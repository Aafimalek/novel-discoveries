#!/usr/bin/env bash
set -euo pipefail
if [ "$#" -lt 7 ] || [ "$#" -gt 8 ]; then
  echo "usage: $0 PINNED_DIR CATALOGUE SINGLE TRIPLE FOUR FIVE FRESH_RUN_DIR [LAST_SHARD=63]" >&2
  exit 2
fi
here=$(cd -- "$(dirname -- "$0")" && pwd)
original=$(realpath -- "$1"); catalogue=$(realpath -- "$2"); single=$(realpath -- "$3")
triple=$(realpath -- "$4"); four=$(realpath -- "$5"); five=$(realpath -- "$6")
work=$(realpath -m -- "$7"); last=${8:-63}
[[ "$last" =~ ^[1-9][0-9]$ && "$last" -ge 36 && "$last" -le 63 ]]
(cd "$here" && sha256sum -c SHA256SUMS && sha256sum -c PRIOR.sha256)
mkdir -- "$work"
cd -- "$work"
ulimit -v 132000
unset PYTHONOPTIMIZE
export OPENBLAS_NUM_THREADS=1 PYTHONDONTWRITEBYTECODE=1
pin() {
  local hash
  hash=$(awk -v n="$1" '$2==n {print $1}' "$here/INPUTS.sha256")
  [ "${#hash}" -eq 64 ]
  printf '%s  %s\n' "$hash" "$2" | sha256sum -c -
}
pin G449.k21 "$original/G449.k21"; pin G449.s6 "$original/G449.s6"
pin denominator-seven-directions.tsv "$catalogue"
pin extension-witnesses.json "$single"; pin triple-residual-witness.json "$triple"
pin four-witness.json "$four"; pin five-witness.json "$five"
for kind in witness11 witness36; do
  pin "$kind/fixture.json" "$here/$kind/fixture.json"
  pin "$kind/witness.json" "$here/$kind/witness.json"
  timeout 25s python3 "$here/$kind/verify.py" "$original" | tee "$kind.log"
done
timeout 25s python3 "$here/prepare.py" "$original" "$catalogue" "$single" "$triple" "$four" "$five" "$here/witness11/witness.json" "$here/witness11/fixture.json" "$here/witness36/witness.json" "$here/witness36/fixture.json" graph.txt coordinates.txt | tee prepare.log
python3 "$here/check_upgrade.py" .
sha256sum graph.txt coordinates.txt >GENERATED.sha256
timeout 25s "${CXX:-g++}" -std=c++20 -O0 -g0 --param=ggc-min-expand=1 --param=ggc-min-heapsize=1024 "$here/enumerate6_connected.cpp" -o connected
sha256sum connected "$here/enumerate6_connected.cpp" >BINARY.sha256
start=36
if [ "${ALL_40:-0}" = 1 ]; then
  test "$last" -eq 63
  start=0
fi
for ((h=start; h<=last; h++)); do
  sha256sum -c --quiet GENERATED.sha256
  sha256sum -c --quiet BINARY.sha256
  ( time timeout 25s ./connected graph.txt "${h}.residual" "$h" 64 1500000 80000000 >"${h}.log" ) 2>"${h}.time"
  sha256sum "${h}.log" "${h}.time" "${h}.residual" >"${h}.sha256"
  chmod a-w "${h}.log" "${h}.time" "${h}.residual" "${h}.sha256"
  head -1 "${h}.log"
  if [ -s "${h}.residual" ]; then
    printf 'Stopped at shard %s: connected palette-bank residual.\n' "$h" >&2
    exit 8
  fi
  if [ "$h" = 36 ]; then
    python3 "$here/collect.py" . --check-36
  fi
done
sha256sum -c GENERATED.sha256
if [ "$last" = 63 ]; then
  opts=(--require-closed)
  if [ "$start" = 0 ]; then opts+=(--all40); fi
  python3 "$here/collect.py" . "${opts[@]}" | tee summary.log
fi
