#include <algorithm>
#include <array>
#include <bit>
#include <cassert>
#include <cstdint>
#include <cstdlib>
#include <fstream>
#include <iostream>
#include <numeric>
#include <string>
#include <vector>

using U64=std::uint64_t;
constexpr int N=7056,M=33908,K=40;
struct Set {
    int n=0;
    std::array<int,6> v{};
};
using Adj=std::array<unsigned,6>;
using Lists=std::array<unsigned,6>;

struct Audit {
    int shard, count, width=(N+63)/64;
    U64 visit_cap, growth_cap, growth=0, visits=0, residual=0;
    std::array<U64,6> at_size{};
    std::array<U64,K> hit{};
    std::vector<int> base_degree=std::vector<int>(N);
    std::vector<std::array<std::uint8_t,K>> colors=
        std::vector<std::array<std::uint8_t,K>>(N);
    std::vector<std::vector<int>> nb=std::vector<std::vector<int>>(N);
    std::vector<U64> graph=std::vector<U64>(std::size_t(N)*width);
    std::ofstream out;
    int roots=0;

    bool edge(int u,int v) const {
        assert(0<=u&&u<N&&0<=v&&v<N);
        return ((graph[std::size_t(u)*width+v/64]>>(v%64))&1)!=0;
    }
    Audit(const char* data,const char* dst,int a,int n,U64 vc,U64 gc):
        shard(a), count(n), visit_cap(vc),growth_cap(gc),out(dst) {
        assert(0<=shard&&shard<count&&1<=count&&count<=N);
        assert(visit_cap>0&&growth_cap>0&&out.good());
        std::ifstream f(data);
        int nn=0,k=0,m=0;
        assert(f>>nn>>k>>m);
        assert(nn==N&&k==K&&m==M);
        for(int u=0;u<N;++u) {
            assert(f>>base_degree[u]);
            assert(2<=base_degree[u]&&base_degree[u]<=9);
            for(int b=0;b<K;++b) {
                int list=0;
                assert(f>>list&&0<=list&&list<32);
                colors[u][b]=std::uint8_t(list);
            }
        }
        for(int i=0;i<M;++i) {
            int u=0,v=0;
            assert(f>>u>>v);
            assert(0<=u&&u<v&&v<N&&!edge(u,v));
            graph[std::size_t(u)*width+v/64]|=U64(1)<<(v%64);
            graph[std::size_t(v)*width+u/64]|=U64(1)<<(u%64);
            nb[u].push_back(v);
            nb[v].push_back(u);
        }
        for(auto& r:nb) {
            std::sort(r.begin(),r.end());
            assert(std::adjacent_find(r.begin(),r.end())==r.end());
        }
        std::string extra;
        assert(!(f>>extra));
    }
    Adj adjacency(const Set& s) const {
        Adj a{};
        for(int i=0;i<s.n;++i)for(int j=i+1;j<s.n;++j)
            if(edge(s.v[i],s.v[j])){
                a[i]|=1u<<j;
                a[j]|=1u<<i;
            }
        return a;
    }
    static bool connected(const Adj& a,unsigned incl) {
        assert(incl);
        unsigned reached=0,front=incl&-incl;
        while(front) {
            int i=std::countr_zero(front);
            unsigned bit=1u<<i;
            front^=bit;
            reached|=bit;
            front|=a[i]&incl&~reached;
        }
        return reached==incl;
    }
    bool eligible_prefix(const Set& s,const Adj& a) const {
        for(int i=0;i<s.n;++i)
            if(base_degree[s.v[i]]+std::popcount(a[i])+6-s.n<5)return false;
        return true;
    }
    static bool list_colorable(const Adj& a,const Lists& masks,unsigned left) {
        if(!left)return true;
        int x=-1,k=6;
        for(unsigned rr=left;rr;rr&=rr-1) {
            int i=std::countr_zero(rr),p=std::popcount(masks[i]);
            if(!p)return false;
            if(p<k){x=i;k=p;}
        }
        assert(x>=0);
        unsigned after=left^(1u<<x);
        for(unsigned l=masks[x];l;l&=l-1) {
            unsigned color=l&-l;
            auto now=masks;
            for(unsigned rr=after&a[x];rr;rr&=rr-1)now[std::countr_zero(rr)]&=~color;
            if(list_colorable(a,now,after))return true;
        }
        return false;
    }
    void classify(const Set& s,const Adj& a) {
        assert(s.n==6&&eligible_prefix(s,a)&&connected(a,63));
        for(int b=0;b<K;++b) {
            Lists l{};
            for(int i=0;i<6;++i)l[i]=colors[s.v[i]][b];
            if(list_colorable(a,l,63)) {
                ++hit[b];
                return;
            }
        }
        if(++residual>100000) {
            std::cerr<<"Incomplete: residual output cap exceeded.\n";
            std::exit(6);
        }
        for(int i=0;i<6;++i)out<<(i?" ":"")<<s.v[i];
        out<<'\n';
        if(!out.good())std::exit(7);
    }
    void grow(const Set& s,const Adj& a) {
        assert(1<=s.n&&s.n<=6);
        assert(eligible_prefix(s,a)&&std::is_sorted(s.v.begin(),s.v.begin()+s.n));
        if(++visits>visit_cap) {
            std::cerr<<"Incomplete: per-shard connected-node cap exceeded.\n";
            std::exit(4);
        }
        ++at_size[s.n-1];
        if(s.n==6){classify(s,a);return;}
        for(int i=0;i<s.n;++i)for(int z:nb[s.v[i]]) {
            if(++growth>growth_cap) {
                std::cerr<<"Incomplete: per-shard expansion cap exceeded.\n";
                std::exit(5);
            }
            if(z<=s.v[0]||std::binary_search(s.v.begin(),s.v.begin()+s.n,z))continue;
            bool first=true;
            for(int j=0;j<i;++j)if(edge(z,s.v[j])){first=false;break;}
            if(!first)continue; // Generate this neighbor once from this parent.
            Set t=s;
            t.v[t.n++]=z;
            for(int j=s.n;j>0&&t.v[j]<t.v[j-1];--j)std::swap(t.v[j],t.v[j-1]);
            Adj b=adjacency(t);
            if(!eligible_prefix(t,b))continue;
            // Our parent must delete the greatest nonroot vertex whose
            // deletion leaves the induced remainder connected. Removing z
            // leaves the connected current set; reject any greater choice.
            int inserted=std::find(t.v.begin(),t.v.begin()+t.n,z)-t.v.begin();
            assert(0<inserted&&inserted<t.n);
            unsigned all=(1u<<t.n)-1;
            bool canonical=true;
            for(int j=t.n-1;j>inserted;--j)
                if(connected(b,all^(1u<<j))){canonical=false;break;}
            if(canonical)grow(t,b);
        }
    }
    void run() {
        for(int r=shard;r<N;r+=count) {
            Set s;
            s.n=1;
            s.v[0]=r;
            grow(s,{});
            ++roots;
        }
        assert(roots==1+(N-1-shard)/count&&at_size[0]==unsigned(roots));
        assert(visits==std::accumulate(at_size.begin(),at_size.end(),U64(0)));
        assert(at_size[5]==residual+std::accumulate(hit.begin(),hit.end(),U64(0)));
        out.flush();
        if(!out.good())std::exit(7);
        std::cout<<"COMPLETE "<<shard<<'/'<<count<<" roots "<<roots
                 <<" visits "<<visits<<" growth "<<growth<<" residual "<<residual<<'\n';
        std::cout<<"connected visits:";
        for(auto i:at_size)std::cout<<' '<<i;
        std::cout<<"\nfirst palette coverage:";
        for(auto i:hit)std::cout<<' '<<i;
        std::cout<<'\n';
    }
};
int main(int argc,char** argv) {
    if(argc!=7) {
        std::cerr<<"Usage: enumerate6_connected MASK_GRAPH RESIDUAL SHARD SHARDS VISIT_CAP EXPANSION_CAP\n";
        return 2;
    }
    Audit a(argv[1],argv[2],std::stoi(argv[3]),std::stoi(argv[4]),
            std::stoull(argv[5]),std::stoull(argv[6]));
    a.run();
}
