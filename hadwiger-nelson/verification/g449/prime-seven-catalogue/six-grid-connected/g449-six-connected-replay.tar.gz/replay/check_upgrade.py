#!/usr/bin/env python3
"""Enforce byte-identical candidate geometry and old palette masks."""
from argparse import ArgumentParser
from hashlib import sha256
from pathlib import Path

NEW_GRAPH='65a7f5c903caf1135be997a434d30d9548a065da5f60af813d3e7814542065ca'
OLD_GRAPH='3044d0f343d4f1a6e3d63ec04bad53b21ccb8c0df60cd4574696ed8dbfb57295'
COORDINATES='f944eea2d111cbe242c3b223155ade4f150e9a9da912795a1b57e956bebdcec9'


def verify(graph, coordinates):
    assert sha256(coordinates.read_bytes()).hexdigest()==COORDINATES
    assert sha256(graph.read_bytes()).hexdigest()==NEW_GRAPH
    g=sha256(b'7056 39 33908\n')
    with graph.open('rb') as f:
        assert f.readline()==b'7056 40 33908\n'
        for _ in range(7056):
            line=next(f)
            assert line.endswith(b'\n')
            v,last=line[:-1].rsplit(b' ',1)
            assert len(v.split())==40 and 0<=int(last)<32
            g.update(v+b'\n')
        count=0
        for line in f:
            g.update(line)
            count+=1
        assert count==33908
    assert g.hexdigest()==OLD_GRAPH
    print("40-palette graph projected to first 39 masks is byte-identical to the original pinned graph.")
    print("Candidate ID order and coordinate map are byte-identical.")


def main():
    a=ArgumentParser(description=__doc__)
    a.add_argument('work',type=Path)
    p=a.parse_args()
    verify(p.work/'graph.txt',p.work/'coordinates.txt')


if __name__=='__main__':main()
