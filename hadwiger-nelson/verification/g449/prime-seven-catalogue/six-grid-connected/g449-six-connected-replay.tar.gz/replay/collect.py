#!/usr/bin/env python3
"""Collect 0–10 v38, 11–35 v39, and 36–63 v40 connected-six shard receipts."""
from argparse import ArgumentParser
from pathlib import Path
import json
import re

from check_upgrade import verify

H=Path(__file__).resolve().parent
N,M,K=7056,33908,40
PAT=r'COMPLETE (\d+)/64 roots (\d+) visits (\d+) growth (\d+) residual (\d+)'


def receipt(where,h,k):
    rows=(where/f'{h}.log').read_text().splitlines()
    assert len(rows)==3 and (m:=re.fullmatch(PAT,rows[0])),h
    i,roots,visits,growth,resid=map(int,m.groups())
    assert i==h and roots==1+(N-1-h)//64
    def parse(row,prefix,n):
        assert row.startswith(prefix)
        x=list(map(int,row[len(prefix):].split()))
        assert len(x)==n and all(c>=0 for c in x)
        return x
    sizes=parse(rows[1],"connected visits:",6)
    colors=parse(rows[2],"first palette coverage:",k)
    assert sizes[0]==roots and sum(sizes)==visits
    assert sizes[-1]==sum(colors)+resid
    sets=[]
    with (where/f'{h}.residual').open() as f:
        for line in f:
            q=tuple(map(int,line.split()))
            assert len(q)==len(set(q))==6 and tuple(sorted(q))==q
            assert 0<=q[0] and q[-1]<N and q[0]%64==h
            sets.append(q)
    assert len(sets)==len(set(sets))==resid
    return sizes,colors,growth,sets


def prior_check():
    old38={j:receipt(H/'prior38',j,38) for j in range(12)}
    old39={j:receipt(H/'prior39',j,39) for j in range(11,37)}
    F11=json.loads((H/'witness11'/'fixture.json').read_text())
    F36=json.loads((H/'witness36'/'fixture.json').read_text())
    assert all(not old38[j][3] for j in range(11))
    assert list(map(list,old38[11][3]))==F11['triple_sets']
    sizes,pal,growth,sets=old39[11]
    assert (sizes,pal[:38],growth)==old38[11][:3] and pal[38]==3 and not sets
    assert all(not old39[j][3] for j in range(11,36))
    assert list(map(list,old39[36][3]))==F36['triple_sets']
    total=sum(old38[j][0][-1] for j in range(11))+sum(old39[j][0][-1] for j in range(11,37))
    assert total==6662000
    print("Original receipts through shard 35 have complete coverage; shard 36's one gap matches the witness fixture.")
    return old38,old39

def main():
    p=ArgumentParser(description=__doc__)
    p.add_argument('work',type=Path,nargs='?')
    p.add_argument('--prior-only',action='store_true')
    p.add_argument('--require-closed',action='store_true')
    p.add_argument('--check-36',action='store_true')
    p.add_argument('--receipts-only',action='store_true')
    p.add_argument('--all40',action='store_true')
    a=p.parse_args()
    old38,old39=prior_check()
    if a.prior_only:
        assert a.work is None
        return
    assert a.work is not None
    if a.receipts_only:
        assert a.require_closed and not a.check_36
    else:
        verify(a.work/'graph.txt',a.work/'coordinates.txt')
    def check_36():
        sizes,pal,growth,sets=receipt(a.work,36,40)
        assert (sizes,pal[:39],growth)==old39[36][:3]
        assert pal[-1]==1 and not sets
        print("Shard 36 reruns with identical visits and old coverage; palette 40 covers exactly the original gap.")
    check_36()
    if a.check_36:return
    if not a.receipts_only:
        with (a.work/'graph.txt').open() as f:
            assert tuple(map(int,next(f).split()))==(N,K,M)
            b=[]
            for _ in range(N):
                q=list(map(int,next(f).split()))
                assert len(q)==K+1 and 2<=q[0]<=9 and all(0<=v<32 for v in q[1:])
                b.append(q[0])
            nb=[set() for _ in range(N)]
            for _ in range(M):
                i,j=map(int,next(f).split())
                assert 0<=i<j<N and j not in nb[i]
                nb[i].add(j);nb[j].add(i)
            assert not f.read().strip()
    T=[0]*6;C=[0]*K;probes=0;residual=0
    for h in range(64):
        if a.all40:
            sizes,pal,growth,sets=receipt(a.work,h,40)
            if h<=10:
                assert (sizes,pal[:38],growth,sets)==old38[h] and pal[38:]==[0,0]
            elif h<=35:
                assert (sizes,pal[:39],growth,sets)==old39[h] and pal[39]==0
        elif h<=10:
            sizes,pal,growth,sets=old38[h]
            pal=pal+[0,0]
        elif h<=35:
            sizes,pal,growth,sets=old39[h]
            pal=pal+[0]
        else:
            sizes,pal,growth,sets=receipt(a.work,h,40)
        if a.receipts_only:assert not sets
        for q in sets:
            r=set(q)
            assert all(b[v]+len(nb[v]&r)>=5 for v in r)
            reach={q[0]}
            for _ in range(5):
                reach|=set.union(*(nb[v] for v in reach))&r
            assert reach==r
        T=[u+v for u,v in zip(T,sizes)]
        C=[u+v for u,v in zip(C,pal)]
        probes+=growth;residual+=len(sets)
    assert T[0]==N and T[-1]==sum(C)+residual
    print("All root shards covered; connected visits by size:",T)
    print("Expansion probes:",probes)
    print("First palette coverage:",C)
    print("Bank residuals:",residual)
    if a.require_closed:
        assert T==[7056,33908,363510,5326384,16292388,11652641]
        assert probes==1501845702 and residual==0


if __name__=='__main__':main()
