# Connected-six replay, forty verified palettes

**Verified connected branch.** All 64 least-ID root shards are completely
covered. Across them there were **11,652,641** eligible connected six-point
sets with all new base degrees at least two, and zero uncovered sets under
the final 40-palette bank. The run made 1,501,845,702 frontier probes,
with connected visits by size
`[7056, 33908, 363510, 5326384, 16292388, 11652641]`.
This relies on the preceding five-point theorem for the degree deletion
step and the exact grid direction catalogue for candidate completeness.
It is not a claim for disconnected six-sets or a new plane bound.

This package retains complete covered receipts from shards 0–10 (38
palettes) and 11–35 (39 palettes). The shard-36 bank gap has a positive
common five-coloring in `witness36/`. The solver-free witness verifier
rechecks all 103,285 exact distances and 2,242 induced edges. The
shard-11 eight-point model and its earlier verifier are in `witness11/`.
The relative witness fixtures contain the exact coordinate rows and
candidate IDs; regenerating the graph rematches these IDs.

Preparation must preserve the old coordinate bytes and, after projection
to the first 39 palettes, the entire v39 graph/profile bytes. Rerun
shard 36 under palette 40; its visits, expansion probes and old first
coverage counts must match, with exactly one additional cover and no
gap. Continue through 63 and stop on the next gap or
cap. Success indicates closure only for connected six-grid additions
with original degrees at least two. Disconnected configurations are
separate.

```sh
PYTHONPATH=RELATIVE_PATH_TO_EXACT_HELPERS ./replay_upgrade.sh \
  PINNED_G449_DIR denominator-seven-directions.tsv \
  extension-witnesses.json triple-residual-witness.json \
  four-witness.json five-witness.json FRESH_RUN_DIR 63
```

Set the last argument to 36 for only the rerun. The clean runner is
serial and enforces 132,000 KiB address-space and 25-second stage limits.


## Archived receipts and solver-free positive witnesses

```sh
sha256sum -c SHA256SUMS
sha256sum -c PRIOR.sha256
sha256sum -c CHECKED40.sha256
python3 collect.py checked40 --receipts-only --require-closed
PYTHONPATH=RELATIVE_PATH_TO_EXACT_HELPERS python3 witness11/verify.py PINNED_G449_DIR
PYTHONPATH=RELATIVE_PATH_TO_EXACT_HELPERS python3 witness36/verify.py PINNED_G449_DIR
```

The receipt-only check validates counters for all root shards and the
two bank upgrades without regenerating the graph. The clean runner
recomputes geometry and masks, verifies the v39 projection byte-for-byte,
and recomputes shards 36–63 by default (or all 64 in full replay mode). Hashes of the generated graph/coordinate
map are in `checked40/GENERATED.sha256`; the files themselves are not
redistributed. Palettes 39 and 40 were added from directly checked
positive finite models; no unverified solver claim is used.

## Completeness of the connected search

Every new vertex in a counterexample must have total degree at least
five: deleting a lower-degree one leaves a five-colorable five-point
extension, which extends greedily. With all new original-neighbor
counts at least two, each new grid point lies among the 7,056 sites
obtained by taking all 546 exact signed steps from all original
vertices and retaining outside sites with at least two incidences.
The complete induced graph on these sites has 33,908 edges. Its
coordinates and both old mask restrictions are hash-checked across
the two upgrades. Every accepted coloring avoids all original and
induced new edges, using lists derived from every original neighbor.

Assign a connected set to the shard of its least candidate ID modulo
64. Its unique parent deletes the largest nonroot candidate ID whose
deletion leaves the induced remainder connected. Such an ID exists
since any spanning tree has a leaf other than its specified root.
The generator tries a frontier site only from the first site of the
current set adjacent to it, then requires that augmentation to invert
the canonical parent. Iterating the parent reaches the singleton root,
so every connected set has one generation path, and no other shard
can duplicate it. A partial set $S$ can be pruned when
$b(v)+d_S(v)+(6-|S|)<5$: an eligible six-set cannot have such an
ancestor because new neighbors still to add are at most $6-|S|$.
At size six this pruning is the exact total-degree condition.
The method does not enumerate disconnected sets. A disconnected
extension must instead use a common base palette for its distinct
nonadjacent components or have a separate combined witness.

## Independent full replay option

With the light slot available, first check static archives, then
run the two solver-free witness verifiers and regenerate the graph
as shown above. An independent *complete* reference run can set
`ALL_40=1` at the same clean command and use the final argument `63`.
This recomputes all 64 shards against the very same final bank, with
the same per-stage 25-second timeout and 132,000 KiB cap, instead
of reusing any earlier shard coverage. It cross-checks shard counts
and old first-success restrictions against the archives. Run serially;
the aggregate runtime is several minutes. The independent full-from-scratch replay succeeded, matching the
archived visits, frontier probes, full first-palette counts and zero
residuals. The original sweep used receipts 0–10 at 38 palettes,
11–35 at 39 palettes and 36–63 at 40 palettes.
