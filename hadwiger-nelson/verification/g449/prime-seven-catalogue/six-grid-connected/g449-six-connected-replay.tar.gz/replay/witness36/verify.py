#!/usr/bin/env python3
"""Solver-free replay of the common positive witness on six fixed added points."""
from argparse import ArgumentParser
from functools import lru_cache
from hashlib import sha256
from itertools import combinations
from math import comb
from pathlib import Path
import json

from audit_layers import PHI, PINNED, parse_sparse6

ROOT=Path(__file__).resolve().parent
UNIT=(49,)+(0,)*11


def pinned(path, pin):
    raw=path.read_bytes()
    assert sha256(raw).hexdigest()==pin,path
    return raw


@lru_cache(maxsize=None)
def unit(q):
    terms=[(i,c) for i,c in enumerate(q) if c]
    f=[0]*42
    for i,x in terms:
        for j,y in terms:f[(i-j)%42]+=x*y
    for i in range(41,11,-1):
        if f[i]:
            for j,c in enumerate(PHI[:-1]):f[i-12+j]-=f[i]*c
    return tuple(f[:12])==UNIT


def main():
    p=ArgumentParser(description=__doc__)
    p.add_argument('pinned',type=Path)
    a=p.parse_args()
    F=json.loads((ROOT/'fixture.json').read_text())
    W=json.loads((ROOT/'witness.json').read_text())
    assert all(W[k]==v for k,v in F.items()) and W['base_sha256']==PINNED
    ids=F['candidate_ids']
    assert ids==sorted(set(ids)) and len(ids)==6
    R=F['triple_sets']
    assert len(R)==1 and all(sorted(set(x))==x and len(x)==6 and x[0]%64==36 for x in R)
    assert set().union(*map(set,R))==set(ids)
    pin_res=''.join(' '.join(map(str,row))+'\n' for row in R).encode('ascii')
    assert sha256(pin_res).hexdigest()==F['residual_sha256']
    q=pinned(a.pinned/'G449.k21',PINNED['G449.k21'])
    hdr,*raw=q.decode('ascii').splitlines()
    assert hdr.split()==['K21','42','12','49','449']
    s=[tuple(map(int,line.split())) for line in raw if line.strip()]
    assert len(s)==449 and all(len(v)==13 and all(c%7==0 for c in v[:-1]) for v in s)
    points=[tuple(c//7 for c in v[:-1]) for v in s]
    points.extend(map(tuple,F['points']))
    assert len(points)==len(set(points))==W['vertices']==455
    assert all(len(x)==12 for x in points)
    n,E=parse_sparse6(pinned(a.pinned/'G449.s6',PINNED['G449.s6']))
    assert n==449 and len(E)==2198
    colors=W['colors']
    assert len(colors)==455 and set(colors)==set('01234')
    induced=set()
    for i,j in combinations(range(455),2):
        d=tuple(x-y for x,y in zip(points[i],points[j]))
        if next(x for x in d if x)>0:d=tuple(-x for x in d)
        if unit(d):
            induced.add((i,j))
            assert colors[i]!=colors[j],(i,j)
    assert {e for e in induced if e[1]<449}==E
    assert len(induced)==W['edges']==2242
    print(f"{comb(455,2):,} exact pair distances; all {len(induced):,} induced edges checked.")
    print("One verified five-coloring covers the single shard-36 configuration.")


if __name__=='__main__':main()
