#!/usr/bin/env python3
"""Generate the pinned exact 7056-point grid graph and 40 palette masks."""
from argparse import ArgumentParser
from pathlib import Path
import json
from two_point_replay import absent,checked_colourings,load_data


def main():
    p=ArgumentParser(description=__doc__)
    p.add_argument('input',type=Path)
    p.add_argument('catalogue',type=Path)
    p.add_argument('single',type=Path)
    p.add_argument('triple',type=Path)
    p.add_argument('four',type=Path)
    p.add_argument('five',type=Path)
    p.add_argument('gap',type=Path)
    p.add_argument('fixture',type=Path)
    p.add_argument('gap36',type=Path)
    p.add_argument('fixture36',type=Path)
    p.add_argument('graph',type=Path)
    p.add_argument('coordinates',type=Path)
    a=p.parse_args()
    pts,orig,E,D=load_data(a.input,a.catalogue)
    palettes,_=checked_colourings(orig,E,a.single)
    for w in (a.triple,a.four,a.five,a.gap,a.gap36):
        c=tuple(map(int,json.loads(w.read_text())["colors"][:449]))
        assert len(c)==449 and set(c)==set(range(5))
        assert all(c[i]!=c[j] for i,j in E)
        palettes.append(c)
    assert len(palettes)==40
    def key(q):
        return sum(a << (8*i) for i,a in enumerate(q))
    def coords(k):
        out=[]
        for i in range(12):
            d=(k+128)%256-128
            out.append(d)
            k=(k-d)//256
        assert k==0
        return tuple(out)
    B=max(abs(v) for x in pts for v in x)
    S=max(abs(v) for d in D for v in d)
    # Candidate and translated keys lie in B+2S, with exact additive
    # packing injective by reduction modulo 256.
    assert B+2*S<128
    dd=sorted(key(x) for x in D)
    bb=[key(x) for x in pts]
    old=set(bb)
    assert len(old)==449 and len(set(dd))==len(dd)==546
    # Do not retain the ~230,000 mostly singleton neighbor groups.
    # Hashing partitions enumeration only: keys are still exact integers
    # and every original-plus-direction incidence enters just one bucket.
    rows=[]
    outside=0
    for h in range(16):
        local={}
        for i,x in enumerate(bb):
            for d in dd:
                z=x+d
                if hash(z)&15!=h or z in old:continue
                li=local.get(z)
                if li is None:
                    local[z]=i
                elif isinstance(li,int):
                    local[z]=[li,i]
                else:
                    li.append(i)
        outside+=len(local)
        for z,ns in local.items():
            if isinstance(ns,int):continue
            q=coords(z)
            assert key(q)==z and all(abs(x)<=B+S for x in q)
            assert 2<=len(ns)<=9 and all(i<j for i,j in zip(ns,ns[1:]))
            rows.append((q,ns))
        del local
    rows.sort()
    assert outside==229320 and len(rows)==7056
    for g,f,n in ((a.gap,a.fixture,8),(a.gap36,a.fixture36,6)):
        F=json.loads(f.read_text())
        W=json.loads(g.read_text())
        assert all(W[k]==v for k,v in F.items())
        assert len(F["candidate_ids"])==n
        assert [list(rows[i][0]) for i in F["candidate_ids"]]==F["points"]
    pp=[key(x) for x,_ in rows]
    index={x:i for i,x in enumerate(pp)}
    assert len(index)==7056
    edges=[]
    for i,x in enumerate(pp):
        js=[j for d in dd if (j:=index.get(x+d,-1))>i]
        assert len(js)==len(set(js))
        edges.extend((i,j) for j in sorted(js))
    assert len(edges)==33908
    with a.graph.open('w') as f:
        print(7056,40,33908,file=f)
        for _,ns in rows:
            print(len(ns),*(absent(ns,c) for c in palettes),file=f)
        for i,j in edges:
            print(i,j,file=f)
    with a.coordinates.open('w') as f:
        for x,_ in rows:print(*x,file=f)
    print("Exact grid graph: 7,056 candidate vertices, 33,908 edges, 40 checked base palettes.",flush=True)


if __name__=='__main__':main()
