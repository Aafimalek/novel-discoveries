# Equal-color witnesses for every original-edge reflected terminal pair

This exact solver-free check covers a particular one-addition
candidate family on the pinned G449. For every oriented original
edge X→Y, set Z=2Y−X. Because |X−Y|=1, the terminals X,Z have
distance two. The preceding complete pair census shows Z cannot
already be an original G449 site. We check every pair, deduplicating
by the exact original ID X and coefficient vector Z. There are
4,396 distinct reflected pairs, and in fact 4,396 distinct new sites.

The original-neighbor degrees of the added sites are:

| degree | number of sites |
|---:|---:|
| 1 | 4,074 |
| 2 | 273 |
| 3 | 28 |
| 4 | 21 |

All 4,396 terminal pairs have an explicit proper five-coloring of
the one-point extension giving the terminals the same color.
There are zero survivors under the 61 checked palettes. This rules
out forced inequality for this reflected-terminal family only.
It says nothing about general distance-two terminals added to
G449 or any whole-plane bound.

## Exact replay

The existing standard-library rotation loader and G449 audit
helpers check the two original files, regenerate all 546 signed
grid directions by exact cyclotomic arithmetic, and match the
2,198 actual original unit edges. The palette census report is
pinned independently; all 61 palettes are rechecked against
every original edge.

Coordinates are scaled by seven. Since Z=Y+(Y−X), coefficient
bounds keep the entire neighbor lookup in the injective range of
the exact base-256 key. Enumerating Z+d for all complete signed
grid directions d and matching by these keys gives every original
unit neighbor of Z. The completeness here uses the previously
proved grid direction catalogue. Properness on the original graph
and absence of the original terminal's color at every unit
neighbor of Z justify assigning that color at Z. No other edges
or constraints are added.

`reflected.json` stores every terminal ID, reflector ID, exact
new numerator, entire original-neighbor list, and one explicit
palette index plus shared color for each successful equality.
All 61 full proper base palettes are included once. The pinned
catalogue and the earlier `exact-distance2.json` are separate
existing inputs. To replay, put both the G449 audit and
`g449-v52-disconnected/` directories on PYTHONPATH:

```sh
sha256sum -c SHA256SUMS
(ulimit -v 132000; timeout 25s python3 reflected.py PINNED_G449_DIR \
  denominator-seven-directions.tsv exact-distance2.json NEW_RESULT.json)
cmp reflected.json NEW_RESULT.json
```

The actual successful guarded run was 0.582 seconds. No SAT query,
new-point search beyond the specified reflections, or forcing
assertion was made.
