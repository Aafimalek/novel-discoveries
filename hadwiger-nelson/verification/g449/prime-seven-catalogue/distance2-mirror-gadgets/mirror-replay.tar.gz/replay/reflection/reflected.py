#!/usr/bin/env python3
"""Exact one-addition distance-two terminals obtained from original unit edges."""
from argparse import ArgumentParser
from hashlib import sha256
from collections import Counter
from pathlib import Path
import json

from rotation_bank import load_data,key
from audit_layers import PINNED,sub

REPORT='fb955ab5e4db6ac2b7116c6b5fba66a5bdba5dbaeb77ea09f8de3f969ecd126b'
CATALOGUE='79347bb31ad25c1c6a10832be0d7d99ee2aa5c9a82899949ba58f4346f645280'


def main():
    p=ArgumentParser(description=__doc__)
    p.add_argument('base',type=Path)
    p.add_argument('catalogue',type=Path)
    p.add_argument('report',type=Path)
    p.add_argument('output',type=Path)
    a=p.parse_args()
    assert sha256(a.catalogue.read_bytes()).hexdigest()==CATALOGUE
    raw=a.report.read_bytes()
    assert sha256(raw).hexdigest()==REPORT
    U=json.loads(raw)
    assert U['base_vertices']==449 and U['distance_two_pairs']==0
    assert U['original_unit_edges']==2198 and U['complete_unordered_pair_checks']==100576
    assert U['pins']['coordinates']==PINNED['G449.k21'] and U['pins']['sparse6']==PINNED['G449.s6']
    G,orig,E,D=load_data(a.base,a.catalogue)
    assert len(G)==len(set(G))==449 and len(E)==2198 and len(D)==546
    P=U['palettes']
    assert [t['index'] for t in P]==list(range(61))
    C=[tuple(map(int,t['colors'])) for t in P]
    assert C[0]==orig
    assert all(len(q)==449 and set(q)==set(range(5)) and all(q[i]!=q[j] for i,j in E) for q in C)
    B=max(abs(x) for a in G for x in a);S=max(abs(x) for d in D for x in d)
    assert B+2*S<128
    old={key(t):i for i,t in enumerate(G)}
    offsets=[key(d) for d in D]
    assert len(old)==449 and len(offsets)==len(set(offsets))==546
    old_pts=set(G)
    allpairs={}
    for i0,j0 in sorted(E):
        for x,y in ((i0,j0),(j0,i0)):
            X,Y=G[x],G[y]
            d=sub(Y,X)
            assert d in D
            Z=tuple(2*v-u for u,v in zip(X,Y))
            # d is a unit vector in scaled coordinates; Z-X=2d.
            assert Z not in old_pts
            assert sub(Z,X)==tuple(2*w for w in d)
            assert sub(Z,Y)==d and all(abs(w)<=B+S for w in Z)
            same=allpairs.setdefault((x,Z),y)
            # For fixed X,Z the midpoint is unique, as are original rows.
            assert same==y
    assert len(allpairs)==4396
    N={}
    reject=[];survive=[]
    dh=Counter();sh=Counter()
    for (x,Z),y in sorted(allpairs.items()):
        if Z not in N:
            z=key(Z)
            # Every sum Z+step is in [-B-2S,B+2S]^12: packed
            # equality implies coefficientwise equality mod 256.
            ns=[old[z+t] for t in offsets if z+t in old]
            assert len(ns)==len(set(ns))
            N[Z]=tuple(sorted(ns))
        ns=N[Z]
        assert all(sub(Z,G[i]) in D for i in ns)
        assert y in ns and x not in ns
        dh[len(ns)]+=1
        record={'original_terminal':x,'reflector_y':y,'new_numerator':Z,
                'original_neighbors':ns,'denominator':7}
        k=next((i for i,c in enumerate(C) if all(c[v]!=c[x] for v in ns)),None)
        if k is None:
            assert all(any(c[v]==c[x] for v in ns) for c in C)
            survive.append(record)
            sh[len(ns)]+=1
        else:
            col=C[k][x]
            assert all(C[k][v]!=col for v in ns)
            record.update(palette_index=k,shared_terminal_color=col)
            reject.append(record)
    assert len(reject)+len(survive)==len(allpairs)
    out={'source_report_sha256':REPORT,'catalogue_sha256':CATALOGUE,
         'oriented_edges':2*len(E),'unique_terminal_pairs':len(allpairs),'unique_new_sites':len(N),
         'all_original_degree_histogram':dict(sorted(dh.items())),
         'survivor_original_degree_histogram':dict(sorted(sh.items())),
         'palettes':P,'rejected_with_explicit_equal_color':reject,'surviving_pairs':survive}
    a.output.write_text(json.dumps(out,separators=(',',':'))+'\n')
    print("4,396 oriented exact original unit edges; 4,396 distinct reflected terminal pairs.")
    print("Distinct new sites:",len(N),"original-neighbor degree histogram:",dict(sorted(dh.items())))
    print("Explicit checked equal-terminal witnesses:",len(reject),"survivors:",len(survive))
    print("Survivor original-neighbor degree histogram:",dict(sorted(sh.items())))
    print("No SAT or forcing claim; only original-edge reflection sites were tested.")


if __name__=='__main__':main()
