#!/usr/bin/env python3
"""Exact, solver-free distance-two terminal census for the pinned G449."""
from argparse import ArgumentParser
from functools import lru_cache
from hashlib import sha256
from itertools import combinations
from math import comb
from pathlib import Path
import json

from audit_layers import PHI,PINNED,POWERS,mul,parse_sparse6

ROOT=Path(__file__).resolve().parent
UNIT=(49,)+(0,)*11
TWO=(196,)+(0,)*11
ROUTES=('triple','four','five','gap11','gap36')


def load(paths,base):
    pins=json.loads((ROOT/'INPUTS.json').read_text())
    m=json.loads(paths.read_text())['paths']
    assert set(m)==set(pins)
    data={}
    for k,v in m.items():
        f=Path(v)
        if not f.is_absolute():f=base/f
        z=f.read_bytes()
        assert sha256(z).hexdigest()==pins[k],k
        data[k]=z
    assert pins['coordinates']==PINNED['G449.k21'] and pins['sparse6']==PINNED['G449.s6']
    return data,pins


@lru_cache(maxsize=None)
def flags(d):
    # d uses the normalized denominator-seven power basis.
    a=[0]*42
    coeff=[(i,u) for i,u in enumerate(d) if u]
    for i,u in coeff:
        for j,v in coeff:
            a[(i-j)%42]+=u*v
    for i in range(41,11,-1):
        if a[i]:
            for j,c in enumerate(PHI[:-1]):a[i-12+j]-=a[i]*c
    w=tuple(a[:12])
    return w==UNIT,w==TWO


def bank(initial,files,E):
    P=[tuple(initial)]
    names=['published']
    ss=json.loads(files['singles'])['single']
    assert len(ss)==34
    for i,s in enumerate(ss):
        P.append(tuple(map(int,s['colors'][:449])))
        names.append(f'single-{i}')
    for k in ROUTES:
        P.append(tuple(map(int,json.loads(files[k])['colors'][:449])))
        names.append(k)
    assert len(P)==40
    R=json.loads(files['rotations52'])['additional_palettes']
    assert len(R)==12
    for c in R:
        P.append(tuple(c['colors']))
        names.append(f'orbit-of-{c["source"]}-power-{c["power"]}')
    for k in ('palette53','palette54'):
        P.append(tuple(map(int,json.loads(files[k])['colors'][:449])))
        names.append(k)
    assert len(P)==54
    U=json.loads(files['bank61'])
    assert U['bank_size']==61 and U['profile_sha256']=='7b04a25fa89bb03d290a7288c10087f2afca2b4f58821b151e6a330dadf2fbf4'
    assert U['original_profile_sha256']=='9196e0d131b74895d94b754cb01efa022825d322f60b961e9e751156d0446cf2'
    for t in U['appended']:
        P.append(tuple(t['colors']))
        names.append(f'union17-power-{t["power"]}')
    assert len(P)==len(names)==61 and len(set(names))==61
    assert all(len(c)==449 and set(c)==set(range(5)) and all(c[i]!=c[j] for i,j in E) for c in P)
    return P,names


def rotation_orbits(Q,U,T):
    idx={q:i for i,q in enumerate(Q)}
    g=[idx[mul(q,POWERS[6])] for q in Q]
    assert sorted(g)==list(range(449))
    assert norm_one(POWERS[6])
    for i in range(449):
        j=i
        for _ in range(7):j=g[j]
        assert j==i
    def step(e):
        i,j=e[:2]
        return tuple(sorted((g[i],g[j])))
    assert {step(x) for x in U}==U
    TT=set(T)
    assert {step(x) for x in T}==TT
    ns={}
    count={}
    for q in T:
        if q in ns:continue
        orb={q}
        z=q
        for _ in range(6):
            z=step(z)
            orb.add(z)
        assert len(orb) in (1,7) and step(z)==q and not (orb&ns.keys())
        r=min(orb)
        for t in orb:ns[t]=r
        count[r]=len(orb)
    assert len(ns)==sum(count.values())==len(T)
    return g,ns,count


def norm_one(d):
    # Here d has denominator one, rather than seven.
    return flags(tuple(7*x for x in d))[0]


def main():
    p=ArgumentParser(description=__doc__)
    p.add_argument('paths',type=Path,help='JSON manifest mapping keys in INPUTS.json to their actual paths')
    p.add_argument('base',type=Path,help='directory resolving relative paths in the path manifest')
    p.add_argument('output',type=Path)
    p.add_argument('--off-orbit',action='store_true',help='skip orbit report; all unordered pairs are still tested')
    a=p.parse_args()
    files,pins=load(a.paths,a.base)
    h,*raw=files['coordinates'].decode('ascii').splitlines()
    assert h.split()==['K21','42','12','49','449']
    R=[tuple(map(int,r.split())) for r in raw if r.strip()]
    assert len(R)==449 and all(len(r)==13 and all(x%7==0 for x in r[:-1]) for r in R)
    Q=[tuple(x//7 for x in r[:-1]) for r in R]
    assert len(Q)==len(set(Q))==449
    n,E=parse_sparse6(files['sparse6'])
    assert n==449 and len(E)==2198
    U=set()
    T=[]
    for i,j in combinations(range(449),2):
        d=tuple(x-y for x,y in zip(Q[i],Q[j]))
        first=next(x for x in d if x)
        if first>0:d=tuple(-x for x in d)
        u,t=flags(d)
        assert not(u and t)
        if u:U.add((i,j))
        if t:T.append((i,j))
    assert U==E
    P,names=bank((r[-1] for r in R),files,U)
    g,mapping,orbits=rotation_orbits(Q,U,T) if not a.off_orbit else (None,{}, {})
    rejected=[];survivors=[]
    for i,j in T:
        C=[k for k,c in enumerate(P) if c[i]==c[j]]
        b={'ids':[i,j],'normalized_numerators':[Q[i],Q[j]], 'denominator':7}
        if mapping:b['orbit_representative']=mapping[(i,j)]
        if C:
            k=C[0]
            assert P[k][i]==P[k][j]
            b.update(same_color_palette_index=k,shared_color=P[k][i])
            rejected.append(b)
        else:
            assert all(c[i]!=c[j] for c in P)
            survivors.append(b)
    assert len(T)==len(rejected)+len(survivors)
    O=[{'representative':q,'size':n,'survivor_count':sum(tuple(x['orbit_representative'])==q for x in survivors)}
       for q,n in sorted(orbits.items())]
    if g is not None:assert sum(o['survivor_count'] for o in O)==len(survivors)
    out={'pins':pins,'base_vertices':449,'complete_unordered_pair_checks':comb(449,2),
         'original_unit_edges':len(U),'distinct_differences':flags.cache_info().misses,
         'distance_two_pairs':len(T),'rotation_permutation':g,'orbits':O,
         'palettes':[{'index':k,'name':names[k],'colors':''.join(map(str,c))} for k,c in enumerate(P)],
         'rejected_by_explicit_same_color_witness':rejected,'surviving_terminals':survivors}
    a.output.write_text(json.dumps(out,indent=2)+'\n')
    print(f"{comb(449,2):,} exact pair checks; {len(U):,} induced unit edges exactly match the pinned graph.")
    print(f"{len(T):,} exact distance-two pairs; {len(rejected):,} have an explicit same-color palette; {len(survivors):,} remain.")
    if g is not None:
        print(f"{len(orbits)} verified geometric orbits; first 61 palette filter applied to every pair separately.")
    print("No same-color solver query was run; surviving pairs are not forcing certificates.")


if __name__=='__main__':main()
