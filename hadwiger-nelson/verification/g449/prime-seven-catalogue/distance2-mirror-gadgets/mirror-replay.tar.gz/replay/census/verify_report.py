#!/usr/bin/env python3
"""Portable solver-free replay from pinned G449 files and saved palette table."""
from argparse import ArgumentParser
from hashlib import sha256
from itertools import combinations
from pathlib import Path
import json
from census import ROOT,flags,rotation_orbits
from audit_layers import PINNED,parse_sparse6

REPORT='fb955ab5e4db6ac2b7116c6b5fba66a5bdba5dbaeb77ea09f8de3f969ecd126b'


def read(p,s):
    z=p.read_bytes()
    assert sha256(z).hexdigest()==s,p
    return z


def main():
    p=ArgumentParser(description=__doc__)
    p.add_argument('g449',type=Path)
    a=p.parse_args()
    A=json.loads(read(ROOT/'exact-distance2.json',REPORT))
    inp=json.loads((ROOT/'INPUTS.json').read_text())
    assert A['pins']==inp and inp['coordinates']==PINNED['G449.k21'] and inp['sparse6']==PINNED['G449.s6']
    hdr,*data=read(a.g449/'G449.k21',PINNED['G449.k21']).decode('ascii').splitlines()
    assert hdr.split()==['K21','42','12','49','449']
    R=[tuple(map(int,r.split())) for r in data if r.strip()]
    assert len(R)==449 and all(len(r)==13 and all(x%7==0 for x in r[:-1]) for r in R)
    Q=[tuple(x//7 for x in r[:-1]) for r in R]
    assert len(Q)==len(set(Q))==449
    n,E=parse_sparse6(read(a.g449/'G449.s6',PINNED['G449.s6']))
    assert n==449 and len(E)==2198
    U=set();T=[];count=0
    for i,j in combinations(range(449),2):
        v=tuple(a-b for a,b in zip(Q[i],Q[j]))
        if next(x for x in v if x)>0:v=tuple(-x for x in v)
        e,t=flags(v)
        if e:U.add((i,j))
        if t:T.append((i,j))
        count+=1
    assert count==A['complete_unordered_pair_checks']==100576
    assert U==E and len(U)==A['original_unit_edges']==2198
    assert len(T)==A['distance_two_pairs']==0
    g,M,O=rotation_orbits(Q,U,T)
    assert g==A['rotation_permutation'] and not M and not O and not A['orbits']
    P=A['palettes']
    assert [r['index'] for r in P]==list(range(61))
    assert ''.join(str(r[-1]) for r in R)==P[0]['colors']
    assert all(len(r['colors'])==449 and set(r['colors'])==set('01234') and
               all(r['colors'][i]!=r['colors'][j] for i,j in E) for r in P)
    assert not A['rejected_by_explicit_same_color_witness'] and not A['surviving_terminals']
    print("100,576 exact pair distances; 2,198 induced unit edges; zero distance-two pairs.")
    print("All 61 saved palettes are proper and the exact order-seven action is verified.")


if __name__=='__main__':main()
