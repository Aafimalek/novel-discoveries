# The pinned G449 contains no distance-two terminal pair

Exact solver-free result: all 100,576 unordered pairs of the 449
original sites were checked, with **zero** pairs at distance two.
All 2,198 induced unit edges match the pinned G449. All 61 proper
base colorings in the existing bank were independently checked
on those edges, and multiplication by ζ₄₂⁶ gives the verified
order-seven vertex action. There are no terminal orbits, no
pairs rejected by a same-color witness, and no survivors, because
the geometric pair set itself is empty. This closes only the
distance-two-terminal scan **on the original G449**; it is not a
forcing result for extensions or a bound on the whole plane.

## Exact criterion

G449's input uses denominator 49, but every original coefficient
is divisible by seven. Divide coefficients by seven and use
common denominator seven. For a difference numerator polynomial
d, form its raw Laurent product d(X)d(X⁻¹), reduce exponents
modulo 42, and take the monic remainder modulo Φ₄₂. Exact squared
distance one means this remainder is the constant 49. Exact
squared distance four (distance two) means it is the constant
196. Distinct original coefficient rows are distinct algebraic
points because they have degree below the minimal polynomial.
No floating-point tolerance is involved.

## Portable proof and replay

With the existing exact helper `audit_layers.py` directory on
PYTHONPATH and the upstream pinned G449 input directory:

```sh
sha256sum -c SHA256SUMS
(ulimit -v 132000; timeout 25s python3 verify_report.py PINNED_G449_DIR)
```

This regenerates all exact distances and checks the archived 61
explicit proper color vectors; it need not fetch each source
witness. To recreate the original assembly of all palette inputs,
map each label of `INPUTS.json` to an actual source filename in a
JSON file of the form `{"paths": ...}`. Relative filenames are resolved against the base directory supplied
on the command line. Then run:

```sh
(ulimit -v 132000; timeout 25s python3 census.py \
  PATH_MAP_JSON BASE_FOR_RELATIVE_INPUT_PATHS NEW_REPORT.json)
```

The census would attach one explicit palette index and shared
color per rejected distance-two pair, backed by the full color
vectors in the report, plus exact coefficient rows for survivors.
Here both lists are empty. The actual full two-file pin, exact
census and palette checks exited successfully in 2.147 seconds
under the guards; the portable report verifier is statically
staged and not separately production-run. No same-color SAT
query or seven-point search ran.

A later construction would need terminals outside the original
449 sites. A bounded next fixture could use the old vertices
and a shortlist of high-original-degree exact grid sites, then
test pairs meeting at least one new site. The norm-numerator
condition must still be checked directly: simply doubling the
known denominator-seven unit catalogue need not catch every
distance-two pair, because halving a grid displacement can
leave the grid.
