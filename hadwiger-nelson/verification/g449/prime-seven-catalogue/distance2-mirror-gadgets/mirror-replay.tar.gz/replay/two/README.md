# Two-addition mirror gadgets: exact equality witnesses

For the pinned G449, choose any oriented original unit edge X→Y,
let Z=2Y−X, and add any distinct further grid site W not already
in the graph. Here the grid is the verified denominator-seven
cyclotomic grid. This check proves that **the distance-two terminals
X,Z can share a color in a proper five-coloring of the enlarged
graph**. It does not address terminals outside this reflected family
or catalysts outside the grid.

The 4,396 reflected terminal pairs already have explicit same-color
witnesses. If W is adjacent to Z and has at most three original
neighbors, or if W is nonadjacent to Z and has at most four original
neighbors, any such witness can be extended greedily at W: at most
four colors are forbidden. Thus only the exact 1,043 original-degree
at least four grid candidates are needed (only the degree-at-least-five
ones when nonadjacent).

The program regenerates all original neighbor lists of those candidates
by exact signed direction lookup, verifies every one of their 61 actual
list masks against the pinned v61 profile, and independently recreates
the complete original-neighbor lists of all reflected Z points.
Use a 61-bit palette universe. For a fixed terminal color c,
A_c contains precisely those palettes giving X color c and permitting
Z to use c. B contains palettes with a nonempty available list at W,
and B_c allows at least one W color other than c. For a nonadjacent
Z,W, the intersection (union_c A_c) ∩ B exactly tests the finite bank.
For adjacent Z,W, the exact test is union_c (A_c ∩ B_c).
In either case the checker selects an explicit feasible palette and
color, and checks the complete condition via the validated list masks.

## Verified counts

| case among 4,396 × 1,043 pairs | count |
|---|---:|
| W equals Z; excluded | 21 |
| nonadjacent W of original degree four; greedy | 2,061,031 |
| adjacent pairs explicitly palette-tested | 1,057 |
| nonadjacent pairs explicitly palette-tested | 2,522,919 |
| residuals | 0 |

All 2,523,976 explicit tests have positive same-color witnesses.
The deterministic witness stream is hashed rather than repeated
millions of times in a released file. For each positive record
pack (reflection index, catalyst ID, palette index, terminal color,
catalyst color) as little-endian `<HHBBB`, in program iteration
order. Its digest and the summary are in `summary.json`. The
residual file is empty. Other low-degree W are all proved by the
greedy argument above. The guarded exact run completed in 4.227
seconds; no SAT search ran.

## Replay

Put the G449 audit helper directory and the v52 standard-library
rotation loader directory on PYTHONPATH. Supply the already pinned
base files, exact signed catalogue, 7,056-site coordinate map,
exact v61 graph and reflected-family witness archive:

```sh
sha256sum -c SHA256SUMS
(ulimit -v 132000; timeout 25s python3 filter_two.py PINNED_G449_DIR \
  denominator-seven-directions.tsv CANDIDATE_COORDINATES graph61.txt \
  reflected.json NEW_SUMMARY.json NEW_RESIDUALS.jsonl)
cmp summary.json NEW_SUMMARY.json
cmp residuals.jsonl NEW_RESIDUALS.jsonl
```

No numerical tolerance, external communication or solver is needed.
Palette-bank success is a constructive positive five-coloring for
each case; no non-five-colorability inference is made.
