#!/usr/bin/env python3
"""Exact 61-palette equality filter for reflected terminal plus one grid catalyst."""
from argparse import ArgumentParser
from hashlib import sha256
from collections import Counter
from itertools import zip_longest
from pathlib import Path
from struct import Struct
import json

from rotation_bank import load_data,key,absent
from audit_layers import sub

PROFILE='7b04a25fa89bb03d290a7288c10087f2afca2b4f58821b151e6a330dadf2fbf4'
COORDS='f944eea2d111cbe242c3b223155ade4f150e9a9da912795a1b57e956bebdcec9'
REFLECTED='61be2ab122118ea7d29e95540536522273fbc9565608ceea0c5dc576d49707cd'
PACK=Struct('<HHBBB')


def read(p,h):
    b=p.read_bytes()
    assert sha256(b).hexdigest()==h,p
    return b


def least(x):
    assert x
    return (x&-x).bit_length()-1


def main():
    p=ArgumentParser(description=__doc__)
    for arg in ('base','catalogue','coordinate_map','profile61','reflected','result','residuals'):
        p.add_argument(arg,type=Path)
    a=p.parse_args()
    data=json.loads(read(a.reflected,REFLECTED))
    assert data['oriented_edges']==data['unique_terminal_pairs']==data['unique_new_sites']==4396
    assert not data['surviving_pairs']
    C=[tuple(map(int,b['colors'])) for b in data['palettes']]
    assert [b['index'] for b in data['palettes']]==list(range(61))
    rows=data['rejected_with_explicit_equal_color']
    assert len(rows)==4396
    G,orig,E,D=load_data(a.base,a.catalogue)
    assert len(E)==2198 and len(D)==546 and C[0]==orig
    assert all(len(c)==449 and set(c)==set(range(5)) and all(c[i]!=c[j] for i,j in E) for c in C)
    xs=read(a.coordinate_map,COORDS).splitlines()
    profile=read(a.profile61,PROFILE).splitlines()
    assert profile[0]==b'7056 61 33908'
    assert len(xs)==7056 and len(profile)==1+7056+33908
    high={}
    for i,(x,p) in enumerate(zip(xs,profile[1:7057])):
        nums=tuple(map(int,p.split()))
        assert len(nums)==62 and 2<=nums[0]<=9
        if nums[0]<4:continue
        v=tuple(map(int,x.split()))
        assert len(v)==12
        high[i]=(v,nums)
    assert len(high)==1043 and sum(deg[0]>=5 for _,deg in high.values())==574
    B=max(abs(x) for q in G for x in q);S=max(abs(x) for d in D for x in d)
    assert B+2*S<128
    offsets={key(d) for d in D}
    assert len(offsets)==546
    gg={key(q):i for i,q in enumerate(G)}
    kk={key(v):i for i,(v,_) in high.items()}
    assert len(gg)==449 and len(kk)==1043 and not gg.keys()&kk.keys()
    hn={i:[] for i in high}
    for i,q in enumerate(G):
        x=key(q)
        for d in offsets:
            w=kk.get(x+d)
            if w is not None:hn[w].append(i)

    candidates=[]
    for i,(v,nums) in high.items():
        n=hn[i]
        assert all(abs(x)<=B+S for x in v)
        assert len(n)==len(set(n))==nums[0]
        ms=tuple(absent(n,c) for c in C)
        assert ms==nums[1:]
        b=0;groups=[0]*5
        for k,t in enumerate(ms):
            if not t:continue
            b|=1<<k
            for c in range(5):
                if t&~(1<<c):groups[c]|=1<<k
        candidates.append((i,key(v),nums[0],ms,b,tuple(groups)))

    terminal=[]
    used=set()
    for q in rows:
        x,y=q['original_terminal'],q['reflector_y']
        z=tuple(q['new_numerator'])
        assert q['denominator']==7 and tuple(sorted((x,y))) in E
        assert z==tuple(2*b-a for a,b in zip(G[x],G[y]))
        assert all(abs(t)<=B+S for t in z)
        zz=key(z)
        assert zz not in gg and (x,zz) not in used
        used.add((x,zz))
        ns=tuple(sorted(gg[zz+t] for t in offsets if zz+t in gg))
        assert ns==tuple(q['original_neighbors']) and len(set(ns))==len(ns)
        assert y in ns and x not in ns
        A=[0]*5
        for i,col in enumerate(C):
            c=col[x]
            if all(col[w]!=c for w in ns):A[c]|=1<<i
        aa=sum(A)
        assert aa and aa&(1<<q['palette_index'])
        assert C[q['palette_index']][x]==q['shared_terminal_color']
        terminal.append((x,y,zz,ns,tuple(A),aa))

    stat=Counter()
    res_degree=Counter()
    digest=sha256()
    with a.residuals.open('w') as out:
        for ri,(x,y,zz,ns,A,aa) in enumerate(terminal):
            for w,wk,bw,ms,Bw,BC in candidates:
                if wk==zz:
                    stat['catalyst_equals_new_terminal']+=1
                    continue
                adj=(wk-zz) in offsets
                if not adj and bw==4:
                    stat['greedy_nonadjacent_degree4']+=1
                    continue
                stat['tested_adjacent' if adj else 'tested_nonadjacent']+=1
                if not adj:
                    possibles=aa&Bw
                    px=least(possibles) if possibles else None
                    c=C[px][x] if px is not None else None
                else:
                    px=None;c=None
                    for j in range(5):
                        possible=A[j]&BC[j]
                        if possible:
                            px=least(possible);c=j;break
                if px is None:
                    stat['residual_adjacent' if adj else 'residual_nonadjacent']+=1
                    res_degree[(len(ns),bw)]+=1
                    q={'reflection_index':ri,'terminal_x':x,'reflector_y':y,
                       'catalyst_candidate_id':w,'adjacent_to_z':adj,
                       'terminal_original_degree':len(ns),'catalyst_original_degree':bw}
                    out.write(json.dumps(q,separators=(',',':'))+'\n')
                    continue
                assert c==C[px][x] and (A[c]>>px)&1
                mask=ms[px]&(~(1<<c) if adj else 31)
                cw=least(mask)
                assert not adj or cw!=c
                stat['witness_adjacent' if adj else 'witness_nonadjacent']+=1
                # Stable digest of every checked positive witness
                # (reflection-index, catalyst-ID, palette, terminal color, catalyst color).
                digest.update(PACK.pack(ri,w,px,c,cw))
    total=4396*1043
    assert total==stat['catalyst_equals_new_terminal']+stat['greedy_nonadjacent_degree4']+stat['tested_adjacent']+stat['tested_nonadjacent']
    for s in ('adjacent','nonadjacent'):
        assert stat['tested_'+s]==stat['witness_'+s]+stat['residual_'+s]
    summary={'reflection_count':4396,'high_candidate_count':1043,'raw_cross_product':total,
             'counts':dict(sorted(stat.items())),
             'positive_witness_stream_sha256':digest.hexdigest(),
             'residual_file_sha256':sha256(a.residuals.read_bytes()).hexdigest(),
             'residual_degree_pairs':[{'terminal_degree':i,'catalyst_degree':j,'count':n} for (i,j),n in sorted(res_degree.items())]}
    a.result.write_text(json.dumps(summary,indent=2)+'\n')
    print(json.dumps(summary,indent=2),flush=True)
    print("No SAT or forcing claim.",flush=True)


if __name__=='__main__':main()
