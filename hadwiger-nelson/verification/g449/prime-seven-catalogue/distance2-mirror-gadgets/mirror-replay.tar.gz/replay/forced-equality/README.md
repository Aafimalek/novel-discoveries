# No forced-equal pair among G449's original vertices

All **100,576** original unordered vertex pairs have an explicit
proper five-coloring of the *same original graph* in which the two
colors differ. The **61** previously checked colorings suffice:
the 449 vertices have 449 distinct color signatures. Thus there
is no forced-equal original pair, regardless of geometric distance.
This is stronger than a negative bank search: a verified unequal
coloring for each pair actually disproves forced equality. It says
nothing about pairs in larger graphs.

The replay pins both original upstream input files, recomputes the
entire induced Euclidean unit graph by exact cyclotomic products
(2,198 edges), reconfirms the absence of any original distance-two
pair, and checks all explicit five-color vectors against every edge.
It then exhausts all pairs in lexicographic zero-based order
`(0,1), (0,2), ..., (447,448)`, with the binomial count independently
cross-checked by the signature groups. The byte at each index of
`first-unequal.bin` is the first index in the archived palette list
whose colors differ. The replay reserves byte 255 for no witness;
the table contains no such bytes.

To reproduce from the workspace root, with the pinned sources named
in the companion distance-two census README and inputs manifest:

```sh
(ulimit -v 132000; timeout 25s env \
  PYTHONPATH=g449-mod7-work:g449-distance2-census-stage \
  python3 g449-forced-equal-bank/filter_equal.py \
  g449-distance2-census-stage/paths.local.json . NEW_OUTPUT)
cmp NEW_OUTPUT/first-unequal.bin g449-forced-equal-bank/first-unequal.bin
cmp NEW_OUTPUT/exact-equality-filter.json g449-forced-equal-bank/exact-equality-filter.json
```

The input path map can substitute other locations for the same pinned
input bytes. The actual full replay completed in 2.270 s under the
displayed guards. There was no SAT call, no Lean check for this
particular computation, and no claim about the whole plane.

## Future distance-two search on a finite high-degree grid fixture (not run)

Let `q,r` be numerator rows in the power basis over denominator
seven and `d=q-r`. A necessary condition for distance two is
`d(X)d(X^-1) = 196 mod Phi_42(X)`, with equality in
`Z[X]/(Phi_42)` after reducing exponents modulo 42.

For each prime `p=43,127`, find a residue `t` with
`t^42=1` and `t^21,t^14,t^6 != 1`, all mod p. Such a residue
has exact order 42 (its prime factors are 2,3,7), and such
residues exist since `42 | p-1`. Because `p` does not divide
42, the roots of `X^42-1` are simple and an exact order-42
residue is a root of `Phi_42`. For each normalised site precompute
`(q(t),q(t^-1))` via modular Horner evaluation. Reject a pair if
`(q(t)-r(t)) * (q(t^-1)-r(t^-1)) != 196 mod p` at either prime.
More primitive roots, up to reciprocal equivalence, can add
necessary filters. Independently recompute the full integer
cyclotomic remainder for *every* survivor, so no precision or
probabilistic assertion enters the result.

On a two-added-terminal fixture of degree-at-least-four candidates,
there are at most binom(1043,2) pairs before the modular filter.
This is a finite search choice, *not* coverage of every possible
grid pair. There is no mutual unit edge for an actual distance-two
pair; the two added sites can receive their same color exactly
when their allowed-color lists for one checked palette intersect.
A positive witness refutes the particular forced-difference
candidate. A bank miss does not establish forced difference.
No modular or other new grid search was run here.
