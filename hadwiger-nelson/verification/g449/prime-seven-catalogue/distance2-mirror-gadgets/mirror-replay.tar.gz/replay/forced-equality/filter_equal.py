#!/usr/bin/env python3
"""Positive unequal-color witnesses on every rejected original G449 pair."""
import argparse
from collections import Counter
from fractions import Fraction as F
from functools import lru_cache
from hashlib import sha256
from itertools import combinations
from math import comb, factorial
from pathlib import Path
import json
from census import load, bank, flags, PHI, parse_sparse6

N=449

def difference(a,b):
    d=tuple(x-y for x,y in zip(a,b))
    first=next(x for x in d if x)
    return d if first<0 else tuple(-x for x in d)

def laurent(d):
    q=[0]*42
    for i,a in enumerate(d):
        for j,b in enumerate(d):
            q[(i-j)%42]+=a*b
    return q

def norm(d):
    w=laurent(d)
    for i in range(41,11,-1):
        a=w[i]
        if a:
            for j,c in enumerate(PHI[:-1]):
                w[i-12+j]-=a*c
            w[i]=0
    return w[:12]

def atan(x):
    m=16
    s=sum(((-1)**k*x**(2*k+1)/(2*k+1) for k in range(m)), F(0))
    return s,s+x**(2*m+1)/(2*m+1)

def cosbound(t):
    p=sum(((-1)**j*t**(2*j)/factorial(2*j) for j in range(15)), F(0))
    r=t**29/factorial(29)
    return p-r,p+r

@lru_cache(maxsize=1)
def cosines():
    # Machin: pi = 16 atan(1/5) - 4 atan(1/239).
    a,b=atan(F(1,5)); c,d=atan(F(1,239))
    lo,hi=16*a-4*d,16*b-4*c
    assert 3<lo<hi<F(22,7)
    # cos decreases on [0,pi]; 20*hi/21 < pi is certified by < lo.
    assert 20*hi<21*lo
    return [(F(1),F(1))]+[(cosbound(j*hi/21)[0],cosbound(j*lo/21)[1])
                              for j in range(1,21)]+[(F(-1),F(-1))]

def classify(d):
    p=norm(d)
    nlo=nhi=F(0)
    C=cosines()
    for j,a in enumerate(laurent(d)):
        x,y=C[min(j,42-j)]
        if a<0:x,y=y,x
        nlo+=a*x/49; nhi+=a*y/49
    scale=10**12
    lo=nlo*scale//1
    hi=-((-nhi*scale)//1)
    if p==[49]+[0]*11 or p==[441]+[0]*11: status='in-range-boundary'
    elif nlo>=1 and nhi<=9:status='in-range'
    elif nhi<1 or nlo>9:status='outside'
    else:status='undetermined'
    return p,[lo,hi],status

def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('paths',type=Path)
    ap.add_argument('base',type=Path)
    ap.add_argument('output',type=Path)
    a=ap.parse_args()
    files,pins=load(a.paths,a.base)
    h,*raw=files['coordinates'].decode('ascii').splitlines()
    assert h.split()==['K21','42','12','49',str(N)]
    rows=[tuple(map(int,r.split())) for r in raw if r.strip()]
    assert len(rows)==N and all(len(r)==13 and all(x%7==0 for x in r[:-1]) for r in rows)
    Q=[tuple(x//7 for x in r[:-1]) for r in rows]
    assert len(set(Q))==N
    nv,E=parse_sparse6(files['sparse6'])
    assert nv==N and len(E)==2198
    # Recompute the complete Euclidean unit graph; also reconfirm no
    # original distance two for the geometric reduction.
    exact=set(); two=0
    for i,j in combinations(range(N),2):
        u,t=flags(difference(Q[i],Q[j]))
        if u:exact.add((i,j))
        two+=t
    assert exact==E and two==0
    P,names=bank((r[-1] for r in rows),files,exact)
    signatures=Counter(tuple(c[i] for c in P) for i in range(N))
    table=bytearray()
    S=[]
    for i,j in combinations(range(N),2):
        w=next((k for k,c in enumerate(P) if c[i]!=c[j]),255)
        table.append(w)
        if w==255:
            assert (i,j) not in E
            d=difference(Q[i],Q[j])
            p,interval,status=classify(d)
            S.append({'vertices':[i,j],'numerators_over_7':[Q[i],Q[j]],
                      'normalized_difference':d,'squared_norm_numerator':p,
                      'squared_distance_bounds_times_10pow12':interval,'geometry':status})
        else:
            assert P[w][i]!=P[w][j]
    assert len(table)==comb(N,2)
    assert len(S)==table.count(255)==sum(comb(m,2) for m in signatures.values())
    a.output.mkdir(exist_ok=True)
    (a.output/'first-unequal.bin').write_bytes(table)
    out={'original_input_sha256': pins,'base_vertices':N,'exact_edges':len(E),
         'exact_pairs':len(table),'distance2_pairs':two,'distinct_signatures':len(signatures),
         'signature_multiplicity_histogram':dict(sorted(Counter(signatures.values()).items())),
         'unequal_witnesses':len(table)-len(S),'survivor_count':len(S),
         'survivor_geometry':dict(Counter(s['geometry'] for s in S)),
         'palettes':[{'name':n,'colors':''.join(map(str,c))} for n,c in zip(names,P)],
         'first_witness_table_sha256':sha256(table).hexdigest(),'survivors':S}
    (a.output/'exact-equality-filter.json').write_text(json.dumps(out,indent=2)+'\n')
    print(f'{len(table)} exact pairs, {len(E)} exact original edges, {two} original distance-two pairs')
    print(f'{len(P)} checked palettes; {len(signatures)} distinct color signatures')
    print(f'{len(table)-len(S)} differing-color witnesses, {len(S)} survivors; {out["survivor_geometry"]}')
    print(f'first-witness sha256 {out["first_witness_table_sha256"]}; no SAT')

if __name__=='__main__':main()
