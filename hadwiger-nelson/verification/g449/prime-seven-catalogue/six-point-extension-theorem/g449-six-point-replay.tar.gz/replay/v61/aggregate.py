#!/usr/bin/env python3
"""Stream all component records to a bounded-cache catalogue, then minimize."""
from argparse import ArgumentParser
from hashlib import sha256
from pathlib import Path
import json,re,sqlite3

N,K=7056,61
PROFILE='7b04a25fa89bb03d290a7288c10087f2afca2b4f58821b151e6a330dadf2fbf4'
FULL=(1<<K)-1
COUNTS=[574,2079,13188,115395,1119839]
PAT=r'COMPLETE (\d+)/(\d+) roots (\d+) visits (\d+) growth (\d+) members (\d+)'
INSERT='''INSERT INTO masks (s,m,pop,n) VALUES (?,?,?,1)
          ON CONFLICT(s,m) DO UPDATE SET n=n+1'''


def log(path,h,n):
    rows=path.read_text().splitlines()
    assert len(rows)==3 and (m:=re.fullmatch(PAT,rows[0])),path
    a,b,r,visits,growth,generated=map(int,m.groups())
    assert (a,b)==(h,n) and r==1+(N-1-h)//n
    def read(row,prefix):
        assert row.startswith(prefix)
        a=[int(x) for x in row[len(prefix):].split()]
        assert len(a)==5 and min(a)>=0
        return a
    v=read(rows[1],"connected visits:")
    c=read(rows[2],"eligible components:")
    assert v[0]==r and sum(v)==visits and sum(c)==generated
    assert all(x<=y for x,y in zip(c,v))
    return v,c,growth


def antichain(cursor,s,cap):
    # A bit in contains[p] names a previously retained mask containing p.
    # An earlier retained mask is a subset of m iff it has no bit outside m.
    # Increasing support cardinality ensures no future strict subset.
    contains=[0]*K
    ids=0
    keep=[]
    query=0
    for m,p,n in cursor.execute("SELECT m,pop,n FROM masks WHERE s=? ORDER BY pop,m",(s,)):
        assert m.bit_count()==p and n>0
        query+=1
        bad=0
        rhs=FULL^m
        while rhs:
            low=rhs&-rhs
            rhs^=low
            bad|=contains[low.bit_length()-1]
            if bad==ids:break
        if bad!=ids:continue
        if len(keep)>=cap:raise RuntimeError("antichain capacity reached; no closure certified")
        bit=1<<len(keep)
        ids|=bit
        keep.append(m)
        v=m
        while v:
            low=v&-v
            v^=low
            contains[low.bit_length()-1]|=bit
    assert keep and query>=len(keep)
    return keep,query


def main():
    p=ArgumentParser(description=__doc__)
    p.add_argument('work',type=Path)
    p.add_argument('shards',type=int)
    p.add_argument('profile',type=Path)
    p.add_argument('--antichain-cap',type=int,default=100000)
    a=p.parse_args()
    assert 1<=a.shards<=N and 0<a.antichain_cap<=100000
    assert sha256(a.profile.read_bytes()).hexdigest()==PROFILE
    database=a.work/'mask-catalogue.sqlite'
    assert not database.exists()
    c=sqlite3.connect(database)
    c.execute("PRAGMA cache_size=-2048")
    c.execute("PRAGMA temp_store=FILE")
    c.execute("PRAGMA journal_mode=DELETE")
    c.execute("CREATE TABLE masks(s INT,m INT,pop INT,n INT, PRIMARY KEY(s,m)) WITHOUT ROWID")
    T=[0]*5;V=[0]*5;G=0
    for h in range(a.shards):
        v,expected,g=log(a.work/f'{h}.log',h,a.shards)
        observed=[0]*5
        block=[]
        with (a.work/f'{h}.members').open() as f:
            for line in f:
                s,m,*ids=map(int,line.split())
                assert 1<=s<=5 and 0<m<=FULL
                assert len(ids)==len(set(ids))==s and ids==sorted(ids)
                assert 0<=ids[0]<=ids[-1]<N and ids[0]%a.shards==h
                observed[s-1]+=1
                block.append((s,m,m.bit_count()))
                if len(block)==2048:
                    c.executemany(INSERT,block)
                    block.clear()
        c.executemany(INSERT,block)
        assert observed==expected,h
        c.commit()
        T=[a+b for a,b in zip(T,observed)]
        V=[a+b for a,b in zip(V,v)]
        G+=g
    assert T==COUNTS and V[0]==N and V[4]==COUNTS[4]
    c.execute("CREATE INDEX ordered ON masks(s,pop,m)")
    c.commit()
    report={'profile_sha256':PROFILE,'bank_size':K,'component_counts':T,'visit_counts':V,
            'frontier_probes':G,'families':{}}
    for s in range(1,6):
        count,distinct=c.execute("SELECT sum(n),count(*) FROM masks WHERE s=?",(s,)).fetchone()
        assert count==T[s-1]
        # The only unsettled partitions use component sizes <=3. The
        # full masks/counts of sizes 4,5 are still emitted and audited.
        if s<=3:
            ms,q=antichain(c,s,a.antichain_cap)
            assert distinct==q
            report['families'][str(s)]={'distinct':distinct,'minimal':ms,
                                       'maximum_rejections':max(K-m.bit_count() for m in ms)}
            print(f"Size {s}: {count:,} components, {distinct:,} masks, {len(ms):,} minimal masks.",flush=True)
        else:
            report['families'][str(s)]={'distinct':distinct,'minimization':'not needed for remaining partitions'}
            print(f"Size {s}: {count:,} components, {distinct:,} masks; no minimization needed.",flush=True)
    (a.work/'minima.json').write_text(json.dumps(report,separators=(',',':'))+'\n')
    print("All generated component IDs remain in the original shard membership files.",flush=True)


if __name__=='__main__':main()
