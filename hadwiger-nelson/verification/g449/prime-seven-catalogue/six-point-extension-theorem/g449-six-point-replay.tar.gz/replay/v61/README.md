# G449: eight disconnected six-point partitions verified

This v61 exact run verifies eight disconnected partitions of six
added grid points with all original degrees at least two:
(5,1), (4,2), (4,1,1), (3,3), (3,2,1), (3,1,1,1), (2,2,2),
and (2,2,1,1). Only (2,1,1,1,1) and (1,1,1,1,1,1) remain
unsettled. They both reached the declared query cap. No new
abstract gap was observed before those caps, and no exclusion
or six-point theorem is claimed for them.

## Direct positive witness and exact rotation append

The three concrete v54 bank gaps share one five-coloring on their
17-site union. Using the accompanying exact union fixture and
positive-model verifier, all 108,345 distances on 466 distinct
sites were recomputed by Laurent/cyclotomic reduction, and the
saved color vector was checked on all 2,325 induced edges.
The complete original edge set matches the pinned G449. The
original colors and their six nonidentity rotations form seven
new palettes, distinct up to global relabeling from each other
and the actual previous 54 palettes.

The append step replays the finite positive witness without a solver,
regenerates all actual original-neighbor lists, independently checks
all 54 old palettes against all old mask rows, and checks exact
ζ₄₂⁶ permutation action on 449/7,056 sites, the original/candidate
edge sets, direction catalogue and all original-neighbor incidences.
All 54 previous profile columns survive byte-for-byte. See the
separate `g449-v54-union17-stage` source package and the immutable
fixture, positive witness and append receipts in `verified/`.
The exact new graph profile is pinned in `PROFILE.sha256`.

## One full component round and exactly three joins

All 64 guarded shards completed once. Component counts by size
remain 574, 2,079, 13,188, 115,395 and 1,119,839. Distinct mask sizes
are 377, 1,355, 6,678, 41,959 and 293,095. Only the three active
families of sizes 1–3 require minimization in this round; they
leave 189, 610 and 2,104 inclusion-minimal masks. Raw membership
records for all sizes are present in the guarded local run and
can be regenerated.

The earlier seven partitions are inherited, because adding proper
palettes preserving the exact old profile cannot remove a common
palette. Exact singleton-pair intersections have 17,955 raw,
17,849 distinct and 11,888 inclusion-minimal masks. The (3,1,1,1)
join checks every one of its 397,656 queries against a complete
target index and finds no disjoint mask; thus every abstract tuple
has a common palette and every actual case is covered.
The two remaining joins were each stopped at 2,000,000 trials
(no abstract gap found; not a proof). We did not perform any
geometry-compatible realization search on them, as no new
abstract witness emerged. All ten outcomes are explicitly
recorded in `verified/partition-summary.json`.

Each stage was guarded by a hard 132,000 KiB address-space cap
and a 25-second timeout. Follow the exact prior connected-search
canonical-parent proof for component completeness. For disconnected
candidates the degree deletion criterion uses the preceding
five-point theorem and the degree inside each component.
No result here changes the full-plane chromatic bounds.

## Replay

Use `g449-v54-union17-stage/union17.py` without `--solver` to
verify the positive model, and its `append_checked.py` with both
exact helper paths and all old palette inputs to regenerate the
profile. Check package and recorded run hashes with
`sha256sum -c SHA256SUMS` and `sha256sum -c VERIFIED.sha256`.
Then guard each exact production stage:

```sh
sha256sum -c PROFILE.sha256
./stage_components.sh graph61.txt FRESH_RUN_DIRECTORY 64
(ulimit -v 132000; timeout 25s python3 direct_join.py \
  FRESH_RUN_DIRECTORY/minima.json join.json 3111)
```

The other two join labels are 21111 and 111111 at the recorded
2,000,000-trial cap. All raw members retain per-shard hashes in
`complete-v61/`; they need not be redistributed. The existing
witness is a positive finite certificate, so the replay uses
no unverified solver outcome.
