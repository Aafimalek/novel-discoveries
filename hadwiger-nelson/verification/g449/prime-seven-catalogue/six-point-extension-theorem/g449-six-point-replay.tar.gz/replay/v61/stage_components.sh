#!/usr/bin/env bash
set -euo pipefail
if [ "$#" -lt 3 ] || [ "$#" -gt 4 ]; then
  echo "usage: $0 EXACT_V61_GRAPH FRESH_DIR SHARDS [LAST_SHARD]" >&2
  exit 2
fi
here=$(cd -- "$(dirname -- "$0")" && pwd)
graph=$(realpath -- "$1")
work=$(realpath -m -- "$2")
shards=$3
last=${4:-$((shards-1))}
[[ "$shards" =~ ^[1-9][0-9]{0,3}$ && "$shards" -le 7056 ]]
[[ "$last" =~ ^[0-9]{1,4}$ && "$last" -lt "$shards" ]]
mkdir -- "$work"
cd -- "$work"
ulimit -v 132000
unset PYTHONOPTIMIZE
export PYTHONDONTWRITEBYTECODE=1
expect=7b04a25fa89bb03d290a7288c10087f2afca2b4f58821b151e6a330dadf2fbf4
printf '%s  %s\n' "$expect" "$graph" | sha256sum -c -
timeout 25s "${CXX:-g++}" -std=c++20 -O0 -g0 --param=ggc-min-expand=1 --param=ggc-min-heapsize=1024 "$here/components.cpp" -o components
sha256sum components "$here/components.cpp" >BINARY.sha256
for ((h=0; h<=last; h++)); do
  printf '%s  %s\n' "$expect" "$graph" | sha256sum -c --quiet -
  sha256sum -c --quiet BINARY.sha256
  (time timeout 25s ./components "$graph" "${h}.members" "$h" "$shards" 1500000 80000000 >"${h}.log") 2>"${h}.time"
  sha256sum "${h}.log" "${h}.time" "${h}.members" >"${h}.sha256"
  chmod a-w "${h}.log" "${h}.time" "${h}.members" "${h}.sha256"
  head -1 "${h}.log"
done
if [ "$last" -eq "$((shards-1))" ]; then
  timeout 25s python3 "$here/aggregate.py" . "$shards" "$graph" | tee aggregate.log
fi
