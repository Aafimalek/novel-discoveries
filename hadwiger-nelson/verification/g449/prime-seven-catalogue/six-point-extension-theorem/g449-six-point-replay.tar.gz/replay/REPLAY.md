# Rebuild the G449 disconnected check from the exact inputs

This archive contains only public directions, positive color vectors,
proof code, and deterministic finite-run receipts.
The original input is the G449 authors'
[pinned repository](https://github.com/bprzybocki/G449/tree/125bfda97ed1d336f84694de04dedcfb349c5164).
Provide the directory with `G449.k21` and `G449.s6`; both SHA-256
values are checked by the loader. All other input files are here.
Run with ordinary Python (not `-O`); the checks use assertions.
A C++20 compiler, Python 3, and GNU `timeout` are required.

## Exact profiles and component masks

From this extracted directory, use fresh output directories:

```sh
set -e
sha256sum --strict -c SHA256SUMS
(ulimit -v 132000; timeout 25s python3 make_profiles.py PINNED_G449_DIR /path/to/profiles)
for k in 52 54 61; do
  bash "v$k/stage_components.sh" "/path/to/profiles/graph$k.txt" "/path/to/masks$k" 64
  cmp "v$k/verified/minima.json" "/path/to/masks$k/minima.json"
done
```

The first executable regenerates each candidate from the complete
exact signed direction catalogue, verifies every original edge
and every base palette, independently constructs all induced
candidate edges and neighbor color lists, and checks four exact
profile hashes. It does not ask a solver to verify a color vector.
For the proof that the direction catalogue is complete, see the
[pinned catalogue proof](https://github.com/Aafimalek/novel-discoveries/tree/f7be4c235d3d6bc073058db7fb201663ed7955e7/hadwiger-nelson/verification/g449/prime-seven-catalogue).
The component generator completes each root shard once and uses
an exact disk-backed mask aggregation and inclusion-minimal reduction.

## Partition joins

At 52 palettes, the following five partition indices have exact
closure (temporary result names can be chosen freely):

```sh
for i in 0 1 2 3 6; do
  (ulimit -v 132000; timeout 25s python3 v52/abstract_cover.py /path/to/masks52/minima.json "result52-$i.json" --only-partition "$i")
done
for part in 321 2211; do
  (ulimit -v 132000; timeout 25s python3 v54/direct_join.py /path/to/masks54/minima.json "result54-$part.json" "$part")
done
(ulimit -v 132000; timeout 25s python3 v61/direct_join.py /path/to/masks61/minima.json result61-3111.json 3111)
```

Each completed join establishes that the acceptance masks for
the corresponding component sizes always intersect. The old
mask prefixes are exact restrictions of the new profile, so no
closed case is lost when more palettes are added.

## Last two partitions

Check `cmp v61/verified/minima.json last-joins/minima.json` (or compare a
freshly generated `masks61/minima.json` after the component run).
The archived receipt check is portable and read-only:

```sh
(cd last-joins; sha256sum --strict -c SHA256SUMS; python3 verify_archive.py)
```

For a clean production replay, follow [last-joins/README.md](last-joins/README.md)
and `replay_batch.sh`, covering exactly coarse ordinals 0 through 60 and
refined ordinals 0 through 25. The pair-plus-four-singleton join covers
7,251,680 raw queries without a gap; the six-singleton join covers
70,668,216. This checks the exact input geometry and the complete
finite-search proof, with no SAT solver or floating point decisions.
