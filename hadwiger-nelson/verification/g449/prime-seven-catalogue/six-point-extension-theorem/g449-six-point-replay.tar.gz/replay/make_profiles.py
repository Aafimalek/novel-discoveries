#!/usr/bin/env python3
"""Regenerate candidate geometry and all profile prefixes from proper base palettes."""
from argparse import ArgumentParser
from hashlib import sha256
from pathlib import Path
import json
import sys

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / "geometry"))
from rotation_bank import absent, base_palettes, load_data, key

PINS = {
    40: "65a7f5c903caf1135be997a434d30d9548a065da5f60af813d3e7814542065ca",
    52: "73015e2075b9f05f73eadc2316d1250efa5777dede3866c29d58ca602f109bb7",
    54: "9196e0d131b74895d94b754cb01efa022825d322f60b961e9e751156d0446cf2",
    61: "7b04a25fa89bb03d290a7288c10087f2afca2b4f58821b151e6a330dadf2fbf4",
}
COORDS_SHA = "f944eea2d111cbe242c3b223155ade4f150e9a9da912795a1b57e956bebdcec9"


def load(name):
    return json.loads((ROOT / "palettes" / name).read_text())


def make(base, out):
    G, orig, E, D = load_data(base, ROOT / "palettes/denominator-seven-directions.tsv")
    bank = base_palettes(orig, E, ROOT / "palettes/extension-witnesses.json")
    for file in ("triple-residual-witness.json", "four-witness.json", "five-witness.json",
                 "gap11.json", "gap36.json"):
        bank.append(tuple(map(int, load(file)["colors"][:449])))
    assert len(bank) == 40
    bank.extend(tuple(p["colors"]) for p in load("rotated-bank.json")["additional_palettes"])
    assert len(bank) == 52
    for file in ("witness53.json", "witness54.json"):
        bank.append(tuple(map(int, load(file)["colors"][:449])))
    assert len(bank) == 54
    bank.extend(tuple(p["colors"]) for p in load("bank-next.json")["appended"])
    assert len(bank) == 61
    assert all(len(c) == 449 and set(c) == set(range(5)) and
               all(c[i] != c[j] for i,j in E) for c in bank)

    bound_g = max(abs(v) for q in G for v in q)
    bound_d = max(abs(v) for q in D for v in q)
    assert bound_g + 2*bound_d < 128  # injective signed base-256 coefficient encoding
    dd = sorted(key(q) for q in D)
    bb = [key(q) for q in G]
    old = set(bb)
    assert len(old) == 449 and len(set(dd)) == 546

    def decode(z):
        q = []
        for _ in range(12):
            d = (z + 128) % 256 - 128
            q.append(d)
            z = (z-d)//256
        assert z == 0
        return tuple(q)

    rows=[]; all_outside=0
    for h in range(16):
        local={}
        for i,p in enumerate(bb):
            for d in dd:
                z=p+d
                if hash(z)&15 != h or z in old:
                    continue
                ns=local.get(z)
                if ns is None:
                    local[z]=i
                elif isinstance(ns,int):
                    local[z]=[ns,i]
                else:
                    ns.append(i)
        all_outside+=len(local)
        for z,ns in local.items():
            if not isinstance(ns,int):
                q=decode(z)
                assert key(q)==z and len(ns)==len(set(ns)) and 2<=len(ns)<=9
                rows.append((q,ns))
    rows.sort()
    assert all_outside == 229320 and len(rows) == 7056
    pp=[key(q) for q,_ in rows]
    ix={p:i for i,p in enumerate(pp)}
    assert len(ix)==7056
    edges=[(i,j) for i,p in enumerate(pp)
           for j in sorted(ix[p+d] for d in dd if ix.get(p+d,-1)>i)]
    assert len(edges)==len(set(edges))==33908
    out.mkdir()
    path=out/"coordinates.txt"
    with path.open("w") as f:
        for q,_ in rows:
            print(*q,file=f)
    assert sha256(path.read_bytes()).hexdigest()==COORDS_SHA
    masks=[(len(ns), *(absent(ns,c) for c in bank)) for _,ns in rows]
    for K, pin in PINS.items():
        path=out/f"graph{K}.txt"
        with path.open("w") as f:
            print(7056,K,33908,file=f)
            for row in masks:
                print(*row[:K+1],file=f)
            for i,j in edges:
                print(i,j,file=f)
        assert sha256(path.read_bytes()).hexdigest()==pin, (K,sha256(path.read_bytes()).hexdigest())
    print("Regenerated exact coordinates, 2198 original edges, 33908 candidate edges; all 61 base palettes proper.")
    print("Byte-identical 40-, 52-, 54- and 61-palette profiles.")


if __name__ == "__main__":
    p=ArgumentParser(description=__doc__)
    p.add_argument("base",type=Path)
    p.add_argument("clean_out",type=Path)
    a=p.parse_args()
    make(a.base,a.clean_out)
