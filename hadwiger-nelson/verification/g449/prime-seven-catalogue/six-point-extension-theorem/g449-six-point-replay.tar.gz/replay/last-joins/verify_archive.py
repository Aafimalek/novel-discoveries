#!/usr/bin/env python3
"""Read-only portable receipt verification for both final v61 joins."""
from argparse import ArgumentParser
from hashlib import sha256
from pathlib import Path
import json
from ast import literal_eval

from sharded_join import payload,loaded
from refined import small_plan,START

ROOT=Path(__file__).resolve().parent


def digest(p):
    return sha256(p.read_bytes()).hexdigest()


def manifest(base,name,allowed):
    got=set()
    for line in (base/name).read_text().splitlines():
        h,v=line.split('  ',1)
        assert len(h)==64 and v in allowed and v not in got
        got.add(v)
        assert digest(base/v)==h,(name,v)
    assert got==set(allowed)


def active(work,plan,names):
    lines=(work/'ACTIVE.sha256').read_text().splitlines()
    located={}
    for line in lines:
        h,p=line.split('  ',1)
        name=Path(p).name
        assert name not in located
        located[name]=h
    assert set(located)==set(names)|{plan}
    assert digest(work/plan)==located[plan]
    for s in names:assert digest(ROOT/s)==located[s]


def completed(work,name,pins,part,lo,hi,n):
    manifest(work,name+'.sha256',[name+'.json',name+'.log',name+'.time'])
    a=json.loads((work/(name+'.json')).read_text())
    assert literal_eval((work/(name+'.log')).read_text())==a
    assert a['pins']==pins and a['partition']==part
    assert a['first_range']==[lo,hi] and a['expected']==a['tried']==n
    assert a['gap'] is None and a['result']=='complete; all tuples intersect'
    assert 0<a['exact_queries']<=n
    return a['exact_queries']


def main():
    p=ArgumentParser(description=__doc__)
    p.add_argument('coarse',type=Path,nargs='?',default=ROOT/'run-v61-last2')
    p.add_argument('refined',type=Path,nargs='?',default=ROOT/'run-v61-refined')
    a=p.parse_args()
    f,q,key=payload()
    active(a.coarse,'plan.json',('minima.json','sharded_join.py','direct_join.py'))
    active(a.refined,'refined-plan.json',('minima.json','sharded_join.py','refined.py','direct_join.py'))
    coarse=loaded(a.coarse/'plan.json',f,q,key)
    fine=small_plan(coarse,len(q),key)
    assert json.loads((a.refined/'refined-plan.json').read_text())==fine
    found={}
    keep_coarse=set()
    for p,lim in (('21111',7),('111111',54)):
        seen=cnt=0
        h=0
        for l,r,n in coarse['plans'][p]['chunks'][:lim]:
            assert l==h
            name=f'{p}-{l}-{r}'
            cnt+=completed(a.coarse,name,key,p,l,r,n)
            keep_coarse.add(name+'.json')
            seen+=n
            h=r
        assert h==(610 if p=='21111' else START)
        found[p]=(seen,cnt)
    assert {p.name for p in a.coarse.glob('[0-9]*-*-*.json')}==keep_coarse
    assert found['21111'][0]==7251680 and found['111111'][0]==64618235
    keep_fine=set()
    h=START;seen=cnt=0
    for l,r,n in fine['chunks']:
        assert l==h
        name=f'{l}-{r}'
        cnt+=completed(a.refined,name,key,'111111',l,r,n)
        seen+=n
        h=r
        keep_fine.add(name+'.json')
    assert {p.name for p in a.refined.glob('[0-9]*-[0-9]*.json')}==keep_fine
    assert seen==6049981 and h==len(q)==11888
    m=found['111111'][0]+seen
    assert m==70668216
    orig=json.loads((ROOT/'prior-summary.json').read_text())
    assert len(orig)==10 and sum(p['result']=='all abstract tuples intersect' for p in orig)==8
    assert sorted(p['partition'] for p in orig if p['result']!='all abstract tuples intersect')==[[1]*6,[2,1,1,1,1]]
    print("Exact v61 archives:",len(fine['chunks']),"refined shards, 54 coarse singleton shards, seven pair-plus-isolates shards.")
    print("(2,1,1,1,1):",found['21111'][0],"raw queries,",found['21111'][1],"evaluated masks; all intersect.")
    print("(1,1,1,1,1,1):",m,"raw queries,",found['111111'][1]+cnt,"evaluated masks; all intersect.")
    print("Ten disconnected partitions accounted for: eight previous certificates and two completed joins.")


if __name__=='__main__':main()
