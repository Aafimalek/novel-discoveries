#!/usr/bin/env bash
set -euo pipefail
here=$(cd -- "$(dirname -- "$0")" && pwd)
if [ "$#" -ne 1 ]; then echo "usage: $0 FRESH_OUTPUT_DIRECTORY" >&2; exit 2; fi
work=$(realpath -m -- "$1")
mkdir -- "$work"
cd -- "$work"
ulimit -v 132000
unset PYTHONOPTIMIZE
export PYTHONDONTWRITEBYTECODE=1
timeout 25s python3 "$here/sharded_join.py" plan plan.json
sha256sum plan.json "$here/minima.json" "$here/sharded_join.py" "$here/direct_join.py" >ACTIVE.sha256
python3 - <<'PY' >ranges.txt
import json
v=json.load(open('plan.json'))['plans']
for p in ('21111','111111'):
    for lo,hi,e in v[p]['chunks']:print(p,lo,hi,e)
PY
skip=
while read -r p lo hi cap; do
  if [ "$p" = "$skip" ]; then continue; fi
  sha256sum -c --quiet ACTIVE.sha256
  n="$p-$lo-$hi"
  (time timeout 25s python3 "$here/sharded_join.py" run plan.json "$p" "$lo" "$hi" "$n.json" >"$n.log") 2>"$n.time"
  sha256sum "$n.json" "$n.log" "$n.time" >"$n.sha256"
  chmod a-w "$n.json" "$n.log" "$n.time" "$n.sha256"
  [ -s "$n.json" ]
  printf '%s %s..%s planned queries %s: ' "$p" "$lo" "$hi" "$cap"
  python3 - "$n.json" <<'PY'
import json,sys
p=json.load(open(sys.argv[1]))
print(p['result'],p['tried'],p['exact_queries'],flush=True)
PY
  if grep -Fq '"result":"abstract gap"' "$n.json"; then
    skip=$p
    echo "STOPPED $p at first verified abstract gap"
  fi
done <ranges.txt
sha256sum -c ACTIVE.sha256
for f in *-*-*.sha256; do sha256sum -c --quiet "$f"; done
timeout 25s python3 "$here/sharded_join.py" collect plan.json . | tee summary.log
