#!/usr/bin/env python3
"""Refine only the six uncompleted v61 all-singleton coarse ranges."""
from argparse import ArgumentParser
from pathlib import Path
from functools import reduce
from operator import and_
import json

from sharded_join import FULL,payload,loaded,trials,run,collect

PART='111111'
START=8410
EXPECTED_OLD=64618235
EXPECTED_ALL=70668216
EXPECTED_MISSING=6049981
CAP=300000


def small_plan(old,n,key):
    coarse=old['plans'][PART]['chunks']
    assert len(coarse)==60 and coarse[54][0]==START
    assert sum(x[2] for x in coarse[:54])==EXPECTED_OLD
    result=[]
    for l,h,v in coarse[54:]:
        i=l
        while i<h:
            j=i+1
            while j<h and trials(PART,i,j+1,n)<=CAP:j+=1
            q=trials(PART,i,j,n)
            assert 0<q<=CAP
            result.append([i,j,q])
            i=j
    assert result[0][0]==START and result[-1][1]==n
    assert sum(v for _,_,v in result)==EXPECTED_MISSING
    assert all(u[1]==v[0] for u,v in zip(result,result[1:]))
    return {'pins':key,'partition':PART,'raw_cap':CAP,'old_trials':EXPECTED_OLD,
            'full_trials':EXPECTED_ALL,'coarse_replaced':coarse[54:],'chunks':result}


def collect_refined(d,P,q):
    R=[]
    ps={t for _,t in q}
    for lo,hi,n in P['chunks']:
        f=d/f'{lo}-{hi}.json'
        if not f.exists():break
        a=json.loads(f.read_text())
        assert a['pins']==P['pins'] and a['partition']==PART
        assert a['first_range']==[lo,hi] and a['expected']==n
        assert 0<a['exact_queries']<=a['tried']<=n
        R.append(a)
        if a['result']=='abstract gap':
            G=a['gap'];i,j=G['first_index'],G['second_index']
            assert lo<=i<hi and i<=j<len(q)
            Z=tuple((x['size'],x['acceptance']) for x in G['witness'])
            assert Z[:4]==q[i][1]+q[j][1] and Z[4:] in ps
            assert len(Z)==6 and reduce(and_,(m for _,m in Z),FULL)==0
            break
        assert a['result']=='complete; all tuples intersect' and a['tried']==n and a['gap'] is None
    assert {p.name for p in d.glob('[0-9]*-[0-9]*.json')}=={f'{a["first_range"][0]}-{a["first_range"][1]}.json' for a in R}
    out={'verified_prior_trials':P['old_trials'],'finished_new_shards':len(R),
         'planned_new_shards':len(P['chunks']),'new_trials':sum(a['tried'] for a in R),
         'new_exact_queries':sum(a['exact_queries'] for a in R)}
    if R and R[-1]['gap']:
        out.update(result='verified abstract gap; no geometry inferred',gap=R[-1]['gap'])
    elif len(R)==len(P['chunks']):
        assert out['verified_prior_trials']+out['new_trials']==P['full_trials']
        out.update(result='all abstract tuples intersect',verified_full_trials=P['full_trials'])
    else:
        out.update(result='partial; not a certificate')
    (d/'summary.json').write_text(json.dumps(out,indent=2)+'\n')
    print(out,flush=True)


def main():
    p=ArgumentParser(description=__doc__)
    s=p.add_subparsers(required=True,dest='cmd')
    for cmd in ('plan','run','collect'):
        a=s.add_parser(cmd)
        a.add_argument('coarse_work',type=Path);a.add_argument('refined_plan',type=Path)
        if cmd=='run':
            a.add_argument('lo',type=int);a.add_argument('hi',type=int);a.add_argument('output',type=Path)
        elif cmd=='collect':a.add_argument('work',type=Path)
    a=p.parse_args()
    f,q,key=payload()
    C=loaded(a.coarse_work/'plan.json',f,q,key)
    P=small_plan(C,len(q),key)
    if a.cmd=='plan':
        collect(a.coarse_work,C,f,q,key)
        x=json.loads((a.coarse_work/'summary.json').read_text())
        assert x[0]['result']=='all abstract tuples intersect'
        assert x[1]['finished_shards']==54 and x[1]['trials']==EXPECTED_OLD and x[1]['result']=='partial; not a certificate'
        a.refined_plan.write_text(json.dumps(P,indent=2)+'\n')
    else:
        assert json.loads(a.refined_plan.read_text())==P
        if a.cmd=='run':
            run(PART,a.lo,a.hi,a.output,f,q,key,{'plans':{PART:{'chunks':P['chunks']}}},100000)
        else:collect_refined(a.work,P,q)


if __name__=='__main__':main()
