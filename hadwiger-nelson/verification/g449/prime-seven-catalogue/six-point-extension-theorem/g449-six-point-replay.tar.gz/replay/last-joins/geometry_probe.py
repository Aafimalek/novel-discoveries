#!/usr/bin/env python3
"""Bounded realization of specific abstract gaps, not a full tuple search."""
from argparse import ArgumentParser
from hashlib import sha256
from itertools import combinations,product
from pathlib import Path
import json

K=61
FULL=(1<<K)-1
PROFILE='7b04a25fa89bb03d290a7288c10087f2afca2b4f58821b151e6a330dadf2fbf4'
COORDS='f944eea2d111cbe242c3b223155ade4f150e9a9da912795a1b57e956bebdcec9'


class Cap(Exception):
    pass


def support(q,nbr,rows):
    A=[(i,j) for i,j in combinations(range(len(q)),2) if q[j] in nbr[q[i]]]
    assert all(rows[x][0]+sum(i in e for e in A)>=5 for i,x in enumerate(q))
    reach={q[0]};S=set(q)
    for _ in range(len(q)):
        reach|=set.union(*(nbr[x] for x in reach))&S
    assert reach==S
    m=0
    for i in range(K):
        colors=[tuple(j for j in range(5) if (rows[x][i+1]>>j)&1) for x in q]
        if any(all(c[i]!=c[j] for i,j in A) for c in product(*colors)):
            m|=1<<i
    return m


def search(keys,buckets,nbr,rows,probe_cap,witness_cap):
    keys=sorted(keys,key=lambda t:(len(buckets[t]),t))
    probes=0
    solutions=[]
    def go(selected,used,last):
        nonlocal probes
        if len(solutions)>=witness_cap:return
        j=len(selected)
        if j==len(keys):
            m=FULL
            for k,C in zip(keys,selected):
                p=support(C,nbr,rows)
                assert (len(C),p)==k
                m&=p
            assert m==0
            solutions.append(tuple(selected))
            return
        k=keys[j]
        for C in buckets[k]:
            probes+=1
            if probes>probe_cap:raise Cap
            if k in last and C<=last[k]:continue
            T=set(C)
            if used&T or any(nbr[x]&used for x in C):continue
            copy=last.copy()
            copy[k]=C
            go(selected+[C],used|T,copy)
    capped=False
    try:
        go([],set(),{})
    except Cap:
        capped=True
    return solutions,probes,capped


def main():
    p=ArgumentParser(description=__doc__)
    p.add_argument('work',type=Path)
    p.add_argument('profile',type=Path)
    p.add_argument('coordinates',type=Path)
    p.add_argument('partition_summary',type=Path)
    p.add_argument('output',type=Path)
    p.add_argument('--slots',type=int,nargs='+',default=[0])
    p.add_argument('--shards',type=int,default=64)
    p.add_argument('--member-cap',type=int,default=64)
    p.add_argument('--probe-cap',type=int,default=25000)
    p.add_argument('--witness-cap',type=int,default=2)
    a=p.parse_args()
    assert 1<=a.member_cap<=1024 and a.probe_cap>0 and 1<=a.witness_cap<=10
    assert 1<=len(set(a.slots))==len(a.slots)<=10 and all(0<=i<10 for i in a.slots)
    raw=a.profile.read_bytes()
    assert sha256(raw).hexdigest()==PROFILE
    F=iter(raw.decode('ascii').splitlines())
    assert tuple(map(int,next(F).split()))==(7056,61,33908)
    rows=[tuple(map(int,next(F).split())) for _ in range(7056)]
    nbr=[set() for _ in rows]
    edges=0
    for line in F:
        i,j=map(int,line.split())
        assert 0<=i<j<7056 and j not in nbr[i]
        nbr[i].add(j);nbr[j].add(i);edges+=1
    assert edges==33908
    raw=a.coordinates.read_bytes()
    assert sha256(raw).hexdigest()==COORDS
    xy=[tuple(map(int,x.split())) for x in raw.decode('ascii').splitlines()]
    assert len(xy)==len(set(xy))==7056
    P=json.loads(a.partition_summary.read_text())
    assert len(P)==10
    wanted={}
    for i in a.slots:
        obj=P[i]
        assert obj['result']=='abstract gap; geometry unresolved'
        keys=[(x['size'],x['acceptance']) for x in obj['witness']]
        assert sorted(x for x,_ in keys)==sorted(obj['partition'])
        wanted[i]=keys
    buckets={k:[] for v in wanted.values() for k in v}
    counts=dict.fromkeys(buckets,0)
    lookup={tuple(str(x).encode('ascii') for x in k):k for k in buckets}
    for h in range(a.shards):
        with (a.work/f'{h}.members').open('rb') as f:
            for line in f:
                s,m,vs=line.split(maxsplit=2)
                k=lookup.get((s,m))
                if k is None:continue
                counts[k]+=1
                if len(buckets[k])<a.member_cap:
                    q=tuple(map(int,vs.split()))
                    assert len(q)==len(set(q))==k[0] and q==tuple(sorted(q)) and q[0]%a.shards==h
                    buckets[k].append(q)
    reports=[]
    for i,keys in wanted.items():
        assert all(counts[k] for k in keys)
        found,probes,capped=search(keys,buckets,nbr,rows,a.probe_cap,a.witness_cap)
        print(i,'targeted mask tuple, bucket sizes:',[counts[k] for k in keys],
              'probe count:',probes,'capped:',capped,'realizations:',found,flush=True)
        reports.append({'partition_index':i,'mask_tuple':keys,'bucket_counts':[counts[k] for k in keys],
                        'membership_truncated':any(counts[k]>a.member_cap for k in keys),
                        'probe_count':probes,'probe_cap_hit':capped,
                        'verified_bank_gaps':[{'sets':q,'point_rows':[[xy[x] for x in C] for C in q]}
                                              for q in found]})
    a.output.write_text(json.dumps(reports,indent=2)+'\n')


if __name__=='__main__':main()
