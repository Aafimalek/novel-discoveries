#!/usr/bin/env python3
"""Deterministic first-index shards for the last two v61 mask joins."""
from argparse import ArgumentParser
from hashlib import sha256
from itertools import combinations_with_replacement
from functools import reduce
from operator import and_
from pathlib import Path
import json

from direct_join import K,FULL,PROFILE,Target,minima

ROOT=Path(__file__).resolve().parent
MINIMA='5367780a20c52bbcd63edabc780ca4d55e463eb60f1a5d84f5c23d4b2177325b'
PARTS={'21111':(2,1,1,1,1),'111111':(1,1,1,1,1,1)}


def sha(x):
    return sha256(x).hexdigest()


def payload():
    blob=(ROOT/'minima.json').read_bytes()
    assert sha(blob)==MINIMA
    o=json.loads(blob)
    assert K==61 and o['profile_sha256']==PROFILE and o['bank_size']==61
    f={i:tuple(o['families'][str(i)]['minimal']) for i in (1,2)}
    assert [len(f[i]) for i in (1,2)]==[189,610]
    assert all(len(set(x))==len(x) and all(0<m<=FULL for m in x) for x in f.values())
    z={}
    raw=0
    for a,b in combinations_with_replacement(f[1],2):
        z.setdefault(a&b,((1,a),(1,b)))
        raw+=1
    q=list(minima(z).items())
    assert (raw,len(z),len(q))==(17955,17849,11888)
    def data_hash(x):return sha(json.dumps(x,separators=(',',':')).encode())
    return f,q,{'minima_sha256':MINIMA,'profile_sha256':PROFILE,
                'singleton_mask_sha256':data_hash(f[1]),'pair_component_mask_sha256':data_hash(f[2]),
                'q11_ordered_with_provenance_sha256':data_hash(q)}


def trials(part,lo,hi,n):
    if part=='21111':return (hi-lo)*n
    assert part=='111111'
    return (hi-lo)*(2*n-lo-hi+1)//2


def plan(f,q,key,cap):
    n=len(q)
    ans={}
    assert cap>=n
    for part,L in ((k,f[2] if k=='21111' else q) for k in PARTS):
        r=0
        chunks=[]
        while r<len(L):
            j=r+1
            while j<len(L) and trials(part,r,j+1,n)<=cap:j+=1
            amount=trials(part,r,j,n)
            assert 0<amount<=cap
            chunks.append([r,j,amount])
            r=j
        assert sum(c[2] for c in chunks)==trials(part,0,len(L),n)
        ans[part]={'part':list(PARTS[part]),'rows':len(L),'targets':n,
                   'total':trials(part,0,len(L),n),'chunks':chunks}
    return {'pin':key,'per_shard_query_cap':cap,'plans':ans}


def loaded(filename,f,q,key):
    a=json.loads(filename.read_text())
    assert a==plan(f,q,key,a['per_shard_query_cap'])
    return a


def run(part,lo,hi,fn,f,q,key,C,cache_cap):
    d=C['plans'][part]
    expected=trials(part,lo,hi,len(q))
    assert [lo,hi,expected] in d['chunks']
    T=Target(dict(q))
    kept=set()
    tried=tested=0
    gap=None
    for i in range(lo,hi):
        if part=='21111':
            m=f[2][i]
            sub=((1,j,y,r) for j,(y,r) in enumerate(q))
            lhs=((2,m),)
        else:
            m,lhs=q[i]
            sub=((1,j,q[j][0],q[j][1]) for j in range(i,len(q)))
        for _,j,y,r in sub:
            tried+=1
            p=m&y
            if p in kept:continue
            tested+=1
            w=T.disjoint(p)
            if w is not None:
                z=lhs+r+w
                assert sorted(s for s,_ in z)==sorted(PARTS[part])
                assert all(a in f[2 if s==2 else 1] for s,a in z)
                assert reduce(and_,(a for _,a in z),FULL)==0
                gap={'first_index':i,'second_index':j,
                     'witness':[{'size':s,'acceptance':a} for s,a in z]}
                break
            if len(kept)<cache_cap:kept.add(p)
        if gap:break
    assert 0<tried<=expected
    if gap is None:assert tried==expected
    out={'pins':key,'partition':part,'first_range':[lo,hi],'expected':expected,'tried':tried,
         'exact_queries':tested,'cache_entries':len(kept),
         'result':'abstract gap' if gap else 'complete; all tuples intersect','gap':gap}
    fn.write_text(json.dumps(out,separators=(',',':'))+'\n')
    print(out,flush=True)


def collect(d,C,f,q,key):
    z=[]
    for part in PARTS:
        p=C['plans'][part]
        R=[]
        for lo,hi,e in p['chunks']:
            fn=d/f'{part}-{lo}-{hi}.json'
            if not fn.exists():break
            a=json.loads(fn.read_text())
            assert a['pins']==key and a['partition']==part and a['first_range']==[lo,hi]
            assert a['expected']==e and 0<a['exact_queries']<=a['tried']<=e
            R.append(a)
            if a['result']=='abstract gap':
                w=a['gap']
                assert lo<=w['first_index']<hi
                i,j=w['first_index'],w['second_index']
                assert (0 if part=='21111' else i)<=j<len(q)
                S=[(r['size'],r['acceptance']) for r in w['witness']]
                lhs=((2,f[2][i]),) if part=='21111' else q[i][1]
                pre=list(lhs+q[j][1])
                assert len(S)==len(pre)+2 and S[:len(pre)]==pre
                assert tuple(S[-2:]) in {t for _,t in q}
                assert reduce(and_,(a for _,a in S),FULL)==0
                break
            assert a['result']=='complete; all tuples intersect' and a['tried']==e and a['gap'] is None
        expected_files={f'{part}-{r["first_range"][0]}-{r["first_range"][1]}.json' for r in R}
        assert expected_files=={f.name for f in d.glob(f'{part}-*.json')}
        alltried=sum(r['tried'] for r in R)
        x={'partition':part,'finished_shards':len(R),'planned_shards':len(p['chunks']),
           'expected_full_trials':p['total'],'trials':alltried,
           'exact_queries':sum(r['exact_queries'] for r in R)}
        if R and R[-1]['gap']:
            x.update(result='abstract gap; geometry unresolved',gap=R[-1]['gap'])
        elif len(R)==len(p['chunks']):
            assert alltried==p['total']
            x.update(result='all abstract tuples intersect')
        else:
            x.update(result='partial; not a certificate')
        z.append(x)
        print(x,flush=True)
    (d/'summary.json').write_text(json.dumps(z,indent=2)+'\n')


def main():
    p=ArgumentParser(description=__doc__)
    sp=p.add_subparsers(dest='cmd',required=True)
    a=sp.add_parser('plan')
    a.add_argument('out',type=Path);a.add_argument('--cap',type=int,default=1200000)
    a=sp.add_parser('run')
    a.add_argument('plan',type=Path);a.add_argument('part',choices=PARTS)
    a.add_argument('lo',type=int);a.add_argument('hi',type=int);a.add_argument('out',type=Path)
    a.add_argument('--cache-cap',type=int,default=100000)
    a=sp.add_parser('collect')
    a.add_argument('plan',type=Path);a.add_argument('work',type=Path)
    a=p.parse_args()
    f,q,key=payload()
    if a.cmd=='plan':
        a.out.write_text(json.dumps(plan(f,q,key,a.cap),indent=2)+'\n')
    elif a.cmd=='run':
        assert 0<=a.cache_cap<=100000
        run(a.part,a.lo,a.hi,a.out,f,q,key,loaded(a.plan,f,q,key),a.cache_cap)
    else:
        collect(a.work,loaded(a.plan,f,q,key),f,q,key)


if __name__=='__main__':main()
