# Final two v61 disconnected joins, exactly verified

**Both final disconnected partitions are closed.** Together with the
eight earlier certificates, all ten disconnected partitions of six
grid additions with original degrees at least two are covered.
The finite joins used an exact 61-palette bank; no new palette or
solver invocation was made during this final step.

- (2,1,1,1,1): all 610 size-two minimum masks ×11,888 minimal
  singleton-pair masks, **7,251,680 raw queries** (7,186,224 actual
  bitset evaluations after reuse), seven coarse shards.
- (1,1,1,1,1,1): all unordered singleton-pair-mask pairs with repeats,
  **70,668,216 raw triangular queries** (68,958,215 actual
  bitset evaluations). The first 54 coarse shards covered
  first indices [0,8410), or 64,618,235 queries. The six missing
  coarse ranges were partitioned into 26 refined subranges with
  6,049,981 total raw queries. Their union is [8410,11888), with
  no boundary gap or duplicate permitted by the checker. Every
  completed query has a common palette; no abstract gaps occurred.

This closes the last open branch of the fixed-graph result when
combined with its separate exact arguments: prior arbitrary
five-point theorem and degree deletion, every mixed/off-grid
six-point case, all-grid degree-zero and degree-one branches,
connected all-grid degree-at-least-two verification, and the other
eight disconnected partitions. **Any six points anywhere can be
added to this G449 while preserving five-colorability.** It does
not change a bound for the whole plane, nor is it a Lean proof.

## Why the join proves the cases

If any new point has degree at most four, delete it and greedily
restore it after coloring the other five. Otherwise each
disconnected component has original degree plus internal degree
at least five at every vertex. Its palette mask is the set of
verified base palettes under which that component admits an
exact list coloring, as computed by the full preceding census.

Replacing any mask by an inclusion-minimal contained mask of its
size only reduces the intersection. Likewise, each acceptance
intersection of two singleton masks contains an inclusion-minimal
singleton-pair mask from Q11. Thus if the abstract tuple of those
smallest masks has a surviving common palette, so does any actual
tuple. Positive abstract closure needs no assumptions about
collisions or cross edges. The Q11 construction checks 17,955 raw
pairs, 17,849 distinct intersections, 11,888 inclusion-minimal
intersections, and retains the two-singleton provenance of every
kept mask.

For each query mask q, exactly the targets carrying any bit of q
are found by OR-ing their precomputed exact incidence bitsets. If
the union covers the entire target index, no target is disjoint
from q. Successful duplicate-query reuse is exact; raw visits
are still counted. The four-isolates case queries each size-two
minimum mask intersected with one Q11 mask against all Q11 masks.
The six-isolates case groups its six factors into three pairs and
checks every first/second Q11 pair against all Q11 targets.
Unordered pairs with repeats are complete, so row r has exactly
11,888−r trials and begins at second index j=r.

## Portable recorded verification

```sh
sha256sum -c SHA256SUMS
python3 verify_archive.py
```

The read-only verifier checks the archived masks/minima and profile
pins, ordered Q11 provenance, both exact plans, and every completed
receipt with its nested hash. It works after relocation without
reading any authoring-machine absolute paths. Coarse receipts are
in `run-v61-last2/`; refined receipts are in `run-v61-refined/`.
The archived partial summaries remain as historical evidence of
the 410-second then 25-second stops. Interrupted logs/time without
a completion JSON are never counted. No raw candidate geometry or
original third-party coordinate files are required for this final
mask-only step; the already independently cold-checked v61 profile
and full earlier component census are separate dependencies.

## Independent production replay in bounded batches

```sh
# Coarse ordinals 0–6: pair-plus-four-isolates; 7–60: singleton prefix.
timeout 250s ./replay_batch.sh NEW_COARSE NEW_REFINED coarse 0 7
# Further calls cover exactly [7,61) in disjoint, consecutive batches.
timeout 250s ./replay_batch.sh NEW_COARSE NEW_REFINED coarse 7 15
# ... repeat for remaining coarse ordinals using <=8 per invocation ...
# Refined ordinals [0,26), also in independently guarded batches:
timeout 250s ./replay_batch.sh NEW_COARSE NEW_REFINED refined 0 8
# ... repeat for the remainder through end-exclusive 26 ...
python3 verify_archive.py NEW_COARSE NEW_REFINED
```

Every subrange independently has a 25-second limit and hard
132,000 KiB virtual-memory cap; ensure each invocation is serial.
If a slower host hits an individual coarse-stage cap, do not
count it; use the exact original denominator and refine its
range arithmetically as done for the last six. The batch recipe
was syntax-checked, not rerun from scratch after the production
receipts were frozen. Complete recorded production used
`replay_shards.sh`, the separately guarded `resume_shards.sh`,
and `replay_refined.sh`. None invokes a solver.
