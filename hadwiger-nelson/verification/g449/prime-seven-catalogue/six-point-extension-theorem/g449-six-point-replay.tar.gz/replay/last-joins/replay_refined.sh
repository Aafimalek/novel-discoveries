#!/usr/bin/env bash
# Staged, not run. Use only after another explicit light-slot release.
set -euo pipefail
here=$(cd -- "$(dirname -- "$0")" && pwd)
if [ "$#" -ne 2 ]; then echo "usage: $0 COARSE_RUN_DIRECTORY FRESH_REFINED_DIRECTORY" >&2; exit 2; fi
coarse=$(realpath -- "$1"); work=$(realpath -m -- "$2")
(cd "$coarse" && sha256sum -c ACTIVE.sha256 && sha256sum -c --quiet RESUME-PARTIAL.sha256
 for s in *-*-*.sha256; do sha256sum -c --quiet "$s"; done)
mkdir -- "$work"
cd -- "$work"
ulimit -v 132000
unset PYTHONOPTIMIZE
export PYTHONDONTWRITEBYTECODE=1
timeout 25s python3 "$here/refined.py" plan "$coarse" refined-plan.json | tee old-coverage.log
sha256sum refined-plan.json "$here/minima.json" "$here/sharded_join.py" "$here/refined.py" "$here/direct_join.py" >ACTIVE.sha256
python3 - <<'PY' >ranges.txt
import json
for x in json.load(open('refined-plan.json'))['chunks']:print(*x)
PY
while read -r lo hi raw; do
  sha256sum -c --quiet ACTIVE.sha256
  n="$lo-$hi"
  (time timeout 25s python3 "$here/refined.py" run "$coarse" refined-plan.json "$lo" "$hi" "$n.json" >"$n.log") 2>"$n.time"
  sha256sum "$n.json" "$n.log" "$n.time" >"$n.sha256"
  chmod a-w "$n.json" "$n.log" "$n.time" "$n.sha256"
  printf '111111 %s..%s planned queries %s: ' "$lo" "$hi" "$raw"
  python3 - "$n.json" <<'PY'
import json,sys
a=json.load(open(sys.argv[1]))
print(a['result'],a['tried'],a['exact_queries'],flush=True)
PY
  if grep -Fq '"result":"abstract gap"' "$n.json"; then break; fi
done <ranges.txt
sha256sum -c ACTIVE.sha256
for s in *-*.sha256; do sha256sum -c --quiet "$s"; done
timeout 25s python3 "$here/refined.py" collect "$coarse" refined-plan.json . | tee summary.log
