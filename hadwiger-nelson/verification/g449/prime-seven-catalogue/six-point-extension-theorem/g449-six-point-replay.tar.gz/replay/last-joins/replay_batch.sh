#!/usr/bin/env bash
# Independent reproduction of a chosen ordinal batch; never extends a time cap.
set -euo pipefail
here=$(cd -- "$(dirname -- "$0")" && pwd)
if [ "$#" -ne 5 ]; then
  echo "usage: $0 COARSE_DIR REFINED_DIR {coarse|refined} FIRST END_EXCLUSIVE" >&2
  exit 2
fi
coarse=$(realpath -m -- "$1"); fine=$(realpath -m -- "$2")
phase=$3; start=$4; end=$5
[[ "$phase" = coarse || "$phase" = refined ]]
[[ "$start" =~ ^[0-9]+$ && "$end" =~ ^[0-9]+$ && "$start" -lt "$end" ]]
mkdir -p -- "$coarse" "$fine"
ulimit -v 132000
unset PYTHONOPTIMIZE
export PYTHONDONTWRITEBYTECODE=1
if [ ! -f "$coarse/plan.json" ]; then
  timeout 25s python3 "$here/sharded_join.py" plan "$coarse/plan.json"
  (cd "$coarse" && sha256sum plan.json "$here/minima.json" "$here/sharded_join.py" "$here/direct_join.py" >ACTIVE.sha256)
fi
(cd "$coarse" && sha256sum -c --quiet ACTIVE.sha256)
if [ "$phase" = refined ] && [ ! -f "$fine/refined-plan.json" ]; then
  timeout 25s python3 "$here/refined.py" plan "$coarse" "$fine/refined-plan.json" >"$fine/old-coverage.log"
  (cd "$fine" && sha256sum refined-plan.json "$here/minima.json" "$here/sharded_join.py" "$here/refined.py" "$here/direct_join.py" >ACTIVE.sha256)
fi
if [ "$phase" = coarse ]; then out=$coarse; else out=$fine; fi
cd "$out"
sha256sum -c --quiet ACTIVE.sha256
python3 - "$phase" "$start" "$end" <<'PY' >"batch-$start-$end.ranges"
from pathlib import Path
import json,sys
p,lo,hi=sys.argv[1],int(sys.argv[2]),int(sys.argv[3])
if p=='coarse':
 d=json.load(open('plan.json'))['plans']
 data=[(k,a,b) for k,w in (('21111',None),('111111',54))
      for a,b,_ in d[k]['chunks'][:w]]
else:
 d=json.load(open('refined-plan.json'))
 data=[('111111',a,b) for a,b,_ in d['chunks']]
assert 0<=lo<hi<=len(data)
for k,a,b in data[lo:hi]:print(k,a,b)
PY
while read -r p lo hi; do
  sha256sum -c --quiet ACTIVE.sha256
  if [ "$phase" = coarse ]; then n="$p-$lo-$hi"; else n="$lo-$hi"; fi
  for x in log time json sha256; do test ! -e "$n.$x"; done
  if [ "$phase" = coarse ]; then
    (time timeout 25s python3 "$here/sharded_join.py" run plan.json "$p" "$lo" "$hi" "$n.json" >"$n.log") 2>"$n.time"
  else
    (time timeout 25s python3 "$here/refined.py" run "$coarse" refined-plan.json "$lo" "$hi" "$n.json" >"$n.log") 2>"$n.time"
  fi
  sha256sum "$n.json" "$n.log" "$n.time" >"$n.sha256"
  chmod a-w "$n.json" "$n.log" "$n.time" "$n.sha256"
  if grep -Fq '"result":"abstract gap"' "$n.json"; then
    echo "Stopped at genuine abstract gap; no geometry inferred."; exit 8
  fi
  printf '%s %s..%s complete\n' "$p" "$lo" "$hi"
done <"batch-$start-$end.ranges"
