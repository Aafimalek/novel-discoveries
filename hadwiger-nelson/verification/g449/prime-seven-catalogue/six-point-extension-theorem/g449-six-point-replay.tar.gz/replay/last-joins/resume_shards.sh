#!/usr/bin/env bash
# Staged continuation only; use after separate light-slot authorization.
set -euo pipefail
here=$(cd -- "$(dirname -- "$0")" && pwd)
if [ "$#" -ne 1 ]; then echo "usage: $0 EXISTING_RUN_DIRECTORY" >&2; exit 2; fi
work=$(realpath -- "$1")
cd -- "$work"
ulimit -v 132000
unset PYTHONOPTIMIZE
export PYTHONDONTWRITEBYTECODE=1
sha256sum -c ACTIVE.sha256
for s in *-*-*.sha256; do sha256sum -c --quiet "$s"; done
# Regenerate the remaining plan from the frozen JSON, not a hand-edited
# range list. The checker verifies exact archived prefix coverage.
timeout 25s python3 "$here/sharded_join.py" collect plan.json . >resume-entry.log
python3 - <<'PY' >pending-ranges.txt
from pathlib import Path
import json
P=json.load(open('plan.json'))['plans']
S=json.load(open('summary.json'))
assert S[0]['partition']=='21111' and S[0]['result']=='all abstract tuples intersect'
assert S[1]['partition']=='111111' and S[1]['result']=='partial; not a certificate'
got=S[1]['finished_shards']
assert 37<=got<len(P['111111']['chunks'])
for (i,j,n) in P['111111']['chunks'][got:]:
    assert not Path(f'111111-{i}-{j}.json').exists()
    print(i,j,n)
PY
while read -r lo hi cap; do
  sha256sum -c --quiet ACTIVE.sha256
  n="111111-$lo-$hi"
  for x in log time json sha256; do test ! -e "$n.$x"; done
  (time timeout 25s python3 "$here/sharded_join.py" run plan.json 111111 "$lo" "$hi" "$n.json" >"$n.log") 2>"$n.time"
  sha256sum "$n.json" "$n.log" "$n.time" >"$n.sha256"
  chmod a-w "$n.json" "$n.log" "$n.time" "$n.sha256"
  printf '111111 %s..%s planned queries %s: ' "$lo" "$hi" "$cap"
  python3 - "$n.json" <<'PY'
import json,sys
x=json.load(open(sys.argv[1]))
print(x['result'],x['tried'],x['exact_queries'],flush=True)
PY
  if grep -Fq '"result":"abstract gap"' "$n.json"; then
    echo "Stopped at first verified abstract gap; no geometry inferred."
    break
  fi
done <pending-ranges.txt
sha256sum -c ACTIVE.sha256
for s in *-*-*.sha256; do sha256sum -c --quiet "$s"; done
timeout 25s python3 "$here/sharded_join.py" collect plan.json . | tee resume-summary.log
