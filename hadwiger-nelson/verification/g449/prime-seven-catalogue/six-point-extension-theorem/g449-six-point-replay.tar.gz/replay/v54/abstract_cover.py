#!/usr/bin/env python3
"""Pure-integer union certificates and shortest abstract empty intersections."""
from argparse import ArgumentParser
from pathlib import Path
from functools import reduce
from operator import or_
import json

K=54
FULL=(1<<K)-1
PROFILE='9196e0d131b74895d94b754cb01efa022825d322f60b961e9e751156d0446cf2'
PARTITIONS=((5,1),(4,2),(4,1,1),(3,3),(3,2,1),(3,1,1,1),
            (2,2,2),(2,2,1,1),(2,1,1,1,1),(1,1,1,1,1,1))


def bits(m):
    while m:
        z=m&-m
        yield z.bit_length()-1
        m^=z


class Family:
    def __init__(self,ms):
        self.rejected=sorted({FULL^m for m in ms},key=lambda x:(-x.bit_count(),x))
        assert self.rejected
        self.max_rej=max(m.bit_count() for m in self.rejected)
        self.union=reduce(or_,self.rejected,0)
        self.inverted=[0]*K
        for i,m in enumerate(self.rejected):
            z=1<<i
            for j in bits(m):
                self.inverted[j]|=z


class BudgetExceeded(Exception):
    pass


class Branch:
    def __init__(self,families,state_cap,probe_cap,memo_cap):
        self.families=families
        self.state_cap=state_cap
        self.probe_cap=probe_cap
        self.memo_cap=memo_cap
        self.states=0
        self.probes=0
        self.fail=set()

    def find(self,missing,slots,cap):
        self.states+=1
        if self.states>self.state_cap:raise BudgetExceeded
        if missing==0:return ()
        if slots==0:return None
        state=(missing,slots,*cap)
        if state in self.fail:return None
        enabled=[j for j in range(1,6) if cap[j]]
        ceiling=sorted((self.families[s].max_rej for s in enabled for _ in range(cap[s])),reverse=True)
        if sum(ceiling[:slots])<missing.bit_count():return None
        if missing&~reduce(or_,(self.families[t].union for t in enabled),0):return None
        # Branch on a not-yet-rejected palette with the fewest exact choices.
        pivot=min(bits(missing),key=lambda p:sum(self.families[s].inverted[p].bit_count() for s in enabled))
        order=sorted(enabled,key=lambda s:(-self.families[s].max_rej,s))
        for s in order:
            child=list(cap)
            child[s]-=1
            child=tuple(child)
            f=self.families[s]
            for i in bits(f.inverted[pivot]):
                self.probes+=1
                if self.probes>self.probe_cap:raise BudgetExceeded
                x=f.rejected[i]
                assert x&(1<<pivot)
                ans=self.find(missing&~x,slots-1,child)
                if ans is not None:
                    return ((s,x),)+ans
        if len(self.fail)<self.memo_cap:self.fail.add(state)
        return None


def solve_partition(parts,f,ac):
    maxsum=sum(f[s].max_rej for s in parts)
    rep={'partition':parts,'unweighted_rejection_bound':maxsum}
    if maxsum<K:
        rep.update(result="all abstract tuples intersect",certificate="sum of component rejection maxima")
        return rep
    cap=tuple(parts.count(s) for s in range(6))
    B=Branch(f,ac.state_cap,ac.probe_cap,ac.memo_cap)
    ceilings=sorted((f[s].max_rej for s in parts),reverse=True)
    try:
        for n in range(1,len(parts)+1):
            if sum(ceilings[:n])<K:continue
            sol=B.find(FULL,n,cap)
            if sol is None:continue
            assert len(sol)==n and reduce(or_,(m for _,m in sol),0)==FULL
            assert all(sum(x==s for x,_ in sol)<=cap[s] for s in range(1,6))
            rep.update(result="abstract gap; geometry unresolved",minimum_zero_intersection=n,
                       witness=[{'size':s,'acceptance':FULL^m} for s,m in sol])
            break
        else:
            rep.update(result="all abstract tuples intersect",certificate="complete shortest-cover search")
    except BudgetExceeded:
        rep.update(result="unresolved: bounded search cap")
    rep.update(states=B.states,probes=B.probes,memo=len(B.fail))
    return rep


def main():
    p=ArgumentParser(description=__doc__)
    p.add_argument('minima',type=Path)
    p.add_argument('output',type=Path)
    p.add_argument('--only-partition',type=int,choices=range(10))
    p.add_argument('--state-cap',type=int,default=250000)
    p.add_argument('--probe-cap',type=int,default=600000)
    p.add_argument('--memo-cap',type=int,default=75000)
    a=p.parse_args()
    assert a.state_cap>0 and a.probe_cap>0 and 0<=a.memo_cap<=100000
    C=json.loads(a.minima.read_text())
    assert C['profile_sha256']==PROFILE and C['bank_size']==K
    assert C['component_counts']==[574,2079,13188,115395,1119839]
    f={}
    for s in range(1,6):
        d=C['families'][str(s)]
        ms=d['minimal']
        assert 0<len(ms)<=100000 and len(set(ms))==len(ms)
        assert all(0<x<=FULL for x in ms)
        f[s]=Family(ms)
        assert f[s].max_rej==d['maximum_rejections']
    todo=PARTITIONS if a.only_partition is None else (PARTITIONS[a.only_partition],)
    rep=[]
    for pt in todo:
        d=solve_partition(pt,f,a)
        rep.append(d)
        print(d,flush=True)
    a.output.write_text(json.dumps(rep,indent=2)+'\n')


if __name__=='__main__':main()
