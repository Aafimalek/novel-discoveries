# G449: seven of ten disconnected six-point partitions verified

This exact v54 run preserves five-colorability for seven disconnected
partitions of six added grid points whose original degrees are at least
two: (5,1), (4,2), (4,1,1), (3,3), (3,2,1), (2,2,2), and (2,2,1,1).
It does **not** settle the remaining three partitions or the whole
six-point theorem. The result is about a fixed base graph, not a
new bound for the whole plane.

The five earlier closures are inherited from the v52 bank: the
v53 and v54 profiles each project byte-for-byte to the previous
profile, so adding palettes cannot remove any successful tuple.
The exact geometry is unchanged. Palettes 53 and 54 come from
directly verified positive models; their solver-free verifiers were
rerun before appending palette 54. All five earlier realized gaps
have a directly checked extension with one of those added palettes.
The exact generated graph SHA-256 is
9196e0d131b74895d94b754cb01efa022825d322f60b961e9e751156d0446cf2.

## One exact component round, then bounded joins

All 64 component shards completed with per-stage timeouts and
the hard 132,000 KiB virtual-memory guard. Their counts by size
remain 574, 2,079, 13,188, 115,395 and 1,119,839. The distinct
acceptance-mask counts are 336, 1,234, 5,922, 35,538 and 234,196;
inclusion-minimal counts are 155, 492, 1,555, 4,622 and 9,654.
All induced connected candidates and root-shard uniqueness follow
the same complete exact canonical-parent enumeration as the
connected release; original degrees and exact palette list
colorability are checked for every emitted component.

For the five formerly unclosed partitions we directly joined
finite acceptance masks using integer bitsets. The singleton
pair intersections have 12,090 raw combinations, 11,939 distinct
intersections and 7,192 inclusion-minimal ones. Every set of
mask tuples is tested against a complete target bitset index:
OR the targets carrying any allowed query bit, then compare with
all targets. A missing target gives an explicit abstract
zero-intersection tuple; a complete scan with none proves
closure without any collision or cross-edge assumptions.
The two new partitions close after 765,060 and 121,278 trials.
All ten outcomes are in `verified/partition-summary.json`.
No search cap was reached in these bounded joins.

The three remaining partitions have exact real v54 **palette-bank
gaps**, not six-chromatic witnesses. Each concrete gap was obtained
by testing only the masks named in one abstract join witness,
not enumerating all realizations:
- (3,1,1,1): triple (2115,5152,5603), isolates 3537, 4544, 5098.
- (2,1,1,1,1): pair (5025,5032), isolates 1030, 2432, 4526, 6561.
- (1,1,1,1,1,1): isolates 1023,1030,2305,3881,3916,5108.

Each used only singleton component-mask membership buckets, and
the extractor independently tested every mask, eligibility, induced
components, distinctness and absence of cross-edges. The exact
coordinates and masks are in `verified/realizations.json`. No
solver or additional palette round ran on these new gaps.

## Reproduce

Use the prior solver-free witnesses from the v52-gap release to
verify the positive palette 53 and 54 models; `append_palette54.py`
recomputes the exact palette54 masks, fixes the old profile prefix,
and verifies coverage of its original target. It imports the v52
rotation loader and pinned exact G449 helpers. All verifiers,
manifests and relative-input examples use the immutable original
geometry and earlier profile hashes. From this package:

```sh
sha256sum -c SHA256SUMS
sha256sum -c VERIFIED.sha256
./stage_components.sh graph54.txt FRESH_RUN_DIRECTORY 64
(ulimit -v 132000; timeout 25s python3 direct_join.py \
  FRESH_RUN_DIRECTORY/minima.json join.json 321)
```

Try the remaining join indices 3111, 2211, 21111, and 111111
separately. Raw component memberships can be regenerated; local
run files in `complete-v54/` retain per-shard SHA-256 manifests.
