#!/usr/bin/env python3
"""Complete bounded bitset joins for five residual v54 partitions."""
from argparse import ArgumentParser
from itertools import combinations_with_replacement,product
from pathlib import Path
from functools import reduce
from operator import and_
import json

K=54
FULL=(1<<K)-1
PROFILE='9196e0d131b74895d94b754cb01efa022825d322f60b961e9e751156d0446cf2'
PARTS={'321':(3,2,1),'2211':(2,2,1,1),'21111':(2,1,1,1,1),'3111':(3,1,1,1),'111111':(1,1,1,1,1,1)}


def bits(m):
    while m:
        a=m&-m
        yield a.bit_length()-1
        m^=a


def minima(d):
    """Keep exactly a subset-minimal representative for each intersection."""
    contain=[0]*K
    used=0
    keep={}
    for m in sorted(d,key=lambda q:(q.bit_count(),q)):
        bad=0
        for b in bits(FULL^m):
            bad|=contain[b]
            if bad==used:break
        if bad!=used:continue
        j=1<<len(keep)
        keep[m]=d[m]
        used|=j
        for b in bits(m):contain[b]|=j
    return keep


class Target:
    def __init__(self,d):
        self.items=list(d.items())
        assert self.items
        self.by_bit=[0]*K
        self.all=(1<<len(self.items))-1
        for j,(m,_orig) in enumerate(self.items):
            for b in bits(m):self.by_bit[b]|=1<<j

    def disjoint(self,q):
        # A target is incompatible iff none of q's bits is present.
        cover=0
        for i in bits(q):
            cover|=self.by_bit[i]
            if cover==self.all:return None
        z=self.all^cover
        assert z
        j=(z&-z).bit_length()-1
        m,rows=self.items[j]
        assert not (m&q)
        return rows


def queries(which,F,Q):
    if which=='321':
        for a,b in product(F[3],F[2]):
            yield a&b,((3,a),(2,b))
    elif which=='2211':
        for a,b in combinations_with_replacement(F[2],2):
            yield a&b,((2,a),(2,b))
    elif which=='21111':
        for a,(b,v) in product(F[2],Q.items()):
            yield a&b,((2,a),)+v
    elif which=='3111':
        for a,b in product(F[3],F[1]):
            yield a&b,((3,a),(1,b))
    else:
        assert which=='111111'
        for (a,x),(b,y) in combinations_with_replacement(Q.items(),2):
            yield a&b,x+y


def main():
    p=ArgumentParser(description=__doc__)
    p.add_argument('minima',type=Path);p.add_argument('output',type=Path)
    p.add_argument('partition',choices=PARTS)
    p.add_argument('--trials-cap',type=int,default=2000000)
    p.add_argument('--cache-cap',type=int,default=100000)
    a=p.parse_args()
    assert a.trials_cap>0 and 0<=a.cache_cap<=100000
    o=json.loads(a.minima.read_text())
    assert o['profile_sha256']==PROFILE and o['bank_size']==K
    F={i:tuple(o['families'][str(i)]['minimal']) for i in range(1,4)}
    assert all(len(F[i])>0 for i in range(1,4))
    assert all(len(set(v))==len(v) and all(0<m<=FULL for m in v) for v in F.values())
    raw=0; q11={}
    for u,v in combinations_with_replacement(F[1],2):
        raw+=1
        q11.setdefault(u&v,((1,u),(1,v)))
    Q=minima(q11)
    assert raw==len(F[1])*(len(F[1])+1)//2 and Q
    part=PARTS[a.partition]
    target=Target({m:((1,m),) for m in F[1]} if a.partition=='321' else Q)
    seen=set()
    trials=tests=0
    rep={'partition':part,'q11_raw':raw,'q11_distinct':len(q11),'q11_minimal':len(Q),
         'target_count':len(target.items)}
    for q,rows in queries(a.partition,F,Q):
        trials+=1
        if trials>a.trials_cap:
            rep.update(result='unresolved: bounded join cap')
            break
        if q in seen:continue
        tests+=1
        g=target.disjoint(q)
        if g is not None:
            T=rows+g
            assert sorted(s for s,_ in T)==sorted(part)
            assert all(m in F[s] for s,m in T)
            assert reduce(and_,(m for _,m in T),FULL)==0
            rep.update(result='abstract gap; geometry unresolved',
                       witness=[{'size':s,'acceptance':m} for s,m in T])
            break
        if len(seen)<a.cache_cap:seen.add(q)
    else:
        rep.update(result='all abstract tuples intersect',certificate='complete exact integer bitset join')
    rep.update(trials=trials,distinct_tests=tests,cached=len(seen))
    a.output.write_text(json.dumps(rep,indent=2)+'\n')
    print(rep,flush=True)


if __name__=='__main__':main()
