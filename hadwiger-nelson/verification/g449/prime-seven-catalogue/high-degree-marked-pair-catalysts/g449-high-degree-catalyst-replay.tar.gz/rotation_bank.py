#!/usr/bin/env python3
"""Stage exact ζ^6 permutation auditing and append rotated witness palettes."""
from argparse import ArgumentParser
from hashlib import sha256
from pathlib import Path
import json
from itertools import combinations
from audit_layers import POWERS,PINNED,catalogue,norm_numerator,parse_sparse6,root_multiplicity_mod7,sub

N=7056
U=(1,)+(0,)*11
V40_SHA='65a7f5c903caf1135be997a434d30d9548a065da5f60af813d3e7814542065ca'
COORDS_SHA='f944eea2d111cbe242c3b223155ade4f150e9a9da912795a1b57e956bebdcec9'


GENERATOR=(-8,-6,5,5,5,-3,-2,4,7,1,-2,-4)
STEP=(49,)+(0,)*11


def load_data(source,path):
    data={name:(source/name).read_bytes() for name in PINNED}
    assert {k:sha256(v).hexdigest() for k,v in data.items()}==PINNED
    head,*rows=data['G449.k21'].decode('ascii').splitlines()
    assert head.split()==['K21','42','12','49','449']
    rr=[tuple(map(int,ln.split())) for ln in rows if ln.strip()]
    assert all(len(x)==13 and all(t%7==0 for t in x[:-1]) for x in rr)
    g=[tuple(t//7 for t in x[:-1]) for x in rr]
    col=tuple(x[-1] for x in rr)
    n,E=parse_sparse6(data['G449.s6'])
    assert len(g)==len(set(g))==n==449 and len(E)==2198
    assert set(col)==set(range(5)) and all(col[i]!=col[j] for i,j in E)
    assert norm_numerator(GENERATOR)==STEP
    assert tuple(root_multiplicity_mod7(GENERATOR,r) for r in (3,5))==(5,6)
    hdr,*data=path.read_text().splitlines()
    assert hdr.split()==['n','denominator',*[f'a{i}' for i in range(12)]]
    supplied=[tuple(map(int,ln.split())) for ln in data if ln.strip()]
    assert sorted(supplied)==sorted(catalogue(GENERATOR,6))
    D={tuple(a*(7//row[1])*t for t in row[2:]) for row in supplied for a in (-1,1)}
    assert len(D)==546 and all(norm_numerator(d)==STEP for d in D)
    assert {(i,j) for i,j in combinations(range(449),2) if sub(g[i],g[j]) in D}==E
    return g,col,E,D


def base_palettes(original,E,path):
    ww=json.loads(path.read_text())['single']
    assert len(ww)==34
    Q=[original]+[tuple(map(int,w['colors'][:449])) for w in ww]
    assert all(len(c)==449 and set(c)==set(range(5)) and all(c[i]!=c[j] for i,j in E)
               for c in Q)
    return Q


def absent(ns,c):
    a=0
    for i in ns:a|=1<<c[i]
    return 31^a


def canonical(c):
    order={}
    return tuple(order.setdefault(x,len(order)) for x in c)


def key(p):
    return sum(x << (8*i) for i,x in enumerate(p))


def cycle7(p):
    assert sorted(p)==list(range(len(p)))
    for i in range(len(p)):
        j=i
        for _ in range(7):j=p[j]
        assert j==i


def main():
    p=ArgumentParser(description=__doc__)
    p.add_argument('base',type=Path)
    p.add_argument('catalogue',type=Path)
    p.add_argument('single',type=Path)
    p.add_argument('coordinates',type=Path)
    p.add_argument('profile40',type=Path)
    p.add_argument('output',type=Path)
    p.add_argument('extra',type=Path,nargs=5,help='triple, four, five, gap11, gap36 verified witness JSON')
    p.add_argument('--sources',type=int,nargs='+',default=[38,39])
    p.add_argument('--profile-out',type=Path)
    a=p.parse_args()
    assert 1<=len(a.sources)<=4 and len(set(a.sources))==len(a.sources) and all(0<=i<40 for i in a.sources)
    G,orig,E,D=load_data(a.base,a.catalogue)
    P=base_palettes(orig,E,a.single)
    for w in a.extra:
        c=tuple(map(int,json.loads(w.read_text())["colors"][:449]))
        assert len(c)==449 and set(c)==set(range(5))
        assert all(c[i]!=c[j] for i,j in E)
        P.append(c)
    assert len(P)==40
    raw=a.coordinates.read_bytes()
    assert sha256(raw).hexdigest()==COORDS_SHA
    X=[tuple(map(int,r.split())) for r in raw.decode('ascii').splitlines()]
    assert len(X)==len(set(X))==N and all(len(x)==12 for x in X)
    assert norm_numerator(POWERS[6])==U
    rotcols=tuple(tuple((k,z) for k,z in enumerate(POWERS[(i+6)%42]) if z) for i in range(12))
    def rotate(x):
        q=[0]*12
        for i,v in enumerate(x):
            for k,z in rotcols[i]:q[k]+=v*z
        return tuple(q)
    def perm(points):
        ix={x:i for i,x in enumerate(points)}
        q=[ix[rotate(x)] for x in points]
        cycle7(q)
        return q
    g,r=perm(G),perm(X)
    assert {rotate(d) for d in D}==D
    assert {tuple(sorted((g[i],g[j]))) for i,j in E}==E
    assert sha256(a.profile40.read_bytes()).hexdigest()==V40_SHA
    with a.profile40.open() as f:
        assert tuple(map(int,next(f).split()))==(7056,40,33908)
        profile=[tuple(map(int,next(f).split())) for _ in range(N)]
        E1={tuple(map(int,line.split())) for line in f}
    assert len(E1)==33908 and all(0<=i<j<N for i,j in E1)
    assert {tuple(sorted((r[i],r[j]))) for i,j in E1}==E1
    growth=max(abs(x) for v in G for x in v)+2*max(abs(x) for d in D for x in d)
    assert growth<128
    J={key(x):i for i,x in enumerate(X)}
    ns=[set() for _ in X]
    dd=[key(d) for d in D]
    for i,x in enumerate(G):
        q=key(x)
        for d in dd:
            j=J.get(q+d)
            if j is not None:ns[j].add(i)
    for j,n in enumerate(ns):
        assert {g[x] for x in n}==ns[r[j]]
        assert tuple([len(n),*(absent(n,c) for c in P)])==profile[j]
    seen={canonical(c) for c in P}
    added=[]
    for source in a.sources:
        c=P[source]
        for power in range(1,7):
            dst=[None]*449
            for i,j in enumerate(g):dst[j]=c[i]
            c=tuple(dst)
            assert all(c[i]!=c[j] for i,j in E)
            sig=canonical(c)
            if sig not in seen:
                seen.add(sig)
                added.append({'source':source,'power':power,'colors':c})
    assert len(added)<=6*len(a.sources) and 40+len(added)<=64
    result={'base_permutation':g,'candidate_permutation':r,'additional_palettes':added}
    a.output.write_text(json.dumps(result,separators=(',',':'))+'\n')
    if a.profile_out is not None:
        with a.profile_out.open('w') as f:
            print(N,40+len(added),len(E1),file=f)
            for row,n in zip(profile,ns):
                print(*row,*(absent(n,c['colors']) for c in added),file=f)
            for x,y in sorted(E1):print(x,y,file=f)
        print("Extended exact profile SHA-256:",sha256(a.profile_out.read_bytes()).hexdigest())
    print(f"Checked exact ζ⁶ action on 449/7056 vertices, 2198/33908 edges and all original-neighbor incidences; {len(added)} distinct proposed appends.")


if __name__=='__main__':main()
