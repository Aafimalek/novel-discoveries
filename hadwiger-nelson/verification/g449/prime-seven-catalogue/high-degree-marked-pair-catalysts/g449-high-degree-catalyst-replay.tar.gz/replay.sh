#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
sha256sum --quiet -c SHA256SUMS
output="$(mktemp -d -p "$PWD" check-XXXXXX)/result"
(ulimit -v 132000; timeout 44s python3 -B filter.py base denominator-seven-directions.tsv coordinates.txt graph61.txt terminal-pairs.json exact-equality-filter.json "$output")
for f in positive.jsonl residual.jsonl summary.json; do cmp "verified/$f" "$output/$f"; done
echo 'All witness rows and summary matched byte for byte.'
