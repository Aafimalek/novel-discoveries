#!/usr/bin/env python3
"""Exact original×degree-at-least-two grid distance-two census."""
import argparse,json
from collections import Counter
from hashlib import sha256
from pathlib import Path
from audit_layers import PHI,sub
from rotation_bank import load_data,key,absent
from census import flags

N=7056
COORD='f944eea2d111cbe242c3b223155ade4f150e9a9da912795a1b57e956bebdcec9'
PROFILE='7b04a25fa89bb03d290a7288c10087f2afca2b4f58821b151e6a330dadf2fbf4'
PALETTES='6ada0cb4253e7bad57cedc7a732485bdbca2d6e8ccc79b1b9d48a9257d180888'

def pinned(path,digest):
    d=path.read_bytes()
    assert sha256(d).hexdigest()==digest,path
    return d

def evalp(q,r,p):
    v=0
    for a in reversed(q):v=(v*r+a)%p
    return v

def root(p):
    assert p in (43,127)
    r=next(r for r in range(2,p) if pow(r,42,p)==1
           and all(pow(r,k,p)!=1 for k in (21,14,6)))
    ri=pow(r,-1,p)
    assert evalp(PHI,r,p)==evalp(PHI,ri,p)==0
    return p,r,ri,196%p

def image(q,rts):
    return tuple(evalp(q,v,p) for p,r,ri,_ in rts for v in (r,ri))

def main():
    p=argparse.ArgumentParser(description=__doc__)
    for name in ('base','catalogue','coords','profile','palettes','output'):
        p.add_argument(name,type=Path)
    a=p.parse_args()
    G,orig,E,D=load_data(a.base,a.catalogue)
    assert len(G)==449 and len(D)==546 and len(E)==2198
    raw=pinned(a.palettes,PALETTES)
    C=[tuple(map(int,s['colors'])) for s in json.loads(raw)['palettes']]
    assert len(C)==61 and C[0]==orig
    assert all(len(c)==449 and set(c)==set(range(5)) and all(c[i]!=c[j] for i,j in E) for c in C)
    Z=[tuple(map(int,r.split())) for r in pinned(a.coords,COORD).splitlines()]
    assert len(Z)==len(set(Z))==N and all(len(z)==12 for z in Z)
    raw=pinned(a.profile,PROFILE).splitlines()
    assert raw[0]==b'7056 61 33908' and len(raw)==1+N+33908
    rows=[tuple(map(int,r.split())) for r in raw[1:1+N]]
    assert all(len(r)==62 and 2<=r[0]<=9 and all(0<=m<=31 for m in r[1:]) for r in rows)
    B=max(abs(c) for q in G for c in q)
    S=max(abs(c) for q in D for c in q)
    assert B+S<128 and all(abs(c)<=B+S for q in Z for c in q)
    offsets=tuple(map(key,D))
    g=set(map(key,G))
    zk=list(map(key,Z))
    assert len(set(offsets))==546 and len(g)==449 and not g&set(zk)
    assert len(set(zk))==N
    # Regenerate entire fixture, not just neighbor counts of supplied sites.
    counts=Counter(key(q)+d for q in G for d in offsets)
    assert {z for z,n in counts.items() if n>=2 and z not in g}==set(zk)
    Zidx={k:j for j,k in enumerate(zk)}
    ns=[[] for _ in Z]
    for i,q in enumerate(G):
        qk=key(q)
        for d in offsets:
            j=Zidx.get(qk+d)
            if j is not None:ns[j].append(i)
    ds=Counter()
    for k,n,r in zip(zk,ns,rows):
        assert len(n)==len(set(n))==counts[k]==r[0]
        assert tuple(absent(n,c) for c in C)==r[1:]
        ds[len(n)]+=1
    del counts
    rts=(root(43),root(127))
    (p1,_,_,t1),(p2,_,_,t2)=rts
    M=[image(z,rts) for z in Z]
    f1=f2=distance=0
    ans=[]
    details=Counter()
    nh=Counter()
    for i,x in enumerate(G):
        u,v,w,t=image(x,rts)
        for j,(aa,bb,cc,dd) in enumerate(M):
            if (u-aa)*(v-bb)%p1!=t1:continue
            f1+=1
            if (w-cc)*(t-dd)%p2!=t2:continue
            f2+=1
            d=sub(x,Z[j])
            if not flags(d)[1]:continue
            distance+=1
            n=ns[j]
            assert i not in n
            mid=[y for y in n if tuple(sorted((i,y))) in E
                 and all(2*a==b+c for a,b,c in zip(G[y],x,Z[j]))]
            assert len(mid)<=1
            # Independently inspect the algebraic midpoint, if it lies in the grid.
            sums=tuple(a+b for a,b in zip(x,Z[j]))
            if all(t%2==0 for t in sums):
                p=tuple(t//2 for t in sums)
                yy=next((y for y,q in enumerate(G) if q==p),None)
                assert mid==([] if yy is None else [yy])
            else:assert not mid
            wtn=next((k for k,c in enumerate(C) if rows[j][k+1]&(1<<c[i])), None)
            if wtn is not None:assert all(C[wtn][y]!=C[wtn][i] for y in n)
            else:assert all(any(c[y]==c[i] for y in n) for c in C)
            detail=('reflection' if mid else 'nonreflection')+('_witness' if wtn is not None else '_residual')
            details[detail]+=1
            nh[detail,len(n)]+=1
            ans.append({'original':i,'new_grid_id':j,'original_numerator':x,'new_numerator':Z[j],
                        'original_neighbors_of_new':n,'reflected_through':mid[0] if mid else None,
                        'same_color_palette':wtn,'shared_color':None if wtn is None else C[wtn][i]})
    assert distance==len(ans)==sum(details.values()) and 0<=distance<=f2<=f1<=449*N
    report={'counts':{'original_times_grid':449*N,'mod43':f1,'mod43_and_mod127':f2,'exact_distance_two':distance},
            'root_information':rts,
            'grid_degree_histogram':dict(sorted(ds.items())),
            'distance_classes':dict(sorted(details.items())),
            'distance_histogram_by_class_and_degree':[[k,m,v] for (k,m),v in sorted(nh.items())],
            'pinned_coordinate_sha256':COORD,'pinned_profile_sha256':PROFILE,'pinned_palette_sha256':PALETTES,
            'true_pairs':ans}
    a.output.write_text(json.dumps(report,separators=(',',':'))+'\n')
    print(report['counts']); print(report['distance_classes'])
    print('root information',rts)
    print('No SAT; a bank residual would not imply forcing.')
if __name__=='__main__':main()
