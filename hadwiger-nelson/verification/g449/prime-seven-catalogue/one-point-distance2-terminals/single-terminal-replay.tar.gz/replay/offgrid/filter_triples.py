#!/usr/bin/env python3
"""Check simultaneous unequal colors for each distinguished vertex and pair of others."""
import argparse,json
from collections import Counter
from hashlib import sha256
from math import comb
from pathlib import Path
from rotation_bank import load_data

PALETTE='6ada0cb4253e7bad57cedc7a732485bdbca2d6e8ccc79b1b9d48a9257d180888'
K=61
ALL=(1<<K)-1

def main():
    p=argparse.ArgumentParser(description=__doc__)
    for name in ('base','catalogue','palettes','output','residuals'):
        p.add_argument(name,type=Path)
    a=p.parse_args()
    G,orig,E,Dc=load_data(a.base,a.catalogue)
    n=len(G)
    assert n==449 and len(E)==2198 and len(Dc)==546
    raw=a.palettes.read_bytes()
    assert sha256(raw).hexdigest()==PALETTE
    C=[tuple(map(int,o['colors'])) for o in json.loads(raw)['palettes']]
    assert len(C)==K and C[0]==orig
    assert all(len(c)==n and set(c)==set(range(5)) and all(c[i]!=c[j] for i,j in E) for c in C)
    eq=[[0]*n for _ in G]
    for k,c in enumerate(C):
        groups=[[j for j,t in enumerate(c) if t==b] for b in range(5)]
        bit=1<<k
        for i,b in enumerate(c):
            d=eq[i]
            for j in groups[b]:d[j]|=bit
    assert all(eq[i][i]==ALL for i in range(n))
    for i in range(n):
        for j in range(i+1,n):
            mask=sum((1<<k) for k,c in enumerate(C) if c[i]!=c[j])
            assert eq[i][j]==eq[j][i]==(ALL^mask) and mask
    count=0
    residuals=0
    outside=[]
    summary=Counter()
    with a.residuals.open('w') as f:
        for x,row in enumerate(eq):
            sites=[(y,ALL^e) for y,e in enumerate(row) if y!=x]
            terms=[d for y,d in sites]
            masksz=Counter(d.bit_count() for d in terms)
            summary.update(masksz)
            base_count=count
            for i,d in enumerate(terms):
                # For every suffix, count every unordered pair exactly once.
                hit=0
                for e in terms[i+1:]:
                    hit+=bool(d&e)
                count+=hit
                rest=len(terms)-i-1
                if hit!=rest:
                    y=sites[i][0]
                    for w,e in sites[i+1:]:
                        if not d&e:
                            assert not any(c[x]!=c[y] and c[x]!=c[w] for c in C)
                            residuals+=1
                            f.write(json.dumps({'original_terminal':x,'neighbor_pair':[y,w],
                                                'different_masks_hex':[hex(d),hex(e)]},separators=(',',':'))+'\n')
            rejected=comb(n-1,2)-(count-base_count)
            assert rejected>=0
            if rejected:outside.append([x,rejected])
    assert count+residuals==n*comb(n-1,2)
    assert sum(m for _,m in outside)==residuals
    report={'vertices':n,'unit_edges':len(E),'palettes':len(C),'palette_input_sha256':PALETTE,
            'distinguished_triples':n*comb(n-1,2),'checked_positive':count,'residuals':residuals,
            'residuals_by_terminal':outside,
            'ordered_distinct_pair_inequality_palette_count_histogram':dict(sorted(summary.items())),
            'residual_jsonl_sha256':sha256(a.residuals.read_bytes()).hexdigest()}
    a.output.write_text(json.dumps(report,indent=2)+'\n')
    print(f'{n*comb(n-1,2):,} triples of distinct originals (x; unordered y,w).')
    print(f'{count:,} have explicit palette-bit witnesses; {residuals:,} remain for geometry.')
    print('No SAT or geometric triple search.')
if __name__=='__main__':main()
