#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
sha256sum -c SOURCE-AND-RECEIPTS.sha256
export LEAN_PATH="$PWD:${LEAN_PATH:?Set to pinned compiled Mathlib and its packages}"
LEAN_BIN="${LEAN_BIN:-lean}"
for m in ES33/PlanarPrelude ES33/QuadrupleReduction ES33/TriangleOrientation ES33/QuadrupleParity ES33/OrientationClauses ES33/Signotope ES33/FullReduction ES33/AnchorReduction ES33/LocalCNF ES33/ProjectiveAnchor ES33/AnchoredTarget ReflectionAlgebra RealDeterminantAdapter ReflectionLexTransport GeometricReflection GeometricReflectionLeader; do
  "$LEAN_BIN" -j1 -M2450 -DwarningAsError=true -o "$m.olean" "$m.lean"
done
