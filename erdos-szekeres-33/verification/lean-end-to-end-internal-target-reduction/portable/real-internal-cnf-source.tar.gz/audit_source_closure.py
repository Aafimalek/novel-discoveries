#!/usr/bin/env python3
"""A static dependency/receipt audit, not a new Lean build."""
from pathlib import Path
import hashlib,json,re
R=Path(__file__).resolve().parent
src=R/'src'
receipt=R/'historical-receipts'
mods={'.'.join(p.relative_to(src).with_suffix('').parts):p for p in src.rglob('*.lean')}
order=(R/'build-order.txt').read_text().splitlines()
assert len(order)==len(set(order))==len(mods)==33
parents={}
for n in order:
    names=re.findall(r'(?m)^import\s+([\w.]+)',mods[n].read_text())
    assert all(m in mods or m=='Lean' or m.startswith('Mathlib.') for m in names),(n,names)
    parents[n]=set(names)&mods.keys()
    assert parents[n]<=parents.keys()-{n},(n,parents[n])
todo={'RealChainExclusions'}
seen=set()
while todo:
    n=todo.pop()
    if n not in seen:
        seen.add(n)
        todo|=parents[n]
assert seen==mods.keys()
dig=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
legacy={
  'ReflectionAlgebra':('algebra-build.log','ES33.ReflectionAlgebra.orient_mirror_reverse','06754c65e933bb1d97458df4d68e0a22eeb9f3b5b1921236314ca1afde61457f'),
  'ReflectionLexTransport':('reflection.log','ES33.ReflectionLex.exists_leader_representative','ad57281dc8795602c0cbb6b7721fc7a0c47595c6ff3ab5696a0515366af7580c'),
  'NumberedCNF':('numbering.log','ES33.Numbering.compile_roundtrip','56d33a37495caa056c57f17460a0468e9a03339ade86a73662756a3962a9db5e'),
  'EndpointGuardCore':('lean-guards.log','ES33.EndpointGuard.pruned_iff_full_model','af17bcbe93266185d8317d5c552905d8f1653132664851fdb9bda02243b149cb'),
  'EndpointBaseAliases':('aliases.log','ES33.EndpointGuard.pruned_base_aliases_equisat','716fba052722a07f294b783cdee2a0777e778682bbda83a343955af6a872792b'),
}
allow={'propext','Classical.choice','Quot.sound'}
found=0
for n,p in mods.items():
    short=n.split('.')[-1]
    if short in legacy:
        log,thm,h=legacy[short]
        assert dig(p)==h and f"'{thm}'" in (receipt/log).read_text(),n
        continue
    if short in ('PlanarPrelude','RealDeterminantAdapter'):
        r=json.loads((receipt/'PreludeAdapter.json').read_text())[
            'prelude' if short=='PlanarPrelude' else 'adapter']
    else:
        r=json.loads((receipt/f'{short}.json').read_text())
    assert r['exit']==0 and r['verified'] and r['source_sha256']==dig(p),n
    assert all(set(v)<=allow for v in r.get('axioms',{}).values()),n
    found+=1
assert found==28
end=json.loads((receipt/'RealChainExclusions.json').read_text())
assert set(end['axioms'])=={'ES33.EndpointConcrete.'+t for t in
  ('chainVal_excludes32','real_residual_satisfies_target32','es33_of_internal_target32_unsat')}
print('Exact 33-source local dependency closure is topological and complete.')
print('28 sources tied to zero-exit hash receipts; five pinned legacy sources have corresponding historical audit logs.')
print('No Lean process launched by this static audit.')
