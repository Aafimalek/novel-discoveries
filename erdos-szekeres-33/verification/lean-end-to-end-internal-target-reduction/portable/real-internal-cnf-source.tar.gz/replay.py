#!/usr/bin/env python3
"""Fresh strict replay only when --compile-approved is explicit."""
import argparse,hashlib,json,os,re,subprocess,sys,time
from pathlib import Path
R=Path(__file__).resolve().parent
A=argparse.ArgumentParser(description=__doc__)
A.add_argument('--compile-approved',action='store_true')
A.add_argument('--lean',type=Path)
A.add_argument('--out',type=Path)
A.add_argument('--mathlib-lean-path')
a=A.parse_args()
subprocess.run(['sha256sum','-c','SHA256SUMS'],check=True,cwd=R)
subprocess.run([sys.executable,str(R/'audit_source_closure.py')],check=True)
if not a.compile_approved:sys.exit(0)
assert a.lean and a.out and a.mathlib_lean_path,'explicit executable/output/import root arguments required'
dig=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
lean=a.lean.resolve(); out=a.out.resolve()
assert dig(lean)=='db7f559d05795e7af52e42bc966c90240a39dcb9712161c54c97afa546e20c00'
mods=(R/'build-order.txt').read_text().splitlines()
lib=[Path(x).resolve() for x in a.mathlib_lean_path.split(os.pathsep)]
for d in lib:
    assert d.is_dir() and not (d/'ES33').exists(),d
    assert not any((d/(m.replace('.','/')+'.olean')).exists() for m in mods),d
out.mkdir()
for x in ('objects','logs','tmp'):(out/x).mkdir()
env={**os.environ,'LEAN_PATH':os.pathsep.join(map(str,[out/'objects',*lib])),
     'TMPDIR':str(out/'tmp')}
version=subprocess.check_output([str(lean),'--version'],env=env,text=True)
(out/'lean-version.txt').write_text(version)
assert 'version 4.36.0' in version
allowed={'propext','Classical.choice','Quot.sound'}
for m in mods:
    loc=m.replace('.','/')
    src=R/'src'/f'{loc}.lean'
    obj=out/'objects'/f'{loc}.olean'; obj.parent.mkdir(parents=True,exist_ok=True)
    log=out/'logs'/f'{m}.log'; start=time.monotonic()
    reason=''; peak=0
    with log.open('wb') as f:
        p=subprocess.Popen([str(lean),'-j','1','-M','2250','-DwarningAsError=true',
                 '--root',str(R/'src'),'-o',str(obj),str(src)],
                 env=env,stdout=f,stderr=f)
        while p.poll() is None:
            try:
                rss=next(int(l.split()[1]) for l in Path(f'/proc/{p.pid}/status')
                         .read_text().splitlines() if l.startswith('VmRSS:'))
                peak=max(peak,rss)
                if rss>2310000:reason='rss';p.kill();break
            except (FileNotFoundError,StopIteration):pass
            if time.monotonic()-start>150:reason='stage timeout';p.kill();break
            time.sleep(.05)
        rc=p.wait()
    txt=log.read_text()
    audits={k:(v.split(', ') if v else []) for k,v in re.findall(
      r"^'([^']+)' (?:depends on axioms: \[([^]]*)\]|does not depend on any axioms)$",txt,re.M)}
    bad=any(set(s)-allowed for s in audits.values())
    rec=dict(module=m,exit=rc,reason=reason,wall_s=round(time.monotonic()-start,3),
      sampled_rss_kib=peak,source_sha256=dig(src),log_sha256=dig(log),axioms=audits)
    if obj.is_file():rec['olean_sha256']=dig(obj)
    (out/'logs'/f'{m}.json').write_text(json.dumps(rec,indent=2)+'\n')
    print(m,rc,reason,rec['wall_s'],peak,flush=True)
    assert rc==0 and obj.is_file() and not bad,log
    if m=='RealChainExclusions':
        assert 'ES33.EndpointConcrete.es33_of_internal_target32_unsat' in audits
