#!/usr/bin/env bash
# Usage: replay.sh LEAN FRESH_OUT MATHLIB_LEAN_PATH [--compile-approved]
set -euo pipefail
HERE="$(cd "$(dirname "$0")" && pwd)"
LEAN="$(realpath "$1")"; OUT="$(realpath -m "$2")"; MATHLIB_LEAN_PATH="$3"
shift 3
(cd "$HERE" && sha256sum -c SHA256SUMS && python3 audit_source_closure.py)
if [ "$#" -eq 0 ]; then
  echo 'Static preflight only; no Lean process invoked.'
  exit 0
fi
[ "$#" -eq 1 ] && [ "$1" = --compile-approved ]
test ! -e "$OUT"
test -d "$(dirname "$OUT")"
IFS=: read -r -a roots <<< "$MATHLIB_LEAN_PATH"
for dir in "${roots[@]}"; do
  test -d "$dir" && test ! -e "$dir/ES33"
  for m in RealResidualExtraction OrbitPairs32 ReflectionAlgebra ReflectionLexTransport RealDeterminantAdapter GeometricReflection GeometricReflectionLeader; do
    test ! -e "$dir/$m.olean"
  done
done
mkdir "$OUT" "$OUT/objects" "$OUT/logs"
export LEAN_PATH="$OUT/objects:$MATHLIB_LEAN_PATH"
"$LEAN" --version | tee "$OUT/lean-version.log"
grep -F 'version 4.36.0' "$OUT/lean-version.log" >/dev/null
while IFS= read -r mod; do
  loc="$(tr . / <<< "$mod")"
  mkdir -p "$(dirname "$OUT/objects/$loc.olean")"
  (
    cd "$HERE/src"
    timeout 150 "$LEAN" -j 1 -M 2250 -DwarningAsError=true \
      --root "$HERE/src" -o "$OUT/objects/$loc.olean" "$HERE/src/$loc.lean"
  ) 2>&1 | tee "$OUT/logs/$mod.log"
  sha256sum "$HERE/src/$loc.lean" "$OUT/objects/$loc.olean" "$OUT/logs/$mod.log" > "$OUT/logs/$mod.sha256"
done < "$HERE/build-order.txt"
test -s "$OUT/objects/RealResidualExtraction.olean"
test -s "$OUT/objects/OrbitPairs32.olean"
if grep -R -E 'sorryAx|native_decide|Lean\.ofReduceBool' "$OUT/logs/"*.log; then
  echo 'Unexpected proof dependency in axiom logs.' >&2; exit 1
fi
echo 'All 17 local source modules replayed in fresh output root.'
