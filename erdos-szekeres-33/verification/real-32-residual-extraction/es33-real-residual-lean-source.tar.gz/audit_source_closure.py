"""Read only: prove the selected local imports are a complete topological closure."""
from pathlib import Path
import hashlib,json,re
R=Path(__file__).resolve().parent
src=R/'src'
mods={'.'.join(p.relative_to(src).with_suffix('').parts):p for p in src.rglob('*.lean')}
order=(R/'build-order.txt').read_text().splitlines()
assert len(order)==len(set(order))==len(mods)==17
done=set()
parents={}
for n in order:
    content=mods[n].read_text()
    deps=set(m for m in re.findall(r'(?m)^import\s+([\w.]+)',content) if m in mods or m.startswith('ES33.'))
    assert deps<=done,(n,deps-done)
    parents[n]=deps
    done.add(n)
starts={'RealResidualExtraction','OrbitPairs32'}
seen=set()
while starts:
    n=starts.pop()
    if n not in seen:
        seen.add(n); starts|=parents[n]
assert seen==set(mods)
h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for n,p in mods.items():
    short=n.split('.')[-1]
    receipt=R/'historical-receipts'/f'{short}.json'
    if receipt.is_file():
        r=json.loads(receipt.read_text())
        assert r['exit']==0 and r['verified'] and r['source_sha256']==h(p),n
    else:
        if short in ('PlanarPrelude','RealDeterminantAdapter'):
            r=json.loads((R/'historical-receipts/PreludeAdapter.json').read_text())[
               'prelude' if short=='PlanarPrelude' else 'adapter']
            assert r['exit']==0 and r['verified'] and r['source_sha256']==h(p),n
        else:
            assert short in ('ReflectionAlgebra','ReflectionLexTransport'),n
print('Verified exact closed local dependency graph for the two endpoints: 17 Lean sources in topological order.')
print('15 matching historical source-hash/exit-zero receipts; separate existing audits for algebra and abstract lex.')
