"""Exact independent 32-label orbit table check, not a Lean proof."""
from itertools import combinations
from hashlib import sha256
import json
T=list(combinations(range(32),3))
rank={t:i for i,t in enumerate(T,1)}
def rev(t):return tuple(31-x for x in reversed(t))
def keep(t):
    a,b,c=t
    return a+c<31 or (a+c==31 and b<=15)
reps=[t for t in T if keep(t)]
assert len(T)==4960 and len(reps)==2480
assert all(rev(rev(t))==t and rev(t)!=t for t in T)
assert all(keep(t)==(rank[t]<rank[rev(t)]) for t in T)
pairs=[(rank[t],rank[rev(t)]) for t in reps]
assert sorted(v for row in pairs for v in row)==list(range(1,4961))
counts=[sum(t[0]==a for t in reps) for a in range(32)]
assert sum(counts)==2480
payload=json.dumps(pairs,separators=(',',':')).encode('ascii')+b'\n'
print('4960 ordered triples; 2480 fixed-point-free exact reversal pairs.')
print('The numerical representative guard agrees for every triple with the earlier orientation-ID test.')
print('Rep counts by first label:',*counts)
print('Pair-list SHA-256 (compact JSON plus newline):',sha256(payload).hexdigest())
