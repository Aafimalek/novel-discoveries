# Portable source-only replay: real residual/lex extraction and orbit invariants

This is the complete *local* Lean source closure of RealResidualExtraction
and OrbitPairs32. It contains 17 sources in explicit topological order
and existing per-module checked receipts. It does not redistribute
prebuilt Lean modules or Mathlib. Use Lean 4.36.0, Mathlib commit
fc4f59e577feb1a4956671bc04ac18aaaf8cd842, and its matching compiled
package closure. The supplied LEAN_PATH must contain only those compiled
Mathlib/package roots and not any preexisting ES33 objects.

    bash replay.sh /path/to/lean /path/to/fresh/output "[colon-separated Mathlib/package paths]"

This command only runs static source and closure checks. A later
authorized full rebuild can append --compile-approved; it builds serially
from sources, stops on any error, and records per-module axiom logs and
source/object/log hashes. The full 17-module replay was not invoked
while packaging. Individual stage receipts attest the exact compiled
modules in their matching rebuilt stack; do not misreport them as a
second clean-directory replay.

The actual 33-to-real-32 witness extraction, the checked lex choice for
a *given* triple list, and the structural ordered-orbit invariants are
checked. The externally confirmed 2,480 count is not a theorem in this
closure. No numbered CNF, concrete literal containment, target UNSAT,
or claim of the Erdős–Szekeres theorem itself follows.
