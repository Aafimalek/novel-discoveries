import Mathlib.Tactic.Sat.FromLRAT

set_option maxHeartbeats 0
set_option maxRecDepth 100000

lrat_proof slot17_core_unsat (include_str "core.cnf") (include_str "core.lrat")

#print axioms slot17_core_unsat
