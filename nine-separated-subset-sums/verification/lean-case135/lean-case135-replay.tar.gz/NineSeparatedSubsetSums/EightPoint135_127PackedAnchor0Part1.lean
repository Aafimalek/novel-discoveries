import NineSeparatedSubsetSums.EightPoint135_127PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint135_127PackedAnchor0Part1 :
    ∀ j : Fin 120, 2342961 ≤ FourPointNumeric.octPackedCharge 135 127 20 packedOct135_127_0
      (2*((j.val : Int)+120)+0) := by decide +kernel

end NineSeparatedSubsetSums
