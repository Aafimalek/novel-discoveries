import NineSeparatedSubsetSums.Adaptive135Third105Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint135Checked

namespace NineSeparatedSubsetSums


theorem adaptive135Third105 : NoDescendingTailAfterThird 135 105 :=
  noDescendingThirdTail_of_cached 135 105 110858 (fun t ht nd => max148_second135_fourPoint_moment_bound (105::t) (by simp [ht]) nd) adaptive135Third105Proof0

#print axioms adaptive135Third105

end NineSeparatedSubsetSums
