import NineSeparatedSubsetSums.FourPoint135PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem fourPoint135PackedAnchor0Part0 :
    ∀ j : Fin 120, 1073976 ≤ FourPointNumeric.packedCharge 135 20 packedWeight135_0
      (2*((j.val : Int)+0)+1) := by decide +kernel

end NineSeparatedSubsetSums
