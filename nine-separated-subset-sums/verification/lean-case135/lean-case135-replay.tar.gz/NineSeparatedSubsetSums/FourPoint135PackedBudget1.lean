import NineSeparatedSubsetSums.FourPoint135PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedWeight135_1_budget :
    FourPointNumeric.packedBudget 20 packedWeight135_1 642 = 80703360 := by decide +kernel

#print axioms packedWeight135_1_budget

end NineSeparatedSubsetSums
