import NineSeparatedSubsetSums.EightPoint135_127PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint135_127PackedAnchor1Part2 :
    ∀ j : Fin 3, 2343988 ≤ FourPointNumeric.octPackedCharge 135 127 20 packedOct135_127_1
      (2*((j.val : Int)+240)+1) := by decide +kernel

end NineSeparatedSubsetSums
