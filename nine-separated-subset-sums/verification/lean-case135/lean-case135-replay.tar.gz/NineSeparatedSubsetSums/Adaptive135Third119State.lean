import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive135Third119Node0 : CachedSearchNode :=
  ⟨4, 118, computeCenteredMask [148,135,119], 402, 54290⟩

end NineSeparatedSubsetSums
