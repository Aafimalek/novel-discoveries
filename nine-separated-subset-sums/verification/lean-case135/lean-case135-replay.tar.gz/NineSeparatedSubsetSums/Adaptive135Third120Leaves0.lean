import NineSeparatedSubsetSums.Adaptive135Third120State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive135Third120Proof0 : runCachedNode 511 124652 Adaptive135Third120Node0 = false := by
  decide +kernel

#print axioms adaptive135Third120Proof0

end NineSeparatedSubsetSums
