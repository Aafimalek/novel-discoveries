import NineSeparatedSubsetSums.Adaptive135Third127State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive135Third127Proof15 : runCachedNode 511 126471 Adaptive135Third127Node15 = false := by
  decide +kernel

#print axioms adaptive135Third127Proof15

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive135Third127Proof14 : runCachedNode 511 126471 Adaptive135Third127Node14 = false := by
  decide +kernel

#print axioms adaptive135Third127Proof14

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive135Third127Proof11 : runCachedNode 511 126471 Adaptive135Third127Node11 = false := by
  decide +kernel

#print axioms adaptive135Third127Proof11

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive135Third127Proof13 : runCachedNode 511 126471 Adaptive135Third127Node13 = false := by
  decide +kernel

#print axioms adaptive135Third127Proof13

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive135Third127Proof12 : runCachedNode 511 126471 Adaptive135Third127Node12 = false := by
  decide +kernel

#print axioms adaptive135Third127Proof12

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive135Third127Proof10 : runCachedNode 511 126471 Adaptive135Third127Node10 = false := by
  decide +kernel

#print axioms adaptive135Third127Proof10

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive135Third127Proof9 : runCachedNode 511 126471 Adaptive135Third127Node9 = false := by
  decide +kernel

#print axioms adaptive135Third127Proof9

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive135Third127Proof8 : runCachedNode 511 126471 Adaptive135Third127Node8 = false := by
  decide +kernel

#print axioms adaptive135Third127Proof8

end NineSeparatedSubsetSums
