import NineSeparatedSubsetSums.Adaptive135Third132State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive135Third132Proof18 : runCachedNode 511 127331 Adaptive135Third132Node18 = false := by
  decide +kernel

#print axioms adaptive135Third132Proof18

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive135Third132Proof17 : runCachedNode 511 127331 Adaptive135Third132Node17 = false := by
  decide +kernel

#print axioms adaptive135Third132Proof17

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive135Third132Proof5 : runCachedNode 511 127331 Adaptive135Third132Node5 = false := by
  decide +kernel

#print axioms adaptive135Third132Proof5

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive135Third132Proof4 : runCachedNode 511 127331 Adaptive135Third132Node4 = false := by
  decide +kernel

#print axioms adaptive135Third132Proof4

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive135Third132Proof2 : runCachedNode 511 127331 Adaptive135Third132Node2 = false := by
  decide +kernel

#print axioms adaptive135Third132Proof2

end NineSeparatedSubsetSums
