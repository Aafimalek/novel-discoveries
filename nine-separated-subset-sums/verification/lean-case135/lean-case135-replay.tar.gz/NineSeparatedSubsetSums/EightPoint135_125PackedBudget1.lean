import NineSeparatedSubsetSums.EightPoint135_125PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct135_125_1_budget :
    FourPointNumeric.packedBudget 20 packedOct135_125_1 480 = 82908678 := by decide +kernel

#print axioms packedOct135_125_1_budget

end NineSeparatedSubsetSums
