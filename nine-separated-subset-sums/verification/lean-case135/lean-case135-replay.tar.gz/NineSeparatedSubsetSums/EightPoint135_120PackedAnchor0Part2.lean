import NineSeparatedSubsetSums.EightPoint135_120PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint135_120PackedAnchor0Part2 :
    ∀ j : Fin 4, 2327011 ≤ FourPointNumeric.octPackedCharge 135 120 20 packedOct135_120_0
      (2*((j.val : Int)+240)+1) := by decide +kernel

end NineSeparatedSubsetSums
