import NineSeparatedSubsetSums.EightPoint135_121PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct135_121_0_budget :
    FourPointNumeric.packedBudget 20 packedOct135_121_0 267 = 84944619 := by decide +kernel

#print axioms packedOct135_121_0_budget

end NineSeparatedSubsetSums
