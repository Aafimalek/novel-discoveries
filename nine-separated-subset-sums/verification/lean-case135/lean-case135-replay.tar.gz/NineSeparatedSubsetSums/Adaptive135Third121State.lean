import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive135Third121Node0 : CachedSearchNode :=
  ⟨4, 120, computeCenteredMask [148,135,121], 404, 54770⟩

end NineSeparatedSubsetSums
