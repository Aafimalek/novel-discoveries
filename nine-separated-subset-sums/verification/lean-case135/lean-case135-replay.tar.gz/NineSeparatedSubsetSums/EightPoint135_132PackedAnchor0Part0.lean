import NineSeparatedSubsetSums.EightPoint135_132PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint135_132PackedAnchor0Part0 :
    ∀ j : Fin 120, 2404746 ≤ FourPointNumeric.octPackedCharge 135 132 20 packedOct135_132_0
      (2*((j.val : Int)+0)+1) := by decide +kernel

end NineSeparatedSubsetSums
