import NineSeparatedSubsetSums.Adaptive135Third131State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive135Third131Proof14 : runCachedNode 511 127139 Adaptive135Third131Node14 = false := by
  decide +kernel

#print axioms adaptive135Third131Proof14

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive135Third131Proof11 : runCachedNode 511 127139 Adaptive135Third131Node11 = false := by
  decide +kernel

#print axioms adaptive135Third131Proof11

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive135Third131Proof13 : runCachedNode 511 127139 Adaptive135Third131Node13 = false := by
  decide +kernel

#print axioms adaptive135Third131Proof13

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive135Third131Proof10 : runCachedNode 511 127139 Adaptive135Third131Node10 = false := by
  decide +kernel

#print axioms adaptive135Third131Proof10

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive135Third131Proof9 : runCachedNode 511 127139 Adaptive135Third131Node9 = false := by
  decide +kernel

#print axioms adaptive135Third131Proof9

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive135Third131Proof7 : runCachedNode 511 127139 Adaptive135Third131Node7 = false := by
  decide +kernel

#print axioms adaptive135Third131Proof7

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive135Third131Proof6 : runCachedNode 511 127139 Adaptive135Third131Node6 = false := by
  decide +kernel

#print axioms adaptive135Third131Proof6

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive135Third131Proof5 : runCachedNode 511 127139 Adaptive135Third131Node5 = false := by
  decide +kernel

#print axioms adaptive135Third131Proof5

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive135Third131Proof4 : runCachedNode 511 127139 Adaptive135Third131Node4 = false := by
  decide +kernel

#print axioms adaptive135Third131Proof4

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive135Third131Proof2 : runCachedNode 511 127139 Adaptive135Third131Node2 = false := by
  decide +kernel

#print axioms adaptive135Third131Proof2

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive135Third131Proof1 : runCachedNode 511 127139 Adaptive135Third131Node1 = false := by
  decide +kernel

#print axioms adaptive135Third131Proof1

end NineSeparatedSubsetSums
