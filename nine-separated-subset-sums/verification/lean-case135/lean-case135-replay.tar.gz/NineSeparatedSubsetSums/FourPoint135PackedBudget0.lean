import NineSeparatedSubsetSums.FourPoint135PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedWeight135_0_budget :
    FourPointNumeric.packedBudget 20 packedWeight135_0 605 = 80709504 := by decide +kernel

#print axioms packedWeight135_0_budget

end NineSeparatedSubsetSums
