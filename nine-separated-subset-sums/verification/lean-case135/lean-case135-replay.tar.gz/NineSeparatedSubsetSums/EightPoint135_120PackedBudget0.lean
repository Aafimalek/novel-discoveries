import NineSeparatedSubsetSums.EightPoint135_120PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct135_120_0_budget :
    FourPointNumeric.packedBudget 20 packedOct135_120_0 387 = 85107257 := by decide +kernel

#print axioms packedOct135_120_0_budget

end NineSeparatedSubsetSums
