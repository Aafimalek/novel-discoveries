import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive135Third126Node0 : CachedSearchNode :=
  ⟨4, 125, computeCenteredMask [148,135,126], 409, 56005⟩

end NineSeparatedSubsetSums
