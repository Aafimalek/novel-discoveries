import NineSeparatedSubsetSums.EightPoint135_130PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct135_130_0_budget :
    FourPointNumeric.packedBudget 20 packedOct135_130_0 443 = 87849573 := by decide +kernel

#print axioms packedOct135_130_0_budget

end NineSeparatedSubsetSums
