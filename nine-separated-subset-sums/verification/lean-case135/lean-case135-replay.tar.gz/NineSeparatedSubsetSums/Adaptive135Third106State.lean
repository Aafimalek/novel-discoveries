import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive135Third106Node0 : CachedSearchNode :=
  ⟨4, 105, computeCenteredMask [148,135,106], 389, 51365⟩

end NineSeparatedSubsetSums
