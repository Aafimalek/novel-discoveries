import NineSeparatedSubsetSums.EightPoint135_122PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct135_122_1_budget :
    FourPointNumeric.packedBudget 20 packedOct135_122_1 264 = 80559726 := by decide +kernel

#print axioms packedOct135_122_1_budget

end NineSeparatedSubsetSums
