import NineSeparatedSubsetSums.EightPoint135_129PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct135_129_0_budget :
    FourPointNumeric.packedBudget 20 packedOct135_129_0 365 = 86158800 := by decide +kernel

#print axioms packedOct135_129_0_budget

end NineSeparatedSubsetSums
