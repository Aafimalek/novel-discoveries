import NineSeparatedSubsetSums.Adaptive135Third112Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint135Checked

namespace NineSeparatedSubsetSums


theorem adaptive135Third112 : NoDescendingTailAfterThird 135 112 :=
  noDescendingThirdTail_of_cached 135 112 110858 (fun t ht nd => max148_second135_fourPoint_moment_bound (112::t) (by simp [ht]) nd) adaptive135Third112Proof0

#print axioms adaptive135Third112

end NineSeparatedSubsetSums
