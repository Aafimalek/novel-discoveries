import NineSeparatedSubsetSums.Adaptive135Third119State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive135Third119Proof0 : runCachedNode 511 124626 Adaptive135Third119Node0 = false := by
  decide +kernel

#print axioms adaptive135Third119Proof0

end NineSeparatedSubsetSums
