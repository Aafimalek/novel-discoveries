import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive135Third124Node0 : CachedSearchNode :=
  ⟨4, 123, computeCenteredMask [148,135,124], 407, 55505⟩

end NineSeparatedSubsetSums
