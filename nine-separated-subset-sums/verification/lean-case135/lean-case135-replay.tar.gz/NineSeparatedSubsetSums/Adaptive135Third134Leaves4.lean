import NineSeparatedSubsetSums.Adaptive135Third134State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive135Third134Proof15 : runCachedNode 511 127641 Adaptive135Third134Node15 = false := by
  decide +kernel

#print axioms adaptive135Third134Proof15

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive135Third134Proof14 : runCachedNode 511 127641 Adaptive135Third134Node14 = false := by
  decide +kernel

#print axioms adaptive135Third134Proof14

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive135Third134Proof11 : runCachedNode 511 127641 Adaptive135Third134Node11 = false := by
  decide +kernel

#print axioms adaptive135Third134Proof11

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive135Third134Proof13 : runCachedNode 511 127641 Adaptive135Third134Node13 = false := by
  decide +kernel

#print axioms adaptive135Third134Proof13

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive135Third134Proof44 : runCachedNode 511 127641 Adaptive135Third134Node44 = false := by
  decide +kernel

#print axioms adaptive135Third134Proof44

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive135Third134Proof43 : runCachedNode 511 127641 Adaptive135Third134Node43 = false := by
  decide +kernel

#print axioms adaptive135Third134Proof43

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive135Third134Proof4 : runCachedNode 511 127641 Adaptive135Third134Node4 = false := by
  decide +kernel

#print axioms adaptive135Third134Proof4

end NineSeparatedSubsetSums
