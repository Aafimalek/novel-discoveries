import NineSeparatedSubsetSums.Adaptive135Third115Joins0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint135Checked

namespace NineSeparatedSubsetSums


theorem adaptive135Third115 : NoDescendingTailAfterThird 135 115 :=
  noDescendingThirdTail_of_cached 135 115 110858 (fun t ht nd => max148_second135_fourPoint_moment_bound (115::t) (by simp [ht]) nd) adaptive135Third115Proof0

#print axioms adaptive135Third115

end NineSeparatedSubsetSums
