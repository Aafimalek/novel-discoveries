import NineSeparatedSubsetSums.EightPoint135_123PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct135_123_0_budget :
    FourPointNumeric.packedBudget 20 packedOct135_123_0 405 = 80983770 := by decide +kernel

#print axioms packedOct135_123_0_budget

end NineSeparatedSubsetSums
