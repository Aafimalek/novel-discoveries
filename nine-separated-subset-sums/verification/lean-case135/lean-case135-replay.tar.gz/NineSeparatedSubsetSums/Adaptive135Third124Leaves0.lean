import NineSeparatedSubsetSums.Adaptive135Third124State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive135Third124Proof0 : runCachedNode 511 125644 Adaptive135Third124Node0 = false := by
  decide +kernel

#print axioms adaptive135Third124Proof0

end NineSeparatedSubsetSums
