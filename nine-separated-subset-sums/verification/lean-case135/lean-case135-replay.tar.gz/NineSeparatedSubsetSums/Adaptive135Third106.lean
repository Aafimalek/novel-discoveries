import NineSeparatedSubsetSums.Adaptive135Third106Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint135Checked

namespace NineSeparatedSubsetSums


theorem adaptive135Third106 : NoDescendingTailAfterThird 135 106 :=
  noDescendingThirdTail_of_cached 135 106 110858 (fun t ht nd => max148_second135_fourPoint_moment_bound (106::t) (by simp [ht]) nd) adaptive135Third106Proof0

#print axioms adaptive135Third106

end NineSeparatedSubsetSums
