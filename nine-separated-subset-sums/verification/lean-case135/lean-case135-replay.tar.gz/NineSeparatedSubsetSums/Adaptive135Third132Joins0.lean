import NineSeparatedSubsetSums.Adaptive135Third132State
import NineSeparatedSubsetSums.Adaptive135Third132Leaves2
import NineSeparatedSubsetSums.Adaptive135Third132Leaves1
import NineSeparatedSubsetSums.Adaptive135Third132Leaves3
import NineSeparatedSubsetSums.Adaptive135Third132Leaves0

namespace NineSeparatedSubsetSums

theorem adaptive135Third132Proof0 : runCachedNode 511 127331 Adaptive135Third132Node0 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 127331 Adaptive135Third132Node0 = [111, 112, 113, 114, 115, 116, 117, 118, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive135Third132Proof1
  · exact adaptive135Third132Proof2
  · exact adaptive135Third132Proof3
  · exact adaptive135Third132Proof4
  · exact adaptive135Third132Proof5
  · exact adaptive135Third132Proof6
  · exact adaptive135Third132Proof7
  · exact adaptive135Third132Proof8
  · exact adaptive135Third132Proof9
  · exact adaptive135Third132Proof10
  · exact adaptive135Third132Proof11
  · exact adaptive135Third132Proof12
  · exact adaptive135Third132Proof13
  · exact adaptive135Third132Proof14
  · exact adaptive135Third132Proof15
  · exact adaptive135Third132Proof16
  · exact adaptive135Third132Proof17
  · exact adaptive135Third132Proof18
  · exact adaptive135Third132Proof19
  · exact adaptive135Third132Proof20

#print axioms adaptive135Third132Proof0

end NineSeparatedSubsetSums
