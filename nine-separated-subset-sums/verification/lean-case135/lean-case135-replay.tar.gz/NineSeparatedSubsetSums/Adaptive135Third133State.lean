import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive135Third133Node0 : CachedSearchNode :=
  ⟨4, 132, computeCenteredMask [148,135,133], 416, 57818⟩
def Adaptive135Third133Node1 : CachedSearchNode := cachedChild Adaptive135Third133Node0 111
def Adaptive135Third133Node2 : CachedSearchNode := cachedChild Adaptive135Third133Node0 112
def Adaptive135Third133Node3 : CachedSearchNode := cachedChild Adaptive135Third133Node0 113
def Adaptive135Third133Node4 : CachedSearchNode := cachedChild Adaptive135Third133Node0 114
def Adaptive135Third133Node5 : CachedSearchNode := cachedChild Adaptive135Third133Node0 115
def Adaptive135Third133Node6 : CachedSearchNode := cachedChild Adaptive135Third133Node0 116
def Adaptive135Third133Node7 : CachedSearchNode := cachedChild Adaptive135Third133Node0 117
def Adaptive135Third133Node8 : CachedSearchNode := cachedChild Adaptive135Third133Node0 118
def Adaptive135Third133Node9 : CachedSearchNode := cachedChild Adaptive135Third133Node0 119
def Adaptive135Third133Node10 : CachedSearchNode := cachedChild Adaptive135Third133Node0 121
def Adaptive135Third133Node11 : CachedSearchNode := cachedChild Adaptive135Third133Node0 122
def Adaptive135Third133Node12 : CachedSearchNode := cachedChild Adaptive135Third133Node0 123
def Adaptive135Third133Node13 : CachedSearchNode := cachedChild Adaptive135Third133Node0 124
def Adaptive135Third133Node14 : CachedSearchNode := cachedChild Adaptive135Third133Node0 125
def Adaptive135Third133Node15 : CachedSearchNode := cachedChild Adaptive135Third133Node0 126
def Adaptive135Third133Node16 : CachedSearchNode := cachedChild Adaptive135Third133Node0 127
def Adaptive135Third133Node17 : CachedSearchNode := cachedChild Adaptive135Third133Node0 128
def Adaptive135Third133Node18 : CachedSearchNode := cachedChild Adaptive135Third133Node0 129
def Adaptive135Third133Node19 : CachedSearchNode := cachedChild Adaptive135Third133Node0 130
def Adaptive135Third133Node20 : CachedSearchNode := cachedChild Adaptive135Third133Node0 131
def Adaptive135Third133Node21 : CachedSearchNode := cachedChild Adaptive135Third133Node0 132

end NineSeparatedSubsetSums
