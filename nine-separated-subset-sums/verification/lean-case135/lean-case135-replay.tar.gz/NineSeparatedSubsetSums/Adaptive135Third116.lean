import NineSeparatedSubsetSums.Adaptive135Third116Joins0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint135Checked

namespace NineSeparatedSubsetSums


theorem adaptive135Third116 : NoDescendingTailAfterThird 135 116 :=
  noDescendingThirdTail_of_cached 135 116 110858 (fun t ht nd => max148_second135_fourPoint_moment_bound (116::t) (by simp [ht]) nd) adaptive135Third116Proof0

#print axioms adaptive135Third116

end NineSeparatedSubsetSums
