import NineSeparatedSubsetSums.Adaptive135Third128State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive135Third128Proof13 : runCachedNode 511 126513 Adaptive135Third128Node13 = false := by
  decide +kernel

#print axioms adaptive135Third128Proof13

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive135Third128Proof12 : runCachedNode 511 126513 Adaptive135Third128Node12 = false := by
  decide +kernel

#print axioms adaptive135Third128Proof12

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive135Third128Proof9 : runCachedNode 511 126513 Adaptive135Third128Node9 = false := by
  decide +kernel

#print axioms adaptive135Third128Proof9

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive135Third128Proof8 : runCachedNode 511 126513 Adaptive135Third128Node8 = false := by
  decide +kernel

#print axioms adaptive135Third128Proof8

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive135Third128Proof7 : runCachedNode 511 126513 Adaptive135Third128Node7 = false := by
  decide +kernel

#print axioms adaptive135Third128Proof7

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive135Third128Proof5 : runCachedNode 511 126513 Adaptive135Third128Node5 = false := by
  decide +kernel

#print axioms adaptive135Third128Proof5

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive135Third128Proof4 : runCachedNode 511 126513 Adaptive135Third128Node4 = false := by
  decide +kernel

#print axioms adaptive135Third128Proof4

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive135Third128Proof3 : runCachedNode 511 126513 Adaptive135Third128Node3 = false := by
  decide +kernel

#print axioms adaptive135Third128Proof3

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive135Third128Proof2 : runCachedNode 511 126513 Adaptive135Third128Node2 = false := by
  decide +kernel

#print axioms adaptive135Third128Proof2

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive135Third128Proof1 : runCachedNode 511 126513 Adaptive135Third128Node1 = false := by
  decide +kernel

#print axioms adaptive135Third128Proof1

end NineSeparatedSubsetSums
