import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive135Third123Node0 : CachedSearchNode :=
  ⟨4, 122, computeCenteredMask [148,135,123], 406, 55258⟩

end NineSeparatedSubsetSums
