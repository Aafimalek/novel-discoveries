import NineSeparatedSubsetSums.Adaptive135Third123State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive135Third123Proof0 : runCachedNode 511 125261 Adaptive135Third123Node0 = false := by
  decide +kernel

#print axioms adaptive135Third123Proof0

end NineSeparatedSubsetSums
