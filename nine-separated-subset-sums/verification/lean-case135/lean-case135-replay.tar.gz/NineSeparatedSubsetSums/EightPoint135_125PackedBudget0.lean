import NineSeparatedSubsetSums.EightPoint135_125PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct135_125_0_budget :
    FourPointNumeric.packedBudget 20 packedOct135_125_0 479 = 82906950 := by decide +kernel

#print axioms packedOct135_125_0_budget

end NineSeparatedSubsetSums
