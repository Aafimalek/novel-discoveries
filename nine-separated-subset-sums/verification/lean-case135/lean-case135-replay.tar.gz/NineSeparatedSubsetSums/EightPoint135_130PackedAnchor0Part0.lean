import NineSeparatedSubsetSums.EightPoint135_130PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint135_130PackedAnchor0Part0 :
    ∀ j : Fin 120, 2387338 ≤ FourPointNumeric.octPackedCharge 135 130 20 packedOct135_130_0
      (2*((j.val : Int)+0)+1) := by decide +kernel

end NineSeparatedSubsetSums
