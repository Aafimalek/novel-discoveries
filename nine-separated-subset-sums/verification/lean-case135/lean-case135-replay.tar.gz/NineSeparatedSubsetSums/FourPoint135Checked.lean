import NineSeparatedSubsetSums.FourPointPackedGeometry
import NineSeparatedSubsetSums.FourPoint135PackedBudget0
import NineSeparatedSubsetSums.FourPoint135PackedAnchor0Part0
import NineSeparatedSubsetSums.FourPoint135PackedAnchor0Part1
import NineSeparatedSubsetSums.FourPoint135PackedBudget1
import NineSeparatedSubsetSums.FourPoint135PackedAnchor1Part0
import NineSeparatedSubsetSums.FourPoint135PackedAnchor1Part1

namespace NineSeparatedSubsetSums

private theorem packed135Anchor0 :
  ∀ j : Fin 478, ((j.val : Int)+135)%2=0 →
    1073976 ≤ FourPointNumeric.packedCharge 135 20 packedWeight135_0 (j.val : Int) := by
  intro j hj
  let k := (j.val-1)/2
  have hk : k < 239 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+1 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := fourPoint135PackedAnchor0Part0 z
    rwa [he,hrep] at ht
  let z : Fin 119 := ⟨k-120, by omega⟩
  have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
  have ht := fourPoint135PackedAnchor0Part1 z
  rwa [he,hrep] at ht

private theorem packed135Anchor1 :
  ∀ j : Fin 478, ((j.val : Int)+135)%2=1 →
    1073924 ≤ FourPointNumeric.packedCharge 135 20 packedWeight135_1 (j.val : Int) := by
  intro j hj
  let k := (j.val-0)/2
  have hk : k < 239 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+0 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := fourPoint135PackedAnchor1Part0 z
    rwa [he,hrep] at ht
  let z : Fin 119 := ⟨k-120, by omega⟩
  have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
  have ht := fourPoint135PackedAnchor1Part1 z
  rwa [he,hrep] at ht

def packedCertificate135_0 : FourPointCertificate 135 0 110858 :=
  fourPointCertificateOfPacked 135 0 110858 1073976 20 packedWeight135_0 605 478
    (by decide +kernel) (by decide) (by decide) packed135Anchor0
    (by rw [packedWeight135_0_budget]; decide)

def packedCertificate135_1 : FourPointCertificate 135 1 110858 :=
  fourPointCertificateOfPacked 135 1 110858 1073924 20 packedWeight135_1 642 478
    (by decide +kernel) (by decide) (by decide) packed135Anchor1
    (by rw [packedWeight135_1_budget]; decide)

theorem max148_second135_fourPoint_moment_bound (tail : List ℕ) (len : tail.length=7)
    (distinct : (natSubsetSums (148::135::tail)).Nodup) :
    110858 ≤ ((148::135::tail).map (· ^ 2)).sum := by
  apply fourPointNatMomentLower 135 110858 tail len distinct
  intro p hp
  by_cases h : p=0
  · subst p
    exact packedCertificate135_0
  · have he : p=1 := hp.resolve_left h
    subst p
    exact packedCertificate135_1

#print axioms max148_second135_fourPoint_moment_bound

end NineSeparatedSubsetSums
