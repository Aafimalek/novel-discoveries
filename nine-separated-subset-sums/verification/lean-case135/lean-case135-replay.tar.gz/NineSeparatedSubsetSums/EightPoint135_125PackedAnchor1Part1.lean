import NineSeparatedSubsetSums.EightPoint135_125PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint135_125PackedAnchor1Part1 :
    ∀ j : Fin 120, 2303626 ≤ FourPointNumeric.octPackedCharge 135 125 20 packedOct135_125_1
      (2*((j.val : Int)+120)+1) := by decide +kernel

end NineSeparatedSubsetSums
