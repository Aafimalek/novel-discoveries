import NineSeparatedSubsetSums.EightPoint135_126PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint135_126PackedAnchor0Part2 :
    ∀ j : Fin 3, 2331177 ≤ FourPointNumeric.octPackedCharge 135 126 20 packedOct135_126_0
      (2*((j.val : Int)+240)+1) := by decide +kernel

end NineSeparatedSubsetSums
