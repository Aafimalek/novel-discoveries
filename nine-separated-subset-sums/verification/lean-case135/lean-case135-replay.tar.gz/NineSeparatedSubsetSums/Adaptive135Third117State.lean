import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive135Third117Node0 : CachedSearchNode :=
  ⟨4, 116, computeCenteredMask [148,135,117], 400, 53818⟩

end NineSeparatedSubsetSums
