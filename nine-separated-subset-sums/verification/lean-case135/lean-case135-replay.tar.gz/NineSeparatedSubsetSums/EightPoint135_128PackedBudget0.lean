import NineSeparatedSubsetSums.EightPoint135_128PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct135_128_0_budget :
    FourPointNumeric.packedBudget 20 packedOct135_128_0 443 = 84031570 := by decide +kernel

#print axioms packedOct135_128_0_budget

end NineSeparatedSubsetSums
