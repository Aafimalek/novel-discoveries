import NineSeparatedSubsetSums.EightPointPackedGeometry
import NineSeparatedSubsetSums.EightPoint135_122PackedBudget0
import NineSeparatedSubsetSums.EightPoint135_122PackedAnchor0Part0
import NineSeparatedSubsetSums.EightPoint135_122PackedAnchor0Part1
import NineSeparatedSubsetSums.EightPoint135_122PackedBudget1
import NineSeparatedSubsetSums.EightPoint135_122PackedAnchor1Part0
import NineSeparatedSubsetSums.EightPoint135_122PackedAnchor1Part1

namespace NineSeparatedSubsetSums

private theorem packedOct135_122Anchor0 :
  ∀ j : Fin 479, ((j.val : Int)+135+122)%2=0 →
    2271173 ≤ FourPointNumeric.octPackedCharge 135 122 20 packedOct135_122_0 (j.val : Int) := by
  intro j hj
  let k := (j.val-1)/2
  have hk : k < 239 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+1 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint135_122PackedAnchor0Part0 z
    rwa [he,hrep] at ht
  let z : Fin 119 := ⟨k-120, by omega⟩
  have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
  have ht := eightPoint135_122PackedAnchor0Part1 z
  rwa [he,hrep] at ht

private theorem packedOct135_122Anchor1 :
  ∀ j : Fin 479, ((j.val : Int)+135+122)%2=1 →
    2258425 ≤ FourPointNumeric.octPackedCharge 135 122 20 packedOct135_122_1 (j.val : Int) := by
  intro j hj
  let k := (j.val-0)/2
  have hk : k < 240 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+0 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint135_122PackedAnchor1Part0 z
    rwa [he,hrep] at ht
  let z : Fin 120 := ⟨k-120, by omega⟩
  have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
  have ht := eightPoint135_122PackedAnchor1Part1 z
  rwa [he,hrep] at ht

def packedOctCertificate135_122_0 : EightPointCertificate 135 122 0 124960 :=
  eightPointCertificateOfPacked 135 122 0 124960 2271173 20 packedOct135_122_0 265 479
    (by decide +kernel) (by decide) packedOct135_122Anchor0
    (by rw [packedOct135_122_0_budget]; decide)

def packedOctCertificate135_122_1 : EightPointCertificate 135 122 1 124960 :=
  eightPointCertificateOfPacked 135 122 1 124960 2258425 20 packedOct135_122_1 264 479
    (by decide +kernel) (by decide) packedOct135_122Anchor1
    (by rw [packedOct135_122_1_budget]; decide)

theorem max148_second135_third122_eightPoint_moment_bound (tail : List ℕ) (len : tail.length=6)
    (distinct : (natSubsetSums (148::135::122::tail)).Nodup) :
    124960 ≤ ((148::135::122::tail).map (· ^ 2)).sum := by
  apply eightPointNatMomentLower 135 122 124960 tail len distinct
  intro p hp
  by_cases h : p=0
  · subst p
    exact packedOctCertificate135_122_0
  · have he : p=1 := hp.resolve_left h
    subst p
    exact packedOctCertificate135_122_1

#print axioms max148_second135_third122_eightPoint_moment_bound

end NineSeparatedSubsetSums
