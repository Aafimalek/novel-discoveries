import NineSeparatedSubsetSums.EightPoint135_126PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint135_126PackedAnchor1Part0 :
    ∀ j : Fin 120, 2331002 ≤ FourPointNumeric.octPackedCharge 135 126 20 packedOct135_126_1
      (2*((j.val : Int)+0)+0) := by decide +kernel

end NineSeparatedSubsetSums
