import NineSeparatedSubsetSums.Adaptive135Third126State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive135Third126Proof0 : runCachedNode 511 126245 Adaptive135Third126Node0 = false := by
  decide +kernel

#print axioms adaptive135Third126Proof0

end NineSeparatedSubsetSums
