import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive135Third115Node0 : CachedSearchNode :=
  ⟨4, 114, computeCenteredMask [148,135,115], 398, 53354⟩
def Adaptive135Third115Node1 : CachedSearchNode := cachedChild Adaptive135Third115Node0 101
def Adaptive135Third115Node2 : CachedSearchNode := cachedChild Adaptive135Third115Node0 103
def Adaptive135Third115Node3 : CachedSearchNode := cachedChild Adaptive135Third115Node0 104
def Adaptive135Third115Node4 : CachedSearchNode := cachedChild Adaptive135Third115Node0 105
def Adaptive135Third115Node5 : CachedSearchNode := cachedChild Adaptive135Third115Node0 106
def Adaptive135Third115Node6 : CachedSearchNode := cachedChild Adaptive135Third115Node0 107
def Adaptive135Third115Node7 : CachedSearchNode := cachedChild Adaptive135Third115Node0 108
def Adaptive135Third115Node8 : CachedSearchNode := cachedChild Adaptive135Third115Node0 109
def Adaptive135Third115Node9 : CachedSearchNode := cachedChild Adaptive135Third115Node0 110
def Adaptive135Third115Node10 : CachedSearchNode := cachedChild Adaptive135Third115Node0 111
def Adaptive135Third115Node11 : CachedSearchNode := cachedChild Adaptive135Third115Node0 112
def Adaptive135Third115Node12 : CachedSearchNode := cachedChild Adaptive135Third115Node0 113
def Adaptive135Third115Node13 : CachedSearchNode := cachedChild Adaptive135Third115Node0 114

end NineSeparatedSubsetSums
