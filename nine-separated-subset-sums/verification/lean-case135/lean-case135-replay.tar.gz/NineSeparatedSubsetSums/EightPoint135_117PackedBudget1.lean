import NineSeparatedSubsetSums.EightPoint135_117PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct135_117_1_budget :
    FourPointNumeric.packedBudget 20 packedOct135_117_1 414 = 81715488 := by decide +kernel

#print axioms packedOct135_117_1_budget

end NineSeparatedSubsetSums
