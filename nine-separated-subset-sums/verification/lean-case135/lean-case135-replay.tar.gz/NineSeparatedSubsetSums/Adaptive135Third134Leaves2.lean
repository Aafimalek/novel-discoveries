import NineSeparatedSubsetSums.Adaptive135Third134State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive135Third134Proof19 : runCachedNode 511 127641 Adaptive135Third134Node19 = false := by
  decide +kernel

#print axioms adaptive135Third134Proof19

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive135Third134Proof18 : runCachedNode 511 127641 Adaptive135Third134Node18 = false := by
  decide +kernel

#print axioms adaptive135Third134Proof18

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive135Third134Proof36 : runCachedNode 511 127641 Adaptive135Third134Node36 = false := by
  decide +kernel

#print axioms adaptive135Third134Proof36

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive135Third134Proof2 : runCachedNode 511 127641 Adaptive135Third134Node2 = false := by
  decide +kernel

#print axioms adaptive135Third134Proof2

end NineSeparatedSubsetSums
