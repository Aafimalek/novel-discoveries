import NineSeparatedSubsetSums.EightPoint135_119PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct135_119_0_budget :
    FourPointNumeric.packedBudget 20 packedOct135_119_0 281 = 84551797 := by decide +kernel

#print axioms packedOct135_119_0_budget

end NineSeparatedSubsetSums
