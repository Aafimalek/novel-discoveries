import NineSeparatedSubsetSums.EightPoint135_131PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct135_131_1_budget :
    FourPointNumeric.packedBudget 20 packedOct135_131_1 454 = 88821748 := by decide +kernel

#print axioms packedOct135_131_1_budget

end NineSeparatedSubsetSums
