import NineSeparatedSubsetSums.Adaptive135Third125State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive135Third125Proof0 : runCachedNode 511 126023 Adaptive135Third125Node0 = false := by
  decide +kernel

#print axioms adaptive135Third125Proof0

end NineSeparatedSubsetSums
