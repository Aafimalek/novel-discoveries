import NineSeparatedSubsetSums.Adaptive135Third134State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive135Third134Proof21 : runCachedNode 511 127641 Adaptive135Third134Node21 = false := by
  decide +kernel

#print axioms adaptive135Third134Proof21

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive135Third134Proof46 : runCachedNode 511 127641 Adaptive135Third134Node46 = false := by
  decide +kernel

#print axioms adaptive135Third134Proof46

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive135Third134Proof27 : runCachedNode 511 127641 Adaptive135Third134Node27 = false := by
  decide +kernel

#print axioms adaptive135Third134Proof27

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive135Third134Proof1 : runCachedNode 511 127641 Adaptive135Third134Node1 = false := by
  decide +kernel

#print axioms adaptive135Third134Proof1

end NineSeparatedSubsetSums
