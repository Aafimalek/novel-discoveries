import NineSeparatedSubsetSums.Adaptive135Third111Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint135Checked

namespace NineSeparatedSubsetSums


theorem adaptive135Third111 : NoDescendingTailAfterThird 135 111 :=
  noDescendingThirdTail_of_cached 135 111 110858 (fun t ht nd => max148_second135_fourPoint_moment_bound (111::t) (by simp [ht]) nd) adaptive135Third111Proof0

#print axioms adaptive135Third111

end NineSeparatedSubsetSums
