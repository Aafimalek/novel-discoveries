import NineSeparatedSubsetSums.Adaptive135Third133State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive135Third133Proof11 : runCachedNode 511 127460 Adaptive135Third133Node11 = false := by
  decide +kernel

#print axioms adaptive135Third133Proof11

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive135Third133Proof13 : runCachedNode 511 127460 Adaptive135Third133Node13 = false := by
  decide +kernel

#print axioms adaptive135Third133Proof13

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive135Third133Proof12 : runCachedNode 511 127460 Adaptive135Third133Node12 = false := by
  decide +kernel

#print axioms adaptive135Third133Proof12

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive135Third133Proof9 : runCachedNode 511 127460 Adaptive135Third133Node9 = false := by
  decide +kernel

#print axioms adaptive135Third133Proof9

end NineSeparatedSubsetSums
