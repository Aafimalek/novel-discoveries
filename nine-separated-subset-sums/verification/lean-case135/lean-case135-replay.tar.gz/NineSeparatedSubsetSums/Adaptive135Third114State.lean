import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive135Third114Node0 : CachedSearchNode :=
  ⟨4, 113, computeCenteredMask [148,135,114], 397, 53125⟩

end NineSeparatedSubsetSums
