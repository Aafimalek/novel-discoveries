import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive135Third107Node0 : CachedSearchNode :=
  ⟨4, 106, computeCenteredMask [148,135,107], 390, 51578⟩

end NineSeparatedSubsetSums
