import NineSeparatedSubsetSums.EightPoint135_123PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct135_123_1_budget :
    FourPointNumeric.packedBudget 20 packedOct135_123_1 406 = 81030164 := by decide +kernel

#print axioms packedOct135_123_1_budget

end NineSeparatedSubsetSums
