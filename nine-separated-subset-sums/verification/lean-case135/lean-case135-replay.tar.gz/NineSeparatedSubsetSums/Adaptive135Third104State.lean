import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive135Third104Node0 : CachedSearchNode :=
  ⟨4, 103, computeCenteredMask [148,135,104], 387, 50945⟩

end NineSeparatedSubsetSums
