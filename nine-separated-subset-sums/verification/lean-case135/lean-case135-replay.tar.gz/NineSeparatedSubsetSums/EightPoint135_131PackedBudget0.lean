import NineSeparatedSubsetSums.EightPoint135_131PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct135_131_0_budget :
    FourPointNumeric.packedBudget 20 packedOct135_131_0 451 = 88803306 := by decide +kernel

#print axioms packedOct135_131_0_budget

end NineSeparatedSubsetSums
