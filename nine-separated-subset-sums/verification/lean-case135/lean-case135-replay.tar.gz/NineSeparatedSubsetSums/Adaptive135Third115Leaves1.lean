import NineSeparatedSubsetSums.Adaptive135Third115State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive135Third115Proof6 : runCachedNode 511 110858 Adaptive135Third115Node6 = false := by
  decide +kernel

#print axioms adaptive135Third115Proof6

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive135Third115Proof5 : runCachedNode 511 110858 Adaptive135Third115Node5 = false := by
  decide +kernel

#print axioms adaptive135Third115Proof5

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive135Third115Proof3 : runCachedNode 511 110858 Adaptive135Third115Node3 = false := by
  decide +kernel

#print axioms adaptive135Third115Proof3

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive135Third115Proof1 : runCachedNode 511 110858 Adaptive135Third115Node1 = false := by
  decide +kernel

#print axioms adaptive135Third115Proof1

end NineSeparatedSubsetSums
