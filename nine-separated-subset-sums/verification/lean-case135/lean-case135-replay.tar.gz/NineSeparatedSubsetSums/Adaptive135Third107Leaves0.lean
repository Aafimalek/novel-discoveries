import NineSeparatedSubsetSums.Adaptive135Third107State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive135Third107Proof0 : runCachedNode 511 110858 Adaptive135Third107Node0 = false := by
  decide +kernel

#print axioms adaptive135Third107Proof0

end NineSeparatedSubsetSums
