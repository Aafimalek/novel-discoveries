import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive135Third113Node0 : CachedSearchNode :=
  ⟨4, 112, computeCenteredMask [148,135,113], 396, 52898⟩

end NineSeparatedSubsetSums
