import NineSeparatedSubsetSums.EightPoint135_124PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint135_124PackedAnchor1Part2 :
    ∀ j : Fin 2, 2305053 ≤ FourPointNumeric.octPackedCharge 135 124 20 packedOct135_124_1
      (2*((j.val : Int)+240)+0) := by decide +kernel

end NineSeparatedSubsetSums
