import NineSeparatedSubsetSums.EightPointPackedGeometry
import NineSeparatedSubsetSums.EightPoint135_127PackedBudget0
import NineSeparatedSubsetSums.EightPoint135_127PackedAnchor0Part0
import NineSeparatedSubsetSums.EightPoint135_127PackedAnchor0Part1
import NineSeparatedSubsetSums.EightPoint135_127PackedAnchor0Part2
import NineSeparatedSubsetSums.EightPoint135_127PackedBudget1
import NineSeparatedSubsetSums.EightPoint135_127PackedAnchor1Part0
import NineSeparatedSubsetSums.EightPoint135_127PackedAnchor1Part1
import NineSeparatedSubsetSums.EightPoint135_127PackedAnchor1Part2

namespace NineSeparatedSubsetSums

private theorem packedOct135_127Anchor0 :
  ∀ j : Fin 487, ((j.val : Int)+135+127)%2=0 →
    2342961 ≤ FourPointNumeric.octPackedCharge 135 127 20 packedOct135_127_0 (j.val : Int) := by
  intro j hj
  let k := (j.val-0)/2
  have hk : k < 244 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+0 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint135_127PackedAnchor0Part0 z
    rwa [he,hrep] at ht
  by_cases h1 : k < 240
  · let z : Fin 120 := ⟨k-120, by omega⟩
    have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
    have ht := eightPoint135_127PackedAnchor0Part1 z
    rwa [he,hrep] at ht
  let z : Fin 4 := ⟨k-240, by omega⟩
  have he : (z.val : Int)+240 = k := by dsimp [z] <;> omega
  have ht := eightPoint135_127PackedAnchor0Part2 z
  rwa [he,hrep] at ht

private theorem packedOct135_127Anchor1 :
  ∀ j : Fin 487, ((j.val : Int)+135+127)%2=1 →
    2343988 ≤ FourPointNumeric.octPackedCharge 135 127 20 packedOct135_127_1 (j.val : Int) := by
  intro j hj
  let k := (j.val-1)/2
  have hk : k < 243 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+1 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint135_127PackedAnchor1Part0 z
    rwa [he,hrep] at ht
  by_cases h1 : k < 240
  · let z : Fin 120 := ⟨k-120, by omega⟩
    have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
    have ht := eightPoint135_127PackedAnchor1Part1 z
    rwa [he,hrep] at ht
  let z : Fin 3 := ⟨k-240, by omega⟩
  have he : (z.val : Int)+240 = k := by dsimp [z] <;> omega
  have ht := eightPoint135_127PackedAnchor1Part2 z
  rwa [he,hrep] at ht

def packedOctCertificate135_127_0 : EightPointCertificate 135 127 0 126471 :=
  eightPointCertificateOfPacked 135 127 0 126471 2342961 20 packedOct135_127_0 501 487
    (by decide +kernel) (by decide) packedOct135_127Anchor0
    (by rw [packedOct135_127_0_budget]; decide)

def packedOctCertificate135_127_1 : EightPointCertificate 135 127 1 126471 :=
  eightPointCertificateOfPacked 135 127 1 126471 2343988 20 packedOct135_127_1 502 487
    (by decide +kernel) (by decide) packedOct135_127Anchor1
    (by rw [packedOct135_127_1_budget]; decide)

theorem max148_second135_third127_eightPoint_moment_bound (tail : List ℕ) (len : tail.length=6)
    (distinct : (natSubsetSums (148::135::127::tail)).Nodup) :
    126471 ≤ ((148::135::127::tail).map (· ^ 2)).sum := by
  apply eightPointNatMomentLower 135 127 126471 tail len distinct
  intro p hp
  by_cases h : p=0
  · subst p
    exact packedOctCertificate135_127_0
  · have he : p=1 := hp.resolve_left h
    subst p
    exact packedOctCertificate135_127_1

#print axioms max148_second135_third127_eightPoint_moment_bound

end NineSeparatedSubsetSums
