import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive135Third127Node0 : CachedSearchNode :=
  ⟨4, 126, computeCenteredMask [148,135,127], 410, 56258⟩
def Adaptive135Third127Node1 : CachedSearchNode := cachedChild Adaptive135Third127Node0 111
def Adaptive135Third127Node2 : CachedSearchNode := cachedChild Adaptive135Third127Node0 112
def Adaptive135Third127Node3 : CachedSearchNode := cachedChild Adaptive135Third127Node0 113
def Adaptive135Third127Node4 : CachedSearchNode := cachedChild Adaptive135Third127Node0 115
def Adaptive135Third127Node5 : CachedSearchNode := cachedChild Adaptive135Third127Node0 116
def Adaptive135Third127Node6 : CachedSearchNode := cachedChild Adaptive135Third127Node0 117
def Adaptive135Third127Node7 : CachedSearchNode := cachedChild Adaptive135Third127Node0 118
def Adaptive135Third127Node8 : CachedSearchNode := cachedChild Adaptive135Third127Node0 119
def Adaptive135Third127Node9 : CachedSearchNode := cachedChild Adaptive135Third127Node0 120
def Adaptive135Third127Node10 : CachedSearchNode := cachedChild Adaptive135Third127Node0 121
def Adaptive135Third127Node11 : CachedSearchNode := cachedChild Adaptive135Third127Node0 122
def Adaptive135Third127Node12 : CachedSearchNode := cachedChild Adaptive135Third127Node0 123
def Adaptive135Third127Node13 : CachedSearchNode := cachedChild Adaptive135Third127Node0 124
def Adaptive135Third127Node14 : CachedSearchNode := cachedChild Adaptive135Third127Node0 125
def Adaptive135Third127Node15 : CachedSearchNode := cachedChild Adaptive135Third127Node0 126

end NineSeparatedSubsetSums
