import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive135Third122Node0 : CachedSearchNode :=
  ⟨4, 121, computeCenteredMask [148,135,122], 405, 55013⟩

end NineSeparatedSubsetSums
