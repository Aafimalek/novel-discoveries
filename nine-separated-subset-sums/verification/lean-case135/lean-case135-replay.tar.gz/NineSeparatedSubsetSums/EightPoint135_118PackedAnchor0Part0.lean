import NineSeparatedSubsetSums.EightPoint135_118PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint135_118PackedAnchor0Part0 :
    ∀ j : Fin 120, 2285440 ≤ FourPointNumeric.octPackedCharge 135 118 20 packedOct135_118_0
      (2*((j.val : Int)+0)+1) := by decide +kernel

end NineSeparatedSubsetSums
