import NineSeparatedSubsetSums.EightPoint135_127PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct135_127_0_budget :
    FourPointNumeric.packedBudget 20 packedOct135_127_0 501 = 85196502 := by decide +kernel

#print axioms packedOct135_127_0_budget

end NineSeparatedSubsetSums
