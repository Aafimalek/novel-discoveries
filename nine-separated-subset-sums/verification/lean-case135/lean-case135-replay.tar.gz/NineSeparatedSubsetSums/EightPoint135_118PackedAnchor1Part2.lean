import NineSeparatedSubsetSums.EightPoint135_118PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint135_118PackedAnchor1Part2 :
    ∀ j : Fin 1, 2285701 ≤ FourPointNumeric.octPackedCharge 135 118 20 packedOct135_118_1
      (2*((j.val : Int)+240)+0) := by decide +kernel

end NineSeparatedSubsetSums
