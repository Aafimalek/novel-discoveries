import NineSeparatedSubsetSums.Adaptive135Third114State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive135Third114Proof0 : runCachedNode 511 110858 Adaptive135Third114Node0 = false := by
  decide +kernel

#print axioms adaptive135Third114Proof0

end NineSeparatedSubsetSums
