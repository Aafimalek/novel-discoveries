import NineSeparatedSubsetSums.EightPoint135_133PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint135_133PackedAnchor0Part0 :
    ∀ j : Fin 120, 2398826 ≤ FourPointNumeric.octPackedCharge 135 133 20 packedOct135_133_0
      (2*((j.val : Int)+0)+0) := by decide +kernel

end NineSeparatedSubsetSums
