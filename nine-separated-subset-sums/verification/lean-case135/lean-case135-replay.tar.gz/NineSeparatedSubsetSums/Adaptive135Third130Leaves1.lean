import NineSeparatedSubsetSums.Adaptive135Third130State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive135Third130Proof15 : runCachedNode 511 126836 Adaptive135Third130Node15 = false := by
  decide +kernel

#print axioms adaptive135Third130Proof15

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive135Third130Proof16 : runCachedNode 511 126836 Adaptive135Third130Node16 = false := by
  decide +kernel

#print axioms adaptive135Third130Proof16

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive135Third130Proof14 : runCachedNode 511 126836 Adaptive135Third130Node14 = false := by
  decide +kernel

#print axioms adaptive135Third130Proof14

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive135Third130Proof13 : runCachedNode 511 126836 Adaptive135Third130Node13 = false := by
  decide +kernel

#print axioms adaptive135Third130Proof13

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive135Third130Proof12 : runCachedNode 511 126836 Adaptive135Third130Node12 = false := by
  decide +kernel

#print axioms adaptive135Third130Proof12

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive135Third130Proof5 : runCachedNode 511 126836 Adaptive135Third130Node5 = false := by
  decide +kernel

#print axioms adaptive135Third130Proof5

end NineSeparatedSubsetSums
