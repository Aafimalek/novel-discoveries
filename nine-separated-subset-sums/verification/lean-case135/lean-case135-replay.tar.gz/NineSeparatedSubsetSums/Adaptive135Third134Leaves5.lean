import NineSeparatedSubsetSums.Adaptive135Third134State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive135Third134Proof42 : runCachedNode 511 127641 Adaptive135Third134Node42 = false := by
  decide +kernel

#print axioms adaptive135Third134Proof42

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive135Third134Proof10 : runCachedNode 511 127641 Adaptive135Third134Node10 = false := by
  decide +kernel

#print axioms adaptive135Third134Proof10

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive135Third134Proof12 : runCachedNode 511 127641 Adaptive135Third134Node12 = false := by
  decide +kernel

#print axioms adaptive135Third134Proof12

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive135Third134Proof39 : runCachedNode 511 127641 Adaptive135Third134Node39 = false := by
  decide +kernel

#print axioms adaptive135Third134Proof39

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive135Third134Proof41 : runCachedNode 511 127641 Adaptive135Third134Node41 = false := by
  decide +kernel

#print axioms adaptive135Third134Proof41

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive135Third134Proof9 : runCachedNode 511 127641 Adaptive135Third134Node9 = false := by
  decide +kernel

#print axioms adaptive135Third134Proof9

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive135Third134Proof40 : runCachedNode 511 127641 Adaptive135Third134Node40 = false := by
  decide +kernel

#print axioms adaptive135Third134Proof40

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive135Third134Proof37 : runCachedNode 511 127641 Adaptive135Third134Node37 = false := by
  decide +kernel

#print axioms adaptive135Third134Proof37

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive135Third134Proof8 : runCachedNode 511 127641 Adaptive135Third134Node8 = false := by
  decide +kernel

#print axioms adaptive135Third134Proof8

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive135Third134Proof7 : runCachedNode 511 127641 Adaptive135Third134Node7 = false := by
  decide +kernel

#print axioms adaptive135Third134Proof7

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive135Third134Proof6 : runCachedNode 511 127641 Adaptive135Third134Node6 = false := by
  decide +kernel

#print axioms adaptive135Third134Proof6

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive135Third134Proof35 : runCachedNode 511 127641 Adaptive135Third134Node35 = false := by
  decide +kernel

#print axioms adaptive135Third134Proof35

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive135Third134Proof30 : runCachedNode 511 127641 Adaptive135Third134Node30 = false := by
  decide +kernel

#print axioms adaptive135Third134Proof30

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive135Third134Proof5 : runCachedNode 511 127641 Adaptive135Third134Node5 = false := by
  decide +kernel

#print axioms adaptive135Third134Proof5

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive135Third134Proof31 : runCachedNode 511 127641 Adaptive135Third134Node31 = false := by
  decide +kernel

#print axioms adaptive135Third134Proof31

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive135Third134Proof34 : runCachedNode 511 127641 Adaptive135Third134Node34 = false := by
  decide +kernel

#print axioms adaptive135Third134Proof34

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive135Third134Proof29 : runCachedNode 511 127641 Adaptive135Third134Node29 = false := by
  decide +kernel

#print axioms adaptive135Third134Proof29

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive135Third134Proof32 : runCachedNode 511 127641 Adaptive135Third134Node32 = false := by
  decide +kernel

#print axioms adaptive135Third134Proof32

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive135Third134Proof33 : runCachedNode 511 127641 Adaptive135Third134Node33 = false := by
  decide +kernel

#print axioms adaptive135Third134Proof33

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive135Third134Proof28 : runCachedNode 511 127641 Adaptive135Third134Node28 = false := by
  decide +kernel

#print axioms adaptive135Third134Proof28

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive135Third134Proof26 : runCachedNode 511 127641 Adaptive135Third134Node26 = false := by
  decide +kernel

#print axioms adaptive135Third134Proof26

end NineSeparatedSubsetSums
