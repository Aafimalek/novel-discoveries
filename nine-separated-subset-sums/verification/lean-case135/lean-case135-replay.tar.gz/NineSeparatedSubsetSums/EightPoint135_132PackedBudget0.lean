import NineSeparatedSubsetSums.EightPoint135_132PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct135_132_0_budget :
    FourPointNumeric.packedBudget 20 packedOct135_132_0 473 = 88710533 := by decide +kernel

#print axioms packedOct135_132_0_budget

end NineSeparatedSubsetSums
