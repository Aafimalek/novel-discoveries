import NineSeparatedSubsetSums.FourPoint135PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem fourPoint135PackedAnchor0Part1 :
    ∀ j : Fin 119, 1073976 ≤ FourPointNumeric.packedCharge 135 20 packedWeight135_0
      (2*((j.val : Int)+120)+1) := by decide +kernel

end NineSeparatedSubsetSums
