import NineSeparatedSubsetSums.Adaptive135Third108State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive135Third108Proof0 : runCachedNode 511 110858 Adaptive135Third108Node0 = false := by
  decide +kernel

#print axioms adaptive135Third108Proof0

end NineSeparatedSubsetSums
