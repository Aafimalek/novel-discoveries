import NineSeparatedSubsetSums.Adaptive135Third130State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive135Third130Proof10 : runCachedNode 511 126836 Adaptive135Third130Node10 = false := by
  decide +kernel

#print axioms adaptive135Third130Proof10

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive135Third130Proof9 : runCachedNode 511 126836 Adaptive135Third130Node9 = false := by
  decide +kernel

#print axioms adaptive135Third130Proof9

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive135Third130Proof7 : runCachedNode 511 126836 Adaptive135Third130Node7 = false := by
  decide +kernel

#print axioms adaptive135Third130Proof7

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive135Third130Proof6 : runCachedNode 511 126836 Adaptive135Third130Node6 = false := by
  decide +kernel

#print axioms adaptive135Third130Proof6

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive135Third130Proof4 : runCachedNode 511 126836 Adaptive135Third130Node4 = false := by
  decide +kernel

#print axioms adaptive135Third130Proof4

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive135Third130Proof3 : runCachedNode 511 126836 Adaptive135Third130Node3 = false := by
  decide +kernel

#print axioms adaptive135Third130Proof3

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive135Third130Proof2 : runCachedNode 511 126836 Adaptive135Third130Node2 = false := by
  decide +kernel

#print axioms adaptive135Third130Proof2

end NineSeparatedSubsetSums
