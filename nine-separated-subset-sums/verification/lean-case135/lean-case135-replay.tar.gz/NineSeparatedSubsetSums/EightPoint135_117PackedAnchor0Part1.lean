import NineSeparatedSubsetSums.EightPoint135_117PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint135_117PackedAnchor0Part1 :
    ∀ j : Fin 120, 2269597 ≤ FourPointNumeric.octPackedCharge 135 117 20 packedOct135_117_0
      (2*((j.val : Int)+120)+0) := by decide +kernel

end NineSeparatedSubsetSums
