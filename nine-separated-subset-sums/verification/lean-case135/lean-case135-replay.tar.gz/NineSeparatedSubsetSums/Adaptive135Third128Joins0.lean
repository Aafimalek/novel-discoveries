import NineSeparatedSubsetSums.Adaptive135Third128State
import NineSeparatedSubsetSums.Adaptive135Third128Leaves1
import NineSeparatedSubsetSums.Adaptive135Third128Leaves0

namespace NineSeparatedSubsetSums

theorem adaptive135Third128Proof0 : runCachedNode 511 126513 Adaptive135Third128Node0 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 126513 Adaptive135Third128Node0 = [111, 112, 113, 114, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive135Third128Proof1
  · exact adaptive135Third128Proof2
  · exact adaptive135Third128Proof3
  · exact adaptive135Third128Proof4
  · exact adaptive135Third128Proof5
  · exact adaptive135Third128Proof6
  · exact adaptive135Third128Proof7
  · exact adaptive135Third128Proof8
  · exact adaptive135Third128Proof9
  · exact adaptive135Third128Proof10
  · exact adaptive135Third128Proof11
  · exact adaptive135Third128Proof12
  · exact adaptive135Third128Proof13
  · exact adaptive135Third128Proof14
  · exact adaptive135Third128Proof15
  · exact adaptive135Third128Proof16

#print axioms adaptive135Third128Proof0

end NineSeparatedSubsetSums
