import NineSeparatedSubsetSums.EightPointPackedGeometry
import NineSeparatedSubsetSums.EightPoint135_117PackedBudget0
import NineSeparatedSubsetSums.EightPoint135_117PackedAnchor0Part0
import NineSeparatedSubsetSums.EightPoint135_117PackedAnchor0Part1
import NineSeparatedSubsetSums.EightPoint135_117PackedBudget1
import NineSeparatedSubsetSums.EightPoint135_117PackedAnchor1Part0
import NineSeparatedSubsetSums.EightPoint135_117PackedAnchor1Part1

namespace NineSeparatedSubsetSums

private theorem packedOct135_117Anchor0 :
  ∀ j : Fin 480, ((j.val : Int)+135+117)%2=0 →
    2269597 ≤ FourPointNumeric.octPackedCharge 135 117 20 packedOct135_117_0 (j.val : Int) := by
  intro j hj
  let k := (j.val-0)/2
  have hk : k < 240 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+0 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint135_117PackedAnchor0Part0 z
    rwa [he,hrep] at ht
  let z : Fin 120 := ⟨k-120, by omega⟩
  have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
  have ht := eightPoint135_117PackedAnchor0Part1 z
  rwa [he,hrep] at ht

private theorem packedOct135_117Anchor1 :
  ∀ j : Fin 480, ((j.val : Int)+135+117)%2=1 →
    2270176 ≤ FourPointNumeric.octPackedCharge 135 117 20 packedOct135_117_1 (j.val : Int) := by
  intro j hj
  let k := (j.val-1)/2
  have hk : k < 240 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+1 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint135_117PackedAnchor1Part0 z
    rwa [he,hrep] at ht
  let z : Fin 120 := ⟨k-120, by omega⟩
  have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
  have ht := eightPoint135_117PackedAnchor1Part1 z
  rwa [he,hrep] at ht

def packedOctCertificate135_117_0 : EightPointCertificate 135 117 0 124172 :=
  eightPointCertificateOfPacked 135 117 0 124172 2269597 20 packedOct135_117_0 413 480
    (by decide +kernel) (by decide) packedOct135_117Anchor0
    (by rw [packedOct135_117_0_budget]; decide)

def packedOctCertificate135_117_1 : EightPointCertificate 135 117 1 124172 :=
  eightPointCertificateOfPacked 135 117 1 124172 2270176 20 packedOct135_117_1 414 480
    (by decide +kernel) (by decide) packedOct135_117Anchor1
    (by rw [packedOct135_117_1_budget]; decide)

theorem max148_second135_third117_eightPoint_moment_bound (tail : List ℕ) (len : tail.length=6)
    (distinct : (natSubsetSums (148::135::117::tail)).Nodup) :
    124172 ≤ ((148::135::117::tail).map (· ^ 2)).sum := by
  apply eightPointNatMomentLower 135 117 124172 tail len distinct
  intro p hp
  by_cases h : p=0
  · subst p
    exact packedOctCertificate135_117_0
  · have he : p=1 := hp.resolve_left h
    subst p
    exact packedOctCertificate135_117_1

#print axioms max148_second135_third117_eightPoint_moment_bound

end NineSeparatedSubsetSums
