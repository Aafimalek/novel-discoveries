import NineSeparatedSubsetSums.Adaptive135Third133State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive135Third133Proof17 : runCachedNode 511 127460 Adaptive135Third133Node17 = false := by
  decide +kernel

#print axioms adaptive135Third133Proof17

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive135Third133Proof16 : runCachedNode 511 127460 Adaptive135Third133Node16 = false := by
  decide +kernel

#print axioms adaptive135Third133Proof16

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive135Third133Proof15 : runCachedNode 511 127460 Adaptive135Third133Node15 = false := by
  decide +kernel

#print axioms adaptive135Third133Proof15

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive135Third133Proof14 : runCachedNode 511 127460 Adaptive135Third133Node14 = false := by
  decide +kernel

#print axioms adaptive135Third133Proof14

end NineSeparatedSubsetSums
