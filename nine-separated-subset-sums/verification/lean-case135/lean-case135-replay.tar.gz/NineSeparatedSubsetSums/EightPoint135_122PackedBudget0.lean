import NineSeparatedSubsetSums.EightPoint135_122PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct135_122_0_budget :
    FourPointNumeric.packedBudget 20 packedOct135_122_0 265 = 81375078 := by decide +kernel

#print axioms packedOct135_122_0_budget

end NineSeparatedSubsetSums
