import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive135Third134Node0 : CachedSearchNode :=
  ⟨4, 133, computeCenteredMask [148,135,134], 417, 58085⟩
def Adaptive135Third134Node1 : CachedSearchNode := cachedChild Adaptive135Third134Node0 111
def Adaptive135Third134Node2 : CachedSearchNode := cachedChild Adaptive135Third134Node0 112
def Adaptive135Third134Node3 : CachedSearchNode := cachedChild Adaptive135Third134Node0 113
def Adaptive135Third134Node4 : CachedSearchNode := cachedChild Adaptive135Third134Node0 114
def Adaptive135Third134Node5 : CachedSearchNode := cachedChild Adaptive135Third134Node0 115
def Adaptive135Third134Node6 : CachedSearchNode := cachedChild Adaptive135Third134Node0 116
def Adaptive135Third134Node7 : CachedSearchNode := cachedChild Adaptive135Third134Node0 117
def Adaptive135Third134Node8 : CachedSearchNode := cachedChild Adaptive135Third134Node0 118
def Adaptive135Third134Node9 : CachedSearchNode := cachedChild Adaptive135Third134Node0 119
def Adaptive135Third134Node10 : CachedSearchNode := cachedChild Adaptive135Third134Node0 120
def Adaptive135Third134Node11 : CachedSearchNode := cachedChild Adaptive135Third134Node0 122
def Adaptive135Third134Node12 : CachedSearchNode := cachedChild Adaptive135Third134Node0 123
def Adaptive135Third134Node13 : CachedSearchNode := cachedChild Adaptive135Third134Node0 124
def Adaptive135Third134Node14 : CachedSearchNode := cachedChild Adaptive135Third134Node0 125
def Adaptive135Third134Node15 : CachedSearchNode := cachedChild Adaptive135Third134Node0 126
def Adaptive135Third134Node16 : CachedSearchNode := cachedChild Adaptive135Third134Node0 127
def Adaptive135Third134Node17 : CachedSearchNode := cachedChild Adaptive135Third134Node0 128
def Adaptive135Third134Node18 : CachedSearchNode := cachedChild Adaptive135Third134Node0 129
def Adaptive135Third134Node19 : CachedSearchNode := cachedChild Adaptive135Third134Node0 130
def Adaptive135Third134Node20 : CachedSearchNode := cachedChild Adaptive135Third134Node0 131
def Adaptive135Third134Node21 : CachedSearchNode := cachedChild Adaptive135Third134Node0 132
def Adaptive135Third134Node22 : CachedSearchNode := cachedChild Adaptive135Third134Node0 133
def Adaptive135Third134Node23 : CachedSearchNode := cachedChild Adaptive135Third134Node22 104
def Adaptive135Third134Node24 : CachedSearchNode := cachedChild Adaptive135Third134Node22 105
def Adaptive135Third134Node25 : CachedSearchNode := cachedChild Adaptive135Third134Node22 106
def Adaptive135Third134Node26 : CachedSearchNode := cachedChild Adaptive135Third134Node22 107
def Adaptive135Third134Node27 : CachedSearchNode := cachedChild Adaptive135Third134Node22 108
def Adaptive135Third134Node28 : CachedSearchNode := cachedChild Adaptive135Third134Node22 109
def Adaptive135Third134Node29 : CachedSearchNode := cachedChild Adaptive135Third134Node22 110
def Adaptive135Third134Node30 : CachedSearchNode := cachedChild Adaptive135Third134Node22 111
def Adaptive135Third134Node31 : CachedSearchNode := cachedChild Adaptive135Third134Node22 112
def Adaptive135Third134Node32 : CachedSearchNode := cachedChild Adaptive135Third134Node22 113
def Adaptive135Third134Node33 : CachedSearchNode := cachedChild Adaptive135Third134Node22 114
def Adaptive135Third134Node34 : CachedSearchNode := cachedChild Adaptive135Third134Node22 115
def Adaptive135Third134Node35 : CachedSearchNode := cachedChild Adaptive135Third134Node22 116
def Adaptive135Third134Node36 : CachedSearchNode := cachedChild Adaptive135Third134Node22 117
def Adaptive135Third134Node37 : CachedSearchNode := cachedChild Adaptive135Third134Node22 118
def Adaptive135Third134Node38 : CachedSearchNode := cachedChild Adaptive135Third134Node22 122
def Adaptive135Third134Node39 : CachedSearchNode := cachedChild Adaptive135Third134Node22 123
def Adaptive135Third134Node40 : CachedSearchNode := cachedChild Adaptive135Third134Node22 124
def Adaptive135Third134Node41 : CachedSearchNode := cachedChild Adaptive135Third134Node22 125
def Adaptive135Third134Node42 : CachedSearchNode := cachedChild Adaptive135Third134Node22 126
def Adaptive135Third134Node43 : CachedSearchNode := cachedChild Adaptive135Third134Node22 127
def Adaptive135Third134Node44 : CachedSearchNode := cachedChild Adaptive135Third134Node22 128
def Adaptive135Third134Node45 : CachedSearchNode := cachedChild Adaptive135Third134Node22 129
def Adaptive135Third134Node46 : CachedSearchNode := cachedChild Adaptive135Third134Node22 130
def Adaptive135Third134Node47 : CachedSearchNode := cachedChild Adaptive135Third134Node22 131

end NineSeparatedSubsetSums
