import NineSeparatedSubsetSums.Adaptive135Third108Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint135Checked

namespace NineSeparatedSubsetSums


theorem adaptive135Third108 : NoDescendingTailAfterThird 135 108 :=
  noDescendingThirdTail_of_cached 135 108 110858 (fun t ht nd => max148_second135_fourPoint_moment_bound (108::t) (by simp [ht]) nd) adaptive135Third108Proof0

#print axioms adaptive135Third108

end NineSeparatedSubsetSums
