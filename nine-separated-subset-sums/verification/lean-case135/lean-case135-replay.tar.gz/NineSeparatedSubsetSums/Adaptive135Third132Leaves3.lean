import NineSeparatedSubsetSums.Adaptive135Third132State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive135Third132Proof13 : runCachedNode 511 127331 Adaptive135Third132Node13 = false := by
  decide +kernel

#print axioms adaptive135Third132Proof13

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive135Third132Proof14 : runCachedNode 511 127331 Adaptive135Third132Node14 = false := by
  decide +kernel

#print axioms adaptive135Third132Proof14

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive135Third132Proof12 : runCachedNode 511 127331 Adaptive135Third132Node12 = false := by
  decide +kernel

#print axioms adaptive135Third132Proof12

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive135Third132Proof10 : runCachedNode 511 127331 Adaptive135Third132Node10 = false := by
  decide +kernel

#print axioms adaptive135Third132Proof10

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive135Third132Proof7 : runCachedNode 511 127331 Adaptive135Third132Node7 = false := by
  decide +kernel

#print axioms adaptive135Third132Proof7

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive135Third132Proof6 : runCachedNode 511 127331 Adaptive135Third132Node6 = false := by
  decide +kernel

#print axioms adaptive135Third132Proof6

end NineSeparatedSubsetSums
