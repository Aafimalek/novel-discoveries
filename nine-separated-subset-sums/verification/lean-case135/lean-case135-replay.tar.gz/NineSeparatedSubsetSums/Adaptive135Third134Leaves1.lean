import NineSeparatedSubsetSums.Adaptive135Third134State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive135Third134Proof20 : runCachedNode 511 127641 Adaptive135Third134Node20 = false := by
  decide +kernel

#print axioms adaptive135Third134Proof20

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive135Third134Proof16 : runCachedNode 511 127641 Adaptive135Third134Node16 = false := by
  decide +kernel

#print axioms adaptive135Third134Proof16

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive135Third134Proof45 : runCachedNode 511 127641 Adaptive135Third134Node45 = false := by
  decide +kernel

#print axioms adaptive135Third134Proof45

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive135Third134Proof25 : runCachedNode 511 127641 Adaptive135Third134Node25 = false := by
  decide +kernel

#print axioms adaptive135Third134Proof25

end NineSeparatedSubsetSums
