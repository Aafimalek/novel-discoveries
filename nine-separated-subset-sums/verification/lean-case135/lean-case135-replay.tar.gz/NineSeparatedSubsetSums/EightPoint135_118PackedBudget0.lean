import NineSeparatedSubsetSums.EightPoint135_118PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct135_118_0_budget :
    FourPointNumeric.packedBudget 20 packedOct135_118_0 467 = 82588655 := by decide +kernel

#print axioms packedOct135_118_0_budget

end NineSeparatedSubsetSums
