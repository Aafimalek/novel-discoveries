import NineSeparatedSubsetSums.Adaptive135Third134State
import NineSeparatedSubsetSums.Adaptive135Third134Leaves3
import NineSeparatedSubsetSums.Adaptive135Third134Leaves1
import NineSeparatedSubsetSums.Adaptive135Third134Leaves5
import NineSeparatedSubsetSums.Adaptive135Third134Leaves0
import NineSeparatedSubsetSums.Adaptive135Third134Leaves2
import NineSeparatedSubsetSums.Adaptive135Third134Leaves4

namespace NineSeparatedSubsetSums

theorem adaptive135Third134Proof22 : runCachedNode 511 127641 Adaptive135Third134Node22 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 127641 Adaptive135Third134Node22 = [104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive135Third134Proof23
  · exact adaptive135Third134Proof24
  · exact adaptive135Third134Proof25
  · exact adaptive135Third134Proof26
  · exact adaptive135Third134Proof27
  · exact adaptive135Third134Proof28
  · exact adaptive135Third134Proof29
  · exact adaptive135Third134Proof30
  · exact adaptive135Third134Proof31
  · exact adaptive135Third134Proof32
  · exact adaptive135Third134Proof33
  · exact adaptive135Third134Proof34
  · exact adaptive135Third134Proof35
  · exact adaptive135Third134Proof36
  · exact adaptive135Third134Proof37
  · exact adaptive135Third134Proof38
  · exact adaptive135Third134Proof39
  · exact adaptive135Third134Proof40
  · exact adaptive135Third134Proof41
  · exact adaptive135Third134Proof42
  · exact adaptive135Third134Proof43
  · exact adaptive135Third134Proof44
  · exact adaptive135Third134Proof45
  · exact adaptive135Third134Proof46
  · exact adaptive135Third134Proof47

#print axioms adaptive135Third134Proof22

theorem adaptive135Third134Proof0 : runCachedNode 511 127641 Adaptive135Third134Node0 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 127641 Adaptive135Third134Node0 = [111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 132, 133] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive135Third134Proof1
  · exact adaptive135Third134Proof2
  · exact adaptive135Third134Proof3
  · exact adaptive135Third134Proof4
  · exact adaptive135Third134Proof5
  · exact adaptive135Third134Proof6
  · exact adaptive135Third134Proof7
  · exact adaptive135Third134Proof8
  · exact adaptive135Third134Proof9
  · exact adaptive135Third134Proof10
  · exact adaptive135Third134Proof11
  · exact adaptive135Third134Proof12
  · exact adaptive135Third134Proof13
  · exact adaptive135Third134Proof14
  · exact adaptive135Third134Proof15
  · exact adaptive135Third134Proof16
  · exact adaptive135Third134Proof17
  · exact adaptive135Third134Proof18
  · exact adaptive135Third134Proof19
  · exact adaptive135Third134Proof20
  · exact adaptive135Third134Proof21
  · exact adaptive135Third134Proof22

#print axioms adaptive135Third134Proof0

end NineSeparatedSubsetSums
