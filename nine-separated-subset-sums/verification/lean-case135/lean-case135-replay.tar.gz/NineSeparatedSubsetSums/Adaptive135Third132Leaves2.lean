import NineSeparatedSubsetSums.Adaptive135Third132State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive135Third132Proof19 : runCachedNode 511 127331 Adaptive135Third132Node19 = false := by
  decide +kernel

#print axioms adaptive135Third132Proof19

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive135Third132Proof15 : runCachedNode 511 127331 Adaptive135Third132Node15 = false := by
  decide +kernel

#print axioms adaptive135Third132Proof15

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive135Third132Proof11 : runCachedNode 511 127331 Adaptive135Third132Node11 = false := by
  decide +kernel

#print axioms adaptive135Third132Proof11

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive135Third132Proof8 : runCachedNode 511 127331 Adaptive135Third132Node8 = false := by
  decide +kernel

#print axioms adaptive135Third132Proof8

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive135Third132Proof3 : runCachedNode 511 127331 Adaptive135Third132Node3 = false := by
  decide +kernel

#print axioms adaptive135Third132Proof3

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive135Third132Proof1 : runCachedNode 511 127331 Adaptive135Third132Node1 = false := by
  decide +kernel

#print axioms adaptive135Third132Proof1

end NineSeparatedSubsetSums
