import NineSeparatedSubsetSums.Adaptive135Third133State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive135Third133Proof21 : runCachedNode 511 127460 Adaptive135Third133Node21 = false := by
  decide +kernel

#print axioms adaptive135Third133Proof21

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive135Third133Proof8 : runCachedNode 511 127460 Adaptive135Third133Node8 = false := by
  decide +kernel

#print axioms adaptive135Third133Proof8

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive135Third133Proof6 : runCachedNode 511 127460 Adaptive135Third133Node6 = false := by
  decide +kernel

#print axioms adaptive135Third133Proof6

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive135Third133Proof5 : runCachedNode 511 127460 Adaptive135Third133Node5 = false := by
  decide +kernel

#print axioms adaptive135Third133Proof5

end NineSeparatedSubsetSums
