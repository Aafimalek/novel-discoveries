import NineSeparatedSubsetSums.EightPoint135_126PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct135_126_1_budget :
    FourPointNumeric.packedBudget 20 packedOct135_126_1 270 = 84547168 := by decide +kernel

#print axioms packedOct135_126_1_budget

end NineSeparatedSubsetSums
