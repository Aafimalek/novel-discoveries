import NineSeparatedSubsetSums.Adaptive135Third114Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint135Checked

namespace NineSeparatedSubsetSums


theorem adaptive135Third114 : NoDescendingTailAfterThird 135 114 :=
  noDescendingThirdTail_of_cached 135 114 110858 (fun t ht nd => max148_second135_fourPoint_moment_bound (114::t) (by simp [ht]) nd) adaptive135Third114Proof0

#print axioms adaptive135Third114

end NineSeparatedSubsetSums
