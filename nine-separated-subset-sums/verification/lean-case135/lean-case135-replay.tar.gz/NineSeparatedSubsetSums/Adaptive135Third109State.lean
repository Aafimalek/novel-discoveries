import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive135Third109Node0 : CachedSearchNode :=
  ⟨4, 108, computeCenteredMask [148,135,109], 392, 52010⟩

end NineSeparatedSubsetSums
