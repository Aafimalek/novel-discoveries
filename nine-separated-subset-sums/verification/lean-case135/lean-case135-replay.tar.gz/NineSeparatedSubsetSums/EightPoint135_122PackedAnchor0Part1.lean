import NineSeparatedSubsetSums.EightPoint135_122PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint135_122PackedAnchor0Part1 :
    ∀ j : Fin 119, 2271173 ≤ FourPointNumeric.octPackedCharge 135 122 20 packedOct135_122_0
      (2*((j.val : Int)+120)+1) := by decide +kernel

end NineSeparatedSubsetSums
