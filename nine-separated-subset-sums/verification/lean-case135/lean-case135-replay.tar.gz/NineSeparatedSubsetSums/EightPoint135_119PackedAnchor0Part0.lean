import NineSeparatedSubsetSums.EightPoint135_119PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint135_119PackedAnchor0Part0 :
    ∀ j : Fin 120, 2318131 ≤ FourPointNumeric.octPackedCharge 135 119 20 packedOct135_119_0
      (2*((j.val : Int)+0)+0) := by decide +kernel

end NineSeparatedSubsetSums
