import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive135Third105Node0 : CachedSearchNode :=
  ⟨4, 104, computeCenteredMask [148,135,105], 388, 51154⟩

end NineSeparatedSubsetSums
