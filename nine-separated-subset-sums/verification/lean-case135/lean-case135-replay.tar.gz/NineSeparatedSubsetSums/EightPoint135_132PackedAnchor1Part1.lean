import NineSeparatedSubsetSums.EightPoint135_132PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint135_132PackedAnchor1Part1 :
    ∀ j : Fin 120, 2404829 ≤ FourPointNumeric.octPackedCharge 135 132 20 packedOct135_132_1
      (2*((j.val : Int)+120)+0) := by decide +kernel

end NineSeparatedSubsetSums
