import NineSeparatedSubsetSums.EightPoint135_134PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint135_134PackedAnchor1Part2 :
    ∀ j : Fin 6, 2398097 ≤ FourPointNumeric.octPackedCharge 135 134 20 packedOct135_134_1
      (2*((j.val : Int)+240)+0) := by decide +kernel

end NineSeparatedSubsetSums
