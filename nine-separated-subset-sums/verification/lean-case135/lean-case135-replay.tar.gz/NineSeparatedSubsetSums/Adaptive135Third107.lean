import NineSeparatedSubsetSums.Adaptive135Third107Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint135Checked

namespace NineSeparatedSubsetSums


theorem adaptive135Third107 : NoDescendingTailAfterThird 135 107 :=
  noDescendingThirdTail_of_cached 135 107 110858 (fun t ht nd => max148_second135_fourPoint_moment_bound (107::t) (by simp [ht]) nd) adaptive135Third107Proof0

#print axioms adaptive135Third107

end NineSeparatedSubsetSums
