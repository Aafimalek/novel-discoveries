import NineSeparatedSubsetSums.Adaptive135Third109Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint135Checked

namespace NineSeparatedSubsetSums


theorem adaptive135Third109 : NoDescendingTailAfterThird 135 109 :=
  noDescendingThirdTail_of_cached 135 109 110858 (fun t ht nd => max148_second135_fourPoint_moment_bound (109::t) (by simp [ht]) nd) adaptive135Third109Proof0

#print axioms adaptive135Third109

end NineSeparatedSubsetSums
