import NineSeparatedSubsetSums.EightPoint135_123PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint135_123PackedAnchor0Part0 :
    ∀ j : Fin 120, 2267461 ≤ FourPointNumeric.octPackedCharge 135 123 20 packedOct135_123_0
      (2*((j.val : Int)+0)+0) := by decide +kernel

end NineSeparatedSubsetSums
