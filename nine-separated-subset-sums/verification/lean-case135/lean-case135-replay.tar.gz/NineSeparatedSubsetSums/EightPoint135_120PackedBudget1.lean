import NineSeparatedSubsetSums.EightPoint135_120PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct135_120_1_budget :
    FourPointNumeric.packedBudget 20 packedOct135_120_1 388 = 85667302 := by decide +kernel

#print axioms packedOct135_120_1_budget

end NineSeparatedSubsetSums
