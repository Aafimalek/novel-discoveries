import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive135Third118Node0 : CachedSearchNode :=
  ⟨4, 117, computeCenteredMask [148,135,118], 401, 54053⟩

end NineSeparatedSubsetSums
