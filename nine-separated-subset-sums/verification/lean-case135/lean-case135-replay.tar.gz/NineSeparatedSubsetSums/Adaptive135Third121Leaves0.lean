import NineSeparatedSubsetSums.Adaptive135Third121State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive135Third121Proof0 : runCachedNode 511 124767 Adaptive135Third121Node0 = false := by
  decide +kernel

#print axioms adaptive135Third121Proof0

end NineSeparatedSubsetSums
