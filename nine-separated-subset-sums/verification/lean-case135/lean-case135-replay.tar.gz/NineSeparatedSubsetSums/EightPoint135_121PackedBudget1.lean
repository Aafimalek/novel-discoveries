import NineSeparatedSubsetSums.EightPoint135_121PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct135_121_1_budget :
    FourPointNumeric.packedBudget 20 packedOct135_121_1 380 = 84938914 := by decide +kernel

#print axioms packedOct135_121_1_budget

end NineSeparatedSubsetSums
