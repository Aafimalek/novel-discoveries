import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive135Third110Node0 : CachedSearchNode :=
  ⟨4, 109, computeCenteredMask [148,135,110], 393, 52229⟩

end NineSeparatedSubsetSums
