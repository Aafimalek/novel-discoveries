import NineSeparatedSubsetSums.Adaptive135Third131State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive135Third131Proof19 : runCachedNode 511 127139 Adaptive135Third131Node19 = false := by
  decide +kernel

#print axioms adaptive135Third131Proof19

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive135Third131Proof18 : runCachedNode 511 127139 Adaptive135Third131Node18 = false := by
  decide +kernel

#print axioms adaptive135Third131Proof18

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive135Third131Proof8 : runCachedNode 511 127139 Adaptive135Third131Node8 = false := by
  decide +kernel

#print axioms adaptive135Third131Proof8

end NineSeparatedSubsetSums
