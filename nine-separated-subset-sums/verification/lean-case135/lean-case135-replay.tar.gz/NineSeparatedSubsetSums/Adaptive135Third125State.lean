import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive135Third125Node0 : CachedSearchNode :=
  ⟨4, 124, computeCenteredMask [148,135,125], 408, 55754⟩

end NineSeparatedSubsetSums
