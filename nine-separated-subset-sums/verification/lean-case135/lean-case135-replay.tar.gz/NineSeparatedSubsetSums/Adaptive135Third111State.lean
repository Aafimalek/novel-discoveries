import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive135Third111Node0 : CachedSearchNode :=
  ⟨4, 110, computeCenteredMask [148,135,111], 394, 52450⟩

end NineSeparatedSubsetSums
