import NineSeparatedSubsetSums.Adaptive135Third132State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive135Third132Proof20 : runCachedNode 511 127331 Adaptive135Third132Node20 = false := by
  decide +kernel

#print axioms adaptive135Third132Proof20

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive135Third132Proof16 : runCachedNode 511 127331 Adaptive135Third132Node16 = false := by
  decide +kernel

#print axioms adaptive135Third132Proof16

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive135Third132Proof9 : runCachedNode 511 127331 Adaptive135Third132Node9 = false := by
  decide +kernel

#print axioms adaptive135Third132Proof9

end NineSeparatedSubsetSums
