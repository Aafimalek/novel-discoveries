import NineSeparatedSubsetSums.EightPoint135_128PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint135_128PackedAnchor0Part2 :
    ∀ j : Fin 2, 2325095 ≤ FourPointNumeric.octPackedCharge 135 128 20 packedOct135_128_0
      (2*((j.val : Int)+240)+1) := by decide +kernel

end NineSeparatedSubsetSums
