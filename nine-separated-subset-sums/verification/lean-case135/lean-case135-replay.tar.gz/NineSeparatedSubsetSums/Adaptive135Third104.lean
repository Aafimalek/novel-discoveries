import NineSeparatedSubsetSums.Adaptive135Third104Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint135Checked

namespace NineSeparatedSubsetSums


theorem adaptive135Third104 : NoDescendingTailAfterThird 135 104 :=
  noDescendingThirdTail_of_cached 135 104 110858 (fun t ht nd => max148_second135_fourPoint_moment_bound (104::t) (by simp [ht]) nd) adaptive135Third104Proof0

#print axioms adaptive135Third104

end NineSeparatedSubsetSums
