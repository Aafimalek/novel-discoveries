import NineSeparatedSubsetSums.Adaptive135Third129State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive135Third129Proof16 : runCachedNode 511 126531 Adaptive135Third129Node16 = false := by
  decide +kernel

#print axioms adaptive135Third129Proof16

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive135Third129Proof17 : runCachedNode 511 126531 Adaptive135Third129Node17 = false := by
  decide +kernel

#print axioms adaptive135Third129Proof17

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive135Third129Proof15 : runCachedNode 511 126531 Adaptive135Third129Node15 = false := by
  decide +kernel

#print axioms adaptive135Third129Proof15

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive135Third129Proof13 : runCachedNode 511 126531 Adaptive135Third129Node13 = false := by
  decide +kernel

#print axioms adaptive135Third129Proof13

end NineSeparatedSubsetSums
