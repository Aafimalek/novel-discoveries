import NineSeparatedSubsetSums.Adaptive135Third134State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive135Third134Proof47 : runCachedNode 511 127641 Adaptive135Third134Node47 = false := by
  decide +kernel

#print axioms adaptive135Third134Proof47

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive135Third134Proof17 : runCachedNode 511 127641 Adaptive135Third134Node17 = false := by
  decide +kernel

#print axioms adaptive135Third134Proof17

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive135Third134Proof38 : runCachedNode 511 127641 Adaptive135Third134Node38 = false := by
  decide +kernel

#print axioms adaptive135Third134Proof38

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive135Third134Proof3 : runCachedNode 511 127641 Adaptive135Third134Node3 = false := by
  decide +kernel

#print axioms adaptive135Third134Proof3

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive135Third134Proof23 : runCachedNode 511 127641 Adaptive135Third134Node23 = false := by
  decide +kernel

#print axioms adaptive135Third134Proof23

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive135Third134Proof24 : runCachedNode 511 127641 Adaptive135Third134Node24 = false := by
  decide +kernel

#print axioms adaptive135Third134Proof24

end NineSeparatedSubsetSums
