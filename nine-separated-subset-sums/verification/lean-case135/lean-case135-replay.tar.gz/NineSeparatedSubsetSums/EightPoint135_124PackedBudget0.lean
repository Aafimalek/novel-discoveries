import NineSeparatedSubsetSums.EightPoint135_124PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct135_124_0_budget :
    FourPointNumeric.packedBudget 20 packedOct135_124_0 385 = 83199568 := by decide +kernel

#print axioms packedOct135_124_0_budget

end NineSeparatedSubsetSums
