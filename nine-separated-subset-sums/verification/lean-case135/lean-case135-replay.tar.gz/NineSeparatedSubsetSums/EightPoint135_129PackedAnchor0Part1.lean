import NineSeparatedSubsetSums.EightPoint135_129PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint135_129PackedAnchor0Part1 :
    ∀ j : Fin 120, 2358472 ≤ FourPointNumeric.octPackedCharge 135 129 20 packedOct135_129_0
      (2*((j.val : Int)+120)+0) := by decide +kernel

end NineSeparatedSubsetSums
