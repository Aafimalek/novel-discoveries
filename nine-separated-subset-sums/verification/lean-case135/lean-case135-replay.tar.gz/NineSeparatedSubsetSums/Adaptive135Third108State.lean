import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive135Third108Node0 : CachedSearchNode :=
  ⟨4, 107, computeCenteredMask [148,135,108], 391, 51793⟩

end NineSeparatedSubsetSums
