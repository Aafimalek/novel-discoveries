import NineSeparatedSubsetSums.EightPoint135_131PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint135_131PackedAnchor1Part1 :
    ∀ j : Fin 120, 2404948 ≤ FourPointNumeric.octPackedCharge 135 131 20 packedOct135_131_1
      (2*((j.val : Int)+120)+1) := by decide +kernel

end NineSeparatedSubsetSums
