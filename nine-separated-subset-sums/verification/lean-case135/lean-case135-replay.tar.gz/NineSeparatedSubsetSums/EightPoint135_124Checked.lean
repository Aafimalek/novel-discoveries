import NineSeparatedSubsetSums.EightPointPackedGeometry
import NineSeparatedSubsetSums.EightPoint135_124PackedBudget0
import NineSeparatedSubsetSums.EightPoint135_124PackedAnchor0Part0
import NineSeparatedSubsetSums.EightPoint135_124PackedAnchor0Part1
import NineSeparatedSubsetSums.EightPoint135_124PackedAnchor0Part2
import NineSeparatedSubsetSums.EightPoint135_124PackedBudget1
import NineSeparatedSubsetSums.EightPoint135_124PackedAnchor1Part0
import NineSeparatedSubsetSums.EightPoint135_124PackedAnchor1Part1
import NineSeparatedSubsetSums.EightPoint135_124PackedAnchor1Part2

namespace NineSeparatedSubsetSums

private theorem packedOct135_124Anchor0 :
  ∀ j : Fin 483, ((j.val : Int)+135+124)%2=0 →
    2305143 ≤ FourPointNumeric.octPackedCharge 135 124 20 packedOct135_124_0 (j.val : Int) := by
  intro j hj
  let k := (j.val-1)/2
  have hk : k < 241 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+1 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint135_124PackedAnchor0Part0 z
    rwa [he,hrep] at ht
  by_cases h1 : k < 240
  · let z : Fin 120 := ⟨k-120, by omega⟩
    have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
    have ht := eightPoint135_124PackedAnchor0Part1 z
    rwa [he,hrep] at ht
  let z : Fin 1 := ⟨k-240, by omega⟩
  have he : (z.val : Int)+240 = k := by dsimp [z] <;> omega
  have ht := eightPoint135_124PackedAnchor0Part2 z
  rwa [he,hrep] at ht

private theorem packedOct135_124Anchor1 :
  ∀ j : Fin 483, ((j.val : Int)+135+124)%2=1 →
    2305053 ≤ FourPointNumeric.octPackedCharge 135 124 20 packedOct135_124_1 (j.val : Int) := by
  intro j hj
  let k := (j.val-0)/2
  have hk : k < 242 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+0 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint135_124PackedAnchor1Part0 z
    rwa [he,hrep] at ht
  by_cases h1 : k < 240
  · let z : Fin 120 := ⟨k-120, by omega⟩
    have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
    have ht := eightPoint135_124PackedAnchor1Part1 z
    rwa [he,hrep] at ht
  let z : Fin 2 := ⟨k-240, by omega⟩
  have he : (z.val : Int)+240 = k := by dsimp [z] <;> omega
  have ht := eightPoint135_124PackedAnchor1Part2 z
  rwa [he,hrep] at ht

def packedOctCertificate135_124_0 : EightPointCertificate 135 124 0 125644 :=
  eightPointCertificateOfPacked 135 124 0 125644 2305143 20 packedOct135_124_0 385 483
    (by decide +kernel) (by decide) packedOct135_124Anchor0
    (by rw [packedOct135_124_0_budget]; decide)

def packedOctCertificate135_124_1 : EightPointCertificate 135 124 1 125644 :=
  eightPointCertificateOfPacked 135 124 1 125644 2305053 20 packedOct135_124_1 386 483
    (by decide +kernel) (by decide) packedOct135_124Anchor1
    (by rw [packedOct135_124_1_budget]; decide)

theorem max148_second135_third124_eightPoint_moment_bound (tail : List ℕ) (len : tail.length=6)
    (distinct : (natSubsetSums (148::135::124::tail)).Nodup) :
    125644 ≤ ((148::135::124::tail).map (· ^ 2)).sum := by
  apply eightPointNatMomentLower 135 124 125644 tail len distinct
  intro p hp
  by_cases h : p=0
  · subst p
    exact packedOctCertificate135_124_0
  · have he : p=1 := hp.resolve_left h
    subst p
    exact packedOctCertificate135_124_1

#print axioms max148_second135_third124_eightPoint_moment_bound

end NineSeparatedSubsetSums
