import NineSeparatedSubsetSums.FourPoint135PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem fourPoint135PackedAnchor1Part1 :
    ∀ j : Fin 119, 1073924 ≤ FourPointNumeric.packedCharge 135 20 packedWeight135_1
      (2*((j.val : Int)+120)+0) := by decide +kernel

end NineSeparatedSubsetSums
