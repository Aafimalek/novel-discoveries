import NineSeparatedSubsetSums.EightPoint135_122PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint135_122PackedAnchor0Part0 :
    ∀ j : Fin 120, 2271173 ≤ FourPointNumeric.octPackedCharge 135 122 20 packedOct135_122_0
      (2*((j.val : Int)+0)+1) := by decide +kernel

end NineSeparatedSubsetSums
