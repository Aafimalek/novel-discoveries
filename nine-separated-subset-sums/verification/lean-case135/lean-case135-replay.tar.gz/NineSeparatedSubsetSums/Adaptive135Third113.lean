import NineSeparatedSubsetSums.Adaptive135Third113Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint135Checked

namespace NineSeparatedSubsetSums


theorem adaptive135Third113 : NoDescendingTailAfterThird 135 113 :=
  noDescendingThirdTail_of_cached 135 113 110858 (fun t ht nd => max148_second135_fourPoint_moment_bound (113::t) (by simp [ht]) nd) adaptive135Third113Proof0

#print axioms adaptive135Third113

end NineSeparatedSubsetSums
