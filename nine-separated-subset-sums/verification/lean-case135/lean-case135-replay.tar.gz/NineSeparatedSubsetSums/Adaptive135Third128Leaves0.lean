import NineSeparatedSubsetSums.Adaptive135Third128State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive135Third128Proof16 : runCachedNode 511 126513 Adaptive135Third128Node16 = false := by
  decide +kernel

#print axioms adaptive135Third128Proof16

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive135Third128Proof15 : runCachedNode 511 126513 Adaptive135Third128Node15 = false := by
  decide +kernel

#print axioms adaptive135Third128Proof15

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive135Third128Proof14 : runCachedNode 511 126513 Adaptive135Third128Node14 = false := by
  decide +kernel

#print axioms adaptive135Third128Proof14

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive135Third128Proof11 : runCachedNode 511 126513 Adaptive135Third128Node11 = false := by
  decide +kernel

#print axioms adaptive135Third128Proof11

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive135Third128Proof10 : runCachedNode 511 126513 Adaptive135Third128Node10 = false := by
  decide +kernel

#print axioms adaptive135Third128Proof10

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive135Third128Proof6 : runCachedNode 511 126513 Adaptive135Third128Node6 = false := by
  decide +kernel

#print axioms adaptive135Third128Proof6

end NineSeparatedSubsetSums
