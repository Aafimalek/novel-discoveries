import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive135Third120Node0 : CachedSearchNode :=
  ⟨4, 119, computeCenteredMask [148,135,120], 403, 54529⟩

end NineSeparatedSubsetSums
