import NineSeparatedSubsetSums.Adaptive135Third133State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive135Third133Proof20 : runCachedNode 511 127460 Adaptive135Third133Node20 = false := by
  decide +kernel

#print axioms adaptive135Third133Proof20

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive135Third133Proof7 : runCachedNode 511 127460 Adaptive135Third133Node7 = false := by
  decide +kernel

#print axioms adaptive135Third133Proof7

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive135Third133Proof4 : runCachedNode 511 127460 Adaptive135Third133Node4 = false := by
  decide +kernel

#print axioms adaptive135Third133Proof4

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive135Third133Proof2 : runCachedNode 511 127460 Adaptive135Third133Node2 = false := by
  decide +kernel

#print axioms adaptive135Third133Proof2

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive135Third133Proof1 : runCachedNode 511 127460 Adaptive135Third133Node1 = false := by
  decide +kernel

#print axioms adaptive135Third133Proof1

end NineSeparatedSubsetSums
