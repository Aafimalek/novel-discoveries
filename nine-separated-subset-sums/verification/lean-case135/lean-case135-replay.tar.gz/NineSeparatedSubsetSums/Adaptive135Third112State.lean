import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive135Third112Node0 : CachedSearchNode :=
  ⟨4, 111, computeCenteredMask [148,135,112], 395, 52673⟩

end NineSeparatedSubsetSums
