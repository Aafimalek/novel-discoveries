import NineSeparatedSubsetSums.EightPoint135_130PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint135_130PackedAnchor1Part1 :
    ∀ j : Fin 120, 2388643 ≤ FourPointNumeric.octPackedCharge 135 130 20 packedOct135_130_1
      (2*((j.val : Int)+120)+0) := by decide +kernel

end NineSeparatedSubsetSums
