import NineSeparatedSubsetSums.Adaptive135Third116State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive135Third116Proof14 : runCachedNode 511 110858 Adaptive135Third116Node14 = false := by
  decide +kernel

#print axioms adaptive135Third116Proof14

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive135Third116Proof13 : runCachedNode 511 110858 Adaptive135Third116Node13 = false := by
  decide +kernel

#print axioms adaptive135Third116Proof13

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive135Third116Proof12 : runCachedNode 511 110858 Adaptive135Third116Node12 = false := by
  decide +kernel

#print axioms adaptive135Third116Proof12

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive135Third116Proof11 : runCachedNode 511 110858 Adaptive135Third116Node11 = false := by
  decide +kernel

#print axioms adaptive135Third116Proof11

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive135Third116Proof5 : runCachedNode 511 110858 Adaptive135Third116Node5 = false := by
  decide +kernel

#print axioms adaptive135Third116Proof5

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive135Third116Proof2 : runCachedNode 511 110858 Adaptive135Third116Node2 = false := by
  decide +kernel

#print axioms adaptive135Third116Proof2

end NineSeparatedSubsetSums
