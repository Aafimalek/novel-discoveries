import NineSeparatedSubsetSums.Adaptive135Third133State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive135Third133Proof19 : runCachedNode 511 127460 Adaptive135Third133Node19 = false := by
  decide +kernel

#print axioms adaptive135Third133Proof19

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive135Third133Proof18 : runCachedNode 511 127460 Adaptive135Third133Node18 = false := by
  decide +kernel

#print axioms adaptive135Third133Proof18

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive135Third133Proof10 : runCachedNode 511 127460 Adaptive135Third133Node10 = false := by
  decide +kernel

#print axioms adaptive135Third133Proof10

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive135Third133Proof3 : runCachedNode 511 127460 Adaptive135Third133Node3 = false := by
  decide +kernel

#print axioms adaptive135Third133Proof3

end NineSeparatedSubsetSums
