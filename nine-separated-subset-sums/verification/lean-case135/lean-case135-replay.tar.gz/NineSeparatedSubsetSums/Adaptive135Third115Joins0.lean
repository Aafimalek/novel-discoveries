import NineSeparatedSubsetSums.Adaptive135Third115State
import NineSeparatedSubsetSums.Adaptive135Third115Leaves1
import NineSeparatedSubsetSums.Adaptive135Third115Leaves0

namespace NineSeparatedSubsetSums

theorem adaptive135Third115Proof0 : runCachedNode 511 110858 Adaptive135Third115Node0 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 110858 Adaptive135Third115Node0 = [101, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive135Third115Proof1
  · exact adaptive135Third115Proof2
  · exact adaptive135Third115Proof3
  · exact adaptive135Third115Proof4
  · exact adaptive135Third115Proof5
  · exact adaptive135Third115Proof6
  · exact adaptive135Third115Proof7
  · exact adaptive135Third115Proof8
  · exact adaptive135Third115Proof9
  · exact adaptive135Third115Proof10
  · exact adaptive135Third115Proof11
  · exact adaptive135Third115Proof12
  · exact adaptive135Third115Proof13

#print axioms adaptive135Third115Proof0

end NineSeparatedSubsetSums
