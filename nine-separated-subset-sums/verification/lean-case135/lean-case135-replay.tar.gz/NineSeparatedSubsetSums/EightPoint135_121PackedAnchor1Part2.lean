import NineSeparatedSubsetSums.EightPoint135_121PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint135_121PackedAnchor1Part2 :
    ∀ j : Fin 3, 2325306 ≤ FourPointNumeric.octPackedCharge 135 121 20 packedOct135_121_1
      (2*((j.val : Int)+240)+1) := by decide +kernel

end NineSeparatedSubsetSums
