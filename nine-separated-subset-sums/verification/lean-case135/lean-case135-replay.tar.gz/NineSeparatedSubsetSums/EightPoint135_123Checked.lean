import NineSeparatedSubsetSums.EightPointPackedGeometry
import NineSeparatedSubsetSums.EightPoint135_123PackedBudget0
import NineSeparatedSubsetSums.EightPoint135_123PackedAnchor0Part0
import NineSeparatedSubsetSums.EightPoint135_123PackedAnchor0Part1
import NineSeparatedSubsetSums.EightPoint135_123PackedBudget1
import NineSeparatedSubsetSums.EightPoint135_123PackedAnchor1Part0
import NineSeparatedSubsetSums.EightPoint135_123PackedAnchor1Part1

namespace NineSeparatedSubsetSums

private theorem packedOct135_123Anchor0 :
  ∀ j : Fin 478, ((j.val : Int)+135+123)%2=0 →
    2267461 ≤ FourPointNumeric.octPackedCharge 135 123 20 packedOct135_123_0 (j.val : Int) := by
  intro j hj
  let k := (j.val-0)/2
  have hk : k < 239 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+0 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint135_123PackedAnchor0Part0 z
    rwa [he,hrep] at ht
  let z : Fin 119 := ⟨k-120, by omega⟩
  have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
  have ht := eightPoint135_123PackedAnchor0Part1 z
  rwa [he,hrep] at ht

private theorem packedOct135_123Anchor1 :
  ∀ j : Fin 478, ((j.val : Int)+135+123)%2=1 →
    2268184 ≤ FourPointNumeric.octPackedCharge 135 123 20 packedOct135_123_1 (j.val : Int) := by
  intro j hj
  let k := (j.val-1)/2
  have hk : k < 239 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+1 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint135_123PackedAnchor1Part0 z
    rwa [he,hrep] at ht
  let z : Fin 119 := ⟨k-120, by omega⟩
  have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
  have ht := eightPoint135_123PackedAnchor1Part1 z
  rwa [he,hrep] at ht

def packedOctCertificate135_123_0 : EightPointCertificate 135 123 0 125261 :=
  eightPointCertificateOfPacked 135 123 0 125261 2267461 20 packedOct135_123_0 405 478
    (by decide +kernel) (by decide) packedOct135_123Anchor0
    (by rw [packedOct135_123_0_budget]; decide)

def packedOctCertificate135_123_1 : EightPointCertificate 135 123 1 125261 :=
  eightPointCertificateOfPacked 135 123 1 125261 2268184 20 packedOct135_123_1 406 478
    (by decide +kernel) (by decide) packedOct135_123Anchor1
    (by rw [packedOct135_123_1_budget]; decide)

theorem max148_second135_third123_eightPoint_moment_bound (tail : List ℕ) (len : tail.length=6)
    (distinct : (natSubsetSums (148::135::123::tail)).Nodup) :
    125261 ≤ ((148::135::123::tail).map (· ^ 2)).sum := by
  apply eightPointNatMomentLower 135 123 125261 tail len distinct
  intro p hp
  by_cases h : p=0
  · subst p
    exact packedOctCertificate135_123_0
  · have he : p=1 := hp.resolve_left h
    subst p
    exact packedOctCertificate135_123_1

#print axioms max148_second135_third123_eightPoint_moment_bound

end NineSeparatedSubsetSums
