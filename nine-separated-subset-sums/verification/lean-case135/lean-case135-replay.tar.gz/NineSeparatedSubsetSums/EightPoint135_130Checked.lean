import NineSeparatedSubsetSums.EightPointPackedGeometry
import NineSeparatedSubsetSums.EightPoint135_130PackedBudget0
import NineSeparatedSubsetSums.EightPoint135_130PackedAnchor0Part0
import NineSeparatedSubsetSums.EightPoint135_130PackedAnchor0Part1
import NineSeparatedSubsetSums.EightPoint135_130PackedAnchor0Part2
import NineSeparatedSubsetSums.EightPoint135_130PackedBudget1
import NineSeparatedSubsetSums.EightPoint135_130PackedAnchor1Part0
import NineSeparatedSubsetSums.EightPoint135_130PackedAnchor1Part1
import NineSeparatedSubsetSums.EightPoint135_130PackedAnchor1Part2

namespace NineSeparatedSubsetSums

private theorem packedOct135_130Anchor0 :
  ∀ j : Fin 492, ((j.val : Int)+135+130)%2=0 →
    2387338 ≤ FourPointNumeric.octPackedCharge 135 130 20 packedOct135_130_0 (j.val : Int) := by
  intro j hj
  let k := (j.val-1)/2
  have hk : k < 246 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+1 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint135_130PackedAnchor0Part0 z
    rwa [he,hrep] at ht
  by_cases h1 : k < 240
  · let z : Fin 120 := ⟨k-120, by omega⟩
    have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
    have ht := eightPoint135_130PackedAnchor0Part1 z
    rwa [he,hrep] at ht
  let z : Fin 6 := ⟨k-240, by omega⟩
  have he : (z.val : Int)+240 = k := by dsimp [z] <;> omega
  have ht := eightPoint135_130PackedAnchor0Part2 z
  rwa [he,hrep] at ht

private theorem packedOct135_130Anchor1 :
  ∀ j : Fin 492, ((j.val : Int)+135+130)%2=1 →
    2388643 ≤ FourPointNumeric.octPackedCharge 135 130 20 packedOct135_130_1 (j.val : Int) := by
  intro j hj
  let k := (j.val-0)/2
  have hk : k < 246 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+0 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint135_130PackedAnchor1Part0 z
    rwa [he,hrep] at ht
  by_cases h1 : k < 240
  · let z : Fin 120 := ⟨k-120, by omega⟩
    have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
    have ht := eightPoint135_130PackedAnchor1Part1 z
    rwa [he,hrep] at ht
  let z : Fin 6 := ⟨k-240, by omega⟩
  have he : (z.val : Int)+240 = k := by dsimp [z] <;> omega
  have ht := eightPoint135_130PackedAnchor1Part2 z
  rwa [he,hrep] at ht

def packedOctCertificate135_130_0 : EightPointCertificate 135 130 0 126836 :=
  eightPointCertificateOfPacked 135 130 0 126836 2387338 20 packedOct135_130_0 443 492
    (by decide +kernel) (by decide) packedOct135_130Anchor0
    (by rw [packedOct135_130_0_budget]; decide)

def packedOctCertificate135_130_1 : EightPointCertificate 135 130 1 126836 :=
  eightPointCertificateOfPacked 135 130 1 126836 2388643 20 packedOct135_130_1 442 492
    (by decide +kernel) (by decide) packedOct135_130Anchor1
    (by rw [packedOct135_130_1_budget]; decide)

theorem max148_second135_third130_eightPoint_moment_bound (tail : List ℕ) (len : tail.length=6)
    (distinct : (natSubsetSums (148::135::130::tail)).Nodup) :
    126836 ≤ ((148::135::130::tail).map (· ^ 2)).sum := by
  apply eightPointNatMomentLower 135 130 126836 tail len distinct
  intro p hp
  by_cases h : p=0
  · subst p
    exact packedOctCertificate135_130_0
  · have he : p=1 := hp.resolve_left h
    subst p
    exact packedOctCertificate135_130_1

#print axioms max148_second135_third130_eightPoint_moment_bound

end NineSeparatedSubsetSums
