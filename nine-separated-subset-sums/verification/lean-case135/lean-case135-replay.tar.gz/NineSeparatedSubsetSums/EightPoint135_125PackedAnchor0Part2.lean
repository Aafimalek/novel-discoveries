import NineSeparatedSubsetSums.EightPoint135_125PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint135_125PackedAnchor0Part2 :
    ∀ j : Fin 1, 2303598 ≤ FourPointNumeric.octPackedCharge 135 125 20 packedOct135_125_0
      (2*((j.val : Int)+240)+0) := by decide +kernel

end NineSeparatedSubsetSums
