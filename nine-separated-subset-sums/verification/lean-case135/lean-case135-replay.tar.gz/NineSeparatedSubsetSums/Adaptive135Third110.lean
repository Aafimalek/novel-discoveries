import NineSeparatedSubsetSums.Adaptive135Third110Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint135Checked

namespace NineSeparatedSubsetSums


theorem adaptive135Third110 : NoDescendingTailAfterThird 135 110 :=
  noDescendingThirdTail_of_cached 135 110 110858 (fun t ht nd => max148_second135_fourPoint_moment_bound (110::t) (by simp [ht]) nd) adaptive135Third110Proof0

#print axioms adaptive135Third110

end NineSeparatedSubsetSums
