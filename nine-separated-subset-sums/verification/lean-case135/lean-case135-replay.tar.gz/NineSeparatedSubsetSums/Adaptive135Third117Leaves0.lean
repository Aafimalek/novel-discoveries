import NineSeparatedSubsetSums.Adaptive135Third117State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive135Third117Proof0 : runCachedNode 511 124172 Adaptive135Third117Node0 = false := by
  decide +kernel

#print axioms adaptive135Third117Proof0

end NineSeparatedSubsetSums
