import NineSeparatedSubsetSums.EightPoint135_132PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct135_132_1_budget :
    FourPointNumeric.packedBudget 20 packedOct135_132_1 474 = 88715730 := by decide +kernel

#print axioms packedOct135_132_1_budget

end NineSeparatedSubsetSums
