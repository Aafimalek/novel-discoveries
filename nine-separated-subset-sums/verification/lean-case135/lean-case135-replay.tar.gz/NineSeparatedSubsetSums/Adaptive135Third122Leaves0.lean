import NineSeparatedSubsetSums.Adaptive135Third122State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive135Third122Proof0 : runCachedNode 511 124960 Adaptive135Third122Node0 = false := by
  decide +kernel

#print axioms adaptive135Third122Proof0

end NineSeparatedSubsetSums
