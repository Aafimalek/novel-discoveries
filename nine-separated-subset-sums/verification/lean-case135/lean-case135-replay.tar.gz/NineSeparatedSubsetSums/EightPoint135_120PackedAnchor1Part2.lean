import NineSeparatedSubsetSums.EightPoint135_120PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint135_120PackedAnchor1Part2 :
    ∀ j : Fin 4, 2335764 ≤ FourPointNumeric.octPackedCharge 135 120 20 packedOct135_120_1
      (2*((j.val : Int)+240)+0) := by decide +kernel

end NineSeparatedSubsetSums
