import NineSeparatedSubsetSums.Adaptive135Third130State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive135Third130Proof18 : runCachedNode 511 126836 Adaptive135Third130Node18 = false := by
  decide +kernel

#print axioms adaptive135Third130Proof18

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive135Third130Proof17 : runCachedNode 511 126836 Adaptive135Third130Node17 = false := by
  decide +kernel

#print axioms adaptive135Third130Proof17

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive135Third130Proof11 : runCachedNode 511 126836 Adaptive135Third130Node11 = false := by
  decide +kernel

#print axioms adaptive135Third130Proof11

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive135Third130Proof8 : runCachedNode 511 126836 Adaptive135Third130Node8 = false := by
  decide +kernel

#print axioms adaptive135Third130Proof8

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive135Third130Proof1 : runCachedNode 511 126836 Adaptive135Third130Node1 = false := by
  decide +kernel

#print axioms adaptive135Third130Proof1

end NineSeparatedSubsetSums
