import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive135Third129Node0 : CachedSearchNode :=
  ⟨4, 128, computeCenteredMask [148,135,129], 412, 56770⟩
def Adaptive135Third129Node1 : CachedSearchNode := cachedChild Adaptive135Third129Node0 111
def Adaptive135Third129Node2 : CachedSearchNode := cachedChild Adaptive135Third129Node0 112
def Adaptive135Third129Node3 : CachedSearchNode := cachedChild Adaptive135Third129Node0 113
def Adaptive135Third129Node4 : CachedSearchNode := cachedChild Adaptive135Third129Node0 114
def Adaptive135Third129Node5 : CachedSearchNode := cachedChild Adaptive135Third129Node0 115
def Adaptive135Third129Node6 : CachedSearchNode := cachedChild Adaptive135Third129Node0 117
def Adaptive135Third129Node7 : CachedSearchNode := cachedChild Adaptive135Third129Node0 118
def Adaptive135Third129Node8 : CachedSearchNode := cachedChild Adaptive135Third129Node0 119
def Adaptive135Third129Node9 : CachedSearchNode := cachedChild Adaptive135Third129Node0 120
def Adaptive135Third129Node10 : CachedSearchNode := cachedChild Adaptive135Third129Node0 121
def Adaptive135Third129Node11 : CachedSearchNode := cachedChild Adaptive135Third129Node0 122
def Adaptive135Third129Node12 : CachedSearchNode := cachedChild Adaptive135Third129Node0 123
def Adaptive135Third129Node13 : CachedSearchNode := cachedChild Adaptive135Third129Node0 124
def Adaptive135Third129Node14 : CachedSearchNode := cachedChild Adaptive135Third129Node0 125
def Adaptive135Third129Node15 : CachedSearchNode := cachedChild Adaptive135Third129Node0 126
def Adaptive135Third129Node16 : CachedSearchNode := cachedChild Adaptive135Third129Node0 127
def Adaptive135Third129Node17 : CachedSearchNode := cachedChild Adaptive135Third129Node0 128

end NineSeparatedSubsetSums
