import NineSeparatedSubsetSums.Adaptive132Third127State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive132Third127Proof4 : runCachedNode 511 125773 Adaptive132Third127Node4 = false := by
  decide +kernel

#print axioms adaptive132Third127Proof4

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive132Third127Proof3 : runCachedNode 511 125773 Adaptive132Third127Node3 = false := by
  decide +kernel

#print axioms adaptive132Third127Proof3

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive132Third127Proof2 : runCachedNode 511 125773 Adaptive132Third127Node2 = false := by
  decide +kernel

#print axioms adaptive132Third127Proof2

end NineSeparatedSubsetSums
