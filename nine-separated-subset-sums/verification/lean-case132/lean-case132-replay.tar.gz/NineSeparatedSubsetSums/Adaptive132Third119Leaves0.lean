import NineSeparatedSubsetSums.Adaptive132Third119State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive132Third119Proof0 : runCachedNode 511 124061 Adaptive132Third119Node0 = false := by
  decide +kernel

#print axioms adaptive132Third119Proof0

end NineSeparatedSubsetSums
