import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive132Third116Node0 : CachedSearchNode :=
  ⟨4, 115, computeCenteredMask [148,132,116], 396, 52784⟩

end NineSeparatedSubsetSums
