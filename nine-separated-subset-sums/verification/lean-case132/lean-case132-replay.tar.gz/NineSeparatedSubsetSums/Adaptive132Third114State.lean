import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive132Third114Node0 : CachedSearchNode :=
  ⟨4, 113, computeCenteredMask [148,132,114], 394, 52324⟩

end NineSeparatedSubsetSums
