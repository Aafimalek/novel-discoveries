import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive132Third107Node0 : CachedSearchNode :=
  ⟨4, 106, computeCenteredMask [148,132,107], 387, 50777⟩

end NineSeparatedSubsetSums
