import NineSeparatedSubsetSums.EightPoint132_118PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct132_118_0_budget :
    FourPointNumeric.packedBudget 20 packedOct132_118_0 267 = 78002965 := by decide +kernel

#print axioms packedOct132_118_0_budget

end NineSeparatedSubsetSums
