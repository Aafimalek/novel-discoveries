import NineSeparatedSubsetSums.EightPoint132_124PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct132_124_1_budget :
    FourPointNumeric.packedBudget 20 packedOct132_124_1 506 = 82401426 := by decide +kernel

#print axioms packedOct132_124_1_budget

end NineSeparatedSubsetSums
