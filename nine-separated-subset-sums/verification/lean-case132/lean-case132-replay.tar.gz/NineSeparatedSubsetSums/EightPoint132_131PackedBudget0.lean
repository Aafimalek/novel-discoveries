import NineSeparatedSubsetSums.EightPoint132_131PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct132_131_0_budget :
    FourPointNumeric.packedBudget 20 packedOct132_131_0 375 = 86986571 := by decide +kernel

#print axioms packedOct132_131_0_budget

end NineSeparatedSubsetSums
