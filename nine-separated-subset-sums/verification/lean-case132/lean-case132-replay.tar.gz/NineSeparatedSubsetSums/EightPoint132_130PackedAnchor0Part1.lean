import NineSeparatedSubsetSums.EightPoint132_130PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint132_130PackedAnchor0Part1 :
    ∀ j : Fin 120, 2357544 ≤ FourPointNumeric.octPackedCharge 132 130 20 packedOct132_130_0
      (2*((j.val : Int)+120)+0) := by decide +kernel

end NineSeparatedSubsetSums
