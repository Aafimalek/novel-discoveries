import NineSeparatedSubsetSums.Adaptive132Third115State
import NineSeparatedSubsetSums.Adaptive132Third115Leaves0
import NineSeparatedSubsetSums.Adaptive132Third115Leaves1

namespace NineSeparatedSubsetSums

theorem adaptive132Third115Proof0 : runCachedNode 511 110282 Adaptive132Third115Node0 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 110282 Adaptive132Third115Node0 = [101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive132Third115Proof1
  · exact adaptive132Third115Proof2
  · exact adaptive132Third115Proof3
  · exact adaptive132Third115Proof4
  · exact adaptive132Third115Proof5
  · exact adaptive132Third115Proof6
  · exact adaptive132Third115Proof7
  · exact adaptive132Third115Proof8
  · exact adaptive132Third115Proof9
  · exact adaptive132Third115Proof10
  · exact adaptive132Third115Proof11
  · exact adaptive132Third115Proof12
  · exact adaptive132Third115Proof13
  · exact adaptive132Third115Proof14

#print axioms adaptive132Third115Proof0

end NineSeparatedSubsetSums
