import NineSeparatedSubsetSums.EightPoint132_120PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct132_120_1_budget :
    FourPointNumeric.packedBudget 20 packedOct132_120_1 390 = 82158002 := by decide +kernel

#print axioms packedOct132_120_1_budget

end NineSeparatedSubsetSums
