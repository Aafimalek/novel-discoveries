import NineSeparatedSubsetSums.EightPoint132_122PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint132_122PackedAnchor0Part1 :
    ∀ j : Fin 120, 2261394 ≤ FourPointNumeric.octPackedCharge 132 122 20 packedOct132_122_0
      (2*((j.val : Int)+120)+0) := by decide +kernel

end NineSeparatedSubsetSums
