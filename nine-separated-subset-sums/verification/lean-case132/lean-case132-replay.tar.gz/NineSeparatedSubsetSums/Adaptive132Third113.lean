import NineSeparatedSubsetSums.Adaptive132Third113Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint132Checked

namespace NineSeparatedSubsetSums


theorem adaptive132Third113 : NoDescendingTailAfterThird 132 113 :=
  noDescendingThirdTail_of_cached 132 113 110282 (fun t ht nd => max148_second132_fourPoint_moment_bound (113::t) (by simp [ht]) nd) adaptive132Third113Proof0

#print axioms adaptive132Third113

end NineSeparatedSubsetSums
