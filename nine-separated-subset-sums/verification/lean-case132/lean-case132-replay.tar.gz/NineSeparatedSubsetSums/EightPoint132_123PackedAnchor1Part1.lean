import NineSeparatedSubsetSums.EightPoint132_123PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint132_123PackedAnchor1Part1 :
    ∀ j : Fin 120, 2275648 ≤ FourPointNumeric.octPackedCharge 132 123 20 packedOct132_123_1
      (2*((j.val : Int)+120)+0) := by decide +kernel

end NineSeparatedSubsetSums
