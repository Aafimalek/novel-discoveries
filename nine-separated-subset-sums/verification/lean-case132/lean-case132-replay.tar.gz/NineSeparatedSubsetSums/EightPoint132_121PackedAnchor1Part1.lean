import NineSeparatedSubsetSums.EightPoint132_121PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint132_121PackedAnchor1Part1 :
    ∀ j : Fin 120, 2310415 ≤ FourPointNumeric.octPackedCharge 132 121 20 packedOct132_121_1
      (2*((j.val : Int)+120)+0) := by decide +kernel

end NineSeparatedSubsetSums
