import NineSeparatedSubsetSums.EightPoint132_125PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct132_125_1_budget :
    FourPointNumeric.packedBudget 20 packedOct132_125_1 382 = 83109672 := by decide +kernel

#print axioms packedOct132_125_1_budget

end NineSeparatedSubsetSums
