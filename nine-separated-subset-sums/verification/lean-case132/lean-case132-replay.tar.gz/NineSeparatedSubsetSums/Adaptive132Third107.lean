import NineSeparatedSubsetSums.Adaptive132Third107Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint132Checked

namespace NineSeparatedSubsetSums


theorem adaptive132Third107 : NoDescendingTailAfterThird 132 107 :=
  noDescendingThirdTail_of_cached 132 107 110282 (fun t ht nd => max148_second132_fourPoint_moment_bound (107::t) (by simp [ht]) nd) adaptive132Third107Proof0

#print axioms adaptive132Third107

end NineSeparatedSubsetSums
