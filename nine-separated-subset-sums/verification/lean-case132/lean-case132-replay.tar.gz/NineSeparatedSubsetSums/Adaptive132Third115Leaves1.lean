import NineSeparatedSubsetSums.Adaptive132Third115State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive132Third115Proof8 : runCachedNode 511 110282 Adaptive132Third115Node8 = false := by
  decide +kernel

#print axioms adaptive132Third115Proof8

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive132Third115Proof7 : runCachedNode 511 110282 Adaptive132Third115Node7 = false := by
  decide +kernel

#print axioms adaptive132Third115Proof7

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive132Third115Proof6 : runCachedNode 511 110282 Adaptive132Third115Node6 = false := by
  decide +kernel

#print axioms adaptive132Third115Proof6

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive132Third115Proof5 : runCachedNode 511 110282 Adaptive132Third115Node5 = false := by
  decide +kernel

#print axioms adaptive132Third115Proof5

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive132Third115Proof4 : runCachedNode 511 110282 Adaptive132Third115Node4 = false := by
  decide +kernel

#print axioms adaptive132Third115Proof4

end NineSeparatedSubsetSums
