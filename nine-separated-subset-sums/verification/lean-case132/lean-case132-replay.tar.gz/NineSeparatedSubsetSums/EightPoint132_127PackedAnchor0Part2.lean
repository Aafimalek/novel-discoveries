import NineSeparatedSubsetSums.EightPoint132_127PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint132_127PackedAnchor0Part2 :
    ∀ j : Fin 2, 2320321 ≤ FourPointNumeric.octPackedCharge 132 127 20 packedOct132_127_0
      (2*((j.val : Int)+240)+1) := by decide +kernel

end NineSeparatedSubsetSums
