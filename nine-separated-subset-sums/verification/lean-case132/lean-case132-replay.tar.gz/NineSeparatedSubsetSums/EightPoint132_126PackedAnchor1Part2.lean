import NineSeparatedSubsetSums.EightPoint132_126PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint132_126PackedAnchor1Part2 :
    ∀ j : Fin 2, 2308993 ≤ FourPointNumeric.octPackedCharge 132 126 20 packedOct132_126_1
      (2*((j.val : Int)+240)+1) := by decide +kernel

end NineSeparatedSubsetSums
