import NineSeparatedSubsetSums.Adaptive132Third128State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive132Third128Proof11 : runCachedNode 511 125907 Adaptive132Third128Node11 = false := by
  decide +kernel

#print axioms adaptive132Third128Proof11

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive132Third128Proof9 : runCachedNode 511 125907 Adaptive132Third128Node9 = false := by
  decide +kernel

#print axioms adaptive132Third128Proof9

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive132Third128Proof8 : runCachedNode 511 125907 Adaptive132Third128Node8 = false := by
  decide +kernel

#print axioms adaptive132Third128Proof8

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive132Third128Proof7 : runCachedNode 511 125907 Adaptive132Third128Node7 = false := by
  decide +kernel

#print axioms adaptive132Third128Proof7

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive132Third128Proof5 : runCachedNode 511 125907 Adaptive132Third128Node5 = false := by
  decide +kernel

#print axioms adaptive132Third128Proof5

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive132Third128Proof6 : runCachedNode 511 125907 Adaptive132Third128Node6 = false := by
  decide +kernel

#print axioms adaptive132Third128Proof6

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive132Third128Proof2 : runCachedNode 511 125907 Adaptive132Third128Node2 = false := by
  decide +kernel

#print axioms adaptive132Third128Proof2

end NineSeparatedSubsetSums
