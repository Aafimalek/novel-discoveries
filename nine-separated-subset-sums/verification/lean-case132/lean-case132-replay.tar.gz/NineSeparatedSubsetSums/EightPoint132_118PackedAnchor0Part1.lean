import NineSeparatedSubsetSums.EightPoint132_118PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint132_118PackedAnchor0Part1 :
    ∀ j : Fin 117, 2209769 ≤ FourPointNumeric.octPackedCharge 132 118 20 packedOct132_118_0
      (2*((j.val : Int)+120)+0) := by decide +kernel

end NineSeparatedSubsetSums
