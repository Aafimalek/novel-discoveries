import NineSeparatedSubsetSums.Adaptive132Third115State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive132Third115Proof14 : runCachedNode 511 110282 Adaptive132Third115Node14 = false := by
  decide +kernel

#print axioms adaptive132Third115Proof14

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive132Third115Proof13 : runCachedNode 511 110282 Adaptive132Third115Node13 = false := by
  decide +kernel

#print axioms adaptive132Third115Proof13

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive132Third115Proof12 : runCachedNode 511 110282 Adaptive132Third115Node12 = false := by
  decide +kernel

#print axioms adaptive132Third115Proof12

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive132Third115Proof11 : runCachedNode 511 110282 Adaptive132Third115Node11 = false := by
  decide +kernel

#print axioms adaptive132Third115Proof11

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive132Third115Proof10 : runCachedNode 511 110282 Adaptive132Third115Node10 = false := by
  decide +kernel

#print axioms adaptive132Third115Proof10

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive132Third115Proof9 : runCachedNode 511 110282 Adaptive132Third115Node9 = false := by
  decide +kernel

#print axioms adaptive132Third115Proof9

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive132Third115Proof3 : runCachedNode 511 110282 Adaptive132Third115Node3 = false := by
  decide +kernel

#print axioms adaptive132Third115Proof3

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive132Third115Proof2 : runCachedNode 511 110282 Adaptive132Third115Node2 = false := by
  decide +kernel

#print axioms adaptive132Third115Proof2

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive132Third115Proof1 : runCachedNode 511 110282 Adaptive132Third115Node1 = false := by
  decide +kernel

#print axioms adaptive132Third115Proof1

end NineSeparatedSubsetSums
