import NineSeparatedSubsetSums.EightPoint132_130PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct132_130_0_budget :
    FourPointNumeric.packedBudget 20 packedOct132_130_0 369 = 86252073 := by decide +kernel

#print axioms packedOct132_130_0_budget

end NineSeparatedSubsetSums
