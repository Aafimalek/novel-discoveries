import NineSeparatedSubsetSums.EightPoint132_116PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint132_116PackedAnchor1Part1 :
    ∀ j : Fin 114, 2172474 ≤ FourPointNumeric.octPackedCharge 132 116 20 packedOct132_116_1
      (2*((j.val : Int)+120)+1) := by decide +kernel

end NineSeparatedSubsetSums
