import NineSeparatedSubsetSums.Adaptive132Third121State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive132Third121Proof0 : runCachedNode 511 124181 Adaptive132Third121Node0 = false := by
  decide +kernel

#print axioms adaptive132Third121Proof0

end NineSeparatedSubsetSums
