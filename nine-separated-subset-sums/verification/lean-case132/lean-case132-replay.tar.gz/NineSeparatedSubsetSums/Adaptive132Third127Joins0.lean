import NineSeparatedSubsetSums.Adaptive132Third127State
import NineSeparatedSubsetSums.Adaptive132Third127Leaves0
import NineSeparatedSubsetSums.Adaptive132Third127Leaves1

namespace NineSeparatedSubsetSums

theorem adaptive132Third127Proof0 : runCachedNode 511 125773 Adaptive132Third127Node0 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 125773 Adaptive132Third127Node0 = [112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive132Third127Proof1
  · exact adaptive132Third127Proof2
  · exact adaptive132Third127Proof3
  · exact adaptive132Third127Proof4
  · exact adaptive132Third127Proof5
  · exact adaptive132Third127Proof6
  · exact adaptive132Third127Proof7
  · exact adaptive132Third127Proof8
  · exact adaptive132Third127Proof9
  · exact adaptive132Third127Proof10
  · exact adaptive132Third127Proof11
  · exact adaptive132Third127Proof12
  · exact adaptive132Third127Proof13
  · exact adaptive132Third127Proof14
  · exact adaptive132Third127Proof15

#print axioms adaptive132Third127Proof0

end NineSeparatedSubsetSums
