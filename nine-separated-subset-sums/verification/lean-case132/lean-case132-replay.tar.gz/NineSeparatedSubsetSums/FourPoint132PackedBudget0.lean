import NineSeparatedSubsetSums.FourPoint132PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedWeight132_0_budget :
    FourPointNumeric.packedBudget 19 packedWeight132_0 519 = 74238464 := by decide +kernel

#print axioms packedWeight132_0_budget

end NineSeparatedSubsetSums
