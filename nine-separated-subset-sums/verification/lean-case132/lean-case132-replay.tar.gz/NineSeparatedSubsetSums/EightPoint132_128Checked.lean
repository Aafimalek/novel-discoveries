import NineSeparatedSubsetSums.EightPointPackedGeometry
import NineSeparatedSubsetSums.EightPoint132_128PackedBudget0
import NineSeparatedSubsetSums.EightPoint132_128PackedAnchor0Part0
import NineSeparatedSubsetSums.EightPoint132_128PackedAnchor0Part1
import NineSeparatedSubsetSums.EightPoint132_128PackedAnchor0Part2
import NineSeparatedSubsetSums.EightPoint132_128PackedBudget1
import NineSeparatedSubsetSums.EightPoint132_128PackedAnchor1Part0
import NineSeparatedSubsetSums.EightPoint132_128PackedAnchor1Part1
import NineSeparatedSubsetSums.EightPoint132_128PackedAnchor1Part2

namespace NineSeparatedSubsetSums

private theorem packedOct132_128Anchor0 :
  ∀ j : Fin 485, ((j.val : Int)+132+128)%2=0 →
    2324751 ≤ FourPointNumeric.octPackedCharge 132 128 20 packedOct132_128_0 (j.val : Int) := by
  intro j hj
  let k := (j.val-0)/2
  have hk : k < 243 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+0 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint132_128PackedAnchor0Part0 z
    rwa [he,hrep] at ht
  by_cases h1 : k < 240
  · let z : Fin 120 := ⟨k-120, by omega⟩
    have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
    have ht := eightPoint132_128PackedAnchor0Part1 z
    rwa [he,hrep] at ht
  let z : Fin 3 := ⟨k-240, by omega⟩
  have he : (z.val : Int)+240 = k := by dsimp [z] <;> omega
  have ht := eightPoint132_128PackedAnchor0Part2 z
  rwa [he,hrep] at ht

private theorem packedOct132_128Anchor1 :
  ∀ j : Fin 485, ((j.val : Int)+132+128)%2=1 →
    2324567 ≤ FourPointNumeric.octPackedCharge 132 128 20 packedOct132_128_1 (j.val : Int) := by
  intro j hj
  let k := (j.val-1)/2
  have hk : k < 242 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+1 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint132_128PackedAnchor1Part0 z
    rwa [he,hrep] at ht
  by_cases h1 : k < 240
  · let z : Fin 120 := ⟨k-120, by omega⟩
    have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
    have ht := eightPoint132_128PackedAnchor1Part1 z
    rwa [he,hrep] at ht
  let z : Fin 2 := ⟨k-240, by omega⟩
  have he : (z.val : Int)+240 = k := by dsimp [z] <;> omega
  have ht := eightPoint132_128PackedAnchor1Part2 z
  rwa [he,hrep] at ht

def packedOctCertificate132_128_0 : EightPointCertificate 132 128 0 125907 :=
  eightPointCertificateOfPacked 132 128 0 125907 2324751 20 packedOct132_128_0 447 485
    (by decide +kernel) (by decide) packedOct132_128Anchor0
    (by rw [packedOct132_128_0_budget]; decide)

def packedOctCertificate132_128_1 : EightPointCertificate 132 128 1 125907 :=
  eightPointCertificateOfPacked 132 128 1 125907 2324567 20 packedOct132_128_1 446 485
    (by decide +kernel) (by decide) packedOct132_128Anchor1
    (by rw [packedOct132_128_1_budget]; decide)

theorem max148_second132_third128_eightPoint_moment_bound (tail : List ℕ) (len : tail.length=6)
    (distinct : (natSubsetSums (148::132::128::tail)).Nodup) :
    125907 ≤ ((148::132::128::tail).map (· ^ 2)).sum := by
  apply eightPointNatMomentLower 132 128 125907 tail len distinct
  intro p hp
  by_cases h : p=0
  · subst p
    exact packedOctCertificate132_128_0
  · have he : p=1 := hp.resolve_left h
    subst p
    exact packedOctCertificate132_128_1

#print axioms max148_second132_third128_eightPoint_moment_bound

end NineSeparatedSubsetSums
