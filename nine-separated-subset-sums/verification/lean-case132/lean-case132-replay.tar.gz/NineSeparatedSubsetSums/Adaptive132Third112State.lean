import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive132Third112Node0 : CachedSearchNode :=
  ⟨4, 111, computeCenteredMask [148,132,112], 392, 51872⟩

end NineSeparatedSubsetSums
