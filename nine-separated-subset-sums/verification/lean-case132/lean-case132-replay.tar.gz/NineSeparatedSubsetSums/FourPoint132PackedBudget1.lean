import NineSeparatedSubsetSums.FourPoint132PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedWeight132_1_budget :
    FourPointNumeric.packedBudget 20 packedWeight132_1 368 = 74227200 := by decide +kernel

#print axioms packedWeight132_1_budget

end NineSeparatedSubsetSums
