import NineSeparatedSubsetSums.Adaptive132Third110State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive132Third110Proof0 : runCachedNode 511 110282 Adaptive132Third110Node0 = false := by
  decide +kernel

#print axioms adaptive132Third110Proof0

end NineSeparatedSubsetSums
