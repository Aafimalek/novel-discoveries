import NineSeparatedSubsetSums.EightPoint132_125PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint132_125PackedAnchor0Part2 :
    ∀ j : Fin 1, 2300238 ≤ FourPointNumeric.octPackedCharge 132 125 20 packedOct132_125_0
      (2*((j.val : Int)+240)+1) := by decide +kernel

end NineSeparatedSubsetSums
