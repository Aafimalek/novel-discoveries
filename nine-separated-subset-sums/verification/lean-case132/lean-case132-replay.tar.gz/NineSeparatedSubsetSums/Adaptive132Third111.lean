import NineSeparatedSubsetSums.Adaptive132Third111Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint132Checked

namespace NineSeparatedSubsetSums


theorem adaptive132Third111 : NoDescendingTailAfterThird 132 111 :=
  noDescendingThirdTail_of_cached 132 111 110282 (fun t ht nd => max148_second132_fourPoint_moment_bound (111::t) (by simp [ht]) nd) adaptive132Third111Proof0

#print axioms adaptive132Third111

end NineSeparatedSubsetSums
