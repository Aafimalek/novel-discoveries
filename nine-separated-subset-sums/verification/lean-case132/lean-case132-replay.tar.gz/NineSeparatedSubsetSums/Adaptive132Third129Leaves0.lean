import NineSeparatedSubsetSums.Adaptive132Third129State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive132Third129Proof17 : runCachedNode 511 126048 Adaptive132Third129Node17 = false := by
  decide +kernel

#print axioms adaptive132Third129Proof17

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive132Third129Proof15 : runCachedNode 511 126048 Adaptive132Third129Node15 = false := by
  decide +kernel

#print axioms adaptive132Third129Proof15

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive132Third129Proof16 : runCachedNode 511 126048 Adaptive132Third129Node16 = false := by
  decide +kernel

#print axioms adaptive132Third129Proof16

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive132Third129Proof14 : runCachedNode 511 126048 Adaptive132Third129Node14 = false := by
  decide +kernel

#print axioms adaptive132Third129Proof14

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive132Third129Proof4 : runCachedNode 511 126048 Adaptive132Third129Node4 = false := by
  decide +kernel

#print axioms adaptive132Third129Proof4

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive132Third129Proof3 : runCachedNode 511 126048 Adaptive132Third129Node3 = false := by
  decide +kernel

#print axioms adaptive132Third129Proof3

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive132Third129Proof1 : runCachedNode 511 126048 Adaptive132Third129Node1 = false := by
  decide +kernel

#print axioms adaptive132Third129Proof1

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive132Third129Proof2 : runCachedNode 511 126048 Adaptive132Third129Node2 = false := by
  decide +kernel

#print axioms adaptive132Third129Proof2

end NineSeparatedSubsetSums
