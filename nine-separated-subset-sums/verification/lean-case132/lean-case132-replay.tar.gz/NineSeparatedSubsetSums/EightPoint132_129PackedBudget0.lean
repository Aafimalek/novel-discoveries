import NineSeparatedSubsetSums.EightPoint132_129PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct132_129_0_budget :
    FourPointNumeric.packedBudget 20 packedOct132_129_0 457 = 85002154 := by decide +kernel

#print axioms packedOct132_129_0_budget

end NineSeparatedSubsetSums
