import NineSeparatedSubsetSums.EightPoint132_128PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct132_128_1_budget :
    FourPointNumeric.packedBudget 20 packedOct132_128_1 446 = 84307768 := by decide +kernel

#print axioms packedOct132_128_1_budget

end NineSeparatedSubsetSums
