import NineSeparatedSubsetSums.EightPoint132_131PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct132_131_1_budget :
    FourPointNumeric.packedBudget 20 packedOct132_131_1 440 = 86930628 := by decide +kernel

#print axioms packedOct132_131_1_budget

end NineSeparatedSubsetSums
