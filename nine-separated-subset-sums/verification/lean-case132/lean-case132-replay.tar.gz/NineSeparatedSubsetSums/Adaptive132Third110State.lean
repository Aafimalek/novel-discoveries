import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive132Third110Node0 : CachedSearchNode :=
  ⟨4, 109, computeCenteredMask [148,132,110], 390, 51428⟩

end NineSeparatedSubsetSums
