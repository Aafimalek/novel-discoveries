import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive132Third111Node0 : CachedSearchNode :=
  ⟨4, 110, computeCenteredMask [148,132,111], 391, 51649⟩

end NineSeparatedSubsetSums
