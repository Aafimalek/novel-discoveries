import NineSeparatedSubsetSums.Adaptive132Third120State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive132Third120Proof0 : runCachedNode 511 124235 Adaptive132Third120Node0 = false := by
  decide +kernel

#print axioms adaptive132Third120Proof0

end NineSeparatedSubsetSums
