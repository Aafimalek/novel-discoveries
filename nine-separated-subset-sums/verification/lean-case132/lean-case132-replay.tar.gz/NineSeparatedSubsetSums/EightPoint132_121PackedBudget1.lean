import NineSeparatedSubsetSums.EightPoint132_121PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct132_121_1_budget :
    FourPointNumeric.packedBudget 20 packedOct132_121_1 370 = 84286060 := by decide +kernel

#print axioms packedOct132_121_1_budget

end NineSeparatedSubsetSums
