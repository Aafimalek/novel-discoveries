import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive132Third123Node0 : CachedSearchNode :=
  ⟨4, 122, computeCenteredMask [148,132,123], 403, 54457⟩

end NineSeparatedSubsetSums
