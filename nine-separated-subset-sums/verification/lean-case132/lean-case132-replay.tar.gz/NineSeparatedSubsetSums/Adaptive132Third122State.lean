import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive132Third122Node0 : CachedSearchNode :=
  ⟨4, 121, computeCenteredMask [148,132,122], 402, 54212⟩

end NineSeparatedSubsetSums
