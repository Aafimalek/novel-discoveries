import NineSeparatedSubsetSums.EightPoint132_120PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct132_120_0_budget :
    FourPointNumeric.packedBudget 20 packedOct132_120_0 391 = 82290712 := by decide +kernel

#print axioms packedOct132_120_0_budget

end NineSeparatedSubsetSums
