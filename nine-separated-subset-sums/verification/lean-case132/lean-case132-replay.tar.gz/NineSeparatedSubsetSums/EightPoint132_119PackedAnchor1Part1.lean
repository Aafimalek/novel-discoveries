import NineSeparatedSubsetSums.EightPoint132_119PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint132_119PackedAnchor1Part1 :
    ∀ j : Fin 119, 2253294 ≤ FourPointNumeric.octPackedCharge 132 119 20 packedOct132_119_1
      (2*((j.val : Int)+120)+0) := by decide +kernel

end NineSeparatedSubsetSums
