import NineSeparatedSubsetSums.EightPoint132_129PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint132_129PackedAnchor0Part0 :
    ∀ j : Fin 120, 2336545 ≤ FourPointNumeric.octPackedCharge 132 129 20 packedOct132_129_0
      (2*((j.val : Int)+0)+1) := by decide +kernel

end NineSeparatedSubsetSums
