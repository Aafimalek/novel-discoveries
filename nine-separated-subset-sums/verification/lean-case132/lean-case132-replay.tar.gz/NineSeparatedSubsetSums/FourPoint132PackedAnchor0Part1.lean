import NineSeparatedSubsetSums.FourPoint132PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem fourPoint132PackedAnchor0Part1 :
    ∀ j : Fin 113, 1021120 ≤ FourPointNumeric.packedCharge 132 19 packedWeight132_0
      (2*((j.val : Int)+120)+0) := by decide +kernel

end NineSeparatedSubsetSums
