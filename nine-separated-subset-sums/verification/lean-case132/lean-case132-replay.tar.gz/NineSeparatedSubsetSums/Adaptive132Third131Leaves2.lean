import NineSeparatedSubsetSums.Adaptive132Third131State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive132Third131Proof13 : runCachedNode 511 126429 Adaptive132Third131Node13 = false := by
  decide +kernel

#print axioms adaptive132Third131Proof13

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive132Third131Proof12 : runCachedNode 511 126429 Adaptive132Third131Node12 = false := by
  decide +kernel

#print axioms adaptive132Third131Proof12

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive132Third131Proof11 : runCachedNode 511 126429 Adaptive132Third131Node11 = false := by
  decide +kernel

#print axioms adaptive132Third131Proof11

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive132Third131Proof10 : runCachedNode 511 126429 Adaptive132Third131Node10 = false := by
  decide +kernel

#print axioms adaptive132Third131Proof10

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive132Third131Proof9 : runCachedNode 511 126429 Adaptive132Third131Node9 = false := by
  decide +kernel

#print axioms adaptive132Third131Proof9

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive132Third131Proof8 : runCachedNode 511 126429 Adaptive132Third131Node8 = false := by
  decide +kernel

#print axioms adaptive132Third131Proof8

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive132Third131Proof7 : runCachedNode 511 126429 Adaptive132Third131Node7 = false := by
  decide +kernel

#print axioms adaptive132Third131Proof7

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive132Third131Proof6 : runCachedNode 511 126429 Adaptive132Third131Node6 = false := by
  decide +kernel

#print axioms adaptive132Third131Proof6

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive132Third131Proof3 : runCachedNode 511 126429 Adaptive132Third131Node3 = false := by
  decide +kernel

#print axioms adaptive132Third131Proof3

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive132Third131Proof2 : runCachedNode 511 126429 Adaptive132Third131Node2 = false := by
  decide +kernel

#print axioms adaptive132Third131Proof2

end NineSeparatedSubsetSums
