import NineSeparatedSubsetSums.Adaptive132Third125State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive132Third125Proof0 : runCachedNode 511 125311 Adaptive132Third125Node0 = false := by
  decide +kernel

#print axioms adaptive132Third125Proof0

end NineSeparatedSubsetSums
