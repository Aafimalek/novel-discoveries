import NineSeparatedSubsetSums.Adaptive132Third105Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint132Checked

namespace NineSeparatedSubsetSums


theorem adaptive132Third105 : NoDescendingTailAfterThird 132 105 :=
  noDescendingThirdTail_of_cached 132 105 110282 (fun t ht nd => max148_second132_fourPoint_moment_bound (105::t) (by simp [ht]) nd) adaptive132Third105Proof0

#print axioms adaptive132Third105

end NineSeparatedSubsetSums
