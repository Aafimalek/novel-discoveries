import NineSeparatedSubsetSums.Adaptive132Third108State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive132Third108Proof0 : runCachedNode 511 110282 Adaptive132Third108Node0 = false := by
  decide +kernel

#print axioms adaptive132Third108Proof0

end NineSeparatedSubsetSums
