import NineSeparatedSubsetSums.EightPoint132_126PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct132_126_1_budget :
    FourPointNumeric.packedBudget 20 packedOct132_126_1 394 = 83478316 := by decide +kernel

#print axioms packedOct132_126_1_budget

end NineSeparatedSubsetSums
