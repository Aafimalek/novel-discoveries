import NineSeparatedSubsetSums.Adaptive132Third112State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive132Third112Proof0 : runCachedNode 511 110282 Adaptive132Third112Node0 = false := by
  decide +kernel

#print axioms adaptive132Third112Proof0

end NineSeparatedSubsetSums
