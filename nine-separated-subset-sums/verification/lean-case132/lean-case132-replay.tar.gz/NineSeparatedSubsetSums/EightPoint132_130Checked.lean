import NineSeparatedSubsetSums.EightPointPackedGeometry
import NineSeparatedSubsetSums.EightPoint132_130PackedBudget0
import NineSeparatedSubsetSums.EightPoint132_130PackedAnchor0Part0
import NineSeparatedSubsetSums.EightPoint132_130PackedAnchor0Part1
import NineSeparatedSubsetSums.EightPoint132_130PackedAnchor0Part2
import NineSeparatedSubsetSums.EightPoint132_130PackedBudget1
import NineSeparatedSubsetSums.EightPoint132_130PackedAnchor1Part0
import NineSeparatedSubsetSums.EightPoint132_130PackedAnchor1Part1
import NineSeparatedSubsetSums.EightPoint132_130PackedAnchor1Part2

namespace NineSeparatedSubsetSums

private theorem packedOct132_130Anchor0 :
  ∀ j : Fin 489, ((j.val : Int)+132+130)%2=0 →
    2357544 ≤ FourPointNumeric.octPackedCharge 132 130 20 packedOct132_130_0 (j.val : Int) := by
  intro j hj
  let k := (j.val-0)/2
  have hk : k < 245 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+0 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint132_130PackedAnchor0Part0 z
    rwa [he,hrep] at ht
  by_cases h1 : k < 240
  · let z : Fin 120 := ⟨k-120, by omega⟩
    have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
    have ht := eightPoint132_130PackedAnchor0Part1 z
    rwa [he,hrep] at ht
  let z : Fin 5 := ⟨k-240, by omega⟩
  have he : (z.val : Int)+240 = k := by dsimp [z] <;> omega
  have ht := eightPoint132_130PackedAnchor0Part2 z
  rwa [he,hrep] at ht

private theorem packedOct132_130Anchor1 :
  ∀ j : Fin 489, ((j.val : Int)+132+130)%2=1 →
    2355286 ≤ FourPointNumeric.octPackedCharge 132 130 20 packedOct132_130_1 (j.val : Int) := by
  intro j hj
  let k := (j.val-1)/2
  have hk : k < 244 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+1 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint132_130PackedAnchor1Part0 z
    rwa [he,hrep] at ht
  by_cases h1 : k < 240
  · let z : Fin 120 := ⟨k-120, by omega⟩
    have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
    have ht := eightPoint132_130PackedAnchor1Part1 z
    rwa [he,hrep] at ht
  let z : Fin 4 := ⟨k-240, by omega⟩
  have he : (z.val : Int)+240 = k := by dsimp [z] <;> omega
  have ht := eightPoint132_130PackedAnchor1Part2 z
  rwa [he,hrep] at ht

def packedOctCertificate132_130_0 : EightPointCertificate 132 130 0 126232 :=
  eightPointCertificateOfPacked 132 130 0 126232 2357544 20 packedOct132_130_0 369 489
    (by decide +kernel) (by decide) packedOct132_130Anchor0
    (by rw [packedOct132_130_0_budget]; decide)

def packedOctCertificate132_130_1 : EightPointCertificate 132 130 1 126232 :=
  eightPointCertificateOfPacked 132 130 1 126232 2355286 20 packedOct132_130_1 518 489
    (by decide +kernel) (by decide) packedOct132_130Anchor1
    (by rw [packedOct132_130_1_budget]; decide)

theorem max148_second132_third130_eightPoint_moment_bound (tail : List ℕ) (len : tail.length=6)
    (distinct : (natSubsetSums (148::132::130::tail)).Nodup) :
    126232 ≤ ((148::132::130::tail).map (· ^ 2)).sum := by
  apply eightPointNatMomentLower 132 130 126232 tail len distinct
  intro p hp
  by_cases h : p=0
  · subst p
    exact packedOctCertificate132_130_0
  · have he : p=1 := hp.resolve_left h
    subst p
    exact packedOctCertificate132_130_1

#print axioms max148_second132_third130_eightPoint_moment_bound

end NineSeparatedSubsetSums
