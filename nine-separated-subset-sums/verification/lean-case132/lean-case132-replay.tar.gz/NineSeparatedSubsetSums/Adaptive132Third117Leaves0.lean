import NineSeparatedSubsetSums.Adaptive132Third117State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive132Third117Proof0 : runCachedNode 511 123740 Adaptive132Third117Node0 = false := by
  decide +kernel

#print axioms adaptive132Third117Proof0

end NineSeparatedSubsetSums
