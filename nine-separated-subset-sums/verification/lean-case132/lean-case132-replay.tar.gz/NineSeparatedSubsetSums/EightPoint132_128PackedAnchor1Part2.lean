import NineSeparatedSubsetSums.EightPoint132_128PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint132_128PackedAnchor1Part2 :
    ∀ j : Fin 2, 2324567 ≤ FourPointNumeric.octPackedCharge 132 128 20 packedOct132_128_1
      (2*((j.val : Int)+240)+1) := by decide +kernel

end NineSeparatedSubsetSums
