import NineSeparatedSubsetSums.Adaptive132Third109Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint132Checked

namespace NineSeparatedSubsetSums


theorem adaptive132Third109 : NoDescendingTailAfterThird 132 109 :=
  noDescendingThirdTail_of_cached 132 109 110282 (fun t ht nd => max148_second132_fourPoint_moment_bound (109::t) (by simp [ht]) nd) adaptive132Third109Proof0

#print axioms adaptive132Third109

end NineSeparatedSubsetSums
