import NineSeparatedSubsetSums.Adaptive132Third106Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint132Checked

namespace NineSeparatedSubsetSums


theorem adaptive132Third106 : NoDescendingTailAfterThird 132 106 :=
  noDescendingThirdTail_of_cached 132 106 110282 (fun t ht nd => max148_second132_fourPoint_moment_bound (106::t) (by simp [ht]) nd) adaptive132Third106Proof0

#print axioms adaptive132Third106

end NineSeparatedSubsetSums
