import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive132Third126Node0 : CachedSearchNode :=
  ⟨4, 125, computeCenteredMask [148,132,126], 406, 55204⟩

end NineSeparatedSubsetSums
