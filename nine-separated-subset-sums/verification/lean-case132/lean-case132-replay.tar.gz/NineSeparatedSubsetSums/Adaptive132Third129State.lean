import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive132Third129Node0 : CachedSearchNode :=
  ⟨4, 128, computeCenteredMask [148,132,129], 409, 55969⟩
def Adaptive132Third129Node1 : CachedSearchNode := cachedChild Adaptive132Third129Node0 111
def Adaptive132Third129Node2 : CachedSearchNode := cachedChild Adaptive132Third129Node0 112
def Adaptive132Third129Node3 : CachedSearchNode := cachedChild Adaptive132Third129Node0 114
def Adaptive132Third129Node4 : CachedSearchNode := cachedChild Adaptive132Third129Node0 115
def Adaptive132Third129Node5 : CachedSearchNode := cachedChild Adaptive132Third129Node0 116
def Adaptive132Third129Node6 : CachedSearchNode := cachedChild Adaptive132Third129Node0 117
def Adaptive132Third129Node7 : CachedSearchNode := cachedChild Adaptive132Third129Node0 118
def Adaptive132Third129Node8 : CachedSearchNode := cachedChild Adaptive132Third129Node0 119
def Adaptive132Third129Node9 : CachedSearchNode := cachedChild Adaptive132Third129Node0 120
def Adaptive132Third129Node10 : CachedSearchNode := cachedChild Adaptive132Third129Node0 121
def Adaptive132Third129Node11 : CachedSearchNode := cachedChild Adaptive132Third129Node0 122
def Adaptive132Third129Node12 : CachedSearchNode := cachedChild Adaptive132Third129Node0 123
def Adaptive132Third129Node13 : CachedSearchNode := cachedChild Adaptive132Third129Node0 124
def Adaptive132Third129Node14 : CachedSearchNode := cachedChild Adaptive132Third129Node0 125
def Adaptive132Third129Node15 : CachedSearchNode := cachedChild Adaptive132Third129Node0 126
def Adaptive132Third129Node16 : CachedSearchNode := cachedChild Adaptive132Third129Node0 127
def Adaptive132Third129Node17 : CachedSearchNode := cachedChild Adaptive132Third129Node0 128

end NineSeparatedSubsetSums
