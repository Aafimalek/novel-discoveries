import NineSeparatedSubsetSums.FourPoint132PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem fourPoint132PackedAnchor1Part1 :
    ∀ j : Fin 112, 1021028 ≤ FourPointNumeric.packedCharge 132 20 packedWeight132_1
      (2*((j.val : Int)+120)+1) := by decide +kernel

end NineSeparatedSubsetSums
