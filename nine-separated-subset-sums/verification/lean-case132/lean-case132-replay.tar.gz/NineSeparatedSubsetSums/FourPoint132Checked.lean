import NineSeparatedSubsetSums.FourPointPackedGeometry
import NineSeparatedSubsetSums.FourPoint132PackedBudget0
import NineSeparatedSubsetSums.FourPoint132PackedAnchor0Part0
import NineSeparatedSubsetSums.FourPoint132PackedAnchor0Part1
import NineSeparatedSubsetSums.FourPoint132PackedBudget1
import NineSeparatedSubsetSums.FourPoint132PackedAnchor1Part0
import NineSeparatedSubsetSums.FourPoint132PackedAnchor1Part1

namespace NineSeparatedSubsetSums

private theorem packed132Anchor0 :
  ∀ j : Fin 465, ((j.val : Int)+132)%2=0 →
    1021120 ≤ FourPointNumeric.packedCharge 132 19 packedWeight132_0 (j.val : Int) := by
  intro j hj
  let k := (j.val-0)/2
  have hk : k < 233 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+0 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := fourPoint132PackedAnchor0Part0 z
    rwa [he,hrep] at ht
  let z : Fin 113 := ⟨k-120, by omega⟩
  have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
  have ht := fourPoint132PackedAnchor0Part1 z
  rwa [he,hrep] at ht

private theorem packed132Anchor1 :
  ∀ j : Fin 465, ((j.val : Int)+132)%2=1 →
    1021028 ≤ FourPointNumeric.packedCharge 132 20 packedWeight132_1 (j.val : Int) := by
  intro j hj
  let k := (j.val-1)/2
  have hk : k < 232 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+1 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := fourPoint132PackedAnchor1Part0 z
    rwa [he,hrep] at ht
  let z : Fin 112 := ⟨k-120, by omega⟩
  have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
  have ht := fourPoint132PackedAnchor1Part1 z
  rwa [he,hrep] at ht

def packedCertificate132_0 : FourPointCertificate 132 0 110282 :=
  fourPointCertificateOfPacked 132 0 110282 1021120 19 packedWeight132_0 519 465
    (by decide +kernel) (by decide) (by decide) packed132Anchor0
    (by rw [packedWeight132_0_budget]; decide)

def packedCertificate132_1 : FourPointCertificate 132 1 110282 :=
  fourPointCertificateOfPacked 132 1 110282 1021028 20 packedWeight132_1 368 465
    (by decide +kernel) (by decide) (by decide) packed132Anchor1
    (by rw [packedWeight132_1_budget]; decide)

theorem max148_second132_fourPoint_moment_bound (tail : List ℕ) (len : tail.length=7)
    (distinct : (natSubsetSums (148::132::tail)).Nodup) :
    110282 ≤ ((148::132::tail).map (· ^ 2)).sum := by
  apply fourPointNatMomentLower 132 110282 tail len distinct
  intro p hp
  by_cases h : p=0
  · subst p
    exact packedCertificate132_0
  · have he : p=1 := hp.resolve_left h
    subst p
    exact packedCertificate132_1

#print axioms max148_second132_fourPoint_moment_bound

end NineSeparatedSubsetSums
