import NineSeparatedSubsetSums.EightPoint132_120PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint132_120PackedAnchor1Part1 :
    ∀ j : Fin 120, 2277598 ≤ FourPointNumeric.octPackedCharge 132 120 20 packedOct132_120_1
      (2*((j.val : Int)+120)+1) := by decide +kernel

end NineSeparatedSubsetSums
