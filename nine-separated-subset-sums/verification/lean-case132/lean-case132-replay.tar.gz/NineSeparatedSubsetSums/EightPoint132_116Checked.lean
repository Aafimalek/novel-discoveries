import NineSeparatedSubsetSums.EightPointPackedGeometry
import NineSeparatedSubsetSums.EightPoint132_116PackedBudget0
import NineSeparatedSubsetSums.EightPoint132_116PackedAnchor0Part0
import NineSeparatedSubsetSums.EightPoint132_116PackedAnchor0Part1
import NineSeparatedSubsetSums.EightPoint132_116PackedBudget1
import NineSeparatedSubsetSums.EightPoint132_116PackedAnchor1Part0
import NineSeparatedSubsetSums.EightPoint132_116PackedAnchor1Part1

namespace NineSeparatedSubsetSums

private theorem packedOct132_116Anchor0 :
  ∀ j : Fin 469, ((j.val : Int)+132+116)%2=0 →
    2175488 ≤ FourPointNumeric.octPackedCharge 132 116 20 packedOct132_116_0 (j.val : Int) := by
  intro j hj
  let k := (j.val-0)/2
  have hk : k < 235 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+0 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint132_116PackedAnchor0Part0 z
    rwa [he,hrep] at ht
  let z : Fin 115 := ⟨k-120, by omega⟩
  have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
  have ht := eightPoint132_116PackedAnchor0Part1 z
  rwa [he,hrep] at ht

private theorem packedOct132_116Anchor1 :
  ∀ j : Fin 469, ((j.val : Int)+132+116)%2=1 →
    2172474 ≤ FourPointNumeric.octPackedCharge 132 116 20 packedOct132_116_1 (j.val : Int) := by
  intro j hj
  let k := (j.val-1)/2
  have hk : k < 234 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+1 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint132_116PackedAnchor1Part0 z
    rwa [he,hrep] at ht
  let z : Fin 114 := ⟨k-120, by omega⟩
  have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
  have ht := eightPoint132_116PackedAnchor1Part1 z
  rwa [he,hrep] at ht

def packedOctCertificate132_116_0 : EightPointCertificate 132 116 0 123477 :=
  eightPointCertificateOfPacked 132 116 0 123477 2175488 20 packedOct132_116_0 453 469
    (by decide +kernel) (by decide) packedOct132_116Anchor0
    (by rw [packedOct132_116_0_budget]; decide)

def packedOctCertificate132_116_1 : EightPointCertificate 132 116 1 123477 :=
  eightPointCertificateOfPacked 132 116 1 123477 2172474 20 packedOct132_116_1 414 469
    (by decide +kernel) (by decide) packedOct132_116Anchor1
    (by rw [packedOct132_116_1_budget]; decide)

theorem max148_second132_third116_eightPoint_moment_bound (tail : List ℕ) (len : tail.length=6)
    (distinct : (natSubsetSums (148::132::116::tail)).Nodup) :
    123477 ≤ ((148::132::116::tail).map (· ^ 2)).sum := by
  apply eightPointNatMomentLower 132 116 123477 tail len distinct
  intro p hp
  by_cases h : p=0
  · subst p
    exact packedOctCertificate132_116_0
  · have he : p=1 := hp.resolve_left h
    subst p
    exact packedOctCertificate132_116_1

#print axioms max148_second132_third116_eightPoint_moment_bound

end NineSeparatedSubsetSums
