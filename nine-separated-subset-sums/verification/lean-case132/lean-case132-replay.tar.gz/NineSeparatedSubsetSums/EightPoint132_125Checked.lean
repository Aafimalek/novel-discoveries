import NineSeparatedSubsetSums.EightPointPackedGeometry
import NineSeparatedSubsetSums.EightPoint132_125PackedBudget0
import NineSeparatedSubsetSums.EightPoint132_125PackedAnchor0Part0
import NineSeparatedSubsetSums.EightPoint132_125PackedAnchor0Part1
import NineSeparatedSubsetSums.EightPoint132_125PackedAnchor0Part2
import NineSeparatedSubsetSums.EightPoint132_125PackedBudget1
import NineSeparatedSubsetSums.EightPoint132_125PackedAnchor1Part0
import NineSeparatedSubsetSums.EightPoint132_125PackedAnchor1Part1
import NineSeparatedSubsetSums.EightPoint132_125PackedAnchor1Part2

namespace NineSeparatedSubsetSums

private theorem packedOct132_125Anchor0 :
  ∀ j : Fin 483, ((j.val : Int)+132+125)%2=0 →
    2300238 ≤ FourPointNumeric.octPackedCharge 132 125 20 packedOct132_125_0 (j.val : Int) := by
  intro j hj
  let k := (j.val-1)/2
  have hk : k < 241 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+1 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint132_125PackedAnchor0Part0 z
    rwa [he,hrep] at ht
  by_cases h1 : k < 240
  · let z : Fin 120 := ⟨k-120, by omega⟩
    have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
    have ht := eightPoint132_125PackedAnchor0Part1 z
    rwa [he,hrep] at ht
  let z : Fin 1 := ⟨k-240, by omega⟩
  have he : (z.val : Int)+240 = k := by dsimp [z] <;> omega
  have ht := eightPoint132_125PackedAnchor0Part2 z
  rwa [he,hrep] at ht

private theorem packedOct132_125Anchor1 :
  ∀ j : Fin 483, ((j.val : Int)+132+125)%2=1 →
    2301069 ≤ FourPointNumeric.octPackedCharge 132 125 20 packedOct132_125_1 (j.val : Int) := by
  intro j hj
  let k := (j.val-0)/2
  have hk : k < 242 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+0 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint132_125PackedAnchor1Part0 z
    rwa [he,hrep] at ht
  by_cases h1 : k < 240
  · let z : Fin 120 := ⟨k-120, by omega⟩
    have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
    have ht := eightPoint132_125PackedAnchor1Part1 z
    rwa [he,hrep] at ht
  let z : Fin 2 := ⟨k-240, by omega⟩
  have he : (z.val : Int)+240 = k := by dsimp [z] <;> omega
  have ht := eightPoint132_125PackedAnchor1Part2 z
  rwa [he,hrep] at ht

def packedOctCertificate132_125_0 : EightPointCertificate 132 125 0 125311 :=
  eightPointCertificateOfPacked 132 125 0 125311 2300238 20 packedOct132_125_0 397 483
    (by decide +kernel) (by decide) packedOct132_125Anchor0
    (by rw [packedOct132_125_0_budget]; decide)

def packedOctCertificate132_125_1 : EightPointCertificate 132 125 1 125311 :=
  eightPointCertificateOfPacked 132 125 1 125311 2301069 20 packedOct132_125_1 382 483
    (by decide +kernel) (by decide) packedOct132_125Anchor1
    (by rw [packedOct132_125_1_budget]; decide)

theorem max148_second132_third125_eightPoint_moment_bound (tail : List ℕ) (len : tail.length=6)
    (distinct : (natSubsetSums (148::132::125::tail)).Nodup) :
    125311 ≤ ((148::132::125::tail).map (· ^ 2)).sum := by
  apply eightPointNatMomentLower 132 125 125311 tail len distinct
  intro p hp
  by_cases h : p=0
  · subst p
    exact packedOctCertificate132_125_0
  · have he : p=1 := hp.resolve_left h
    subst p
    exact packedOctCertificate132_125_1

#print axioms max148_second132_third125_eightPoint_moment_bound

end NineSeparatedSubsetSums
