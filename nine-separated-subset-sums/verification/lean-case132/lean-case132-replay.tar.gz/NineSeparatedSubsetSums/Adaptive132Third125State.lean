import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive132Third125Node0 : CachedSearchNode :=
  ⟨4, 124, computeCenteredMask [148,132,125], 405, 54953⟩

end NineSeparatedSubsetSums
