import NineSeparatedSubsetSums.Adaptive132Third118State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive132Third118Proof0 : runCachedNode 511 123872 Adaptive132Third118Node0 = false := by
  decide +kernel

#print axioms adaptive132Third118Proof0

end NineSeparatedSubsetSums
