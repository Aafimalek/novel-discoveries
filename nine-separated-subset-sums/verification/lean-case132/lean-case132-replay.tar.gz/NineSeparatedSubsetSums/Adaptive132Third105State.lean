import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive132Third105Node0 : CachedSearchNode :=
  ⟨4, 104, computeCenteredMask [148,132,105], 385, 50353⟩

end NineSeparatedSubsetSums
