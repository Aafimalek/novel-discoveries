import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive132Third108Node0 : CachedSearchNode :=
  ⟨4, 107, computeCenteredMask [148,132,108], 388, 50992⟩

end NineSeparatedSubsetSums
