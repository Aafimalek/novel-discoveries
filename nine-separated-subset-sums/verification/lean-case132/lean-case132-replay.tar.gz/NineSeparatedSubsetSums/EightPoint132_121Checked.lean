import NineSeparatedSubsetSums.EightPointPackedGeometry
import NineSeparatedSubsetSums.EightPoint132_121PackedBudget0
import NineSeparatedSubsetSums.EightPoint132_121PackedAnchor0Part0
import NineSeparatedSubsetSums.EightPoint132_121PackedAnchor0Part1
import NineSeparatedSubsetSums.EightPoint132_121PackedAnchor0Part2
import NineSeparatedSubsetSums.EightPoint132_121PackedBudget1
import NineSeparatedSubsetSums.EightPoint132_121PackedAnchor1Part0
import NineSeparatedSubsetSums.EightPoint132_121PackedAnchor1Part1
import NineSeparatedSubsetSums.EightPoint132_121PackedAnchor1Part2

namespace NineSeparatedSubsetSums

private theorem packedOct132_121Anchor0 :
  ∀ j : Fin 485, ((j.val : Int)+132+121)%2=0 →
    2310287 ≤ FourPointNumeric.octPackedCharge 132 121 20 packedOct132_121_0 (j.val : Int) := by
  intro j hj
  let k := (j.val-1)/2
  have hk : k < 242 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+1 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint132_121PackedAnchor0Part0 z
    rwa [he,hrep] at ht
  by_cases h1 : k < 240
  · let z : Fin 120 := ⟨k-120, by omega⟩
    have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
    have ht := eightPoint132_121PackedAnchor0Part1 z
    rwa [he,hrep] at ht
  let z : Fin 2 := ⟨k-240, by omega⟩
  have he : (z.val : Int)+240 = k := by dsimp [z] <;> omega
  have ht := eightPoint132_121PackedAnchor0Part2 z
  rwa [he,hrep] at ht

private theorem packedOct132_121Anchor1 :
  ∀ j : Fin 485, ((j.val : Int)+132+121)%2=1 →
    2310415 ≤ FourPointNumeric.octPackedCharge 132 121 20 packedOct132_121_1 (j.val : Int) := by
  intro j hj
  let k := (j.val-0)/2
  have hk : k < 243 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+0 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint132_121PackedAnchor1Part0 z
    rwa [he,hrep] at ht
  by_cases h1 : k < 240
  · let z : Fin 120 := ⟨k-120, by omega⟩
    have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
    have ht := eightPoint132_121PackedAnchor1Part1 z
    rwa [he,hrep] at ht
  let z : Fin 3 := ⟨k-240, by omega⟩
  have he : (z.val : Int)+240 = k := by dsimp [z] <;> omega
  have ht := eightPoint132_121PackedAnchor1Part2 z
  rwa [he,hrep] at ht

def packedOctCertificate132_121_0 : EightPointCertificate 132 121 0 124181 :=
  eightPointCertificateOfPacked 132 121 0 124181 2310287 20 packedOct132_121_0 371 485
    (by decide +kernel) (by decide) packedOct132_121Anchor0
    (by rw [packedOct132_121_0_budget]; decide)

def packedOctCertificate132_121_1 : EightPointCertificate 132 121 1 124181 :=
  eightPointCertificateOfPacked 132 121 1 124181 2310415 20 packedOct132_121_1 370 485
    (by decide +kernel) (by decide) packedOct132_121Anchor1
    (by rw [packedOct132_121_1_budget]; decide)

theorem max148_second132_third121_eightPoint_moment_bound (tail : List ℕ) (len : tail.length=6)
    (distinct : (natSubsetSums (148::132::121::tail)).Nodup) :
    124181 ≤ ((148::132::121::tail).map (· ^ 2)).sum := by
  apply eightPointNatMomentLower 132 121 124181 tail len distinct
  intro p hp
  by_cases h : p=0
  · subst p
    exact packedOctCertificate132_121_0
  · have he : p=1 := hp.resolve_left h
    subst p
    exact packedOctCertificate132_121_1

#print axioms max148_second132_third121_eightPoint_moment_bound

end NineSeparatedSubsetSums
