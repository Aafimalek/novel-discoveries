import NineSeparatedSubsetSums.EightPointPackedGeometry
import NineSeparatedSubsetSums.EightPoint132_123PackedBudget0
import NineSeparatedSubsetSums.EightPoint132_123PackedAnchor0Part0
import NineSeparatedSubsetSums.EightPoint132_123PackedAnchor0Part1
import NineSeparatedSubsetSums.EightPoint132_123PackedBudget1
import NineSeparatedSubsetSums.EightPoint132_123PackedAnchor1Part0
import NineSeparatedSubsetSums.EightPoint132_123PackedAnchor1Part1

namespace NineSeparatedSubsetSums

private theorem packedOct132_123Anchor0 :
  ∀ j : Fin 480, ((j.val : Int)+132+123)%2=0 →
    2276616 ≤ FourPointNumeric.octPackedCharge 132 123 20 packedOct132_123_0 (j.val : Int) := by
  intro j hj
  let k := (j.val-1)/2
  have hk : k < 240 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+1 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint132_123PackedAnchor0Part0 z
    rwa [he,hrep] at ht
  let z : Fin 120 := ⟨k-120, by omega⟩
  have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
  have ht := eightPoint132_123PackedAnchor0Part1 z
  rwa [he,hrep] at ht

private theorem packedOct132_123Anchor1 :
  ∀ j : Fin 480, ((j.val : Int)+132+123)%2=1 →
    2275648 ≤ FourPointNumeric.octPackedCharge 132 123 20 packedOct132_123_1 (j.val : Int) := by
  intro j hj
  let k := (j.val-0)/2
  have hk : k < 240 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+0 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint132_123PackedAnchor1Part0 z
    rwa [he,hrep] at ht
  let z : Fin 120 := ⟨k-120, by omega⟩
  have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
  have ht := eightPoint132_123PackedAnchor1Part1 z
  rwa [he,hrep] at ht

def packedOctCertificate132_123_0 : EightPointCertificate 132 123 0 124755 :=
  eightPointCertificateOfPacked 132 123 0 124755 2276616 20 packedOct132_123_0 401 480
    (by decide +kernel) (by decide) packedOct132_123Anchor0
    (by rw [packedOct132_123_0_budget]; decide)

def packedOctCertificate132_123_1 : EightPointCertificate 132 123 1 124755 :=
  eightPointCertificateOfPacked 132 123 1 124755 2275648 20 packedOct132_123_1 400 480
    (by decide +kernel) (by decide) packedOct132_123Anchor1
    (by rw [packedOct132_123_1_budget]; decide)

theorem max148_second132_third123_eightPoint_moment_bound (tail : List ℕ) (len : tail.length=6)
    (distinct : (natSubsetSums (148::132::123::tail)).Nodup) :
    124755 ≤ ((148::132::123::tail).map (· ^ 2)).sum := by
  apply eightPointNatMomentLower 132 123 124755 tail len distinct
  intro p hp
  by_cases h : p=0
  · subst p
    exact packedOctCertificate132_123_0
  · have he : p=1 := hp.resolve_left h
    subst p
    exact packedOctCertificate132_123_1

#print axioms max148_second132_third123_eightPoint_moment_bound

end NineSeparatedSubsetSums
