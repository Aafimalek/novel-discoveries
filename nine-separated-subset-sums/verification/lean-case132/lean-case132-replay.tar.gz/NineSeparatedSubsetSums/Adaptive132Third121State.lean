import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive132Third121Node0 : CachedSearchNode :=
  ⟨4, 120, computeCenteredMask [148,132,121], 401, 53969⟩

end NineSeparatedSubsetSums
