import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive132Third106Node0 : CachedSearchNode :=
  ⟨4, 105, computeCenteredMask [148,132,106], 386, 50564⟩

end NineSeparatedSubsetSums
