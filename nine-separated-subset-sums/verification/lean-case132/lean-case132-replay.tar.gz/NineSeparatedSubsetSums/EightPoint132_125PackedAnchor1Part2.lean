import NineSeparatedSubsetSums.EightPoint132_125PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint132_125PackedAnchor1Part2 :
    ∀ j : Fin 2, 2301069 ≤ FourPointNumeric.octPackedCharge 132 125 20 packedOct132_125_1
      (2*((j.val : Int)+240)+0) := by decide +kernel

end NineSeparatedSubsetSums
