import NineSeparatedSubsetSums.Adaptive132Third127State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive132Third127Proof15 : runCachedNode 511 125773 Adaptive132Third127Node15 = false := by
  decide +kernel

#print axioms adaptive132Third127Proof15

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive132Third127Proof14 : runCachedNode 511 125773 Adaptive132Third127Node14 = false := by
  decide +kernel

#print axioms adaptive132Third127Proof14

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive132Third127Proof13 : runCachedNode 511 125773 Adaptive132Third127Node13 = false := by
  decide +kernel

#print axioms adaptive132Third127Proof13

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive132Third127Proof12 : runCachedNode 511 125773 Adaptive132Third127Node12 = false := by
  decide +kernel

#print axioms adaptive132Third127Proof12

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive132Third127Proof11 : runCachedNode 511 125773 Adaptive132Third127Node11 = false := by
  decide +kernel

#print axioms adaptive132Third127Proof11

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive132Third127Proof9 : runCachedNode 511 125773 Adaptive132Third127Node9 = false := by
  decide +kernel

#print axioms adaptive132Third127Proof9

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive132Third127Proof8 : runCachedNode 511 125773 Adaptive132Third127Node8 = false := by
  decide +kernel

#print axioms adaptive132Third127Proof8

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive132Third127Proof10 : runCachedNode 511 125773 Adaptive132Third127Node10 = false := by
  decide +kernel

#print axioms adaptive132Third127Proof10

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive132Third127Proof7 : runCachedNode 511 125773 Adaptive132Third127Node7 = false := by
  decide +kernel

#print axioms adaptive132Third127Proof7

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive132Third127Proof5 : runCachedNode 511 125773 Adaptive132Third127Node5 = false := by
  decide +kernel

#print axioms adaptive132Third127Proof5

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive132Third127Proof6 : runCachedNode 511 125773 Adaptive132Third127Node6 = false := by
  decide +kernel

#print axioms adaptive132Third127Proof6

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive132Third127Proof1 : runCachedNode 511 125773 Adaptive132Third127Node1 = false := by
  decide +kernel

#print axioms adaptive132Third127Proof1

end NineSeparatedSubsetSums
