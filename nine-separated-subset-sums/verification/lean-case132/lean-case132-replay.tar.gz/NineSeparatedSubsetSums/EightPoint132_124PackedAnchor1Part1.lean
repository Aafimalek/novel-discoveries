import NineSeparatedSubsetSums.EightPoint132_124PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint132_124PackedAnchor1Part1 :
    ∀ j : Fin 120, 2287688 ≤ FourPointNumeric.octPackedCharge 132 124 20 packedOct132_124_1
      (2*((j.val : Int)+120)+1) := by decide +kernel

end NineSeparatedSubsetSums
