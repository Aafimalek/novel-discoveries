import NineSeparatedSubsetSums.Adaptive132Third108Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint132Checked

namespace NineSeparatedSubsetSums


theorem adaptive132Third108 : NoDescendingTailAfterThird 132 108 :=
  noDescendingThirdTail_of_cached 132 108 110282 (fun t ht nd => max148_second132_fourPoint_moment_bound (108::t) (by simp [ht]) nd) adaptive132Third108Proof0

#print axioms adaptive132Third108

end NineSeparatedSubsetSums
