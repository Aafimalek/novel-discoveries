import NineSeparatedSubsetSums.EightPoint132_127PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint132_127PackedAnchor1Part2 :
    ∀ j : Fin 3, 2320310 ≤ FourPointNumeric.octPackedCharge 132 127 20 packedOct132_127_1
      (2*((j.val : Int)+240)+0) := by decide +kernel

end NineSeparatedSubsetSums
