import NineSeparatedSubsetSums.Adaptive132Third130State
import NineSeparatedSubsetSums.Adaptive132Third130Leaves1
import NineSeparatedSubsetSums.Adaptive132Third130Leaves0
import NineSeparatedSubsetSums.Adaptive132Third130Leaves2

namespace NineSeparatedSubsetSums

theorem adaptive132Third130Proof0 : runCachedNode 511 126232 Adaptive132Third130Node0 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 126232 Adaptive132Third130Node0 = [111, 112, 113, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive132Third130Proof1
  · exact adaptive132Third130Proof2
  · exact adaptive132Third130Proof3
  · exact adaptive132Third130Proof4
  · exact adaptive132Third130Proof5
  · exact adaptive132Third130Proof6
  · exact adaptive132Third130Proof7
  · exact adaptive132Third130Proof8
  · exact adaptive132Third130Proof9
  · exact adaptive132Third130Proof10
  · exact adaptive132Third130Proof11
  · exact adaptive132Third130Proof12
  · exact adaptive132Third130Proof13
  · exact adaptive132Third130Proof14
  · exact adaptive132Third130Proof15
  · exact adaptive132Third130Proof16
  · exact adaptive132Third130Proof17
  · exact adaptive132Third130Proof18

#print axioms adaptive132Third130Proof0

end NineSeparatedSubsetSums
