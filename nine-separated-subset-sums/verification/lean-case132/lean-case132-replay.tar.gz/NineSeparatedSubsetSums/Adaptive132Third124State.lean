import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive132Third124Node0 : CachedSearchNode :=
  ⟨4, 123, computeCenteredMask [148,132,124], 404, 54704⟩

end NineSeparatedSubsetSums
