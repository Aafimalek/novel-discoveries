import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive132Third115Node0 : CachedSearchNode :=
  ⟨4, 114, computeCenteredMask [148,132,115], 395, 52553⟩
def Adaptive132Third115Node1 : CachedSearchNode := cachedChild Adaptive132Third115Node0 101
def Adaptive132Third115Node2 : CachedSearchNode := cachedChild Adaptive132Third115Node0 102
def Adaptive132Third115Node3 : CachedSearchNode := cachedChild Adaptive132Third115Node0 103
def Adaptive132Third115Node4 : CachedSearchNode := cachedChild Adaptive132Third115Node0 104
def Adaptive132Third115Node5 : CachedSearchNode := cachedChild Adaptive132Third115Node0 105
def Adaptive132Third115Node6 : CachedSearchNode := cachedChild Adaptive132Third115Node0 106
def Adaptive132Third115Node7 : CachedSearchNode := cachedChild Adaptive132Third115Node0 107
def Adaptive132Third115Node8 : CachedSearchNode := cachedChild Adaptive132Third115Node0 108
def Adaptive132Third115Node9 : CachedSearchNode := cachedChild Adaptive132Third115Node0 109
def Adaptive132Third115Node10 : CachedSearchNode := cachedChild Adaptive132Third115Node0 110
def Adaptive132Third115Node11 : CachedSearchNode := cachedChild Adaptive132Third115Node0 111
def Adaptive132Third115Node12 : CachedSearchNode := cachedChild Adaptive132Third115Node0 112
def Adaptive132Third115Node13 : CachedSearchNode := cachedChild Adaptive132Third115Node0 113
def Adaptive132Third115Node14 : CachedSearchNode := cachedChild Adaptive132Third115Node0 114

end NineSeparatedSubsetSums
