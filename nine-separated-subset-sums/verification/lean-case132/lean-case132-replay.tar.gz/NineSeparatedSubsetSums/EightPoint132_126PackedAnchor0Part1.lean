import NineSeparatedSubsetSums.EightPoint132_126PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint132_126PackedAnchor0Part1 :
    ∀ j : Fin 120, 2308886 ≤ FourPointNumeric.octPackedCharge 132 126 20 packedOct132_126_0
      (2*((j.val : Int)+120)+0) := by decide +kernel

end NineSeparatedSubsetSums
