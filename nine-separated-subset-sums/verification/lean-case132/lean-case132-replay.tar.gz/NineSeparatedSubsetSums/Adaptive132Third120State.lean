import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive132Third120Node0 : CachedSearchNode :=
  ⟨4, 119, computeCenteredMask [148,132,120], 400, 53728⟩

end NineSeparatedSubsetSums
