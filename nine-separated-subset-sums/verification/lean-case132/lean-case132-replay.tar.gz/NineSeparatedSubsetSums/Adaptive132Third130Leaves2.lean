import NineSeparatedSubsetSums.Adaptive132Third130State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive132Third130Proof8 : runCachedNode 511 126232 Adaptive132Third130Node8 = false := by
  decide +kernel

#print axioms adaptive132Third130Proof8

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive132Third130Proof5 : runCachedNode 511 126232 Adaptive132Third130Node5 = false := by
  decide +kernel

#print axioms adaptive132Third130Proof5

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive132Third130Proof7 : runCachedNode 511 126232 Adaptive132Third130Node7 = false := by
  decide +kernel

#print axioms adaptive132Third130Proof7

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive132Third130Proof6 : runCachedNode 511 126232 Adaptive132Third130Node6 = false := by
  decide +kernel

#print axioms adaptive132Third130Proof6

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive132Third130Proof4 : runCachedNode 511 126232 Adaptive132Third130Node4 = false := by
  decide +kernel

#print axioms adaptive132Third130Proof4

end NineSeparatedSubsetSums
