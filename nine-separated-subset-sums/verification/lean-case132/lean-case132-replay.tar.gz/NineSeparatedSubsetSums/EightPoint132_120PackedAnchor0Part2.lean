import NineSeparatedSubsetSums.EightPoint132_120PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint132_120PackedAnchor0Part2 :
    ∀ j : Fin 1, 2279680 ≤ FourPointNumeric.octPackedCharge 132 120 20 packedOct132_120_0
      (2*((j.val : Int)+240)+0) := by decide +kernel

end NineSeparatedSubsetSums
