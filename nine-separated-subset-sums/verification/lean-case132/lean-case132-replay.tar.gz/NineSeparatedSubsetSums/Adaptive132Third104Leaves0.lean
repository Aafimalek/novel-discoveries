import NineSeparatedSubsetSums.Adaptive132Third104State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive132Third104Proof0 : runCachedNode 511 110282 Adaptive132Third104Node0 = false := by
  decide +kernel

#print axioms adaptive132Third104Proof0

end NineSeparatedSubsetSums
