import NineSeparatedSubsetSums.Adaptive132Third129State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive132Third129Proof13 : runCachedNode 511 126048 Adaptive132Third129Node13 = false := by
  decide +kernel

#print axioms adaptive132Third129Proof13

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive132Third129Proof12 : runCachedNode 511 126048 Adaptive132Third129Node12 = false := by
  decide +kernel

#print axioms adaptive132Third129Proof12

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive132Third129Proof11 : runCachedNode 511 126048 Adaptive132Third129Node11 = false := by
  decide +kernel

#print axioms adaptive132Third129Proof11

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive132Third129Proof10 : runCachedNode 511 126048 Adaptive132Third129Node10 = false := by
  decide +kernel

#print axioms adaptive132Third129Proof10

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive132Third129Proof9 : runCachedNode 511 126048 Adaptive132Third129Node9 = false := by
  decide +kernel

#print axioms adaptive132Third129Proof9

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive132Third129Proof7 : runCachedNode 511 126048 Adaptive132Third129Node7 = false := by
  decide +kernel

#print axioms adaptive132Third129Proof7

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive132Third129Proof8 : runCachedNode 511 126048 Adaptive132Third129Node8 = false := by
  decide +kernel

#print axioms adaptive132Third129Proof8

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive132Third129Proof5 : runCachedNode 511 126048 Adaptive132Third129Node5 = false := by
  decide +kernel

#print axioms adaptive132Third129Proof5

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive132Third129Proof6 : runCachedNode 511 126048 Adaptive132Third129Node6 = false := by
  decide +kernel

#print axioms adaptive132Third129Proof6

end NineSeparatedSubsetSums
