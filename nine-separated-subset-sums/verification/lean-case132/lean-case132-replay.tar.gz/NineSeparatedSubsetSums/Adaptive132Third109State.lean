import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive132Third109Node0 : CachedSearchNode :=
  ⟨4, 108, computeCenteredMask [148,132,109], 389, 51209⟩

end NineSeparatedSubsetSums
