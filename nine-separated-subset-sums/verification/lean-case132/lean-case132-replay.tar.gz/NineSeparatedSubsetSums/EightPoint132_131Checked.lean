import NineSeparatedSubsetSums.EightPointPackedGeometry
import NineSeparatedSubsetSums.EightPoint132_131PackedBudget0
import NineSeparatedSubsetSums.EightPoint132_131PackedAnchor0Part0
import NineSeparatedSubsetSums.EightPoint132_131PackedAnchor0Part1
import NineSeparatedSubsetSums.EightPoint132_131PackedAnchor0Part2
import NineSeparatedSubsetSums.EightPoint132_131PackedBudget1
import NineSeparatedSubsetSums.EightPoint132_131PackedAnchor1Part0
import NineSeparatedSubsetSums.EightPoint132_131PackedAnchor1Part1
import NineSeparatedSubsetSums.EightPoint132_131PackedAnchor1Part2

namespace NineSeparatedSubsetSums

private theorem packedOct132_131Anchor0 :
  ∀ j : Fin 490, ((j.val : Int)+132+131)%2=0 →
    2370600 ≤ FourPointNumeric.octPackedCharge 132 131 20 packedOct132_131_0 (j.val : Int) := by
  intro j hj
  let k := (j.val-1)/2
  have hk : k < 245 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+1 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint132_131PackedAnchor0Part0 z
    rwa [he,hrep] at ht
  by_cases h1 : k < 240
  · let z : Fin 120 := ⟨k-120, by omega⟩
    have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
    have ht := eightPoint132_131PackedAnchor0Part1 z
    rwa [he,hrep] at ht
  let z : Fin 5 := ⟨k-240, by omega⟩
  have he : (z.val : Int)+240 = k := by dsimp [z] <;> omega
  have ht := eightPoint132_131PackedAnchor0Part2 z
  rwa [he,hrep] at ht

private theorem packedOct132_131Anchor1 :
  ∀ j : Fin 490, ((j.val : Int)+132+131)%2=1 →
    2369723 ≤ FourPointNumeric.octPackedCharge 132 131 20 packedOct132_131_1 (j.val : Int) := by
  intro j hj
  let k := (j.val-0)/2
  have hk : k < 245 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+0 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint132_131PackedAnchor1Part0 z
    rwa [he,hrep] at ht
  by_cases h1 : k < 240
  · let z : Fin 120 := ⟨k-120, by omega⟩
    have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
    have ht := eightPoint132_131PackedAnchor1Part1 z
    rwa [he,hrep] at ht
  let z : Fin 5 := ⟨k-240, by omega⟩
  have he : (z.val : Int)+240 = k := by dsimp [z] <;> omega
  have ht := eightPoint132_131PackedAnchor1Part2 z
  rwa [he,hrep] at ht

def packedOctCertificate132_131_0 : EightPointCertificate 132 131 0 126429 :=
  eightPointCertificateOfPacked 132 131 0 126429 2370600 20 packedOct132_131_0 375 490
    (by decide +kernel) (by decide) packedOct132_131Anchor0
    (by rw [packedOct132_131_0_budget]; decide)

def packedOctCertificate132_131_1 : EightPointCertificate 132 131 1 126429 :=
  eightPointCertificateOfPacked 132 131 1 126429 2369723 20 packedOct132_131_1 440 490
    (by decide +kernel) (by decide) packedOct132_131Anchor1
    (by rw [packedOct132_131_1_budget]; decide)

theorem max148_second132_third131_eightPoint_moment_bound (tail : List ℕ) (len : tail.length=6)
    (distinct : (natSubsetSums (148::132::131::tail)).Nodup) :
    126429 ≤ ((148::132::131::tail).map (· ^ 2)).sum := by
  apply eightPointNatMomentLower 132 131 126429 tail len distinct
  intro p hp
  by_cases h : p=0
  · subst p
    exact packedOctCertificate132_131_0
  · have he : p=1 := hp.resolve_left h
    subst p
    exact packedOctCertificate132_131_1

#print axioms max148_second132_third131_eightPoint_moment_bound

end NineSeparatedSubsetSums
