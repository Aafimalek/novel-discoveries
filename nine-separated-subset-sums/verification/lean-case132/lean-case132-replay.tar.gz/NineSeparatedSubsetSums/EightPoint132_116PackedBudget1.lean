import NineSeparatedSubsetSums.EightPoint132_116PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct132_116_1_budget :
    FourPointNumeric.packedBudget 20 packedOct132_116_1 414 = 75818202 := by decide +kernel

#print axioms packedOct132_116_1_budget

end NineSeparatedSubsetSums
