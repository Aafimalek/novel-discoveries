import NineSeparatedSubsetSums.EightPoint132_131PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint132_131PackedAnchor1Part0 :
    ∀ j : Fin 120, 2369723 ≤ FourPointNumeric.octPackedCharge 132 131 20 packedOct132_131_1
      (2*((j.val : Int)+0)+0) := by decide +kernel

end NineSeparatedSubsetSums
