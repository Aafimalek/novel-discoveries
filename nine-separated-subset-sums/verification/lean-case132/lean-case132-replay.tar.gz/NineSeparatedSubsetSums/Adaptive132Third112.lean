import NineSeparatedSubsetSums.Adaptive132Third112Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint132Checked

namespace NineSeparatedSubsetSums


theorem adaptive132Third112 : NoDescendingTailAfterThird 132 112 :=
  noDescendingThirdTail_of_cached 132 112 110282 (fun t ht nd => max148_second132_fourPoint_moment_bound (112::t) (by simp [ht]) nd) adaptive132Third112Proof0

#print axioms adaptive132Third112

end NineSeparatedSubsetSums
