import NineSeparatedSubsetSums.EightPointPackedGeometry
import NineSeparatedSubsetSums.EightPoint132_119PackedBudget0
import NineSeparatedSubsetSums.EightPoint132_119PackedAnchor0Part0
import NineSeparatedSubsetSums.EightPoint132_119PackedAnchor0Part1
import NineSeparatedSubsetSums.EightPoint132_119PackedBudget1
import NineSeparatedSubsetSums.EightPoint132_119PackedAnchor1Part0
import NineSeparatedSubsetSums.EightPoint132_119PackedAnchor1Part1

namespace NineSeparatedSubsetSums

private theorem packedOct132_119Anchor0 :
  ∀ j : Fin 478, ((j.val : Int)+132+119)%2=0 →
    2253119 ≤ FourPointNumeric.octPackedCharge 132 119 20 packedOct132_119_0 (j.val : Int) := by
  intro j hj
  let k := (j.val-1)/2
  have hk : k < 239 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+1 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint132_119PackedAnchor0Part0 z
    rwa [he,hrep] at ht
  let z : Fin 119 := ⟨k-120, by omega⟩
  have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
  have ht := eightPoint132_119PackedAnchor0Part1 z
  rwa [he,hrep] at ht

private theorem packedOct132_119Anchor1 :
  ∀ j : Fin 478, ((j.val : Int)+132+119)%2=1 →
    2253294 ≤ FourPointNumeric.octPackedCharge 132 119 20 packedOct132_119_1 (j.val : Int) := by
  intro j hj
  let k := (j.val-0)/2
  have hk : k < 239 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+0 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint132_119PackedAnchor1Part0 z
    rwa [he,hrep] at ht
  let z : Fin 119 := ⟨k-120, by omega⟩
  have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
  have ht := eightPoint132_119PackedAnchor1Part1 z
  rwa [he,hrep] at ht

def packedOctCertificate132_119_0 : EightPointCertificate 132 119 0 124061 :=
  eightPointCertificateOfPacked 132 119 0 124061 2253119 20 packedOct132_119_0 377 478
    (by decide +kernel) (by decide) packedOct132_119Anchor0
    (by rw [packedOct132_119_0_budget]; decide)

def packedOctCertificate132_119_1 : EightPointCertificate 132 119 1 124061 :=
  eightPointCertificateOfPacked 132 119 1 124061 2253294 20 packedOct132_119_1 376 478
    (by decide +kernel) (by decide) packedOct132_119Anchor1
    (by rw [packedOct132_119_1_budget]; decide)

theorem max148_second132_third119_eightPoint_moment_bound (tail : List ℕ) (len : tail.length=6)
    (distinct : (natSubsetSums (148::132::119::tail)).Nodup) :
    124061 ≤ ((148::132::119::tail).map (· ^ 2)).sum := by
  apply eightPointNatMomentLower 132 119 124061 tail len distinct
  intro p hp
  by_cases h : p=0
  · subst p
    exact packedOctCertificate132_119_0
  · have he : p=1 := hp.resolve_left h
    subst p
    exact packedOctCertificate132_119_1

#print axioms max148_second132_third119_eightPoint_moment_bound

end NineSeparatedSubsetSums
