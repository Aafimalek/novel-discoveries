import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive132Third118Node0 : CachedSearchNode :=
  ⟨4, 117, computeCenteredMask [148,132,118], 398, 53252⟩

end NineSeparatedSubsetSums
