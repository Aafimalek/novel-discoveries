import NineSeparatedSubsetSums.EightPoint132_117PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint132_117PackedAnchor1Part1 :
    ∀ j : Fin 115, 2179128 ≤ FourPointNumeric.octPackedCharge 132 117 20 packedOct132_117_1
      (2*((j.val : Int)+120)+0) := by decide +kernel

end NineSeparatedSubsetSums
