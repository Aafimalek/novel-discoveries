import NineSeparatedSubsetSums.EightPoint132_119PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct132_119_1_budget :
    FourPointNumeric.packedBudget 20 packedOct132_119_1 376 = 80691848 := by decide +kernel

#print axioms packedOct132_119_1_budget

end NineSeparatedSubsetSums
