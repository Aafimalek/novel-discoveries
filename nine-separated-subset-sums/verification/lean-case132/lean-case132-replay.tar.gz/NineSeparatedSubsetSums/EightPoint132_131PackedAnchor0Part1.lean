import NineSeparatedSubsetSums.EightPoint132_131PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint132_131PackedAnchor0Part1 :
    ∀ j : Fin 120, 2370600 ≤ FourPointNumeric.octPackedCharge 132 131 20 packedOct132_131_0
      (2*((j.val : Int)+120)+1) := by decide +kernel

end NineSeparatedSubsetSums
