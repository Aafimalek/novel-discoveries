import NineSeparatedSubsetSums.Adaptive132Third130State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive132Third130Proof16 : runCachedNode 511 126232 Adaptive132Third130Node16 = false := by
  decide +kernel

#print axioms adaptive132Third130Proof16

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive132Third130Proof15 : runCachedNode 511 126232 Adaptive132Third130Node15 = false := by
  decide +kernel

#print axioms adaptive132Third130Proof15

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive132Third130Proof14 : runCachedNode 511 126232 Adaptive132Third130Node14 = false := by
  decide +kernel

#print axioms adaptive132Third130Proof14

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive132Third130Proof13 : runCachedNode 511 126232 Adaptive132Third130Node13 = false := by
  decide +kernel

#print axioms adaptive132Third130Proof13

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive132Third130Proof12 : runCachedNode 511 126232 Adaptive132Third130Node12 = false := by
  decide +kernel

#print axioms adaptive132Third130Proof12

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive132Third130Proof10 : runCachedNode 511 126232 Adaptive132Third130Node10 = false := by
  decide +kernel

#print axioms adaptive132Third130Proof10

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive132Third130Proof9 : runCachedNode 511 126232 Adaptive132Third130Node9 = false := by
  decide +kernel

#print axioms adaptive132Third130Proof9

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive132Third130Proof3 : runCachedNode 511 126232 Adaptive132Third130Node3 = false := by
  decide +kernel

#print axioms adaptive132Third130Proof3

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive132Third130Proof1 : runCachedNode 511 126232 Adaptive132Third130Node1 = false := by
  decide +kernel

#print axioms adaptive132Third130Proof1

end NineSeparatedSubsetSums
