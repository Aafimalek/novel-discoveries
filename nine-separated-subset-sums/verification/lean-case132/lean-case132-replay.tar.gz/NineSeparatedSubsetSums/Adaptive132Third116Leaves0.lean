import NineSeparatedSubsetSums.Adaptive132Third116State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive132Third116Proof0 : runCachedNode 511 123477 Adaptive132Third116Node0 = false := by
  decide +kernel

#print axioms adaptive132Third116Proof0

end NineSeparatedSubsetSums
