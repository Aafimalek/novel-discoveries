import NineSeparatedSubsetSums.EightPoint132_123PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct132_123_0_budget :
    FourPointNumeric.packedBudget 20 packedOct132_123_0 401 = 81829028 := by decide +kernel

#print axioms packedOct132_123_0_budget

end NineSeparatedSubsetSums
