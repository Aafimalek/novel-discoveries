import NineSeparatedSubsetSums.Adaptive132Third124State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive132Third124Proof0 : runCachedNode 511 125021 Adaptive132Third124Node0 = false := by
  decide +kernel

#print axioms adaptive132Third124Proof0

end NineSeparatedSubsetSums
