import NineSeparatedSubsetSums.Adaptive132Third106State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive132Third106Proof0 : runCachedNode 511 110282 Adaptive132Third106Node0 = false := by
  decide +kernel

#print axioms adaptive132Third106Proof0

end NineSeparatedSubsetSums
