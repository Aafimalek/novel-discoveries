import NineSeparatedSubsetSums.Adaptive132Third128State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive132Third128Proof16 : runCachedNode 511 125907 Adaptive132Third128Node16 = false := by
  decide +kernel

#print axioms adaptive132Third128Proof16

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive132Third128Proof15 : runCachedNode 511 125907 Adaptive132Third128Node15 = false := by
  decide +kernel

#print axioms adaptive132Third128Proof15

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive132Third128Proof13 : runCachedNode 511 125907 Adaptive132Third128Node13 = false := by
  decide +kernel

#print axioms adaptive132Third128Proof13

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive132Third128Proof14 : runCachedNode 511 125907 Adaptive132Third128Node14 = false := by
  decide +kernel

#print axioms adaptive132Third128Proof14

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive132Third128Proof12 : runCachedNode 511 125907 Adaptive132Third128Node12 = false := by
  decide +kernel

#print axioms adaptive132Third128Proof12

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive132Third128Proof10 : runCachedNode 511 125907 Adaptive132Third128Node10 = false := by
  decide +kernel

#print axioms adaptive132Third128Proof10

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive132Third128Proof4 : runCachedNode 511 125907 Adaptive132Third128Node4 = false := by
  decide +kernel

#print axioms adaptive132Third128Proof4

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive132Third128Proof3 : runCachedNode 511 125907 Adaptive132Third128Node3 = false := by
  decide +kernel

#print axioms adaptive132Third128Proof3

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive132Third128Proof1 : runCachedNode 511 125907 Adaptive132Third128Node1 = false := by
  decide +kernel

#print axioms adaptive132Third128Proof1

end NineSeparatedSubsetSums
