import NineSeparatedSubsetSums.EightPoint132_122PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint132_122PackedAnchor1Part0 :
    ∀ j : Fin 120, 2262237 ≤ FourPointNumeric.octPackedCharge 132 122 20 packedOct132_122_1
      (2*((j.val : Int)+0)+1) := by decide +kernel

end NineSeparatedSubsetSums
