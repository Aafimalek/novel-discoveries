import NineSeparatedSubsetSums.Adaptive132Third131State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive132Third131Proof19 : runCachedNode 511 126429 Adaptive132Third131Node19 = false := by
  decide +kernel

#print axioms adaptive132Third131Proof19

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive132Third131Proof16 : runCachedNode 511 126429 Adaptive132Third131Node16 = false := by
  decide +kernel

#print axioms adaptive132Third131Proof16

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive132Third131Proof5 : runCachedNode 511 126429 Adaptive132Third131Node5 = false := by
  decide +kernel

#print axioms adaptive132Third131Proof5

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive132Third131Proof4 : runCachedNode 511 126429 Adaptive132Third131Node4 = false := by
  decide +kernel

#print axioms adaptive132Third131Proof4

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive132Third131Proof1 : runCachedNode 511 126429 Adaptive132Third131Node1 = false := by
  decide +kernel

#print axioms adaptive132Third131Proof1

end NineSeparatedSubsetSums
