import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive132Third117Node0 : CachedSearchNode :=
  ⟨4, 116, computeCenteredMask [148,132,117], 397, 53017⟩

end NineSeparatedSubsetSums
