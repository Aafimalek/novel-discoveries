import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive132Third113Node0 : CachedSearchNode :=
  ⟨4, 112, computeCenteredMask [148,132,113], 393, 52097⟩

end NineSeparatedSubsetSums
