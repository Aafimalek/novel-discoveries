import NineSeparatedSubsetSums.Adaptive132Third131State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive132Third131Proof18 : runCachedNode 511 126429 Adaptive132Third131Node18 = false := by
  decide +kernel

#print axioms adaptive132Third131Proof18

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive132Third131Proof17 : runCachedNode 511 126429 Adaptive132Third131Node17 = false := by
  decide +kernel

#print axioms adaptive132Third131Proof17

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive132Third131Proof15 : runCachedNode 511 126429 Adaptive132Third131Node15 = false := by
  decide +kernel

#print axioms adaptive132Third131Proof15

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive132Third131Proof14 : runCachedNode 511 126429 Adaptive132Third131Node14 = false := by
  decide +kernel

#print axioms adaptive132Third131Proof14

end NineSeparatedSubsetSums
