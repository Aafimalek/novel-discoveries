import NineSeparatedSubsetSums.EightPointPackedGeometry
import NineSeparatedSubsetSums.EightPoint132_117PackedBudget0
import NineSeparatedSubsetSums.EightPoint132_117PackedAnchor0Part0
import NineSeparatedSubsetSums.EightPoint132_117PackedAnchor0Part1
import NineSeparatedSubsetSums.EightPoint132_117PackedBudget1
import NineSeparatedSubsetSums.EightPoint132_117PackedAnchor1Part0
import NineSeparatedSubsetSums.EightPoint132_117PackedAnchor1Part1

namespace NineSeparatedSubsetSums

private theorem packedOct132_117Anchor0 :
  ∀ j : Fin 469, ((j.val : Int)+132+117)%2=0 →
    2180260 ≤ FourPointNumeric.octPackedCharge 132 117 20 packedOct132_117_0 (j.val : Int) := by
  intro j hj
  let k := (j.val-1)/2
  have hk : k < 234 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+1 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint132_117PackedAnchor0Part0 z
    rwa [he,hrep] at ht
  let z : Fin 114 := ⟨k-120, by omega⟩
  have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
  have ht := eightPoint132_117PackedAnchor0Part1 z
  rwa [he,hrep] at ht

private theorem packedOct132_117Anchor1 :
  ∀ j : Fin 469, ((j.val : Int)+132+117)%2=1 →
    2179128 ≤ FourPointNumeric.octPackedCharge 132 117 20 packedOct132_117_1 (j.val : Int) := by
  intro j hj
  let k := (j.val-0)/2
  have hk : k < 235 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+0 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint132_117PackedAnchor1Part0 z
    rwa [he,hrep] at ht
  let z : Fin 115 := ⟨k-120, by omega⟩
  have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
  have ht := eightPoint132_117PackedAnchor1Part1 z
  rwa [he,hrep] at ht

def packedOctCertificate132_117_0 : EightPointCertificate 132 117 0 123740 :=
  eightPointCertificateOfPacked 132 117 0 123740 2180260 20 packedOct132_117_0 463 469
    (by decide +kernel) (by decide) packedOct132_117Anchor0
    (by rw [packedOct132_117_0_budget]; decide)

def packedOctCertificate132_117_1 : EightPointCertificate 132 117 1 123740 :=
  eightPointCertificateOfPacked 132 117 1 123740 2179128 20 packedOct132_117_1 396 469
    (by decide +kernel) (by decide) packedOct132_117Anchor1
    (by rw [packedOct132_117_1_budget]; decide)

theorem max148_second132_third117_eightPoint_moment_bound (tail : List ℕ) (len : tail.length=6)
    (distinct : (natSubsetSums (148::132::117::tail)).Nodup) :
    123740 ≤ ((148::132::117::tail).map (· ^ 2)).sum := by
  apply eightPointNatMomentLower 132 117 123740 tail len distinct
  intro p hp
  by_cases h : p=0
  · subst p
    exact packedOctCertificate132_117_0
  · have he : p=1 := hp.resolve_left h
    subst p
    exact packedOctCertificate132_117_1

#print axioms max148_second132_third117_eightPoint_moment_bound

end NineSeparatedSubsetSums
