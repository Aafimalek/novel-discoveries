import NineSeparatedSubsetSums.EightPoint132_129PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint132_129PackedAnchor0Part2 :
    ∀ j : Fin 3, 2336545 ≤ FourPointNumeric.octPackedCharge 132 129 20 packedOct132_129_0
      (2*((j.val : Int)+240)+1) := by decide +kernel

end NineSeparatedSubsetSums
