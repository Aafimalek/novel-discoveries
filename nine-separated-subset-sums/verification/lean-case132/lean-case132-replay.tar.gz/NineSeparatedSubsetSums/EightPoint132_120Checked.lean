import NineSeparatedSubsetSums.EightPointPackedGeometry
import NineSeparatedSubsetSums.EightPoint132_120PackedBudget0
import NineSeparatedSubsetSums.EightPoint132_120PackedAnchor0Part0
import NineSeparatedSubsetSums.EightPoint132_120PackedAnchor0Part1
import NineSeparatedSubsetSums.EightPoint132_120PackedAnchor0Part2
import NineSeparatedSubsetSums.EightPoint132_120PackedBudget1
import NineSeparatedSubsetSums.EightPoint132_120PackedAnchor1Part0
import NineSeparatedSubsetSums.EightPoint132_120PackedAnchor1Part1

namespace NineSeparatedSubsetSums

private theorem packedOct132_120Anchor0 :
  ∀ j : Fin 481, ((j.val : Int)+132+120)%2=0 →
    2279680 ≤ FourPointNumeric.octPackedCharge 132 120 20 packedOct132_120_0 (j.val : Int) := by
  intro j hj
  let k := (j.val-0)/2
  have hk : k < 241 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+0 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint132_120PackedAnchor0Part0 z
    rwa [he,hrep] at ht
  by_cases h1 : k < 240
  · let z : Fin 120 := ⟨k-120, by omega⟩
    have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
    have ht := eightPoint132_120PackedAnchor0Part1 z
    rwa [he,hrep] at ht
  let z : Fin 1 := ⟨k-240, by omega⟩
  have he : (z.val : Int)+240 = k := by dsimp [z] <;> omega
  have ht := eightPoint132_120PackedAnchor0Part2 z
  rwa [he,hrep] at ht

private theorem packedOct132_120Anchor1 :
  ∀ j : Fin 481, ((j.val : Int)+132+120)%2=1 →
    2277598 ≤ FourPointNumeric.octPackedCharge 132 120 20 packedOct132_120_1 (j.val : Int) := by
  intro j hj
  let k := (j.val-1)/2
  have hk : k < 240 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+1 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint132_120PackedAnchor1Part0 z
    rwa [he,hrep] at ht
  let z : Fin 120 := ⟨k-120, by omega⟩
  have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
  have ht := eightPoint132_120PackedAnchor1Part1 z
  rwa [he,hrep] at ht

def packedOctCertificate132_120_0 : EightPointCertificate 132 120 0 124235 :=
  eightPointCertificateOfPacked 132 120 0 124235 2279680 20 packedOct132_120_0 391 481
    (by decide +kernel) (by decide) packedOct132_120Anchor0
    (by rw [packedOct132_120_0_budget]; decide)

def packedOctCertificate132_120_1 : EightPointCertificate 132 120 1 124235 :=
  eightPointCertificateOfPacked 132 120 1 124235 2277598 20 packedOct132_120_1 390 481
    (by decide +kernel) (by decide) packedOct132_120Anchor1
    (by rw [packedOct132_120_1_budget]; decide)

theorem max148_second132_third120_eightPoint_moment_bound (tail : List ℕ) (len : tail.length=6)
    (distinct : (natSubsetSums (148::132::120::tail)).Nodup) :
    124235 ≤ ((148::132::120::tail).map (· ^ 2)).sum := by
  apply eightPointNatMomentLower 132 120 124235 tail len distinct
  intro p hp
  by_cases h : p=0
  · subst p
    exact packedOctCertificate132_120_0
  · have he : p=1 := hp.resolve_left h
    subst p
    exact packedOctCertificate132_120_1

#print axioms max148_second132_third120_eightPoint_moment_bound

end NineSeparatedSubsetSums
