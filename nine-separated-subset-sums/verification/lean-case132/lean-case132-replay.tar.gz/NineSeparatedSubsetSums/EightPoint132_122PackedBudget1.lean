import NineSeparatedSubsetSums.EightPoint132_122PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct132_122_1_budget :
    FourPointNumeric.packedBudget 20 packedOct132_122_1 386 = 81059684 := by decide +kernel

#print axioms packedOct132_122_1_budget

end NineSeparatedSubsetSums
