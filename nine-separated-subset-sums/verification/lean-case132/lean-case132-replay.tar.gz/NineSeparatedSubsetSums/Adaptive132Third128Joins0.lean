import NineSeparatedSubsetSums.Adaptive132Third128State
import NineSeparatedSubsetSums.Adaptive132Third128Leaves0
import NineSeparatedSubsetSums.Adaptive132Third128Leaves1

namespace NineSeparatedSubsetSums

theorem adaptive132Third128Proof0 : runCachedNode 511 125907 Adaptive132Third128Node0 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 125907 Adaptive132Third128Node0 = [111, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive132Third128Proof1
  · exact adaptive132Third128Proof2
  · exact adaptive132Third128Proof3
  · exact adaptive132Third128Proof4
  · exact adaptive132Third128Proof5
  · exact adaptive132Third128Proof6
  · exact adaptive132Third128Proof7
  · exact adaptive132Third128Proof8
  · exact adaptive132Third128Proof9
  · exact adaptive132Third128Proof10
  · exact adaptive132Third128Proof11
  · exact adaptive132Third128Proof12
  · exact adaptive132Third128Proof13
  · exact adaptive132Third128Proof14
  · exact adaptive132Third128Proof15
  · exact adaptive132Third128Proof16

#print axioms adaptive132Third128Proof0

end NineSeparatedSubsetSums
