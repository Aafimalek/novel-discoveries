import NineSeparatedSubsetSums.Adaptive132Third110Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint132Checked

namespace NineSeparatedSubsetSums


theorem adaptive132Third110 : NoDescendingTailAfterThird 132 110 :=
  noDescendingThirdTail_of_cached 132 110 110282 (fun t ht nd => max148_second132_fourPoint_moment_bound (110::t) (by simp [ht]) nd) adaptive132Third110Proof0

#print axioms adaptive132Third110

end NineSeparatedSubsetSums
