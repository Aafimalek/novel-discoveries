import NineSeparatedSubsetSums.Adaptive132Third122State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive132Third122Proof0 : runCachedNode 511 124460 Adaptive132Third122Node0 = false := by
  decide +kernel

#print axioms adaptive132Third122Proof0

end NineSeparatedSubsetSums
