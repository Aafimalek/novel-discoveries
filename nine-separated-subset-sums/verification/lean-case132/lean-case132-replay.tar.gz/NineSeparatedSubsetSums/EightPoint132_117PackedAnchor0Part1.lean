import NineSeparatedSubsetSums.EightPoint132_117PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint132_117PackedAnchor0Part1 :
    ∀ j : Fin 114, 2180260 ≤ FourPointNumeric.octPackedCharge 132 117 20 packedOct132_117_0
      (2*((j.val : Int)+120)+1) := by decide +kernel

end NineSeparatedSubsetSums
