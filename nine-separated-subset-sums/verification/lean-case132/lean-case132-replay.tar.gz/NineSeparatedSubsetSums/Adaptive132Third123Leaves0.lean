import NineSeparatedSubsetSums.Adaptive132Third123State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive132Third123Proof0 : runCachedNode 511 124755 Adaptive132Third123Node0 = false := by
  decide +kernel

#print axioms adaptive132Third123Proof0

end NineSeparatedSubsetSums
