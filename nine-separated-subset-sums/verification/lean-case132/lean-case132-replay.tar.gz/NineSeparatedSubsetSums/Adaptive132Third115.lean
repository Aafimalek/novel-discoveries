import NineSeparatedSubsetSums.Adaptive132Third115Joins0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint132Checked

namespace NineSeparatedSubsetSums


theorem adaptive132Third115 : NoDescendingTailAfterThird 132 115 :=
  noDescendingThirdTail_of_cached 132 115 110282 (fun t ht nd => max148_second132_fourPoint_moment_bound (115::t) (by simp [ht]) nd) adaptive132Third115Proof0

#print axioms adaptive132Third115

end NineSeparatedSubsetSums
