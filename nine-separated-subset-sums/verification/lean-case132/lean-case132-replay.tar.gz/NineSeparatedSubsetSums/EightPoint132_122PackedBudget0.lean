import NineSeparatedSubsetSums.EightPoint132_122PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct132_122_0_budget :
    FourPointNumeric.packedBudget 20 packedOct132_122_0 387 = 81006021 := by decide +kernel

#print axioms packedOct132_122_0_budget

end NineSeparatedSubsetSums
