import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive132Third104Node0 : CachedSearchNode :=
  ⟨4, 103, computeCenteredMask [148,132,104], 384, 50144⟩

end NineSeparatedSubsetSums
