import NineSeparatedSubsetSums.EightPoint132_117PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct132_117_0_budget :
    FourPointNumeric.packedBudget 20 packedOct132_117_0 463 = 76181712 := by decide +kernel

#print axioms packedOct132_117_0_budget

end NineSeparatedSubsetSums
