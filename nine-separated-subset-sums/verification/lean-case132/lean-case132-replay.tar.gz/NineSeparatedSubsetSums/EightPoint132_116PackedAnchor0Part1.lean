import NineSeparatedSubsetSums.EightPoint132_116PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint132_116PackedAnchor0Part1 :
    ∀ j : Fin 115, 2175488 ≤ FourPointNumeric.octPackedCharge 132 116 20 packedOct132_116_0
      (2*((j.val : Int)+120)+0) := by decide +kernel

end NineSeparatedSubsetSums
