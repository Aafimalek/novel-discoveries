import NineSeparatedSubsetSums.Adaptive132Third104Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint132Checked

namespace NineSeparatedSubsetSums


theorem adaptive132Third104 : NoDescendingTailAfterThird 132 104 :=
  noDescendingThirdTail_of_cached 132 104 110282 (fun t ht nd => max148_second132_fourPoint_moment_bound (104::t) (by simp [ht]) nd) adaptive132Third104Proof0

#print axioms adaptive132Third104

end NineSeparatedSubsetSums
