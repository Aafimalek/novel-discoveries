import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive132Third119Node0 : CachedSearchNode :=
  ⟨4, 118, computeCenteredMask [148,132,119], 399, 53489⟩

end NineSeparatedSubsetSums
