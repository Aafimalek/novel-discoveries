import NineSeparatedSubsetSums.EightPoint132_127PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct132_127_0_budget :
    FourPointNumeric.packedBudget 20 packedOct132_127_0 445 = 84105249 := by decide +kernel

#print axioms packedOct132_127_0_budget

end NineSeparatedSubsetSums
