import NineSeparatedSubsetSums.Adaptive132Third114Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint132Checked

namespace NineSeparatedSubsetSums


theorem adaptive132Third114 : NoDescendingTailAfterThird 132 114 :=
  noDescendingThirdTail_of_cached 132 114 110282 (fun t ht nd => max148_second132_fourPoint_moment_bound (114::t) (by simp [ht]) nd) adaptive132Third114Proof0

#print axioms adaptive132Third114

end NineSeparatedSubsetSums
