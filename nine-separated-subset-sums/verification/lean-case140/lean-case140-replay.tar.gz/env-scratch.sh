ROOT=/workspace/scratch/fb47f17f885e/.lean-check
export LEAN="$ROOT/lean-4.36.0-linux/bin/lean"
export LEAN_PATH="$PWD:$ROOT/mathlib4/.lake/build/lib/lean$(printf ':%s' "$ROOT"/mathlib4/.lake/packages/*/.lake/build/lib/lean)"
export TMPDIR=$(realpath "$PWD/../tmp")
export NINE_STAGE_ROOT=$(realpath "$PWD/../staging")
