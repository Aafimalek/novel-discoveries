import NineSeparatedSubsetSums.Adaptive140Third122State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third122Proof0 : runCachedNode 511 125940 Adaptive140Third122Node0 = false := by
  decide +kernel

#print axioms adaptive140Third122Proof0

end NineSeparatedSubsetSums
