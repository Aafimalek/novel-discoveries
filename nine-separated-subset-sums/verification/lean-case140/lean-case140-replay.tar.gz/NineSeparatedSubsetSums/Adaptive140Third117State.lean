import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive140Third117Node0 : CachedSearchNode :=
  ⟨4, 116, computeCenteredMask [148,140,117], 405, 55193⟩

end NineSeparatedSubsetSums
