import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive140Third124Node0 : CachedSearchNode :=
  ⟨4, 123, computeCenteredMask [148,140,124], 412, 56880⟩

end NineSeparatedSubsetSums
