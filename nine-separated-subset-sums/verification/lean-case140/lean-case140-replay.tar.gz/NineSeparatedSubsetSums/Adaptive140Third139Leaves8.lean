import NineSeparatedSubsetSums.Adaptive140Third139State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third139Proof99 : runCachedNode 511 129561 Adaptive140Third139Node99 = false := by
  decide +kernel

#print axioms adaptive140Third139Proof99

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third139Proof128 : runCachedNode 511 129561 Adaptive140Third139Node128 = false := by
  decide +kernel

#print axioms adaptive140Third139Proof128

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third139Proof95 : runCachedNode 511 129561 Adaptive140Third139Node95 = false := by
  decide +kernel

#print axioms adaptive140Third139Proof95

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third139Proof1 : runCachedNode 511 129561 Adaptive140Third139Node1 = false := by
  decide +kernel

#print axioms adaptive140Third139Proof1

end NineSeparatedSubsetSums
