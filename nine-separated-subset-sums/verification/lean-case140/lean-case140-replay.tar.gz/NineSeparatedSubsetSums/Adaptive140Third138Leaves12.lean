import NineSeparatedSubsetSums.Adaptive140Third138State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third138Proof127 : runCachedNode 511 129379 Adaptive140Third138Node127 = false := by
  decide +kernel

#print axioms adaptive140Third138Proof127

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third138Proof43 : runCachedNode 511 129379 Adaptive140Third138Node43 = false := by
  decide +kernel

#print axioms adaptive140Third138Proof43

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third138Proof101 : runCachedNode 511 129379 Adaptive140Third138Node101 = false := by
  decide +kernel

#print axioms adaptive140Third138Proof101

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third138Proof126 : runCachedNode 511 129379 Adaptive140Third138Node126 = false := by
  decide +kernel

#print axioms adaptive140Third138Proof126

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third138Proof152 : runCachedNode 511 129379 Adaptive140Third138Node152 = false := by
  decide +kernel

#print axioms adaptive140Third138Proof152

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third138Proof24 : runCachedNode 511 129379 Adaptive140Third138Node24 = false := by
  decide +kernel

#print axioms adaptive140Third138Proof24

end NineSeparatedSubsetSums
