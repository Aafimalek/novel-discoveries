import NineSeparatedSubsetSums.Adaptive140Third107Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint140Checked

namespace NineSeparatedSubsetSums


theorem adaptive140Third107 : NoDescendingTailAfterThird 140 107 :=
  noDescendingThirdTail_of_cached 140 107 111588 (fun t ht nd => max148_second140_fourPoint_moment_bound (107::t) (by simp [ht]) nd) adaptive140Third107Proof0

#print axioms adaptive140Third107

end NineSeparatedSubsetSums
