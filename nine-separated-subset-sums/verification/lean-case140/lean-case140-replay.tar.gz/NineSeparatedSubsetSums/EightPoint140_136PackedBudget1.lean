import NineSeparatedSubsetSums.EightPoint140_136PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct140_136_1_budget :
    FourPointNumeric.packedBudget 20 packedOct140_136_1 270 = 92061696 := by decide +kernel

#print axioms packedOct140_136_1_budget

end NineSeparatedSubsetSums
