import NineSeparatedSubsetSums.Adaptive140Third138State
import NineSeparatedSubsetSums.Adaptive140Third138Leaves7
import NineSeparatedSubsetSums.Adaptive140Third138Leaves12
import NineSeparatedSubsetSums.Adaptive140Third138Leaves19
import NineSeparatedSubsetSums.Adaptive140Third138Leaves11
import NineSeparatedSubsetSums.Adaptive140Third138Leaves3
import NineSeparatedSubsetSums.Adaptive140Third138Leaves18
import NineSeparatedSubsetSums.Adaptive140Third138Leaves17
import NineSeparatedSubsetSums.Adaptive140Third138Leaves16
import NineSeparatedSubsetSums.Adaptive140Third138Leaves15
import NineSeparatedSubsetSums.Adaptive140Third138Leaves13
import NineSeparatedSubsetSums.Adaptive140Third138Leaves4
import NineSeparatedSubsetSums.Adaptive140Third138Leaves8
import NineSeparatedSubsetSums.Adaptive140Third138Leaves21
import NineSeparatedSubsetSums.Adaptive140Third138Leaves20
import NineSeparatedSubsetSums.Adaptive140Third138Leaves0
import NineSeparatedSubsetSums.Adaptive140Third138Leaves2
import NineSeparatedSubsetSums.Adaptive140Third138Leaves9
import NineSeparatedSubsetSums.Adaptive140Third138Leaves14
import NineSeparatedSubsetSums.Adaptive140Third138Leaves5
import NineSeparatedSubsetSums.Adaptive140Third138Leaves6
import NineSeparatedSubsetSums.Adaptive140Third138Leaves1
import NineSeparatedSubsetSums.Adaptive140Third138Leaves10

namespace NineSeparatedSubsetSums

theorem adaptive140Third138Proof22 : runCachedNode 511 129379 Adaptive140Third138Node22 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 129379 Adaptive140Third138Node22 = [104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 123, 125, 126, 127, 128, 129, 131] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive140Third138Proof23
  · exact adaptive140Third138Proof24
  · exact adaptive140Third138Proof25
  · exact adaptive140Third138Proof26
  · exact adaptive140Third138Proof27
  · exact adaptive140Third138Proof28
  · exact adaptive140Third138Proof29
  · exact adaptive140Third138Proof30
  · exact adaptive140Third138Proof31
  · exact adaptive140Third138Proof32
  · exact adaptive140Third138Proof33
  · exact adaptive140Third138Proof34
  · exact adaptive140Third138Proof35
  · exact adaptive140Third138Proof36
  · exact adaptive140Third138Proof37
  · exact adaptive140Third138Proof38
  · exact adaptive140Third138Proof39
  · exact adaptive140Third138Proof40
  · exact adaptive140Third138Proof41
  · exact adaptive140Third138Proof42
  · exact adaptive140Third138Proof43
  · exact adaptive140Third138Proof44
  · exact adaptive140Third138Proof45
  · exact adaptive140Third138Proof46
  · exact adaptive140Third138Proof47

#print axioms adaptive140Third138Proof22

theorem adaptive140Third138Proof48 : runCachedNode 511 129379 Adaptive140Third138Node48 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 129379 Adaptive140Third138Node48 = [104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 124, 126, 127, 128, 129, 132] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive140Third138Proof49
  · exact adaptive140Third138Proof50
  · exact adaptive140Third138Proof51
  · exact adaptive140Third138Proof52
  · exact adaptive140Third138Proof53
  · exact adaptive140Third138Proof54
  · exact adaptive140Third138Proof55
  · exact adaptive140Third138Proof56
  · exact adaptive140Third138Proof57
  · exact adaptive140Third138Proof58
  · exact adaptive140Third138Proof59
  · exact adaptive140Third138Proof60
  · exact adaptive140Third138Proof61
  · exact adaptive140Third138Proof62
  · exact adaptive140Third138Proof63
  · exact adaptive140Third138Proof64
  · exact adaptive140Third138Proof65
  · exact adaptive140Third138Proof66
  · exact adaptive140Third138Proof67
  · exact adaptive140Third138Proof68
  · exact adaptive140Third138Proof69
  · exact adaptive140Third138Proof70
  · exact adaptive140Third138Proof71
  · exact adaptive140Third138Proof72
  · exact adaptive140Third138Proof73

#print axioms adaptive140Third138Proof48

theorem adaptive140Third138Proof74 : runCachedNode 511 129379 Adaptive140Third138Node74 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 129379 Adaptive140Third138Node74 = [103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 125, 127, 128, 129, 131, 133] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive140Third138Proof75
  · exact adaptive140Third138Proof76
  · exact adaptive140Third138Proof77
  · exact adaptive140Third138Proof78
  · exact adaptive140Third138Proof79
  · exact adaptive140Third138Proof80
  · exact adaptive140Third138Proof81
  · exact adaptive140Third138Proof82
  · exact adaptive140Third138Proof83
  · exact adaptive140Third138Proof84
  · exact adaptive140Third138Proof85
  · exact adaptive140Third138Proof86
  · exact adaptive140Third138Proof87
  · exact adaptive140Third138Proof88
  · exact adaptive140Third138Proof89
  · exact adaptive140Third138Proof90
  · exact adaptive140Third138Proof91
  · exact adaptive140Third138Proof92
  · exact adaptive140Third138Proof93
  · exact adaptive140Third138Proof94
  · exact adaptive140Third138Proof95
  · exact adaptive140Third138Proof96
  · exact adaptive140Third138Proof97
  · exact adaptive140Third138Proof98
  · exact adaptive140Third138Proof99
  · exact adaptive140Third138Proof100
  · exact adaptive140Third138Proof101

#print axioms adaptive140Third138Proof74

theorem adaptive140Third138Proof102 : runCachedNode 511 129379 Adaptive140Third138Node102 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 129379 Adaptive140Third138Node102 = [103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 126, 128, 129, 131, 132, 134] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive140Third138Proof103
  · exact adaptive140Third138Proof104
  · exact adaptive140Third138Proof105
  · exact adaptive140Third138Proof106
  · exact adaptive140Third138Proof107
  · exact adaptive140Third138Proof108
  · exact adaptive140Third138Proof109
  · exact adaptive140Third138Proof110
  · exact adaptive140Third138Proof111
  · exact adaptive140Third138Proof112
  · exact adaptive140Third138Proof113
  · exact adaptive140Third138Proof114
  · exact adaptive140Third138Proof115
  · exact adaptive140Third138Proof116
  · exact adaptive140Third138Proof117
  · exact adaptive140Third138Proof118
  · exact adaptive140Third138Proof119
  · exact adaptive140Third138Proof120
  · exact adaptive140Third138Proof121
  · exact adaptive140Third138Proof122
  · exact adaptive140Third138Proof123
  · exact adaptive140Third138Proof124
  · exact adaptive140Third138Proof125
  · exact adaptive140Third138Proof126
  · exact adaptive140Third138Proof127
  · exact adaptive140Third138Proof128
  · exact adaptive140Third138Proof129
  · exact adaptive140Third138Proof130

#print axioms adaptive140Third138Proof102

theorem adaptive140Third138Proof158 : runCachedNode 511 129379 Adaptive140Third138Node158 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 129379 Adaptive140Third138Node158 = [93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 119, 121, 123, 125, 127, 129, 131] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive140Third138Proof159
  · exact adaptive140Third138Proof160
  · exact adaptive140Third138Proof161
  · exact adaptive140Third138Proof162
  · exact adaptive140Third138Proof163
  · exact adaptive140Third138Proof164
  · exact adaptive140Third138Proof165
  · exact adaptive140Third138Proof166
  · exact adaptive140Third138Proof167
  · exact adaptive140Third138Proof168
  · exact adaptive140Third138Proof169
  · exact adaptive140Third138Proof170
  · exact adaptive140Third138Proof171
  · exact adaptive140Third138Proof172
  · exact adaptive140Third138Proof173
  · exact adaptive140Third138Proof174
  · exact adaptive140Third138Proof175
  · exact adaptive140Third138Proof176
  · exact adaptive140Third138Proof177
  · exact adaptive140Third138Proof178
  · exact adaptive140Third138Proof179
  · exact adaptive140Third138Proof180
  · exact adaptive140Third138Proof181
  · exact adaptive140Third138Proof182
  · exact adaptive140Third138Proof183
  · exact adaptive140Third138Proof184
  · exact adaptive140Third138Proof185
  · exact adaptive140Third138Proof186
  · exact adaptive140Third138Proof187
  · exact adaptive140Third138Proof188
  · exact adaptive140Third138Proof189
  · exact adaptive140Third138Proof190

#print axioms adaptive140Third138Proof158

theorem adaptive140Third138Proof131 : runCachedNode 511 129379 Adaptive140Third138Node131 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 129379 Adaptive140Third138Node131 = [103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 127, 129, 131, 132, 133, 135] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive140Third138Proof132
  · exact adaptive140Third138Proof133
  · exact adaptive140Third138Proof134
  · exact adaptive140Third138Proof135
  · exact adaptive140Third138Proof136
  · exact adaptive140Third138Proof137
  · exact adaptive140Third138Proof138
  · exact adaptive140Third138Proof139
  · exact adaptive140Third138Proof140
  · exact adaptive140Third138Proof141
  · exact adaptive140Third138Proof142
  · exact adaptive140Third138Proof143
  · exact adaptive140Third138Proof144
  · exact adaptive140Third138Proof145
  · exact adaptive140Third138Proof146
  · exact adaptive140Third138Proof147
  · exact adaptive140Third138Proof148
  · exact adaptive140Third138Proof149
  · exact adaptive140Third138Proof150
  · exact adaptive140Third138Proof151
  · exact adaptive140Third138Proof152
  · exact adaptive140Third138Proof153
  · exact adaptive140Third138Proof154
  · exact adaptive140Third138Proof155
  · exact adaptive140Third138Proof156
  · exact adaptive140Third138Proof157
  · exact adaptive140Third138Proof158
  · exact adaptive140Third138Proof191
  · exact adaptive140Third138Proof192

#print axioms adaptive140Third138Proof131

theorem adaptive140Third138Proof193 : runCachedNode 511 129379 Adaptive140Third138Node193 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 129379 Adaptive140Third138Node193 = [103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 128, 131, 132, 133, 134, 136] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive140Third138Proof194
  · exact adaptive140Third138Proof195
  · exact adaptive140Third138Proof196
  · exact adaptive140Third138Proof197
  · exact adaptive140Third138Proof198
  · exact adaptive140Third138Proof199
  · exact adaptive140Third138Proof200
  · exact adaptive140Third138Proof201
  · exact adaptive140Third138Proof202
  · exact adaptive140Third138Proof203
  · exact adaptive140Third138Proof204
  · exact adaptive140Third138Proof205
  · exact adaptive140Third138Proof206
  · exact adaptive140Third138Proof207
  · exact adaptive140Third138Proof208
  · exact adaptive140Third138Proof209
  · exact adaptive140Third138Proof210
  · exact adaptive140Third138Proof211
  · exact adaptive140Third138Proof212
  · exact adaptive140Third138Proof213
  · exact adaptive140Third138Proof214
  · exact adaptive140Third138Proof215
  · exact adaptive140Third138Proof216
  · exact adaptive140Third138Proof217
  · exact adaptive140Third138Proof218
  · exact adaptive140Third138Proof219
  · exact adaptive140Third138Proof220
  · exact adaptive140Third138Proof221
  · exact adaptive140Third138Proof222
  · exact adaptive140Third138Proof223

#print axioms adaptive140Third138Proof193

theorem adaptive140Third138Proof0 : runCachedNode 511 129379 Adaptive140Third138Node0 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 129379 Adaptive140Third138Node0 = [110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 131, 132, 133, 134, 135, 136, 137] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive140Third138Proof1
  · exact adaptive140Third138Proof2
  · exact adaptive140Third138Proof3
  · exact adaptive140Third138Proof4
  · exact adaptive140Third138Proof5
  · exact adaptive140Third138Proof6
  · exact adaptive140Third138Proof7
  · exact adaptive140Third138Proof8
  · exact adaptive140Third138Proof9
  · exact adaptive140Third138Proof10
  · exact adaptive140Third138Proof11
  · exact adaptive140Third138Proof12
  · exact adaptive140Third138Proof13
  · exact adaptive140Third138Proof14
  · exact adaptive140Third138Proof15
  · exact adaptive140Third138Proof16
  · exact adaptive140Third138Proof17
  · exact adaptive140Third138Proof18
  · exact adaptive140Third138Proof19
  · exact adaptive140Third138Proof20
  · exact adaptive140Third138Proof21
  · exact adaptive140Third138Proof22
  · exact adaptive140Third138Proof48
  · exact adaptive140Third138Proof74
  · exact adaptive140Third138Proof102
  · exact adaptive140Third138Proof131
  · exact adaptive140Third138Proof193

#print axioms adaptive140Third138Proof0

end NineSeparatedSubsetSums
