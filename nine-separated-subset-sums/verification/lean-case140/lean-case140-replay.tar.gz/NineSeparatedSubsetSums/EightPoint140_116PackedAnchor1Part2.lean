import NineSeparatedSubsetSums.EightPoint140_116PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint140_116PackedAnchor1Part2 :
    ∀ j : Fin 4, 2341448 ≤ FourPointNumeric.octPackedCharge 140 116 20 packedOct140_116_1
      (2*((j.val : Int)+240)+1) := by decide +kernel

end NineSeparatedSubsetSums
