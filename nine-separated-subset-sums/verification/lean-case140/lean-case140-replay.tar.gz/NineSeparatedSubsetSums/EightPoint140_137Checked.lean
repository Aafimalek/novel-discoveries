import NineSeparatedSubsetSums.EightPointPackedGeometry
import NineSeparatedSubsetSums.EightPoint140_137PackedBudget0
import NineSeparatedSubsetSums.EightPoint140_137PackedAnchor0Part0
import NineSeparatedSubsetSums.EightPoint140_137PackedAnchor0Part1
import NineSeparatedSubsetSums.EightPoint140_137PackedAnchor0Part2
import NineSeparatedSubsetSums.EightPoint140_137PackedBudget1
import NineSeparatedSubsetSums.EightPoint140_137PackedAnchor1Part0
import NineSeparatedSubsetSums.EightPoint140_137PackedAnchor1Part1
import NineSeparatedSubsetSums.EightPoint140_137PackedAnchor1Part2

namespace NineSeparatedSubsetSums

private theorem packedOct140_137Anchor0 :
  ∀ j : Fin 500, ((j.val : Int)+140+137)%2=0 →
    2475128 ≤ FourPointNumeric.octPackedCharge 140 137 20 packedOct140_137_0 (j.val : Int) := by
  intro j hj
  let k := (j.val-1)/2
  have hk : k < 250 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+1 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint140_137PackedAnchor0Part0 z
    rwa [he,hrep] at ht
  by_cases h1 : k < 240
  · let z : Fin 120 := ⟨k-120, by omega⟩
    have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
    have ht := eightPoint140_137PackedAnchor0Part1 z
    rwa [he,hrep] at ht
  let z : Fin 10 := ⟨k-240, by omega⟩
  have he : (z.val : Int)+240 = k := by dsimp [z] <;> omega
  have ht := eightPoint140_137PackedAnchor0Part2 z
  rwa [he,hrep] at ht

private theorem packedOct140_137Anchor1 :
  ∀ j : Fin 500, ((j.val : Int)+140+137)%2=1 →
    2475165 ≤ FourPointNumeric.octPackedCharge 140 137 20 packedOct140_137_1 (j.val : Int) := by
  intro j hj
  let k := (j.val-0)/2
  have hk : k < 250 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+0 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint140_137PackedAnchor1Part0 z
    rwa [he,hrep] at ht
  by_cases h1 : k < 240
  · let z : Fin 120 := ⟨k-120, by omega⟩
    have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
    have ht := eightPoint140_137PackedAnchor1Part1 z
    rwa [he,hrep] at ht
  let z : Fin 10 := ⟨k-240, by omega⟩
  have he : (z.val : Int)+240 = k := by dsimp [z] <;> omega
  have ht := eightPoint140_137PackedAnchor1Part2 z
  rwa [he,hrep] at ht

def packedOctCertificate140_137_0 : EightPointCertificate 140 137 0 129199 :=
  eightPointCertificateOfPacked 140 137 0 129199 2475128 20 packedOct140_137_0 271 500
    (by decide +kernel) (by decide) packedOct140_137Anchor0
    (by rw [packedOct140_137_0_budget]; decide)

def packedOctCertificate140_137_1 : EightPointCertificate 140 137 1 129199 :=
  eightPointCertificateOfPacked 140 137 1 129199 2475165 20 packedOct140_137_1 270 500
    (by decide +kernel) (by decide) packedOct140_137Anchor1
    (by rw [packedOct140_137_1_budget]; decide)

theorem max148_second140_third137_eightPoint_moment_bound (tail : List ℕ) (len : tail.length=6)
    (distinct : (natSubsetSums (148::140::137::tail)).Nodup) :
    129199 ≤ ((148::140::137::tail).map (· ^ 2)).sum := by
  apply eightPointNatMomentLower 140 137 129199 tail len distinct
  intro p hp
  by_cases h : p=0
  · subst p
    exact packedOctCertificate140_137_0
  · have he : p=1 := hp.resolve_left h
    subst p
    exact packedOctCertificate140_137_1

#print axioms max148_second140_third137_eightPoint_moment_bound

end NineSeparatedSubsetSums
