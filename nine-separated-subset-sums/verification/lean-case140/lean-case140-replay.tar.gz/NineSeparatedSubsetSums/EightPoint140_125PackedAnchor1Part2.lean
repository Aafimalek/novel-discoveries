import NineSeparatedSubsetSums.EightPoint140_125PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint140_125PackedAnchor1Part2 :
    ∀ j : Fin 3, 2333448 ≤ FourPointNumeric.octPackedCharge 140 125 20 packedOct140_125_1
      (2*((j.val : Int)+240)+0) := by decide +kernel

end NineSeparatedSubsetSums
