import NineSeparatedSubsetSums.EightPoint140_130PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint140_130PackedAnchor0Part2 :
    ∀ j : Fin 7, 2404573 ≤ FourPointNumeric.octPackedCharge 140 130 20 packedOct140_130_0
      (2*((j.val : Int)+240)+0) := by decide +kernel

end NineSeparatedSubsetSums
