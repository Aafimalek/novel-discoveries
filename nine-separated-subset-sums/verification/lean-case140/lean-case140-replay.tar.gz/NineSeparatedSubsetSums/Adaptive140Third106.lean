import NineSeparatedSubsetSums.Adaptive140Third106Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint140Checked

namespace NineSeparatedSubsetSums


theorem adaptive140Third106 : NoDescendingTailAfterThird 140 106 :=
  noDescendingThirdTail_of_cached 140 106 111588 (fun t ht nd => max148_second140_fourPoint_moment_bound (106::t) (by simp [ht]) nd) adaptive140Third106Proof0

#print axioms adaptive140Third106

end NineSeparatedSubsetSums
