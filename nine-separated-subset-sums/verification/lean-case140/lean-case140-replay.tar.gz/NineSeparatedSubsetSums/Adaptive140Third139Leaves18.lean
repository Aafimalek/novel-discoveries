import NineSeparatedSubsetSums.Adaptive140Third139State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third139Proof211 : runCachedNode 511 129561 Adaptive140Third139Node211 = false := by
  decide +kernel

#print axioms adaptive140Third139Proof211

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third139Proof210 : runCachedNode 511 129561 Adaptive140Third139Node210 = false := by
  decide +kernel

#print axioms adaptive140Third139Proof210

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third139Proof154 : runCachedNode 511 129561 Adaptive140Third139Node154 = false := by
  decide +kernel

#print axioms adaptive140Third139Proof154

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third139Proof151 : runCachedNode 511 129561 Adaptive140Third139Node151 = false := by
  decide +kernel

#print axioms adaptive140Third139Proof151

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third139Proof121 : runCachedNode 511 129561 Adaptive140Third139Node121 = false := by
  decide +kernel

#print axioms adaptive140Third139Proof121

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third139Proof257 : runCachedNode 511 129561 Adaptive140Third139Node257 = false := by
  decide +kernel

#print axioms adaptive140Third139Proof257

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third139Proof11 : runCachedNode 511 129561 Adaptive140Third139Node11 = false := by
  decide +kernel

#print axioms adaptive140Third139Proof11

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third139Proof183 : runCachedNode 511 129561 Adaptive140Third139Node183 = false := by
  decide +kernel

#print axioms adaptive140Third139Proof183

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third139Proof152 : runCachedNode 511 129561 Adaptive140Third139Node152 = false := by
  decide +kernel

#print axioms adaptive140Third139Proof152

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third139Proof209 : runCachedNode 511 129561 Adaptive140Third139Node209 = false := by
  decide +kernel

#print axioms adaptive140Third139Proof209

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third139Proof150 : runCachedNode 511 129561 Adaptive140Third139Node150 = false := by
  decide +kernel

#print axioms adaptive140Third139Proof150

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third139Proof62 : runCachedNode 511 129561 Adaptive140Third139Node62 = false := by
  decide +kernel

#print axioms adaptive140Third139Proof62

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third139Proof76 : runCachedNode 511 129561 Adaptive140Third139Node76 = false := by
  decide +kernel

#print axioms adaptive140Third139Proof76

end NineSeparatedSubsetSums
