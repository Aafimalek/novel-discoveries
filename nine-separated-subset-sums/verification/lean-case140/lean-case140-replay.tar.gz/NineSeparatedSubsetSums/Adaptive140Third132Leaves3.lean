import NineSeparatedSubsetSums.Adaptive140Third132State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third132Proof14 : runCachedNode 511 128323 Adaptive140Third132Node14 = false := by
  decide +kernel

#print axioms adaptive140Third132Proof14

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third132Proof65 : runCachedNode 511 128323 Adaptive140Third132Node65 = false := by
  decide +kernel

#print axioms adaptive140Third132Proof65

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third132Proof40 : runCachedNode 511 128323 Adaptive140Third132Node40 = false := by
  decide +kernel

#print axioms adaptive140Third132Proof40

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third132Proof44 : runCachedNode 511 128323 Adaptive140Third132Node44 = false := by
  decide +kernel

#print axioms adaptive140Third132Proof44

end NineSeparatedSubsetSums
