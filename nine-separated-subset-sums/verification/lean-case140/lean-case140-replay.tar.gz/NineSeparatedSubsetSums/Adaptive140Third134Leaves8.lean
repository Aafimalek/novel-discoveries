import NineSeparatedSubsetSums.Adaptive140Third134State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third134Proof63 : runCachedNode 511 128648 Adaptive140Third134Node63 = false := by
  decide +kernel

#print axioms adaptive140Third134Proof63

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third134Proof36 : runCachedNode 511 128648 Adaptive140Third134Node36 = false := by
  decide +kernel

#print axioms adaptive140Third134Proof36

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third134Proof65 : runCachedNode 511 128648 Adaptive140Third134Node65 = false := by
  decide +kernel

#print axioms adaptive140Third134Proof65

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third134Proof8 : runCachedNode 511 128648 Adaptive140Third134Node8 = false := by
  decide +kernel

#print axioms adaptive140Third134Proof8

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third134Proof62 : runCachedNode 511 128648 Adaptive140Third134Node62 = false := by
  decide +kernel

#print axioms adaptive140Third134Proof62

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third134Proof6 : runCachedNode 511 128648 Adaptive140Third134Node6 = false := by
  decide +kernel

#print axioms adaptive140Third134Proof6

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third134Proof61 : runCachedNode 511 128648 Adaptive140Third134Node61 = false := by
  decide +kernel

#print axioms adaptive140Third134Proof61

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third134Proof33 : runCachedNode 511 128648 Adaptive140Third134Node33 = false := by
  decide +kernel

#print axioms adaptive140Third134Proof33

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third134Proof60 : runCachedNode 511 128648 Adaptive140Third134Node60 = false := by
  decide +kernel

#print axioms adaptive140Third134Proof60

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third134Proof5 : runCachedNode 511 128648 Adaptive140Third134Node5 = false := by
  decide +kernel

#print axioms adaptive140Third134Proof5

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third134Proof31 : runCachedNode 511 128648 Adaptive140Third134Node31 = false := by
  decide +kernel

#print axioms adaptive140Third134Proof31

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third134Proof4 : runCachedNode 511 128648 Adaptive140Third134Node4 = false := by
  decide +kernel

#print axioms adaptive140Third134Proof4

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third134Proof30 : runCachedNode 511 128648 Adaptive140Third134Node30 = false := by
  decide +kernel

#print axioms adaptive140Third134Proof30

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third134Proof58 : runCachedNode 511 128648 Adaptive140Third134Node58 = false := by
  decide +kernel

#print axioms adaptive140Third134Proof58

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third134Proof59 : runCachedNode 511 128648 Adaptive140Third134Node59 = false := by
  decide +kernel

#print axioms adaptive140Third134Proof59

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third134Proof29 : runCachedNode 511 128648 Adaptive140Third134Node29 = false := by
  decide +kernel

#print axioms adaptive140Third134Proof29

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third134Proof3 : runCachedNode 511 128648 Adaptive140Third134Node3 = false := by
  decide +kernel

#print axioms adaptive140Third134Proof3

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third134Proof28 : runCachedNode 511 128648 Adaptive140Third134Node28 = false := by
  decide +kernel

#print axioms adaptive140Third134Proof28

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third134Proof27 : runCachedNode 511 128648 Adaptive140Third134Node27 = false := by
  decide +kernel

#print axioms adaptive140Third134Proof27

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third134Proof55 : runCachedNode 511 128648 Adaptive140Third134Node55 = false := by
  decide +kernel

#print axioms adaptive140Third134Proof55

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third134Proof26 : runCachedNode 511 128648 Adaptive140Third134Node26 = false := by
  decide +kernel

#print axioms adaptive140Third134Proof26

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third134Proof54 : runCachedNode 511 128648 Adaptive140Third134Node54 = false := by
  decide +kernel

#print axioms adaptive140Third134Proof54

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third134Proof2 : runCachedNode 511 128648 Adaptive140Third134Node2 = false := by
  decide +kernel

#print axioms adaptive140Third134Proof2

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third134Proof52 : runCachedNode 511 128648 Adaptive140Third134Node52 = false := by
  decide +kernel

#print axioms adaptive140Third134Proof52

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third134Proof53 : runCachedNode 511 128648 Adaptive140Third134Node53 = false := by
  decide +kernel

#print axioms adaptive140Third134Proof53

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third134Proof51 : runCachedNode 511 128648 Adaptive140Third134Node51 = false := by
  decide +kernel

#print axioms adaptive140Third134Proof51

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third134Proof25 : runCachedNode 511 128648 Adaptive140Third134Node25 = false := by
  decide +kernel

#print axioms adaptive140Third134Proof25

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third134Proof24 : runCachedNode 511 128648 Adaptive140Third134Node24 = false := by
  decide +kernel

#print axioms adaptive140Third134Proof24

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third134Proof50 : runCachedNode 511 128648 Adaptive140Third134Node50 = false := by
  decide +kernel

#print axioms adaptive140Third134Proof50

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third134Proof23 : runCachedNode 511 128648 Adaptive140Third134Node23 = false := by
  decide +kernel

#print axioms adaptive140Third134Proof23

end NineSeparatedSubsetSums
