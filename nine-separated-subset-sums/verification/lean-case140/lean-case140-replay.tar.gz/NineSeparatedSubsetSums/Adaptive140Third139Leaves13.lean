import NineSeparatedSubsetSums.Adaptive140Third139State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third139Proof68 : runCachedNode 511 129561 Adaptive140Third139Node68 = false := by
  decide +kernel

#print axioms adaptive140Third139Proof68

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third139Proof157 : runCachedNode 511 129561 Adaptive140Third139Node157 = false := by
  decide +kernel

#print axioms adaptive140Third139Proof157

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third139Proof187 : runCachedNode 511 129561 Adaptive140Third139Node187 = false := by
  decide +kernel

#print axioms adaptive140Third139Proof187

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third139Proof44 : runCachedNode 511 129561 Adaptive140Third139Node44 = false := by
  decide +kernel

#print axioms adaptive140Third139Proof44

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third139Proof87 : runCachedNode 511 129561 Adaptive140Third139Node87 = false := by
  decide +kernel

#print axioms adaptive140Third139Proof87

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third139Proof22 : runCachedNode 511 129561 Adaptive140Third139Node22 = false := by
  decide +kernel

#print axioms adaptive140Third139Proof22

end NineSeparatedSubsetSums
