import NineSeparatedSubsetSums.FourPoint140PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedWeight140_1_budget :
    FourPointNumeric.packedBudget 20 packedWeight140_1 362 = 81959424 := by decide +kernel

#print axioms packedWeight140_1_budget

end NineSeparatedSubsetSums
