import NineSeparatedSubsetSums.Adaptive140Third136State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third136Proof20 : runCachedNode 511 129025 Adaptive140Third136Node20 = false := by
  decide +kernel

#print axioms adaptive140Third136Proof20

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third136Proof19 : runCachedNode 511 129025 Adaptive140Third136Node19 = false := by
  decide +kernel

#print axioms adaptive140Third136Proof19

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third136Proof40 : runCachedNode 511 129025 Adaptive140Third136Node40 = false := by
  decide +kernel

#print axioms adaptive140Third136Proof40

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third136Proof5 : runCachedNode 511 129025 Adaptive140Third136Node5 = false := by
  decide +kernel

#print axioms adaptive140Third136Proof5

end NineSeparatedSubsetSums
