import NineSeparatedSubsetSums.Adaptive140Third137State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third137Proof159 : runCachedNode 511 129199 Adaptive140Third137Node159 = false := by
  decide +kernel

#print axioms adaptive140Third137Proof159

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third137Proof99 : runCachedNode 511 129199 Adaptive140Third137Node99 = false := by
  decide +kernel

#print axioms adaptive140Third137Proof99

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third137Proof42 : runCachedNode 511 129199 Adaptive140Third137Node42 = false := by
  decide +kernel

#print axioms adaptive140Third137Proof42

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third137Proof132 : runCachedNode 511 129199 Adaptive140Third137Node132 = false := by
  decide +kernel

#print axioms adaptive140Third137Proof132

end NineSeparatedSubsetSums
