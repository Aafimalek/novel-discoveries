import NineSeparatedSubsetSums.Adaptive140Third136State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third136Proof47 : runCachedNode 511 129025 Adaptive140Third136Node47 = false := by
  decide +kernel

#print axioms adaptive140Third136Proof47

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third136Proof43 : runCachedNode 511 129025 Adaptive140Third136Node43 = false := by
  decide +kernel

#print axioms adaptive140Third136Proof43

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third136Proof133 : runCachedNode 511 129025 Adaptive140Third136Node133 = false := by
  decide +kernel

#print axioms adaptive140Third136Proof133

end NineSeparatedSubsetSums
