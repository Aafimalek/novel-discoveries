import NineSeparatedSubsetSums.Adaptive140Third138State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third138Proof44 : runCachedNode 511 129379 Adaptive140Third138Node44 = false := by
  decide +kernel

#print axioms adaptive140Third138Proof44

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third138Proof15 : runCachedNode 511 129379 Adaptive140Third138Node15 = false := by
  decide +kernel

#print axioms adaptive140Third138Proof15

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third138Proof187 : runCachedNode 511 129379 Adaptive140Third138Node187 = false := by
  decide +kernel

#print axioms adaptive140Third138Proof187

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third138Proof13 : runCachedNode 511 129379 Adaptive140Third138Node13 = false := by
  decide +kernel

#print axioms adaptive140Third138Proof13

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third138Proof182 : runCachedNode 511 129379 Adaptive140Third138Node182 = false := by
  decide +kernel

#print axioms adaptive140Third138Proof182

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third138Proof215 : runCachedNode 511 129379 Adaptive140Third138Node215 = false := by
  decide +kernel

#print axioms adaptive140Third138Proof215

end NineSeparatedSubsetSums
