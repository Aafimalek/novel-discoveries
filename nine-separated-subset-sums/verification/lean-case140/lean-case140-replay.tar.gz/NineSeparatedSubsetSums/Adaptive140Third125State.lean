import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive140Third125Node0 : CachedSearchNode :=
  ⟨4, 124, computeCenteredMask [148,140,125], 413, 57129⟩

end NineSeparatedSubsetSums
