import NineSeparatedSubsetSums.EightPoint140_129PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint140_129PackedAnchor1Part2 :
    ∀ j : Fin 6, 2390734 ≤ FourPointNumeric.octPackedCharge 140 129 20 packedOct140_129_1
      (2*((j.val : Int)+240)+0) := by decide +kernel

end NineSeparatedSubsetSums
