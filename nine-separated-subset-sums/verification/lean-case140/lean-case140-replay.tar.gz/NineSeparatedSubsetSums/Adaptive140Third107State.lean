import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive140Third107Node0 : CachedSearchNode :=
  ⟨4, 106, computeCenteredMask [148,140,107], 395, 52953⟩

end NineSeparatedSubsetSums
