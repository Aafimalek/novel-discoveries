import NineSeparatedSubsetSums.EightPoint140_139PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct140_139_1_budget :
    FourPointNumeric.packedBudget 20 packedOct140_139_1 274 = 93278610 := by decide +kernel

#print axioms packedOct140_139_1_budget

end NineSeparatedSubsetSums
