import NineSeparatedSubsetSums.FourPoint140PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem fourPoint140PackedAnchor1Part0 :
    ∀ j : Fin 120, 1086660 ≤ FourPointNumeric.packedCharge 140 20 packedWeight140_1
      (2*((j.val : Int)+0)+1) := by decide +kernel

end NineSeparatedSubsetSums
