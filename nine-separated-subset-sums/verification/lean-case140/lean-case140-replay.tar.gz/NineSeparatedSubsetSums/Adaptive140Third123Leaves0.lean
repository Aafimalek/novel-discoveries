import NineSeparatedSubsetSums.Adaptive140Third123State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third123Proof0 : runCachedNode 511 126110 Adaptive140Third123Node0 = false := by
  decide +kernel

#print axioms adaptive140Third123Proof0

end NineSeparatedSubsetSums
