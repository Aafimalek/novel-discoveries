import NineSeparatedSubsetSums.Adaptive140Third137State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third137Proof13 : runCachedNode 511 129199 Adaptive140Third137Node13 = false := by
  decide +kernel

#print axioms adaptive140Third137Proof13

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third137Proof70 : runCachedNode 511 129199 Adaptive140Third137Node70 = false := by
  decide +kernel

#print axioms adaptive140Third137Proof70

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third137Proof97 : runCachedNode 511 129199 Adaptive140Third137Node97 = false := by
  decide +kernel

#print axioms adaptive140Third137Proof97

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third137Proof72 : runCachedNode 511 129199 Adaptive140Third137Node72 = false := by
  decide +kernel

#print axioms adaptive140Third137Proof72

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third137Proof12 : runCachedNode 511 129199 Adaptive140Third137Node12 = false := by
  decide +kernel

#print axioms adaptive140Third137Proof12

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third137Proof154 : runCachedNode 511 129199 Adaptive140Third137Node154 = false := by
  decide +kernel

#print axioms adaptive140Third137Proof154

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third137Proof96 : runCachedNode 511 129199 Adaptive140Third137Node96 = false := by
  decide +kernel

#print axioms adaptive140Third137Proof96

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third137Proof155 : runCachedNode 511 129199 Adaptive140Third137Node155 = false := by
  decide +kernel

#print axioms adaptive140Third137Proof155

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third137Proof66 : runCachedNode 511 129199 Adaptive140Third137Node66 = false := by
  decide +kernel

#print axioms adaptive140Third137Proof66

end NineSeparatedSubsetSums
