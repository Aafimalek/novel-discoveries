import NineSeparatedSubsetSums.EightPoint140_116PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint140_116PackedAnchor0Part1 :
    ∀ j : Fin 120, 2342304 ≤ FourPointNumeric.octPackedCharge 140 116 20 packedOct140_116_0
      (2*((j.val : Int)+120)+0) := by decide +kernel

end NineSeparatedSubsetSums
