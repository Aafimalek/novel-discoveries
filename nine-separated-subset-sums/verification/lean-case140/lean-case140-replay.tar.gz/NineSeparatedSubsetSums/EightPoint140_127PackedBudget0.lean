import NineSeparatedSubsetSums.EightPoint140_127PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct140_127_0_budget :
    FourPointNumeric.packedBudget 20 packedOct140_127_0 267 = 85548645 := by decide +kernel

#print axioms packedOct140_127_0_budget

end NineSeparatedSubsetSums
