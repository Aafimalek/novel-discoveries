import NineSeparatedSubsetSums.Adaptive140Third115State
import NineSeparatedSubsetSums.Adaptive140Third115Leaves0
import NineSeparatedSubsetSums.Adaptive140Third115Leaves1

namespace NineSeparatedSubsetSums

theorem adaptive140Third115Proof0 : runCachedNode 511 111588 Adaptive140Third115Node0 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 111588 Adaptive140Third115Node0 = [100, 101, 102, 103, 104, 105, 106, 108, 109, 110, 111, 112, 113, 114] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive140Third115Proof1
  · exact adaptive140Third115Proof2
  · exact adaptive140Third115Proof3
  · exact adaptive140Third115Proof4
  · exact adaptive140Third115Proof5
  · exact adaptive140Third115Proof6
  · exact adaptive140Third115Proof7
  · exact adaptive140Third115Proof8
  · exact adaptive140Third115Proof9
  · exact adaptive140Third115Proof10
  · exact adaptive140Third115Proof11
  · exact adaptive140Third115Proof12
  · exact adaptive140Third115Proof13
  · exact adaptive140Third115Proof14

#print axioms adaptive140Third115Proof0

end NineSeparatedSubsetSums
