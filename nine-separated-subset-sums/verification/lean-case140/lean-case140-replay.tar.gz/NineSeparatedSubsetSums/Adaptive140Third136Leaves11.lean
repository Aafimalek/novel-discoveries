import NineSeparatedSubsetSums.Adaptive140Third136State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third136Proof98 : runCachedNode 511 129025 Adaptive140Third136Node98 = false := by
  decide +kernel

#print axioms adaptive140Third136Proof98

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third136Proof37 : runCachedNode 511 129025 Adaptive140Third136Node37 = false := by
  decide +kernel

#print axioms adaptive140Third136Proof37

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third136Proof124 : runCachedNode 511 129025 Adaptive140Third136Node124 = false := by
  decide +kernel

#print axioms adaptive140Third136Proof124

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third136Proof12 : runCachedNode 511 129025 Adaptive140Third136Node12 = false := by
  decide +kernel

#print axioms adaptive140Third136Proof12

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third136Proof154 : runCachedNode 511 129025 Adaptive140Third136Node154 = false := by
  decide +kernel

#print axioms adaptive140Third136Proof154

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third136Proof69 : runCachedNode 511 129025 Adaptive140Third136Node69 = false := by
  decide +kernel

#print axioms adaptive140Third136Proof69

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third136Proof123 : runCachedNode 511 129025 Adaptive140Third136Node123 = false := by
  decide +kernel

#print axioms adaptive140Third136Proof123

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third136Proof11 : runCachedNode 511 129025 Adaptive140Third136Node11 = false := by
  decide +kernel

#print axioms adaptive140Third136Proof11

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third136Proof36 : runCachedNode 511 129025 Adaptive140Third136Node36 = false := by
  decide +kernel

#print axioms adaptive140Third136Proof36

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third136Proof152 : runCachedNode 511 129025 Adaptive140Third136Node152 = false := by
  decide +kernel

#print axioms adaptive140Third136Proof152

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third136Proof68 : runCachedNode 511 129025 Adaptive140Third136Node68 = false := by
  decide +kernel

#print axioms adaptive140Third136Proof68

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third136Proof151 : runCachedNode 511 129025 Adaptive140Third136Node151 = false := by
  decide +kernel

#print axioms adaptive140Third136Proof151

end NineSeparatedSubsetSums
