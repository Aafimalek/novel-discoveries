import NineSeparatedSubsetSums.Adaptive140Third136State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third136Proof73 : runCachedNode 511 129025 Adaptive140Third136Node73 = false := by
  decide +kernel

#print axioms adaptive140Third136Proof73

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third136Proof13 : runCachedNode 511 129025 Adaptive140Third136Node13 = false := by
  decide +kernel

#print axioms adaptive140Third136Proof13

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third136Proof1 : runCachedNode 511 129025 Adaptive140Third136Node1 = false := by
  decide +kernel

#print axioms adaptive140Third136Proof1

end NineSeparatedSubsetSums
