import NineSeparatedSubsetSums.Adaptive140Third124State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third124Proof0 : runCachedNode 511 126427 Adaptive140Third124Node0 = false := by
  decide +kernel

#print axioms adaptive140Third124Proof0

end NineSeparatedSubsetSums
