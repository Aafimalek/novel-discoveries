import NineSeparatedSubsetSums.EightPoint140_128PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint140_128PackedAnchor1Part2 :
    ∀ j : Fin 4, 2365898 ≤ FourPointNumeric.octPackedCharge 140 128 20 packedOct140_128_1
      (2*((j.val : Int)+240)+1) := by decide +kernel

end NineSeparatedSubsetSums
