import NineSeparatedSubsetSums.Adaptive140Third113Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint140Checked

namespace NineSeparatedSubsetSums


theorem adaptive140Third113 : NoDescendingTailAfterThird 140 113 :=
  noDescendingThirdTail_of_cached 140 113 111588 (fun t ht nd => max148_second140_fourPoint_moment_bound (113::t) (by simp [ht]) nd) adaptive140Third113Proof0

#print axioms adaptive140Third113

end NineSeparatedSubsetSums
