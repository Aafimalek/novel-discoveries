import NineSeparatedSubsetSums.EightPoint140_118PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint140_118PackedAnchor0Part2 :
    ∀ j : Fin 5, 2350317 ≤ FourPointNumeric.octPackedCharge 140 118 20 packedOct140_118_0
      (2*((j.val : Int)+240)+0) := by decide +kernel

end NineSeparatedSubsetSums
