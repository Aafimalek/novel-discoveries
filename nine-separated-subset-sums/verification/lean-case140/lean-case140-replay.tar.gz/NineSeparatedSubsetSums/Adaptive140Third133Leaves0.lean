import NineSeparatedSubsetSums.Adaptive140Third133State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third133Proof21 : runCachedNode 511 128482 Adaptive140Third133Node21 = false := by
  decide +kernel

#print axioms adaptive140Third133Proof21

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third133Proof13 : runCachedNode 511 128482 Adaptive140Third133Node13 = false := by
  decide +kernel

#print axioms adaptive140Third133Proof13

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third133Proof30 : runCachedNode 511 128482 Adaptive140Third133Node30 = false := by
  decide +kernel

#print axioms adaptive140Third133Proof30

end NineSeparatedSubsetSums
