import NineSeparatedSubsetSums.Adaptive140Third130State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third130Proof17 : runCachedNode 511 127983 Adaptive140Third130Node17 = false := by
  decide +kernel

#print axioms adaptive140Third130Proof17

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third130Proof18 : runCachedNode 511 127983 Adaptive140Third130Node18 = false := by
  decide +kernel

#print axioms adaptive140Third130Proof18

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third130Proof9 : runCachedNode 511 127983 Adaptive140Third130Node9 = false := by
  decide +kernel

#print axioms adaptive140Third130Proof9

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third130Proof2 : runCachedNode 511 127983 Adaptive140Third130Node2 = false := by
  decide +kernel

#print axioms adaptive140Third130Proof2

end NineSeparatedSubsetSums
