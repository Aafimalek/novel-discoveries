import NineSeparatedSubsetSums.Adaptive140Third111Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint140Checked

namespace NineSeparatedSubsetSums


theorem adaptive140Third111 : NoDescendingTailAfterThird 140 111 :=
  noDescendingThirdTail_of_cached 140 111 111588 (fun t ht nd => max148_second140_fourPoint_moment_bound (111::t) (by simp [ht]) nd) adaptive140Third111Proof0

#print axioms adaptive140Third111

end NineSeparatedSubsetSums
