import NineSeparatedSubsetSums.Adaptive140Third114State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third114Proof0 : runCachedNode 511 111588 Adaptive140Third114Node0 = false := by
  decide +kernel

#print axioms adaptive140Third114Proof0

end NineSeparatedSubsetSums
