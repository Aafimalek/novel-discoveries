import NineSeparatedSubsetSums.Adaptive140Third120State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third120Proof0 : runCachedNode 511 125608 Adaptive140Third120Node0 = false := by
  decide +kernel

#print axioms adaptive140Third120Proof0

end NineSeparatedSubsetSums
