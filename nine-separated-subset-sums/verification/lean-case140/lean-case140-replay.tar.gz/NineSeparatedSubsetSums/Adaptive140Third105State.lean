import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive140Third105Node0 : CachedSearchNode :=
  ⟨4, 104, computeCenteredMask [148,140,105], 393, 52529⟩

end NineSeparatedSubsetSums
