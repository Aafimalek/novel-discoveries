import NineSeparatedSubsetSums.Adaptive140Third129State
import NineSeparatedSubsetSums.Adaptive140Third129Leaves1
import NineSeparatedSubsetSums.Adaptive140Third129Leaves0

namespace NineSeparatedSubsetSums

theorem adaptive140Third129Proof0 : runCachedNode 511 127696 Adaptive140Third129Node0 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 127696 Adaptive140Third129Node0 = [111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 122, 123, 124, 125, 126, 127, 128] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive140Third129Proof1
  · exact adaptive140Third129Proof2
  · exact adaptive140Third129Proof3
  · exact adaptive140Third129Proof4
  · exact adaptive140Third129Proof5
  · exact adaptive140Third129Proof6
  · exact adaptive140Third129Proof7
  · exact adaptive140Third129Proof8
  · exact adaptive140Third129Proof9
  · exact adaptive140Third129Proof10
  · exact adaptive140Third129Proof11
  · exact adaptive140Third129Proof12
  · exact adaptive140Third129Proof13
  · exact adaptive140Third129Proof14
  · exact adaptive140Third129Proof15
  · exact adaptive140Third129Proof16
  · exact adaptive140Third129Proof17

#print axioms adaptive140Third129Proof0

end NineSeparatedSubsetSums
