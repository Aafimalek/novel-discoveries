import NineSeparatedSubsetSums.EightPoint140_133PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct140_133_1_budget :
    FourPointNumeric.packedBudget 20 packedOct140_133_1 422 = 91599122 := by decide +kernel

#print axioms packedOct140_133_1_budget

end NineSeparatedSubsetSums
