import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive140Third111Node0 : CachedSearchNode :=
  ⟨4, 110, computeCenteredMask [148,140,111], 399, 53825⟩

end NineSeparatedSubsetSums
