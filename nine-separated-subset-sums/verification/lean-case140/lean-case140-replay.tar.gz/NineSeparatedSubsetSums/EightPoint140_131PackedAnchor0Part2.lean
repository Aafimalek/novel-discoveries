import NineSeparatedSubsetSums.EightPoint140_131PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint140_131PackedAnchor0Part2 :
    ∀ j : Fin 8, 2432005 ≤ FourPointNumeric.octPackedCharge 140 131 20 packedOct140_131_0
      (2*((j.val : Int)+240)+1) := by decide +kernel

end NineSeparatedSubsetSums
