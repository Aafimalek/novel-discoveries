import NineSeparatedSubsetSums.Adaptive140Third132State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third132Proof9 : runCachedNode 511 128323 Adaptive140Third132Node9 = false := by
  decide +kernel

#print axioms adaptive140Third132Proof9

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third132Proof59 : runCachedNode 511 128323 Adaptive140Third132Node59 = false := by
  decide +kernel

#print axioms adaptive140Third132Proof59

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third132Proof8 : runCachedNode 511 128323 Adaptive140Third132Node8 = false := by
  decide +kernel

#print axioms adaptive140Third132Proof8

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third132Proof34 : runCachedNode 511 128323 Adaptive140Third132Node34 = false := by
  decide +kernel

#print axioms adaptive140Third132Proof34

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third132Proof7 : runCachedNode 511 128323 Adaptive140Third132Node7 = false := by
  decide +kernel

#print axioms adaptive140Third132Proof7

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third132Proof36 : runCachedNode 511 128323 Adaptive140Third132Node36 = false := by
  decide +kernel

#print axioms adaptive140Third132Proof36

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third132Proof37 : runCachedNode 511 128323 Adaptive140Third132Node37 = false := by
  decide +kernel

#print axioms adaptive140Third132Proof37

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third132Proof57 : runCachedNode 511 128323 Adaptive140Third132Node57 = false := by
  decide +kernel

#print axioms adaptive140Third132Proof57

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third132Proof30 : runCachedNode 511 128323 Adaptive140Third132Node30 = false := by
  decide +kernel

#print axioms adaptive140Third132Proof30

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third132Proof5 : runCachedNode 511 128323 Adaptive140Third132Node5 = false := by
  decide +kernel

#print axioms adaptive140Third132Proof5

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third132Proof58 : runCachedNode 511 128323 Adaptive140Third132Node58 = false := by
  decide +kernel

#print axioms adaptive140Third132Proof58

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third132Proof53 : runCachedNode 511 128323 Adaptive140Third132Node53 = false := by
  decide +kernel

#print axioms adaptive140Third132Proof53

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third132Proof56 : runCachedNode 511 128323 Adaptive140Third132Node56 = false := by
  decide +kernel

#print axioms adaptive140Third132Proof56

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third132Proof33 : runCachedNode 511 128323 Adaptive140Third132Node33 = false := by
  decide +kernel

#print axioms adaptive140Third132Proof33

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third132Proof50 : runCachedNode 511 128323 Adaptive140Third132Node50 = false := by
  decide +kernel

#print axioms adaptive140Third132Proof50

end NineSeparatedSubsetSums
