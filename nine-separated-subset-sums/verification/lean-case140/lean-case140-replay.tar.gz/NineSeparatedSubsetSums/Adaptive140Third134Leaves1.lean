import NineSeparatedSubsetSums.Adaptive140Third134State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third134Proof21 : runCachedNode 511 128648 Adaptive140Third134Node21 = false := by
  decide +kernel

#print axioms adaptive140Third134Proof21

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third134Proof12 : runCachedNode 511 128648 Adaptive140Third134Node12 = false := by
  decide +kernel

#print axioms adaptive140Third134Proof12

end NineSeparatedSubsetSums
