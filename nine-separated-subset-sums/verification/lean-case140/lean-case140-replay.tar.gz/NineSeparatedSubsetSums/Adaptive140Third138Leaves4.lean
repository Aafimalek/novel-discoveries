import NineSeparatedSubsetSums.Adaptive140Third138State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third138Proof21 : runCachedNode 511 129379 Adaptive140Third138Node21 = false := by
  decide +kernel

#print axioms adaptive140Third138Proof21

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third138Proof46 : runCachedNode 511 129379 Adaptive140Third138Node46 = false := by
  decide +kernel

#print axioms adaptive140Third138Proof46

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third138Proof117 : runCachedNode 511 129379 Adaptive140Third138Node117 = false := by
  decide +kernel

#print axioms adaptive140Third138Proof117

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third138Proof194 : runCachedNode 511 129379 Adaptive140Third138Node194 = false := by
  decide +kernel

#print axioms adaptive140Third138Proof194

end NineSeparatedSubsetSums
