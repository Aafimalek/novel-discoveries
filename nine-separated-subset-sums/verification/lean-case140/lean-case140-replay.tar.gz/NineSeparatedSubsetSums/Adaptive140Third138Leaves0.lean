import NineSeparatedSubsetSums.Adaptive140Third138State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third138Proof223 : runCachedNode 511 129379 Adaptive140Third138Node223 = false := by
  decide +kernel

#print axioms adaptive140Third138Proof223

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third138Proof155 : runCachedNode 511 129379 Adaptive140Third138Node155 = false := by
  decide +kernel

#print axioms adaptive140Third138Proof155

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third138Proof55 : runCachedNode 511 129379 Adaptive140Third138Node55 = false := by
  decide +kernel

#print axioms adaptive140Third138Proof55

end NineSeparatedSubsetSums
