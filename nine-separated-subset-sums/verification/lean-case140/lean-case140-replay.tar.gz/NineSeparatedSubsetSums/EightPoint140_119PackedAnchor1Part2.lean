import NineSeparatedSubsetSums.EightPoint140_119PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint140_119PackedAnchor1Part2 :
    ∀ j : Fin 5, 2351837 ≤ FourPointNumeric.octPackedCharge 140 119 20 packedOct140_119_1
      (2*((j.val : Int)+240)+0) := by decide +kernel

end NineSeparatedSubsetSums
