import NineSeparatedSubsetSums.Adaptive140Third112Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint140Checked

namespace NineSeparatedSubsetSums


theorem adaptive140Third112 : NoDescendingTailAfterThird 140 112 :=
  noDescendingThirdTail_of_cached 140 112 111588 (fun t ht nd => max148_second140_fourPoint_moment_bound (112::t) (by simp [ht]) nd) adaptive140Third112Proof0

#print axioms adaptive140Third112

end NineSeparatedSubsetSums
