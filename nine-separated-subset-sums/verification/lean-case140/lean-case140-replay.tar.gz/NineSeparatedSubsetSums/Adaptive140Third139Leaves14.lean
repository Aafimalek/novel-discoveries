import NineSeparatedSubsetSums.Adaptive140Third139State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third139Proof65 : runCachedNode 511 129561 Adaptive140Third139Node65 = false := by
  decide +kernel

#print axioms adaptive140Third139Proof65

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third139Proof188 : runCachedNode 511 129561 Adaptive140Third139Node188 = false := by
  decide +kernel

#print axioms adaptive140Third139Proof188

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third139Proof14 : runCachedNode 511 129561 Adaptive140Third139Node14 = false := by
  decide +kernel

#print axioms adaptive140Third139Proof14

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third139Proof97 : runCachedNode 511 129561 Adaptive140Third139Node97 = false := by
  decide +kernel

#print axioms adaptive140Third139Proof97

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third139Proof69 : runCachedNode 511 129561 Adaptive140Third139Node69 = false := by
  decide +kernel

#print axioms adaptive140Third139Proof69

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third139Proof241 : runCachedNode 511 129561 Adaptive140Third139Node241 = false := by
  decide +kernel

#print axioms adaptive140Third139Proof241

end NineSeparatedSubsetSums
