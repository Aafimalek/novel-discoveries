import NineSeparatedSubsetSums.Adaptive140Third133State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third133Proof47 : runCachedNode 511 128482 Adaptive140Third133Node47 = false := by
  decide +kernel

#print axioms adaptive140Third133Proof47

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third133Proof16 : runCachedNode 511 128482 Adaptive140Third133Node16 = false := by
  decide +kernel

#print axioms adaptive140Third133Proof16

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third133Proof15 : runCachedNode 511 128482 Adaptive140Third133Node15 = false := by
  decide +kernel

#print axioms adaptive140Third133Proof15

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third133Proof5 : runCachedNode 511 128482 Adaptive140Third133Node5 = false := by
  decide +kernel

#print axioms adaptive140Third133Proof5

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third133Proof23 : runCachedNode 511 128482 Adaptive140Third133Node23 = false := by
  decide +kernel

#print axioms adaptive140Third133Proof23

end NineSeparatedSubsetSums
