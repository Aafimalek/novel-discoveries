import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive140Third109Node0 : CachedSearchNode :=
  ⟨4, 108, computeCenteredMask [148,140,109], 397, 53385⟩

end NineSeparatedSubsetSums
