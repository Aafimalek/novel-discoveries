import NineSeparatedSubsetSums.Adaptive140Third137State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third137Proof71 : runCachedNode 511 129199 Adaptive140Third137Node71 = false := by
  decide +kernel

#print axioms adaptive140Third137Proof71

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third137Proof47 : runCachedNode 511 129199 Adaptive140Third137Node47 = false := by
  decide +kernel

#print axioms adaptive140Third137Proof47

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third137Proof69 : runCachedNode 511 129199 Adaptive140Third137Node69 = false := by
  decide +kernel

#print axioms adaptive140Third137Proof69

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third137Proof15 : runCachedNode 511 129199 Adaptive140Third137Node15 = false := by
  decide +kernel

#print axioms adaptive140Third137Proof15

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third137Proof156 : runCachedNode 511 129199 Adaptive140Third137Node156 = false := by
  decide +kernel

#print axioms adaptive140Third137Proof156

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third137Proof157 : runCachedNode 511 129199 Adaptive140Third137Node157 = false := by
  decide +kernel

#print axioms adaptive140Third137Proof157

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third137Proof147 : runCachedNode 511 129199 Adaptive140Third137Node147 = false := by
  decide +kernel

#print axioms adaptive140Third137Proof147

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third137Proof75 : runCachedNode 511 129199 Adaptive140Third137Node75 = false := by
  decide +kernel

#print axioms adaptive140Third137Proof75

end NineSeparatedSubsetSums
