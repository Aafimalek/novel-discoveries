import NineSeparatedSubsetSums.EightPoint140_116PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct140_116_1_budget :
    FourPointNumeric.packedBudget 20 packedOct140_116_1 446 = 85961956 := by decide +kernel

#print axioms packedOct140_116_1_budget

end NineSeparatedSubsetSums
