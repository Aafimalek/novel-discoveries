import NineSeparatedSubsetSums.Adaptive140Third134State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third134Proof18 : runCachedNode 511 128648 Adaptive140Third134Node18 = false := by
  decide +kernel

#print axioms adaptive140Third134Proof18

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third134Proof44 : runCachedNode 511 128648 Adaptive140Third134Node44 = false := by
  decide +kernel

#print axioms adaptive140Third134Proof44

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third134Proof7 : runCachedNode 511 128648 Adaptive140Third134Node7 = false := by
  decide +kernel

#print axioms adaptive140Third134Proof7

end NineSeparatedSubsetSums
