import NineSeparatedSubsetSums.Adaptive140Third134State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third134Proof42 : runCachedNode 511 128648 Adaptive140Third134Node42 = false := by
  decide +kernel

#print axioms adaptive140Third134Proof42

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third134Proof11 : runCachedNode 511 128648 Adaptive140Third134Node11 = false := by
  decide +kernel

#print axioms adaptive140Third134Proof11

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third134Proof43 : runCachedNode 511 128648 Adaptive140Third134Node43 = false := by
  decide +kernel

#print axioms adaptive140Third134Proof43

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third134Proof41 : runCachedNode 511 128648 Adaptive140Third134Node41 = false := by
  decide +kernel

#print axioms adaptive140Third134Proof41

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third134Proof68 : runCachedNode 511 128648 Adaptive140Third134Node68 = false := by
  decide +kernel

#print axioms adaptive140Third134Proof68

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third134Proof40 : runCachedNode 511 128648 Adaptive140Third134Node40 = false := by
  decide +kernel

#print axioms adaptive140Third134Proof40

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third134Proof70 : runCachedNode 511 128648 Adaptive140Third134Node70 = false := by
  decide +kernel

#print axioms adaptive140Third134Proof70

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third134Proof64 : runCachedNode 511 128648 Adaptive140Third134Node64 = false := by
  decide +kernel

#print axioms adaptive140Third134Proof64

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third134Proof9 : runCachedNode 511 128648 Adaptive140Third134Node9 = false := by
  decide +kernel

#print axioms adaptive140Third134Proof9

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third134Proof67 : runCachedNode 511 128648 Adaptive140Third134Node67 = false := by
  decide +kernel

#print axioms adaptive140Third134Proof67

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third134Proof35 : runCachedNode 511 128648 Adaptive140Third134Node35 = false := by
  decide +kernel

#print axioms adaptive140Third134Proof35

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third134Proof66 : runCachedNode 511 128648 Adaptive140Third134Node66 = false := by
  decide +kernel

#print axioms adaptive140Third134Proof66

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third134Proof37 : runCachedNode 511 128648 Adaptive140Third134Node37 = false := by
  decide +kernel

#print axioms adaptive140Third134Proof37

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third134Proof34 : runCachedNode 511 128648 Adaptive140Third134Node34 = false := by
  decide +kernel

#print axioms adaptive140Third134Proof34

end NineSeparatedSubsetSums
