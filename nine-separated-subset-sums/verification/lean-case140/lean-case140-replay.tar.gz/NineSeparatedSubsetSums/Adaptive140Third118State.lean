import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive140Third118Node0 : CachedSearchNode :=
  ⟨4, 117, computeCenteredMask [148,140,118], 406, 55428⟩

end NineSeparatedSubsetSums
