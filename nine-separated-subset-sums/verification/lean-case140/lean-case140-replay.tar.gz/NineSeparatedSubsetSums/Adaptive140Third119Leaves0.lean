import NineSeparatedSubsetSums.Adaptive140Third119State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third119Proof0 : runCachedNode 511 125441 Adaptive140Third119Node0 = false := by
  decide +kernel

#print axioms adaptive140Third119Proof0

end NineSeparatedSubsetSums
