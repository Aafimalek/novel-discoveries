import NineSeparatedSubsetSums.EightPoint140_124PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint140_124PackedAnchor0Part1 :
    ∀ j : Fin 120, 2294738 ≤ FourPointNumeric.octPackedCharge 140 124 20 packedOct140_124_0
      (2*((j.val : Int)+120)+0) := by decide +kernel

end NineSeparatedSubsetSums
