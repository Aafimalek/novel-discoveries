import NineSeparatedSubsetSums.Adaptive140Third138State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third138Proof192 : runCachedNode 511 129379 Adaptive140Third138Node192 = false := by
  decide +kernel

#print axioms adaptive140Third138Proof192

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third138Proof190 : runCachedNode 511 129379 Adaptive140Third138Node190 = false := by
  decide +kernel

#print axioms adaptive140Third138Proof190

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third138Proof31 : runCachedNode 511 129379 Adaptive140Third138Node31 = false := by
  decide +kernel

#print axioms adaptive140Third138Proof31

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third138Proof1 : runCachedNode 511 129379 Adaptive140Third138Node1 = false := by
  decide +kernel

#print axioms adaptive140Third138Proof1

end NineSeparatedSubsetSums
