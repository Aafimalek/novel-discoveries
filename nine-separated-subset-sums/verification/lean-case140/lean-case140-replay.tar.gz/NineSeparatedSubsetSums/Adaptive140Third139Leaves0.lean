import NineSeparatedSubsetSums.Adaptive140Third139State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third139Proof156 : runCachedNode 511 129561 Adaptive140Third139Node156 = false := by
  decide +kernel

#print axioms adaptive140Third139Proof156

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third139Proof12 : runCachedNode 511 129561 Adaptive140Third139Node12 = false := by
  decide +kernel

#print axioms adaptive140Third139Proof12

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third139Proof49 : runCachedNode 511 129561 Adaptive140Third139Node49 = false := by
  decide +kernel

#print axioms adaptive140Third139Proof49

end NineSeparatedSubsetSums
