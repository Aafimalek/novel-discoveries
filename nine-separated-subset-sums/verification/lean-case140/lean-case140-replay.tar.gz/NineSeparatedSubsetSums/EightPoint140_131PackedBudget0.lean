import NineSeparatedSubsetSums.EightPoint140_131PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct140_131_0_budget :
    FourPointNumeric.packedBudget 20 packedOct140_131_0 481 = 89991487 := by decide +kernel

#print axioms packedOct140_131_0_budget

end NineSeparatedSubsetSums
