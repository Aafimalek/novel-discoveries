import NineSeparatedSubsetSums.Adaptive140Third130State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third130Proof15 : runCachedNode 511 127983 Adaptive140Third130Node15 = false := by
  decide +kernel

#print axioms adaptive140Third130Proof15

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third130Proof16 : runCachedNode 511 127983 Adaptive140Third130Node16 = false := by
  decide +kernel

#print axioms adaptive140Third130Proof16

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third130Proof14 : runCachedNode 511 127983 Adaptive140Third130Node14 = false := by
  decide +kernel

#print axioms adaptive140Third130Proof14

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third130Proof13 : runCachedNode 511 127983 Adaptive140Third130Node13 = false := by
  decide +kernel

#print axioms adaptive140Third130Proof13

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third130Proof11 : runCachedNode 511 127983 Adaptive140Third130Node11 = false := by
  decide +kernel

#print axioms adaptive140Third130Proof11

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third130Proof1 : runCachedNode 511 127983 Adaptive140Third130Node1 = false := by
  decide +kernel

#print axioms adaptive140Third130Proof1

end NineSeparatedSubsetSums
