import NineSeparatedSubsetSums.Adaptive140Third121State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third121Proof0 : runCachedNode 511 125771 Adaptive140Third121Node0 = false := by
  decide +kernel

#print axioms adaptive140Third121Proof0

end NineSeparatedSubsetSums
