import NineSeparatedSubsetSums.Adaptive140Third130State
import NineSeparatedSubsetSums.Adaptive140Third130Leaves1
import NineSeparatedSubsetSums.Adaptive140Third130Leaves0
import NineSeparatedSubsetSums.Adaptive140Third130Leaves2

namespace NineSeparatedSubsetSums

theorem adaptive140Third130Proof0 : runCachedNode 511 127983 Adaptive140Third130Node0 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 127983 Adaptive140Third130Node0 = [111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 123, 124, 125, 126, 127, 128, 129] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive140Third130Proof1
  · exact adaptive140Third130Proof2
  · exact adaptive140Third130Proof3
  · exact adaptive140Third130Proof4
  · exact adaptive140Third130Proof5
  · exact adaptive140Third130Proof6
  · exact adaptive140Third130Proof7
  · exact adaptive140Third130Proof8
  · exact adaptive140Third130Proof9
  · exact adaptive140Third130Proof10
  · exact adaptive140Third130Proof11
  · exact adaptive140Third130Proof12
  · exact adaptive140Third130Proof13
  · exact adaptive140Third130Proof14
  · exact adaptive140Third130Proof15
  · exact adaptive140Third130Proof16
  · exact adaptive140Third130Proof17
  · exact adaptive140Third130Proof18

#print axioms adaptive140Third130Proof0

end NineSeparatedSubsetSums
