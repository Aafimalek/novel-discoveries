import NineSeparatedSubsetSums.Adaptive140Third117State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third117Proof0 : runCachedNode 511 124976 Adaptive140Third117Node0 = false := by
  decide +kernel

#print axioms adaptive140Third117Proof0

end NineSeparatedSubsetSums
