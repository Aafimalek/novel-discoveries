import NineSeparatedSubsetSums.Adaptive140Third136State
import NineSeparatedSubsetSums.Adaptive140Third136Leaves9
import NineSeparatedSubsetSums.Adaptive140Third136Leaves14
import NineSeparatedSubsetSums.Adaptive140Third136Leaves5
import NineSeparatedSubsetSums.Adaptive140Third136Leaves13
import NineSeparatedSubsetSums.Adaptive140Third136Leaves4
import NineSeparatedSubsetSums.Adaptive140Third136Leaves12
import NineSeparatedSubsetSums.Adaptive140Third136Leaves10
import NineSeparatedSubsetSums.Adaptive140Third136Leaves11
import NineSeparatedSubsetSums.Adaptive140Third136Leaves6
import NineSeparatedSubsetSums.Adaptive140Third136Leaves8
import NineSeparatedSubsetSums.Adaptive140Third136Leaves3
import NineSeparatedSubsetSums.Adaptive140Third136Leaves7
import NineSeparatedSubsetSums.Adaptive140Third136Leaves2
import NineSeparatedSubsetSums.Adaptive140Third136Leaves0
import NineSeparatedSubsetSums.Adaptive140Third136Leaves1

namespace NineSeparatedSubsetSums

theorem adaptive140Third136Proof22 : runCachedNode 511 129025 Adaptive140Third136Node22 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 129025 Adaptive140Third136Node22 = [104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 121, 122, 123, 125, 126, 127, 129, 130, 131] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive140Third136Proof23
  · exact adaptive140Third136Proof24
  · exact adaptive140Third136Proof25
  · exact adaptive140Third136Proof26
  · exact adaptive140Third136Proof27
  · exact adaptive140Third136Proof28
  · exact adaptive140Third136Proof29
  · exact adaptive140Third136Proof30
  · exact adaptive140Third136Proof31
  · exact adaptive140Third136Proof32
  · exact adaptive140Third136Proof33
  · exact adaptive140Third136Proof34
  · exact adaptive140Third136Proof35
  · exact adaptive140Third136Proof36
  · exact adaptive140Third136Proof37
  · exact adaptive140Third136Proof38
  · exact adaptive140Third136Proof39
  · exact adaptive140Third136Proof40
  · exact adaptive140Third136Proof41
  · exact adaptive140Third136Proof42
  · exact adaptive140Third136Proof43
  · exact adaptive140Third136Proof44
  · exact adaptive140Third136Proof45
  · exact adaptive140Third136Proof46
  · exact adaptive140Third136Proof47

#print axioms adaptive140Third136Proof22

theorem adaptive140Third136Proof48 : runCachedNode 511 129025 Adaptive140Third136Node48 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 129025 Adaptive140Third136Node48 = [104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 122, 123, 124, 126, 127, 130, 131, 132] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive140Third136Proof49
  · exact adaptive140Third136Proof50
  · exact adaptive140Third136Proof51
  · exact adaptive140Third136Proof52
  · exact adaptive140Third136Proof53
  · exact adaptive140Third136Proof54
  · exact adaptive140Third136Proof55
  · exact adaptive140Third136Proof56
  · exact adaptive140Third136Proof57
  · exact adaptive140Third136Proof58
  · exact adaptive140Third136Proof59
  · exact adaptive140Third136Proof60
  · exact adaptive140Third136Proof61
  · exact adaptive140Third136Proof62
  · exact adaptive140Third136Proof63
  · exact adaptive140Third136Proof64
  · exact adaptive140Third136Proof65
  · exact adaptive140Third136Proof66
  · exact adaptive140Third136Proof67
  · exact adaptive140Third136Proof68
  · exact adaptive140Third136Proof69
  · exact adaptive140Third136Proof70
  · exact adaptive140Third136Proof71
  · exact adaptive140Third136Proof72
  · exact adaptive140Third136Proof73

#print axioms adaptive140Third136Proof48

theorem adaptive140Third136Proof99 : runCachedNode 511 129025 Adaptive140Third136Node99 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 129025 Adaptive140Third136Node99 = [94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 115, 116, 117, 119, 121, 123, 125, 127, 129, 131] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive140Third136Proof100
  · exact adaptive140Third136Proof101
  · exact adaptive140Third136Proof102
  · exact adaptive140Third136Proof103
  · exact adaptive140Third136Proof104
  · exact adaptive140Third136Proof105
  · exact adaptive140Third136Proof106
  · exact adaptive140Third136Proof107
  · exact adaptive140Third136Proof108
  · exact adaptive140Third136Proof109
  · exact adaptive140Third136Proof110
  · exact adaptive140Third136Proof111
  · exact adaptive140Third136Proof112
  · exact adaptive140Third136Proof113
  · exact adaptive140Third136Proof114
  · exact adaptive140Third136Proof115
  · exact adaptive140Third136Proof116
  · exact adaptive140Third136Proof117
  · exact adaptive140Third136Proof118
  · exact adaptive140Third136Proof119
  · exact adaptive140Third136Proof120
  · exact adaptive140Third136Proof121
  · exact adaptive140Third136Proof122
  · exact adaptive140Third136Proof123
  · exact adaptive140Third136Proof124
  · exact adaptive140Third136Proof125
  · exact adaptive140Third136Proof126
  · exact adaptive140Third136Proof127
  · exact adaptive140Third136Proof128
  · exact adaptive140Third136Proof129

#print axioms adaptive140Third136Proof99

theorem adaptive140Third136Proof74 : runCachedNode 511 129025 Adaptive140Third136Node74 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 129025 Adaptive140Third136Node74 = [104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 123, 124, 125, 127, 129, 131, 132, 133] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive140Third136Proof75
  · exact adaptive140Third136Proof76
  · exact adaptive140Third136Proof77
  · exact adaptive140Third136Proof78
  · exact adaptive140Third136Proof79
  · exact adaptive140Third136Proof80
  · exact adaptive140Third136Proof81
  · exact adaptive140Third136Proof82
  · exact adaptive140Third136Proof83
  · exact adaptive140Third136Proof84
  · exact adaptive140Third136Proof85
  · exact adaptive140Third136Proof86
  · exact adaptive140Third136Proof87
  · exact adaptive140Third136Proof88
  · exact adaptive140Third136Proof89
  · exact adaptive140Third136Proof90
  · exact adaptive140Third136Proof91
  · exact adaptive140Third136Proof92
  · exact adaptive140Third136Proof93
  · exact adaptive140Third136Proof94
  · exact adaptive140Third136Proof95
  · exact adaptive140Third136Proof96
  · exact adaptive140Third136Proof97
  · exact adaptive140Third136Proof98
  · exact adaptive140Third136Proof99
  · exact adaptive140Third136Proof130

#print axioms adaptive140Third136Proof74

theorem adaptive140Third136Proof131 : runCachedNode 511 129025 Adaptive140Third136Node131 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 129025 Adaptive140Third136Node131 = [103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 124, 125, 126, 129, 130, 132, 133, 134] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive140Third136Proof132
  · exact adaptive140Third136Proof133
  · exact adaptive140Third136Proof134
  · exact adaptive140Third136Proof135
  · exact adaptive140Third136Proof136
  · exact adaptive140Third136Proof137
  · exact adaptive140Third136Proof138
  · exact adaptive140Third136Proof139
  · exact adaptive140Third136Proof140
  · exact adaptive140Third136Proof141
  · exact adaptive140Third136Proof142
  · exact adaptive140Third136Proof143
  · exact adaptive140Third136Proof144
  · exact adaptive140Third136Proof145
  · exact adaptive140Third136Proof146
  · exact adaptive140Third136Proof147
  · exact adaptive140Third136Proof148
  · exact adaptive140Third136Proof149
  · exact adaptive140Third136Proof150
  · exact adaptive140Third136Proof151
  · exact adaptive140Third136Proof152
  · exact adaptive140Third136Proof153
  · exact adaptive140Third136Proof154
  · exact adaptive140Third136Proof155
  · exact adaptive140Third136Proof156
  · exact adaptive140Third136Proof157
  · exact adaptive140Third136Proof158
  · exact adaptive140Third136Proof159

#print axioms adaptive140Third136Proof131

theorem adaptive140Third136Proof0 : runCachedNode 511 129025 Adaptive140Third136Node0 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 129025 Adaptive140Third136Node0 = [110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 129, 130, 131, 132, 133, 134, 135] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive140Third136Proof1
  · exact adaptive140Third136Proof2
  · exact adaptive140Third136Proof3
  · exact adaptive140Third136Proof4
  · exact adaptive140Third136Proof5
  · exact adaptive140Third136Proof6
  · exact adaptive140Third136Proof7
  · exact adaptive140Third136Proof8
  · exact adaptive140Third136Proof9
  · exact adaptive140Third136Proof10
  · exact adaptive140Third136Proof11
  · exact adaptive140Third136Proof12
  · exact adaptive140Third136Proof13
  · exact adaptive140Third136Proof14
  · exact adaptive140Third136Proof15
  · exact adaptive140Third136Proof16
  · exact adaptive140Third136Proof17
  · exact adaptive140Third136Proof18
  · exact adaptive140Third136Proof19
  · exact adaptive140Third136Proof20
  · exact adaptive140Third136Proof21
  · exact adaptive140Third136Proof22
  · exact adaptive140Third136Proof48
  · exact adaptive140Third136Proof74
  · exact adaptive140Third136Proof131

#print axioms adaptive140Third136Proof0

end NineSeparatedSubsetSums
