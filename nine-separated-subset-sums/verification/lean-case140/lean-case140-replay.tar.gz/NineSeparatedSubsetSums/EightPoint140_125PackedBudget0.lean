import NineSeparatedSubsetSums.EightPoint140_125PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct140_125_0_budget :
    FourPointNumeric.packedBudget 20 packedOct140_125_0 489 = 84481435 := by decide +kernel

#print axioms packedOct140_125_0_budget

end NineSeparatedSubsetSums
