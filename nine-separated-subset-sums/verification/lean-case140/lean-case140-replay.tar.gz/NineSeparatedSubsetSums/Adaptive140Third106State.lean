import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive140Third106Node0 : CachedSearchNode :=
  ⟨4, 105, computeCenteredMask [148,140,106], 394, 52740⟩

end NineSeparatedSubsetSums
