import NineSeparatedSubsetSums.EightPoint140_119PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint140_119PackedAnchor0Part0 :
    ∀ j : Fin 120, 2351995 ≤ FourPointNumeric.octPackedCharge 140 119 20 packedOct140_119_0
      (2*((j.val : Int)+0)+1) := by decide +kernel

end NineSeparatedSubsetSums
