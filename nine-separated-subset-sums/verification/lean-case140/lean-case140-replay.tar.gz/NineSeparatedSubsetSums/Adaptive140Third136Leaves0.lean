import NineSeparatedSubsetSums.Adaptive140Third136State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third136Proof157 : runCachedNode 511 129025 Adaptive140Third136Node157 = false := by
  decide +kernel

#print axioms adaptive140Third136Proof157

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third136Proof71 : runCachedNode 511 129025 Adaptive140Third136Node71 = false := by
  decide +kernel

#print axioms adaptive140Third136Proof71

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third136Proof75 : runCachedNode 511 129025 Adaptive140Third136Node75 = false := by
  decide +kernel

#print axioms adaptive140Third136Proof75

end NineSeparatedSubsetSums
