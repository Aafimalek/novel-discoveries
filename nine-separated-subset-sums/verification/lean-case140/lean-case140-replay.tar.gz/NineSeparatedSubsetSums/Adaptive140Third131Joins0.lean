import NineSeparatedSubsetSums.Adaptive140Third131State
import NineSeparatedSubsetSums.Adaptive140Third131Leaves2
import NineSeparatedSubsetSums.Adaptive140Third131Leaves0
import NineSeparatedSubsetSums.Adaptive140Third131Leaves1

namespace NineSeparatedSubsetSums

theorem adaptive140Third131Proof0 : runCachedNode 511 128237 Adaptive140Third131Node0 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 128237 Adaptive140Third131Node0 = [111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 124, 125, 126, 127, 128, 129, 130] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive140Third131Proof1
  · exact adaptive140Third131Proof2
  · exact adaptive140Third131Proof3
  · exact adaptive140Third131Proof4
  · exact adaptive140Third131Proof5
  · exact adaptive140Third131Proof6
  · exact adaptive140Third131Proof7
  · exact adaptive140Third131Proof8
  · exact adaptive140Third131Proof9
  · exact adaptive140Third131Proof10
  · exact adaptive140Third131Proof11
  · exact adaptive140Third131Proof12
  · exact adaptive140Third131Proof13
  · exact adaptive140Third131Proof14
  · exact adaptive140Third131Proof15
  · exact adaptive140Third131Proof16
  · exact adaptive140Third131Proof17
  · exact adaptive140Third131Proof18
  · exact adaptive140Third131Proof19

#print axioms adaptive140Third131Proof0

end NineSeparatedSubsetSums
