import NineSeparatedSubsetSums.Adaptive140Third136State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third136Proof46 : runCachedNode 511 129025 Adaptive140Third136Node46 = false := by
  decide +kernel

#print axioms adaptive140Third136Proof46

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third136Proof127 : runCachedNode 511 129025 Adaptive140Third136Node127 = false := by
  decide +kernel

#print axioms adaptive140Third136Proof127

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third136Proof111 : runCachedNode 511 129025 Adaptive140Third136Node111 = false := by
  decide +kernel

#print axioms adaptive140Third136Proof111

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third136Proof100 : runCachedNode 511 129025 Adaptive140Third136Node100 = false := by
  decide +kernel

#print axioms adaptive140Third136Proof100

end NineSeparatedSubsetSums
