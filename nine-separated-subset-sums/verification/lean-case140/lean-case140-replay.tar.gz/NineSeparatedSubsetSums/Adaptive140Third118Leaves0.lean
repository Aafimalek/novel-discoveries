import NineSeparatedSubsetSums.Adaptive140Third118State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third118Proof0 : runCachedNode 511 125226 Adaptive140Third118Node0 = false := by
  decide +kernel

#print axioms adaptive140Third118Proof0

end NineSeparatedSubsetSums
