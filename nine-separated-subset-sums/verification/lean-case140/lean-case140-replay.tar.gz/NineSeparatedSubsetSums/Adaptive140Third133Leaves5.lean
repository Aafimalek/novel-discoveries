import NineSeparatedSubsetSums.Adaptive140Third133State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third133Proof14 : runCachedNode 511 128482 Adaptive140Third133Node14 = false := by
  decide +kernel

#print axioms adaptive140Third133Proof14

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third133Proof41 : runCachedNode 511 128482 Adaptive140Third133Node41 = false := by
  decide +kernel

#print axioms adaptive140Third133Proof41

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third133Proof11 : runCachedNode 511 128482 Adaptive140Third133Node11 = false := by
  decide +kernel

#print axioms adaptive140Third133Proof11

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third133Proof10 : runCachedNode 511 128482 Adaptive140Third133Node10 = false := by
  decide +kernel

#print axioms adaptive140Third133Proof10

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third133Proof40 : runCachedNode 511 128482 Adaptive140Third133Node40 = false := by
  decide +kernel

#print axioms adaptive140Third133Proof40

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third133Proof9 : runCachedNode 511 128482 Adaptive140Third133Node9 = false := by
  decide +kernel

#print axioms adaptive140Third133Proof9

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third133Proof39 : runCachedNode 511 128482 Adaptive140Third133Node39 = false := by
  decide +kernel

#print axioms adaptive140Third133Proof39

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third133Proof38 : runCachedNode 511 128482 Adaptive140Third133Node38 = false := by
  decide +kernel

#print axioms adaptive140Third133Proof38

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third133Proof36 : runCachedNode 511 128482 Adaptive140Third133Node36 = false := by
  decide +kernel

#print axioms adaptive140Third133Proof36

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third133Proof8 : runCachedNode 511 128482 Adaptive140Third133Node8 = false := by
  decide +kernel

#print axioms adaptive140Third133Proof8

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third133Proof35 : runCachedNode 511 128482 Adaptive140Third133Node35 = false := by
  decide +kernel

#print axioms adaptive140Third133Proof35

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third133Proof37 : runCachedNode 511 128482 Adaptive140Third133Node37 = false := by
  decide +kernel

#print axioms adaptive140Third133Proof37

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third133Proof7 : runCachedNode 511 128482 Adaptive140Third133Node7 = false := by
  decide +kernel

#print axioms adaptive140Third133Proof7

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third133Proof34 : runCachedNode 511 128482 Adaptive140Third133Node34 = false := by
  decide +kernel

#print axioms adaptive140Third133Proof34

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third133Proof6 : runCachedNode 511 128482 Adaptive140Third133Node6 = false := by
  decide +kernel

#print axioms adaptive140Third133Proof6

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third133Proof33 : runCachedNode 511 128482 Adaptive140Third133Node33 = false := by
  decide +kernel

#print axioms adaptive140Third133Proof33

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third133Proof32 : runCachedNode 511 128482 Adaptive140Third133Node32 = false := by
  decide +kernel

#print axioms adaptive140Third133Proof32

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third133Proof31 : runCachedNode 511 128482 Adaptive140Third133Node31 = false := by
  decide +kernel

#print axioms adaptive140Third133Proof31

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third133Proof4 : runCachedNode 511 128482 Adaptive140Third133Node4 = false := by
  decide +kernel

#print axioms adaptive140Third133Proof4

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third133Proof3 : runCachedNode 511 128482 Adaptive140Third133Node3 = false := by
  decide +kernel

#print axioms adaptive140Third133Proof3

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third133Proof28 : runCachedNode 511 128482 Adaptive140Third133Node28 = false := by
  decide +kernel

#print axioms adaptive140Third133Proof28

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third133Proof26 : runCachedNode 511 128482 Adaptive140Third133Node26 = false := by
  decide +kernel

#print axioms adaptive140Third133Proof26

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third133Proof2 : runCachedNode 511 128482 Adaptive140Third133Node2 = false := by
  decide +kernel

#print axioms adaptive140Third133Proof2

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third133Proof1 : runCachedNode 511 128482 Adaptive140Third133Node1 = false := by
  decide +kernel

#print axioms adaptive140Third133Proof1

end NineSeparatedSubsetSums
