import NineSeparatedSubsetSums.Adaptive140Third132State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third132Proof18 : runCachedNode 511 128323 Adaptive140Third132Node18 = false := by
  decide +kernel

#print axioms adaptive140Third132Proof18

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third132Proof6 : runCachedNode 511 128323 Adaptive140Third132Node6 = false := by
  decide +kernel

#print axioms adaptive140Third132Proof6

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third132Proof21 : runCachedNode 511 128323 Adaptive140Third132Node21 = false := by
  decide +kernel

#print axioms adaptive140Third132Proof21

end NineSeparatedSubsetSums
