import NineSeparatedSubsetSums.EightPoint140_132PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint140_132PackedAnchor0Part2 :
    ∀ j : Fin 8, 2437865 ≤ FourPointNumeric.octPackedCharge 140 132 20 packedOct140_132_0
      (2*((j.val : Int)+240)+0) := by decide +kernel

end NineSeparatedSubsetSums
