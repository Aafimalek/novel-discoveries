import NineSeparatedSubsetSums.Adaptive140Third139State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third139Proof161 : runCachedNode 511 129561 Adaptive140Third139Node161 = false := by
  decide +kernel

#print axioms adaptive140Third139Proof161

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third139Proof162 : runCachedNode 511 129561 Adaptive140Third139Node162 = false := by
  decide +kernel

#print axioms adaptive140Third139Proof162

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third139Proof192 : runCachedNode 511 129561 Adaptive140Third139Node192 = false := by
  decide +kernel

#print axioms adaptive140Third139Proof192

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third139Proof193 : runCachedNode 511 129561 Adaptive140Third139Node193 = false := by
  decide +kernel

#print axioms adaptive140Third139Proof193

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third139Proof224 : runCachedNode 511 129561 Adaptive140Third139Node224 = false := by
  decide +kernel

#print axioms adaptive140Third139Proof224

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third139Proof225 : runCachedNode 511 129561 Adaptive140Third139Node225 = false := by
  decide +kernel

#print axioms adaptive140Third139Proof225

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third139Proof226 : runCachedNode 511 129561 Adaptive140Third139Node226 = false := by
  decide +kernel

#print axioms adaptive140Third139Proof226

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third139Proof227 : runCachedNode 511 129561 Adaptive140Third139Node227 = false := by
  decide +kernel

#print axioms adaptive140Third139Proof227

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third139Proof228 : runCachedNode 511 129561 Adaptive140Third139Node228 = false := by
  decide +kernel

#print axioms adaptive140Third139Proof228

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third139Proof229 : runCachedNode 511 129561 Adaptive140Third139Node229 = false := by
  decide +kernel

#print axioms adaptive140Third139Proof229

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third139Proof230 : runCachedNode 511 129561 Adaptive140Third139Node230 = false := by
  decide +kernel

#print axioms adaptive140Third139Proof230

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third139Proof231 : runCachedNode 511 129561 Adaptive140Third139Node231 = false := by
  decide +kernel

#print axioms adaptive140Third139Proof231

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third139Proof232 : runCachedNode 511 129561 Adaptive140Third139Node232 = false := by
  decide +kernel

#print axioms adaptive140Third139Proof232

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third139Proof233 : runCachedNode 511 129561 Adaptive140Third139Node233 = false := by
  decide +kernel

#print axioms adaptive140Third139Proof233

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third139Proof234 : runCachedNode 511 129561 Adaptive140Third139Node234 = false := by
  decide +kernel

#print axioms adaptive140Third139Proof234

end NineSeparatedSubsetSums
