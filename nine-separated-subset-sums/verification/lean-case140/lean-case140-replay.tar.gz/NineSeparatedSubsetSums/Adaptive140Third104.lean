import NineSeparatedSubsetSums.Adaptive140Third104Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint140Checked

namespace NineSeparatedSubsetSums


theorem adaptive140Third104 : NoDescendingTailAfterThird 140 104 :=
  noDescendingThirdTail_of_cached 140 104 111588 (fun t ht nd => max148_second140_fourPoint_moment_bound (104::t) (by simp [ht]) nd) adaptive140Third104Proof0

#print axioms adaptive140Third104

end NineSeparatedSubsetSums
