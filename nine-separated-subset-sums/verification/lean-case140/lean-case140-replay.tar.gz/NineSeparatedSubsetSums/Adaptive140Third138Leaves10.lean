import NineSeparatedSubsetSums.Adaptive140Third138State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third138Proof218 : runCachedNode 511 129379 Adaptive140Third138Node218 = false := by
  decide +kernel

#print axioms adaptive140Third138Proof218

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third138Proof17 : runCachedNode 511 129379 Adaptive140Third138Node17 = false := by
  decide +kernel

#print axioms adaptive140Third138Proof17

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third138Proof221 : runCachedNode 511 129379 Adaptive140Third138Node221 = false := by
  decide +kernel

#print axioms adaptive140Third138Proof221

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third138Proof153 : runCachedNode 511 129379 Adaptive140Third138Node153 = false := by
  decide +kernel

#print axioms adaptive140Third138Proof153

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third138Proof195 : runCachedNode 511 129379 Adaptive140Third138Node195 = false := by
  decide +kernel

#print axioms adaptive140Third138Proof195

end NineSeparatedSubsetSums
