import NineSeparatedSubsetSums.EightPoint140_134PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct140_134_1_budget :
    FourPointNumeric.packedBudget 20 packedOct140_134_1 358 = 91487930 := by decide +kernel

#print axioms packedOct140_134_1_budget

end NineSeparatedSubsetSums
