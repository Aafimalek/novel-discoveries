import NineSeparatedSubsetSums.Adaptive140Third132State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third132Proof55 : runCachedNode 511 128323 Adaptive140Third132Node55 = false := by
  decide +kernel

#print axioms adaptive140Third132Proof55

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third132Proof4 : runCachedNode 511 128323 Adaptive140Third132Node4 = false := by
  decide +kernel

#print axioms adaptive140Third132Proof4

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third132Proof32 : runCachedNode 511 128323 Adaptive140Third132Node32 = false := by
  decide +kernel

#print axioms adaptive140Third132Proof32

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third132Proof31 : runCachedNode 511 128323 Adaptive140Third132Node31 = false := by
  decide +kernel

#print axioms adaptive140Third132Proof31

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third132Proof54 : runCachedNode 511 128323 Adaptive140Third132Node54 = false := by
  decide +kernel

#print axioms adaptive140Third132Proof54

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third132Proof52 : runCachedNode 511 128323 Adaptive140Third132Node52 = false := by
  decide +kernel

#print axioms adaptive140Third132Proof52

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third132Proof3 : runCachedNode 511 128323 Adaptive140Third132Node3 = false := by
  decide +kernel

#print axioms adaptive140Third132Proof3

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third132Proof27 : runCachedNode 511 128323 Adaptive140Third132Node27 = false := by
  decide +kernel

#print axioms adaptive140Third132Proof27

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third132Proof28 : runCachedNode 511 128323 Adaptive140Third132Node28 = false := by
  decide +kernel

#print axioms adaptive140Third132Proof28

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third132Proof51 : runCachedNode 511 128323 Adaptive140Third132Node51 = false := by
  decide +kernel

#print axioms adaptive140Third132Proof51

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third132Proof2 : runCachedNode 511 128323 Adaptive140Third132Node2 = false := by
  decide +kernel

#print axioms adaptive140Third132Proof2

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third132Proof26 : runCachedNode 511 128323 Adaptive140Third132Node26 = false := by
  decide +kernel

#print axioms adaptive140Third132Proof26

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third132Proof49 : runCachedNode 511 128323 Adaptive140Third132Node49 = false := by
  decide +kernel

#print axioms adaptive140Third132Proof49

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third132Proof48 : runCachedNode 511 128323 Adaptive140Third132Node48 = false := by
  decide +kernel

#print axioms adaptive140Third132Proof48

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third132Proof47 : runCachedNode 511 128323 Adaptive140Third132Node47 = false := by
  decide +kernel

#print axioms adaptive140Third132Proof47

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third132Proof24 : runCachedNode 511 128323 Adaptive140Third132Node24 = false := by
  decide +kernel

#print axioms adaptive140Third132Proof24

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third132Proof25 : runCachedNode 511 128323 Adaptive140Third132Node25 = false := by
  decide +kernel

#print axioms adaptive140Third132Proof25

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third132Proof46 : runCachedNode 511 128323 Adaptive140Third132Node46 = false := by
  decide +kernel

#print axioms adaptive140Third132Proof46

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third132Proof23 : runCachedNode 511 128323 Adaptive140Third132Node23 = false := by
  decide +kernel

#print axioms adaptive140Third132Proof23

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third132Proof1 : runCachedNode 511 128323 Adaptive140Third132Node1 = false := by
  decide +kernel

#print axioms adaptive140Third132Proof1

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third132Proof22 : runCachedNode 511 128323 Adaptive140Third132Node22 = false := by
  decide +kernel

#print axioms adaptive140Third132Proof22

end NineSeparatedSubsetSums
