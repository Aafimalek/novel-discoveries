import NineSeparatedSubsetSums.Adaptive140Third138State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third138Proof20 : runCachedNode 511 129379 Adaptive140Third138Node20 = false := by
  decide +kernel

#print axioms adaptive140Third138Proof20

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third138Proof73 : runCachedNode 511 129379 Adaptive140Third138Node73 = false := by
  decide +kernel

#print axioms adaptive140Third138Proof73

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third138Proof87 : runCachedNode 511 129379 Adaptive140Third138Node87 = false := by
  decide +kernel

#print axioms adaptive140Third138Proof87

end NineSeparatedSubsetSums
