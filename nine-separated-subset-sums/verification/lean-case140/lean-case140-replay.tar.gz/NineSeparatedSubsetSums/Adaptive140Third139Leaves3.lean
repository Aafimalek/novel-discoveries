import NineSeparatedSubsetSums.Adaptive140Third139State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third139Proof222 : runCachedNode 511 129561 Adaptive140Third139Node222 = false := by
  decide +kernel

#print axioms adaptive140Third139Proof222

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third139Proof16 : runCachedNode 511 129561 Adaptive140Third139Node16 = false := by
  decide +kernel

#print axioms adaptive140Third139Proof16

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third139Proof4 : runCachedNode 511 129561 Adaptive140Third139Node4 = false := by
  decide +kernel

#print axioms adaptive140Third139Proof4

end NineSeparatedSubsetSums
