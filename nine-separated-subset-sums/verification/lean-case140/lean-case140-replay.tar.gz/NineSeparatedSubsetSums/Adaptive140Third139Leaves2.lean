import NineSeparatedSubsetSums.Adaptive140Third139State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third139Proof219 : runCachedNode 511 129561 Adaptive140Third139Node219 = false := by
  decide +kernel

#print axioms adaptive140Third139Proof219

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third139Proof42 : runCachedNode 511 129561 Adaptive140Third139Node42 = false := by
  decide +kernel

#print axioms adaptive140Third139Proof42

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third139Proof6 : runCachedNode 511 129561 Adaptive140Third139Node6 = false := by
  decide +kernel

#print axioms adaptive140Third139Proof6

end NineSeparatedSubsetSums
