import NineSeparatedSubsetSums.EightPoint140_128PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct140_128_1_budget :
    FourPointNumeric.packedBudget 20 packedOct140_128_1 356 = 86126766 := by decide +kernel

#print axioms packedOct140_128_1_budget

end NineSeparatedSubsetSums
