import NineSeparatedSubsetSums.EightPoint140_131PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint140_131PackedAnchor1Part1 :
    ∀ j : Fin 120, 2432732 ≤ FourPointNumeric.octPackedCharge 140 131 20 packedOct140_131_1
      (2*((j.val : Int)+120)+0) := by decide +kernel

end NineSeparatedSubsetSums
