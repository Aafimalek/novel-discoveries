import NineSeparatedSubsetSums.Adaptive140Third129State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third129Proof14 : runCachedNode 511 127696 Adaptive140Third129Node14 = false := by
  decide +kernel

#print axioms adaptive140Third129Proof14

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third129Proof12 : runCachedNode 511 127696 Adaptive140Third129Node12 = false := by
  decide +kernel

#print axioms adaptive140Third129Proof12

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third129Proof13 : runCachedNode 511 127696 Adaptive140Third129Node13 = false := by
  decide +kernel

#print axioms adaptive140Third129Proof13

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third129Proof11 : runCachedNode 511 127696 Adaptive140Third129Node11 = false := by
  decide +kernel

#print axioms adaptive140Third129Proof11

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third129Proof9 : runCachedNode 511 127696 Adaptive140Third129Node9 = false := by
  decide +kernel

#print axioms adaptive140Third129Proof9

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third129Proof8 : runCachedNode 511 127696 Adaptive140Third129Node8 = false := by
  decide +kernel

#print axioms adaptive140Third129Proof8

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third129Proof7 : runCachedNode 511 127696 Adaptive140Third129Node7 = false := by
  decide +kernel

#print axioms adaptive140Third129Proof7

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third129Proof6 : runCachedNode 511 127696 Adaptive140Third129Node6 = false := by
  decide +kernel

#print axioms adaptive140Third129Proof6

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third129Proof5 : runCachedNode 511 127696 Adaptive140Third129Node5 = false := by
  decide +kernel

#print axioms adaptive140Third129Proof5

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third129Proof4 : runCachedNode 511 127696 Adaptive140Third129Node4 = false := by
  decide +kernel

#print axioms adaptive140Third129Proof4

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third129Proof3 : runCachedNode 511 127696 Adaptive140Third129Node3 = false := by
  decide +kernel

#print axioms adaptive140Third129Proof3

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third129Proof1 : runCachedNode 511 127696 Adaptive140Third129Node1 = false := by
  decide +kernel

#print axioms adaptive140Third129Proof1

end NineSeparatedSubsetSums
