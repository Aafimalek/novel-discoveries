import NineSeparatedSubsetSums.EightPoint140_125PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint140_125PackedAnchor0Part0 :
    ∀ j : Fin 120, 2335312 ≤ FourPointNumeric.octPackedCharge 140 125 20 packedOct140_125_0
      (2*((j.val : Int)+0)+1) := by decide +kernel

end NineSeparatedSubsetSums
