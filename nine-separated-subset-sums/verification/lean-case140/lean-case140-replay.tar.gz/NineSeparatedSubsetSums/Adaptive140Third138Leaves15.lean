import NineSeparatedSubsetSums.Adaptive140Third138State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third138Proof217 : runCachedNode 511 129379 Adaptive140Third138Node217 = false := by
  decide +kernel

#print axioms adaptive140Third138Proof217

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third138Proof184 : runCachedNode 511 129379 Adaptive140Third138Node184 = false := by
  decide +kernel

#print axioms adaptive140Third138Proof184

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third138Proof154 : runCachedNode 511 129379 Adaptive140Third138Node154 = false := by
  decide +kernel

#print axioms adaptive140Third138Proof154

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third138Proof12 : runCachedNode 511 129379 Adaptive140Third138Node12 = false := by
  decide +kernel

#print axioms adaptive140Third138Proof12

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third138Proof70 : runCachedNode 511 129379 Adaptive140Third138Node70 = false := by
  decide +kernel

#print axioms adaptive140Third138Proof70

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third138Proof41 : runCachedNode 511 129379 Adaptive140Third138Node41 = false := by
  decide +kernel

#print axioms adaptive140Third138Proof41

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third138Proof11 : runCachedNode 511 129379 Adaptive140Third138Node11 = false := by
  decide +kernel

#print axioms adaptive140Third138Proof11

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third138Proof122 : runCachedNode 511 129379 Adaptive140Third138Node122 = false := by
  decide +kernel

#print axioms adaptive140Third138Proof122

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third138Proof42 : runCachedNode 511 129379 Adaptive140Third138Node42 = false := by
  decide +kernel

#print axioms adaptive140Third138Proof42

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third138Proof53 : runCachedNode 511 129379 Adaptive140Third138Node53 = false := by
  decide +kernel

#print axioms adaptive140Third138Proof53

end NineSeparatedSubsetSums
