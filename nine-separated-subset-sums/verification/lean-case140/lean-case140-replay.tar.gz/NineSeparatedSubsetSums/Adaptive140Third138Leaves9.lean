import NineSeparatedSubsetSums.Adaptive140Third138State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third138Proof222 : runCachedNode 511 129379 Adaptive140Third138Node222 = false := by
  decide +kernel

#print axioms adaptive140Third138Proof222

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third138Proof71 : runCachedNode 511 129379 Adaptive140Third138Node71 = false := by
  decide +kernel

#print axioms adaptive140Third138Proof71

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third138Proof130 : runCachedNode 511 129379 Adaptive140Third138Node130 = false := by
  decide +kernel

#print axioms adaptive140Third138Proof130

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third138Proof146 : runCachedNode 511 129379 Adaptive140Third138Node146 = false := by
  decide +kernel

#print axioms adaptive140Third138Proof146

end NineSeparatedSubsetSums
