import NineSeparatedSubsetSums.EightPoint140_117PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct140_117_0_budget :
    FourPointNumeric.packedBudget 20 packedOct140_117_0 349 = 86375450 := by decide +kernel

#print axioms packedOct140_117_0_budget

end NineSeparatedSubsetSums
