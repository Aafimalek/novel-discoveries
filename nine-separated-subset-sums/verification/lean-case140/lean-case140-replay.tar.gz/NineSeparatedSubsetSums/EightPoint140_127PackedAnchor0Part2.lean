import NineSeparatedSubsetSums.EightPoint140_127PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint140_127PackedAnchor0Part2 :
    ∀ j : Fin 3, 2355565 ≤ FourPointNumeric.octPackedCharge 140 127 20 packedOct140_127_0
      (2*((j.val : Int)+240)+1) := by decide +kernel

end NineSeparatedSubsetSums
