import NineSeparatedSubsetSums.Adaptive140Third139State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third139Proof220 : runCachedNode 511 129561 Adaptive140Third139Node220 = false := by
  decide +kernel

#print axioms adaptive140Third139Proof220

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third139Proof20 : runCachedNode 511 129561 Adaptive140Third139Node20 = false := by
  decide +kernel

#print axioms adaptive140Third139Proof20

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third139Proof78 : runCachedNode 511 129561 Adaptive140Third139Node78 = false := by
  decide +kernel

#print axioms adaptive140Third139Proof78

end NineSeparatedSubsetSums
