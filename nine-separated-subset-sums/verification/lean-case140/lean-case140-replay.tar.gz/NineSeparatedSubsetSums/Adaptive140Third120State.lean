import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive140Third120Node0 : CachedSearchNode :=
  ⟨4, 119, computeCenteredMask [148,140,120], 408, 55904⟩

end NineSeparatedSubsetSums
