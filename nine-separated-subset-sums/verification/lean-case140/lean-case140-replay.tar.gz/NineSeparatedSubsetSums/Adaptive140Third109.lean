import NineSeparatedSubsetSums.Adaptive140Third109Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint140Checked

namespace NineSeparatedSubsetSums


theorem adaptive140Third109 : NoDescendingTailAfterThird 140 109 :=
  noDescendingThirdTail_of_cached 140 109 111588 (fun t ht nd => max148_second140_fourPoint_moment_bound (109::t) (by simp [ht]) nd) adaptive140Third109Proof0

#print axioms adaptive140Third109

end NineSeparatedSubsetSums
