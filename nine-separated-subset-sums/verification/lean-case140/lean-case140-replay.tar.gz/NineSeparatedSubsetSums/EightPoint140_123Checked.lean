import NineSeparatedSubsetSums.EightPointPackedGeometry
import NineSeparatedSubsetSums.EightPoint140_123PackedBudget0
import NineSeparatedSubsetSums.EightPoint140_123PackedAnchor0Part0
import NineSeparatedSubsetSums.EightPoint140_123PackedAnchor0Part1
import NineSeparatedSubsetSums.EightPoint140_123PackedBudget1
import NineSeparatedSubsetSums.EightPoint140_123PackedAnchor1Part0
import NineSeparatedSubsetSums.EightPoint140_123PackedAnchor1Part1

namespace NineSeparatedSubsetSums

private theorem packedOct140_123Anchor0 :
  ∀ j : Fin 479, ((j.val : Int)+140+123)%2=0 →
    2285652 ≤ FourPointNumeric.octPackedCharge 140 123 20 packedOct140_123_0 (j.val : Int) := by
  intro j hj
  let k := (j.val-1)/2
  have hk : k < 239 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+1 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint140_123PackedAnchor0Part0 z
    rwa [he,hrep] at ht
  let z : Fin 119 := ⟨k-120, by omega⟩
  have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
  have ht := eightPoint140_123PackedAnchor0Part1 z
  rwa [he,hrep] at ht

private theorem packedOct140_123Anchor1 :
  ∀ j : Fin 479, ((j.val : Int)+140+123)%2=1 →
    2285143 ≤ FourPointNumeric.octPackedCharge 140 123 20 packedOct140_123_1 (j.val : Int) := by
  intro j hj
  let k := (j.val-0)/2
  have hk : k < 240 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+0 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint140_123PackedAnchor1Part0 z
    rwa [he,hrep] at ht
  let z : Fin 120 := ⟨k-120, by omega⟩
  have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
  have ht := eightPoint140_123PackedAnchor1Part1 z
  rwa [he,hrep] at ht

def packedOctCertificate140_123_0 : EightPointCertificate 140 123 0 126110 :=
  eightPointCertificateOfPacked 140 123 0 126110 2285652 20 packedOct140_123_0 279 479
    (by decide +kernel) (by decide) packedOct140_123Anchor0
    (by rw [packedOct140_123_0_budget]; decide)

def packedOctCertificate140_123_1 : EightPointCertificate 140 123 1 126110 :=
  eightPointCertificateOfPacked 140 123 1 126110 2285143 20 packedOct140_123_1 478 479
    (by decide +kernel) (by decide) packedOct140_123Anchor1
    (by rw [packedOct140_123_1_budget]; decide)

theorem max148_second140_third123_eightPoint_moment_bound (tail : List ℕ) (len : tail.length=6)
    (distinct : (natSubsetSums (148::140::123::tail)).Nodup) :
    126110 ≤ ((148::140::123::tail).map (· ^ 2)).sum := by
  apply eightPointNatMomentLower 140 123 126110 tail len distinct
  intro p hp
  by_cases h : p=0
  · subst p
    exact packedOctCertificate140_123_0
  · have he : p=1 := hp.resolve_left h
    subst p
    exact packedOctCertificate140_123_1

#print axioms max148_second140_third123_eightPoint_moment_bound

end NineSeparatedSubsetSums
