import NineSeparatedSubsetSums.EightPoint140_134PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint140_134PackedAnchor0Part2 :
    ∀ j : Fin 9, 2459048 ≤ FourPointNumeric.octPackedCharge 140 134 20 packedOct140_134_0
      (2*((j.val : Int)+240)+0) := by decide +kernel

end NineSeparatedSubsetSums
