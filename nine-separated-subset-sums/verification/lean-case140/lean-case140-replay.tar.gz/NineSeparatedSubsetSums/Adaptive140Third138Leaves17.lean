import NineSeparatedSubsetSums.Adaptive140Third138State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third138Proof176 : runCachedNode 511 129379 Adaptive140Third138Node176 = false := by
  decide +kernel

#print axioms adaptive140Third138Proof176

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third138Proof10 : runCachedNode 511 129379 Adaptive140Third138Node10 = false := by
  decide +kernel

#print axioms adaptive140Third138Proof10

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third138Proof38 : runCachedNode 511 129379 Adaptive140Third138Node38 = false := by
  decide +kernel

#print axioms adaptive140Third138Proof38

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third138Proof120 : runCachedNode 511 129379 Adaptive140Third138Node120 = false := by
  decide +kernel

#print axioms adaptive140Third138Proof120

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third138Proof97 : runCachedNode 511 129379 Adaptive140Third138Node97 = false := by
  decide +kernel

#print axioms adaptive140Third138Proof97

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third138Proof150 : runCachedNode 511 129379 Adaptive140Third138Node150 = false := by
  decide +kernel

#print axioms adaptive140Third138Proof150

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third138Proof35 : runCachedNode 511 129379 Adaptive140Third138Node35 = false := by
  decide +kernel

#print axioms adaptive140Third138Proof35

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third138Proof96 : runCachedNode 511 129379 Adaptive140Third138Node96 = false := by
  decide +kernel

#print axioms adaptive140Third138Proof96

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third138Proof179 : runCachedNode 511 129379 Adaptive140Third138Node179 = false := by
  decide +kernel

#print axioms adaptive140Third138Proof179

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third138Proof92 : runCachedNode 511 129379 Adaptive140Third138Node92 = false := by
  decide +kernel

#print axioms adaptive140Third138Proof92

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third138Proof213 : runCachedNode 511 129379 Adaptive140Third138Node213 = false := by
  decide +kernel

#print axioms adaptive140Third138Proof213

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third138Proof37 : runCachedNode 511 129379 Adaptive140Third138Node37 = false := by
  decide +kernel

#print axioms adaptive140Third138Proof37

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third138Proof147 : runCachedNode 511 129379 Adaptive140Third138Node147 = false := by
  decide +kernel

#print axioms adaptive140Third138Proof147

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third138Proof67 : runCachedNode 511 129379 Adaptive140Third138Node67 = false := by
  decide +kernel

#print axioms adaptive140Third138Proof67

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third138Proof68 : runCachedNode 511 129379 Adaptive140Third138Node68 = false := by
  decide +kernel

#print axioms adaptive140Third138Proof68

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third138Proof95 : runCachedNode 511 129379 Adaptive140Third138Node95 = false := by
  decide +kernel

#print axioms adaptive140Third138Proof95

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third138Proof148 : runCachedNode 511 129379 Adaptive140Third138Node148 = false := by
  decide +kernel

#print axioms adaptive140Third138Proof148

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third138Proof36 : runCachedNode 511 129379 Adaptive140Third138Node36 = false := by
  decide +kernel

#print axioms adaptive140Third138Proof36

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third138Proof93 : runCachedNode 511 129379 Adaptive140Third138Node93 = false := by
  decide +kernel

#print axioms adaptive140Third138Proof93

end NineSeparatedSubsetSums
