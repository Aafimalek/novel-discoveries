import NineSeparatedSubsetSums.Adaptive140Third106State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third106Proof0 : runCachedNode 511 111588 Adaptive140Third106Node0 = false := by
  decide +kernel

#print axioms adaptive140Third106Proof0

end NineSeparatedSubsetSums
