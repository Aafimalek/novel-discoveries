import NineSeparatedSubsetSums.Adaptive140Third115Joins0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint140Checked

namespace NineSeparatedSubsetSums


theorem adaptive140Third115 : NoDescendingTailAfterThird 140 115 :=
  noDescendingThirdTail_of_cached 140 115 111588 (fun t ht nd => max148_second140_fourPoint_moment_bound (115::t) (by simp [ht]) nd) adaptive140Third115Proof0

#print axioms adaptive140Third115

end NineSeparatedSubsetSums
