import NineSeparatedSubsetSums.Adaptive140Third135State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third135Proof84 : runCachedNode 511 128865 Adaptive140Third135Node84 = false := by
  decide +kernel

#print axioms adaptive140Third135Proof84

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third135Proof85 : runCachedNode 511 128865 Adaptive140Third135Node85 = false := by
  decide +kernel

#print axioms adaptive140Third135Proof85

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third135Proof4 : runCachedNode 511 128865 Adaptive140Third135Node4 = false := by
  decide +kernel

#print axioms adaptive140Third135Proof4

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third135Proof28 : runCachedNode 511 128865 Adaptive140Third135Node28 = false := by
  decide +kernel

#print axioms adaptive140Third135Proof28

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third135Proof83 : runCachedNode 511 128865 Adaptive140Third135Node83 = false := by
  decide +kernel

#print axioms adaptive140Third135Proof83

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third135Proof57 : runCachedNode 511 128865 Adaptive140Third135Node57 = false := by
  decide +kernel

#print axioms adaptive140Third135Proof57

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third135Proof27 : runCachedNode 511 128865 Adaptive140Third135Node27 = false := by
  decide +kernel

#print axioms adaptive140Third135Proof27

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third135Proof3 : runCachedNode 511 128865 Adaptive140Third135Node3 = false := by
  decide +kernel

#print axioms adaptive140Third135Proof3

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third135Proof56 : runCachedNode 511 128865 Adaptive140Third135Node56 = false := by
  decide +kernel

#print axioms adaptive140Third135Proof56

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third135Proof26 : runCachedNode 511 128865 Adaptive140Third135Node26 = false := by
  decide +kernel

#print axioms adaptive140Third135Proof26

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third135Proof55 : runCachedNode 511 128865 Adaptive140Third135Node55 = false := by
  decide +kernel

#print axioms adaptive140Third135Proof55

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third135Proof82 : runCachedNode 511 128865 Adaptive140Third135Node82 = false := by
  decide +kernel

#print axioms adaptive140Third135Proof82

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third135Proof51 : runCachedNode 511 128865 Adaptive140Third135Node51 = false := by
  decide +kernel

#print axioms adaptive140Third135Proof51

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third135Proof52 : runCachedNode 511 128865 Adaptive140Third135Node52 = false := by
  decide +kernel

#print axioms adaptive140Third135Proof52

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third135Proof53 : runCachedNode 511 128865 Adaptive140Third135Node53 = false := by
  decide +kernel

#print axioms adaptive140Third135Proof53

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third135Proof54 : runCachedNode 511 128865 Adaptive140Third135Node54 = false := by
  decide +kernel

#print axioms adaptive140Third135Proof54

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third135Proof81 : runCachedNode 511 128865 Adaptive140Third135Node81 = false := by
  decide +kernel

#print axioms adaptive140Third135Proof81

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third135Proof25 : runCachedNode 511 128865 Adaptive140Third135Node25 = false := by
  decide +kernel

#print axioms adaptive140Third135Proof25

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third135Proof77 : runCachedNode 511 128865 Adaptive140Third135Node77 = false := by
  decide +kernel

#print axioms adaptive140Third135Proof77

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third135Proof78 : runCachedNode 511 128865 Adaptive140Third135Node78 = false := by
  decide +kernel

#print axioms adaptive140Third135Proof78

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third135Proof79 : runCachedNode 511 128865 Adaptive140Third135Node79 = false := by
  decide +kernel

#print axioms adaptive140Third135Proof79

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third135Proof80 : runCachedNode 511 128865 Adaptive140Third135Node80 = false := by
  decide +kernel

#print axioms adaptive140Third135Proof80

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third135Proof76 : runCachedNode 511 128865 Adaptive140Third135Node76 = false := by
  decide +kernel

#print axioms adaptive140Third135Proof76

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third135Proof50 : runCachedNode 511 128865 Adaptive140Third135Node50 = false := by
  decide +kernel

#print axioms adaptive140Third135Proof50

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third135Proof75 : runCachedNode 511 128865 Adaptive140Third135Node75 = false := by
  decide +kernel

#print axioms adaptive140Third135Proof75

end NineSeparatedSubsetSums
