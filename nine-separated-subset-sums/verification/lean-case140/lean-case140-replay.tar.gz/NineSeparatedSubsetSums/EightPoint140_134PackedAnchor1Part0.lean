import NineSeparatedSubsetSums.EightPoint140_134PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint140_134PackedAnchor1Part0 :
    ∀ j : Fin 120, 2458675 ≤ FourPointNumeric.octPackedCharge 140 134 20 packedOct140_134_1
      (2*((j.val : Int)+0)+1) := by decide +kernel

end NineSeparatedSubsetSums
