import NineSeparatedSubsetSums.EightPoint140_123PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct140_123_1_budget :
    FourPointNumeric.packedBudget 20 packedOct140_123_1 478 = 81680900 := by decide +kernel

#print axioms packedOct140_123_1_budget

end NineSeparatedSubsetSums
