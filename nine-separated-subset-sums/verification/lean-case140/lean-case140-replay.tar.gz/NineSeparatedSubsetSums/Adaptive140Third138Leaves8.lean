import NineSeparatedSubsetSums.Adaptive140Third138State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third138Proof47 : runCachedNode 511 129379 Adaptive140Third138Node47 = false := by
  decide +kernel

#print axioms adaptive140Third138Proof47

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third138Proof18 : runCachedNode 511 129379 Adaptive140Third138Node18 = false := by
  decide +kernel

#print axioms adaptive140Third138Proof18

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third138Proof14 : runCachedNode 511 129379 Adaptive140Third138Node14 = false := by
  decide +kernel

#print axioms adaptive140Third138Proof14

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third138Proof112 : runCachedNode 511 129379 Adaptive140Third138Node112 = false := by
  decide +kernel

#print axioms adaptive140Third138Proof112

end NineSeparatedSubsetSums
