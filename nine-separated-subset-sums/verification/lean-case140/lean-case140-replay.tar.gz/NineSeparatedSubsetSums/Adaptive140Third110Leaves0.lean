import NineSeparatedSubsetSums.Adaptive140Third110State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third110Proof0 : runCachedNode 511 111588 Adaptive140Third110Node0 = false := by
  decide +kernel

#print axioms adaptive140Third110Proof0

end NineSeparatedSubsetSums
