import NineSeparatedSubsetSums.Adaptive140Third135State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third135Proof46 : runCachedNode 511 128865 Adaptive140Third135Node46 = false := by
  decide +kernel

#print axioms adaptive140Third135Proof46

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third135Proof47 : runCachedNode 511 128865 Adaptive140Third135Node47 = false := by
  decide +kernel

#print axioms adaptive140Third135Proof47

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third135Proof42 : runCachedNode 511 128865 Adaptive140Third135Node42 = false := by
  decide +kernel

#print axioms adaptive140Third135Proof42

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third135Proof90 : runCachedNode 511 128865 Adaptive140Third135Node90 = false := by
  decide +kernel

#print axioms adaptive140Third135Proof90

end NineSeparatedSubsetSums
