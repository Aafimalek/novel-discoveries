import NineSeparatedSubsetSums.EightPointPackedGeometry
import NineSeparatedSubsetSums.EightPoint140_136PackedBudget0
import NineSeparatedSubsetSums.EightPoint140_136PackedAnchor0Part0
import NineSeparatedSubsetSums.EightPoint140_136PackedAnchor0Part1
import NineSeparatedSubsetSums.EightPoint140_136PackedAnchor0Part2
import NineSeparatedSubsetSums.EightPoint140_136PackedBudget1
import NineSeparatedSubsetSums.EightPoint140_136PackedAnchor1Part0
import NineSeparatedSubsetSums.EightPoint140_136PackedAnchor1Part1
import NineSeparatedSubsetSums.EightPoint140_136PackedAnchor1Part2

namespace NineSeparatedSubsetSums

private theorem packedOct140_136Anchor0 :
  ∀ j : Fin 500, ((j.val : Int)+140+136)%2=0 →
    2476800 ≤ FourPointNumeric.octPackedCharge 140 136 20 packedOct140_136_0 (j.val : Int) := by
  intro j hj
  let k := (j.val-0)/2
  have hk : k < 250 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+0 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint140_136PackedAnchor0Part0 z
    rwa [he,hrep] at ht
  by_cases h1 : k < 240
  · let z : Fin 120 := ⟨k-120, by omega⟩
    have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
    have ht := eightPoint140_136PackedAnchor0Part1 z
    rwa [he,hrep] at ht
  let z : Fin 10 := ⟨k-240, by omega⟩
  have he : (z.val : Int)+240 = k := by dsimp [z] <;> omega
  have ht := eightPoint140_136PackedAnchor0Part2 z
  rwa [he,hrep] at ht

private theorem packedOct140_136Anchor1 :
  ∀ j : Fin 500, ((j.val : Int)+140+136)%2=1 →
    2470664 ≤ FourPointNumeric.octPackedCharge 140 136 20 packedOct140_136_1 (j.val : Int) := by
  intro j hj
  let k := (j.val-1)/2
  have hk : k < 250 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+1 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint140_136PackedAnchor1Part0 z
    rwa [he,hrep] at ht
  by_cases h1 : k < 240
  · let z : Fin 120 := ⟨k-120, by omega⟩
    have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
    have ht := eightPoint140_136PackedAnchor1Part1 z
    rwa [he,hrep] at ht
  let z : Fin 10 := ⟨k-240, by omega⟩
  have he : (z.val : Int)+240 = k := by dsimp [z] <;> omega
  have ht := eightPoint140_136PackedAnchor1Part2 z
  rwa [he,hrep] at ht

def packedOctCertificate140_136_0 : EightPointCertificate 140 136 0 129025 :=
  eightPointCertificateOfPacked 140 136 0 129025 2476800 20 packedOct140_136_0 267 500
    (by decide +kernel) (by decide) packedOct140_136Anchor0
    (by rw [packedOct140_136_0_budget]; decide)

def packedOctCertificate140_136_1 : EightPointCertificate 140 136 1 129025 :=
  eightPointCertificateOfPacked 140 136 1 129025 2470664 20 packedOct140_136_1 270 500
    (by decide +kernel) (by decide) packedOct140_136Anchor1
    (by rw [packedOct140_136_1_budget]; decide)

theorem max148_second140_third136_eightPoint_moment_bound (tail : List ℕ) (len : tail.length=6)
    (distinct : (natSubsetSums (148::140::136::tail)).Nodup) :
    129025 ≤ ((148::140::136::tail).map (· ^ 2)).sum := by
  apply eightPointNatMomentLower 140 136 129025 tail len distinct
  intro p hp
  by_cases h : p=0
  · subst p
    exact packedOctCertificate140_136_0
  · have he : p=1 := hp.resolve_left h
    subst p
    exact packedOctCertificate140_136_1

#print axioms max148_second140_third136_eightPoint_moment_bound

end NineSeparatedSubsetSums
