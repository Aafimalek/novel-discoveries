import NineSeparatedSubsetSums.EightPointPackedGeometry
import NineSeparatedSubsetSums.EightPoint140_139PackedBudget0
import NineSeparatedSubsetSums.EightPoint140_139PackedAnchor0Part0
import NineSeparatedSubsetSums.EightPoint140_139PackedAnchor0Part1
import NineSeparatedSubsetSums.EightPoint140_139PackedAnchor0Part2
import NineSeparatedSubsetSums.EightPoint140_139PackedBudget1
import NineSeparatedSubsetSums.EightPoint140_139PackedAnchor1Part0
import NineSeparatedSubsetSums.EightPoint140_139PackedAnchor1Part1
import NineSeparatedSubsetSums.EightPoint140_139PackedAnchor1Part2

namespace NineSeparatedSubsetSums

private theorem packedOct140_139Anchor0 :
  ∀ j : Fin 502, ((j.val : Int)+140+139)%2=0 →
    2496630 ≤ FourPointNumeric.octPackedCharge 140 139 20 packedOct140_139_0 (j.val : Int) := by
  intro j hj
  let k := (j.val-1)/2
  have hk : k < 251 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+1 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint140_139PackedAnchor0Part0 z
    rwa [he,hrep] at ht
  by_cases h1 : k < 240
  · let z : Fin 120 := ⟨k-120, by omega⟩
    have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
    have ht := eightPoint140_139PackedAnchor0Part1 z
    rwa [he,hrep] at ht
  let z : Fin 11 := ⟨k-240, by omega⟩
  have he : (z.val : Int)+240 = k := by dsimp [z] <;> omega
  have ht := eightPoint140_139PackedAnchor0Part2 z
  rwa [he,hrep] at ht

private theorem packedOct140_139Anchor1 :
  ∀ j : Fin 502, ((j.val : Int)+140+139)%2=1 →
    2493960 ≤ FourPointNumeric.octPackedCharge 140 139 20 packedOct140_139_1 (j.val : Int) := by
  intro j hj
  let k := (j.val-0)/2
  have hk : k < 251 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+0 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint140_139PackedAnchor1Part0 z
    rwa [he,hrep] at ht
  by_cases h1 : k < 240
  · let z : Fin 120 := ⟨k-120, by omega⟩
    have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
    have ht := eightPoint140_139PackedAnchor1Part1 z
    rwa [he,hrep] at ht
  let z : Fin 11 := ⟨k-240, by omega⟩
  have he : (z.val : Int)+240 = k := by dsimp [z] <;> omega
  have ht := eightPoint140_139PackedAnchor1Part2 z
  rwa [he,hrep] at ht

def packedOctCertificate140_139_0 : EightPointCertificate 140 139 0 129561 :=
  eightPointCertificateOfPacked 140 139 0 129561 2496630 20 packedOct140_139_0 273 502
    (by decide +kernel) (by decide) packedOct140_139Anchor0
    (by rw [packedOct140_139_0_budget]; decide)

def packedOctCertificate140_139_1 : EightPointCertificate 140 139 1 129561 :=
  eightPointCertificateOfPacked 140 139 1 129561 2493960 20 packedOct140_139_1 274 502
    (by decide +kernel) (by decide) packedOct140_139Anchor1
    (by rw [packedOct140_139_1_budget]; decide)

theorem max148_second140_third139_eightPoint_moment_bound (tail : List ℕ) (len : tail.length=6)
    (distinct : (natSubsetSums (148::140::139::tail)).Nodup) :
    129561 ≤ ((148::140::139::tail).map (· ^ 2)).sum := by
  apply eightPointNatMomentLower 140 139 129561 tail len distinct
  intro p hp
  by_cases h : p=0
  · subst p
    exact packedOctCertificate140_139_0
  · have he : p=1 := hp.resolve_left h
    subst p
    exact packedOctCertificate140_139_1

#print axioms max148_second140_third139_eightPoint_moment_bound

end NineSeparatedSubsetSums
