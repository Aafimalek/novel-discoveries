import NineSeparatedSubsetSums.Adaptive140Third139State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third139Proof40 : runCachedNode 511 129561 Adaptive140Third139Node40 = false := by
  decide +kernel

#print axioms adaptive140Third139Proof40

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third139Proof119 : runCachedNode 511 129561 Adaptive140Third139Node119 = false := by
  decide +kernel

#print axioms adaptive140Third139Proof119

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third139Proof94 : runCachedNode 511 129561 Adaptive140Third139Node94 = false := by
  decide +kernel

#print axioms adaptive140Third139Proof94

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third139Proof122 : runCachedNode 511 129561 Adaptive140Third139Node122 = false := by
  decide +kernel

#print axioms adaptive140Third139Proof122

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third139Proof92 : runCachedNode 511 129561 Adaptive140Third139Node92 = false := by
  decide +kernel

#print axioms adaptive140Third139Proof92

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third139Proof63 : runCachedNode 511 129561 Adaptive140Third139Node63 = false := by
  decide +kernel

#print axioms adaptive140Third139Proof63

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third139Proof256 : runCachedNode 511 129561 Adaptive140Third139Node256 = false := by
  decide +kernel

#print axioms adaptive140Third139Proof256

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third139Proof10 : runCachedNode 511 129561 Adaptive140Third139Node10 = false := by
  decide +kernel

#print axioms adaptive140Third139Proof10

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third139Proof90 : runCachedNode 511 129561 Adaptive140Third139Node90 = false := by
  decide +kernel

#print axioms adaptive140Third139Proof90

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third139Proof61 : runCachedNode 511 129561 Adaptive140Third139Node61 = false := by
  decide +kernel

#print axioms adaptive140Third139Proof61

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third139Proof208 : runCachedNode 511 129561 Adaptive140Third139Node208 = false := by
  decide +kernel

#print axioms adaptive140Third139Proof208

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third139Proof91 : runCachedNode 511 129561 Adaptive140Third139Node91 = false := by
  decide +kernel

#print axioms adaptive140Third139Proof91

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third139Proof93 : runCachedNode 511 129561 Adaptive140Third139Node93 = false := by
  decide +kernel

#print axioms adaptive140Third139Proof93

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third139Proof60 : runCachedNode 511 129561 Adaptive140Third139Node60 = false := by
  decide +kernel

#print axioms adaptive140Third139Proof60

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third139Proof149 : runCachedNode 511 129561 Adaptive140Third139Node149 = false := by
  decide +kernel

#print axioms adaptive140Third139Proof149

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third139Proof37 : runCachedNode 511 129561 Adaptive140Third139Node37 = false := by
  decide +kernel

#print axioms adaptive140Third139Proof37

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third139Proof181 : runCachedNode 511 129561 Adaptive140Third139Node181 = false := by
  decide +kernel

#print axioms adaptive140Third139Proof181

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third139Proof205 : runCachedNode 511 129561 Adaptive140Third139Node205 = false := by
  decide +kernel

#print axioms adaptive140Third139Proof205

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third139Proof75 : runCachedNode 511 129561 Adaptive140Third139Node75 = false := by
  decide +kernel

#print axioms adaptive140Third139Proof75

end NineSeparatedSubsetSums
