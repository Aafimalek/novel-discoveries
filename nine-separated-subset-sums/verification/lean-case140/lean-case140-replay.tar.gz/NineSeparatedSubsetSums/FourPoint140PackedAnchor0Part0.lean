import NineSeparatedSubsetSums.FourPoint140PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem fourPoint140PackedAnchor0Part0 :
    ∀ j : Fin 120, 1087616 ≤ FourPointNumeric.packedCharge 140 20 packedWeight140_0
      (2*((j.val : Int)+0)+0) := by decide +kernel

end NineSeparatedSubsetSums
