import NineSeparatedSubsetSums.Adaptive140Third139State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third139Proof96 : runCachedNode 511 129561 Adaptive140Third139Node96 = false := by
  decide +kernel

#print axioms adaptive140Third139Proof96

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third139Proof124 : runCachedNode 511 129561 Adaptive140Third139Node124 = false := by
  decide +kernel

#print axioms adaptive140Third139Proof124

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third139Proof214 : runCachedNode 511 129561 Adaptive140Third139Node214 = false := by
  decide +kernel

#print axioms adaptive140Third139Proof214

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third139Proof155 : runCachedNode 511 129561 Adaptive140Third139Node155 = false := by
  decide +kernel

#print axioms adaptive140Third139Proof155

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third139Proof213 : runCachedNode 511 129561 Adaptive140Third139Node213 = false := by
  decide +kernel

#print axioms adaptive140Third139Proof213

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third139Proof66 : runCachedNode 511 129561 Adaptive140Third139Node66 = false := by
  decide +kernel

#print axioms adaptive140Third139Proof66

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third139Proof212 : runCachedNode 511 129561 Adaptive140Third139Node212 = false := by
  decide +kernel

#print axioms adaptive140Third139Proof212

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third139Proof204 : runCachedNode 511 129561 Adaptive140Third139Node204 = false := by
  decide +kernel

#print axioms adaptive140Third139Proof204

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third139Proof46 : runCachedNode 511 129561 Adaptive140Third139Node46 = false := by
  decide +kernel

#print axioms adaptive140Third139Proof46

end NineSeparatedSubsetSums
