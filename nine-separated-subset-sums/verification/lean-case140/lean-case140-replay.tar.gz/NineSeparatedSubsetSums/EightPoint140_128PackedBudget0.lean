import NineSeparatedSubsetSums.EightPoint140_128PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct140_128_0_budget :
    FourPointNumeric.packedBudget 20 packedOct140_128_0 279 = 86126267 := by decide +kernel

#print axioms packedOct140_128_0_budget

end NineSeparatedSubsetSums
