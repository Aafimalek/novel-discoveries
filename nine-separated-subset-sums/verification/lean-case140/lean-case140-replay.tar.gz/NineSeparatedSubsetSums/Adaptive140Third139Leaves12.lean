import NineSeparatedSubsetSums.Adaptive140Third139State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third139Proof18 : runCachedNode 511 129561 Adaptive140Third139Node18 = false := by
  decide +kernel

#print axioms adaptive140Third139Proof18

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third139Proof98 : runCachedNode 511 129561 Adaptive140Third139Node98 = false := by
  decide +kernel

#print axioms adaptive140Third139Proof98

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third139Proof217 : runCachedNode 511 129561 Adaptive140Third139Node217 = false := by
  decide +kernel

#print axioms adaptive140Third139Proof217

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third139Proof56 : runCachedNode 511 129561 Adaptive140Third139Node56 = false := by
  decide +kernel

#print axioms adaptive140Third139Proof56

end NineSeparatedSubsetSums
