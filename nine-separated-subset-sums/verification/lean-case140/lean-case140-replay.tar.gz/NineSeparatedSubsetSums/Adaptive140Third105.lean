import NineSeparatedSubsetSums.Adaptive140Third105Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint140Checked

namespace NineSeparatedSubsetSums


theorem adaptive140Third105 : NoDescendingTailAfterThird 140 105 :=
  noDescendingThirdTail_of_cached 140 105 111588 (fun t ht nd => max148_second140_fourPoint_moment_bound (105::t) (by simp [ht]) nd) adaptive140Third105Proof0

#print axioms adaptive140Third105

end NineSeparatedSubsetSums
