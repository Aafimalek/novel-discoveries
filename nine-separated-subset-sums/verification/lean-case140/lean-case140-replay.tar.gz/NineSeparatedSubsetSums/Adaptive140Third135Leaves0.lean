import NineSeparatedSubsetSums.Adaptive140Third135State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third135Proof21 : runCachedNode 511 128865 Adaptive140Third135Node21 = false := by
  decide +kernel

#print axioms adaptive140Third135Proof21

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third135Proof11 : runCachedNode 511 128865 Adaptive140Third135Node11 = false := by
  decide +kernel

#print axioms adaptive140Third135Proof11

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third135Proof1 : runCachedNode 511 128865 Adaptive140Third135Node1 = false := by
  decide +kernel

#print axioms adaptive140Third135Proof1

end NineSeparatedSubsetSums
