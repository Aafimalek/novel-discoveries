import NineSeparatedSubsetSums.Adaptive140Third138State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third138Proof186 : runCachedNode 511 129379 Adaptive140Third138Node186 = false := by
  decide +kernel

#print axioms adaptive140Third138Proof186

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third138Proof156 : runCachedNode 511 129379 Adaptive140Third138Node156 = false := by
  decide +kernel

#print axioms adaptive140Third138Proof156

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third138Proof99 : runCachedNode 511 129379 Adaptive140Third138Node99 = false := by
  decide +kernel

#print axioms adaptive140Third138Proof99

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third138Proof128 : runCachedNode 511 129379 Adaptive140Third138Node128 = false := by
  decide +kernel

#print axioms adaptive140Third138Proof128

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third138Proof72 : runCachedNode 511 129379 Adaptive140Third138Node72 = false := by
  decide +kernel

#print axioms adaptive140Third138Proof72

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third138Proof185 : runCachedNode 511 129379 Adaptive140Third138Node185 = false := by
  decide +kernel

#print axioms adaptive140Third138Proof185

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third138Proof180 : runCachedNode 511 129379 Adaptive140Third138Node180 = false := by
  decide +kernel

#print axioms adaptive140Third138Proof180

end NineSeparatedSubsetSums
