import NineSeparatedSubsetSums.Adaptive140Third137State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third137Proof158 : runCachedNode 511 129199 Adaptive140Third137Node158 = false := by
  decide +kernel

#print axioms adaptive140Third137Proof158

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third137Proof125 : runCachedNode 511 129199 Adaptive140Third137Node125 = false := by
  decide +kernel

#print axioms adaptive140Third137Proof125

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third137Proof3 : runCachedNode 511 129199 Adaptive140Third137Node3 = false := by
  decide +kernel

#print axioms adaptive140Third137Proof3

end NineSeparatedSubsetSums
