import NineSeparatedSubsetSums.Adaptive140Third135State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third135Proof17 : runCachedNode 511 128865 Adaptive140Third135Node17 = false := by
  decide +kernel

#print axioms adaptive140Third135Proof17

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third135Proof97 : runCachedNode 511 128865 Adaptive140Third135Node97 = false := by
  decide +kernel

#print axioms adaptive140Third135Proof97

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third135Proof13 : runCachedNode 511 128865 Adaptive140Third135Node13 = false := by
  decide +kernel

#print axioms adaptive140Third135Proof13

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third135Proof98 : runCachedNode 511 128865 Adaptive140Third135Node98 = false := by
  decide +kernel

#print axioms adaptive140Third135Proof98

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third135Proof12 : runCachedNode 511 128865 Adaptive140Third135Node12 = false := by
  decide +kernel

#print axioms adaptive140Third135Proof12

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third135Proof23 : runCachedNode 511 128865 Adaptive140Third135Node23 = false := by
  decide +kernel

#print axioms adaptive140Third135Proof23

end NineSeparatedSubsetSums
