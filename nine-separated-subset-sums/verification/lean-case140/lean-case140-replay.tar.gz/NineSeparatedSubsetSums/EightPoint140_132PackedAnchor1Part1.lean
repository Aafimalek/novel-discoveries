import NineSeparatedSubsetSums.EightPoint140_132PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint140_132PackedAnchor1Part1 :
    ∀ j : Fin 120, 2436989 ≤ FourPointNumeric.octPackedCharge 140 132 20 packedOct140_132_1
      (2*((j.val : Int)+120)+1) := by decide +kernel

end NineSeparatedSubsetSums
