import NineSeparatedSubsetSums.EightPointPackedGeometry
import NineSeparatedSubsetSums.EightPoint140_121PackedBudget0
import NineSeparatedSubsetSums.EightPoint140_121PackedAnchor0Part0
import NineSeparatedSubsetSums.EightPoint140_121PackedAnchor0Part1
import NineSeparatedSubsetSums.EightPoint140_121PackedAnchor0Part2
import NineSeparatedSubsetSums.EightPoint140_121PackedBudget1
import NineSeparatedSubsetSums.EightPoint140_121PackedAnchor1Part0
import NineSeparatedSubsetSums.EightPoint140_121PackedAnchor1Part1
import NineSeparatedSubsetSums.EightPoint140_121PackedAnchor1Part2

namespace NineSeparatedSubsetSums

private theorem packedOct140_121Anchor0 :
  ∀ j : Fin 486, ((j.val : Int)+140+121)%2=0 →
    2331233 ≤ FourPointNumeric.octPackedCharge 140 121 20 packedOct140_121_0 (j.val : Int) := by
  intro j hj
  let k := (j.val-1)/2
  have hk : k < 243 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+1 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint140_121PackedAnchor0Part0 z
    rwa [he,hrep] at ht
  by_cases h1 : k < 240
  · let z : Fin 120 := ⟨k-120, by omega⟩
    have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
    have ht := eightPoint140_121PackedAnchor0Part1 z
    rwa [he,hrep] at ht
  let z : Fin 3 := ⟨k-240, by omega⟩
  have he : (z.val : Int)+240 = k := by dsimp [z] <;> omega
  have ht := eightPoint140_121PackedAnchor0Part2 z
  rwa [he,hrep] at ht

private theorem packedOct140_121Anchor1 :
  ∀ j : Fin 486, ((j.val : Int)+140+121)%2=1 →
    2327306 ≤ FourPointNumeric.octPackedCharge 140 121 20 packedOct140_121_1 (j.val : Int) := by
  intro j hj
  let k := (j.val-0)/2
  have hk : k < 243 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+0 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint140_121PackedAnchor1Part0 z
    rwa [he,hrep] at ht
  by_cases h1 : k < 240
  · let z : Fin 120 := ⟨k-120, by omega⟩
    have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
    have ht := eightPoint140_121PackedAnchor1Part1 z
    rwa [he,hrep] at ht
  let z : Fin 3 := ⟨k-240, by omega⟩
  have he : (z.val : Int)+240 = k := by dsimp [z] <;> omega
  have ht := eightPoint140_121PackedAnchor1Part2 z
  rwa [he,hrep] at ht

def packedOctCertificate140_121_0 : EightPointCertificate 140 121 0 125771 :=
  eightPointCertificateOfPacked 140 121 0 125771 2331233 20 packedOct140_121_0 271 486
    (by decide +kernel) (by decide) packedOct140_121Anchor0
    (by rw [packedOct140_121_0_budget]; decide)

def packedOctCertificate140_121_1 : EightPointCertificate 140 121 1 125771 :=
  eightPointCertificateOfPacked 140 121 1 125771 2327306 20 packedOct140_121_1 270 486
    (by decide +kernel) (by decide) packedOct140_121Anchor1
    (by rw [packedOct140_121_1_budget]; decide)

theorem max148_second140_third121_eightPoint_moment_bound (tail : List ℕ) (len : tail.length=6)
    (distinct : (natSubsetSums (148::140::121::tail)).Nodup) :
    125771 ≤ ((148::140::121::tail).map (· ^ 2)).sum := by
  apply eightPointNatMomentLower 140 121 125771 tail len distinct
  intro p hp
  by_cases h : p=0
  · subst p
    exact packedOctCertificate140_121_0
  · have he : p=1 := hp.resolve_left h
    subst p
    exact packedOctCertificate140_121_1

#print axioms max148_second140_third121_eightPoint_moment_bound

end NineSeparatedSubsetSums
