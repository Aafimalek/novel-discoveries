import NineSeparatedSubsetSums.EightPoint140_123PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint140_123PackedAnchor1Part0 :
    ∀ j : Fin 120, 2285143 ≤ FourPointNumeric.octPackedCharge 140 123 20 packedOct140_123_1
      (2*((j.val : Int)+0)+0) := by decide +kernel

end NineSeparatedSubsetSums
