import NineSeparatedSubsetSums.Adaptive140Third133State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third133Proof42 : runCachedNode 511 128482 Adaptive140Third133Node42 = false := by
  decide +kernel

#print axioms adaptive140Third133Proof42

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third133Proof46 : runCachedNode 511 128482 Adaptive140Third133Node46 = false := by
  decide +kernel

#print axioms adaptive140Third133Proof46

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third133Proof45 : runCachedNode 511 128482 Adaptive140Third133Node45 = false := by
  decide +kernel

#print axioms adaptive140Third133Proof45

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third133Proof44 : runCachedNode 511 128482 Adaptive140Third133Node44 = false := by
  decide +kernel

#print axioms adaptive140Third133Proof44

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third133Proof43 : runCachedNode 511 128482 Adaptive140Third133Node43 = false := by
  decide +kernel

#print axioms adaptive140Third133Proof43

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third133Proof29 : runCachedNode 511 128482 Adaptive140Third133Node29 = false := by
  decide +kernel

#print axioms adaptive140Third133Proof29

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third133Proof24 : runCachedNode 511 128482 Adaptive140Third133Node24 = false := by
  decide +kernel

#print axioms adaptive140Third133Proof24

end NineSeparatedSubsetSums
