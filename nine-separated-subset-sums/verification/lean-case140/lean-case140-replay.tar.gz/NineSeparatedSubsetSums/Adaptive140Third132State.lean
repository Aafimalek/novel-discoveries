import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive140Third132Node0 : CachedSearchNode :=
  ⟨4, 131, computeCenteredMask [148,140,132], 420, 58928⟩
def Adaptive140Third132Node1 : CachedSearchNode := cachedChild Adaptive140Third132Node0 111
def Adaptive140Third132Node2 : CachedSearchNode := cachedChild Adaptive140Third132Node0 112
def Adaptive140Third132Node3 : CachedSearchNode := cachedChild Adaptive140Third132Node0 113
def Adaptive140Third132Node4 : CachedSearchNode := cachedChild Adaptive140Third132Node0 114
def Adaptive140Third132Node5 : CachedSearchNode := cachedChild Adaptive140Third132Node0 115
def Adaptive140Third132Node6 : CachedSearchNode := cachedChild Adaptive140Third132Node0 116
def Adaptive140Third132Node7 : CachedSearchNode := cachedChild Adaptive140Third132Node0 117
def Adaptive140Third132Node8 : CachedSearchNode := cachedChild Adaptive140Third132Node0 118
def Adaptive140Third132Node9 : CachedSearchNode := cachedChild Adaptive140Third132Node0 119
def Adaptive140Third132Node10 : CachedSearchNode := cachedChild Adaptive140Third132Node0 120
def Adaptive140Third132Node11 : CachedSearchNode := cachedChild Adaptive140Third132Node0 121
def Adaptive140Third132Node12 : CachedSearchNode := cachedChild Adaptive140Third132Node0 122
def Adaptive140Third132Node13 : CachedSearchNode := cachedChild Adaptive140Third132Node0 123
def Adaptive140Third132Node14 : CachedSearchNode := cachedChild Adaptive140Third132Node0 125
def Adaptive140Third132Node15 : CachedSearchNode := cachedChild Adaptive140Third132Node0 126
def Adaptive140Third132Node16 : CachedSearchNode := cachedChild Adaptive140Third132Node0 127
def Adaptive140Third132Node17 : CachedSearchNode := cachedChild Adaptive140Third132Node0 128
def Adaptive140Third132Node18 : CachedSearchNode := cachedChild Adaptive140Third132Node0 129
def Adaptive140Third132Node19 : CachedSearchNode := cachedChild Adaptive140Third132Node0 130
def Adaptive140Third132Node20 : CachedSearchNode := cachedChild Adaptive140Third132Node19 105
def Adaptive140Third132Node21 : CachedSearchNode := cachedChild Adaptive140Third132Node19 106
def Adaptive140Third132Node22 : CachedSearchNode := cachedChild Adaptive140Third132Node19 107
def Adaptive140Third132Node23 : CachedSearchNode := cachedChild Adaptive140Third132Node19 108
def Adaptive140Third132Node24 : CachedSearchNode := cachedChild Adaptive140Third132Node19 109
def Adaptive140Third132Node25 : CachedSearchNode := cachedChild Adaptive140Third132Node19 110
def Adaptive140Third132Node26 : CachedSearchNode := cachedChild Adaptive140Third132Node19 111
def Adaptive140Third132Node27 : CachedSearchNode := cachedChild Adaptive140Third132Node19 112
def Adaptive140Third132Node28 : CachedSearchNode := cachedChild Adaptive140Third132Node19 113
def Adaptive140Third132Node29 : CachedSearchNode := cachedChild Adaptive140Third132Node19 115
def Adaptive140Third132Node30 : CachedSearchNode := cachedChild Adaptive140Third132Node19 116
def Adaptive140Third132Node31 : CachedSearchNode := cachedChild Adaptive140Third132Node19 117
def Adaptive140Third132Node32 : CachedSearchNode := cachedChild Adaptive140Third132Node19 118
def Adaptive140Third132Node33 : CachedSearchNode := cachedChild Adaptive140Third132Node19 119
def Adaptive140Third132Node34 : CachedSearchNode := cachedChild Adaptive140Third132Node19 120
def Adaptive140Third132Node35 : CachedSearchNode := cachedChild Adaptive140Third132Node19 121
def Adaptive140Third132Node36 : CachedSearchNode := cachedChild Adaptive140Third132Node19 123
def Adaptive140Third132Node37 : CachedSearchNode := cachedChild Adaptive140Third132Node19 125
def Adaptive140Third132Node38 : CachedSearchNode := cachedChild Adaptive140Third132Node19 126
def Adaptive140Third132Node39 : CachedSearchNode := cachedChild Adaptive140Third132Node19 127
def Adaptive140Third132Node40 : CachedSearchNode := cachedChild Adaptive140Third132Node19 128
def Adaptive140Third132Node41 : CachedSearchNode := cachedChild Adaptive140Third132Node19 129
def Adaptive140Third132Node42 : CachedSearchNode := cachedChild Adaptive140Third132Node0 131
def Adaptive140Third132Node43 : CachedSearchNode := cachedChild Adaptive140Third132Node42 105
def Adaptive140Third132Node44 : CachedSearchNode := cachedChild Adaptive140Third132Node42 106
def Adaptive140Third132Node45 : CachedSearchNode := cachedChild Adaptive140Third132Node42 107
def Adaptive140Third132Node46 : CachedSearchNode := cachedChild Adaptive140Third132Node42 108
def Adaptive140Third132Node47 : CachedSearchNode := cachedChild Adaptive140Third132Node42 109
def Adaptive140Third132Node48 : CachedSearchNode := cachedChild Adaptive140Third132Node42 110
def Adaptive140Third132Node49 : CachedSearchNode := cachedChild Adaptive140Third132Node42 111
def Adaptive140Third132Node50 : CachedSearchNode := cachedChild Adaptive140Third132Node42 112
def Adaptive140Third132Node51 : CachedSearchNode := cachedChild Adaptive140Third132Node42 113
def Adaptive140Third132Node52 : CachedSearchNode := cachedChild Adaptive140Third132Node42 114
def Adaptive140Third132Node53 : CachedSearchNode := cachedChild Adaptive140Third132Node42 116
def Adaptive140Third132Node54 : CachedSearchNode := cachedChild Adaptive140Third132Node42 117
def Adaptive140Third132Node55 : CachedSearchNode := cachedChild Adaptive140Third132Node42 118
def Adaptive140Third132Node56 : CachedSearchNode := cachedChild Adaptive140Third132Node42 119
def Adaptive140Third132Node57 : CachedSearchNode := cachedChild Adaptive140Third132Node42 120
def Adaptive140Third132Node58 : CachedSearchNode := cachedChild Adaptive140Third132Node42 121
def Adaptive140Third132Node59 : CachedSearchNode := cachedChild Adaptive140Third132Node42 122
def Adaptive140Third132Node60 : CachedSearchNode := cachedChild Adaptive140Third132Node42 125
def Adaptive140Third132Node61 : CachedSearchNode := cachedChild Adaptive140Third132Node42 126
def Adaptive140Third132Node62 : CachedSearchNode := cachedChild Adaptive140Third132Node42 127
def Adaptive140Third132Node63 : CachedSearchNode := cachedChild Adaptive140Third132Node42 128
def Adaptive140Third132Node64 : CachedSearchNode := cachedChild Adaptive140Third132Node42 129
def Adaptive140Third132Node65 : CachedSearchNode := cachedChild Adaptive140Third132Node42 130

end NineSeparatedSubsetSums
