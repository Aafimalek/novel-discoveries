import NineSeparatedSubsetSums.Adaptive140Third110Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint140Checked

namespace NineSeparatedSubsetSums


theorem adaptive140Third110 : NoDescendingTailAfterThird 140 110 :=
  noDescendingThirdTail_of_cached 140 110 111588 (fun t ht nd => max148_second140_fourPoint_moment_bound (110::t) (by simp [ht]) nd) adaptive140Third110Proof0

#print axioms adaptive140Third110

end NineSeparatedSubsetSums
