import NineSeparatedSubsetSums.EightPoint140_130PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct140_130_1_budget :
    FourPointNumeric.packedBudget 20 packedOct140_130_1 436 = 88384618 := by decide +kernel

#print axioms packedOct140_130_1_budget

end NineSeparatedSubsetSums
