import NineSeparatedSubsetSums.Adaptive140Third138State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third138Proof220 : runCachedNode 511 129379 Adaptive140Third138Node220 = false := by
  decide +kernel

#print axioms adaptive140Third138Proof220

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third138Proof45 : runCachedNode 511 129379 Adaptive140Third138Node45 = false := by
  decide +kernel

#print axioms adaptive140Third138Proof45

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third138Proof151 : runCachedNode 511 129379 Adaptive140Third138Node151 = false := by
  decide +kernel

#print axioms adaptive140Third138Proof151

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third138Proof23 : runCachedNode 511 129379 Adaptive140Third138Node23 = false := by
  decide +kernel

#print axioms adaptive140Third138Proof23

end NineSeparatedSubsetSums
