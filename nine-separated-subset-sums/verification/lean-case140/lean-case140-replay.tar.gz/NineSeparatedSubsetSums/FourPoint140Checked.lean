import NineSeparatedSubsetSums.FourPointPackedGeometry
import NineSeparatedSubsetSums.FourPoint140PackedBudget0
import NineSeparatedSubsetSums.FourPoint140PackedAnchor0Part0
import NineSeparatedSubsetSums.FourPoint140PackedAnchor0Part1
import NineSeparatedSubsetSums.FourPoint140PackedAnchor0Part2
import NineSeparatedSubsetSums.FourPoint140PackedBudget1
import NineSeparatedSubsetSums.FourPoint140PackedAnchor1Part0
import NineSeparatedSubsetSums.FourPoint140PackedAnchor1Part1

namespace NineSeparatedSubsetSums

private theorem packed140Anchor0 :
  ∀ j : Fin 481, ((j.val : Int)+140)%2=0 →
    1087616 ≤ FourPointNumeric.packedCharge 140 20 packedWeight140_0 (j.val : Int) := by
  intro j hj
  let k := (j.val-0)/2
  have hk : k < 241 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+0 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := fourPoint140PackedAnchor0Part0 z
    rwa [he,hrep] at ht
  by_cases h1 : k < 240
  · let z : Fin 120 := ⟨k-120, by omega⟩
    have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
    have ht := fourPoint140PackedAnchor0Part1 z
    rwa [he,hrep] at ht
  let z : Fin 1 := ⟨k-240, by omega⟩
  have he : (z.val : Int)+240 = k := by dsimp [z] <;> omega
  have ht := fourPoint140PackedAnchor0Part2 z
  rwa [he,hrep] at ht

private theorem packed140Anchor1 :
  ∀ j : Fin 481, ((j.val : Int)+140)%2=1 →
    1086660 ≤ FourPointNumeric.packedCharge 140 20 packedWeight140_1 (j.val : Int) := by
  intro j hj
  let k := (j.val-1)/2
  have hk : k < 240 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+1 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := fourPoint140PackedAnchor1Part0 z
    rwa [he,hrep] at ht
  let z : Fin 120 := ⟨k-120, by omega⟩
  have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
  have ht := fourPoint140PackedAnchor1Part1 z
  rwa [he,hrep] at ht

def packedCertificate140_0 : FourPointCertificate 140 0 111588 :=
  fourPointCertificateOfPacked 140 0 111588 1087616 20 packedWeight140_0 361 481
    (by decide +kernel) (by decide) (by decide) packed140Anchor0
    (by rw [packedWeight140_0_budget]; decide)

def packedCertificate140_1 : FourPointCertificate 140 1 111588 :=
  fourPointCertificateOfPacked 140 1 111588 1086660 20 packedWeight140_1 362 481
    (by decide +kernel) (by decide) (by decide) packed140Anchor1
    (by rw [packedWeight140_1_budget]; decide)

theorem max148_second140_fourPoint_moment_bound (tail : List ℕ) (len : tail.length=7)
    (distinct : (natSubsetSums (148::140::tail)).Nodup) :
    111588 ≤ ((148::140::tail).map (· ^ 2)).sum := by
  apply fourPointNatMomentLower 140 111588 tail len distinct
  intro p hp
  by_cases h : p=0
  · subst p
    exact packedCertificate140_0
  · have he : p=1 := hp.resolve_left h
    subst p
    exact packedCertificate140_1

#print axioms max148_second140_fourPoint_moment_bound

end NineSeparatedSubsetSums
