import NineSeparatedSubsetSums.Adaptive140Third139State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third139Proof127 : runCachedNode 511 129561 Adaptive140Third139Node127 = false := by
  decide +kernel

#print axioms adaptive140Third139Proof127

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third139Proof221 : runCachedNode 511 129561 Adaptive140Third139Node221 = false := by
  decide +kernel

#print axioms adaptive140Third139Proof221

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third139Proof88 : runCachedNode 511 129561 Adaptive140Third139Node88 = false := by
  decide +kernel

#print axioms adaptive140Third139Proof88

end NineSeparatedSubsetSums
