import NineSeparatedSubsetSums.EightPoint140_126PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint140_126PackedAnchor0Part0 :
    ∀ j : Fin 120, 2342249 ≤ FourPointNumeric.octPackedCharge 140 126 20 packedOct140_126_0
      (2*((j.val : Int)+0)+0) := by decide +kernel

end NineSeparatedSubsetSums
