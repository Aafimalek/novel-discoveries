import NineSeparatedSubsetSums.EightPoint140_120PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint140_120PackedAnchor0Part1 :
    ∀ j : Fin 120, 2344859 ≤ FourPointNumeric.octPackedCharge 140 120 20 packedOct140_120_0
      (2*((j.val : Int)+120)+0) := by decide +kernel

end NineSeparatedSubsetSums
