import NineSeparatedSubsetSums.Adaptive140Third109State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third109Proof0 : runCachedNode 511 111588 Adaptive140Third109Node0 = false := by
  decide +kernel

#print axioms adaptive140Third109Proof0

end NineSeparatedSubsetSums
