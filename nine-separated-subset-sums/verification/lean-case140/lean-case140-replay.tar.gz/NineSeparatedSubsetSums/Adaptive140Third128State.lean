import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive140Third128Node0 : CachedSearchNode :=
  ⟨4, 127, computeCenteredMask [148,140,128], 416, 57888⟩
def Adaptive140Third128Node1 : CachedSearchNode := cachedChild Adaptive140Third128Node0 111
def Adaptive140Third128Node2 : CachedSearchNode := cachedChild Adaptive140Third128Node0 112
def Adaptive140Third128Node3 : CachedSearchNode := cachedChild Adaptive140Third128Node0 113
def Adaptive140Third128Node4 : CachedSearchNode := cachedChild Adaptive140Third128Node0 114
def Adaptive140Third128Node5 : CachedSearchNode := cachedChild Adaptive140Third128Node0 115
def Adaptive140Third128Node6 : CachedSearchNode := cachedChild Adaptive140Third128Node0 116
def Adaptive140Third128Node7 : CachedSearchNode := cachedChild Adaptive140Third128Node0 117
def Adaptive140Third128Node8 : CachedSearchNode := cachedChild Adaptive140Third128Node0 118
def Adaptive140Third128Node9 : CachedSearchNode := cachedChild Adaptive140Third128Node0 119
def Adaptive140Third128Node10 : CachedSearchNode := cachedChild Adaptive140Third128Node0 121
def Adaptive140Third128Node11 : CachedSearchNode := cachedChild Adaptive140Third128Node0 122
def Adaptive140Third128Node12 : CachedSearchNode := cachedChild Adaptive140Third128Node0 123
def Adaptive140Third128Node13 : CachedSearchNode := cachedChild Adaptive140Third128Node0 124
def Adaptive140Third128Node14 : CachedSearchNode := cachedChild Adaptive140Third128Node0 125
def Adaptive140Third128Node15 : CachedSearchNode := cachedChild Adaptive140Third128Node0 126
def Adaptive140Third128Node16 : CachedSearchNode := cachedChild Adaptive140Third128Node0 127

end NineSeparatedSubsetSums
