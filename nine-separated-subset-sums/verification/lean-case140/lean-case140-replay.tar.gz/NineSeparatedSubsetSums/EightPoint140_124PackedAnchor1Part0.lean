import NineSeparatedSubsetSums.EightPoint140_124PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint140_124PackedAnchor1Part0 :
    ∀ j : Fin 120, 2294259 ≤ FourPointNumeric.octPackedCharge 140 124 20 packedOct140_124_1
      (2*((j.val : Int)+0)+1) := by decide +kernel

end NineSeparatedSubsetSums
