import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive140Third108Node0 : CachedSearchNode :=
  ⟨4, 107, computeCenteredMask [148,140,108], 396, 53168⟩

end NineSeparatedSubsetSums
