import NineSeparatedSubsetSums.Adaptive140Third134State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third134Proof46 : runCachedNode 511 128648 Adaptive140Third134Node46 = false := by
  decide +kernel

#print axioms adaptive140Third134Proof46

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third134Proof19 : runCachedNode 511 128648 Adaptive140Third134Node19 = false := by
  decide +kernel

#print axioms adaptive140Third134Proof19

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third134Proof10 : runCachedNode 511 128648 Adaptive140Third134Node10 = false := by
  decide +kernel

#print axioms adaptive140Third134Proof10

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third134Proof1 : runCachedNode 511 128648 Adaptive140Third134Node1 = false := by
  decide +kernel

#print axioms adaptive140Third134Proof1

end NineSeparatedSubsetSums
