import NineSeparatedSubsetSums.Adaptive140Third137State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third137Proof44 : runCachedNode 511 129199 Adaptive140Third137Node44 = false := by
  decide +kernel

#print axioms adaptive140Third137Proof44

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third137Proof46 : runCachedNode 511 129199 Adaptive140Third137Node46 = false := by
  decide +kernel

#print axioms adaptive140Third137Proof46

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third137Proof45 : runCachedNode 511 129199 Adaptive140Third137Node45 = false := by
  decide +kernel

#print axioms adaptive140Third137Proof45

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third137Proof92 : runCachedNode 511 129199 Adaptive140Third137Node92 = false := by
  decide +kernel

#print axioms adaptive140Third137Proof92

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third137Proof82 : runCachedNode 511 129199 Adaptive140Third137Node82 = false := by
  decide +kernel

#print axioms adaptive140Third137Proof82

end NineSeparatedSubsetSums
