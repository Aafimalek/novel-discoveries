import NineSeparatedSubsetSums.Adaptive140Third139State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third139Proof158 : runCachedNode 511 129561 Adaptive140Third139Node158 = false := by
  decide +kernel

#print axioms adaptive140Third139Proof158

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third139Proof19 : runCachedNode 511 129561 Adaptive140Third139Node19 = false := by
  decide +kernel

#print axioms adaptive140Third139Proof19

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third139Proof25 : runCachedNode 511 129561 Adaptive140Third139Node25 = false := by
  decide +kernel

#print axioms adaptive140Third139Proof25

end NineSeparatedSubsetSums
