import NineSeparatedSubsetSums.Adaptive140Third127State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third127Proof7 : runCachedNode 511 127359 Adaptive140Third127Node7 = false := by
  decide +kernel

#print axioms adaptive140Third127Proof7

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third127Proof5 : runCachedNode 511 127359 Adaptive140Third127Node5 = false := by
  decide +kernel

#print axioms adaptive140Third127Proof5

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third127Proof4 : runCachedNode 511 127359 Adaptive140Third127Node4 = false := by
  decide +kernel

#print axioms adaptive140Third127Proof4

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third127Proof3 : runCachedNode 511 127359 Adaptive140Third127Node3 = false := by
  decide +kernel

#print axioms adaptive140Third127Proof3

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third127Proof2 : runCachedNode 511 127359 Adaptive140Third127Node2 = false := by
  decide +kernel

#print axioms adaptive140Third127Proof2

end NineSeparatedSubsetSums
