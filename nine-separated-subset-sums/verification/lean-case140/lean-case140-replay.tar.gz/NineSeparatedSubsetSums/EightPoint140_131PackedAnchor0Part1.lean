import NineSeparatedSubsetSums.EightPoint140_131PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint140_131PackedAnchor0Part1 :
    ∀ j : Fin 120, 2432005 ≤ FourPointNumeric.octPackedCharge 140 131 20 packedOct140_131_0
      (2*((j.val : Int)+120)+1) := by decide +kernel

end NineSeparatedSubsetSums
