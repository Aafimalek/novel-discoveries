import NineSeparatedSubsetSums.Adaptive140Third129State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third129Proof17 : runCachedNode 511 127696 Adaptive140Third129Node17 = false := by
  decide +kernel

#print axioms adaptive140Third129Proof17

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third129Proof16 : runCachedNode 511 127696 Adaptive140Third129Node16 = false := by
  decide +kernel

#print axioms adaptive140Third129Proof16

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third129Proof15 : runCachedNode 511 127696 Adaptive140Third129Node15 = false := by
  decide +kernel

#print axioms adaptive140Third129Proof15

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third129Proof10 : runCachedNode 511 127696 Adaptive140Third129Node10 = false := by
  decide +kernel

#print axioms adaptive140Third129Proof10

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third129Proof2 : runCachedNode 511 127696 Adaptive140Third129Node2 = false := by
  decide +kernel

#print axioms adaptive140Third129Proof2

end NineSeparatedSubsetSums
