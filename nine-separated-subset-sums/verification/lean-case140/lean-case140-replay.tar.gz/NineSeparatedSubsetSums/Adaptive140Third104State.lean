import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive140Third104Node0 : CachedSearchNode :=
  ⟨4, 103, computeCenteredMask [148,140,104], 392, 52320⟩

end NineSeparatedSubsetSums
