import NineSeparatedSubsetSums.Adaptive140Third136State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third136Proof155 : runCachedNode 511 129025 Adaptive140Third136Node155 = false := by
  decide +kernel

#print axioms adaptive140Third136Proof155

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third136Proof39 : runCachedNode 511 129025 Adaptive140Third136Node39 = false := by
  decide +kernel

#print axioms adaptive140Third136Proof39

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third136Proof72 : runCachedNode 511 129025 Adaptive140Third136Node72 = false := by
  decide +kernel

#print axioms adaptive140Third136Proof72

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third136Proof94 : runCachedNode 511 129025 Adaptive140Third136Node94 = false := by
  decide +kernel

#print axioms adaptive140Third136Proof94

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third136Proof125 : runCachedNode 511 129025 Adaptive140Third136Node125 = false := by
  decide +kernel

#print axioms adaptive140Third136Proof125

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third136Proof35 : runCachedNode 511 129025 Adaptive140Third136Node35 = false := by
  decide +kernel

#print axioms adaptive140Third136Proof35

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third136Proof158 : runCachedNode 511 129025 Adaptive140Third136Node158 = false := by
  decide +kernel

#print axioms adaptive140Third136Proof158

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third136Proof38 : runCachedNode 511 129025 Adaptive140Third136Node38 = false := by
  decide +kernel

#print axioms adaptive140Third136Proof38

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third136Proof122 : runCachedNode 511 129025 Adaptive140Third136Node122 = false := by
  decide +kernel

#print axioms adaptive140Third136Proof122

end NineSeparatedSubsetSums
