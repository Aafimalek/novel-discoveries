import NineSeparatedSubsetSums.Adaptive140Third131State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third131Proof18 : runCachedNode 511 128237 Adaptive140Third131Node18 = false := by
  decide +kernel

#print axioms adaptive140Third131Proof18

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third131Proof17 : runCachedNode 511 128237 Adaptive140Third131Node17 = false := by
  decide +kernel

#print axioms adaptive140Third131Proof17

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third131Proof12 : runCachedNode 511 128237 Adaptive140Third131Node12 = false := by
  decide +kernel

#print axioms adaptive140Third131Proof12

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third131Proof5 : runCachedNode 511 128237 Adaptive140Third131Node5 = false := by
  decide +kernel

#print axioms adaptive140Third131Proof5

end NineSeparatedSubsetSums
