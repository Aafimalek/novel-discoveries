import NineSeparatedSubsetSums.EightPoint140_125PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint140_125PackedAnchor1Part0 :
    ∀ j : Fin 120, 2333448 ≤ FourPointNumeric.octPackedCharge 140 125 20 packedOct140_125_1
      (2*((j.val : Int)+0)+0) := by decide +kernel

end NineSeparatedSubsetSums
