import NineSeparatedSubsetSums.Adaptive140Third108Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint140Checked

namespace NineSeparatedSubsetSums


theorem adaptive140Third108 : NoDescendingTailAfterThird 140 108 :=
  noDescendingThirdTail_of_cached 140 108 111588 (fun t ht nd => max148_second140_fourPoint_moment_bound (108::t) (by simp [ht]) nd) adaptive140Third108Proof0

#print axioms adaptive140Third108

end NineSeparatedSubsetSums
