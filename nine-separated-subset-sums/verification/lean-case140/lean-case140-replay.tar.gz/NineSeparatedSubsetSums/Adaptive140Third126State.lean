import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive140Third126Node0 : CachedSearchNode :=
  ⟨4, 125, computeCenteredMask [148,140,126], 414, 57380⟩

end NineSeparatedSubsetSums
