import NineSeparatedSubsetSums.Adaptive140Third134State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third134Proof73 : runCachedNode 511 128648 Adaptive140Third134Node73 = false := by
  decide +kernel

#print axioms adaptive140Third134Proof73

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third134Proof17 : runCachedNode 511 128648 Adaptive140Third134Node17 = false := by
  decide +kernel

#print axioms adaptive140Third134Proof17

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third134Proof56 : runCachedNode 511 128648 Adaptive140Third134Node56 = false := by
  decide +kernel

#print axioms adaptive140Third134Proof56

end NineSeparatedSubsetSums
