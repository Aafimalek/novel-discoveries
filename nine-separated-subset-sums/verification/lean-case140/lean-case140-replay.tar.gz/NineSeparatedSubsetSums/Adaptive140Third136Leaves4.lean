import NineSeparatedSubsetSums.Adaptive140Third136State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third136Proof21 : runCachedNode 511 129025 Adaptive140Third136Node21 = false := by
  decide +kernel

#print axioms adaptive140Third136Proof21

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third136Proof45 : runCachedNode 511 129025 Adaptive140Third136Node45 = false := by
  decide +kernel

#print axioms adaptive140Third136Proof45

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third136Proof29 : runCachedNode 511 129025 Adaptive140Third136Node29 = false := by
  decide +kernel

#print axioms adaptive140Third136Proof29

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third136Proof132 : runCachedNode 511 129025 Adaptive140Third136Node132 = false := by
  decide +kernel

#print axioms adaptive140Third136Proof132

end NineSeparatedSubsetSums
