import NineSeparatedSubsetSums.Adaptive140Third139State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third139Proof15 : runCachedNode 511 129561 Adaptive140Third139Node15 = false := by
  decide +kernel

#print axioms adaptive140Third139Proof15

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third139Proof67 : runCachedNode 511 129561 Adaptive140Third139Node67 = false := by
  decide +kernel

#print axioms adaptive140Third139Proof67

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third139Proof216 : runCachedNode 511 129561 Adaptive140Third139Node216 = false := by
  decide +kernel

#print axioms adaptive140Third139Proof216

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third139Proof185 : runCachedNode 511 129561 Adaptive140Third139Node185 = false := by
  decide +kernel

#print axioms adaptive140Third139Proof185

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third139Proof13 : runCachedNode 511 129561 Adaptive140Third139Node13 = false := by
  decide +kernel

#print axioms adaptive140Third139Proof13

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third139Proof215 : runCachedNode 511 129561 Adaptive140Third139Node215 = false := by
  decide +kernel

#print axioms adaptive140Third139Proof215

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third139Proof173 : runCachedNode 511 129561 Adaptive140Third139Node173 = false := by
  decide +kernel

#print axioms adaptive140Third139Proof173

end NineSeparatedSubsetSums
