import NineSeparatedSubsetSums.Adaptive140Third137State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third137Proof93 : runCachedNode 511 129199 Adaptive140Third137Node93 = false := by
  decide +kernel

#print axioms adaptive140Third137Proof93

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third137Proof95 : runCachedNode 511 129199 Adaptive140Third137Node95 = false := by
  decide +kernel

#print axioms adaptive140Third137Proof95

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third137Proof153 : runCachedNode 511 129199 Adaptive140Third137Node153 = false := by
  decide +kernel

#print axioms adaptive140Third137Proof153

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third137Proof11 : runCachedNode 511 129199 Adaptive140Third137Node11 = false := by
  decide +kernel

#print axioms adaptive140Third137Proof11

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third137Proof94 : runCachedNode 511 129199 Adaptive140Third137Node94 = false := by
  decide +kernel

#print axioms adaptive140Third137Proof94

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third137Proof40 : runCachedNode 511 129199 Adaptive140Third137Node40 = false := by
  decide +kernel

#print axioms adaptive140Third137Proof40

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third137Proof41 : runCachedNode 511 129199 Adaptive140Third137Node41 = false := by
  decide +kernel

#print axioms adaptive140Third137Proof41

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third137Proof38 : runCachedNode 511 129199 Adaptive140Third137Node38 = false := by
  decide +kernel

#print axioms adaptive140Third137Proof38

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third137Proof151 : runCachedNode 511 129199 Adaptive140Third137Node151 = false := by
  decide +kernel

#print axioms adaptive140Third137Proof151

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third137Proof90 : runCachedNode 511 129199 Adaptive140Third137Node90 = false := by
  decide +kernel

#print axioms adaptive140Third137Proof90

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third137Proof10 : runCachedNode 511 129199 Adaptive140Third137Node10 = false := by
  decide +kernel

#print axioms adaptive140Third137Proof10

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third137Proof122 : runCachedNode 511 129199 Adaptive140Third137Node122 = false := by
  decide +kernel

#print axioms adaptive140Third137Proof122

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third137Proof37 : runCachedNode 511 129199 Adaptive140Third137Node37 = false := by
  decide +kernel

#print axioms adaptive140Third137Proof37

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third137Proof150 : runCachedNode 511 129199 Adaptive140Third137Node150 = false := by
  decide +kernel

#print axioms adaptive140Third137Proof150

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third137Proof91 : runCachedNode 511 129199 Adaptive140Third137Node91 = false := by
  decide +kernel

#print axioms adaptive140Third137Proof91

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third137Proof59 : runCachedNode 511 129199 Adaptive140Third137Node59 = false := by
  decide +kernel

#print axioms adaptive140Third137Proof59

end NineSeparatedSubsetSums
