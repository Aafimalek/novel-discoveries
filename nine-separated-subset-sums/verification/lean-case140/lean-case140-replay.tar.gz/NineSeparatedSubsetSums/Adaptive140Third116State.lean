import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive140Third116Node0 : CachedSearchNode :=
  ⟨4, 115, computeCenteredMask [148,140,116], 404, 54960⟩

end NineSeparatedSubsetSums
