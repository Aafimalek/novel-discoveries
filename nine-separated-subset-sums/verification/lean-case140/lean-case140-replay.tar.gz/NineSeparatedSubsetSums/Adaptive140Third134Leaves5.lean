import NineSeparatedSubsetSums.Adaptive140Third134State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third134Proof47 : runCachedNode 511 128648 Adaptive140Third134Node47 = false := by
  decide +kernel

#print axioms adaptive140Third134Proof47

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third134Proof45 : runCachedNode 511 128648 Adaptive140Third134Node45 = false := by
  decide +kernel

#print axioms adaptive140Third134Proof45

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third134Proof16 : runCachedNode 511 128648 Adaptive140Third134Node16 = false := by
  decide +kernel

#print axioms adaptive140Third134Proof16

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third134Proof38 : runCachedNode 511 128648 Adaptive140Third134Node38 = false := by
  decide +kernel

#print axioms adaptive140Third134Proof38

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third134Proof32 : runCachedNode 511 128648 Adaptive140Third134Node32 = false := by
  decide +kernel

#print axioms adaptive140Third134Proof32

end NineSeparatedSubsetSums
