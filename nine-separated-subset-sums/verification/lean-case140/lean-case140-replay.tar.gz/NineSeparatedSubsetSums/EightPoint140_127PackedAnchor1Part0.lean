import NineSeparatedSubsetSums.EightPoint140_127PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint140_127PackedAnchor1Part0 :
    ∀ j : Fin 120, 2355701 ≤ FourPointNumeric.octPackedCharge 140 127 20 packedOct140_127_1
      (2*((j.val : Int)+0)+0) := by decide +kernel

end NineSeparatedSubsetSums
