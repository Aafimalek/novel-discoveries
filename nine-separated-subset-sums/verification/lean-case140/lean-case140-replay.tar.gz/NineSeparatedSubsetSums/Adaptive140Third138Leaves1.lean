import NineSeparatedSubsetSums.Adaptive140Third138State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third138Proof19 : runCachedNode 511 129379 Adaptive140Third138Node19 = false := by
  decide +kernel

#print axioms adaptive140Third138Proof19

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third138Proof100 : runCachedNode 511 129379 Adaptive140Third138Node100 = false := by
  decide +kernel

#print axioms adaptive140Third138Proof100

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third138Proof2 : runCachedNode 511 129379 Adaptive140Third138Node2 = false := by
  decide +kernel

#print axioms adaptive140Third138Proof2

end NineSeparatedSubsetSums
