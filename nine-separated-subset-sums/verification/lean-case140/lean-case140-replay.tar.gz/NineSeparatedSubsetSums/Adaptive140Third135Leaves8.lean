import NineSeparatedSubsetSums.Adaptive140Third135State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third135Proof15 : runCachedNode 511 128865 Adaptive140Third135Node15 = false := by
  decide +kernel

#print axioms adaptive140Third135Proof15

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third135Proof14 : runCachedNode 511 128865 Adaptive140Third135Node14 = false := by
  decide +kernel

#print axioms adaptive140Third135Proof14

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third135Proof40 : runCachedNode 511 128865 Adaptive140Third135Node40 = false := by
  decide +kernel

#print axioms adaptive140Third135Proof40

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third135Proof70 : runCachedNode 511 128865 Adaptive140Third135Node70 = false := by
  decide +kernel

#print axioms adaptive140Third135Proof70

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third135Proof43 : runCachedNode 511 128865 Adaptive140Third135Node43 = false := by
  decide +kernel

#print axioms adaptive140Third135Proof43

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third135Proof69 : runCachedNode 511 128865 Adaptive140Third135Node69 = false := by
  decide +kernel

#print axioms adaptive140Third135Proof69

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third135Proof41 : runCachedNode 511 128865 Adaptive140Third135Node41 = false := by
  decide +kernel

#print axioms adaptive140Third135Proof41

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third135Proof10 : runCachedNode 511 128865 Adaptive140Third135Node10 = false := by
  decide +kernel

#print axioms adaptive140Third135Proof10

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third135Proof65 : runCachedNode 511 128865 Adaptive140Third135Node65 = false := by
  decide +kernel

#print axioms adaptive140Third135Proof65

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third135Proof24 : runCachedNode 511 128865 Adaptive140Third135Node24 = false := by
  decide +kernel

#print axioms adaptive140Third135Proof24

end NineSeparatedSubsetSums
