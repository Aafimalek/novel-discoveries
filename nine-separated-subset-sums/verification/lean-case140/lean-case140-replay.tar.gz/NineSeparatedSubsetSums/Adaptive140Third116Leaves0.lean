import NineSeparatedSubsetSums.Adaptive140Third116State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third116Proof0 : runCachedNode 511 124787 Adaptive140Third116Node0 = false := by
  decide +kernel

#print axioms adaptive140Third116Proof0

end NineSeparatedSubsetSums
