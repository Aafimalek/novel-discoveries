import NineSeparatedSubsetSums.Adaptive140Third135State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third135Proof100 : runCachedNode 511 128865 Adaptive140Third135Node100 = false := by
  decide +kernel

#print axioms adaptive140Third135Proof100

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third135Proof72 : runCachedNode 511 128865 Adaptive140Third135Node72 = false := by
  decide +kernel

#print axioms adaptive140Third135Proof72

end NineSeparatedSubsetSums
