import NineSeparatedSubsetSums.EightPointPackedGeometry
import NineSeparatedSubsetSums.EightPoint140_119PackedBudget0
import NineSeparatedSubsetSums.EightPoint140_119PackedAnchor0Part0
import NineSeparatedSubsetSums.EightPoint140_119PackedAnchor0Part1
import NineSeparatedSubsetSums.EightPoint140_119PackedAnchor0Part2
import NineSeparatedSubsetSums.EightPoint140_119PackedBudget1
import NineSeparatedSubsetSums.EightPoint140_119PackedAnchor1Part0
import NineSeparatedSubsetSums.EightPoint140_119PackedAnchor1Part1
import NineSeparatedSubsetSums.EightPoint140_119PackedAnchor1Part2

namespace NineSeparatedSubsetSums

private theorem packedOct140_119Anchor0 :
  ∀ j : Fin 489, ((j.val : Int)+140+119)%2=0 →
    2351995 ≤ FourPointNumeric.octPackedCharge 140 119 20 packedOct140_119_0 (j.val : Int) := by
  intro j hj
  let k := (j.val-1)/2
  have hk : k < 244 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+1 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint140_119PackedAnchor0Part0 z
    rwa [he,hrep] at ht
  by_cases h1 : k < 240
  · let z : Fin 120 := ⟨k-120, by omega⟩
    have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
    have ht := eightPoint140_119PackedAnchor0Part1 z
    rwa [he,hrep] at ht
  let z : Fin 4 := ⟨k-240, by omega⟩
  have he : (z.val : Int)+240 = k := by dsimp [z] <;> omega
  have ht := eightPoint140_119PackedAnchor0Part2 z
  rwa [he,hrep] at ht

private theorem packedOct140_119Anchor1 :
  ∀ j : Fin 489, ((j.val : Int)+140+119)%2=1 →
    2351837 ≤ FourPointNumeric.octPackedCharge 140 119 20 packedOct140_119_1 (j.val : Int) := by
  intro j hj
  let k := (j.val-0)/2
  have hk : k < 245 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+0 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint140_119PackedAnchor1Part0 z
    rwa [he,hrep] at ht
  by_cases h1 : k < 240
  · let z : Fin 120 := ⟨k-120, by omega⟩
    have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
    have ht := eightPoint140_119PackedAnchor1Part1 z
    rwa [he,hrep] at ht
  let z : Fin 5 := ⟨k-240, by omega⟩
  have he : (z.val : Int)+240 = k := by dsimp [z] <;> omega
  have ht := eightPoint140_119PackedAnchor1Part2 z
  rwa [he,hrep] at ht

def packedOctCertificate140_119_0 : EightPointCertificate 140 119 0 125441 :=
  eightPointCertificateOfPacked 140 119 0 125441 2351995 20 packedOct140_119_0 273 489
    (by decide +kernel) (by decide) packedOct140_119Anchor0
    (by rw [packedOct140_119_0_budget]; decide)

def packedOctCertificate140_119_1 : EightPointCertificate 140 119 1 125441 :=
  eightPointCertificateOfPacked 140 119 1 125441 2351837 20 packedOct140_119_1 272 489
    (by decide +kernel) (by decide) packedOct140_119Anchor1
    (by rw [packedOct140_119_1_budget]; decide)

theorem max148_second140_third119_eightPoint_moment_bound (tail : List ℕ) (len : tail.length=6)
    (distinct : (natSubsetSums (148::140::119::tail)).Nodup) :
    125441 ≤ ((148::140::119::tail).map (· ^ 2)).sum := by
  apply eightPointNatMomentLower 140 119 125441 tail len distinct
  intro p hp
  by_cases h : p=0
  · subst p
    exact packedOctCertificate140_119_0
  · have he : p=1 := hp.resolve_left h
    subst p
    exact packedOctCertificate140_119_1

#print axioms max148_second140_third119_eightPoint_moment_bound

end NineSeparatedSubsetSums
