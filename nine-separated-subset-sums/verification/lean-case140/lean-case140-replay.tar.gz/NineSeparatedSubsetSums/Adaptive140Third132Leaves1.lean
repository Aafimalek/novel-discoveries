import NineSeparatedSubsetSums.Adaptive140Third132State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third132Proof17 : runCachedNode 511 128323 Adaptive140Third132Node17 = false := by
  decide +kernel

#print axioms adaptive140Third132Proof17

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third132Proof35 : runCachedNode 511 128323 Adaptive140Third132Node35 = false := by
  decide +kernel

#print axioms adaptive140Third132Proof35

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third132Proof29 : runCachedNode 511 128323 Adaptive140Third132Node29 = false := by
  decide +kernel

#print axioms adaptive140Third132Proof29

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third132Proof20 : runCachedNode 511 128323 Adaptive140Third132Node20 = false := by
  decide +kernel

#print axioms adaptive140Third132Proof20

end NineSeparatedSubsetSums
