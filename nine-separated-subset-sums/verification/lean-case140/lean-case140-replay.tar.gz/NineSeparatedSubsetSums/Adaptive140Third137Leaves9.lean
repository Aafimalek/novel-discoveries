import NineSeparatedSubsetSums.Adaptive140Third137State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third137Proof128 : runCachedNode 511 129199 Adaptive140Third137Node128 = false := by
  decide +kernel

#print axioms adaptive140Third137Proof128

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third137Proof129 : runCachedNode 511 129199 Adaptive140Third137Node129 = false := by
  decide +kernel

#print axioms adaptive140Third137Proof129

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third137Proof43 : runCachedNode 511 129199 Adaptive140Third137Node43 = false := by
  decide +kernel

#print axioms adaptive140Third137Proof43

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third137Proof160 : runCachedNode 511 129199 Adaptive140Third137Node160 = false := by
  decide +kernel

#print axioms adaptive140Third137Proof160

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third137Proof14 : runCachedNode 511 129199 Adaptive140Third137Node14 = false := by
  decide +kernel

#print axioms adaptive140Third137Proof14

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third137Proof49 : runCachedNode 511 129199 Adaptive140Third137Node49 = false := by
  decide +kernel

#print axioms adaptive140Third137Proof49

end NineSeparatedSubsetSums
