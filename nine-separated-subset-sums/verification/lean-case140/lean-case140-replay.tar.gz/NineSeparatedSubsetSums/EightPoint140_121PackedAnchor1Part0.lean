import NineSeparatedSubsetSums.EightPoint140_121PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint140_121PackedAnchor1Part0 :
    ∀ j : Fin 120, 2327306 ≤ FourPointNumeric.octPackedCharge 140 121 20 packedOct140_121_1
      (2*((j.val : Int)+0)+0) := by decide +kernel

end NineSeparatedSubsetSums
