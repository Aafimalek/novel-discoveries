import NineSeparatedSubsetSums.Adaptive140Third131State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third131Proof19 : runCachedNode 511 128237 Adaptive140Third131Node19 = false := by
  decide +kernel

#print axioms adaptive140Third131Proof19

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third131Proof16 : runCachedNode 511 128237 Adaptive140Third131Node16 = false := by
  decide +kernel

#print axioms adaptive140Third131Proof16

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third131Proof4 : runCachedNode 511 128237 Adaptive140Third131Node4 = false := by
  decide +kernel

#print axioms adaptive140Third131Proof4

end NineSeparatedSubsetSums
