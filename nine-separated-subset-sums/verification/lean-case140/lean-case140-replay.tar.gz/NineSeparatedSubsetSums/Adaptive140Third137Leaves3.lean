import NineSeparatedSubsetSums.Adaptive140Third137State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third137Proof130 : runCachedNode 511 129199 Adaptive140Third137Node130 = false := by
  decide +kernel

#print axioms adaptive140Third137Proof130

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third137Proof98 : runCachedNode 511 129199 Adaptive140Third137Node98 = false := by
  decide +kernel

#print axioms adaptive140Third137Proof98

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third137Proof65 : runCachedNode 511 129199 Adaptive140Third137Node65 = false := by
  decide +kernel

#print axioms adaptive140Third137Proof65

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third137Proof2 : runCachedNode 511 129199 Adaptive140Third137Node2 = false := by
  decide +kernel

#print axioms adaptive140Third137Proof2

end NineSeparatedSubsetSums
