import NineSeparatedSubsetSums.Adaptive140Third138State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third138Proof219 : runCachedNode 511 129379 Adaptive140Third138Node219 = false := by
  decide +kernel

#print axioms adaptive140Third138Proof219

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third138Proof189 : runCachedNode 511 129379 Adaptive140Third138Node189 = false := by
  decide +kernel

#print axioms adaptive140Third138Proof189

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third138Proof16 : runCachedNode 511 129379 Adaptive140Third138Node16 = false := by
  decide +kernel

#print axioms adaptive140Third138Proof16

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third138Proof188 : runCachedNode 511 129379 Adaptive140Third138Node188 = false := by
  decide +kernel

#print axioms adaptive140Third138Proof188

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third138Proof26 : runCachedNode 511 129379 Adaptive140Third138Node26 = false := by
  decide +kernel

#print axioms adaptive140Third138Proof26

end NineSeparatedSubsetSums
