import NineSeparatedSubsetSums.Adaptive140Third131State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third131Proof15 : runCachedNode 511 128237 Adaptive140Third131Node15 = false := by
  decide +kernel

#print axioms adaptive140Third131Proof15

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third131Proof14 : runCachedNode 511 128237 Adaptive140Third131Node14 = false := by
  decide +kernel

#print axioms adaptive140Third131Proof14

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third131Proof13 : runCachedNode 511 128237 Adaptive140Third131Node13 = false := by
  decide +kernel

#print axioms adaptive140Third131Proof13

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third131Proof11 : runCachedNode 511 128237 Adaptive140Third131Node11 = false := by
  decide +kernel

#print axioms adaptive140Third131Proof11

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third131Proof10 : runCachedNode 511 128237 Adaptive140Third131Node10 = false := by
  decide +kernel

#print axioms adaptive140Third131Proof10

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third131Proof9 : runCachedNode 511 128237 Adaptive140Third131Node9 = false := by
  decide +kernel

#print axioms adaptive140Third131Proof9

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third131Proof8 : runCachedNode 511 128237 Adaptive140Third131Node8 = false := by
  decide +kernel

#print axioms adaptive140Third131Proof8

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third131Proof7 : runCachedNode 511 128237 Adaptive140Third131Node7 = false := by
  decide +kernel

#print axioms adaptive140Third131Proof7

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third131Proof6 : runCachedNode 511 128237 Adaptive140Third131Node6 = false := by
  decide +kernel

#print axioms adaptive140Third131Proof6

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third131Proof3 : runCachedNode 511 128237 Adaptive140Third131Node3 = false := by
  decide +kernel

#print axioms adaptive140Third131Proof3

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third131Proof2 : runCachedNode 511 128237 Adaptive140Third131Node2 = false := by
  decide +kernel

#print axioms adaptive140Third131Proof2

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third131Proof1 : runCachedNode 511 128237 Adaptive140Third131Node1 = false := by
  decide +kernel

#print axioms adaptive140Third131Proof1

end NineSeparatedSubsetSums
