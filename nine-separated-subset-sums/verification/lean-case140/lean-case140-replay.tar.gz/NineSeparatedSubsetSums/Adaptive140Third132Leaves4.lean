import NineSeparatedSubsetSums.Adaptive140Third132State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third132Proof13 : runCachedNode 511 128323 Adaptive140Third132Node13 = false := by
  decide +kernel

#print axioms adaptive140Third132Proof13

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third132Proof12 : runCachedNode 511 128323 Adaptive140Third132Node12 = false := by
  decide +kernel

#print axioms adaptive140Third132Proof12

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third132Proof63 : runCachedNode 511 128323 Adaptive140Third132Node63 = false := by
  decide +kernel

#print axioms adaptive140Third132Proof63

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third132Proof11 : runCachedNode 511 128323 Adaptive140Third132Node11 = false := by
  decide +kernel

#print axioms adaptive140Third132Proof11

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third132Proof60 : runCachedNode 511 128323 Adaptive140Third132Node60 = false := by
  decide +kernel

#print axioms adaptive140Third132Proof60

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third132Proof43 : runCachedNode 511 128323 Adaptive140Third132Node43 = false := by
  decide +kernel

#print axioms adaptive140Third132Proof43

end NineSeparatedSubsetSums
