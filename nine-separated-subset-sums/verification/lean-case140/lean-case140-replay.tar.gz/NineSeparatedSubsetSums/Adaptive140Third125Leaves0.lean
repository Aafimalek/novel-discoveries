import NineSeparatedSubsetSums.Adaptive140Third125State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third125Proof0 : runCachedNode 511 126911 Adaptive140Third125Node0 = false := by
  decide +kernel

#print axioms adaptive140Third125Proof0

end NineSeparatedSubsetSums
