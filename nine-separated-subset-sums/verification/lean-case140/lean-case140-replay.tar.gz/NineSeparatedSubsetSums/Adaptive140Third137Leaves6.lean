import NineSeparatedSubsetSums.Adaptive140Third137State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third137Proof73 : runCachedNode 511 129199 Adaptive140Third137Node73 = false := by
  decide +kernel

#print axioms adaptive140Third137Proof73

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third137Proof17 : runCachedNode 511 129199 Adaptive140Third137Node17 = false := by
  decide +kernel

#print axioms adaptive140Third137Proof17

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third137Proof152 : runCachedNode 511 129199 Adaptive140Third137Node152 = false := by
  decide +kernel

#print axioms adaptive140Third137Proof152

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third137Proof103 : runCachedNode 511 129199 Adaptive140Third137Node103 = false := by
  decide +kernel

#print axioms adaptive140Third137Proof103

end NineSeparatedSubsetSums
