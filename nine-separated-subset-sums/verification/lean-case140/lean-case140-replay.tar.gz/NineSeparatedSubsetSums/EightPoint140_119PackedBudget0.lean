import NineSeparatedSubsetSums.EightPoint140_119PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct140_119_0_budget :
    FourPointNumeric.packedBudget 20 packedOct140_119_0 273 = 86302278 := by decide +kernel

#print axioms packedOct140_119_0_budget

end NineSeparatedSubsetSums
