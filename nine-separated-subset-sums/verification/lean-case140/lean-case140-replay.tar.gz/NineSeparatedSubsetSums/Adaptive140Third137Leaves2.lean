import NineSeparatedSubsetSums.Adaptive140Third137State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third137Proof21 : runCachedNode 511 129199 Adaptive140Third137Node21 = false := by
  decide +kernel

#print axioms adaptive140Third137Proof21

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third137Proof127 : runCachedNode 511 129199 Adaptive140Third137Node127 = false := by
  decide +kernel

#print axioms adaptive140Third137Proof127

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third137Proof1 : runCachedNode 511 129199 Adaptive140Third137Node1 = false := by
  decide +kernel

#print axioms adaptive140Third137Proof1

end NineSeparatedSubsetSums
