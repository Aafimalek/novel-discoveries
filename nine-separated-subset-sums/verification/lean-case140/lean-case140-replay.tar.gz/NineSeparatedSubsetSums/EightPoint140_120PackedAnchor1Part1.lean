import NineSeparatedSubsetSums.EightPoint140_120PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint140_120PackedAnchor1Part1 :
    ∀ j : Fin 120, 2338624 ≤ FourPointNumeric.octPackedCharge 140 120 20 packedOct140_120_1
      (2*((j.val : Int)+120)+1) := by decide +kernel

end NineSeparatedSubsetSums
