import NineSeparatedSubsetSums.EightPoint140_130PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint140_130PackedAnchor1Part0 :
    ∀ j : Fin 120, 2404870 ≤ FourPointNumeric.octPackedCharge 140 130 20 packedOct140_130_1
      (2*((j.val : Int)+0)+1) := by decide +kernel

end NineSeparatedSubsetSums
