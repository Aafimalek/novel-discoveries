import NineSeparatedSubsetSums.Adaptive140Third137State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third137Proof139 : runCachedNode 511 129199 Adaptive140Third137Node139 = false := by
  decide +kernel

#print axioms adaptive140Third137Proof139

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third137Proof140 : runCachedNode 511 129199 Adaptive140Third137Node140 = false := by
  decide +kernel

#print axioms adaptive140Third137Proof140

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third137Proof24 : runCachedNode 511 129199 Adaptive140Third137Node24 = false := by
  decide +kernel

#print axioms adaptive140Third137Proof24

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third137Proof51 : runCachedNode 511 129199 Adaptive140Third137Node51 = false := by
  decide +kernel

#print axioms adaptive140Third137Proof51

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third137Proof77 : runCachedNode 511 129199 Adaptive140Third137Node77 = false := by
  decide +kernel

#print axioms adaptive140Third137Proof77

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third137Proof110 : runCachedNode 511 129199 Adaptive140Third137Node110 = false := by
  decide +kernel

#print axioms adaptive140Third137Proof110

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third137Proof137 : runCachedNode 511 129199 Adaptive140Third137Node137 = false := by
  decide +kernel

#print axioms adaptive140Third137Proof137

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third137Proof138 : runCachedNode 511 129199 Adaptive140Third137Node138 = false := by
  decide +kernel

#print axioms adaptive140Third137Proof138

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third137Proof50 : runCachedNode 511 129199 Adaptive140Third137Node50 = false := by
  decide +kernel

#print axioms adaptive140Third137Proof50

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third137Proof76 : runCachedNode 511 129199 Adaptive140Third137Node76 = false := by
  decide +kernel

#print axioms adaptive140Third137Proof76

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third137Proof108 : runCachedNode 511 129199 Adaptive140Third137Node108 = false := by
  decide +kernel

#print axioms adaptive140Third137Proof108

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third137Proof109 : runCachedNode 511 129199 Adaptive140Third137Node109 = false := by
  decide +kernel

#print axioms adaptive140Third137Proof109

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third137Proof136 : runCachedNode 511 129199 Adaptive140Third137Node136 = false := by
  decide +kernel

#print axioms adaptive140Third137Proof136

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third137Proof106 : runCachedNode 511 129199 Adaptive140Third137Node106 = false := by
  decide +kernel

#print axioms adaptive140Third137Proof106

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third137Proof107 : runCachedNode 511 129199 Adaptive140Third137Node107 = false := by
  decide +kernel

#print axioms adaptive140Third137Proof107

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third137Proof135 : runCachedNode 511 129199 Adaptive140Third137Node135 = false := by
  decide +kernel

#print axioms adaptive140Third137Proof135

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third137Proof104 : runCachedNode 511 129199 Adaptive140Third137Node104 = false := by
  decide +kernel

#print axioms adaptive140Third137Proof104

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third137Proof105 : runCachedNode 511 129199 Adaptive140Third137Node105 = false := by
  decide +kernel

#print axioms adaptive140Third137Proof105

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third137Proof133 : runCachedNode 511 129199 Adaptive140Third137Node133 = false := by
  decide +kernel

#print axioms adaptive140Third137Proof133

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third137Proof134 : runCachedNode 511 129199 Adaptive140Third137Node134 = false := by
  decide +kernel

#print axioms adaptive140Third137Proof134

end NineSeparatedSubsetSums
