import NineSeparatedSubsetSums.Adaptive140Third132State
import NineSeparatedSubsetSums.Adaptive140Third132Leaves1
import NineSeparatedSubsetSums.Adaptive140Third132Leaves0
import NineSeparatedSubsetSums.Adaptive140Third132Leaves7
import NineSeparatedSubsetSums.Adaptive140Third132Leaves6
import NineSeparatedSubsetSums.Adaptive140Third132Leaves5
import NineSeparatedSubsetSums.Adaptive140Third132Leaves3
import NineSeparatedSubsetSums.Adaptive140Third132Leaves4
import NineSeparatedSubsetSums.Adaptive140Third132Leaves2

namespace NineSeparatedSubsetSums

theorem adaptive140Third132Proof19 : runCachedNode 511 128323 Adaptive140Third132Node19 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 128323 Adaptive140Third132Node19 = [105, 106, 107, 108, 109, 110, 111, 112, 113, 115, 116, 117, 118, 119, 120, 121, 123, 125, 126, 127, 128, 129] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive140Third132Proof20
  · exact adaptive140Third132Proof21
  · exact adaptive140Third132Proof22
  · exact adaptive140Third132Proof23
  · exact adaptive140Third132Proof24
  · exact adaptive140Third132Proof25
  · exact adaptive140Third132Proof26
  · exact adaptive140Third132Proof27
  · exact adaptive140Third132Proof28
  · exact adaptive140Third132Proof29
  · exact adaptive140Third132Proof30
  · exact adaptive140Third132Proof31
  · exact adaptive140Third132Proof32
  · exact adaptive140Third132Proof33
  · exact adaptive140Third132Proof34
  · exact adaptive140Third132Proof35
  · exact adaptive140Third132Proof36
  · exact adaptive140Third132Proof37
  · exact adaptive140Third132Proof38
  · exact adaptive140Third132Proof39
  · exact adaptive140Third132Proof40
  · exact adaptive140Third132Proof41

#print axioms adaptive140Third132Proof19

theorem adaptive140Third132Proof42 : runCachedNode 511 128323 Adaptive140Third132Node42 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 128323 Adaptive140Third132Node42 = [105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 116, 117, 118, 119, 120, 121, 122, 125, 126, 127, 128, 129, 130] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive140Third132Proof43
  · exact adaptive140Third132Proof44
  · exact adaptive140Third132Proof45
  · exact adaptive140Third132Proof46
  · exact adaptive140Third132Proof47
  · exact adaptive140Third132Proof48
  · exact adaptive140Third132Proof49
  · exact adaptive140Third132Proof50
  · exact adaptive140Third132Proof51
  · exact adaptive140Third132Proof52
  · exact adaptive140Third132Proof53
  · exact adaptive140Third132Proof54
  · exact adaptive140Third132Proof55
  · exact adaptive140Third132Proof56
  · exact adaptive140Third132Proof57
  · exact adaptive140Third132Proof58
  · exact adaptive140Third132Proof59
  · exact adaptive140Third132Proof60
  · exact adaptive140Third132Proof61
  · exact adaptive140Third132Proof62
  · exact adaptive140Third132Proof63
  · exact adaptive140Third132Proof64
  · exact adaptive140Third132Proof65

#print axioms adaptive140Third132Proof42

theorem adaptive140Third132Proof0 : runCachedNode 511 128323 Adaptive140Third132Node0 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 128323 Adaptive140Third132Node0 = [111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 125, 126, 127, 128, 129, 130, 131] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive140Third132Proof1
  · exact adaptive140Third132Proof2
  · exact adaptive140Third132Proof3
  · exact adaptive140Third132Proof4
  · exact adaptive140Third132Proof5
  · exact adaptive140Third132Proof6
  · exact adaptive140Third132Proof7
  · exact adaptive140Third132Proof8
  · exact adaptive140Third132Proof9
  · exact adaptive140Third132Proof10
  · exact adaptive140Third132Proof11
  · exact adaptive140Third132Proof12
  · exact adaptive140Third132Proof13
  · exact adaptive140Third132Proof14
  · exact adaptive140Third132Proof15
  · exact adaptive140Third132Proof16
  · exact adaptive140Third132Proof17
  · exact adaptive140Third132Proof18
  · exact adaptive140Third132Proof19
  · exact adaptive140Third132Proof42

#print axioms adaptive140Third132Proof0

end NineSeparatedSubsetSums
