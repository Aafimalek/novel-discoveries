import NineSeparatedSubsetSums.EightPoint140_135PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct140_135_1_budget :
    FourPointNumeric.packedBudget 20 packedOct140_135_1 272 = 92411526 := by decide +kernel

#print axioms packedOct140_135_1_budget

end NineSeparatedSubsetSums
