import NineSeparatedSubsetSums.Adaptive140Third137State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third137Proof20 : runCachedNode 511 129199 Adaptive140Third137Node20 = false := by
  decide +kernel

#print axioms adaptive140Third137Proof20

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third137Proof18 : runCachedNode 511 129199 Adaptive140Third137Node18 = false := by
  decide +kernel

#print axioms adaptive140Third137Proof18

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third137Proof87 : runCachedNode 511 129199 Adaptive140Third137Node87 = false := by
  decide +kernel

#print axioms adaptive140Third137Proof87

end NineSeparatedSubsetSums
