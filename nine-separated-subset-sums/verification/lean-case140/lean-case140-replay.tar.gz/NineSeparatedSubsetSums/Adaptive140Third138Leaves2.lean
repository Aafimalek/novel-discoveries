import NineSeparatedSubsetSums.Adaptive140Third138State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third138Proof129 : runCachedNode 511 129379 Adaptive140Third138Node129 = false := by
  decide +kernel

#print axioms adaptive140Third138Proof129

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third138Proof157 : runCachedNode 511 129379 Adaptive140Third138Node157 = false := by
  decide +kernel

#print axioms adaptive140Third138Proof157

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third138Proof57 : runCachedNode 511 129379 Adaptive140Third138Node57 = false := by
  decide +kernel

#print axioms adaptive140Third138Proof57

end NineSeparatedSubsetSums
