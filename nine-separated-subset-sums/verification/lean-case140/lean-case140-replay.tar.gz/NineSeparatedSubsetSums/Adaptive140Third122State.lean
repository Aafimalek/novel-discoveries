import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive140Third122Node0 : CachedSearchNode :=
  ⟨4, 121, computeCenteredMask [148,140,122], 410, 56388⟩

end NineSeparatedSubsetSums
