import NineSeparatedSubsetSums.Adaptive140Third132State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third132Proof16 : runCachedNode 511 128323 Adaptive140Third132Node16 = false := by
  decide +kernel

#print axioms adaptive140Third132Proof16

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third132Proof15 : runCachedNode 511 128323 Adaptive140Third132Node15 = false := by
  decide +kernel

#print axioms adaptive140Third132Proof15

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third132Proof45 : runCachedNode 511 128323 Adaptive140Third132Node45 = false := by
  decide +kernel

#print axioms adaptive140Third132Proof45

end NineSeparatedSubsetSums
