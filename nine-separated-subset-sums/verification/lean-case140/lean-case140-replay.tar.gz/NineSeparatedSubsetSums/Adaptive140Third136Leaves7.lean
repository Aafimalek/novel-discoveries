import NineSeparatedSubsetSums.Adaptive140Third136State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third136Proof44 : runCachedNode 511 129025 Adaptive140Third136Node44 = false := by
  decide +kernel

#print axioms adaptive140Third136Proof44

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third136Proof18 : runCachedNode 511 129025 Adaptive140Third136Node18 = false := by
  decide +kernel

#print axioms adaptive140Third136Proof18

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third136Proof17 : runCachedNode 511 129025 Adaptive140Third136Node17 = false := by
  decide +kernel

#print axioms adaptive140Third136Proof17

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third136Proof97 : runCachedNode 511 129025 Adaptive140Third136Node97 = false := by
  decide +kernel

#print axioms adaptive140Third136Proof97

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third136Proof2 : runCachedNode 511 129025 Adaptive140Third136Node2 = false := by
  decide +kernel

#print axioms adaptive140Third136Proof2

end NineSeparatedSubsetSums
