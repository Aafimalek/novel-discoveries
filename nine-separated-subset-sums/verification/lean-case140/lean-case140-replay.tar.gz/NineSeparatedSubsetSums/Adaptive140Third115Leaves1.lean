import NineSeparatedSubsetSums.Adaptive140Third115State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third115Proof10 : runCachedNode 511 111588 Adaptive140Third115Node10 = false := by
  decide +kernel

#print axioms adaptive140Third115Proof10

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third115Proof8 : runCachedNode 511 111588 Adaptive140Third115Node8 = false := by
  decide +kernel

#print axioms adaptive140Third115Proof8

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third115Proof7 : runCachedNode 511 111588 Adaptive140Third115Node7 = false := by
  decide +kernel

#print axioms adaptive140Third115Proof7

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third115Proof6 : runCachedNode 511 111588 Adaptive140Third115Node6 = false := by
  decide +kernel

#print axioms adaptive140Third115Proof6

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third115Proof5 : runCachedNode 511 111588 Adaptive140Third115Node5 = false := by
  decide +kernel

#print axioms adaptive140Third115Proof5

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third115Proof4 : runCachedNode 511 111588 Adaptive140Third115Node4 = false := by
  decide +kernel

#print axioms adaptive140Third115Proof4

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third115Proof3 : runCachedNode 511 111588 Adaptive140Third115Node3 = false := by
  decide +kernel

#print axioms adaptive140Third115Proof3

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third115Proof2 : runCachedNode 511 111588 Adaptive140Third115Node2 = false := by
  decide +kernel

#print axioms adaptive140Third115Proof2

end NineSeparatedSubsetSums
