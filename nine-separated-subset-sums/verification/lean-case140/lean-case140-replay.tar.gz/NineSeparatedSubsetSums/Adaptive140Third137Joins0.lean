import NineSeparatedSubsetSums.Adaptive140Third137State
import NineSeparatedSubsetSums.Adaptive140Third137Leaves7
import NineSeparatedSubsetSums.Adaptive140Third137Leaves15
import NineSeparatedSubsetSums.Adaptive140Third137Leaves14
import NineSeparatedSubsetSums.Adaptive140Third137Leaves13
import NineSeparatedSubsetSums.Adaptive140Third137Leaves12
import NineSeparatedSubsetSums.Adaptive140Third137Leaves5
import NineSeparatedSubsetSums.Adaptive140Third137Leaves9
import NineSeparatedSubsetSums.Adaptive140Third137Leaves8
import NineSeparatedSubsetSums.Adaptive140Third137Leaves10
import NineSeparatedSubsetSums.Adaptive140Third137Leaves3
import NineSeparatedSubsetSums.Adaptive140Third137Leaves11
import NineSeparatedSubsetSums.Adaptive140Third137Leaves6
import NineSeparatedSubsetSums.Adaptive140Third137Leaves1
import NineSeparatedSubsetSums.Adaptive140Third137Leaves4
import NineSeparatedSubsetSums.Adaptive140Third137Leaves0
import NineSeparatedSubsetSums.Adaptive140Third137Leaves2

namespace NineSeparatedSubsetSums

theorem adaptive140Third137Proof22 : runCachedNode 511 129199 Adaptive140Third137Node22 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 129199 Adaptive140Third137Node22 = [104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 122, 123, 125, 126, 127, 128, 130, 131] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive140Third137Proof23
  · exact adaptive140Third137Proof24
  · exact adaptive140Third137Proof25
  · exact adaptive140Third137Proof26
  · exact adaptive140Third137Proof27
  · exact adaptive140Third137Proof28
  · exact adaptive140Third137Proof29
  · exact adaptive140Third137Proof30
  · exact adaptive140Third137Proof31
  · exact adaptive140Third137Proof32
  · exact adaptive140Third137Proof33
  · exact adaptive140Third137Proof34
  · exact adaptive140Third137Proof35
  · exact adaptive140Third137Proof36
  · exact adaptive140Third137Proof37
  · exact adaptive140Third137Proof38
  · exact adaptive140Third137Proof39
  · exact adaptive140Third137Proof40
  · exact adaptive140Third137Proof41
  · exact adaptive140Third137Proof42
  · exact adaptive140Third137Proof43
  · exact adaptive140Third137Proof44
  · exact adaptive140Third137Proof45
  · exact adaptive140Third137Proof46
  · exact adaptive140Third137Proof47

#print axioms adaptive140Third137Proof22

theorem adaptive140Third137Proof48 : runCachedNode 511 129199 Adaptive140Third137Node48 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 129199 Adaptive140Third137Node48 = [104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 123, 124, 126, 127, 128, 131, 132] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive140Third137Proof49
  · exact adaptive140Third137Proof50
  · exact adaptive140Third137Proof51
  · exact adaptive140Third137Proof52
  · exact adaptive140Third137Proof53
  · exact adaptive140Third137Proof54
  · exact adaptive140Third137Proof55
  · exact adaptive140Third137Proof56
  · exact adaptive140Third137Proof57
  · exact adaptive140Third137Proof58
  · exact adaptive140Third137Proof59
  · exact adaptive140Third137Proof60
  · exact adaptive140Third137Proof61
  · exact adaptive140Third137Proof62
  · exact adaptive140Third137Proof63
  · exact adaptive140Third137Proof64
  · exact adaptive140Third137Proof65
  · exact adaptive140Third137Proof66
  · exact adaptive140Third137Proof67
  · exact adaptive140Third137Proof68
  · exact adaptive140Third137Proof69
  · exact adaptive140Third137Proof70
  · exact adaptive140Third137Proof71
  · exact adaptive140Third137Proof72
  · exact adaptive140Third137Proof73

#print axioms adaptive140Third137Proof48

theorem adaptive140Third137Proof74 : runCachedNode 511 129199 Adaptive140Third137Node74 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 129199 Adaptive140Third137Node74 = [103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 124, 125, 127, 128, 130, 132, 133] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive140Third137Proof75
  · exact adaptive140Third137Proof76
  · exact adaptive140Third137Proof77
  · exact adaptive140Third137Proof78
  · exact adaptive140Third137Proof79
  · exact adaptive140Third137Proof80
  · exact adaptive140Third137Proof81
  · exact adaptive140Third137Proof82
  · exact adaptive140Third137Proof83
  · exact adaptive140Third137Proof84
  · exact adaptive140Third137Proof85
  · exact adaptive140Third137Proof86
  · exact adaptive140Third137Proof87
  · exact adaptive140Third137Proof88
  · exact adaptive140Third137Proof89
  · exact adaptive140Third137Proof90
  · exact adaptive140Third137Proof91
  · exact adaptive140Third137Proof92
  · exact adaptive140Third137Proof93
  · exact adaptive140Third137Proof94
  · exact adaptive140Third137Proof95
  · exact adaptive140Third137Proof96
  · exact adaptive140Third137Proof97
  · exact adaptive140Third137Proof98
  · exact adaptive140Third137Proof99
  · exact adaptive140Third137Proof100
  · exact adaptive140Third137Proof101

#print axioms adaptive140Third137Proof74

theorem adaptive140Third137Proof102 : runCachedNode 511 129199 Adaptive140Third137Node102 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 129199 Adaptive140Third137Node102 = [103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 125, 126, 128, 130, 131, 133, 134] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive140Third137Proof103
  · exact adaptive140Third137Proof104
  · exact adaptive140Third137Proof105
  · exact adaptive140Third137Proof106
  · exact adaptive140Third137Proof107
  · exact adaptive140Third137Proof108
  · exact adaptive140Third137Proof109
  · exact adaptive140Third137Proof110
  · exact adaptive140Third137Proof111
  · exact adaptive140Third137Proof112
  · exact adaptive140Third137Proof113
  · exact adaptive140Third137Proof114
  · exact adaptive140Third137Proof115
  · exact adaptive140Third137Proof116
  · exact adaptive140Third137Proof117
  · exact adaptive140Third137Proof118
  · exact adaptive140Third137Proof119
  · exact adaptive140Third137Proof120
  · exact adaptive140Third137Proof121
  · exact adaptive140Third137Proof122
  · exact adaptive140Third137Proof123
  · exact adaptive140Third137Proof124
  · exact adaptive140Third137Proof125
  · exact adaptive140Third137Proof126
  · exact adaptive140Third137Proof127
  · exact adaptive140Third137Proof128
  · exact adaptive140Third137Proof129
  · exact adaptive140Third137Proof130

#print axioms adaptive140Third137Proof102

theorem adaptive140Third137Proof131 : runCachedNode 511 129199 Adaptive140Third137Node131 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 129199 Adaptive140Third137Node131 = [103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 126, 127, 130, 131, 132, 134, 135] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive140Third137Proof132
  · exact adaptive140Third137Proof133
  · exact adaptive140Third137Proof134
  · exact adaptive140Third137Proof135
  · exact adaptive140Third137Proof136
  · exact adaptive140Third137Proof137
  · exact adaptive140Third137Proof138
  · exact adaptive140Third137Proof139
  · exact adaptive140Third137Proof140
  · exact adaptive140Third137Proof141
  · exact adaptive140Third137Proof142
  · exact adaptive140Third137Proof143
  · exact adaptive140Third137Proof144
  · exact adaptive140Third137Proof145
  · exact adaptive140Third137Proof146
  · exact adaptive140Third137Proof147
  · exact adaptive140Third137Proof148
  · exact adaptive140Third137Proof149
  · exact adaptive140Third137Proof150
  · exact adaptive140Third137Proof151
  · exact adaptive140Third137Proof152
  · exact adaptive140Third137Proof153
  · exact adaptive140Third137Proof154
  · exact adaptive140Third137Proof155
  · exact adaptive140Third137Proof156
  · exact adaptive140Third137Proof157
  · exact adaptive140Third137Proof158
  · exact adaptive140Third137Proof159
  · exact adaptive140Third137Proof160

#print axioms adaptive140Third137Proof131

theorem adaptive140Third137Proof0 : runCachedNode 511 129199 Adaptive140Third137Node0 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 129199 Adaptive140Third137Node0 = [110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 130, 131, 132, 133, 134, 135, 136] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive140Third137Proof1
  · exact adaptive140Third137Proof2
  · exact adaptive140Third137Proof3
  · exact adaptive140Third137Proof4
  · exact adaptive140Third137Proof5
  · exact adaptive140Third137Proof6
  · exact adaptive140Third137Proof7
  · exact adaptive140Third137Proof8
  · exact adaptive140Third137Proof9
  · exact adaptive140Third137Proof10
  · exact adaptive140Third137Proof11
  · exact adaptive140Third137Proof12
  · exact adaptive140Third137Proof13
  · exact adaptive140Third137Proof14
  · exact adaptive140Third137Proof15
  · exact adaptive140Third137Proof16
  · exact adaptive140Third137Proof17
  · exact adaptive140Third137Proof18
  · exact adaptive140Third137Proof19
  · exact adaptive140Third137Proof20
  · exact adaptive140Third137Proof21
  · exact adaptive140Third137Proof22
  · exact adaptive140Third137Proof48
  · exact adaptive140Third137Proof74
  · exact adaptive140Third137Proof102
  · exact adaptive140Third137Proof131

#print axioms adaptive140Third137Proof0

end NineSeparatedSubsetSums
