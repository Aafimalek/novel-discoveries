import NineSeparatedSubsetSums.Adaptive140Third113State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third113Proof0 : runCachedNode 511 111588 Adaptive140Third113Node0 = false := by
  decide +kernel

#print axioms adaptive140Third113Proof0

end NineSeparatedSubsetSums
