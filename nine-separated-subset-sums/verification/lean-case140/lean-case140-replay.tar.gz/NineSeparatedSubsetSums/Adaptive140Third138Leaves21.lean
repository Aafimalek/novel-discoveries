import NineSeparatedSubsetSums.Adaptive140Third138State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third138Proof105 : runCachedNode 511 129379 Adaptive140Third138Node105 = false := by
  decide +kernel

#print axioms adaptive140Third138Proof105

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third138Proof133 : runCachedNode 511 129379 Adaptive140Third138Node133 = false := by
  decide +kernel

#print axioms adaptive140Third138Proof133

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third138Proof134 : runCachedNode 511 129379 Adaptive140Third138Node134 = false := by
  decide +kernel

#print axioms adaptive140Third138Proof134

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third138Proof160 : runCachedNode 511 129379 Adaptive140Third138Node160 = false := by
  decide +kernel

#print axioms adaptive140Third138Proof160

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third138Proof161 : runCachedNode 511 129379 Adaptive140Third138Node161 = false := by
  decide +kernel

#print axioms adaptive140Third138Proof161

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third138Proof197 : runCachedNode 511 129379 Adaptive140Third138Node197 = false := by
  decide +kernel

#print axioms adaptive140Third138Proof197

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third138Proof50 : runCachedNode 511 129379 Adaptive140Third138Node50 = false := by
  decide +kernel

#print axioms adaptive140Third138Proof50

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third138Proof75 : runCachedNode 511 129379 Adaptive140Third138Node75 = false := by
  decide +kernel

#print axioms adaptive140Third138Proof75

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third138Proof76 : runCachedNode 511 129379 Adaptive140Third138Node76 = false := by
  decide +kernel

#print axioms adaptive140Third138Proof76

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third138Proof103 : runCachedNode 511 129379 Adaptive140Third138Node103 = false := by
  decide +kernel

#print axioms adaptive140Third138Proof103

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third138Proof104 : runCachedNode 511 129379 Adaptive140Third138Node104 = false := by
  decide +kernel

#print axioms adaptive140Third138Proof104

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third138Proof132 : runCachedNode 511 129379 Adaptive140Third138Node132 = false := by
  decide +kernel

#print axioms adaptive140Third138Proof132

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third138Proof159 : runCachedNode 511 129379 Adaptive140Third138Node159 = false := by
  decide +kernel

#print axioms adaptive140Third138Proof159

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third138Proof196 : runCachedNode 511 129379 Adaptive140Third138Node196 = false := by
  decide +kernel

#print axioms adaptive140Third138Proof196

end NineSeparatedSubsetSums
