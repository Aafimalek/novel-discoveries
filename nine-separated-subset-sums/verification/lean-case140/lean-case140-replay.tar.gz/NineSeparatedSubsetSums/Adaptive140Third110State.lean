import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive140Third110Node0 : CachedSearchNode :=
  ⟨4, 109, computeCenteredMask [148,140,110], 398, 53604⟩

end NineSeparatedSubsetSums
