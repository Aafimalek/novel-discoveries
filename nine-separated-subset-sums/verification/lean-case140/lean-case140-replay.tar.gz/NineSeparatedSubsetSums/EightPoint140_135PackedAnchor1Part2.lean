import NineSeparatedSubsetSums.EightPoint140_135PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint140_135PackedAnchor1Part2 :
    ∀ j : Fin 10, 2474854 ≤ FourPointNumeric.octPackedCharge 140 135 20 packedOct140_135_1
      (2*((j.val : Int)+240)+0) := by decide +kernel

end NineSeparatedSubsetSums
