import NineSeparatedSubsetSums.Adaptive140Third138State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third138Proof183 : runCachedNode 511 129379 Adaptive140Third138Node183 = false := by
  decide +kernel

#print axioms adaptive140Third138Proof183

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third138Proof39 : runCachedNode 511 129379 Adaptive140Third138Node39 = false := by
  decide +kernel

#print axioms adaptive140Third138Proof39

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third138Proof123 : runCachedNode 511 129379 Adaptive140Third138Node123 = false := by
  decide +kernel

#print axioms adaptive140Third138Proof123

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third138Proof178 : runCachedNode 511 129379 Adaptive140Third138Node178 = false := by
  decide +kernel

#print axioms adaptive140Third138Proof178

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third138Proof124 : runCachedNode 511 129379 Adaptive140Third138Node124 = false := by
  decide +kernel

#print axioms adaptive140Third138Proof124

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third138Proof125 : runCachedNode 511 129379 Adaptive140Third138Node125 = false := by
  decide +kernel

#print axioms adaptive140Third138Proof125

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third138Proof40 : runCachedNode 511 129379 Adaptive140Third138Node40 = false := by
  decide +kernel

#print axioms adaptive140Third138Proof40

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third138Proof69 : runCachedNode 511 129379 Adaptive140Third138Node69 = false := by
  decide +kernel

#print axioms adaptive140Third138Proof69

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third138Proof94 : runCachedNode 511 129379 Adaptive140Third138Node94 = false := by
  decide +kernel

#print axioms adaptive140Third138Proof94

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third138Proof181 : runCachedNode 511 129379 Adaptive140Third138Node181 = false := by
  decide +kernel

#print axioms adaptive140Third138Proof181

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third138Proof216 : runCachedNode 511 129379 Adaptive140Third138Node216 = false := by
  decide +kernel

#print axioms adaptive140Third138Proof216

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third138Proof149 : runCachedNode 511 129379 Adaptive140Third138Node149 = false := by
  decide +kernel

#print axioms adaptive140Third138Proof149

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third138Proof49 : runCachedNode 511 129379 Adaptive140Third138Node49 = false := by
  decide +kernel

#print axioms adaptive140Third138Proof49

end NineSeparatedSubsetSums
