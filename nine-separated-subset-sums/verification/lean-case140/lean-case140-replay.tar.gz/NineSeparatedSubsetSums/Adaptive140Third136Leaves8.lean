import NineSeparatedSubsetSums.Adaptive140Third136State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third136Proof15 : runCachedNode 511 129025 Adaptive140Third136Node15 = false := by
  decide +kernel

#print axioms adaptive140Third136Proof15

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third136Proof129 : runCachedNode 511 129025 Adaptive140Third136Node129 = false := by
  decide +kernel

#print axioms adaptive140Third136Proof129

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third136Proof42 : runCachedNode 511 129025 Adaptive140Third136Node42 = false := by
  decide +kernel

#print axioms adaptive140Third136Proof42

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third136Proof16 : runCachedNode 511 129025 Adaptive140Third136Node16 = false := by
  decide +kernel

#print axioms adaptive140Third136Proof16

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third136Proof10 : runCachedNode 511 129025 Adaptive140Third136Node10 = false := by
  decide +kernel

#print axioms adaptive140Third136Proof10

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third136Proof142 : runCachedNode 511 129025 Adaptive140Third136Node142 = false := by
  decide +kernel

#print axioms adaptive140Third136Proof142

end NineSeparatedSubsetSums
