import NineSeparatedSubsetSums.EightPoint140_132PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct140_132_0_budget :
    FourPointNumeric.packedBudget 20 packedOct140_132_0 487 = 90322223 := by decide +kernel

#print axioms packedOct140_132_0_budget

end NineSeparatedSubsetSums
