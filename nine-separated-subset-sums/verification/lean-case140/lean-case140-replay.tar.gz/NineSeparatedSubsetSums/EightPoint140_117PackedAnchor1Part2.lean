import NineSeparatedSubsetSums.EightPoint140_117PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint140_117PackedAnchor1Part2 :
    ∀ j : Fin 5, 2349009 ≤ FourPointNumeric.octPackedCharge 140 117 20 packedOct140_117_1
      (2*((j.val : Int)+240)+0) := by decide +kernel

end NineSeparatedSubsetSums
