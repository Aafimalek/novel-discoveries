import NineSeparatedSubsetSums.Adaptive140Third126State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third126Proof0 : runCachedNode 511 127178 Adaptive140Third126Node0 = false := by
  decide +kernel

#print axioms adaptive140Third126Proof0

end NineSeparatedSubsetSums
