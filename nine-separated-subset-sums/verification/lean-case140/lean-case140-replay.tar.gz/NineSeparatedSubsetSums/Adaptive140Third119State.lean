import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive140Third119Node0 : CachedSearchNode :=
  ⟨4, 118, computeCenteredMask [148,140,119], 407, 55665⟩

end NineSeparatedSubsetSums
