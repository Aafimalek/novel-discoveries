import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive140Third121Node0 : CachedSearchNode :=
  ⟨4, 120, computeCenteredMask [148,140,121], 409, 56145⟩

end NineSeparatedSubsetSums
