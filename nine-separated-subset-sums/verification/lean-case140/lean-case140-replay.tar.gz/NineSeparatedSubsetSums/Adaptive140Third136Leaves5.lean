import NineSeparatedSubsetSums.Adaptive140Third136State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third136Proof159 : runCachedNode 511 129025 Adaptive140Third136Node159 = false := by
  decide +kernel

#print axioms adaptive140Third136Proof159

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third136Proof130 : runCachedNode 511 129025 Adaptive140Third136Node130 = false := by
  decide +kernel

#print axioms adaptive140Third136Proof130

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third136Proof70 : runCachedNode 511 129025 Adaptive140Third136Node70 = false := by
  decide +kernel

#print axioms adaptive140Third136Proof70

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third136Proof25 : runCachedNode 511 129025 Adaptive140Third136Node25 = false := by
  decide +kernel

#print axioms adaptive140Third136Proof25

end NineSeparatedSubsetSums
