import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive140Third114Node0 : CachedSearchNode :=
  ⟨4, 113, computeCenteredMask [148,140,114], 402, 54500⟩

end NineSeparatedSubsetSums
