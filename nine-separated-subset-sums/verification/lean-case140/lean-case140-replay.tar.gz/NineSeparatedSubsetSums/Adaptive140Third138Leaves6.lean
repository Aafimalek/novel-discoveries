import NineSeparatedSubsetSums.Adaptive140Third138State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third138Proof191 : runCachedNode 511 129379 Adaptive140Third138Node191 = false := by
  decide +kernel

#print axioms adaptive140Third138Proof191

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third138Proof98 : runCachedNode 511 129379 Adaptive140Third138Node98 = false := by
  decide +kernel

#print axioms adaptive140Third138Proof98

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third138Proof118 : runCachedNode 511 129379 Adaptive140Third138Node118 = false := by
  decide +kernel

#print axioms adaptive140Third138Proof118

end NineSeparatedSubsetSums
