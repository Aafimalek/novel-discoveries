import NineSeparatedSubsetSums.EightPoint140_137PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint140_137PackedAnchor0Part1 :
    ∀ j : Fin 120, 2475128 ≤ FourPointNumeric.octPackedCharge 140 137 20 packedOct140_137_0
      (2*((j.val : Int)+120)+1) := by decide +kernel

end NineSeparatedSubsetSums
