import NineSeparatedSubsetSums.Adaptive140Third139State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third139Proof189 : runCachedNode 511 129561 Adaptive140Third139Node189 = false := by
  decide +kernel

#print axioms adaptive140Third139Proof189

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third139Proof17 : runCachedNode 511 129561 Adaptive140Third139Node17 = false := by
  decide +kernel

#print axioms adaptive140Third139Proof17

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third139Proof85 : runCachedNode 511 129561 Adaptive140Third139Node85 = false := by
  decide +kernel

#print axioms adaptive140Third139Proof85

end NineSeparatedSubsetSums
