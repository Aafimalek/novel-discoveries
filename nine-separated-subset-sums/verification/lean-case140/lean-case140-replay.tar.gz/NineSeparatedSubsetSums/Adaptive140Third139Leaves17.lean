import NineSeparatedSubsetSums.Adaptive140Third139State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third139Proof41 : runCachedNode 511 129561 Adaptive140Third139Node41 = false := by
  decide +kernel

#print axioms adaptive140Third139Proof41

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third139Proof43 : runCachedNode 511 129561 Adaptive140Third139Node43 = false := by
  decide +kernel

#print axioms adaptive140Third139Proof43

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third139Proof153 : runCachedNode 511 129561 Adaptive140Third139Node153 = false := by
  decide +kernel

#print axioms adaptive140Third139Proof153

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third139Proof64 : runCachedNode 511 129561 Adaptive140Third139Node64 = false := by
  decide +kernel

#print axioms adaptive140Third139Proof64

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third139Proof184 : runCachedNode 511 129561 Adaptive140Third139Node184 = false := by
  decide +kernel

#print axioms adaptive140Third139Proof184

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third139Proof258 : runCachedNode 511 129561 Adaptive140Third139Node258 = false := by
  decide +kernel

#print axioms adaptive140Third139Proof258

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third139Proof125 : runCachedNode 511 129561 Adaptive140Third139Node125 = false := by
  decide +kernel

#print axioms adaptive140Third139Proof125

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third139Proof120 : runCachedNode 511 129561 Adaptive140Third139Node120 = false := by
  decide +kernel

#print axioms adaptive140Third139Proof120

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third139Proof38 : runCachedNode 511 129561 Adaptive140Third139Node38 = false := by
  decide +kernel

#print axioms adaptive140Third139Proof38

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third139Proof79 : runCachedNode 511 129561 Adaptive140Third139Node79 = false := by
  decide +kernel

#print axioms adaptive140Third139Proof79

end NineSeparatedSubsetSums
