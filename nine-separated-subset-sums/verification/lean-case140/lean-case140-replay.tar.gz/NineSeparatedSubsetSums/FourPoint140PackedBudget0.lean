import NineSeparatedSubsetSums.FourPoint140PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedWeight140_0_budget :
    FourPointNumeric.packedBudget 20 packedWeight140_0 361 = 82081280 := by decide +kernel

#print axioms packedWeight140_0_budget

end NineSeparatedSubsetSums
