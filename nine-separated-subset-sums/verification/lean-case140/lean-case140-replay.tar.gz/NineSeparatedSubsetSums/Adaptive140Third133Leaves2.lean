import NineSeparatedSubsetSums.Adaptive140Third133State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third133Proof19 : runCachedNode 511 128482 Adaptive140Third133Node19 = false := by
  decide +kernel

#print axioms adaptive140Third133Proof19

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third133Proof17 : runCachedNode 511 128482 Adaptive140Third133Node17 = false := by
  decide +kernel

#print axioms adaptive140Third133Proof17

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third133Proof12 : runCachedNode 511 128482 Adaptive140Third133Node12 = false := by
  decide +kernel

#print axioms adaptive140Third133Proof12

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third133Proof27 : runCachedNode 511 128482 Adaptive140Third133Node27 = false := by
  decide +kernel

#print axioms adaptive140Third133Proof27

end NineSeparatedSubsetSums
