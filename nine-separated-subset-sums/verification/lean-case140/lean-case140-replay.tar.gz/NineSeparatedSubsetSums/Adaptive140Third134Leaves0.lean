import NineSeparatedSubsetSums.Adaptive140Third134State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third134Proof20 : runCachedNode 511 128648 Adaptive140Third134Node20 = false := by
  decide +kernel

#print axioms adaptive140Third134Proof20

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third134Proof39 : runCachedNode 511 128648 Adaptive140Third134Node39 = false := by
  decide +kernel

#print axioms adaptive140Third134Proof39

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third134Proof49 : runCachedNode 511 128648 Adaptive140Third134Node49 = false := by
  decide +kernel

#print axioms adaptive140Third134Proof49

end NineSeparatedSubsetSums
