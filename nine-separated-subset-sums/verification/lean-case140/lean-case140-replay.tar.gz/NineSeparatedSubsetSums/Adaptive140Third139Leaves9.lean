import NineSeparatedSubsetSums.Adaptive140Third139State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third139Proof190 : runCachedNode 511 129561 Adaptive140Third139Node190 = false := by
  decide +kernel

#print axioms adaptive140Third139Proof190

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third139Proof126 : runCachedNode 511 129561 Adaptive140Third139Node126 = false := by
  decide +kernel

#print axioms adaptive140Third139Proof126

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third139Proof27 : runCachedNode 511 129561 Adaptive140Third139Node27 = false := by
  decide +kernel

#print axioms adaptive140Third139Proof27

end NineSeparatedSubsetSums
