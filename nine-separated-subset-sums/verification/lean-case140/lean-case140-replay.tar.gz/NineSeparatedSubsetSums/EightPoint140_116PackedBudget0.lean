import NineSeparatedSubsetSums.EightPoint140_116PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct140_116_0_budget :
    FourPointNumeric.packedBudget 20 packedOct140_116_0 357 = 86016468 := by decide +kernel

#print axioms packedOct140_116_0_budget

end NineSeparatedSubsetSums
