import NineSeparatedSubsetSums.Adaptive140Third128State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third128Proof16 : runCachedNode 511 127521 Adaptive140Third128Node16 = false := by
  decide +kernel

#print axioms adaptive140Third128Proof16

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third128Proof15 : runCachedNode 511 127521 Adaptive140Third128Node15 = false := by
  decide +kernel

#print axioms adaptive140Third128Proof15

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third128Proof14 : runCachedNode 511 127521 Adaptive140Third128Node14 = false := by
  decide +kernel

#print axioms adaptive140Third128Proof14

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third128Proof13 : runCachedNode 511 127521 Adaptive140Third128Node13 = false := by
  decide +kernel

#print axioms adaptive140Third128Proof13

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third128Proof12 : runCachedNode 511 127521 Adaptive140Third128Node12 = false := by
  decide +kernel

#print axioms adaptive140Third128Proof12

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third128Proof2 : runCachedNode 511 127521 Adaptive140Third128Node2 = false := by
  decide +kernel

#print axioms adaptive140Third128Proof2

end NineSeparatedSubsetSums
