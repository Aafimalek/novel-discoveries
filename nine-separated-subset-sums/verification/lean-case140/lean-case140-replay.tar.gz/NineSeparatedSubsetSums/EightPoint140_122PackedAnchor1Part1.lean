import NineSeparatedSubsetSums.EightPoint140_122PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint140_122PackedAnchor1Part1 :
    ∀ j : Fin 120, 2289047 ≤ FourPointNumeric.octPackedCharge 140 122 20 packedOct140_122_1
      (2*((j.val : Int)+120)+1) := by decide +kernel

end NineSeparatedSubsetSums
