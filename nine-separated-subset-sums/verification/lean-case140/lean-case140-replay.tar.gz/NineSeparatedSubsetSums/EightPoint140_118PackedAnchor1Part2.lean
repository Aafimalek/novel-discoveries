import NineSeparatedSubsetSums.EightPoint140_118PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint140_118PackedAnchor1Part2 :
    ∀ j : Fin 4, 2350998 ≤ FourPointNumeric.octPackedCharge 140 118 20 packedOct140_118_1
      (2*((j.val : Int)+240)+1) := by decide +kernel

end NineSeparatedSubsetSums
