import NineSeparatedSubsetSums.EightPoint140_134PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct140_134_0_budget :
    FourPointNumeric.packedBudget 20 packedOct140_134_0 357 = 91511459 := by decide +kernel

#print axioms packedOct140_134_0_budget

end NineSeparatedSubsetSums
