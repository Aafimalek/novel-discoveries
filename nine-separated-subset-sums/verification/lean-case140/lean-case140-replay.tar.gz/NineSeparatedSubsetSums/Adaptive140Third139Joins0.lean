import NineSeparatedSubsetSums.Adaptive140Third139State
import NineSeparatedSubsetSums.Adaptive140Third139Leaves13
import NineSeparatedSubsetSums.Adaptive140Third139Leaves23
import NineSeparatedSubsetSums.Adaptive140Third139Leaves22
import NineSeparatedSubsetSums.Adaptive140Third139Leaves6
import NineSeparatedSubsetSums.Adaptive140Third139Leaves9
import NineSeparatedSubsetSums.Adaptive140Third139Leaves21
import NineSeparatedSubsetSums.Adaptive140Third139Leaves20
import NineSeparatedSubsetSums.Adaptive140Third139Leaves19
import NineSeparatedSubsetSums.Adaptive140Third139Leaves17
import NineSeparatedSubsetSums.Adaptive140Third139Leaves1
import NineSeparatedSubsetSums.Adaptive140Third139Leaves2
import NineSeparatedSubsetSums.Adaptive140Third139Leaves16
import NineSeparatedSubsetSums.Adaptive140Third139Leaves11
import NineSeparatedSubsetSums.Adaptive140Third139Leaves0
import NineSeparatedSubsetSums.Adaptive140Third139Leaves12
import NineSeparatedSubsetSums.Adaptive140Third139Leaves18
import NineSeparatedSubsetSums.Adaptive140Third139Leaves14
import NineSeparatedSubsetSums.Adaptive140Third139Leaves15
import NineSeparatedSubsetSums.Adaptive140Third139Leaves7
import NineSeparatedSubsetSums.Adaptive140Third139Leaves4
import NineSeparatedSubsetSums.Adaptive140Third139Leaves5
import NineSeparatedSubsetSums.Adaptive140Third139Leaves8
import NineSeparatedSubsetSums.Adaptive140Third139Leaves24
import NineSeparatedSubsetSums.Adaptive140Third139Leaves10
import NineSeparatedSubsetSums.Adaptive140Third139Leaves3

namespace NineSeparatedSubsetSums

theorem adaptive140Third139Proof21 : runCachedNode 511 129561 Adaptive140Third139Node21 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 129561 Adaptive140Third139Node21 = [104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 123, 124, 125, 126, 127, 128] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive140Third139Proof22
  · exact adaptive140Third139Proof23
  · exact adaptive140Third139Proof24
  · exact adaptive140Third139Proof25
  · exact adaptive140Third139Proof26
  · exact adaptive140Third139Proof27
  · exact adaptive140Third139Proof28
  · exact adaptive140Third139Proof29
  · exact adaptive140Third139Proof30
  · exact adaptive140Third139Proof31
  · exact adaptive140Third139Proof32
  · exact adaptive140Third139Proof33
  · exact adaptive140Third139Proof34
  · exact adaptive140Third139Proof35
  · exact adaptive140Third139Proof36
  · exact adaptive140Third139Proof37
  · exact adaptive140Third139Proof38
  · exact adaptive140Third139Proof39
  · exact adaptive140Third139Proof40
  · exact adaptive140Third139Proof41
  · exact adaptive140Third139Proof42
  · exact adaptive140Third139Proof43
  · exact adaptive140Third139Proof44

#print axioms adaptive140Third139Proof21

theorem adaptive140Third139Proof45 : runCachedNode 511 129561 Adaptive140Third139Node45 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 129561 Adaptive140Third139Node45 = [104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 125, 126, 127, 128, 129, 130] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive140Third139Proof46
  · exact adaptive140Third139Proof47
  · exact adaptive140Third139Proof48
  · exact adaptive140Third139Proof49
  · exact adaptive140Third139Proof50
  · exact adaptive140Third139Proof51
  · exact adaptive140Third139Proof52
  · exact adaptive140Third139Proof53
  · exact adaptive140Third139Proof54
  · exact adaptive140Third139Proof55
  · exact adaptive140Third139Proof56
  · exact adaptive140Third139Proof57
  · exact adaptive140Third139Proof58
  · exact adaptive140Third139Proof59
  · exact adaptive140Third139Proof60
  · exact adaptive140Third139Proof61
  · exact adaptive140Third139Proof62
  · exact adaptive140Third139Proof63
  · exact adaptive140Third139Proof64
  · exact adaptive140Third139Proof65
  · exact adaptive140Third139Proof66
  · exact adaptive140Third139Proof67
  · exact adaptive140Third139Proof68
  · exact adaptive140Third139Proof69
  · exact adaptive140Third139Proof70

#print axioms adaptive140Third139Proof45

theorem adaptive140Third139Proof72 : runCachedNode 511 129561 Adaptive140Third139Node72 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 129561 Adaptive140Third139Node72 = [103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 127, 128, 129, 130, 132] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive140Third139Proof73
  · exact adaptive140Third139Proof74
  · exact adaptive140Third139Proof75
  · exact adaptive140Third139Proof76
  · exact adaptive140Third139Proof77
  · exact adaptive140Third139Proof78
  · exact adaptive140Third139Proof79
  · exact adaptive140Third139Proof80
  · exact adaptive140Third139Proof81
  · exact adaptive140Third139Proof82
  · exact adaptive140Third139Proof83
  · exact adaptive140Third139Proof84
  · exact adaptive140Third139Proof85
  · exact adaptive140Third139Proof86
  · exact adaptive140Third139Proof87
  · exact adaptive140Third139Proof88
  · exact adaptive140Third139Proof89
  · exact adaptive140Third139Proof90
  · exact adaptive140Third139Proof91
  · exact adaptive140Third139Proof92
  · exact adaptive140Third139Proof93
  · exact adaptive140Third139Proof94
  · exact adaptive140Third139Proof95
  · exact adaptive140Third139Proof96
  · exact adaptive140Third139Proof97
  · exact adaptive140Third139Proof98
  · exact adaptive140Third139Proof99

#print axioms adaptive140Third139Proof72

theorem adaptive140Third139Proof100 : runCachedNode 511 129561 Adaptive140Third139Node100 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 129561 Adaptive140Third139Node100 = [103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 128, 129, 130, 132, 133] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive140Third139Proof101
  · exact adaptive140Third139Proof102
  · exact adaptive140Third139Proof103
  · exact adaptive140Third139Proof104
  · exact adaptive140Third139Proof105
  · exact adaptive140Third139Proof106
  · exact adaptive140Third139Proof107
  · exact adaptive140Third139Proof108
  · exact adaptive140Third139Proof109
  · exact adaptive140Third139Proof110
  · exact adaptive140Third139Proof111
  · exact adaptive140Third139Proof112
  · exact adaptive140Third139Proof113
  · exact adaptive140Third139Proof114
  · exact adaptive140Third139Proof115
  · exact adaptive140Third139Proof116
  · exact adaptive140Third139Proof117
  · exact adaptive140Third139Proof118
  · exact adaptive140Third139Proof119
  · exact adaptive140Third139Proof120
  · exact adaptive140Third139Proof121
  · exact adaptive140Third139Proof122
  · exact adaptive140Third139Proof123
  · exact adaptive140Third139Proof124
  · exact adaptive140Third139Proof125
  · exact adaptive140Third139Proof126
  · exact adaptive140Third139Proof127
  · exact adaptive140Third139Proof128

#print axioms adaptive140Third139Proof100

theorem adaptive140Third139Proof129 : runCachedNode 511 129561 Adaptive140Third139Node129 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 129561 Adaptive140Third139Node129 = [103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 129, 130, 132, 133, 134] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive140Third139Proof130
  · exact adaptive140Third139Proof131
  · exact adaptive140Third139Proof132
  · exact adaptive140Third139Proof133
  · exact adaptive140Third139Proof134
  · exact adaptive140Third139Proof135
  · exact adaptive140Third139Proof136
  · exact adaptive140Third139Proof137
  · exact adaptive140Third139Proof138
  · exact adaptive140Third139Proof139
  · exact adaptive140Third139Proof140
  · exact adaptive140Third139Proof141
  · exact adaptive140Third139Proof142
  · exact adaptive140Third139Proof143
  · exact adaptive140Third139Proof144
  · exact adaptive140Third139Proof145
  · exact adaptive140Third139Proof146
  · exact adaptive140Third139Proof147
  · exact adaptive140Third139Proof148
  · exact adaptive140Third139Proof149
  · exact adaptive140Third139Proof150
  · exact adaptive140Third139Proof151
  · exact adaptive140Third139Proof152
  · exact adaptive140Third139Proof153
  · exact adaptive140Third139Proof154
  · exact adaptive140Third139Proof155
  · exact adaptive140Third139Proof156
  · exact adaptive140Third139Proof157
  · exact adaptive140Third139Proof158

#print axioms adaptive140Third139Proof129

theorem adaptive140Third139Proof159 : runCachedNode 511 129561 Adaptive140Third139Node159 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 129561 Adaptive140Third139Node159 = [102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 130, 132, 133, 134, 135] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive140Third139Proof160
  · exact adaptive140Third139Proof161
  · exact adaptive140Third139Proof162
  · exact adaptive140Third139Proof163
  · exact adaptive140Third139Proof164
  · exact adaptive140Third139Proof165
  · exact adaptive140Third139Proof166
  · exact adaptive140Third139Proof167
  · exact adaptive140Third139Proof168
  · exact adaptive140Third139Proof169
  · exact adaptive140Third139Proof170
  · exact adaptive140Third139Proof171
  · exact adaptive140Third139Proof172
  · exact adaptive140Third139Proof173
  · exact adaptive140Third139Proof174
  · exact adaptive140Third139Proof175
  · exact adaptive140Third139Proof176
  · exact adaptive140Third139Proof177
  · exact adaptive140Third139Proof178
  · exact adaptive140Third139Proof179
  · exact adaptive140Third139Proof180
  · exact adaptive140Third139Proof181
  · exact adaptive140Third139Proof182
  · exact adaptive140Third139Proof183
  · exact adaptive140Third139Proof184
  · exact adaptive140Third139Proof185
  · exact adaptive140Third139Proof186
  · exact adaptive140Third139Proof187
  · exact adaptive140Third139Proof188
  · exact adaptive140Third139Proof189
  · exact adaptive140Third139Proof190

#print axioms adaptive140Third139Proof159

theorem adaptive140Third139Proof223 : runCachedNode 511 129561 Adaptive140Third139Node223 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 129561 Adaptive140Third139Node223 = [90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 132] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive140Third139Proof224
  · exact adaptive140Third139Proof225
  · exact adaptive140Third139Proof226
  · exact adaptive140Third139Proof227
  · exact adaptive140Third139Proof228
  · exact adaptive140Third139Proof229
  · exact adaptive140Third139Proof230
  · exact adaptive140Third139Proof231
  · exact adaptive140Third139Proof232
  · exact adaptive140Third139Proof233
  · exact adaptive140Third139Proof234
  · exact adaptive140Third139Proof235
  · exact adaptive140Third139Proof236
  · exact adaptive140Third139Proof237
  · exact adaptive140Third139Proof238
  · exact adaptive140Third139Proof239
  · exact adaptive140Third139Proof240
  · exact adaptive140Third139Proof241
  · exact adaptive140Third139Proof242
  · exact adaptive140Third139Proof243
  · exact adaptive140Third139Proof244
  · exact adaptive140Third139Proof245
  · exact adaptive140Third139Proof246
  · exact adaptive140Third139Proof247
  · exact adaptive140Third139Proof248
  · exact adaptive140Third139Proof249
  · exact adaptive140Third139Proof250
  · exact adaptive140Third139Proof251
  · exact adaptive140Third139Proof252
  · exact adaptive140Third139Proof253
  · exact adaptive140Third139Proof254
  · exact adaptive140Third139Proof255
  · exact adaptive140Third139Proof256
  · exact adaptive140Third139Proof257
  · exact adaptive140Third139Proof258
  · exact adaptive140Third139Proof259

#print axioms adaptive140Third139Proof223

theorem adaptive140Third139Proof191 : runCachedNode 511 129561 Adaptive140Third139Node191 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 129561 Adaptive140Third139Node191 = [102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 132, 133, 134, 135, 136] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive140Third139Proof192
  · exact adaptive140Third139Proof193
  · exact adaptive140Third139Proof194
  · exact adaptive140Third139Proof195
  · exact adaptive140Third139Proof196
  · exact adaptive140Third139Proof197
  · exact adaptive140Third139Proof198
  · exact adaptive140Third139Proof199
  · exact adaptive140Third139Proof200
  · exact adaptive140Third139Proof201
  · exact adaptive140Third139Proof202
  · exact adaptive140Third139Proof203
  · exact adaptive140Third139Proof204
  · exact adaptive140Third139Proof205
  · exact adaptive140Third139Proof206
  · exact adaptive140Third139Proof207
  · exact adaptive140Third139Proof208
  · exact adaptive140Third139Proof209
  · exact adaptive140Third139Proof210
  · exact adaptive140Third139Proof211
  · exact adaptive140Third139Proof212
  · exact adaptive140Third139Proof213
  · exact adaptive140Third139Proof214
  · exact adaptive140Third139Proof215
  · exact adaptive140Third139Proof216
  · exact adaptive140Third139Proof217
  · exact adaptive140Third139Proof218
  · exact adaptive140Third139Proof219
  · exact adaptive140Third139Proof220
  · exact adaptive140Third139Proof221
  · exact adaptive140Third139Proof222
  · exact adaptive140Third139Proof223

#print axioms adaptive140Third139Proof191

end NineSeparatedSubsetSums
