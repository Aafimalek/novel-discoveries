import NineSeparatedSubsetSums.EightPoint140_126PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct140_126_0_budget :
    FourPointNumeric.packedBudget 20 packedOct140_126_0 477 = 84788938 := by decide +kernel

#print axioms packedOct140_126_0_budget

end NineSeparatedSubsetSums
