import NineSeparatedSubsetSums.EightPoint140_122PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct140_122_1_budget :
    FourPointNumeric.packedBudget 20 packedOct140_122_1 374 = 82018066 := by decide +kernel

#print axioms packedOct140_122_1_budget

end NineSeparatedSubsetSums
