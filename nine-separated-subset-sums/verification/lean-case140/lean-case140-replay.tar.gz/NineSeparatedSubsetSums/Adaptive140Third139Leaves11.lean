import NineSeparatedSubsetSums.Adaptive140Third139State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third139Proof70 : runCachedNode 511 129561 Adaptive140Third139Node70 = false := by
  decide +kernel

#print axioms adaptive140Third139Proof70

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third139Proof186 : runCachedNode 511 129561 Adaptive140Third139Node186 = false := by
  decide +kernel

#print axioms adaptive140Third139Proof186

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third139Proof123 : runCachedNode 511 129561 Adaptive140Third139Node123 = false := by
  decide +kernel

#print axioms adaptive140Third139Proof123

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third139Proof47 : runCachedNode 511 129561 Adaptive140Third139Node47 = false := by
  decide +kernel

#print axioms adaptive140Third139Proof47

end NineSeparatedSubsetSums
