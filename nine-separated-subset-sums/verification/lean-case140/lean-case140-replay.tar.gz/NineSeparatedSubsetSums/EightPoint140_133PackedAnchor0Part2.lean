import NineSeparatedSubsetSums.EightPoint140_133PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint140_133PackedAnchor0Part2 :
    ∀ j : Fin 9, 2458551 ≤ FourPointNumeric.octPackedCharge 140 133 20 packedOct140_133_0
      (2*((j.val : Int)+240)+1) := by decide +kernel

end NineSeparatedSubsetSums
