import NineSeparatedSubsetSums.EightPoint140_118PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct140_118_0_budget :
    FourPointNumeric.packedBudget 20 packedOct140_118_0 271 = 86304582 := by decide +kernel

#print axioms packedOct140_118_0_budget

end NineSeparatedSubsetSums
