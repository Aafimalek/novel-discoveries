import NineSeparatedSubsetSums.EightPointPackedGeometry
import NineSeparatedSubsetSums.EightPoint140_124PackedBudget0
import NineSeparatedSubsetSums.EightPoint140_124PackedAnchor0Part0
import NineSeparatedSubsetSums.EightPoint140_124PackedAnchor0Part1
import NineSeparatedSubsetSums.EightPoint140_124PackedBudget1
import NineSeparatedSubsetSums.EightPoint140_124PackedAnchor1Part0
import NineSeparatedSubsetSums.EightPoint140_124PackedAnchor1Part1

namespace NineSeparatedSubsetSums

private theorem packedOct140_124Anchor0 :
  ∀ j : Fin 480, ((j.val : Int)+140+124)%2=0 →
    2294738 ≤ FourPointNumeric.octPackedCharge 140 124 20 packedOct140_124_0 (j.val : Int) := by
  intro j hj
  let k := (j.val-0)/2
  have hk : k < 240 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+0 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint140_124PackedAnchor0Part0 z
    rwa [he,hrep] at ht
  let z : Fin 120 := ⟨k-120, by omega⟩
  have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
  have ht := eightPoint140_124PackedAnchor0Part1 z
  rwa [he,hrep] at ht

private theorem packedOct140_124Anchor1 :
  ∀ j : Fin 480, ((j.val : Int)+140+124)%2=1 →
    2294259 ≤ FourPointNumeric.octPackedCharge 140 124 20 packedOct140_124_1 (j.val : Int) := by
  intro j hj
  let k := (j.val-1)/2
  have hk : k < 240 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+1 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint140_124PackedAnchor1Part0 z
    rwa [he,hrep] at ht
  let z : Fin 120 := ⟨k-120, by omega⟩
  have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
  have ht := eightPoint140_124PackedAnchor1Part1 z
  rwa [he,hrep] at ht

def packedOctCertificate140_124_0 : EightPointCertificate 140 124 0 126427 :=
  eightPointCertificateOfPacked 140 124 0 126427 2294738 20 packedOct140_124_0 377 480
    (by decide +kernel) (by decide) packedOct140_124Anchor0
    (by rw [packedOct140_124_0_budget]; decide)

def packedOctCertificate140_124_1 : EightPointCertificate 140 124 1 126427 :=
  eightPointCertificateOfPacked 140 124 1 126427 2294259 20 packedOct140_124_1 486 480
    (by decide +kernel) (by decide) packedOct140_124Anchor1
    (by rw [packedOct140_124_1_budget]; decide)

theorem max148_second140_third124_eightPoint_moment_bound (tail : List ℕ) (len : tail.length=6)
    (distinct : (natSubsetSums (148::140::124::tail)).Nodup) :
    126427 ≤ ((148::140::124::tail).map (· ^ 2)).sum := by
  apply eightPointNatMomentLower 140 124 126427 tail len distinct
  intro p hp
  by_cases h : p=0
  · subst p
    exact packedOctCertificate140_124_0
  · have he : p=1 := hp.resolve_left h
    subst p
    exact packedOctCertificate140_124_1

#print axioms max148_second140_third124_eightPoint_moment_bound

end NineSeparatedSubsetSums
