import NineSeparatedSubsetSums.Adaptive140Third135State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third135Proof71 : runCachedNode 511 128865 Adaptive140Third135Node71 = false := by
  decide +kernel

#print axioms adaptive140Third135Proof71

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third135Proof73 : runCachedNode 511 128865 Adaptive140Third135Node73 = false := by
  decide +kernel

#print axioms adaptive140Third135Proof73

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third135Proof44 : runCachedNode 511 128865 Adaptive140Third135Node44 = false := by
  decide +kernel

#print axioms adaptive140Third135Proof44

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third135Proof2 : runCachedNode 511 128865 Adaptive140Third135Node2 = false := by
  decide +kernel

#print axioms adaptive140Third135Proof2

end NineSeparatedSubsetSums
