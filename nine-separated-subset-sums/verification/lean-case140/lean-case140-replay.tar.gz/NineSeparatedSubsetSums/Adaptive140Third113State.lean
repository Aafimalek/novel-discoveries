import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive140Third113Node0 : CachedSearchNode :=
  ⟨4, 112, computeCenteredMask [148,140,113], 401, 54273⟩

end NineSeparatedSubsetSums
