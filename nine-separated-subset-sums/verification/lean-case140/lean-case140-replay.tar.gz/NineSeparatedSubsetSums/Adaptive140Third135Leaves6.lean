import NineSeparatedSubsetSums.Adaptive140Third135State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third135Proof45 : runCachedNode 511 128865 Adaptive140Third135Node45 = false := by
  decide +kernel

#print axioms adaptive140Third135Proof45

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third135Proof18 : runCachedNode 511 128865 Adaptive140Third135Node18 = false := by
  decide +kernel

#print axioms adaptive140Third135Proof18

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third135Proof96 : runCachedNode 511 128865 Adaptive140Third135Node96 = false := by
  decide +kernel

#print axioms adaptive140Third135Proof96

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third135Proof38 : runCachedNode 511 128865 Adaptive140Third135Node38 = false := by
  decide +kernel

#print axioms adaptive140Third135Proof38

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third135Proof49 : runCachedNode 511 128865 Adaptive140Third135Node49 = false := by
  decide +kernel

#print axioms adaptive140Third135Proof49

end NineSeparatedSubsetSums
