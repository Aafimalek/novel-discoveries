import NineSeparatedSubsetSums.EightPoint140_129PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct140_129_0_budget :
    FourPointNumeric.packedBudget 20 packedOct140_129_0 445 = 87570340 := by decide +kernel

#print axioms packedOct140_129_0_budget

end NineSeparatedSubsetSums
