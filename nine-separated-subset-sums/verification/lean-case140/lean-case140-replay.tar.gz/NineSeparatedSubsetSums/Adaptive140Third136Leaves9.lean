import NineSeparatedSubsetSums.Adaptive140Third136State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third136Proof128 : runCachedNode 511 129025 Adaptive140Third136Node128 = false := by
  decide +kernel

#print axioms adaptive140Third136Proof128

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third136Proof41 : runCachedNode 511 129025 Adaptive140Third136Node41 = false := by
  decide +kernel

#print axioms adaptive140Third136Proof41

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third136Proof14 : runCachedNode 511 129025 Adaptive140Third136Node14 = false := by
  decide +kernel

#print axioms adaptive140Third136Proof14

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third136Proof156 : runCachedNode 511 129025 Adaptive140Third136Node156 = false := by
  decide +kernel

#print axioms adaptive140Third136Proof156

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third136Proof126 : runCachedNode 511 129025 Adaptive140Third136Node126 = false := by
  decide +kernel

#print axioms adaptive140Third136Proof126

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third136Proof121 : runCachedNode 511 129025 Adaptive140Third136Node121 = false := by
  decide +kernel

#print axioms adaptive140Third136Proof121

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third136Proof91 : runCachedNode 511 129025 Adaptive140Third136Node91 = false := by
  decide +kernel

#print axioms adaptive140Third136Proof91

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third136Proof4 : runCachedNode 511 129025 Adaptive140Third136Node4 = false := by
  decide +kernel

#print axioms adaptive140Third136Proof4

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third136Proof23 : runCachedNode 511 129025 Adaptive140Third136Node23 = false := by
  decide +kernel

#print axioms adaptive140Third136Proof23

end NineSeparatedSubsetSums
