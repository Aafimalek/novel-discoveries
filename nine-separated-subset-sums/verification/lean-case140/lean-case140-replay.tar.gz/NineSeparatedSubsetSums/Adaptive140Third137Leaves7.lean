import NineSeparatedSubsetSums.Adaptive140Third137State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third137Proof101 : runCachedNode 511 129199 Adaptive140Third137Node101 = false := by
  decide +kernel

#print axioms adaptive140Third137Proof101

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third137Proof19 : runCachedNode 511 129199 Adaptive140Third137Node19 = false := by
  decide +kernel

#print axioms adaptive140Third137Proof19

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third137Proof39 : runCachedNode 511 129199 Adaptive140Third137Node39 = false := by
  decide +kernel

#print axioms adaptive140Third137Proof39

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third137Proof23 : runCachedNode 511 129199 Adaptive140Third137Node23 = false := by
  decide +kernel

#print axioms adaptive140Third137Proof23

end NineSeparatedSubsetSums
