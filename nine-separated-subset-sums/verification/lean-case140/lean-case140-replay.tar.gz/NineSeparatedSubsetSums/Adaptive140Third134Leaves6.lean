import NineSeparatedSubsetSums.Adaptive140Third134State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third134Proof71 : runCachedNode 511 128648 Adaptive140Third134Node71 = false := by
  decide +kernel

#print axioms adaptive140Third134Proof71

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third134Proof15 : runCachedNode 511 128648 Adaptive140Third134Node15 = false := by
  decide +kernel

#print axioms adaptive140Third134Proof15

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third134Proof72 : runCachedNode 511 128648 Adaptive140Third134Node72 = false := by
  decide +kernel

#print axioms adaptive140Third134Proof72

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third134Proof14 : runCachedNode 511 128648 Adaptive140Third134Node14 = false := by
  decide +kernel

#print axioms adaptive140Third134Proof14

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third134Proof13 : runCachedNode 511 128648 Adaptive140Third134Node13 = false := by
  decide +kernel

#print axioms adaptive140Third134Proof13

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third134Proof69 : runCachedNode 511 128648 Adaptive140Third134Node69 = false := by
  decide +kernel

#print axioms adaptive140Third134Proof69

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third134Proof57 : runCachedNode 511 128648 Adaptive140Third134Node57 = false := by
  decide +kernel

#print axioms adaptive140Third134Proof57

end NineSeparatedSubsetSums
