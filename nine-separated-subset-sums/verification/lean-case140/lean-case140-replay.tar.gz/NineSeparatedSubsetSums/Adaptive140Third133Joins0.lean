import NineSeparatedSubsetSums.Adaptive140Third133State
import NineSeparatedSubsetSums.Adaptive140Third133Leaves3
import NineSeparatedSubsetSums.Adaptive140Third133Leaves4
import NineSeparatedSubsetSums.Adaptive140Third133Leaves1
import NineSeparatedSubsetSums.Adaptive140Third133Leaves5
import NineSeparatedSubsetSums.Adaptive140Third133Leaves2
import NineSeparatedSubsetSums.Adaptive140Third133Leaves0

namespace NineSeparatedSubsetSums

theorem adaptive140Third133Proof22 : runCachedNode 511 128482 Adaptive140Third133Node22 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 128482 Adaptive140Third133Node22 = [104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 118, 119, 120, 121, 122, 123, 126, 127, 128, 129, 130, 131] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive140Third133Proof23
  · exact adaptive140Third133Proof24
  · exact adaptive140Third133Proof25
  · exact adaptive140Third133Proof26
  · exact adaptive140Third133Proof27
  · exact adaptive140Third133Proof28
  · exact adaptive140Third133Proof29
  · exact adaptive140Third133Proof30
  · exact adaptive140Third133Proof31
  · exact adaptive140Third133Proof32
  · exact adaptive140Third133Proof33
  · exact adaptive140Third133Proof34
  · exact adaptive140Third133Proof35
  · exact adaptive140Third133Proof36
  · exact adaptive140Third133Proof37
  · exact adaptive140Third133Proof38
  · exact adaptive140Third133Proof39
  · exact adaptive140Third133Proof40
  · exact adaptive140Third133Proof41
  · exact adaptive140Third133Proof42
  · exact adaptive140Third133Proof43
  · exact adaptive140Third133Proof44
  · exact adaptive140Third133Proof45
  · exact adaptive140Third133Proof46
  · exact adaptive140Third133Proof47

#print axioms adaptive140Third133Proof22

theorem adaptive140Third133Proof0 : runCachedNode 511 128482 Adaptive140Third133Node0 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 128482 Adaptive140Third133Node0 = [110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 126, 127, 128, 129, 130, 131, 132] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive140Third133Proof1
  · exact adaptive140Third133Proof2
  · exact adaptive140Third133Proof3
  · exact adaptive140Third133Proof4
  · exact adaptive140Third133Proof5
  · exact adaptive140Third133Proof6
  · exact adaptive140Third133Proof7
  · exact adaptive140Third133Proof8
  · exact adaptive140Third133Proof9
  · exact adaptive140Third133Proof10
  · exact adaptive140Third133Proof11
  · exact adaptive140Third133Proof12
  · exact adaptive140Third133Proof13
  · exact adaptive140Third133Proof14
  · exact adaptive140Third133Proof15
  · exact adaptive140Third133Proof16
  · exact adaptive140Third133Proof17
  · exact adaptive140Third133Proof18
  · exact adaptive140Third133Proof19
  · exact adaptive140Third133Proof20
  · exact adaptive140Third133Proof21
  · exact adaptive140Third133Proof22

#print axioms adaptive140Third133Proof0

end NineSeparatedSubsetSums
