import NineSeparatedSubsetSums.Adaptive140Third135State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third135Proof19 : runCachedNode 511 128865 Adaptive140Third135Node19 = false := by
  decide +kernel

#print axioms adaptive140Third135Proof19

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third135Proof99 : runCachedNode 511 128865 Adaptive140Third135Node99 = false := by
  decide +kernel

#print axioms adaptive140Third135Proof99

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third135Proof68 : runCachedNode 511 128865 Adaptive140Third135Node68 = false := by
  decide +kernel

#print axioms adaptive140Third135Proof68

end NineSeparatedSubsetSums
