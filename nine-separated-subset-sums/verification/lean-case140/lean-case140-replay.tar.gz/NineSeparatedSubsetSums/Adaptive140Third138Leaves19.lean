import NineSeparatedSubsetSums.Adaptive140Third138State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third138Proof143 : runCachedNode 511 129379 Adaptive140Third138Node143 = false := by
  decide +kernel

#print axioms adaptive140Third138Proof143

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third138Proof61 : runCachedNode 511 129379 Adaptive140Third138Node61 = false := by
  decide +kernel

#print axioms adaptive140Third138Proof61

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third138Proof173 : runCachedNode 511 129379 Adaptive140Third138Node173 = false := by
  decide +kernel

#print axioms adaptive140Third138Proof173

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third138Proof114 : runCachedNode 511 129379 Adaptive140Third138Node114 = false := by
  decide +kernel

#print axioms adaptive140Third138Proof114

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third138Proof6 : runCachedNode 511 129379 Adaptive140Third138Node6 = false := by
  decide +kernel

#print axioms adaptive140Third138Proof6

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third138Proof206 : runCachedNode 511 129379 Adaptive140Third138Node206 = false := by
  decide +kernel

#print axioms adaptive140Third138Proof206

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third138Proof30 : runCachedNode 511 129379 Adaptive140Third138Node30 = false := by
  decide +kernel

#print axioms adaptive140Third138Proof30

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third138Proof60 : runCachedNode 511 129379 Adaptive140Third138Node60 = false := by
  decide +kernel

#print axioms adaptive140Third138Proof60

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third138Proof205 : runCachedNode 511 129379 Adaptive140Third138Node205 = false := by
  decide +kernel

#print axioms adaptive140Third138Proof205

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third138Proof170 : runCachedNode 511 129379 Adaptive140Third138Node170 = false := by
  decide +kernel

#print axioms adaptive140Third138Proof170

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third138Proof29 : runCachedNode 511 129379 Adaptive140Third138Node29 = false := by
  decide +kernel

#print axioms adaptive140Third138Proof29

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third138Proof113 : runCachedNode 511 129379 Adaptive140Third138Node113 = false := by
  decide +kernel

#print axioms adaptive140Third138Proof113

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third138Proof142 : runCachedNode 511 129379 Adaptive140Third138Node142 = false := by
  decide +kernel

#print axioms adaptive140Third138Proof142

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third138Proof5 : runCachedNode 511 129379 Adaptive140Third138Node5 = false := by
  decide +kernel

#print axioms adaptive140Third138Proof5

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third138Proof171 : runCachedNode 511 129379 Adaptive140Third138Node171 = false := by
  decide +kernel

#print axioms adaptive140Third138Proof171

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third138Proof59 : runCachedNode 511 129379 Adaptive140Third138Node59 = false := by
  decide +kernel

#print axioms adaptive140Third138Proof59

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third138Proof86 : runCachedNode 511 129379 Adaptive140Third138Node86 = false := by
  decide +kernel

#print axioms adaptive140Third138Proof86

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third138Proof28 : runCachedNode 511 129379 Adaptive140Third138Node28 = false := by
  decide +kernel

#print axioms adaptive140Third138Proof28

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third138Proof141 : runCachedNode 511 129379 Adaptive140Third138Node141 = false := by
  decide +kernel

#print axioms adaptive140Third138Proof141

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third138Proof4 : runCachedNode 511 129379 Adaptive140Third138Node4 = false := by
  decide +kernel

#print axioms adaptive140Third138Proof4

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third138Proof204 : runCachedNode 511 129379 Adaptive140Third138Node204 = false := by
  decide +kernel

#print axioms adaptive140Third138Proof204

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third138Proof27 : runCachedNode 511 129379 Adaptive140Third138Node27 = false := by
  decide +kernel

#print axioms adaptive140Third138Proof27

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third138Proof58 : runCachedNode 511 129379 Adaptive140Third138Node58 = false := by
  decide +kernel

#print axioms adaptive140Third138Proof58

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third138Proof169 : runCachedNode 511 129379 Adaptive140Third138Node169 = false := by
  decide +kernel

#print axioms adaptive140Third138Proof169

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third138Proof85 : runCachedNode 511 129379 Adaptive140Third138Node85 = false := by
  decide +kernel

#print axioms adaptive140Third138Proof85

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third138Proof111 : runCachedNode 511 129379 Adaptive140Third138Node111 = false := by
  decide +kernel

#print axioms adaptive140Third138Proof111

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third138Proof110 : runCachedNode 511 129379 Adaptive140Third138Node110 = false := by
  decide +kernel

#print axioms adaptive140Third138Proof110

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third138Proof140 : runCachedNode 511 129379 Adaptive140Third138Node140 = false := by
  decide +kernel

#print axioms adaptive140Third138Proof140

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third138Proof168 : runCachedNode 511 129379 Adaptive140Third138Node168 = false := by
  decide +kernel

#print axioms adaptive140Third138Proof168

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third138Proof203 : runCachedNode 511 129379 Adaptive140Third138Node203 = false := by
  decide +kernel

#print axioms adaptive140Third138Proof203

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third138Proof25 : runCachedNode 511 129379 Adaptive140Third138Node25 = false := by
  decide +kernel

#print axioms adaptive140Third138Proof25

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third138Proof109 : runCachedNode 511 129379 Adaptive140Third138Node109 = false := by
  decide +kernel

#print axioms adaptive140Third138Proof109

end NineSeparatedSubsetSums
