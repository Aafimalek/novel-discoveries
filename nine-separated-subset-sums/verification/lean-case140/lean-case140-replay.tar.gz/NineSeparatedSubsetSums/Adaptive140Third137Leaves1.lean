import NineSeparatedSubsetSums.Adaptive140Third137State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third137Proof100 : runCachedNode 511 129199 Adaptive140Third137Node100 = false := by
  decide +kernel

#print axioms adaptive140Third137Proof100

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third137Proof16 : runCachedNode 511 129199 Adaptive140Third137Node16 = false := by
  decide +kernel

#print axioms adaptive140Third137Proof16

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third137Proof81 : runCachedNode 511 129199 Adaptive140Third137Node81 = false := by
  decide +kernel

#print axioms adaptive140Third137Proof81

end NineSeparatedSubsetSums
