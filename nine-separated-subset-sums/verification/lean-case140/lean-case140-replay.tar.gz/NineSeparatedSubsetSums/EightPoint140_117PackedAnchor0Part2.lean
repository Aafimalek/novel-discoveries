import NineSeparatedSubsetSums.EightPoint140_117PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint140_117PackedAnchor0Part2 :
    ∀ j : Fin 4, 2349420 ≤ FourPointNumeric.octPackedCharge 140 117 20 packedOct140_117_0
      (2*((j.val : Int)+240)+1) := by decide +kernel

end NineSeparatedSubsetSums
