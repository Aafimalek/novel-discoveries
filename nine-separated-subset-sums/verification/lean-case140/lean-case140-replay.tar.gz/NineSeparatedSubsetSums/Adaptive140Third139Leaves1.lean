import NineSeparatedSubsetSums.Adaptive140Third139State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third139Proof71 : runCachedNode 511 129561 Adaptive140Third139Node71 = false := by
  decide +kernel

#print axioms adaptive140Third139Proof71

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third139Proof39 : runCachedNode 511 129561 Adaptive140Third139Node39 = false := by
  decide +kernel

#print axioms adaptive140Third139Proof39

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third139Proof2 : runCachedNode 511 129561 Adaptive140Third139Node2 = false := by
  decide +kernel

#print axioms adaptive140Third139Proof2

end NineSeparatedSubsetSums
