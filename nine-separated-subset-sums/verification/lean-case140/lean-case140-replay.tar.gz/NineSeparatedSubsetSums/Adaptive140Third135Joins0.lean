import NineSeparatedSubsetSums.Adaptive140Third135State
import NineSeparatedSubsetSums.Adaptive140Third135Leaves7
import NineSeparatedSubsetSums.Adaptive140Third135Leaves8
import NineSeparatedSubsetSums.Adaptive140Third135Leaves10
import NineSeparatedSubsetSums.Adaptive140Third135Leaves9
import NineSeparatedSubsetSums.Adaptive140Third135Leaves1
import NineSeparatedSubsetSums.Adaptive140Third135Leaves6
import NineSeparatedSubsetSums.Adaptive140Third135Leaves4
import NineSeparatedSubsetSums.Adaptive140Third135Leaves5
import NineSeparatedSubsetSums.Adaptive140Third135Leaves3
import NineSeparatedSubsetSums.Adaptive140Third135Leaves2
import NineSeparatedSubsetSums.Adaptive140Third135Leaves0

namespace NineSeparatedSubsetSums

theorem adaptive140Third135Proof22 : runCachedNode 511 128865 Adaptive140Third135Node22 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 128865 Adaptive140Third135Node22 = [104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 120, 121, 122, 123, 125, 126, 128, 129, 130, 131] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive140Third135Proof23
  · exact adaptive140Third135Proof24
  · exact adaptive140Third135Proof25
  · exact adaptive140Third135Proof26
  · exact adaptive140Third135Proof27
  · exact adaptive140Third135Proof28
  · exact adaptive140Third135Proof29
  · exact adaptive140Third135Proof30
  · exact adaptive140Third135Proof31
  · exact adaptive140Third135Proof32
  · exact adaptive140Third135Proof33
  · exact adaptive140Third135Proof34
  · exact adaptive140Third135Proof35
  · exact adaptive140Third135Proof36
  · exact adaptive140Third135Proof37
  · exact adaptive140Third135Proof38
  · exact adaptive140Third135Proof39
  · exact adaptive140Third135Proof40
  · exact adaptive140Third135Proof41
  · exact adaptive140Third135Proof42
  · exact adaptive140Third135Proof43
  · exact adaptive140Third135Proof44
  · exact adaptive140Third135Proof45
  · exact adaptive140Third135Proof46
  · exact adaptive140Third135Proof47

#print axioms adaptive140Third135Proof22

theorem adaptive140Third135Proof48 : runCachedNode 511 128865 Adaptive140Third135Node48 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 128865 Adaptive140Third135Node48 = [104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 121, 122, 123, 124, 126, 129, 130, 131, 132] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive140Third135Proof49
  · exact adaptive140Third135Proof50
  · exact adaptive140Third135Proof51
  · exact adaptive140Third135Proof52
  · exact adaptive140Third135Proof53
  · exact adaptive140Third135Proof54
  · exact adaptive140Third135Proof55
  · exact adaptive140Third135Proof56
  · exact adaptive140Third135Proof57
  · exact adaptive140Third135Proof58
  · exact adaptive140Third135Proof59
  · exact adaptive140Third135Proof60
  · exact adaptive140Third135Proof61
  · exact adaptive140Third135Proof62
  · exact adaptive140Third135Proof63
  · exact adaptive140Third135Proof64
  · exact adaptive140Third135Proof65
  · exact adaptive140Third135Proof66
  · exact adaptive140Third135Proof67
  · exact adaptive140Third135Proof68
  · exact adaptive140Third135Proof69
  · exact adaptive140Third135Proof70
  · exact adaptive140Third135Proof71
  · exact adaptive140Third135Proof72
  · exact adaptive140Third135Proof73

#print axioms adaptive140Third135Proof48

theorem adaptive140Third135Proof74 : runCachedNode 511 128865 Adaptive140Third135Node74 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 128865 Adaptive140Third135Node74 = [104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 122, 123, 124, 125, 128, 130, 131, 132, 133] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive140Third135Proof75
  · exact adaptive140Third135Proof76
  · exact adaptive140Third135Proof77
  · exact adaptive140Third135Proof78
  · exact adaptive140Third135Proof79
  · exact adaptive140Third135Proof80
  · exact adaptive140Third135Proof81
  · exact adaptive140Third135Proof82
  · exact adaptive140Third135Proof83
  · exact adaptive140Third135Proof84
  · exact adaptive140Third135Proof85
  · exact adaptive140Third135Proof86
  · exact adaptive140Third135Proof87
  · exact adaptive140Third135Proof88
  · exact adaptive140Third135Proof89
  · exact adaptive140Third135Proof90
  · exact adaptive140Third135Proof91
  · exact adaptive140Third135Proof92
  · exact adaptive140Third135Proof93
  · exact adaptive140Third135Proof94
  · exact adaptive140Third135Proof95
  · exact adaptive140Third135Proof96
  · exact adaptive140Third135Proof97
  · exact adaptive140Third135Proof98
  · exact adaptive140Third135Proof99
  · exact adaptive140Third135Proof100

#print axioms adaptive140Third135Proof74

theorem adaptive140Third135Proof0 : runCachedNode 511 128865 Adaptive140Third135Node0 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 128865 Adaptive140Third135Node0 = [110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 128, 129, 130, 131, 132, 133, 134] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive140Third135Proof1
  · exact adaptive140Third135Proof2
  · exact adaptive140Third135Proof3
  · exact adaptive140Third135Proof4
  · exact adaptive140Third135Proof5
  · exact adaptive140Third135Proof6
  · exact adaptive140Third135Proof7
  · exact adaptive140Third135Proof8
  · exact adaptive140Third135Proof9
  · exact adaptive140Third135Proof10
  · exact adaptive140Third135Proof11
  · exact adaptive140Third135Proof12
  · exact adaptive140Third135Proof13
  · exact adaptive140Third135Proof14
  · exact adaptive140Third135Proof15
  · exact adaptive140Third135Proof16
  · exact adaptive140Third135Proof17
  · exact adaptive140Third135Proof18
  · exact adaptive140Third135Proof19
  · exact adaptive140Third135Proof20
  · exact adaptive140Third135Proof21
  · exact adaptive140Third135Proof22
  · exact adaptive140Third135Proof48
  · exact adaptive140Third135Proof74

#print axioms adaptive140Third135Proof0

end NineSeparatedSubsetSums
