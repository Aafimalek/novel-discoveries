import NineSeparatedSubsetSums.Adaptive140Third132State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third132Proof41 : runCachedNode 511 128323 Adaptive140Third132Node41 = false := by
  decide +kernel

#print axioms adaptive140Third132Proof41

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third132Proof39 : runCachedNode 511 128323 Adaptive140Third132Node39 = false := by
  decide +kernel

#print axioms adaptive140Third132Proof39

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third132Proof10 : runCachedNode 511 128323 Adaptive140Third132Node10 = false := by
  decide +kernel

#print axioms adaptive140Third132Proof10

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third132Proof62 : runCachedNode 511 128323 Adaptive140Third132Node62 = false := by
  decide +kernel

#print axioms adaptive140Third132Proof62

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third132Proof38 : runCachedNode 511 128323 Adaptive140Third132Node38 = false := by
  decide +kernel

#print axioms adaptive140Third132Proof38

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third132Proof64 : runCachedNode 511 128323 Adaptive140Third132Node64 = false := by
  decide +kernel

#print axioms adaptive140Third132Proof64

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third132Proof61 : runCachedNode 511 128323 Adaptive140Third132Node61 = false := by
  decide +kernel

#print axioms adaptive140Third132Proof61

end NineSeparatedSubsetSums
