import NineSeparatedSubsetSums.Adaptive140Third135State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third135Proof20 : runCachedNode 511 128865 Adaptive140Third135Node20 = false := by
  decide +kernel

#print axioms adaptive140Third135Proof20

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third135Proof16 : runCachedNode 511 128865 Adaptive140Third135Node16 = false := by
  decide +kernel

#print axioms adaptive140Third135Proof16

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third135Proof32 : runCachedNode 511 128865 Adaptive140Third135Node32 = false := by
  decide +kernel

#print axioms adaptive140Third135Proof32

end NineSeparatedSubsetSums
