import NineSeparatedSubsetSums.EightPoint140_123PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint140_123PackedAnchor0Part1 :
    ∀ j : Fin 119, 2285652 ≤ FourPointNumeric.octPackedCharge 140 123 20 packedOct140_123_0
      (2*((j.val : Int)+120)+1) := by decide +kernel

end NineSeparatedSubsetSums
