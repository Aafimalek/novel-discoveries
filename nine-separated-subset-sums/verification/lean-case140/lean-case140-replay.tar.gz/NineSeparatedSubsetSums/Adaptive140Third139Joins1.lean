import NineSeparatedSubsetSums.Adaptive140Third139State
import NineSeparatedSubsetSums.Adaptive140Third139Leaves8
import NineSeparatedSubsetSums.Adaptive140Third139Leaves1
import NineSeparatedSubsetSums.Adaptive140Third139Leaves22
import NineSeparatedSubsetSums.Adaptive140Third139Leaves3
import NineSeparatedSubsetSums.Adaptive140Third139Leaves10
import NineSeparatedSubsetSums.Adaptive140Third139Leaves2
import NineSeparatedSubsetSums.Adaptive140Third139Leaves21
import NineSeparatedSubsetSums.Adaptive140Third139Leaves20
import NineSeparatedSubsetSums.Adaptive140Third139Leaves19
import NineSeparatedSubsetSums.Adaptive140Third139Leaves18
import NineSeparatedSubsetSums.Adaptive140Third139Leaves0
import NineSeparatedSubsetSums.Adaptive140Third139Leaves15
import NineSeparatedSubsetSums.Adaptive140Third139Leaves14
import NineSeparatedSubsetSums.Adaptive140Third139Leaves4
import NineSeparatedSubsetSums.Adaptive140Third139Leaves12
import NineSeparatedSubsetSums.Adaptive140Third139Leaves6
import NineSeparatedSubsetSums.Adaptive140Third139Leaves7
import NineSeparatedSubsetSums.Adaptive140Third139Joins0

namespace NineSeparatedSubsetSums

theorem adaptive140Third139Proof0 : runCachedNode 511 129561 Adaptive140Third139Node0 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 129561 Adaptive140Third139Node0 = [110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 132, 133, 134, 135, 136, 137, 138] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive140Third139Proof1
  · exact adaptive140Third139Proof2
  · exact adaptive140Third139Proof3
  · exact adaptive140Third139Proof4
  · exact adaptive140Third139Proof5
  · exact adaptive140Third139Proof6
  · exact adaptive140Third139Proof7
  · exact adaptive140Third139Proof8
  · exact adaptive140Third139Proof9
  · exact adaptive140Third139Proof10
  · exact adaptive140Third139Proof11
  · exact adaptive140Third139Proof12
  · exact adaptive140Third139Proof13
  · exact adaptive140Third139Proof14
  · exact adaptive140Third139Proof15
  · exact adaptive140Third139Proof16
  · exact adaptive140Third139Proof17
  · exact adaptive140Third139Proof18
  · exact adaptive140Third139Proof19
  · exact adaptive140Third139Proof20
  · exact adaptive140Third139Proof21
  · exact adaptive140Third139Proof45
  · exact adaptive140Third139Proof71
  · exact adaptive140Third139Proof72
  · exact adaptive140Third139Proof100
  · exact adaptive140Third139Proof129
  · exact adaptive140Third139Proof159
  · exact adaptive140Third139Proof191

#print axioms adaptive140Third139Proof0

end NineSeparatedSubsetSums
