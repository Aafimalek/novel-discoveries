import NineSeparatedSubsetSums.Adaptive140Third133State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third133Proof20 : runCachedNode 511 128482 Adaptive140Third133Node20 = false := by
  decide +kernel

#print axioms adaptive140Third133Proof20

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third133Proof18 : runCachedNode 511 128482 Adaptive140Third133Node18 = false := by
  decide +kernel

#print axioms adaptive140Third133Proof18

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third133Proof25 : runCachedNode 511 128482 Adaptive140Third133Node25 = false := by
  decide +kernel

#print axioms adaptive140Third133Proof25

end NineSeparatedSubsetSums
