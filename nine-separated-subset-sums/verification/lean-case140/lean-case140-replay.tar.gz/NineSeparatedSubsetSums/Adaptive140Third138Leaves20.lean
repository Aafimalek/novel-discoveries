import NineSeparatedSubsetSums.Adaptive140Third138State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third138Proof56 : runCachedNode 511 129379 Adaptive140Third138Node56 = false := by
  decide +kernel

#print axioms adaptive140Third138Proof56

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third138Proof83 : runCachedNode 511 129379 Adaptive140Third138Node83 = false := by
  decide +kernel

#print axioms adaptive140Third138Proof83

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third138Proof84 : runCachedNode 511 129379 Adaptive140Third138Node84 = false := by
  decide +kernel

#print axioms adaptive140Third138Proof84

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third138Proof108 : runCachedNode 511 129379 Adaptive140Third138Node108 = false := by
  decide +kernel

#print axioms adaptive140Third138Proof108

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third138Proof166 : runCachedNode 511 129379 Adaptive140Third138Node166 = false := by
  decide +kernel

#print axioms adaptive140Third138Proof166

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third138Proof167 : runCachedNode 511 129379 Adaptive140Third138Node167 = false := by
  decide +kernel

#print axioms adaptive140Third138Proof167

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third138Proof202 : runCachedNode 511 129379 Adaptive140Third138Node202 = false := by
  decide +kernel

#print axioms adaptive140Third138Proof202

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third138Proof3 : runCachedNode 511 129379 Adaptive140Third138Node3 = false := by
  decide +kernel

#print axioms adaptive140Third138Proof3

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third138Proof82 : runCachedNode 511 129379 Adaptive140Third138Node82 = false := by
  decide +kernel

#print axioms adaptive140Third138Proof82

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third138Proof107 : runCachedNode 511 129379 Adaptive140Third138Node107 = false := by
  decide +kernel

#print axioms adaptive140Third138Proof107

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third138Proof138 : runCachedNode 511 129379 Adaptive140Third138Node138 = false := by
  decide +kernel

#print axioms adaptive140Third138Proof138

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third138Proof139 : runCachedNode 511 129379 Adaptive140Third138Node139 = false := by
  decide +kernel

#print axioms adaptive140Third138Proof139

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third138Proof165 : runCachedNode 511 129379 Adaptive140Third138Node165 = false := by
  decide +kernel

#print axioms adaptive140Third138Proof165

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third138Proof54 : runCachedNode 511 129379 Adaptive140Third138Node54 = false := by
  decide +kernel

#print axioms adaptive140Third138Proof54

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third138Proof80 : runCachedNode 511 129379 Adaptive140Third138Node80 = false := by
  decide +kernel

#print axioms adaptive140Third138Proof80

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third138Proof81 : runCachedNode 511 129379 Adaptive140Third138Node81 = false := by
  decide +kernel

#print axioms adaptive140Third138Proof81

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third138Proof137 : runCachedNode 511 129379 Adaptive140Third138Node137 = false := by
  decide +kernel

#print axioms adaptive140Third138Proof137

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third138Proof163 : runCachedNode 511 129379 Adaptive140Third138Node163 = false := by
  decide +kernel

#print axioms adaptive140Third138Proof163

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third138Proof164 : runCachedNode 511 129379 Adaptive140Third138Node164 = false := by
  decide +kernel

#print axioms adaptive140Third138Proof164

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third138Proof200 : runCachedNode 511 129379 Adaptive140Third138Node200 = false := by
  decide +kernel

#print axioms adaptive140Third138Proof200

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third138Proof201 : runCachedNode 511 129379 Adaptive140Third138Node201 = false := by
  decide +kernel

#print axioms adaptive140Third138Proof201

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third138Proof79 : runCachedNode 511 129379 Adaptive140Third138Node79 = false := by
  decide +kernel

#print axioms adaptive140Third138Proof79

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third138Proof106 : runCachedNode 511 129379 Adaptive140Third138Node106 = false := by
  decide +kernel

#print axioms adaptive140Third138Proof106

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third138Proof135 : runCachedNode 511 129379 Adaptive140Third138Node135 = false := by
  decide +kernel

#print axioms adaptive140Third138Proof135

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third138Proof136 : runCachedNode 511 129379 Adaptive140Third138Node136 = false := by
  decide +kernel

#print axioms adaptive140Third138Proof136

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third138Proof162 : runCachedNode 511 129379 Adaptive140Third138Node162 = false := by
  decide +kernel

#print axioms adaptive140Third138Proof162

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third138Proof198 : runCachedNode 511 129379 Adaptive140Third138Node198 = false := by
  decide +kernel

#print axioms adaptive140Third138Proof198

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third138Proof199 : runCachedNode 511 129379 Adaptive140Third138Node199 = false := by
  decide +kernel

#print axioms adaptive140Third138Proof199

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third138Proof51 : runCachedNode 511 129379 Adaptive140Third138Node51 = false := by
  decide +kernel

#print axioms adaptive140Third138Proof51

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third138Proof52 : runCachedNode 511 129379 Adaptive140Third138Node52 = false := by
  decide +kernel

#print axioms adaptive140Third138Proof52

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third138Proof77 : runCachedNode 511 129379 Adaptive140Third138Node77 = false := by
  decide +kernel

#print axioms adaptive140Third138Proof77

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third138Proof78 : runCachedNode 511 129379 Adaptive140Third138Node78 = false := by
  decide +kernel

#print axioms adaptive140Third138Proof78

end NineSeparatedSubsetSums
