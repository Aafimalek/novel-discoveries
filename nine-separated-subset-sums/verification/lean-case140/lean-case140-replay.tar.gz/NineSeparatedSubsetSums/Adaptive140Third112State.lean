import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive140Third112Node0 : CachedSearchNode :=
  ⟨4, 111, computeCenteredMask [148,140,112], 400, 54048⟩

end NineSeparatedSubsetSums
