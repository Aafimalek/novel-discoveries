import NineSeparatedSubsetSums.EightPointPackedGeometry
import NineSeparatedSubsetSums.EightPoint140_127PackedBudget0
import NineSeparatedSubsetSums.EightPoint140_127PackedAnchor0Part0
import NineSeparatedSubsetSums.EightPoint140_127PackedAnchor0Part1
import NineSeparatedSubsetSums.EightPoint140_127PackedAnchor0Part2
import NineSeparatedSubsetSums.EightPoint140_127PackedBudget1
import NineSeparatedSubsetSums.EightPoint140_127PackedAnchor1Part0
import NineSeparatedSubsetSums.EightPoint140_127PackedAnchor1Part1
import NineSeparatedSubsetSums.EightPoint140_127PackedAnchor1Part2

namespace NineSeparatedSubsetSums

private theorem packedOct140_127Anchor0 :
  ∀ j : Fin 487, ((j.val : Int)+140+127)%2=0 →
    2355565 ≤ FourPointNumeric.octPackedCharge 140 127 20 packedOct140_127_0 (j.val : Int) := by
  intro j hj
  let k := (j.val-1)/2
  have hk : k < 243 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+1 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint140_127PackedAnchor0Part0 z
    rwa [he,hrep] at ht
  by_cases h1 : k < 240
  · let z : Fin 120 := ⟨k-120, by omega⟩
    have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
    have ht := eightPoint140_127PackedAnchor0Part1 z
    rwa [he,hrep] at ht
  let z : Fin 3 := ⟨k-240, by omega⟩
  have he : (z.val : Int)+240 = k := by dsimp [z] <;> omega
  have ht := eightPoint140_127PackedAnchor0Part2 z
  rwa [he,hrep] at ht

private theorem packedOct140_127Anchor1 :
  ∀ j : Fin 487, ((j.val : Int)+140+127)%2=1 →
    2355701 ≤ FourPointNumeric.octPackedCharge 140 127 20 packedOct140_127_1 (j.val : Int) := by
  intro j hj
  let k := (j.val-0)/2
  have hk : k < 244 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+0 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint140_127PackedAnchor1Part0 z
    rwa [he,hrep] at ht
  by_cases h1 : k < 240
  · let z : Fin 120 := ⟨k-120, by omega⟩
    have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
    have ht := eightPoint140_127PackedAnchor1Part1 z
    rwa [he,hrep] at ht
  let z : Fin 4 := ⟨k-240, by omega⟩
  have he : (z.val : Int)+240 = k := by dsimp [z] <;> omega
  have ht := eightPoint140_127PackedAnchor1Part2 z
  rwa [he,hrep] at ht

def packedOctCertificate140_127_0 : EightPointCertificate 140 127 0 127359 :=
  eightPointCertificateOfPacked 140 127 0 127359 2355565 20 packedOct140_127_0 267 487
    (by decide +kernel) (by decide) packedOct140_127Anchor0
    (by rw [packedOct140_127_0_budget]; decide)

def packedOctCertificate140_127_1 : EightPointCertificate 140 127 1 127359 :=
  eightPointCertificateOfPacked 140 127 1 127359 2355701 20 packedOct140_127_1 268 487
    (by decide +kernel) (by decide) packedOct140_127Anchor1
    (by rw [packedOct140_127_1_budget]; decide)

theorem max148_second140_third127_eightPoint_moment_bound (tail : List ℕ) (len : tail.length=6)
    (distinct : (natSubsetSums (148::140::127::tail)).Nodup) :
    127359 ≤ ((148::140::127::tail).map (· ^ 2)).sum := by
  apply eightPointNatMomentLower 140 127 127359 tail len distinct
  intro p hp
  by_cases h : p=0
  · subst p
    exact packedOctCertificate140_127_0
  · have he : p=1 := hp.resolve_left h
    subst p
    exact packedOctCertificate140_127_1

#print axioms max148_second140_third127_eightPoint_moment_bound

end NineSeparatedSubsetSums
