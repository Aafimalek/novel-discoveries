import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive140Third123Node0 : CachedSearchNode :=
  ⟨4, 122, computeCenteredMask [148,140,123], 411, 56633⟩

end NineSeparatedSubsetSums
