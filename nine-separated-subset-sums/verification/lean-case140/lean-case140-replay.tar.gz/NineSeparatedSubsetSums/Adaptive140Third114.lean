import NineSeparatedSubsetSums.Adaptive140Third114Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint140Checked

namespace NineSeparatedSubsetSums


theorem adaptive140Third114 : NoDescendingTailAfterThird 140 114 :=
  noDescendingThirdTail_of_cached 140 114 111588 (fun t ht nd => max148_second140_fourPoint_moment_bound (114::t) (by simp [ht]) nd) adaptive140Third114Proof0

#print axioms adaptive140Third114

end NineSeparatedSubsetSums
