import NineSeparatedSubsetSums.EightPoint140_138PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint140_138PackedAnchor0Part2 :
    ∀ j : Fin 11, 2496474 ≤ FourPointNumeric.octPackedCharge 140 138 20 packedOct140_138_0
      (2*((j.val : Int)+240)+0) := by decide +kernel

end NineSeparatedSubsetSums
