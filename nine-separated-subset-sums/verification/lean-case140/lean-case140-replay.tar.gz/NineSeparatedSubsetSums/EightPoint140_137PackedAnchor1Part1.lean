import NineSeparatedSubsetSums.EightPoint140_137PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint140_137PackedAnchor1Part1 :
    ∀ j : Fin 120, 2475165 ≤ FourPointNumeric.octPackedCharge 140 137 20 packedOct140_137_1
      (2*((j.val : Int)+120)+0) := by decide +kernel

end NineSeparatedSubsetSums
