import NineSeparatedSubsetSums.EightPoint140_139PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint140_139PackedAnchor0Part2 :
    ∀ j : Fin 11, 2496630 ≤ FourPointNumeric.octPackedCharge 140 139 20 packedOct140_139_0
      (2*((j.val : Int)+240)+1) := by decide +kernel

end NineSeparatedSubsetSums
