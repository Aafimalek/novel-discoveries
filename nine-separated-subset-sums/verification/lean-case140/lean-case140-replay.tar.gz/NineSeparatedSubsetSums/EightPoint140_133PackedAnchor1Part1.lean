import NineSeparatedSubsetSums.EightPoint140_133PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint140_133PackedAnchor1Part1 :
    ∀ j : Fin 120, 2459090 ≤ FourPointNumeric.octPackedCharge 140 133 20 packedOct140_133_1
      (2*((j.val : Int)+120)+0) := by decide +kernel

end NineSeparatedSubsetSums
