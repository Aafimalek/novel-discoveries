import NineSeparatedSubsetSums.EightPoint140_137PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct140_137_1_budget :
    FourPointNumeric.packedBudget 20 packedOct140_137_1 270 = 92261128 := by decide +kernel

#print axioms packedOct140_137_1_budget

end NineSeparatedSubsetSums
