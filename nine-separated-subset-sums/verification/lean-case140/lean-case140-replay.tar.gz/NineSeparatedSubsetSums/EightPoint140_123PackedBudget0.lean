import NineSeparatedSubsetSums.EightPoint140_123PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct140_123_0_budget :
    FourPointNumeric.packedBudget 20 packedOct140_123_0 279 = 81713663 := by decide +kernel

#print axioms packedOct140_123_0_budget

end NineSeparatedSubsetSums
