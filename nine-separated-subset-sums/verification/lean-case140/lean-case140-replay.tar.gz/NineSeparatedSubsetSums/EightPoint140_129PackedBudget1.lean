import NineSeparatedSubsetSums.EightPoint140_129PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct140_129_1_budget :
    FourPointNumeric.packedBudget 20 packedOct140_129_1 446 = 87626862 := by decide +kernel

#print axioms packedOct140_129_1_budget

end NineSeparatedSubsetSums
