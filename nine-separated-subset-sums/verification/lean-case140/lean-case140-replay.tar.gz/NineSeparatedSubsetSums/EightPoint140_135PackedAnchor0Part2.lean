import NineSeparatedSubsetSums.EightPoint140_135PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint140_135PackedAnchor0Part2 :
    ∀ j : Fin 10, 2476053 ≤ FourPointNumeric.octPackedCharge 140 135 20 packedOct140_135_0
      (2*((j.val : Int)+240)+1) := by decide +kernel

end NineSeparatedSubsetSums
