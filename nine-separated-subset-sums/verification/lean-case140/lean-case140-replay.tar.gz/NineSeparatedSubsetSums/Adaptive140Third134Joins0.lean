import NineSeparatedSubsetSums.Adaptive140Third134State
import NineSeparatedSubsetSums.Adaptive140Third134Leaves8
import NineSeparatedSubsetSums.Adaptive140Third134Leaves5
import NineSeparatedSubsetSums.Adaptive140Third134Leaves7
import NineSeparatedSubsetSums.Adaptive140Third134Leaves0
import NineSeparatedSubsetSums.Adaptive140Third134Leaves3
import NineSeparatedSubsetSums.Adaptive140Third134Leaves4
import NineSeparatedSubsetSums.Adaptive140Third134Leaves2
import NineSeparatedSubsetSums.Adaptive140Third134Leaves6
import NineSeparatedSubsetSums.Adaptive140Third134Leaves1

namespace NineSeparatedSubsetSums

theorem adaptive140Third134Proof22 : runCachedNode 511 128648 Adaptive140Third134Node22 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 128648 Adaptive140Third134Node22 = [104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 119, 120, 121, 122, 123, 125, 127, 128, 129, 130, 131] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive140Third134Proof23
  · exact adaptive140Third134Proof24
  · exact adaptive140Third134Proof25
  · exact adaptive140Third134Proof26
  · exact adaptive140Third134Proof27
  · exact adaptive140Third134Proof28
  · exact adaptive140Third134Proof29
  · exact adaptive140Third134Proof30
  · exact adaptive140Third134Proof31
  · exact adaptive140Third134Proof32
  · exact adaptive140Third134Proof33
  · exact adaptive140Third134Proof34
  · exact adaptive140Third134Proof35
  · exact adaptive140Third134Proof36
  · exact adaptive140Third134Proof37
  · exact adaptive140Third134Proof38
  · exact adaptive140Third134Proof39
  · exact adaptive140Third134Proof40
  · exact adaptive140Third134Proof41
  · exact adaptive140Third134Proof42
  · exact adaptive140Third134Proof43
  · exact adaptive140Third134Proof44
  · exact adaptive140Third134Proof45
  · exact adaptive140Third134Proof46
  · exact adaptive140Third134Proof47

#print axioms adaptive140Third134Proof22

theorem adaptive140Third134Proof48 : runCachedNode 511 128648 Adaptive140Third134Node48 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 128648 Adaptive140Third134Node48 = [104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 120, 121, 122, 123, 124, 128, 129, 130, 131, 132] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive140Third134Proof49
  · exact adaptive140Third134Proof50
  · exact adaptive140Third134Proof51
  · exact adaptive140Third134Proof52
  · exact adaptive140Third134Proof53
  · exact adaptive140Third134Proof54
  · exact adaptive140Third134Proof55
  · exact adaptive140Third134Proof56
  · exact adaptive140Third134Proof57
  · exact adaptive140Third134Proof58
  · exact adaptive140Third134Proof59
  · exact adaptive140Third134Proof60
  · exact adaptive140Third134Proof61
  · exact adaptive140Third134Proof62
  · exact adaptive140Third134Proof63
  · exact adaptive140Third134Proof64
  · exact adaptive140Third134Proof65
  · exact adaptive140Third134Proof66
  · exact adaptive140Third134Proof67
  · exact adaptive140Third134Proof68
  · exact adaptive140Third134Proof69
  · exact adaptive140Third134Proof70
  · exact adaptive140Third134Proof71
  · exact adaptive140Third134Proof72
  · exact adaptive140Third134Proof73

#print axioms adaptive140Third134Proof48

theorem adaptive140Third134Proof0 : runCachedNode 511 128648 Adaptive140Third134Node0 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 128648 Adaptive140Third134Node0 = [110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 127, 128, 129, 130, 131, 132, 133] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive140Third134Proof1
  · exact adaptive140Third134Proof2
  · exact adaptive140Third134Proof3
  · exact adaptive140Third134Proof4
  · exact adaptive140Third134Proof5
  · exact adaptive140Third134Proof6
  · exact adaptive140Third134Proof7
  · exact adaptive140Third134Proof8
  · exact adaptive140Third134Proof9
  · exact adaptive140Third134Proof10
  · exact adaptive140Third134Proof11
  · exact adaptive140Third134Proof12
  · exact adaptive140Third134Proof13
  · exact adaptive140Third134Proof14
  · exact adaptive140Third134Proof15
  · exact adaptive140Third134Proof16
  · exact adaptive140Third134Proof17
  · exact adaptive140Third134Proof18
  · exact adaptive140Third134Proof19
  · exact adaptive140Third134Proof20
  · exact adaptive140Third134Proof21
  · exact adaptive140Third134Proof22
  · exact adaptive140Third134Proof48

#print axioms adaptive140Third134Proof0

end NineSeparatedSubsetSums
