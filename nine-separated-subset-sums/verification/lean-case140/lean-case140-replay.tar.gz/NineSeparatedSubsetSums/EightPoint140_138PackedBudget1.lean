import NineSeparatedSubsetSums.EightPoint140_138PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct140_138_1_budget :
    FourPointNumeric.packedBudget 20 packedOct140_138_1 274 = 93473934 := by decide +kernel

#print axioms packedOct140_138_1_budget

end NineSeparatedSubsetSums
