import NineSeparatedSubsetSums.Adaptive140Third139State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third139Proof218 : runCachedNode 511 129561 Adaptive140Third139Node218 = false := by
  decide +kernel

#print axioms adaptive140Third139Proof218

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third139Proof259 : runCachedNode 511 129561 Adaptive140Third139Node259 = false := by
  decide +kernel

#print axioms adaptive140Third139Proof259

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive140Third139Proof5 : runCachedNode 511 129561 Adaptive140Third139Node5 = false := by
  decide +kernel

#print axioms adaptive140Third139Proof5

end NineSeparatedSubsetSums
