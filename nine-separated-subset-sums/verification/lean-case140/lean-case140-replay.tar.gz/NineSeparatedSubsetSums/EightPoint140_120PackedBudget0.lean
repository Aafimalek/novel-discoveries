import NineSeparatedSubsetSums.EightPoint140_120PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct140_120_0_budget :
    FourPointNumeric.packedBudget 20 packedOct140_120_0 361 = 85759847 := by decide +kernel

#print axioms packedOct140_120_0_budget

end NineSeparatedSubsetSums
