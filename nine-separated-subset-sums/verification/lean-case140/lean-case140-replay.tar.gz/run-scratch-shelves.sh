#!/usr/bin/env bash
set -eu
cd "$(dirname "$0")"
source env-scratch.sh
# Share the same lock as the original workspace, including for audits.
exec 9>/tmp/nine-149-next/.adaptive-sequential-124-127.lock
flock -n 9 || { echo 'Sequential proof worker already active'; exit 75; }
first=${1:?first shelf} last=${2:?last shelf}
[[ "$first" =~ ^(13[8-9]|14[0-7])$ && "$last" =~ ^(13[8-9]|14[0-7])$ && $first -le $last ]] || exit 64
for ((a=first; a<=last; ++a)); do
  free=$(df -Pm "$PWD" | awk 'NR==2 {print $4}')
  if ((free < 600)); then echo "STOP SHELF $a: scratch free ${free}MiB <600MiB"; exit 74; fi
  m="adaptive-$a-full.json"; log="adaptive-$a-full-run.log"
  if [[ -e "$log" ]]; then cp -p "$log" "$log.prior-$(date +%s)"; fi
  echo "$(date -Iseconds) START SHELF $a on scratch (${free}MiB free)"
  if [[ ! -e "$m" ]]; then
    python make-adaptive-shelves.py "$a" --cost 1600 --oct-cost 3000 --out "$m"
  fi
  rc=0
  timeout --kill-after=10 2400 python -u run-adaptive-queue-guarded.py "$m" \
      --lean "$LEAN" --jobs 1 --seconds 125 --memory 2850 --min-free-mib 400 >"$log" 2>&1 || rc=$?
  echo "$(date -Iseconds) EXIT SHELF $a $rc"
  tail -n 4 "$log"
  if ((rc != 0)); then exit "$rc"; fi
  [[ "$(tail -n 1 "$log")" == "VERIFIED SHELF $a: AdaptiveShelf$a" ]] || exit 1
  cat >"AuditShelf$a.lean" <<AUDIT
import NineSeparatedSubsetSums.AdaptiveShelf$a
example : NineSeparatedSubsetSums.NoDescendingTail $a :=
  NineSeparatedSubsetSums.adaptiveShelf${a}_no_descending_tail
#print axioms NineSeparatedSubsetSums.adaptiveShelf${a}_no_descending_tail
AUDIT
  timeout --kill-after=5 125 "$LEAN" -j1 -M2850 "AuditShelf$a.lean" >"AuditShelf$a.log" 2>&1
  python stage-verified-adaptive.py "$a"
  out="$NINE_STAGE_ROOT/nine149-verified-through$a"
  cp run-adaptive-queue-guarded.py run-scratch-shelves.sh env-scratch.sh "$out/"
  (cd "$out"; sha256sum run-adaptive-queue-guarded.py run-scratch-shelves.sh env-scratch.sh >> SHA256SUMS;
    sha256sum -c SHA256SUMS >"$NINE_STAGE_ROOT/stage-$a-integrity.log")
  echo "$(date -Iseconds) ARCHIVED AND AUDITED SHELF $a ($out)"
done
