import NineSeparatedSubsetSums.Adaptive138Third136State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third136Proof18 : runCachedNode 511 128623 Adaptive138Third136Node18 = false := by
  decide +kernel

#print axioms adaptive138Third136Proof18

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third136Proof45 : runCachedNode 511 128623 Adaptive138Third136Node45 = false := by
  decide +kernel

#print axioms adaptive138Third136Proof45

end NineSeparatedSubsetSums
