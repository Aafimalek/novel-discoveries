import NineSeparatedSubsetSums.Adaptive138Third137State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third137Proof97 : runCachedNode 511 128810 Adaptive138Third137Node97 = false := by
  decide +kernel

#print axioms adaptive138Third137Proof97

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third137Proof128 : runCachedNode 511 128810 Adaptive138Third137Node128 = false := by
  decide +kernel

#print axioms adaptive138Third137Proof128

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third137Proof188 : runCachedNode 511 128810 Adaptive138Third137Node188 = false := by
  decide +kernel

#print axioms adaptive138Third137Proof188

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third137Proof9 : runCachedNode 511 128810 Adaptive138Third137Node9 = false := by
  decide +kernel

#print axioms adaptive138Third137Proof9

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third137Proof101 : runCachedNode 511 128810 Adaptive138Third137Node101 = false := by
  decide +kernel

#print axioms adaptive138Third137Proof101

end NineSeparatedSubsetSums
