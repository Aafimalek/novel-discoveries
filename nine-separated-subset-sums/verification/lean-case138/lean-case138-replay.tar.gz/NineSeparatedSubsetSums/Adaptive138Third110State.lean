import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive138Third110Node0 : CachedSearchNode :=
  ⟨4, 109, computeCenteredMask [148,138,110], 396, 53048⟩

end NineSeparatedSubsetSums
