import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive138Third125Node0 : CachedSearchNode :=
  ⟨4, 124, computeCenteredMask [148,138,125], 411, 56573⟩

end NineSeparatedSubsetSums
