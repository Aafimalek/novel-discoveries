import NineSeparatedSubsetSums.Adaptive138Third115State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third115Proof10 : runCachedNode 511 111079 Adaptive138Third115Node10 = false := by
  decide +kernel

#print axioms adaptive138Third115Proof10

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third115Proof8 : runCachedNode 511 111079 Adaptive138Third115Node8 = false := by
  decide +kernel

#print axioms adaptive138Third115Proof8

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third115Proof7 : runCachedNode 511 111079 Adaptive138Third115Node7 = false := by
  decide +kernel

#print axioms adaptive138Third115Proof7

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third115Proof6 : runCachedNode 511 111079 Adaptive138Third115Node6 = false := by
  decide +kernel

#print axioms adaptive138Third115Proof6

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third115Proof4 : runCachedNode 511 111079 Adaptive138Third115Node4 = false := by
  decide +kernel

#print axioms adaptive138Third115Proof4

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third115Proof3 : runCachedNode 511 111079 Adaptive138Third115Node3 = false := by
  decide +kernel

#print axioms adaptive138Third115Proof3

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third115Proof1 : runCachedNode 511 111079 Adaptive138Third115Node1 = false := by
  decide +kernel

#print axioms adaptive138Third115Proof1

end NineSeparatedSubsetSums
