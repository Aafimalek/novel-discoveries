import NineSeparatedSubsetSums.Adaptive138Third134State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third134Proof36 : runCachedNode 511 128232 Adaptive138Third134Node36 = false := by
  decide +kernel

#print axioms adaptive138Third134Proof36

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third134Proof37 : runCachedNode 511 128232 Adaptive138Third134Node37 = false := by
  decide +kernel

#print axioms adaptive138Third134Proof37

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third134Proof65 : runCachedNode 511 128232 Adaptive138Third134Node65 = false := by
  decide +kernel

#print axioms adaptive138Third134Proof65

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third134Proof89 : runCachedNode 511 128232 Adaptive138Third134Node89 = false := by
  decide +kernel

#print axioms adaptive138Third134Proof89

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third134Proof10 : runCachedNode 511 128232 Adaptive138Third134Node10 = false := by
  decide +kernel

#print axioms adaptive138Third134Proof10

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third134Proof87 : runCachedNode 511 128232 Adaptive138Third134Node87 = false := by
  decide +kernel

#print axioms adaptive138Third134Proof87

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third134Proof64 : runCachedNode 511 128232 Adaptive138Third134Node64 = false := by
  decide +kernel

#print axioms adaptive138Third134Proof64

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third134Proof88 : runCachedNode 511 128232 Adaptive138Third134Node88 = false := by
  decide +kernel

#print axioms adaptive138Third134Proof88

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third134Proof35 : runCachedNode 511 128232 Adaptive138Third134Node35 = false := by
  decide +kernel

#print axioms adaptive138Third134Proof35

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third134Proof84 : runCachedNode 511 128232 Adaptive138Third134Node84 = false := by
  decide +kernel

#print axioms adaptive138Third134Proof84

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third134Proof86 : runCachedNode 511 128232 Adaptive138Third134Node86 = false := by
  decide +kernel

#print axioms adaptive138Third134Proof86

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third134Proof8 : runCachedNode 511 128232 Adaptive138Third134Node8 = false := by
  decide +kernel

#print axioms adaptive138Third134Proof8

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third134Proof59 : runCachedNode 511 128232 Adaptive138Third134Node59 = false := by
  decide +kernel

#print axioms adaptive138Third134Proof59

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third134Proof9 : runCachedNode 511 128232 Adaptive138Third134Node9 = false := by
  decide +kernel

#print axioms adaptive138Third134Proof9

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third134Proof33 : runCachedNode 511 128232 Adaptive138Third134Node33 = false := by
  decide +kernel

#print axioms adaptive138Third134Proof33

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third134Proof62 : runCachedNode 511 128232 Adaptive138Third134Node62 = false := by
  decide +kernel

#print axioms adaptive138Third134Proof62

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third134Proof34 : runCachedNode 511 128232 Adaptive138Third134Node34 = false := by
  decide +kernel

#print axioms adaptive138Third134Proof34

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third134Proof61 : runCachedNode 511 128232 Adaptive138Third134Node61 = false := by
  decide +kernel

#print axioms adaptive138Third134Proof61

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third134Proof6 : runCachedNode 511 128232 Adaptive138Third134Node6 = false := by
  decide +kernel

#print axioms adaptive138Third134Proof6

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third134Proof83 : runCachedNode 511 128232 Adaptive138Third134Node83 = false := by
  decide +kernel

#print axioms adaptive138Third134Proof83

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third134Proof85 : runCachedNode 511 128232 Adaptive138Third134Node85 = false := by
  decide +kernel

#print axioms adaptive138Third134Proof85

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third134Proof32 : runCachedNode 511 128232 Adaptive138Third134Node32 = false := by
  decide +kernel

#print axioms adaptive138Third134Proof32

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third134Proof31 : runCachedNode 511 128232 Adaptive138Third134Node31 = false := by
  decide +kernel

#print axioms adaptive138Third134Proof31

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third134Proof60 : runCachedNode 511 128232 Adaptive138Third134Node60 = false := by
  decide +kernel

#print axioms adaptive138Third134Proof60

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third134Proof30 : runCachedNode 511 128232 Adaptive138Third134Node30 = false := by
  decide +kernel

#print axioms adaptive138Third134Proof30

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third134Proof5 : runCachedNode 511 128232 Adaptive138Third134Node5 = false := by
  decide +kernel

#print axioms adaptive138Third134Proof5

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third134Proof28 : runCachedNode 511 128232 Adaptive138Third134Node28 = false := by
  decide +kernel

#print axioms adaptive138Third134Proof28

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third134Proof25 : runCachedNode 511 128232 Adaptive138Third134Node25 = false := by
  decide +kernel

#print axioms adaptive138Third134Proof25

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third134Proof72 : runCachedNode 511 128232 Adaptive138Third134Node72 = false := by
  decide +kernel

#print axioms adaptive138Third134Proof72

end NineSeparatedSubsetSums
