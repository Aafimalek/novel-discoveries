import NineSeparatedSubsetSums.EightPoint138_119PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint138_119PackedAnchor0Part1 :
    ∀ j : Fin 120, 2293939 ≤ FourPointNumeric.octPackedCharge 138 119 20 packedOct138_119_0
      (2*((j.val : Int)+120)+1) := by decide +kernel

end NineSeparatedSubsetSums
