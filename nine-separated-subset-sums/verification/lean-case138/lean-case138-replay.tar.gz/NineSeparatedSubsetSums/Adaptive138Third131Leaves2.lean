import NineSeparatedSubsetSums.Adaptive138Third131State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third131Proof18 : runCachedNode 511 127792 Adaptive138Third131Node18 = false := by
  decide +kernel

#print axioms adaptive138Third131Proof18

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third131Proof14 : runCachedNode 511 127792 Adaptive138Third131Node14 = false := by
  decide +kernel

#print axioms adaptive138Third131Proof14

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third131Proof13 : runCachedNode 511 127792 Adaptive138Third131Node13 = false := by
  decide +kernel

#print axioms adaptive138Third131Proof13

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third131Proof12 : runCachedNode 511 127792 Adaptive138Third131Node12 = false := by
  decide +kernel

#print axioms adaptive138Third131Proof12

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third131Proof10 : runCachedNode 511 127792 Adaptive138Third131Node10 = false := by
  decide +kernel

#print axioms adaptive138Third131Proof10

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third131Proof3 : runCachedNode 511 127792 Adaptive138Third131Node3 = false := by
  decide +kernel

#print axioms adaptive138Third131Proof3

end NineSeparatedSubsetSums
