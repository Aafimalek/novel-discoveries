import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive138Third111Node0 : CachedSearchNode :=
  ⟨4, 110, computeCenteredMask [148,138,111], 397, 53269⟩

end NineSeparatedSubsetSums
