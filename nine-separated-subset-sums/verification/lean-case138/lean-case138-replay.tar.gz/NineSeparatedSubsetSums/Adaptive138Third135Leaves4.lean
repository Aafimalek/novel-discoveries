import NineSeparatedSubsetSums.Adaptive138Third135State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third135Proof98 : runCachedNode 511 128437 Adaptive138Third135Node98 = false := by
  decide +kernel

#print axioms adaptive138Third135Proof98

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third135Proof44 : runCachedNode 511 128437 Adaptive138Third135Node44 = false := by
  decide +kernel

#print axioms adaptive138Third135Proof44

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third135Proof45 : runCachedNode 511 128437 Adaptive138Third135Node45 = false := by
  decide +kernel

#print axioms adaptive138Third135Proof45

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third135Proof55 : runCachedNode 511 128437 Adaptive138Third135Node55 = false := by
  decide +kernel

#print axioms adaptive138Third135Proof55

end NineSeparatedSubsetSums
