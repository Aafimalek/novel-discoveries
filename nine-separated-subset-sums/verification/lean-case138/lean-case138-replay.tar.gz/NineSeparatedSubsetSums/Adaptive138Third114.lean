import NineSeparatedSubsetSums.Adaptive138Third114Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint138Checked

namespace NineSeparatedSubsetSums


theorem adaptive138Third114 : NoDescendingTailAfterThird 138 114 :=
  noDescendingThirdTail_of_cached 138 114 111079 (fun t ht nd => max148_second138_fourPoint_moment_bound (114::t) (by simp [ht]) nd) adaptive138Third114Proof0

#print axioms adaptive138Third114

end NineSeparatedSubsetSums
