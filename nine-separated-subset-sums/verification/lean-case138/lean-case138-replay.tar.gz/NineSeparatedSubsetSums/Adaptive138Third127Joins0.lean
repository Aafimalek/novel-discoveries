import NineSeparatedSubsetSums.Adaptive138Third127State
import NineSeparatedSubsetSums.Adaptive138Third127Leaves1
import NineSeparatedSubsetSums.Adaptive138Third127Leaves0

namespace NineSeparatedSubsetSums

theorem adaptive138Third127Proof0 : runCachedNode 511 126958 Adaptive138Third127Node0 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 126958 Adaptive138Third127Node0 = [111, 112, 113, 114, 115, 116, 118, 119, 120, 121, 122, 123, 124, 125, 126] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive138Third127Proof1
  · exact adaptive138Third127Proof2
  · exact adaptive138Third127Proof3
  · exact adaptive138Third127Proof4
  · exact adaptive138Third127Proof5
  · exact adaptive138Third127Proof6
  · exact adaptive138Third127Proof7
  · exact adaptive138Third127Proof8
  · exact adaptive138Third127Proof9
  · exact adaptive138Third127Proof10
  · exact adaptive138Third127Proof11
  · exact adaptive138Third127Proof12
  · exact adaptive138Third127Proof13
  · exact adaptive138Third127Proof14
  · exact adaptive138Third127Proof15

#print axioms adaptive138Third127Proof0

end NineSeparatedSubsetSums
