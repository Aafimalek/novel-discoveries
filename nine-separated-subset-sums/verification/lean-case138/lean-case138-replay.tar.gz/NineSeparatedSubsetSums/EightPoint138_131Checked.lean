import NineSeparatedSubsetSums.EightPointPackedGeometry
import NineSeparatedSubsetSums.EightPoint138_131PackedBudget0
import NineSeparatedSubsetSums.EightPoint138_131PackedAnchor0Part0
import NineSeparatedSubsetSums.EightPoint138_131PackedAnchor0Part1
import NineSeparatedSubsetSums.EightPoint138_131PackedAnchor0Part2
import NineSeparatedSubsetSums.EightPoint138_131PackedBudget1
import NineSeparatedSubsetSums.EightPoint138_131PackedAnchor1Part0
import NineSeparatedSubsetSums.EightPoint138_131PackedAnchor1Part1
import NineSeparatedSubsetSums.EightPoint138_131PackedAnchor1Part2

namespace NineSeparatedSubsetSums

private theorem packedOct138_131Anchor0 :
  ∀ j : Fin 495, ((j.val : Int)+138+131)%2=0 →
    2423480 ≤ FourPointNumeric.octPackedCharge 138 131 20 packedOct138_131_0 (j.val : Int) := by
  intro j hj
  let k := (j.val-1)/2
  have hk : k < 247 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+1 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint138_131PackedAnchor0Part0 z
    rwa [he,hrep] at ht
  by_cases h1 : k < 240
  · let z : Fin 120 := ⟨k-120, by omega⟩
    have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
    have ht := eightPoint138_131PackedAnchor0Part1 z
    rwa [he,hrep] at ht
  let z : Fin 7 := ⟨k-240, by omega⟩
  have he : (z.val : Int)+240 = k := by dsimp [z] <;> omega
  have ht := eightPoint138_131PackedAnchor0Part2 z
  rwa [he,hrep] at ht

private theorem packedOct138_131Anchor1 :
  ∀ j : Fin 495, ((j.val : Int)+138+131)%2=1 →
    2423915 ≤ FourPointNumeric.octPackedCharge 138 131 20 packedOct138_131_1 (j.val : Int) := by
  intro j hj
  let k := (j.val-0)/2
  have hk : k < 248 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+0 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint138_131PackedAnchor1Part0 z
    rwa [he,hrep] at ht
  by_cases h1 : k < 240
  · let z : Fin 120 := ⟨k-120, by omega⟩
    have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
    have ht := eightPoint138_131PackedAnchor1Part1 z
    rwa [he,hrep] at ht
  let z : Fin 8 := ⟨k-240, by omega⟩
  have he : (z.val : Int)+240 = k := by dsimp [z] <;> omega
  have ht := eightPoint138_131PackedAnchor1Part2 z
  rwa [he,hrep] at ht

def packedOctCertificate138_131_0 : EightPointCertificate 138 131 0 127792 :=
  eightPointCertificateOfPacked 138 131 0 127792 2423480 20 packedOct138_131_0 453 495
    (by decide +kernel) (by decide) packedOct138_131Anchor0
    (by rw [packedOct138_131_0_budget]; decide)

def packedOctCertificate138_131_1 : EightPointCertificate 138 131 1 127792 :=
  eightPointCertificateOfPacked 138 131 1 127792 2423915 20 packedOct138_131_1 454 495
    (by decide +kernel) (by decide) packedOct138_131Anchor1
    (by rw [packedOct138_131_1_budget]; decide)

theorem max148_second138_third131_eightPoint_moment_bound (tail : List ℕ) (len : tail.length=6)
    (distinct : (natSubsetSums (148::138::131::tail)).Nodup) :
    127792 ≤ ((148::138::131::tail).map (· ^ 2)).sum := by
  apply eightPointNatMomentLower 138 131 127792 tail len distinct
  intro p hp
  by_cases h : p=0
  · subst p
    exact packedOctCertificate138_131_0
  · have he : p=1 := hp.resolve_left h
    subst p
    exact packedOctCertificate138_131_1

#print axioms max148_second138_third131_eightPoint_moment_bound

end NineSeparatedSubsetSums
