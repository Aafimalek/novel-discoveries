import NineSeparatedSubsetSums.EightPointPackedGeometry
import NineSeparatedSubsetSums.EightPoint138_135PackedBudget0
import NineSeparatedSubsetSums.EightPoint138_135PackedAnchor0Part0
import NineSeparatedSubsetSums.EightPoint138_135PackedAnchor0Part1
import NineSeparatedSubsetSums.EightPoint138_135PackedAnchor0Part2
import NineSeparatedSubsetSums.EightPoint138_135PackedBudget1
import NineSeparatedSubsetSums.EightPoint138_135PackedAnchor1Part0
import NineSeparatedSubsetSums.EightPoint138_135PackedAnchor1Part1
import NineSeparatedSubsetSums.EightPoint138_135PackedAnchor1Part2

namespace NineSeparatedSubsetSums

private theorem packedOct138_135Anchor0 :
  ∀ j : Fin 499, ((j.val : Int)+138+135)%2=0 →
    2461356 ≤ FourPointNumeric.octPackedCharge 138 135 20 packedOct138_135_0 (j.val : Int) := by
  intro j hj
  let k := (j.val-1)/2
  have hk : k < 249 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+1 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint138_135PackedAnchor0Part0 z
    rwa [he,hrep] at ht
  by_cases h1 : k < 240
  · let z : Fin 120 := ⟨k-120, by omega⟩
    have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
    have ht := eightPoint138_135PackedAnchor0Part1 z
    rwa [he,hrep] at ht
  let z : Fin 9 := ⟨k-240, by omega⟩
  have he : (z.val : Int)+240 = k := by dsimp [z] <;> omega
  have ht := eightPoint138_135PackedAnchor0Part2 z
  rwa [he,hrep] at ht

private theorem packedOct138_135Anchor1 :
  ∀ j : Fin 499, ((j.val : Int)+138+135)%2=1 →
    2463104 ≤ FourPointNumeric.octPackedCharge 138 135 20 packedOct138_135_1 (j.val : Int) := by
  intro j hj
  let k := (j.val-0)/2
  have hk : k < 250 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+0 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint138_135PackedAnchor1Part0 z
    rwa [he,hrep] at ht
  by_cases h1 : k < 240
  · let z : Fin 120 := ⟨k-120, by omega⟩
    have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
    have ht := eightPoint138_135PackedAnchor1Part1 z
    rwa [he,hrep] at ht
  let z : Fin 10 := ⟨k-240, by omega⟩
  have he : (z.val : Int)+240 = k := by dsimp [z] <;> omega
  have ht := eightPoint138_135PackedAnchor1Part2 z
  rwa [he,hrep] at ht

def packedOctCertificate138_135_0 : EightPointCertificate 138 135 0 128437 :=
  eightPointCertificateOfPacked 138 135 0 128437 2461356 20 packedOct138_135_0 473 499
    (by decide +kernel) (by decide) packedOct138_135Anchor0
    (by rw [packedOct138_135_0_budget]; decide)

def packedOctCertificate138_135_1 : EightPointCertificate 138 135 1 128437 :=
  eightPointCertificateOfPacked 138 135 1 128437 2463104 20 packedOct138_135_1 470 499
    (by decide +kernel) (by decide) packedOct138_135Anchor1
    (by rw [packedOct138_135_1_budget]; decide)

theorem max148_second138_third135_eightPoint_moment_bound (tail : List ℕ) (len : tail.length=6)
    (distinct : (natSubsetSums (148::138::135::tail)).Nodup) :
    128437 ≤ ((148::138::135::tail).map (· ^ 2)).sum := by
  apply eightPointNatMomentLower 138 135 128437 tail len distinct
  intro p hp
  by_cases h : p=0
  · subst p
    exact packedOctCertificate138_135_0
  · have he : p=1 := hp.resolve_left h
    subst p
    exact packedOctCertificate138_135_1

#print axioms max148_second138_third135_eightPoint_moment_bound

end NineSeparatedSubsetSums
