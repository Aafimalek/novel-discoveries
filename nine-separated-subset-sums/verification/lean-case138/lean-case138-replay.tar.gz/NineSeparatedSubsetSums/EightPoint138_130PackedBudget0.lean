import NineSeparatedSubsetSums.EightPoint138_130PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct138_130_0_budget :
    FourPointNumeric.packedBudget 20 packedOct138_130_0 453 = 88372054 := by decide +kernel

#print axioms packedOct138_130_0_budget

end NineSeparatedSubsetSums
