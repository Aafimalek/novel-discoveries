import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive138Third124Node0 : CachedSearchNode :=
  ⟨4, 123, computeCenteredMask [148,138,124], 410, 56324⟩

end NineSeparatedSubsetSums
