import NineSeparatedSubsetSums.Adaptive138Third137State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third137Proof99 : runCachedNode 511 128810 Adaptive138Third137Node99 = false := by
  decide +kernel

#print axioms adaptive138Third137Proof99

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third137Proof19 : runCachedNode 511 128810 Adaptive138Third137Node19 = false := by
  decide +kernel

#print axioms adaptive138Third137Proof19

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third137Proof44 : runCachedNode 511 128810 Adaptive138Third137Node44 = false := by
  decide +kernel

#print axioms adaptive138Third137Proof44

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third137Proof147 : runCachedNode 511 128810 Adaptive138Third137Node147 = false := by
  decide +kernel

#print axioms adaptive138Third137Proof147

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third137Proof102 : runCachedNode 511 128810 Adaptive138Third137Node102 = false := by
  decide +kernel

#print axioms adaptive138Third137Proof102

end NineSeparatedSubsetSums
