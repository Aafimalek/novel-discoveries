import NineSeparatedSubsetSums.Adaptive138Third137State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third137Proof21 : runCachedNode 511 128810 Adaptive138Third137Node21 = false := by
  decide +kernel

#print axioms adaptive138Third137Proof21

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third137Proof153 : runCachedNode 511 128810 Adaptive138Third137Node153 = false := by
  decide +kernel

#print axioms adaptive138Third137Proof153

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third137Proof84 : runCachedNode 511 128810 Adaptive138Third137Node84 = false := by
  decide +kernel

#print axioms adaptive138Third137Proof84

end NineSeparatedSubsetSums
