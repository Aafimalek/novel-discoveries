import NineSeparatedSubsetSums.EightPoint138_135PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct138_135_1_budget :
    FourPointNumeric.packedBudget 20 packedOct138_135_1 470 = 91879210 := by decide +kernel

#print axioms packedOct138_135_1_budget

end NineSeparatedSubsetSums
