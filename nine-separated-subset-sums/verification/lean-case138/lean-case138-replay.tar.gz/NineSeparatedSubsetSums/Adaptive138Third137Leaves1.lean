import NineSeparatedSubsetSums.Adaptive138Third137State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third137Proof18 : runCachedNode 511 128810 Adaptive138Third137Node18 = false := by
  decide +kernel

#print axioms adaptive138Third137Proof18

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third137Proof46 : runCachedNode 511 128810 Adaptive138Third137Node46 = false := by
  decide +kernel

#print axioms adaptive138Third137Proof46

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third137Proof90 : runCachedNode 511 128810 Adaptive138Third137Node90 = false := by
  decide +kernel

#print axioms adaptive138Third137Proof90

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third137Proof1 : runCachedNode 511 128810 Adaptive138Third137Node1 = false := by
  decide +kernel

#print axioms adaptive138Third137Proof1

end NineSeparatedSubsetSums
