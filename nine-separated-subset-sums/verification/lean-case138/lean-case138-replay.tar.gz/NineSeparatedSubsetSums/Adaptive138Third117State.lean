import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive138Third117Node0 : CachedSearchNode :=
  ⟨4, 116, computeCenteredMask [148,138,117], 403, 54637⟩

end NineSeparatedSubsetSums
