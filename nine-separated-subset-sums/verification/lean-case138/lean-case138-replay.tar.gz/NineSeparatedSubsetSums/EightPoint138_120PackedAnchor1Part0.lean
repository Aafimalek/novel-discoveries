import NineSeparatedSubsetSums.EightPoint138_120PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint138_120PackedAnchor1Part0 :
    ∀ j : Fin 120, 2320849 ≤ FourPointNumeric.octPackedCharge 138 120 20 packedOct138_120_1
      (2*((j.val : Int)+0)+1) := by decide +kernel

end NineSeparatedSubsetSums
