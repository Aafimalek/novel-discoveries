import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive138Third123Node0 : CachedSearchNode :=
  ⟨4, 122, computeCenteredMask [148,138,123], 409, 56077⟩

end NineSeparatedSubsetSums
