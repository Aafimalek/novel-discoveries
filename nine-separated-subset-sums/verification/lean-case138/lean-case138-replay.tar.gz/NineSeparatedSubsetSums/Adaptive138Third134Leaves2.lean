import NineSeparatedSubsetSums.Adaptive138Third134State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third134Proof19 : runCachedNode 511 128232 Adaptive138Third134Node19 = false := by
  decide +kernel

#print axioms adaptive138Third134Proof19

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third134Proof93 : runCachedNode 511 128232 Adaptive138Third134Node93 = false := by
  decide +kernel

#print axioms adaptive138Third134Proof93

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third134Proof63 : runCachedNode 511 128232 Adaptive138Third134Node63 = false := by
  decide +kernel

#print axioms adaptive138Third134Proof63

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third134Proof2 : runCachedNode 511 128232 Adaptive138Third134Node2 = false := by
  decide +kernel

#print axioms adaptive138Third134Proof2

end NineSeparatedSubsetSums
