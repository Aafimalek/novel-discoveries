import NineSeparatedSubsetSums.Adaptive138Third127State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third127Proof15 : runCachedNode 511 126958 Adaptive138Third127Node15 = false := by
  decide +kernel

#print axioms adaptive138Third127Proof15

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third127Proof14 : runCachedNode 511 126958 Adaptive138Third127Node14 = false := by
  decide +kernel

#print axioms adaptive138Third127Proof14

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third127Proof13 : runCachedNode 511 126958 Adaptive138Third127Node13 = false := by
  decide +kernel

#print axioms adaptive138Third127Proof13

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third127Proof12 : runCachedNode 511 126958 Adaptive138Third127Node12 = false := by
  decide +kernel

#print axioms adaptive138Third127Proof12

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third127Proof11 : runCachedNode 511 126958 Adaptive138Third127Node11 = false := by
  decide +kernel

#print axioms adaptive138Third127Proof11

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third127Proof10 : runCachedNode 511 126958 Adaptive138Third127Node10 = false := by
  decide +kernel

#print axioms adaptive138Third127Proof10

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third127Proof9 : runCachedNode 511 126958 Adaptive138Third127Node9 = false := by
  decide +kernel

#print axioms adaptive138Third127Proof9

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third127Proof8 : runCachedNode 511 126958 Adaptive138Third127Node8 = false := by
  decide +kernel

#print axioms adaptive138Third127Proof8

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third127Proof6 : runCachedNode 511 126958 Adaptive138Third127Node6 = false := by
  decide +kernel

#print axioms adaptive138Third127Proof6

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third127Proof2 : runCachedNode 511 126958 Adaptive138Third127Node2 = false := by
  decide +kernel

#print axioms adaptive138Third127Proof2

end NineSeparatedSubsetSums
