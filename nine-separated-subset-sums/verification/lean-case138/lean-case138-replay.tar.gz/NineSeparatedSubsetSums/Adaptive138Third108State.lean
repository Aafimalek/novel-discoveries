import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive138Third108Node0 : CachedSearchNode :=
  ⟨4, 107, computeCenteredMask [148,138,108], 394, 52612⟩

end NineSeparatedSubsetSums
