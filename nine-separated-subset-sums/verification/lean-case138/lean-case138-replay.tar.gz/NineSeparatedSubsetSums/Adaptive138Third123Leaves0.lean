import NineSeparatedSubsetSums.Adaptive138Third123State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third123Proof0 : runCachedNode 511 125816 Adaptive138Third123Node0 = false := by
  decide +kernel

#print axioms adaptive138Third123Proof0

end NineSeparatedSubsetSums
