import NineSeparatedSubsetSums.EightPoint138_128PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct138_128_0_budget :
    FourPointNumeric.packedBudget 20 packedOct138_128_0 267 = 85781634 := by decide +kernel

#print axioms packedOct138_128_0_budget

end NineSeparatedSubsetSums
