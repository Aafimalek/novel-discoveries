import NineSeparatedSubsetSums.EightPoint138_124PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint138_124PackedAnchor1Part0 :
    ∀ j : Fin 120, 2295374 ≤ FourPointNumeric.octPackedCharge 138 124 20 packedOct138_124_1
      (2*((j.val : Int)+0)+1) := by decide +kernel

end NineSeparatedSubsetSums
