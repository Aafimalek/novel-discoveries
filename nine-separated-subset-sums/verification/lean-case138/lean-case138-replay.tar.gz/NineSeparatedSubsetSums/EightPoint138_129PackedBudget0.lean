import NineSeparatedSubsetSums.EightPoint138_129PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct138_129_0_budget :
    FourPointNumeric.packedBudget 20 packedOct138_129_0 457 = 86700430 := by decide +kernel

#print axioms packedOct138_129_0_budget

end NineSeparatedSubsetSums
