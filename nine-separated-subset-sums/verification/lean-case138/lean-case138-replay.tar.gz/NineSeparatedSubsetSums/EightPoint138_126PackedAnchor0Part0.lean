import NineSeparatedSubsetSums.EightPoint138_126PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint138_126PackedAnchor0Part0 :
    ∀ j : Fin 120, 2350486 ≤ FourPointNumeric.octPackedCharge 138 126 20 packedOct138_126_0
      (2*((j.val : Int)+0)+0) := by decide +kernel

end NineSeparatedSubsetSums
