import NineSeparatedSubsetSums.EightPoint138_124PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct138_124_1_budget :
    FourPointNumeric.packedBudget 20 packedOct138_124_1 480 = 82308130 := by decide +kernel

#print axioms packedOct138_124_1_budget

end NineSeparatedSubsetSums
