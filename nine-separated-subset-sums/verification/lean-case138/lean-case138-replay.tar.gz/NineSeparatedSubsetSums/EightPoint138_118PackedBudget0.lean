import NineSeparatedSubsetSums.EightPoint138_118PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct138_118_0_budget :
    FourPointNumeric.packedBudget 20 packedOct138_118_0 271 = 81778229 := by decide +kernel

#print axioms packedOct138_118_0_budget

end NineSeparatedSubsetSums
