import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive138Third106Node0 : CachedSearchNode :=
  ⟨4, 105, computeCenteredMask [148,138,106], 392, 52184⟩

end NineSeparatedSubsetSums
