import NineSeparatedSubsetSums.EightPoint138_134PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct138_134_0_budget :
    FourPointNumeric.packedBudget 20 packedOct138_134_0 271 = 89556080 := by decide +kernel

#print axioms packedOct138_134_0_budget

end NineSeparatedSubsetSums
