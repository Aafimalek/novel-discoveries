import NineSeparatedSubsetSums.Adaptive138Third135State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third135Proof18 : runCachedNode 511 128437 Adaptive138Third135Node18 = false := by
  decide +kernel

#print axioms adaptive138Third135Proof18

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third135Proof17 : runCachedNode 511 128437 Adaptive138Third135Node17 = false := by
  decide +kernel

#print axioms adaptive138Third135Proof17

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third135Proof9 : runCachedNode 511 128437 Adaptive138Third135Node9 = false := by
  decide +kernel

#print axioms adaptive138Third135Proof9

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third135Proof48 : runCachedNode 511 128437 Adaptive138Third135Node48 = false := by
  decide +kernel

#print axioms adaptive138Third135Proof48

end NineSeparatedSubsetSums
