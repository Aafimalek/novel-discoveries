import NineSeparatedSubsetSums.Adaptive138Third132State
import NineSeparatedSubsetSums.Adaptive138Third132Leaves0
import NineSeparatedSubsetSums.Adaptive138Third132Leaves3
import NineSeparatedSubsetSums.Adaptive138Third132Leaves4
import NineSeparatedSubsetSums.Adaptive138Third132Leaves2
import NineSeparatedSubsetSums.Adaptive138Third132Leaves1

namespace NineSeparatedSubsetSums

theorem adaptive138Third132Proof0 : runCachedNode 511 127973 Adaptive138Third132Node0 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 127973 Adaptive138Third132Node0 = [111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 123, 124, 125, 126, 127, 128, 129, 130, 131] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive138Third132Proof1
  · exact adaptive138Third132Proof2
  · exact adaptive138Third132Proof3
  · exact adaptive138Third132Proof4
  · exact adaptive138Third132Proof5
  · exact adaptive138Third132Proof6
  · exact adaptive138Third132Proof7
  · exact adaptive138Third132Proof8
  · exact adaptive138Third132Proof9
  · exact adaptive138Third132Proof10
  · exact adaptive138Third132Proof11
  · exact adaptive138Third132Proof12
  · exact adaptive138Third132Proof13
  · exact adaptive138Third132Proof14
  · exact adaptive138Third132Proof15
  · exact adaptive138Third132Proof16
  · exact adaptive138Third132Proof17
  · exact adaptive138Third132Proof18
  · exact adaptive138Third132Proof19
  · exact adaptive138Third132Proof20

#print axioms adaptive138Third132Proof0

end NineSeparatedSubsetSums
