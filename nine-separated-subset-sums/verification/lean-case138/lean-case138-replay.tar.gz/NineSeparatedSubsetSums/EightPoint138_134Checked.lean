import NineSeparatedSubsetSums.EightPointPackedGeometry
import NineSeparatedSubsetSums.EightPoint138_134PackedBudget0
import NineSeparatedSubsetSums.EightPoint138_134PackedAnchor0Part0
import NineSeparatedSubsetSums.EightPoint138_134PackedAnchor0Part1
import NineSeparatedSubsetSums.EightPoint138_134PackedAnchor0Part2
import NineSeparatedSubsetSums.EightPoint138_134PackedBudget1
import NineSeparatedSubsetSums.EightPoint138_134PackedAnchor1Part0
import NineSeparatedSubsetSums.EightPoint138_134PackedAnchor1Part1
import NineSeparatedSubsetSums.EightPoint138_134PackedAnchor1Part2

namespace NineSeparatedSubsetSums

private theorem packedOct138_134Anchor0 :
  ∀ j : Fin 495, ((j.val : Int)+138+134)%2=0 →
    2425167 ≤ FourPointNumeric.octPackedCharge 138 134 20 packedOct138_134_0 (j.val : Int) := by
  intro j hj
  let k := (j.val-0)/2
  have hk : k < 248 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+0 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint138_134PackedAnchor0Part0 z
    rwa [he,hrep] at ht
  by_cases h1 : k < 240
  · let z : Fin 120 := ⟨k-120, by omega⟩
    have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
    have ht := eightPoint138_134PackedAnchor0Part1 z
    rwa [he,hrep] at ht
  let z : Fin 8 := ⟨k-240, by omega⟩
  have he : (z.val : Int)+240 = k := by dsimp [z] <;> omega
  have ht := eightPoint138_134PackedAnchor0Part2 z
  rwa [he,hrep] at ht

private theorem packedOct138_134Anchor1 :
  ∀ j : Fin 495, ((j.val : Int)+138+134)%2=1 →
    2423428 ≤ FourPointNumeric.octPackedCharge 138 134 20 packedOct138_134_1 (j.val : Int) := by
  intro j hj
  let k := (j.val-1)/2
  have hk : k < 247 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+1 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint138_134PackedAnchor1Part0 z
    rwa [he,hrep] at ht
  by_cases h1 : k < 240
  · let z : Fin 120 := ⟨k-120, by omega⟩
    have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
    have ht := eightPoint138_134PackedAnchor1Part1 z
    rwa [he,hrep] at ht
  let z : Fin 7 := ⟨k-240, by omega⟩
  have he : (z.val : Int)+240 = k := by dsimp [z] <;> omega
  have ht := eightPoint138_134PackedAnchor1Part2 z
  rwa [he,hrep] at ht

def packedOctCertificate138_134_0 : EightPointCertificate 138 134 0 128232 :=
  eightPointCertificateOfPacked 138 134 0 128232 2425167 20 packedOct138_134_0 271 495
    (by decide +kernel) (by decide) packedOct138_134Anchor0
    (by rw [packedOct138_134_0_budget]; decide)

def packedOctCertificate138_134_1 : EightPointCertificate 138 134 1 128232 :=
  eightPointCertificateOfPacked 138 134 1 128232 2423428 20 packedOct138_134_1 272 495
    (by decide +kernel) (by decide) packedOct138_134Anchor1
    (by rw [packedOct138_134_1_budget]; decide)

theorem max148_second138_third134_eightPoint_moment_bound (tail : List ℕ) (len : tail.length=6)
    (distinct : (natSubsetSums (148::138::134::tail)).Nodup) :
    128232 ≤ ((148::138::134::tail).map (· ^ 2)).sum := by
  apply eightPointNatMomentLower 138 134 128232 tail len distinct
  intro p hp
  by_cases h : p=0
  · subst p
    exact packedOctCertificate138_134_0
  · have he : p=1 := hp.resolve_left h
    subst p
    exact packedOctCertificate138_134_1

#print axioms max148_second138_third134_eightPoint_moment_bound

end NineSeparatedSubsetSums
