import NineSeparatedSubsetSums.EightPoint138_123PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint138_123PackedAnchor1Part2 :
    ∀ j : Fin 1, 2292791 ≤ FourPointNumeric.octPackedCharge 138 123 20 packedOct138_123_1
      (2*((j.val : Int)+240)+0) := by decide +kernel

end NineSeparatedSubsetSums
