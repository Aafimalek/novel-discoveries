import NineSeparatedSubsetSums.EightPoint138_125PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint138_125PackedAnchor1Part2 :
    ∀ j : Fin 2, 2314930 ≤ FourPointNumeric.octPackedCharge 138 125 20 packedOct138_125_1
      (2*((j.val : Int)+240)+0) := by decide +kernel

end NineSeparatedSubsetSums
