import NineSeparatedSubsetSums.EightPoint138_137PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct138_137_0_budget :
    FourPointNumeric.packedBudget 20 packedOct138_137_0 273 = 91818410 := by decide +kernel

#print axioms packedOct138_137_0_budget

end NineSeparatedSubsetSums
