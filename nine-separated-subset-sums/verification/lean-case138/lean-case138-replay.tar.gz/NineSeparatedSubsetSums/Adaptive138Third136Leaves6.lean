import NineSeparatedSubsetSums.Adaptive138Third136State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third136Proof158 : runCachedNode 511 128623 Adaptive138Third136Node158 = false := by
  decide +kernel

#print axioms adaptive138Third136Proof158

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third136Proof69 : runCachedNode 511 128623 Adaptive138Third136Node69 = false := by
  decide +kernel

#print axioms adaptive138Third136Proof69

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third136Proof15 : runCachedNode 511 128623 Adaptive138Third136Node15 = false := by
  decide +kernel

#print axioms adaptive138Third136Proof15

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third136Proof66 : runCachedNode 511 128623 Adaptive138Third136Node66 = false := by
  decide +kernel

#print axioms adaptive138Third136Proof66

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third136Proof1 : runCachedNode 511 128623 Adaptive138Third136Node1 = false := by
  decide +kernel

#print axioms adaptive138Third136Proof1

end NineSeparatedSubsetSums
