import NineSeparatedSubsetSums.FourPoint138PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedWeight138_0_budget :
    FourPointNumeric.packedBudget 19 packedWeight138_0 367 = 76120320 := by decide +kernel

#print axioms packedWeight138_0_budget

end NineSeparatedSubsetSums
