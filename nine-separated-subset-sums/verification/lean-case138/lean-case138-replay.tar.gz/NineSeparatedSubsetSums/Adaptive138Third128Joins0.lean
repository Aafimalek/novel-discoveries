import NineSeparatedSubsetSums.Adaptive138Third128State
import NineSeparatedSubsetSums.Adaptive138Third128Leaves0
import NineSeparatedSubsetSums.Adaptive138Third128Leaves2
import NineSeparatedSubsetSums.Adaptive138Third128Leaves1

namespace NineSeparatedSubsetSums

theorem adaptive138Third128Proof0 : runCachedNode 511 127087 Adaptive138Third128Node0 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 127087 Adaptive138Third128Node0 = [111, 112, 113, 114, 115, 116, 117, 119, 120, 121, 122, 123, 124, 125, 126, 127] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive138Third128Proof1
  · exact adaptive138Third128Proof2
  · exact adaptive138Third128Proof3
  · exact adaptive138Third128Proof4
  · exact adaptive138Third128Proof5
  · exact adaptive138Third128Proof6
  · exact adaptive138Third128Proof7
  · exact adaptive138Third128Proof8
  · exact adaptive138Third128Proof9
  · exact adaptive138Third128Proof10
  · exact adaptive138Third128Proof11
  · exact adaptive138Third128Proof12
  · exact adaptive138Third128Proof13
  · exact adaptive138Third128Proof14
  · exact adaptive138Third128Proof15
  · exact adaptive138Third128Proof16

#print axioms adaptive138Third128Proof0

end NineSeparatedSubsetSums
