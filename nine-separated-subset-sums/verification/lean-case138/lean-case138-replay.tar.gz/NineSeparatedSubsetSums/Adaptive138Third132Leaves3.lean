import NineSeparatedSubsetSums.Adaptive138Third132State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third132Proof18 : runCachedNode 511 127973 Adaptive138Third132Node18 = false := by
  decide +kernel

#print axioms adaptive138Third132Proof18

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third132Proof16 : runCachedNode 511 127973 Adaptive138Third132Node16 = false := by
  decide +kernel

#print axioms adaptive138Third132Proof16

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third132Proof9 : runCachedNode 511 127973 Adaptive138Third132Node9 = false := by
  decide +kernel

#print axioms adaptive138Third132Proof9

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third132Proof7 : runCachedNode 511 127973 Adaptive138Third132Node7 = false := by
  decide +kernel

#print axioms adaptive138Third132Proof7

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third132Proof6 : runCachedNode 511 127973 Adaptive138Third132Node6 = false := by
  decide +kernel

#print axioms adaptive138Third132Proof6

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third132Proof2 : runCachedNode 511 127973 Adaptive138Third132Node2 = false := by
  decide +kernel

#print axioms adaptive138Third132Proof2

end NineSeparatedSubsetSums
