import NineSeparatedSubsetSums.EightPoint138_125PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint138_125PackedAnchor0Part0 :
    ∀ j : Fin 120, 2314955 ≤ FourPointNumeric.octPackedCharge 138 125 20 packedOct138_125_0
      (2*((j.val : Int)+0)+1) := by decide +kernel

end NineSeparatedSubsetSums
