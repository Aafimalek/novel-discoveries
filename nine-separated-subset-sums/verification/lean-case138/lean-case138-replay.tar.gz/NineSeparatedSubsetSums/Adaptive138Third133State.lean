import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive138Third133Node0 : CachedSearchNode :=
  ⟨4, 132, computeCenteredMask [148,138,133], 419, 58637⟩
def Adaptive138Third133Node1 : CachedSearchNode := cachedChild Adaptive138Third133Node0 111
def Adaptive138Third133Node2 : CachedSearchNode := cachedChild Adaptive138Third133Node0 112
def Adaptive138Third133Node3 : CachedSearchNode := cachedChild Adaptive138Third133Node0 113
def Adaptive138Third133Node4 : CachedSearchNode := cachedChild Adaptive138Third133Node0 114
def Adaptive138Third133Node5 : CachedSearchNode := cachedChild Adaptive138Third133Node0 115
def Adaptive138Third133Node6 : CachedSearchNode := cachedChild Adaptive138Third133Node0 116
def Adaptive138Third133Node7 : CachedSearchNode := cachedChild Adaptive138Third133Node0 117
def Adaptive138Third133Node8 : CachedSearchNode := cachedChild Adaptive138Third133Node0 118
def Adaptive138Third133Node9 : CachedSearchNode := cachedChild Adaptive138Third133Node0 119
def Adaptive138Third133Node10 : CachedSearchNode := cachedChild Adaptive138Third133Node0 120
def Adaptive138Third133Node11 : CachedSearchNode := cachedChild Adaptive138Third133Node0 121
def Adaptive138Third133Node12 : CachedSearchNode := cachedChild Adaptive138Third133Node0 122
def Adaptive138Third133Node13 : CachedSearchNode := cachedChild Adaptive138Third133Node0 124
def Adaptive138Third133Node14 : CachedSearchNode := cachedChild Adaptive138Third133Node0 125
def Adaptive138Third133Node15 : CachedSearchNode := cachedChild Adaptive138Third133Node0 126
def Adaptive138Third133Node16 : CachedSearchNode := cachedChild Adaptive138Third133Node0 127
def Adaptive138Third133Node17 : CachedSearchNode := cachedChild Adaptive138Third133Node0 128
def Adaptive138Third133Node18 : CachedSearchNode := cachedChild Adaptive138Third133Node0 129
def Adaptive138Third133Node19 : CachedSearchNode := cachedChild Adaptive138Third133Node0 130
def Adaptive138Third133Node20 : CachedSearchNode := cachedChild Adaptive138Third133Node0 131
def Adaptive138Third133Node21 : CachedSearchNode := cachedChild Adaptive138Third133Node0 132
def Adaptive138Third133Node22 : CachedSearchNode := cachedChild Adaptive138Third133Node21 104
def Adaptive138Third133Node23 : CachedSearchNode := cachedChild Adaptive138Third133Node21 105
def Adaptive138Third133Node24 : CachedSearchNode := cachedChild Adaptive138Third133Node21 106
def Adaptive138Third133Node25 : CachedSearchNode := cachedChild Adaptive138Third133Node21 107
def Adaptive138Third133Node26 : CachedSearchNode := cachedChild Adaptive138Third133Node21 108
def Adaptive138Third133Node27 : CachedSearchNode := cachedChild Adaptive138Third133Node21 109
def Adaptive138Third133Node28 : CachedSearchNode := cachedChild Adaptive138Third133Node21 110
def Adaptive138Third133Node29 : CachedSearchNode := cachedChild Adaptive138Third133Node21 111
def Adaptive138Third133Node30 : CachedSearchNode := cachedChild Adaptive138Third133Node21 112
def Adaptive138Third133Node31 : CachedSearchNode := cachedChild Adaptive138Third133Node21 113
def Adaptive138Third133Node32 : CachedSearchNode := cachedChild Adaptive138Third133Node21 114
def Adaptive138Third133Node33 : CachedSearchNode := cachedChild Adaptive138Third133Node21 115
def Adaptive138Third133Node34 : CachedSearchNode := cachedChild Adaptive138Third133Node21 116
def Adaptive138Third133Node35 : CachedSearchNode := cachedChild Adaptive138Third133Node21 118
def Adaptive138Third133Node36 : CachedSearchNode := cachedChild Adaptive138Third133Node21 119
def Adaptive138Third133Node37 : CachedSearchNode := cachedChild Adaptive138Third133Node21 120
def Adaptive138Third133Node38 : CachedSearchNode := cachedChild Adaptive138Third133Node21 121
def Adaptive138Third133Node39 : CachedSearchNode := cachedChild Adaptive138Third133Node21 124
def Adaptive138Third133Node40 : CachedSearchNode := cachedChild Adaptive138Third133Node21 125
def Adaptive138Third133Node41 : CachedSearchNode := cachedChild Adaptive138Third133Node21 126
def Adaptive138Third133Node42 : CachedSearchNode := cachedChild Adaptive138Third133Node21 128
def Adaptive138Third133Node43 : CachedSearchNode := cachedChild Adaptive138Third133Node21 129
def Adaptive138Third133Node44 : CachedSearchNode := cachedChild Adaptive138Third133Node21 130
def Adaptive138Third133Node45 : CachedSearchNode := cachedChild Adaptive138Third133Node21 131

end NineSeparatedSubsetSums
