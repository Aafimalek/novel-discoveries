import NineSeparatedSubsetSums.EightPoint138_131PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint138_131PackedAnchor0Part0 :
    ∀ j : Fin 120, 2423480 ≤ FourPointNumeric.octPackedCharge 138 131 20 packedOct138_131_0
      (2*((j.val : Int)+0)+1) := by decide +kernel

end NineSeparatedSubsetSums
