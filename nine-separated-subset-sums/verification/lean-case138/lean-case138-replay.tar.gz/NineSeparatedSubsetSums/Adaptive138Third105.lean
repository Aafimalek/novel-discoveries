import NineSeparatedSubsetSums.Adaptive138Third105Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint138Checked

namespace NineSeparatedSubsetSums


theorem adaptive138Third105 : NoDescendingTailAfterThird 138 105 :=
  noDescendingThirdTail_of_cached 138 105 111079 (fun t ht nd => max148_second138_fourPoint_moment_bound (105::t) (by simp [ht]) nd) adaptive138Third105Proof0

#print axioms adaptive138Third105

end NineSeparatedSubsetSums
