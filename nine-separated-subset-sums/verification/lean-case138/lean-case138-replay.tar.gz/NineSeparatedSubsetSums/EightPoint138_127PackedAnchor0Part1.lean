import NineSeparatedSubsetSums.EightPoint138_127PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint138_127PackedAnchor0Part1 :
    ∀ j : Fin 120, 2349624 ≤ FourPointNumeric.octPackedCharge 138 127 20 packedOct138_127_0
      (2*((j.val : Int)+120)+1) := by decide +kernel

end NineSeparatedSubsetSums
