import NineSeparatedSubsetSums.EightPoint138_136PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint138_136PackedAnchor1Part2 :
    ∀ j : Fin 9, 2451952 ≤ FourPointNumeric.octPackedCharge 138 136 20 packedOct138_136_1
      (2*((j.val : Int)+240)+1) := by decide +kernel

end NineSeparatedSubsetSums
