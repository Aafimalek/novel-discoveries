import NineSeparatedSubsetSums.Adaptive138Third135State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third135Proof26 : runCachedNode 511 128437 Adaptive138Third135Node26 = false := by
  decide +kernel

#print axioms adaptive138Third135Proof26

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third135Proof54 : runCachedNode 511 128437 Adaptive138Third135Node54 = false := by
  decide +kernel

#print axioms adaptive138Third135Proof54

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third135Proof78 : runCachedNode 511 128437 Adaptive138Third135Node78 = false := by
  decide +kernel

#print axioms adaptive138Third135Proof78

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third135Proof3 : runCachedNode 511 128437 Adaptive138Third135Node3 = false := by
  decide +kernel

#print axioms adaptive138Third135Proof3

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third135Proof53 : runCachedNode 511 128437 Adaptive138Third135Node53 = false := by
  decide +kernel

#print axioms adaptive138Third135Proof53

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third135Proof25 : runCachedNode 511 128437 Adaptive138Third135Node25 = false := by
  decide +kernel

#print axioms adaptive138Third135Proof25

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third135Proof52 : runCachedNode 511 128437 Adaptive138Third135Node52 = false := by
  decide +kernel

#print axioms adaptive138Third135Proof52

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third135Proof2 : runCachedNode 511 128437 Adaptive138Third135Node2 = false := by
  decide +kernel

#print axioms adaptive138Third135Proof2

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third135Proof24 : runCachedNode 511 128437 Adaptive138Third135Node24 = false := by
  decide +kernel

#print axioms adaptive138Third135Proof24

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third135Proof51 : runCachedNode 511 128437 Adaptive138Third135Node51 = false := by
  decide +kernel

#print axioms adaptive138Third135Proof51

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third135Proof77 : runCachedNode 511 128437 Adaptive138Third135Node77 = false := by
  decide +kernel

#print axioms adaptive138Third135Proof77

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third135Proof1 : runCachedNode 511 128437 Adaptive138Third135Node1 = false := by
  decide +kernel

#print axioms adaptive138Third135Proof1

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third135Proof23 : runCachedNode 511 128437 Adaptive138Third135Node23 = false := by
  decide +kernel

#print axioms adaptive138Third135Proof23

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third135Proof50 : runCachedNode 511 128437 Adaptive138Third135Node50 = false := by
  decide +kernel

#print axioms adaptive138Third135Proof50

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third135Proof75 : runCachedNode 511 128437 Adaptive138Third135Node75 = false := by
  decide +kernel

#print axioms adaptive138Third135Proof75

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third135Proof76 : runCachedNode 511 128437 Adaptive138Third135Node76 = false := by
  decide +kernel

#print axioms adaptive138Third135Proof76

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third135Proof74 : runCachedNode 511 128437 Adaptive138Third135Node74 = false := by
  decide +kernel

#print axioms adaptive138Third135Proof74

end NineSeparatedSubsetSums
