import NineSeparatedSubsetSums.EightPoint138_117PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct138_117_0_budget :
    FourPointNumeric.packedBudget 20 packedOct138_117_0 265 = 81118602 := by decide +kernel

#print axioms packedOct138_117_0_budget

end NineSeparatedSubsetSums
