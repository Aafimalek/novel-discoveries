import NineSeparatedSubsetSums.Adaptive138Third135State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third135Proof21 : runCachedNode 511 128437 Adaptive138Third135Node21 = false := by
  decide +kernel

#print axioms adaptive138Third135Proof21

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third135Proof72 : runCachedNode 511 128437 Adaptive138Third135Node72 = false := by
  decide +kernel

#print axioms adaptive138Third135Proof72

end NineSeparatedSubsetSums
