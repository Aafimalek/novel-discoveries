import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive138Third114Node0 : CachedSearchNode :=
  ⟨4, 113, computeCenteredMask [148,138,114], 400, 53944⟩

end NineSeparatedSubsetSums
