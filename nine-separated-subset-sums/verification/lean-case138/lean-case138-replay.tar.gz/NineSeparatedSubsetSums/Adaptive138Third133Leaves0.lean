import NineSeparatedSubsetSums.Adaptive138Third133State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third133Proof17 : runCachedNode 511 128072 Adaptive138Third133Node17 = false := by
  decide +kernel

#print axioms adaptive138Third133Proof17

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third133Proof43 : runCachedNode 511 128072 Adaptive138Third133Node43 = false := by
  decide +kernel

#print axioms adaptive138Third133Proof43

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third133Proof27 : runCachedNode 511 128072 Adaptive138Third133Node27 = false := by
  decide +kernel

#print axioms adaptive138Third133Proof27

end NineSeparatedSubsetSums
