import NineSeparatedSubsetSums.EightPoint138_123PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint138_123PackedAnchor0Part0 :
    ∀ j : Fin 120, 2292988 ≤ FourPointNumeric.octPackedCharge 138 123 20 packedOct138_123_0
      (2*((j.val : Int)+0)+1) := by decide +kernel

end NineSeparatedSubsetSums
