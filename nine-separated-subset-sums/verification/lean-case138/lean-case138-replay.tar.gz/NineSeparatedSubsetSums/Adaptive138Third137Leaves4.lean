import NineSeparatedSubsetSums.Adaptive138Third137State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third137Proof157 : runCachedNode 511 128810 Adaptive138Third137Node157 = false := by
  decide +kernel

#print axioms adaptive138Third137Proof157

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third137Proof155 : runCachedNode 511 128810 Adaptive138Third137Node155 = false := by
  decide +kernel

#print axioms adaptive138Third137Proof155

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third137Proof11 : runCachedNode 511 128810 Adaptive138Third137Node11 = false := by
  decide +kernel

#print axioms adaptive138Third137Proof11

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third137Proof49 : runCachedNode 511 128810 Adaptive138Third137Node49 = false := by
  decide +kernel

#print axioms adaptive138Third137Proof49

end NineSeparatedSubsetSums
