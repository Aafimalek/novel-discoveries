import NineSeparatedSubsetSums.EightPoint138_127PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct138_127_0_budget :
    FourPointNumeric.packedBudget 20 packedOct138_127_0 423 = 85373709 := by decide +kernel

#print axioms packedOct138_127_0_budget

end NineSeparatedSubsetSums
