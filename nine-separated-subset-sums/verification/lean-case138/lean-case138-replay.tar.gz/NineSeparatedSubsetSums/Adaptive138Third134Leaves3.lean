import NineSeparatedSubsetSums.Adaptive138Third134State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third134Proof66 : runCachedNode 511 128232 Adaptive138Third134Node66 = false := by
  decide +kernel

#print axioms adaptive138Third134Proof66

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third134Proof90 : runCachedNode 511 128232 Adaptive138Third134Node90 = false := by
  decide +kernel

#print axioms adaptive138Third134Proof90

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third134Proof14 : runCachedNode 511 128232 Adaptive138Third134Node14 = false := by
  decide +kernel

#print axioms adaptive138Third134Proof14

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third134Proof4 : runCachedNode 511 128232 Adaptive138Third134Node4 = false := by
  decide +kernel

#print axioms adaptive138Third134Proof4

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third134Proof21 : runCachedNode 511 128232 Adaptive138Third134Node21 = false := by
  decide +kernel

#print axioms adaptive138Third134Proof21

end NineSeparatedSubsetSums
