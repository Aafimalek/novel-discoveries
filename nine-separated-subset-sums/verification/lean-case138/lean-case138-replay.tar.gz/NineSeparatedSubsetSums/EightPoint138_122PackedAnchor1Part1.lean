import NineSeparatedSubsetSums.EightPoint138_122PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint138_122PackedAnchor1Part1 :
    ∀ j : Fin 120, 2285157 ≤ FourPointNumeric.octPackedCharge 138 122 20 packedOct138_122_1
      (2*((j.val : Int)+120)+1) := by decide +kernel

end NineSeparatedSubsetSums
