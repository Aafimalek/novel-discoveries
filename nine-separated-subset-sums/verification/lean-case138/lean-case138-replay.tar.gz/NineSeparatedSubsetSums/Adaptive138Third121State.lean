import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive138Third121Node0 : CachedSearchNode :=
  ⟨4, 120, computeCenteredMask [148,138,121], 407, 55589⟩

end NineSeparatedSubsetSums
