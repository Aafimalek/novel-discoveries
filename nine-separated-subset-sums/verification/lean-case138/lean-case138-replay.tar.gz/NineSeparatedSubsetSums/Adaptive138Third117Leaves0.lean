import NineSeparatedSubsetSums.Adaptive138Third117State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third117Proof0 : runCachedNode 511 124697 Adaptive138Third117Node0 = false := by
  decide +kernel

#print axioms adaptive138Third117Proof0

end NineSeparatedSubsetSums
