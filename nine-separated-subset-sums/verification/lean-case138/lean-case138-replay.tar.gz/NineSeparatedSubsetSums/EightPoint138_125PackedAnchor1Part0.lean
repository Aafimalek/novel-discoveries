import NineSeparatedSubsetSums.EightPoint138_125PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint138_125PackedAnchor1Part0 :
    ∀ j : Fin 120, 2314930 ≤ FourPointNumeric.octPackedCharge 138 125 20 packedOct138_125_1
      (2*((j.val : Int)+0)+0) := by decide +kernel

end NineSeparatedSubsetSums
