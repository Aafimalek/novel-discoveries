import NineSeparatedSubsetSums.Adaptive138Third110State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third110Proof0 : runCachedNode 511 111079 Adaptive138Third110Node0 = false := by
  decide +kernel

#print axioms adaptive138Third110Proof0

end NineSeparatedSubsetSums
