import NineSeparatedSubsetSums.Adaptive138Third136State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third136Proof98 : runCachedNode 511 128623 Adaptive138Third136Node98 = false := by
  decide +kernel

#print axioms adaptive138Third136Proof98

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third136Proof95 : runCachedNode 511 128623 Adaptive138Third136Node95 = false := by
  decide +kernel

#print axioms adaptive138Third136Proof95

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third136Proof101 : runCachedNode 511 128623 Adaptive138Third136Node101 = false := by
  decide +kernel

#print axioms adaptive138Third136Proof101

end NineSeparatedSubsetSums
