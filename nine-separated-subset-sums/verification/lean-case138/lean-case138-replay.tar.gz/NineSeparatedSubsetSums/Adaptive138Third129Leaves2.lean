import NineSeparatedSubsetSums.Adaptive138Third129State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third129Proof3 : runCachedNode 511 127319 Adaptive138Third129Node3 = false := by
  decide +kernel

#print axioms adaptive138Third129Proof3

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third129Proof2 : runCachedNode 511 127319 Adaptive138Third129Node2 = false := by
  decide +kernel

#print axioms adaptive138Third129Proof2

end NineSeparatedSubsetSums
