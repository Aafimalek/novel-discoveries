import NineSeparatedSubsetSums.EightPoint138_130PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint138_130PackedAnchor1Part1 :
    ∀ j : Fin 120, 2401124 ≤ FourPointNumeric.octPackedCharge 138 130 20 packedOct138_130_1
      (2*((j.val : Int)+120)+1) := by decide +kernel

end NineSeparatedSubsetSums
