import NineSeparatedSubsetSums.Adaptive138Third118State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third118Proof0 : runCachedNode 511 124914 Adaptive138Third118Node0 = false := by
  decide +kernel

#print axioms adaptive138Third118Proof0

end NineSeparatedSubsetSums
