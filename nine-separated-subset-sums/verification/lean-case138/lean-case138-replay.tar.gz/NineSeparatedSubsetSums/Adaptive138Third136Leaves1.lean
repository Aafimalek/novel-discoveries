import NineSeparatedSubsetSums.Adaptive138Third136State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third136Proof21 : runCachedNode 511 128623 Adaptive138Third136Node21 = false := by
  decide +kernel

#print axioms adaptive138Third136Proof21

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third136Proof126 : runCachedNode 511 128623 Adaptive138Third136Node126 = false := by
  decide +kernel

#print axioms adaptive138Third136Proof126

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third136Proof4 : runCachedNode 511 128623 Adaptive138Third136Node4 = false := by
  decide +kernel

#print axioms adaptive138Third136Proof4

end NineSeparatedSubsetSums
