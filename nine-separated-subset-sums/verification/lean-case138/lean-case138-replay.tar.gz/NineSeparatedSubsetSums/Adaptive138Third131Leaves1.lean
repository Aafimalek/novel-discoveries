import NineSeparatedSubsetSums.Adaptive138Third131State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third131Proof19 : runCachedNode 511 127792 Adaptive138Third131Node19 = false := by
  decide +kernel

#print axioms adaptive138Third131Proof19

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third131Proof15 : runCachedNode 511 127792 Adaptive138Third131Node15 = false := by
  decide +kernel

#print axioms adaptive138Third131Proof15

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third131Proof11 : runCachedNode 511 127792 Adaptive138Third131Node11 = false := by
  decide +kernel

#print axioms adaptive138Third131Proof11

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third131Proof2 : runCachedNode 511 127792 Adaptive138Third131Node2 = false := by
  decide +kernel

#print axioms adaptive138Third131Proof2

end NineSeparatedSubsetSums
