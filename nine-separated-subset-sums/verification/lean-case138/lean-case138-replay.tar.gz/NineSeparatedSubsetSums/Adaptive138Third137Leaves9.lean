import NineSeparatedSubsetSums.Adaptive138Third137State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third137Proof151 : runCachedNode 511 128810 Adaptive138Third137Node151 = false := by
  decide +kernel

#print axioms adaptive138Third137Proof151

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third137Proof154 : runCachedNode 511 128810 Adaptive138Third137Node154 = false := by
  decide +kernel

#print axioms adaptive138Third137Proof154

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third137Proof16 : runCachedNode 511 128810 Adaptive138Third137Node16 = false := by
  decide +kernel

#print axioms adaptive138Third137Proof16

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third137Proof72 : runCachedNode 511 128810 Adaptive138Third137Node72 = false := by
  decide +kernel

#print axioms adaptive138Third137Proof72

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third137Proof15 : runCachedNode 511 128810 Adaptive138Third137Node15 = false := by
  decide +kernel

#print axioms adaptive138Third137Proof15

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third137Proof149 : runCachedNode 511 128810 Adaptive138Third137Node149 = false := by
  decide +kernel

#print axioms adaptive138Third137Proof149

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third137Proof103 : runCachedNode 511 128810 Adaptive138Third137Node103 = false := by
  decide +kernel

#print axioms adaptive138Third137Proof103

end NineSeparatedSubsetSums
