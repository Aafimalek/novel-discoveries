import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive138Third118Node0 : CachedSearchNode :=
  ⟨4, 117, computeCenteredMask [148,138,118], 404, 54872⟩

end NineSeparatedSubsetSums
