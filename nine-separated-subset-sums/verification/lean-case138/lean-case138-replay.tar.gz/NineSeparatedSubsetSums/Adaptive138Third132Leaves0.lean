import NineSeparatedSubsetSums.Adaptive138Third132State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third132Proof20 : runCachedNode 511 127973 Adaptive138Third132Node20 = false := by
  decide +kernel

#print axioms adaptive138Third132Proof20

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third132Proof14 : runCachedNode 511 127973 Adaptive138Third132Node14 = false := by
  decide +kernel

#print axioms adaptive138Third132Proof14

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third132Proof3 : runCachedNode 511 127973 Adaptive138Third132Node3 = false := by
  decide +kernel

#print axioms adaptive138Third132Proof3

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third132Proof1 : runCachedNode 511 127973 Adaptive138Third132Node1 = false := by
  decide +kernel

#print axioms adaptive138Third132Proof1

end NineSeparatedSubsetSums
