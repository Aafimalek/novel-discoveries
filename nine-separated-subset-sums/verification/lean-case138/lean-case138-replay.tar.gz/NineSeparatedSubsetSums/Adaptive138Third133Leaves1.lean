import NineSeparatedSubsetSums.Adaptive138Third133State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third133Proof20 : runCachedNode 511 128072 Adaptive138Third133Node20 = false := by
  decide +kernel

#print axioms adaptive138Third133Proof20

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third133Proof45 : runCachedNode 511 128072 Adaptive138Third133Node45 = false := by
  decide +kernel

#print axioms adaptive138Third133Proof45

end NineSeparatedSubsetSums
