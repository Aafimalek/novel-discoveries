import NineSeparatedSubsetSums.Adaptive138Third121State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third121Proof0 : runCachedNode 511 125497 Adaptive138Third121Node0 = false := by
  decide +kernel

#print axioms adaptive138Third121Proof0

end NineSeparatedSubsetSums
