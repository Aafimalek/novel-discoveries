import NineSeparatedSubsetSums.EightPoint138_119PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct138_119_1_budget :
    FourPointNumeric.packedBudget 20 packedOct138_119_1 422 = 82712876 := by decide +kernel

#print axioms packedOct138_119_1_budget

end NineSeparatedSubsetSums
