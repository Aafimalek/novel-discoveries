import NineSeparatedSubsetSums.EightPoint138_117PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint138_117PackedAnchor0Part1 :
    ∀ j : Fin 119, 2265048 ≤ FourPointNumeric.octPackedCharge 138 117 20 packedOct138_117_0
      (2*((j.val : Int)+120)+1) := by decide +kernel

end NineSeparatedSubsetSums
