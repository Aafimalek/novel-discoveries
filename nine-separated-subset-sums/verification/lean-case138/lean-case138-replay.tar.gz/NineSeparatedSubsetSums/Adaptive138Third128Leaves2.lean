import NineSeparatedSubsetSums.Adaptive138Third128State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third128Proof9 : runCachedNode 511 127087 Adaptive138Third128Node9 = false := by
  decide +kernel

#print axioms adaptive138Third128Proof9

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third128Proof8 : runCachedNode 511 127087 Adaptive138Third128Node8 = false := by
  decide +kernel

#print axioms adaptive138Third128Proof8

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third128Proof7 : runCachedNode 511 127087 Adaptive138Third128Node7 = false := by
  decide +kernel

#print axioms adaptive138Third128Proof7

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third128Proof6 : runCachedNode 511 127087 Adaptive138Third128Node6 = false := by
  decide +kernel

#print axioms adaptive138Third128Proof6

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third128Proof5 : runCachedNode 511 127087 Adaptive138Third128Node5 = false := by
  decide +kernel

#print axioms adaptive138Third128Proof5

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third128Proof3 : runCachedNode 511 127087 Adaptive138Third128Node3 = false := by
  decide +kernel

#print axioms adaptive138Third128Proof3

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third128Proof2 : runCachedNode 511 127087 Adaptive138Third128Node2 = false := by
  decide +kernel

#print axioms adaptive138Third128Proof2

end NineSeparatedSubsetSums
