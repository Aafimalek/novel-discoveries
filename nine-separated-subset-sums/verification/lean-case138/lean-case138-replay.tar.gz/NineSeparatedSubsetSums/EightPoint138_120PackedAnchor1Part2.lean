import NineSeparatedSubsetSums.EightPoint138_120PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint138_120PackedAnchor1Part2 :
    ∀ j : Fin 2, 2320849 ≤ FourPointNumeric.octPackedCharge 138 120 20 packedOct138_120_1
      (2*((j.val : Int)+240)+1) := by decide +kernel

end NineSeparatedSubsetSums
