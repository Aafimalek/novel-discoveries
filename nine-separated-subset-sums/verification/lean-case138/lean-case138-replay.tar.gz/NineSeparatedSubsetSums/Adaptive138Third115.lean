import NineSeparatedSubsetSums.Adaptive138Third115Joins0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint138Checked

namespace NineSeparatedSubsetSums


theorem adaptive138Third115 : NoDescendingTailAfterThird 138 115 :=
  noDescendingThirdTail_of_cached 138 115 111079 (fun t ht nd => max148_second138_fourPoint_moment_bound (115::t) (by simp [ht]) nd) adaptive138Third115Proof0

#print axioms adaptive138Third115

end NineSeparatedSubsetSums
