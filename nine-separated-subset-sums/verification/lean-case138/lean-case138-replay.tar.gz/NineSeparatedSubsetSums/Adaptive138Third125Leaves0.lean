import NineSeparatedSubsetSums.Adaptive138Third125State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third125Proof0 : runCachedNode 511 126666 Adaptive138Third125Node0 = false := by
  decide +kernel

#print axioms adaptive138Third125Proof0

end NineSeparatedSubsetSums
