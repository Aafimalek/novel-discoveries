import NineSeparatedSubsetSums.Adaptive138Third104Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint138Checked

namespace NineSeparatedSubsetSums


theorem adaptive138Third104 : NoDescendingTailAfterThird 138 104 :=
  noDescendingThirdTail_of_cached 138 104 111079 (fun t ht nd => max148_second138_fourPoint_moment_bound (104::t) (by simp [ht]) nd) adaptive138Third104Proof0

#print axioms adaptive138Third104

end NineSeparatedSubsetSums
