import NineSeparatedSubsetSums.EightPoint138_128PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint138_128PackedAnchor1Part2 :
    ∀ j : Fin 4, 2358471 ≤ FourPointNumeric.octPackedCharge 138 128 20 packedOct138_128_1
      (2*((j.val : Int)+240)+1) := by decide +kernel

end NineSeparatedSubsetSums
