import NineSeparatedSubsetSums.EightPointPackedGeometry
import NineSeparatedSubsetSums.EightPoint138_118PackedBudget0
import NineSeparatedSubsetSums.EightPoint138_118PackedAnchor0Part0
import NineSeparatedSubsetSums.EightPoint138_118PackedAnchor0Part1
import NineSeparatedSubsetSums.EightPoint138_118PackedBudget1
import NineSeparatedSubsetSums.EightPoint138_118PackedAnchor1Part0
import NineSeparatedSubsetSums.EightPoint138_118PackedAnchor1Part1

namespace NineSeparatedSubsetSums

private theorem packedOct138_118Anchor0 :
  ∀ j : Fin 480, ((j.val : Int)+138+118)%2=0 →
    2277096 ≤ FourPointNumeric.octPackedCharge 138 118 20 packedOct138_118_0 (j.val : Int) := by
  intro j hj
  let k := (j.val-0)/2
  have hk : k < 240 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+0 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint138_118PackedAnchor0Part0 z
    rwa [he,hrep] at ht
  let z : Fin 120 := ⟨k-120, by omega⟩
  have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
  have ht := eightPoint138_118PackedAnchor0Part1 z
  rwa [he,hrep] at ht

private theorem packedOct138_118Anchor1 :
  ∀ j : Fin 480, ((j.val : Int)+138+118)%2=1 →
    2277193 ≤ FourPointNumeric.octPackedCharge 138 118 20 packedOct138_118_1 (j.val : Int) := by
  intro j hj
  let k := (j.val-1)/2
  have hk : k < 240 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+1 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint138_118PackedAnchor1Part0 z
    rwa [he,hrep] at ht
  let z : Fin 120 := ⟨k-120, by omega⟩
  have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
  have ht := eightPoint138_118PackedAnchor1Part1 z
  rwa [he,hrep] at ht

def packedOctCertificate138_118_0 : EightPointCertificate 138 118 0 124914 :=
  eightPointCertificateOfPacked 138 118 0 124914 2277096 20 packedOct138_118_0 271 480
    (by decide +kernel) (by decide) packedOct138_118Anchor0
    (by rw [packedOct138_118_0_budget]; decide)

def packedOctCertificate138_118_1 : EightPointCertificate 138 118 1 124914 :=
  eightPointCertificateOfPacked 138 118 1 124914 2277193 20 packedOct138_118_1 272 480
    (by decide +kernel) (by decide) packedOct138_118Anchor1
    (by rw [packedOct138_118_1_budget]; decide)

theorem max148_second138_third118_eightPoint_moment_bound (tail : List ℕ) (len : tail.length=6)
    (distinct : (natSubsetSums (148::138::118::tail)).Nodup) :
    124914 ≤ ((148::138::118::tail).map (· ^ 2)).sum := by
  apply eightPointNatMomentLower 138 118 124914 tail len distinct
  intro p hp
  by_cases h : p=0
  · subst p
    exact packedOctCertificate138_118_0
  · have he : p=1 := hp.resolve_left h
    subst p
    exact packedOctCertificate138_118_1

#print axioms max148_second138_third118_eightPoint_moment_bound

end NineSeparatedSubsetSums
