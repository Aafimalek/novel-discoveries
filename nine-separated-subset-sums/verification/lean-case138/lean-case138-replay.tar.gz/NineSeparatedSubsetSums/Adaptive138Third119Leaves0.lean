import NineSeparatedSubsetSums.Adaptive138Third119State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third119Proof0 : runCachedNode 511 125117 Adaptive138Third119Node0 = false := by
  decide +kernel

#print axioms adaptive138Third119Proof0

end NineSeparatedSubsetSums
