import NineSeparatedSubsetSums.Adaptive138Third137State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third137Proof162 : runCachedNode 511 128810 Adaptive138Third137Node162 = false := by
  decide +kernel

#print axioms adaptive138Third137Proof162

end NineSeparatedSubsetSums
