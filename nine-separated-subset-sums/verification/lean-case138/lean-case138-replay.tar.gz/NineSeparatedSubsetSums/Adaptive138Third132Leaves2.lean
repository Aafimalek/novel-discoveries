import NineSeparatedSubsetSums.Adaptive138Third132State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third132Proof19 : runCachedNode 511 127973 Adaptive138Third132Node19 = false := by
  decide +kernel

#print axioms adaptive138Third132Proof19

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third132Proof12 : runCachedNode 511 127973 Adaptive138Third132Node12 = false := by
  decide +kernel

#print axioms adaptive138Third132Proof12

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third132Proof11 : runCachedNode 511 127973 Adaptive138Third132Node11 = false := by
  decide +kernel

#print axioms adaptive138Third132Proof11

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third132Proof8 : runCachedNode 511 127973 Adaptive138Third132Node8 = false := by
  decide +kernel

#print axioms adaptive138Third132Proof8

end NineSeparatedSubsetSums
