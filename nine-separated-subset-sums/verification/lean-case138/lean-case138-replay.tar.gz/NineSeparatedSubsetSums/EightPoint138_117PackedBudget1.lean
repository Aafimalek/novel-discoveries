import NineSeparatedSubsetSums.EightPoint138_117PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct138_117_1_budget :
    FourPointNumeric.packedBudget 20 packedOct138_117_1 350 = 81116252 := by decide +kernel

#print axioms packedOct138_117_1_budget

end NineSeparatedSubsetSums
