import NineSeparatedSubsetSums.Adaptive138Third109Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint138Checked

namespace NineSeparatedSubsetSums


theorem adaptive138Third109 : NoDescendingTailAfterThird 138 109 :=
  noDescendingThirdTail_of_cached 138 109 111079 (fun t ht nd => max148_second138_fourPoint_moment_bound (109::t) (by simp [ht]) nd) adaptive138Third109Proof0

#print axioms adaptive138Third109

end NineSeparatedSubsetSums
