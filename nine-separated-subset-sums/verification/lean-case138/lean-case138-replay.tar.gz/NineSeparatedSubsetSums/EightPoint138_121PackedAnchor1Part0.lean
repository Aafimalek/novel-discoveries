import NineSeparatedSubsetSums.EightPoint138_121PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint138_121PackedAnchor1Part0 :
    ∀ j : Fin 120, 2371417 ≤ FourPointNumeric.octPackedCharge 138 121 20 packedOct138_121_1
      (2*((j.val : Int)+0)+0) := by decide +kernel

end NineSeparatedSubsetSums
