import NineSeparatedSubsetSums.Adaptive138Third122State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third122Proof0 : runCachedNode 511 125600 Adaptive138Third122Node0 = false := by
  decide +kernel

#print axioms adaptive138Third122Proof0

end NineSeparatedSubsetSums
