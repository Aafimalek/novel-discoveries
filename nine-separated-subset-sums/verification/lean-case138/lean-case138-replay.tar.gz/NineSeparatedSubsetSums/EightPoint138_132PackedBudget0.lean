import NineSeparatedSubsetSums.EightPoint138_132PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct138_132_0_budget :
    FourPointNumeric.packedBudget 20 packedOct138_132_0 275 = 89525772 := by decide +kernel

#print axioms packedOct138_132_0_budget

end NineSeparatedSubsetSums
