import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive138Third104Node0 : CachedSearchNode :=
  ⟨4, 103, computeCenteredMask [148,138,104], 390, 51764⟩

end NineSeparatedSubsetSums
