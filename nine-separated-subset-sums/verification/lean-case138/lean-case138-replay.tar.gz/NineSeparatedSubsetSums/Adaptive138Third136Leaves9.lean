import NineSeparatedSubsetSums.Adaptive138Third136State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third136Proof70 : runCachedNode 511 128623 Adaptive138Third136Node70 = false := by
  decide +kernel

#print axioms adaptive138Third136Proof70

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third136Proof123 : runCachedNode 511 128623 Adaptive138Third136Node123 = false := by
  decide +kernel

#print axioms adaptive138Third136Proof123

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third136Proof14 : runCachedNode 511 128623 Adaptive138Third136Node14 = false := by
  decide +kernel

#print axioms adaptive138Third136Proof14

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third136Proof41 : runCachedNode 511 128623 Adaptive138Third136Node41 = false := by
  decide +kernel

#print axioms adaptive138Third136Proof41

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third136Proof122 : runCachedNode 511 128623 Adaptive138Third136Node122 = false := by
  decide +kernel

#print axioms adaptive138Third136Proof122

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third136Proof121 : runCachedNode 511 128623 Adaptive138Third136Node121 = false := by
  decide +kernel

#print axioms adaptive138Third136Proof121

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third136Proof94 : runCachedNode 511 128623 Adaptive138Third136Node94 = false := by
  decide +kernel

#print axioms adaptive138Third136Proof94

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third136Proof32 : runCachedNode 511 128623 Adaptive138Third136Node32 = false := by
  decide +kernel

#print axioms adaptive138Third136Proof32

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third136Proof23 : runCachedNode 511 128623 Adaptive138Third136Node23 = false := by
  decide +kernel

#print axioms adaptive138Third136Proof23

end NineSeparatedSubsetSums
