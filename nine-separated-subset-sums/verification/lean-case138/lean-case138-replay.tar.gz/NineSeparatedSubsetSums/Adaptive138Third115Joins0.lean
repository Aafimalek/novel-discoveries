import NineSeparatedSubsetSums.Adaptive138Third115State
import NineSeparatedSubsetSums.Adaptive138Third115Leaves1
import NineSeparatedSubsetSums.Adaptive138Third115Leaves0

namespace NineSeparatedSubsetSums

theorem adaptive138Third115Proof0 : runCachedNode 511 111079 Adaptive138Third115Node0 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 111079 Adaptive138Third115Node0 = [100, 101, 102, 103, 104, 106, 107, 108, 109, 110, 111, 112, 113, 114] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive138Third115Proof1
  · exact adaptive138Third115Proof2
  · exact adaptive138Third115Proof3
  · exact adaptive138Third115Proof4
  · exact adaptive138Third115Proof5
  · exact adaptive138Third115Proof6
  · exact adaptive138Third115Proof7
  · exact adaptive138Third115Proof8
  · exact adaptive138Third115Proof9
  · exact adaptive138Third115Proof10
  · exact adaptive138Third115Proof11
  · exact adaptive138Third115Proof12
  · exact adaptive138Third115Proof13
  · exact adaptive138Third115Proof14

#print axioms adaptive138Third115Proof0

end NineSeparatedSubsetSums
