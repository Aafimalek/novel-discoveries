import NineSeparatedSubsetSums.EightPoint138_132PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint138_132PackedAnchor1Part1 :
    ∀ j : Fin 120, 2423272 ≤ FourPointNumeric.octPackedCharge 138 132 20 packedOct138_132_1
      (2*((j.val : Int)+120)+1) := by decide +kernel

end NineSeparatedSubsetSums
