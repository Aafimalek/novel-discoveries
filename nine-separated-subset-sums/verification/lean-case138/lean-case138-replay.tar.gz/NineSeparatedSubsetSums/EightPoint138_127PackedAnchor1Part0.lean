import NineSeparatedSubsetSums.EightPoint138_127PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint138_127PackedAnchor1Part0 :
    ∀ j : Fin 120, 2349358 ≤ FourPointNumeric.octPackedCharge 138 127 20 packedOct138_127_1
      (2*((j.val : Int)+0)+0) := by decide +kernel

end NineSeparatedSubsetSums
