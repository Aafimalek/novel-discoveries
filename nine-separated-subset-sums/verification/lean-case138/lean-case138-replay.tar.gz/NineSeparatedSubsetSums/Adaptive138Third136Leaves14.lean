import NineSeparatedSubsetSums.Adaptive138Third136State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third136Proof131 : runCachedNode 511 128623 Adaptive138Third136Node131 = false := by
  decide +kernel

#print axioms adaptive138Third136Proof131

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third136Proof132 : runCachedNode 511 128623 Adaptive138Third136Node132 = false := by
  decide +kernel

#print axioms adaptive138Third136Proof132

end NineSeparatedSubsetSums
