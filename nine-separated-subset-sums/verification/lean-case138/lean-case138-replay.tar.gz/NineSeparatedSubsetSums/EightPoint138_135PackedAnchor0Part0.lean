import NineSeparatedSubsetSums.EightPoint138_135PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint138_135PackedAnchor0Part0 :
    ∀ j : Fin 120, 2461356 ≤ FourPointNumeric.octPackedCharge 138 135 20 packedOct138_135_0
      (2*((j.val : Int)+0)+1) := by decide +kernel

end NineSeparatedSubsetSums
