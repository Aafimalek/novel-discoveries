import NineSeparatedSubsetSums.Adaptive138Third131State
import NineSeparatedSubsetSums.Adaptive138Third131Leaves0
import NineSeparatedSubsetSums.Adaptive138Third131Leaves1
import NineSeparatedSubsetSums.Adaptive138Third131Leaves2
import NineSeparatedSubsetSums.Adaptive138Third131Leaves3

namespace NineSeparatedSubsetSums

theorem adaptive138Third131Proof0 : runCachedNode 511 127792 Adaptive138Third131Node0 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 127792 Adaptive138Third131Node0 = [111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 122, 123, 124, 125, 126, 127, 128, 129, 130] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive138Third131Proof1
  · exact adaptive138Third131Proof2
  · exact adaptive138Third131Proof3
  · exact adaptive138Third131Proof4
  · exact adaptive138Third131Proof5
  · exact adaptive138Third131Proof6
  · exact adaptive138Third131Proof7
  · exact adaptive138Third131Proof8
  · exact adaptive138Third131Proof9
  · exact adaptive138Third131Proof10
  · exact adaptive138Third131Proof11
  · exact adaptive138Third131Proof12
  · exact adaptive138Third131Proof13
  · exact adaptive138Third131Proof14
  · exact adaptive138Third131Proof15
  · exact adaptive138Third131Proof16
  · exact adaptive138Third131Proof17
  · exact adaptive138Third131Proof18
  · exact adaptive138Third131Proof19

#print axioms adaptive138Third131Proof0

end NineSeparatedSubsetSums
