import NineSeparatedSubsetSums.Adaptive138Third134State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third134Proof42 : runCachedNode 511 128232 Adaptive138Third134Node42 = false := by
  decide +kernel

#print axioms adaptive138Third134Proof42

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third134Proof26 : runCachedNode 511 128232 Adaptive138Third134Node26 = false := by
  decide +kernel

#print axioms adaptive138Third134Proof26

end NineSeparatedSubsetSums
