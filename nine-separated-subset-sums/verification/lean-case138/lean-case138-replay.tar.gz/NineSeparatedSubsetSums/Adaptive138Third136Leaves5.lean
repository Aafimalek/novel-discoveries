import NineSeparatedSubsetSums.Adaptive138Third136State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third136Proof19 : runCachedNode 511 128623 Adaptive138Third136Node19 = false := by
  decide +kernel

#print axioms adaptive138Third136Proof19

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third136Proof20 : runCachedNode 511 128623 Adaptive138Third136Node20 = false := by
  decide +kernel

#print axioms adaptive138Third136Proof20

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third136Proof8 : runCachedNode 511 128623 Adaptive138Third136Node8 = false := by
  decide +kernel

#print axioms adaptive138Third136Proof8

end NineSeparatedSubsetSums
