import NineSeparatedSubsetSums.EightPoint138_132PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct138_132_1_budget :
    FourPointNumeric.packedBudget 20 packedOct138_132_1 276 = 89567078 := by decide +kernel

#print axioms packedOct138_132_1_budget

end NineSeparatedSubsetSums
