import NineSeparatedSubsetSums.Adaptive138Third137State
import NineSeparatedSubsetSums.Adaptive138Third137Leaves2
import NineSeparatedSubsetSums.Adaptive138Third137Leaves15
import NineSeparatedSubsetSums.Adaptive138Third137Leaves11
import NineSeparatedSubsetSums.Adaptive138Third137Leaves8
import NineSeparatedSubsetSums.Adaptive138Third137Leaves14
import NineSeparatedSubsetSums.Adaptive138Third137Leaves13
import NineSeparatedSubsetSums.Adaptive138Third137Leaves12
import NineSeparatedSubsetSums.Adaptive138Third137Leaves10
import NineSeparatedSubsetSums.Adaptive138Third137Leaves7
import NineSeparatedSubsetSums.Adaptive138Third137Leaves1
import NineSeparatedSubsetSums.Adaptive138Third137Leaves5
import NineSeparatedSubsetSums.Adaptive138Third137Leaves4
import NineSeparatedSubsetSums.Adaptive138Third137Leaves3
import NineSeparatedSubsetSums.Adaptive138Third137Leaves9
import NineSeparatedSubsetSums.Adaptive138Third137Leaves0
import NineSeparatedSubsetSums.Adaptive138Third137Leaves6
import NineSeparatedSubsetSums.Adaptive138Third137Leaves16

namespace NineSeparatedSubsetSums

theorem adaptive138Third137Proof22 : runCachedNode 511 128810 Adaptive138Third137Node22 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 128810 Adaptive138Third137Node22 = [104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 123, 124, 125, 126, 128, 129, 130] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive138Third137Proof23
  · exact adaptive138Third137Proof24
  · exact adaptive138Third137Proof25
  · exact adaptive138Third137Proof26
  · exact adaptive138Third137Proof27
  · exact adaptive138Third137Proof28
  · exact adaptive138Third137Proof29
  · exact adaptive138Third137Proof30
  · exact adaptive138Third137Proof31
  · exact adaptive138Third137Proof32
  · exact adaptive138Third137Proof33
  · exact adaptive138Third137Proof34
  · exact adaptive138Third137Proof35
  · exact adaptive138Third137Proof36
  · exact adaptive138Third137Proof37
  · exact adaptive138Third137Proof38
  · exact adaptive138Third137Proof39
  · exact adaptive138Third137Proof40
  · exact adaptive138Third137Proof41
  · exact adaptive138Third137Proof42
  · exact adaptive138Third137Proof43
  · exact adaptive138Third137Proof44
  · exact adaptive138Third137Proof45
  · exact adaptive138Third137Proof46

#print axioms adaptive138Third137Proof22

theorem adaptive138Third137Proof47 : runCachedNode 511 128810 Adaptive138Third137Node47 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 128810 Adaptive138Third137Node47 = [104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 124, 125, 126, 128, 129, 130, 131] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive138Third137Proof48
  · exact adaptive138Third137Proof49
  · exact adaptive138Third137Proof50
  · exact adaptive138Third137Proof51
  · exact adaptive138Third137Proof52
  · exact adaptive138Third137Proof53
  · exact adaptive138Third137Proof54
  · exact adaptive138Third137Proof55
  · exact adaptive138Third137Proof56
  · exact adaptive138Third137Proof57
  · exact adaptive138Third137Proof58
  · exact adaptive138Third137Proof59
  · exact adaptive138Third137Proof60
  · exact adaptive138Third137Proof61
  · exact adaptive138Third137Proof62
  · exact adaptive138Third137Proof63
  · exact adaptive138Third137Proof64
  · exact adaptive138Third137Proof65
  · exact adaptive138Third137Proof66
  · exact adaptive138Third137Proof67
  · exact adaptive138Third137Proof68
  · exact adaptive138Third137Proof69
  · exact adaptive138Third137Proof70
  · exact adaptive138Third137Proof71
  · exact adaptive138Third137Proof72

#print axioms adaptive138Third137Proof47

theorem adaptive138Third137Proof73 : runCachedNode 511 128810 Adaptive138Third137Node73 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 128810 Adaptive138Third137Node73 = [104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 125, 126, 128, 129, 130, 131, 132] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive138Third137Proof74
  · exact adaptive138Third137Proof75
  · exact adaptive138Third137Proof76
  · exact adaptive138Third137Proof77
  · exact adaptive138Third137Proof78
  · exact adaptive138Third137Proof79
  · exact adaptive138Third137Proof80
  · exact adaptive138Third137Proof81
  · exact adaptive138Third137Proof82
  · exact adaptive138Third137Proof83
  · exact adaptive138Third137Proof84
  · exact adaptive138Third137Proof85
  · exact adaptive138Third137Proof86
  · exact adaptive138Third137Proof87
  · exact adaptive138Third137Proof88
  · exact adaptive138Third137Proof89
  · exact adaptive138Third137Proof90
  · exact adaptive138Third137Proof91
  · exact adaptive138Third137Proof92
  · exact adaptive138Third137Proof93
  · exact adaptive138Third137Proof94
  · exact adaptive138Third137Proof95
  · exact adaptive138Third137Proof96
  · exact adaptive138Third137Proof97
  · exact adaptive138Third137Proof98
  · exact adaptive138Third137Proof99

#print axioms adaptive138Third137Proof73

theorem adaptive138Third137Proof100 : runCachedNode 511 128810 Adaptive138Third137Node100 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 128810 Adaptive138Third137Node100 = [103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 126, 128, 129, 130, 131, 132, 133] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive138Third137Proof101
  · exact adaptive138Third137Proof102
  · exact adaptive138Third137Proof103
  · exact adaptive138Third137Proof104
  · exact adaptive138Third137Proof105
  · exact adaptive138Third137Proof106
  · exact adaptive138Third137Proof107
  · exact adaptive138Third137Proof108
  · exact adaptive138Third137Proof109
  · exact adaptive138Third137Proof110
  · exact adaptive138Third137Proof111
  · exact adaptive138Third137Proof112
  · exact adaptive138Third137Proof113
  · exact adaptive138Third137Proof114
  · exact adaptive138Third137Proof115
  · exact adaptive138Third137Proof116
  · exact adaptive138Third137Proof117
  · exact adaptive138Third137Proof118
  · exact adaptive138Third137Proof119
  · exact adaptive138Third137Proof120
  · exact adaptive138Third137Proof121
  · exact adaptive138Third137Proof122
  · exact adaptive138Third137Proof123
  · exact adaptive138Third137Proof124
  · exact adaptive138Third137Proof125
  · exact adaptive138Third137Proof126
  · exact adaptive138Third137Proof127
  · exact adaptive138Third137Proof128

#print axioms adaptive138Third137Proof100

theorem adaptive138Third137Proof158 : runCachedNode 511 128810 Adaptive138Third137Node158 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 128810 Adaptive138Third137Node158 = [92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 128, 130, 131] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive138Third137Proof159
  · exact adaptive138Third137Proof160
  · exact adaptive138Third137Proof161
  · exact adaptive138Third137Proof162
  · exact adaptive138Third137Proof163
  · exact adaptive138Third137Proof164
  · exact adaptive138Third137Proof165
  · exact adaptive138Third137Proof166
  · exact adaptive138Third137Proof167
  · exact adaptive138Third137Proof168
  · exact adaptive138Third137Proof169
  · exact adaptive138Third137Proof170
  · exact adaptive138Third137Proof171
  · exact adaptive138Third137Proof172
  · exact adaptive138Third137Proof173
  · exact adaptive138Third137Proof174
  · exact adaptive138Third137Proof175
  · exact adaptive138Third137Proof176
  · exact adaptive138Third137Proof177
  · exact adaptive138Third137Proof178
  · exact adaptive138Third137Proof179
  · exact adaptive138Third137Proof180
  · exact adaptive138Third137Proof181
  · exact adaptive138Third137Proof182
  · exact adaptive138Third137Proof183
  · exact adaptive138Third137Proof184
  · exact adaptive138Third137Proof185
  · exact adaptive138Third137Proof186
  · exact adaptive138Third137Proof187
  · exact adaptive138Third137Proof188
  · exact adaptive138Third137Proof189
  · exact adaptive138Third137Proof190

#print axioms adaptive138Third137Proof158

theorem adaptive138Third137Proof129 : runCachedNode 511 128810 Adaptive138Third137Node129 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 128810 Adaptive138Third137Node129 = [103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 128, 129, 130, 131, 132, 133, 134] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive138Third137Proof130
  · exact adaptive138Third137Proof131
  · exact adaptive138Third137Proof132
  · exact adaptive138Third137Proof133
  · exact adaptive138Third137Proof134
  · exact adaptive138Third137Proof135
  · exact adaptive138Third137Proof136
  · exact adaptive138Third137Proof137
  · exact adaptive138Third137Proof138
  · exact adaptive138Third137Proof139
  · exact adaptive138Third137Proof140
  · exact adaptive138Third137Proof141
  · exact adaptive138Third137Proof142
  · exact adaptive138Third137Proof143
  · exact adaptive138Third137Proof144
  · exact adaptive138Third137Proof145
  · exact adaptive138Third137Proof146
  · exact adaptive138Third137Proof147
  · exact adaptive138Third137Proof148
  · exact adaptive138Third137Proof149
  · exact adaptive138Third137Proof150
  · exact adaptive138Third137Proof151
  · exact adaptive138Third137Proof152
  · exact adaptive138Third137Proof153
  · exact adaptive138Third137Proof154
  · exact adaptive138Third137Proof155
  · exact adaptive138Third137Proof156
  · exact adaptive138Third137Proof157
  · exact adaptive138Third137Proof158

#print axioms adaptive138Third137Proof129

theorem adaptive138Third137Proof0 : runCachedNode 511 128810 Adaptive138Third137Node0 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 128810 Adaptive138Third137Node0 = [110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 128, 129, 130, 131, 132, 133, 134, 135, 136] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive138Third137Proof1
  · exact adaptive138Third137Proof2
  · exact adaptive138Third137Proof3
  · exact adaptive138Third137Proof4
  · exact adaptive138Third137Proof5
  · exact adaptive138Third137Proof6
  · exact adaptive138Third137Proof7
  · exact adaptive138Third137Proof8
  · exact adaptive138Third137Proof9
  · exact adaptive138Third137Proof10
  · exact adaptive138Third137Proof11
  · exact adaptive138Third137Proof12
  · exact adaptive138Third137Proof13
  · exact adaptive138Third137Proof14
  · exact adaptive138Third137Proof15
  · exact adaptive138Third137Proof16
  · exact adaptive138Third137Proof17
  · exact adaptive138Third137Proof18
  · exact adaptive138Third137Proof19
  · exact adaptive138Third137Proof20
  · exact adaptive138Third137Proof21
  · exact adaptive138Third137Proof22
  · exact adaptive138Third137Proof47
  · exact adaptive138Third137Proof73
  · exact adaptive138Third137Proof100
  · exact adaptive138Third137Proof129

#print axioms adaptive138Third137Proof0

end NineSeparatedSubsetSums
