import NineSeparatedSubsetSums.EightPoint138_130PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint138_130PackedAnchor0Part0 :
    ∀ j : Fin 120, 2401223 ≤ FourPointNumeric.octPackedCharge 138 130 20 packedOct138_130_0
      (2*((j.val : Int)+0)+0) := by decide +kernel

end NineSeparatedSubsetSums
