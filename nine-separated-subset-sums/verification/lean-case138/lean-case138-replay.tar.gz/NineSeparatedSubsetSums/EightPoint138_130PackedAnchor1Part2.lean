import NineSeparatedSubsetSums.EightPoint138_130PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint138_130PackedAnchor1Part2 :
    ∀ j : Fin 6, 2401124 ≤ FourPointNumeric.octPackedCharge 138 130 20 packedOct138_130_1
      (2*((j.val : Int)+240)+1) := by decide +kernel

end NineSeparatedSubsetSums
