import NineSeparatedSubsetSums.FourPointPackedGeometry
import NineSeparatedSubsetSums.FourPoint138PackedBudget0
import NineSeparatedSubsetSums.FourPoint138PackedAnchor0Part0
import NineSeparatedSubsetSums.FourPoint138PackedAnchor0Part1
import NineSeparatedSubsetSums.FourPoint138PackedBudget1
import NineSeparatedSubsetSums.FourPoint138PackedAnchor1Part0
import NineSeparatedSubsetSums.FourPoint138PackedAnchor1Part1

namespace NineSeparatedSubsetSums

private theorem packed138Anchor0 :
  ∀ j : Fin 468, ((j.val : Int)+138)%2=0 →
    1039008 ≤ FourPointNumeric.packedCharge 138 19 packedWeight138_0 (j.val : Int) := by
  intro j hj
  let k := (j.val-0)/2
  have hk : k < 234 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+0 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := fourPoint138PackedAnchor0Part0 z
    rwa [he,hrep] at ht
  let z : Fin 114 := ⟨k-120, by omega⟩
  have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
  have ht := fourPoint138PackedAnchor0Part1 z
  rwa [he,hrep] at ht

private theorem packed138Anchor1 :
  ∀ j : Fin 468, ((j.val : Int)+138)%2=1 →
    1038996 ≤ FourPointNumeric.packedCharge 138 19 packedWeight138_1 (j.val : Int) := by
  intro j hj
  let k := (j.val-1)/2
  have hk : k < 234 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+1 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := fourPoint138PackedAnchor1Part0 z
    rwa [he,hrep] at ht
  let z : Fin 114 := ⟨k-120, by omega⟩
  have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
  have ht := fourPoint138PackedAnchor1Part1 z
  rwa [he,hrep] at ht

def packedCertificate138_0 : FourPointCertificate 138 0 111079 :=
  fourPointCertificateOfPacked 138 0 111079 1039008 19 packedWeight138_0 367 468
    (by decide +kernel) (by decide) (by decide) packed138Anchor0
    (by rw [packedWeight138_0_budget]; decide)

def packedCertificate138_1 : FourPointCertificate 138 1 111079 :=
  fourPointCertificateOfPacked 138 1 111079 1038996 19 packedWeight138_1 372 468
    (by decide +kernel) (by decide) (by decide) packed138Anchor1
    (by rw [packedWeight138_1_budget]; decide)

theorem max148_second138_fourPoint_moment_bound (tail : List ℕ) (len : tail.length=7)
    (distinct : (natSubsetSums (148::138::tail)).Nodup) :
    111079 ≤ ((148::138::tail).map (· ^ 2)).sum := by
  apply fourPointNatMomentLower 138 111079 tail len distinct
  intro p hp
  by_cases h : p=0
  · subst p
    exact packedCertificate138_0
  · have he : p=1 := hp.resolve_left h
    subst p
    exact packedCertificate138_1

#print axioms max148_second138_fourPoint_moment_bound

end NineSeparatedSubsetSums
