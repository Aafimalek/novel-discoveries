import NineSeparatedSubsetSums.FourPoint138PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem fourPoint138PackedAnchor1Part1 :
    ∀ j : Fin 114, 1038996 ≤ FourPointNumeric.packedCharge 138 19 packedWeight138_1
      (2*((j.val : Int)+120)+1) := by decide +kernel

end NineSeparatedSubsetSums
