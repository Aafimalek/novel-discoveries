import NineSeparatedSubsetSums.Adaptive138Third115State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third115Proof14 : runCachedNode 511 111079 Adaptive138Third115Node14 = false := by
  decide +kernel

#print axioms adaptive138Third115Proof14

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third115Proof13 : runCachedNode 511 111079 Adaptive138Third115Node13 = false := by
  decide +kernel

#print axioms adaptive138Third115Proof13

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third115Proof12 : runCachedNode 511 111079 Adaptive138Third115Node12 = false := by
  decide +kernel

#print axioms adaptive138Third115Proof12

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third115Proof11 : runCachedNode 511 111079 Adaptive138Third115Node11 = false := by
  decide +kernel

#print axioms adaptive138Third115Proof11

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third115Proof9 : runCachedNode 511 111079 Adaptive138Third115Node9 = false := by
  decide +kernel

#print axioms adaptive138Third115Proof9

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third115Proof5 : runCachedNode 511 111079 Adaptive138Third115Node5 = false := by
  decide +kernel

#print axioms adaptive138Third115Proof5

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third115Proof2 : runCachedNode 511 111079 Adaptive138Third115Node2 = false := by
  decide +kernel

#print axioms adaptive138Third115Proof2

end NineSeparatedSubsetSums
