import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive138Third107Node0 : CachedSearchNode :=
  ⟨4, 106, computeCenteredMask [148,138,107], 393, 52397⟩

end NineSeparatedSubsetSums
