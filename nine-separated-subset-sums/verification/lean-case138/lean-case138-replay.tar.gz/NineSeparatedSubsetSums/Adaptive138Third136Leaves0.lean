import NineSeparatedSubsetSums.Adaptive138Third136State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third136Proof97 : runCachedNode 511 128623 Adaptive138Third136Node97 = false := by
  decide +kernel

#print axioms adaptive138Third136Proof97

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third136Proof11 : runCachedNode 511 128623 Adaptive138Third136Node11 = false := by
  decide +kernel

#print axioms adaptive138Third136Proof11

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third136Proof26 : runCachedNode 511 128623 Adaptive138Third136Node26 = false := by
  decide +kernel

#print axioms adaptive138Third136Proof26

end NineSeparatedSubsetSums
