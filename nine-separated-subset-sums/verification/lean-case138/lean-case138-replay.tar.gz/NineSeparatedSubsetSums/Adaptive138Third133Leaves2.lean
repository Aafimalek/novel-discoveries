import NineSeparatedSubsetSums.Adaptive138Third133State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third133Proof19 : runCachedNode 511 128072 Adaptive138Third133Node19 = false := by
  decide +kernel

#print axioms adaptive138Third133Proof19

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third133Proof42 : runCachedNode 511 128072 Adaptive138Third133Node42 = false := by
  decide +kernel

#print axioms adaptive138Third133Proof42

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third133Proof11 : runCachedNode 511 128072 Adaptive138Third133Node11 = false := by
  decide +kernel

#print axioms adaptive138Third133Proof11

end NineSeparatedSubsetSums
