import NineSeparatedSubsetSums.Adaptive138Third129State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third129Proof17 : runCachedNode 511 127319 Adaptive138Third129Node17 = false := by
  decide +kernel

#print axioms adaptive138Third129Proof17

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third129Proof16 : runCachedNode 511 127319 Adaptive138Third129Node16 = false := by
  decide +kernel

#print axioms adaptive138Third129Proof16

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third129Proof10 : runCachedNode 511 127319 Adaptive138Third129Node10 = false := by
  decide +kernel

#print axioms adaptive138Third129Proof10

end NineSeparatedSubsetSums
