import NineSeparatedSubsetSums.Adaptive138Third116State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third116Proof15 : runCachedNode 511 111079 Adaptive138Third116Node15 = false := by
  decide +kernel

#print axioms adaptive138Third116Proof15

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third116Proof14 : runCachedNode 511 111079 Adaptive138Third116Node14 = false := by
  decide +kernel

#print axioms adaptive138Third116Proof14

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third116Proof13 : runCachedNode 511 111079 Adaptive138Third116Node13 = false := by
  decide +kernel

#print axioms adaptive138Third116Proof13

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third116Proof7 : runCachedNode 511 111079 Adaptive138Third116Node7 = false := by
  decide +kernel

#print axioms adaptive138Third116Proof7

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third116Proof4 : runCachedNode 511 111079 Adaptive138Third116Node4 = false := by
  decide +kernel

#print axioms adaptive138Third116Proof4

end NineSeparatedSubsetSums
