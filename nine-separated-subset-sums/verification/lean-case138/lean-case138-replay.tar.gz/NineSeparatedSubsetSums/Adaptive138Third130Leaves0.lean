import NineSeparatedSubsetSums.Adaptive138Third130State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third130Proof17 : runCachedNode 511 127551 Adaptive138Third130Node17 = false := by
  decide +kernel

#print axioms adaptive138Third130Proof17

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third130Proof16 : runCachedNode 511 127551 Adaptive138Third130Node16 = false := by
  decide +kernel

#print axioms adaptive138Third130Proof16

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third130Proof8 : runCachedNode 511 127551 Adaptive138Third130Node8 = false := by
  decide +kernel

#print axioms adaptive138Third130Proof8

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third130Proof3 : runCachedNode 511 127551 Adaptive138Third130Node3 = false := by
  decide +kernel

#print axioms adaptive138Third130Proof3

end NineSeparatedSubsetSums
