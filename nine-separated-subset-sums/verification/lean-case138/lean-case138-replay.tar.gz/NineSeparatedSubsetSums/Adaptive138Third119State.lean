import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive138Third119Node0 : CachedSearchNode :=
  ⟨4, 118, computeCenteredMask [148,138,119], 405, 55109⟩

end NineSeparatedSubsetSums
