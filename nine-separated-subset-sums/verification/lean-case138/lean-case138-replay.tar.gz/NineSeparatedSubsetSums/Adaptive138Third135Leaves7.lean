import NineSeparatedSubsetSums.Adaptive138Third135State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third135Proof94 : runCachedNode 511 128437 Adaptive138Third135Node94 = false := by
  decide +kernel

#print axioms adaptive138Third135Proof94

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third135Proof12 : runCachedNode 511 128437 Adaptive138Third135Node12 = false := by
  decide +kernel

#print axioms adaptive138Third135Proof12

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third135Proof68 : runCachedNode 511 128437 Adaptive138Third135Node68 = false := by
  decide +kernel

#print axioms adaptive138Third135Proof68

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third135Proof93 : runCachedNode 511 128437 Adaptive138Third135Node93 = false := by
  decide +kernel

#print axioms adaptive138Third135Proof93

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third135Proof41 : runCachedNode 511 128437 Adaptive138Third135Node41 = false := by
  decide +kernel

#print axioms adaptive138Third135Proof41

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third135Proof91 : runCachedNode 511 128437 Adaptive138Third135Node91 = false := by
  decide +kernel

#print axioms adaptive138Third135Proof91

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third135Proof11 : runCachedNode 511 128437 Adaptive138Third135Node11 = false := by
  decide +kernel

#print axioms adaptive138Third135Proof11

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third135Proof65 : runCachedNode 511 128437 Adaptive138Third135Node65 = false := by
  decide +kernel

#print axioms adaptive138Third135Proof65

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third135Proof40 : runCachedNode 511 128437 Adaptive138Third135Node40 = false := by
  decide +kernel

#print axioms adaptive138Third135Proof40

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third135Proof92 : runCachedNode 511 128437 Adaptive138Third135Node92 = false := by
  decide +kernel

#print axioms adaptive138Third135Proof92

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third135Proof10 : runCachedNode 511 128437 Adaptive138Third135Node10 = false := by
  decide +kernel

#print axioms adaptive138Third135Proof10

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third135Proof90 : runCachedNode 511 128437 Adaptive138Third135Node90 = false := by
  decide +kernel

#print axioms adaptive138Third135Proof90

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third135Proof67 : runCachedNode 511 128437 Adaptive138Third135Node67 = false := by
  decide +kernel

#print axioms adaptive138Third135Proof67

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third135Proof39 : runCachedNode 511 128437 Adaptive138Third135Node39 = false := by
  decide +kernel

#print axioms adaptive138Third135Proof39

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third135Proof38 : runCachedNode 511 128437 Adaptive138Third135Node38 = false := by
  decide +kernel

#print axioms adaptive138Third135Proof38

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third135Proof8 : runCachedNode 511 128437 Adaptive138Third135Node8 = false := by
  decide +kernel

#print axioms adaptive138Third135Proof8

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third135Proof35 : runCachedNode 511 128437 Adaptive138Third135Node35 = false := by
  decide +kernel

#print axioms adaptive138Third135Proof35

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third135Proof59 : runCachedNode 511 128437 Adaptive138Third135Node59 = false := by
  decide +kernel

#print axioms adaptive138Third135Proof59

end NineSeparatedSubsetSums
