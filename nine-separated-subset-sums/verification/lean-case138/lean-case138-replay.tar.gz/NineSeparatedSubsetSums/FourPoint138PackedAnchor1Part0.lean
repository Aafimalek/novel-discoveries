import NineSeparatedSubsetSums.FourPoint138PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem fourPoint138PackedAnchor1Part0 :
    ∀ j : Fin 120, 1038996 ≤ FourPointNumeric.packedCharge 138 19 packedWeight138_1
      (2*((j.val : Int)+0)+1) := by decide +kernel

end NineSeparatedSubsetSums
