import NineSeparatedSubsetSums.Adaptive138Third132State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third132Proof15 : runCachedNode 511 127973 Adaptive138Third132Node15 = false := by
  decide +kernel

#print axioms adaptive138Third132Proof15

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third132Proof5 : runCachedNode 511 127973 Adaptive138Third132Node5 = false := by
  decide +kernel

#print axioms adaptive138Third132Proof5

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third132Proof4 : runCachedNode 511 127973 Adaptive138Third132Node4 = false := by
  decide +kernel

#print axioms adaptive138Third132Proof4

end NineSeparatedSubsetSums
