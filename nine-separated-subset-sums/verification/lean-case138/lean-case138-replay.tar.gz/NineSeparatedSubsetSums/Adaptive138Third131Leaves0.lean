import NineSeparatedSubsetSums.Adaptive138Third131State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third131Proof17 : runCachedNode 511 127792 Adaptive138Third131Node17 = false := by
  decide +kernel

#print axioms adaptive138Third131Proof17

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third131Proof16 : runCachedNode 511 127792 Adaptive138Third131Node16 = false := by
  decide +kernel

#print axioms adaptive138Third131Proof16

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third131Proof6 : runCachedNode 511 127792 Adaptive138Third131Node6 = false := by
  decide +kernel

#print axioms adaptive138Third131Proof6

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third131Proof1 : runCachedNode 511 127792 Adaptive138Third131Node1 = false := by
  decide +kernel

#print axioms adaptive138Third131Proof1

end NineSeparatedSubsetSums
