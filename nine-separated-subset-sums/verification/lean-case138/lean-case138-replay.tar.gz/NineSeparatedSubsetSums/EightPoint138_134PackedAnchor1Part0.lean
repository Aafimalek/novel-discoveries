import NineSeparatedSubsetSums.EightPoint138_134PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint138_134PackedAnchor1Part0 :
    ∀ j : Fin 120, 2423428 ≤ FourPointNumeric.octPackedCharge 138 134 20 packedOct138_134_1
      (2*((j.val : Int)+0)+1) := by decide +kernel

end NineSeparatedSubsetSums
