import NineSeparatedSubsetSums.EightPoint138_120PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct138_120_1_budget :
    FourPointNumeric.packedBudget 20 packedOct138_120_1 268 = 84381610 := by decide +kernel

#print axioms packedOct138_120_1_budget

end NineSeparatedSubsetSums
