import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive138Third120Node0 : CachedSearchNode :=
  ⟨4, 119, computeCenteredMask [148,138,120], 406, 55348⟩

end NineSeparatedSubsetSums
