import NineSeparatedSubsetSums.Adaptive138Third106State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third106Proof0 : runCachedNode 511 111079 Adaptive138Third106Node0 = false := by
  decide +kernel

#print axioms adaptive138Third106Proof0

end NineSeparatedSubsetSums
