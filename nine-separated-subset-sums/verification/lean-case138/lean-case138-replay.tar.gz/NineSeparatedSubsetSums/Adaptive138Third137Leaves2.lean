import NineSeparatedSubsetSums.Adaptive138Third137State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third137Proof20 : runCachedNode 511 128810 Adaptive138Third137Node20 = false := by
  decide +kernel

#print axioms adaptive138Third137Proof20

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third137Proof127 : runCachedNode 511 128810 Adaptive138Third137Node127 = false := by
  decide +kernel

#print axioms adaptive138Third137Proof127

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third137Proof23 : runCachedNode 511 128810 Adaptive138Third137Node23 = false := by
  decide +kernel

#print axioms adaptive138Third137Proof23

end NineSeparatedSubsetSums
