import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive138Third131Node0 : CachedSearchNode :=
  ⟨4, 130, computeCenteredMask [148,138,131], 417, 58109⟩
def Adaptive138Third131Node1 : CachedSearchNode := cachedChild Adaptive138Third131Node0 111
def Adaptive138Third131Node2 : CachedSearchNode := cachedChild Adaptive138Third131Node0 112
def Adaptive138Third131Node3 : CachedSearchNode := cachedChild Adaptive138Third131Node0 113
def Adaptive138Third131Node4 : CachedSearchNode := cachedChild Adaptive138Third131Node0 114
def Adaptive138Third131Node5 : CachedSearchNode := cachedChild Adaptive138Third131Node0 115
def Adaptive138Third131Node6 : CachedSearchNode := cachedChild Adaptive138Third131Node0 116
def Adaptive138Third131Node7 : CachedSearchNode := cachedChild Adaptive138Third131Node0 117
def Adaptive138Third131Node8 : CachedSearchNode := cachedChild Adaptive138Third131Node0 118
def Adaptive138Third131Node9 : CachedSearchNode := cachedChild Adaptive138Third131Node0 119
def Adaptive138Third131Node10 : CachedSearchNode := cachedChild Adaptive138Third131Node0 120
def Adaptive138Third131Node11 : CachedSearchNode := cachedChild Adaptive138Third131Node0 122
def Adaptive138Third131Node12 : CachedSearchNode := cachedChild Adaptive138Third131Node0 123
def Adaptive138Third131Node13 : CachedSearchNode := cachedChild Adaptive138Third131Node0 124
def Adaptive138Third131Node14 : CachedSearchNode := cachedChild Adaptive138Third131Node0 125
def Adaptive138Third131Node15 : CachedSearchNode := cachedChild Adaptive138Third131Node0 126
def Adaptive138Third131Node16 : CachedSearchNode := cachedChild Adaptive138Third131Node0 127
def Adaptive138Third131Node17 : CachedSearchNode := cachedChild Adaptive138Third131Node0 128
def Adaptive138Third131Node18 : CachedSearchNode := cachedChild Adaptive138Third131Node0 129
def Adaptive138Third131Node19 : CachedSearchNode := cachedChild Adaptive138Third131Node0 130

end NineSeparatedSubsetSums
