import NineSeparatedSubsetSums.Adaptive138Third107Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint138Checked

namespace NineSeparatedSubsetSums


theorem adaptive138Third107 : NoDescendingTailAfterThird 138 107 :=
  noDescendingThirdTail_of_cached 138 107 111079 (fun t ht nd => max148_second138_fourPoint_moment_bound (107::t) (by simp [ht]) nd) adaptive138Third107Proof0

#print axioms adaptive138Third107

end NineSeparatedSubsetSums
