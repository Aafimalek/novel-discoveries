import NineSeparatedSubsetSums.EightPoint138_132PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint138_132PackedAnchor0Part2 :
    ∀ j : Fin 8, 2422624 ≤ FourPointNumeric.octPackedCharge 138 132 20 packedOct138_132_0
      (2*((j.val : Int)+240)+0) := by decide +kernel

end NineSeparatedSubsetSums
