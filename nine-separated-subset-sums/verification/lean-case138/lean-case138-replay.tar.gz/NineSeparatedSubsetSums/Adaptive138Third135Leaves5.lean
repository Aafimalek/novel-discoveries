import NineSeparatedSubsetSums.Adaptive138Third135State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third135Proof46 : runCachedNode 511 128437 Adaptive138Third135Node46 = false := by
  decide +kernel

#print axioms adaptive138Third135Proof46

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third135Proof97 : runCachedNode 511 128437 Adaptive138Third135Node97 = false := by
  decide +kernel

#print axioms adaptive138Third135Proof97

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third135Proof16 : runCachedNode 511 128437 Adaptive138Third135Node16 = false := by
  decide +kernel

#print axioms adaptive138Third135Proof16

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third135Proof15 : runCachedNode 511 128437 Adaptive138Third135Node15 = false := by
  decide +kernel

#print axioms adaptive138Third135Proof15

end NineSeparatedSubsetSums
