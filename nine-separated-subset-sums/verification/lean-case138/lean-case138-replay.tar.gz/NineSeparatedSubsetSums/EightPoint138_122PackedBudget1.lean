import NineSeparatedSubsetSums.EightPoint138_122PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct138_122_1_budget :
    FourPointNumeric.packedBudget 20 packedOct138_122_1 466 = 81943124 := by decide +kernel

#print axioms packedOct138_122_1_budget

end NineSeparatedSubsetSums
