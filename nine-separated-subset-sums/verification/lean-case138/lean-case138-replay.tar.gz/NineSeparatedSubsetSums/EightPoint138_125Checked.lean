import NineSeparatedSubsetSums.EightPointPackedGeometry
import NineSeparatedSubsetSums.EightPoint138_125PackedBudget0
import NineSeparatedSubsetSums.EightPoint138_125PackedAnchor0Part0
import NineSeparatedSubsetSums.EightPoint138_125PackedAnchor0Part1
import NineSeparatedSubsetSums.EightPoint138_125PackedAnchor0Part2
import NineSeparatedSubsetSums.EightPoint138_125PackedBudget1
import NineSeparatedSubsetSums.EightPoint138_125PackedAnchor1Part0
import NineSeparatedSubsetSums.EightPoint138_125PackedAnchor1Part1
import NineSeparatedSubsetSums.EightPoint138_125PackedAnchor1Part2

namespace NineSeparatedSubsetSums

private theorem packedOct138_125Anchor0 :
  ∀ j : Fin 483, ((j.val : Int)+138+125)%2=0 →
    2314955 ≤ FourPointNumeric.octPackedCharge 138 125 20 packedOct138_125_0 (j.val : Int) := by
  intro j hj
  let k := (j.val-1)/2
  have hk : k < 241 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+1 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint138_125PackedAnchor0Part0 z
    rwa [he,hrep] at ht
  by_cases h1 : k < 240
  · let z : Fin 120 := ⟨k-120, by omega⟩
    have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
    have ht := eightPoint138_125PackedAnchor0Part1 z
    rwa [he,hrep] at ht
  let z : Fin 1 := ⟨k-240, by omega⟩
  have he : (z.val : Int)+240 = k := by dsimp [z] <;> omega
  have ht := eightPoint138_125PackedAnchor0Part2 z
  rwa [he,hrep] at ht

private theorem packedOct138_125Anchor1 :
  ∀ j : Fin 483, ((j.val : Int)+138+125)%2=1 →
    2314930 ≤ FourPointNumeric.octPackedCharge 138 125 20 packedOct138_125_1 (j.val : Int) := by
  intro j hj
  let k := (j.val-0)/2
  have hk : k < 242 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+0 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint138_125PackedAnchor1Part0 z
    rwa [he,hrep] at ht
  by_cases h1 : k < 240
  · let z : Fin 120 := ⟨k-120, by omega⟩
    have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
    have ht := eightPoint138_125PackedAnchor1Part1 z
    rwa [he,hrep] at ht
  let z : Fin 2 := ⟨k-240, by omega⟩
  have he : (z.val : Int)+240 = k := by dsimp [z] <;> omega
  have ht := eightPoint138_125PackedAnchor1Part2 z
  rwa [he,hrep] at ht

def packedOctCertificate138_125_0 : EightPointCertificate 138 125 0 126666 :=
  eightPointCertificateOfPacked 138 125 0 126666 2314955 20 packedOct138_125_0 489 483
    (by decide +kernel) (by decide) packedOct138_125Anchor0
    (by rw [packedOct138_125_0_budget]; decide)

def packedOctCertificate138_125_1 : EightPointCertificate 138 125 1 126666 :=
  eightPointCertificateOfPacked 138 125 1 126666 2314930 20 packedOct138_125_1 492 483
    (by decide +kernel) (by decide) packedOct138_125Anchor1
    (by rw [packedOct138_125_1_budget]; decide)

theorem max148_second138_third125_eightPoint_moment_bound (tail : List ℕ) (len : tail.length=6)
    (distinct : (natSubsetSums (148::138::125::tail)).Nodup) :
    126666 ≤ ((148::138::125::tail).map (· ^ 2)).sum := by
  apply eightPointNatMomentLower 138 125 126666 tail len distinct
  intro p hp
  by_cases h : p=0
  · subst p
    exact packedOctCertificate138_125_0
  · have he : p=1 := hp.resolve_left h
    subst p
    exact packedOctCertificate138_125_1

#print axioms max148_second138_third125_eightPoint_moment_bound

end NineSeparatedSubsetSums
