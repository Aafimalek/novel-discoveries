import NineSeparatedSubsetSums.EightPoint138_129PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint138_129PackedAnchor1Part1 :
    ∀ j : Fin 120, 2373305 ≤ FourPointNumeric.octPackedCharge 138 129 20 packedOct138_129_1
      (2*((j.val : Int)+120)+0) := by decide +kernel

end NineSeparatedSubsetSums
