import NineSeparatedSubsetSums.EightPoint138_137PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint138_137PackedAnchor0Part2 :
    ∀ j : Fin 9, 2465141 ≤ FourPointNumeric.octPackedCharge 138 137 20 packedOct138_137_0
      (2*((j.val : Int)+240)+1) := by decide +kernel

end NineSeparatedSubsetSums
