import NineSeparatedSubsetSums.EightPoint138_134PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint138_134PackedAnchor0Part1 :
    ∀ j : Fin 120, 2425167 ≤ FourPointNumeric.octPackedCharge 138 134 20 packedOct138_134_0
      (2*((j.val : Int)+120)+0) := by decide +kernel

end NineSeparatedSubsetSums
