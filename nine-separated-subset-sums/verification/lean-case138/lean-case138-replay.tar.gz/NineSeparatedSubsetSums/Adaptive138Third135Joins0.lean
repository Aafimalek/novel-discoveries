import NineSeparatedSubsetSums.Adaptive138Third135State
import NineSeparatedSubsetSums.Adaptive138Third135Leaves9
import NineSeparatedSubsetSums.Adaptive138Third135Leaves8
import NineSeparatedSubsetSums.Adaptive138Third135Leaves7
import NineSeparatedSubsetSums.Adaptive138Third135Leaves6
import NineSeparatedSubsetSums.Adaptive138Third135Leaves4
import NineSeparatedSubsetSums.Adaptive138Third135Leaves5
import NineSeparatedSubsetSums.Adaptive138Third135Leaves1
import NineSeparatedSubsetSums.Adaptive138Third135Leaves3
import NineSeparatedSubsetSums.Adaptive138Third135Leaves0
import NineSeparatedSubsetSums.Adaptive138Third135Leaves2

namespace NineSeparatedSubsetSums

theorem adaptive138Third135Proof22 : runCachedNode 511 128437 Adaptive138Third135Node22 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 128437 Adaptive138Third135Node22 = [104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 120, 121, 123, 124, 126, 127, 128, 130, 131] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive138Third135Proof23
  · exact adaptive138Third135Proof24
  · exact adaptive138Third135Proof25
  · exact adaptive138Third135Proof26
  · exact adaptive138Third135Proof27
  · exact adaptive138Third135Proof28
  · exact adaptive138Third135Proof29
  · exact adaptive138Third135Proof30
  · exact adaptive138Third135Proof31
  · exact adaptive138Third135Proof32
  · exact adaptive138Third135Proof33
  · exact adaptive138Third135Proof34
  · exact adaptive138Third135Proof35
  · exact adaptive138Third135Proof36
  · exact adaptive138Third135Proof37
  · exact adaptive138Third135Proof38
  · exact adaptive138Third135Proof39
  · exact adaptive138Third135Proof40
  · exact adaptive138Third135Proof41
  · exact adaptive138Third135Proof42
  · exact adaptive138Third135Proof43
  · exact adaptive138Third135Proof44
  · exact adaptive138Third135Proof45
  · exact adaptive138Third135Proof46

#print axioms adaptive138Third135Proof22

theorem adaptive138Third135Proof47 : runCachedNode 511 128437 Adaptive138Third135Node47 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 128437 Adaptive138Third135Node47 = [104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 121, 122, 124, 126, 127, 128, 129, 131, 132] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive138Third135Proof48
  · exact adaptive138Third135Proof49
  · exact adaptive138Third135Proof50
  · exact adaptive138Third135Proof51
  · exact adaptive138Third135Proof52
  · exact adaptive138Third135Proof53
  · exact adaptive138Third135Proof54
  · exact adaptive138Third135Proof55
  · exact adaptive138Third135Proof56
  · exact adaptive138Third135Proof57
  · exact adaptive138Third135Proof58
  · exact adaptive138Third135Proof59
  · exact adaptive138Third135Proof60
  · exact adaptive138Third135Proof61
  · exact adaptive138Third135Proof62
  · exact adaptive138Third135Proof63
  · exact adaptive138Third135Proof64
  · exact adaptive138Third135Proof65
  · exact adaptive138Third135Proof66
  · exact adaptive138Third135Proof67
  · exact adaptive138Third135Proof68
  · exact adaptive138Third135Proof69
  · exact adaptive138Third135Proof70
  · exact adaptive138Third135Proof71
  · exact adaptive138Third135Proof72

#print axioms adaptive138Third135Proof47

theorem adaptive138Third135Proof73 : runCachedNode 511 128437 Adaptive138Third135Node73 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 128437 Adaptive138Third135Node73 = [104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 122, 123, 126, 127, 128, 129, 130, 132, 133] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive138Third135Proof74
  · exact adaptive138Third135Proof75
  · exact adaptive138Third135Proof76
  · exact adaptive138Third135Proof77
  · exact adaptive138Third135Proof78
  · exact adaptive138Third135Proof79
  · exact adaptive138Third135Proof80
  · exact adaptive138Third135Proof81
  · exact adaptive138Third135Proof82
  · exact adaptive138Third135Proof83
  · exact adaptive138Third135Proof84
  · exact adaptive138Third135Proof85
  · exact adaptive138Third135Proof86
  · exact adaptive138Third135Proof87
  · exact adaptive138Third135Proof88
  · exact adaptive138Third135Proof89
  · exact adaptive138Third135Proof90
  · exact adaptive138Third135Proof91
  · exact adaptive138Third135Proof92
  · exact adaptive138Third135Proof93
  · exact adaptive138Third135Proof94
  · exact adaptive138Third135Proof95
  · exact adaptive138Third135Proof96
  · exact adaptive138Third135Proof97
  · exact adaptive138Third135Proof98
  · exact adaptive138Third135Proof99

#print axioms adaptive138Third135Proof73

theorem adaptive138Third135Proof0 : runCachedNode 511 128437 Adaptive138Third135Node0 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 128437 Adaptive138Third135Node0 = [110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 126, 127, 128, 129, 130, 131, 132, 133, 134] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive138Third135Proof1
  · exact adaptive138Third135Proof2
  · exact adaptive138Third135Proof3
  · exact adaptive138Third135Proof4
  · exact adaptive138Third135Proof5
  · exact adaptive138Third135Proof6
  · exact adaptive138Third135Proof7
  · exact adaptive138Third135Proof8
  · exact adaptive138Third135Proof9
  · exact adaptive138Third135Proof10
  · exact adaptive138Third135Proof11
  · exact adaptive138Third135Proof12
  · exact adaptive138Third135Proof13
  · exact adaptive138Third135Proof14
  · exact adaptive138Third135Proof15
  · exact adaptive138Third135Proof16
  · exact adaptive138Third135Proof17
  · exact adaptive138Third135Proof18
  · exact adaptive138Third135Proof19
  · exact adaptive138Third135Proof20
  · exact adaptive138Third135Proof21
  · exact adaptive138Third135Proof22
  · exact adaptive138Third135Proof47
  · exact adaptive138Third135Proof73

#print axioms adaptive138Third135Proof0

end NineSeparatedSubsetSums
