import NineSeparatedSubsetSums.EightPoint138_133PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint138_133PackedAnchor1Part2 :
    ∀ j : Fin 7, 2412193 ≤ FourPointNumeric.octPackedCharge 138 133 20 packedOct138_133_1
      (2*((j.val : Int)+240)+0) := by decide +kernel

end NineSeparatedSubsetSums
