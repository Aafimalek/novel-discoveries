import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive138Third112Node0 : CachedSearchNode :=
  ⟨4, 111, computeCenteredMask [148,138,112], 398, 53492⟩

end NineSeparatedSubsetSums
