import NineSeparatedSubsetSums.EightPoint138_133PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint138_133PackedAnchor0Part0 :
    ∀ j : Fin 120, 2411801 ≤ FourPointNumeric.octPackedCharge 138 133 20 packedOct138_133_0
      (2*((j.val : Int)+0)+1) := by decide +kernel

end NineSeparatedSubsetSums
