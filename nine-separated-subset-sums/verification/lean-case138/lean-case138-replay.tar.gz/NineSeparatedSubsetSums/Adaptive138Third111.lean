import NineSeparatedSubsetSums.Adaptive138Third111Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint138Checked

namespace NineSeparatedSubsetSums


theorem adaptive138Third111 : NoDescendingTailAfterThird 138 111 :=
  noDescendingThirdTail_of_cached 138 111 111079 (fun t ht nd => max148_second138_fourPoint_moment_bound (111::t) (by simp [ht]) nd) adaptive138Third111Proof0

#print axioms adaptive138Third111

end NineSeparatedSubsetSums
