import NineSeparatedSubsetSums.Adaptive138Third137State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third137Proof95 : runCachedNode 511 128810 Adaptive138Third137Node95 = false := by
  decide +kernel

#print axioms adaptive138Third137Proof95

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third137Proof43 : runCachedNode 511 128810 Adaptive138Third137Node43 = false := by
  decide +kernel

#print axioms adaptive138Third137Proof43

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third137Proof122 : runCachedNode 511 128810 Adaptive138Third137Node122 = false := by
  decide +kernel

#print axioms adaptive138Third137Proof122

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third137Proof71 : runCachedNode 511 128810 Adaptive138Third137Node71 = false := by
  decide +kernel

#print axioms adaptive138Third137Proof71

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third137Proof14 : runCachedNode 511 128810 Adaptive138Third137Node14 = false := by
  decide +kernel

#print axioms adaptive138Third137Proof14

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third137Proof70 : runCachedNode 511 128810 Adaptive138Third137Node70 = false := by
  decide +kernel

#print axioms adaptive138Third137Proof70

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third137Proof121 : runCachedNode 511 128810 Adaptive138Third137Node121 = false := by
  decide +kernel

#print axioms adaptive138Third137Proof121

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third137Proof2 : runCachedNode 511 128810 Adaptive138Third137Node2 = false := by
  decide +kernel

#print axioms adaptive138Third137Proof2

end NineSeparatedSubsetSums
