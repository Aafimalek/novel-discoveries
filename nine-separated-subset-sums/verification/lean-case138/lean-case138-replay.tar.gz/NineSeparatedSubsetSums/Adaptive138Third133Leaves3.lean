import NineSeparatedSubsetSums.Adaptive138Third133State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third133Proof18 : runCachedNode 511 128072 Adaptive138Third133Node18 = false := by
  decide +kernel

#print axioms adaptive138Third133Proof18

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third133Proof16 : runCachedNode 511 128072 Adaptive138Third133Node16 = false := by
  decide +kernel

#print axioms adaptive138Third133Proof16

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third133Proof15 : runCachedNode 511 128072 Adaptive138Third133Node15 = false := by
  decide +kernel

#print axioms adaptive138Third133Proof15

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third133Proof12 : runCachedNode 511 128072 Adaptive138Third133Node12 = false := by
  decide +kernel

#print axioms adaptive138Third133Proof12

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third133Proof30 : runCachedNode 511 128072 Adaptive138Third133Node30 = false := by
  decide +kernel

#print axioms adaptive138Third133Proof30

end NineSeparatedSubsetSums
