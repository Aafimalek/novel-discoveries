import NineSeparatedSubsetSums.Adaptive138Third134State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third134Proof40 : runCachedNode 511 128232 Adaptive138Third134Node40 = false := by
  decide +kernel

#print axioms adaptive138Third134Proof40

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third134Proof67 : runCachedNode 511 128232 Adaptive138Third134Node67 = false := by
  decide +kernel

#print axioms adaptive138Third134Proof67

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third134Proof16 : runCachedNode 511 128232 Adaptive138Third134Node16 = false := by
  decide +kernel

#print axioms adaptive138Third134Proof16

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third134Proof91 : runCachedNode 511 128232 Adaptive138Third134Node91 = false := by
  decide +kernel

#print axioms adaptive138Third134Proof91

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third134Proof38 : runCachedNode 511 128232 Adaptive138Third134Node38 = false := by
  decide +kernel

#print axioms adaptive138Third134Proof38

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third134Proof80 : runCachedNode 511 128232 Adaptive138Third134Node80 = false := by
  decide +kernel

#print axioms adaptive138Third134Proof80

end NineSeparatedSubsetSums
