import NineSeparatedSubsetSums.Adaptive138Third135State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third135Proof19 : runCachedNode 511 128437 Adaptive138Third135Node19 = false := by
  decide +kernel

#print axioms adaptive138Third135Proof19

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third135Proof99 : runCachedNode 511 128437 Adaptive138Third135Node99 = false := by
  decide +kernel

#print axioms adaptive138Third135Proof99

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third135Proof13 : runCachedNode 511 128437 Adaptive138Third135Node13 = false := by
  decide +kernel

#print axioms adaptive138Third135Proof13

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third135Proof49 : runCachedNode 511 128437 Adaptive138Third135Node49 = false := by
  decide +kernel

#print axioms adaptive138Third135Proof49

end NineSeparatedSubsetSums
