import NineSeparatedSubsetSums.Adaptive138Third136State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third136Proof99 : runCachedNode 511 128623 Adaptive138Third136Node99 = false := by
  decide +kernel

#print axioms adaptive138Third136Proof99

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third136Proof127 : runCachedNode 511 128623 Adaptive138Third136Node127 = false := by
  decide +kernel

#print axioms adaptive138Third136Proof127

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third136Proof54 : runCachedNode 511 128623 Adaptive138Third136Node54 = false := by
  decide +kernel

#print axioms adaptive138Third136Proof54

end NineSeparatedSubsetSums
