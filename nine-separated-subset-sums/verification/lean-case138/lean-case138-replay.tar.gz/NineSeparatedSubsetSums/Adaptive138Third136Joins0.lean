import NineSeparatedSubsetSums.Adaptive138Third136State
import NineSeparatedSubsetSums.Adaptive138Third136Leaves9
import NineSeparatedSubsetSums.Adaptive138Third136Leaves13
import NineSeparatedSubsetSums.Adaptive138Third136Leaves10
import NineSeparatedSubsetSums.Adaptive138Third136Leaves0
import NineSeparatedSubsetSums.Adaptive138Third136Leaves11
import NineSeparatedSubsetSums.Adaptive138Third136Leaves12
import NineSeparatedSubsetSums.Adaptive138Third136Leaves8
import NineSeparatedSubsetSums.Adaptive138Third136Leaves2
import NineSeparatedSubsetSums.Adaptive138Third136Leaves7
import NineSeparatedSubsetSums.Adaptive138Third136Leaves3
import NineSeparatedSubsetSums.Adaptive138Third136Leaves6
import NineSeparatedSubsetSums.Adaptive138Third136Leaves4
import NineSeparatedSubsetSums.Adaptive138Third136Leaves14
import NineSeparatedSubsetSums.Adaptive138Third136Leaves1
import NineSeparatedSubsetSums.Adaptive138Third136Leaves5

namespace NineSeparatedSubsetSums

theorem adaptive138Third136Proof22 : runCachedNode 511 128623 Adaptive138Third136Node22 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 128623 Adaptive138Third136Node22 = [104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 121, 123, 124, 125, 127, 128, 129, 131] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive138Third136Proof23
  · exact adaptive138Third136Proof24
  · exact adaptive138Third136Proof25
  · exact adaptive138Third136Proof26
  · exact adaptive138Third136Proof27
  · exact adaptive138Third136Proof28
  · exact adaptive138Third136Proof29
  · exact adaptive138Third136Proof30
  · exact adaptive138Third136Proof31
  · exact adaptive138Third136Proof32
  · exact adaptive138Third136Proof33
  · exact adaptive138Third136Proof34
  · exact adaptive138Third136Proof35
  · exact adaptive138Third136Proof36
  · exact adaptive138Third136Proof37
  · exact adaptive138Third136Proof38
  · exact adaptive138Third136Proof39
  · exact adaptive138Third136Proof40
  · exact adaptive138Third136Proof41
  · exact adaptive138Third136Proof42
  · exact adaptive138Third136Proof43
  · exact adaptive138Third136Proof44
  · exact adaptive138Third136Proof45
  · exact adaptive138Third136Proof46

#print axioms adaptive138Third136Proof22

theorem adaptive138Third136Proof47 : runCachedNode 511 128623 Adaptive138Third136Node47 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 128623 Adaptive138Third136Node47 = [104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 122, 124, 125, 127, 128, 129, 130, 132] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive138Third136Proof48
  · exact adaptive138Third136Proof49
  · exact adaptive138Third136Proof50
  · exact adaptive138Third136Proof51
  · exact adaptive138Third136Proof52
  · exact adaptive138Third136Proof53
  · exact adaptive138Third136Proof54
  · exact adaptive138Third136Proof55
  · exact adaptive138Third136Proof56
  · exact adaptive138Third136Proof57
  · exact adaptive138Third136Proof58
  · exact adaptive138Third136Proof59
  · exact adaptive138Third136Proof60
  · exact adaptive138Third136Proof61
  · exact adaptive138Third136Proof62
  · exact adaptive138Third136Proof63
  · exact adaptive138Third136Proof64
  · exact adaptive138Third136Proof65
  · exact adaptive138Third136Proof66
  · exact adaptive138Third136Proof67
  · exact adaptive138Third136Proof68
  · exact adaptive138Third136Proof69
  · exact adaptive138Third136Proof70
  · exact adaptive138Third136Proof71
  · exact adaptive138Third136Proof72

#print axioms adaptive138Third136Proof47

theorem adaptive138Third136Proof73 : runCachedNode 511 128623 Adaptive138Third136Node73 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 128623 Adaptive138Third136Node73 = [104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 123, 125, 127, 128, 129, 130, 131, 133] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive138Third136Proof74
  · exact adaptive138Third136Proof75
  · exact adaptive138Third136Proof76
  · exact adaptive138Third136Proof77
  · exact adaptive138Third136Proof78
  · exact adaptive138Third136Proof79
  · exact adaptive138Third136Proof80
  · exact adaptive138Third136Proof81
  · exact adaptive138Third136Proof82
  · exact adaptive138Third136Proof83
  · exact adaptive138Third136Proof84
  · exact adaptive138Third136Proof85
  · exact adaptive138Third136Proof86
  · exact adaptive138Third136Proof87
  · exact adaptive138Third136Proof88
  · exact adaptive138Third136Proof89
  · exact adaptive138Third136Proof90
  · exact adaptive138Third136Proof91
  · exact adaptive138Third136Proof92
  · exact adaptive138Third136Proof93
  · exact adaptive138Third136Proof94
  · exact adaptive138Third136Proof95
  · exact adaptive138Third136Proof96
  · exact adaptive138Third136Proof97
  · exact adaptive138Third136Proof98
  · exact adaptive138Third136Proof99

#print axioms adaptive138Third136Proof73

theorem adaptive138Third136Proof128 : runCachedNode 511 128623 Adaptive138Third136Node128 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 128623 Adaptive138Third136Node128 = [93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 120, 128, 129, 130] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive138Third136Proof129
  · exact adaptive138Third136Proof130
  · exact adaptive138Third136Proof131
  · exact adaptive138Third136Proof132
  · exact adaptive138Third136Proof133
  · exact adaptive138Third136Proof134
  · exact adaptive138Third136Proof135
  · exact adaptive138Third136Proof136
  · exact adaptive138Third136Proof137
  · exact adaptive138Third136Proof138
  · exact adaptive138Third136Proof139
  · exact adaptive138Third136Proof140
  · exact adaptive138Third136Proof141
  · exact adaptive138Third136Proof142
  · exact adaptive138Third136Proof143
  · exact adaptive138Third136Proof144
  · exact adaptive138Third136Proof145
  · exact adaptive138Third136Proof146
  · exact adaptive138Third136Proof147
  · exact adaptive138Third136Proof148
  · exact adaptive138Third136Proof149
  · exact adaptive138Third136Proof150
  · exact adaptive138Third136Proof151
  · exact adaptive138Third136Proof152
  · exact adaptive138Third136Proof153
  · exact adaptive138Third136Proof154
  · exact adaptive138Third136Proof155
  · exact adaptive138Third136Proof156
  · exact adaptive138Third136Proof157
  · exact adaptive138Third136Proof158

#print axioms adaptive138Third136Proof128

theorem adaptive138Third136Proof100 : runCachedNode 511 128623 Adaptive138Third136Node100 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 128623 Adaptive138Third136Node100 = [103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 124, 127, 128, 129, 130, 131, 132, 134] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive138Third136Proof101
  · exact adaptive138Third136Proof102
  · exact adaptive138Third136Proof103
  · exact adaptive138Third136Proof104
  · exact adaptive138Third136Proof105
  · exact adaptive138Third136Proof106
  · exact adaptive138Third136Proof107
  · exact adaptive138Third136Proof108
  · exact adaptive138Third136Proof109
  · exact adaptive138Third136Proof110
  · exact adaptive138Third136Proof111
  · exact adaptive138Third136Proof112
  · exact adaptive138Third136Proof113
  · exact adaptive138Third136Proof114
  · exact adaptive138Third136Proof115
  · exact adaptive138Third136Proof116
  · exact adaptive138Third136Proof117
  · exact adaptive138Third136Proof118
  · exact adaptive138Third136Proof119
  · exact adaptive138Third136Proof120
  · exact adaptive138Third136Proof121
  · exact adaptive138Third136Proof122
  · exact adaptive138Third136Proof123
  · exact adaptive138Third136Proof124
  · exact adaptive138Third136Proof125
  · exact adaptive138Third136Proof126
  · exact adaptive138Third136Proof127
  · exact adaptive138Third136Proof128

#print axioms adaptive138Third136Proof100

theorem adaptive138Third136Proof0 : runCachedNode 511 128623 Adaptive138Third136Node0 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 128623 Adaptive138Third136Node0 = [110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 127, 128, 129, 130, 131, 132, 133, 134, 135] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive138Third136Proof1
  · exact adaptive138Third136Proof2
  · exact adaptive138Third136Proof3
  · exact adaptive138Third136Proof4
  · exact adaptive138Third136Proof5
  · exact adaptive138Third136Proof6
  · exact adaptive138Third136Proof7
  · exact adaptive138Third136Proof8
  · exact adaptive138Third136Proof9
  · exact adaptive138Third136Proof10
  · exact adaptive138Third136Proof11
  · exact adaptive138Third136Proof12
  · exact adaptive138Third136Proof13
  · exact adaptive138Third136Proof14
  · exact adaptive138Third136Proof15
  · exact adaptive138Third136Proof16
  · exact adaptive138Third136Proof17
  · exact adaptive138Third136Proof18
  · exact adaptive138Third136Proof19
  · exact adaptive138Third136Proof20
  · exact adaptive138Third136Proof21
  · exact adaptive138Third136Proof22
  · exact adaptive138Third136Proof47
  · exact adaptive138Third136Proof73
  · exact adaptive138Third136Proof100

#print axioms adaptive138Third136Proof0

end NineSeparatedSubsetSums
