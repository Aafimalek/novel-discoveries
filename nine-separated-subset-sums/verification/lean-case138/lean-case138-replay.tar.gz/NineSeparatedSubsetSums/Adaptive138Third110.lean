import NineSeparatedSubsetSums.Adaptive138Third110Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint138Checked

namespace NineSeparatedSubsetSums


theorem adaptive138Third110 : NoDescendingTailAfterThird 138 110 :=
  noDescendingThirdTail_of_cached 138 110 111079 (fun t ht nd => max148_second138_fourPoint_moment_bound (110::t) (by simp [ht]) nd) adaptive138Third110Proof0

#print axioms adaptive138Third110

end NineSeparatedSubsetSums
