import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive138Third132Node0 : CachedSearchNode :=
  ⟨4, 131, computeCenteredMask [148,138,132], 418, 58372⟩
def Adaptive138Third132Node1 : CachedSearchNode := cachedChild Adaptive138Third132Node0 111
def Adaptive138Third132Node2 : CachedSearchNode := cachedChild Adaptive138Third132Node0 112
def Adaptive138Third132Node3 : CachedSearchNode := cachedChild Adaptive138Third132Node0 113
def Adaptive138Third132Node4 : CachedSearchNode := cachedChild Adaptive138Third132Node0 114
def Adaptive138Third132Node5 : CachedSearchNode := cachedChild Adaptive138Third132Node0 115
def Adaptive138Third132Node6 : CachedSearchNode := cachedChild Adaptive138Third132Node0 116
def Adaptive138Third132Node7 : CachedSearchNode := cachedChild Adaptive138Third132Node0 117
def Adaptive138Third132Node8 : CachedSearchNode := cachedChild Adaptive138Third132Node0 118
def Adaptive138Third132Node9 : CachedSearchNode := cachedChild Adaptive138Third132Node0 119
def Adaptive138Third132Node10 : CachedSearchNode := cachedChild Adaptive138Third132Node0 120
def Adaptive138Third132Node11 : CachedSearchNode := cachedChild Adaptive138Third132Node0 121
def Adaptive138Third132Node12 : CachedSearchNode := cachedChild Adaptive138Third132Node0 123
def Adaptive138Third132Node13 : CachedSearchNode := cachedChild Adaptive138Third132Node0 124
def Adaptive138Third132Node14 : CachedSearchNode := cachedChild Adaptive138Third132Node0 125
def Adaptive138Third132Node15 : CachedSearchNode := cachedChild Adaptive138Third132Node0 126
def Adaptive138Third132Node16 : CachedSearchNode := cachedChild Adaptive138Third132Node0 127
def Adaptive138Third132Node17 : CachedSearchNode := cachedChild Adaptive138Third132Node0 128
def Adaptive138Third132Node18 : CachedSearchNode := cachedChild Adaptive138Third132Node0 129
def Adaptive138Third132Node19 : CachedSearchNode := cachedChild Adaptive138Third132Node0 130
def Adaptive138Third132Node20 : CachedSearchNode := cachedChild Adaptive138Third132Node0 131

end NineSeparatedSubsetSums
