import NineSeparatedSubsetSums.Adaptive138Third127State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third127Proof7 : runCachedNode 511 126958 Adaptive138Third127Node7 = false := by
  decide +kernel

#print axioms adaptive138Third127Proof7

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third127Proof5 : runCachedNode 511 126958 Adaptive138Third127Node5 = false := by
  decide +kernel

#print axioms adaptive138Third127Proof5

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third127Proof4 : runCachedNode 511 126958 Adaptive138Third127Node4 = false := by
  decide +kernel

#print axioms adaptive138Third127Proof4

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third127Proof3 : runCachedNode 511 126958 Adaptive138Third127Node3 = false := by
  decide +kernel

#print axioms adaptive138Third127Proof3

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third127Proof1 : runCachedNode 511 126958 Adaptive138Third127Node1 = false := by
  decide +kernel

#print axioms adaptive138Third127Proof1

end NineSeparatedSubsetSums
