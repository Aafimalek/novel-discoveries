import NineSeparatedSubsetSums.Adaptive138Third131State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third131Proof9 : runCachedNode 511 127792 Adaptive138Third131Node9 = false := by
  decide +kernel

#print axioms adaptive138Third131Proof9

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third131Proof7 : runCachedNode 511 127792 Adaptive138Third131Node7 = false := by
  decide +kernel

#print axioms adaptive138Third131Proof7

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third131Proof8 : runCachedNode 511 127792 Adaptive138Third131Node8 = false := by
  decide +kernel

#print axioms adaptive138Third131Proof8

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third131Proof5 : runCachedNode 511 127792 Adaptive138Third131Node5 = false := by
  decide +kernel

#print axioms adaptive138Third131Proof5

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third131Proof4 : runCachedNode 511 127792 Adaptive138Third131Node4 = false := by
  decide +kernel

#print axioms adaptive138Third131Proof4

end NineSeparatedSubsetSums
