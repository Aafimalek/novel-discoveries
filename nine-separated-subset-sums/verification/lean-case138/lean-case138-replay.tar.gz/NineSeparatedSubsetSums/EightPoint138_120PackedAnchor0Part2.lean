import NineSeparatedSubsetSums.EightPoint138_120PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint138_120PackedAnchor0Part2 :
    ∀ j : Fin 3, 2318958 ≤ FourPointNumeric.octPackedCharge 138 120 20 packedOct138_120_0
      (2*((j.val : Int)+240)+0) := by decide +kernel

end NineSeparatedSubsetSums
