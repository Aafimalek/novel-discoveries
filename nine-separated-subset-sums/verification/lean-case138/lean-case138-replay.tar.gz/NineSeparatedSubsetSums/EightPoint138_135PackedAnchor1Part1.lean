import NineSeparatedSubsetSums.EightPoint138_135PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint138_135PackedAnchor1Part1 :
    ∀ j : Fin 120, 2463104 ≤ FourPointNumeric.octPackedCharge 138 135 20 packedOct138_135_1
      (2*((j.val : Int)+120)+0) := by decide +kernel

end NineSeparatedSubsetSums
