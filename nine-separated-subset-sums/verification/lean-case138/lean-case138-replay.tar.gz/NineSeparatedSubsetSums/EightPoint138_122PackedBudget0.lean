import NineSeparatedSubsetSums.EightPoint138_122PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct138_122_0_budget :
    FourPointNumeric.packedBudget 20 packedOct138_122_0 467 = 81925090 := by decide +kernel

#print axioms packedOct138_122_0_budget

end NineSeparatedSubsetSums
