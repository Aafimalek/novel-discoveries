import NineSeparatedSubsetSums.Adaptive138Third120State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third120Proof0 : runCachedNode 511 125299 Adaptive138Third120Node0 = false := by
  decide +kernel

#print axioms adaptive138Third120Proof0

end NineSeparatedSubsetSums
