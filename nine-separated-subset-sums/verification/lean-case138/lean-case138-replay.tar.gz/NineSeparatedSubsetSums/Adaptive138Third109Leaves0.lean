import NineSeparatedSubsetSums.Adaptive138Third109State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third109Proof0 : runCachedNode 511 111079 Adaptive138Third109Node0 = false := by
  decide +kernel

#print axioms adaptive138Third109Proof0

end NineSeparatedSubsetSums
