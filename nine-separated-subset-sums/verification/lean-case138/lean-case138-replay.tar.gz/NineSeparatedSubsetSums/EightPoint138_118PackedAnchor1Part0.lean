import NineSeparatedSubsetSums.EightPoint138_118PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint138_118PackedAnchor1Part0 :
    ∀ j : Fin 120, 2277193 ≤ FourPointNumeric.octPackedCharge 138 118 20 packedOct138_118_1
      (2*((j.val : Int)+0)+1) := by decide +kernel

end NineSeparatedSubsetSums
