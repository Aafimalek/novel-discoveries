import NineSeparatedSubsetSums.Adaptive138Third116Joins0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint138Checked

namespace NineSeparatedSubsetSums


theorem adaptive138Third116 : NoDescendingTailAfterThird 138 116 :=
  noDescendingThirdTail_of_cached 138 116 111079 (fun t ht nd => max148_second138_fourPoint_moment_bound (116::t) (by simp [ht]) nd) adaptive138Third116Proof0

#print axioms adaptive138Third116

end NineSeparatedSubsetSums
