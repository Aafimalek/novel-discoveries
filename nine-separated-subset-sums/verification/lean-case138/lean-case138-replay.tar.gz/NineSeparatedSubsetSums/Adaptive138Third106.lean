import NineSeparatedSubsetSums.Adaptive138Third106Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint138Checked

namespace NineSeparatedSubsetSums


theorem adaptive138Third106 : NoDescendingTailAfterThird 138 106 :=
  noDescendingThirdTail_of_cached 138 106 111079 (fun t ht nd => max148_second138_fourPoint_moment_bound (106::t) (by simp [ht]) nd) adaptive138Third106Proof0

#print axioms adaptive138Third106

end NineSeparatedSubsetSums
