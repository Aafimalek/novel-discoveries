import NineSeparatedSubsetSums.FourPoint138PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedWeight138_1_budget :
    FourPointNumeric.packedBudget 19 packedWeight138_1 372 = 76119296 := by decide +kernel

#print axioms packedWeight138_1_budget

end NineSeparatedSubsetSums
