import NineSeparatedSubsetSums.Adaptive138Third124State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third124Proof0 : runCachedNode 511 126164 Adaptive138Third124Node0 = false := by
  decide +kernel

#print axioms adaptive138Third124Proof0

end NineSeparatedSubsetSums
