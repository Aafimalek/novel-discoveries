import NineSeparatedSubsetSums.Adaptive138Third113Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint138Checked

namespace NineSeparatedSubsetSums


theorem adaptive138Third113 : NoDescendingTailAfterThird 138 113 :=
  noDescendingThirdTail_of_cached 138 113 111079 (fun t ht nd => max148_second138_fourPoint_moment_bound (113::t) (by simp [ht]) nd) adaptive138Third113Proof0

#print axioms adaptive138Third113

end NineSeparatedSubsetSums
