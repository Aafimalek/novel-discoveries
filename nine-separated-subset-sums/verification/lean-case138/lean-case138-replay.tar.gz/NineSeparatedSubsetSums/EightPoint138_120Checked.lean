import NineSeparatedSubsetSums.EightPointPackedGeometry
import NineSeparatedSubsetSums.EightPoint138_120PackedBudget0
import NineSeparatedSubsetSums.EightPoint138_120PackedAnchor0Part0
import NineSeparatedSubsetSums.EightPoint138_120PackedAnchor0Part1
import NineSeparatedSubsetSums.EightPoint138_120PackedAnchor0Part2
import NineSeparatedSubsetSums.EightPoint138_120PackedBudget1
import NineSeparatedSubsetSums.EightPoint138_120PackedAnchor1Part0
import NineSeparatedSubsetSums.EightPoint138_120PackedAnchor1Part1
import NineSeparatedSubsetSums.EightPoint138_120PackedAnchor1Part2

namespace NineSeparatedSubsetSums

private theorem packedOct138_120Anchor0 :
  ∀ j : Fin 485, ((j.val : Int)+138+120)%2=0 →
    2318958 ≤ FourPointNumeric.octPackedCharge 138 120 20 packedOct138_120_0 (j.val : Int) := by
  intro j hj
  let k := (j.val-0)/2
  have hk : k < 243 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+0 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint138_120PackedAnchor0Part0 z
    rwa [he,hrep] at ht
  by_cases h1 : k < 240
  · let z : Fin 120 := ⟨k-120, by omega⟩
    have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
    have ht := eightPoint138_120PackedAnchor0Part1 z
    rwa [he,hrep] at ht
  let z : Fin 3 := ⟨k-240, by omega⟩
  have he : (z.val : Int)+240 = k := by dsimp [z] <;> omega
  have ht := eightPoint138_120PackedAnchor0Part2 z
  rwa [he,hrep] at ht

private theorem packedOct138_120Anchor1 :
  ∀ j : Fin 485, ((j.val : Int)+138+120)%2=1 →
    2320849 ≤ FourPointNumeric.octPackedCharge 138 120 20 packedOct138_120_1 (j.val : Int) := by
  intro j hj
  let k := (j.val-1)/2
  have hk : k < 242 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+1 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint138_120PackedAnchor1Part0 z
    rwa [he,hrep] at ht
  by_cases h1 : k < 240
  · let z : Fin 120 := ⟨k-120, by omega⟩
    have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
    have ht := eightPoint138_120PackedAnchor1Part1 z
    rwa [he,hrep] at ht
  let z : Fin 2 := ⟨k-240, by omega⟩
  have he : (z.val : Int)+240 = k := by dsimp [z] <;> omega
  have ht := eightPoint138_120PackedAnchor1Part2 z
  rwa [he,hrep] at ht

def packedOctCertificate138_120_0 : EightPointCertificate 138 120 0 125299 :=
  eightPointCertificateOfPacked 138 120 0 125299 2318958 20 packedOct138_120_0 273 485
    (by decide +kernel) (by decide) packedOct138_120Anchor0
    (by rw [packedOct138_120_0_budget]; decide)

def packedOctCertificate138_120_1 : EightPointCertificate 138 120 1 125299 :=
  eightPointCertificateOfPacked 138 120 1 125299 2320849 20 packedOct138_120_1 268 485
    (by decide +kernel) (by decide) packedOct138_120Anchor1
    (by rw [packedOct138_120_1_budget]; decide)

theorem max148_second138_third120_eightPoint_moment_bound (tail : List ℕ) (len : tail.length=6)
    (distinct : (natSubsetSums (148::138::120::tail)).Nodup) :
    125299 ≤ ((148::138::120::tail).map (· ^ 2)).sum := by
  apply eightPointNatMomentLower 138 120 125299 tail len distinct
  intro p hp
  by_cases h : p=0
  · subst p
    exact packedOctCertificate138_120_0
  · have he : p=1 := hp.resolve_left h
    subst p
    exact packedOctCertificate138_120_1

#print axioms max148_second138_third120_eightPoint_moment_bound

end NineSeparatedSubsetSums
