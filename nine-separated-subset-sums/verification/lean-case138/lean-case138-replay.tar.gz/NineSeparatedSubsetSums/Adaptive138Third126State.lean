import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive138Third126Node0 : CachedSearchNode :=
  ⟨4, 125, computeCenteredMask [148,138,126], 412, 56824⟩

end NineSeparatedSubsetSums
