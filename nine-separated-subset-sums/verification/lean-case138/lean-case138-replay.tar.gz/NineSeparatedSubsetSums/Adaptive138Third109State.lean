import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive138Third109Node0 : CachedSearchNode :=
  ⟨4, 108, computeCenteredMask [148,138,109], 395, 52829⟩

end NineSeparatedSubsetSums
