import NineSeparatedSubsetSums.EightPoint138_137PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint138_137PackedAnchor1Part0 :
    ∀ j : Fin 120, 2464811 ≤ FourPointNumeric.octPackedCharge 138 137 20 packedOct138_137_1
      (2*((j.val : Int)+0)+0) := by decide +kernel

end NineSeparatedSubsetSums
