import NineSeparatedSubsetSums.EightPointPackedGeometry
import NineSeparatedSubsetSums.EightPoint138_137PackedBudget0
import NineSeparatedSubsetSums.EightPoint138_137PackedAnchor0Part0
import NineSeparatedSubsetSums.EightPoint138_137PackedAnchor0Part1
import NineSeparatedSubsetSums.EightPoint138_137PackedAnchor0Part2
import NineSeparatedSubsetSums.EightPoint138_137PackedBudget1
import NineSeparatedSubsetSums.EightPoint138_137PackedAnchor1Part0
import NineSeparatedSubsetSums.EightPoint138_137PackedAnchor1Part1
import NineSeparatedSubsetSums.EightPoint138_137PackedAnchor1Part2

namespace NineSeparatedSubsetSums

private theorem packedOct138_137Anchor0 :
  ∀ j : Fin 499, ((j.val : Int)+138+137)%2=0 →
    2465141 ≤ FourPointNumeric.octPackedCharge 138 137 20 packedOct138_137_0 (j.val : Int) := by
  intro j hj
  let k := (j.val-1)/2
  have hk : k < 249 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+1 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint138_137PackedAnchor0Part0 z
    rwa [he,hrep] at ht
  by_cases h1 : k < 240
  · let z : Fin 120 := ⟨k-120, by omega⟩
    have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
    have ht := eightPoint138_137PackedAnchor0Part1 z
    rwa [he,hrep] at ht
  let z : Fin 9 := ⟨k-240, by omega⟩
  have he : (z.val : Int)+240 = k := by dsimp [z] <;> omega
  have ht := eightPoint138_137PackedAnchor0Part2 z
  rwa [he,hrep] at ht

private theorem packedOct138_137Anchor1 :
  ∀ j : Fin 499, ((j.val : Int)+138+137)%2=1 →
    2464811 ≤ FourPointNumeric.octPackedCharge 138 137 20 packedOct138_137_1 (j.val : Int) := by
  intro j hj
  let k := (j.val-0)/2
  have hk : k < 250 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+0 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint138_137PackedAnchor1Part0 z
    rwa [he,hrep] at ht
  by_cases h1 : k < 240
  · let z : Fin 120 := ⟨k-120, by omega⟩
    have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
    have ht := eightPoint138_137PackedAnchor1Part1 z
    rwa [he,hrep] at ht
  let z : Fin 10 := ⟨k-240, by omega⟩
  have he : (z.val : Int)+240 = k := by dsimp [z] <;> omega
  have ht := eightPoint138_137PackedAnchor1Part2 z
  rwa [he,hrep] at ht

def packedOctCertificate138_137_0 : EightPointCertificate 138 137 0 128810 :=
  eightPointCertificateOfPacked 138 137 0 128810 2465141 20 packedOct138_137_0 273 499
    (by decide +kernel) (by decide) packedOct138_137Anchor0
    (by rw [packedOct138_137_0_budget]; decide)

def packedOctCertificate138_137_1 : EightPointCertificate 138 137 1 128810 :=
  eightPointCertificateOfPacked 138 137 1 128810 2464811 20 packedOct138_137_1 274 499
    (by decide +kernel) (by decide) packedOct138_137Anchor1
    (by rw [packedOct138_137_1_budget]; decide)

theorem max148_second138_third137_eightPoint_moment_bound (tail : List ℕ) (len : tail.length=6)
    (distinct : (natSubsetSums (148::138::137::tail)).Nodup) :
    128810 ≤ ((148::138::137::tail).map (· ^ 2)).sum := by
  apply eightPointNatMomentLower 138 137 128810 tail len distinct
  intro p hp
  by_cases h : p=0
  · subst p
    exact packedOctCertificate138_137_0
  · have he : p=1 := hp.resolve_left h
    subst p
    exact packedOctCertificate138_137_1

#print axioms max148_second138_third137_eightPoint_moment_bound

end NineSeparatedSubsetSums
