import NineSeparatedSubsetSums.Adaptive138Third136State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third136Proof13 : runCachedNode 511 128623 Adaptive138Third136Node13 = false := by
  decide +kernel

#print axioms adaptive138Third136Proof13

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third136Proof124 : runCachedNode 511 128623 Adaptive138Third136Node124 = false := by
  decide +kernel

#print axioms adaptive138Third136Proof124

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third136Proof71 : runCachedNode 511 128623 Adaptive138Third136Node71 = false := by
  decide +kernel

#print axioms adaptive138Third136Proof71

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third136Proof93 : runCachedNode 511 128623 Adaptive138Third136Node93 = false := by
  decide +kernel

#print axioms adaptive138Third136Proof93

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third136Proof125 : runCachedNode 511 128623 Adaptive138Third136Node125 = false := by
  decide +kernel

#print axioms adaptive138Third136Proof125

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third136Proof12 : runCachedNode 511 128623 Adaptive138Third136Node12 = false := by
  decide +kernel

#print axioms adaptive138Third136Proof12

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third136Proof90 : runCachedNode 511 128623 Adaptive138Third136Node90 = false := by
  decide +kernel

#print axioms adaptive138Third136Proof90

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third136Proof92 : runCachedNode 511 128623 Adaptive138Third136Node92 = false := by
  decide +kernel

#print axioms adaptive138Third136Proof92

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third136Proof43 : runCachedNode 511 128623 Adaptive138Third136Node43 = false := by
  decide +kernel

#print axioms adaptive138Third136Proof43

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third136Proof91 : runCachedNode 511 128623 Adaptive138Third136Node91 = false := by
  decide +kernel

#print axioms adaptive138Third136Proof91

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third136Proof155 : runCachedNode 511 128623 Adaptive138Third136Node155 = false := by
  decide +kernel

#print axioms adaptive138Third136Proof155

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third136Proof25 : runCachedNode 511 128623 Adaptive138Third136Node25 = false := by
  decide +kernel

#print axioms adaptive138Third136Proof25

end NineSeparatedSubsetSums
