import NineSeparatedSubsetSums.EightPoint138_137PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct138_137_1_budget :
    FourPointNumeric.packedBudget 20 packedOct138_137_1 274 = 91797334 := by decide +kernel

#print axioms packedOct138_137_1_budget

end NineSeparatedSubsetSums
