import NineSeparatedSubsetSums.EightPoint138_122PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint138_122PackedAnchor0Part1 :
    ∀ j : Fin 120, 2284873 ≤ FourPointNumeric.octPackedCharge 138 122 20 packedOct138_122_0
      (2*((j.val : Int)+120)+0) := by decide +kernel

end NineSeparatedSubsetSums
