import NineSeparatedSubsetSums.FourPoint138PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem fourPoint138PackedAnchor0Part1 :
    ∀ j : Fin 114, 1039008 ≤ FourPointNumeric.packedCharge 138 19 packedWeight138_0
      (2*((j.val : Int)+120)+0) := by decide +kernel

end NineSeparatedSubsetSums
