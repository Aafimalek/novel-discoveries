import NineSeparatedSubsetSums.EightPointPackedGeometry
import NineSeparatedSubsetSums.EightPoint138_126PackedBudget0
import NineSeparatedSubsetSums.EightPoint138_126PackedAnchor0Part0
import NineSeparatedSubsetSums.EightPoint138_126PackedAnchor0Part1
import NineSeparatedSubsetSums.EightPoint138_126PackedAnchor0Part2
import NineSeparatedSubsetSums.EightPoint138_126PackedBudget1
import NineSeparatedSubsetSums.EightPoint138_126PackedAnchor1Part0
import NineSeparatedSubsetSums.EightPoint138_126PackedAnchor1Part1
import NineSeparatedSubsetSums.EightPoint138_126PackedAnchor1Part2

namespace NineSeparatedSubsetSums

private theorem packedOct138_126Anchor0 :
  ∀ j : Fin 487, ((j.val : Int)+138+126)%2=0 →
    2350486 ≤ FourPointNumeric.octPackedCharge 138 126 20 packedOct138_126_0 (j.val : Int) := by
  intro j hj
  let k := (j.val-0)/2
  have hk : k < 244 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+0 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint138_126PackedAnchor0Part0 z
    rwa [he,hrep] at ht
  by_cases h1 : k < 240
  · let z : Fin 120 := ⟨k-120, by omega⟩
    have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
    have ht := eightPoint138_126PackedAnchor0Part1 z
    rwa [he,hrep] at ht
  let z : Fin 4 := ⟨k-240, by omega⟩
  have he : (z.val : Int)+240 = k := by dsimp [z] <;> omega
  have ht := eightPoint138_126PackedAnchor0Part2 z
  rwa [he,hrep] at ht

private theorem packedOct138_126Anchor1 :
  ∀ j : Fin 487, ((j.val : Int)+138+126)%2=1 →
    2350833 ≤ FourPointNumeric.octPackedCharge 138 126 20 packedOct138_126_1 (j.val : Int) := by
  intro j hj
  let k := (j.val-1)/2
  have hk : k < 243 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+1 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint138_126PackedAnchor1Part0 z
    rwa [he,hrep] at ht
  by_cases h1 : k < 240
  · let z : Fin 120 := ⟨k-120, by omega⟩
    have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
    have ht := eightPoint138_126PackedAnchor1Part1 z
    rwa [he,hrep] at ht
  let z : Fin 3 := ⟨k-240, by omega⟩
  have he : (z.val : Int)+240 = k := by dsimp [z] <;> omega
  have ht := eightPoint138_126PackedAnchor1Part2 z
  rwa [he,hrep] at ht

def packedOctCertificate138_126_0 : EightPointCertificate 138 126 0 126903 :=
  eightPointCertificateOfPacked 138 126 0 126903 2350486 20 packedOct138_126_0 411 487
    (by decide +kernel) (by decide) packedOct138_126Anchor0
    (by rw [packedOct138_126_0_budget]; decide)

def packedOctCertificate138_126_1 : EightPointCertificate 138 126 1 126903 :=
  eightPointCertificateOfPacked 138 126 1 126903 2350833 20 packedOct138_126_1 412 487
    (by decide +kernel) (by decide) packedOct138_126Anchor1
    (by rw [packedOct138_126_1_budget]; decide)

theorem max148_second138_third126_eightPoint_moment_bound (tail : List ℕ) (len : tail.length=6)
    (distinct : (natSubsetSums (148::138::126::tail)).Nodup) :
    126903 ≤ ((148::138::126::tail).map (· ^ 2)).sum := by
  apply eightPointNatMomentLower 138 126 126903 tail len distinct
  intro p hp
  by_cases h : p=0
  · subst p
    exact packedOctCertificate138_126_0
  · have he : p=1 := hp.resolve_left h
    subst p
    exact packedOctCertificate138_126_1

#print axioms max148_second138_third126_eightPoint_moment_bound

end NineSeparatedSubsetSums
