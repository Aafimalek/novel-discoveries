import NineSeparatedSubsetSums.EightPoint138_131PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct138_131_1_budget :
    FourPointNumeric.packedBudget 20 packedOct138_131_1 454 = 89701196 := by decide +kernel

#print axioms packedOct138_131_1_budget

end NineSeparatedSubsetSums
