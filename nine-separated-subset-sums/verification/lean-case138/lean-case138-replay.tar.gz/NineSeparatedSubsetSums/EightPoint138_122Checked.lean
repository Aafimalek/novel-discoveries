import NineSeparatedSubsetSums.EightPointPackedGeometry
import NineSeparatedSubsetSums.EightPoint138_122PackedBudget0
import NineSeparatedSubsetSums.EightPoint138_122PackedAnchor0Part0
import NineSeparatedSubsetSums.EightPoint138_122PackedAnchor0Part1
import NineSeparatedSubsetSums.EightPoint138_122PackedBudget1
import NineSeparatedSubsetSums.EightPoint138_122PackedAnchor1Part0
import NineSeparatedSubsetSums.EightPoint138_122PackedAnchor1Part1

namespace NineSeparatedSubsetSums

private theorem packedOct138_122Anchor0 :
  ∀ j : Fin 480, ((j.val : Int)+138+122)%2=0 →
    2284873 ≤ FourPointNumeric.octPackedCharge 138 122 20 packedOct138_122_0 (j.val : Int) := by
  intro j hj
  let k := (j.val-0)/2
  have hk : k < 240 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+0 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint138_122PackedAnchor0Part0 z
    rwa [he,hrep] at ht
  let z : Fin 120 := ⟨k-120, by omega⟩
  have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
  have ht := eightPoint138_122PackedAnchor0Part1 z
  rwa [he,hrep] at ht

private theorem packedOct138_122Anchor1 :
  ∀ j : Fin 480, ((j.val : Int)+138+122)%2=1 →
    2285157 ≤ FourPointNumeric.octPackedCharge 138 122 20 packedOct138_122_1 (j.val : Int) := by
  intro j hj
  let k := (j.val-1)/2
  have hk : k < 240 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+1 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint138_122PackedAnchor1Part0 z
    rwa [he,hrep] at ht
  let z : Fin 120 := ⟨k-120, by omega⟩
  have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
  have ht := eightPoint138_122PackedAnchor1Part1 z
  rwa [he,hrep] at ht

def packedOctCertificate138_122_0 : EightPointCertificate 138 122 0 125600 :=
  eightPointCertificateOfPacked 138 122 0 125600 2284873 20 packedOct138_122_0 467 480
    (by decide +kernel) (by decide) packedOct138_122Anchor0
    (by rw [packedOct138_122_0_budget]; decide)

def packedOctCertificate138_122_1 : EightPointCertificate 138 122 1 125600 :=
  eightPointCertificateOfPacked 138 122 1 125600 2285157 20 packedOct138_122_1 466 480
    (by decide +kernel) (by decide) packedOct138_122Anchor1
    (by rw [packedOct138_122_1_budget]; decide)

theorem max148_second138_third122_eightPoint_moment_bound (tail : List ℕ) (len : tail.length=6)
    (distinct : (natSubsetSums (148::138::122::tail)).Nodup) :
    125600 ≤ ((148::138::122::tail).map (· ^ 2)).sum := by
  apply eightPointNatMomentLower 138 122 125600 tail len distinct
  intro p hp
  by_cases h : p=0
  · subst p
    exact packedOctCertificate138_122_0
  · have he : p=1 := hp.resolve_left h
    subst p
    exact packedOctCertificate138_122_1

#print axioms max148_second138_third122_eightPoint_moment_bound

end NineSeparatedSubsetSums
