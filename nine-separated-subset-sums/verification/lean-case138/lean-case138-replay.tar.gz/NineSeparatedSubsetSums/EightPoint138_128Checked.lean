import NineSeparatedSubsetSums.EightPointPackedGeometry
import NineSeparatedSubsetSums.EightPoint138_128PackedBudget0
import NineSeparatedSubsetSums.EightPoint138_128PackedAnchor0Part0
import NineSeparatedSubsetSums.EightPoint138_128PackedAnchor0Part1
import NineSeparatedSubsetSums.EightPoint138_128PackedAnchor0Part2
import NineSeparatedSubsetSums.EightPoint138_128PackedBudget1
import NineSeparatedSubsetSums.EightPoint138_128PackedAnchor1Part0
import NineSeparatedSubsetSums.EightPoint138_128PackedAnchor1Part1
import NineSeparatedSubsetSums.EightPoint138_128PackedAnchor1Part2

namespace NineSeparatedSubsetSums

private theorem packedOct138_128Anchor0 :
  ∀ j : Fin 488, ((j.val : Int)+138+128)%2=0 →
    2357035 ≤ FourPointNumeric.octPackedCharge 138 128 20 packedOct138_128_0 (j.val : Int) := by
  intro j hj
  let k := (j.val-0)/2
  have hk : k < 244 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+0 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint138_128PackedAnchor0Part0 z
    rwa [he,hrep] at ht
  by_cases h1 : k < 240
  · let z : Fin 120 := ⟨k-120, by omega⟩
    have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
    have ht := eightPoint138_128PackedAnchor0Part1 z
    rwa [he,hrep] at ht
  let z : Fin 4 := ⟨k-240, by omega⟩
  have he : (z.val : Int)+240 = k := by dsimp [z] <;> omega
  have ht := eightPoint138_128PackedAnchor0Part2 z
  rwa [he,hrep] at ht

private theorem packedOct138_128Anchor1 :
  ∀ j : Fin 488, ((j.val : Int)+138+128)%2=1 →
    2358471 ≤ FourPointNumeric.octPackedCharge 138 128 20 packedOct138_128_1 (j.val : Int) := by
  intro j hj
  let k := (j.val-1)/2
  have hk : k < 244 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+1 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint138_128PackedAnchor1Part0 z
    rwa [he,hrep] at ht
  by_cases h1 : k < 240
  · let z : Fin 120 := ⟨k-120, by omega⟩
    have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
    have ht := eightPoint138_128PackedAnchor1Part1 z
    rwa [he,hrep] at ht
  let z : Fin 4 := ⟨k-240, by omega⟩
  have he : (z.val : Int)+240 = k := by dsimp [z] <;> omega
  have ht := eightPoint138_128PackedAnchor1Part2 z
  rwa [he,hrep] at ht

def packedOctCertificate138_128_0 : EightPointCertificate 138 128 0 127087 :=
  eightPointCertificateOfPacked 138 128 0 127087 2357035 20 packedOct138_128_0 267 488
    (by decide +kernel) (by decide) packedOct138_128Anchor0
    (by rw [packedOct138_128_0_budget]; decide)

def packedOctCertificate138_128_1 : EightPointCertificate 138 128 1 127087 :=
  eightPointCertificateOfPacked 138 128 1 127087 2358471 20 packedOct138_128_1 268 488
    (by decide +kernel) (by decide) packedOct138_128Anchor1
    (by rw [packedOct138_128_1_budget]; decide)

theorem max148_second138_third128_eightPoint_moment_bound (tail : List ℕ) (len : tail.length=6)
    (distinct : (natSubsetSums (148::138::128::tail)).Nodup) :
    127087 ≤ ((148::138::128::tail).map (· ^ 2)).sum := by
  apply eightPointNatMomentLower 138 128 127087 tail len distinct
  intro p hp
  by_cases h : p=0
  · subst p
    exact packedOctCertificate138_128_0
  · have he : p=1 := hp.resolve_left h
    subst p
    exact packedOctCertificate138_128_1

#print axioms max148_second138_third128_eightPoint_moment_bound

end NineSeparatedSubsetSums
