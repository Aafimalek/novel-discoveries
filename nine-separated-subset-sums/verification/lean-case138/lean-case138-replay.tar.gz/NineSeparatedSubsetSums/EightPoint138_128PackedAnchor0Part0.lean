import NineSeparatedSubsetSums.EightPoint138_128PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint138_128PackedAnchor0Part0 :
    ∀ j : Fin 120, 2357035 ≤ FourPointNumeric.octPackedCharge 138 128 20 packedOct138_128_0
      (2*((j.val : Int)+0)+0) := by decide +kernel

end NineSeparatedSubsetSums
