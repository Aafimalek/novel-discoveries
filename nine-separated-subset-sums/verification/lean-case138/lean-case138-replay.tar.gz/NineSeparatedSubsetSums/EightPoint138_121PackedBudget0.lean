import NineSeparatedSubsetSums.EightPoint138_121PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct138_121_0_budget :
    FourPointNumeric.packedBudget 20 packedOct138_121_0 381 = 87469313 := by decide +kernel

#print axioms packedOct138_121_0_budget

end NineSeparatedSubsetSums
