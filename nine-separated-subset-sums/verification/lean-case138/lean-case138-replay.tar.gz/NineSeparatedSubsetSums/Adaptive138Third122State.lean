import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive138Third122Node0 : CachedSearchNode :=
  ⟨4, 121, computeCenteredMask [148,138,122], 408, 55832⟩

end NineSeparatedSubsetSums
