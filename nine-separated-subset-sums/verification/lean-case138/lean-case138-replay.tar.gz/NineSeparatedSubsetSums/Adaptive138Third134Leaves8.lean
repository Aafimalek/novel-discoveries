import NineSeparatedSubsetSums.Adaptive138Third134State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third134Proof69 : runCachedNode 511 128232 Adaptive138Third134Node69 = false := by
  decide +kernel

#print axioms adaptive138Third134Proof69

end NineSeparatedSubsetSums
