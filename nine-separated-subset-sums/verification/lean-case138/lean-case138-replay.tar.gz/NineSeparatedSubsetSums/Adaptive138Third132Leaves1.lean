import NineSeparatedSubsetSums.Adaptive138Third132State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third132Proof17 : runCachedNode 511 127973 Adaptive138Third132Node17 = false := by
  decide +kernel

#print axioms adaptive138Third132Proof17

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third132Proof13 : runCachedNode 511 127973 Adaptive138Third132Node13 = false := by
  decide +kernel

#print axioms adaptive138Third132Proof13

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third132Proof10 : runCachedNode 511 127973 Adaptive138Third132Node10 = false := by
  decide +kernel

#print axioms adaptive138Third132Proof10

end NineSeparatedSubsetSums
