import NineSeparatedSubsetSums.Adaptive138Third130State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third130Proof13 : runCachedNode 511 127551 Adaptive138Third130Node13 = false := by
  decide +kernel

#print axioms adaptive138Third130Proof13

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third130Proof12 : runCachedNode 511 127551 Adaptive138Third130Node12 = false := by
  decide +kernel

#print axioms adaptive138Third130Proof12

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third130Proof11 : runCachedNode 511 127551 Adaptive138Third130Node11 = false := by
  decide +kernel

#print axioms adaptive138Third130Proof11

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third130Proof10 : runCachedNode 511 127551 Adaptive138Third130Node10 = false := by
  decide +kernel

#print axioms adaptive138Third130Proof10

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third130Proof9 : runCachedNode 511 127551 Adaptive138Third130Node9 = false := by
  decide +kernel

#print axioms adaptive138Third130Proof9

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third130Proof7 : runCachedNode 511 127551 Adaptive138Third130Node7 = false := by
  decide +kernel

#print axioms adaptive138Third130Proof7

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third130Proof6 : runCachedNode 511 127551 Adaptive138Third130Node6 = false := by
  decide +kernel

#print axioms adaptive138Third130Proof6

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third130Proof5 : runCachedNode 511 127551 Adaptive138Third130Node5 = false := by
  decide +kernel

#print axioms adaptive138Third130Proof5

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third130Proof2 : runCachedNode 511 127551 Adaptive138Third130Node2 = false := by
  decide +kernel

#print axioms adaptive138Third130Proof2

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third130Proof1 : runCachedNode 511 127551 Adaptive138Third130Node1 = false := by
  decide +kernel

#print axioms adaptive138Third130Proof1

end NineSeparatedSubsetSums
