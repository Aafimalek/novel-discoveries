import NineSeparatedSubsetSums.EightPoint138_133PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct138_133_0_budget :
    FourPointNumeric.packedBudget 20 packedOct138_133_0 265 = 88782454 := by decide +kernel

#print axioms packedOct138_133_0_budget

end NineSeparatedSubsetSums
