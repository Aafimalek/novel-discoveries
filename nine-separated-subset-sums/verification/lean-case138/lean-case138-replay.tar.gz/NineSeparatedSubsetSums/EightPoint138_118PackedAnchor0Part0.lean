import NineSeparatedSubsetSums.EightPoint138_118PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint138_118PackedAnchor0Part0 :
    ∀ j : Fin 120, 2277096 ≤ FourPointNumeric.octPackedCharge 138 118 20 packedOct138_118_0
      (2*((j.val : Int)+0)+0) := by decide +kernel

end NineSeparatedSubsetSums
