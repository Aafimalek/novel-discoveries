import NineSeparatedSubsetSums.EightPoint138_123PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct138_123_1_budget :
    FourPointNumeric.packedBudget 20 packedOct138_123_1 374 = 82321064 := by decide +kernel

#print axioms packedOct138_123_1_budget

end NineSeparatedSubsetSums
