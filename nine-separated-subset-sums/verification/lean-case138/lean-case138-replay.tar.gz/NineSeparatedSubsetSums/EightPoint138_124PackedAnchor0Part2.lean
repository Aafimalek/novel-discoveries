import NineSeparatedSubsetSums.EightPoint138_124PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint138_124PackedAnchor0Part2 :
    ∀ j : Fin 1, 2295366 ≤ FourPointNumeric.octPackedCharge 138 124 20 packedOct138_124_0
      (2*((j.val : Int)+240)+0) := by decide +kernel

end NineSeparatedSubsetSums
