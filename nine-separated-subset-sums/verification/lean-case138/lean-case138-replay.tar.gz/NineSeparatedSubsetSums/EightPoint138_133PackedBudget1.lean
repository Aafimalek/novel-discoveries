import NineSeparatedSubsetSums.EightPoint138_133PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct138_133_1_budget :
    FourPointNumeric.packedBudget 20 packedOct138_133_1 264 = 88807668 := by decide +kernel

#print axioms packedOct138_133_1_budget

end NineSeparatedSubsetSums
