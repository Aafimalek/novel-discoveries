import NineSeparatedSubsetSums.EightPoint138_119PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint138_119PackedAnchor1Part2 :
    ∀ j : Fin 1, 2293324 ≤ FourPointNumeric.octPackedCharge 138 119 20 packedOct138_119_1
      (2*((j.val : Int)+240)+0) := by decide +kernel

end NineSeparatedSubsetSums
