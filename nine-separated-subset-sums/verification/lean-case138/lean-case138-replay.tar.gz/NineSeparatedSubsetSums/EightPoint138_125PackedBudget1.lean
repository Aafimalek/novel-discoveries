import NineSeparatedSubsetSums.EightPoint138_125PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct138_125_1_budget :
    FourPointNumeric.packedBudget 20 packedOct138_125_1 492 = 83302712 := by decide +kernel

#print axioms packedOct138_125_1_budget

end NineSeparatedSubsetSums
