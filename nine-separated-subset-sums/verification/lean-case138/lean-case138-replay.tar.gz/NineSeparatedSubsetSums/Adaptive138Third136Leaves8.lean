import NineSeparatedSubsetSums.Adaptive138Third136State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third136Proof44 : runCachedNode 511 128623 Adaptive138Third136Node44 = false := by
  decide +kernel

#print axioms adaptive138Third136Proof44

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third136Proof72 : runCachedNode 511 128623 Adaptive138Third136Node72 = false := by
  decide +kernel

#print axioms adaptive138Third136Proof72

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third136Proof16 : runCachedNode 511 128623 Adaptive138Third136Node16 = false := by
  decide +kernel

#print axioms adaptive138Third136Proof16

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third136Proof156 : runCachedNode 511 128623 Adaptive138Third136Node156 = false := by
  decide +kernel

#print axioms adaptive138Third136Proof156

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third136Proof42 : runCachedNode 511 128623 Adaptive138Third136Node42 = false := by
  decide +kernel

#print axioms adaptive138Third136Proof42

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third136Proof2 : runCachedNode 511 128623 Adaptive138Third136Node2 = false := by
  decide +kernel

#print axioms adaptive138Third136Proof2

end NineSeparatedSubsetSums
