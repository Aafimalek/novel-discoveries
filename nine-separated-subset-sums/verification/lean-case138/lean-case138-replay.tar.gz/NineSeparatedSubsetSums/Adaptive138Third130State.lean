import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive138Third130Node0 : CachedSearchNode :=
  ⟨4, 129, computeCenteredMask [148,138,130], 416, 57848⟩
def Adaptive138Third130Node1 : CachedSearchNode := cachedChild Adaptive138Third130Node0 111
def Adaptive138Third130Node2 : CachedSearchNode := cachedChild Adaptive138Third130Node0 112
def Adaptive138Third130Node3 : CachedSearchNode := cachedChild Adaptive138Third130Node0 113
def Adaptive138Third130Node4 : CachedSearchNode := cachedChild Adaptive138Third130Node0 114
def Adaptive138Third130Node5 : CachedSearchNode := cachedChild Adaptive138Third130Node0 115
def Adaptive138Third130Node6 : CachedSearchNode := cachedChild Adaptive138Third130Node0 116
def Adaptive138Third130Node7 : CachedSearchNode := cachedChild Adaptive138Third130Node0 117
def Adaptive138Third130Node8 : CachedSearchNode := cachedChild Adaptive138Third130Node0 118
def Adaptive138Third130Node9 : CachedSearchNode := cachedChild Adaptive138Third130Node0 119
def Adaptive138Third130Node10 : CachedSearchNode := cachedChild Adaptive138Third130Node0 121
def Adaptive138Third130Node11 : CachedSearchNode := cachedChild Adaptive138Third130Node0 122
def Adaptive138Third130Node12 : CachedSearchNode := cachedChild Adaptive138Third130Node0 123
def Adaptive138Third130Node13 : CachedSearchNode := cachedChild Adaptive138Third130Node0 124
def Adaptive138Third130Node14 : CachedSearchNode := cachedChild Adaptive138Third130Node0 125
def Adaptive138Third130Node15 : CachedSearchNode := cachedChild Adaptive138Third130Node0 126
def Adaptive138Third130Node16 : CachedSearchNode := cachedChild Adaptive138Third130Node0 127
def Adaptive138Third130Node17 : CachedSearchNode := cachedChild Adaptive138Third130Node0 128
def Adaptive138Third130Node18 : CachedSearchNode := cachedChild Adaptive138Third130Node0 129

end NineSeparatedSubsetSums
