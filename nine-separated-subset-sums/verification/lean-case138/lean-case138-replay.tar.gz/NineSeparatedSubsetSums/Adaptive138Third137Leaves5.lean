import NineSeparatedSubsetSums.Adaptive138Third137State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third137Proof98 : runCachedNode 511 128810 Adaptive138Third137Node98 = false := by
  decide +kernel

#print axioms adaptive138Third137Proof98

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third137Proof190 : runCachedNode 511 128810 Adaptive138Third137Node190 = false := by
  decide +kernel

#print axioms adaptive138Third137Proof190

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third137Proof125 : runCachedNode 511 128810 Adaptive138Third137Node125 = false := by
  decide +kernel

#print axioms adaptive138Third137Proof125

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third137Proof48 : runCachedNode 511 128810 Adaptive138Third137Node48 = false := by
  decide +kernel

#print axioms adaptive138Third137Proof48

end NineSeparatedSubsetSums
