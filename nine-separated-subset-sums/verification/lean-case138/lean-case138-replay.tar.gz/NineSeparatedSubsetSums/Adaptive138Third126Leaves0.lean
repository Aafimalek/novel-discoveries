import NineSeparatedSubsetSums.Adaptive138Third126State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third126Proof0 : runCachedNode 511 126903 Adaptive138Third126Node0 = false := by
  decide +kernel

#print axioms adaptive138Third126Proof0

end NineSeparatedSubsetSums
