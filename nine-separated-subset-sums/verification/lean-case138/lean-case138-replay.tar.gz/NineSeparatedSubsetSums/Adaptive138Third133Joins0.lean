import NineSeparatedSubsetSums.Adaptive138Third133State
import NineSeparatedSubsetSums.Adaptive138Third133Leaves4
import NineSeparatedSubsetSums.Adaptive138Third133Leaves0
import NineSeparatedSubsetSums.Adaptive138Third133Leaves3
import NineSeparatedSubsetSums.Adaptive138Third133Leaves2
import NineSeparatedSubsetSums.Adaptive138Third133Leaves1

namespace NineSeparatedSubsetSums

theorem adaptive138Third133Proof21 : runCachedNode 511 128072 Adaptive138Third133Node21 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 128072 Adaptive138Third133Node21 = [104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 118, 119, 120, 121, 124, 125, 126, 128, 129, 130, 131] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive138Third133Proof22
  · exact adaptive138Third133Proof23
  · exact adaptive138Third133Proof24
  · exact adaptive138Third133Proof25
  · exact adaptive138Third133Proof26
  · exact adaptive138Third133Proof27
  · exact adaptive138Third133Proof28
  · exact adaptive138Third133Proof29
  · exact adaptive138Third133Proof30
  · exact adaptive138Third133Proof31
  · exact adaptive138Third133Proof32
  · exact adaptive138Third133Proof33
  · exact adaptive138Third133Proof34
  · exact adaptive138Third133Proof35
  · exact adaptive138Third133Proof36
  · exact adaptive138Third133Proof37
  · exact adaptive138Third133Proof38
  · exact adaptive138Third133Proof39
  · exact adaptive138Third133Proof40
  · exact adaptive138Third133Proof41
  · exact adaptive138Third133Proof42
  · exact adaptive138Third133Proof43
  · exact adaptive138Third133Proof44
  · exact adaptive138Third133Proof45

#print axioms adaptive138Third133Proof21

theorem adaptive138Third133Proof0 : runCachedNode 511 128072 Adaptive138Third133Node0 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 128072 Adaptive138Third133Node0 = [111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 124, 125, 126, 127, 128, 129, 130, 131, 132] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive138Third133Proof1
  · exact adaptive138Third133Proof2
  · exact adaptive138Third133Proof3
  · exact adaptive138Third133Proof4
  · exact adaptive138Third133Proof5
  · exact adaptive138Third133Proof6
  · exact adaptive138Third133Proof7
  · exact adaptive138Third133Proof8
  · exact adaptive138Third133Proof9
  · exact adaptive138Third133Proof10
  · exact adaptive138Third133Proof11
  · exact adaptive138Third133Proof12
  · exact adaptive138Third133Proof13
  · exact adaptive138Third133Proof14
  · exact adaptive138Third133Proof15
  · exact adaptive138Third133Proof16
  · exact adaptive138Third133Proof17
  · exact adaptive138Third133Proof18
  · exact adaptive138Third133Proof19
  · exact adaptive138Third133Proof20
  · exact adaptive138Third133Proof21

#print axioms adaptive138Third133Proof0

end NineSeparatedSubsetSums
