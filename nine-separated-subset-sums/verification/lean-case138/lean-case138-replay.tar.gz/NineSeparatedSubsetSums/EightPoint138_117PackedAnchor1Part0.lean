import NineSeparatedSubsetSums.EightPoint138_117PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint138_117PackedAnchor1Part0 :
    ∀ j : Fin 120, 2265010 ≤ FourPointNumeric.octPackedCharge 138 117 20 packedOct138_117_1
      (2*((j.val : Int)+0)+0) := by decide +kernel

end NineSeparatedSubsetSums
