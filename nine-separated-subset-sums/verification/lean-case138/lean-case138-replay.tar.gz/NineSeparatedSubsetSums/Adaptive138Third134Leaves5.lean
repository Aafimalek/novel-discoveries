import NineSeparatedSubsetSums.Adaptive138Third134State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third134Proof41 : runCachedNode 511 128232 Adaptive138Third134Node41 = false := by
  decide +kernel

#print axioms adaptive138Third134Proof41

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third134Proof15 : runCachedNode 511 128232 Adaptive138Third134Node15 = false := by
  decide +kernel

#print axioms adaptive138Third134Proof15

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third134Proof92 : runCachedNode 511 128232 Adaptive138Third134Node92 = false := by
  decide +kernel

#print axioms adaptive138Third134Proof92

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third134Proof13 : runCachedNode 511 128232 Adaptive138Third134Node13 = false := by
  decide +kernel

#print axioms adaptive138Third134Proof13

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third134Proof11 : runCachedNode 511 128232 Adaptive138Third134Node11 = false := by
  decide +kernel

#print axioms adaptive138Third134Proof11

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third134Proof12 : runCachedNode 511 128232 Adaptive138Third134Node12 = false := by
  decide +kernel

#print axioms adaptive138Third134Proof12

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third134Proof39 : runCachedNode 511 128232 Adaptive138Third134Node39 = false := by
  decide +kernel

#print axioms adaptive138Third134Proof39

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third134Proof7 : runCachedNode 511 128232 Adaptive138Third134Node7 = false := by
  decide +kernel

#print axioms adaptive138Third134Proof7

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third134Proof48 : runCachedNode 511 128232 Adaptive138Third134Node48 = false := by
  decide +kernel

#print axioms adaptive138Third134Proof48

end NineSeparatedSubsetSums
