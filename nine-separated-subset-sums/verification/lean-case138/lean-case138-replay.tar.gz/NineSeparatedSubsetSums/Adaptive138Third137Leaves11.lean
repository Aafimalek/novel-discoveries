import NineSeparatedSubsetSums.Adaptive138Third137State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third137Proof126 : runCachedNode 511 128810 Adaptive138Third137Node126 = false := by
  decide +kernel

#print axioms adaptive138Third137Proof126

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third137Proof13 : runCachedNode 511 128810 Adaptive138Third137Node13 = false := by
  decide +kernel

#print axioms adaptive138Third137Proof13

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third137Proof123 : runCachedNode 511 128810 Adaptive138Third137Node123 = false := by
  decide +kernel

#print axioms adaptive138Third137Proof123

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third137Proof150 : runCachedNode 511 128810 Adaptive138Third137Node150 = false := by
  decide +kernel

#print axioms adaptive138Third137Proof150

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third137Proof45 : runCachedNode 511 128810 Adaptive138Third137Node45 = false := by
  decide +kernel

#print axioms adaptive138Third137Proof45

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third137Proof12 : runCachedNode 511 128810 Adaptive138Third137Node12 = false := by
  decide +kernel

#print axioms adaptive138Third137Proof12

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third137Proof68 : runCachedNode 511 128810 Adaptive138Third137Node68 = false := by
  decide +kernel

#print axioms adaptive138Third137Proof68

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third137Proof94 : runCachedNode 511 128810 Adaptive138Third137Node94 = false := by
  decide +kernel

#print axioms adaptive138Third137Proof94

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third137Proof124 : runCachedNode 511 128810 Adaptive138Third137Node124 = false := by
  decide +kernel

#print axioms adaptive138Third137Proof124

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third137Proof148 : runCachedNode 511 128810 Adaptive138Third137Node148 = false := by
  decide +kernel

#print axioms adaptive138Third137Proof148

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third137Proof39 : runCachedNode 511 128810 Adaptive138Third137Node39 = false := by
  decide +kernel

#print axioms adaptive138Third137Proof39

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third137Proof27 : runCachedNode 511 128810 Adaptive138Third137Node27 = false := by
  decide +kernel

#print axioms adaptive138Third137Proof27

end NineSeparatedSubsetSums
