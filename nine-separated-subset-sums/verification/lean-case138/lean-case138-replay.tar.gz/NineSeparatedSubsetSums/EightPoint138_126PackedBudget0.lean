import NineSeparatedSubsetSums.EightPoint138_126PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct138_126_0_budget :
    FourPointNumeric.packedBudget 20 packedOct138_126_0 411 = 85456626 := by decide +kernel

#print axioms packedOct138_126_0_budget

end NineSeparatedSubsetSums
