import NineSeparatedSubsetSums.Adaptive138Third128State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third128Proof16 : runCachedNode 511 127087 Adaptive138Third128Node16 = false := by
  decide +kernel

#print axioms adaptive138Third128Proof16

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third128Proof15 : runCachedNode 511 127087 Adaptive138Third128Node15 = false := by
  decide +kernel

#print axioms adaptive138Third128Proof15

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third128Proof10 : runCachedNode 511 127087 Adaptive138Third128Node10 = false := by
  decide +kernel

#print axioms adaptive138Third128Proof10

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third128Proof1 : runCachedNode 511 127087 Adaptive138Third128Node1 = false := by
  decide +kernel

#print axioms adaptive138Third128Proof1

end NineSeparatedSubsetSums
