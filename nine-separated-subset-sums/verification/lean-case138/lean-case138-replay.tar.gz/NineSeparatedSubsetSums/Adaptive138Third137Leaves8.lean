import NineSeparatedSubsetSums.Adaptive138Third137State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third137Proof152 : runCachedNode 511 128810 Adaptive138Third137Node152 = false := by
  decide +kernel

#print axioms adaptive138Third137Proof152

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third137Proof189 : runCachedNode 511 128810 Adaptive138Third137Node189 = false := by
  decide +kernel

#print axioms adaptive138Third137Proof189

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third137Proof69 : runCachedNode 511 128810 Adaptive138Third137Node69 = false := by
  decide +kernel

#print axioms adaptive138Third137Proof69

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third137Proof28 : runCachedNode 511 128810 Adaptive138Third137Node28 = false := by
  decide +kernel

#print axioms adaptive138Third137Proof28

end NineSeparatedSubsetSums
