import NineSeparatedSubsetSums.EightPoint138_131PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct138_131_0_budget :
    FourPointNumeric.packedBudget 20 packedOct138_131_0 453 = 89673225 := by decide +kernel

#print axioms packedOct138_131_0_budget

end NineSeparatedSubsetSums
