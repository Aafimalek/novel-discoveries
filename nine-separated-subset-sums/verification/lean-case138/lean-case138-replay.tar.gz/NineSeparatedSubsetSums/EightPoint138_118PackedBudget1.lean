import NineSeparatedSubsetSums.EightPoint138_118PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct138_118_1_budget :
    FourPointNumeric.packedBudget 20 packedOct138_118_1 272 = 81784728 := by decide +kernel

#print axioms packedOct138_118_1_budget

end NineSeparatedSubsetSums
