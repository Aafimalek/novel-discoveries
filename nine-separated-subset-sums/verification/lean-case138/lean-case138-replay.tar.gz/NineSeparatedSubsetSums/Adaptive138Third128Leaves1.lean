import NineSeparatedSubsetSums.Adaptive138Third128State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third128Proof14 : runCachedNode 511 127087 Adaptive138Third128Node14 = false := by
  decide +kernel

#print axioms adaptive138Third128Proof14

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third128Proof13 : runCachedNode 511 127087 Adaptive138Third128Node13 = false := by
  decide +kernel

#print axioms adaptive138Third128Proof13

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third128Proof12 : runCachedNode 511 127087 Adaptive138Third128Node12 = false := by
  decide +kernel

#print axioms adaptive138Third128Proof12

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third128Proof11 : runCachedNode 511 127087 Adaptive138Third128Node11 = false := by
  decide +kernel

#print axioms adaptive138Third128Proof11

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third128Proof4 : runCachedNode 511 127087 Adaptive138Third128Node4 = false := by
  decide +kernel

#print axioms adaptive138Third128Proof4

end NineSeparatedSubsetSums
