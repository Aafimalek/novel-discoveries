import NineSeparatedSubsetSums.EightPoint138_120PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct138_120_0_budget :
    FourPointNumeric.packedBudget 20 packedOct138_120_0 273 = 84260407 := by decide +kernel

#print axioms packedOct138_120_0_budget

end NineSeparatedSubsetSums
