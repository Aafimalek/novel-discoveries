import NineSeparatedSubsetSums.Adaptive138Third135State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third135Proof20 : runCachedNode 511 128437 Adaptive138Third135Node20 = false := by
  decide +kernel

#print axioms adaptive138Third135Proof20

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third135Proof69 : runCachedNode 511 128437 Adaptive138Third135Node69 = false := by
  decide +kernel

#print axioms adaptive138Third135Proof69

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third135Proof4 : runCachedNode 511 128437 Adaptive138Third135Node4 = false := by
  decide +kernel

#print axioms adaptive138Third135Proof4

end NineSeparatedSubsetSums
