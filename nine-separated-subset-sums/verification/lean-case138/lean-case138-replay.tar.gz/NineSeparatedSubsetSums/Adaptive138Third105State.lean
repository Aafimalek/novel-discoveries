import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive138Third105Node0 : CachedSearchNode :=
  ⟨4, 104, computeCenteredMask [148,138,105], 391, 51973⟩

end NineSeparatedSubsetSums
