import NineSeparatedSubsetSums.Adaptive138Third135State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third135Proof95 : runCachedNode 511 128437 Adaptive138Third135Node95 = false := by
  decide +kernel

#print axioms adaptive138Third135Proof95

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third135Proof43 : runCachedNode 511 128437 Adaptive138Third135Node43 = false := by
  decide +kernel

#print axioms adaptive138Third135Proof43

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third135Proof14 : runCachedNode 511 128437 Adaptive138Third135Node14 = false := by
  decide +kernel

#print axioms adaptive138Third135Proof14

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third135Proof42 : runCachedNode 511 128437 Adaptive138Third135Node42 = false := by
  decide +kernel

#print axioms adaptive138Third135Proof42

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third135Proof96 : runCachedNode 511 128437 Adaptive138Third135Node96 = false := by
  decide +kernel

#print axioms adaptive138Third135Proof96

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third135Proof70 : runCachedNode 511 128437 Adaptive138Third135Node70 = false := by
  decide +kernel

#print axioms adaptive138Third135Proof70

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third135Proof71 : runCachedNode 511 128437 Adaptive138Third135Node71 = false := by
  decide +kernel

#print axioms adaptive138Third135Proof71

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third135Proof79 : runCachedNode 511 128437 Adaptive138Third135Node79 = false := by
  decide +kernel

#print axioms adaptive138Third135Proof79

end NineSeparatedSubsetSums
