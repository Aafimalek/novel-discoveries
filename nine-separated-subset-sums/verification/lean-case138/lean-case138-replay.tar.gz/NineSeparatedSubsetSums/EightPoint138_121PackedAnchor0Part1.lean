import NineSeparatedSubsetSums.EightPoint138_121PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint138_121PackedAnchor0Part1 :
    ∀ j : Fin 120, 2370677 ≤ FourPointNumeric.octPackedCharge 138 121 20 packedOct138_121_0
      (2*((j.val : Int)+120)+1) := by decide +kernel

end NineSeparatedSubsetSums
