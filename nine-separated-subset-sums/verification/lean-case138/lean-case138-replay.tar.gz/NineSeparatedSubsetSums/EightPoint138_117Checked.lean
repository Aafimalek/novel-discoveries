import NineSeparatedSubsetSums.EightPointPackedGeometry
import NineSeparatedSubsetSums.EightPoint138_117PackedBudget0
import NineSeparatedSubsetSums.EightPoint138_117PackedAnchor0Part0
import NineSeparatedSubsetSums.EightPoint138_117PackedAnchor0Part1
import NineSeparatedSubsetSums.EightPoint138_117PackedBudget1
import NineSeparatedSubsetSums.EightPoint138_117PackedAnchor1Part0
import NineSeparatedSubsetSums.EightPoint138_117PackedAnchor1Part1

namespace NineSeparatedSubsetSums

private theorem packedOct138_117Anchor0 :
  ∀ j : Fin 479, ((j.val : Int)+138+117)%2=0 →
    2265048 ≤ FourPointNumeric.octPackedCharge 138 117 20 packedOct138_117_0 (j.val : Int) := by
  intro j hj
  let k := (j.val-1)/2
  have hk : k < 239 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+1 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint138_117PackedAnchor0Part0 z
    rwa [he,hrep] at ht
  let z : Fin 119 := ⟨k-120, by omega⟩
  have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
  have ht := eightPoint138_117PackedAnchor0Part1 z
  rwa [he,hrep] at ht

private theorem packedOct138_117Anchor1 :
  ∀ j : Fin 479, ((j.val : Int)+138+117)%2=1 →
    2265010 ≤ FourPointNumeric.octPackedCharge 138 117 20 packedOct138_117_1 (j.val : Int) := by
  intro j hj
  let k := (j.val-0)/2
  have hk : k < 240 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+0 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint138_117PackedAnchor1Part0 z
    rwa [he,hrep] at ht
  let z : Fin 120 := ⟨k-120, by omega⟩
  have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
  have ht := eightPoint138_117PackedAnchor1Part1 z
  rwa [he,hrep] at ht

def packedOctCertificate138_117_0 : EightPointCertificate 138 117 0 124697 :=
  eightPointCertificateOfPacked 138 117 0 124697 2265048 20 packedOct138_117_0 265 479
    (by decide +kernel) (by decide) packedOct138_117Anchor0
    (by rw [packedOct138_117_0_budget]; decide)

def packedOctCertificate138_117_1 : EightPointCertificate 138 117 1 124697 :=
  eightPointCertificateOfPacked 138 117 1 124697 2265010 20 packedOct138_117_1 350 479
    (by decide +kernel) (by decide) packedOct138_117Anchor1
    (by rw [packedOct138_117_1_budget]; decide)

theorem max148_second138_third117_eightPoint_moment_bound (tail : List ℕ) (len : tail.length=6)
    (distinct : (natSubsetSums (148::138::117::tail)).Nodup) :
    124697 ≤ ((148::138::117::tail).map (· ^ 2)).sum := by
  apply eightPointNatMomentLower 138 117 124697 tail len distinct
  intro p hp
  by_cases h : p=0
  · subst p
    exact packedOctCertificate138_117_0
  · have he : p=1 := hp.resolve_left h
    subst p
    exact packedOctCertificate138_117_1

#print axioms max148_second138_third117_eightPoint_moment_bound

end NineSeparatedSubsetSums
