import NineSeparatedSubsetSums.Adaptive138Third112Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint138Checked

namespace NineSeparatedSubsetSums


theorem adaptive138Third112 : NoDescendingTailAfterThird 138 112 :=
  noDescendingThirdTail_of_cached 138 112 111079 (fun t ht nd => max148_second138_fourPoint_moment_bound (112::t) (by simp [ht]) nd) adaptive138Third112Proof0

#print axioms adaptive138Third112

end NineSeparatedSubsetSums
