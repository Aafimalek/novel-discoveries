import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive138Third113Node0 : CachedSearchNode :=
  ⟨4, 112, computeCenteredMask [148,138,113], 399, 53717⟩

end NineSeparatedSubsetSums
