import NineSeparatedSubsetSums.Adaptive138Third134State
import NineSeparatedSubsetSums.Adaptive138Third134Leaves3
import NineSeparatedSubsetSums.Adaptive138Third134Leaves7
import NineSeparatedSubsetSums.Adaptive138Third134Leaves6
import NineSeparatedSubsetSums.Adaptive138Third134Leaves0
import NineSeparatedSubsetSums.Adaptive138Third134Leaves4
import NineSeparatedSubsetSums.Adaptive138Third134Leaves5
import NineSeparatedSubsetSums.Adaptive138Third134Leaves2
import NineSeparatedSubsetSums.Adaptive138Third134Leaves8
import NineSeparatedSubsetSums.Adaptive138Third134Leaves1

namespace NineSeparatedSubsetSums

theorem adaptive138Third134Proof20 : runCachedNode 511 128232 Adaptive138Third134Node20 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 128232 Adaptive138Third134Node20 = [105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 117, 118, 119, 121, 122, 123, 125, 127, 128, 129] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive138Third134Proof21
  · exact adaptive138Third134Proof22
  · exact adaptive138Third134Proof23
  · exact adaptive138Third134Proof24
  · exact adaptive138Third134Proof25
  · exact adaptive138Third134Proof26
  · exact adaptive138Third134Proof27
  · exact adaptive138Third134Proof28
  · exact adaptive138Third134Proof29
  · exact adaptive138Third134Proof30
  · exact adaptive138Third134Proof31
  · exact adaptive138Third134Proof32
  · exact adaptive138Third134Proof33
  · exact adaptive138Third134Proof34
  · exact adaptive138Third134Proof35
  · exact adaptive138Third134Proof36
  · exact adaptive138Third134Proof37
  · exact adaptive138Third134Proof38
  · exact adaptive138Third134Proof39
  · exact adaptive138Third134Proof40
  · exact adaptive138Third134Proof41

#print axioms adaptive138Third134Proof20

theorem adaptive138Third134Proof43 : runCachedNode 511 128232 Adaptive138Third134Node43 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 128232 Adaptive138Third134Node43 = [104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 119, 120, 121, 123, 125, 126, 127, 129, 130, 131] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive138Third134Proof44
  · exact adaptive138Third134Proof45
  · exact adaptive138Third134Proof46
  · exact adaptive138Third134Proof47
  · exact adaptive138Third134Proof48
  · exact adaptive138Third134Proof49
  · exact adaptive138Third134Proof50
  · exact adaptive138Third134Proof51
  · exact adaptive138Third134Proof52
  · exact adaptive138Third134Proof53
  · exact adaptive138Third134Proof54
  · exact adaptive138Third134Proof55
  · exact adaptive138Third134Proof56
  · exact adaptive138Third134Proof57
  · exact adaptive138Third134Proof58
  · exact adaptive138Third134Proof59
  · exact adaptive138Third134Proof60
  · exact adaptive138Third134Proof61
  · exact adaptive138Third134Proof62
  · exact adaptive138Third134Proof63
  · exact adaptive138Third134Proof64
  · exact adaptive138Third134Proof65
  · exact adaptive138Third134Proof66
  · exact adaptive138Third134Proof67

#print axioms adaptive138Third134Proof43

theorem adaptive138Third134Proof68 : runCachedNode 511 128232 Adaptive138Third134Node68 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 128232 Adaptive138Third134Node68 = [104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 120, 121, 122, 125, 126, 127, 128, 130, 131, 132] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive138Third134Proof69
  · exact adaptive138Third134Proof70
  · exact adaptive138Third134Proof71
  · exact adaptive138Third134Proof72
  · exact adaptive138Third134Proof73
  · exact adaptive138Third134Proof74
  · exact adaptive138Third134Proof75
  · exact adaptive138Third134Proof76
  · exact adaptive138Third134Proof77
  · exact adaptive138Third134Proof78
  · exact adaptive138Third134Proof79
  · exact adaptive138Third134Proof80
  · exact adaptive138Third134Proof81
  · exact adaptive138Third134Proof82
  · exact adaptive138Third134Proof83
  · exact adaptive138Third134Proof84
  · exact adaptive138Third134Proof85
  · exact adaptive138Third134Proof86
  · exact adaptive138Third134Proof87
  · exact adaptive138Third134Proof88
  · exact adaptive138Third134Proof89
  · exact adaptive138Third134Proof90
  · exact adaptive138Third134Proof91
  · exact adaptive138Third134Proof92
  · exact adaptive138Third134Proof93

#print axioms adaptive138Third134Proof68

theorem adaptive138Third134Proof0 : runCachedNode 511 128232 Adaptive138Third134Node0 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 128232 Adaptive138Third134Node0 = [110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 125, 126, 127, 128, 129, 130, 131, 132, 133] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive138Third134Proof1
  · exact adaptive138Third134Proof2
  · exact adaptive138Third134Proof3
  · exact adaptive138Third134Proof4
  · exact adaptive138Third134Proof5
  · exact adaptive138Third134Proof6
  · exact adaptive138Third134Proof7
  · exact adaptive138Third134Proof8
  · exact adaptive138Third134Proof9
  · exact adaptive138Third134Proof10
  · exact adaptive138Third134Proof11
  · exact adaptive138Third134Proof12
  · exact adaptive138Third134Proof13
  · exact adaptive138Third134Proof14
  · exact adaptive138Third134Proof15
  · exact adaptive138Third134Proof16
  · exact adaptive138Third134Proof17
  · exact adaptive138Third134Proof18
  · exact adaptive138Third134Proof19
  · exact adaptive138Third134Proof20
  · exact adaptive138Third134Proof42
  · exact adaptive138Third134Proof43
  · exact adaptive138Third134Proof68

#print axioms adaptive138Third134Proof0

end NineSeparatedSubsetSums
