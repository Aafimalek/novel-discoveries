import NineSeparatedSubsetSums.Adaptive138Third136State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third136Proof96 : runCachedNode 511 128623 Adaptive138Third136Node96 = false := by
  decide +kernel

#print axioms adaptive138Third136Proof96

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third136Proof157 : runCachedNode 511 128623 Adaptive138Third136Node157 = false := by
  decide +kernel

#print axioms adaptive138Third136Proof157

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third136Proof17 : runCachedNode 511 128623 Adaptive138Third136Node17 = false := by
  decide +kernel

#print axioms adaptive138Third136Proof17

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third136Proof46 : runCachedNode 511 128623 Adaptive138Third136Node46 = false := by
  decide +kernel

#print axioms adaptive138Third136Proof46

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third136Proof115 : runCachedNode 511 128623 Adaptive138Third136Node115 = false := by
  decide +kernel

#print axioms adaptive138Third136Proof115

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third136Proof102 : runCachedNode 511 128623 Adaptive138Third136Node102 = false := by
  decide +kernel

#print axioms adaptive138Third136Proof102

end NineSeparatedSubsetSums
