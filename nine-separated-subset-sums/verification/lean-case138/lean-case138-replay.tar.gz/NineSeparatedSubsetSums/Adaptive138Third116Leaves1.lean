import NineSeparatedSubsetSums.Adaptive138Third116State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third116Proof12 : runCachedNode 511 111079 Adaptive138Third116Node12 = false := by
  decide +kernel

#print axioms adaptive138Third116Proof12

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third116Proof11 : runCachedNode 511 111079 Adaptive138Third116Node11 = false := by
  decide +kernel

#print axioms adaptive138Third116Proof11

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third116Proof10 : runCachedNode 511 111079 Adaptive138Third116Node10 = false := by
  decide +kernel

#print axioms adaptive138Third116Proof10

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third116Proof9 : runCachedNode 511 111079 Adaptive138Third116Node9 = false := by
  decide +kernel

#print axioms adaptive138Third116Proof9

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third116Proof8 : runCachedNode 511 111079 Adaptive138Third116Node8 = false := by
  decide +kernel

#print axioms adaptive138Third116Proof8

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third116Proof6 : runCachedNode 511 111079 Adaptive138Third116Node6 = false := by
  decide +kernel

#print axioms adaptive138Third116Proof6

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third116Proof5 : runCachedNode 511 111079 Adaptive138Third116Node5 = false := by
  decide +kernel

#print axioms adaptive138Third116Proof5

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third116Proof3 : runCachedNode 511 111079 Adaptive138Third116Node3 = false := by
  decide +kernel

#print axioms adaptive138Third116Proof3

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third116Proof2 : runCachedNode 511 111079 Adaptive138Third116Node2 = false := by
  decide +kernel

#print axioms adaptive138Third116Proof2

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third116Proof1 : runCachedNode 511 111079 Adaptive138Third116Node1 = false := by
  decide +kernel

#print axioms adaptive138Third116Proof1

end NineSeparatedSubsetSums
