import NineSeparatedSubsetSums.Adaptive138Third137State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third137Proof156 : runCachedNode 511 128810 Adaptive138Third137Node156 = false := by
  decide +kernel

#print axioms adaptive138Third137Proof156

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third137Proof17 : runCachedNode 511 128810 Adaptive138Third137Node17 = false := by
  decide +kernel

#print axioms adaptive138Third137Proof17

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive138Third137Proof66 : runCachedNode 511 128810 Adaptive138Third137Node66 = false := by
  decide +kernel

#print axioms adaptive138Third137Proof66

end NineSeparatedSubsetSums
