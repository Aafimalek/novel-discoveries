import NineSeparatedSubsetSums.EightPoint138_129PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint138_129PackedAnchor0Part2 :
    ∀ j : Fin 4, 2373241 ≤ FourPointNumeric.octPackedCharge 138 129 20 packedOct138_129_0
      (2*((j.val : Int)+240)+1) := by decide +kernel

end NineSeparatedSubsetSums
