import NineSeparatedSubsetSums.EightPoint138_136PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct138_136_0_budget :
    FourPointNumeric.packedBudget 20 packedOct138_136_0 447 = 91312331 := by decide +kernel

#print axioms packedOct138_136_0_budget

end NineSeparatedSubsetSums
