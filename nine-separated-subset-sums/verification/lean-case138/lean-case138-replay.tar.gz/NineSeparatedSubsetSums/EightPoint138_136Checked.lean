import NineSeparatedSubsetSums.EightPointPackedGeometry
import NineSeparatedSubsetSums.EightPoint138_136PackedBudget0
import NineSeparatedSubsetSums.EightPoint138_136PackedAnchor0Part0
import NineSeparatedSubsetSums.EightPoint138_136PackedAnchor0Part1
import NineSeparatedSubsetSums.EightPoint138_136PackedAnchor0Part2
import NineSeparatedSubsetSums.EightPoint138_136PackedBudget1
import NineSeparatedSubsetSums.EightPoint138_136PackedAnchor1Part0
import NineSeparatedSubsetSums.EightPoint138_136PackedAnchor1Part1
import NineSeparatedSubsetSums.EightPoint138_136PackedAnchor1Part2

namespace NineSeparatedSubsetSums

private theorem packedOct138_136Anchor0 :
  ∀ j : Fin 498, ((j.val : Int)+138+136)%2=0 →
    2455736 ≤ FourPointNumeric.octPackedCharge 138 136 20 packedOct138_136_0 (j.val : Int) := by
  intro j hj
  let k := (j.val-0)/2
  have hk : k < 249 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+0 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint138_136PackedAnchor0Part0 z
    rwa [he,hrep] at ht
  by_cases h1 : k < 240
  · let z : Fin 120 := ⟨k-120, by omega⟩
    have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
    have ht := eightPoint138_136PackedAnchor0Part1 z
    rwa [he,hrep] at ht
  let z : Fin 9 := ⟨k-240, by omega⟩
  have he : (z.val : Int)+240 = k := by dsimp [z] <;> omega
  have ht := eightPoint138_136PackedAnchor0Part2 z
  rwa [he,hrep] at ht

private theorem packedOct138_136Anchor1 :
  ∀ j : Fin 498, ((j.val : Int)+138+136)%2=1 →
    2451952 ≤ FourPointNumeric.octPackedCharge 138 136 20 packedOct138_136_1 (j.val : Int) := by
  intro j hj
  let k := (j.val-1)/2
  have hk : k < 249 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+1 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint138_136PackedAnchor1Part0 z
    rwa [he,hrep] at ht
  by_cases h1 : k < 240
  · let z : Fin 120 := ⟨k-120, by omega⟩
    have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
    have ht := eightPoint138_136PackedAnchor1Part1 z
    rwa [he,hrep] at ht
  let z : Fin 9 := ⟨k-240, by omega⟩
  have he : (z.val : Int)+240 = k := by dsimp [z] <;> omega
  have ht := eightPoint138_136PackedAnchor1Part2 z
  rwa [he,hrep] at ht

def packedOctCertificate138_136_0 : EightPointCertificate 138 136 0 128623 :=
  eightPointCertificateOfPacked 138 136 0 128623 2455736 20 packedOct138_136_0 447 498
    (by decide +kernel) (by decide) packedOct138_136Anchor0
    (by rw [packedOct138_136_0_budget]; decide)

def packedOctCertificate138_136_1 : EightPointCertificate 138 136 1 128623 :=
  eightPointCertificateOfPacked 138 136 1 128623 2451952 20 packedOct138_136_1 486 498
    (by decide +kernel) (by decide) packedOct138_136Anchor1
    (by rw [packedOct138_136_1_budget]; decide)

theorem max148_second138_third136_eightPoint_moment_bound (tail : List ℕ) (len : tail.length=6)
    (distinct : (natSubsetSums (148::138::136::tail)).Nodup) :
    128623 ≤ ((148::138::136::tail).map (· ^ 2)).sum := by
  apply eightPointNatMomentLower 138 136 128623 tail len distinct
  intro p hp
  by_cases h : p=0
  · subst p
    exact packedOctCertificate138_136_0
  · have he : p=1 := hp.resolve_left h
    subst p
    exact packedOctCertificate138_136_1

#print axioms max148_second138_third136_eightPoint_moment_bound

end NineSeparatedSubsetSums
