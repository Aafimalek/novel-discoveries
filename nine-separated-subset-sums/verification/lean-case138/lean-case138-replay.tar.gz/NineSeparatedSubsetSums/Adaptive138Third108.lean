import NineSeparatedSubsetSums.Adaptive138Third108Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint138Checked

namespace NineSeparatedSubsetSums


theorem adaptive138Third108 : NoDescendingTailAfterThird 138 108 :=
  noDescendingThirdTail_of_cached 138 108 111079 (fun t ht nd => max148_second138_fourPoint_moment_bound (108::t) (by simp [ht]) nd) adaptive138Third108Proof0

#print axioms adaptive138Third108

end NineSeparatedSubsetSums
