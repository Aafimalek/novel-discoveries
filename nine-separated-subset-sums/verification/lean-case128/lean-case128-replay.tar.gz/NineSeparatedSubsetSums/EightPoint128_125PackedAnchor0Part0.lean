import NineSeparatedSubsetSums.EightPoint128_125PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint128_125PackedAnchor0Part0 :
    ∀ j : Fin 120, 2344086 ≤ FourPointNumeric.octPackedCharge 128 125 20 packedOct128_125_0
      (2*((j.val : Int)+0)+1) := by decide +kernel

end NineSeparatedSubsetSums
