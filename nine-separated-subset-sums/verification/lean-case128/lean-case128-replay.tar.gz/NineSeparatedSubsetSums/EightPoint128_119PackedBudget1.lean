import NineSeparatedSubsetSums.EightPoint128_119PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct128_119_1_budget :
    FourPointNumeric.packedBudget 20 packedOct128_119_1 268 = 77245036 := by decide +kernel

#print axioms packedOct128_119_1_budget

end NineSeparatedSubsetSums
