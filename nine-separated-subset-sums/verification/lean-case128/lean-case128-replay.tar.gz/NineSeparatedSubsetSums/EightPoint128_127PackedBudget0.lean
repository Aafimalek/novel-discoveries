import NineSeparatedSubsetSums.EightPoint128_127PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct128_127_0_budget :
    FourPointNumeric.packedBudget 20 packedOct128_127_0 449 = 84564051 := by decide +kernel

#print axioms packedOct128_127_0_budget

end NineSeparatedSubsetSums
