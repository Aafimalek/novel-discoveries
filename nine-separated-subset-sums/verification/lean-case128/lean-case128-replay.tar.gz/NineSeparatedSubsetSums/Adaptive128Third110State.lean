import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive128Third110Node0 : CachedSearchNode :=
  ⟨4, 109, computeCenteredMask [148,128,110], 386, 50388⟩

end NineSeparatedSubsetSums
