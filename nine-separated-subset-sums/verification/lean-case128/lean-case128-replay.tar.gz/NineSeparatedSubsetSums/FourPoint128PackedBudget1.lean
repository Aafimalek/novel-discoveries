import NineSeparatedSubsetSums.FourPoint128PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedWeight128_1_budget :
    FourPointNumeric.packedBudget 19 packedWeight128_1 360 = 67962880 := by decide +kernel

#print axioms packedWeight128_1_budget

end NineSeparatedSubsetSums
