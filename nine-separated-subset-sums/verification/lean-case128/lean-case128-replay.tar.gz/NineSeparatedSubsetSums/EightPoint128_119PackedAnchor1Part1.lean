import NineSeparatedSubsetSums.EightPoint128_119PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint128_119PackedAnchor1Part1 :
    ∀ j : Fin 116, 2191987 ≤ FourPointNumeric.octPackedCharge 128 119 20 packedOct128_119_1
      (2*((j.val : Int)+120)+0) := by decide +kernel

end NineSeparatedSubsetSums
