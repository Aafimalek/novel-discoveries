import NineSeparatedSubsetSums.EightPoint128_118PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct128_118_0_budget :
    FourPointNumeric.packedBudget 20 packedOct128_118_0 463 = 76850631 := by decide +kernel

#print axioms packedOct128_118_0_budget

end NineSeparatedSubsetSums
