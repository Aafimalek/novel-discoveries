import NineSeparatedSubsetSums.EightPoint128_116PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint128_116PackedAnchor1Part1 :
    ∀ j : Fin 117, 2204035 ≤ FourPointNumeric.octPackedCharge 128 116 20 packedOct128_116_1
      (2*((j.val : Int)+120)+1) := by decide +kernel

end NineSeparatedSubsetSums
