import NineSeparatedSubsetSums.EightPoint128_120PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct128_120_0_budget :
    FourPointNumeric.packedBudget 20 packedOct128_120_0 265 = 77318171 := by decide +kernel

#print axioms packedOct128_120_0_budget

end NineSeparatedSubsetSums
