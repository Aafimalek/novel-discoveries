import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive128Third120Node0 : CachedSearchNode :=
  ⟨4, 119, computeCenteredMask [148,128,120], 396, 52688⟩

end NineSeparatedSubsetSums
