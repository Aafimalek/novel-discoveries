import NineSeparatedSubsetSums.Adaptive128Third114State
import NineSeparatedSubsetSums.Adaptive128Third114Leaves0
import NineSeparatedSubsetSums.Adaptive128Third114Leaves1

namespace NineSeparatedSubsetSums

theorem adaptive128Third114Proof0 : runCachedNode 511 109269 Adaptive128Third114Node0 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 109269 Adaptive128Third114Node0 = [101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive128Third114Proof1
  · exact adaptive128Third114Proof2
  · exact adaptive128Third114Proof3
  · exact adaptive128Third114Proof4
  · exact adaptive128Third114Proof5
  · exact adaptive128Third114Proof6
  · exact adaptive128Third114Proof7
  · exact adaptive128Third114Proof8
  · exact adaptive128Third114Proof9
  · exact adaptive128Third114Proof10
  · exact adaptive128Third114Proof11
  · exact adaptive128Third114Proof12
  · exact adaptive128Third114Proof13

#print axioms adaptive128Third114Proof0

end NineSeparatedSubsetSums
