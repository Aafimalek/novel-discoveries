import NineSeparatedSubsetSums.Adaptive128Third124State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive128Third124Proof0 : runCachedNode 511 124340 Adaptive128Third124Node0 = false := by
  decide +kernel

#print axioms adaptive128Third124Proof0

end NineSeparatedSubsetSums
