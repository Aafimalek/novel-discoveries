import NineSeparatedSubsetSums.EightPoint128_122PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint128_122PackedAnchor0Part1 :
    ∀ j : Fin 120, 2385924 ≤ FourPointNumeric.octPackedCharge 128 122 20 packedOct128_122_0
      (2*((j.val : Int)+120)+0) := by decide +kernel

end NineSeparatedSubsetSums
