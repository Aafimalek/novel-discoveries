import NineSeparatedSubsetSums.Adaptive128Third104Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint128Checked

namespace NineSeparatedSubsetSums


theorem adaptive128Third104 : NoDescendingTailAfterThird 128 104 :=
  noDescendingThirdTail_of_cached 128 104 109269 (fun t ht nd => max148_second128_fourPoint_moment_bound (104::t) (by simp [ht]) nd) adaptive128Third104Proof0

#print axioms adaptive128Third104

end NineSeparatedSubsetSums
