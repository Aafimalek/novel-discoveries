import NineSeparatedSubsetSums.Adaptive128Third114Joins0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint128Checked

namespace NineSeparatedSubsetSums


theorem adaptive128Third114 : NoDescendingTailAfterThird 128 114 :=
  noDescendingThirdTail_of_cached 128 114 109269 (fun t ht nd => max148_second128_fourPoint_moment_bound (114::t) (by simp [ht]) nd) adaptive128Third114Proof0

#print axioms adaptive128Third114

end NineSeparatedSubsetSums
