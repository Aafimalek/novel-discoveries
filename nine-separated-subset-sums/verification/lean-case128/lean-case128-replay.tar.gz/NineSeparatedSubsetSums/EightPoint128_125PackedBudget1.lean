import NineSeparatedSubsetSums.EightPoint128_125PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct128_125_1_budget :
    FourPointNumeric.packedBudget 20 packedOct128_125_1 378 = 86252204 := by decide +kernel

#print axioms packedOct128_125_1_budget

end NineSeparatedSubsetSums
