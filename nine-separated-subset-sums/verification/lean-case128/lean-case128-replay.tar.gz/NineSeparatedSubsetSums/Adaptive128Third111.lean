import NineSeparatedSubsetSums.Adaptive128Third111Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint128Checked

namespace NineSeparatedSubsetSums


theorem adaptive128Third111 : NoDescendingTailAfterThird 128 111 :=
  noDescendingThirdTail_of_cached 128 111 109269 (fun t ht nd => max148_second128_fourPoint_moment_bound (111::t) (by simp [ht]) nd) adaptive128Third111Proof0

#print axioms adaptive128Third111

end NineSeparatedSubsetSums
