import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive128Third108Node0 : CachedSearchNode :=
  ⟨4, 107, computeCenteredMask [148,128,108], 384, 49952⟩

end NineSeparatedSubsetSums
