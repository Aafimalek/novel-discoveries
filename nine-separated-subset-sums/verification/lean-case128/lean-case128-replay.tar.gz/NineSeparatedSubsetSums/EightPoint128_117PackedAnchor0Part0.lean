import NineSeparatedSubsetSums.EightPoint128_117PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint128_117PackedAnchor0Part0 :
    ∀ j : Fin 120, 2194508 ≤ FourPointNumeric.octPackedCharge 128 117 20 packedOct128_117_0
      (2*((j.val : Int)+0)+1) := by decide +kernel

end NineSeparatedSubsetSums
