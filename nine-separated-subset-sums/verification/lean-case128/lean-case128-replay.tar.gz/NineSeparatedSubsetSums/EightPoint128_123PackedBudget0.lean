import NineSeparatedSubsetSums.EightPoint128_123PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct128_123_0_budget :
    FourPointNumeric.packedBudget 20 packedOct128_123_0 493 = 87992636 := by decide +kernel

#print axioms packedOct128_123_0_budget

end NineSeparatedSubsetSums
