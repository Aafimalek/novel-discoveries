import NineSeparatedSubsetSums.FourPoint128PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem fourPoint128PackedAnchor1Part1 :
    ∀ j : Fin 106, 968036 ≤ FourPointNumeric.packedCharge 128 19 packedWeight128_1
      (2*((j.val : Int)+120)+1) := by decide +kernel

end NineSeparatedSubsetSums
