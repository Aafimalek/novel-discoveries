import NineSeparatedSubsetSums.Adaptive128Third106State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive128Third106Proof0 : runCachedNode 511 109269 Adaptive128Third106Node0 = false := by
  decide +kernel

#print axioms adaptive128Third106Proof0

end NineSeparatedSubsetSums
