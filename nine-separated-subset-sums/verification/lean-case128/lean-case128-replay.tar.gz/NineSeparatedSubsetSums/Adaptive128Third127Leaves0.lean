import NineSeparatedSubsetSums.Adaptive128Third127State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive128Third127Proof0 : runCachedNode 511 124917 Adaptive128Third127Node0 = false := by
  decide +kernel

#print axioms adaptive128Third127Proof0

end NineSeparatedSubsetSums
