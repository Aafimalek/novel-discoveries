import NineSeparatedSubsetSums.EightPoint128_121PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint128_121PackedAnchor1Part0 :
    ∀ j : Fin 120, 2243768 ≤ FourPointNumeric.octPackedCharge 128 121 20 packedOct128_121_1
      (2*((j.val : Int)+0)+0) := by decide +kernel

end NineSeparatedSubsetSums
