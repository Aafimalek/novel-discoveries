import NineSeparatedSubsetSums.EightPoint128_120PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint128_120PackedAnchor0Part1 :
    ∀ j : Fin 116, 2193971 ≤ FourPointNumeric.octPackedCharge 128 120 20 packedOct128_120_0
      (2*((j.val : Int)+120)+0) := by decide +kernel

end NineSeparatedSubsetSums
