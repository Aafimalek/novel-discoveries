import NineSeparatedSubsetSums.Adaptive128Third105Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint128Checked

namespace NineSeparatedSubsetSums


theorem adaptive128Third105 : NoDescendingTailAfterThird 128 105 :=
  noDescendingThirdTail_of_cached 128 105 109269 (fun t ht nd => max148_second128_fourPoint_moment_bound (105::t) (by simp [ht]) nd) adaptive128Third105Proof0

#print axioms adaptive128Third105

end NineSeparatedSubsetSums
