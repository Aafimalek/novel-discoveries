import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive128Third106Node0 : CachedSearchNode :=
  ⟨4, 105, computeCenteredMask [148,128,106], 382, 49524⟩

end NineSeparatedSubsetSums
