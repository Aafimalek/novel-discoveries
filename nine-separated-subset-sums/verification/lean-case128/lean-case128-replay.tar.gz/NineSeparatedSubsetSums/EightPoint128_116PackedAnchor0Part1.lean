import NineSeparatedSubsetSums.EightPoint128_116PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint128_116PackedAnchor0Part1 :
    ∀ j : Fin 117, 2205543 ≤ FourPointNumeric.octPackedCharge 128 116 20 packedOct128_116_0
      (2*((j.val : Int)+120)+0) := by decide +kernel

end NineSeparatedSubsetSums
