import NineSeparatedSubsetSums.Adaptive128Third109Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint128Checked

namespace NineSeparatedSubsetSums


theorem adaptive128Third109 : NoDescendingTailAfterThird 128 109 :=
  noDescendingThirdTail_of_cached 128 109 109269 (fun t ht nd => max148_second128_fourPoint_moment_bound (109::t) (by simp [ht]) nd) adaptive128Third109Proof0

#print axioms adaptive128Third109

end NineSeparatedSubsetSums
