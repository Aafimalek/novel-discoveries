import NineSeparatedSubsetSums.EightPoint128_123PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint128_123PackedAnchor1Part2 :
    ∀ j : Fin 7, 2363600 ≤ FourPointNumeric.octPackedCharge 128 123 20 packedOct128_123_1
      (2*((j.val : Int)+240)+0) := by decide +kernel

end NineSeparatedSubsetSums
