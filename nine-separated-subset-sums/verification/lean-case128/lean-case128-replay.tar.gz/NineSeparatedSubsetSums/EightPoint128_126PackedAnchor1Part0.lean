import NineSeparatedSubsetSums.EightPoint128_126PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint128_126PackedAnchor1Part0 :
    ∀ j : Fin 120, 2324322 ≤ FourPointNumeric.octPackedCharge 128 126 20 packedOct128_126_1
      (2*((j.val : Int)+0)+1) := by decide +kernel

end NineSeparatedSubsetSums
