import NineSeparatedSubsetSums.Adaptive128Third115Joins0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint128Checked

namespace NineSeparatedSubsetSums


theorem adaptive128Third115 : NoDescendingTailAfterThird 128 115 :=
  noDescendingThirdTail_of_cached 128 115 109269 (fun t ht nd => max148_second128_fourPoint_moment_bound (115::t) (by simp [ht]) nd) adaptive128Third115Proof0

#print axioms adaptive128Third115

end NineSeparatedSubsetSums
