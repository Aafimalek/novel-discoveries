import NineSeparatedSubsetSums.Adaptive128Third122State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive128Third122Proof0 : runCachedNode 511 123780 Adaptive128Third122Node0 = false := by
  decide +kernel

#print axioms adaptive128Third122Proof0

end NineSeparatedSubsetSums
