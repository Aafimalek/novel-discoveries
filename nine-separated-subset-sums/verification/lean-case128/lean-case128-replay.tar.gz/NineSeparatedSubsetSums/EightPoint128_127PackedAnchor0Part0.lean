import NineSeparatedSubsetSums.EightPoint128_127PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint128_127PackedAnchor0Part0 :
    ∀ j : Fin 120, 2320648 ≤ FourPointNumeric.octPackedCharge 128 127 20 packedOct128_127_0
      (2*((j.val : Int)+0)+1) := by decide +kernel

end NineSeparatedSubsetSums
