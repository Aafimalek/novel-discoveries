import NineSeparatedSubsetSums.EightPointPackedGeometry
import NineSeparatedSubsetSums.EightPoint128_116PackedBudget0
import NineSeparatedSubsetSums.EightPoint128_116PackedAnchor0Part0
import NineSeparatedSubsetSums.EightPoint128_116PackedAnchor0Part1
import NineSeparatedSubsetSums.EightPoint128_116PackedBudget1
import NineSeparatedSubsetSums.EightPoint128_116PackedAnchor1Part0
import NineSeparatedSubsetSums.EightPoint128_116PackedAnchor1Part1

namespace NineSeparatedSubsetSums

private theorem packedOct128_116Anchor0 :
  ∀ j : Fin 474, ((j.val : Int)+128+116)%2=0 →
    2205543 ≤ FourPointNumeric.octPackedCharge 128 116 20 packedOct128_116_0 (j.val : Int) := by
  intro j hj
  let k := (j.val-0)/2
  have hk : k < 237 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+0 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint128_116PackedAnchor0Part0 z
    rwa [he,hrep] at ht
  let z : Fin 117 := ⟨k-120, by omega⟩
  have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
  have ht := eightPoint128_116PackedAnchor0Part1 z
  rwa [he,hrep] at ht

private theorem packedOct128_116Anchor1 :
  ∀ j : Fin 474, ((j.val : Int)+128+116)%2=1 →
    2204035 ≤ FourPointNumeric.octPackedCharge 128 116 20 packedOct128_116_1 (j.val : Int) := by
  intro j hj
  let k := (j.val-1)/2
  have hk : k < 237 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+1 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint128_116PackedAnchor1Part0 z
    rwa [he,hrep] at ht
  let z : Fin 117 := ⟨k-120, by omega⟩
  have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
  have ht := eightPoint128_116PackedAnchor1Part1 z
  rwa [he,hrep] at ht

def packedOctCertificate128_116_0 : EightPointCertificate 128 116 0 122720 :=
  eightPointCertificateOfPacked 128 116 0 122720 2205543 20 packedOct128_116_0 457 474
    (by decide +kernel) (by decide) packedOct128_116Anchor0
    (by rw [packedOct128_116_0_budget]; decide)

def packedOctCertificate128_116_1 : EightPointCertificate 128 116 1 122720 :=
  eightPointCertificateOfPacked 128 116 1 122720 2204035 20 packedOct128_116_1 458 474
    (by decide +kernel) (by decide) packedOct128_116Anchor1
    (by rw [packedOct128_116_1_budget]; decide)

theorem max148_second128_third116_eightPoint_moment_bound (tail : List ℕ) (len : tail.length=6)
    (distinct : (natSubsetSums (148::128::116::tail)).Nodup) :
    122720 ≤ ((148::128::116::tail).map (· ^ 2)).sum := by
  apply eightPointNatMomentLower 128 116 122720 tail len distinct
  intro p hp
  by_cases h : p=0
  · subst p
    exact packedOctCertificate128_116_0
  · have he : p=1 := hp.resolve_left h
    subst p
    exact packedOctCertificate128_116_1

#print axioms max148_second128_third116_eightPoint_moment_bound

end NineSeparatedSubsetSums
