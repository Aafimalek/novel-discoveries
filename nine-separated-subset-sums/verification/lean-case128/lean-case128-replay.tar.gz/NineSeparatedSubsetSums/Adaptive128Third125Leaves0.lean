import NineSeparatedSubsetSums.Adaptive128Third125State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive128Third125Proof0 : runCachedNode 511 124551 Adaptive128Third125Node0 = false := by
  decide +kernel

#print axioms adaptive128Third125Proof0

end NineSeparatedSubsetSums
