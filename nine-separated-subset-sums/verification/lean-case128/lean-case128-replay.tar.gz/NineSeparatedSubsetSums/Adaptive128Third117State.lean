import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive128Third117Node0 : CachedSearchNode :=
  ⟨4, 116, computeCenteredMask [148,128,117], 393, 51977⟩

end NineSeparatedSubsetSums
