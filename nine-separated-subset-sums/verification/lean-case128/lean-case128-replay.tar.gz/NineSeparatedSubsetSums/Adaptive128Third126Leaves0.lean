import NineSeparatedSubsetSums.Adaptive128Third126State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive128Third126Proof0 : runCachedNode 511 124725 Adaptive128Third126Node0 = false := by
  decide +kernel

#print axioms adaptive128Third126Proof0

end NineSeparatedSubsetSums
