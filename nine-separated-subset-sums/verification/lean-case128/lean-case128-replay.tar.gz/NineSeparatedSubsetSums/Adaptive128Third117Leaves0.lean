import NineSeparatedSubsetSums.Adaptive128Third117State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive128Third117Proof0 : runCachedNode 511 122903 Adaptive128Third117Node0 = false := by
  decide +kernel

#print axioms adaptive128Third117Proof0

end NineSeparatedSubsetSums
