import NineSeparatedSubsetSums.EightPoint128_124PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct128_124_1_budget :
    FourPointNumeric.packedBudget 20 packedOct128_124_1 500 = 87552862 := by decide +kernel

#print axioms packedOct128_124_1_budget

end NineSeparatedSubsetSums
