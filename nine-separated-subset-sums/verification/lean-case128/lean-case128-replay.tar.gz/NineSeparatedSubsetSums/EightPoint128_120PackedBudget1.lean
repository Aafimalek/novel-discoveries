import NineSeparatedSubsetSums.EightPoint128_120PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct128_120_1_budget :
    FourPointNumeric.packedBudget 20 packedOct128_120_1 264 = 77264320 := by decide +kernel

#print axioms packedOct128_120_1_budget

end NineSeparatedSubsetSums
