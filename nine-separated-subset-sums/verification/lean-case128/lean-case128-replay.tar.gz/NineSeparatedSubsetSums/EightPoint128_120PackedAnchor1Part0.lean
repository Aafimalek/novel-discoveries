import NineSeparatedSubsetSums.EightPoint128_120PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint128_120PackedAnchor1Part0 :
    ∀ j : Fin 120, 2193126 ≤ FourPointNumeric.octPackedCharge 128 120 20 packedOct128_120_1
      (2*((j.val : Int)+0)+1) := by decide +kernel

end NineSeparatedSubsetSums
