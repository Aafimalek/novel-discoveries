import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive128Third109Node0 : CachedSearchNode :=
  ⟨4, 108, computeCenteredMask [148,128,109], 385, 50169⟩

end NineSeparatedSubsetSums
