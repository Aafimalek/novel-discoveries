import NineSeparatedSubsetSums.Adaptive128Third107Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint128Checked

namespace NineSeparatedSubsetSums


theorem adaptive128Third107 : NoDescendingTailAfterThird 128 107 :=
  noDescendingThirdTail_of_cached 128 107 109269 (fun t ht nd => max148_second128_fourPoint_moment_bound (107::t) (by simp [ht]) nd) adaptive128Third107Proof0

#print axioms adaptive128Third107

end NineSeparatedSubsetSums
