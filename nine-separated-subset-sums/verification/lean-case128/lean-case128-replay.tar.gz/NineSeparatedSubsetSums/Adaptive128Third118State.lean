import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive128Third118Node0 : CachedSearchNode :=
  ⟨4, 117, computeCenteredMask [148,128,118], 394, 52212⟩

end NineSeparatedSubsetSums
