import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive128Third122Node0 : CachedSearchNode :=
  ⟨4, 121, computeCenteredMask [148,128,122], 398, 53172⟩

end NineSeparatedSubsetSums
