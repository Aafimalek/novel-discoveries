import NineSeparatedSubsetSums.EightPoint128_122PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct128_122_1_budget :
    FourPointNumeric.packedBudget 20 packedOct128_122_1 494 = 89324072 := by decide +kernel

#print axioms packedOct128_122_1_budget

end NineSeparatedSubsetSums
