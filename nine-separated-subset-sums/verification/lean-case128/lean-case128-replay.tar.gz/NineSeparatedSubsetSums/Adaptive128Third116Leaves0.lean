import NineSeparatedSubsetSums.Adaptive128Third116State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive128Third116Proof0 : runCachedNode 511 122720 Adaptive128Third116Node0 = false := by
  decide +kernel

#print axioms adaptive128Third116Proof0

end NineSeparatedSubsetSums
