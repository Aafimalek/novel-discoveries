import NineSeparatedSubsetSums.EightPoint128_126PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct128_126_1_budget :
    FourPointNumeric.packedBudget 20 packedOct128_126_1 388 = 84897272 := by decide +kernel

#print axioms packedOct128_126_1_budget

end NineSeparatedSubsetSums
