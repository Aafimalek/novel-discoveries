import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive128Third127Node0 : CachedSearchNode :=
  ⟨4, 126, computeCenteredMask [148,128,127], 403, 54417⟩

end NineSeparatedSubsetSums
