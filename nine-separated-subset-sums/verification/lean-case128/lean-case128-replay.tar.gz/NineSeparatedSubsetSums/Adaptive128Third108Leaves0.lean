import NineSeparatedSubsetSums.Adaptive128Third108State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive128Third108Proof0 : runCachedNode 511 109269 Adaptive128Third108Node0 = false := by
  decide +kernel

#print axioms adaptive128Third108Proof0

end NineSeparatedSubsetSums
