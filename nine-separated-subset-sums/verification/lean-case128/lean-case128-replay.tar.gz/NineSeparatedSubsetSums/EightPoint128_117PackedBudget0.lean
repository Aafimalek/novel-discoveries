import NineSeparatedSubsetSums.EightPoint128_117PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct128_117_0_budget :
    FourPointNumeric.packedBudget 20 packedOct128_117_0 293 = 77521941 := by decide +kernel

#print axioms packedOct128_117_0_budget

end NineSeparatedSubsetSums
