import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive128Third125Node0 : CachedSearchNode :=
  ⟨4, 124, computeCenteredMask [148,128,125], 401, 53913⟩

end NineSeparatedSubsetSums
