import NineSeparatedSubsetSums.FourPoint128PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem fourPoint128PackedAnchor0Part1 :
    ∀ j : Fin 106, 968064 ≤ FourPointNumeric.packedCharge 128 19 packedWeight128_0
      (2*((j.val : Int)+120)+0) := by decide +kernel

end NineSeparatedSubsetSums
