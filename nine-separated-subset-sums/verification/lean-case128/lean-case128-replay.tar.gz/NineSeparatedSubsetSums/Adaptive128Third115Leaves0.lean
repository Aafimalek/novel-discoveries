import NineSeparatedSubsetSums.Adaptive128Third115State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive128Third115Proof14 : runCachedNode 511 109269 Adaptive128Third115Node14 = false := by
  decide +kernel

#print axioms adaptive128Third115Proof14

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive128Third115Proof13 : runCachedNode 511 109269 Adaptive128Third115Node13 = false := by
  decide +kernel

#print axioms adaptive128Third115Proof13

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive128Third115Proof12 : runCachedNode 511 109269 Adaptive128Third115Node12 = false := by
  decide +kernel

#print axioms adaptive128Third115Proof12

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive128Third115Proof11 : runCachedNode 511 109269 Adaptive128Third115Node11 = false := by
  decide +kernel

#print axioms adaptive128Third115Proof11

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive128Third115Proof7 : runCachedNode 511 109269 Adaptive128Third115Node7 = false := by
  decide +kernel

#print axioms adaptive128Third115Proof7

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive128Third115Proof5 : runCachedNode 511 109269 Adaptive128Third115Node5 = false := by
  decide +kernel

#print axioms adaptive128Third115Proof5

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive128Third115Proof1 : runCachedNode 511 109269 Adaptive128Third115Node1 = false := by
  decide +kernel

#print axioms adaptive128Third115Proof1

end NineSeparatedSubsetSums
