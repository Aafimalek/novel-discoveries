import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive128Third105Node0 : CachedSearchNode :=
  ⟨4, 104, computeCenteredMask [148,128,105], 381, 49313⟩

end NineSeparatedSubsetSums
