import NineSeparatedSubsetSums.EightPoint128_122PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct128_122_0_budget :
    FourPointNumeric.packedBudget 20 packedOct128_122_0 493 = 89323824 := by decide +kernel

#print axioms packedOct128_122_0_budget

end NineSeparatedSubsetSums
