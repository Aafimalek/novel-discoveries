import NineSeparatedSubsetSums.EightPoint128_124PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint128_124PackedAnchor1Part2 :
    ∀ j : Fin 6, 2362733 ≤ FourPointNumeric.octPackedCharge 128 124 20 packedOct128_124_1
      (2*((j.val : Int)+240)+1) := by decide +kernel

end NineSeparatedSubsetSums
