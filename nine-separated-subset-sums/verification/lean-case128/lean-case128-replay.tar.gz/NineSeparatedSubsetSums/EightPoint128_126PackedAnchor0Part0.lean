import NineSeparatedSubsetSums.EightPoint128_126PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint128_126PackedAnchor0Part0 :
    ∀ j : Fin 120, 2324496 ≤ FourPointNumeric.octPackedCharge 128 126 20 packedOct128_126_0
      (2*((j.val : Int)+0)+0) := by decide +kernel

end NineSeparatedSubsetSums
