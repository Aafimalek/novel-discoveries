import NineSeparatedSubsetSums.FourPoint128PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedWeight128_0_budget :
    FourPointNumeric.packedBudget 19 packedWeight128_0 383 = 67965952 := by decide +kernel

#print axioms packedWeight128_0_budget

end NineSeparatedSubsetSums
