import NineSeparatedSubsetSums.Adaptive128Third112Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint128Checked

namespace NineSeparatedSubsetSums


theorem adaptive128Third112 : NoDescendingTailAfterThird 128 112 :=
  noDescendingThirdTail_of_cached 128 112 109269 (fun t ht nd => max148_second128_fourPoint_moment_bound (112::t) (by simp [ht]) nd) adaptive128Third112Proof0

#print axioms adaptive128Third112

end NineSeparatedSubsetSums
