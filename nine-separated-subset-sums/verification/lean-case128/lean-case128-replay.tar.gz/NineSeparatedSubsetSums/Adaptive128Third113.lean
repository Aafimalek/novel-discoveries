import NineSeparatedSubsetSums.Adaptive128Third113Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint128Checked

namespace NineSeparatedSubsetSums


theorem adaptive128Third113 : NoDescendingTailAfterThird 128 113 :=
  noDescendingThirdTail_of_cached 128 113 109269 (fun t ht nd => max148_second128_fourPoint_moment_bound (113::t) (by simp [ht]) nd) adaptive128Third113Proof0

#print axioms adaptive128Third113

end NineSeparatedSubsetSums
