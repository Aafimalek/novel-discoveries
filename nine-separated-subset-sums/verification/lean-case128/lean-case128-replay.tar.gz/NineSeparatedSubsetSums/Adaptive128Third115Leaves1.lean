import NineSeparatedSubsetSums.Adaptive128Third115State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive128Third115Proof10 : runCachedNode 511 109269 Adaptive128Third115Node10 = false := by
  decide +kernel

#print axioms adaptive128Third115Proof10

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive128Third115Proof8 : runCachedNode 511 109269 Adaptive128Third115Node8 = false := by
  decide +kernel

#print axioms adaptive128Third115Proof8

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive128Third115Proof9 : runCachedNode 511 109269 Adaptive128Third115Node9 = false := by
  decide +kernel

#print axioms adaptive128Third115Proof9

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive128Third115Proof6 : runCachedNode 511 109269 Adaptive128Third115Node6 = false := by
  decide +kernel

#print axioms adaptive128Third115Proof6

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive128Third115Proof4 : runCachedNode 511 109269 Adaptive128Third115Node4 = false := by
  decide +kernel

#print axioms adaptive128Third115Proof4

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive128Third115Proof3 : runCachedNode 511 109269 Adaptive128Third115Node3 = false := by
  decide +kernel

#print axioms adaptive128Third115Proof3

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive128Third115Proof2 : runCachedNode 511 109269 Adaptive128Third115Node2 = false := by
  decide +kernel

#print axioms adaptive128Third115Proof2

end NineSeparatedSubsetSums
