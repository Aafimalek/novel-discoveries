import NineSeparatedSubsetSums.EightPoint128_121PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint128_121PackedAnchor0Part1 :
    ∀ j : Fin 119, 2245840 ≤ FourPointNumeric.octPackedCharge 128 121 20 packedOct128_121_0
      (2*((j.val : Int)+120)+1) := by decide +kernel

end NineSeparatedSubsetSums
