import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive128Third113Node0 : CachedSearchNode :=
  ⟨4, 112, computeCenteredMask [148,128,113], 389, 51057⟩

end NineSeparatedSubsetSums
