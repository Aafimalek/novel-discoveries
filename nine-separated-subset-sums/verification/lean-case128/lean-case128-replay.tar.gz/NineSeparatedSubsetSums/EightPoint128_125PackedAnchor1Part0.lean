import NineSeparatedSubsetSums.EightPoint128_125PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint128_125PackedAnchor1Part0 :
    ∀ j : Fin 120, 2344092 ≤ FourPointNumeric.octPackedCharge 128 125 20 packedOct128_125_1
      (2*((j.val : Int)+0)+0) := by decide +kernel

end NineSeparatedSubsetSums
