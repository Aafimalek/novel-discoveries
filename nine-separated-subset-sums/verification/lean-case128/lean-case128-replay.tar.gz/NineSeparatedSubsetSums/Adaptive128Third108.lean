import NineSeparatedSubsetSums.Adaptive128Third108Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint128Checked

namespace NineSeparatedSubsetSums


theorem adaptive128Third108 : NoDescendingTailAfterThird 128 108 :=
  noDescendingThirdTail_of_cached 128 108 109269 (fun t ht nd => max148_second128_fourPoint_moment_bound (108::t) (by simp [ht]) nd) adaptive128Third108Proof0

#print axioms adaptive128Third108

end NineSeparatedSubsetSums
