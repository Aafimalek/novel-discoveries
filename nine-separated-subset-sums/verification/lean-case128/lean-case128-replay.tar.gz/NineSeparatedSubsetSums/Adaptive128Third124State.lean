import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive128Third124Node0 : CachedSearchNode :=
  ⟨4, 123, computeCenteredMask [148,128,124], 400, 53664⟩

end NineSeparatedSubsetSums
