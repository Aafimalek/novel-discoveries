import NineSeparatedSubsetSums.Adaptive128Third110Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint128Checked

namespace NineSeparatedSubsetSums


theorem adaptive128Third110 : NoDescendingTailAfterThird 128 110 :=
  noDescendingThirdTail_of_cached 128 110 109269 (fun t ht nd => max148_second128_fourPoint_moment_bound (110::t) (by simp [ht]) nd) adaptive128Third110Proof0

#print axioms adaptive128Third110

end NineSeparatedSubsetSums
