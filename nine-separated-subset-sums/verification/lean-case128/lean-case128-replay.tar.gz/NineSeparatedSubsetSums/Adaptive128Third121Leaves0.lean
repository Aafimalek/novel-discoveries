import NineSeparatedSubsetSums.Adaptive128Third121State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive128Third121Proof0 : runCachedNode 511 123386 Adaptive128Third121Node0 = false := by
  decide +kernel

#print axioms adaptive128Third121Proof0

end NineSeparatedSubsetSums
