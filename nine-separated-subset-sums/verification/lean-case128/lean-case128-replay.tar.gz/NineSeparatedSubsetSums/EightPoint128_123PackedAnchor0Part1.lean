import NineSeparatedSubsetSums.EightPoint128_123PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint128_123PackedAnchor0Part1 :
    ∀ j : Fin 120, 2367473 ≤ FourPointNumeric.octPackedCharge 128 123 20 packedOct128_123_0
      (2*((j.val : Int)+120)+1) := by decide +kernel

end NineSeparatedSubsetSums
