import NineSeparatedSubsetSums.EightPointPackedGeometry
import NineSeparatedSubsetSums.EightPoint128_124PackedBudget0
import NineSeparatedSubsetSums.EightPoint128_124PackedAnchor0Part0
import NineSeparatedSubsetSums.EightPoint128_124PackedAnchor0Part1
import NineSeparatedSubsetSums.EightPoint128_124PackedAnchor0Part2
import NineSeparatedSubsetSums.EightPoint128_124PackedBudget1
import NineSeparatedSubsetSums.EightPoint128_124PackedAnchor1Part0
import NineSeparatedSubsetSums.EightPoint128_124PackedAnchor1Part1
import NineSeparatedSubsetSums.EightPoint128_124PackedAnchor1Part2

namespace NineSeparatedSubsetSums

private theorem packedOct128_124Anchor0 :
  ∀ j : Fin 492, ((j.val : Int)+128+124)%2=0 →
    2362000 ≤ FourPointNumeric.octPackedCharge 128 124 20 packedOct128_124_0 (j.val : Int) := by
  intro j hj
  let k := (j.val-0)/2
  have hk : k < 246 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+0 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint128_124PackedAnchor0Part0 z
    rwa [he,hrep] at ht
  by_cases h1 : k < 240
  · let z : Fin 120 := ⟨k-120, by omega⟩
    have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
    have ht := eightPoint128_124PackedAnchor0Part1 z
    rwa [he,hrep] at ht
  let z : Fin 6 := ⟨k-240, by omega⟩
  have he : (z.val : Int)+240 = k := by dsimp [z] <;> omega
  have ht := eightPoint128_124PackedAnchor0Part2 z
  rwa [he,hrep] at ht

private theorem packedOct128_124Anchor1 :
  ∀ j : Fin 492, ((j.val : Int)+128+124)%2=1 →
    2362733 ≤ FourPointNumeric.octPackedCharge 128 124 20 packedOct128_124_1 (j.val : Int) := by
  intro j hj
  let k := (j.val-1)/2
  have hk : k < 246 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+1 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint128_124PackedAnchor1Part0 z
    rwa [he,hrep] at ht
  by_cases h1 : k < 240
  · let z : Fin 120 := ⟨k-120, by omega⟩
    have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
    have ht := eightPoint128_124PackedAnchor1Part1 z
    rwa [he,hrep] at ht
  let z : Fin 6 := ⟨k-240, by omega⟩
  have he : (z.val : Int)+240 = k := by dsimp [z] <;> omega
  have ht := eightPoint128_124PackedAnchor1Part2 z
  rwa [he,hrep] at ht

def packedOctCertificate128_124_0 : EightPointCertificate 128 124 0 124340 :=
  eightPointCertificateOfPacked 128 124 0 124340 2362000 20 packedOct128_124_0 499 492
    (by decide +kernel) (by decide) packedOct128_124Anchor0
    (by rw [packedOct128_124_0_budget]; decide)

def packedOctCertificate128_124_1 : EightPointCertificate 128 124 1 124340 :=
  eightPointCertificateOfPacked 128 124 1 124340 2362733 20 packedOct128_124_1 500 492
    (by decide +kernel) (by decide) packedOct128_124Anchor1
    (by rw [packedOct128_124_1_budget]; decide)

theorem max148_second128_third124_eightPoint_moment_bound (tail : List ℕ) (len : tail.length=6)
    (distinct : (natSubsetSums (148::128::124::tail)).Nodup) :
    124340 ≤ ((148::128::124::tail).map (· ^ 2)).sum := by
  apply eightPointNatMomentLower 128 124 124340 tail len distinct
  intro p hp
  by_cases h : p=0
  · subst p
    exact packedOctCertificate128_124_0
  · have he : p=1 := hp.resolve_left h
    subst p
    exact packedOctCertificate128_124_1

#print axioms max148_second128_third124_eightPoint_moment_bound

end NineSeparatedSubsetSums
