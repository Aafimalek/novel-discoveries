import NineSeparatedSubsetSums.EightPoint128_125PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct128_125_0_budget :
    FourPointNumeric.packedBudget 20 packedOct128_125_0 385 = 86251577 := by decide +kernel

#print axioms packedOct128_125_0_budget

end NineSeparatedSubsetSums
