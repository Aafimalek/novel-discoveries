import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive128Third123Node0 : CachedSearchNode :=
  ⟨4, 122, computeCenteredMask [148,128,123], 399, 53417⟩

end NineSeparatedSubsetSums
