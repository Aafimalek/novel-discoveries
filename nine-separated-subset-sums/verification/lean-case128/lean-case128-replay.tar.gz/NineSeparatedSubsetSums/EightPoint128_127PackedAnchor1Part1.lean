import NineSeparatedSubsetSums.EightPoint128_127PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint128_127PackedAnchor1Part1 :
    ∀ j : Fin 120, 2319719 ≤ FourPointNumeric.octPackedCharge 128 127 20 packedOct128_127_1
      (2*((j.val : Int)+120)+0) := by decide +kernel

end NineSeparatedSubsetSums
