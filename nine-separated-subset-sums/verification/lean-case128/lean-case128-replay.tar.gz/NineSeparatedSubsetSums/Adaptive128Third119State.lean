import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive128Third119Node0 : CachedSearchNode :=
  ⟨4, 118, computeCenteredMask [148,128,119], 395, 52449⟩

end NineSeparatedSubsetSums
