import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive128Third112Node0 : CachedSearchNode :=
  ⟨4, 111, computeCenteredMask [148,128,112], 388, 50832⟩

end NineSeparatedSubsetSums
