import NineSeparatedSubsetSums.EightPoint128_124PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint128_124PackedAnchor0Part0 :
    ∀ j : Fin 120, 2362000 ≤ FourPointNumeric.octPackedCharge 128 124 20 packedOct128_124_0
      (2*((j.val : Int)+0)+0) := by decide +kernel

end NineSeparatedSubsetSums
