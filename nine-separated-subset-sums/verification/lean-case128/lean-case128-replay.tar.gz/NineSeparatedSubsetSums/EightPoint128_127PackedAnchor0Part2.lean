import NineSeparatedSubsetSums.EightPoint128_127PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint128_127PackedAnchor0Part2 :
    ∀ j : Fin 3, 2320648 ≤ FourPointNumeric.octPackedCharge 128 127 20 packedOct128_127_0
      (2*((j.val : Int)+240)+1) := by decide +kernel

end NineSeparatedSubsetSums
