import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive128Third111Node0 : CachedSearchNode :=
  ⟨4, 110, computeCenteredMask [148,128,111], 387, 50609⟩

end NineSeparatedSubsetSums
