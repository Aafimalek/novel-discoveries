import NineSeparatedSubsetSums.Adaptive128Third114State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive128Third114Proof7 : runCachedNode 511 109269 Adaptive128Third114Node7 = false := by
  decide +kernel

#print axioms adaptive128Third114Proof7

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive128Third114Proof6 : runCachedNode 511 109269 Adaptive128Third114Node6 = false := by
  decide +kernel

#print axioms adaptive128Third114Proof6

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive128Third114Proof5 : runCachedNode 511 109269 Adaptive128Third114Node5 = false := by
  decide +kernel

#print axioms adaptive128Third114Proof5

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive128Third114Proof4 : runCachedNode 511 109269 Adaptive128Third114Node4 = false := by
  decide +kernel

#print axioms adaptive128Third114Proof4

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive128Third114Proof3 : runCachedNode 511 109269 Adaptive128Third114Node3 = false := by
  decide +kernel

#print axioms adaptive128Third114Proof3

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive128Third114Proof2 : runCachedNode 511 109269 Adaptive128Third114Node2 = false := by
  decide +kernel

#print axioms adaptive128Third114Proof2

end NineSeparatedSubsetSums
