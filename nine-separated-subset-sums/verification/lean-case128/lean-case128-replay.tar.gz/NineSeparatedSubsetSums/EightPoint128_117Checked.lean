import NineSeparatedSubsetSums.EightPointPackedGeometry
import NineSeparatedSubsetSums.EightPoint128_117PackedBudget0
import NineSeparatedSubsetSums.EightPoint128_117PackedAnchor0Part0
import NineSeparatedSubsetSums.EightPoint128_117PackedAnchor0Part1
import NineSeparatedSubsetSums.EightPoint128_117PackedBudget1
import NineSeparatedSubsetSums.EightPoint128_117PackedAnchor1Part0
import NineSeparatedSubsetSums.EightPoint128_117PackedAnchor1Part1

namespace NineSeparatedSubsetSums

private theorem packedOct128_117Anchor0 :
  ∀ j : Fin 472, ((j.val : Int)+128+117)%2=0 →
    2194508 ≤ FourPointNumeric.octPackedCharge 128 117 20 packedOct128_117_0 (j.val : Int) := by
  intro j hj
  let k := (j.val-1)/2
  have hk : k < 236 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+1 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint128_117PackedAnchor0Part0 z
    rwa [he,hrep] at ht
  let z : Fin 116 := ⟨k-120, by omega⟩
  have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
  have ht := eightPoint128_117PackedAnchor0Part1 z
  rwa [he,hrep] at ht

private theorem packedOct128_117Anchor1 :
  ∀ j : Fin 472, ((j.val : Int)+128+117)%2=1 →
    2193203 ≤ FourPointNumeric.octPackedCharge 128 117 20 packedOct128_117_1 (j.val : Int) := by
  intro j hj
  let k := (j.val-0)/2
  have hk : k < 236 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+0 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint128_117PackedAnchor1Part0 z
    rwa [he,hrep] at ht
  let z : Fin 116 := ⟨k-120, by omega⟩
  have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
  have ht := eightPoint128_117PackedAnchor1Part1 z
  rwa [he,hrep] at ht

def packedOctCertificate128_117_0 : EightPointCertificate 128 117 0 122903 :=
  eightPointCertificateOfPacked 128 117 0 122903 2194508 20 packedOct128_117_0 293 472
    (by decide +kernel) (by decide) packedOct128_117Anchor0
    (by rw [packedOct128_117_0_budget]; decide)

def packedOctCertificate128_117_1 : EightPointCertificate 128 117 1 122903 :=
  eightPointCertificateOfPacked 128 117 1 122903 2193203 20 packedOct128_117_1 292 472
    (by decide +kernel) (by decide) packedOct128_117Anchor1
    (by rw [packedOct128_117_1_budget]; decide)

theorem max148_second128_third117_eightPoint_moment_bound (tail : List ℕ) (len : tail.length=6)
    (distinct : (natSubsetSums (148::128::117::tail)).Nodup) :
    122903 ≤ ((148::128::117::tail).map (· ^ 2)).sum := by
  apply eightPointNatMomentLower 128 117 122903 tail len distinct
  intro p hp
  by_cases h : p=0
  · subst p
    exact packedOctCertificate128_117_0
  · have he : p=1 := hp.resolve_left h
    subst p
    exact packedOctCertificate128_117_1

#print axioms max148_second128_third117_eightPoint_moment_bound

end NineSeparatedSubsetSums
