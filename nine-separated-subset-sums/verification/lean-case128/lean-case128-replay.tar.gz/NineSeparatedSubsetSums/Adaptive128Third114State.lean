import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive128Third114Node0 : CachedSearchNode :=
  ⟨4, 113, computeCenteredMask [148,128,114], 390, 51284⟩
def Adaptive128Third114Node1 : CachedSearchNode := cachedChild Adaptive128Third114Node0 101
def Adaptive128Third114Node2 : CachedSearchNode := cachedChild Adaptive128Third114Node0 102
def Adaptive128Third114Node3 : CachedSearchNode := cachedChild Adaptive128Third114Node0 103
def Adaptive128Third114Node4 : CachedSearchNode := cachedChild Adaptive128Third114Node0 104
def Adaptive128Third114Node5 : CachedSearchNode := cachedChild Adaptive128Third114Node0 105
def Adaptive128Third114Node6 : CachedSearchNode := cachedChild Adaptive128Third114Node0 106
def Adaptive128Third114Node7 : CachedSearchNode := cachedChild Adaptive128Third114Node0 107
def Adaptive128Third114Node8 : CachedSearchNode := cachedChild Adaptive128Third114Node0 108
def Adaptive128Third114Node9 : CachedSearchNode := cachedChild Adaptive128Third114Node0 109
def Adaptive128Third114Node10 : CachedSearchNode := cachedChild Adaptive128Third114Node0 110
def Adaptive128Third114Node11 : CachedSearchNode := cachedChild Adaptive128Third114Node0 111
def Adaptive128Third114Node12 : CachedSearchNode := cachedChild Adaptive128Third114Node0 112
def Adaptive128Third114Node13 : CachedSearchNode := cachedChild Adaptive128Third114Node0 113

end NineSeparatedSubsetSums
