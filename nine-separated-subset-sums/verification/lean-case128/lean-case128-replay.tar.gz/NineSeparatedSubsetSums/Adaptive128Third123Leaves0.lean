import NineSeparatedSubsetSums.Adaptive128Third123State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive128Third123Proof0 : runCachedNode 511 124073 Adaptive128Third123Node0 = false := by
  decide +kernel

#print axioms adaptive128Third123Proof0

end NineSeparatedSubsetSums
