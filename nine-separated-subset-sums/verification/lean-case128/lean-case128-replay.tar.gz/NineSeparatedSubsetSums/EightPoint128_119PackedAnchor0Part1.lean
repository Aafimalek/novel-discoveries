import NineSeparatedSubsetSums.EightPoint128_119PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint128_119PackedAnchor0Part1 :
    ∀ j : Fin 115, 2191253 ≤ FourPointNumeric.octPackedCharge 128 119 20 packedOct128_119_0
      (2*((j.val : Int)+120)+1) := by decide +kernel

end NineSeparatedSubsetSums
