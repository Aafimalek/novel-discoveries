import NineSeparatedSubsetSums.EightPoint128_118PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct128_118_1_budget :
    FourPointNumeric.packedBudget 20 packedOct128_118_1 466 = 76880916 := by decide +kernel

#print axioms packedOct128_118_1_budget

end NineSeparatedSubsetSums
