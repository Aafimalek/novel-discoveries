import NineSeparatedSubsetSums.Adaptive128Third114State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive128Third114Proof12 : runCachedNode 511 109269 Adaptive128Third114Node12 = false := by
  decide +kernel

#print axioms adaptive128Third114Proof12

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive128Third114Proof13 : runCachedNode 511 109269 Adaptive128Third114Node13 = false := by
  decide +kernel

#print axioms adaptive128Third114Proof13

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive128Third114Proof11 : runCachedNode 511 109269 Adaptive128Third114Node11 = false := by
  decide +kernel

#print axioms adaptive128Third114Proof11

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive128Third114Proof10 : runCachedNode 511 109269 Adaptive128Third114Node10 = false := by
  decide +kernel

#print axioms adaptive128Third114Proof10

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive128Third114Proof9 : runCachedNode 511 109269 Adaptive128Third114Node9 = false := by
  decide +kernel

#print axioms adaptive128Third114Proof9

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive128Third114Proof8 : runCachedNode 511 109269 Adaptive128Third114Node8 = false := by
  decide +kernel

#print axioms adaptive128Third114Proof8

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive128Third114Proof1 : runCachedNode 511 109269 Adaptive128Third114Node1 = false := by
  decide +kernel

#print axioms adaptive128Third114Proof1

end NineSeparatedSubsetSums
