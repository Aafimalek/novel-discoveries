import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive128Third104Node0 : CachedSearchNode :=
  ⟨4, 103, computeCenteredMask [148,128,104], 380, 49104⟩

end NineSeparatedSubsetSums
