import NineSeparatedSubsetSums.EightPointPackedGeometry
import NineSeparatedSubsetSums.EightPoint128_121PackedBudget0
import NineSeparatedSubsetSums.EightPoint128_121PackedAnchor0Part0
import NineSeparatedSubsetSums.EightPoint128_121PackedAnchor0Part1
import NineSeparatedSubsetSums.EightPoint128_121PackedBudget1
import NineSeparatedSubsetSums.EightPoint128_121PackedAnchor1Part0
import NineSeparatedSubsetSums.EightPoint128_121PackedAnchor1Part1

namespace NineSeparatedSubsetSums

private theorem packedOct128_121Anchor0 :
  ∀ j : Fin 478, ((j.val : Int)+128+121)%2=0 →
    2245840 ≤ FourPointNumeric.octPackedCharge 128 121 20 packedOct128_121_0 (j.val : Int) := by
  intro j hj
  let k := (j.val-1)/2
  have hk : k < 239 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+1 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint128_121PackedAnchor0Part0 z
    rwa [he,hrep] at ht
  let z : Fin 119 := ⟨k-120, by omega⟩
  have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
  have ht := eightPoint128_121PackedAnchor0Part1 z
  rwa [he,hrep] at ht

private theorem packedOct128_121Anchor1 :
  ∀ j : Fin 478, ((j.val : Int)+128+121)%2=1 →
    2243768 ≤ FourPointNumeric.octPackedCharge 128 121 20 packedOct128_121_1 (j.val : Int) := by
  intro j hj
  let k := (j.val-0)/2
  have hk : k < 239 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+0 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint128_121PackedAnchor1Part0 z
    rwa [he,hrep] at ht
  let z : Fin 119 := ⟨k-120, by omega⟩
  have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
  have ht := eightPoint128_121PackedAnchor1Part1 z
  rwa [he,hrep] at ht

def packedOctCertificate128_121_0 : EightPointCertificate 128 121 0 123386 :=
  eightPointCertificateOfPacked 128 121 0 123386 2245840 20 packedOct128_121_0 395 478
    (by decide +kernel) (by decide) packedOct128_121Anchor0
    (by rw [packedOct128_121_0_budget]; decide)

def packedOctCertificate128_121_1 : EightPointCertificate 128 121 1 123386 :=
  eightPointCertificateOfPacked 128 121 1 123386 2243768 20 packedOct128_121_1 490 478
    (by decide +kernel) (by decide) packedOct128_121Anchor1
    (by rw [packedOct128_121_1_budget]; decide)

theorem max148_second128_third121_eightPoint_moment_bound (tail : List ℕ) (len : tail.length=6)
    (distinct : (natSubsetSums (148::128::121::tail)).Nodup) :
    123386 ≤ ((148::128::121::tail).map (· ^ 2)).sum := by
  apply eightPointNatMomentLower 128 121 123386 tail len distinct
  intro p hp
  by_cases h : p=0
  · subst p
    exact packedOctCertificate128_121_0
  · have he : p=1 := hp.resolve_left h
    subst p
    exact packedOctCertificate128_121_1

#print axioms max148_second128_third121_eightPoint_moment_bound

end NineSeparatedSubsetSums
