import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive128Third121Node0 : CachedSearchNode :=
  ⟨4, 120, computeCenteredMask [148,128,121], 397, 52929⟩

end NineSeparatedSubsetSums
