import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive128Third107Node0 : CachedSearchNode :=
  ⟨4, 106, computeCenteredMask [148,128,107], 383, 49737⟩

end NineSeparatedSubsetSums
