import NineSeparatedSubsetSums.EightPointPackedGeometry
import NineSeparatedSubsetSums.EightPoint128_118PackedBudget0
import NineSeparatedSubsetSums.EightPoint128_118PackedAnchor0Part0
import NineSeparatedSubsetSums.EightPoint128_118PackedAnchor0Part1
import NineSeparatedSubsetSums.EightPoint128_118PackedBudget1
import NineSeparatedSubsetSums.EightPoint128_118PackedAnchor1Part0
import NineSeparatedSubsetSums.EightPoint128_118PackedAnchor1Part1

namespace NineSeparatedSubsetSums

private theorem packedOct128_118Anchor0 :
  ∀ j : Fin 471, ((j.val : Int)+128+118)%2=0 →
    2185432 ≤ FourPointNumeric.octPackedCharge 128 118 20 packedOct128_118_0 (j.val : Int) := by
  intro j hj
  let k := (j.val-0)/2
  have hk : k < 236 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+0 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint128_118PackedAnchor0Part0 z
    rwa [he,hrep] at ht
  let z : Fin 116 := ⟨k-120, by omega⟩
  have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
  have ht := eightPoint128_118PackedAnchor0Part1 z
  rwa [he,hrep] at ht

private theorem packedOct128_118Anchor1 :
  ∀ j : Fin 471, ((j.val : Int)+128+118)%2=1 →
    2185905 ≤ FourPointNumeric.octPackedCharge 128 118 20 packedOct128_118_1 (j.val : Int) := by
  intro j hj
  let k := (j.val-1)/2
  have hk : k < 235 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+1 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint128_118PackedAnchor1Part0 z
    rwa [he,hrep] at ht
  let z : Fin 115 := ⟨k-120, by omega⟩
  have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
  have ht := eightPoint128_118PackedAnchor1Part1 z
  rwa [he,hrep] at ht

def packedOctCertificate128_118_0 : EightPointCertificate 128 118 0 123081 :=
  eightPointCertificateOfPacked 128 118 0 123081 2185432 20 packedOct128_118_0 463 471
    (by decide +kernel) (by decide) packedOct128_118Anchor0
    (by rw [packedOct128_118_0_budget]; decide)

def packedOctCertificate128_118_1 : EightPointCertificate 128 118 1 123081 :=
  eightPointCertificateOfPacked 128 118 1 123081 2185905 20 packedOct128_118_1 466 471
    (by decide +kernel) (by decide) packedOct128_118Anchor1
    (by rw [packedOct128_118_1_budget]; decide)

theorem max148_second128_third118_eightPoint_moment_bound (tail : List ℕ) (len : tail.length=6)
    (distinct : (natSubsetSums (148::128::118::tail)).Nodup) :
    123081 ≤ ((148::128::118::tail).map (· ^ 2)).sum := by
  apply eightPointNatMomentLower 128 118 123081 tail len distinct
  intro p hp
  by_cases h : p=0
  · subst p
    exact packedOctCertificate128_118_0
  · have he : p=1 := hp.resolve_left h
    subst p
    exact packedOctCertificate128_118_1

#print axioms max148_second128_third118_eightPoint_moment_bound

end NineSeparatedSubsetSums
