import NineSeparatedSubsetSums.EightPoint128_117PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint128_117PackedAnchor1Part1 :
    ∀ j : Fin 116, 2193203 ≤ FourPointNumeric.octPackedCharge 128 117 20 packedOct128_117_1
      (2*((j.val : Int)+120)+0) := by decide +kernel

end NineSeparatedSubsetSums
