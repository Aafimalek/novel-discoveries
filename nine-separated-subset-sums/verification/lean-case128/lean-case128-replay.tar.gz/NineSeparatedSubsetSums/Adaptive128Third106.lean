import NineSeparatedSubsetSums.Adaptive128Third106Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint128Checked

namespace NineSeparatedSubsetSums


theorem adaptive128Third106 : NoDescendingTailAfterThird 128 106 :=
  noDescendingThirdTail_of_cached 128 106 109269 (fun t ht nd => max148_second128_fourPoint_moment_bound (106::t) (by simp [ht]) nd) adaptive128Third106Proof0

#print axioms adaptive128Third106

end NineSeparatedSubsetSums
