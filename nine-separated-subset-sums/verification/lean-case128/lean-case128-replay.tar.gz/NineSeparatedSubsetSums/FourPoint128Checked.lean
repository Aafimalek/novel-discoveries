import NineSeparatedSubsetSums.FourPointPackedGeometry
import NineSeparatedSubsetSums.FourPoint128PackedBudget0
import NineSeparatedSubsetSums.FourPoint128PackedAnchor0Part0
import NineSeparatedSubsetSums.FourPoint128PackedAnchor0Part1
import NineSeparatedSubsetSums.FourPoint128PackedBudget1
import NineSeparatedSubsetSums.FourPoint128PackedAnchor1Part0
import NineSeparatedSubsetSums.FourPoint128PackedAnchor1Part1

namespace NineSeparatedSubsetSums

private theorem packed128Anchor0 :
  ∀ j : Fin 452, ((j.val : Int)+128)%2=0 →
    968064 ≤ FourPointNumeric.packedCharge 128 19 packedWeight128_0 (j.val : Int) := by
  intro j hj
  let k := (j.val-0)/2
  have hk : k < 226 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+0 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := fourPoint128PackedAnchor0Part0 z
    rwa [he,hrep] at ht
  let z : Fin 106 := ⟨k-120, by omega⟩
  have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
  have ht := fourPoint128PackedAnchor0Part1 z
  rwa [he,hrep] at ht

private theorem packed128Anchor1 :
  ∀ j : Fin 452, ((j.val : Int)+128)%2=1 →
    968036 ≤ FourPointNumeric.packedCharge 128 19 packedWeight128_1 (j.val : Int) := by
  intro j hj
  let k := (j.val-1)/2
  have hk : k < 226 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+1 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := fourPoint128PackedAnchor1Part0 z
    rwa [he,hrep] at ht
  let z : Fin 106 := ⟨k-120, by omega⟩
  have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
  have ht := fourPoint128PackedAnchor1Part1 z
  rwa [he,hrep] at ht

def packedCertificate128_0 : FourPointCertificate 128 0 109269 :=
  fourPointCertificateOfPacked 128 0 109269 968064 19 packedWeight128_0 383 452
    (by decide +kernel) (by decide) (by decide) packed128Anchor0
    (by rw [packedWeight128_0_budget]; decide)

def packedCertificate128_1 : FourPointCertificate 128 1 109269 :=
  fourPointCertificateOfPacked 128 1 109269 968036 19 packedWeight128_1 360 452
    (by decide +kernel) (by decide) (by decide) packed128Anchor1
    (by rw [packedWeight128_1_budget]; decide)

theorem max148_second128_fourPoint_moment_bound (tail : List ℕ) (len : tail.length=7)
    (distinct : (natSubsetSums (148::128::tail)).Nodup) :
    109269 ≤ ((148::128::tail).map (· ^ 2)).sum := by
  apply fourPointNatMomentLower 128 109269 tail len distinct
  intro p hp
  by_cases h : p=0
  · subst p
    exact packedCertificate128_0
  · have he : p=1 := hp.resolve_left h
    subst p
    exact packedCertificate128_1

#print axioms max148_second128_fourPoint_moment_bound

end NineSeparatedSubsetSums
