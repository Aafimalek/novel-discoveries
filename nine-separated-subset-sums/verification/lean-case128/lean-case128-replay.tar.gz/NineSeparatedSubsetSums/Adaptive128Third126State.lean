import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive128Third126Node0 : CachedSearchNode :=
  ⟨4, 125, computeCenteredMask [148,128,126], 402, 54164⟩

end NineSeparatedSubsetSums
