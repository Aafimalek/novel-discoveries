import NineSeparatedSubsetSums.EightPointPackedGeometry
import NineSeparatedSubsetSums.EightPoint128_120PackedBudget0
import NineSeparatedSubsetSums.EightPoint128_120PackedAnchor0Part0
import NineSeparatedSubsetSums.EightPoint128_120PackedAnchor0Part1
import NineSeparatedSubsetSums.EightPoint128_120PackedBudget1
import NineSeparatedSubsetSums.EightPoint128_120PackedAnchor1Part0
import NineSeparatedSubsetSums.EightPoint128_120PackedAnchor1Part1

namespace NineSeparatedSubsetSums

private theorem packedOct128_120Anchor0 :
  ∀ j : Fin 471, ((j.val : Int)+128+120)%2=0 →
    2193971 ≤ FourPointNumeric.octPackedCharge 128 120 20 packedOct128_120_0 (j.val : Int) := by
  intro j hj
  let k := (j.val-0)/2
  have hk : k < 236 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+0 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint128_120PackedAnchor0Part0 z
    rwa [he,hrep] at ht
  let z : Fin 116 := ⟨k-120, by omega⟩
  have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
  have ht := eightPoint128_120PackedAnchor0Part1 z
  rwa [he,hrep] at ht

private theorem packedOct128_120Anchor1 :
  ∀ j : Fin 471, ((j.val : Int)+128+120)%2=1 →
    2193126 ≤ FourPointNumeric.octPackedCharge 128 120 20 packedOct128_120_1 (j.val : Int) := by
  intro j hj
  let k := (j.val-1)/2
  have hk : k < 235 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+1 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint128_120PackedAnchor1Part0 z
    rwa [he,hrep] at ht
  let z : Fin 115 := ⟨k-120, by omega⟩
  have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
  have ht := eightPoint128_120PackedAnchor1Part1 z
  rwa [he,hrep] at ht

def packedOctCertificate128_120_0 : EightPointCertificate 128 120 0 123234 :=
  eightPointCertificateOfPacked 128 120 0 123234 2193971 20 packedOct128_120_0 265 471
    (by decide +kernel) (by decide) packedOct128_120Anchor0
    (by rw [packedOct128_120_0_budget]; decide)

def packedOctCertificate128_120_1 : EightPointCertificate 128 120 1 123234 :=
  eightPointCertificateOfPacked 128 120 1 123234 2193126 20 packedOct128_120_1 264 471
    (by decide +kernel) (by decide) packedOct128_120Anchor1
    (by rw [packedOct128_120_1_budget]; decide)

theorem max148_second128_third120_eightPoint_moment_bound (tail : List ℕ) (len : tail.length=6)
    (distinct : (natSubsetSums (148::128::120::tail)).Nodup) :
    123234 ≤ ((148::128::120::tail).map (· ^ 2)).sum := by
  apply eightPointNatMomentLower 128 120 123234 tail len distinct
  intro p hp
  by_cases h : p=0
  · subst p
    exact packedOctCertificate128_120_0
  · have he : p=1 := hp.resolve_left h
    subst p
    exact packedOctCertificate128_120_1

#print axioms max148_second128_third120_eightPoint_moment_bound

end NineSeparatedSubsetSums
