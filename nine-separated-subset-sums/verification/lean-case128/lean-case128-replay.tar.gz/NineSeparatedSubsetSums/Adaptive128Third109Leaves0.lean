import NineSeparatedSubsetSums.Adaptive128Third109State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive128Third109Proof0 : runCachedNode 511 109269 Adaptive128Third109Node0 = false := by
  decide +kernel

#print axioms adaptive128Third109Proof0

end NineSeparatedSubsetSums
