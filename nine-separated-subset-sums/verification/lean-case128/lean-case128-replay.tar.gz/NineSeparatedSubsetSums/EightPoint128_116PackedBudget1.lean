import NineSeparatedSubsetSums.EightPoint128_116PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct128_116_1_budget :
    FourPointNumeric.packedBudget 20 packedOct128_116_1 458 = 78225790 := by decide +kernel

#print axioms packedOct128_116_1_budget

end NineSeparatedSubsetSums
