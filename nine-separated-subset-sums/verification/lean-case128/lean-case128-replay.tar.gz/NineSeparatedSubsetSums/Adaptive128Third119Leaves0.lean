import NineSeparatedSubsetSums.Adaptive128Third119State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive128Third119Proof0 : runCachedNode 511 123130 Adaptive128Third119Node0 = false := by
  decide +kernel

#print axioms adaptive128Third119Proof0

end NineSeparatedSubsetSums
