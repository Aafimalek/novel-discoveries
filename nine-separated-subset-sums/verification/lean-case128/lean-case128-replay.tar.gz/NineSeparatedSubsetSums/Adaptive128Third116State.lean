import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive128Third116Node0 : CachedSearchNode :=
  ⟨4, 115, computeCenteredMask [148,128,116], 392, 51744⟩

end NineSeparatedSubsetSums
