import NineSeparatedSubsetSums.Adaptive134Third130State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive134Third130Proof18 : runCachedNode 511 126608 Adaptive134Third130Node18 = false := by
  decide +kernel

#print axioms adaptive134Third130Proof18

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive134Third130Proof15 : runCachedNode 511 126608 Adaptive134Third130Node15 = false := by
  decide +kernel

#print axioms adaptive134Third130Proof15

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive134Third130Proof14 : runCachedNode 511 126608 Adaptive134Third130Node14 = false := by
  decide +kernel

#print axioms adaptive134Third130Proof14

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive134Third130Proof8 : runCachedNode 511 126608 Adaptive134Third130Node8 = false := by
  decide +kernel

#print axioms adaptive134Third130Proof8

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive134Third130Proof4 : runCachedNode 511 126608 Adaptive134Third130Node4 = false := by
  decide +kernel

#print axioms adaptive134Third130Proof4

end NineSeparatedSubsetSums
