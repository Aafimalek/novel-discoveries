import NineSeparatedSubsetSums.EightPoint134_121PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct134_121_0_budget :
    FourPointNumeric.packedBudget 20 packedOct134_121_0 269 = 84103928 := by decide +kernel

#print axioms packedOct134_121_0_budget

end NineSeparatedSubsetSums
