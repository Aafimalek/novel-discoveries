import NineSeparatedSubsetSums.EightPoint134_119PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct134_119_0_budget :
    FourPointNumeric.packedBudget 20 packedOct134_119_0 381 = 83181389 := by decide +kernel

#print axioms packedOct134_119_0_budget

end NineSeparatedSubsetSums
