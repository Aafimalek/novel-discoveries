import NineSeparatedSubsetSums.Adaptive134Third119State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive134Third119Proof0 : runCachedNode 511 124381 Adaptive134Third119Node0 = false := by
  decide +kernel

#print axioms adaptive134Third119Proof0

end NineSeparatedSubsetSums
