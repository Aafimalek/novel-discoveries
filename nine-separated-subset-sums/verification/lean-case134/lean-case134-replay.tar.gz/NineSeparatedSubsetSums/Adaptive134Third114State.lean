import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive134Third114Node0 : CachedSearchNode :=
  ⟨4, 113, computeCenteredMask [148,134,114], 396, 52856⟩

end NineSeparatedSubsetSums
