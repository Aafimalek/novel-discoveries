import NineSeparatedSubsetSums.Adaptive134Third127State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive134Third127Proof7 : runCachedNode 511 126222 Adaptive134Third127Node7 = false := by
  decide +kernel

#print axioms adaptive134Third127Proof7

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive134Third127Proof5 : runCachedNode 511 126222 Adaptive134Third127Node5 = false := by
  decide +kernel

#print axioms adaptive134Third127Proof5

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive134Third127Proof4 : runCachedNode 511 126222 Adaptive134Third127Node4 = false := by
  decide +kernel

#print axioms adaptive134Third127Proof4

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive134Third127Proof2 : runCachedNode 511 126222 Adaptive134Third127Node2 = false := by
  decide +kernel

#print axioms adaptive134Third127Proof2

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive134Third127Proof1 : runCachedNode 511 126222 Adaptive134Third127Node1 = false := by
  decide +kernel

#print axioms adaptive134Third127Proof1

end NineSeparatedSubsetSums
