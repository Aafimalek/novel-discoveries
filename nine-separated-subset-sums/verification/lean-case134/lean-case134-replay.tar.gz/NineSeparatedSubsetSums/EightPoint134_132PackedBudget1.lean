import NineSeparatedSubsetSums.EightPoint134_132PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct134_132_1_budget :
    FourPointNumeric.packedBudget 20 packedOct134_132_1 418 = 88297490 := by decide +kernel

#print axioms packedOct134_132_1_budget

end NineSeparatedSubsetSums
