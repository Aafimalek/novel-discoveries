import NineSeparatedSubsetSums.Adaptive134Third133State
import NineSeparatedSubsetSums.Adaptive134Third133Leaves4
import NineSeparatedSubsetSums.Adaptive134Third133Leaves0
import NineSeparatedSubsetSums.Adaptive134Third133Leaves3
import NineSeparatedSubsetSums.Adaptive134Third133Leaves2
import NineSeparatedSubsetSums.Adaptive134Third133Leaves1

namespace NineSeparatedSubsetSums

theorem adaptive134Third133Proof21 : runCachedNode 511 127264 Adaptive134Third133Node21 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 127264 Adaptive134Third133Node21 = [105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive134Third133Proof22
  · exact adaptive134Third133Proof23
  · exact adaptive134Third133Proof24
  · exact adaptive134Third133Proof25
  · exact adaptive134Third133Proof26
  · exact adaptive134Third133Proof27
  · exact adaptive134Third133Proof28
  · exact adaptive134Third133Proof29
  · exact adaptive134Third133Proof30
  · exact adaptive134Third133Proof31
  · exact adaptive134Third133Proof32
  · exact adaptive134Third133Proof33
  · exact adaptive134Third133Proof34
  · exact adaptive134Third133Proof35
  · exact adaptive134Third133Proof36
  · exact adaptive134Third133Proof37
  · exact adaptive134Third133Proof38
  · exact adaptive134Third133Proof39
  · exact adaptive134Third133Proof40
  · exact adaptive134Third133Proof41
  · exact adaptive134Third133Proof42
  · exact adaptive134Third133Proof43
  · exact adaptive134Third133Proof44

#print axioms adaptive134Third133Proof21

theorem adaptive134Third133Proof0 : runCachedNode 511 127264 Adaptive134Third133Node0 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 127264 Adaptive134Third133Node0 = [111, 112, 113, 114, 115, 116, 117, 118, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 132] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive134Third133Proof1
  · exact adaptive134Third133Proof2
  · exact adaptive134Third133Proof3
  · exact adaptive134Third133Proof4
  · exact adaptive134Third133Proof5
  · exact adaptive134Third133Proof6
  · exact adaptive134Third133Proof7
  · exact adaptive134Third133Proof8
  · exact adaptive134Third133Proof9
  · exact adaptive134Third133Proof10
  · exact adaptive134Third133Proof11
  · exact adaptive134Third133Proof12
  · exact adaptive134Third133Proof13
  · exact adaptive134Third133Proof14
  · exact adaptive134Third133Proof15
  · exact adaptive134Third133Proof16
  · exact adaptive134Third133Proof17
  · exact adaptive134Third133Proof18
  · exact adaptive134Third133Proof19
  · exact adaptive134Third133Proof20
  · exact adaptive134Third133Proof21

#print axioms adaptive134Third133Proof0

end NineSeparatedSubsetSums
