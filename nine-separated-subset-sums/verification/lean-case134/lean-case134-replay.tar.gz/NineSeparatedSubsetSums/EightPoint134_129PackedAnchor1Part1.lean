import NineSeparatedSubsetSums.EightPoint134_129PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint134_129PackedAnchor1Part1 :
    ∀ j : Fin 120, 2339932 ≤ FourPointNumeric.octPackedCharge 134 129 20 packedOct134_129_1
      (2*((j.val : Int)+120)+0) := by decide +kernel

end NineSeparatedSubsetSums
