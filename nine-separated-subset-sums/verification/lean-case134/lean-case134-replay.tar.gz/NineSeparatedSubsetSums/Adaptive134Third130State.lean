import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive134Third130Node0 : CachedSearchNode :=
  ⟨4, 129, computeCenteredMask [148,134,130], 412, 56760⟩
def Adaptive134Third130Node1 : CachedSearchNode := cachedChild Adaptive134Third130Node0 111
def Adaptive134Third130Node2 : CachedSearchNode := cachedChild Adaptive134Third130Node0 112
def Adaptive134Third130Node3 : CachedSearchNode := cachedChild Adaptive134Third130Node0 113
def Adaptive134Third130Node4 : CachedSearchNode := cachedChild Adaptive134Third130Node0 114
def Adaptive134Third130Node5 : CachedSearchNode := cachedChild Adaptive134Third130Node0 115
def Adaptive134Third130Node6 : CachedSearchNode := cachedChild Adaptive134Third130Node0 117
def Adaptive134Third130Node7 : CachedSearchNode := cachedChild Adaptive134Third130Node0 118
def Adaptive134Third130Node8 : CachedSearchNode := cachedChild Adaptive134Third130Node0 119
def Adaptive134Third130Node9 : CachedSearchNode := cachedChild Adaptive134Third130Node0 120
def Adaptive134Third130Node10 : CachedSearchNode := cachedChild Adaptive134Third130Node0 121
def Adaptive134Third130Node11 : CachedSearchNode := cachedChild Adaptive134Third130Node0 122
def Adaptive134Third130Node12 : CachedSearchNode := cachedChild Adaptive134Third130Node0 123
def Adaptive134Third130Node13 : CachedSearchNode := cachedChild Adaptive134Third130Node0 124
def Adaptive134Third130Node14 : CachedSearchNode := cachedChild Adaptive134Third130Node0 125
def Adaptive134Third130Node15 : CachedSearchNode := cachedChild Adaptive134Third130Node0 126
def Adaptive134Third130Node16 : CachedSearchNode := cachedChild Adaptive134Third130Node0 127
def Adaptive134Third130Node17 : CachedSearchNode := cachedChild Adaptive134Third130Node0 128
def Adaptive134Third130Node18 : CachedSearchNode := cachedChild Adaptive134Third130Node0 129

end NineSeparatedSubsetSums
