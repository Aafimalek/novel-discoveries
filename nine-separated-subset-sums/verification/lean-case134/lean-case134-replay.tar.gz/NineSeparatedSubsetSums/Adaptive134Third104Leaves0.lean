import NineSeparatedSubsetSums.Adaptive134Third104State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive134Third104Proof0 : runCachedNode 511 110531 Adaptive134Third104Node0 = false := by
  decide +kernel

#print axioms adaptive134Third104Proof0

end NineSeparatedSubsetSums
