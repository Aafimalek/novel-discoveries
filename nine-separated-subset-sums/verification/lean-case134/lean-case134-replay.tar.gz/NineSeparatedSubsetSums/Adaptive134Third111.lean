import NineSeparatedSubsetSums.Adaptive134Third111Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint134Checked

namespace NineSeparatedSubsetSums


theorem adaptive134Third111 : NoDescendingTailAfterThird 134 111 :=
  noDescendingThirdTail_of_cached 134 111 110531 (fun t ht nd => max148_second134_fourPoint_moment_bound (111::t) (by simp [ht]) nd) adaptive134Third111Proof0

#print axioms adaptive134Third111

end NineSeparatedSubsetSums
