import NineSeparatedSubsetSums.EightPoint134_131PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint134_131PackedAnchor1Part1 :
    ∀ j : Fin 120, 2393040 ≤ FourPointNumeric.octPackedCharge 134 131 20 packedOct134_131_1
      (2*((j.val : Int)+120)+0) := by decide +kernel

end NineSeparatedSubsetSums
