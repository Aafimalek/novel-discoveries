import NineSeparatedSubsetSums.Adaptive134Third122State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive134Third122Proof0 : runCachedNode 511 124779 Adaptive134Third122Node0 = false := by
  decide +kernel

#print axioms adaptive134Third122Proof0

end NineSeparatedSubsetSums
