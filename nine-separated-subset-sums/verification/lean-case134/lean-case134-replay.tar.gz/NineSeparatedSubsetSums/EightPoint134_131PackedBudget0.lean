import NineSeparatedSubsetSums.EightPoint134_131PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct134_131_0_budget :
    FourPointNumeric.packedBudget 20 packedOct134_131_0 429 = 88204080 := by decide +kernel

#print axioms packedOct134_131_0_budget

end NineSeparatedSubsetSums
