import NineSeparatedSubsetSums.Adaptive134Third109Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint134Checked

namespace NineSeparatedSubsetSums


theorem adaptive134Third109 : NoDescendingTailAfterThird 134 109 :=
  noDescendingThirdTail_of_cached 134 109 110531 (fun t ht nd => max148_second134_fourPoint_moment_bound (109::t) (by simp [ht]) nd) adaptive134Third109Proof0

#print axioms adaptive134Third109

end NineSeparatedSubsetSums
