import NineSeparatedSubsetSums.Adaptive134Third133State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive134Third133Proof44 : runCachedNode 511 127264 Adaptive134Third133Node44 = false := by
  decide +kernel

#print axioms adaptive134Third133Proof44

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive134Third133Proof15 : runCachedNode 511 127264 Adaptive134Third133Node15 = false := by
  decide +kernel

#print axioms adaptive134Third133Proof15

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive134Third133Proof16 : runCachedNode 511 127264 Adaptive134Third133Node16 = false := by
  decide +kernel

#print axioms adaptive134Third133Proof16

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive134Third133Proof14 : runCachedNode 511 127264 Adaptive134Third133Node14 = false := by
  decide +kernel

#print axioms adaptive134Third133Proof14

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive134Third133Proof7 : runCachedNode 511 127264 Adaptive134Third133Node7 = false := by
  decide +kernel

#print axioms adaptive134Third133Proof7

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive134Third133Proof2 : runCachedNode 511 127264 Adaptive134Third133Node2 = false := by
  decide +kernel

#print axioms adaptive134Third133Proof2

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive134Third133Proof1 : runCachedNode 511 127264 Adaptive134Third133Node1 = false := by
  decide +kernel

#print axioms adaptive134Third133Proof1

end NineSeparatedSubsetSums
