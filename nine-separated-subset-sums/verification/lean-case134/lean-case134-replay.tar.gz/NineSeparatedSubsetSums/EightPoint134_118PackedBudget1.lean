import NineSeparatedSubsetSums.EightPoint134_118PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct134_118_1_budget :
    FourPointNumeric.packedBudget 20 packedOct134_118_1 268 = 81346604 := by decide +kernel

#print axioms packedOct134_118_1_budget

end NineSeparatedSubsetSums
