import NineSeparatedSubsetSums.Adaptive134Third130State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive134Third130Proof17 : runCachedNode 511 126608 Adaptive134Third130Node17 = false := by
  decide +kernel

#print axioms adaptive134Third130Proof17

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive134Third130Proof16 : runCachedNode 511 126608 Adaptive134Third130Node16 = false := by
  decide +kernel

#print axioms adaptive134Third130Proof16

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive134Third130Proof12 : runCachedNode 511 126608 Adaptive134Third130Node12 = false := by
  decide +kernel

#print axioms adaptive134Third130Proof12

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive134Third130Proof9 : runCachedNode 511 126608 Adaptive134Third130Node9 = false := by
  decide +kernel

#print axioms adaptive134Third130Proof9

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive134Third130Proof13 : runCachedNode 511 126608 Adaptive134Third130Node13 = false := by
  decide +kernel

#print axioms adaptive134Third130Proof13

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive134Third130Proof7 : runCachedNode 511 126608 Adaptive134Third130Node7 = false := by
  decide +kernel

#print axioms adaptive134Third130Proof7

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive134Third130Proof3 : runCachedNode 511 126608 Adaptive134Third130Node3 = false := by
  decide +kernel

#print axioms adaptive134Third130Proof3

end NineSeparatedSubsetSums
