import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive134Third104Node0 : CachedSearchNode :=
  ⟨4, 103, computeCenteredMask [148,134,104], 386, 50676⟩

end NineSeparatedSubsetSums
