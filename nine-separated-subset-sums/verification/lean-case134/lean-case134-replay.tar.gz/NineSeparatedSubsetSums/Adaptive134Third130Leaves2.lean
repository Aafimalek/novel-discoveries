import NineSeparatedSubsetSums.Adaptive134Third130State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive134Third130Proof11 : runCachedNode 511 126608 Adaptive134Third130Node11 = false := by
  decide +kernel

#print axioms adaptive134Third130Proof11

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive134Third130Proof10 : runCachedNode 511 126608 Adaptive134Third130Node10 = false := by
  decide +kernel

#print axioms adaptive134Third130Proof10

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive134Third130Proof6 : runCachedNode 511 126608 Adaptive134Third130Node6 = false := by
  decide +kernel

#print axioms adaptive134Third130Proof6

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive134Third130Proof5 : runCachedNode 511 126608 Adaptive134Third130Node5 = false := by
  decide +kernel

#print axioms adaptive134Third130Proof5

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive134Third130Proof2 : runCachedNode 511 126608 Adaptive134Third130Node2 = false := by
  decide +kernel

#print axioms adaptive134Third130Proof2

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive134Third130Proof1 : runCachedNode 511 126608 Adaptive134Third130Node1 = false := by
  decide +kernel

#print axioms adaptive134Third130Proof1

end NineSeparatedSubsetSums
