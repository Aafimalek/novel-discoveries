import NineSeparatedSubsetSums.Adaptive134Third104Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint134Checked

namespace NineSeparatedSubsetSums


theorem adaptive134Third104 : NoDescendingTailAfterThird 134 104 :=
  noDescendingThirdTail_of_cached 134 104 110531 (fun t ht nd => max148_second134_fourPoint_moment_bound (104::t) (by simp [ht]) nd) adaptive134Third104Proof0

#print axioms adaptive134Third104

end NineSeparatedSubsetSums
