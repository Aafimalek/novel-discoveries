import NineSeparatedSubsetSums.Adaptive134Third133State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive134Third133Proof19 : runCachedNode 511 127264 Adaptive134Third133Node19 = false := by
  decide +kernel

#print axioms adaptive134Third133Proof19

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive134Third133Proof18 : runCachedNode 511 127264 Adaptive134Third133Node18 = false := by
  decide +kernel

#print axioms adaptive134Third133Proof18

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive134Third133Proof38 : runCachedNode 511 127264 Adaptive134Third133Node38 = false := by
  decide +kernel

#print axioms adaptive134Third133Proof38

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive134Third133Proof3 : runCachedNode 511 127264 Adaptive134Third133Node3 = false := by
  decide +kernel

#print axioms adaptive134Third133Proof3

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive134Third133Proof24 : runCachedNode 511 127264 Adaptive134Third133Node24 = false := by
  decide +kernel

#print axioms adaptive134Third133Proof24

end NineSeparatedSubsetSums
