import NineSeparatedSubsetSums.FourPoint134PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedWeight134_0_budget :
    FourPointNumeric.packedBudget 20 packedWeight134_0 399 = 77252864 := by decide +kernel

#print axioms packedWeight134_0_budget

end NineSeparatedSubsetSums
