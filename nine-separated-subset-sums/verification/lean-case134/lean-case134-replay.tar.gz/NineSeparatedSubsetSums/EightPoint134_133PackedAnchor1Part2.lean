import NineSeparatedSubsetSums.EightPoint134_133PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint134_133PackedAnchor1Part2 :
    ∀ j : Fin 7, 2401922 ≤ FourPointNumeric.octPackedCharge 134 133 20 packedOct134_133_1
      (2*((j.val : Int)+240)+0) := by decide +kernel

end NineSeparatedSubsetSums
