import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive134Third133Node0 : CachedSearchNode :=
  ⟨4, 132, computeCenteredMask [148,134,133], 415, 57549⟩
def Adaptive134Third133Node1 : CachedSearchNode := cachedChild Adaptive134Third133Node0 111
def Adaptive134Third133Node2 : CachedSearchNode := cachedChild Adaptive134Third133Node0 112
def Adaptive134Third133Node3 : CachedSearchNode := cachedChild Adaptive134Third133Node0 113
def Adaptive134Third133Node4 : CachedSearchNode := cachedChild Adaptive134Third133Node0 114
def Adaptive134Third133Node5 : CachedSearchNode := cachedChild Adaptive134Third133Node0 115
def Adaptive134Third133Node6 : CachedSearchNode := cachedChild Adaptive134Third133Node0 116
def Adaptive134Third133Node7 : CachedSearchNode := cachedChild Adaptive134Third133Node0 117
def Adaptive134Third133Node8 : CachedSearchNode := cachedChild Adaptive134Third133Node0 118
def Adaptive134Third133Node9 : CachedSearchNode := cachedChild Adaptive134Third133Node0 120
def Adaptive134Third133Node10 : CachedSearchNode := cachedChild Adaptive134Third133Node0 121
def Adaptive134Third133Node11 : CachedSearchNode := cachedChild Adaptive134Third133Node0 122
def Adaptive134Third133Node12 : CachedSearchNode := cachedChild Adaptive134Third133Node0 123
def Adaptive134Third133Node13 : CachedSearchNode := cachedChild Adaptive134Third133Node0 124
def Adaptive134Third133Node14 : CachedSearchNode := cachedChild Adaptive134Third133Node0 125
def Adaptive134Third133Node15 : CachedSearchNode := cachedChild Adaptive134Third133Node0 126
def Adaptive134Third133Node16 : CachedSearchNode := cachedChild Adaptive134Third133Node0 127
def Adaptive134Third133Node17 : CachedSearchNode := cachedChild Adaptive134Third133Node0 128
def Adaptive134Third133Node18 : CachedSearchNode := cachedChild Adaptive134Third133Node0 129
def Adaptive134Third133Node19 : CachedSearchNode := cachedChild Adaptive134Third133Node0 130
def Adaptive134Third133Node20 : CachedSearchNode := cachedChild Adaptive134Third133Node0 131
def Adaptive134Third133Node21 : CachedSearchNode := cachedChild Adaptive134Third133Node0 132
def Adaptive134Third133Node22 : CachedSearchNode := cachedChild Adaptive134Third133Node21 105
def Adaptive134Third133Node23 : CachedSearchNode := cachedChild Adaptive134Third133Node21 106
def Adaptive134Third133Node24 : CachedSearchNode := cachedChild Adaptive134Third133Node21 107
def Adaptive134Third133Node25 : CachedSearchNode := cachedChild Adaptive134Third133Node21 108
def Adaptive134Third133Node26 : CachedSearchNode := cachedChild Adaptive134Third133Node21 109
def Adaptive134Third133Node27 : CachedSearchNode := cachedChild Adaptive134Third133Node21 110
def Adaptive134Third133Node28 : CachedSearchNode := cachedChild Adaptive134Third133Node21 111
def Adaptive134Third133Node29 : CachedSearchNode := cachedChild Adaptive134Third133Node21 112
def Adaptive134Third133Node30 : CachedSearchNode := cachedChild Adaptive134Third133Node21 113
def Adaptive134Third133Node31 : CachedSearchNode := cachedChild Adaptive134Third133Node21 114
def Adaptive134Third133Node32 : CachedSearchNode := cachedChild Adaptive134Third133Node21 115
def Adaptive134Third133Node33 : CachedSearchNode := cachedChild Adaptive134Third133Node21 116
def Adaptive134Third133Node34 : CachedSearchNode := cachedChild Adaptive134Third133Node21 120
def Adaptive134Third133Node35 : CachedSearchNode := cachedChild Adaptive134Third133Node21 121
def Adaptive134Third133Node36 : CachedSearchNode := cachedChild Adaptive134Third133Node21 122
def Adaptive134Third133Node37 : CachedSearchNode := cachedChild Adaptive134Third133Node21 123
def Adaptive134Third133Node38 : CachedSearchNode := cachedChild Adaptive134Third133Node21 124
def Adaptive134Third133Node39 : CachedSearchNode := cachedChild Adaptive134Third133Node21 125
def Adaptive134Third133Node40 : CachedSearchNode := cachedChild Adaptive134Third133Node21 126
def Adaptive134Third133Node41 : CachedSearchNode := cachedChild Adaptive134Third133Node21 127
def Adaptive134Third133Node42 : CachedSearchNode := cachedChild Adaptive134Third133Node21 128
def Adaptive134Third133Node43 : CachedSearchNode := cachedChild Adaptive134Third133Node21 129
def Adaptive134Third133Node44 : CachedSearchNode := cachedChild Adaptive134Third133Node21 130

end NineSeparatedSubsetSums
