import NineSeparatedSubsetSums.Adaptive134Third115State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive134Third115Proof13 : runCachedNode 511 110531 Adaptive134Third115Node13 = false := by
  decide +kernel

#print axioms adaptive134Third115Proof13

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive134Third115Proof12 : runCachedNode 511 110531 Adaptive134Third115Node12 = false := by
  decide +kernel

#print axioms adaptive134Third115Proof12

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive134Third115Proof11 : runCachedNode 511 110531 Adaptive134Third115Node11 = false := by
  decide +kernel

#print axioms adaptive134Third115Proof11

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive134Third115Proof10 : runCachedNode 511 110531 Adaptive134Third115Node10 = false := by
  decide +kernel

#print axioms adaptive134Third115Proof10

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive134Third115Proof9 : runCachedNode 511 110531 Adaptive134Third115Node9 = false := by
  decide +kernel

#print axioms adaptive134Third115Proof9

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive134Third115Proof8 : runCachedNode 511 110531 Adaptive134Third115Node8 = false := by
  decide +kernel

#print axioms adaptive134Third115Proof8

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive134Third115Proof3 : runCachedNode 511 110531 Adaptive134Third115Node3 = false := by
  decide +kernel

#print axioms adaptive134Third115Proof3

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive134Third115Proof2 : runCachedNode 511 110531 Adaptive134Third115Node2 = false := by
  decide +kernel

#print axioms adaptive134Third115Proof2

end NineSeparatedSubsetSums
