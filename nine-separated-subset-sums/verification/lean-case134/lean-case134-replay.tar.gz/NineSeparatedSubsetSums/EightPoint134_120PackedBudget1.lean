import NineSeparatedSubsetSums.EightPoint134_120PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct134_120_1_budget :
    FourPointNumeric.packedBudget 20 packedOct134_120_1 376 = 81892386 := by decide +kernel

#print axioms packedOct134_120_1_budget

end NineSeparatedSubsetSums
