import NineSeparatedSubsetSums.EightPoint134_117PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint134_117PackedAnchor1Part1 :
    ∀ j : Fin 118, 2238158 ≤ FourPointNumeric.octPackedCharge 134 117 20 packedOct134_117_1
      (2*((j.val : Int)+120)+0) := by decide +kernel

end NineSeparatedSubsetSums
