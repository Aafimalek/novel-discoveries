import NineSeparatedSubsetSums.EightPoint134_130PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct134_130_1_budget :
    FourPointNumeric.packedBudget 20 packedOct134_130_1 446 = 86446848 := by decide +kernel

#print axioms packedOct134_130_1_budget

end NineSeparatedSubsetSums
