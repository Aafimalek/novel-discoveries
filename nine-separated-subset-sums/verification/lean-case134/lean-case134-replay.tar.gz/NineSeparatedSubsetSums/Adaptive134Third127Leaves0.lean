import NineSeparatedSubsetSums.Adaptive134Third127State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive134Third127Proof15 : runCachedNode 511 126222 Adaptive134Third127Node15 = false := by
  decide +kernel

#print axioms adaptive134Third127Proof15

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive134Third127Proof14 : runCachedNode 511 126222 Adaptive134Third127Node14 = false := by
  decide +kernel

#print axioms adaptive134Third127Proof14

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive134Third127Proof13 : runCachedNode 511 126222 Adaptive134Third127Node13 = false := by
  decide +kernel

#print axioms adaptive134Third127Proof13

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive134Third127Proof9 : runCachedNode 511 126222 Adaptive134Third127Node9 = false := by
  decide +kernel

#print axioms adaptive134Third127Proof9

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive134Third127Proof12 : runCachedNode 511 126222 Adaptive134Third127Node12 = false := by
  decide +kernel

#print axioms adaptive134Third127Proof12

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive134Third127Proof11 : runCachedNode 511 126222 Adaptive134Third127Node11 = false := by
  decide +kernel

#print axioms adaptive134Third127Proof11

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive134Third127Proof10 : runCachedNode 511 126222 Adaptive134Third127Node10 = false := by
  decide +kernel

#print axioms adaptive134Third127Proof10

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive134Third127Proof8 : runCachedNode 511 126222 Adaptive134Third127Node8 = false := by
  decide +kernel

#print axioms adaptive134Third127Proof8

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive134Third127Proof6 : runCachedNode 511 126222 Adaptive134Third127Node6 = false := by
  decide +kernel

#print axioms adaptive134Third127Proof6

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive134Third127Proof3 : runCachedNode 511 126222 Adaptive134Third127Node3 = false := by
  decide +kernel

#print axioms adaptive134Third127Proof3

end NineSeparatedSubsetSums
