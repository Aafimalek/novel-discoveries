import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive134Third119Node0 : CachedSearchNode :=
  ⟨4, 118, computeCenteredMask [148,134,119], 401, 54021⟩

end NineSeparatedSubsetSums
