import NineSeparatedSubsetSums.Adaptive134Third129State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive134Third129Proof17 : runCachedNode 511 126399 Adaptive134Third129Node17 = false := by
  decide +kernel

#print axioms adaptive134Third129Proof17

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive134Third129Proof16 : runCachedNode 511 126399 Adaptive134Third129Node16 = false := by
  decide +kernel

#print axioms adaptive134Third129Proof16

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive134Third129Proof15 : runCachedNode 511 126399 Adaptive134Third129Node15 = false := by
  decide +kernel

#print axioms adaptive134Third129Proof15

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive134Third129Proof14 : runCachedNode 511 126399 Adaptive134Third129Node14 = false := by
  decide +kernel

#print axioms adaptive134Third129Proof14

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive134Third129Proof4 : runCachedNode 511 126399 Adaptive134Third129Node4 = false := by
  decide +kernel

#print axioms adaptive134Third129Proof4

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive134Third129Proof3 : runCachedNode 511 126399 Adaptive134Third129Node3 = false := by
  decide +kernel

#print axioms adaptive134Third129Proof3

end NineSeparatedSubsetSums
