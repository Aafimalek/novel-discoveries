import NineSeparatedSubsetSums.Adaptive134Third115Joins0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint134Checked

namespace NineSeparatedSubsetSums


theorem adaptive134Third115 : NoDescendingTailAfterThird 134 115 :=
  noDescendingThirdTail_of_cached 134 115 110531 (fun t ht nd => max148_second134_fourPoint_moment_bound (115::t) (by simp [ht]) nd) adaptive134Third115Proof0

#print axioms adaptive134Third115

end NineSeparatedSubsetSums
