import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive134Third124Node0 : CachedSearchNode :=
  ⟨4, 123, computeCenteredMask [148,134,124], 406, 55236⟩

end NineSeparatedSubsetSums
