import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive134Third126Node0 : CachedSearchNode :=
  ⟨4, 125, computeCenteredMask [148,134,126], 408, 55736⟩

end NineSeparatedSubsetSums
