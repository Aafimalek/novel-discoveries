import NineSeparatedSubsetSums.EightPoint134_122PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint134_122PackedAnchor0Part2 :
    ∀ j : Fin 1, 2294487 ≤ FourPointNumeric.octPackedCharge 134 122 20 packedOct134_122_0
      (2*((j.val : Int)+240)+0) := by decide +kernel

end NineSeparatedSubsetSums
