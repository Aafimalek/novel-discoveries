import NineSeparatedSubsetSums.Adaptive134Third131State
import NineSeparatedSubsetSums.Adaptive134Third131Leaves1
import NineSeparatedSubsetSums.Adaptive134Third131Leaves2
import NineSeparatedSubsetSums.Adaptive134Third131Leaves0

namespace NineSeparatedSubsetSums

theorem adaptive134Third131Proof0 : runCachedNode 511 126872 Adaptive134Third131Node0 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 126872 Adaptive134Third131Node0 = [111, 112, 113, 114, 115, 116, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive134Third131Proof1
  · exact adaptive134Third131Proof2
  · exact adaptive134Third131Proof3
  · exact adaptive134Third131Proof4
  · exact adaptive134Third131Proof5
  · exact adaptive134Third131Proof6
  · exact adaptive134Third131Proof7
  · exact adaptive134Third131Proof8
  · exact adaptive134Third131Proof9
  · exact adaptive134Third131Proof10
  · exact adaptive134Third131Proof11
  · exact adaptive134Third131Proof12
  · exact adaptive134Third131Proof13
  · exact adaptive134Third131Proof14
  · exact adaptive134Third131Proof15
  · exact adaptive134Third131Proof16
  · exact adaptive134Third131Proof17
  · exact adaptive134Third131Proof18
  · exact adaptive134Third131Proof19

#print axioms adaptive134Third131Proof0

end NineSeparatedSubsetSums
