import NineSeparatedSubsetSums.Adaptive134Third128State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive134Third128Proof11 : runCachedNode 511 126356 Adaptive134Third128Node11 = false := by
  decide +kernel

#print axioms adaptive134Third128Proof11

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive134Third128Proof9 : runCachedNode 511 126356 Adaptive134Third128Node9 = false := by
  decide +kernel

#print axioms adaptive134Third128Proof9

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive134Third128Proof10 : runCachedNode 511 126356 Adaptive134Third128Node10 = false := by
  decide +kernel

#print axioms adaptive134Third128Proof10

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive134Third128Proof7 : runCachedNode 511 126356 Adaptive134Third128Node7 = false := by
  decide +kernel

#print axioms adaptive134Third128Proof7

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive134Third128Proof6 : runCachedNode 511 126356 Adaptive134Third128Node6 = false := by
  decide +kernel

#print axioms adaptive134Third128Proof6

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive134Third128Proof5 : runCachedNode 511 126356 Adaptive134Third128Node5 = false := by
  decide +kernel

#print axioms adaptive134Third128Proof5

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive134Third128Proof3 : runCachedNode 511 126356 Adaptive134Third128Node3 = false := by
  decide +kernel

#print axioms adaptive134Third128Proof3

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive134Third128Proof1 : runCachedNode 511 126356 Adaptive134Third128Node1 = false := by
  decide +kernel

#print axioms adaptive134Third128Proof1

end NineSeparatedSubsetSums
