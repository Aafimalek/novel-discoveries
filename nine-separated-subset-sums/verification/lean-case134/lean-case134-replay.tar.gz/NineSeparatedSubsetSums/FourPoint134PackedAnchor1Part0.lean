import NineSeparatedSubsetSums.FourPoint134PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem fourPoint134PackedAnchor1Part0 :
    ∀ j : Fin 120, 1045652 ≤ FourPointNumeric.packedCharge 134 20 packedWeight134_1
      (2*((j.val : Int)+0)+1) := by decide +kernel

end NineSeparatedSubsetSums
