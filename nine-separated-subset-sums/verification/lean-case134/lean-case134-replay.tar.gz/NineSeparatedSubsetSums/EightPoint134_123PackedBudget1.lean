import NineSeparatedSubsetSums.EightPoint134_123PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct134_123_1_budget :
    FourPointNumeric.packedBudget 20 packedOct134_123_1 506 = 80814658 := by decide +kernel

#print axioms packedOct134_123_1_budget

end NineSeparatedSubsetSums
