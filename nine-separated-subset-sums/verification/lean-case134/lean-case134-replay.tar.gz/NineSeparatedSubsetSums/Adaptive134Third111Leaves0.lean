import NineSeparatedSubsetSums.Adaptive134Third111State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive134Third111Proof0 : runCachedNode 511 110531 Adaptive134Third111Node0 = false := by
  decide +kernel

#print axioms adaptive134Third111Proof0

end NineSeparatedSubsetSums
