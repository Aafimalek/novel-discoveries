import NineSeparatedSubsetSums.Adaptive134Third133State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive134Third133Proof43 : runCachedNode 511 127264 Adaptive134Third133Node43 = false := by
  decide +kernel

#print axioms adaptive134Third133Proof43

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive134Third133Proof42 : runCachedNode 511 127264 Adaptive134Third133Node42 = false := by
  decide +kernel

#print axioms adaptive134Third133Proof42

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive134Third133Proof12 : runCachedNode 511 127264 Adaptive134Third133Node12 = false := by
  decide +kernel

#print axioms adaptive134Third133Proof12

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive134Third133Proof39 : runCachedNode 511 127264 Adaptive134Third133Node39 = false := by
  decide +kernel

#print axioms adaptive134Third133Proof39

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive134Third133Proof41 : runCachedNode 511 127264 Adaptive134Third133Node41 = false := by
  decide +kernel

#print axioms adaptive134Third133Proof41

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive134Third133Proof9 : runCachedNode 511 127264 Adaptive134Third133Node9 = false := by
  decide +kernel

#print axioms adaptive134Third133Proof9

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive134Third133Proof40 : runCachedNode 511 127264 Adaptive134Third133Node40 = false := by
  decide +kernel

#print axioms adaptive134Third133Proof40

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive134Third133Proof11 : runCachedNode 511 127264 Adaptive134Third133Node11 = false := by
  decide +kernel

#print axioms adaptive134Third133Proof11

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive134Third133Proof8 : runCachedNode 511 127264 Adaptive134Third133Node8 = false := by
  decide +kernel

#print axioms adaptive134Third133Proof8

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive134Third133Proof10 : runCachedNode 511 127264 Adaptive134Third133Node10 = false := by
  decide +kernel

#print axioms adaptive134Third133Proof10

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive134Third133Proof34 : runCachedNode 511 127264 Adaptive134Third133Node34 = false := by
  decide +kernel

#print axioms adaptive134Third133Proof34

end NineSeparatedSubsetSums
