import NineSeparatedSubsetSums.EightPointPackedGeometry
import NineSeparatedSubsetSums.EightPoint134_120PackedBudget0
import NineSeparatedSubsetSums.EightPoint134_120PackedAnchor0Part0
import NineSeparatedSubsetSums.EightPoint134_120PackedAnchor0Part1
import NineSeparatedSubsetSums.EightPoint134_120PackedBudget1
import NineSeparatedSubsetSums.EightPoint134_120PackedAnchor1Part0
import NineSeparatedSubsetSums.EightPoint134_120PackedAnchor1Part1

namespace NineSeparatedSubsetSums

private theorem packedOct134_120Anchor0 :
  ∀ j : Fin 480, ((j.val : Int)+134+120)%2=0 →
    2274589 ≤ FourPointNumeric.octPackedCharge 134 120 20 packedOct134_120_0 (j.val : Int) := by
  intro j hj
  let k := (j.val-0)/2
  have hk : k < 240 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+0 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint134_120PackedAnchor0Part0 z
    rwa [he,hrep] at ht
  let z : Fin 120 := ⟨k-120, by omega⟩
  have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
  have ht := eightPoint134_120PackedAnchor0Part1 z
  rwa [he,hrep] at ht

private theorem packedOct134_120Anchor1 :
  ∀ j : Fin 480, ((j.val : Int)+134+120)%2=1 →
    2274751 ≤ FourPointNumeric.octPackedCharge 134 120 20 packedOct134_120_1 (j.val : Int) := by
  intro j hj
  let k := (j.val-1)/2
  have hk : k < 240 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+1 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint134_120PackedAnchor1Part0 z
    rwa [he,hrep] at ht
  let z : Fin 120 := ⟨k-120, by omega⟩
  have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
  have ht := eightPoint134_120PackedAnchor1Part1 z
  rwa [he,hrep] at ht

def packedOctCertificate134_120_0 : EightPointCertificate 134 120 0 124398 :=
  eightPointCertificateOfPacked 134 120 0 124398 2274589 20 packedOct134_120_0 267 480
    (by decide +kernel) (by decide) packedOct134_120Anchor0
    (by rw [packedOct134_120_0_budget]; decide)

def packedOctCertificate134_120_1 : EightPointCertificate 134 120 1 124398 :=
  eightPointCertificateOfPacked 134 120 1 124398 2274751 20 packedOct134_120_1 376 480
    (by decide +kernel) (by decide) packedOct134_120Anchor1
    (by rw [packedOct134_120_1_budget]; decide)

theorem max148_second134_third120_eightPoint_moment_bound (tail : List ℕ) (len : tail.length=6)
    (distinct : (natSubsetSums (148::134::120::tail)).Nodup) :
    124398 ≤ ((148::134::120::tail).map (· ^ 2)).sum := by
  apply eightPointNatMomentLower 134 120 124398 tail len distinct
  intro p hp
  by_cases h : p=0
  · subst p
    exact packedOctCertificate134_120_0
  · have he : p=1 := hp.resolve_left h
    subst p
    exact packedOctCertificate134_120_1

#print axioms max148_second134_third120_eightPoint_moment_bound

end NineSeparatedSubsetSums
