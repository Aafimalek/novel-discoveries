import NineSeparatedSubsetSums.EightPoint134_120PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint134_120PackedAnchor0Part0 :
    ∀ j : Fin 120, 2274589 ≤ FourPointNumeric.octPackedCharge 134 120 20 packedOct134_120_0
      (2*((j.val : Int)+0)+0) := by decide +kernel

end NineSeparatedSubsetSums
