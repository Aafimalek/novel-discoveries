import NineSeparatedSubsetSums.Adaptive134Third125State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive134Third125Proof0 : runCachedNode 511 125800 Adaptive134Third125Node0 = false := by
  decide +kernel

#print axioms adaptive134Third125Proof0

end NineSeparatedSubsetSums
