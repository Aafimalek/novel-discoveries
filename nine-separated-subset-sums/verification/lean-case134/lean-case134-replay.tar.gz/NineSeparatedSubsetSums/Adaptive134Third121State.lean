import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive134Third121Node0 : CachedSearchNode :=
  ⟨4, 120, computeCenteredMask [148,134,121], 403, 54501⟩

end NineSeparatedSubsetSums
