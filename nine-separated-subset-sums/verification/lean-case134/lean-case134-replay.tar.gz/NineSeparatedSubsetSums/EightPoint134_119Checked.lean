import NineSeparatedSubsetSums.EightPointPackedGeometry
import NineSeparatedSubsetSums.EightPoint134_119PackedBudget0
import NineSeparatedSubsetSums.EightPoint134_119PackedAnchor0Part0
import NineSeparatedSubsetSums.EightPoint134_119PackedAnchor0Part1
import NineSeparatedSubsetSums.EightPoint134_119PackedAnchor0Part2
import NineSeparatedSubsetSums.EightPoint134_119PackedBudget1
import NineSeparatedSubsetSums.EightPoint134_119PackedAnchor1Part0
import NineSeparatedSubsetSums.EightPoint134_119PackedAnchor1Part1
import NineSeparatedSubsetSums.EightPoint134_119PackedAnchor1Part2

namespace NineSeparatedSubsetSums

private theorem packedOct134_119Anchor0 :
  ∀ j : Fin 483, ((j.val : Int)+134+119)%2=0 →
    2294754 ≤ FourPointNumeric.octPackedCharge 134 119 20 packedOct134_119_0 (j.val : Int) := by
  intro j hj
  let k := (j.val-1)/2
  have hk : k < 241 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+1 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint134_119PackedAnchor0Part0 z
    rwa [he,hrep] at ht
  by_cases h1 : k < 240
  · let z : Fin 120 := ⟨k-120, by omega⟩
    have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
    have ht := eightPoint134_119PackedAnchor0Part1 z
    rwa [he,hrep] at ht
  let z : Fin 1 := ⟨k-240, by omega⟩
  have he : (z.val : Int)+240 = k := by dsimp [z] <;> omega
  have ht := eightPoint134_119PackedAnchor0Part2 z
  rwa [he,hrep] at ht

private theorem packedOct134_119Anchor1 :
  ∀ j : Fin 483, ((j.val : Int)+134+119)%2=1 →
    2294391 ≤ FourPointNumeric.octPackedCharge 134 119 20 packedOct134_119_1 (j.val : Int) := by
  intro j hj
  let k := (j.val-0)/2
  have hk : k < 242 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+0 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint134_119PackedAnchor1Part0 z
    rwa [he,hrep] at ht
  by_cases h1 : k < 240
  · let z : Fin 120 := ⟨k-120, by omega⟩
    have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
    have ht := eightPoint134_119PackedAnchor1Part1 z
    rwa [he,hrep] at ht
  let z : Fin 2 := ⟨k-240, by omega⟩
  have he : (z.val : Int)+240 = k := by dsimp [z] <;> omega
  have ht := eightPoint134_119PackedAnchor1Part2 z
  rwa [he,hrep] at ht

def packedOctCertificate134_119_0 : EightPointCertificate 134 119 0 124381 :=
  eightPointCertificateOfPacked 134 119 0 124381 2294754 20 packedOct134_119_0 381 483
    (by decide +kernel) (by decide) packedOct134_119Anchor0
    (by rw [packedOct134_119_0_budget]; decide)

def packedOctCertificate134_119_1 : EightPointCertificate 134 119 1 124381 :=
  eightPointCertificateOfPacked 134 119 1 124381 2294391 20 packedOct134_119_1 382 483
    (by decide +kernel) (by decide) packedOct134_119Anchor1
    (by rw [packedOct134_119_1_budget]; decide)

theorem max148_second134_third119_eightPoint_moment_bound (tail : List ℕ) (len : tail.length=6)
    (distinct : (natSubsetSums (148::134::119::tail)).Nodup) :
    124381 ≤ ((148::134::119::tail).map (· ^ 2)).sum := by
  apply eightPointNatMomentLower 134 119 124381 tail len distinct
  intro p hp
  by_cases h : p=0
  · subst p
    exact packedOctCertificate134_119_0
  · have he : p=1 := hp.resolve_left h
    subst p
    exact packedOctCertificate134_119_1

#print axioms max148_second134_third119_eightPoint_moment_bound

end NineSeparatedSubsetSums
