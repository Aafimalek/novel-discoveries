import NineSeparatedSubsetSums.EightPointPackedGeometry
import NineSeparatedSubsetSums.EightPoint134_118PackedBudget0
import NineSeparatedSubsetSums.EightPoint134_118PackedAnchor0Part0
import NineSeparatedSubsetSums.EightPoint134_118PackedAnchor0Part1
import NineSeparatedSubsetSums.EightPoint134_118PackedBudget1
import NineSeparatedSubsetSums.EightPoint134_118PackedAnchor1Part0
import NineSeparatedSubsetSums.EightPoint134_118PackedAnchor1Part1

namespace NineSeparatedSubsetSums

private theorem packedOct134_118Anchor0 :
  ∀ j : Fin 479, ((j.val : Int)+134+118)%2=0 →
    2264867 ≤ FourPointNumeric.octPackedCharge 134 118 20 packedOct134_118_0 (j.val : Int) := by
  intro j hj
  let k := (j.val-0)/2
  have hk : k < 240 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+0 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint134_118PackedAnchor0Part0 z
    rwa [he,hrep] at ht
  let z : Fin 120 := ⟨k-120, by omega⟩
  have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
  have ht := eightPoint134_118PackedAnchor0Part1 z
  rwa [he,hrep] at ht

private theorem packedOct134_118Anchor1 :
  ∀ j : Fin 479, ((j.val : Int)+134+118)%2=1 →
    2265076 ≤ FourPointNumeric.octPackedCharge 134 118 20 packedOct134_118_1 (j.val : Int) := by
  intro j hj
  let k := (j.val-1)/2
  have hk : k < 239 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+1 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint134_118PackedAnchor1Part0 z
    rwa [he,hrep] at ht
  let z : Fin 119 := ⟨k-120, by omega⟩
  have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
  have ht := eightPoint134_118PackedAnchor1Part1 z
  rwa [he,hrep] at ht

def packedOctCertificate134_118_0 : EightPointCertificate 134 118 0 124255 :=
  eightPointCertificateOfPacked 134 118 0 124255 2264867 20 packedOct134_118_0 269 479
    (by decide +kernel) (by decide) packedOct134_118Anchor0
    (by rw [packedOct134_118_0_budget]; decide)

def packedOctCertificate134_118_1 : EightPointCertificate 134 118 1 124255 :=
  eightPointCertificateOfPacked 134 118 1 124255 2265076 20 packedOct134_118_1 268 479
    (by decide +kernel) (by decide) packedOct134_118Anchor1
    (by rw [packedOct134_118_1_budget]; decide)

theorem max148_second134_third118_eightPoint_moment_bound (tail : List ℕ) (len : tail.length=6)
    (distinct : (natSubsetSums (148::134::118::tail)).Nodup) :
    124255 ≤ ((148::134::118::tail).map (· ^ 2)).sum := by
  apply eightPointNatMomentLower 134 118 124255 tail len distinct
  intro p hp
  by_cases h : p=0
  · subst p
    exact packedOctCertificate134_118_0
  · have he : p=1 := hp.resolve_left h
    subst p
    exact packedOctCertificate134_118_1

#print axioms max148_second134_third118_eightPoint_moment_bound

end NineSeparatedSubsetSums
