import NineSeparatedSubsetSums.Adaptive134Third115State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive134Third115Proof7 : runCachedNode 511 110531 Adaptive134Third115Node7 = false := by
  decide +kernel

#print axioms adaptive134Third115Proof7

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive134Third115Proof6 : runCachedNode 511 110531 Adaptive134Third115Node6 = false := by
  decide +kernel

#print axioms adaptive134Third115Proof6

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive134Third115Proof5 : runCachedNode 511 110531 Adaptive134Third115Node5 = false := by
  decide +kernel

#print axioms adaptive134Third115Proof5

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive134Third115Proof4 : runCachedNode 511 110531 Adaptive134Third115Node4 = false := by
  decide +kernel

#print axioms adaptive134Third115Proof4

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive134Third115Proof1 : runCachedNode 511 110531 Adaptive134Third115Node1 = false := by
  decide +kernel

#print axioms adaptive134Third115Proof1

end NineSeparatedSubsetSums
