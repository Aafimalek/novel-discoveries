import NineSeparatedSubsetSums.EightPoint134_123PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint134_123PackedAnchor1Part0 :
    ∀ j : Fin 120, 2263297 ≤ FourPointNumeric.octPackedCharge 134 123 20 packedOct134_123_1
      (2*((j.val : Int)+0)+0) := by decide +kernel

end NineSeparatedSubsetSums
