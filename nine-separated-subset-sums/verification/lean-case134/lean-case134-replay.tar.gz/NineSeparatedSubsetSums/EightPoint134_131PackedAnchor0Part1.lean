import NineSeparatedSubsetSums.EightPoint134_131PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint134_131PackedAnchor0Part1 :
    ∀ j : Fin 120, 2393160 ≤ FourPointNumeric.octPackedCharge 134 131 20 packedOct134_131_0
      (2*((j.val : Int)+120)+1) := by decide +kernel

end NineSeparatedSubsetSums
