import NineSeparatedSubsetSums.Adaptive134Third123State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive134Third123Proof0 : runCachedNode 511 125071 Adaptive134Third123Node0 = false := by
  decide +kernel

#print axioms adaptive134Third123Proof0

end NineSeparatedSubsetSums
