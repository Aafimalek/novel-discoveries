import NineSeparatedSubsetSums.EightPoint134_123PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint134_123PackedAnchor0Part0 :
    ∀ j : Fin 120, 2265082 ≤ FourPointNumeric.octPackedCharge 134 123 20 packedOct134_123_0
      (2*((j.val : Int)+0)+1) := by decide +kernel

end NineSeparatedSubsetSums
