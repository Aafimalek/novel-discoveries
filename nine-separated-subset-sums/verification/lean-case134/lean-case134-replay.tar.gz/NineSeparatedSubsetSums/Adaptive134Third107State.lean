import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive134Third107Node0 : CachedSearchNode :=
  ⟨4, 106, computeCenteredMask [148,134,107], 389, 51309⟩

end NineSeparatedSubsetSums
