import NineSeparatedSubsetSums.EightPoint134_124PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint134_124PackedAnchor1Part1 :
    ∀ j : Fin 120, 2284784 ≤ FourPointNumeric.octPackedCharge 134 124 20 packedOct134_124_1
      (2*((j.val : Int)+120)+1) := by decide +kernel

end NineSeparatedSubsetSums
