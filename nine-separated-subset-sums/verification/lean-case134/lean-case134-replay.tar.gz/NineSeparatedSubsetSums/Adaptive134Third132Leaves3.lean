import NineSeparatedSubsetSums.Adaptive134Third132State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive134Third132Proof16 : runCachedNode 511 127087 Adaptive134Third132Node16 = false := by
  decide +kernel

#print axioms adaptive134Third132Proof16

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive134Third132Proof13 : runCachedNode 511 127087 Adaptive134Third132Node13 = false := by
  decide +kernel

#print axioms adaptive134Third132Proof13

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive134Third132Proof9 : runCachedNode 511 127087 Adaptive134Third132Node9 = false := by
  decide +kernel

#print axioms adaptive134Third132Proof9

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive134Third132Proof12 : runCachedNode 511 127087 Adaptive134Third132Node12 = false := by
  decide +kernel

#print axioms adaptive134Third132Proof12

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive134Third132Proof11 : runCachedNode 511 127087 Adaptive134Third132Node11 = false := by
  decide +kernel

#print axioms adaptive134Third132Proof11

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive134Third132Proof10 : runCachedNode 511 127087 Adaptive134Third132Node10 = false := by
  decide +kernel

#print axioms adaptive134Third132Proof10

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive134Third132Proof5 : runCachedNode 511 127087 Adaptive134Third132Node5 = false := by
  decide +kernel

#print axioms adaptive134Third132Proof5

end NineSeparatedSubsetSums
