import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive134Third122Node0 : CachedSearchNode :=
  ⟨4, 121, computeCenteredMask [148,134,122], 404, 54744⟩

end NineSeparatedSubsetSums
