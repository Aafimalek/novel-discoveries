import NineSeparatedSubsetSums.EightPoint134_132PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint134_132PackedAnchor0Part2 :
    ∀ j : Fin 7, 2396242 ≤ FourPointNumeric.octPackedCharge 134 132 20 packedOct134_132_0
      (2*((j.val : Int)+240)+0) := by decide +kernel

end NineSeparatedSubsetSums
