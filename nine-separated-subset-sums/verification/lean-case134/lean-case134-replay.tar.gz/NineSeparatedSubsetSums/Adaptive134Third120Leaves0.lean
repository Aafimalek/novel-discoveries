import NineSeparatedSubsetSums.Adaptive134Third120State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive134Third120Proof0 : runCachedNode 511 124398 Adaptive134Third120Node0 = false := by
  decide +kernel

#print axioms adaptive134Third120Proof0

end NineSeparatedSubsetSums
