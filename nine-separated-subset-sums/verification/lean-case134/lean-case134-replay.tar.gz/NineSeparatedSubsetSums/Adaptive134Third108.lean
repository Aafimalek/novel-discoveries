import NineSeparatedSubsetSums.Adaptive134Third108Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint134Checked

namespace NineSeparatedSubsetSums


theorem adaptive134Third108 : NoDescendingTailAfterThird 134 108 :=
  noDescendingThirdTail_of_cached 134 108 110531 (fun t ht nd => max148_second134_fourPoint_moment_bound (108::t) (by simp [ht]) nd) adaptive134Third108Proof0

#print axioms adaptive134Third108

end NineSeparatedSubsetSums
