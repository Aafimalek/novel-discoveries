import NineSeparatedSubsetSums.EightPoint134_122PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint134_122PackedAnchor1Part1 :
    ∀ j : Fin 120, 2295163 ≤ FourPointNumeric.octPackedCharge 134 122 20 packedOct134_122_1
      (2*((j.val : Int)+120)+1) := by decide +kernel

end NineSeparatedSubsetSums
