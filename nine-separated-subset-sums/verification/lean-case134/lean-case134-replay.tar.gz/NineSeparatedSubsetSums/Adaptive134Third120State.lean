import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive134Third120Node0 : CachedSearchNode :=
  ⟨4, 119, computeCenteredMask [148,134,120], 402, 54260⟩

end NineSeparatedSubsetSums
