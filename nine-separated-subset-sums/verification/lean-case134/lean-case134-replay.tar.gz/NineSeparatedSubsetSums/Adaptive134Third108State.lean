import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive134Third108Node0 : CachedSearchNode :=
  ⟨4, 107, computeCenteredMask [148,134,108], 390, 51524⟩

end NineSeparatedSubsetSums
