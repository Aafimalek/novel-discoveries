import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive134Third123Node0 : CachedSearchNode :=
  ⟨4, 122, computeCenteredMask [148,134,123], 405, 54989⟩

end NineSeparatedSubsetSums
