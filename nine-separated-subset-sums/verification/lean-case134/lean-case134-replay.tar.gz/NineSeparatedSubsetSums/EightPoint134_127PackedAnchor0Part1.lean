import NineSeparatedSubsetSums.EightPoint134_127PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint134_127PackedAnchor0Part1 :
    ∀ j : Fin 120, 2332935 ≤ FourPointNumeric.octPackedCharge 134 127 20 packedOct134_127_0
      (2*((j.val : Int)+120)+1) := by decide +kernel

end NineSeparatedSubsetSums
