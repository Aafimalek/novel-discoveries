import NineSeparatedSubsetSums.EightPoint134_129PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint134_129PackedAnchor0Part1 :
    ∀ j : Fin 120, 2339669 ≤ FourPointNumeric.octPackedCharge 134 129 20 packedOct134_129_0
      (2*((j.val : Int)+120)+1) := by decide +kernel

end NineSeparatedSubsetSums
