import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive134Third125Node0 : CachedSearchNode :=
  ⟨4, 124, computeCenteredMask [148,134,125], 407, 55485⟩

end NineSeparatedSubsetSums
