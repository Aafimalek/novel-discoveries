import NineSeparatedSubsetSums.EightPoint134_130PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct134_130_0_budget :
    FourPointNumeric.packedBudget 20 packedOct134_130_0 447 = 86619904 := by decide +kernel

#print axioms packedOct134_130_0_budget

end NineSeparatedSubsetSums
