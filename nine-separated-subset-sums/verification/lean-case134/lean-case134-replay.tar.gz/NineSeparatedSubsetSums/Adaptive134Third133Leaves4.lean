import NineSeparatedSubsetSums.Adaptive134Third133State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive134Third133Proof37 : runCachedNode 511 127264 Adaptive134Third133Node37 = false := by
  decide +kernel

#print axioms adaptive134Third133Proof37

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive134Third133Proof35 : runCachedNode 511 127264 Adaptive134Third133Node35 = false := by
  decide +kernel

#print axioms adaptive134Third133Proof35

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive134Third133Proof36 : runCachedNode 511 127264 Adaptive134Third133Node36 = false := by
  decide +kernel

#print axioms adaptive134Third133Proof36

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive134Third133Proof33 : runCachedNode 511 127264 Adaptive134Third133Node33 = false := by
  decide +kernel

#print axioms adaptive134Third133Proof33

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive134Third133Proof6 : runCachedNode 511 127264 Adaptive134Third133Node6 = false := by
  decide +kernel

#print axioms adaptive134Third133Proof6

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive134Third133Proof32 : runCachedNode 511 127264 Adaptive134Third133Node32 = false := by
  decide +kernel

#print axioms adaptive134Third133Proof32

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive134Third133Proof29 : runCachedNode 511 127264 Adaptive134Third133Node29 = false := by
  decide +kernel

#print axioms adaptive134Third133Proof29

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive134Third133Proof28 : runCachedNode 511 127264 Adaptive134Third133Node28 = false := by
  decide +kernel

#print axioms adaptive134Third133Proof28

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive134Third133Proof30 : runCachedNode 511 127264 Adaptive134Third133Node30 = false := by
  decide +kernel

#print axioms adaptive134Third133Proof30

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive134Third133Proof5 : runCachedNode 511 127264 Adaptive134Third133Node5 = false := by
  decide +kernel

#print axioms adaptive134Third133Proof5

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive134Third133Proof31 : runCachedNode 511 127264 Adaptive134Third133Node31 = false := by
  decide +kernel

#print axioms adaptive134Third133Proof31

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive134Third133Proof27 : runCachedNode 511 127264 Adaptive134Third133Node27 = false := by
  decide +kernel

#print axioms adaptive134Third133Proof27

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive134Third133Proof26 : runCachedNode 511 127264 Adaptive134Third133Node26 = false := by
  decide +kernel

#print axioms adaptive134Third133Proof26

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive134Third133Proof25 : runCachedNode 511 127264 Adaptive134Third133Node25 = false := by
  decide +kernel

#print axioms adaptive134Third133Proof25

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive134Third133Proof23 : runCachedNode 511 127264 Adaptive134Third133Node23 = false := by
  decide +kernel

#print axioms adaptive134Third133Proof23

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive134Third133Proof22 : runCachedNode 511 127264 Adaptive134Third133Node22 = false := by
  decide +kernel

#print axioms adaptive134Third133Proof22

end NineSeparatedSubsetSums
