import NineSeparatedSubsetSums.Adaptive134Third105Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint134Checked

namespace NineSeparatedSubsetSums


theorem adaptive134Third105 : NoDescendingTailAfterThird 134 105 :=
  noDescendingThirdTail_of_cached 134 105 110531 (fun t ht nd => max148_second134_fourPoint_moment_bound (105::t) (by simp [ht]) nd) adaptive134Third105Proof0

#print axioms adaptive134Third105

end NineSeparatedSubsetSums
