import NineSeparatedSubsetSums.EightPoint134_122PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct134_122_0_budget :
    FourPointNumeric.packedBudget 20 packedOct134_122_0 403 = 82960563 := by decide +kernel

#print axioms packedOct134_122_0_budget

end NineSeparatedSubsetSums
