import NineSeparatedSubsetSums.Adaptive134Third113Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint134Checked

namespace NineSeparatedSubsetSums


theorem adaptive134Third113 : NoDescendingTailAfterThird 134 113 :=
  noDescendingThirdTail_of_cached 134 113 110531 (fun t ht nd => max148_second134_fourPoint_moment_bound (113::t) (by simp [ht]) nd) adaptive134Third113Proof0

#print axioms adaptive134Third113

end NineSeparatedSubsetSums
