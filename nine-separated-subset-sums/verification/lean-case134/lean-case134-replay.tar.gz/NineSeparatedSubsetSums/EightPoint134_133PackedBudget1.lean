import NineSeparatedSubsetSums.EightPoint134_133PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct134_133_1_budget :
    FourPointNumeric.packedBudget 20 packedOct134_133_1 366 = 88564270 := by decide +kernel

#print axioms packedOct134_133_1_budget

end NineSeparatedSubsetSums
