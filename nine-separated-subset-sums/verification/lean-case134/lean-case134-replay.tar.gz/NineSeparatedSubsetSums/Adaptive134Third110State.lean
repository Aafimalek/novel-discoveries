import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive134Third110Node0 : CachedSearchNode :=
  ⟨4, 109, computeCenteredMask [148,134,110], 392, 51960⟩

end NineSeparatedSubsetSums
