import NineSeparatedSubsetSums.Adaptive134Third116State
import NineSeparatedSubsetSums.Adaptive134Third116Leaves0
import NineSeparatedSubsetSums.Adaptive134Third116Leaves1

namespace NineSeparatedSubsetSums

theorem adaptive134Third116Proof0 : runCachedNode 511 110531 Adaptive134Third116Node0 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 110531 Adaptive134Third116Node0 = [101, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive134Third116Proof1
  · exact adaptive134Third116Proof2
  · exact adaptive134Third116Proof3
  · exact adaptive134Third116Proof4
  · exact adaptive134Third116Proof5
  · exact adaptive134Third116Proof6
  · exact adaptive134Third116Proof7
  · exact adaptive134Third116Proof8
  · exact adaptive134Third116Proof9
  · exact adaptive134Third116Proof10
  · exact adaptive134Third116Proof11
  · exact adaptive134Third116Proof12
  · exact adaptive134Third116Proof13
  · exact adaptive134Third116Proof14

#print axioms adaptive134Third116Proof0

end NineSeparatedSubsetSums
