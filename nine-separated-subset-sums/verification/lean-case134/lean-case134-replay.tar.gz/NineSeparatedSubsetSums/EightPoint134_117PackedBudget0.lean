import NineSeparatedSubsetSums.EightPoint134_117PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct134_117_0_budget :
    FourPointNumeric.packedBudget 20 packedOct134_117_0 269 = 79626442 := by decide +kernel

#print axioms packedOct134_117_0_budget

end NineSeparatedSubsetSums
