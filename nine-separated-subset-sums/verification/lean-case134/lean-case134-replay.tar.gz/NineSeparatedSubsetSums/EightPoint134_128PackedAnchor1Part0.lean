import NineSeparatedSubsetSums.EightPoint134_128PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint134_128PackedAnchor1Part0 :
    ∀ j : Fin 120, 2327335 ≤ FourPointNumeric.octPackedCharge 134 128 20 packedOct134_128_1
      (2*((j.val : Int)+0)+1) := by decide +kernel

end NineSeparatedSubsetSums
