import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive134Third112Node0 : CachedSearchNode :=
  ⟨4, 111, computeCenteredMask [148,134,112], 394, 52404⟩

end NineSeparatedSubsetSums
