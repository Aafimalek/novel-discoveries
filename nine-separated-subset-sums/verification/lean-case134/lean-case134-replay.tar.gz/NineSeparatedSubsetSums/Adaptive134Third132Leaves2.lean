import NineSeparatedSubsetSums.Adaptive134Third132State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive134Third132Proof18 : runCachedNode 511 127087 Adaptive134Third132Node18 = false := by
  decide +kernel

#print axioms adaptive134Third132Proof18

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive134Third132Proof17 : runCachedNode 511 127087 Adaptive134Third132Node17 = false := by
  decide +kernel

#print axioms adaptive134Third132Proof17

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive134Third132Proof14 : runCachedNode 511 127087 Adaptive134Third132Node14 = false := by
  decide +kernel

#print axioms adaptive134Third132Proof14

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive134Third132Proof7 : runCachedNode 511 127087 Adaptive134Third132Node7 = false := by
  decide +kernel

#print axioms adaptive134Third132Proof7

end NineSeparatedSubsetSums
