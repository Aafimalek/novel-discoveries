import NineSeparatedSubsetSums.Adaptive134Third118State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive134Third118Proof0 : runCachedNode 511 124255 Adaptive134Third118Node0 = false := by
  decide +kernel

#print axioms adaptive134Third118Proof0

end NineSeparatedSubsetSums
