import NineSeparatedSubsetSums.EightPoint134_127PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint134_127PackedAnchor1Part2 :
    ∀ j : Fin 3, 2333230 ≤ FourPointNumeric.octPackedCharge 134 127 20 packedOct134_127_1
      (2*((j.val : Int)+240)+0) := by decide +kernel

end NineSeparatedSubsetSums
