import NineSeparatedSubsetSums.Adaptive134Third116Joins0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint134Checked

namespace NineSeparatedSubsetSums


theorem adaptive134Third116 : NoDescendingTailAfterThird 134 116 :=
  noDescendingThirdTail_of_cached 134 116 110531 (fun t ht nd => max148_second134_fourPoint_moment_bound (116::t) (by simp [ht]) nd) adaptive134Third116Proof0

#print axioms adaptive134Third116

end NineSeparatedSubsetSums
