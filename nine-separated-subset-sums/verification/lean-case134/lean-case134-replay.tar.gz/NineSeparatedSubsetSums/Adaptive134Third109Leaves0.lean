import NineSeparatedSubsetSums.Adaptive134Third109State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive134Third109Proof0 : runCachedNode 511 110531 Adaptive134Third109Node0 = false := by
  decide +kernel

#print axioms adaptive134Third109Proof0

end NineSeparatedSubsetSums
