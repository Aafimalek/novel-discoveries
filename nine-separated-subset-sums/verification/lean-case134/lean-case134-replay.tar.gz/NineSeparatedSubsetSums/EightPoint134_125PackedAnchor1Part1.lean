import NineSeparatedSubsetSums.EightPoint134_125PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint134_125PackedAnchor1Part1 :
    ∀ j : Fin 120, 2323880 ≤ FourPointNumeric.octPackedCharge 134 125 20 packedOct134_125_1
      (2*((j.val : Int)+120)+0) := by decide +kernel

end NineSeparatedSubsetSums
