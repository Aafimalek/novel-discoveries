import NineSeparatedSubsetSums.EightPoint134_121PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint134_121PackedAnchor0Part0 :
    ∀ j : Fin 120, 2310504 ≤ FourPointNumeric.octPackedCharge 134 121 20 packedOct134_121_0
      (2*((j.val : Int)+0)+1) := by decide +kernel

end NineSeparatedSubsetSums
