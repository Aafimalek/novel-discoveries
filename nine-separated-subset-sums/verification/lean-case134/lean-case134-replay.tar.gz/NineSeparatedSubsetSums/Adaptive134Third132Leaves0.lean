import NineSeparatedSubsetSums.Adaptive134Third132State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive134Third132Proof19 : runCachedNode 511 127087 Adaptive134Third132Node19 = false := by
  decide +kernel

#print axioms adaptive134Third132Proof19

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive134Third132Proof8 : runCachedNode 511 127087 Adaptive134Third132Node8 = false := by
  decide +kernel

#print axioms adaptive134Third132Proof8

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive134Third132Proof4 : runCachedNode 511 127087 Adaptive134Third132Node4 = false := by
  decide +kernel

#print axioms adaptive134Third132Proof4

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive134Third132Proof2 : runCachedNode 511 127087 Adaptive134Third132Node2 = false := by
  decide +kernel

#print axioms adaptive134Third132Proof2

end NineSeparatedSubsetSums
