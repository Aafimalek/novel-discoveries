import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive134Third118Node0 : CachedSearchNode :=
  ⟨4, 117, computeCenteredMask [148,134,118], 400, 53784⟩

end NineSeparatedSubsetSums
