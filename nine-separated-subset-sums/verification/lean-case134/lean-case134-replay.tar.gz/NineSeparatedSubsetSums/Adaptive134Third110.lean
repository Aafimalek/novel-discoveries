import NineSeparatedSubsetSums.Adaptive134Third110Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint134Checked

namespace NineSeparatedSubsetSums


theorem adaptive134Third110 : NoDescendingTailAfterThird 134 110 :=
  noDescendingThirdTail_of_cached 134 110 110531 (fun t ht nd => max148_second134_fourPoint_moment_bound (110::t) (by simp [ht]) nd) adaptive134Third110Proof0

#print axioms adaptive134Third110

end NineSeparatedSubsetSums
