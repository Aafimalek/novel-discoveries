import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive134Third109Node0 : CachedSearchNode :=
  ⟨4, 108, computeCenteredMask [148,134,109], 391, 51741⟩

end NineSeparatedSubsetSums
