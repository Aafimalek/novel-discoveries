import NineSeparatedSubsetSums.Adaptive134Third126State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive134Third126Proof0 : runCachedNode 511 126052 Adaptive134Third126Node0 = false := by
  decide +kernel

#print axioms adaptive134Third126Proof0

end NineSeparatedSubsetSums
