import NineSeparatedSubsetSums.Adaptive134Third130State
import NineSeparatedSubsetSums.Adaptive134Third130Leaves2
import NineSeparatedSubsetSums.Adaptive134Third130Leaves1
import NineSeparatedSubsetSums.Adaptive134Third130Leaves0

namespace NineSeparatedSubsetSums

theorem adaptive134Third130Proof0 : runCachedNode 511 126608 Adaptive134Third130Node0 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 126608 Adaptive134Third130Node0 = [111, 112, 113, 114, 115, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive134Third130Proof1
  · exact adaptive134Third130Proof2
  · exact adaptive134Third130Proof3
  · exact adaptive134Third130Proof4
  · exact adaptive134Third130Proof5
  · exact adaptive134Third130Proof6
  · exact adaptive134Third130Proof7
  · exact adaptive134Third130Proof8
  · exact adaptive134Third130Proof9
  · exact adaptive134Third130Proof10
  · exact adaptive134Third130Proof11
  · exact adaptive134Third130Proof12
  · exact adaptive134Third130Proof13
  · exact adaptive134Third130Proof14
  · exact adaptive134Third130Proof15
  · exact adaptive134Third130Proof16
  · exact adaptive134Third130Proof17
  · exact adaptive134Third130Proof18

#print axioms adaptive134Third130Proof0

end NineSeparatedSubsetSums
