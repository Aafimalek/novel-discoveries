import NineSeparatedSubsetSums.Adaptive134Third132State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive134Third132Proof20 : runCachedNode 511 127087 Adaptive134Third132Node20 = false := by
  decide +kernel

#print axioms adaptive134Third132Proof20

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive134Third132Proof15 : runCachedNode 511 127087 Adaptive134Third132Node15 = false := by
  decide +kernel

#print axioms adaptive134Third132Proof15

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive134Third132Proof6 : runCachedNode 511 127087 Adaptive134Third132Node6 = false := by
  decide +kernel

#print axioms adaptive134Third132Proof6

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive134Third132Proof3 : runCachedNode 511 127087 Adaptive134Third132Node3 = false := by
  decide +kernel

#print axioms adaptive134Third132Proof3

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive134Third132Proof1 : runCachedNode 511 127087 Adaptive134Third132Node1 = false := by
  decide +kernel

#print axioms adaptive134Third132Proof1

end NineSeparatedSubsetSums
