import NineSeparatedSubsetSums.EightPoint134_119PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint134_119PackedAnchor1Part2 :
    ∀ j : Fin 2, 2294391 ≤ FourPointNumeric.octPackedCharge 134 119 20 packedOct134_119_1
      (2*((j.val : Int)+240)+0) := by decide +kernel

end NineSeparatedSubsetSums
