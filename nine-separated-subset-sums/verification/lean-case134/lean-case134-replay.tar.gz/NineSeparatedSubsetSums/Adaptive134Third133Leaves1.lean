import NineSeparatedSubsetSums.Adaptive134Third133State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive134Third133Proof20 : runCachedNode 511 127264 Adaptive134Third133Node20 = false := by
  decide +kernel

#print axioms adaptive134Third133Proof20

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive134Third133Proof17 : runCachedNode 511 127264 Adaptive134Third133Node17 = false := by
  decide +kernel

#print axioms adaptive134Third133Proof17

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive134Third133Proof13 : runCachedNode 511 127264 Adaptive134Third133Node13 = false := by
  decide +kernel

#print axioms adaptive134Third133Proof13

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive134Third133Proof4 : runCachedNode 511 127264 Adaptive134Third133Node4 = false := by
  decide +kernel

#print axioms adaptive134Third133Proof4

end NineSeparatedSubsetSums
