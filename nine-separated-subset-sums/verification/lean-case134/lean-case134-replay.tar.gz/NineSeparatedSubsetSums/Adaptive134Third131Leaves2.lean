import NineSeparatedSubsetSums.Adaptive134Third131State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive134Third131Proof14 : runCachedNode 511 126872 Adaptive134Third131Node14 = false := by
  decide +kernel

#print axioms adaptive134Third131Proof14

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive134Third131Proof13 : runCachedNode 511 126872 Adaptive134Third131Node13 = false := by
  decide +kernel

#print axioms adaptive134Third131Proof13

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive134Third131Proof11 : runCachedNode 511 126872 Adaptive134Third131Node11 = false := by
  decide +kernel

#print axioms adaptive134Third131Proof11

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive134Third131Proof12 : runCachedNode 511 126872 Adaptive134Third131Node12 = false := by
  decide +kernel

#print axioms adaptive134Third131Proof12

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive134Third131Proof10 : runCachedNode 511 126872 Adaptive134Third131Node10 = false := by
  decide +kernel

#print axioms adaptive134Third131Proof10

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive134Third131Proof8 : runCachedNode 511 126872 Adaptive134Third131Node8 = false := by
  decide +kernel

#print axioms adaptive134Third131Proof8

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive134Third131Proof7 : runCachedNode 511 126872 Adaptive134Third131Node7 = false := by
  decide +kernel

#print axioms adaptive134Third131Proof7

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive134Third131Proof5 : runCachedNode 511 126872 Adaptive134Third131Node5 = false := by
  decide +kernel

#print axioms adaptive134Third131Proof5

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive134Third131Proof4 : runCachedNode 511 126872 Adaptive134Third131Node4 = false := by
  decide +kernel

#print axioms adaptive134Third131Proof4

end NineSeparatedSubsetSums
