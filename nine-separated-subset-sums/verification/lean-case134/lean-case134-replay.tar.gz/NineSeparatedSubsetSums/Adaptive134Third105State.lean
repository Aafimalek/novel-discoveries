import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive134Third105Node0 : CachedSearchNode :=
  ⟨4, 104, computeCenteredMask [148,134,105], 387, 50885⟩

end NineSeparatedSubsetSums
