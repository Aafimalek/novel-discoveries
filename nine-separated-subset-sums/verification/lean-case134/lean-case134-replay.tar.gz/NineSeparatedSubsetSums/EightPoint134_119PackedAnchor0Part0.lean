import NineSeparatedSubsetSums.EightPoint134_119PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint134_119PackedAnchor0Part0 :
    ∀ j : Fin 120, 2294754 ≤ FourPointNumeric.octPackedCharge 134 119 20 packedOct134_119_0
      (2*((j.val : Int)+0)+1) := by decide +kernel

end NineSeparatedSubsetSums
