import NineSeparatedSubsetSums.EightPoint134_128PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint134_128PackedAnchor0Part0 :
    ∀ j : Fin 120, 2328011 ≤ FourPointNumeric.octPackedCharge 134 128 20 packedOct134_128_0
      (2*((j.val : Int)+0)+0) := by decide +kernel

end NineSeparatedSubsetSums
