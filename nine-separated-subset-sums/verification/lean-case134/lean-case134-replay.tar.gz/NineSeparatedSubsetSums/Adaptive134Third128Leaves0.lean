import NineSeparatedSubsetSums.Adaptive134Third128State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive134Third128Proof16 : runCachedNode 511 126356 Adaptive134Third128Node16 = false := by
  decide +kernel

#print axioms adaptive134Third128Proof16

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive134Third128Proof14 : runCachedNode 511 126356 Adaptive134Third128Node14 = false := by
  decide +kernel

#print axioms adaptive134Third128Proof14

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive134Third128Proof13 : runCachedNode 511 126356 Adaptive134Third128Node13 = false := by
  decide +kernel

#print axioms adaptive134Third128Proof13

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive134Third128Proof15 : runCachedNode 511 126356 Adaptive134Third128Node15 = false := by
  decide +kernel

#print axioms adaptive134Third128Proof15

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive134Third128Proof12 : runCachedNode 511 126356 Adaptive134Third128Node12 = false := by
  decide +kernel

#print axioms adaptive134Third128Proof12

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive134Third128Proof8 : runCachedNode 511 126356 Adaptive134Third128Node8 = false := by
  decide +kernel

#print axioms adaptive134Third128Proof8

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive134Third128Proof4 : runCachedNode 511 126356 Adaptive134Third128Node4 = false := by
  decide +kernel

#print axioms adaptive134Third128Proof4

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive134Third128Proof2 : runCachedNode 511 126356 Adaptive134Third128Node2 = false := by
  decide +kernel

#print axioms adaptive134Third128Proof2

end NineSeparatedSubsetSums
