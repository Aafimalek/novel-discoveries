import NineSeparatedSubsetSums.EightPoint134_129PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct134_129_0_budget :
    FourPointNumeric.packedBudget 20 packedOct134_129_0 443 = 85022398 := by decide +kernel

#print axioms packedOct134_129_0_budget

end NineSeparatedSubsetSums
