import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive134Third106Node0 : CachedSearchNode :=
  ⟨4, 105, computeCenteredMask [148,134,106], 388, 51096⟩

end NineSeparatedSubsetSums
