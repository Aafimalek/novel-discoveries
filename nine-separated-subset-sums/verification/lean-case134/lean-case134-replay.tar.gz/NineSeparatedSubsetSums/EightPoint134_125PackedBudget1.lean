import NineSeparatedSubsetSums.EightPoint134_125PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct134_125_1_budget :
    FourPointNumeric.packedBudget 20 packedOct134_125_1 496 = 84319200 := by decide +kernel

#print axioms packedOct134_125_1_budget

end NineSeparatedSubsetSums
