import NineSeparatedSubsetSums.Adaptive134Third107Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint134Checked

namespace NineSeparatedSubsetSums


theorem adaptive134Third107 : NoDescendingTailAfterThird 134 107 :=
  noDescendingThirdTail_of_cached 134 107 110531 (fun t ht nd => max148_second134_fourPoint_moment_bound (107::t) (by simp [ht]) nd) adaptive134Third107Proof0

#print axioms adaptive134Third107

end NineSeparatedSubsetSums
