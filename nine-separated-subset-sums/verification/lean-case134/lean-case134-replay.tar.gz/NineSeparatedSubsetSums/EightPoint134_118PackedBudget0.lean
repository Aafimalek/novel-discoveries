import NineSeparatedSubsetSums.EightPoint134_118PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct134_118_0_budget :
    FourPointNumeric.packedBudget 20 packedOct134_118_0 269 = 81333286 := by decide +kernel

#print axioms packedOct134_118_0_budget

end NineSeparatedSubsetSums
