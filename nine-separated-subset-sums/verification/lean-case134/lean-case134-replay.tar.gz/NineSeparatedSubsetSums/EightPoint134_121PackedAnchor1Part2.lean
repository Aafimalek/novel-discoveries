import NineSeparatedSubsetSums.EightPoint134_121PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint134_121PackedAnchor1Part2 :
    ∀ j : Fin 3, 2318546 ≤ FourPointNumeric.octPackedCharge 134 121 20 packedOct134_121_1
      (2*((j.val : Int)+240)+0) := by decide +kernel

end NineSeparatedSubsetSums
