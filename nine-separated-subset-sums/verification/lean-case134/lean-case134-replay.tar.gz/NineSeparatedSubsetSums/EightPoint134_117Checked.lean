import NineSeparatedSubsetSums.EightPointPackedGeometry
import NineSeparatedSubsetSums.EightPoint134_117PackedBudget0
import NineSeparatedSubsetSums.EightPoint134_117PackedAnchor0Part0
import NineSeparatedSubsetSums.EightPoint134_117PackedAnchor0Part1
import NineSeparatedSubsetSums.EightPoint134_117PackedBudget1
import NineSeparatedSubsetSums.EightPoint134_117PackedAnchor1Part0
import NineSeparatedSubsetSums.EightPoint134_117PackedAnchor1Part1

namespace NineSeparatedSubsetSums

private theorem packedOct134_117Anchor0 :
  ∀ j : Fin 476, ((j.val : Int)+134+117)%2=0 →
    2236649 ≤ FourPointNumeric.octPackedCharge 134 117 20 packedOct134_117_0 (j.val : Int) := by
  intro j hj
  let k := (j.val-1)/2
  have hk : k < 238 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+1 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint134_117PackedAnchor0Part0 z
    rwa [he,hrep] at ht
  let z : Fin 118 := ⟨k-120, by omega⟩
  have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
  have ht := eightPoint134_117PackedAnchor0Part1 z
  rwa [he,hrep] at ht

private theorem packedOct134_117Anchor1 :
  ∀ j : Fin 476, ((j.val : Int)+134+117)%2=1 →
    2238158 ≤ FourPointNumeric.octPackedCharge 134 117 20 packedOct134_117_1 (j.val : Int) := by
  intro j hj
  let k := (j.val-0)/2
  have hk : k < 238 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+0 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint134_117PackedAnchor1Part0 z
    rwa [he,hrep] at ht
  let z : Fin 118 := ⟨k-120, by omega⟩
  have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
  have ht := eightPoint134_117PackedAnchor1Part1 z
  rwa [he,hrep] at ht

def packedOctCertificate134_117_0 : EightPointCertificate 134 117 0 124061 :=
  eightPointCertificateOfPacked 134 117 0 124061 2236649 20 packedOct134_117_0 269 476
    (by decide +kernel) (by decide) packedOct134_117Anchor0
    (by rw [packedOct134_117_0_budget]; decide)

def packedOctCertificate134_117_1 : EightPointCertificate 134 117 1 124061 :=
  eightPointCertificateOfPacked 134 117 1 124061 2238158 20 packedOct134_117_1 270 476
    (by decide +kernel) (by decide) packedOct134_117Anchor1
    (by rw [packedOct134_117_1_budget]; decide)

theorem max148_second134_third117_eightPoint_moment_bound (tail : List ℕ) (len : tail.length=6)
    (distinct : (natSubsetSums (148::134::117::tail)).Nodup) :
    124061 ≤ ((148::134::117::tail).map (· ^ 2)).sum := by
  apply eightPointNatMomentLower 134 117 124061 tail len distinct
  intro p hp
  by_cases h : p=0
  · subst p
    exact packedOctCertificate134_117_0
  · have he : p=1 := hp.resolve_left h
    subst p
    exact packedOctCertificate134_117_1

#print axioms max148_second134_third117_eightPoint_moment_bound

end NineSeparatedSubsetSums
