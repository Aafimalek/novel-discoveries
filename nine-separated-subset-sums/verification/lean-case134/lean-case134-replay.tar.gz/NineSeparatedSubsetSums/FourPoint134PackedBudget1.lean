import NineSeparatedSubsetSums.FourPoint134PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedWeight134_1_budget :
    FourPointNumeric.packedBudget 20 packedWeight134_1 548 = 77251840 := by decide +kernel

#print axioms packedWeight134_1_budget

end NineSeparatedSubsetSums
