import NineSeparatedSubsetSums.EightPointPackedGeometry
import NineSeparatedSubsetSums.EightPoint134_125PackedBudget0
import NineSeparatedSubsetSums.EightPoint134_125PackedAnchor0Part0
import NineSeparatedSubsetSums.EightPoint134_125PackedAnchor0Part1
import NineSeparatedSubsetSums.EightPoint134_125PackedAnchor0Part2
import NineSeparatedSubsetSums.EightPoint134_125PackedBudget1
import NineSeparatedSubsetSums.EightPoint134_125PackedAnchor1Part0
import NineSeparatedSubsetSums.EightPoint134_125PackedAnchor1Part1
import NineSeparatedSubsetSums.EightPoint134_125PackedAnchor1Part2

namespace NineSeparatedSubsetSums

private theorem packedOct134_125Anchor0 :
  ∀ j : Fin 486, ((j.val : Int)+134+125)%2=0 →
    2325709 ≤ FourPointNumeric.octPackedCharge 134 125 20 packedOct134_125_0 (j.val : Int) := by
  intro j hj
  let k := (j.val-1)/2
  have hk : k < 243 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+1 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint134_125PackedAnchor0Part0 z
    rwa [he,hrep] at ht
  by_cases h1 : k < 240
  · let z : Fin 120 := ⟨k-120, by omega⟩
    have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
    have ht := eightPoint134_125PackedAnchor0Part1 z
    rwa [he,hrep] at ht
  let z : Fin 3 := ⟨k-240, by omega⟩
  have he : (z.val : Int)+240 = k := by dsimp [z] <;> omega
  have ht := eightPoint134_125PackedAnchor0Part2 z
  rwa [he,hrep] at ht

private theorem packedOct134_125Anchor1 :
  ∀ j : Fin 486, ((j.val : Int)+134+125)%2=1 →
    2323880 ≤ FourPointNumeric.octPackedCharge 134 125 20 packedOct134_125_1 (j.val : Int) := by
  intro j hj
  let k := (j.val-0)/2
  have hk : k < 243 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+0 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint134_125PackedAnchor1Part0 z
    rwa [he,hrep] at ht
  by_cases h1 : k < 240
  · let z : Fin 120 := ⟨k-120, by omega⟩
    have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
    have ht := eightPoint134_125PackedAnchor1Part1 z
    rwa [he,hrep] at ht
  let z : Fin 3 := ⟨k-240, by omega⟩
  have he : (z.val : Int)+240 = k := by dsimp [z] <;> omega
  have ht := eightPoint134_125PackedAnchor1Part2 z
  rwa [he,hrep] at ht

def packedOctCertificate134_125_0 : EightPointCertificate 134 125 0 125800 :=
  eightPointCertificateOfPacked 134 125 0 125800 2325709 20 packedOct134_125_0 497 486
    (by decide +kernel) (by decide) packedOct134_125Anchor0
    (by rw [packedOct134_125_0_budget]; decide)

def packedOctCertificate134_125_1 : EightPointCertificate 134 125 1 125800 :=
  eightPointCertificateOfPacked 134 125 1 125800 2323880 20 packedOct134_125_1 496 486
    (by decide +kernel) (by decide) packedOct134_125Anchor1
    (by rw [packedOct134_125_1_budget]; decide)

theorem max148_second134_third125_eightPoint_moment_bound (tail : List ℕ) (len : tail.length=6)
    (distinct : (natSubsetSums (148::134::125::tail)).Nodup) :
    125800 ≤ ((148::134::125::tail).map (· ^ 2)).sum := by
  apply eightPointNatMomentLower 134 125 125800 tail len distinct
  intro p hp
  by_cases h : p=0
  · subst p
    exact packedOctCertificate134_125_0
  · have he : p=1 := hp.resolve_left h
    subst p
    exact packedOctCertificate134_125_1

#print axioms max148_second134_third125_eightPoint_moment_bound

end NineSeparatedSubsetSums
