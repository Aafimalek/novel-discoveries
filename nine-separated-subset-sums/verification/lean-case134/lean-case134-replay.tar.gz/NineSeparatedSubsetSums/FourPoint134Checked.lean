import NineSeparatedSubsetSums.FourPointPackedGeometry
import NineSeparatedSubsetSums.FourPoint134PackedBudget0
import NineSeparatedSubsetSums.FourPoint134PackedAnchor0Part0
import NineSeparatedSubsetSums.FourPoint134PackedAnchor0Part1
import NineSeparatedSubsetSums.FourPoint134PackedBudget1
import NineSeparatedSubsetSums.FourPoint134PackedAnchor1Part0
import NineSeparatedSubsetSums.FourPoint134PackedAnchor1Part1

namespace NineSeparatedSubsetSums

private theorem packed134Anchor0 :
  ∀ j : Fin 471, ((j.val : Int)+134)%2=0 →
    1045664 ≤ FourPointNumeric.packedCharge 134 20 packedWeight134_0 (j.val : Int) := by
  intro j hj
  let k := (j.val-0)/2
  have hk : k < 236 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+0 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := fourPoint134PackedAnchor0Part0 z
    rwa [he,hrep] at ht
  let z : Fin 116 := ⟨k-120, by omega⟩
  have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
  have ht := fourPoint134PackedAnchor0Part1 z
  rwa [he,hrep] at ht

private theorem packed134Anchor1 :
  ∀ j : Fin 471, ((j.val : Int)+134)%2=1 →
    1045652 ≤ FourPointNumeric.packedCharge 134 20 packedWeight134_1 (j.val : Int) := by
  intro j hj
  let k := (j.val-1)/2
  have hk : k < 235 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+1 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := fourPoint134PackedAnchor1Part0 z
    rwa [he,hrep] at ht
  let z : Fin 115 := ⟨k-120, by omega⟩
  have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
  have ht := fourPoint134PackedAnchor1Part1 z
  rwa [he,hrep] at ht

def packedCertificate134_0 : FourPointCertificate 134 0 110531 :=
  fourPointCertificateOfPacked 134 0 110531 1045664 20 packedWeight134_0 399 471
    (by decide +kernel) (by decide) (by decide) packed134Anchor0
    (by rw [packedWeight134_0_budget]; decide)

def packedCertificate134_1 : FourPointCertificate 134 1 110531 :=
  fourPointCertificateOfPacked 134 1 110531 1045652 20 packedWeight134_1 548 471
    (by decide +kernel) (by decide) (by decide) packed134Anchor1
    (by rw [packedWeight134_1_budget]; decide)

theorem max148_second134_fourPoint_moment_bound (tail : List ℕ) (len : tail.length=7)
    (distinct : (natSubsetSums (148::134::tail)).Nodup) :
    110531 ≤ ((148::134::tail).map (· ^ 2)).sum := by
  apply fourPointNatMomentLower 134 110531 tail len distinct
  intro p hp
  by_cases h : p=0
  · subst p
    exact packedCertificate134_0
  · have he : p=1 := hp.resolve_left h
    subst p
    exact packedCertificate134_1

#print axioms max148_second134_fourPoint_moment_bound

end NineSeparatedSubsetSums
