import NineSeparatedSubsetSums.EightPoint134_130PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint134_130PackedAnchor0Part1 :
    ∀ j : Fin 120, 2366304 ≤ FourPointNumeric.octPackedCharge 134 130 20 packedOct134_130_0
      (2*((j.val : Int)+120)+0) := by decide +kernel

end NineSeparatedSubsetSums
