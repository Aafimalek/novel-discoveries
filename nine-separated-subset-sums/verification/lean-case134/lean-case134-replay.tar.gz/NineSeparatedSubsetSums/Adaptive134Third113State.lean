import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive134Third113Node0 : CachedSearchNode :=
  ⟨4, 112, computeCenteredMask [148,134,113], 395, 52629⟩

end NineSeparatedSubsetSums
