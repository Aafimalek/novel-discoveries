import NineSeparatedSubsetSums.Adaptive134Third132State
import NineSeparatedSubsetSums.Adaptive134Third132Leaves1
import NineSeparatedSubsetSums.Adaptive134Third132Leaves0
import NineSeparatedSubsetSums.Adaptive134Third132Leaves3
import NineSeparatedSubsetSums.Adaptive134Third132Leaves2

namespace NineSeparatedSubsetSums

theorem adaptive134Third132Proof0 : runCachedNode 511 127087 Adaptive134Third132Node0 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 127087 Adaptive134Third132Node0 = [111, 112, 113, 114, 115, 116, 117, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive134Third132Proof1
  · exact adaptive134Third132Proof2
  · exact adaptive134Third132Proof3
  · exact adaptive134Third132Proof4
  · exact adaptive134Third132Proof5
  · exact adaptive134Third132Proof6
  · exact adaptive134Third132Proof7
  · exact adaptive134Third132Proof8
  · exact adaptive134Third132Proof9
  · exact adaptive134Third132Proof10
  · exact adaptive134Third132Proof11
  · exact adaptive134Third132Proof12
  · exact adaptive134Third132Proof13
  · exact adaptive134Third132Proof14
  · exact adaptive134Third132Proof15
  · exact adaptive134Third132Proof16
  · exact adaptive134Third132Proof17
  · exact adaptive134Third132Proof18
  · exact adaptive134Third132Proof19
  · exact adaptive134Third132Proof20

#print axioms adaptive134Third132Proof0

end NineSeparatedSubsetSums
