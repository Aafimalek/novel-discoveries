import NineSeparatedSubsetSums.EightPoint134_120PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint134_120PackedAnchor1Part0 :
    ∀ j : Fin 120, 2274751 ≤ FourPointNumeric.octPackedCharge 134 120 20 packedOct134_120_1
      (2*((j.val : Int)+0)+1) := by decide +kernel

end NineSeparatedSubsetSums
