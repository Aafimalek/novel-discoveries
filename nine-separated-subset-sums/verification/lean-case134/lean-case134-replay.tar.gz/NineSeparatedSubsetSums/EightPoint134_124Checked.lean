import NineSeparatedSubsetSums.EightPointPackedGeometry
import NineSeparatedSubsetSums.EightPoint134_124PackedBudget0
import NineSeparatedSubsetSums.EightPoint134_124PackedAnchor0Part0
import NineSeparatedSubsetSums.EightPoint134_124PackedAnchor0Part1
import NineSeparatedSubsetSums.EightPoint134_124PackedAnchor0Part2
import NineSeparatedSubsetSums.EightPoint134_124PackedBudget1
import NineSeparatedSubsetSums.EightPoint134_124PackedAnchor1Part0
import NineSeparatedSubsetSums.EightPoint134_124PackedAnchor1Part1

namespace NineSeparatedSubsetSums

private theorem packedOct134_124Anchor0 :
  ∀ j : Fin 481, ((j.val : Int)+134+124)%2=0 →
    2286670 ≤ FourPointNumeric.octPackedCharge 134 124 20 packedOct134_124_0 (j.val : Int) := by
  intro j hj
  let k := (j.val-0)/2
  have hk : k < 241 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+0 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint134_124PackedAnchor0Part0 z
    rwa [he,hrep] at ht
  by_cases h1 : k < 240
  · let z : Fin 120 := ⟨k-120, by omega⟩
    have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
    have ht := eightPoint134_124PackedAnchor0Part1 z
    rwa [he,hrep] at ht
  let z : Fin 1 := ⟨k-240, by omega⟩
  have he : (z.val : Int)+240 = k := by dsimp [z] <;> omega
  have ht := eightPoint134_124PackedAnchor0Part2 z
  rwa [he,hrep] at ht

private theorem packedOct134_124Anchor1 :
  ∀ j : Fin 481, ((j.val : Int)+134+124)%2=1 →
    2284784 ≤ FourPointNumeric.octPackedCharge 134 124 20 packedOct134_124_1 (j.val : Int) := by
  intro j hj
  let k := (j.val-1)/2
  have hk : k < 240 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+1 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint134_124PackedAnchor1Part0 z
    rwa [he,hrep] at ht
  let z : Fin 120 := ⟨k-120, by omega⟩
  have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
  have ht := eightPoint134_124PackedAnchor1Part1 z
  rwa [he,hrep] at ht

def packedOctCertificate134_124_0 : EightPointCertificate 134 124 0 125437 :=
  eightPointCertificateOfPacked 134 124 0 125437 2286670 20 packedOct134_124_0 405 481
    (by decide +kernel) (by decide) packedOct134_124Anchor0
    (by rw [packedOct134_124_0_budget]; decide)

def packedOctCertificate134_124_1 : EightPointCertificate 134 124 1 125437 :=
  eightPointCertificateOfPacked 134 124 1 125437 2284784 20 packedOct134_124_1 408 481
    (by decide +kernel) (by decide) packedOct134_124Anchor1
    (by rw [packedOct134_124_1_budget]; decide)

theorem max148_second134_third124_eightPoint_moment_bound (tail : List ℕ) (len : tail.length=6)
    (distinct : (natSubsetSums (148::134::124::tail)).Nodup) :
    125437 ≤ ((148::134::124::tail).map (· ^ 2)).sum := by
  apply eightPointNatMomentLower 134 124 125437 tail len distinct
  intro p hp
  by_cases h : p=0
  · subst p
    exact packedOctCertificate134_124_0
  · have he : p=1 := hp.resolve_left h
    subst p
    exact packedOctCertificate134_124_1

#print axioms max148_second134_third124_eightPoint_moment_bound

end NineSeparatedSubsetSums
