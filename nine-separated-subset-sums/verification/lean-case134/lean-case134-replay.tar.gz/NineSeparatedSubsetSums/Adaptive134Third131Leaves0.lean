import NineSeparatedSubsetSums.Adaptive134Third131State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive134Third131Proof19 : runCachedNode 511 126872 Adaptive134Third131Node19 = false := by
  decide +kernel

#print axioms adaptive134Third131Proof19

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive134Third131Proof17 : runCachedNode 511 126872 Adaptive134Third131Node17 = false := by
  decide +kernel

#print axioms adaptive134Third131Proof17

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive134Third131Proof6 : runCachedNode 511 126872 Adaptive134Third131Node6 = false := by
  decide +kernel

#print axioms adaptive134Third131Proof6

end NineSeparatedSubsetSums
