import NineSeparatedSubsetSums.EightPoint134_126PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct134_126_1_budget :
    FourPointNumeric.packedBudget 20 packedOct134_126_1 350 = 84413782 := by decide +kernel

#print axioms packedOct134_126_1_budget

end NineSeparatedSubsetSums
