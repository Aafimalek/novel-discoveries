import NineSeparatedSubsetSums.Adaptive134Third124State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive134Third124Proof0 : runCachedNode 511 125437 Adaptive134Third124Node0 = false := by
  decide +kernel

#print axioms adaptive134Third124Proof0

end NineSeparatedSubsetSums
