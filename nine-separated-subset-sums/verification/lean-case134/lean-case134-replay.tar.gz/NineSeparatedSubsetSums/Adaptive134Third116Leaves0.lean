import NineSeparatedSubsetSums.Adaptive134Third116State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive134Third116Proof14 : runCachedNode 511 110531 Adaptive134Third116Node14 = false := by
  decide +kernel

#print axioms adaptive134Third116Proof14

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive134Third116Proof13 : runCachedNode 511 110531 Adaptive134Third116Node13 = false := by
  decide +kernel

#print axioms adaptive134Third116Proof13

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive134Third116Proof12 : runCachedNode 511 110531 Adaptive134Third116Node12 = false := by
  decide +kernel

#print axioms adaptive134Third116Proof12

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive134Third116Proof10 : runCachedNode 511 110531 Adaptive134Third116Node10 = false := by
  decide +kernel

#print axioms adaptive134Third116Proof10

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive134Third116Proof4 : runCachedNode 511 110531 Adaptive134Third116Node4 = false := by
  decide +kernel

#print axioms adaptive134Third116Proof4

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive134Third116Proof3 : runCachedNode 511 110531 Adaptive134Third116Node3 = false := by
  decide +kernel

#print axioms adaptive134Third116Proof3

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive134Third116Proof1 : runCachedNode 511 110531 Adaptive134Third116Node1 = false := by
  decide +kernel

#print axioms adaptive134Third116Proof1

end NineSeparatedSubsetSums
