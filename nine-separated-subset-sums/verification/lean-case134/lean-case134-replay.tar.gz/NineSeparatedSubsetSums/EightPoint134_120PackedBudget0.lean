import NineSeparatedSubsetSums.EightPoint134_120PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct134_120_0_budget :
    FourPointNumeric.packedBudget 20 packedOct134_120_0 267 = 81881498 := by decide +kernel

#print axioms packedOct134_120_0_budget

end NineSeparatedSubsetSums
