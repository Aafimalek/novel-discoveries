import NineSeparatedSubsetSums.Adaptive134Third114Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint134Checked

namespace NineSeparatedSubsetSums


theorem adaptive134Third114 : NoDescendingTailAfterThird 134 114 :=
  noDescendingThirdTail_of_cached 134 114 110531 (fun t ht nd => max148_second134_fourPoint_moment_bound (114::t) (by simp [ht]) nd) adaptive134Third114Proof0

#print axioms adaptive134Third114

end NineSeparatedSubsetSums
