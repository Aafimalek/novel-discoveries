import NineSeparatedSubsetSums.Adaptive134Third116State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive134Third116Proof11 : runCachedNode 511 110531 Adaptive134Third116Node11 = false := by
  decide +kernel

#print axioms adaptive134Third116Proof11

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive134Third116Proof9 : runCachedNode 511 110531 Adaptive134Third116Node9 = false := by
  decide +kernel

#print axioms adaptive134Third116Proof9

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive134Third116Proof8 : runCachedNode 511 110531 Adaptive134Third116Node8 = false := by
  decide +kernel

#print axioms adaptive134Third116Proof8

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive134Third116Proof7 : runCachedNode 511 110531 Adaptive134Third116Node7 = false := by
  decide +kernel

#print axioms adaptive134Third116Proof7

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive134Third116Proof6 : runCachedNode 511 110531 Adaptive134Third116Node6 = false := by
  decide +kernel

#print axioms adaptive134Third116Proof6

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive134Third116Proof5 : runCachedNode 511 110531 Adaptive134Third116Node5 = false := by
  decide +kernel

#print axioms adaptive134Third116Proof5

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive134Third116Proof2 : runCachedNode 511 110531 Adaptive134Third116Node2 = false := by
  decide +kernel

#print axioms adaptive134Third116Proof2

end NineSeparatedSubsetSums
