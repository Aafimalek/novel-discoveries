import NineSeparatedSubsetSums.EightPoint134_118PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint134_118PackedAnchor0Part1 :
    ∀ j : Fin 120, 2264867 ≤ FourPointNumeric.octPackedCharge 134 118 20 packedOct134_118_0
      (2*((j.val : Int)+120)+0) := by decide +kernel

end NineSeparatedSubsetSums
