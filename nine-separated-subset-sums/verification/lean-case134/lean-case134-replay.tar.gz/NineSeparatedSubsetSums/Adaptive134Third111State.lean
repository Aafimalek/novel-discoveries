import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive134Third111Node0 : CachedSearchNode :=
  ⟨4, 110, computeCenteredMask [148,134,111], 393, 52181⟩

end NineSeparatedSubsetSums
