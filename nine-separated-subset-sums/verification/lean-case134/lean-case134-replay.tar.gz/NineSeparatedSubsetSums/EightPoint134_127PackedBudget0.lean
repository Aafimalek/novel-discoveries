import NineSeparatedSubsetSums.EightPoint134_127PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct134_127_0_budget :
    FourPointNumeric.packedBudget 20 packedOct134_127_0 275 = 84682523 := by decide +kernel

#print axioms packedOct134_127_0_budget

end NineSeparatedSubsetSums
