import NineSeparatedSubsetSums.Adaptive134Third112Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint134Checked

namespace NineSeparatedSubsetSums


theorem adaptive134Third112 : NoDescendingTailAfterThird 134 112 :=
  noDescendingThirdTail_of_cached 134 112 110531 (fun t ht nd => max148_second134_fourPoint_moment_bound (112::t) (by simp [ht]) nd) adaptive134Third112Proof0

#print axioms adaptive134Third112

end NineSeparatedSubsetSums
