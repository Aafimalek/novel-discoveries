import NineSeparatedSubsetSums.Adaptive134Third106Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint134Checked

namespace NineSeparatedSubsetSums


theorem adaptive134Third106 : NoDescendingTailAfterThird 134 106 :=
  noDescendingThirdTail_of_cached 134 106 110531 (fun t ht nd => max148_second134_fourPoint_moment_bound (106::t) (by simp [ht]) nd) adaptive134Third106Proof0

#print axioms adaptive134Third106

end NineSeparatedSubsetSums
