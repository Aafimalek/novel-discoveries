import NineSeparatedSubsetSums.EightPoint134_127PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct134_127_1_budget :
    FourPointNumeric.packedBudget 20 packedOct134_127_1 274 = 84701392 := by decide +kernel

#print axioms packedOct134_127_1_budget

end NineSeparatedSubsetSums
