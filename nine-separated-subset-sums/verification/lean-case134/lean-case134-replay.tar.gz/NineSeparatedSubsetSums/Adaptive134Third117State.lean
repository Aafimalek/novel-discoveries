import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive134Third117Node0 : CachedSearchNode :=
  ⟨4, 116, computeCenteredMask [148,134,117], 399, 53549⟩

end NineSeparatedSubsetSums
