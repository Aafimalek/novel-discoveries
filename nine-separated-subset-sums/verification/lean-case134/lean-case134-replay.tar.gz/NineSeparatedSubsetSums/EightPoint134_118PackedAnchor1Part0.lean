import NineSeparatedSubsetSums.EightPoint134_118PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint134_118PackedAnchor1Part0 :
    ∀ j : Fin 120, 2265076 ≤ FourPointNumeric.octPackedCharge 134 118 20 packedOct134_118_1
      (2*((j.val : Int)+0)+1) := by decide +kernel

end NineSeparatedSubsetSums
