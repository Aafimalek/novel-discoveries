import NineSeparatedSubsetSums.EightPoint134_130PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint134_130PackedAnchor1Part2 :
    ∀ j : Fin 4, 2363592 ≤ FourPointNumeric.octPackedCharge 134 130 20 packedOct134_130_1
      (2*((j.val : Int)+240)+1) := by decide +kernel

end NineSeparatedSubsetSums
