import NineSeparatedSubsetSums.Adaptive134Third129State
import NineSeparatedSubsetSums.Adaptive134Third129Leaves1
import NineSeparatedSubsetSums.Adaptive134Third129Leaves0

namespace NineSeparatedSubsetSums

theorem adaptive134Third129Proof0 : runCachedNode 511 126399 Adaptive134Third129Node0 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 126399 Adaptive134Third129Node0 = [111, 112, 113, 114, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive134Third129Proof1
  · exact adaptive134Third129Proof2
  · exact adaptive134Third129Proof3
  · exact adaptive134Third129Proof4
  · exact adaptive134Third129Proof5
  · exact adaptive134Third129Proof6
  · exact adaptive134Third129Proof7
  · exact adaptive134Third129Proof8
  · exact adaptive134Third129Proof9
  · exact adaptive134Third129Proof10
  · exact adaptive134Third129Proof11
  · exact adaptive134Third129Proof12
  · exact adaptive134Third129Proof13
  · exact adaptive134Third129Proof14
  · exact adaptive134Third129Proof15
  · exact adaptive134Third129Proof16
  · exact adaptive134Third129Proof17

#print axioms adaptive134Third129Proof0

end NineSeparatedSubsetSums
