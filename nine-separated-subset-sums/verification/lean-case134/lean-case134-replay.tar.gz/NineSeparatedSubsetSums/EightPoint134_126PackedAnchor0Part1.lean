import NineSeparatedSubsetSums.EightPoint134_126PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint134_126PackedAnchor0Part1 :
    ∀ j : Fin 120, 2327098 ≤ FourPointNumeric.octPackedCharge 134 126 20 packedOct134_126_0
      (2*((j.val : Int)+120)+0) := by decide +kernel

end NineSeparatedSubsetSums
