import NineSeparatedSubsetSums.Adaptive134Third121State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive134Third121Proof0 : runCachedNode 511 124548 Adaptive134Third121Node0 = false := by
  decide +kernel

#print axioms adaptive134Third121Proof0

end NineSeparatedSubsetSums
