import NineSeparatedSubsetSums.FourPoint134PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem fourPoint134PackedAnchor0Part1 :
    ∀ j : Fin 116, 1045664 ≤ FourPointNumeric.packedCharge 134 20 packedWeight134_0
      (2*((j.val : Int)+120)+0) := by decide +kernel

end NineSeparatedSubsetSums
