import NineSeparatedSubsetSums.Adaptive134Third131State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive134Third131Proof18 : runCachedNode 511 126872 Adaptive134Third131Node18 = false := by
  decide +kernel

#print axioms adaptive134Third131Proof18

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive134Third131Proof15 : runCachedNode 511 126872 Adaptive134Third131Node15 = false := by
  decide +kernel

#print axioms adaptive134Third131Proof15

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive134Third131Proof16 : runCachedNode 511 126872 Adaptive134Third131Node16 = false := by
  decide +kernel

#print axioms adaptive134Third131Proof16

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive134Third131Proof9 : runCachedNode 511 126872 Adaptive134Third131Node9 = false := by
  decide +kernel

#print axioms adaptive134Third131Proof9

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive134Third131Proof3 : runCachedNode 511 126872 Adaptive134Third131Node3 = false := by
  decide +kernel

#print axioms adaptive134Third131Proof3

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive134Third131Proof2 : runCachedNode 511 126872 Adaptive134Third131Node2 = false := by
  decide +kernel

#print axioms adaptive134Third131Proof2

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive134Third131Proof1 : runCachedNode 511 126872 Adaptive134Third131Node1 = false := by
  decide +kernel

#print axioms adaptive134Third131Proof1

end NineSeparatedSubsetSums
