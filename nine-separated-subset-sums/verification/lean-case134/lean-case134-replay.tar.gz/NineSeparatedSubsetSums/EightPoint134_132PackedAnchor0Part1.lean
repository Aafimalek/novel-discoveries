import NineSeparatedSubsetSums.EightPoint134_132PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint134_132PackedAnchor0Part1 :
    ∀ j : Fin 120, 2396242 ≤ FourPointNumeric.octPackedCharge 134 132 20 packedOct134_132_0
      (2*((j.val : Int)+120)+0) := by decide +kernel

end NineSeparatedSubsetSums
