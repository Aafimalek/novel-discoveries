import NineSeparatedSubsetSums.EightPoint134_132PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint134_132PackedAnchor1Part1 :
    ∀ j : Fin 120, 2396341 ≤ FourPointNumeric.octPackedCharge 134 132 20 packedOct134_132_1
      (2*((j.val : Int)+120)+1) := by decide +kernel

end NineSeparatedSubsetSums
