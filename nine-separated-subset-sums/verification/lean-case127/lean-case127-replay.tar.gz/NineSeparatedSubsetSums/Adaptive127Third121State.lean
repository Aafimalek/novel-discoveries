import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive127Third121Node0 : CachedSearchNode :=
  ⟨4, 120, computeCenteredMask [148,127,121], 396, 52674⟩

end NineSeparatedSubsetSums
