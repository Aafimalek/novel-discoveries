import NineSeparatedSubsetSums.EightPoint127_126PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct127_126_1_budget :
    FourPointNumeric.packedBudget 20 packedOct127_126_1 448 = 85587358 := by decide +kernel

#print axioms packedOct127_126_1_budget

end NineSeparatedSubsetSums
