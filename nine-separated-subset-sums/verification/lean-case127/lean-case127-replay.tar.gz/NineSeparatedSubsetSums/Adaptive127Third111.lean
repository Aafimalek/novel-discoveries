import NineSeparatedSubsetSums.Adaptive127Third111Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint127Checked

namespace NineSeparatedSubsetSums


theorem adaptive127Third111 : NoDescendingTailAfterThird 127 111 :=
  noDescendingThirdTail_of_cached 127 111 108841 (fun t ht nd => max148_second127_fourPoint_moment_bound (111::t) (by simp [ht]) nd) adaptive127Third111Proof0

#print axioms adaptive127Third111

end NineSeparatedSubsetSums
