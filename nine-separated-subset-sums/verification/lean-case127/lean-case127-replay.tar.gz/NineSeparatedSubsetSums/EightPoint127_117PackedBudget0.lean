import NineSeparatedSubsetSums.EightPoint127_117PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct127_117_0_budget :
    FourPointNumeric.packedBudget 20 packedOct127_117_0 413 = 80742574 := by decide +kernel

#print axioms packedOct127_117_0_budget

end NineSeparatedSubsetSums
