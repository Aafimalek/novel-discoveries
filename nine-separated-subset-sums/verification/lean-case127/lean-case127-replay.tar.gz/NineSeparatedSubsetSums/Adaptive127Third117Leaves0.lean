import NineSeparatedSubsetSums.Adaptive127Third117State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive127Third117Proof0 : runCachedNode 511 122530 Adaptive127Third117Node0 = false := by
  decide +kernel

#print axioms adaptive127Third117Proof0

end NineSeparatedSubsetSums
