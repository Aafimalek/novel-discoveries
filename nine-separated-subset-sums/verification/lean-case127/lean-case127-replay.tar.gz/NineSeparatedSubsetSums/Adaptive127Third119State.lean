import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive127Third119Node0 : CachedSearchNode :=
  ⟨4, 118, computeCenteredMask [148,127,119], 394, 52194⟩

end NineSeparatedSubsetSums
