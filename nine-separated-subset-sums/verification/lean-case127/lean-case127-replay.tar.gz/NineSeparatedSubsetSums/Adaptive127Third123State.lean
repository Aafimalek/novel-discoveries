import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive127Third123Node0 : CachedSearchNode :=
  ⟨4, 122, computeCenteredMask [148,127,123], 398, 53162⟩

end NineSeparatedSubsetSums
