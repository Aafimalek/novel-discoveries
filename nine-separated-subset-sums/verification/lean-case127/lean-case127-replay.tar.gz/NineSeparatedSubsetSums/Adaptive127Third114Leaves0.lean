import NineSeparatedSubsetSums.Adaptive127Third114State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive127Third114Proof13 : runCachedNode 511 108841 Adaptive127Third114Node13 = false := by
  decide +kernel

#print axioms adaptive127Third114Proof13

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive127Third114Proof12 : runCachedNode 511 108841 Adaptive127Third114Node12 = false := by
  decide +kernel

#print axioms adaptive127Third114Proof12

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive127Third114Proof11 : runCachedNode 511 108841 Adaptive127Third114Node11 = false := by
  decide +kernel

#print axioms adaptive127Third114Proof11

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive127Third114Proof10 : runCachedNode 511 108841 Adaptive127Third114Node10 = false := by
  decide +kernel

#print axioms adaptive127Third114Proof10

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive127Third114Proof9 : runCachedNode 511 108841 Adaptive127Third114Node9 = false := by
  decide +kernel

#print axioms adaptive127Third114Proof9

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive127Third114Proof8 : runCachedNode 511 108841 Adaptive127Third114Node8 = false := by
  decide +kernel

#print axioms adaptive127Third114Proof8

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive127Third114Proof4 : runCachedNode 511 108841 Adaptive127Third114Node4 = false := by
  decide +kernel

#print axioms adaptive127Third114Proof4

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive127Third114Proof1 : runCachedNode 511 108841 Adaptive127Third114Node1 = false := by
  decide +kernel

#print axioms adaptive127Third114Proof1

end NineSeparatedSubsetSums
