import NineSeparatedSubsetSums.EightPoint127_119PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct127_119_1_budget :
    FourPointNumeric.packedBudget 20 packedOct127_119_1 402 = 77577098 := by decide +kernel

#print axioms packedOct127_119_1_budget

end NineSeparatedSubsetSums
