import NineSeparatedSubsetSums.EightPoint127_117PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint127_117PackedAnchor1Part1 :
    ∀ j : Fin 119, 2241848 ≤ FourPointNumeric.octPackedCharge 127 117 20 packedOct127_117_1
      (2*((j.val : Int)+120)+1) := by decide +kernel

end NineSeparatedSubsetSums
