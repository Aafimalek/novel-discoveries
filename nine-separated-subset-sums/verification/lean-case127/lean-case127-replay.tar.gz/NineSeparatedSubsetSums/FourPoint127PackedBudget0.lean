import NineSeparatedSubsetSums.FourPoint127PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedWeight127_0_budget :
    FourPointNumeric.packedBudget 20 packedWeight127_0 373 = 75069504 := by decide +kernel

#print axioms packedWeight127_0_budget

end NineSeparatedSubsetSums
