import NineSeparatedSubsetSums.EightPoint127_126PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct127_126_0_budget :
    FourPointNumeric.packedBudget 20 packedOct127_126_0 389 = 85548633 := by decide +kernel

#print axioms packedOct127_126_0_budget

end NineSeparatedSubsetSums
