import NineSeparatedSubsetSums.EightPoint127_125PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint127_125PackedAnchor1Part2 :
    ∀ j : Fin 4, 2336535 ≤ FourPointNumeric.octPackedCharge 127 125 20 packedOct127_125_1
      (2*((j.val : Int)+240)+1) := by decide +kernel

end NineSeparatedSubsetSums
