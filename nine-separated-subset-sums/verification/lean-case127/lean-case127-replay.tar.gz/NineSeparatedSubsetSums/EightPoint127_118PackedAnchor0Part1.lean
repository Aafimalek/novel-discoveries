import NineSeparatedSubsetSums.EightPoint127_118PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint127_118PackedAnchor0Part1 :
    ∀ j : Fin 117, 2217678 ≤ FourPointNumeric.octPackedCharge 127 118 20 packedOct127_118_0
      (2*((j.val : Int)+120)+1) := by decide +kernel

end NineSeparatedSubsetSums
