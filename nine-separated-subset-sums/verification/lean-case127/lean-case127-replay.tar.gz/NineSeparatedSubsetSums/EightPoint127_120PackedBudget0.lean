import NineSeparatedSubsetSums.EightPoint127_120PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct127_120_0_budget :
    FourPointNumeric.packedBudget 20 packedOct127_120_0 265 = 80798445 := by decide +kernel

#print axioms packedOct127_120_0_budget

end NineSeparatedSubsetSums
