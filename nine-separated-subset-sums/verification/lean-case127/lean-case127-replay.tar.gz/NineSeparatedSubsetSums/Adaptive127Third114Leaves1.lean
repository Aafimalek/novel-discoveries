import NineSeparatedSubsetSums.Adaptive127Third114State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive127Third114Proof7 : runCachedNode 511 108841 Adaptive127Third114Node7 = false := by
  decide +kernel

#print axioms adaptive127Third114Proof7

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive127Third114Proof6 : runCachedNode 511 108841 Adaptive127Third114Node6 = false := by
  decide +kernel

#print axioms adaptive127Third114Proof6

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive127Third114Proof5 : runCachedNode 511 108841 Adaptive127Third114Node5 = false := by
  decide +kernel

#print axioms adaptive127Third114Proof5

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive127Third114Proof3 : runCachedNode 511 108841 Adaptive127Third114Node3 = false := by
  decide +kernel

#print axioms adaptive127Third114Proof3

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive127Third114Proof2 : runCachedNode 511 108841 Adaptive127Third114Node2 = false := by
  decide +kernel

#print axioms adaptive127Third114Proof2

end NineSeparatedSubsetSums
