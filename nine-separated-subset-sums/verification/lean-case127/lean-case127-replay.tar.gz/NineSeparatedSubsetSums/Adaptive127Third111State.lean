import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive127Third111Node0 : CachedSearchNode :=
  ⟨4, 110, computeCenteredMask [148,127,111], 386, 50354⟩

end NineSeparatedSubsetSums
