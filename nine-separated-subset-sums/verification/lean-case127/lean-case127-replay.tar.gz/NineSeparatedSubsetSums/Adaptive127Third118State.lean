import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive127Third118Node0 : CachedSearchNode :=
  ⟨4, 117, computeCenteredMask [148,127,118], 393, 51957⟩

end NineSeparatedSubsetSums
