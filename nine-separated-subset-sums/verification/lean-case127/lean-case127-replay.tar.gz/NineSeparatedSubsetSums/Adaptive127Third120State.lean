import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive127Third120Node0 : CachedSearchNode :=
  ⟨4, 119, computeCenteredMask [148,127,120], 395, 52433⟩

end NineSeparatedSubsetSums
