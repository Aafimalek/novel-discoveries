import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive127Third125Node0 : CachedSearchNode :=
  ⟨4, 124, computeCenteredMask [148,127,125], 400, 53658⟩

end NineSeparatedSubsetSums
