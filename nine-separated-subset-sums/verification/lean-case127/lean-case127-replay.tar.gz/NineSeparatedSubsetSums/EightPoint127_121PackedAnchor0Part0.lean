import NineSeparatedSubsetSums.EightPoint127_121PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint127_121PackedAnchor0Part0 :
    ∀ j : Fin 120, 2401773 ≤ FourPointNumeric.octPackedCharge 127 121 20 packedOct127_121_0
      (2*((j.val : Int)+0)+0) := by decide +kernel

end NineSeparatedSubsetSums
