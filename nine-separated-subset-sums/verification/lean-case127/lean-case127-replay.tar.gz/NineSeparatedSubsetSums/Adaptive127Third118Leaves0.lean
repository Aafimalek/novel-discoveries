import NineSeparatedSubsetSums.Adaptive127Third118State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive127Third118Proof0 : runCachedNode 511 122765 Adaptive127Third118Node0 = false := by
  decide +kernel

#print axioms adaptive127Third118Proof0

end NineSeparatedSubsetSums
