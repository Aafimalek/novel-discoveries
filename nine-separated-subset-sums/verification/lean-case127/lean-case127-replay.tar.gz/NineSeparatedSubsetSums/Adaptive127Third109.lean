import NineSeparatedSubsetSums.Adaptive127Third109Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint127Checked

namespace NineSeparatedSubsetSums


theorem adaptive127Third109 : NoDescendingTailAfterThird 127 109 :=
  noDescendingThirdTail_of_cached 127 109 108841 (fun t ht nd => max148_second127_fourPoint_moment_bound (109::t) (by simp [ht]) nd) adaptive127Third109Proof0

#print axioms adaptive127Third109

end NineSeparatedSubsetSums
