import NineSeparatedSubsetSums.Adaptive127Third115State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive127Third115Proof14 : runCachedNode 511 108841 Adaptive127Third115Node14 = false := by
  decide +kernel

#print axioms adaptive127Third115Proof14

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive127Third115Proof13 : runCachedNode 511 108841 Adaptive127Third115Node13 = false := by
  decide +kernel

#print axioms adaptive127Third115Proof13

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive127Third115Proof12 : runCachedNode 511 108841 Adaptive127Third115Node12 = false := by
  decide +kernel

#print axioms adaptive127Third115Proof12

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive127Third115Proof11 : runCachedNode 511 108841 Adaptive127Third115Node11 = false := by
  decide +kernel

#print axioms adaptive127Third115Proof11

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive127Third115Proof7 : runCachedNode 511 108841 Adaptive127Third115Node7 = false := by
  decide +kernel

#print axioms adaptive127Third115Proof7

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive127Third115Proof1 : runCachedNode 511 108841 Adaptive127Third115Node1 = false := by
  decide +kernel

#print axioms adaptive127Third115Proof1

end NineSeparatedSubsetSums
