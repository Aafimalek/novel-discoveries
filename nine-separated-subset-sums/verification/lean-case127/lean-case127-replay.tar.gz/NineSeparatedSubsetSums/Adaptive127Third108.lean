import NineSeparatedSubsetSums.Adaptive127Third108Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint127Checked

namespace NineSeparatedSubsetSums


theorem adaptive127Third108 : NoDescendingTailAfterThird 127 108 :=
  noDescendingThirdTail_of_cached 127 108 108841 (fun t ht nd => max148_second127_fourPoint_moment_bound (108::t) (by simp [ht]) nd) adaptive127Third108Proof0

#print axioms adaptive127Third108

end NineSeparatedSubsetSums
