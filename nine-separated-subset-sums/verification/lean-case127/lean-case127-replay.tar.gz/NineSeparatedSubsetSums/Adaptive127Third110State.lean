import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive127Third110Node0 : CachedSearchNode :=
  ⟨4, 109, computeCenteredMask [148,127,110], 385, 50133⟩

end NineSeparatedSubsetSums
