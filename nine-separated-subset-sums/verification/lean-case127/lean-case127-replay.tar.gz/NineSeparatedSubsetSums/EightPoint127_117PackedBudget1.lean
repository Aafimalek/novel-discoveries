import NineSeparatedSubsetSums.EightPoint127_117PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct127_117_1_budget :
    FourPointNumeric.packedBudget 20 packedOct127_117_1 488 = 80742560 := by decide +kernel

#print axioms packedOct127_117_1_budget

end NineSeparatedSubsetSums
