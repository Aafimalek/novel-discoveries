import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive127Third122Node0 : CachedSearchNode :=
  ⟨4, 121, computeCenteredMask [148,127,122], 397, 52917⟩

end NineSeparatedSubsetSums
