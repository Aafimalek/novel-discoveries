import NineSeparatedSubsetSums.Adaptive127Third122State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive127Third122Proof0 : runCachedNode 511 123648 Adaptive127Third122Node0 = false := by
  decide +kernel

#print axioms adaptive127Third122Proof0

end NineSeparatedSubsetSums
