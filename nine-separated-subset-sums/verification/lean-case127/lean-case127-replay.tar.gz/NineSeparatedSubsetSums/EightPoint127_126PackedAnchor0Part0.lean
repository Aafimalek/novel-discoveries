import NineSeparatedSubsetSums.EightPoint127_126PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint127_126PackedAnchor0Part0 :
    ∀ j : Fin 120, 2333043 ≤ FourPointNumeric.octPackedCharge 127 126 20 packedOct127_126_0
      (2*((j.val : Int)+0)+1) := by decide +kernel

end NineSeparatedSubsetSums
