import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive127Third109Node0 : CachedSearchNode :=
  ⟨4, 108, computeCenteredMask [148,127,109], 384, 49914⟩

end NineSeparatedSubsetSums
