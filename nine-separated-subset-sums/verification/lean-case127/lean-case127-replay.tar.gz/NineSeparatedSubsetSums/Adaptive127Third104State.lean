import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive127Third104Node0 : CachedSearchNode :=
  ⟨4, 103, computeCenteredMask [148,127,104], 379, 48849⟩

end NineSeparatedSubsetSums
