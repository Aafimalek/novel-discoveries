import NineSeparatedSubsetSums.EightPointPackedGeometry
import NineSeparatedSubsetSums.EightPoint127_118PackedBudget0
import NineSeparatedSubsetSums.EightPoint127_118PackedAnchor0Part0
import NineSeparatedSubsetSums.EightPoint127_118PackedAnchor0Part1
import NineSeparatedSubsetSums.EightPoint127_118PackedBudget1
import NineSeparatedSubsetSums.EightPoint127_118PackedAnchor1Part0
import NineSeparatedSubsetSums.EightPoint127_118PackedAnchor1Part1

namespace NineSeparatedSubsetSums

private theorem packedOct127_118Anchor0 :
  ∀ j : Fin 475, ((j.val : Int)+127+118)%2=0 →
    2217678 ≤ FourPointNumeric.octPackedCharge 127 118 20 packedOct127_118_0 (j.val : Int) := by
  intro j hj
  let k := (j.val-1)/2
  have hk : k < 237 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+1 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint127_118PackedAnchor0Part0 z
    rwa [he,hrep] at ht
  let z : Fin 117 := ⟨k-120, by omega⟩
  have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
  have ht := eightPoint127_118PackedAnchor0Part1 z
  rwa [he,hrep] at ht

private theorem packedOct127_118Anchor1 :
  ∀ j : Fin 475, ((j.val : Int)+127+118)%2=1 →
    2217167 ≤ FourPointNumeric.octPackedCharge 127 118 20 packedOct127_118_1 (j.val : Int) := by
  intro j hj
  let k := (j.val-0)/2
  have hk : k < 238 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+0 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint127_118PackedAnchor1Part0 z
    rwa [he,hrep] at ht
  let z : Fin 118 := ⟨k-120, by omega⟩
  have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
  have ht := eightPoint127_118PackedAnchor1Part1 z
  rwa [he,hrep] at ht

def packedOctCertificate127_118_0 : EightPointCertificate 127 118 0 122765 :=
  eightPointCertificateOfPacked 127 118 0 122765 2217678 20 packedOct127_118_0 425 475
    (by decide +kernel) (by decide) packedOct127_118Anchor0
    (by rw [packedOct127_118_0_budget]; decide)

def packedOctCertificate127_118_1 : EightPointCertificate 127 118 1 122765 :=
  eightPointCertificateOfPacked 127 118 1 122765 2217167 20 packedOct127_118_1 426 475
    (by decide +kernel) (by decide) packedOct127_118Anchor1
    (by rw [packedOct127_118_1_budget]; decide)

theorem max148_second127_third118_eightPoint_moment_bound (tail : List ℕ) (len : tail.length=6)
    (distinct : (natSubsetSums (148::127::118::tail)).Nodup) :
    122765 ≤ ((148::127::118::tail).map (· ^ 2)).sum := by
  apply eightPointNatMomentLower 127 118 122765 tail len distinct
  intro p hp
  by_cases h : p=0
  · subst p
    exact packedOctCertificate127_118_0
  · have he : p=1 := hp.resolve_left h
    subst p
    exact packedOctCertificate127_118_1

#print axioms max148_second127_third118_eightPoint_moment_bound

end NineSeparatedSubsetSums
