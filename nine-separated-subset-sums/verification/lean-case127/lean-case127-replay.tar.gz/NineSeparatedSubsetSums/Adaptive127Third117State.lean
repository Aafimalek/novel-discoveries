import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive127Third117Node0 : CachedSearchNode :=
  ⟨4, 116, computeCenteredMask [148,127,117], 392, 51722⟩

end NineSeparatedSubsetSums
