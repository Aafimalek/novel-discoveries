import NineSeparatedSubsetSums.Adaptive127Third125State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive127Third125Proof0 : runCachedNode 511 124345 Adaptive127Third125Node0 = false := by
  decide +kernel

#print axioms adaptive127Third125Proof0

end NineSeparatedSubsetSums
