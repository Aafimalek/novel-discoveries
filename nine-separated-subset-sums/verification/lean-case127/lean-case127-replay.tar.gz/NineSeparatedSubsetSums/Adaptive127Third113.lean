import NineSeparatedSubsetSums.Adaptive127Third113Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint127Checked

namespace NineSeparatedSubsetSums


theorem adaptive127Third113 : NoDescendingTailAfterThird 127 113 :=
  noDescendingThirdTail_of_cached 127 113 108841 (fun t ht nd => max148_second127_fourPoint_moment_bound (113::t) (by simp [ht]) nd) adaptive127Third113Proof0

#print axioms adaptive127Third113

end NineSeparatedSubsetSums
