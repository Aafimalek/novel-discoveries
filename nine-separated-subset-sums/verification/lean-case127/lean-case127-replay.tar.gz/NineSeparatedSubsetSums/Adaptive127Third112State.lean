import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive127Third112Node0 : CachedSearchNode :=
  ⟨4, 111, computeCenteredMask [148,127,112], 387, 50577⟩

end NineSeparatedSubsetSums
