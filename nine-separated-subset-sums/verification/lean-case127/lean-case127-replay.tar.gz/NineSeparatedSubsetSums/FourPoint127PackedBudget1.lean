import NineSeparatedSubsetSums.FourPoint127PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedWeight127_1_budget :
    FourPointNumeric.packedBudget 19 packedWeight127_1 368 = 75049024 := by decide +kernel

#print axioms packedWeight127_1_budget

end NineSeparatedSubsetSums
