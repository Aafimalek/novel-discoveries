import NineSeparatedSubsetSums.Adaptive127Third126State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive127Third126Proof0 : runCachedNode 511 124544 Adaptive127Third126Node0 = false := by
  decide +kernel

#print axioms adaptive127Third126Proof0

end NineSeparatedSubsetSums
