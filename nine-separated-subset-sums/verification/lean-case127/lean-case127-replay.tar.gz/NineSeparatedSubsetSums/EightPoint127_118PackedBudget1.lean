import NineSeparatedSubsetSums.EightPoint127_118PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct127_118_1_budget :
    FourPointNumeric.packedBudget 20 packedOct127_118_1 426 = 79043180 := by decide +kernel

#print axioms packedOct127_118_1_budget

end NineSeparatedSubsetSums
