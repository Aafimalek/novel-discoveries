import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive127Third108Node0 : CachedSearchNode :=
  ⟨4, 107, computeCenteredMask [148,127,108], 383, 49697⟩

end NineSeparatedSubsetSums
