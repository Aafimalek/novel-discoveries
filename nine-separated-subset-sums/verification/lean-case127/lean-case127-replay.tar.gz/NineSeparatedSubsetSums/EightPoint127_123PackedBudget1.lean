import NineSeparatedSubsetSums.EightPoint127_123PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct127_123_1_budget :
    FourPointNumeric.packedBudget 20 packedOct127_123_1 494 = 88183632 := by decide +kernel

#print axioms packedOct127_123_1_budget

end NineSeparatedSubsetSums
