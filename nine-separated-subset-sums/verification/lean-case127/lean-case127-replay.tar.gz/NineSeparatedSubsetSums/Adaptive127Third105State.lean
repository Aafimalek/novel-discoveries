import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive127Third105Node0 : CachedSearchNode :=
  ⟨4, 104, computeCenteredMask [148,127,105], 380, 49058⟩

end NineSeparatedSubsetSums
