import NineSeparatedSubsetSums.Adaptive127Third105Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint127Checked

namespace NineSeparatedSubsetSums


theorem adaptive127Third105 : NoDescendingTailAfterThird 127 105 :=
  noDescendingThirdTail_of_cached 127 105 108841 (fun t ht nd => max148_second127_fourPoint_moment_bound (105::t) (by simp [ht]) nd) adaptive127Third105Proof0

#print axioms adaptive127Third105

end NineSeparatedSubsetSums
