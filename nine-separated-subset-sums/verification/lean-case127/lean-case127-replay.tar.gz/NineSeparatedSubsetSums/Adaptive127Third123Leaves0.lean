import NineSeparatedSubsetSums.Adaptive127Third123State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive127Third123Proof0 : runCachedNode 511 123902 Adaptive127Third123Node0 = false := by
  decide +kernel

#print axioms adaptive127Third123Proof0

end NineSeparatedSubsetSums
