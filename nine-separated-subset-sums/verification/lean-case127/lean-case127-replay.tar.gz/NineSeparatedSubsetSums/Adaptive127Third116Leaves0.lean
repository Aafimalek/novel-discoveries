import NineSeparatedSubsetSums.Adaptive127Third116State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive127Third116Proof15 : runCachedNode 511 108841 Adaptive127Third116Node15 = false := by
  decide +kernel

#print axioms adaptive127Third116Proof15

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive127Third116Proof14 : runCachedNode 511 108841 Adaptive127Third116Node14 = false := by
  decide +kernel

#print axioms adaptive127Third116Proof14

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive127Third116Proof13 : runCachedNode 511 108841 Adaptive127Third116Node13 = false := by
  decide +kernel

#print axioms adaptive127Third116Proof13

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive127Third116Proof6 : runCachedNode 511 108841 Adaptive127Third116Node6 = false := by
  decide +kernel

#print axioms adaptive127Third116Proof6

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive127Third116Proof1 : runCachedNode 511 108841 Adaptive127Third116Node1 = false := by
  decide +kernel

#print axioms adaptive127Third116Proof1

end NineSeparatedSubsetSums
