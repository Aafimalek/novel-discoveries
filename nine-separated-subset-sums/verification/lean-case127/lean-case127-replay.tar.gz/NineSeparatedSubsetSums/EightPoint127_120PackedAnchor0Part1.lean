import NineSeparatedSubsetSums.EightPoint127_120PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint127_120PackedAnchor0Part1 :
    ∀ j : Fin 119, 2246751 ≤ FourPointNumeric.octPackedCharge 127 120 20 packedOct127_120_0
      (2*((j.val : Int)+120)+1) := by decide +kernel

end NineSeparatedSubsetSums
