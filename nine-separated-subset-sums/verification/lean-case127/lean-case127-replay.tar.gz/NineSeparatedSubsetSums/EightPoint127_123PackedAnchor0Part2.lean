import NineSeparatedSubsetSums.EightPoint127_123PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint127_123PackedAnchor0Part2 :
    ∀ j : Fin 7, 2369120 ≤ FourPointNumeric.octPackedCharge 127 123 20 packedOct127_123_0
      (2*((j.val : Int)+240)+0) := by decide +kernel

end NineSeparatedSubsetSums
