import NineSeparatedSubsetSums.Adaptive127Third124State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive127Third124Proof0 : runCachedNode 511 124130 Adaptive127Third124Node0 = false := by
  decide +kernel

#print axioms adaptive127Third124Proof0

end NineSeparatedSubsetSums
