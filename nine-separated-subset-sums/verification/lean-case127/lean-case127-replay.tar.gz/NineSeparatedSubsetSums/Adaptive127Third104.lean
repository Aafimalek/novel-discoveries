import NineSeparatedSubsetSums.Adaptive127Third104Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint127Checked

namespace NineSeparatedSubsetSums


theorem adaptive127Third104 : NoDescendingTailAfterThird 127 104 :=
  noDescendingThirdTail_of_cached 127 104 108841 (fun t ht nd => max148_second127_fourPoint_moment_bound (104::t) (by simp [ht]) nd) adaptive127Third104Proof0

#print axioms adaptive127Third104

end NineSeparatedSubsetSums
