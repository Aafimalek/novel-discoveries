import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive127Third124Node0 : CachedSearchNode :=
  ⟨4, 123, computeCenteredMask [148,127,124], 399, 53409⟩

end NineSeparatedSubsetSums
