import NineSeparatedSubsetSums.Adaptive127Third121State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive127Third121Proof0 : runCachedNode 511 123359 Adaptive127Third121Node0 = false := by
  decide +kernel

#print axioms adaptive127Third121Proof0

end NineSeparatedSubsetSums
