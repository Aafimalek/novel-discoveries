import NineSeparatedSubsetSums.EightPoint127_124PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint127_124PackedAnchor1Part2 :
    ∀ j : Fin 6, 2356202 ≤ FourPointNumeric.octPackedCharge 127 124 20 packedOct127_124_1
      (2*((j.val : Int)+240)+0) := by decide +kernel

end NineSeparatedSubsetSums
