import NineSeparatedSubsetSums.EightPoint127_122PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint127_122PackedAnchor0Part2 :
    ∀ j : Fin 8, 2389794 ≤ FourPointNumeric.octPackedCharge 127 122 20 packedOct127_122_0
      (2*((j.val : Int)+240)+1) := by decide +kernel

end NineSeparatedSubsetSums
