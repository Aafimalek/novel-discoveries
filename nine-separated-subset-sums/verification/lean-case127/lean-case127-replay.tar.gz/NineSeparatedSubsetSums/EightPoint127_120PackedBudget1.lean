import NineSeparatedSubsetSums.EightPoint127_120PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct127_120_1_budget :
    FourPointNumeric.packedBudget 20 packedOct127_120_1 266 = 80686218 := by decide +kernel

#print axioms packedOct127_120_1_budget

end NineSeparatedSubsetSums
