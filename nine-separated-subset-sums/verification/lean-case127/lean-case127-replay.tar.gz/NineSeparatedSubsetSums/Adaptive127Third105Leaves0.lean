import NineSeparatedSubsetSums.Adaptive127Third105State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive127Third105Proof0 : runCachedNode 511 108841 Adaptive127Third105Node0 = false := by
  decide +kernel

#print axioms adaptive127Third105Proof0

end NineSeparatedSubsetSums
