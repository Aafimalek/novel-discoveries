import NineSeparatedSubsetSums.Adaptive127Third106Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint127Checked

namespace NineSeparatedSubsetSums


theorem adaptive127Third106 : NoDescendingTailAfterThird 127 106 :=
  noDescendingThirdTail_of_cached 127 106 108841 (fun t ht nd => max148_second127_fourPoint_moment_bound (106::t) (by simp [ht]) nd) adaptive127Third106Proof0

#print axioms adaptive127Third106

end NineSeparatedSubsetSums
