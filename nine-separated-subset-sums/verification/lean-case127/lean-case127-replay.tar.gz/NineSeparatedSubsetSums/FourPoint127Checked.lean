import NineSeparatedSubsetSums.FourPointPackedGeometry
import NineSeparatedSubsetSums.FourPoint127PackedBudget0
import NineSeparatedSubsetSums.FourPoint127PackedAnchor0Part0
import NineSeparatedSubsetSums.FourPoint127PackedAnchor0Part1
import NineSeparatedSubsetSums.FourPoint127PackedBudget1
import NineSeparatedSubsetSums.FourPoint127PackedAnchor1Part0
import NineSeparatedSubsetSums.FourPoint127PackedAnchor1Part1

namespace NineSeparatedSubsetSums

private theorem packed127Anchor0 :
  ∀ j : Fin 467, ((j.val : Int)+127)%2=0 →
    1021848 ≤ FourPointNumeric.packedCharge 127 20 packedWeight127_0 (j.val : Int) := by
  intro j hj
  let k := (j.val-1)/2
  have hk : k < 233 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+1 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := fourPoint127PackedAnchor0Part0 z
    rwa [he,hrep] at ht
  let z : Fin 113 := ⟨k-120, by omega⟩
  have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
  have ht := fourPoint127PackedAnchor0Part1 z
  rwa [he,hrep] at ht

private theorem packed127Anchor1 :
  ∀ j : Fin 467, ((j.val : Int)+127)%2=1 →
    1021684 ≤ FourPointNumeric.packedCharge 127 19 packedWeight127_1 (j.val : Int) := by
  intro j hj
  let k := (j.val-0)/2
  have hk : k < 234 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+0 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := fourPoint127PackedAnchor1Part0 z
    rwa [he,hrep] at ht
  let z : Fin 114 := ⟨k-120, by omega⟩
  have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
  have ht := fourPoint127PackedAnchor1Part1 z
  rwa [he,hrep] at ht

def packedCertificate127_0 : FourPointCertificate 127 0 108841 :=
  fourPointCertificateOfPacked 127 0 108841 1021848 20 packedWeight127_0 373 467
    (by decide +kernel) (by decide) (by decide) packed127Anchor0
    (by rw [packedWeight127_0_budget]; decide)

def packedCertificate127_1 : FourPointCertificate 127 1 108841 :=
  fourPointCertificateOfPacked 127 1 108841 1021684 19 packedWeight127_1 368 467
    (by decide +kernel) (by decide) (by decide) packed127Anchor1
    (by rw [packedWeight127_1_budget]; decide)

theorem max148_second127_fourPoint_moment_bound (tail : List ℕ) (len : tail.length=7)
    (distinct : (natSubsetSums (148::127::tail)).Nodup) :
    108841 ≤ ((148::127::tail).map (· ^ 2)).sum := by
  apply fourPointNatMomentLower 127 108841 tail len distinct
  intro p hp
  by_cases h : p=0
  · subst p
    exact packedCertificate127_0
  · have he : p=1 := hp.resolve_left h
    subst p
    exact packedCertificate127_1

#print axioms max148_second127_fourPoint_moment_bound

end NineSeparatedSubsetSums
