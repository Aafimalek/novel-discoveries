import NineSeparatedSubsetSums.EightPoint127_118PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint127_118PackedAnchor1Part1 :
    ∀ j : Fin 118, 2217167 ≤ FourPointNumeric.octPackedCharge 127 118 20 packedOct127_118_1
      (2*((j.val : Int)+120)+0) := by decide +kernel

end NineSeparatedSubsetSums
