import NineSeparatedSubsetSums.Adaptive127Third120State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive127Third120Proof0 : runCachedNode 511 123035 Adaptive127Third120Node0 = false := by
  decide +kernel

#print axioms adaptive127Third120Proof0

end NineSeparatedSubsetSums
