import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive127Third113Node0 : CachedSearchNode :=
  ⟨4, 112, computeCenteredMask [148,127,113], 388, 50802⟩

end NineSeparatedSubsetSums
