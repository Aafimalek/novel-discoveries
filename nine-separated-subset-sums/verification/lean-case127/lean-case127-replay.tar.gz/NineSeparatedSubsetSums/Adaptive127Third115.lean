import NineSeparatedSubsetSums.Adaptive127Third115Joins0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint127Checked

namespace NineSeparatedSubsetSums


theorem adaptive127Third115 : NoDescendingTailAfterThird 127 115 :=
  noDescendingThirdTail_of_cached 127 115 108841 (fun t ht nd => max148_second127_fourPoint_moment_bound (115::t) (by simp [ht]) nd) adaptive127Third115Proof0

#print axioms adaptive127Third115

end NineSeparatedSubsetSums
