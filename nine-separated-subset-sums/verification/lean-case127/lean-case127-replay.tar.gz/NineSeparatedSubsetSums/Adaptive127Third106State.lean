import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive127Third106Node0 : CachedSearchNode :=
  ⟨4, 105, computeCenteredMask [148,127,106], 381, 49269⟩

end NineSeparatedSubsetSums
