import NineSeparatedSubsetSums.Adaptive127Third116Joins0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint127Checked

namespace NineSeparatedSubsetSums


theorem adaptive127Third116 : NoDescendingTailAfterThird 127 116 :=
  noDescendingThirdTail_of_cached 127 116 108841 (fun t ht nd => max148_second127_fourPoint_moment_bound (116::t) (by simp [ht]) nd) adaptive127Third116Proof0

#print axioms adaptive127Third116

end NineSeparatedSubsetSums
