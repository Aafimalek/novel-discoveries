import NineSeparatedSubsetSums.EightPoint127_121PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint127_121PackedAnchor1Part0 :
    ∀ j : Fin 120, 2402854 ≤ FourPointNumeric.octPackedCharge 127 121 20 packedOct127_121_1
      (2*((j.val : Int)+0)+1) := by decide +kernel

end NineSeparatedSubsetSums
