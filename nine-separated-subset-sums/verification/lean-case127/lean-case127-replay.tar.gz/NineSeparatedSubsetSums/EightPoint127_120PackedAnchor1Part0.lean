import NineSeparatedSubsetSums.EightPoint127_120PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint127_120PackedAnchor1Part0 :
    ∀ j : Fin 120, 2245002 ≤ FourPointNumeric.octPackedCharge 127 120 20 packedOct127_120_1
      (2*((j.val : Int)+0)+0) := by decide +kernel

end NineSeparatedSubsetSums
