import NineSeparatedSubsetSums.Adaptive127Third110Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint127Checked

namespace NineSeparatedSubsetSums


theorem adaptive127Third110 : NoDescendingTailAfterThird 127 110 :=
  noDescendingThirdTail_of_cached 127 110 108841 (fun t ht nd => max148_second127_fourPoint_moment_bound (110::t) (by simp [ht]) nd) adaptive127Third110Proof0

#print axioms adaptive127Third110

end NineSeparatedSubsetSums
