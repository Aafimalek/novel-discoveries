import NineSeparatedSubsetSums.EightPoint127_118PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct127_118_0_budget :
    FourPointNumeric.packedBudget 20 packedOct127_118_0 425 = 79075368 := by decide +kernel

#print axioms packedOct127_118_0_budget

end NineSeparatedSubsetSums
