import NineSeparatedSubsetSums.EightPoint127_117PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint127_117PackedAnchor0Part1 :
    ∀ j : Fin 120, 2241840 ≤ FourPointNumeric.octPackedCharge 127 117 20 packedOct127_117_0
      (2*((j.val : Int)+120)+0) := by decide +kernel

end NineSeparatedSubsetSums
