import NineSeparatedSubsetSums.Adaptive127Third107Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint127Checked

namespace NineSeparatedSubsetSums


theorem adaptive127Third107 : NoDescendingTailAfterThird 127 107 :=
  noDescendingThirdTail_of_cached 127 107 108841 (fun t ht nd => max148_second127_fourPoint_moment_bound (107::t) (by simp [ht]) nd) adaptive127Third107Proof0

#print axioms adaptive127Third107

end NineSeparatedSubsetSums
