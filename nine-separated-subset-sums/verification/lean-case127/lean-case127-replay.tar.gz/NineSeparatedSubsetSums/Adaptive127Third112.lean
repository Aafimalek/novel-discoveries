import NineSeparatedSubsetSums.Adaptive127Third112Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint127Checked

namespace NineSeparatedSubsetSums


theorem adaptive127Third112 : NoDescendingTailAfterThird 127 112 :=
  noDescendingThirdTail_of_cached 127 112 108841 (fun t ht nd => max148_second127_fourPoint_moment_bound (112::t) (by simp [ht]) nd) adaptive127Third112Proof0

#print axioms adaptive127Third112

end NineSeparatedSubsetSums
