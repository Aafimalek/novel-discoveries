import NineSeparatedSubsetSums.FourPoint127PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem fourPoint127PackedAnchor1Part1 :
    ∀ j : Fin 114, 1021684 ≤ FourPointNumeric.packedCharge 127 19 packedWeight127_1
      (2*((j.val : Int)+120)+0) := by decide +kernel

end NineSeparatedSubsetSums
