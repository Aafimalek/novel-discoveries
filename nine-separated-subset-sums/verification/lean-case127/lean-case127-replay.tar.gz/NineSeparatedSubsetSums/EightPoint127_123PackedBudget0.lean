import NineSeparatedSubsetSums.EightPoint127_123PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct127_123_0_budget :
    FourPointNumeric.packedBudget 20 packedOct127_123_0 491 = 88186340 := by decide +kernel

#print axioms packedOct127_123_0_budget

end NineSeparatedSubsetSums
