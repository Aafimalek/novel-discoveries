import NineSeparatedSubsetSums.EightPoint127_119PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint127_119PackedAnchor1Part0 :
    ∀ j : Fin 120, 2195156 ≤ FourPointNumeric.octPackedCharge 127 119 20 packedOct127_119_1
      (2*((j.val : Int)+0)+1) := by decide +kernel

end NineSeparatedSubsetSums
