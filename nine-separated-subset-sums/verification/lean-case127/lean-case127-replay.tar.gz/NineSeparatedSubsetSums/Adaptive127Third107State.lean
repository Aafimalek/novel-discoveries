import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive127Third107Node0 : CachedSearchNode :=
  ⟨4, 106, computeCenteredMask [148,127,107], 382, 49482⟩

end NineSeparatedSubsetSums
