import NineSeparatedSubsetSums.Adaptive127Third119State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive127Third119Proof0 : runCachedNode 511 122877 Adaptive127Third119Node0 = false := by
  decide +kernel

#print axioms adaptive127Third119Proof0

end NineSeparatedSubsetSums
