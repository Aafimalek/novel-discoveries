import NineSeparatedSubsetSums.EightPointPackedGeometry
import NineSeparatedSubsetSums.EightPoint127_120PackedBudget0
import NineSeparatedSubsetSums.EightPoint127_120PackedAnchor0Part0
import NineSeparatedSubsetSums.EightPoint127_120PackedAnchor0Part1
import NineSeparatedSubsetSums.EightPoint127_120PackedBudget1
import NineSeparatedSubsetSums.EightPoint127_120PackedAnchor1Part0
import NineSeparatedSubsetSums.EightPoint127_120PackedAnchor1Part1

namespace NineSeparatedSubsetSums

private theorem packedOct127_120Anchor0 :
  ∀ j : Fin 478, ((j.val : Int)+127+120)%2=0 →
    2246751 ≤ FourPointNumeric.octPackedCharge 127 120 20 packedOct127_120_0 (j.val : Int) := by
  intro j hj
  let k := (j.val-1)/2
  have hk : k < 239 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+1 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint127_120PackedAnchor0Part0 z
    rwa [he,hrep] at ht
  let z : Fin 119 := ⟨k-120, by omega⟩
  have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
  have ht := eightPoint127_120PackedAnchor0Part1 z
  rwa [he,hrep] at ht

private theorem packedOct127_120Anchor1 :
  ∀ j : Fin 478, ((j.val : Int)+127+120)%2=1 →
    2245002 ≤ FourPointNumeric.octPackedCharge 127 120 20 packedOct127_120_1 (j.val : Int) := by
  intro j hj
  let k := (j.val-0)/2
  have hk : k < 239 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+0 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint127_120PackedAnchor1Part0 z
    rwa [he,hrep] at ht
  let z : Fin 119 := ⟨k-120, by omega⟩
  have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
  have ht := eightPoint127_120PackedAnchor1Part1 z
  rwa [he,hrep] at ht

def packedOctCertificate127_120_0 : EightPointCertificate 127 120 0 123035 :=
  eightPointCertificateOfPacked 127 120 0 123035 2246751 20 packedOct127_120_0 265 478
    (by decide +kernel) (by decide) packedOct127_120Anchor0
    (by rw [packedOct127_120_0_budget]; decide)

def packedOctCertificate127_120_1 : EightPointCertificate 127 120 1 123035 :=
  eightPointCertificateOfPacked 127 120 1 123035 2245002 20 packedOct127_120_1 266 478
    (by decide +kernel) (by decide) packedOct127_120Anchor1
    (by rw [packedOct127_120_1_budget]; decide)

theorem max148_second127_third120_eightPoint_moment_bound (tail : List ℕ) (len : tail.length=6)
    (distinct : (natSubsetSums (148::127::120::tail)).Nodup) :
    123035 ≤ ((148::127::120::tail).map (· ^ 2)).sum := by
  apply eightPointNatMomentLower 127 120 123035 tail len distinct
  intro p hp
  by_cases h : p=0
  · subst p
    exact packedOctCertificate127_120_0
  · have he : p=1 := hp.resolve_left h
    subst p
    exact packedOctCertificate127_120_1

#print axioms max148_second127_third120_eightPoint_moment_bound

end NineSeparatedSubsetSums
