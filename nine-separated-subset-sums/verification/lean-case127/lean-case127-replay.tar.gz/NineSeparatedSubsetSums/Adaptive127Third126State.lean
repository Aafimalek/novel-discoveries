import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive127Third126Node0 : CachedSearchNode :=
  ⟨4, 125, computeCenteredMask [148,127,126], 401, 53909⟩

end NineSeparatedSubsetSums
