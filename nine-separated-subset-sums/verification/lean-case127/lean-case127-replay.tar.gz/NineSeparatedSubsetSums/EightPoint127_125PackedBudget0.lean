import NineSeparatedSubsetSums.EightPoint127_125PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct127_125_0_budget :
    FourPointNumeric.packedBudget 20 packedOct127_125_0 489 = 85869552 := by decide +kernel

#print axioms packedOct127_125_0_budget

end NineSeparatedSubsetSums
