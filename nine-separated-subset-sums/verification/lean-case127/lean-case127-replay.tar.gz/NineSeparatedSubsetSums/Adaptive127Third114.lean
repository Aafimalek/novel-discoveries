import NineSeparatedSubsetSums.Adaptive127Third114Joins0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint127Checked

namespace NineSeparatedSubsetSums


theorem adaptive127Third114 : NoDescendingTailAfterThird 127 114 :=
  noDescendingThirdTail_of_cached 127 114 108841 (fun t ht nd => max148_second127_fourPoint_moment_bound (114::t) (by simp [ht]) nd) adaptive127Third114Proof0

#print axioms adaptive127Third114

end NineSeparatedSubsetSums
