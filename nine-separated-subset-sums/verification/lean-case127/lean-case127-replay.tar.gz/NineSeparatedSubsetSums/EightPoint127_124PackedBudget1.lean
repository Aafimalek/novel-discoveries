import NineSeparatedSubsetSums.EightPoint127_124PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct127_124_1_budget :
    FourPointNumeric.packedBudget 20 packedOct127_124_1 490 = 87242472 := by decide +kernel

#print axioms packedOct127_124_1_budget

end NineSeparatedSubsetSums
