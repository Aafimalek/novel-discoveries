import NineSeparatedSubsetSums.FourPoint127PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem fourPoint127PackedAnchor0Part1 :
    ∀ j : Fin 113, 1021848 ≤ FourPointNumeric.packedCharge 127 20 packedWeight127_0
      (2*((j.val : Int)+120)+1) := by decide +kernel

end NineSeparatedSubsetSums
