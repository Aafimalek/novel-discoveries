import NineSeparatedSubsetSums.Adaptive127Third116State
import NineSeparatedSubsetSums.Adaptive127Third116Leaves0
import NineSeparatedSubsetSums.Adaptive127Third116Leaves1

namespace NineSeparatedSubsetSums

theorem adaptive127Third116Proof0 : runCachedNode 511 108841 Adaptive127Third116Node0 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 108841 Adaptive127Third116Node0 = [101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive127Third116Proof1
  · exact adaptive127Third116Proof2
  · exact adaptive127Third116Proof3
  · exact adaptive127Third116Proof4
  · exact adaptive127Third116Proof5
  · exact adaptive127Third116Proof6
  · exact adaptive127Third116Proof7
  · exact adaptive127Third116Proof8
  · exact adaptive127Third116Proof9
  · exact adaptive127Third116Proof10
  · exact adaptive127Third116Proof11
  · exact adaptive127Third116Proof12
  · exact adaptive127Third116Proof13
  · exact adaptive127Third116Proof14
  · exact adaptive127Third116Proof15

#print axioms adaptive127Third116Proof0

end NineSeparatedSubsetSums
