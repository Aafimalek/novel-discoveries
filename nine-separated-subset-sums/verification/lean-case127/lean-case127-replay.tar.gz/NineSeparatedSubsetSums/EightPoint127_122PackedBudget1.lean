import NineSeparatedSubsetSums.EightPoint127_122PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct127_122_1_budget :
    FourPointNumeric.packedBudget 20 packedOct127_122_1 494 = 89505176 := by decide +kernel

#print axioms packedOct127_122_1_budget

end NineSeparatedSubsetSums
