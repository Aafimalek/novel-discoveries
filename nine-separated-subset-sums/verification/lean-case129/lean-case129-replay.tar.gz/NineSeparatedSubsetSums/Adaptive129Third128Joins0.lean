import NineSeparatedSubsetSums.Adaptive129Third128State
import NineSeparatedSubsetSums.Adaptive129Third128Leaves1
import NineSeparatedSubsetSums.Adaptive129Third128Leaves0

namespace NineSeparatedSubsetSums

theorem adaptive129Third128Proof0 : runCachedNode 511 125293 Adaptive129Third128Node0 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 125293 Adaptive129Third128Node0 = [111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive129Third128Proof1
  · exact adaptive129Third128Proof2
  · exact adaptive129Third128Proof3
  · exact adaptive129Third128Proof4
  · exact adaptive129Third128Proof5
  · exact adaptive129Third128Proof6
  · exact adaptive129Third128Proof7
  · exact adaptive129Third128Proof8
  · exact adaptive129Third128Proof9
  · exact adaptive129Third128Proof10
  · exact adaptive129Third128Proof11
  · exact adaptive129Third128Proof12
  · exact adaptive129Third128Proof13
  · exact adaptive129Third128Proof14
  · exact adaptive129Third128Proof15
  · exact adaptive129Third128Proof16
  · exact adaptive129Third128Proof17

#print axioms adaptive129Third128Proof0

end NineSeparatedSubsetSums
