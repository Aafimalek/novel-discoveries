import NineSeparatedSubsetSums.EightPoint129_126PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct129_126_1_budget :
    FourPointNumeric.packedBudget 20 packedOct129_126_1 388 = 85033830 := by decide +kernel

#print axioms packedOct129_126_1_budget

end NineSeparatedSubsetSums
