import NineSeparatedSubsetSums.Adaptive129Third109Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint129Checked

namespace NineSeparatedSubsetSums


theorem adaptive129Third109 : NoDescendingTailAfterThird 129 109 :=
  noDescendingThirdTail_of_cached 129 109 109587 (fun t ht nd => max148_second129_fourPoint_moment_bound (109::t) (by simp [ht]) nd) adaptive129Third109Proof0

#print axioms adaptive129Third109

end NineSeparatedSubsetSums
