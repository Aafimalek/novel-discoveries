import NineSeparatedSubsetSums.EightPointPackedGeometry
import NineSeparatedSubsetSums.EightPoint129_122PackedBudget0
import NineSeparatedSubsetSums.EightPoint129_122PackedAnchor0Part0
import NineSeparatedSubsetSums.EightPoint129_122PackedAnchor0Part1
import NineSeparatedSubsetSums.EightPoint129_122PackedAnchor0Part2
import NineSeparatedSubsetSums.EightPoint129_122PackedBudget1
import NineSeparatedSubsetSums.EightPoint129_122PackedAnchor1Part0
import NineSeparatedSubsetSums.EightPoint129_122PackedAnchor1Part1
import NineSeparatedSubsetSums.EightPoint129_122PackedAnchor1Part2

namespace NineSeparatedSubsetSums

private theorem packedOct129_122Anchor0 :
  ∀ j : Fin 494, ((j.val : Int)+129+122)%2=0 →
    2377461 ≤ FourPointNumeric.octPackedCharge 129 122 20 packedOct129_122_0 (j.val : Int) := by
  intro j hj
  let k := (j.val-1)/2
  have hk : k < 247 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+1 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint129_122PackedAnchor0Part0 z
    rwa [he,hrep] at ht
  by_cases h1 : k < 240
  · let z : Fin 120 := ⟨k-120, by omega⟩
    have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
    have ht := eightPoint129_122PackedAnchor0Part1 z
    rwa [he,hrep] at ht
  let z : Fin 7 := ⟨k-240, by omega⟩
  have he : (z.val : Int)+240 = k := by dsimp [z] <;> omega
  have ht := eightPoint129_122PackedAnchor0Part2 z
  rwa [he,hrep] at ht

private theorem packedOct129_122Anchor1 :
  ∀ j : Fin 494, ((j.val : Int)+129+122)%2=1 →
    2376429 ≤ FourPointNumeric.octPackedCharge 129 122 20 packedOct129_122_1 (j.val : Int) := by
  intro j hj
  let k := (j.val-0)/2
  have hk : k < 247 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+0 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint129_122PackedAnchor1Part0 z
    rwa [he,hrep] at ht
  by_cases h1 : k < 240
  · let z : Fin 120 := ⟨k-120, by omega⟩
    have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
    have ht := eightPoint129_122PackedAnchor1Part1 z
    rwa [he,hrep] at ht
  let z : Fin 7 := ⟨k-240, by omega⟩
  have he : (z.val : Int)+240 = k := by dsimp [z] <;> omega
  have ht := eightPoint129_122PackedAnchor1Part2 z
  rwa [he,hrep] at ht

def packedOctCertificate129_122_0 : EightPointCertificate 129 122 0 123939 :=
  eightPointCertificateOfPacked 129 122 0 123939 2377461 20 packedOct129_122_0 489 494
    (by decide +kernel) (by decide) packedOct129_122Anchor0
    (by rw [packedOct129_122_0_budget]; decide)

def packedOctCertificate129_122_1 : EightPointCertificate 129 122 1 123939 :=
  eightPointCertificateOfPacked 129 122 1 123939 2376429 20 packedOct129_122_1 488 494
    (by decide +kernel) (by decide) packedOct129_122Anchor1
    (by rw [packedOct129_122_1_budget]; decide)

theorem max148_second129_third122_eightPoint_moment_bound (tail : List ℕ) (len : tail.length=6)
    (distinct : (natSubsetSums (148::129::122::tail)).Nodup) :
    123939 ≤ ((148::129::122::tail).map (· ^ 2)).sum := by
  apply eightPointNatMomentLower 129 122 123939 tail len distinct
  intro p hp
  by_cases h : p=0
  · subst p
    exact packedOctCertificate129_122_0
  · have he : p=1 := hp.resolve_left h
    subst p
    exact packedOctCertificate129_122_1

#print axioms max148_second129_third122_eightPoint_moment_bound

end NineSeparatedSubsetSums
