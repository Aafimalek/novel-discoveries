import NineSeparatedSubsetSums.Adaptive129Third128State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive129Third128Proof17 : runCachedNode 511 125293 Adaptive129Third128Node17 = false := by
  decide +kernel

#print axioms adaptive129Third128Proof17

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive129Third128Proof16 : runCachedNode 511 125293 Adaptive129Third128Node16 = false := by
  decide +kernel

#print axioms adaptive129Third128Proof16

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive129Third128Proof15 : runCachedNode 511 125293 Adaptive129Third128Node15 = false := by
  decide +kernel

#print axioms adaptive129Third128Proof15

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive129Third128Proof14 : runCachedNode 511 125293 Adaptive129Third128Node14 = false := by
  decide +kernel

#print axioms adaptive129Third128Proof14

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive129Third128Proof13 : runCachedNode 511 125293 Adaptive129Third128Node13 = false := by
  decide +kernel

#print axioms adaptive129Third128Proof13

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive129Third128Proof12 : runCachedNode 511 125293 Adaptive129Third128Node12 = false := by
  decide +kernel

#print axioms adaptive129Third128Proof12

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive129Third128Proof11 : runCachedNode 511 125293 Adaptive129Third128Node11 = false := by
  decide +kernel

#print axioms adaptive129Third128Proof11

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive129Third128Proof2 : runCachedNode 511 125293 Adaptive129Third128Node2 = false := by
  decide +kernel

#print axioms adaptive129Third128Proof2

end NineSeparatedSubsetSums
