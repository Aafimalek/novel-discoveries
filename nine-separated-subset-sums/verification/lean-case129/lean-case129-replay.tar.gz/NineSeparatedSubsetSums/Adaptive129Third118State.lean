import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive129Third118Node0 : CachedSearchNode :=
  ⟨4, 117, computeCenteredMask [148,129,118], 395, 52469⟩

end NineSeparatedSubsetSums
