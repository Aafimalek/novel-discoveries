import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive129Third110Node0 : CachedSearchNode :=
  ⟨4, 109, computeCenteredMask [148,129,110], 387, 50645⟩

end NineSeparatedSubsetSums
