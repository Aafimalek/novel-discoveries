import NineSeparatedSubsetSums.EightPoint129_127PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct129_127_0_budget :
    FourPointNumeric.packedBudget 20 packedOct129_127_0 441 = 85161581 := by decide +kernel

#print axioms packedOct129_127_0_budget

end NineSeparatedSubsetSums
