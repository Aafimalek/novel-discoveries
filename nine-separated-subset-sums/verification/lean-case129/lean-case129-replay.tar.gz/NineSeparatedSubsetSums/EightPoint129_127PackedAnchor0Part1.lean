import NineSeparatedSubsetSums.EightPoint129_127PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint129_127PackedAnchor0Part1 :
    ∀ j : Fin 120, 2331376 ≤ FourPointNumeric.octPackedCharge 129 127 20 packedOct129_127_0
      (2*((j.val : Int)+120)+0) := by decide +kernel

end NineSeparatedSubsetSums
