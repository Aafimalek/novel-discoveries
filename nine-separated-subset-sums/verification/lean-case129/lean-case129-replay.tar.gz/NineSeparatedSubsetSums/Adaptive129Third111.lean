import NineSeparatedSubsetSums.Adaptive129Third111Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint129Checked

namespace NineSeparatedSubsetSums


theorem adaptive129Third111 : NoDescendingTailAfterThird 129 111 :=
  noDescendingThirdTail_of_cached 129 111 109587 (fun t ht nd => max148_second129_fourPoint_moment_bound (111::t) (by simp [ht]) nd) adaptive129Third111Proof0

#print axioms adaptive129Third111

end NineSeparatedSubsetSums
