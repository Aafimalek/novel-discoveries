import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive129Third111Node0 : CachedSearchNode :=
  ⟨4, 110, computeCenteredMask [148,129,111], 388, 50866⟩

end NineSeparatedSubsetSums
