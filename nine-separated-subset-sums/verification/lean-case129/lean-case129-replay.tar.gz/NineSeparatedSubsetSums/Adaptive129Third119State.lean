import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive129Third119Node0 : CachedSearchNode :=
  ⟨4, 118, computeCenteredMask [148,129,119], 396, 52706⟩

end NineSeparatedSubsetSums
