import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive129Third106Node0 : CachedSearchNode :=
  ⟨4, 105, computeCenteredMask [148,129,106], 383, 49781⟩

end NineSeparatedSubsetSums
