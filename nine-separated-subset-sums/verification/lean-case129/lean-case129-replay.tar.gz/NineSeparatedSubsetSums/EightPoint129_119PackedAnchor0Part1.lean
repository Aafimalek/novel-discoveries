import NineSeparatedSubsetSums.EightPoint129_119PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint129_119PackedAnchor0Part1 :
    ∀ j : Fin 116, 2191543 ≤ FourPointNumeric.octPackedCharge 129 119 20 packedOct129_119_0
      (2*((j.val : Int)+120)+0) := by decide +kernel

end NineSeparatedSubsetSums
