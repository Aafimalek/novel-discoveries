import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive129Third112Node0 : CachedSearchNode :=
  ⟨4, 111, computeCenteredMask [148,129,112], 389, 51089⟩

end NineSeparatedSubsetSums
