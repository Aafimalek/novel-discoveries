import NineSeparatedSubsetSums.EightPoint129_127PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint129_127PackedAnchor1Part0 :
    ∀ j : Fin 120, 2330186 ≤ FourPointNumeric.octPackedCharge 129 127 20 packedOct129_127_1
      (2*((j.val : Int)+0)+1) := by decide +kernel

end NineSeparatedSubsetSums
