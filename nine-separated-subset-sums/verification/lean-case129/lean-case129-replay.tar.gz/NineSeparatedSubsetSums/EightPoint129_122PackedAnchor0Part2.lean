import NineSeparatedSubsetSums.EightPoint129_122PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint129_122PackedAnchor0Part2 :
    ∀ j : Fin 7, 2377461 ≤ FourPointNumeric.octPackedCharge 129 122 20 packedOct129_122_0
      (2*((j.val : Int)+240)+1) := by decide +kernel

end NineSeparatedSubsetSums
