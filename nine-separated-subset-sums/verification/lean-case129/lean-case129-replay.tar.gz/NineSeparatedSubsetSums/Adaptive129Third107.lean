import NineSeparatedSubsetSums.Adaptive129Third107Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint129Checked

namespace NineSeparatedSubsetSums


theorem adaptive129Third107 : NoDescendingTailAfterThird 129 107 :=
  noDescendingThirdTail_of_cached 129 107 109587 (fun t ht nd => max148_second129_fourPoint_moment_bound (107::t) (by simp [ht]) nd) adaptive129Third107Proof0

#print axioms adaptive129Third107

end NineSeparatedSubsetSums
