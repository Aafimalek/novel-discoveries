import NineSeparatedSubsetSums.EightPoint129_124PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint129_124PackedAnchor0Part1 :
    ∀ j : Fin 120, 2358209 ≤ FourPointNumeric.octPackedCharge 129 124 20 packedOct129_124_0
      (2*((j.val : Int)+120)+1) := by decide +kernel

end NineSeparatedSubsetSums
