import NineSeparatedSubsetSums.Adaptive129Third115Joins0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint129Checked

namespace NineSeparatedSubsetSums


theorem adaptive129Third115 : NoDescendingTailAfterThird 129 115 :=
  noDescendingThirdTail_of_cached 129 115 109587 (fun t ht nd => max148_second129_fourPoint_moment_bound (115::t) (by simp [ht]) nd) adaptive129Third115Proof0

#print axioms adaptive129Third115

end NineSeparatedSubsetSums
