import NineSeparatedSubsetSums.Adaptive129Third110State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive129Third110Proof0 : runCachedNode 511 109587 Adaptive129Third110Node0 = false := by
  decide +kernel

#print axioms adaptive129Third110Proof0

end NineSeparatedSubsetSums
