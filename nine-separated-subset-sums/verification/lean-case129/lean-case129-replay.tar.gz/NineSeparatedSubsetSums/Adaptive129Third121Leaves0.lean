import NineSeparatedSubsetSums.Adaptive129Third121State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive129Third121Proof0 : runCachedNode 511 123566 Adaptive129Third121Node0 = false := by
  decide +kernel

#print axioms adaptive129Third121Proof0

end NineSeparatedSubsetSums
