import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive129Third120Node0 : CachedSearchNode :=
  ⟨4, 119, computeCenteredMask [148,129,120], 397, 52945⟩

end NineSeparatedSubsetSums
