import NineSeparatedSubsetSums.FourPointPackedGeometry
import NineSeparatedSubsetSums.FourPoint129PackedBudget0
import NineSeparatedSubsetSums.FourPoint129PackedAnchor0Part0
import NineSeparatedSubsetSums.FourPoint129PackedAnchor0Part1
import NineSeparatedSubsetSums.FourPoint129PackedBudget1
import NineSeparatedSubsetSums.FourPoint129PackedAnchor1Part0
import NineSeparatedSubsetSums.FourPoint129PackedAnchor1Part1

namespace NineSeparatedSubsetSums

private theorem packed129Anchor0 :
  ∀ j : Fin 455, ((j.val : Int)+129)%2=0 →
    982136 ≤ FourPointNumeric.packedCharge 129 19 packedWeight129_0 (j.val : Int) := by
  intro j hj
  let k := (j.val-1)/2
  have hk : k < 227 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+1 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := fourPoint129PackedAnchor0Part0 z
    rwa [he,hrep] at ht
  let z : Fin 107 := ⟨k-120, by omega⟩
  have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
  have ht := fourPoint129PackedAnchor0Part1 z
  rwa [he,hrep] at ht

private theorem packed129Anchor1 :
  ∀ j : Fin 455, ((j.val : Int)+129)%2=1 →
    982116 ≤ FourPointNumeric.packedCharge 129 19 packedWeight129_1 (j.val : Int) := by
  intro j hj
  let k := (j.val-0)/2
  have hk : k < 228 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+0 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := fourPoint129PackedAnchor1Part0 z
    rwa [he,hrep] at ht
  let z : Fin 108 := ⟨k-120, by omega⟩
  have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
  have ht := fourPoint129PackedAnchor1Part1 z
  rwa [he,hrep] at ht

def packedCertificate129_0 : FourPointCertificate 129 0 109587 :=
  fourPointCertificateOfPacked 129 0 109587 982136 19 packedWeight129_0 353 455
    (by decide +kernel) (by decide) (by decide) packed129Anchor0
    (by rw [packedWeight129_0_budget]; decide)

def packedCertificate129_1 : FourPointCertificate 129 1 109587 :=
  fourPointCertificateOfPacked 129 1 109587 982116 19 packedWeight129_1 364 455
    (by decide +kernel) (by decide) (by decide) packed129Anchor1
    (by rw [packedWeight129_1_budget]; decide)

theorem max148_second129_fourPoint_moment_bound (tail : List ℕ) (len : tail.length=7)
    (distinct : (natSubsetSums (148::129::tail)).Nodup) :
    109587 ≤ ((148::129::tail).map (· ^ 2)).sum := by
  apply fourPointNatMomentLower 129 109587 tail len distinct
  intro p hp
  by_cases h : p=0
  · subst p
    exact packedCertificate129_0
  · have he : p=1 := hp.resolve_left h
    subst p
    exact packedCertificate129_1

#print axioms max148_second129_fourPoint_moment_bound

end NineSeparatedSubsetSums
