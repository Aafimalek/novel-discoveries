import NineSeparatedSubsetSums.EightPointPackedGeometry
import NineSeparatedSubsetSums.EightPoint129_120PackedBudget0
import NineSeparatedSubsetSums.EightPoint129_120PackedAnchor0Part0
import NineSeparatedSubsetSums.EightPoint129_120PackedAnchor0Part1
import NineSeparatedSubsetSums.EightPoint129_120PackedBudget1
import NineSeparatedSubsetSums.EightPoint129_120PackedAnchor1Part0
import NineSeparatedSubsetSums.EightPoint129_120PackedAnchor1Part1

namespace NineSeparatedSubsetSums

private theorem packedOct129_120Anchor0 :
  ∀ j : Fin 472, ((j.val : Int)+129+120)%2=0 →
    2199709 ≤ FourPointNumeric.octPackedCharge 129 120 20 packedOct129_120_0 (j.val : Int) := by
  intro j hj
  let k := (j.val-1)/2
  have hk : k < 236 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+1 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint129_120PackedAnchor0Part0 z
    rwa [he,hrep] at ht
  let z : Fin 116 := ⟨k-120, by omega⟩
  have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
  have ht := eightPoint129_120PackedAnchor0Part1 z
  rwa [he,hrep] at ht

private theorem packedOct129_120Anchor1 :
  ∀ j : Fin 472, ((j.val : Int)+129+120)%2=1 →
    2200147 ≤ FourPointNumeric.octPackedCharge 129 120 20 packedOct129_120_1 (j.val : Int) := by
  intro j hj
  let k := (j.val-0)/2
  have hk : k < 236 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+0 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint129_120PackedAnchor1Part0 z
    rwa [he,hrep] at ht
  let z : Fin 116 := ⟨k-120, by omega⟩
  have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
  have ht := eightPoint129_120PackedAnchor1Part1 z
  rwa [he,hrep] at ht

def packedOctCertificate129_120_0 : EightPointCertificate 129 120 0 123451 :=
  eightPointCertificateOfPacked 129 120 0 123451 2199709 20 packedOct129_120_0 379 472
    (by decide +kernel) (by decide) packedOct129_120Anchor0
    (by rw [packedOct129_120_0_budget]; decide)

def packedOctCertificate129_120_1 : EightPointCertificate 129 120 1 123451 :=
  eightPointCertificateOfPacked 129 120 1 123451 2200147 20 packedOct129_120_1 380 472
    (by decide +kernel) (by decide) packedOct129_120Anchor1
    (by rw [packedOct129_120_1_budget]; decide)

theorem max148_second129_third120_eightPoint_moment_bound (tail : List ℕ) (len : tail.length=6)
    (distinct : (natSubsetSums (148::129::120::tail)).Nodup) :
    123451 ≤ ((148::129::120::tail).map (· ^ 2)).sum := by
  apply eightPointNatMomentLower 129 120 123451 tail len distinct
  intro p hp
  by_cases h : p=0
  · subst p
    exact packedOctCertificate129_120_0
  · have he : p=1 := hp.resolve_left h
    subst p
    exact packedOctCertificate129_120_1

#print axioms max148_second129_third120_eightPoint_moment_bound

end NineSeparatedSubsetSums
