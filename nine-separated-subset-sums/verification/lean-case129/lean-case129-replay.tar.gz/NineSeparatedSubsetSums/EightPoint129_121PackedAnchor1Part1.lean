import NineSeparatedSubsetSums.EightPoint129_121PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint129_121PackedAnchor1Part1 :
    ∀ j : Fin 117, 2227508 ≤ FourPointNumeric.octPackedCharge 129 121 20 packedOct129_121_1
      (2*((j.val : Int)+120)+1) := by decide +kernel

end NineSeparatedSubsetSums
