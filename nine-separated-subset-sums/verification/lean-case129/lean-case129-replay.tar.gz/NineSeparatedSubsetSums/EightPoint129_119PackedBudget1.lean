import NineSeparatedSubsetSums.EightPoint129_119PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct129_119_1_budget :
    FourPointNumeric.packedBudget 20 packedOct129_119_1 374 = 77144192 := by decide +kernel

#print axioms packedOct129_119_1_budget

end NineSeparatedSubsetSums
