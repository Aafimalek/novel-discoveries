import NineSeparatedSubsetSums.EightPoint129_123PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint129_123PackedAnchor0Part2 :
    ∀ j : Fin 7, 2366360 ≤ FourPointNumeric.octPackedCharge 129 123 20 packedOct129_123_0
      (2*((j.val : Int)+240)+0) := by decide +kernel

end NineSeparatedSubsetSums
