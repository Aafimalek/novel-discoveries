import NineSeparatedSubsetSums.EightPoint129_127PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint129_127PackedAnchor0Part2 :
    ∀ j : Fin 4, 2331376 ≤ FourPointNumeric.octPackedCharge 129 127 20 packedOct129_127_0
      (2*((j.val : Int)+240)+0) := by decide +kernel

end NineSeparatedSubsetSums
