import NineSeparatedSubsetSums.EightPoint129_124PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct129_124_0_budget :
    FourPointNumeric.packedBudget 20 packedOct129_124_0 391 = 87152167 := by decide +kernel

#print axioms packedOct129_124_0_budget

end NineSeparatedSubsetSums
