import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive129Third122Node0 : CachedSearchNode :=
  ⟨4, 121, computeCenteredMask [148,129,122], 399, 53429⟩

end NineSeparatedSubsetSums
