import NineSeparatedSubsetSums.EightPoint129_118PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint129_118PackedAnchor1Part1 :
    ∀ j : Fin 116, 2197552 ≤ FourPointNumeric.octPackedCharge 129 118 20 packedOct129_118_1
      (2*((j.val : Int)+120)+0) := by decide +kernel

end NineSeparatedSubsetSums
