import NineSeparatedSubsetSums.FourPoint129PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem fourPoint129PackedAnchor1Part0 :
    ∀ j : Fin 120, 982116 ≤ FourPointNumeric.packedCharge 129 19 packedWeight129_1
      (2*((j.val : Int)+0)+0) := by decide +kernel

end NineSeparatedSubsetSums
