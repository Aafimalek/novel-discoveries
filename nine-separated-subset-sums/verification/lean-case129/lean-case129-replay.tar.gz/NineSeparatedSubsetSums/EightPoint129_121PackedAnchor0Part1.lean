import NineSeparatedSubsetSums.EightPoint129_121PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint129_121PackedAnchor0Part1 :
    ∀ j : Fin 118, 2228232 ≤ FourPointNumeric.octPackedCharge 129 121 20 packedOct129_121_0
      (2*((j.val : Int)+120)+0) := by decide +kernel

end NineSeparatedSubsetSums
