import NineSeparatedSubsetSums.Adaptive129Third105Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint129Checked

namespace NineSeparatedSubsetSums


theorem adaptive129Third105 : NoDescendingTailAfterThird 129 105 :=
  noDescendingThirdTail_of_cached 129 105 109587 (fun t ht nd => max148_second129_fourPoint_moment_bound (105::t) (by simp [ht]) nd) adaptive129Third105Proof0

#print axioms adaptive129Third105

end NineSeparatedSubsetSums
