import NineSeparatedSubsetSums.EightPoint129_123PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct129_123_0_budget :
    FourPointNumeric.packedBudget 20 packedOct129_123_0 491 = 87816108 := by decide +kernel

#print axioms packedOct129_123_0_budget

end NineSeparatedSubsetSums
