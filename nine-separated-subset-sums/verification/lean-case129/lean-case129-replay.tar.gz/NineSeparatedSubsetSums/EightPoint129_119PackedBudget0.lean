import NineSeparatedSubsetSums.EightPoint129_119PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct129_119_0_budget :
    FourPointNumeric.packedBudget 20 packedOct129_119_0 375 = 77088423 := by decide +kernel

#print axioms packedOct129_119_0_budget

end NineSeparatedSubsetSums
