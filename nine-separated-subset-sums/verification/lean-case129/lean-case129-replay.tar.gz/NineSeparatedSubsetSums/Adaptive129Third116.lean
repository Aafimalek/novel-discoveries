import NineSeparatedSubsetSums.Adaptive129Third116Joins0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint129Checked

namespace NineSeparatedSubsetSums


theorem adaptive129Third116 : NoDescendingTailAfterThird 129 116 :=
  noDescendingThirdTail_of_cached 129 116 109587 (fun t ht nd => max148_second129_fourPoint_moment_bound (116::t) (by simp [ht]) nd) adaptive129Third116Proof0

#print axioms adaptive129Third116

end NineSeparatedSubsetSums
