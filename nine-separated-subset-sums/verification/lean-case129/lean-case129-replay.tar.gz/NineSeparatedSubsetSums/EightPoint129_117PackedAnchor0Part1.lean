import NineSeparatedSubsetSums.EightPoint129_117PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint129_117PackedAnchor0Part1 :
    ∀ j : Fin 116, 2196183 ≤ FourPointNumeric.octPackedCharge 129 117 20 packedOct129_117_0
      (2*((j.val : Int)+120)+0) := by decide +kernel

end NineSeparatedSubsetSums
