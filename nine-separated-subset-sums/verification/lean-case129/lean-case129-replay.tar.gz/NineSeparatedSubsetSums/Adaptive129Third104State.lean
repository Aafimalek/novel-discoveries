import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive129Third104Node0 : CachedSearchNode :=
  ⟨4, 103, computeCenteredMask [148,129,104], 381, 49361⟩

end NineSeparatedSubsetSums
