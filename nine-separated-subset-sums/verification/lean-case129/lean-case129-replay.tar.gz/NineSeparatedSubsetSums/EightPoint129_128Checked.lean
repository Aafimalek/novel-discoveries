import NineSeparatedSubsetSums.EightPointPackedGeometry
import NineSeparatedSubsetSums.EightPoint129_128PackedBudget0
import NineSeparatedSubsetSums.EightPoint129_128PackedAnchor0Part0
import NineSeparatedSubsetSums.EightPoint129_128PackedAnchor0Part1
import NineSeparatedSubsetSums.EightPoint129_128PackedAnchor0Part2
import NineSeparatedSubsetSums.EightPoint129_128PackedBudget1
import NineSeparatedSubsetSums.EightPoint129_128PackedAnchor1Part0
import NineSeparatedSubsetSums.EightPoint129_128PackedAnchor1Part1
import NineSeparatedSubsetSums.EightPoint129_128PackedAnchor1Part2

namespace NineSeparatedSubsetSums

private theorem packedOct129_128Anchor0 :
  ∀ j : Fin 486, ((j.val : Int)+129+128)%2=0 →
    2324957 ≤ FourPointNumeric.octPackedCharge 129 128 20 packedOct129_128_0 (j.val : Int) := by
  intro j hj
  let k := (j.val-1)/2
  have hk : k < 243 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+1 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint129_128PackedAnchor0Part0 z
    rwa [he,hrep] at ht
  by_cases h1 : k < 240
  · let z : Fin 120 := ⟨k-120, by omega⟩
    have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
    have ht := eightPoint129_128PackedAnchor0Part1 z
    rwa [he,hrep] at ht
  let z : Fin 3 := ⟨k-240, by omega⟩
  have he : (z.val : Int)+240 = k := by dsimp [z] <;> omega
  have ht := eightPoint129_128PackedAnchor0Part2 z
  rwa [he,hrep] at ht

private theorem packedOct129_128Anchor1 :
  ∀ j : Fin 486, ((j.val : Int)+129+128)%2=1 →
    2325212 ≤ FourPointNumeric.octPackedCharge 129 128 20 packedOct129_128_1 (j.val : Int) := by
  intro j hj
  let k := (j.val-0)/2
  have hk : k < 243 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+0 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint129_128PackedAnchor1Part0 z
    rwa [he,hrep] at ht
  by_cases h1 : k < 240
  · let z : Fin 120 := ⟨k-120, by omega⟩
    have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
    have ht := eightPoint129_128PackedAnchor1Part1 z
    rwa [he,hrep] at ht
  let z : Fin 3 := ⟨k-240, by omega⟩
  have he : (z.val : Int)+240 = k := by dsimp [z] <;> omega
  have ht := eightPoint129_128PackedAnchor1Part2 z
  rwa [he,hrep] at ht

def packedOctCertificate129_128_0 : EightPointCertificate 129 128 0 125293 :=
  eightPointCertificateOfPacked 129 128 0 125293 2324957 20 packedOct129_128_0 445 486
    (by decide +kernel) (by decide) packedOct129_128Anchor0
    (by rw [packedOct129_128_0_budget]; decide)

def packedOctCertificate129_128_1 : EightPointCertificate 129 128 1 125293 :=
  eightPointCertificateOfPacked 129 128 1 125293 2325212 20 packedOct129_128_1 276 486
    (by decide +kernel) (by decide) packedOct129_128Anchor1
    (by rw [packedOct129_128_1_budget]; decide)

theorem max148_second129_third128_eightPoint_moment_bound (tail : List ℕ) (len : tail.length=6)
    (distinct : (natSubsetSums (148::129::128::tail)).Nodup) :
    125293 ≤ ((148::129::128::tail).map (· ^ 2)).sum := by
  apply eightPointNatMomentLower 129 128 125293 tail len distinct
  intro p hp
  by_cases h : p=0
  · subst p
    exact packedOctCertificate129_128_0
  · have he : p=1 := hp.resolve_left h
    subst p
    exact packedOctCertificate129_128_1

#print axioms max148_second129_third128_eightPoint_moment_bound

end NineSeparatedSubsetSums
