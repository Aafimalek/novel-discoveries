import NineSeparatedSubsetSums.FourPoint129PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedWeight129_0_budget :
    FourPointNumeric.packedBudget 19 packedWeight129_0 353 = 69604480 := by decide +kernel

#print axioms packedWeight129_0_budget

end NineSeparatedSubsetSums
