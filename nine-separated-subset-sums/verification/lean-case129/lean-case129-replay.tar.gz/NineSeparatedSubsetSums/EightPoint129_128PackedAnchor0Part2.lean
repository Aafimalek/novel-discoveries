import NineSeparatedSubsetSums.EightPoint129_128PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint129_128PackedAnchor0Part2 :
    ∀ j : Fin 3, 2324957 ≤ FourPointNumeric.octPackedCharge 129 128 20 packedOct129_128_0
      (2*((j.val : Int)+240)+1) := by decide +kernel

end NineSeparatedSubsetSums
