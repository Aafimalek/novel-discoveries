import NineSeparatedSubsetSums.Adaptive129Third113Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint129Checked

namespace NineSeparatedSubsetSums


theorem adaptive129Third113 : NoDescendingTailAfterThird 129 113 :=
  noDescendingThirdTail_of_cached 129 113 109587 (fun t ht nd => max148_second129_fourPoint_moment_bound (113::t) (by simp [ht]) nd) adaptive129Third113Proof0

#print axioms adaptive129Third113

end NineSeparatedSubsetSums
