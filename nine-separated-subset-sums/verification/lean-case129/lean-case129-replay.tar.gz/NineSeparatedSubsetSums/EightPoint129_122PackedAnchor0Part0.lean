import NineSeparatedSubsetSums.EightPoint129_122PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint129_122PackedAnchor0Part0 :
    ∀ j : Fin 120, 2377461 ≤ FourPointNumeric.octPackedCharge 129 122 20 packedOct129_122_0
      (2*((j.val : Int)+0)+1) := by decide +kernel

end NineSeparatedSubsetSums
