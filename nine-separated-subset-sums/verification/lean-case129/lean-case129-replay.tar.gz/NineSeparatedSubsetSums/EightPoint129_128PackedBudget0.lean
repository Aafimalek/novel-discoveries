import NineSeparatedSubsetSums.EightPoint129_128PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct129_128_0_budget :
    FourPointNumeric.packedBudget 20 packedOct129_128_0 445 = 84647728 := by decide +kernel

#print axioms packedOct129_128_0_budget

end NineSeparatedSubsetSums
