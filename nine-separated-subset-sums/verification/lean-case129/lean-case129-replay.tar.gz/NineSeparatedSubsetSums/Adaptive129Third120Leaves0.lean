import NineSeparatedSubsetSums.Adaptive129Third120State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive129Third120Proof0 : runCachedNode 511 123451 Adaptive129Third120Node0 = false := by
  decide +kernel

#print axioms adaptive129Third120Proof0

end NineSeparatedSubsetSums
