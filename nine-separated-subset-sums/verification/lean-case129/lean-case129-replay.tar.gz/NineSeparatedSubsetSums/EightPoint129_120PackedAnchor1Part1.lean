import NineSeparatedSubsetSums.EightPoint129_120PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint129_120PackedAnchor1Part1 :
    ∀ j : Fin 116, 2200147 ≤ FourPointNumeric.octPackedCharge 129 120 20 packedOct129_120_1
      (2*((j.val : Int)+120)+0) := by decide +kernel

end NineSeparatedSubsetSums
