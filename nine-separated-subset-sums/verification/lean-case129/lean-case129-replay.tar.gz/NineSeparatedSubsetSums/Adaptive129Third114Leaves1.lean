import NineSeparatedSubsetSums.Adaptive129Third114State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive129Third114Proof6 : runCachedNode 511 109587 Adaptive129Third114Node6 = false := by
  decide +kernel

#print axioms adaptive129Third114Proof6

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive129Third114Proof5 : runCachedNode 511 109587 Adaptive129Third114Node5 = false := by
  decide +kernel

#print axioms adaptive129Third114Proof5

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive129Third114Proof3 : runCachedNode 511 109587 Adaptive129Third114Node3 = false := by
  decide +kernel

#print axioms adaptive129Third114Proof3

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive129Third114Proof1 : runCachedNode 511 109587 Adaptive129Third114Node1 = false := by
  decide +kernel

#print axioms adaptive129Third114Proof1

end NineSeparatedSubsetSums
