import NineSeparatedSubsetSums.EightPoint129_119PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint129_119PackedAnchor1Part1 :
    ∀ j : Fin 115, 2192412 ≤ FourPointNumeric.octPackedCharge 129 119 20 packedOct129_119_1
      (2*((j.val : Int)+120)+1) := by decide +kernel

end NineSeparatedSubsetSums
