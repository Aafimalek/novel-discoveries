import NineSeparatedSubsetSums.EightPoint129_117PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint129_117PackedAnchor1Part1 :
    ∀ j : Fin 116, 2196508 ≤ FourPointNumeric.octPackedCharge 129 117 20 packedOct129_117_1
      (2*((j.val : Int)+120)+1) := by decide +kernel

end NineSeparatedSubsetSums
