import NineSeparatedSubsetSums.EightPoint129_121PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct129_121_1_budget :
    FourPointNumeric.packedBudget 20 packedOct129_121_1 268 = 79295182 := by decide +kernel

#print axioms packedOct129_121_1_budget

end NineSeparatedSubsetSums
