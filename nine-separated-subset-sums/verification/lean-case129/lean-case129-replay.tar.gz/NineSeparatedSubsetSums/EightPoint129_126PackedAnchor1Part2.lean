import NineSeparatedSubsetSums.EightPoint129_126PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint129_126PackedAnchor1Part2 :
    ∀ j : Fin 4, 2327919 ≤ FourPointNumeric.octPackedCharge 129 126 20 packedOct129_126_1
      (2*((j.val : Int)+240)+0) := by decide +kernel

end NineSeparatedSubsetSums
