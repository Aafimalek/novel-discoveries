import NineSeparatedSubsetSums.Adaptive129Third108Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint129Checked

namespace NineSeparatedSubsetSums


theorem adaptive129Third108 : NoDescendingTailAfterThird 129 108 :=
  noDescendingThirdTail_of_cached 129 108 109587 (fun t ht nd => max148_second129_fourPoint_moment_bound (108::t) (by simp [ht]) nd) adaptive129Third108Proof0

#print axioms adaptive129Third108

end NineSeparatedSubsetSums
