import NineSeparatedSubsetSums.Adaptive129Third128State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive129Third128Proof10 : runCachedNode 511 125293 Adaptive129Third128Node10 = false := by
  decide +kernel

#print axioms adaptive129Third128Proof10

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive129Third128Proof9 : runCachedNode 511 125293 Adaptive129Third128Node9 = false := by
  decide +kernel

#print axioms adaptive129Third128Proof9

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive129Third128Proof8 : runCachedNode 511 125293 Adaptive129Third128Node8 = false := by
  decide +kernel

#print axioms adaptive129Third128Proof8

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive129Third128Proof7 : runCachedNode 511 125293 Adaptive129Third128Node7 = false := by
  decide +kernel

#print axioms adaptive129Third128Proof7

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive129Third128Proof6 : runCachedNode 511 125293 Adaptive129Third128Node6 = false := by
  decide +kernel

#print axioms adaptive129Third128Proof6

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive129Third128Proof5 : runCachedNode 511 125293 Adaptive129Third128Node5 = false := by
  decide +kernel

#print axioms adaptive129Third128Proof5

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive129Third128Proof4 : runCachedNode 511 125293 Adaptive129Third128Node4 = false := by
  decide +kernel

#print axioms adaptive129Third128Proof4

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive129Third128Proof3 : runCachedNode 511 125293 Adaptive129Third128Node3 = false := by
  decide +kernel

#print axioms adaptive129Third128Proof3

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive129Third128Proof1 : runCachedNode 511 125293 Adaptive129Third128Node1 = false := by
  decide +kernel

#print axioms adaptive129Third128Proof1

end NineSeparatedSubsetSums
