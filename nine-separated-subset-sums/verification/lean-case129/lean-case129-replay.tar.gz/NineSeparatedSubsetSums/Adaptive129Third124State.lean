import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive129Third124Node0 : CachedSearchNode :=
  ⟨4, 123, computeCenteredMask [148,129,124], 401, 53921⟩

end NineSeparatedSubsetSums
