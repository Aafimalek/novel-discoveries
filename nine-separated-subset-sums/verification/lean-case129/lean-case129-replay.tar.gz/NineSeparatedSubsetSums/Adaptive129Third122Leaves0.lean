import NineSeparatedSubsetSums.Adaptive129Third122State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive129Third122Proof0 : runCachedNode 511 123939 Adaptive129Third122Node0 = false := by
  decide +kernel

#print axioms adaptive129Third122Proof0

end NineSeparatedSubsetSums
