import NineSeparatedSubsetSums.EightPoint129_120PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct129_120_1_budget :
    FourPointNumeric.packedBudget 20 packedOct129_120_1 380 = 77602714 := by decide +kernel

#print axioms packedOct129_120_1_budget

end NineSeparatedSubsetSums
