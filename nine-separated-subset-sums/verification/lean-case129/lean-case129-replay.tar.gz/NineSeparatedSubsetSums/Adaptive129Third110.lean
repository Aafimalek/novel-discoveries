import NineSeparatedSubsetSums.Adaptive129Third110Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint129Checked

namespace NineSeparatedSubsetSums


theorem adaptive129Third110 : NoDescendingTailAfterThird 129 110 :=
  noDescendingThirdTail_of_cached 129 110 109587 (fun t ht nd => max148_second129_fourPoint_moment_bound (110::t) (by simp [ht]) nd) adaptive129Third110Proof0

#print axioms adaptive129Third110

end NineSeparatedSubsetSums
