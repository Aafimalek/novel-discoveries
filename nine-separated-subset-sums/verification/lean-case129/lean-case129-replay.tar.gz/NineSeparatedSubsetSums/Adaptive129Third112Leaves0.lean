import NineSeparatedSubsetSums.Adaptive129Third112State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive129Third112Proof0 : runCachedNode 511 109587 Adaptive129Third112Node0 = false := by
  decide +kernel

#print axioms adaptive129Third112Proof0

end NineSeparatedSubsetSums
