import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive129Third105Node0 : CachedSearchNode :=
  ⟨4, 104, computeCenteredMask [148,129,105], 382, 49570⟩

end NineSeparatedSubsetSums
