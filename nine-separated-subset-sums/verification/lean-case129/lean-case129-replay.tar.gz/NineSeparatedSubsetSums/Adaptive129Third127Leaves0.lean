import NineSeparatedSubsetSums.Adaptive129Third127State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive129Third127Proof0 : runCachedNode 511 125091 Adaptive129Third127Node0 = false := by
  decide +kernel

#print axioms adaptive129Third127Proof0

end NineSeparatedSubsetSums
