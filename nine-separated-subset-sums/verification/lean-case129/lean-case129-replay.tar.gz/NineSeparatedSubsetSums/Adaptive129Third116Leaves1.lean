import NineSeparatedSubsetSums.Adaptive129Third116State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive129Third116Proof12 : runCachedNode 511 109587 Adaptive129Third116Node12 = false := by
  decide +kernel

#print axioms adaptive129Third116Proof12

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive129Third116Proof10 : runCachedNode 511 109587 Adaptive129Third116Node10 = false := by
  decide +kernel

#print axioms adaptive129Third116Proof10

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive129Third116Proof11 : runCachedNode 511 109587 Adaptive129Third116Node11 = false := by
  decide +kernel

#print axioms adaptive129Third116Proof11

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive129Third116Proof8 : runCachedNode 511 109587 Adaptive129Third116Node8 = false := by
  decide +kernel

#print axioms adaptive129Third116Proof8

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive129Third116Proof7 : runCachedNode 511 109587 Adaptive129Third116Node7 = false := by
  decide +kernel

#print axioms adaptive129Third116Proof7

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive129Third116Proof5 : runCachedNode 511 109587 Adaptive129Third116Node5 = false := by
  decide +kernel

#print axioms adaptive129Third116Proof5

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive129Third116Proof4 : runCachedNode 511 109587 Adaptive129Third116Node4 = false := by
  decide +kernel

#print axioms adaptive129Third116Proof4

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive129Third116Proof3 : runCachedNode 511 109587 Adaptive129Third116Node3 = false := by
  decide +kernel

#print axioms adaptive129Third116Proof3

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive129Third116Proof1 : runCachedNode 511 109587 Adaptive129Third116Node1 = false := by
  decide +kernel

#print axioms adaptive129Third116Proof1

end NineSeparatedSubsetSums
