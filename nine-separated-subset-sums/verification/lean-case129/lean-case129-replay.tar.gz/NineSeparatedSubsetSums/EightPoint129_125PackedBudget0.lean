import NineSeparatedSubsetSums.EightPoint129_125PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct129_125_0_budget :
    FourPointNumeric.packedBudget 20 packedOct129_125_0 387 = 85922786 := by decide +kernel

#print axioms packedOct129_125_0_budget

end NineSeparatedSubsetSums
