import NineSeparatedSubsetSums.EightPoint129_122PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct129_122_1_budget :
    FourPointNumeric.packedBudget 20 packedOct129_122_1 488 = 88634980 := by decide +kernel

#print axioms packedOct129_122_1_budget

end NineSeparatedSubsetSums
