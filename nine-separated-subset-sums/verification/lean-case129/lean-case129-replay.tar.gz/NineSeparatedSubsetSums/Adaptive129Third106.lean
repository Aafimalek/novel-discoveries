import NineSeparatedSubsetSums.Adaptive129Third106Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint129Checked

namespace NineSeparatedSubsetSums


theorem adaptive129Third106 : NoDescendingTailAfterThird 129 106 :=
  noDescendingThirdTail_of_cached 129 106 109587 (fun t ht nd => max148_second129_fourPoint_moment_bound (106::t) (by simp [ht]) nd) adaptive129Third106Proof0

#print axioms adaptive129Third106

end NineSeparatedSubsetSums
