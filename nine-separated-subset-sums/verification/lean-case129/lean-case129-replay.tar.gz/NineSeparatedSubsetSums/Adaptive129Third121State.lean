import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive129Third121Node0 : CachedSearchNode :=
  ⟨4, 120, computeCenteredMask [148,129,121], 398, 53186⟩

end NineSeparatedSubsetSums
