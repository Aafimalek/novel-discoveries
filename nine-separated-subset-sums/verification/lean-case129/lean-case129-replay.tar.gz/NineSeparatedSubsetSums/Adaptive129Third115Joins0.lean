import NineSeparatedSubsetSums.Adaptive129Third115State
import NineSeparatedSubsetSums.Adaptive129Third115Leaves0
import NineSeparatedSubsetSums.Adaptive129Third115Leaves1

namespace NineSeparatedSubsetSums

theorem adaptive129Third115Proof0 : runCachedNode 511 109587 Adaptive129Third115Node0 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 109587 Adaptive129Third115Node0 = [101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive129Third115Proof1
  · exact adaptive129Third115Proof2
  · exact adaptive129Third115Proof3
  · exact adaptive129Third115Proof4
  · exact adaptive129Third115Proof5
  · exact adaptive129Third115Proof6
  · exact adaptive129Third115Proof7
  · exact adaptive129Third115Proof8
  · exact adaptive129Third115Proof9
  · exact adaptive129Third115Proof10
  · exact adaptive129Third115Proof11
  · exact adaptive129Third115Proof12
  · exact adaptive129Third115Proof13
  · exact adaptive129Third115Proof14

#print axioms adaptive129Third115Proof0

end NineSeparatedSubsetSums
