import NineSeparatedSubsetSums.Adaptive129Third115State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive129Third115Proof14 : runCachedNode 511 109587 Adaptive129Third115Node14 = false := by
  decide +kernel

#print axioms adaptive129Third115Proof14

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive129Third115Proof13 : runCachedNode 511 109587 Adaptive129Third115Node13 = false := by
  decide +kernel

#print axioms adaptive129Third115Proof13

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive129Third115Proof12 : runCachedNode 511 109587 Adaptive129Third115Node12 = false := by
  decide +kernel

#print axioms adaptive129Third115Proof12

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive129Third115Proof10 : runCachedNode 511 109587 Adaptive129Third115Node10 = false := by
  decide +kernel

#print axioms adaptive129Third115Proof10

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive129Third115Proof11 : runCachedNode 511 109587 Adaptive129Third115Node11 = false := by
  decide +kernel

#print axioms adaptive129Third115Proof11

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive129Third115Proof2 : runCachedNode 511 109587 Adaptive129Third115Node2 = false := by
  decide +kernel

#print axioms adaptive129Third115Proof2

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive129Third115Proof1 : runCachedNode 511 109587 Adaptive129Third115Node1 = false := by
  decide +kernel

#print axioms adaptive129Third115Proof1

end NineSeparatedSubsetSums
