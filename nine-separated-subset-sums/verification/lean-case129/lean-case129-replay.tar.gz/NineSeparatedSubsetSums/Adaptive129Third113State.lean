import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive129Third113Node0 : CachedSearchNode :=
  ⟨4, 112, computeCenteredMask [148,129,113], 390, 51314⟩

end NineSeparatedSubsetSums
