import NineSeparatedSubsetSums.Adaptive129Third118State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive129Third118Proof0 : runCachedNode 511 123272 Adaptive129Third118Node0 = false := by
  decide +kernel

#print axioms adaptive129Third118Proof0

end NineSeparatedSubsetSums
