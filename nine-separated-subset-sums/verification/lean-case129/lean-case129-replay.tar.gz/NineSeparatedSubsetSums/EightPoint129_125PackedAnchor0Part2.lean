import NineSeparatedSubsetSums.EightPoint129_125PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint129_125PackedAnchor0Part2 :
    ∀ j : Fin 5, 2340436 ≤ FourPointNumeric.octPackedCharge 129 125 20 packedOct129_125_0
      (2*((j.val : Int)+240)+0) := by decide +kernel

end NineSeparatedSubsetSums
