import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive129Third126Node0 : CachedSearchNode :=
  ⟨4, 125, computeCenteredMask [148,129,126], 403, 54421⟩

end NineSeparatedSubsetSums
