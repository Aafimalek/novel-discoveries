import NineSeparatedSubsetSums.Adaptive129Third114Joins0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint129Checked

namespace NineSeparatedSubsetSums


theorem adaptive129Third114 : NoDescendingTailAfterThird 129 114 :=
  noDescendingThirdTail_of_cached 129 114 109587 (fun t ht nd => max148_second129_fourPoint_moment_bound (114::t) (by simp [ht]) nd) adaptive129Third114Proof0

#print axioms adaptive129Third114

end NineSeparatedSubsetSums
