import NineSeparatedSubsetSums.EightPoint129_118PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint129_118PackedAnchor0Part1 :
    ∀ j : Fin 116, 2197979 ≤ FourPointNumeric.octPackedCharge 129 118 20 packedOct129_118_0
      (2*((j.val : Int)+120)+1) := by decide +kernel

end NineSeparatedSubsetSums
