import NineSeparatedSubsetSums.Adaptive129Third114State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive129Third114Proof13 : runCachedNode 511 109587 Adaptive129Third114Node13 = false := by
  decide +kernel

#print axioms adaptive129Third114Proof13

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive129Third114Proof12 : runCachedNode 511 109587 Adaptive129Third114Node12 = false := by
  decide +kernel

#print axioms adaptive129Third114Proof12

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive129Third114Proof10 : runCachedNode 511 109587 Adaptive129Third114Node10 = false := by
  decide +kernel

#print axioms adaptive129Third114Proof10

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive129Third114Proof11 : runCachedNode 511 109587 Adaptive129Third114Node11 = false := by
  decide +kernel

#print axioms adaptive129Third114Proof11

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive129Third114Proof9 : runCachedNode 511 109587 Adaptive129Third114Node9 = false := by
  decide +kernel

#print axioms adaptive129Third114Proof9

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive129Third114Proof8 : runCachedNode 511 109587 Adaptive129Third114Node8 = false := by
  decide +kernel

#print axioms adaptive129Third114Proof8

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive129Third114Proof7 : runCachedNode 511 109587 Adaptive129Third114Node7 = false := by
  decide +kernel

#print axioms adaptive129Third114Proof7

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive129Third114Proof4 : runCachedNode 511 109587 Adaptive129Third114Node4 = false := by
  decide +kernel

#print axioms adaptive129Third114Proof4

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive129Third114Proof2 : runCachedNode 511 109587 Adaptive129Third114Node2 = false := by
  decide +kernel

#print axioms adaptive129Third114Proof2

end NineSeparatedSubsetSums
