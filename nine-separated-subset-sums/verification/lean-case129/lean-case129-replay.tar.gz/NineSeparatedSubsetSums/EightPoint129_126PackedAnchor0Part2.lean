import NineSeparatedSubsetSums.EightPoint129_126PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint129_126PackedAnchor0Part2 :
    ∀ j : Fin 3, 2329047 ≤ FourPointNumeric.octPackedCharge 129 126 20 packedOct129_126_0
      (2*((j.val : Int)+240)+1) := by decide +kernel

end NineSeparatedSubsetSums
