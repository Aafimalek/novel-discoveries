import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive129Third117Node0 : CachedSearchNode :=
  ⟨4, 116, computeCenteredMask [148,129,117], 394, 52234⟩

end NineSeparatedSubsetSums
