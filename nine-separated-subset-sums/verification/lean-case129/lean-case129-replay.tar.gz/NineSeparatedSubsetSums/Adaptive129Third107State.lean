import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive129Third107Node0 : CachedSearchNode :=
  ⟨4, 106, computeCenteredMask [148,129,107], 384, 49994⟩

end NineSeparatedSubsetSums
