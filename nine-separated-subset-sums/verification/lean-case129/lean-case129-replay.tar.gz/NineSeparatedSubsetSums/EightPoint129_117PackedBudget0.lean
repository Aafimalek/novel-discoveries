import NineSeparatedSubsetSums.EightPoint129_117PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct129_117_0_budget :
    FourPointNumeric.packedBudget 20 packedOct129_117_0 465 = 77537368 := by decide +kernel

#print axioms packedOct129_117_0_budget

end NineSeparatedSubsetSums
