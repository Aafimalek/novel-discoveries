import NineSeparatedSubsetSums.Adaptive129Third117State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive129Third117Proof0 : runCachedNode 511 123083 Adaptive129Third117Node0 = false := by
  decide +kernel

#print axioms adaptive129Third117Proof0

end NineSeparatedSubsetSums
