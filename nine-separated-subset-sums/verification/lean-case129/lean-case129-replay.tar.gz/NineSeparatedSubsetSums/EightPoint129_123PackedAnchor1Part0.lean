import NineSeparatedSubsetSums.EightPoint129_123PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint129_123PackedAnchor1Part0 :
    ∀ j : Fin 120, 2365695 ≤ FourPointNumeric.octPackedCharge 129 123 20 packedOct129_123_1
      (2*((j.val : Int)+0)+1) := by decide +kernel

end NineSeparatedSubsetSums
