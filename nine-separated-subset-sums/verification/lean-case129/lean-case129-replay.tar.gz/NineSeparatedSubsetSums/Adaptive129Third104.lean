import NineSeparatedSubsetSums.Adaptive129Third104Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint129Checked

namespace NineSeparatedSubsetSums


theorem adaptive129Third104 : NoDescendingTailAfterThird 129 104 :=
  noDescendingThirdTail_of_cached 129 104 109587 (fun t ht nd => max148_second129_fourPoint_moment_bound (104::t) (by simp [ht]) nd) adaptive129Third104Proof0

#print axioms adaptive129Third104

end NineSeparatedSubsetSums
