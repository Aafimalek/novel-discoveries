import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive129Third109Node0 : CachedSearchNode :=
  ⟨4, 108, computeCenteredMask [148,129,109], 386, 50426⟩

end NineSeparatedSubsetSums
