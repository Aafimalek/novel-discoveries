import NineSeparatedSubsetSums.Adaptive129Third123State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive129Third123Proof0 : runCachedNode 511 124280 Adaptive129Third123Node0 = false := by
  decide +kernel

#print axioms adaptive129Third123Proof0

end NineSeparatedSubsetSums
