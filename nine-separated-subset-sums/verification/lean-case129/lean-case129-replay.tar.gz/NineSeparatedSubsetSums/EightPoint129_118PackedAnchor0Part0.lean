import NineSeparatedSubsetSums.EightPoint129_118PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint129_118PackedAnchor0Part0 :
    ∀ j : Fin 120, 2197979 ≤ FourPointNumeric.octPackedCharge 129 118 20 packedOct129_118_0
      (2*((j.val : Int)+0)+1) := by decide +kernel

end NineSeparatedSubsetSums
