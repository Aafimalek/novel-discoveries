import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive129Third123Node0 : CachedSearchNode :=
  ⟨4, 122, computeCenteredMask [148,129,123], 400, 53674⟩

end NineSeparatedSubsetSums
