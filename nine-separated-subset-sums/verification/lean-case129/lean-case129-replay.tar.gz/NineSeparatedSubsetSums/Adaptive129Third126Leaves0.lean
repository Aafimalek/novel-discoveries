import NineSeparatedSubsetSums.Adaptive129Third126State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive129Third126Proof0 : runCachedNode 511 124909 Adaptive129Third126Node0 = false := by
  decide +kernel

#print axioms adaptive129Third126Proof0

end NineSeparatedSubsetSums
