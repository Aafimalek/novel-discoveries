import NineSeparatedSubsetSums.EightPoint129_123PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct129_123_1_budget :
    FourPointNumeric.packedBudget 20 packedOct129_123_1 492 = 87773294 := by decide +kernel

#print axioms packedOct129_123_1_budget

end NineSeparatedSubsetSums
