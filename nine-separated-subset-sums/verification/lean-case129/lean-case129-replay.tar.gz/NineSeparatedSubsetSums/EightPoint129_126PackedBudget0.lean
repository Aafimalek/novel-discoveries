import NineSeparatedSubsetSums.EightPoint129_126PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct129_126_0_budget :
    FourPointNumeric.packedBudget 20 packedOct129_126_0 383 = 85105612 := by decide +kernel

#print axioms packedOct129_126_0_budget

end NineSeparatedSubsetSums
