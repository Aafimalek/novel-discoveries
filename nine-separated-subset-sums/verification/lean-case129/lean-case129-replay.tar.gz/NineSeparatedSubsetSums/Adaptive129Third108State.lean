import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive129Third108Node0 : CachedSearchNode :=
  ⟨4, 107, computeCenteredMask [148,129,108], 385, 50209⟩

end NineSeparatedSubsetSums
