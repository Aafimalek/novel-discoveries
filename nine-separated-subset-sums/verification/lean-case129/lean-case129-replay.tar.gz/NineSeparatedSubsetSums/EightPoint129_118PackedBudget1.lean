import NineSeparatedSubsetSums.EightPoint129_118PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct129_118_1_budget :
    FourPointNumeric.packedBudget 20 packedOct129_118_1 266 = 77528564 := by decide +kernel

#print axioms packedOct129_118_1_budget

end NineSeparatedSubsetSums
