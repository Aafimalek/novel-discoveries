import NineSeparatedSubsetSums.EightPoint129_124PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct129_124_1_budget :
    FourPointNumeric.packedBudget 20 packedOct129_124_1 394 = 87162526 := by decide +kernel

#print axioms packedOct129_124_1_budget

end NineSeparatedSubsetSums
