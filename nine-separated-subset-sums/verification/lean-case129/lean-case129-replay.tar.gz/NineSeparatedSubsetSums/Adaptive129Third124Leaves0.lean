import NineSeparatedSubsetSums.Adaptive129Third124State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive129Third124Proof0 : runCachedNode 511 124558 Adaptive129Third124Node0 = false := by
  decide +kernel

#print axioms adaptive129Third124Proof0

end NineSeparatedSubsetSums
