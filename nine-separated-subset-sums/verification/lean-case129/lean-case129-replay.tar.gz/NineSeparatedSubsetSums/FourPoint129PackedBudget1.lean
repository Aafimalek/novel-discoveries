import NineSeparatedSubsetSums.FourPoint129PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedWeight129_1_budget :
    FourPointNumeric.packedBudget 19 packedWeight129_1 364 = 69602304 := by decide +kernel

#print axioms packedWeight129_1_budget

end NineSeparatedSubsetSums
