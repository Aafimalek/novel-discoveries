import NineSeparatedSubsetSums.Adaptive129Third125State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive129Third125Proof0 : runCachedNode 511 124737 Adaptive129Third125Node0 = false := by
  decide +kernel

#print axioms adaptive129Third125Proof0

end NineSeparatedSubsetSums
