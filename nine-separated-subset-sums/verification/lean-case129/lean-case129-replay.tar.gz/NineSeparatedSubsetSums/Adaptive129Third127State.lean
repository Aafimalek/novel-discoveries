import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive129Third127Node0 : CachedSearchNode :=
  ⟨4, 126, computeCenteredMask [148,129,127], 404, 54674⟩

end NineSeparatedSubsetSums
