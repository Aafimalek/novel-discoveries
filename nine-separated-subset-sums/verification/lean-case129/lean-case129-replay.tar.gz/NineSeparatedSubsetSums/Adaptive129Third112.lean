import NineSeparatedSubsetSums.Adaptive129Third112Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint129Checked

namespace NineSeparatedSubsetSums


theorem adaptive129Third112 : NoDescendingTailAfterThird 129 112 :=
  noDescendingThirdTail_of_cached 129 112 109587 (fun t ht nd => max148_second129_fourPoint_moment_bound (112::t) (by simp [ht]) nd) adaptive129Third112Proof0

#print axioms adaptive129Third112

end NineSeparatedSubsetSums
