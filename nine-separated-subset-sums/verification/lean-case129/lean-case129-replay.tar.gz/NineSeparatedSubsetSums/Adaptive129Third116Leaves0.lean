import NineSeparatedSubsetSums.Adaptive129Third116State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive129Third116Proof15 : runCachedNode 511 109587 Adaptive129Third116Node15 = false := by
  decide +kernel

#print axioms adaptive129Third116Proof15

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive129Third116Proof14 : runCachedNode 511 109587 Adaptive129Third116Node14 = false := by
  decide +kernel

#print axioms adaptive129Third116Proof14

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive129Third116Proof13 : runCachedNode 511 109587 Adaptive129Third116Node13 = false := by
  decide +kernel

#print axioms adaptive129Third116Proof13

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive129Third116Proof9 : runCachedNode 511 109587 Adaptive129Third116Node9 = false := by
  decide +kernel

#print axioms adaptive129Third116Proof9

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive129Third116Proof6 : runCachedNode 511 109587 Adaptive129Third116Node6 = false := by
  decide +kernel

#print axioms adaptive129Third116Proof6

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive129Third116Proof2 : runCachedNode 511 109587 Adaptive129Third116Node2 = false := by
  decide +kernel

#print axioms adaptive129Third116Proof2

end NineSeparatedSubsetSums
