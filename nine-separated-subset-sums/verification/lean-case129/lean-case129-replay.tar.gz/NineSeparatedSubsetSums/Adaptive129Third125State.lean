import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive129Third125Node0 : CachedSearchNode :=
  ⟨4, 124, computeCenteredMask [148,129,125], 402, 54170⟩

end NineSeparatedSubsetSums
