import NineSeparatedSubsetSums.Adaptive145Third137State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third137Proof181 : runCachedNode 511 130164 Adaptive145Third137Node181 = false := by
  decide +kernel

#print axioms adaptive145Third137Proof181

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third137Proof151 : runCachedNode 511 130164 Adaptive145Third137Node151 = false := by
  decide +kernel

#print axioms adaptive145Third137Proof151

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third137Proof67 : runCachedNode 511 130164 Adaptive145Third137Node67 = false := by
  decide +kernel

#print axioms adaptive145Third137Proof67

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third137Proof1 : runCachedNode 511 130164 Adaptive145Third137Node1 = false := by
  decide +kernel

#print axioms adaptive145Third137Proof1

end NineSeparatedSubsetSums
