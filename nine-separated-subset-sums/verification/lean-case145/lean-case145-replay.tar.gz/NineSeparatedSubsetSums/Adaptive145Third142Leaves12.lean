import NineSeparatedSubsetSums.Adaptive145Third142State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof462 : runCachedNode 511 130865 Adaptive145Third142Node462 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof462

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof696 : runCachedNode 511 130865 Adaptive145Third142Node696 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof696

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof2 : runCachedNode 511 130865 Adaptive145Third142Node2 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof2

end NineSeparatedSubsetSums
