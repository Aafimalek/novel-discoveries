import NineSeparatedSubsetSums.Adaptive145Third141State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third141Proof22 : runCachedNode 511 130740 Adaptive145Third141Node22 = false := by
  decide +kernel

#print axioms adaptive145Third141Proof22

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third141Proof161 : runCachedNode 511 130740 Adaptive145Third141Node161 = false := by
  decide +kernel

#print axioms adaptive145Third141Proof161

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third141Proof166 : runCachedNode 511 130740 Adaptive145Third141Node166 = false := by
  decide +kernel

#print axioms adaptive145Third141Proof166

end NineSeparatedSubsetSums
