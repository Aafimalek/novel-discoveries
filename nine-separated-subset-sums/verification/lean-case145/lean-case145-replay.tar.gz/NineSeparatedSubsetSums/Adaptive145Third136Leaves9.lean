import NineSeparatedSubsetSums.Adaptive145Third136State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third136Proof146 : runCachedNode 511 130013 Adaptive145Third136Node146 = false := by
  decide +kernel

#print axioms adaptive145Third136Proof146

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third136Proof64 : runCachedNode 511 130013 Adaptive145Third136Node64 = false := by
  decide +kernel

#print axioms adaptive145Third136Proof64

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third136Proof66 : runCachedNode 511 130013 Adaptive145Third136Node66 = false := by
  decide +kernel

#print axioms adaptive145Third136Proof66

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third136Proof145 : runCachedNode 511 130013 Adaptive145Third136Node145 = false := by
  decide +kernel

#print axioms adaptive145Third136Proof145

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third136Proof116 : runCachedNode 511 130013 Adaptive145Third136Node116 = false := by
  decide +kernel

#print axioms adaptive145Third136Proof116

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third136Proof11 : runCachedNode 511 130013 Adaptive145Third136Node11 = false := by
  decide +kernel

#print axioms adaptive145Third136Proof11

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third136Proof118 : runCachedNode 511 130013 Adaptive145Third136Node118 = false := by
  decide +kernel

#print axioms adaptive145Third136Proof118

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third136Proof10 : runCachedNode 511 130013 Adaptive145Third136Node10 = false := by
  decide +kernel

#print axioms adaptive145Third136Proof10

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third136Proof144 : runCachedNode 511 130013 Adaptive145Third136Node144 = false := by
  decide +kernel

#print axioms adaptive145Third136Proof144

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third136Proof88 : runCachedNode 511 130013 Adaptive145Third136Node88 = false := by
  decide +kernel

#print axioms adaptive145Third136Proof88

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third136Proof38 : runCachedNode 511 130013 Adaptive145Third136Node38 = false := by
  decide +kernel

#print axioms adaptive145Third136Proof38

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third136Proof90 : runCachedNode 511 130013 Adaptive145Third136Node90 = false := by
  decide +kernel

#print axioms adaptive145Third136Proof90

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third136Proof87 : runCachedNode 511 130013 Adaptive145Third136Node87 = false := by
  decide +kernel

#print axioms adaptive145Third136Proof87

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third136Proof84 : runCachedNode 511 130013 Adaptive145Third136Node84 = false := by
  decide +kernel

#print axioms adaptive145Third136Proof84

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third136Proof72 : runCachedNode 511 130013 Adaptive145Third136Node72 = false := by
  decide +kernel

#print axioms adaptive145Third136Proof72

end NineSeparatedSubsetSums
