import NineSeparatedSubsetSums.Adaptive145Third144State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third144Proof332 : runCachedNode 511 131183 Adaptive145Third144Node332 = false := by
  decide +kernel

#print axioms adaptive145Third144Proof332

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third144Proof622 : runCachedNode 511 131183 Adaptive145Third144Node622 = false := by
  decide +kernel

#print axioms adaptive145Third144Proof622

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third144Proof257 : runCachedNode 511 131183 Adaptive145Third144Node257 = false := by
  decide +kernel

#print axioms adaptive145Third144Proof257

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third144Proof3 : runCachedNode 511 131183 Adaptive145Third144Node3 = false := by
  decide +kernel

#print axioms adaptive145Third144Proof3

end NineSeparatedSubsetSums
