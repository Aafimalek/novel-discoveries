import NineSeparatedSubsetSums.Adaptive145Third135State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third135Proof20 : runCachedNode 511 129879 Adaptive145Third135Node20 = false := by
  decide +kernel

#print axioms adaptive145Third135Proof20

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third135Proof73 : runCachedNode 511 129879 Adaptive145Third135Node73 = false := by
  decide +kernel

#print axioms adaptive145Third135Proof73

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third135Proof35 : runCachedNode 511 129879 Adaptive145Third135Node35 = false := by
  decide +kernel

#print axioms adaptive145Third135Proof35

end NineSeparatedSubsetSums
