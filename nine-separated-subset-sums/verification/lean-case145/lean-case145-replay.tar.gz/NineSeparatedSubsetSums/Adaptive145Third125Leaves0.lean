import NineSeparatedSubsetSums.Adaptive145Third125State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third125Proof0 : runCachedNode 511 127613 Adaptive145Third125Node0 = false := by
  decide +kernel

#print axioms adaptive145Third125Proof0

end NineSeparatedSubsetSums
