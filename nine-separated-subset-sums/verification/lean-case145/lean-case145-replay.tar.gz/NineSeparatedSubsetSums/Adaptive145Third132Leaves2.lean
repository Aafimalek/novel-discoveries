import NineSeparatedSubsetSums.Adaptive145Third132State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third132Proof19 : runCachedNode 511 129338 Adaptive145Third132Node19 = false := by
  decide +kernel

#print axioms adaptive145Third132Proof19

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third132Proof17 : runCachedNode 511 129338 Adaptive145Third132Node17 = false := by
  decide +kernel

#print axioms adaptive145Third132Proof17

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third132Proof11 : runCachedNode 511 129338 Adaptive145Third132Node11 = false := by
  decide +kernel

#print axioms adaptive145Third132Proof11

end NineSeparatedSubsetSums
