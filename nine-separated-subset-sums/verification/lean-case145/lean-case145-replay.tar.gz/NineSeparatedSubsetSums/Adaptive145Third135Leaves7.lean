import NineSeparatedSubsetSums.Adaptive145Third135State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third135Proof12 : runCachedNode 511 129879 Adaptive145Third135Node12 = false := by
  decide +kernel

#print axioms adaptive145Third135Proof12

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third135Proof11 : runCachedNode 511 129879 Adaptive145Third135Node11 = false := by
  decide +kernel

#print axioms adaptive145Third135Proof11

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third135Proof10 : runCachedNode 511 129879 Adaptive145Third135Node10 = false := by
  decide +kernel

#print axioms adaptive145Third135Proof10

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third135Proof71 : runCachedNode 511 129879 Adaptive145Third135Node71 = false := by
  decide +kernel

#print axioms adaptive145Third135Proof71

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third135Proof69 : runCachedNode 511 129879 Adaptive145Third135Node69 = false := by
  decide +kernel

#print axioms adaptive145Third135Proof69

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third135Proof41 : runCachedNode 511 129879 Adaptive145Third135Node41 = false := by
  decide +kernel

#print axioms adaptive145Third135Proof41

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third135Proof68 : runCachedNode 511 129879 Adaptive145Third135Node68 = false := by
  decide +kernel

#print axioms adaptive145Third135Proof68

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third135Proof40 : runCachedNode 511 129879 Adaptive145Third135Node40 = false := by
  decide +kernel

#print axioms adaptive145Third135Proof40

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third135Proof45 : runCachedNode 511 129879 Adaptive145Third135Node45 = false := by
  decide +kernel

#print axioms adaptive145Third135Proof45

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third135Proof67 : runCachedNode 511 129879 Adaptive145Third135Node67 = false := by
  decide +kernel

#print axioms adaptive145Third135Proof67

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third135Proof9 : runCachedNode 511 129879 Adaptive145Third135Node9 = false := by
  decide +kernel

#print axioms adaptive145Third135Proof9

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third135Proof42 : runCachedNode 511 129879 Adaptive145Third135Node42 = false := by
  decide +kernel

#print axioms adaptive145Third135Proof42

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third135Proof8 : runCachedNode 511 129879 Adaptive145Third135Node8 = false := by
  decide +kernel

#print axioms adaptive145Third135Proof8

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third135Proof38 : runCachedNode 511 129879 Adaptive145Third135Node38 = false := by
  decide +kernel

#print axioms adaptive145Third135Proof38

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third135Proof65 : runCachedNode 511 129879 Adaptive145Third135Node65 = false := by
  decide +kernel

#print axioms adaptive145Third135Proof65

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third135Proof66 : runCachedNode 511 129879 Adaptive145Third135Node66 = false := by
  decide +kernel

#print axioms adaptive145Third135Proof66

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third135Proof39 : runCachedNode 511 129879 Adaptive145Third135Node39 = false := by
  decide +kernel

#print axioms adaptive145Third135Proof39

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third135Proof37 : runCachedNode 511 129879 Adaptive145Third135Node37 = false := by
  decide +kernel

#print axioms adaptive145Third135Proof37

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third135Proof7 : runCachedNode 511 129879 Adaptive145Third135Node7 = false := by
  decide +kernel

#print axioms adaptive145Third135Proof7

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third135Proof57 : runCachedNode 511 129879 Adaptive145Third135Node57 = false := by
  decide +kernel

#print axioms adaptive145Third135Proof57

end NineSeparatedSubsetSums
