import NineSeparatedSubsetSums.Adaptive145Third142State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof254 : runCachedNode 511 130865 Adaptive145Third142Node254 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof254

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof651 : runCachedNode 511 130865 Adaptive145Third142Node651 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof651

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof460 : runCachedNode 511 130865 Adaptive145Third142Node460 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof460

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof118 : runCachedNode 511 130865 Adaptive145Third142Node118 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof118

end NineSeparatedSubsetSums
