import NineSeparatedSubsetSums.Adaptive145Third139State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third139Proof69 : runCachedNode 511 130465 Adaptive145Third139Node69 = false := by
  decide +kernel

#print axioms adaptive145Third139Proof69

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third139Proof11 : runCachedNode 511 130465 Adaptive145Third139Node11 = false := by
  decide +kernel

#print axioms adaptive145Third139Proof11

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third139Proof187 : runCachedNode 511 130465 Adaptive145Third139Node187 = false := by
  decide +kernel

#print axioms adaptive145Third139Proof187

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third139Proof219 : runCachedNode 511 130465 Adaptive145Third139Node219 = false := by
  decide +kernel

#print axioms adaptive145Third139Proof219

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third139Proof41 : runCachedNode 511 130465 Adaptive145Third139Node41 = false := by
  decide +kernel

#print axioms adaptive145Third139Proof41

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third139Proof90 : runCachedNode 511 130465 Adaptive145Third139Node90 = false := by
  decide +kernel

#print axioms adaptive145Third139Proof90

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third139Proof152 : runCachedNode 511 130465 Adaptive145Third139Node152 = false := by
  decide +kernel

#print axioms adaptive145Third139Proof152

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third139Proof183 : runCachedNode 511 130465 Adaptive145Third139Node183 = false := by
  decide +kernel

#print axioms adaptive145Third139Proof183

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third139Proof215 : runCachedNode 511 130465 Adaptive145Third139Node215 = false := by
  decide +kernel

#print axioms adaptive145Third139Proof215

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third139Proof151 : runCachedNode 511 130465 Adaptive145Third139Node151 = false := by
  decide +kernel

#print axioms adaptive145Third139Proof151

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third139Proof40 : runCachedNode 511 130465 Adaptive145Third139Node40 = false := by
  decide +kernel

#print axioms adaptive145Third139Proof40

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third139Proof36 : runCachedNode 511 130465 Adaptive145Third139Node36 = false := by
  decide +kernel

#print axioms adaptive145Third139Proof36

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third139Proof66 : runCachedNode 511 130465 Adaptive145Third139Node66 = false := by
  decide +kernel

#print axioms adaptive145Third139Proof66

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third139Proof61 : runCachedNode 511 130465 Adaptive145Third139Node61 = false := by
  decide +kernel

#print axioms adaptive145Third139Proof61

end NineSeparatedSubsetSums
