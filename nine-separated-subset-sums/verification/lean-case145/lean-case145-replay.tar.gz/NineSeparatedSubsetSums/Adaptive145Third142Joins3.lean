import NineSeparatedSubsetSums.Adaptive145Third142State
import NineSeparatedSubsetSums.Adaptive145Third142Leaves83
import NineSeparatedSubsetSums.Adaptive145Third142Leaves84
import NineSeparatedSubsetSums.Adaptive145Third142Leaves81
import NineSeparatedSubsetSums.Adaptive145Third142Leaves80
import NineSeparatedSubsetSums.Adaptive145Third142Leaves79
import NineSeparatedSubsetSums.Adaptive145Third142Leaves78
import NineSeparatedSubsetSums.Adaptive145Third142Leaves77
import NineSeparatedSubsetSums.Adaptive145Third142Leaves76
import NineSeparatedSubsetSums.Adaptive145Third142Leaves75
import NineSeparatedSubsetSums.Adaptive145Third142Leaves74
import NineSeparatedSubsetSums.Adaptive145Third142Leaves72
import NineSeparatedSubsetSums.Adaptive145Third142Leaves71
import NineSeparatedSubsetSums.Adaptive145Third142Leaves70
import NineSeparatedSubsetSums.Adaptive145Third142Leaves73
import NineSeparatedSubsetSums.Adaptive145Third142Leaves69
import NineSeparatedSubsetSums.Adaptive145Third142Leaves68
import NineSeparatedSubsetSums.Adaptive145Third142Leaves65
import NineSeparatedSubsetSums.Adaptive145Third142Leaves64
import NineSeparatedSubsetSums.Adaptive145Third142Leaves61
import NineSeparatedSubsetSums.Adaptive145Third142Leaves58
import NineSeparatedSubsetSums.Adaptive145Third142Leaves50
import NineSeparatedSubsetSums.Adaptive145Third142Leaves44
import NineSeparatedSubsetSums.Adaptive145Third142Leaves33
import NineSeparatedSubsetSums.Adaptive145Third142Leaves66
import NineSeparatedSubsetSums.Adaptive145Third142Leaves67
import NineSeparatedSubsetSums.Adaptive145Third142Leaves63
import NineSeparatedSubsetSums.Adaptive145Third142Leaves62
import NineSeparatedSubsetSums.Adaptive145Third142Leaves59
import NineSeparatedSubsetSums.Adaptive145Third142Leaves56
import NineSeparatedSubsetSums.Adaptive145Third142Leaves51
import NineSeparatedSubsetSums.Adaptive145Third142Leaves47
import NineSeparatedSubsetSums.Adaptive145Third142Leaves42
import NineSeparatedSubsetSums.Adaptive145Third142Leaves13
import NineSeparatedSubsetSums.Adaptive145Third142Leaves20
import NineSeparatedSubsetSums.Adaptive145Third142Leaves26
import NineSeparatedSubsetSums.Adaptive145Third142Leaves60
import NineSeparatedSubsetSums.Adaptive145Third142Leaves5
import NineSeparatedSubsetSums.Adaptive145Third142Leaves38
import NineSeparatedSubsetSums.Adaptive145Third142Leaves46
import NineSeparatedSubsetSums.Adaptive145Third142Leaves45
import NineSeparatedSubsetSums.Adaptive145Third142Leaves43
import NineSeparatedSubsetSums.Adaptive145Third142Leaves21
import NineSeparatedSubsetSums.Adaptive145Third142Leaves10
import NineSeparatedSubsetSums.Adaptive145Third142Leaves29
import NineSeparatedSubsetSums.Adaptive145Third142Leaves6
import NineSeparatedSubsetSums.Adaptive145Third142Joins2
import NineSeparatedSubsetSums.Adaptive145Third142Leaves11
import NineSeparatedSubsetSums.Adaptive145Third142Leaves12
import NineSeparatedSubsetSums.Adaptive145Third142Leaves35
import NineSeparatedSubsetSums.Adaptive145Third142Leaves9
import NineSeparatedSubsetSums.Adaptive145Third142Leaves34
import NineSeparatedSubsetSums.Adaptive145Third142Leaves57
import NineSeparatedSubsetSums.Adaptive145Third142Leaves52
import NineSeparatedSubsetSums.Adaptive145Third142Leaves41
import NineSeparatedSubsetSums.Adaptive145Third142Leaves22
import NineSeparatedSubsetSums.Adaptive145Third142Leaves18
import NineSeparatedSubsetSums.Adaptive145Third142Leaves15
import NineSeparatedSubsetSums.Adaptive145Third142Leaves8
import NineSeparatedSubsetSums.Adaptive145Third142Joins0
import NineSeparatedSubsetSums.Adaptive145Third142Joins1

namespace NineSeparatedSubsetSums

theorem adaptive145Third142Proof861 : runCachedNode 511 130865 Adaptive145Third142Node861 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130865 Adaptive145Third142Node861 = [87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 128, 129, 132] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive145Third142Proof862
  · exact adaptive145Third142Proof863
  · exact adaptive145Third142Proof864
  · exact adaptive145Third142Proof865
  · exact adaptive145Third142Proof866
  · exact adaptive145Third142Proof867
  · exact adaptive145Third142Proof868
  · exact adaptive145Third142Proof869
  · exact adaptive145Third142Proof870
  · exact adaptive145Third142Proof871
  · exact adaptive145Third142Proof872
  · exact adaptive145Third142Proof873
  · exact adaptive145Third142Proof874
  · exact adaptive145Third142Proof875
  · exact adaptive145Third142Proof876
  · exact adaptive145Third142Proof877
  · exact adaptive145Third142Proof878
  · exact adaptive145Third142Proof879
  · exact adaptive145Third142Proof880
  · exact adaptive145Third142Proof881
  · exact adaptive145Third142Proof882
  · exact adaptive145Third142Proof883
  · exact adaptive145Third142Proof884
  · exact adaptive145Third142Proof885
  · exact adaptive145Third142Proof886
  · exact adaptive145Third142Proof887
  · exact adaptive145Third142Proof888
  · exact adaptive145Third142Proof889
  · exact adaptive145Third142Proof890
  · exact adaptive145Third142Proof891
  · exact adaptive145Third142Proof892
  · exact adaptive145Third142Proof893
  · exact adaptive145Third142Proof894
  · exact adaptive145Third142Proof895
  · exact adaptive145Third142Proof896
  · exact adaptive145Third142Proof897
  · exact adaptive145Third142Proof898
  · exact adaptive145Third142Proof899
  · exact adaptive145Third142Proof900
  · exact adaptive145Third142Proof901
  · exact adaptive145Third142Proof902
  · exact adaptive145Third142Proof903
  · exact adaptive145Third142Proof904

#print axioms adaptive145Third142Proof861

theorem adaptive145Third142Proof905 : runCachedNode 511 130865 Adaptive145Third142Node905 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130865 Adaptive145Third142Node905 = [86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 131, 132] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive145Third142Proof906
  · exact adaptive145Third142Proof907
  · exact adaptive145Third142Proof908
  · exact adaptive145Third142Proof909
  · exact adaptive145Third142Proof910
  · exact adaptive145Third142Proof911
  · exact adaptive145Third142Proof912
  · exact adaptive145Third142Proof913
  · exact adaptive145Third142Proof914
  · exact adaptive145Third142Proof915
  · exact adaptive145Third142Proof916
  · exact adaptive145Third142Proof917
  · exact adaptive145Third142Proof918
  · exact adaptive145Third142Proof919
  · exact adaptive145Third142Proof920
  · exact adaptive145Third142Proof921
  · exact adaptive145Third142Proof922
  · exact adaptive145Third142Proof923
  · exact adaptive145Third142Proof924
  · exact adaptive145Third142Proof925
  · exact adaptive145Third142Proof926
  · exact adaptive145Third142Proof927
  · exact adaptive145Third142Proof928
  · exact adaptive145Third142Proof929
  · exact adaptive145Third142Proof930
  · exact adaptive145Third142Proof931
  · exact adaptive145Third142Proof932
  · exact adaptive145Third142Proof933
  · exact adaptive145Third142Proof934
  · exact adaptive145Third142Proof935
  · exact adaptive145Third142Proof936
  · exact adaptive145Third142Proof937
  · exact adaptive145Third142Proof938
  · exact adaptive145Third142Proof939
  · exact adaptive145Third142Proof940
  · exact adaptive145Third142Proof941
  · exact adaptive145Third142Proof942
  · exact adaptive145Third142Proof943
  · exact adaptive145Third142Proof944
  · exact adaptive145Third142Proof945
  · exact adaptive145Third142Proof946
  · exact adaptive145Third142Proof947
  · exact adaptive145Third142Proof948
  · exact adaptive145Third142Proof949
  · exact adaptive145Third142Proof950
  · exact adaptive145Third142Proof951

#print axioms adaptive145Third142Proof905

theorem adaptive145Third142Proof783 : runCachedNode 511 130865 Adaptive145Third142Node783 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130865 Adaptive145Third142Node783 = [100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 132, 133, 134, 136, 137, 140] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive145Third142Proof784
  · exact adaptive145Third142Proof785
  · exact adaptive145Third142Proof786
  · exact adaptive145Third142Proof787
  · exact adaptive145Third142Proof788
  · exact adaptive145Third142Proof789
  · exact adaptive145Third142Proof790
  · exact adaptive145Third142Proof791
  · exact adaptive145Third142Proof792
  · exact adaptive145Third142Proof793
  · exact adaptive145Third142Proof794
  · exact adaptive145Third142Proof795
  · exact adaptive145Third142Proof796
  · exact adaptive145Third142Proof797
  · exact adaptive145Third142Proof798
  · exact adaptive145Third142Proof799
  · exact adaptive145Third142Proof800
  · exact adaptive145Third142Proof801
  · exact adaptive145Third142Proof802
  · exact adaptive145Third142Proof803
  · exact adaptive145Third142Proof804
  · exact adaptive145Third142Proof805
  · exact adaptive145Third142Proof806
  · exact adaptive145Third142Proof807
  · exact adaptive145Third142Proof808
  · exact adaptive145Third142Proof809
  · exact adaptive145Third142Proof810
  · exact adaptive145Third142Proof811
  · exact adaptive145Third142Proof812
  · exact adaptive145Third142Proof813
  · exact adaptive145Third142Proof814
  · exact adaptive145Third142Proof815
  · exact adaptive145Third142Proof816
  · exact adaptive145Third142Proof817
  · exact adaptive145Third142Proof818
  · exact adaptive145Third142Proof819
  · exact adaptive145Third142Proof861
  · exact adaptive145Third142Proof905

#print axioms adaptive145Third142Proof783

theorem adaptive145Third142Proof0 : runCachedNode 511 130865 Adaptive145Third142Node0 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130865 Adaptive145Third142Node0 = [109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 132, 133, 134, 135, 136, 137, 138, 140, 141] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive145Third142Proof1
  · exact adaptive145Third142Proof2
  · exact adaptive145Third142Proof3
  · exact adaptive145Third142Proof4
  · exact adaptive145Third142Proof5
  · exact adaptive145Third142Proof6
  · exact adaptive145Third142Proof7
  · exact adaptive145Third142Proof8
  · exact adaptive145Third142Proof9
  · exact adaptive145Third142Proof10
  · exact adaptive145Third142Proof11
  · exact adaptive145Third142Proof12
  · exact adaptive145Third142Proof13
  · exact adaptive145Third142Proof14
  · exact adaptive145Third142Proof15
  · exact adaptive145Third142Proof16
  · exact adaptive145Third142Proof17
  · exact adaptive145Third142Proof18
  · exact adaptive145Third142Proof19
  · exact adaptive145Third142Proof41
  · exact adaptive145Third142Proof64
  · exact adaptive145Third142Proof88
  · exact adaptive145Third142Proof114
  · exact adaptive145Third142Proof141
  · exact adaptive145Third142Proof169
  · exact adaptive145Third142Proof198
  · exact adaptive145Third142Proof229
  · exact adaptive145Third142Proof261
  · exact adaptive145Third142Proof433
  · exact adaptive145Third142Proof508
  · exact adaptive145Third142Proof623
  · exact adaptive145Third142Proof783

#print axioms adaptive145Third142Proof0

end NineSeparatedSubsetSums
