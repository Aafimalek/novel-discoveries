import NineSeparatedSubsetSums.Adaptive145Third144State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third144Proof228 : runCachedNode 511 131183 Adaptive145Third144Node228 = false := by
  decide +kernel

#print axioms adaptive145Third144Proof228

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third144Proof230 : runCachedNode 511 131183 Adaptive145Third144Node230 = false := by
  decide +kernel

#print axioms adaptive145Third144Proof230

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third144Proof112 : runCachedNode 511 131183 Adaptive145Third144Node112 = false := by
  decide +kernel

#print axioms adaptive145Third144Proof112

end NineSeparatedSubsetSums
