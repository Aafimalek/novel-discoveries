import NineSeparatedSubsetSums.Adaptive145Third140State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third140Proof101 : runCachedNode 511 130597 Adaptive145Third140Node101 = false := by
  decide +kernel

#print axioms adaptive145Third140Proof101

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third140Proof303 : runCachedNode 511 130597 Adaptive145Third140Node303 = false := by
  decide +kernel

#print axioms adaptive145Third140Proof303

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third140Proof191 : runCachedNode 511 130597 Adaptive145Third140Node191 = false := by
  decide +kernel

#print axioms adaptive145Third140Proof191

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third140Proof158 : runCachedNode 511 130597 Adaptive145Third140Node158 = false := by
  decide +kernel

#print axioms adaptive145Third140Proof158

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third140Proof224 : runCachedNode 511 130597 Adaptive145Third140Node224 = false := by
  decide +kernel

#print axioms adaptive145Third140Proof224

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third140Proof232 : runCachedNode 511 130597 Adaptive145Third140Node232 = false := by
  decide +kernel

#print axioms adaptive145Third140Proof232

end NineSeparatedSubsetSums
