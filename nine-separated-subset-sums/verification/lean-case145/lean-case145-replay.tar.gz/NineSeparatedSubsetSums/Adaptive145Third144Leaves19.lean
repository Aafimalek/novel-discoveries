import NineSeparatedSubsetSums.Adaptive145Third144State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third144Proof334 : runCachedNode 511 131183 Adaptive145Third144Node334 = false := by
  decide +kernel

#print axioms adaptive145Third144Proof334

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third144Proof197 : runCachedNode 511 131183 Adaptive145Third144Node197 = false := by
  decide +kernel

#print axioms adaptive145Third144Proof197

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third144Proof98 : runCachedNode 511 131183 Adaptive145Third144Node98 = false := by
  decide +kernel

#print axioms adaptive145Third144Proof98

end NineSeparatedSubsetSums
