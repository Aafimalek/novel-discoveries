import NineSeparatedSubsetSums.Adaptive145Third126State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third126Proof15 : runCachedNode 511 127918 Adaptive145Third126Node15 = false := by
  decide +kernel

#print axioms adaptive145Third126Proof15

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third126Proof14 : runCachedNode 511 127918 Adaptive145Third126Node14 = false := by
  decide +kernel

#print axioms adaptive145Third126Proof14

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third126Proof13 : runCachedNode 511 127918 Adaptive145Third126Node13 = false := by
  decide +kernel

#print axioms adaptive145Third126Proof13

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third126Proof11 : runCachedNode 511 127918 Adaptive145Third126Node11 = false := by
  decide +kernel

#print axioms adaptive145Third126Proof11

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third126Proof12 : runCachedNode 511 127918 Adaptive145Third126Node12 = false := by
  decide +kernel

#print axioms adaptive145Third126Proof12

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third126Proof10 : runCachedNode 511 127918 Adaptive145Third126Node10 = false := by
  decide +kernel

#print axioms adaptive145Third126Proof10

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third126Proof9 : runCachedNode 511 127918 Adaptive145Third126Node9 = false := by
  decide +kernel

#print axioms adaptive145Third126Proof9

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third126Proof8 : runCachedNode 511 127918 Adaptive145Third126Node8 = false := by
  decide +kernel

#print axioms adaptive145Third126Proof8

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third126Proof7 : runCachedNode 511 127918 Adaptive145Third126Node7 = false := by
  decide +kernel

#print axioms adaptive145Third126Proof7

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third126Proof6 : runCachedNode 511 127918 Adaptive145Third126Node6 = false := by
  decide +kernel

#print axioms adaptive145Third126Proof6

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third126Proof4 : runCachedNode 511 127918 Adaptive145Third126Node4 = false := by
  decide +kernel

#print axioms adaptive145Third126Proof4

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third126Proof3 : runCachedNode 511 127918 Adaptive145Third126Node3 = false := by
  decide +kernel

#print axioms adaptive145Third126Proof3

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third126Proof2 : runCachedNode 511 127918 Adaptive145Third126Node2 = false := by
  decide +kernel

#print axioms adaptive145Third126Proof2

end NineSeparatedSubsetSums
