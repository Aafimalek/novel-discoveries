import NineSeparatedSubsetSums.Adaptive145Third138State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third138Proof193 : runCachedNode 511 130311 Adaptive145Third138Node193 = false := by
  decide +kernel

#print axioms adaptive145Third138Proof193

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third138Proof72 : runCachedNode 511 130311 Adaptive145Third138Node72 = false := by
  decide +kernel

#print axioms adaptive145Third138Proof72

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third138Proof59 : runCachedNode 511 130311 Adaptive145Third138Node59 = false := by
  decide +kernel

#print axioms adaptive145Third138Proof59

end NineSeparatedSubsetSums
