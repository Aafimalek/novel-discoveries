import NineSeparatedSubsetSums.Adaptive145Third142State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof815 : runCachedNode 511 130865 Adaptive145Third142Node815 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof815

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof813 : runCachedNode 511 130865 Adaptive145Third142Node813 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof813

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof7 : runCachedNode 511 130865 Adaptive145Third142Node7 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof7

end NineSeparatedSubsetSums
