import NineSeparatedSubsetSums.Adaptive145Third138State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third138Proof129 : runCachedNode 511 130311 Adaptive145Third138Node129 = false := by
  decide +kernel

#print axioms adaptive145Third138Proof129

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third138Proof16 : runCachedNode 511 130311 Adaptive145Third138Node16 = false := by
  decide +kernel

#print axioms adaptive145Third138Proof16

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third138Proof126 : runCachedNode 511 130311 Adaptive145Third138Node126 = false := by
  decide +kernel

#print axioms adaptive145Third138Proof126

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third138Proof91 : runCachedNode 511 130311 Adaptive145Third138Node91 = false := by
  decide +kernel

#print axioms adaptive145Third138Proof91

end NineSeparatedSubsetSums
