import NineSeparatedSubsetSums.Adaptive145Third140State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third140Proof193 : runCachedNode 511 130597 Adaptive145Third140Node193 = false := by
  decide +kernel

#print axioms adaptive145Third140Proof193

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third140Proof99 : runCachedNode 511 130597 Adaptive145Third140Node99 = false := by
  decide +kernel

#print axioms adaptive145Third140Proof99

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third140Proof241 : runCachedNode 511 130597 Adaptive145Third140Node241 = false := by
  decide +kernel

#print axioms adaptive145Third140Proof241

end NineSeparatedSubsetSums
