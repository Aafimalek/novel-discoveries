import NineSeparatedSubsetSums.Adaptive145Third141State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third141Proof123 : runCachedNode 511 130740 Adaptive145Third141Node123 = false := by
  decide +kernel

#print axioms adaptive145Third141Proof123

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third141Proof417 : runCachedNode 511 130740 Adaptive145Third141Node417 = false := by
  decide +kernel

#print axioms adaptive145Third141Proof417

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third141Proof218 : runCachedNode 511 130740 Adaptive145Third141Node218 = false := by
  decide +kernel

#print axioms adaptive145Third141Proof218

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third141Proof13 : runCachedNode 511 130740 Adaptive145Third141Node13 = false := by
  decide +kernel

#print axioms adaptive145Third141Proof13

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third141Proof220 : runCachedNode 511 130740 Adaptive145Third141Node220 = false := by
  decide +kernel

#print axioms adaptive145Third141Proof220

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third141Proof155 : runCachedNode 511 130740 Adaptive145Third141Node155 = false := by
  decide +kernel

#print axioms adaptive145Third141Proof155

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third141Proof157 : runCachedNode 511 130740 Adaptive145Third141Node157 = false := by
  decide +kernel

#print axioms adaptive145Third141Proof157

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third141Proof184 : runCachedNode 511 130740 Adaptive145Third141Node184 = false := by
  decide +kernel

#print axioms adaptive145Third141Proof184

end NineSeparatedSubsetSums
