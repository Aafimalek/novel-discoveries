import NineSeparatedSubsetSums.Adaptive145Third136State
import NineSeparatedSubsetSums.Adaptive145Third136Leaves12
import NineSeparatedSubsetSums.Adaptive145Third136Leaves11
import NineSeparatedSubsetSums.Adaptive145Third136Leaves4
import NineSeparatedSubsetSums.Adaptive145Third136Leaves10
import NineSeparatedSubsetSums.Adaptive145Third136Leaves9
import NineSeparatedSubsetSums.Adaptive145Third136Leaves5
import NineSeparatedSubsetSums.Adaptive145Third136Leaves7
import NineSeparatedSubsetSums.Adaptive145Third136Leaves8
import NineSeparatedSubsetSums.Adaptive145Third136Leaves6
import NineSeparatedSubsetSums.Adaptive145Third136Leaves3
import NineSeparatedSubsetSums.Adaptive145Third136Leaves0
import NineSeparatedSubsetSums.Adaptive145Third136Leaves2
import NineSeparatedSubsetSums.Adaptive145Third136Leaves1

namespace NineSeparatedSubsetSums

theorem adaptive145Third136Proof21 : runCachedNode 511 130013 Adaptive145Third136Node21 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130013 Adaptive145Third136Node21 = [104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 119, 120, 122, 123, 124, 125, 126, 128, 129] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive145Third136Proof22
  · exact adaptive145Third136Proof23
  · exact adaptive145Third136Proof24
  · exact adaptive145Third136Proof25
  · exact adaptive145Third136Proof26
  · exact adaptive145Third136Proof27
  · exact adaptive145Third136Proof28
  · exact adaptive145Third136Proof29
  · exact adaptive145Third136Proof30
  · exact adaptive145Third136Proof31
  · exact adaptive145Third136Proof32
  · exact adaptive145Third136Proof33
  · exact adaptive145Third136Proof34
  · exact adaptive145Third136Proof35
  · exact adaptive145Third136Proof36
  · exact adaptive145Third136Proof37
  · exact adaptive145Third136Proof38
  · exact adaptive145Third136Proof39
  · exact adaptive145Third136Proof40
  · exact adaptive145Third136Proof41
  · exact adaptive145Third136Proof42
  · exact adaptive145Third136Proof43
  · exact adaptive145Third136Proof44

#print axioms adaptive145Third136Proof21

theorem adaptive145Third136Proof45 : runCachedNode 511 130013 Adaptive145Third136Node45 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130013 Adaptive145Third136Node45 = [104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 120, 121, 123, 124, 125, 126, 127, 129, 130] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive145Third136Proof46
  · exact adaptive145Third136Proof47
  · exact adaptive145Third136Proof48
  · exact adaptive145Third136Proof49
  · exact adaptive145Third136Proof50
  · exact adaptive145Third136Proof51
  · exact adaptive145Third136Proof52
  · exact adaptive145Third136Proof53
  · exact adaptive145Third136Proof54
  · exact adaptive145Third136Proof55
  · exact adaptive145Third136Proof56
  · exact adaptive145Third136Proof57
  · exact adaptive145Third136Proof58
  · exact adaptive145Third136Proof59
  · exact adaptive145Third136Proof60
  · exact adaptive145Third136Proof61
  · exact adaptive145Third136Proof62
  · exact adaptive145Third136Proof63
  · exact adaptive145Third136Proof64
  · exact adaptive145Third136Proof65
  · exact adaptive145Third136Proof66
  · exact adaptive145Third136Proof67
  · exact adaptive145Third136Proof68
  · exact adaptive145Third136Proof69

#print axioms adaptive145Third136Proof45

theorem adaptive145Third136Proof70 : runCachedNode 511 130013 Adaptive145Third136Node70 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130013 Adaptive145Third136Node70 = [104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 121, 122, 124, 125, 126, 127, 128, 130, 131] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive145Third136Proof71
  · exact adaptive145Third136Proof72
  · exact adaptive145Third136Proof73
  · exact adaptive145Third136Proof74
  · exact adaptive145Third136Proof75
  · exact adaptive145Third136Proof76
  · exact adaptive145Third136Proof77
  · exact adaptive145Third136Proof78
  · exact adaptive145Third136Proof79
  · exact adaptive145Third136Proof80
  · exact adaptive145Third136Proof81
  · exact adaptive145Third136Proof82
  · exact adaptive145Third136Proof83
  · exact adaptive145Third136Proof84
  · exact adaptive145Third136Proof85
  · exact adaptive145Third136Proof86
  · exact adaptive145Third136Proof87
  · exact adaptive145Third136Proof88
  · exact adaptive145Third136Proof89
  · exact adaptive145Third136Proof90
  · exact adaptive145Third136Proof91
  · exact adaptive145Third136Proof92
  · exact adaptive145Third136Proof93
  · exact adaptive145Third136Proof94
  · exact adaptive145Third136Proof95

#print axioms adaptive145Third136Proof70

theorem adaptive145Third136Proof96 : runCachedNode 511 130013 Adaptive145Third136Node96 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130013 Adaptive145Third136Node96 = [103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 123, 124, 126, 127, 128, 129, 130, 132] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive145Third136Proof97
  · exact adaptive145Third136Proof98
  · exact adaptive145Third136Proof99
  · exact adaptive145Third136Proof100
  · exact adaptive145Third136Proof101
  · exact adaptive145Third136Proof102
  · exact adaptive145Third136Proof103
  · exact adaptive145Third136Proof104
  · exact adaptive145Third136Proof105
  · exact adaptive145Third136Proof106
  · exact adaptive145Third136Proof107
  · exact adaptive145Third136Proof108
  · exact adaptive145Third136Proof109
  · exact adaptive145Third136Proof110
  · exact adaptive145Third136Proof111
  · exact adaptive145Third136Proof112
  · exact adaptive145Third136Proof113
  · exact adaptive145Third136Proof114
  · exact adaptive145Third136Proof115
  · exact adaptive145Third136Proof116
  · exact adaptive145Third136Proof117
  · exact adaptive145Third136Proof118
  · exact adaptive145Third136Proof119
  · exact adaptive145Third136Proof120
  · exact adaptive145Third136Proof121
  · exact adaptive145Third136Proof122
  · exact adaptive145Third136Proof123

#print axioms adaptive145Third136Proof96

theorem adaptive145Third136Proof124 : runCachedNode 511 130013 Adaptive145Third136Node124 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130013 Adaptive145Third136Node124 = [103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 124, 125, 127, 128, 129, 130, 131, 134] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive145Third136Proof125
  · exact adaptive145Third136Proof126
  · exact adaptive145Third136Proof127
  · exact adaptive145Third136Proof128
  · exact adaptive145Third136Proof129
  · exact adaptive145Third136Proof130
  · exact adaptive145Third136Proof131
  · exact adaptive145Third136Proof132
  · exact adaptive145Third136Proof133
  · exact adaptive145Third136Proof134
  · exact adaptive145Third136Proof135
  · exact adaptive145Third136Proof136
  · exact adaptive145Third136Proof137
  · exact adaptive145Third136Proof138
  · exact adaptive145Third136Proof139
  · exact adaptive145Third136Proof140
  · exact adaptive145Third136Proof141
  · exact adaptive145Third136Proof142
  · exact adaptive145Third136Proof143
  · exact adaptive145Third136Proof144
  · exact adaptive145Third136Proof145
  · exact adaptive145Third136Proof146
  · exact adaptive145Third136Proof147
  · exact adaptive145Third136Proof148
  · exact adaptive145Third136Proof149
  · exact adaptive145Third136Proof150
  · exact adaptive145Third136Proof151
  · exact adaptive145Third136Proof152

#print axioms adaptive145Third136Proof124

theorem adaptive145Third136Proof0 : runCachedNode 511 130013 Adaptive145Third136Node0 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130013 Adaptive145Third136Node0 = [110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 132, 134, 135] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive145Third136Proof1
  · exact adaptive145Third136Proof2
  · exact adaptive145Third136Proof3
  · exact adaptive145Third136Proof4
  · exact adaptive145Third136Proof5
  · exact adaptive145Third136Proof6
  · exact adaptive145Third136Proof7
  · exact adaptive145Third136Proof8
  · exact adaptive145Third136Proof9
  · exact adaptive145Third136Proof10
  · exact adaptive145Third136Proof11
  · exact adaptive145Third136Proof12
  · exact adaptive145Third136Proof13
  · exact adaptive145Third136Proof14
  · exact adaptive145Third136Proof15
  · exact adaptive145Third136Proof16
  · exact adaptive145Third136Proof17
  · exact adaptive145Third136Proof18
  · exact adaptive145Third136Proof19
  · exact adaptive145Third136Proof20
  · exact adaptive145Third136Proof21
  · exact adaptive145Third136Proof45
  · exact adaptive145Third136Proof70
  · exact adaptive145Third136Proof96
  · exact adaptive145Third136Proof124

#print axioms adaptive145Third136Proof0

end NineSeparatedSubsetSums
