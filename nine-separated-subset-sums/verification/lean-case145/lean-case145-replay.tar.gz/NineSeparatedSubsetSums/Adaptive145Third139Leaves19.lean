import NineSeparatedSubsetSums.Adaptive145Third139State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third139Proof132 : runCachedNode 511 130465 Adaptive145Third139Node132 = false := by
  decide +kernel

#print axioms adaptive145Third139Proof132

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third139Proof133 : runCachedNode 511 130465 Adaptive145Third139Node133 = false := by
  decide +kernel

#print axioms adaptive145Third139Proof133

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third139Proof134 : runCachedNode 511 130465 Adaptive145Third139Node134 = false := by
  decide +kernel

#print axioms adaptive145Third139Proof134

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third139Proof164 : runCachedNode 511 130465 Adaptive145Third139Node164 = false := by
  decide +kernel

#print axioms adaptive145Third139Proof164

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third139Proof165 : runCachedNode 511 130465 Adaptive145Third139Node165 = false := by
  decide +kernel

#print axioms adaptive145Third139Proof165

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third139Proof166 : runCachedNode 511 130465 Adaptive145Third139Node166 = false := by
  decide +kernel

#print axioms adaptive145Third139Proof166

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third139Proof197 : runCachedNode 511 130465 Adaptive145Third139Node197 = false := by
  decide +kernel

#print axioms adaptive145Third139Proof197

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third139Proof198 : runCachedNode 511 130465 Adaptive145Third139Node198 = false := by
  decide +kernel

#print axioms adaptive145Third139Proof198

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third139Proof162 : runCachedNode 511 130465 Adaptive145Third139Node162 = false := by
  decide +kernel

#print axioms adaptive145Third139Proof162

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third139Proof163 : runCachedNode 511 130465 Adaptive145Third139Node163 = false := by
  decide +kernel

#print axioms adaptive145Third139Proof163

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third139Proof194 : runCachedNode 511 130465 Adaptive145Third139Node194 = false := by
  decide +kernel

#print axioms adaptive145Third139Proof194

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third139Proof195 : runCachedNode 511 130465 Adaptive145Third139Node195 = false := by
  decide +kernel

#print axioms adaptive145Third139Proof195

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third139Proof196 : runCachedNode 511 130465 Adaptive145Third139Node196 = false := by
  decide +kernel

#print axioms adaptive145Third139Proof196

end NineSeparatedSubsetSums
