import NineSeparatedSubsetSums.Adaptive145Third144State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third144Proof494 : runCachedNode 511 131183 Adaptive145Third144Node494 = false := by
  decide +kernel

#print axioms adaptive145Third144Proof494

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third144Proof764 : runCachedNode 511 131183 Adaptive145Third144Node764 = false := by
  decide +kernel

#print axioms adaptive145Third144Proof764

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third144Proof164 : runCachedNode 511 131183 Adaptive145Third144Node164 = false := by
  decide +kernel

#print axioms adaptive145Third144Proof164

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third144Proof26 : runCachedNode 511 131183 Adaptive145Third144Node26 = false := by
  decide +kernel

#print axioms adaptive145Third144Proof26

end NineSeparatedSubsetSums
