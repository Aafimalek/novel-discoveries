import NineSeparatedSubsetSums.Adaptive145Third119State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third119Proof0 : runCachedNode 511 126245 Adaptive145Third119Node0 = false := by
  decide +kernel

#print axioms adaptive145Third119Proof0

end NineSeparatedSubsetSums
