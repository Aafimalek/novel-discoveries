import NineSeparatedSubsetSums.Adaptive145Third142State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof228 : runCachedNode 511 130865 Adaptive145Third142Node228 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof228

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof950 : runCachedNode 511 130865 Adaptive145Third142Node950 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof950

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof73 : runCachedNode 511 130865 Adaptive145Third142Node73 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof73

end NineSeparatedSubsetSums
