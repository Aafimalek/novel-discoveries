import NineSeparatedSubsetSums.Adaptive145Third139State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third139Proof39 : runCachedNode 511 130465 Adaptive145Third139Node39 = false := by
  decide +kernel

#print axioms adaptive145Third139Proof39

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third139Proof10 : runCachedNode 511 130465 Adaptive145Third139Node10 = false := by
  decide +kernel

#print axioms adaptive145Third139Proof10

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third139Proof121 : runCachedNode 511 130465 Adaptive145Third139Node121 = false := by
  decide +kernel

#print axioms adaptive145Third139Proof121

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third139Proof214 : runCachedNode 511 130465 Adaptive145Third139Node214 = false := by
  decide +kernel

#print axioms adaptive145Third139Proof214

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third139Proof38 : runCachedNode 511 130465 Adaptive145Third139Node38 = false := by
  decide +kernel

#print axioms adaptive145Third139Proof38

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third139Proof37 : runCachedNode 511 130465 Adaptive145Third139Node37 = false := by
  decide +kernel

#print axioms adaptive145Third139Proof37

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third139Proof88 : runCachedNode 511 130465 Adaptive145Third139Node88 = false := by
  decide +kernel

#print axioms adaptive145Third139Proof88

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third139Proof119 : runCachedNode 511 130465 Adaptive145Third139Node119 = false := by
  decide +kernel

#print axioms adaptive145Third139Proof119

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third139Proof212 : runCachedNode 511 130465 Adaptive145Third139Node212 = false := by
  decide +kernel

#print axioms adaptive145Third139Proof212

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third139Proof123 : runCachedNode 511 130465 Adaptive145Third139Node123 = false := by
  decide +kernel

#print axioms adaptive145Third139Proof123

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third139Proof180 : runCachedNode 511 130465 Adaptive145Third139Node180 = false := by
  decide +kernel

#print axioms adaptive145Third139Proof180

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third139Proof87 : runCachedNode 511 130465 Adaptive145Third139Node87 = false := by
  decide +kernel

#print axioms adaptive145Third139Proof87

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third139Proof63 : runCachedNode 511 130465 Adaptive145Third139Node63 = false := by
  decide +kernel

#print axioms adaptive145Third139Proof63

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third139Proof65 : runCachedNode 511 130465 Adaptive145Third139Node65 = false := by
  decide +kernel

#print axioms adaptive145Third139Proof65

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third139Proof86 : runCachedNode 511 130465 Adaptive145Third139Node86 = false := by
  decide +kernel

#print axioms adaptive145Third139Proof86

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third139Proof9 : runCachedNode 511 130465 Adaptive145Third139Node9 = false := by
  decide +kernel

#print axioms adaptive145Third139Proof9

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third139Proof153 : runCachedNode 511 130465 Adaptive145Third139Node153 = false := by
  decide +kernel

#print axioms adaptive145Third139Proof153

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third139Proof149 : runCachedNode 511 130465 Adaptive145Third139Node149 = false := by
  decide +kernel

#print axioms adaptive145Third139Proof149

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third139Proof148 : runCachedNode 511 130465 Adaptive145Third139Node148 = false := by
  decide +kernel

#print axioms adaptive145Third139Proof148

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third139Proof184 : runCachedNode 511 130465 Adaptive145Third139Node184 = false := by
  decide +kernel

#print axioms adaptive145Third139Proof184

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third139Proof5 : runCachedNode 511 130465 Adaptive145Third139Node5 = false := by
  decide +kernel

#print axioms adaptive145Third139Proof5

end NineSeparatedSubsetSums
