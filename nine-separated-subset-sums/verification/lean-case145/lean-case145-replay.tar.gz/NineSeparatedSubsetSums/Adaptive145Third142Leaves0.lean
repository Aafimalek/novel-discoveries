import NineSeparatedSubsetSums.Adaptive145Third142State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof319 : runCachedNode 511 130865 Adaptive145Third142Node319 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof319

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof523 : runCachedNode 511 130865 Adaptive145Third142Node523 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof523

end NineSeparatedSubsetSums
