import NineSeparatedSubsetSums.Adaptive145Third143State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof162 : runCachedNode 511 131040 Adaptive145Third143Node162 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof162

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof495 : runCachedNode 511 131040 Adaptive145Third143Node495 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof495

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof134 : runCachedNode 511 131040 Adaptive145Third143Node134 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof134

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof578 : runCachedNode 511 131040 Adaptive145Third143Node578 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof578

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof270 : runCachedNode 511 131040 Adaptive145Third143Node270 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof270

end NineSeparatedSubsetSums
