import NineSeparatedSubsetSums.Adaptive145Third144State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third144Proof22 : runCachedNode 511 131183 Adaptive145Third144Node22 = false := by
  decide +kernel

#print axioms adaptive145Third144Proof22

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third144Proof154 : runCachedNode 511 131183 Adaptive145Third144Node154 = false := by
  decide +kernel

#print axioms adaptive145Third144Proof154

end NineSeparatedSubsetSums
