import NineSeparatedSubsetSums.Adaptive145Third142State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof14 : runCachedNode 511 130865 Adaptive145Third142Node14 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof14

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof195 : runCachedNode 511 130865 Adaptive145Third142Node195 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof195

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof193 : runCachedNode 511 130865 Adaptive145Third142Node193 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof193

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof5 : runCachedNode 511 130865 Adaptive145Third142Node5 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof5

end NineSeparatedSubsetSums
