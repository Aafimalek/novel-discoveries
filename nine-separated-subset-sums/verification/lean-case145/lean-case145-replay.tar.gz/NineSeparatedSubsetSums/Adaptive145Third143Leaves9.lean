import NineSeparatedSubsetSums.Adaptive145Third143State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof262 : runCachedNode 511 131040 Adaptive145Third143Node262 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof262

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof194 : runCachedNode 511 131040 Adaptive145Third143Node194 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof194

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof27 : runCachedNode 511 131040 Adaptive145Third143Node27 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof27

end NineSeparatedSubsetSums
