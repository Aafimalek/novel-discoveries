import NineSeparatedSubsetSums.Adaptive145Third141State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third141Proof227 : runCachedNode 511 130740 Adaptive145Third141Node227 = false := by
  decide +kernel

#print axioms adaptive145Third141Proof227

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third141Proof222 : runCachedNode 511 130740 Adaptive145Third141Node222 = false := by
  decide +kernel

#print axioms adaptive145Third141Proof222

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third141Proof74 : runCachedNode 511 130740 Adaptive145Third141Node74 = false := by
  decide +kernel

#print axioms adaptive145Third141Proof74

end NineSeparatedSubsetSums
