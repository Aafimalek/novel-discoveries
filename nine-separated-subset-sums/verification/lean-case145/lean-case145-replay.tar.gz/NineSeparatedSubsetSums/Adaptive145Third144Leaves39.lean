import NineSeparatedSubsetSums.Adaptive145Third144State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third144Proof161 : runCachedNode 511 131183 Adaptive145Third144Node161 = false := by
  decide +kernel

#print axioms adaptive145Third144Proof161

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third144Proof541 : runCachedNode 511 131183 Adaptive145Third144Node541 = false := by
  decide +kernel

#print axioms adaptive145Third144Proof541

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third144Proof328 : runCachedNode 511 131183 Adaptive145Third144Node328 = false := by
  decide +kernel

#print axioms adaptive145Third144Proof328

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third144Proof372 : runCachedNode 511 131183 Adaptive145Third144Node372 = false := by
  decide +kernel

#print axioms adaptive145Third144Proof372

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third144Proof671 : runCachedNode 511 131183 Adaptive145Third144Node671 = false := by
  decide +kernel

#print axioms adaptive145Third144Proof671

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third144Proof97 : runCachedNode 511 131183 Adaptive145Third144Node97 = false := by
  decide +kernel

#print axioms adaptive145Third144Proof97

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third144Proof52 : runCachedNode 511 131183 Adaptive145Third144Node52 = false := by
  decide +kernel

#print axioms adaptive145Third144Proof52

end NineSeparatedSubsetSums
