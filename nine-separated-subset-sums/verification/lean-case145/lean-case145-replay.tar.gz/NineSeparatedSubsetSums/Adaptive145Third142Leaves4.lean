import NineSeparatedSubsetSums.Adaptive145Third142State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof317 : runCachedNode 511 130865 Adaptive145Third142Node317 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof317

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof779 : runCachedNode 511 130865 Adaptive145Third142Node779 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof779

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof324 : runCachedNode 511 130865 Adaptive145Third142Node324 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof324

end NineSeparatedSubsetSums
