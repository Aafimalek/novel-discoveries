import NineSeparatedSubsetSums.Adaptive145Third143State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof165 : runCachedNode 511 131040 Adaptive145Third143Node165 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof165

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof227 : runCachedNode 511 131040 Adaptive145Third143Node227 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof227

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof96 : runCachedNode 511 131040 Adaptive145Third143Node96 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof96

end NineSeparatedSubsetSums
