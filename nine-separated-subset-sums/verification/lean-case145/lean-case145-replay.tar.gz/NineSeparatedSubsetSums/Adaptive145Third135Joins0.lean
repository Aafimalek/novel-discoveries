import NineSeparatedSubsetSums.Adaptive145Third135State
import NineSeparatedSubsetSums.Adaptive145Third135Leaves8
import NineSeparatedSubsetSums.Adaptive145Third135Leaves2
import NineSeparatedSubsetSums.Adaptive145Third135Leaves3
import NineSeparatedSubsetSums.Adaptive145Third135Leaves4
import NineSeparatedSubsetSums.Adaptive145Third135Leaves1
import NineSeparatedSubsetSums.Adaptive145Third135Leaves7
import NineSeparatedSubsetSums.Adaptive145Third135Leaves6
import NineSeparatedSubsetSums.Adaptive145Third135Leaves0
import NineSeparatedSubsetSums.Adaptive145Third135Leaves5

namespace NineSeparatedSubsetSums

theorem adaptive145Third135Proof23 : runCachedNode 511 129879 Adaptive145Third135Node23 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 129879 Adaptive145Third135Node23 = [104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 121, 122, 124, 125, 126, 127, 128, 129, 131] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive145Third135Proof24
  · exact adaptive145Third135Proof25
  · exact adaptive145Third135Proof26
  · exact adaptive145Third135Proof27
  · exact adaptive145Third135Proof28
  · exact adaptive145Third135Proof29
  · exact adaptive145Third135Proof30
  · exact adaptive145Third135Proof31
  · exact adaptive145Third135Proof32
  · exact adaptive145Third135Proof33
  · exact adaptive145Third135Proof34
  · exact adaptive145Third135Proof35
  · exact adaptive145Third135Proof36
  · exact adaptive145Third135Proof37
  · exact adaptive145Third135Proof38
  · exact adaptive145Third135Proof39
  · exact adaptive145Third135Proof40
  · exact adaptive145Third135Proof41
  · exact adaptive145Third135Proof42
  · exact adaptive145Third135Proof43
  · exact adaptive145Third135Proof44
  · exact adaptive145Third135Proof45
  · exact adaptive145Third135Proof46
  · exact adaptive145Third135Proof47
  · exact adaptive145Third135Proof48

#print axioms adaptive145Third135Proof23

theorem adaptive145Third135Proof49 : runCachedNode 511 129879 Adaptive145Third135Node49 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 129879 Adaptive145Third135Node49 = [103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 122, 123, 125, 126, 127, 128, 129, 130, 133] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive145Third135Proof50
  · exact adaptive145Third135Proof51
  · exact adaptive145Third135Proof52
  · exact adaptive145Third135Proof53
  · exact adaptive145Third135Proof54
  · exact adaptive145Third135Proof55
  · exact adaptive145Third135Proof56
  · exact adaptive145Third135Proof57
  · exact adaptive145Third135Proof58
  · exact adaptive145Third135Proof59
  · exact adaptive145Third135Proof60
  · exact adaptive145Third135Proof61
  · exact adaptive145Third135Proof62
  · exact adaptive145Third135Proof63
  · exact adaptive145Third135Proof64
  · exact adaptive145Third135Proof65
  · exact adaptive145Third135Proof66
  · exact adaptive145Third135Proof67
  · exact adaptive145Third135Proof68
  · exact adaptive145Third135Proof69
  · exact adaptive145Third135Proof70
  · exact adaptive145Third135Proof71
  · exact adaptive145Third135Proof72
  · exact adaptive145Third135Proof73
  · exact adaptive145Third135Proof74
  · exact adaptive145Third135Proof75
  · exact adaptive145Third135Proof76

#print axioms adaptive145Third135Proof49

theorem adaptive145Third135Proof0 : runCachedNode 511 129879 Adaptive145Third135Node0 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 129879 Adaptive145Third135Node0 = [110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 133, 134] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive145Third135Proof1
  · exact adaptive145Third135Proof2
  · exact adaptive145Third135Proof3
  · exact adaptive145Third135Proof4
  · exact adaptive145Third135Proof5
  · exact adaptive145Third135Proof6
  · exact adaptive145Third135Proof7
  · exact adaptive145Third135Proof8
  · exact adaptive145Third135Proof9
  · exact adaptive145Third135Proof10
  · exact adaptive145Third135Proof11
  · exact adaptive145Third135Proof12
  · exact adaptive145Third135Proof13
  · exact adaptive145Third135Proof14
  · exact adaptive145Third135Proof15
  · exact adaptive145Third135Proof16
  · exact adaptive145Third135Proof17
  · exact adaptive145Third135Proof18
  · exact adaptive145Third135Proof19
  · exact adaptive145Third135Proof20
  · exact adaptive145Third135Proof21
  · exact adaptive145Third135Proof22
  · exact adaptive145Third135Proof23
  · exact adaptive145Third135Proof49

#print axioms adaptive145Third135Proof0

end NineSeparatedSubsetSums
