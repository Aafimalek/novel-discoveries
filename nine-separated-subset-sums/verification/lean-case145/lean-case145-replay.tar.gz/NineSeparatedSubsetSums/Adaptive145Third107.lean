import NineSeparatedSubsetSums.Adaptive145Third107Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint145Checked

namespace NineSeparatedSubsetSums


theorem adaptive145Third107 : NoDescendingTailAfterThird 145 107 :=
  noDescendingThirdTail_of_cached 145 107 112442 (fun t ht nd => max148_second145_fourPoint_moment_bound (107::t) (by simp [ht]) nd) adaptive145Third107Proof0

#print axioms adaptive145Third107

end NineSeparatedSubsetSums
