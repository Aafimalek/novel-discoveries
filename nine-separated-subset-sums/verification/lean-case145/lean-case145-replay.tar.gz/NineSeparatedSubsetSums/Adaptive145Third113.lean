import NineSeparatedSubsetSums.Adaptive145Third113Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint145Checked

namespace NineSeparatedSubsetSums


theorem adaptive145Third113 : NoDescendingTailAfterThird 145 113 :=
  noDescendingThirdTail_of_cached 145 113 112442 (fun t ht nd => max148_second145_fourPoint_moment_bound (113::t) (by simp [ht]) nd) adaptive145Third113Proof0

#print axioms adaptive145Third113

end NineSeparatedSubsetSums
