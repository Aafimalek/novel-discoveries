import NineSeparatedSubsetSums.Adaptive145Third142State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof655 : runCachedNode 511 130865 Adaptive145Third142Node655 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof655

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof112 : runCachedNode 511 130865 Adaptive145Third142Node112 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof112

end NineSeparatedSubsetSums
