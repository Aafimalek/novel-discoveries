import NineSeparatedSubsetSums.Adaptive145Third144State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third144Proof301 : runCachedNode 511 131183 Adaptive145Third144Node301 = false := by
  decide +kernel

#print axioms adaptive145Third144Proof301

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third144Proof165 : runCachedNode 511 131183 Adaptive145Third144Node165 = false := by
  decide +kernel

#print axioms adaptive145Third144Proof165

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third144Proof484 : runCachedNode 511 131183 Adaptive145Third144Node484 = false := by
  decide +kernel

#print axioms adaptive145Third144Proof484

end NineSeparatedSubsetSums
