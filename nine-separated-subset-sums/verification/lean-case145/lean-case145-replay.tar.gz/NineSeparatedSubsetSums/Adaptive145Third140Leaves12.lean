import NineSeparatedSubsetSums.Adaptive145Third140State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third140Proof225 : runCachedNode 511 130597 Adaptive145Third140Node225 = false := by
  decide +kernel

#print axioms adaptive145Third140Proof225

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third140Proof74 : runCachedNode 511 130597 Adaptive145Third140Node74 = false := by
  decide +kernel

#print axioms adaptive145Third140Proof74

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third140Proof15 : runCachedNode 511 130597 Adaptive145Third140Node15 = false := by
  decide +kernel

#print axioms adaptive145Third140Proof15

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third140Proof36 : runCachedNode 511 130597 Adaptive145Third140Node36 = false := by
  decide +kernel

#print axioms adaptive145Third140Proof36

end NineSeparatedSubsetSums
