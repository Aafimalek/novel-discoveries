import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive145Third112Node0 : CachedSearchNode :=
  ⟨4, 111, computeCenteredMask [148,145,112], 405, 55473⟩

end NineSeparatedSubsetSums
