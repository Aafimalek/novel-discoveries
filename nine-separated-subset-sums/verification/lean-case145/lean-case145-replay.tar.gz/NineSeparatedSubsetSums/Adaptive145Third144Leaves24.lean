import NineSeparatedSubsetSums.Adaptive145Third144State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third144Proof620 : runCachedNode 511 131183 Adaptive145Third144Node620 = false := by
  decide +kernel

#print axioms adaptive145Third144Proof620

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third144Proof459 : runCachedNode 511 131183 Adaptive145Third144Node459 = false := by
  decide +kernel

#print axioms adaptive145Third144Proof459

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third144Proof414 : runCachedNode 511 131183 Adaptive145Third144Node414 = false := by
  decide +kernel

#print axioms adaptive145Third144Proof414

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third144Proof136 : runCachedNode 511 131183 Adaptive145Third144Node136 = false := by
  decide +kernel

#print axioms adaptive145Third144Proof136

end NineSeparatedSubsetSums
