import NineSeparatedSubsetSums.Adaptive145Third140State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third140Proof98 : runCachedNode 511 130597 Adaptive145Third140Node98 = false := by
  decide +kernel

#print axioms adaptive145Third140Proof98

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third140Proof95 : runCachedNode 511 130597 Adaptive145Third140Node95 = false := by
  decide +kernel

#print axioms adaptive145Third140Proof95

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third140Proof215 : runCachedNode 511 130597 Adaptive145Third140Node215 = false := by
  decide +kernel

#print axioms adaptive145Third140Proof215

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third140Proof186 : runCachedNode 511 130597 Adaptive145Third140Node186 = false := by
  decide +kernel

#print axioms adaptive145Third140Proof186

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third140Proof65 : runCachedNode 511 130597 Adaptive145Third140Node65 = false := by
  decide +kernel

#print axioms adaptive145Third140Proof65

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third140Proof299 : runCachedNode 511 130597 Adaptive145Third140Node299 = false := by
  decide +kernel

#print axioms adaptive145Third140Proof299

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third140Proof252 : runCachedNode 511 130597 Adaptive145Third140Node252 = false := by
  decide +kernel

#print axioms adaptive145Third140Proof252

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third140Proof41 : runCachedNode 511 130597 Adaptive145Third140Node41 = false := by
  decide +kernel

#print axioms adaptive145Third140Proof41

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third140Proof63 : runCachedNode 511 130597 Adaptive145Third140Node63 = false := by
  decide +kernel

#print axioms adaptive145Third140Proof63

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third140Proof150 : runCachedNode 511 130597 Adaptive145Third140Node150 = false := by
  decide +kernel

#print axioms adaptive145Third140Proof150

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third140Proof94 : runCachedNode 511 130597 Adaptive145Third140Node94 = false := by
  decide +kernel

#print axioms adaptive145Third140Proof94

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third140Proof251 : runCachedNode 511 130597 Adaptive145Third140Node251 = false := by
  decide +kernel

#print axioms adaptive145Third140Proof251

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third140Proof298 : runCachedNode 511 130597 Adaptive145Third140Node298 = false := by
  decide +kernel

#print axioms adaptive145Third140Proof298

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third140Proof10 : runCachedNode 511 130597 Adaptive145Third140Node10 = false := by
  decide +kernel

#print axioms adaptive145Third140Proof10

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third140Proof216 : runCachedNode 511 130597 Adaptive145Third140Node216 = false := by
  decide +kernel

#print axioms adaptive145Third140Proof216

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third140Proof184 : runCachedNode 511 130597 Adaptive145Third140Node184 = false := by
  decide +kernel

#print axioms adaptive145Third140Proof184

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third140Proof185 : runCachedNode 511 130597 Adaptive145Third140Node185 = false := by
  decide +kernel

#print axioms adaptive145Third140Proof185

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third140Proof234 : runCachedNode 511 130597 Adaptive145Third140Node234 = false := by
  decide +kernel

#print axioms adaptive145Third140Proof234

end NineSeparatedSubsetSums
