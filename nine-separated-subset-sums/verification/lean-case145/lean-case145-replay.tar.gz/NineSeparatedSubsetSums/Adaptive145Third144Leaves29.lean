import NineSeparatedSubsetSums.Adaptive145Third144State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third144Proof229 : runCachedNode 511 131183 Adaptive145Third144Node229 = false := by
  decide +kernel

#print axioms adaptive145Third144Proof229

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third144Proof196 : runCachedNode 511 131183 Adaptive145Third144Node196 = false := by
  decide +kernel

#print axioms adaptive145Third144Proof196

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third144Proof104 : runCachedNode 511 131183 Adaptive145Third144Node104 = false := by
  decide +kernel

#print axioms adaptive145Third144Proof104

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third144Proof61 : runCachedNode 511 131183 Adaptive145Third144Node61 = false := by
  decide +kernel

#print axioms adaptive145Third144Proof61

end NineSeparatedSubsetSums
