import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive145Third119Node0 : CachedSearchNode :=
  ⟨4, 118, computeCenteredMask [148,145,119], 412, 57090⟩

end NineSeparatedSubsetSums
