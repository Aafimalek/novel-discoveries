import NineSeparatedSubsetSums.Adaptive145Third143State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof255 : runCachedNode 511 131040 Adaptive145Third143Node255 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof255

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof13 : runCachedNode 511 131040 Adaptive145Third143Node13 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof13

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof589 : runCachedNode 511 131040 Adaptive145Third143Node589 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof589

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof103 : runCachedNode 511 131040 Adaptive145Third143Node103 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof103

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof490 : runCachedNode 511 131040 Adaptive145Third143Node490 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof490

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof545 : runCachedNode 511 131040 Adaptive145Third143Node545 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof545

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof304 : runCachedNode 511 131040 Adaptive145Third143Node304 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof304

end NineSeparatedSubsetSums
