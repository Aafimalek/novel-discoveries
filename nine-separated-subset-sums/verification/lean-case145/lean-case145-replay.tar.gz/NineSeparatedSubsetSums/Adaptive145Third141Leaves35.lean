import NineSeparatedSubsetSums.Adaptive145Third141State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third141Proof306 : runCachedNode 511 130740 Adaptive145Third141Node306 = false := by
  decide +kernel

#print axioms adaptive145Third141Proof306

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third141Proof307 : runCachedNode 511 130740 Adaptive145Third141Node307 = false := by
  decide +kernel

#print axioms adaptive145Third141Proof307

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third141Proof308 : runCachedNode 511 130740 Adaptive145Third141Node308 = false := by
  decide +kernel

#print axioms adaptive145Third141Proof308

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third141Proof309 : runCachedNode 511 130740 Adaptive145Third141Node309 = false := by
  decide +kernel

#print axioms adaptive145Third141Proof309

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third141Proof343 : runCachedNode 511 130740 Adaptive145Third141Node343 = false := by
  decide +kernel

#print axioms adaptive145Third141Proof343

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third141Proof344 : runCachedNode 511 130740 Adaptive145Third141Node344 = false := by
  decide +kernel

#print axioms adaptive145Third141Proof344

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third141Proof345 : runCachedNode 511 130740 Adaptive145Third141Node345 = false := by
  decide +kernel

#print axioms adaptive145Third141Proof345

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third141Proof346 : runCachedNode 511 130740 Adaptive145Third141Node346 = false := by
  decide +kernel

#print axioms adaptive145Third141Proof346

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third141Proof378 : runCachedNode 511 130740 Adaptive145Third141Node378 = false := by
  decide +kernel

#print axioms adaptive145Third141Proof378

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third141Proof379 : runCachedNode 511 130740 Adaptive145Third141Node379 = false := by
  decide +kernel

#print axioms adaptive145Third141Proof379

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third141Proof380 : runCachedNode 511 130740 Adaptive145Third141Node380 = false := by
  decide +kernel

#print axioms adaptive145Third141Proof380

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third141Proof381 : runCachedNode 511 130740 Adaptive145Third141Node381 = false := by
  decide +kernel

#print axioms adaptive145Third141Proof381

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third141Proof382 : runCachedNode 511 130740 Adaptive145Third141Node382 = false := by
  decide +kernel

#print axioms adaptive145Third141Proof382

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third141Proof383 : runCachedNode 511 130740 Adaptive145Third141Node383 = false := by
  decide +kernel

#print axioms adaptive145Third141Proof383

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third141Proof384 : runCachedNode 511 130740 Adaptive145Third141Node384 = false := by
  decide +kernel

#print axioms adaptive145Third141Proof384

end NineSeparatedSubsetSums
