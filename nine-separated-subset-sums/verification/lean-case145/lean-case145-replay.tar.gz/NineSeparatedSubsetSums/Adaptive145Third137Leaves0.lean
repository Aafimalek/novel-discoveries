import NineSeparatedSubsetSums.Adaptive145Third137State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third137Proof43 : runCachedNode 511 130164 Adaptive145Third137Node43 = false := by
  decide +kernel

#print axioms adaptive145Third137Proof43

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third137Proof175 : runCachedNode 511 130164 Adaptive145Third137Node175 = false := by
  decide +kernel

#print axioms adaptive145Third137Proof175

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third137Proof48 : runCachedNode 511 130164 Adaptive145Third137Node48 = false := by
  decide +kernel

#print axioms adaptive145Third137Proof48

end NineSeparatedSubsetSums
