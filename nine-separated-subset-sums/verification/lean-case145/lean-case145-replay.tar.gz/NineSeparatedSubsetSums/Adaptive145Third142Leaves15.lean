import NineSeparatedSubsetSums.Adaptive145Third142State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof17 : runCachedNode 511 130865 Adaptive145Third142Node17 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof17

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof463 : runCachedNode 511 130865 Adaptive145Third142Node463 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof463

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof68 : runCachedNode 511 130865 Adaptive145Third142Node68 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof68

end NineSeparatedSubsetSums
