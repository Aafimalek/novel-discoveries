import NineSeparatedSubsetSums.Adaptive145Third137State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third137Proof17 : runCachedNode 511 130164 Adaptive145Third137Node17 = false := by
  decide +kernel

#print axioms adaptive145Third137Proof17

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third137Proof18 : runCachedNode 511 130164 Adaptive145Third137Node18 = false := by
  decide +kernel

#print axioms adaptive145Third137Proof18

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third137Proof82 : runCachedNode 511 130164 Adaptive145Third137Node82 = false := by
  decide +kernel

#print axioms adaptive145Third137Proof82

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third137Proof70 : runCachedNode 511 130164 Adaptive145Third137Node70 = false := by
  decide +kernel

#print axioms adaptive145Third137Proof70

end NineSeparatedSubsetSums
