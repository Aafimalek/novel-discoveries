import NineSeparatedSubsetSums.Adaptive145Third133State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third133Proof18 : runCachedNode 511 129495 Adaptive145Third133Node18 = false := by
  decide +kernel

#print axioms adaptive145Third133Proof18

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third133Proof19 : runCachedNode 511 129495 Adaptive145Third133Node19 = false := by
  decide +kernel

#print axioms adaptive145Third133Proof19

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third133Proof5 : runCachedNode 511 129495 Adaptive145Third133Node5 = false := by
  decide +kernel

#print axioms adaptive145Third133Proof5

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third133Proof28 : runCachedNode 511 129495 Adaptive145Third133Node28 = false := by
  decide +kernel

#print axioms adaptive145Third133Proof28

end NineSeparatedSubsetSums
