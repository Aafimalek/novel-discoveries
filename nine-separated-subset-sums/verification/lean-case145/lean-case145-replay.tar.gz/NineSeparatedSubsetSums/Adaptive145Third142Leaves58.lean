import NineSeparatedSubsetSums.Adaptive145Third142State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof804 : runCachedNode 511 130865 Adaptive145Third142Node804 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof804

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof901 : runCachedNode 511 130865 Adaptive145Third142Node901 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof901

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof312 : runCachedNode 511 130865 Adaptive145Third142Node312 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof312

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof159 : runCachedNode 511 130865 Adaptive145Third142Node159 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof159

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof218 : runCachedNode 511 130865 Adaptive145Third142Node218 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof218

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof351 : runCachedNode 511 130865 Adaptive145Third142Node351 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof351

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof503 : runCachedNode 511 130865 Adaptive145Third142Node503 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof503

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof644 : runCachedNode 511 130865 Adaptive145Third142Node644 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof644

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof693 : runCachedNode 511 130865 Adaptive145Third142Node693 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof693

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof33 : runCachedNode 511 130865 Adaptive145Third142Node33 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof33

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof395 : runCachedNode 511 130865 Adaptive145Third142Node395 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof395

end NineSeparatedSubsetSums
