import NineSeparatedSubsetSums.Adaptive145Third143State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof101 : runCachedNode 511 131040 Adaptive145Third143Node101 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof101

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof338 : runCachedNode 511 131040 Adaptive145Third143Node338 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof338

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof192 : runCachedNode 511 131040 Adaptive145Third143Node192 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof192

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof305 : runCachedNode 511 131040 Adaptive145Third143Node305 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof305

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof409 : runCachedNode 511 131040 Adaptive145Third143Node409 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof409

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof193 : runCachedNode 511 131040 Adaptive145Third143Node193 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof193

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof138 : runCachedNode 511 131040 Adaptive145Third143Node138 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof138

end NineSeparatedSubsetSums
