import NineSeparatedSubsetSums.Adaptive145Third140State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third140Proof262 : runCachedNode 511 130597 Adaptive145Third140Node262 = false := by
  decide +kernel

#print axioms adaptive145Third140Proof262

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third140Proof103 : runCachedNode 511 130597 Adaptive145Third140Node103 = false := by
  decide +kernel

#print axioms adaptive145Third140Proof103

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third140Proof198 : runCachedNode 511 130597 Adaptive145Third140Node198 = false := by
  decide +kernel

#print axioms adaptive145Third140Proof198

end NineSeparatedSubsetSums
