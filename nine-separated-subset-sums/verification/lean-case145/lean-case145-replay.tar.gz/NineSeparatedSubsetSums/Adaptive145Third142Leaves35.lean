import NineSeparatedSubsetSums.Adaptive145Third142State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof282 : runCachedNode 511 130865 Adaptive145Third142Node282 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof282

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof194 : runCachedNode 511 130865 Adaptive145Third142Node194 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof194

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof168 : runCachedNode 511 130865 Adaptive145Third142Node168 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof168

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof3 : runCachedNode 511 130865 Adaptive145Third142Node3 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof3

end NineSeparatedSubsetSums
