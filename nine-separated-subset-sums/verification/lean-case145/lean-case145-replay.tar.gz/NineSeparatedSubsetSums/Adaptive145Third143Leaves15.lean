import NineSeparatedSubsetSums.Adaptive145Third143State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof341 : runCachedNode 511 131040 Adaptive145Third143Node341 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof341

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof197 : runCachedNode 511 131040 Adaptive145Third143Node197 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof197

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof268 : runCachedNode 511 131040 Adaptive145Third143Node268 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof268

end NineSeparatedSubsetSums
