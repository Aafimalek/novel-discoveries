import NineSeparatedSubsetSums.Adaptive145Third140State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third140Proof226 : runCachedNode 511 130597 Adaptive145Third140Node226 = false := by
  decide +kernel

#print axioms adaptive145Third140Proof226

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third140Proof19 : runCachedNode 511 130597 Adaptive145Third140Node19 = false := by
  decide +kernel

#print axioms adaptive145Third140Proof19

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third140Proof57 : runCachedNode 511 130597 Adaptive145Third140Node57 = false := by
  decide +kernel

#print axioms adaptive145Third140Proof57

end NineSeparatedSubsetSums
