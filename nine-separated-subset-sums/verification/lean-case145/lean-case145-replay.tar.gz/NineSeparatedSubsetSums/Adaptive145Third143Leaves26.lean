import NineSeparatedSubsetSums.Adaptive145Third143State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof16 : runCachedNode 511 131040 Adaptive145Third143Node16 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof16

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof258 : runCachedNode 511 131040 Adaptive145Third143Node258 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof258

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof306 : runCachedNode 511 131040 Adaptive145Third143Node306 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof306

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof583 : runCachedNode 511 131040 Adaptive145Third143Node583 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof583

end NineSeparatedSubsetSums
