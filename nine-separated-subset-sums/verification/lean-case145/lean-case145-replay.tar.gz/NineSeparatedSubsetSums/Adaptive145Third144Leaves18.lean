import NineSeparatedSubsetSums.Adaptive145Third144State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third144Proof590 : runCachedNode 511 131183 Adaptive145Third144Node590 = false := by
  decide +kernel

#print axioms adaptive145Third144Proof590

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third144Proof495 : runCachedNode 511 131183 Adaptive145Third144Node495 = false := by
  decide +kernel

#print axioms adaptive145Third144Proof495

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third144Proof693 : runCachedNode 511 131183 Adaptive145Third144Node693 = false := by
  decide +kernel

#print axioms adaptive145Third144Proof693

end NineSeparatedSubsetSums
