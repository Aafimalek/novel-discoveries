import NineSeparatedSubsetSums.Adaptive145Third134State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third134Proof19 : runCachedNode 511 129715 Adaptive145Third134Node19 = false := by
  decide +kernel

#print axioms adaptive145Third134Proof19

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third134Proof16 : runCachedNode 511 129715 Adaptive145Third134Node16 = false := by
  decide +kernel

#print axioms adaptive145Third134Proof16

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third134Proof7 : runCachedNode 511 129715 Adaptive145Third134Node7 = false := by
  decide +kernel

#print axioms adaptive145Third134Proof7

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third134Proof2 : runCachedNode 511 129715 Adaptive145Third134Node2 = false := by
  decide +kernel

#print axioms adaptive145Third134Proof2

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third134Proof24 : runCachedNode 511 129715 Adaptive145Third134Node24 = false := by
  decide +kernel

#print axioms adaptive145Third134Proof24

end NineSeparatedSubsetSums
