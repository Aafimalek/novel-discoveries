import NineSeparatedSubsetSums.Adaptive145Third140State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third140Proof194 : runCachedNode 511 130597 Adaptive145Third140Node194 = false := by
  decide +kernel

#print axioms adaptive145Third140Proof194

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third140Proof160 : runCachedNode 511 130597 Adaptive145Third140Node160 = false := by
  decide +kernel

#print axioms adaptive145Third140Proof160

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third140Proof281 : runCachedNode 511 130597 Adaptive145Third140Node281 = false := by
  decide +kernel

#print axioms adaptive145Third140Proof281

end NineSeparatedSubsetSums
