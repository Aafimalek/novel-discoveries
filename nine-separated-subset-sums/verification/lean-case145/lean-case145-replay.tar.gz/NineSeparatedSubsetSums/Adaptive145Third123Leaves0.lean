import NineSeparatedSubsetSums.Adaptive145Third123State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third123Proof0 : runCachedNode 511 127036 Adaptive145Third123Node0 = false := by
  decide +kernel

#print axioms adaptive145Third123Proof0

end NineSeparatedSubsetSums
