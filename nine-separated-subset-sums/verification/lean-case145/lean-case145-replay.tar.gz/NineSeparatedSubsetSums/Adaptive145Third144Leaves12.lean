import NineSeparatedSubsetSums.Adaptive145Third144State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third144Proof496 : runCachedNode 511 131183 Adaptive145Third144Node496 = false := by
  decide +kernel

#print axioms adaptive145Third144Proof496

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third144Proof260 : runCachedNode 511 131183 Adaptive145Third144Node260 = false := by
  decide +kernel

#print axioms adaptive145Third144Proof260

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third144Proof106 : runCachedNode 511 131183 Adaptive145Third144Node106 = false := by
  decide +kernel

#print axioms adaptive145Third144Proof106

end NineSeparatedSubsetSums
