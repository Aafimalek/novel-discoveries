import NineSeparatedSubsetSums.Adaptive145Third139State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third139Proof15 : runCachedNode 511 130465 Adaptive145Third139Node15 = false := by
  decide +kernel

#print axioms adaptive145Third139Proof15

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third139Proof95 : runCachedNode 511 130465 Adaptive145Third139Node95 = false := by
  decide +kernel

#print axioms adaptive145Third139Proof95

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third139Proof158 : runCachedNode 511 130465 Adaptive145Third139Node158 = false := by
  decide +kernel

#print axioms adaptive145Third139Proof158

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third139Proof14 : runCachedNode 511 130465 Adaptive145Third139Node14 = false := by
  decide +kernel

#print axioms adaptive145Third139Proof14

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third139Proof44 : runCachedNode 511 130465 Adaptive145Third139Node44 = false := by
  decide +kernel

#print axioms adaptive145Third139Proof44

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third139Proof93 : runCachedNode 511 130465 Adaptive145Third139Node93 = false := by
  decide +kernel

#print axioms adaptive145Third139Proof93

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third139Proof48 : runCachedNode 511 130465 Adaptive145Third139Node48 = false := by
  decide +kernel

#print axioms adaptive145Third139Proof48

end NineSeparatedSubsetSums
