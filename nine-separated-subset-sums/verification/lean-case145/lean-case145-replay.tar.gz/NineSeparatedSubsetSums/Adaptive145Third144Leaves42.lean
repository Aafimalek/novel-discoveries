import NineSeparatedSubsetSums.Adaptive145Third144State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third144Proof457 : runCachedNode 511 131183 Adaptive145Third144Node457 = false := by
  decide +kernel

#print axioms adaptive145Third144Proof457

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third144Proof613 : runCachedNode 511 131183 Adaptive145Third144Node613 = false := by
  decide +kernel

#print axioms adaptive145Third144Proof613

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third144Proof223 : runCachedNode 511 131183 Adaptive145Third144Node223 = false := by
  decide +kernel

#print axioms adaptive145Third144Proof223

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third144Proof540 : runCachedNode 511 131183 Adaptive145Third144Node540 = false := by
  decide +kernel

#print axioms adaptive145Third144Proof540

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third144Proof612 : runCachedNode 511 131183 Adaptive145Third144Node612 = false := by
  decide +kernel

#print axioms adaptive145Third144Proof612

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third144Proof325 : runCachedNode 511 131183 Adaptive145Third144Node325 = false := by
  decide +kernel

#print axioms adaptive145Third144Proof325

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third144Proof456 : runCachedNode 511 131183 Adaptive145Third144Node456 = false := by
  decide +kernel

#print axioms adaptive145Third144Proof456

end NineSeparatedSubsetSums
