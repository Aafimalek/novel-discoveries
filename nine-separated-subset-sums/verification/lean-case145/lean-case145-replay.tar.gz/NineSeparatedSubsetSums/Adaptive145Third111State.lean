import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive145Third111Node0 : CachedSearchNode :=
  ⟨4, 110, computeCenteredMask [148,145,111], 404, 55250⟩

end NineSeparatedSubsetSums
