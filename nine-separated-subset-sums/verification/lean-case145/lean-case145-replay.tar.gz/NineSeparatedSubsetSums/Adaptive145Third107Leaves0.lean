import NineSeparatedSubsetSums.Adaptive145Third107State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third107Proof0 : runCachedNode 511 112442 Adaptive145Third107Node0 = false := by
  decide +kernel

#print axioms adaptive145Third107Proof0

end NineSeparatedSubsetSums
