import NineSeparatedSubsetSums.Adaptive145Third142State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof279 : runCachedNode 511 130865 Adaptive145Third142Node279 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof279

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof135 : runCachedNode 511 130865 Adaptive145Third142Node135 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof135

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof252 : runCachedNode 511 130865 Adaptive145Third142Node252 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof252

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof113 : runCachedNode 511 130865 Adaptive145Third142Node113 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof113

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof190 : runCachedNode 511 130865 Adaptive145Third142Node190 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof190

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof428 : runCachedNode 511 130865 Adaptive145Third142Node428 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof428

end NineSeparatedSubsetSums
