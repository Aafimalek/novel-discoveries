import NineSeparatedSubsetSums.Adaptive145Third141State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third141Proof225 : runCachedNode 511 130740 Adaptive145Third141Node225 = false := by
  decide +kernel

#print axioms adaptive145Third141Proof225

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third141Proof18 : runCachedNode 511 130740 Adaptive145Third141Node18 = false := by
  decide +kernel

#print axioms adaptive145Third141Proof18

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third141Proof230 : runCachedNode 511 130740 Adaptive145Third141Node230 = false := by
  decide +kernel

#print axioms adaptive145Third141Proof230

end NineSeparatedSubsetSums
