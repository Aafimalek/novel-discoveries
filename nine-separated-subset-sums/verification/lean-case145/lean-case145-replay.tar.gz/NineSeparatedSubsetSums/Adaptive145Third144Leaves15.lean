import NineSeparatedSubsetSums.Adaptive145Third144State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third144Proof265 : runCachedNode 511 131183 Adaptive145Third144Node265 = false := by
  decide +kernel

#print axioms adaptive145Third144Proof265

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third144Proof333 : runCachedNode 511 131183 Adaptive145Third144Node333 = false := by
  decide +kernel

#print axioms adaptive145Third144Proof333

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third144Proof82 : runCachedNode 511 131183 Adaptive145Third144Node82 = false := by
  decide +kernel

#print axioms adaptive145Third144Proof82

end NineSeparatedSubsetSums
