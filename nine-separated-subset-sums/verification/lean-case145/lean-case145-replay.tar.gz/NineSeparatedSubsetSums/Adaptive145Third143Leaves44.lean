import NineSeparatedSubsetSums.Adaptive145Third143State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof220 : runCachedNode 511 131040 Adaptive145Third143Node220 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof220

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof569 : runCachedNode 511 131040 Adaptive145Third143Node569 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof569

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof484 : runCachedNode 511 131040 Adaptive145Third143Node484 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof484

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof251 : runCachedNode 511 131040 Adaptive145Third143Node251 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof251

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof154 : runCachedNode 511 131040 Adaptive145Third143Node154 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof154

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof332 : runCachedNode 511 131040 Adaptive145Third143Node332 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof332

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof155 : runCachedNode 511 131040 Adaptive145Third143Node155 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof155

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof219 : runCachedNode 511 131040 Adaptive145Third143Node219 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof219

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof70 : runCachedNode 511 131040 Adaptive145Third143Node70 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof70

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof126 : runCachedNode 511 131040 Adaptive145Third143Node126 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof126

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof42 : runCachedNode 511 131040 Adaptive145Third143Node42 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof42

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof124 : runCachedNode 511 131040 Adaptive145Third143Node124 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof124

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof402 : runCachedNode 511 131040 Adaptive145Third143Node402 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof402

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof67 : runCachedNode 511 131040 Adaptive145Third143Node67 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof67

end NineSeparatedSubsetSums
