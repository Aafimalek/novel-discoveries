import NineSeparatedSubsetSums.Adaptive145Third141State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third141Proof101 : runCachedNode 511 130740 Adaptive145Third141Node101 = false := by
  decide +kernel

#print axioms adaptive145Third141Proof101

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third141Proof338 : runCachedNode 511 130740 Adaptive145Third141Node338 = false := by
  decide +kernel

#print axioms adaptive145Third141Proof338

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third141Proof189 : runCachedNode 511 130740 Adaptive145Third141Node189 = false := by
  decide +kernel

#print axioms adaptive145Third141Proof189

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third141Proof70 : runCachedNode 511 130740 Adaptive145Third141Node70 = false := by
  decide +kernel

#print axioms adaptive145Third141Proof70

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third141Proof73 : runCachedNode 511 130740 Adaptive145Third141Node73 = false := by
  decide +kernel

#print axioms adaptive145Third141Proof73

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third141Proof264 : runCachedNode 511 130740 Adaptive145Third141Node264 = false := by
  decide +kernel

#print axioms adaptive145Third141Proof264

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third141Proof124 : runCachedNode 511 130740 Adaptive145Third141Node124 = false := by
  decide +kernel

#print axioms adaptive145Third141Proof124

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third141Proof190 : runCachedNode 511 130740 Adaptive145Third141Node190 = false := by
  decide +kernel

#print axioms adaptive145Third141Proof190

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third141Proof293 : runCachedNode 511 130740 Adaptive145Third141Node293 = false := by
  decide +kernel

#print axioms adaptive145Third141Proof293

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third141Proof234 : runCachedNode 511 130740 Adaptive145Third141Node234 = false := by
  decide +kernel

#print axioms adaptive145Third141Proof234

end NineSeparatedSubsetSums
