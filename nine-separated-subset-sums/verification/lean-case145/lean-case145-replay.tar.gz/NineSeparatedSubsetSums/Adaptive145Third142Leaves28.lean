import NineSeparatedSubsetSums.Adaptive145Third142State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof537 : runCachedNode 511 130865 Adaptive145Third142Node537 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof537

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof652 : runCachedNode 511 130865 Adaptive145Third142Node652 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof652

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof69 : runCachedNode 511 130865 Adaptive145Third142Node69 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof69

end NineSeparatedSubsetSums
