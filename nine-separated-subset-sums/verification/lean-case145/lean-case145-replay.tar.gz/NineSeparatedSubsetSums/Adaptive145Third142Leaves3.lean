import NineSeparatedSubsetSums.Adaptive145Third142State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof284 : runCachedNode 511 130865 Adaptive145Third142Node284 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof284

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof390 : runCachedNode 511 130865 Adaptive145Third142Node390 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof390

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof322 : runCachedNode 511 130865 Adaptive145Third142Node322 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof322

end NineSeparatedSubsetSums
