import NineSeparatedSubsetSums.Adaptive145Third143State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof498 : runCachedNode 511 131040 Adaptive145Third143Node498 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof498

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof594 : runCachedNode 511 131040 Adaptive145Third143Node594 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof594

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof413 : runCachedNode 511 131040 Adaptive145Third143Node413 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof413

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof269 : runCachedNode 511 131040 Adaptive145Third143Node269 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof269

end NineSeparatedSubsetSums
