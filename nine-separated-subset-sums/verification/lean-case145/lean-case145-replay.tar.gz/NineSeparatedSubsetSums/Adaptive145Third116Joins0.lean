import NineSeparatedSubsetSums.Adaptive145Third116State
import NineSeparatedSubsetSums.Adaptive145Third116Leaves1
import NineSeparatedSubsetSums.Adaptive145Third116Leaves0

namespace NineSeparatedSubsetSums

theorem adaptive145Third116Proof0 : runCachedNode 511 112442 Adaptive145Third116Node0 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 112442 Adaptive145Third116Node0 = [100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 114, 115] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive145Third116Proof1
  · exact adaptive145Third116Proof2
  · exact adaptive145Third116Proof3
  · exact adaptive145Third116Proof4
  · exact adaptive145Third116Proof5
  · exact adaptive145Third116Proof6
  · exact adaptive145Third116Proof7
  · exact adaptive145Third116Proof8
  · exact adaptive145Third116Proof9
  · exact adaptive145Third116Proof10
  · exact adaptive145Third116Proof11
  · exact adaptive145Third116Proof12
  · exact adaptive145Third116Proof13
  · exact adaptive145Third116Proof14
  · exact adaptive145Third116Proof15

#print axioms adaptive145Third116Proof0

end NineSeparatedSubsetSums
