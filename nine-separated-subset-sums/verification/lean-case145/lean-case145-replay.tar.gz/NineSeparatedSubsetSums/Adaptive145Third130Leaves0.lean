import NineSeparatedSubsetSums.Adaptive145Third130State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third130Proof19 : runCachedNode 511 128861 Adaptive145Third130Node19 = false := by
  decide +kernel

#print axioms adaptive145Third130Proof19

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third130Proof18 : runCachedNode 511 128861 Adaptive145Third130Node18 = false := by
  decide +kernel

#print axioms adaptive145Third130Proof18

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third130Proof11 : runCachedNode 511 128861 Adaptive145Third130Node11 = false := by
  decide +kernel

#print axioms adaptive145Third130Proof11

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third130Proof3 : runCachedNode 511 128861 Adaptive145Third130Node3 = false := by
  decide +kernel

#print axioms adaptive145Third130Proof3

end NineSeparatedSubsetSums
