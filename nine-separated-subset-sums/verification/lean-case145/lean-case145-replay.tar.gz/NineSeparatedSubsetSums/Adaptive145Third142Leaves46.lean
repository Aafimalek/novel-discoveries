import NineSeparatedSubsetSums.Adaptive145Third142State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof280 : runCachedNode 511 130865 Adaptive145Third142Node280 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof280

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof458 : runCachedNode 511 130865 Adaptive145Third142Node458 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof458

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof809 : runCachedNode 511 130865 Adaptive145Third142Node809 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof809

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof63 : runCachedNode 511 130865 Adaptive145Third142Node63 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof63

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof695 : runCachedNode 511 130865 Adaptive145Third142Node695 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof695

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof370 : runCachedNode 511 130865 Adaptive145Third142Node370 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof370

end NineSeparatedSubsetSums
