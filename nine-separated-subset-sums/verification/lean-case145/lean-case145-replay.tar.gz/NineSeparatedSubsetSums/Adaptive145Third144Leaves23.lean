import NineSeparatedSubsetSums.Adaptive145Third144State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third144Proof493 : runCachedNode 511 131183 Adaptive145Third144Node493 = false := by
  decide +kernel

#print axioms adaptive145Third144Proof493

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third144Proof621 : runCachedNode 511 131183 Adaptive145Third144Node621 = false := by
  decide +kernel

#print axioms adaptive145Third144Proof621

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third144Proof258 : runCachedNode 511 131183 Adaptive145Third144Node258 = false := by
  decide +kernel

#print axioms adaptive145Third144Proof258

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third144Proof139 : runCachedNode 511 131183 Adaptive145Third144Node139 = false := by
  decide +kernel

#print axioms adaptive145Third144Proof139

end NineSeparatedSubsetSums
