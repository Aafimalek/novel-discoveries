import NineSeparatedSubsetSums.Adaptive145Third141State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third141Proof122 : runCachedNode 511 130740 Adaptive145Third141Node122 = false := by
  decide +kernel

#print axioms adaptive145Third141Proof122

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third141Proof216 : runCachedNode 511 130740 Adaptive145Third141Node216 = false := by
  decide +kernel

#print axioms adaptive145Third141Proof216

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third141Proof11 : runCachedNode 511 130740 Adaptive145Third141Node11 = false := by
  decide +kernel

#print axioms adaptive145Third141Proof11

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third141Proof363 : runCachedNode 511 130740 Adaptive145Third141Node363 = false := by
  decide +kernel

#print axioms adaptive145Third141Proof363

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third141Proof364 : runCachedNode 511 130740 Adaptive145Third141Node364 = false := by
  decide +kernel

#print axioms adaptive145Third141Proof364

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third141Proof41 : runCachedNode 511 130740 Adaptive145Third141Node41 = false := by
  decide +kernel

#print axioms adaptive145Third141Proof41

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third141Proof95 : runCachedNode 511 130740 Adaptive145Third141Node95 = false := by
  decide +kernel

#print axioms adaptive145Third141Proof95

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third141Proof292 : runCachedNode 511 130740 Adaptive145Third141Node292 = false := by
  decide +kernel

#print axioms adaptive145Third141Proof292

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third141Proof187 : runCachedNode 511 130740 Adaptive145Third141Node187 = false := by
  decide +kernel

#print axioms adaptive145Third141Proof187

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third141Proof152 : runCachedNode 511 130740 Adaptive145Third141Node152 = false := by
  decide +kernel

#print axioms adaptive145Third141Proof152

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third141Proof153 : runCachedNode 511 130740 Adaptive145Third141Node153 = false := by
  decide +kernel

#print axioms adaptive145Third141Proof153

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third141Proof262 : runCachedNode 511 130740 Adaptive145Third141Node262 = false := by
  decide +kernel

#print axioms adaptive145Third141Proof262

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third141Proof414 : runCachedNode 511 130740 Adaptive145Third141Node414 = false := by
  decide +kernel

#print axioms adaptive145Third141Proof414

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third141Proof121 : runCachedNode 511 130740 Adaptive145Third141Node121 = false := by
  decide +kernel

#print axioms adaptive145Third141Proof121

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third141Proof185 : runCachedNode 511 130740 Adaptive145Third141Node185 = false := by
  decide +kernel

#print axioms adaptive145Third141Proof185

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third141Proof59 : runCachedNode 511 130740 Adaptive145Third141Node59 = false := by
  decide +kernel

#print axioms adaptive145Third141Proof59

end NineSeparatedSubsetSums
