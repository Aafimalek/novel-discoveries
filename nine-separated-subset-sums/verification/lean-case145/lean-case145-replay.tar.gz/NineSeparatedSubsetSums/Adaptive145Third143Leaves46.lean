import NineSeparatedSubsetSums.Adaptive145Third143State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof330 : runCachedNode 511 131040 Adaptive145Third143Node330 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof330

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof41 : runCachedNode 511 131040 Adaptive145Third143Node41 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof41

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof186 : runCachedNode 511 131040 Adaptive145Third143Node186 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof186

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof40 : runCachedNode 511 131040 Adaptive145Third143Node40 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof40

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof66 : runCachedNode 511 131040 Adaptive145Third143Node66 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof66

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof247 : runCachedNode 511 131040 Adaptive145Third143Node247 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof247

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof301 : runCachedNode 511 131040 Adaptive145Third143Node301 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof301

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof95 : runCachedNode 511 131040 Adaptive145Third143Node95 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof95

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof152 : runCachedNode 511 131040 Adaptive145Third143Node152 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof152

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof567 : runCachedNode 511 131040 Adaptive145Third143Node567 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof567

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof400 : runCachedNode 511 131040 Adaptive145Third143Node400 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof400

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof216 : runCachedNode 511 131040 Adaptive145Third143Node216 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof216

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof331 : runCachedNode 511 131040 Adaptive145Third143Node331 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof331

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof378 : runCachedNode 511 131040 Adaptive145Third143Node378 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof378

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof541 : runCachedNode 511 131040 Adaptive145Third143Node541 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof541

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof329 : runCachedNode 511 131040 Adaptive145Third143Node329 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof329

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof454 : runCachedNode 511 131040 Adaptive145Third143Node454 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof454

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof328 : runCachedNode 511 131040 Adaptive145Third143Node328 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof328

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof525 : runCachedNode 511 131040 Adaptive145Third143Node525 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof525

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof526 : runCachedNode 511 131040 Adaptive145Third143Node526 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof526

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof327 : runCachedNode 511 131040 Adaptive145Third143Node327 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof327

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof28 : runCachedNode 511 131040 Adaptive145Third143Node28 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof28

end NineSeparatedSubsetSums
