import NineSeparatedSubsetSums.Adaptive145Third141State
import NineSeparatedSubsetSums.Adaptive145Third141Leaves10
import NineSeparatedSubsetSums.Adaptive145Third141Leaves33
import NineSeparatedSubsetSums.Adaptive145Third141Leaves32
import NineSeparatedSubsetSums.Adaptive145Third141Leaves8
import NineSeparatedSubsetSums.Adaptive145Third141Leaves31
import NineSeparatedSubsetSums.Adaptive145Third141Leaves30
import NineSeparatedSubsetSums.Adaptive145Third141Leaves24
import NineSeparatedSubsetSums.Adaptive145Third141Leaves6
import NineSeparatedSubsetSums.Adaptive145Third141Leaves29
import NineSeparatedSubsetSums.Adaptive145Third141Leaves28
import NineSeparatedSubsetSums.Adaptive145Third141Leaves27
import NineSeparatedSubsetSums.Adaptive145Third141Leaves26
import NineSeparatedSubsetSums.Adaptive145Third141Leaves25
import NineSeparatedSubsetSums.Adaptive145Third141Leaves22
import NineSeparatedSubsetSums.Adaptive145Third141Leaves15
import NineSeparatedSubsetSums.Adaptive145Third141Leaves23
import NineSeparatedSubsetSums.Adaptive145Third141Leaves11
import NineSeparatedSubsetSums.Adaptive145Third141Leaves16
import NineSeparatedSubsetSums.Adaptive145Third141Leaves0
import NineSeparatedSubsetSums.Adaptive145Third141Leaves4
import NineSeparatedSubsetSums.Adaptive145Third141Leaves19
import NineSeparatedSubsetSums.Adaptive145Third141Leaves20
import NineSeparatedSubsetSums.Adaptive145Third141Leaves13
import NineSeparatedSubsetSums.Adaptive145Third141Leaves21
import NineSeparatedSubsetSums.Adaptive145Third141Leaves17
import NineSeparatedSubsetSums.Adaptive145Third141Leaves14
import NineSeparatedSubsetSums.Adaptive145Third141Leaves1
import NineSeparatedSubsetSums.Adaptive145Third141Leaves12
import NineSeparatedSubsetSums.Adaptive145Third141Leaves18
import NineSeparatedSubsetSums.Adaptive145Third141Leaves2
import NineSeparatedSubsetSums.Adaptive145Third141Leaves34
import NineSeparatedSubsetSums.Adaptive145Third141Leaves7
import NineSeparatedSubsetSums.Adaptive145Third141Leaves5
import NineSeparatedSubsetSums.Adaptive145Third141Leaves3

namespace NineSeparatedSubsetSums

theorem adaptive145Third141Proof23 : runCachedNode 511 130740 Adaptive145Third141Node23 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130740 Adaptive145Third141Node23 = [103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 125, 126, 129, 130] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive145Third141Proof24
  · exact adaptive145Third141Proof25
  · exact adaptive145Third141Proof26
  · exact adaptive145Third141Proof27
  · exact adaptive145Third141Proof28
  · exact adaptive145Third141Proof29
  · exact adaptive145Third141Proof30
  · exact adaptive145Third141Proof31
  · exact adaptive145Third141Proof32
  · exact adaptive145Third141Proof33
  · exact adaptive145Third141Proof34
  · exact adaptive145Third141Proof35
  · exact adaptive145Third141Proof36
  · exact adaptive145Third141Proof37
  · exact adaptive145Third141Proof38
  · exact adaptive145Third141Proof39
  · exact adaptive145Third141Proof40
  · exact adaptive145Third141Proof41
  · exact adaptive145Third141Proof42
  · exact adaptive145Third141Proof43
  · exact adaptive145Third141Proof44
  · exact adaptive145Third141Proof45
  · exact adaptive145Third141Proof46
  · exact adaptive145Third141Proof47
  · exact adaptive145Third141Proof48

#print axioms adaptive145Third141Proof23

theorem adaptive145Third141Proof49 : runCachedNode 511 130740 Adaptive145Third141Node49 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130740 Adaptive145Third141Node49 = [103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 126, 127, 130, 131] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive145Third141Proof50
  · exact adaptive145Third141Proof51
  · exact adaptive145Third141Proof52
  · exact adaptive145Third141Proof53
  · exact adaptive145Third141Proof54
  · exact adaptive145Third141Proof55
  · exact adaptive145Third141Proof56
  · exact adaptive145Third141Proof57
  · exact adaptive145Third141Proof58
  · exact adaptive145Third141Proof59
  · exact adaptive145Third141Proof60
  · exact adaptive145Third141Proof61
  · exact adaptive145Third141Proof62
  · exact adaptive145Third141Proof63
  · exact adaptive145Third141Proof64
  · exact adaptive145Third141Proof65
  · exact adaptive145Third141Proof66
  · exact adaptive145Third141Proof67
  · exact adaptive145Third141Proof68
  · exact adaptive145Third141Proof69
  · exact adaptive145Third141Proof70
  · exact adaptive145Third141Proof71
  · exact adaptive145Third141Proof72
  · exact adaptive145Third141Proof73
  · exact adaptive145Third141Proof74
  · exact adaptive145Third141Proof75

#print axioms adaptive145Third141Proof49

theorem adaptive145Third141Proof76 : runCachedNode 511 130740 Adaptive145Third141Node76 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130740 Adaptive145Third141Node76 = [103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 127, 128, 131, 132] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive145Third141Proof77
  · exact adaptive145Third141Proof78
  · exact adaptive145Third141Proof79
  · exact adaptive145Third141Proof80
  · exact adaptive145Third141Proof81
  · exact adaptive145Third141Proof82
  · exact adaptive145Third141Proof83
  · exact adaptive145Third141Proof84
  · exact adaptive145Third141Proof85
  · exact adaptive145Third141Proof86
  · exact adaptive145Third141Proof87
  · exact adaptive145Third141Proof88
  · exact adaptive145Third141Proof89
  · exact adaptive145Third141Proof90
  · exact adaptive145Third141Proof91
  · exact adaptive145Third141Proof92
  · exact adaptive145Third141Proof93
  · exact adaptive145Third141Proof94
  · exact adaptive145Third141Proof95
  · exact adaptive145Third141Proof96
  · exact adaptive145Third141Proof97
  · exact adaptive145Third141Proof98
  · exact adaptive145Third141Proof99
  · exact adaptive145Third141Proof100
  · exact adaptive145Third141Proof101
  · exact adaptive145Third141Proof102
  · exact adaptive145Third141Proof103

#print axioms adaptive145Third141Proof76

theorem adaptive145Third141Proof104 : runCachedNode 511 130740 Adaptive145Third141Node104 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130740 Adaptive145Third141Node104 = [102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 128, 129, 132, 133] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive145Third141Proof105
  · exact adaptive145Third141Proof106
  · exact adaptive145Third141Proof107
  · exact adaptive145Third141Proof108
  · exact adaptive145Third141Proof109
  · exact adaptive145Third141Proof110
  · exact adaptive145Third141Proof111
  · exact adaptive145Third141Proof112
  · exact adaptive145Third141Proof113
  · exact adaptive145Third141Proof114
  · exact adaptive145Third141Proof115
  · exact adaptive145Third141Proof116
  · exact adaptive145Third141Proof117
  · exact adaptive145Third141Proof118
  · exact adaptive145Third141Proof119
  · exact adaptive145Third141Proof120
  · exact adaptive145Third141Proof121
  · exact adaptive145Third141Proof122
  · exact adaptive145Third141Proof123
  · exact adaptive145Third141Proof124
  · exact adaptive145Third141Proof125
  · exact adaptive145Third141Proof126
  · exact adaptive145Third141Proof127
  · exact adaptive145Third141Proof128
  · exact adaptive145Third141Proof129
  · exact adaptive145Third141Proof130
  · exact adaptive145Third141Proof131
  · exact adaptive145Third141Proof132
  · exact adaptive145Third141Proof133

#print axioms adaptive145Third141Proof104

theorem adaptive145Third141Proof134 : runCachedNode 511 130740 Adaptive145Third141Node134 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130740 Adaptive145Third141Node134 = [102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 129, 130, 133, 134] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive145Third141Proof135
  · exact adaptive145Third141Proof136
  · exact adaptive145Third141Proof137
  · exact adaptive145Third141Proof138
  · exact adaptive145Third141Proof139
  · exact adaptive145Third141Proof140
  · exact adaptive145Third141Proof141
  · exact adaptive145Third141Proof142
  · exact adaptive145Third141Proof143
  · exact adaptive145Third141Proof144
  · exact adaptive145Third141Proof145
  · exact adaptive145Third141Proof146
  · exact adaptive145Third141Proof147
  · exact adaptive145Third141Proof148
  · exact adaptive145Third141Proof149
  · exact adaptive145Third141Proof150
  · exact adaptive145Third141Proof151
  · exact adaptive145Third141Proof152
  · exact adaptive145Third141Proof153
  · exact adaptive145Third141Proof154
  · exact adaptive145Third141Proof155
  · exact adaptive145Third141Proof156
  · exact adaptive145Third141Proof157
  · exact adaptive145Third141Proof158
  · exact adaptive145Third141Proof159
  · exact adaptive145Third141Proof160
  · exact adaptive145Third141Proof161
  · exact adaptive145Third141Proof162
  · exact adaptive145Third141Proof163
  · exact adaptive145Third141Proof164

#print axioms adaptive145Third141Proof134

theorem adaptive145Third141Proof165 : runCachedNode 511 130740 Adaptive145Third141Node165 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130740 Adaptive145Third141Node165 = [102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 130, 131, 134, 135] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive145Third141Proof166
  · exact adaptive145Third141Proof167
  · exact adaptive145Third141Proof168
  · exact adaptive145Third141Proof169
  · exact adaptive145Third141Proof170
  · exact adaptive145Third141Proof171
  · exact adaptive145Third141Proof172
  · exact adaptive145Third141Proof173
  · exact adaptive145Third141Proof174
  · exact adaptive145Third141Proof175
  · exact adaptive145Third141Proof176
  · exact adaptive145Third141Proof177
  · exact adaptive145Third141Proof178
  · exact adaptive145Third141Proof179
  · exact adaptive145Third141Proof180
  · exact adaptive145Third141Proof181
  · exact adaptive145Third141Proof182
  · exact adaptive145Third141Proof183
  · exact adaptive145Third141Proof184
  · exact adaptive145Third141Proof185
  · exact adaptive145Third141Proof186
  · exact adaptive145Third141Proof187
  · exact adaptive145Third141Proof188
  · exact adaptive145Third141Proof189
  · exact adaptive145Third141Proof190
  · exact adaptive145Third141Proof191
  · exact adaptive145Third141Proof192
  · exact adaptive145Third141Proof193
  · exact adaptive145Third141Proof194
  · exact adaptive145Third141Proof195
  · exact adaptive145Third141Proof196

#print axioms adaptive145Third141Proof165

theorem adaptive145Third141Proof229 : runCachedNode 511 130740 Adaptive145Third141Node229 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130740 Adaptive145Third141Node229 = [90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 122, 123, 124, 126, 127, 131] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive145Third141Proof230
  · exact adaptive145Third141Proof231
  · exact adaptive145Third141Proof232
  · exact adaptive145Third141Proof233
  · exact adaptive145Third141Proof234
  · exact adaptive145Third141Proof235
  · exact adaptive145Third141Proof236
  · exact adaptive145Third141Proof237
  · exact adaptive145Third141Proof238
  · exact adaptive145Third141Proof239
  · exact adaptive145Third141Proof240
  · exact adaptive145Third141Proof241
  · exact adaptive145Third141Proof242
  · exact adaptive145Third141Proof243
  · exact adaptive145Third141Proof244
  · exact adaptive145Third141Proof245
  · exact adaptive145Third141Proof246
  · exact adaptive145Third141Proof247
  · exact adaptive145Third141Proof248
  · exact adaptive145Third141Proof249
  · exact adaptive145Third141Proof250
  · exact adaptive145Third141Proof251
  · exact adaptive145Third141Proof252
  · exact adaptive145Third141Proof253
  · exact adaptive145Third141Proof254
  · exact adaptive145Third141Proof255
  · exact adaptive145Third141Proof256
  · exact adaptive145Third141Proof257
  · exact adaptive145Third141Proof258
  · exact adaptive145Third141Proof259
  · exact adaptive145Third141Proof260
  · exact adaptive145Third141Proof261
  · exact adaptive145Third141Proof262
  · exact adaptive145Third141Proof263
  · exact adaptive145Third141Proof264
  · exact adaptive145Third141Proof265
  · exact adaptive145Third141Proof266

#print axioms adaptive145Third141Proof229

theorem adaptive145Third141Proof197 : runCachedNode 511 130740 Adaptive145Third141Node197 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130740 Adaptive145Third141Node197 = [102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 131, 132, 135, 136] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive145Third141Proof198
  · exact adaptive145Third141Proof199
  · exact adaptive145Third141Proof200
  · exact adaptive145Third141Proof201
  · exact adaptive145Third141Proof202
  · exact adaptive145Third141Proof203
  · exact adaptive145Third141Proof204
  · exact adaptive145Third141Proof205
  · exact adaptive145Third141Proof206
  · exact adaptive145Third141Proof207
  · exact adaptive145Third141Proof208
  · exact adaptive145Third141Proof209
  · exact adaptive145Third141Proof210
  · exact adaptive145Third141Proof211
  · exact adaptive145Third141Proof212
  · exact adaptive145Third141Proof213
  · exact adaptive145Third141Proof214
  · exact adaptive145Third141Proof215
  · exact adaptive145Third141Proof216
  · exact adaptive145Third141Proof217
  · exact adaptive145Third141Proof218
  · exact adaptive145Third141Proof219
  · exact adaptive145Third141Proof220
  · exact adaptive145Third141Proof221
  · exact adaptive145Third141Proof222
  · exact adaptive145Third141Proof223
  · exact adaptive145Third141Proof224
  · exact adaptive145Third141Proof225
  · exact adaptive145Third141Proof226
  · exact adaptive145Third141Proof227
  · exact adaptive145Third141Proof228
  · exact adaptive145Third141Proof229

#print axioms adaptive145Third141Proof197

end NineSeparatedSubsetSums
