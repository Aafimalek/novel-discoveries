import NineSeparatedSubsetSums.Adaptive145Third108Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint145Checked

namespace NineSeparatedSubsetSums


theorem adaptive145Third108 : NoDescendingTailAfterThird 145 108 :=
  noDescendingThirdTail_of_cached 145 108 112442 (fun t ht nd => max148_second145_fourPoint_moment_bound (108::t) (by simp [ht]) nd) adaptive145Third108Proof0

#print axioms adaptive145Third108

end NineSeparatedSubsetSums
