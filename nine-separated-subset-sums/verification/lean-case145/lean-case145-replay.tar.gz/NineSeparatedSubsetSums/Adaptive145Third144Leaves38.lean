import NineSeparatedSubsetSums.Adaptive145Third144State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third144Proof225 : runCachedNode 511 131183 Adaptive145Third144Node225 = false := by
  decide +kernel

#print axioms adaptive145Third144Proof225

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third144Proof192 : runCachedNode 511 131183 Adaptive145Third144Node192 = false := by
  decide +kernel

#print axioms adaptive145Third144Proof192

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third144Proof298 : runCachedNode 511 131183 Adaptive145Third144Node298 = false := by
  decide +kernel

#print axioms adaptive145Third144Proof298

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third144Proof458 : runCachedNode 511 131183 Adaptive145Third144Node458 = false := by
  decide +kernel

#print axioms adaptive145Third144Proof458

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third144Proof584 : runCachedNode 511 131183 Adaptive145Third144Node584 = false := by
  decide +kernel

#print axioms adaptive145Third144Proof584

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third144Proof248 : runCachedNode 511 131183 Adaptive145Third144Node248 = false := by
  decide +kernel

#print axioms adaptive145Third144Proof248

end NineSeparatedSubsetSums
