import NineSeparatedSubsetSums.Adaptive145Third132State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third132Proof20 : runCachedNode 511 129338 Adaptive145Third132Node20 = false := by
  decide +kernel

#print axioms adaptive145Third132Proof20

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third132Proof18 : runCachedNode 511 129338 Adaptive145Third132Node18 = false := by
  decide +kernel

#print axioms adaptive145Third132Proof18

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third132Proof3 : runCachedNode 511 129338 Adaptive145Third132Node3 = false := by
  decide +kernel

#print axioms adaptive145Third132Proof3

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third132Proof2 : runCachedNode 511 129338 Adaptive145Third132Node2 = false := by
  decide +kernel

#print axioms adaptive145Third132Proof2

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third132Proof1 : runCachedNode 511 129338 Adaptive145Third132Node1 = false := by
  decide +kernel

#print axioms adaptive145Third132Proof1

end NineSeparatedSubsetSums
