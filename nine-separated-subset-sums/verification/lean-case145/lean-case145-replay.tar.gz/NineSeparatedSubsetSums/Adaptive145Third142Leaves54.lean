import NineSeparatedSubsetSums.Adaptive145Third142State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof84 : runCachedNode 511 130865 Adaptive145Third142Node84 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof84

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof61 : runCachedNode 511 130865 Adaptive145Third142Node61 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof61

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof314 : runCachedNode 511 130865 Adaptive145Third142Node314 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof314

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof429 : runCachedNode 511 130865 Adaptive145Third142Node429 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof429

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof313 : runCachedNode 511 130865 Adaptive145Third142Node313 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof313

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof62 : runCachedNode 511 130865 Adaptive145Third142Node62 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof62

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof107 : runCachedNode 511 130865 Adaptive145Third142Node107 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof107

end NineSeparatedSubsetSums
