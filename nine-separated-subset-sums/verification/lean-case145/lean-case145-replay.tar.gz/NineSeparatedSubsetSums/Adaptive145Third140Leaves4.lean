import NineSeparatedSubsetSums.Adaptive145Third140State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third140Proof163 : runCachedNode 511 130597 Adaptive145Third140Node163 = false := by
  decide +kernel

#print axioms adaptive145Third140Proof163

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third140Proof102 : runCachedNode 511 130597 Adaptive145Third140Node102 = false := by
  decide +kernel

#print axioms adaptive145Third140Proof102

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third140Proof244 : runCachedNode 511 130597 Adaptive145Third140Node244 = false := by
  decide +kernel

#print axioms adaptive145Third140Proof244

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third140Proof197 : runCachedNode 511 130597 Adaptive145Third140Node197 = false := by
  decide +kernel

#print axioms adaptive145Third140Proof197

end NineSeparatedSubsetSums
