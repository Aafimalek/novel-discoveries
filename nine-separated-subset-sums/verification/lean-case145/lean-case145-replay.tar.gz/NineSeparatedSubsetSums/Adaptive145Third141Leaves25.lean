import NineSeparatedSubsetSums.Adaptive145Third141State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third141Proof98 : runCachedNode 511 130740 Adaptive145Third141Node98 = false := by
  decide +kernel

#print axioms adaptive145Third141Proof98

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third141Proof263 : runCachedNode 511 130740 Adaptive145Third141Node263 = false := by
  decide +kernel

#print axioms adaptive145Third141Proof263

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third141Proof69 : runCachedNode 511 130740 Adaptive145Third141Node69 = false := by
  decide +kernel

#print axioms adaptive145Third141Proof69

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third141Proof100 : runCachedNode 511 130740 Adaptive145Third141Node100 = false := by
  decide +kernel

#print axioms adaptive145Third141Proof100

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third141Proof71 : runCachedNode 511 130740 Adaptive145Third141Node71 = false := by
  decide +kernel

#print axioms adaptive145Third141Proof71

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third141Proof43 : runCachedNode 511 130740 Adaptive145Third141Node43 = false := by
  decide +kernel

#print axioms adaptive145Third141Proof43

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third141Proof154 : runCachedNode 511 130740 Adaptive145Third141Node154 = false := by
  decide +kernel

#print axioms adaptive145Third141Proof154

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third141Proof415 : runCachedNode 511 130740 Adaptive145Third141Node415 = false := by
  decide +kernel

#print axioms adaptive145Third141Proof415

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third141Proof217 : runCachedNode 511 130740 Adaptive145Third141Node217 = false := by
  decide +kernel

#print axioms adaptive145Third141Proof217

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third141Proof365 : runCachedNode 511 130740 Adaptive145Third141Node365 = false := by
  decide +kernel

#print axioms adaptive145Third141Proof365

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third141Proof337 : runCachedNode 511 130740 Adaptive145Third141Node337 = false := by
  decide +kernel

#print axioms adaptive145Third141Proof337

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third141Proof294 : runCachedNode 511 130740 Adaptive145Third141Node294 = false := by
  decide +kernel

#print axioms adaptive145Third141Proof294

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third141Proof64 : runCachedNode 511 130740 Adaptive145Third141Node64 = false := by
  decide +kernel

#print axioms adaptive145Third141Proof64

end NineSeparatedSubsetSums
