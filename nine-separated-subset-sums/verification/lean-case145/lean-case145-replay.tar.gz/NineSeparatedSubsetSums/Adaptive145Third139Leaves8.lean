import NineSeparatedSubsetSums.Adaptive145Third139State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third139Proof222 : runCachedNode 511 130465 Adaptive145Third139Node222 = false := by
  decide +kernel

#print axioms adaptive145Third139Proof222

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third139Proof16 : runCachedNode 511 130465 Adaptive145Third139Node16 = false := by
  decide +kernel

#print axioms adaptive145Third139Proof16

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third139Proof92 : runCachedNode 511 130465 Adaptive145Third139Node92 = false := by
  decide +kernel

#print axioms adaptive145Third139Proof92

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third139Proof188 : runCachedNode 511 130465 Adaptive145Third139Node188 = false := by
  decide +kernel

#print axioms adaptive145Third139Proof188

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third139Proof208 : runCachedNode 511 130465 Adaptive145Third139Node208 = false := by
  decide +kernel

#print axioms adaptive145Third139Proof208

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third139Proof74 : runCachedNode 511 130465 Adaptive145Third139Node74 = false := by
  decide +kernel

#print axioms adaptive145Third139Proof74

end NineSeparatedSubsetSums
