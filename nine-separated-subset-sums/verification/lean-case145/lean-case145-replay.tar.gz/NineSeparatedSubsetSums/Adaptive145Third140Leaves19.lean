import NineSeparatedSubsetSums.Adaptive145Third140State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third140Proof190 : runCachedNode 511 130597 Adaptive145Third140Node190 = false := by
  decide +kernel

#print axioms adaptive145Third140Proof190

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third140Proof69 : runCachedNode 511 130597 Adaptive145Third140Node69 = false := by
  decide +kernel

#print axioms adaptive145Third140Proof69

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third140Proof68 : runCachedNode 511 130597 Adaptive145Third140Node68 = false := by
  decide +kernel

#print axioms adaptive145Third140Proof68

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third140Proof192 : runCachedNode 511 130597 Adaptive145Third140Node192 = false := by
  decide +kernel

#print axioms adaptive145Third140Proof192

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third140Proof301 : runCachedNode 511 130597 Adaptive145Third140Node301 = false := by
  decide +kernel

#print axioms adaptive145Third140Proof301

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third140Proof48 : runCachedNode 511 130597 Adaptive145Third140Node48 = false := by
  decide +kernel

#print axioms adaptive145Third140Proof48

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third140Proof258 : runCachedNode 511 130597 Adaptive145Third140Node258 = false := by
  decide +kernel

#print axioms adaptive145Third140Proof258

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third140Proof178 : runCachedNode 511 130597 Adaptive145Third140Node178 = false := by
  decide +kernel

#print axioms adaptive145Third140Proof178

end NineSeparatedSubsetSums
