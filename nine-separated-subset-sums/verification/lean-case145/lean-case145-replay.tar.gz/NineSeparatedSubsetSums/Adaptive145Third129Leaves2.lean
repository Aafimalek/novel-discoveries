import NineSeparatedSubsetSums.Adaptive145Third129State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third129Proof7 : runCachedNode 511 128639 Adaptive145Third129Node7 = false := by
  decide +kernel

#print axioms adaptive145Third129Proof7

end NineSeparatedSubsetSums
