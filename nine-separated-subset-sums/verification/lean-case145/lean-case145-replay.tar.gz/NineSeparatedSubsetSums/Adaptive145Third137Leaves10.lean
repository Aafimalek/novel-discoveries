import NineSeparatedSubsetSums.Adaptive145Third137State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third137Proof150 : runCachedNode 511 130164 Adaptive145Third137Node150 = false := by
  decide +kernel

#print axioms adaptive145Third137Proof150

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third137Proof41 : runCachedNode 511 130164 Adaptive145Third137Node41 = false := by
  decide +kernel

#print axioms adaptive145Third137Proof41

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third137Proof146 : runCachedNode 511 130164 Adaptive145Third137Node146 = false := by
  decide +kernel

#print axioms adaptive145Third137Proof146

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third137Proof40 : runCachedNode 511 130164 Adaptive145Third137Node40 = false := by
  decide +kernel

#print axioms adaptive145Third137Proof40

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third137Proof12 : runCachedNode 511 130164 Adaptive145Third137Node12 = false := by
  decide +kernel

#print axioms adaptive145Third137Proof12

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third137Proof38 : runCachedNode 511 130164 Adaptive145Third137Node38 = false := by
  decide +kernel

#print axioms adaptive145Third137Proof38

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third137Proof145 : runCachedNode 511 130164 Adaptive145Third137Node145 = false := by
  decide +kernel

#print axioms adaptive145Third137Proof145

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third137Proof64 : runCachedNode 511 130164 Adaptive145Third137Node64 = false := by
  decide +kernel

#print axioms adaptive145Third137Proof64

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third137Proof147 : runCachedNode 511 130164 Adaptive145Third137Node147 = false := by
  decide +kernel

#print axioms adaptive145Third137Proof147

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third137Proof83 : runCachedNode 511 130164 Adaptive145Third137Node83 = false := by
  decide +kernel

#print axioms adaptive145Third137Proof83

end NineSeparatedSubsetSums
