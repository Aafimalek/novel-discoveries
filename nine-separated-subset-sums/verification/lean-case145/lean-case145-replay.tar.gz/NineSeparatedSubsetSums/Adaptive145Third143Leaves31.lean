import NineSeparatedSubsetSums.Adaptive145Third143State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof226 : runCachedNode 511 131040 Adaptive145Third143Node226 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof226

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof104 : runCachedNode 511 131040 Adaptive145Third143Node104 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof104

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof133 : runCachedNode 511 131040 Adaptive145Third143Node133 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof133

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof257 : runCachedNode 511 131040 Adaptive145Third143Node257 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof257

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof72 : runCachedNode 511 131040 Adaptive145Third143Node72 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof72

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof109 : runCachedNode 511 131040 Adaptive145Third143Node109 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof109

end NineSeparatedSubsetSums
