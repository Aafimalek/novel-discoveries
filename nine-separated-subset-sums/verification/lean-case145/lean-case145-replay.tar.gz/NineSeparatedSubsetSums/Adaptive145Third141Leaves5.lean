import NineSeparatedSubsetSums.Adaptive145Third141State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third141Proof21 : runCachedNode 511 130740 Adaptive145Third141Node21 = false := by
  decide +kernel

#print axioms adaptive145Third141Proof21

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third141Proof17 : runCachedNode 511 130740 Adaptive145Third141Node17 = false := by
  decide +kernel

#print axioms adaptive145Third141Proof17

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third141Proof249 : runCachedNode 511 130740 Adaptive145Third141Node249 = false := by
  decide +kernel

#print axioms adaptive145Third141Proof249

end NineSeparatedSubsetSums
