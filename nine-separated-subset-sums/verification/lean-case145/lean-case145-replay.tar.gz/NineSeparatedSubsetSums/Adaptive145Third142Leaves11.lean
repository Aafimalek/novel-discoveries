import NineSeparatedSubsetSums.Adaptive145Third142State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof466 : runCachedNode 511 130865 Adaptive145Third142Node466 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof466

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof649 : runCachedNode 511 130865 Adaptive145Third142Node649 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof649

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof1 : runCachedNode 511 130865 Adaptive145Third142Node1 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof1

end NineSeparatedSubsetSums
