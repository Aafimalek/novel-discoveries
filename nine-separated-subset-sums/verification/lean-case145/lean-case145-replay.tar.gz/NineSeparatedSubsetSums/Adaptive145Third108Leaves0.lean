import NineSeparatedSubsetSums.Adaptive145Third108State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third108Proof0 : runCachedNode 511 112442 Adaptive145Third108Node0 = false := by
  decide +kernel

#print axioms adaptive145Third108Proof0

end NineSeparatedSubsetSums
