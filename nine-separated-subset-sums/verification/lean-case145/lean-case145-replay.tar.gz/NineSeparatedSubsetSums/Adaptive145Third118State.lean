import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive145Third118Node0 : CachedSearchNode :=
  ⟨4, 117, computeCenteredMask [148,145,118], 411, 56853⟩

end NineSeparatedSubsetSums
