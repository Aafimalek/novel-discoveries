import NineSeparatedSubsetSums.Adaptive145Third141State
import NineSeparatedSubsetSums.Adaptive145Third141Leaves34
import NineSeparatedSubsetSums.Adaptive145Third141Leaves35
import NineSeparatedSubsetSums.Adaptive145Third141Leaves33
import NineSeparatedSubsetSums.Adaptive145Third141Leaves32
import NineSeparatedSubsetSums.Adaptive145Third141Leaves31
import NineSeparatedSubsetSums.Adaptive145Third141Leaves30
import NineSeparatedSubsetSums.Adaptive145Third141Leaves29
import NineSeparatedSubsetSums.Adaptive145Third141Leaves28
import NineSeparatedSubsetSums.Adaptive145Third141Leaves27
import NineSeparatedSubsetSums.Adaptive145Third141Leaves25
import NineSeparatedSubsetSums.Adaptive145Third141Leaves23
import NineSeparatedSubsetSums.Adaptive145Third141Leaves13
import NineSeparatedSubsetSums.Adaptive145Third141Leaves19
import NineSeparatedSubsetSums.Adaptive145Third141Leaves14
import NineSeparatedSubsetSums.Adaptive145Third141Leaves26
import NineSeparatedSubsetSums.Adaptive145Third141Leaves24
import NineSeparatedSubsetSums.Adaptive145Third141Leaves20
import NineSeparatedSubsetSums.Adaptive145Third141Leaves12
import NineSeparatedSubsetSums.Adaptive145Third141Leaves21
import NineSeparatedSubsetSums.Adaptive145Third141Leaves18
import NineSeparatedSubsetSums.Adaptive145Third141Leaves16
import NineSeparatedSubsetSums.Adaptive145Third141Leaves4
import NineSeparatedSubsetSums.Adaptive145Third141Leaves22
import NineSeparatedSubsetSums.Adaptive145Third141Leaves15
import NineSeparatedSubsetSums.Adaptive145Third141Leaves9
import NineSeparatedSubsetSums.Adaptive145Third141Leaves3
import NineSeparatedSubsetSums.Adaptive145Third141Leaves0
import NineSeparatedSubsetSums.Adaptive145Third141Leaves5
import NineSeparatedSubsetSums.Adaptive145Third141Leaves7
import NineSeparatedSubsetSums.Adaptive145Third141Leaves10
import NineSeparatedSubsetSums.Adaptive145Third141Leaves2
import NineSeparatedSubsetSums.Adaptive145Third141Joins0

namespace NineSeparatedSubsetSums

theorem adaptive145Third141Proof301 : runCachedNode 511 130740 Adaptive145Third141Node301 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130740 Adaptive145Third141Node301 = [88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 125, 126, 127, 129] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive145Third141Proof302
  · exact adaptive145Third141Proof303
  · exact adaptive145Third141Proof304
  · exact adaptive145Third141Proof305
  · exact adaptive145Third141Proof306
  · exact adaptive145Third141Proof307
  · exact adaptive145Third141Proof308
  · exact adaptive145Third141Proof309
  · exact adaptive145Third141Proof310
  · exact adaptive145Third141Proof311
  · exact adaptive145Third141Proof312
  · exact adaptive145Third141Proof313
  · exact adaptive145Third141Proof314
  · exact adaptive145Third141Proof315
  · exact adaptive145Third141Proof316
  · exact adaptive145Third141Proof317
  · exact adaptive145Third141Proof318
  · exact adaptive145Third141Proof319
  · exact adaptive145Third141Proof320
  · exact adaptive145Third141Proof321
  · exact adaptive145Third141Proof322
  · exact adaptive145Third141Proof323
  · exact adaptive145Third141Proof324
  · exact adaptive145Third141Proof325
  · exact adaptive145Third141Proof326
  · exact adaptive145Third141Proof327
  · exact adaptive145Third141Proof328
  · exact adaptive145Third141Proof329
  · exact adaptive145Third141Proof330
  · exact adaptive145Third141Proof331
  · exact adaptive145Third141Proof332
  · exact adaptive145Third141Proof333
  · exact adaptive145Third141Proof334
  · exact adaptive145Third141Proof335
  · exact adaptive145Third141Proof336
  · exact adaptive145Third141Proof337
  · exact adaptive145Third141Proof338
  · exact adaptive145Third141Proof339
  · exact adaptive145Third141Proof340
  · exact adaptive145Third141Proof341

#print axioms adaptive145Third141Proof301

theorem adaptive145Third141Proof267 : runCachedNode 511 130740 Adaptive145Third141Node267 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130740 Adaptive145Third141Node267 = [101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 133, 134, 137] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive145Third141Proof268
  · exact adaptive145Third141Proof269
  · exact adaptive145Third141Proof270
  · exact adaptive145Third141Proof271
  · exact adaptive145Third141Proof272
  · exact adaptive145Third141Proof273
  · exact adaptive145Third141Proof274
  · exact adaptive145Third141Proof275
  · exact adaptive145Third141Proof276
  · exact adaptive145Third141Proof277
  · exact adaptive145Third141Proof278
  · exact adaptive145Third141Proof279
  · exact adaptive145Third141Proof280
  · exact adaptive145Third141Proof281
  · exact adaptive145Third141Proof282
  · exact adaptive145Third141Proof283
  · exact adaptive145Third141Proof284
  · exact adaptive145Third141Proof285
  · exact adaptive145Third141Proof286
  · exact adaptive145Third141Proof287
  · exact adaptive145Third141Proof288
  · exact adaptive145Third141Proof289
  · exact adaptive145Third141Proof290
  · exact adaptive145Third141Proof291
  · exact adaptive145Third141Proof292
  · exact adaptive145Third141Proof293
  · exact adaptive145Third141Proof294
  · exact adaptive145Third141Proof295
  · exact adaptive145Third141Proof296
  · exact adaptive145Third141Proof297
  · exact adaptive145Third141Proof298
  · exact adaptive145Third141Proof299
  · exact adaptive145Third141Proof300
  · exact adaptive145Third141Proof301

#print axioms adaptive145Third141Proof267

theorem adaptive145Third141Proof377 : runCachedNode 511 130740 Adaptive145Third141Node377 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130740 Adaptive145Third141Node377 = [87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 128, 129, 130] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive145Third141Proof378
  · exact adaptive145Third141Proof379
  · exact adaptive145Third141Proof380
  · exact adaptive145Third141Proof381
  · exact adaptive145Third141Proof382
  · exact adaptive145Third141Proof383
  · exact adaptive145Third141Proof384
  · exact adaptive145Third141Proof385
  · exact adaptive145Third141Proof386
  · exact adaptive145Third141Proof387
  · exact adaptive145Third141Proof388
  · exact adaptive145Third141Proof389
  · exact adaptive145Third141Proof390
  · exact adaptive145Third141Proof391
  · exact adaptive145Third141Proof392
  · exact adaptive145Third141Proof393
  · exact adaptive145Third141Proof394
  · exact adaptive145Third141Proof395
  · exact adaptive145Third141Proof396
  · exact adaptive145Third141Proof397
  · exact adaptive145Third141Proof398
  · exact adaptive145Third141Proof399
  · exact adaptive145Third141Proof400
  · exact adaptive145Third141Proof401
  · exact adaptive145Third141Proof402
  · exact adaptive145Third141Proof403
  · exact adaptive145Third141Proof404
  · exact adaptive145Third141Proof405
  · exact adaptive145Third141Proof406
  · exact adaptive145Third141Proof407
  · exact adaptive145Third141Proof408
  · exact adaptive145Third141Proof409
  · exact adaptive145Third141Proof410
  · exact adaptive145Third141Proof411
  · exact adaptive145Third141Proof412
  · exact adaptive145Third141Proof413
  · exact adaptive145Third141Proof414
  · exact adaptive145Third141Proof415
  · exact adaptive145Third141Proof416
  · exact adaptive145Third141Proof417
  · exact adaptive145Third141Proof418
  · exact adaptive145Third141Proof419
  · exact adaptive145Third141Proof420

#print axioms adaptive145Third141Proof377

theorem adaptive145Third141Proof342 : runCachedNode 511 130740 Adaptive145Third141Node342 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130740 Adaptive145Third141Node342 = [101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 132, 134, 135, 139] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive145Third141Proof343
  · exact adaptive145Third141Proof344
  · exact adaptive145Third141Proof345
  · exact adaptive145Third141Proof346
  · exact adaptive145Third141Proof347
  · exact adaptive145Third141Proof348
  · exact adaptive145Third141Proof349
  · exact adaptive145Third141Proof350
  · exact adaptive145Third141Proof351
  · exact adaptive145Third141Proof352
  · exact adaptive145Third141Proof353
  · exact adaptive145Third141Proof354
  · exact adaptive145Third141Proof355
  · exact adaptive145Third141Proof356
  · exact adaptive145Third141Proof357
  · exact adaptive145Third141Proof358
  · exact adaptive145Third141Proof359
  · exact adaptive145Third141Proof360
  · exact adaptive145Third141Proof361
  · exact adaptive145Third141Proof362
  · exact adaptive145Third141Proof363
  · exact adaptive145Third141Proof364
  · exact adaptive145Third141Proof365
  · exact adaptive145Third141Proof366
  · exact adaptive145Third141Proof367
  · exact adaptive145Third141Proof368
  · exact adaptive145Third141Proof369
  · exact adaptive145Third141Proof370
  · exact adaptive145Third141Proof371
  · exact adaptive145Third141Proof372
  · exact adaptive145Third141Proof373
  · exact adaptive145Third141Proof374
  · exact adaptive145Third141Proof375
  · exact adaptive145Third141Proof376
  · exact adaptive145Third141Proof377

#print axioms adaptive145Third141Proof342

theorem adaptive145Third141Proof0 : runCachedNode 511 130740 Adaptive145Third141Node0 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130740 Adaptive145Third141Node0 = [109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 132, 133, 134, 135, 136, 137, 139, 140] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive145Third141Proof1
  · exact adaptive145Third141Proof2
  · exact adaptive145Third141Proof3
  · exact adaptive145Third141Proof4
  · exact adaptive145Third141Proof5
  · exact adaptive145Third141Proof6
  · exact adaptive145Third141Proof7
  · exact adaptive145Third141Proof8
  · exact adaptive145Third141Proof9
  · exact adaptive145Third141Proof10
  · exact adaptive145Third141Proof11
  · exact adaptive145Third141Proof12
  · exact adaptive145Third141Proof13
  · exact adaptive145Third141Proof14
  · exact adaptive145Third141Proof15
  · exact adaptive145Third141Proof16
  · exact adaptive145Third141Proof17
  · exact adaptive145Third141Proof18
  · exact adaptive145Third141Proof19
  · exact adaptive145Third141Proof20
  · exact adaptive145Third141Proof21
  · exact adaptive145Third141Proof22
  · exact adaptive145Third141Proof23
  · exact adaptive145Third141Proof49
  · exact adaptive145Third141Proof76
  · exact adaptive145Third141Proof104
  · exact adaptive145Third141Proof134
  · exact adaptive145Third141Proof165
  · exact adaptive145Third141Proof197
  · exact adaptive145Third141Proof267
  · exact adaptive145Third141Proof342

#print axioms adaptive145Third141Proof0

end NineSeparatedSubsetSums
