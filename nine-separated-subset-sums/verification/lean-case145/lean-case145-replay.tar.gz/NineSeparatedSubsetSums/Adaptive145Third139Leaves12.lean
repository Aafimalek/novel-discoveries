import NineSeparatedSubsetSums.Adaptive145Third139State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third139Proof128 : runCachedNode 511 130465 Adaptive145Third139Node128 = false := by
  decide +kernel

#print axioms adaptive145Third139Proof128

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third139Proof94 : runCachedNode 511 130465 Adaptive145Third139Node94 = false := by
  decide +kernel

#print axioms adaptive145Third139Proof94

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third139Proof218 : runCachedNode 511 130465 Adaptive145Third139Node218 = false := by
  decide +kernel

#print axioms adaptive145Third139Proof218

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third139Proof156 : runCachedNode 511 130465 Adaptive145Third139Node156 = false := by
  decide +kernel

#print axioms adaptive145Third139Proof156

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third139Proof154 : runCachedNode 511 130465 Adaptive145Third139Node154 = false := by
  decide +kernel

#print axioms adaptive145Third139Proof154

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third139Proof43 : runCachedNode 511 130465 Adaptive145Third139Node43 = false := by
  decide +kernel

#print axioms adaptive145Third139Proof43

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third139Proof126 : runCachedNode 511 130465 Adaptive145Third139Node126 = false := by
  decide +kernel

#print axioms adaptive145Third139Proof126

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third139Proof179 : runCachedNode 511 130465 Adaptive145Third139Node179 = false := by
  decide +kernel

#print axioms adaptive145Third139Proof179

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third139Proof102 : runCachedNode 511 130465 Adaptive145Third139Node102 = false := by
  decide +kernel

#print axioms adaptive145Third139Proof102

end NineSeparatedSubsetSums
