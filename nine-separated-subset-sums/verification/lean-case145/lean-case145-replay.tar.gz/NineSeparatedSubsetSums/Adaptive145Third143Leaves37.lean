import NineSeparatedSubsetSums.Adaptive145Third143State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof408 : runCachedNode 511 131040 Adaptive145Third143Node408 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof408

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof588 : runCachedNode 511 131040 Adaptive145Third143Node588 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof588

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof129 : runCachedNode 511 131040 Adaptive145Third143Node129 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof129

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof160 : runCachedNode 511 131040 Adaptive145Third143Node160 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof160

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof158 : runCachedNode 511 131040 Adaptive145Third143Node158 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof158

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof222 : runCachedNode 511 131040 Adaptive145Third143Node222 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof222

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof489 : runCachedNode 511 131040 Adaptive145Third143Node489 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof489

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof401 : runCachedNode 511 131040 Adaptive145Third143Node401 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof401

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof271 : runCachedNode 511 131040 Adaptive145Third143Node271 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof271

end NineSeparatedSubsetSums
