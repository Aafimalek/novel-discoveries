import NineSeparatedSubsetSums.Adaptive145Third142State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof16 : runCachedNode 511 130865 Adaptive145Third142Node16 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof16

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof582 : runCachedNode 511 130865 Adaptive145Third142Node582 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof582

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof235 : runCachedNode 511 130865 Adaptive145Third142Node235 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof235

end NineSeparatedSubsetSums
