import NineSeparatedSubsetSums.Adaptive145Third143State
import NineSeparatedSubsetSums.Adaptive145Third143Leaves54
import NineSeparatedSubsetSums.Adaptive145Third143Leaves10
import NineSeparatedSubsetSums.Adaptive145Third143Leaves9
import NineSeparatedSubsetSums.Adaptive145Third143Leaves46
import NineSeparatedSubsetSums.Adaptive145Third143Leaves52
import NineSeparatedSubsetSums.Adaptive145Third143Leaves51
import NineSeparatedSubsetSums.Adaptive145Third143Leaves8
import NineSeparatedSubsetSums.Adaptive145Third143Leaves50
import NineSeparatedSubsetSums.Adaptive145Third143Leaves49
import NineSeparatedSubsetSums.Adaptive145Third143Leaves47
import NineSeparatedSubsetSums.Adaptive145Third143Leaves48
import NineSeparatedSubsetSums.Adaptive145Third143Leaves44
import NineSeparatedSubsetSums.Adaptive145Third143Leaves45
import NineSeparatedSubsetSums.Adaptive145Third143Leaves42
import NineSeparatedSubsetSums.Adaptive145Third143Leaves38
import NineSeparatedSubsetSums.Adaptive145Third143Leaves34
import NineSeparatedSubsetSums.Adaptive145Third143Leaves27
import NineSeparatedSubsetSums.Adaptive145Third143Leaves20
import NineSeparatedSubsetSums.Adaptive145Third143Leaves21
import NineSeparatedSubsetSums.Adaptive145Third143Leaves16
import NineSeparatedSubsetSums.Adaptive145Third143Leaves12
import NineSeparatedSubsetSums.Adaptive145Third143Leaves43
import NineSeparatedSubsetSums.Adaptive145Third143Leaves39
import NineSeparatedSubsetSums.Adaptive145Third143Leaves31
import NineSeparatedSubsetSums.Adaptive145Third143Leaves40
import NineSeparatedSubsetSums.Adaptive145Third143Leaves32
import NineSeparatedSubsetSums.Adaptive145Third143Leaves30
import NineSeparatedSubsetSums.Adaptive145Third143Leaves6
import NineSeparatedSubsetSums.Adaptive145Third143Leaves14
import NineSeparatedSubsetSums.Adaptive145Third143Leaves19
import NineSeparatedSubsetSums.Adaptive145Third143Leaves2
import NineSeparatedSubsetSums.Adaptive145Third143Leaves35
import NineSeparatedSubsetSums.Adaptive145Third143Leaves41
import NineSeparatedSubsetSums.Adaptive145Third143Leaves36
import NineSeparatedSubsetSums.Adaptive145Third143Leaves18
import NineSeparatedSubsetSums.Adaptive145Third143Leaves11
import NineSeparatedSubsetSums.Adaptive145Third143Leaves37
import NineSeparatedSubsetSums.Adaptive145Third143Leaves33
import NineSeparatedSubsetSums.Adaptive145Third143Leaves25
import NineSeparatedSubsetSums.Adaptive145Third143Leaves53
import NineSeparatedSubsetSums.Adaptive145Third143Leaves28
import NineSeparatedSubsetSums.Adaptive145Third143Leaves24
import NineSeparatedSubsetSums.Adaptive145Third143Leaves3
import NineSeparatedSubsetSums.Adaptive145Third143Leaves15
import NineSeparatedSubsetSums.Adaptive145Third143Leaves29
import NineSeparatedSubsetSums.Adaptive145Third143Leaves5
import NineSeparatedSubsetSums.Adaptive145Third143Leaves23
import NineSeparatedSubsetSums.Adaptive145Third143Leaves17
import NineSeparatedSubsetSums.Adaptive145Third143Leaves22
import NineSeparatedSubsetSums.Adaptive145Third143Leaves55
import NineSeparatedSubsetSums.Adaptive145Third143Leaves26

namespace NineSeparatedSubsetSums

theorem adaptive145Third143Proof23 : runCachedNode 511 131040 Adaptive145Third143Node23 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 131040 Adaptive145Third143Node23 = [103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 127, 130] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive145Third143Proof24
  · exact adaptive145Third143Proof25
  · exact adaptive145Third143Proof26
  · exact adaptive145Third143Proof27
  · exact adaptive145Third143Proof28
  · exact adaptive145Third143Proof29
  · exact adaptive145Third143Proof30
  · exact adaptive145Third143Proof31
  · exact adaptive145Third143Proof32
  · exact adaptive145Third143Proof33
  · exact adaptive145Third143Proof34
  · exact adaptive145Third143Proof35
  · exact adaptive145Third143Proof36
  · exact adaptive145Third143Proof37
  · exact adaptive145Third143Proof38
  · exact adaptive145Third143Proof39
  · exact adaptive145Third143Proof40
  · exact adaptive145Third143Proof41
  · exact adaptive145Third143Proof42
  · exact adaptive145Third143Proof43
  · exact adaptive145Third143Proof44
  · exact adaptive145Third143Proof45
  · exact adaptive145Third143Proof46
  · exact adaptive145Third143Proof47
  · exact adaptive145Third143Proof48

#print axioms adaptive145Third143Proof23

theorem adaptive145Third143Proof49 : runCachedNode 511 131040 Adaptive145Third143Node49 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 131040 Adaptive145Third143Node49 = [103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 128, 131] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive145Third143Proof50
  · exact adaptive145Third143Proof51
  · exact adaptive145Third143Proof52
  · exact adaptive145Third143Proof53
  · exact adaptive145Third143Proof54
  · exact adaptive145Third143Proof55
  · exact adaptive145Third143Proof56
  · exact adaptive145Third143Proof57
  · exact adaptive145Third143Proof58
  · exact adaptive145Third143Proof59
  · exact adaptive145Third143Proof60
  · exact adaptive145Third143Proof61
  · exact adaptive145Third143Proof62
  · exact adaptive145Third143Proof63
  · exact adaptive145Third143Proof64
  · exact adaptive145Third143Proof65
  · exact adaptive145Third143Proof66
  · exact adaptive145Third143Proof67
  · exact adaptive145Third143Proof68
  · exact adaptive145Third143Proof69
  · exact adaptive145Third143Proof70
  · exact adaptive145Third143Proof71
  · exact adaptive145Third143Proof72
  · exact adaptive145Third143Proof73
  · exact adaptive145Third143Proof74
  · exact adaptive145Third143Proof75

#print axioms adaptive145Third143Proof49

theorem adaptive145Third143Proof76 : runCachedNode 511 131040 Adaptive145Third143Node76 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 131040 Adaptive145Third143Node76 = [102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 129, 132] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive145Third143Proof77
  · exact adaptive145Third143Proof78
  · exact adaptive145Third143Proof79
  · exact adaptive145Third143Proof80
  · exact adaptive145Third143Proof81
  · exact adaptive145Third143Proof82
  · exact adaptive145Third143Proof83
  · exact adaptive145Third143Proof84
  · exact adaptive145Third143Proof85
  · exact adaptive145Third143Proof86
  · exact adaptive145Third143Proof87
  · exact adaptive145Third143Proof88
  · exact adaptive145Third143Proof89
  · exact adaptive145Third143Proof90
  · exact adaptive145Third143Proof91
  · exact adaptive145Third143Proof92
  · exact adaptive145Third143Proof93
  · exact adaptive145Third143Proof94
  · exact adaptive145Third143Proof95
  · exact adaptive145Third143Proof96
  · exact adaptive145Third143Proof97
  · exact adaptive145Third143Proof98
  · exact adaptive145Third143Proof99
  · exact adaptive145Third143Proof100
  · exact adaptive145Third143Proof101
  · exact adaptive145Third143Proof102
  · exact adaptive145Third143Proof103
  · exact adaptive145Third143Proof104

#print axioms adaptive145Third143Proof76

theorem adaptive145Third143Proof105 : runCachedNode 511 131040 Adaptive145Third143Node105 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 131040 Adaptive145Third143Node105 = [102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 130, 133] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive145Third143Proof106
  · exact adaptive145Third143Proof107
  · exact adaptive145Third143Proof108
  · exact adaptive145Third143Proof109
  · exact adaptive145Third143Proof110
  · exact adaptive145Third143Proof111
  · exact adaptive145Third143Proof112
  · exact adaptive145Third143Proof113
  · exact adaptive145Third143Proof114
  · exact adaptive145Third143Proof115
  · exact adaptive145Third143Proof116
  · exact adaptive145Third143Proof117
  · exact adaptive145Third143Proof118
  · exact adaptive145Third143Proof119
  · exact adaptive145Third143Proof120
  · exact adaptive145Third143Proof121
  · exact adaptive145Third143Proof122
  · exact adaptive145Third143Proof123
  · exact adaptive145Third143Proof124
  · exact adaptive145Third143Proof125
  · exact adaptive145Third143Proof126
  · exact adaptive145Third143Proof127
  · exact adaptive145Third143Proof128
  · exact adaptive145Third143Proof129
  · exact adaptive145Third143Proof130
  · exact adaptive145Third143Proof131
  · exact adaptive145Third143Proof132
  · exact adaptive145Third143Proof133
  · exact adaptive145Third143Proof134

#print axioms adaptive145Third143Proof105

theorem adaptive145Third143Proof135 : runCachedNode 511 131040 Adaptive145Third143Node135 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 131040 Adaptive145Third143Node135 = [102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 131, 134] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive145Third143Proof136
  · exact adaptive145Third143Proof137
  · exact adaptive145Third143Proof138
  · exact adaptive145Third143Proof139
  · exact adaptive145Third143Proof140
  · exact adaptive145Third143Proof141
  · exact adaptive145Third143Proof142
  · exact adaptive145Third143Proof143
  · exact adaptive145Third143Proof144
  · exact adaptive145Third143Proof145
  · exact adaptive145Third143Proof146
  · exact adaptive145Third143Proof147
  · exact adaptive145Third143Proof148
  · exact adaptive145Third143Proof149
  · exact adaptive145Third143Proof150
  · exact adaptive145Third143Proof151
  · exact adaptive145Third143Proof152
  · exact adaptive145Third143Proof153
  · exact adaptive145Third143Proof154
  · exact adaptive145Third143Proof155
  · exact adaptive145Third143Proof156
  · exact adaptive145Third143Proof157
  · exact adaptive145Third143Proof158
  · exact adaptive145Third143Proof159
  · exact adaptive145Third143Proof160
  · exact adaptive145Third143Proof161
  · exact adaptive145Third143Proof162
  · exact adaptive145Third143Proof163
  · exact adaptive145Third143Proof164
  · exact adaptive145Third143Proof165

#print axioms adaptive145Third143Proof135

theorem adaptive145Third143Proof166 : runCachedNode 511 131040 Adaptive145Third143Node166 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 131040 Adaptive145Third143Node166 = [102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 132, 135] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive145Third143Proof167
  · exact adaptive145Third143Proof168
  · exact adaptive145Third143Proof169
  · exact adaptive145Third143Proof170
  · exact adaptive145Third143Proof171
  · exact adaptive145Third143Proof172
  · exact adaptive145Third143Proof173
  · exact adaptive145Third143Proof174
  · exact adaptive145Third143Proof175
  · exact adaptive145Third143Proof176
  · exact adaptive145Third143Proof177
  · exact adaptive145Third143Proof178
  · exact adaptive145Third143Proof179
  · exact adaptive145Third143Proof180
  · exact adaptive145Third143Proof181
  · exact adaptive145Third143Proof182
  · exact adaptive145Third143Proof183
  · exact adaptive145Third143Proof184
  · exact adaptive145Third143Proof185
  · exact adaptive145Third143Proof186
  · exact adaptive145Third143Proof187
  · exact adaptive145Third143Proof188
  · exact adaptive145Third143Proof189
  · exact adaptive145Third143Proof190
  · exact adaptive145Third143Proof191
  · exact adaptive145Third143Proof192
  · exact adaptive145Third143Proof193
  · exact adaptive145Third143Proof194
  · exact adaptive145Third143Proof195
  · exact adaptive145Third143Proof196
  · exact adaptive145Third143Proof197

#print axioms adaptive145Third143Proof166

theorem adaptive145Third143Proof198 : runCachedNode 511 131040 Adaptive145Third143Node198 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 131040 Adaptive145Third143Node198 = [101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 133, 136] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive145Third143Proof199
  · exact adaptive145Third143Proof200
  · exact adaptive145Third143Proof201
  · exact adaptive145Third143Proof202
  · exact adaptive145Third143Proof203
  · exact adaptive145Third143Proof204
  · exact adaptive145Third143Proof205
  · exact adaptive145Third143Proof206
  · exact adaptive145Third143Proof207
  · exact adaptive145Third143Proof208
  · exact adaptive145Third143Proof209
  · exact adaptive145Third143Proof210
  · exact adaptive145Third143Proof211
  · exact adaptive145Third143Proof212
  · exact adaptive145Third143Proof213
  · exact adaptive145Third143Proof214
  · exact adaptive145Third143Proof215
  · exact adaptive145Third143Proof216
  · exact adaptive145Third143Proof217
  · exact adaptive145Third143Proof218
  · exact adaptive145Third143Proof219
  · exact adaptive145Third143Proof220
  · exact adaptive145Third143Proof221
  · exact adaptive145Third143Proof222
  · exact adaptive145Third143Proof223
  · exact adaptive145Third143Proof224
  · exact adaptive145Third143Proof225
  · exact adaptive145Third143Proof226
  · exact adaptive145Third143Proof227
  · exact adaptive145Third143Proof228
  · exact adaptive145Third143Proof229
  · exact adaptive145Third143Proof230
  · exact adaptive145Third143Proof231

#print axioms adaptive145Third143Proof198

theorem adaptive145Third143Proof266 : runCachedNode 511 131040 Adaptive145Third143Node266 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 131040 Adaptive145Third143Node266 = [88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 126, 128, 131] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive145Third143Proof267
  · exact adaptive145Third143Proof268
  · exact adaptive145Third143Proof269
  · exact adaptive145Third143Proof270
  · exact adaptive145Third143Proof271
  · exact adaptive145Third143Proof272
  · exact adaptive145Third143Proof273
  · exact adaptive145Third143Proof274
  · exact adaptive145Third143Proof275
  · exact adaptive145Third143Proof276
  · exact adaptive145Third143Proof277
  · exact adaptive145Third143Proof278
  · exact adaptive145Third143Proof279
  · exact adaptive145Third143Proof280
  · exact adaptive145Third143Proof281
  · exact adaptive145Third143Proof282
  · exact adaptive145Third143Proof283
  · exact adaptive145Third143Proof284
  · exact adaptive145Third143Proof285
  · exact adaptive145Third143Proof286
  · exact adaptive145Third143Proof287
  · exact adaptive145Third143Proof288
  · exact adaptive145Third143Proof289
  · exact adaptive145Third143Proof290
  · exact adaptive145Third143Proof291
  · exact adaptive145Third143Proof292
  · exact adaptive145Third143Proof293
  · exact adaptive145Third143Proof294
  · exact adaptive145Third143Proof295
  · exact adaptive145Third143Proof296
  · exact adaptive145Third143Proof297
  · exact adaptive145Third143Proof298
  · exact adaptive145Third143Proof299
  · exact adaptive145Third143Proof300
  · exact adaptive145Third143Proof301
  · exact adaptive145Third143Proof302
  · exact adaptive145Third143Proof303
  · exact adaptive145Third143Proof304
  · exact adaptive145Third143Proof305
  · exact adaptive145Third143Proof306

#print axioms adaptive145Third143Proof266

end NineSeparatedSubsetSums
