import NineSeparatedSubsetSums.Adaptive145Third144State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third144Proof163 : runCachedNode 511 131183 Adaptive145Third144Node163 = false := by
  decide +kernel

#print axioms adaptive145Third144Proof163

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third144Proof717 : runCachedNode 511 131183 Adaptive145Third144Node717 = false := by
  decide +kernel

#print axioms adaptive145Third144Proof717

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third144Proof762 : runCachedNode 511 131183 Adaptive145Third144Node762 = false := by
  decide +kernel

#print axioms adaptive145Third144Proof762

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third144Proof194 : runCachedNode 511 131183 Adaptive145Third144Node194 = false := by
  decide +kernel

#print axioms adaptive145Third144Proof194

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third144Proof233 : runCachedNode 511 131183 Adaptive145Third144Node233 = false := by
  decide +kernel

#print axioms adaptive145Third144Proof233

end NineSeparatedSubsetSums
