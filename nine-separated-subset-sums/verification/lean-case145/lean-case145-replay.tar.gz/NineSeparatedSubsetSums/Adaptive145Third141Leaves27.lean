import NineSeparatedSubsetSums.Adaptive145Third141State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third141Proof362 : runCachedNode 511 130740 Adaptive145Third141Node362 = false := by
  decide +kernel

#print axioms adaptive145Third141Proof362

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third141Proof290 : runCachedNode 511 130740 Adaptive145Third141Node290 = false := by
  decide +kernel

#print axioms adaptive145Third141Proof290

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third141Proof214 : runCachedNode 511 130740 Adaptive145Third141Node214 = false := by
  decide +kernel

#print axioms adaptive145Third141Proof214

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third141Proof361 : runCachedNode 511 130740 Adaptive145Third141Node361 = false := by
  decide +kernel

#print axioms adaptive145Third141Proof361

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third141Proof120 : runCachedNode 511 130740 Adaptive145Third141Node120 = false := by
  decide +kernel

#print axioms adaptive145Third141Proof120

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third141Proof186 : runCachedNode 511 130740 Adaptive145Third141Node186 = false := by
  decide +kernel

#print axioms adaptive145Third141Proof186

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third141Proof213 : runCachedNode 511 130740 Adaptive145Third141Node213 = false := by
  decide +kernel

#print axioms adaptive145Third141Proof213

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third141Proof67 : runCachedNode 511 130740 Adaptive145Third141Node67 = false := by
  decide +kernel

#print axioms adaptive145Third141Proof67

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third141Proof151 : runCachedNode 511 130740 Adaptive145Third141Node151 = false := by
  decide +kernel

#print axioms adaptive145Third141Proof151

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third141Proof10 : runCachedNode 511 130740 Adaptive145Third141Node10 = false := by
  decide +kernel

#print axioms adaptive145Third141Proof10

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third141Proof336 : runCachedNode 511 130740 Adaptive145Third141Node336 = false := by
  decide +kernel

#print axioms adaptive145Third141Proof336

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third141Proof66 : runCachedNode 511 130740 Adaptive145Third141Node66 = false := by
  decide +kernel

#print axioms adaptive145Third141Proof66

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third141Proof289 : runCachedNode 511 130740 Adaptive145Third141Node289 = false := by
  decide +kernel

#print axioms adaptive145Third141Proof289

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third141Proof39 : runCachedNode 511 130740 Adaptive145Third141Node39 = false := by
  decide +kernel

#print axioms adaptive145Third141Proof39

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third141Proof212 : runCachedNode 511 130740 Adaptive145Third141Node212 = false := by
  decide +kernel

#print axioms adaptive145Third141Proof212

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third141Proof413 : runCachedNode 511 130740 Adaptive145Third141Node413 = false := by
  decide +kernel

#print axioms adaptive145Third141Proof413

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third141Proof40 : runCachedNode 511 130740 Adaptive145Third141Node40 = false := by
  decide +kernel

#print axioms adaptive145Third141Proof40

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third141Proof93 : runCachedNode 511 130740 Adaptive145Third141Node93 = false := by
  decide +kernel

#print axioms adaptive145Third141Proof93

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third141Proof119 : runCachedNode 511 130740 Adaptive145Third141Node119 = false := by
  decide +kernel

#print axioms adaptive145Third141Proof119

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third141Proof150 : runCachedNode 511 130740 Adaptive145Third141Node150 = false := by
  decide +kernel

#print axioms adaptive145Third141Proof150

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third141Proof82 : runCachedNode 511 130740 Adaptive145Third141Node82 = false := by
  decide +kernel

#print axioms adaptive145Third141Proof82

end NineSeparatedSubsetSums
