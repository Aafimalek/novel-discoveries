import NineSeparatedSubsetSums.Adaptive145Third138State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third138Proof160 : runCachedNode 511 130311 Adaptive145Third138Node160 = false := by
  decide +kernel

#print axioms adaptive145Third138Proof160

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third138Proof15 : runCachedNode 511 130311 Adaptive145Third138Node15 = false := by
  decide +kernel

#print axioms adaptive145Third138Proof15

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third138Proof99 : runCachedNode 511 130311 Adaptive145Third138Node99 = false := by
  decide +kernel

#print axioms adaptive145Third138Proof99

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third138Proof191 : runCachedNode 511 130311 Adaptive145Third138Node191 = false := by
  decide +kernel

#print axioms adaptive145Third138Proof191

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third138Proof150 : runCachedNode 511 130311 Adaptive145Third138Node150 = false := by
  decide +kernel

#print axioms adaptive145Third138Proof150

end NineSeparatedSubsetSums
