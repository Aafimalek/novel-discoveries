import NineSeparatedSubsetSums.Adaptive145Third143State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof132 : runCachedNode 511 131040 Adaptive145Third143Node132 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof132

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof339 : runCachedNode 511 131040 Adaptive145Third143Node339 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof339

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof493 : runCachedNode 511 131040 Adaptive145Third143Node493 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof493

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof547 : runCachedNode 511 131040 Adaptive145Third143Node547 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof547

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof99 : runCachedNode 511 131040 Adaptive145Third143Node99 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof99

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof80 : runCachedNode 511 131040 Adaptive145Third143Node80 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof80

end NineSeparatedSubsetSums
