import NineSeparatedSubsetSums.Adaptive145Third136State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third136Proof18 : runCachedNode 511 130013 Adaptive145Third136Node18 = false := by
  decide +kernel

#print axioms adaptive145Third136Proof18

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third136Proof15 : runCachedNode 511 130013 Adaptive145Third136Node15 = false := by
  decide +kernel

#print axioms adaptive145Third136Proof15

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third136Proof80 : runCachedNode 511 130013 Adaptive145Third136Node80 = false := by
  decide +kernel

#print axioms adaptive145Third136Proof80

end NineSeparatedSubsetSums
