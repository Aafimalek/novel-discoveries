import NineSeparatedSubsetSums.Adaptive145Third131State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third131Proof20 : runCachedNode 511 129127 Adaptive145Third131Node20 = false := by
  decide +kernel

#print axioms adaptive145Third131Proof20

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third131Proof16 : runCachedNode 511 129127 Adaptive145Third131Node16 = false := by
  decide +kernel

#print axioms adaptive145Third131Proof16

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third131Proof5 : runCachedNode 511 129127 Adaptive145Third131Node5 = false := by
  decide +kernel

#print axioms adaptive145Third131Proof5

end NineSeparatedSubsetSums
