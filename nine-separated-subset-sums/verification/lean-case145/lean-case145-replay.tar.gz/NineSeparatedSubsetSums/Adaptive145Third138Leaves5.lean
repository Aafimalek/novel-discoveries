import NineSeparatedSubsetSums.Adaptive145Third138State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third138Proof159 : runCachedNode 511 130311 Adaptive145Third138Node159 = false := by
  decide +kernel

#print axioms adaptive145Third138Proof159

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third138Proof128 : runCachedNode 511 130311 Adaptive145Third138Node128 = false := by
  decide +kernel

#print axioms adaptive145Third138Proof128

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third138Proof153 : runCachedNode 511 130311 Adaptive145Third138Node153 = false := by
  decide +kernel

#print axioms adaptive145Third138Proof153

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third138Proof75 : runCachedNode 511 130311 Adaptive145Third138Node75 = false := by
  decide +kernel

#print axioms adaptive145Third138Proof75

end NineSeparatedSubsetSums
