import NineSeparatedSubsetSums.Adaptive145Third143State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof500 : runCachedNode 511 131040 Adaptive145Third143Node500 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof500

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof415 : runCachedNode 511 131040 Adaptive145Third143Node415 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof415

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof31 : runCachedNode 511 131040 Adaptive145Third143Node31 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof31

end NineSeparatedSubsetSums
