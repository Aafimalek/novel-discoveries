import NineSeparatedSubsetSums.Adaptive145Third142State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof577 : runCachedNode 511 130865 Adaptive145Third142Node577 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof577

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof801 : runCachedNode 511 130865 Adaptive145Third142Node801 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof801

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof691 : runCachedNode 511 130865 Adaptive145Third142Node691 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof691

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof216 : runCachedNode 511 130865 Adaptive145Third142Node216 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof216

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof857 : runCachedNode 511 130865 Adaptive145Third142Node857 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof857

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof307 : runCachedNode 511 130865 Adaptive145Third142Node307 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof307

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof104 : runCachedNode 511 130865 Adaptive145Third142Node104 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof104

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof275 : runCachedNode 511 130865 Adaptive145Third142Node275 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof275

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof525 : runCachedNode 511 130865 Adaptive145Third142Node525 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof525

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof640 : runCachedNode 511 130865 Adaptive145Third142Node640 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof640

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof692 : runCachedNode 511 130865 Adaptive145Third142Node692 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof692

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof734 : runCachedNode 511 130865 Adaptive145Third142Node734 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof734

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof348 : runCachedNode 511 130865 Adaptive145Third142Node348 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof348

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof942 : runCachedNode 511 130865 Adaptive145Third142Node942 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof942

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof214 : runCachedNode 511 130865 Adaptive145Third142Node214 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof214

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof237 : runCachedNode 511 130865 Adaptive145Third142Node237 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof237

end NineSeparatedSubsetSums
