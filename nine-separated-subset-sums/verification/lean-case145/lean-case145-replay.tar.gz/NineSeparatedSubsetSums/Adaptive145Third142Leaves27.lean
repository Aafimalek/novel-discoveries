import NineSeparatedSubsetSums.Adaptive145Third142State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof536 : runCachedNode 511 130865 Adaptive145Third142Node536 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof536

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof197 : runCachedNode 511 130865 Adaptive145Third142Node197 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof197

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof378 : runCachedNode 511 130865 Adaptive145Third142Node378 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof378

end NineSeparatedSubsetSums
