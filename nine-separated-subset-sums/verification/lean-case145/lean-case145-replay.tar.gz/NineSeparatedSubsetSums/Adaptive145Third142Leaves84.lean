import NineSeparatedSubsetSums.Adaptive145Third142State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof864 : runCachedNode 511 130865 Adaptive145Third142Node864 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof864

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof865 : runCachedNode 511 130865 Adaptive145Third142Node865 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof865

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof866 : runCachedNode 511 130865 Adaptive145Third142Node866 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof866

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof867 : runCachedNode 511 130865 Adaptive145Third142Node867 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof867

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof868 : runCachedNode 511 130865 Adaptive145Third142Node868 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof868

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof869 : runCachedNode 511 130865 Adaptive145Third142Node869 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof869

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof870 : runCachedNode 511 130865 Adaptive145Third142Node870 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof870

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof906 : runCachedNode 511 130865 Adaptive145Third142Node906 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof906

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof907 : runCachedNode 511 130865 Adaptive145Third142Node907 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof907

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof908 : runCachedNode 511 130865 Adaptive145Third142Node908 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof908

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof909 : runCachedNode 511 130865 Adaptive145Third142Node909 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof909

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof910 : runCachedNode 511 130865 Adaptive145Third142Node910 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof910

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof911 : runCachedNode 511 130865 Adaptive145Third142Node911 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof911

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof912 : runCachedNode 511 130865 Adaptive145Third142Node912 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof912

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof913 : runCachedNode 511 130865 Adaptive145Third142Node913 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof913

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof914 : runCachedNode 511 130865 Adaptive145Third142Node914 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof914

end NineSeparatedSubsetSums
