import NineSeparatedSubsetSums.Adaptive145Third136State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third136Proof12 : runCachedNode 511 130013 Adaptive145Third136Node12 = false := by
  decide +kernel

#print axioms adaptive145Third136Proof12

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third136Proof121 : runCachedNode 511 130013 Adaptive145Third136Node121 = false := by
  decide +kernel

#print axioms adaptive145Third136Proof121

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third136Proof42 : runCachedNode 511 130013 Adaptive145Third136Node42 = false := by
  decide +kernel

#print axioms adaptive145Third136Proof42

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third136Proof68 : runCachedNode 511 130013 Adaptive145Third136Node68 = false := by
  decide +kernel

#print axioms adaptive145Third136Proof68

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third136Proof148 : runCachedNode 511 130013 Adaptive145Third136Node148 = false := by
  decide +kernel

#print axioms adaptive145Third136Proof148

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third136Proof117 : runCachedNode 511 130013 Adaptive145Third136Node117 = false := by
  decide +kernel

#print axioms adaptive145Third136Proof117

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third136Proof65 : runCachedNode 511 130013 Adaptive145Third136Node65 = false := by
  decide +kernel

#print axioms adaptive145Third136Proof65

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third136Proof89 : runCachedNode 511 130013 Adaptive145Third136Node89 = false := by
  decide +kernel

#print axioms adaptive145Third136Proof89

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third136Proof9 : runCachedNode 511 130013 Adaptive145Third136Node9 = false := by
  decide +kernel

#print axioms adaptive145Third136Proof9

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third136Proof81 : runCachedNode 511 130013 Adaptive145Third136Node81 = false := by
  decide +kernel

#print axioms adaptive145Third136Proof81

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third136Proof71 : runCachedNode 511 130013 Adaptive145Third136Node71 = false := by
  decide +kernel

#print axioms adaptive145Third136Proof71

end NineSeparatedSubsetSums
