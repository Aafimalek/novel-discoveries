import NineSeparatedSubsetSums.Adaptive145Third138State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third138Proof19 : runCachedNode 511 130311 Adaptive145Third138Node19 = false := by
  decide +kernel

#print axioms adaptive145Third138Proof19

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third138Proof189 : runCachedNode 511 130311 Adaptive145Third138Node189 = false := by
  decide +kernel

#print axioms adaptive145Third138Proof189

end NineSeparatedSubsetSums
