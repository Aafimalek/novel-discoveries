import NineSeparatedSubsetSums.Adaptive145Third137State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third137Proof91 : runCachedNode 511 130164 Adaptive145Third137Node91 = false := by
  decide +kernel

#print axioms adaptive145Third137Proof91

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third137Proof178 : runCachedNode 511 130164 Adaptive145Third137Node178 = false := by
  decide +kernel

#print axioms adaptive145Third137Proof178

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third137Proof15 : runCachedNode 511 130164 Adaptive145Third137Node15 = false := by
  decide +kernel

#print axioms adaptive145Third137Proof15

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third137Proof121 : runCachedNode 511 130164 Adaptive145Third137Node121 = false := by
  decide +kernel

#print axioms adaptive145Third137Proof121

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third137Proof89 : runCachedNode 511 130164 Adaptive145Third137Node89 = false := by
  decide +kernel

#print axioms adaptive145Third137Proof89

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third137Proof125 : runCachedNode 511 130164 Adaptive145Third137Node125 = false := by
  decide +kernel

#print axioms adaptive145Third137Proof125

end NineSeparatedSubsetSums
