import NineSeparatedSubsetSums.Adaptive145Third117State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third117Proof0 : runCachedNode 511 125802 Adaptive145Third117Node0 = false := by
  decide +kernel

#print axioms adaptive145Third117Proof0

end NineSeparatedSubsetSums
