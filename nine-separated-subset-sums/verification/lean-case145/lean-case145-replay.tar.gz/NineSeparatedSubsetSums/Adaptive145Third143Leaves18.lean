import NineSeparatedSubsetSums.Adaptive145Third143State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof19 : runCachedNode 511 131040 Adaptive145Third143Node19 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof19

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof596 : runCachedNode 511 131040 Adaptive145Third143Node596 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof596

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof110 : runCachedNode 511 131040 Adaptive145Third143Node110 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof110

end NineSeparatedSubsetSums
