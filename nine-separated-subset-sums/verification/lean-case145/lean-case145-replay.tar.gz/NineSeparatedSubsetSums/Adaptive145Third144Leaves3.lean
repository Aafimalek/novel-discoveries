import NineSeparatedSubsetSums.Adaptive145Third144State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third144Proof373 : runCachedNode 511 131183 Adaptive145Third144Node373 = false := by
  decide +kernel

#print axioms adaptive145Third144Proof373

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third144Proof189 : runCachedNode 511 131183 Adaptive145Third144Node189 = false := by
  decide +kernel

#print axioms adaptive145Third144Proof189

end NineSeparatedSubsetSums
