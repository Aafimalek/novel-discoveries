import NineSeparatedSubsetSums.Adaptive145Third104State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third104Proof0 : runCachedNode 511 112442 Adaptive145Third104Node0 = false := by
  decide +kernel

#print axioms adaptive145Third104Proof0

end NineSeparatedSubsetSums
