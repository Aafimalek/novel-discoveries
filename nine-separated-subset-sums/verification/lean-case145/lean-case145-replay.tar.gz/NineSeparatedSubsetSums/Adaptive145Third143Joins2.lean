import NineSeparatedSubsetSums.Adaptive145Third143State
import NineSeparatedSubsetSums.Adaptive145Third143Leaves3
import NineSeparatedSubsetSums.Adaptive145Third143Leaves4
import NineSeparatedSubsetSums.Adaptive145Third143Leaves41
import NineSeparatedSubsetSums.Adaptive145Third143Leaves7
import NineSeparatedSubsetSums.Adaptive145Third143Leaves52
import NineSeparatedSubsetSums.Adaptive145Third143Leaves23
import NineSeparatedSubsetSums.Adaptive145Third143Leaves51
import NineSeparatedSubsetSums.Adaptive145Third143Leaves33
import NineSeparatedSubsetSums.Adaptive145Third143Leaves48
import NineSeparatedSubsetSums.Adaptive145Third143Leaves29
import NineSeparatedSubsetSums.Adaptive145Third143Leaves43
import NineSeparatedSubsetSums.Adaptive145Third143Leaves39
import NineSeparatedSubsetSums.Adaptive145Third143Leaves36
import NineSeparatedSubsetSums.Adaptive145Third143Leaves26
import NineSeparatedSubsetSums.Adaptive145Third143Leaves13
import NineSeparatedSubsetSums.Adaptive145Third143Leaves18
import NineSeparatedSubsetSums.Adaptive145Third143Leaves11
import NineSeparatedSubsetSums.Adaptive145Third143Joins0
import NineSeparatedSubsetSums.Adaptive145Third143Joins1

namespace NineSeparatedSubsetSums

theorem adaptive145Third143Proof0 : runCachedNode 511 131040 Adaptive145Third143Node0 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 131040 Adaptive145Third143Node0 = [109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 132, 133, 134, 135, 136, 137, 138, 139, 141, 142] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive145Third143Proof1
  · exact adaptive145Third143Proof2
  · exact adaptive145Third143Proof3
  · exact adaptive145Third143Proof4
  · exact adaptive145Third143Proof5
  · exact adaptive145Third143Proof6
  · exact adaptive145Third143Proof7
  · exact adaptive145Third143Proof8
  · exact adaptive145Third143Proof9
  · exact adaptive145Third143Proof10
  · exact adaptive145Third143Proof11
  · exact adaptive145Third143Proof12
  · exact adaptive145Third143Proof13
  · exact adaptive145Third143Proof14
  · exact adaptive145Third143Proof15
  · exact adaptive145Third143Proof16
  · exact adaptive145Third143Proof17
  · exact adaptive145Third143Proof18
  · exact adaptive145Third143Proof19
  · exact adaptive145Third143Proof20
  · exact adaptive145Third143Proof21
  · exact adaptive145Third143Proof22
  · exact adaptive145Third143Proof23
  · exact adaptive145Third143Proof49
  · exact adaptive145Third143Proof76
  · exact adaptive145Third143Proof105
  · exact adaptive145Third143Proof135
  · exact adaptive145Third143Proof166
  · exact adaptive145Third143Proof198
  · exact adaptive145Third143Proof232
  · exact adaptive145Third143Proof307
  · exact adaptive145Third143Proof384
  · exact adaptive145Third143Proof465

#print axioms adaptive145Third143Proof0

end NineSeparatedSubsetSums
