import NineSeparatedSubsetSums.Adaptive145Third144State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third144Proof670 : runCachedNode 511 131183 Adaptive145Third144Node670 = false := by
  decide +kernel

#print axioms adaptive145Third144Proof670

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third144Proof485 : runCachedNode 511 131183 Adaptive145Third144Node485 = false := by
  decide +kernel

#print axioms adaptive145Third144Proof485

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third144Proof256 : runCachedNode 511 131183 Adaptive145Third144Node256 = false := by
  decide +kernel

#print axioms adaptive145Third144Proof256

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third144Proof583 : runCachedNode 511 131183 Adaptive145Third144Node583 = false := by
  decide +kernel

#print axioms adaptive145Third144Proof583

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third144Proof45 : runCachedNode 511 131183 Adaptive145Third144Node45 = false := by
  decide +kernel

#print axioms adaptive145Third144Proof45

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third144Proof73 : runCachedNode 511 131183 Adaptive145Third144Node73 = false := by
  decide +kernel

#print axioms adaptive145Third144Proof73

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third144Proof714 : runCachedNode 511 131183 Adaptive145Third144Node714 = false := by
  decide +kernel

#print axioms adaptive145Third144Proof714

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third144Proof153 : runCachedNode 511 131183 Adaptive145Third144Node153 = false := by
  decide +kernel

#print axioms adaptive145Third144Proof153

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third144Proof268 : runCachedNode 511 131183 Adaptive145Third144Node268 = false := by
  decide +kernel

#print axioms adaptive145Third144Proof268

end NineSeparatedSubsetSums
