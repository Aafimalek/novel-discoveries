import NineSeparatedSubsetSums.Adaptive145Third134State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third134Proof21 : runCachedNode 511 129715 Adaptive145Third134Node21 = false := by
  decide +kernel

#print axioms adaptive145Third134Proof21

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third134Proof14 : runCachedNode 511 129715 Adaptive145Third134Node14 = false := by
  decide +kernel

#print axioms adaptive145Third134Proof14

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third134Proof34 : runCachedNode 511 129715 Adaptive145Third134Node34 = false := by
  decide +kernel

#print axioms adaptive145Third134Proof34

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third134Proof27 : runCachedNode 511 129715 Adaptive145Third134Node27 = false := by
  decide +kernel

#print axioms adaptive145Third134Proof27

end NineSeparatedSubsetSums
