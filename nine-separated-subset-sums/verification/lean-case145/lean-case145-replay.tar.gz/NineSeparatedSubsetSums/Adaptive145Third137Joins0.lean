import NineSeparatedSubsetSums.Adaptive145Third137State
import NineSeparatedSubsetSums.Adaptive145Third137Leaves14
import NineSeparatedSubsetSums.Adaptive145Third137Leaves9
import NineSeparatedSubsetSums.Adaptive145Third137Leaves6
import NineSeparatedSubsetSums.Adaptive145Third137Leaves13
import NineSeparatedSubsetSums.Adaptive145Third137Leaves12
import NineSeparatedSubsetSums.Adaptive145Third137Leaves11
import NineSeparatedSubsetSums.Adaptive145Third137Leaves10
import NineSeparatedSubsetSums.Adaptive145Third137Leaves8
import NineSeparatedSubsetSums.Adaptive145Third137Leaves0
import NineSeparatedSubsetSums.Adaptive145Third137Leaves5
import NineSeparatedSubsetSums.Adaptive145Third137Leaves4
import NineSeparatedSubsetSums.Adaptive145Third137Leaves3
import NineSeparatedSubsetSums.Adaptive145Third137Leaves7
import NineSeparatedSubsetSums.Adaptive145Third137Leaves2
import NineSeparatedSubsetSums.Adaptive145Third137Leaves15
import NineSeparatedSubsetSums.Adaptive145Third137Leaves1

namespace NineSeparatedSubsetSums

theorem adaptive145Third137Proof20 : runCachedNode 511 130164 Adaptive145Third137Node20 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130164 Adaptive145Third137Node20 = [104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 119, 120, 122, 123, 124, 125, 127, 128] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive145Third137Proof21
  · exact adaptive145Third137Proof22
  · exact adaptive145Third137Proof23
  · exact adaptive145Third137Proof24
  · exact adaptive145Third137Proof25
  · exact adaptive145Third137Proof26
  · exact adaptive145Third137Proof27
  · exact adaptive145Third137Proof28
  · exact adaptive145Third137Proof29
  · exact adaptive145Third137Proof30
  · exact adaptive145Third137Proof31
  · exact adaptive145Third137Proof32
  · exact adaptive145Third137Proof33
  · exact adaptive145Third137Proof34
  · exact adaptive145Third137Proof35
  · exact adaptive145Third137Proof36
  · exact adaptive145Third137Proof37
  · exact adaptive145Third137Proof38
  · exact adaptive145Third137Proof39
  · exact adaptive145Third137Proof40
  · exact adaptive145Third137Proof41
  · exact adaptive145Third137Proof42

#print axioms adaptive145Third137Proof20

theorem adaptive145Third137Proof44 : runCachedNode 511 130164 Adaptive145Third137Node44 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130164 Adaptive145Third137Node44 = [104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 121, 122, 124, 125, 126, 127, 129, 130] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive145Third137Proof45
  · exact adaptive145Third137Proof46
  · exact adaptive145Third137Proof47
  · exact adaptive145Third137Proof48
  · exact adaptive145Third137Proof49
  · exact adaptive145Third137Proof50
  · exact adaptive145Third137Proof51
  · exact adaptive145Third137Proof52
  · exact adaptive145Third137Proof53
  · exact adaptive145Third137Proof54
  · exact adaptive145Third137Proof55
  · exact adaptive145Third137Proof56
  · exact adaptive145Third137Proof57
  · exact adaptive145Third137Proof58
  · exact adaptive145Third137Proof59
  · exact adaptive145Third137Proof60
  · exact adaptive145Third137Proof61
  · exact adaptive145Third137Proof62
  · exact adaptive145Third137Proof63
  · exact adaptive145Third137Proof64
  · exact adaptive145Third137Proof65
  · exact adaptive145Third137Proof66
  · exact adaptive145Third137Proof67
  · exact adaptive145Third137Proof68

#print axioms adaptive145Third137Proof44

theorem adaptive145Third137Proof69 : runCachedNode 511 130164 Adaptive145Third137Node69 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130164 Adaptive145Third137Node69 = [104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 122, 123, 125, 126, 127, 128, 130, 131] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive145Third137Proof70
  · exact adaptive145Third137Proof71
  · exact adaptive145Third137Proof72
  · exact adaptive145Third137Proof73
  · exact adaptive145Third137Proof74
  · exact adaptive145Third137Proof75
  · exact adaptive145Third137Proof76
  · exact adaptive145Third137Proof77
  · exact adaptive145Third137Proof78
  · exact adaptive145Third137Proof79
  · exact adaptive145Third137Proof80
  · exact adaptive145Third137Proof81
  · exact adaptive145Third137Proof82
  · exact adaptive145Third137Proof83
  · exact adaptive145Third137Proof84
  · exact adaptive145Third137Proof85
  · exact adaptive145Third137Proof86
  · exact adaptive145Third137Proof87
  · exact adaptive145Third137Proof88
  · exact adaptive145Third137Proof89
  · exact adaptive145Third137Proof90
  · exact adaptive145Third137Proof91
  · exact adaptive145Third137Proof92
  · exact adaptive145Third137Proof93
  · exact adaptive145Third137Proof94

#print axioms adaptive145Third137Proof69

theorem adaptive145Third137Proof95 : runCachedNode 511 130164 Adaptive145Third137Node95 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130164 Adaptive145Third137Node95 = [103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 123, 124, 126, 127, 128, 129, 131, 132] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive145Third137Proof96
  · exact adaptive145Third137Proof97
  · exact adaptive145Third137Proof98
  · exact adaptive145Third137Proof99
  · exact adaptive145Third137Proof100
  · exact adaptive145Third137Proof101
  · exact adaptive145Third137Proof102
  · exact adaptive145Third137Proof103
  · exact adaptive145Third137Proof104
  · exact adaptive145Third137Proof105
  · exact adaptive145Third137Proof106
  · exact adaptive145Third137Proof107
  · exact adaptive145Third137Proof108
  · exact adaptive145Third137Proof109
  · exact adaptive145Third137Proof110
  · exact adaptive145Third137Proof111
  · exact adaptive145Third137Proof112
  · exact adaptive145Third137Proof113
  · exact adaptive145Third137Proof114
  · exact adaptive145Third137Proof115
  · exact adaptive145Third137Proof116
  · exact adaptive145Third137Proof117
  · exact adaptive145Third137Proof118
  · exact adaptive145Third137Proof119
  · exact adaptive145Third137Proof120
  · exact adaptive145Third137Proof121
  · exact adaptive145Third137Proof122

#print axioms adaptive145Third137Proof95

theorem adaptive145Third137Proof123 : runCachedNode 511 130164 Adaptive145Third137Node123 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130164 Adaptive145Third137Node123 = [103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 125, 126, 128, 129, 130, 131, 133] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive145Third137Proof124
  · exact adaptive145Third137Proof125
  · exact adaptive145Third137Proof126
  · exact adaptive145Third137Proof127
  · exact adaptive145Third137Proof128
  · exact adaptive145Third137Proof129
  · exact adaptive145Third137Proof130
  · exact adaptive145Third137Proof131
  · exact adaptive145Third137Proof132
  · exact adaptive145Third137Proof133
  · exact adaptive145Third137Proof134
  · exact adaptive145Third137Proof135
  · exact adaptive145Third137Proof136
  · exact adaptive145Third137Proof137
  · exact adaptive145Third137Proof138
  · exact adaptive145Third137Proof139
  · exact adaptive145Third137Proof140
  · exact adaptive145Third137Proof141
  · exact adaptive145Third137Proof142
  · exact adaptive145Third137Proof143
  · exact adaptive145Third137Proof144
  · exact adaptive145Third137Proof145
  · exact adaptive145Third137Proof146
  · exact adaptive145Third137Proof147
  · exact adaptive145Third137Proof148
  · exact adaptive145Third137Proof149
  · exact adaptive145Third137Proof150
  · exact adaptive145Third137Proof151

#print axioms adaptive145Third137Proof123

theorem adaptive145Third137Proof152 : runCachedNode 511 130164 Adaptive145Third137Node152 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130164 Adaptive145Third137Node152 = [102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 126, 127, 129, 130, 131, 132, 135] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive145Third137Proof153
  · exact adaptive145Third137Proof154
  · exact adaptive145Third137Proof155
  · exact adaptive145Third137Proof156
  · exact adaptive145Third137Proof157
  · exact adaptive145Third137Proof158
  · exact adaptive145Third137Proof159
  · exact adaptive145Third137Proof160
  · exact adaptive145Third137Proof161
  · exact adaptive145Third137Proof162
  · exact adaptive145Third137Proof163
  · exact adaptive145Third137Proof164
  · exact adaptive145Third137Proof165
  · exact adaptive145Third137Proof166
  · exact adaptive145Third137Proof167
  · exact adaptive145Third137Proof168
  · exact adaptive145Third137Proof169
  · exact adaptive145Third137Proof170
  · exact adaptive145Third137Proof171
  · exact adaptive145Third137Proof172
  · exact adaptive145Third137Proof173
  · exact adaptive145Third137Proof174
  · exact adaptive145Third137Proof175
  · exact adaptive145Third137Proof176
  · exact adaptive145Third137Proof177
  · exact adaptive145Third137Proof178
  · exact adaptive145Third137Proof179
  · exact adaptive145Third137Proof180
  · exact adaptive145Third137Proof181
  · exact adaptive145Third137Proof182

#print axioms adaptive145Third137Proof152

theorem adaptive145Third137Proof0 : runCachedNode 511 130164 Adaptive145Third137Node0 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130164 Adaptive145Third137Node0 = [110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 132, 133, 135, 136] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive145Third137Proof1
  · exact adaptive145Third137Proof2
  · exact adaptive145Third137Proof3
  · exact adaptive145Third137Proof4
  · exact adaptive145Third137Proof5
  · exact adaptive145Third137Proof6
  · exact adaptive145Third137Proof7
  · exact adaptive145Third137Proof8
  · exact adaptive145Third137Proof9
  · exact adaptive145Third137Proof10
  · exact adaptive145Third137Proof11
  · exact adaptive145Third137Proof12
  · exact adaptive145Third137Proof13
  · exact adaptive145Third137Proof14
  · exact adaptive145Third137Proof15
  · exact adaptive145Third137Proof16
  · exact adaptive145Third137Proof17
  · exact adaptive145Third137Proof18
  · exact adaptive145Third137Proof19
  · exact adaptive145Third137Proof20
  · exact adaptive145Third137Proof43
  · exact adaptive145Third137Proof44
  · exact adaptive145Third137Proof69
  · exact adaptive145Third137Proof95
  · exact adaptive145Third137Proof123
  · exact adaptive145Third137Proof152

#print axioms adaptive145Third137Proof0

end NineSeparatedSubsetSums
