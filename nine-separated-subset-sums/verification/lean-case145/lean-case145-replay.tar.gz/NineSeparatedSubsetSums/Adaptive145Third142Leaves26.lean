import NineSeparatedSubsetSums.Adaptive145Third142State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof256 : runCachedNode 511 130865 Adaptive145Third142Node256 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof256

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof951 : runCachedNode 511 130865 Adaptive145Third142Node951 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof951

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof42 : runCachedNode 511 130865 Adaptive145Third142Node42 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof42

end NineSeparatedSubsetSums
