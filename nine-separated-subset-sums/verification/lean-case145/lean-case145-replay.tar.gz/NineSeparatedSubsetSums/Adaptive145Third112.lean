import NineSeparatedSubsetSums.Adaptive145Third112Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint145Checked

namespace NineSeparatedSubsetSums


theorem adaptive145Third112 : NoDescendingTailAfterThird 145 112 :=
  noDescendingThirdTail_of_cached 145 112 112442 (fun t ht nd => max148_second145_fourPoint_moment_bound (112::t) (by simp [ht]) nd) adaptive145Third112Proof0

#print axioms adaptive145Third112

end NineSeparatedSubsetSums
