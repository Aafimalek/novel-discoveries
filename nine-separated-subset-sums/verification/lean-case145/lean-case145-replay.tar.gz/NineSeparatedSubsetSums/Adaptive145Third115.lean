import NineSeparatedSubsetSums.Adaptive145Third115Joins0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint145Checked

namespace NineSeparatedSubsetSums


theorem adaptive145Third115 : NoDescendingTailAfterThird 145 115 :=
  noDescendingThirdTail_of_cached 145 115 112442 (fun t ht nd => max148_second145_fourPoint_moment_bound (115::t) (by simp [ht]) nd) adaptive145Third115Proof0

#print axioms adaptive145Third115

end NineSeparatedSubsetSums
