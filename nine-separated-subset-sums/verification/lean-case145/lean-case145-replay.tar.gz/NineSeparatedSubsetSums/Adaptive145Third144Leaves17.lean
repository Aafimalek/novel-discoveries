import NineSeparatedSubsetSums.Adaptive145Third144State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third144Proof19 : runCachedNode 511 131183 Adaptive145Third144Node19 = false := by
  decide +kernel

#print axioms adaptive145Third144Proof19

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third144Proof625 : runCachedNode 511 131183 Adaptive145Third144Node625 = false := by
  decide +kernel

#print axioms adaptive145Third144Proof625

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third144Proof88 : runCachedNode 511 131183 Adaptive145Third144Node88 = false := by
  decide +kernel

#print axioms adaptive145Third144Proof88

end NineSeparatedSubsetSums
