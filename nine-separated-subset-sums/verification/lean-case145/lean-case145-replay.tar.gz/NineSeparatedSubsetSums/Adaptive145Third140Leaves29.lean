import NineSeparatedSubsetSums.Adaptive145Third140State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third140Proof266 : runCachedNode 511 130597 Adaptive145Third140Node266 = false := by
  decide +kernel

#print axioms adaptive145Third140Proof266

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third140Proof267 : runCachedNode 511 130597 Adaptive145Third140Node267 = false := by
  decide +kernel

#print axioms adaptive145Third140Proof267

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third140Proof268 : runCachedNode 511 130597 Adaptive145Third140Node268 = false := by
  decide +kernel

#print axioms adaptive145Third140Proof268

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third140Proof269 : runCachedNode 511 130597 Adaptive145Third140Node269 = false := by
  decide +kernel

#print axioms adaptive145Third140Proof269

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third140Proof270 : runCachedNode 511 130597 Adaptive145Third140Node270 = false := by
  decide +kernel

#print axioms adaptive145Third140Proof270

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third140Proof271 : runCachedNode 511 130597 Adaptive145Third140Node271 = false := by
  decide +kernel

#print axioms adaptive145Third140Proof271

end NineSeparatedSubsetSums
