import NineSeparatedSubsetSums.Adaptive145Third141State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third141Proof228 : runCachedNode 511 130740 Adaptive145Third141Node228 = false := by
  decide +kernel

#print axioms adaptive145Third141Proof228

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third141Proof420 : runCachedNode 511 130740 Adaptive145Third141Node420 = false := by
  decide +kernel

#print axioms adaptive145Third141Proof420

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third141Proof86 : runCachedNode 511 130740 Adaptive145Third141Node86 = false := by
  decide +kernel

#print axioms adaptive145Third141Proof86

end NineSeparatedSubsetSums
