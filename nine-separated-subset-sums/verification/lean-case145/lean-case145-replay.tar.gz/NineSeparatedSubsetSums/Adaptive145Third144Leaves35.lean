import NineSeparatedSubsetSums.Adaptive145Third144State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third144Proof330 : runCachedNode 511 131183 Adaptive145Third144Node330 = false := by
  decide +kernel

#print axioms adaptive145Third144Proof330

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third144Proof48 : runCachedNode 511 131183 Adaptive145Third144Node48 = false := by
  decide +kernel

#print axioms adaptive145Third144Proof48

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third144Proof226 : runCachedNode 511 131183 Adaptive145Third144Node226 = false := by
  decide +kernel

#print axioms adaptive145Third144Proof226

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third144Proof297 : runCachedNode 511 131183 Adaptive145Third144Node297 = false := by
  decide +kernel

#print axioms adaptive145Third144Proof297

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third144Proof96 : runCachedNode 511 131183 Adaptive145Third144Node96 = false := by
  decide +kernel

#print axioms adaptive145Third144Proof96

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third144Proof50 : runCachedNode 511 131183 Adaptive145Third144Node50 = false := by
  decide +kernel

#print axioms adaptive145Third144Proof50

end NineSeparatedSubsetSums
