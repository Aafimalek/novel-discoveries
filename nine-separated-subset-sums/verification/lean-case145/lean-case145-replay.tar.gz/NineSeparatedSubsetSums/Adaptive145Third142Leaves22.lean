import NineSeparatedSubsetSums.Adaptive145Third142State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof258 : runCachedNode 511 130865 Adaptive145Third142Node258 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof258

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof15 : runCachedNode 511 130865 Adaptive145Third142Node15 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof15

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof357 : runCachedNode 511 130865 Adaptive145Third142Node357 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof357

end NineSeparatedSubsetSums
