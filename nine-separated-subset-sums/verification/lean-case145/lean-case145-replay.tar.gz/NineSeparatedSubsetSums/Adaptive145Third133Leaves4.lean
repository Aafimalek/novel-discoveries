import NineSeparatedSubsetSums.Adaptive145Third133State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third133Proof12 : runCachedNode 511 129495 Adaptive145Third133Node12 = false := by
  decide +kernel

#print axioms adaptive145Third133Proof12

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third133Proof45 : runCachedNode 511 129495 Adaptive145Third133Node45 = false := by
  decide +kernel

#print axioms adaptive145Third133Proof45

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third133Proof11 : runCachedNode 511 129495 Adaptive145Third133Node11 = false := by
  decide +kernel

#print axioms adaptive145Third133Proof11

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third133Proof43 : runCachedNode 511 129495 Adaptive145Third133Node43 = false := by
  decide +kernel

#print axioms adaptive145Third133Proof43

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third133Proof10 : runCachedNode 511 129495 Adaptive145Third133Node10 = false := by
  decide +kernel

#print axioms adaptive145Third133Proof10

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third133Proof9 : runCachedNode 511 129495 Adaptive145Third133Node9 = false := by
  decide +kernel

#print axioms adaptive145Third133Proof9

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third133Proof44 : runCachedNode 511 129495 Adaptive145Third133Node44 = false := by
  decide +kernel

#print axioms adaptive145Third133Proof44

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third133Proof40 : runCachedNode 511 129495 Adaptive145Third133Node40 = false := by
  decide +kernel

#print axioms adaptive145Third133Proof40

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third133Proof8 : runCachedNode 511 129495 Adaptive145Third133Node8 = false := by
  decide +kernel

#print axioms adaptive145Third133Proof8

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third133Proof42 : runCachedNode 511 129495 Adaptive145Third133Node42 = false := by
  decide +kernel

#print axioms adaptive145Third133Proof42

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third133Proof38 : runCachedNode 511 129495 Adaptive145Third133Node38 = false := by
  decide +kernel

#print axioms adaptive145Third133Proof38

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third133Proof7 : runCachedNode 511 129495 Adaptive145Third133Node7 = false := by
  decide +kernel

#print axioms adaptive145Third133Proof7

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third133Proof41 : runCachedNode 511 129495 Adaptive145Third133Node41 = false := by
  decide +kernel

#print axioms adaptive145Third133Proof41

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third133Proof39 : runCachedNode 511 129495 Adaptive145Third133Node39 = false := by
  decide +kernel

#print axioms adaptive145Third133Proof39

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third133Proof31 : runCachedNode 511 129495 Adaptive145Third133Node31 = false := by
  decide +kernel

#print axioms adaptive145Third133Proof31

end NineSeparatedSubsetSums
