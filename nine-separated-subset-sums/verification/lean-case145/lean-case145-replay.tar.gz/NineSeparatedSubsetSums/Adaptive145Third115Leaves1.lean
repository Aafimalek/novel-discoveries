import NineSeparatedSubsetSums.Adaptive145Third115State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third115Proof9 : runCachedNode 511 112442 Adaptive145Third115Node9 = false := by
  decide +kernel

#print axioms adaptive145Third115Proof9

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third115Proof8 : runCachedNode 511 112442 Adaptive145Third115Node8 = false := by
  decide +kernel

#print axioms adaptive145Third115Proof8

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third115Proof6 : runCachedNode 511 112442 Adaptive145Third115Node6 = false := by
  decide +kernel

#print axioms adaptive145Third115Proof6

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third115Proof5 : runCachedNode 511 112442 Adaptive145Third115Node5 = false := by
  decide +kernel

#print axioms adaptive145Third115Proof5

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third115Proof4 : runCachedNode 511 112442 Adaptive145Third115Node4 = false := by
  decide +kernel

#print axioms adaptive145Third115Proof4

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third115Proof1 : runCachedNode 511 112442 Adaptive145Third115Node1 = false := by
  decide +kernel

#print axioms adaptive145Third115Proof1

end NineSeparatedSubsetSums
