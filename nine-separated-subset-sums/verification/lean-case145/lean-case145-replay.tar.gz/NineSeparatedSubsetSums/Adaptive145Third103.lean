import NineSeparatedSubsetSums.Adaptive145Third103Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint145Checked

namespace NineSeparatedSubsetSums


theorem adaptive145Third103 : NoDescendingTailAfterThird 145 103 :=
  noDescendingThirdTail_of_cached 145 103 112442 (fun t ht nd => max148_second145_fourPoint_moment_bound (103::t) (by simp [ht]) nd) adaptive145Third103Proof0

#print axioms adaptive145Third103

end NineSeparatedSubsetSums
