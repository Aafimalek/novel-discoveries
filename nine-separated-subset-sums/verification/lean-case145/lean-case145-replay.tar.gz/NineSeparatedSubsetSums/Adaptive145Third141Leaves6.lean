import NineSeparatedSubsetSums.Adaptive145Third141State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third141Proof133 : runCachedNode 511 130740 Adaptive145Third141Node133 = false := by
  decide +kernel

#print axioms adaptive145Third141Proof133

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third141Proof132 : runCachedNode 511 130740 Adaptive145Third141Node132 = false := by
  decide +kernel

#print axioms adaptive145Third141Proof132

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third141Proof36 : runCachedNode 511 130740 Adaptive145Third141Node36 = false := by
  decide +kernel

#print axioms adaptive145Third141Proof36

end NineSeparatedSubsetSums
