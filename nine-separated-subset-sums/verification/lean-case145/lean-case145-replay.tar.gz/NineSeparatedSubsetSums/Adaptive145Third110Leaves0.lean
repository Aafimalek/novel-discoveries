import NineSeparatedSubsetSums.Adaptive145Third110State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third110Proof0 : runCachedNode 511 112442 Adaptive145Third110Node0 = false := by
  decide +kernel

#print axioms adaptive145Third110Proof0

end NineSeparatedSubsetSums
