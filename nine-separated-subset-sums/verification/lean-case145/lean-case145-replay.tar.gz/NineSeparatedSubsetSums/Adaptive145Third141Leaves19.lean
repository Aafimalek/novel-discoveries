import NineSeparatedSubsetSums.Adaptive145Third141State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third141Proof370 : runCachedNode 511 130740 Adaptive145Third141Node370 = false := by
  decide +kernel

#print axioms adaptive145Third141Proof370

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third141Proof297 : runCachedNode 511 130740 Adaptive145Third141Node297 = false := by
  decide +kernel

#print axioms adaptive145Third141Proof297

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third141Proof340 : runCachedNode 511 130740 Adaptive145Third141Node340 = false := by
  decide +kernel

#print axioms adaptive145Third141Proof340

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third141Proof192 : runCachedNode 511 130740 Adaptive145Third141Node192 = false := by
  decide +kernel

#print axioms adaptive145Third141Proof192

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third141Proof221 : runCachedNode 511 130740 Adaptive145Third141Node221 = false := by
  decide +kernel

#print axioms adaptive145Third141Proof221

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third141Proof96 : runCachedNode 511 130740 Adaptive145Third141Node96 = false := by
  decide +kernel

#print axioms adaptive145Third141Proof96

end NineSeparatedSubsetSums
