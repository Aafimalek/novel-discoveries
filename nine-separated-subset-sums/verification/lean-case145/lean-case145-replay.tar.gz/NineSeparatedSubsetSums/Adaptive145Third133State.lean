import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive145Third133Node0 : CachedSearchNode :=
  ⟨4, 132, computeCenteredMask [148,145,133], 426, 60618⟩
def Adaptive145Third133Node1 : CachedSearchNode := cachedChild Adaptive145Third133Node0 110
def Adaptive145Third133Node2 : CachedSearchNode := cachedChild Adaptive145Third133Node0 111
def Adaptive145Third133Node3 : CachedSearchNode := cachedChild Adaptive145Third133Node0 112
def Adaptive145Third133Node4 : CachedSearchNode := cachedChild Adaptive145Third133Node0 113
def Adaptive145Third133Node5 : CachedSearchNode := cachedChild Adaptive145Third133Node0 114
def Adaptive145Third133Node6 : CachedSearchNode := cachedChild Adaptive145Third133Node0 115
def Adaptive145Third133Node7 : CachedSearchNode := cachedChild Adaptive145Third133Node0 116
def Adaptive145Third133Node8 : CachedSearchNode := cachedChild Adaptive145Third133Node0 117
def Adaptive145Third133Node9 : CachedSearchNode := cachedChild Adaptive145Third133Node0 118
def Adaptive145Third133Node10 : CachedSearchNode := cachedChild Adaptive145Third133Node0 119
def Adaptive145Third133Node11 : CachedSearchNode := cachedChild Adaptive145Third133Node0 120
def Adaptive145Third133Node12 : CachedSearchNode := cachedChild Adaptive145Third133Node0 121
def Adaptive145Third133Node13 : CachedSearchNode := cachedChild Adaptive145Third133Node0 122
def Adaptive145Third133Node14 : CachedSearchNode := cachedChild Adaptive145Third133Node0 123
def Adaptive145Third133Node15 : CachedSearchNode := cachedChild Adaptive145Third133Node0 124
def Adaptive145Third133Node16 : CachedSearchNode := cachedChild Adaptive145Third133Node0 125
def Adaptive145Third133Node17 : CachedSearchNode := cachedChild Adaptive145Third133Node0 126
def Adaptive145Third133Node18 : CachedSearchNode := cachedChild Adaptive145Third133Node0 127
def Adaptive145Third133Node19 : CachedSearchNode := cachedChild Adaptive145Third133Node0 128
def Adaptive145Third133Node20 : CachedSearchNode := cachedChild Adaptive145Third133Node0 129
def Adaptive145Third133Node21 : CachedSearchNode := cachedChild Adaptive145Third133Node0 131
def Adaptive145Third133Node22 : CachedSearchNode := cachedChild Adaptive145Third133Node0 132
def Adaptive145Third133Node23 : CachedSearchNode := cachedChild Adaptive145Third133Node22 104
def Adaptive145Third133Node24 : CachedSearchNode := cachedChild Adaptive145Third133Node22 105
def Adaptive145Third133Node25 : CachedSearchNode := cachedChild Adaptive145Third133Node22 106
def Adaptive145Third133Node26 : CachedSearchNode := cachedChild Adaptive145Third133Node22 107
def Adaptive145Third133Node27 : CachedSearchNode := cachedChild Adaptive145Third133Node22 108
def Adaptive145Third133Node28 : CachedSearchNode := cachedChild Adaptive145Third133Node22 109
def Adaptive145Third133Node29 : CachedSearchNode := cachedChild Adaptive145Third133Node22 110
def Adaptive145Third133Node30 : CachedSearchNode := cachedChild Adaptive145Third133Node22 111
def Adaptive145Third133Node31 : CachedSearchNode := cachedChild Adaptive145Third133Node22 112
def Adaptive145Third133Node32 : CachedSearchNode := cachedChild Adaptive145Third133Node22 113
def Adaptive145Third133Node33 : CachedSearchNode := cachedChild Adaptive145Third133Node22 114
def Adaptive145Third133Node34 : CachedSearchNode := cachedChild Adaptive145Third133Node22 115
def Adaptive145Third133Node35 : CachedSearchNode := cachedChild Adaptive145Third133Node22 116
def Adaptive145Third133Node36 : CachedSearchNode := cachedChild Adaptive145Third133Node22 118
def Adaptive145Third133Node37 : CachedSearchNode := cachedChild Adaptive145Third133Node22 119
def Adaptive145Third133Node38 : CachedSearchNode := cachedChild Adaptive145Third133Node22 121
def Adaptive145Third133Node39 : CachedSearchNode := cachedChild Adaptive145Third133Node22 122
def Adaptive145Third133Node40 : CachedSearchNode := cachedChild Adaptive145Third133Node22 123
def Adaptive145Third133Node41 : CachedSearchNode := cachedChild Adaptive145Third133Node22 124
def Adaptive145Third133Node42 : CachedSearchNode := cachedChild Adaptive145Third133Node22 125
def Adaptive145Third133Node43 : CachedSearchNode := cachedChild Adaptive145Third133Node22 126
def Adaptive145Third133Node44 : CachedSearchNode := cachedChild Adaptive145Third133Node22 127
def Adaptive145Third133Node45 : CachedSearchNode := cachedChild Adaptive145Third133Node22 128
def Adaptive145Third133Node46 : CachedSearchNode := cachedChild Adaptive145Third133Node22 131

end NineSeparatedSubsetSums
