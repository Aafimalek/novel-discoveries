import NineSeparatedSubsetSums.Adaptive145Third138State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third138Proof39 : runCachedNode 511 130311 Adaptive145Third138Node39 = false := by
  decide +kernel

#print axioms adaptive145Third138Proof39

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third138Proof120 : runCachedNode 511 130311 Adaptive145Third138Node120 = false := by
  decide +kernel

#print axioms adaptive145Third138Proof120

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third138Proof155 : runCachedNode 511 130311 Adaptive145Third138Node155 = false := by
  decide +kernel

#print axioms adaptive145Third138Proof155

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third138Proof65 : runCachedNode 511 130311 Adaptive145Third138Node65 = false := by
  decide +kernel

#print axioms adaptive145Third138Proof65

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third138Proof40 : runCachedNode 511 130311 Adaptive145Third138Node40 = false := by
  decide +kernel

#print axioms adaptive145Third138Proof40

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third138Proof37 : runCachedNode 511 130311 Adaptive145Third138Node37 = false := by
  decide +kernel

#print axioms adaptive145Third138Proof37

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third138Proof121 : runCachedNode 511 130311 Adaptive145Third138Node121 = false := by
  decide +kernel

#print axioms adaptive145Third138Proof121

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third138Proof122 : runCachedNode 511 130311 Adaptive145Third138Node122 = false := by
  decide +kernel

#print axioms adaptive145Third138Proof122

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third138Proof38 : runCachedNode 511 130311 Adaptive145Third138Node38 = false := by
  decide +kernel

#print axioms adaptive145Third138Proof38

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third138Proof36 : runCachedNode 511 130311 Adaptive145Third138Node36 = false := by
  decide +kernel

#print axioms adaptive145Third138Proof36

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third138Proof183 : runCachedNode 511 130311 Adaptive145Third138Node183 = false := by
  decide +kernel

#print axioms adaptive145Third138Proof183

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third138Proof97 : runCachedNode 511 130311 Adaptive145Third138Node97 = false := by
  decide +kernel

#print axioms adaptive145Third138Proof97

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third138Proof9 : runCachedNode 511 130311 Adaptive145Third138Node9 = false := by
  decide +kernel

#print axioms adaptive145Third138Proof9

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third138Proof93 : runCachedNode 511 130311 Adaptive145Third138Node93 = false := by
  decide +kernel

#print axioms adaptive145Third138Proof93

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third138Proof66 : runCachedNode 511 130311 Adaptive145Third138Node66 = false := by
  decide +kernel

#print axioms adaptive145Third138Proof66

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third138Proof95 : runCachedNode 511 130311 Adaptive145Third138Node95 = false := by
  decide +kernel

#print axioms adaptive145Third138Proof95

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third138Proof151 : runCachedNode 511 130311 Adaptive145Third138Node151 = false := by
  decide +kernel

#print axioms adaptive145Third138Proof151

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third138Proof8 : runCachedNode 511 130311 Adaptive145Third138Node8 = false := by
  decide +kernel

#print axioms adaptive145Third138Proof8

end NineSeparatedSubsetSums
