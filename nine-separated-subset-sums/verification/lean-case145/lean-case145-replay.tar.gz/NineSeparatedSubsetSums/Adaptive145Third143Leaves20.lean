import NineSeparatedSubsetSums.Adaptive145Third143State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof418 : runCachedNode 511 131040 Adaptive145Third143Node418 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof418

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof595 : runCachedNode 511 131040 Adaptive145Third143Node595 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof595

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof191 : runCachedNode 511 131040 Adaptive145Third143Node191 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof191

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof52 : runCachedNode 511 131040 Adaptive145Third143Node52 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof52

end NineSeparatedSubsetSums
