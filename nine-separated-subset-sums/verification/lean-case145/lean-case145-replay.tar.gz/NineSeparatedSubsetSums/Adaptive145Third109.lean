import NineSeparatedSubsetSums.Adaptive145Third109Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint145Checked

namespace NineSeparatedSubsetSums


theorem adaptive145Third109 : NoDescendingTailAfterThird 145 109 :=
  noDescendingThirdTail_of_cached 145 109 112442 (fun t ht nd => max148_second145_fourPoint_moment_bound (109::t) (by simp [ht]) nd) adaptive145Third109Proof0

#print axioms adaptive145Third109

end NineSeparatedSubsetSums
