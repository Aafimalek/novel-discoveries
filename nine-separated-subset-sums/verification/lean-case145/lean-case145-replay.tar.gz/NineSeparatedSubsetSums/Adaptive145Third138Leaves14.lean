import NineSeparatedSubsetSums.Adaptive145Third138State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third138Proof124 : runCachedNode 511 130311 Adaptive145Third138Node124 = false := by
  decide +kernel

#print axioms adaptive145Third138Proof124

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third138Proof154 : runCachedNode 511 130311 Adaptive145Third138Node154 = false := by
  decide +kernel

#print axioms adaptive145Third138Proof154

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third138Proof96 : runCachedNode 511 130311 Adaptive145Third138Node96 = false := by
  decide +kernel

#print axioms adaptive145Third138Proof96

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third138Proof125 : runCachedNode 511 130311 Adaptive145Third138Node125 = false := by
  decide +kernel

#print axioms adaptive145Third138Proof125

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third138Proof11 : runCachedNode 511 130311 Adaptive145Third138Node11 = false := by
  decide +kernel

#print axioms adaptive145Third138Proof11

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third138Proof184 : runCachedNode 511 130311 Adaptive145Third138Node184 = false := by
  decide +kernel

#print axioms adaptive145Third138Proof184

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third138Proof185 : runCachedNode 511 130311 Adaptive145Third138Node185 = false := by
  decide +kernel

#print axioms adaptive145Third138Proof185

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third138Proof10 : runCachedNode 511 130311 Adaptive145Third138Node10 = false := by
  decide +kernel

#print axioms adaptive145Third138Proof10

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third138Proof41 : runCachedNode 511 130311 Adaptive145Third138Node41 = false := by
  decide +kernel

#print axioms adaptive145Third138Proof41

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third138Proof64 : runCachedNode 511 130311 Adaptive145Third138Node64 = false := by
  decide +kernel

#print axioms adaptive145Third138Proof64

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third138Proof186 : runCachedNode 511 130311 Adaptive145Third138Node186 = false := by
  decide +kernel

#print axioms adaptive145Third138Proof186

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third138Proof92 : runCachedNode 511 130311 Adaptive145Third138Node92 = false := by
  decide +kernel

#print axioms adaptive145Third138Proof92

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third138Proof77 : runCachedNode 511 130311 Adaptive145Third138Node77 = false := by
  decide +kernel

#print axioms adaptive145Third138Proof77

end NineSeparatedSubsetSums
