import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive145Third107Node0 : CachedSearchNode :=
  ⟨4, 106, computeCenteredMask [148,145,107], 400, 54378⟩

end NineSeparatedSubsetSums
