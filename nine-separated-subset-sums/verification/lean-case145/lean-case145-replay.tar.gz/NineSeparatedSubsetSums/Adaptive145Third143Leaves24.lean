import NineSeparatedSubsetSums.Adaptive145Third143State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof548 : runCachedNode 511 131040 Adaptive145Third143Node548 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof548

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof340 : runCachedNode 511 131040 Adaptive145Third143Node340 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof340

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof161 : runCachedNode 511 131040 Adaptive145Third143Node161 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof161

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof153 : runCachedNode 511 131040 Adaptive145Third143Node153 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof153

end NineSeparatedSubsetSums
