import NineSeparatedSubsetSums.Adaptive145Third144State
import NineSeparatedSubsetSums.Adaptive145Third144Leaves5
import NineSeparatedSubsetSums.Adaptive145Third144Leaves25
import NineSeparatedSubsetSums.Adaptive145Third144Leaves27
import NineSeparatedSubsetSums.Adaptive145Third144Leaves11
import NineSeparatedSubsetSums.Adaptive145Third144Leaves62
import NineSeparatedSubsetSums.Adaptive145Third144Leaves61
import NineSeparatedSubsetSums.Adaptive145Third144Leaves60
import NineSeparatedSubsetSums.Adaptive145Third144Leaves53
import NineSeparatedSubsetSums.Adaptive145Third144Leaves59
import NineSeparatedSubsetSums.Adaptive145Third144Leaves58
import NineSeparatedSubsetSums.Adaptive145Third144Leaves56
import NineSeparatedSubsetSums.Adaptive145Third144Leaves54
import NineSeparatedSubsetSums.Adaptive145Third144Leaves55
import NineSeparatedSubsetSums.Adaptive145Third144Leaves52
import NineSeparatedSubsetSums.Adaptive145Third144Leaves49
import NineSeparatedSubsetSums.Adaptive145Third144Leaves43
import NineSeparatedSubsetSums.Adaptive145Third144Leaves47
import NineSeparatedSubsetSums.Adaptive145Third144Leaves44
import NineSeparatedSubsetSums.Adaptive145Third144Leaves35
import NineSeparatedSubsetSums.Adaptive145Third144Leaves37
import NineSeparatedSubsetSums.Adaptive145Third144Leaves39
import NineSeparatedSubsetSums.Adaptive145Third144Leaves63
import NineSeparatedSubsetSums.Adaptive145Third144Leaves8
import NineSeparatedSubsetSums.Adaptive145Third144Leaves13
import NineSeparatedSubsetSums.Adaptive145Third144Leaves51
import NineSeparatedSubsetSums.Adaptive145Third144Leaves29
import NineSeparatedSubsetSums.Adaptive145Third144Leaves46
import NineSeparatedSubsetSums.Adaptive145Third144Leaves57
import NineSeparatedSubsetSums.Adaptive145Third144Leaves22
import NineSeparatedSubsetSums.Adaptive145Third144Leaves4
import NineSeparatedSubsetSums.Adaptive145Third144Leaves26
import NineSeparatedSubsetSums.Adaptive145Third144Leaves6
import NineSeparatedSubsetSums.Adaptive145Third144Leaves65
import NineSeparatedSubsetSums.Adaptive145Third144Leaves15
import NineSeparatedSubsetSums.Adaptive145Third144Leaves17
import NineSeparatedSubsetSums.Adaptive145Third144Leaves33
import NineSeparatedSubsetSums.Adaptive145Third144Leaves19
import NineSeparatedSubsetSums.Adaptive145Third144Leaves40
import NineSeparatedSubsetSums.Adaptive145Third144Leaves45
import NineSeparatedSubsetSums.Adaptive145Third144Leaves12
import NineSeparatedSubsetSums.Adaptive145Third144Leaves14
import NineSeparatedSubsetSums.Adaptive145Third144Leaves16
import NineSeparatedSubsetSums.Adaptive145Third144Leaves31
import NineSeparatedSubsetSums.Adaptive145Third144Leaves48
import NineSeparatedSubsetSums.Adaptive145Third144Leaves41
import NineSeparatedSubsetSums.Adaptive145Third144Leaves10
import NineSeparatedSubsetSums.Adaptive145Third144Leaves24
import NineSeparatedSubsetSums.Adaptive145Third144Leaves23
import NineSeparatedSubsetSums.Adaptive145Third144Leaves50
import NineSeparatedSubsetSums.Adaptive145Third144Leaves1
import NineSeparatedSubsetSums.Adaptive145Third144Leaves30
import NineSeparatedSubsetSums.Adaptive145Third144Leaves36
import NineSeparatedSubsetSums.Adaptive145Third144Leaves32
import NineSeparatedSubsetSums.Adaptive145Third144Leaves20
import NineSeparatedSubsetSums.Adaptive145Third144Leaves64
import NineSeparatedSubsetSums.Adaptive145Third144Leaves3
import NineSeparatedSubsetSums.Adaptive145Third144Leaves38
import NineSeparatedSubsetSums.Adaptive145Third144Leaves34
import NineSeparatedSubsetSums.Adaptive145Third144Leaves42
import NineSeparatedSubsetSums.Adaptive145Third144Leaves21

namespace NineSeparatedSubsetSums

theorem adaptive145Third144Proof23 : runCachedNode 511 131183 Adaptive145Third144Node23 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 131183 Adaptive145Third144Node23 = [103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 129] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive145Third144Proof24
  · exact adaptive145Third144Proof25
  · exact adaptive145Third144Proof26
  · exact adaptive145Third144Proof27
  · exact adaptive145Third144Proof28
  · exact adaptive145Third144Proof29
  · exact adaptive145Third144Proof30
  · exact adaptive145Third144Proof31
  · exact adaptive145Third144Proof32
  · exact adaptive145Third144Proof33
  · exact adaptive145Third144Proof34
  · exact adaptive145Third144Proof35
  · exact adaptive145Third144Proof36
  · exact adaptive145Third144Proof37
  · exact adaptive145Third144Proof38
  · exact adaptive145Third144Proof39
  · exact adaptive145Third144Proof40
  · exact adaptive145Third144Proof41
  · exact adaptive145Third144Proof42
  · exact adaptive145Third144Proof43
  · exact adaptive145Third144Proof44
  · exact adaptive145Third144Proof45
  · exact adaptive145Third144Proof46
  · exact adaptive145Third144Proof47
  · exact adaptive145Third144Proof48

#print axioms adaptive145Third144Proof23

theorem adaptive145Third144Proof49 : runCachedNode 511 131183 Adaptive145Third144Node49 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 131183 Adaptive145Third144Node49 = [103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 130] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive145Third144Proof50
  · exact adaptive145Third144Proof51
  · exact adaptive145Third144Proof52
  · exact adaptive145Third144Proof53
  · exact adaptive145Third144Proof54
  · exact adaptive145Third144Proof55
  · exact adaptive145Third144Proof56
  · exact adaptive145Third144Proof57
  · exact adaptive145Third144Proof58
  · exact adaptive145Third144Proof59
  · exact adaptive145Third144Proof60
  · exact adaptive145Third144Proof61
  · exact adaptive145Third144Proof62
  · exact adaptive145Third144Proof63
  · exact adaptive145Third144Proof64
  · exact adaptive145Third144Proof65
  · exact adaptive145Third144Proof66
  · exact adaptive145Third144Proof67
  · exact adaptive145Third144Proof68
  · exact adaptive145Third144Proof69
  · exact adaptive145Third144Proof70
  · exact adaptive145Third144Proof71
  · exact adaptive145Third144Proof72
  · exact adaptive145Third144Proof73
  · exact adaptive145Third144Proof74
  · exact adaptive145Third144Proof75

#print axioms adaptive145Third144Proof49

theorem adaptive145Third144Proof76 : runCachedNode 511 131183 Adaptive145Third144Node76 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 131183 Adaptive145Third144Node76 = [102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 131] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive145Third144Proof77
  · exact adaptive145Third144Proof78
  · exact adaptive145Third144Proof79
  · exact adaptive145Third144Proof80
  · exact adaptive145Third144Proof81
  · exact adaptive145Third144Proof82
  · exact adaptive145Third144Proof83
  · exact adaptive145Third144Proof84
  · exact adaptive145Third144Proof85
  · exact adaptive145Third144Proof86
  · exact adaptive145Third144Proof87
  · exact adaptive145Third144Proof88
  · exact adaptive145Third144Proof89
  · exact adaptive145Third144Proof90
  · exact adaptive145Third144Proof91
  · exact adaptive145Third144Proof92
  · exact adaptive145Third144Proof93
  · exact adaptive145Third144Proof94
  · exact adaptive145Third144Proof95
  · exact adaptive145Third144Proof96
  · exact adaptive145Third144Proof97
  · exact adaptive145Third144Proof98
  · exact adaptive145Third144Proof99
  · exact adaptive145Third144Proof100
  · exact adaptive145Third144Proof101
  · exact adaptive145Third144Proof102
  · exact adaptive145Third144Proof103
  · exact adaptive145Third144Proof104

#print axioms adaptive145Third144Proof76

theorem adaptive145Third144Proof105 : runCachedNode 511 131183 Adaptive145Third144Node105 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 131183 Adaptive145Third144Node105 = [102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 132] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive145Third144Proof106
  · exact adaptive145Third144Proof107
  · exact adaptive145Third144Proof108
  · exact adaptive145Third144Proof109
  · exact adaptive145Third144Proof110
  · exact adaptive145Third144Proof111
  · exact adaptive145Third144Proof112
  · exact adaptive145Third144Proof113
  · exact adaptive145Third144Proof114
  · exact adaptive145Third144Proof115
  · exact adaptive145Third144Proof116
  · exact adaptive145Third144Proof117
  · exact adaptive145Third144Proof118
  · exact adaptive145Third144Proof119
  · exact adaptive145Third144Proof120
  · exact adaptive145Third144Proof121
  · exact adaptive145Third144Proof122
  · exact adaptive145Third144Proof123
  · exact adaptive145Third144Proof124
  · exact adaptive145Third144Proof125
  · exact adaptive145Third144Proof126
  · exact adaptive145Third144Proof127
  · exact adaptive145Third144Proof128
  · exact adaptive145Third144Proof129
  · exact adaptive145Third144Proof130
  · exact adaptive145Third144Proof131
  · exact adaptive145Third144Proof132
  · exact adaptive145Third144Proof133
  · exact adaptive145Third144Proof134

#print axioms adaptive145Third144Proof105

theorem adaptive145Third144Proof135 : runCachedNode 511 131183 Adaptive145Third144Node135 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 131183 Adaptive145Third144Node135 = [102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 133] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive145Third144Proof136
  · exact adaptive145Third144Proof137
  · exact adaptive145Third144Proof138
  · exact adaptive145Third144Proof139
  · exact adaptive145Third144Proof140
  · exact adaptive145Third144Proof141
  · exact adaptive145Third144Proof142
  · exact adaptive145Third144Proof143
  · exact adaptive145Third144Proof144
  · exact adaptive145Third144Proof145
  · exact adaptive145Third144Proof146
  · exact adaptive145Third144Proof147
  · exact adaptive145Third144Proof148
  · exact adaptive145Third144Proof149
  · exact adaptive145Third144Proof150
  · exact adaptive145Third144Proof151
  · exact adaptive145Third144Proof152
  · exact adaptive145Third144Proof153
  · exact adaptive145Third144Proof154
  · exact adaptive145Third144Proof155
  · exact adaptive145Third144Proof156
  · exact adaptive145Third144Proof157
  · exact adaptive145Third144Proof158
  · exact adaptive145Third144Proof159
  · exact adaptive145Third144Proof160
  · exact adaptive145Third144Proof161
  · exact adaptive145Third144Proof162
  · exact adaptive145Third144Proof163
  · exact adaptive145Third144Proof164
  · exact adaptive145Third144Proof165

#print axioms adaptive145Third144Proof135

theorem adaptive145Third144Proof166 : runCachedNode 511 131183 Adaptive145Third144Node166 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 131183 Adaptive145Third144Node166 = [102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 134] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive145Third144Proof167
  · exact adaptive145Third144Proof168
  · exact adaptive145Third144Proof169
  · exact adaptive145Third144Proof170
  · exact adaptive145Third144Proof171
  · exact adaptive145Third144Proof172
  · exact adaptive145Third144Proof173
  · exact adaptive145Third144Proof174
  · exact adaptive145Third144Proof175
  · exact adaptive145Third144Proof176
  · exact adaptive145Third144Proof177
  · exact adaptive145Third144Proof178
  · exact adaptive145Third144Proof179
  · exact adaptive145Third144Proof180
  · exact adaptive145Third144Proof181
  · exact adaptive145Third144Proof182
  · exact adaptive145Third144Proof183
  · exact adaptive145Third144Proof184
  · exact adaptive145Third144Proof185
  · exact adaptive145Third144Proof186
  · exact adaptive145Third144Proof187
  · exact adaptive145Third144Proof188
  · exact adaptive145Third144Proof189
  · exact adaptive145Third144Proof190
  · exact adaptive145Third144Proof191
  · exact adaptive145Third144Proof192
  · exact adaptive145Third144Proof193
  · exact adaptive145Third144Proof194
  · exact adaptive145Third144Proof195
  · exact adaptive145Third144Proof196
  · exact adaptive145Third144Proof197

#print axioms adaptive145Third144Proof166

theorem adaptive145Third144Proof198 : runCachedNode 511 131183 Adaptive145Third144Node198 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 131183 Adaptive145Third144Node198 = [101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 132, 135] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive145Third144Proof199
  · exact adaptive145Third144Proof200
  · exact adaptive145Third144Proof201
  · exact adaptive145Third144Proof202
  · exact adaptive145Third144Proof203
  · exact adaptive145Third144Proof204
  · exact adaptive145Third144Proof205
  · exact adaptive145Third144Proof206
  · exact adaptive145Third144Proof207
  · exact adaptive145Third144Proof208
  · exact adaptive145Third144Proof209
  · exact adaptive145Third144Proof210
  · exact adaptive145Third144Proof211
  · exact adaptive145Third144Proof212
  · exact adaptive145Third144Proof213
  · exact adaptive145Third144Proof214
  · exact adaptive145Third144Proof215
  · exact adaptive145Third144Proof216
  · exact adaptive145Third144Proof217
  · exact adaptive145Third144Proof218
  · exact adaptive145Third144Proof219
  · exact adaptive145Third144Proof220
  · exact adaptive145Third144Proof221
  · exact adaptive145Third144Proof222
  · exact adaptive145Third144Proof223
  · exact adaptive145Third144Proof224
  · exact adaptive145Third144Proof225
  · exact adaptive145Third144Proof226
  · exact adaptive145Third144Proof227
  · exact adaptive145Third144Proof228
  · exact adaptive145Third144Proof229
  · exact adaptive145Third144Proof230
  · exact adaptive145Third144Proof231

#print axioms adaptive145Third144Proof198

theorem adaptive145Third144Proof232 : runCachedNode 511 131183 Adaptive145Third144Node232 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 131183 Adaptive145Third144Node232 = [101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 132, 133, 136] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive145Third144Proof233
  · exact adaptive145Third144Proof234
  · exact adaptive145Third144Proof235
  · exact adaptive145Third144Proof236
  · exact adaptive145Third144Proof237
  · exact adaptive145Third144Proof238
  · exact adaptive145Third144Proof239
  · exact adaptive145Third144Proof240
  · exact adaptive145Third144Proof241
  · exact adaptive145Third144Proof242
  · exact adaptive145Third144Proof243
  · exact adaptive145Third144Proof244
  · exact adaptive145Third144Proof245
  · exact adaptive145Third144Proof246
  · exact adaptive145Third144Proof247
  · exact adaptive145Third144Proof248
  · exact adaptive145Third144Proof249
  · exact adaptive145Third144Proof250
  · exact adaptive145Third144Proof251
  · exact adaptive145Third144Proof252
  · exact adaptive145Third144Proof253
  · exact adaptive145Third144Proof254
  · exact adaptive145Third144Proof255
  · exact adaptive145Third144Proof256
  · exact adaptive145Third144Proof257
  · exact adaptive145Third144Proof258
  · exact adaptive145Third144Proof259
  · exact adaptive145Third144Proof260
  · exact adaptive145Third144Proof261
  · exact adaptive145Third144Proof262
  · exact adaptive145Third144Proof263
  · exact adaptive145Third144Proof264
  · exact adaptive145Third144Proof265
  · exact adaptive145Third144Proof266

#print axioms adaptive145Third144Proof232

end NineSeparatedSubsetSums
