import NineSeparatedSubsetSums.Adaptive145Third142State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof13 : runCachedNode 511 130865 Adaptive145Third142Node13 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof13

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof533 : runCachedNode 511 130865 Adaptive145Third142Node533 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof533

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof139 : runCachedNode 511 130865 Adaptive145Third142Node139 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof139

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof12 : runCachedNode 511 130865 Adaptive145Third142Node12 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof12

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof89 : runCachedNode 511 130865 Adaptive145Third142Node89 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof89

end NineSeparatedSubsetSums
