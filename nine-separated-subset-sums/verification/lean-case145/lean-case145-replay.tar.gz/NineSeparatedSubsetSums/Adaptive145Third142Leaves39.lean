import NineSeparatedSubsetSums.Adaptive145Third142State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof226 : runCachedNode 511 130865 Adaptive145Third142Node226 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof226

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof538 : runCachedNode 511 130865 Adaptive145Third142Node538 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof538

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof860 : runCachedNode 511 130865 Adaptive145Third142Node860 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof860

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof430 : runCachedNode 511 130865 Adaptive145Third142Node430 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof430

end NineSeparatedSubsetSums
