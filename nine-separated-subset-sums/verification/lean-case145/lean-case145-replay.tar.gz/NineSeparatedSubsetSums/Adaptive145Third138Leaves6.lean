import NineSeparatedSubsetSums.Adaptive145Third138State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third138Proof18 : runCachedNode 511 130311 Adaptive145Third138Node18 = false := by
  decide +kernel

#print axioms adaptive145Third138Proof18

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third138Proof73 : runCachedNode 511 130311 Adaptive145Third138Node73 = false := by
  decide +kernel

#print axioms adaptive145Third138Proof73

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third138Proof188 : runCachedNode 511 130311 Adaptive145Third138Node188 = false := by
  decide +kernel

#print axioms adaptive145Third138Proof188

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third138Proof1 : runCachedNode 511 130311 Adaptive145Third138Node1 = false := by
  decide +kernel

#print axioms adaptive145Third138Proof1

end NineSeparatedSubsetSums
