import NineSeparatedSubsetSums.Adaptive145Third142State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof318 : runCachedNode 511 130865 Adaptive145Third142Node318 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof318

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof82 : runCachedNode 511 130865 Adaptive145Third142Node82 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof82

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof321 : runCachedNode 511 130865 Adaptive145Third142Node321 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof321

end NineSeparatedSubsetSums
