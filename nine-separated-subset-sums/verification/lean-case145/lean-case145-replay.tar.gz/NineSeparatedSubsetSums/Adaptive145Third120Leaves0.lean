import NineSeparatedSubsetSums.Adaptive145Third120State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third120Proof0 : runCachedNode 511 126380 Adaptive145Third120Node0 = false := by
  decide +kernel

#print axioms adaptive145Third120Proof0

end NineSeparatedSubsetSums
