import NineSeparatedSubsetSums.Adaptive145Third140State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third140Proof22 : runCachedNode 511 130597 Adaptive145Third140Node22 = false := by
  decide +kernel

#print axioms adaptive145Third140Proof22

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third140Proof16 : runCachedNode 511 130597 Adaptive145Third140Node16 = false := by
  decide +kernel

#print axioms adaptive145Third140Proof16

end NineSeparatedSubsetSums
