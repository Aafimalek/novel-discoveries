import NineSeparatedSubsetSums.Adaptive145Third135State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third135Proof22 : runCachedNode 511 129879 Adaptive145Third135Node22 = false := by
  decide +kernel

#print axioms adaptive145Third135Proof22

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third135Proof75 : runCachedNode 511 129879 Adaptive145Third135Node75 = false := by
  decide +kernel

#print axioms adaptive145Third135Proof75

end NineSeparatedSubsetSums
