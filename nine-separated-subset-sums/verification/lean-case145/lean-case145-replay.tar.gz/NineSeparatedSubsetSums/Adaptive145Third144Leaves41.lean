import NineSeparatedSubsetSums.Adaptive145Third144State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third144Proof326 : runCachedNode 511 131183 Adaptive145Third144Node326 = false := by
  decide +kernel

#print axioms adaptive145Third144Proof326

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third144Proof715 : runCachedNode 511 131183 Adaptive145Third144Node715 = false := by
  decide +kernel

#print axioms adaptive145Third144Proof715

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third144Proof130 : runCachedNode 511 131183 Adaptive145Third144Node130 = false := by
  decide +kernel

#print axioms adaptive145Third144Proof130

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third144Proof614 : runCachedNode 511 131183 Adaptive145Third144Node614 = false := by
  decide +kernel

#print axioms adaptive145Third144Proof614

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third144Proof486 : runCachedNode 511 131183 Adaptive145Third144Node486 = false := by
  decide +kernel

#print axioms adaptive145Third144Proof486

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third144Proof13 : runCachedNode 511 131183 Adaptive145Third144Node13 = false := by
  decide +kernel

#print axioms adaptive145Third144Proof13

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third144Proof436 : runCachedNode 511 131183 Adaptive145Third144Node436 = false := by
  decide +kernel

#print axioms adaptive145Third144Proof436

end NineSeparatedSubsetSums
