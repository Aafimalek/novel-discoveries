import NineSeparatedSubsetSums.Adaptive145Third142State
import NineSeparatedSubsetSums.Adaptive145Third142Leaves79
import NineSeparatedSubsetSums.Adaptive145Third142Leaves78
import NineSeparatedSubsetSums.Adaptive145Third142Leaves18
import NineSeparatedSubsetSums.Adaptive145Third142Leaves76
import NineSeparatedSubsetSums.Adaptive145Third142Leaves63
import NineSeparatedSubsetSums.Adaptive145Third142Leaves75
import NineSeparatedSubsetSums.Adaptive145Third142Leaves74
import NineSeparatedSubsetSums.Adaptive145Third142Leaves73
import NineSeparatedSubsetSums.Adaptive145Third142Leaves70
import NineSeparatedSubsetSums.Adaptive145Third142Leaves69
import NineSeparatedSubsetSums.Adaptive145Third142Leaves68
import NineSeparatedSubsetSums.Adaptive145Third142Leaves66
import NineSeparatedSubsetSums.Adaptive145Third142Leaves65
import NineSeparatedSubsetSums.Adaptive145Third142Leaves64
import NineSeparatedSubsetSums.Adaptive145Third142Leaves59
import NineSeparatedSubsetSums.Adaptive145Third142Leaves61
import NineSeparatedSubsetSums.Adaptive145Third142Leaves48
import NineSeparatedSubsetSums.Adaptive145Third142Leaves51
import NineSeparatedSubsetSums.Adaptive145Third142Leaves49
import NineSeparatedSubsetSums.Adaptive145Third142Leaves30
import NineSeparatedSubsetSums.Adaptive145Third142Leaves32
import NineSeparatedSubsetSums.Adaptive145Third142Leaves38
import NineSeparatedSubsetSums.Adaptive145Third142Leaves26
import NineSeparatedSubsetSums.Adaptive145Third142Leaves40
import NineSeparatedSubsetSums.Adaptive145Third142Leaves22
import NineSeparatedSubsetSums.Adaptive145Third142Leaves23
import NineSeparatedSubsetSums.Adaptive145Third142Leaves14
import NineSeparatedSubsetSums.Adaptive145Third142Leaves80
import NineSeparatedSubsetSums.Adaptive145Third142Leaves77
import NineSeparatedSubsetSums.Adaptive145Third142Leaves72
import NineSeparatedSubsetSums.Adaptive145Third142Leaves71
import NineSeparatedSubsetSums.Adaptive145Third142Leaves67
import NineSeparatedSubsetSums.Adaptive145Third142Leaves1
import NineSeparatedSubsetSums.Adaptive145Third142Leaves57
import NineSeparatedSubsetSums.Adaptive145Third142Leaves58
import NineSeparatedSubsetSums.Adaptive145Third142Leaves54
import NineSeparatedSubsetSums.Adaptive145Third142Leaves8
import NineSeparatedSubsetSums.Adaptive145Third142Leaves2
import NineSeparatedSubsetSums.Adaptive145Third142Leaves3
import NineSeparatedSubsetSums.Adaptive145Third142Leaves10
import NineSeparatedSubsetSums.Adaptive145Third142Leaves4
import NineSeparatedSubsetSums.Adaptive145Third142Leaves60
import NineSeparatedSubsetSums.Adaptive145Third142Leaves62
import NineSeparatedSubsetSums.Adaptive145Third142Leaves50
import NineSeparatedSubsetSums.Adaptive145Third142Leaves56
import NineSeparatedSubsetSums.Adaptive145Third142Leaves52
import NineSeparatedSubsetSums.Adaptive145Third142Leaves29
import NineSeparatedSubsetSums.Adaptive145Third142Leaves36
import NineSeparatedSubsetSums.Adaptive145Third142Leaves45
import NineSeparatedSubsetSums.Adaptive145Third142Leaves46
import NineSeparatedSubsetSums.Adaptive145Third142Leaves27
import NineSeparatedSubsetSums.Adaptive145Third142Leaves53
import NineSeparatedSubsetSums.Adaptive145Third142Leaves43
import NineSeparatedSubsetSums.Adaptive145Third142Leaves81
import NineSeparatedSubsetSums.Adaptive145Third142Leaves82
import NineSeparatedSubsetSums.Adaptive145Third142Leaves39
import NineSeparatedSubsetSums.Adaptive145Third142Leaves44
import NineSeparatedSubsetSums.Adaptive145Third142Leaves37
import NineSeparatedSubsetSums.Adaptive145Third142Leaves35
import NineSeparatedSubsetSums.Adaptive145Third142Leaves24
import NineSeparatedSubsetSums.Adaptive145Third142Leaves19
import NineSeparatedSubsetSums.Adaptive145Third142Leaves0
import NineSeparatedSubsetSums.Adaptive145Third142Leaves55
import NineSeparatedSubsetSums.Adaptive145Third142Leaves47
import NineSeparatedSubsetSums.Adaptive145Third142Leaves31
import NineSeparatedSubsetSums.Adaptive145Third142Leaves25
import NineSeparatedSubsetSums.Adaptive145Third142Leaves12
import NineSeparatedSubsetSums.Adaptive145Third142Leaves15
import NineSeparatedSubsetSums.Adaptive145Third142Leaves9
import NineSeparatedSubsetSums.Adaptive145Third142Leaves16
import NineSeparatedSubsetSums.Adaptive145Third142Leaves11

namespace NineSeparatedSubsetSums

theorem adaptive145Third142Proof229 : runCachedNode 511 130865 Adaptive145Third142Node229 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130865 Adaptive145Third142Node229 = [102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 130, 131, 133, 134] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive145Third142Proof230
  · exact adaptive145Third142Proof231
  · exact adaptive145Third142Proof232
  · exact adaptive145Third142Proof233
  · exact adaptive145Third142Proof234
  · exact adaptive145Third142Proof235
  · exact adaptive145Third142Proof236
  · exact adaptive145Third142Proof237
  · exact adaptive145Third142Proof238
  · exact adaptive145Third142Proof239
  · exact adaptive145Third142Proof240
  · exact adaptive145Third142Proof241
  · exact adaptive145Third142Proof242
  · exact adaptive145Third142Proof243
  · exact adaptive145Third142Proof244
  · exact adaptive145Third142Proof245
  · exact adaptive145Third142Proof246
  · exact adaptive145Third142Proof247
  · exact adaptive145Third142Proof248
  · exact adaptive145Third142Proof249
  · exact adaptive145Third142Proof250
  · exact adaptive145Third142Proof251
  · exact adaptive145Third142Proof252
  · exact adaptive145Third142Proof253
  · exact adaptive145Third142Proof254
  · exact adaptive145Third142Proof255
  · exact adaptive145Third142Proof256
  · exact adaptive145Third142Proof257
  · exact adaptive145Third142Proof258
  · exact adaptive145Third142Proof259
  · exact adaptive145Third142Proof260

#print axioms adaptive145Third142Proof229

theorem adaptive145Third142Proof287 : runCachedNode 511 130865 Adaptive145Third142Node287 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130865 Adaptive145Third142Node287 = [93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 113, 114, 116, 117, 119, 120, 122, 123, 125, 126] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive145Third142Proof288
  · exact adaptive145Third142Proof289
  · exact adaptive145Third142Proof290
  · exact adaptive145Third142Proof291
  · exact adaptive145Third142Proof292
  · exact adaptive145Third142Proof293
  · exact adaptive145Third142Proof294
  · exact adaptive145Third142Proof295
  · exact adaptive145Third142Proof296
  · exact adaptive145Third142Proof297
  · exact adaptive145Third142Proof298
  · exact adaptive145Third142Proof299
  · exact adaptive145Third142Proof300
  · exact adaptive145Third142Proof301
  · exact adaptive145Third142Proof302
  · exact adaptive145Third142Proof303
  · exact adaptive145Third142Proof304
  · exact adaptive145Third142Proof305
  · exact adaptive145Third142Proof306
  · exact adaptive145Third142Proof307
  · exact adaptive145Third142Proof308
  · exact adaptive145Third142Proof309
  · exact adaptive145Third142Proof310
  · exact adaptive145Third142Proof311
  · exact adaptive145Third142Proof312
  · exact adaptive145Third142Proof313
  · exact adaptive145Third142Proof314
  · exact adaptive145Third142Proof315
  · exact adaptive145Third142Proof316

#print axioms adaptive145Third142Proof287

theorem adaptive145Third142Proof320 : runCachedNode 511 130865 Adaptive145Third142Node320 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130865 Adaptive145Third142Node320 = [91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 118, 119, 121, 122, 124, 125, 127, 128, 131] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive145Third142Proof321
  · exact adaptive145Third142Proof322
  · exact adaptive145Third142Proof323
  · exact adaptive145Third142Proof324
  · exact adaptive145Third142Proof325
  · exact adaptive145Third142Proof326
  · exact adaptive145Third142Proof327
  · exact adaptive145Third142Proof328
  · exact adaptive145Third142Proof329
  · exact adaptive145Third142Proof330
  · exact adaptive145Third142Proof331
  · exact adaptive145Third142Proof332
  · exact adaptive145Third142Proof333
  · exact adaptive145Third142Proof334
  · exact adaptive145Third142Proof335
  · exact adaptive145Third142Proof336
  · exact adaptive145Third142Proof337
  · exact adaptive145Third142Proof338
  · exact adaptive145Third142Proof339
  · exact adaptive145Third142Proof340
  · exact adaptive145Third142Proof341
  · exact adaptive145Third142Proof342
  · exact adaptive145Third142Proof343
  · exact adaptive145Third142Proof344
  · exact adaptive145Third142Proof345
  · exact adaptive145Third142Proof346
  · exact adaptive145Third142Proof347
  · exact adaptive145Third142Proof348
  · exact adaptive145Third142Proof349
  · exact adaptive145Third142Proof350
  · exact adaptive145Third142Proof351
  · exact adaptive145Third142Proof352
  · exact adaptive145Third142Proof353
  · exact adaptive145Third142Proof354
  · exact adaptive145Third142Proof355

#print axioms adaptive145Third142Proof320

theorem adaptive145Third142Proof356 : runCachedNode 511 130865 Adaptive145Third142Node356 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130865 Adaptive145Third142Node356 = [90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 120, 121, 123, 124, 126, 127, 129, 132] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive145Third142Proof357
  · exact adaptive145Third142Proof358
  · exact adaptive145Third142Proof359
  · exact adaptive145Third142Proof360
  · exact adaptive145Third142Proof361
  · exact adaptive145Third142Proof362
  · exact adaptive145Third142Proof363
  · exact adaptive145Third142Proof364
  · exact adaptive145Third142Proof365
  · exact adaptive145Third142Proof366
  · exact adaptive145Third142Proof367
  · exact adaptive145Third142Proof368
  · exact adaptive145Third142Proof369
  · exact adaptive145Third142Proof370
  · exact adaptive145Third142Proof371
  · exact adaptive145Third142Proof372
  · exact adaptive145Third142Proof373
  · exact adaptive145Third142Proof374
  · exact adaptive145Third142Proof375
  · exact adaptive145Third142Proof376
  · exact adaptive145Third142Proof377
  · exact adaptive145Third142Proof378
  · exact adaptive145Third142Proof379
  · exact adaptive145Third142Proof380
  · exact adaptive145Third142Proof381
  · exact adaptive145Third142Proof382
  · exact adaptive145Third142Proof383
  · exact adaptive145Third142Proof384
  · exact adaptive145Third142Proof385
  · exact adaptive145Third142Proof386
  · exact adaptive145Third142Proof387
  · exact adaptive145Third142Proof388
  · exact adaptive145Third142Proof389
  · exact adaptive145Third142Proof390
  · exact adaptive145Third142Proof391
  · exact adaptive145Third142Proof392
  · exact adaptive145Third142Proof393

#print axioms adaptive145Third142Proof356

theorem adaptive145Third142Proof394 : runCachedNode 511 130865 Adaptive145Third142Node394 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130865 Adaptive145Third142Node394 = [90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 121, 122, 124, 125, 127, 128, 131, 134] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive145Third142Proof395
  · exact adaptive145Third142Proof396
  · exact adaptive145Third142Proof397
  · exact adaptive145Third142Proof398
  · exact adaptive145Third142Proof399
  · exact adaptive145Third142Proof400
  · exact adaptive145Third142Proof401
  · exact adaptive145Third142Proof402
  · exact adaptive145Third142Proof403
  · exact adaptive145Third142Proof404
  · exact adaptive145Third142Proof405
  · exact adaptive145Third142Proof406
  · exact adaptive145Third142Proof407
  · exact adaptive145Third142Proof408
  · exact adaptive145Third142Proof409
  · exact adaptive145Third142Proof410
  · exact adaptive145Third142Proof411
  · exact adaptive145Third142Proof412
  · exact adaptive145Third142Proof413
  · exact adaptive145Third142Proof414
  · exact adaptive145Third142Proof415
  · exact adaptive145Third142Proof416
  · exact adaptive145Third142Proof417
  · exact adaptive145Third142Proof418
  · exact adaptive145Third142Proof419
  · exact adaptive145Third142Proof420
  · exact adaptive145Third142Proof421
  · exact adaptive145Third142Proof422
  · exact adaptive145Third142Proof423
  · exact adaptive145Third142Proof424
  · exact adaptive145Third142Proof425
  · exact adaptive145Third142Proof426
  · exact adaptive145Third142Proof427
  · exact adaptive145Third142Proof428
  · exact adaptive145Third142Proof429
  · exact adaptive145Third142Proof430
  · exact adaptive145Third142Proof431
  · exact adaptive145Third142Proof432

#print axioms adaptive145Third142Proof394

theorem adaptive145Third142Proof261 : runCachedNode 511 130865 Adaptive145Third142Node261 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130865 Adaptive145Third142Node261 = [102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 131, 132, 134, 135] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive145Third142Proof262
  · exact adaptive145Third142Proof263
  · exact adaptive145Third142Proof264
  · exact adaptive145Third142Proof265
  · exact adaptive145Third142Proof266
  · exact adaptive145Third142Proof267
  · exact adaptive145Third142Proof268
  · exact adaptive145Third142Proof269
  · exact adaptive145Third142Proof270
  · exact adaptive145Third142Proof271
  · exact adaptive145Third142Proof272
  · exact adaptive145Third142Proof273
  · exact adaptive145Third142Proof274
  · exact adaptive145Third142Proof275
  · exact adaptive145Third142Proof276
  · exact adaptive145Third142Proof277
  · exact adaptive145Third142Proof278
  · exact adaptive145Third142Proof279
  · exact adaptive145Third142Proof280
  · exact adaptive145Third142Proof281
  · exact adaptive145Third142Proof282
  · exact adaptive145Third142Proof283
  · exact adaptive145Third142Proof284
  · exact adaptive145Third142Proof285
  · exact adaptive145Third142Proof286
  · exact adaptive145Third142Proof287
  · exact adaptive145Third142Proof317
  · exact adaptive145Third142Proof318
  · exact adaptive145Third142Proof319
  · exact adaptive145Third142Proof320
  · exact adaptive145Third142Proof356
  · exact adaptive145Third142Proof394

#print axioms adaptive145Third142Proof261

theorem adaptive145Third142Proof467 : runCachedNode 511 130865 Adaptive145Third142Node467 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130865 Adaptive145Third142Node467 = [89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 123, 124, 126, 127, 129, 132, 135] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive145Third142Proof468
  · exact adaptive145Third142Proof469
  · exact adaptive145Third142Proof470
  · exact adaptive145Third142Proof471
  · exact adaptive145Third142Proof472
  · exact adaptive145Third142Proof473
  · exact adaptive145Third142Proof474
  · exact adaptive145Third142Proof475
  · exact adaptive145Third142Proof476
  · exact adaptive145Third142Proof477
  · exact adaptive145Third142Proof478
  · exact adaptive145Third142Proof479
  · exact adaptive145Third142Proof480
  · exact adaptive145Third142Proof481
  · exact adaptive145Third142Proof482
  · exact adaptive145Third142Proof483
  · exact adaptive145Third142Proof484
  · exact adaptive145Third142Proof485
  · exact adaptive145Third142Proof486
  · exact adaptive145Third142Proof487
  · exact adaptive145Third142Proof488
  · exact adaptive145Third142Proof489
  · exact adaptive145Third142Proof490
  · exact adaptive145Third142Proof491
  · exact adaptive145Third142Proof492
  · exact adaptive145Third142Proof493
  · exact adaptive145Third142Proof494
  · exact adaptive145Third142Proof495
  · exact adaptive145Third142Proof496
  · exact adaptive145Third142Proof497
  · exact adaptive145Third142Proof498
  · exact adaptive145Third142Proof499
  · exact adaptive145Third142Proof500
  · exact adaptive145Third142Proof501
  · exact adaptive145Third142Proof502
  · exact adaptive145Third142Proof503
  · exact adaptive145Third142Proof504
  · exact adaptive145Third142Proof505
  · exact adaptive145Third142Proof506
  · exact adaptive145Third142Proof507

#print axioms adaptive145Third142Proof467

theorem adaptive145Third142Proof433 : runCachedNode 511 130865 Adaptive145Third142Node433 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130865 Adaptive145Third142Node433 = [101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 132, 133, 135, 136] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive145Third142Proof434
  · exact adaptive145Third142Proof435
  · exact adaptive145Third142Proof436
  · exact adaptive145Third142Proof437
  · exact adaptive145Third142Proof438
  · exact adaptive145Third142Proof439
  · exact adaptive145Third142Proof440
  · exact adaptive145Third142Proof441
  · exact adaptive145Third142Proof442
  · exact adaptive145Third142Proof443
  · exact adaptive145Third142Proof444
  · exact adaptive145Third142Proof445
  · exact adaptive145Third142Proof446
  · exact adaptive145Third142Proof447
  · exact adaptive145Third142Proof448
  · exact adaptive145Third142Proof449
  · exact adaptive145Third142Proof450
  · exact adaptive145Third142Proof451
  · exact adaptive145Third142Proof452
  · exact adaptive145Third142Proof453
  · exact adaptive145Third142Proof454
  · exact adaptive145Third142Proof455
  · exact adaptive145Third142Proof456
  · exact adaptive145Third142Proof457
  · exact adaptive145Third142Proof458
  · exact adaptive145Third142Proof459
  · exact adaptive145Third142Proof460
  · exact adaptive145Third142Proof461
  · exact adaptive145Third142Proof462
  · exact adaptive145Third142Proof463
  · exact adaptive145Third142Proof464
  · exact adaptive145Third142Proof465
  · exact adaptive145Third142Proof466
  · exact adaptive145Third142Proof467

#print axioms adaptive145Third142Proof433

end NineSeparatedSubsetSums
