import NineSeparatedSubsetSums.Adaptive145Third140State
import NineSeparatedSubsetSums.Adaptive145Third140Leaves28
import NineSeparatedSubsetSums.Adaptive145Third140Leaves27
import NineSeparatedSubsetSums.Adaptive145Third140Leaves26
import NineSeparatedSubsetSums.Adaptive145Third140Leaves5
import NineSeparatedSubsetSums.Adaptive145Third140Leaves25
import NineSeparatedSubsetSums.Adaptive145Third140Leaves12
import NineSeparatedSubsetSums.Adaptive145Third140Leaves22
import NineSeparatedSubsetSums.Adaptive145Third140Leaves7
import NineSeparatedSubsetSums.Adaptive145Third140Leaves24
import NineSeparatedSubsetSums.Adaptive145Third140Leaves23
import NineSeparatedSubsetSums.Adaptive145Third140Leaves20
import NineSeparatedSubsetSums.Adaptive145Third140Leaves2
import NineSeparatedSubsetSums.Adaptive145Third140Leaves19
import NineSeparatedSubsetSums.Adaptive145Third140Leaves8
import NineSeparatedSubsetSums.Adaptive145Third140Leaves13
import NineSeparatedSubsetSums.Adaptive145Third140Leaves17
import NineSeparatedSubsetSums.Adaptive145Third140Leaves21
import NineSeparatedSubsetSums.Adaptive145Third140Leaves14
import NineSeparatedSubsetSums.Adaptive145Third140Leaves18
import NineSeparatedSubsetSums.Adaptive145Third140Leaves1
import NineSeparatedSubsetSums.Adaptive145Third140Leaves16
import NineSeparatedSubsetSums.Adaptive145Third140Leaves4
import NineSeparatedSubsetSums.Adaptive145Third140Leaves6
import NineSeparatedSubsetSums.Adaptive145Third140Leaves15
import NineSeparatedSubsetSums.Adaptive145Third140Leaves9
import NineSeparatedSubsetSums.Adaptive145Third140Leaves11
import NineSeparatedSubsetSums.Adaptive145Third140Leaves0
import NineSeparatedSubsetSums.Adaptive145Third140Leaves10
import NineSeparatedSubsetSums.Adaptive145Third140Leaves29

namespace NineSeparatedSubsetSums

theorem adaptive145Third140Proof23 : runCachedNode 511 130597 Adaptive145Third140Node23 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130597 Adaptive145Third140Node23 = [103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 124, 125, 127, 129, 130] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive145Third140Proof24
  · exact adaptive145Third140Proof25
  · exact adaptive145Third140Proof26
  · exact adaptive145Third140Proof27
  · exact adaptive145Third140Proof28
  · exact adaptive145Third140Proof29
  · exact adaptive145Third140Proof30
  · exact adaptive145Third140Proof31
  · exact adaptive145Third140Proof32
  · exact adaptive145Third140Proof33
  · exact adaptive145Third140Proof34
  · exact adaptive145Third140Proof35
  · exact adaptive145Third140Proof36
  · exact adaptive145Third140Proof37
  · exact adaptive145Third140Proof38
  · exact adaptive145Third140Proof39
  · exact adaptive145Third140Proof40
  · exact adaptive145Third140Proof41
  · exact adaptive145Third140Proof42
  · exact adaptive145Third140Proof43
  · exact adaptive145Third140Proof44
  · exact adaptive145Third140Proof45
  · exact adaptive145Third140Proof46
  · exact adaptive145Third140Proof47
  · exact adaptive145Third140Proof48

#print axioms adaptive145Third140Proof23

theorem adaptive145Third140Proof49 : runCachedNode 511 130597 Adaptive145Third140Node49 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130597 Adaptive145Third140Node49 = [103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 125, 126, 128, 130, 131] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive145Third140Proof50
  · exact adaptive145Third140Proof51
  · exact adaptive145Third140Proof52
  · exact adaptive145Third140Proof53
  · exact adaptive145Third140Proof54
  · exact adaptive145Third140Proof55
  · exact adaptive145Third140Proof56
  · exact adaptive145Third140Proof57
  · exact adaptive145Third140Proof58
  · exact adaptive145Third140Proof59
  · exact adaptive145Third140Proof60
  · exact adaptive145Third140Proof61
  · exact adaptive145Third140Proof62
  · exact adaptive145Third140Proof63
  · exact adaptive145Third140Proof64
  · exact adaptive145Third140Proof65
  · exact adaptive145Third140Proof66
  · exact adaptive145Third140Proof67
  · exact adaptive145Third140Proof68
  · exact adaptive145Third140Proof69
  · exact adaptive145Third140Proof70
  · exact adaptive145Third140Proof71
  · exact adaptive145Third140Proof72
  · exact adaptive145Third140Proof73
  · exact adaptive145Third140Proof74
  · exact adaptive145Third140Proof75

#print axioms adaptive145Third140Proof49

theorem adaptive145Third140Proof76 : runCachedNode 511 130597 Adaptive145Third140Node76 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130597 Adaptive145Third140Node76 = [103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 126, 127, 129, 131, 132] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive145Third140Proof77
  · exact adaptive145Third140Proof78
  · exact adaptive145Third140Proof79
  · exact adaptive145Third140Proof80
  · exact adaptive145Third140Proof81
  · exact adaptive145Third140Proof82
  · exact adaptive145Third140Proof83
  · exact adaptive145Third140Proof84
  · exact adaptive145Third140Proof85
  · exact adaptive145Third140Proof86
  · exact adaptive145Third140Proof87
  · exact adaptive145Third140Proof88
  · exact adaptive145Third140Proof89
  · exact adaptive145Third140Proof90
  · exact adaptive145Third140Proof91
  · exact adaptive145Third140Proof92
  · exact adaptive145Third140Proof93
  · exact adaptive145Third140Proof94
  · exact adaptive145Third140Proof95
  · exact adaptive145Third140Proof96
  · exact adaptive145Third140Proof97
  · exact adaptive145Third140Proof98
  · exact adaptive145Third140Proof99
  · exact adaptive145Third140Proof100
  · exact adaptive145Third140Proof101
  · exact adaptive145Third140Proof102
  · exact adaptive145Third140Proof103

#print axioms adaptive145Third140Proof76

theorem adaptive145Third140Proof104 : runCachedNode 511 130597 Adaptive145Third140Node104 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130597 Adaptive145Third140Node104 = [103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 127, 128, 130, 132, 133] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive145Third140Proof105
  · exact adaptive145Third140Proof106
  · exact adaptive145Third140Proof107
  · exact adaptive145Third140Proof108
  · exact adaptive145Third140Proof109
  · exact adaptive145Third140Proof110
  · exact adaptive145Third140Proof111
  · exact adaptive145Third140Proof112
  · exact adaptive145Third140Proof113
  · exact adaptive145Third140Proof114
  · exact adaptive145Third140Proof115
  · exact adaptive145Third140Proof116
  · exact adaptive145Third140Proof117
  · exact adaptive145Third140Proof118
  · exact adaptive145Third140Proof119
  · exact adaptive145Third140Proof120
  · exact adaptive145Third140Proof121
  · exact adaptive145Third140Proof122
  · exact adaptive145Third140Proof123
  · exact adaptive145Third140Proof124
  · exact adaptive145Third140Proof125
  · exact adaptive145Third140Proof126
  · exact adaptive145Third140Proof127
  · exact adaptive145Third140Proof128
  · exact adaptive145Third140Proof129
  · exact adaptive145Third140Proof130
  · exact adaptive145Third140Proof131
  · exact adaptive145Third140Proof132

#print axioms adaptive145Third140Proof104

theorem adaptive145Third140Proof133 : runCachedNode 511 130597 Adaptive145Third140Node133 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130597 Adaptive145Third140Node133 = [102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 128, 129, 131, 133, 134] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive145Third140Proof134
  · exact adaptive145Third140Proof135
  · exact adaptive145Third140Proof136
  · exact adaptive145Third140Proof137
  · exact adaptive145Third140Proof138
  · exact adaptive145Third140Proof139
  · exact adaptive145Third140Proof140
  · exact adaptive145Third140Proof141
  · exact adaptive145Third140Proof142
  · exact adaptive145Third140Proof143
  · exact adaptive145Third140Proof144
  · exact adaptive145Third140Proof145
  · exact adaptive145Third140Proof146
  · exact adaptive145Third140Proof147
  · exact adaptive145Third140Proof148
  · exact adaptive145Third140Proof149
  · exact adaptive145Third140Proof150
  · exact adaptive145Third140Proof151
  · exact adaptive145Third140Proof152
  · exact adaptive145Third140Proof153
  · exact adaptive145Third140Proof154
  · exact adaptive145Third140Proof155
  · exact adaptive145Third140Proof156
  · exact adaptive145Third140Proof157
  · exact adaptive145Third140Proof158
  · exact adaptive145Third140Proof159
  · exact adaptive145Third140Proof160
  · exact adaptive145Third140Proof161
  · exact adaptive145Third140Proof162
  · exact adaptive145Third140Proof163

#print axioms adaptive145Third140Proof133

theorem adaptive145Third140Proof164 : runCachedNode 511 130597 Adaptive145Third140Node164 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130597 Adaptive145Third140Node164 = [102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 129, 130, 132, 134, 135] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive145Third140Proof165
  · exact adaptive145Third140Proof166
  · exact adaptive145Third140Proof167
  · exact adaptive145Third140Proof168
  · exact adaptive145Third140Proof169
  · exact adaptive145Third140Proof170
  · exact adaptive145Third140Proof171
  · exact adaptive145Third140Proof172
  · exact adaptive145Third140Proof173
  · exact adaptive145Third140Proof174
  · exact adaptive145Third140Proof175
  · exact adaptive145Third140Proof176
  · exact adaptive145Third140Proof177
  · exact adaptive145Third140Proof178
  · exact adaptive145Third140Proof179
  · exact adaptive145Third140Proof180
  · exact adaptive145Third140Proof181
  · exact adaptive145Third140Proof182
  · exact adaptive145Third140Proof183
  · exact adaptive145Third140Proof184
  · exact adaptive145Third140Proof185
  · exact adaptive145Third140Proof186
  · exact adaptive145Third140Proof187
  · exact adaptive145Third140Proof188
  · exact adaptive145Third140Proof189
  · exact adaptive145Third140Proof190
  · exact adaptive145Third140Proof191
  · exact adaptive145Third140Proof192
  · exact adaptive145Third140Proof193
  · exact adaptive145Third140Proof194
  · exact adaptive145Third140Proof195

#print axioms adaptive145Third140Proof164

theorem adaptive145Third140Proof196 : runCachedNode 511 130597 Adaptive145Third140Node196 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130597 Adaptive145Third140Node196 = [102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 131, 132, 134, 136] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive145Third140Proof197
  · exact adaptive145Third140Proof198
  · exact adaptive145Third140Proof199
  · exact adaptive145Third140Proof200
  · exact adaptive145Third140Proof201
  · exact adaptive145Third140Proof202
  · exact adaptive145Third140Proof203
  · exact adaptive145Third140Proof204
  · exact adaptive145Third140Proof205
  · exact adaptive145Third140Proof206
  · exact adaptive145Third140Proof207
  · exact adaptive145Third140Proof208
  · exact adaptive145Third140Proof209
  · exact adaptive145Third140Proof210
  · exact adaptive145Third140Proof211
  · exact adaptive145Third140Proof212
  · exact adaptive145Third140Proof213
  · exact adaptive145Third140Proof214
  · exact adaptive145Third140Proof215
  · exact adaptive145Third140Proof216
  · exact adaptive145Third140Proof217
  · exact adaptive145Third140Proof218
  · exact adaptive145Third140Proof219
  · exact adaptive145Third140Proof220
  · exact adaptive145Third140Proof221
  · exact adaptive145Third140Proof222
  · exact adaptive145Third140Proof223
  · exact adaptive145Third140Proof224
  · exact adaptive145Third140Proof225
  · exact adaptive145Third140Proof226
  · exact adaptive145Third140Proof227
  · exact adaptive145Third140Proof228

#print axioms adaptive145Third140Proof196

theorem adaptive145Third140Proof263 : runCachedNode 511 130597 Adaptive145Third140Node263 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130597 Adaptive145Third140Node263 = [88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 125, 126, 127, 128] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive145Third140Proof264
  · exact adaptive145Third140Proof265
  · exact adaptive145Third140Proof266
  · exact adaptive145Third140Proof267
  · exact adaptive145Third140Proof268
  · exact adaptive145Third140Proof269
  · exact adaptive145Third140Proof270
  · exact adaptive145Third140Proof271
  · exact adaptive145Third140Proof272
  · exact adaptive145Third140Proof273
  · exact adaptive145Third140Proof274
  · exact adaptive145Third140Proof275
  · exact adaptive145Third140Proof276
  · exact adaptive145Third140Proof277
  · exact adaptive145Third140Proof278
  · exact adaptive145Third140Proof279
  · exact adaptive145Third140Proof280
  · exact adaptive145Third140Proof281
  · exact adaptive145Third140Proof282
  · exact adaptive145Third140Proof283
  · exact adaptive145Third140Proof284
  · exact adaptive145Third140Proof285
  · exact adaptive145Third140Proof286
  · exact adaptive145Third140Proof287
  · exact adaptive145Third140Proof288
  · exact adaptive145Third140Proof289
  · exact adaptive145Third140Proof290
  · exact adaptive145Third140Proof291
  · exact adaptive145Third140Proof292
  · exact adaptive145Third140Proof293
  · exact adaptive145Third140Proof294
  · exact adaptive145Third140Proof295
  · exact adaptive145Third140Proof296
  · exact adaptive145Third140Proof297
  · exact adaptive145Third140Proof298
  · exact adaptive145Third140Proof299
  · exact adaptive145Third140Proof300
  · exact adaptive145Third140Proof301
  · exact adaptive145Third140Proof302
  · exact adaptive145Third140Proof303

#print axioms adaptive145Third140Proof263

end NineSeparatedSubsetSums
