import NineSeparatedSubsetSums.Adaptive145Third142State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof530 : runCachedNode 511 130865 Adaptive145Third142Node530 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof530

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof532 : runCachedNode 511 130865 Adaptive145Third142Node532 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof532

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof457 : runCachedNode 511 130865 Adaptive145Third142Node457 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof457

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof859 : runCachedNode 511 130865 Adaptive145Third142Node859 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof859

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof392 : runCachedNode 511 130865 Adaptive145Third142Node392 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof392

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof219 : runCachedNode 511 130865 Adaptive145Third142Node219 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof219

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof455 : runCachedNode 511 130865 Adaptive145Third142Node455 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof455

end NineSeparatedSubsetSums
