import NineSeparatedSubsetSums.Adaptive145Third140State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third140Proof217 : runCachedNode 511 130597 Adaptive145Third140Node217 = false := by
  decide +kernel

#print axioms adaptive145Third140Proof217

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third140Proof128 : runCachedNode 511 130597 Adaptive145Third140Node128 = false := by
  decide +kernel

#print axioms adaptive145Third140Proof128

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third140Proof100 : runCachedNode 511 130597 Adaptive145Third140Node100 = false := by
  decide +kernel

#print axioms adaptive145Third140Proof100

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third140Proof123 : runCachedNode 511 130597 Adaptive145Third140Node123 = false := by
  decide +kernel

#print axioms adaptive145Third140Proof123

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third140Proof43 : runCachedNode 511 130597 Adaptive145Third140Node43 = false := by
  decide +kernel

#print axioms adaptive145Third140Proof43

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third140Proof256 : runCachedNode 511 130597 Adaptive145Third140Node256 = false := by
  decide +kernel

#print axioms adaptive145Third140Proof256

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third140Proof96 : runCachedNode 511 130597 Adaptive145Third140Node96 = false := by
  decide +kernel

#print axioms adaptive145Third140Proof96

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third140Proof11 : runCachedNode 511 130597 Adaptive145Third140Node11 = false := by
  decide +kernel

#print axioms adaptive145Third140Proof11

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third140Proof152 : runCachedNode 511 130597 Adaptive145Third140Node152 = false := by
  decide +kernel

#print axioms adaptive145Third140Proof152

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third140Proof219 : runCachedNode 511 130597 Adaptive145Third140Node219 = false := by
  decide +kernel

#print axioms adaptive145Third140Proof219

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third140Proof153 : runCachedNode 511 130597 Adaptive145Third140Node153 = false := by
  decide +kernel

#print axioms adaptive145Third140Proof153

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third140Proof151 : runCachedNode 511 130597 Adaptive145Third140Node151 = false := by
  decide +kernel

#print axioms adaptive145Third140Proof151

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third140Proof38 : runCachedNode 511 130597 Adaptive145Third140Node38 = false := by
  decide +kernel

#print axioms adaptive145Third140Proof38

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third140Proof233 : runCachedNode 511 130597 Adaptive145Third140Node233 = false := by
  decide +kernel

#print axioms adaptive145Third140Proof233

end NineSeparatedSubsetSums
