import NineSeparatedSubsetSums.Adaptive145Third142State
import NineSeparatedSubsetSums.Adaptive145Third142Leaves17
import NineSeparatedSubsetSums.Adaptive145Third142Leaves14
import NineSeparatedSubsetSums.Adaptive145Third142Leaves78
import NineSeparatedSubsetSums.Adaptive145Third142Leaves31
import NineSeparatedSubsetSums.Adaptive145Third142Leaves75
import NineSeparatedSubsetSums.Adaptive145Third142Leaves73
import NineSeparatedSubsetSums.Adaptive145Third142Leaves71
import NineSeparatedSubsetSums.Adaptive145Third142Leaves70
import NineSeparatedSubsetSums.Adaptive145Third142Leaves69
import NineSeparatedSubsetSums.Adaptive145Third142Leaves68
import NineSeparatedSubsetSums.Adaptive145Third142Leaves42
import NineSeparatedSubsetSums.Adaptive145Third142Leaves67
import NineSeparatedSubsetSums.Adaptive145Third142Leaves58
import NineSeparatedSubsetSums.Adaptive145Third142Leaves59
import NineSeparatedSubsetSums.Adaptive145Third142Leaves55
import NineSeparatedSubsetSums.Adaptive145Third142Leaves62
import NineSeparatedSubsetSums.Adaptive145Third142Leaves61
import NineSeparatedSubsetSums.Adaptive145Third142Leaves44
import NineSeparatedSubsetSums.Adaptive145Third142Leaves45
import NineSeparatedSubsetSums.Adaptive145Third142Leaves26
import NineSeparatedSubsetSums.Adaptive145Third142Leaves5
import NineSeparatedSubsetSums.Adaptive145Third142Leaves16
import NineSeparatedSubsetSums.Adaptive145Third142Leaves76
import NineSeparatedSubsetSums.Adaptive145Third142Leaves13
import NineSeparatedSubsetSums.Adaptive145Third142Leaves72
import NineSeparatedSubsetSums.Adaptive145Third142Leaves66
import NineSeparatedSubsetSums.Adaptive145Third142Leaves52
import NineSeparatedSubsetSums.Adaptive145Third142Leaves60
import NineSeparatedSubsetSums.Adaptive145Third142Leaves57
import NineSeparatedSubsetSums.Adaptive145Third142Leaves54
import NineSeparatedSubsetSums.Adaptive145Third142Leaves46
import NineSeparatedSubsetSums.Adaptive145Third142Leaves79
import NineSeparatedSubsetSums.Adaptive145Third142Leaves15
import NineSeparatedSubsetSums.Adaptive145Third142Leaves28
import NineSeparatedSubsetSums.Adaptive145Third142Leaves20
import NineSeparatedSubsetSums.Adaptive145Third142Leaves56
import NineSeparatedSubsetSums.Adaptive145Third142Leaves37
import NineSeparatedSubsetSums.Adaptive145Third142Leaves2
import NineSeparatedSubsetSums.Adaptive145Third142Leaves47
import NineSeparatedSubsetSums.Adaptive145Third142Leaves41
import NineSeparatedSubsetSums.Adaptive145Third142Leaves77
import NineSeparatedSubsetSums.Adaptive145Third142Leaves19
import NineSeparatedSubsetSums.Adaptive145Third142Leaves63
import NineSeparatedSubsetSums.Adaptive145Third142Leaves64
import NineSeparatedSubsetSums.Adaptive145Third142Leaves7
import NineSeparatedSubsetSums.Adaptive145Third142Leaves49
import NineSeparatedSubsetSums.Adaptive145Third142Leaves50
import NineSeparatedSubsetSums.Adaptive145Third142Leaves32
import NineSeparatedSubsetSums.Adaptive145Third142Leaves74
import NineSeparatedSubsetSums.Adaptive145Third142Leaves25
import NineSeparatedSubsetSums.Adaptive145Third142Leaves65
import NineSeparatedSubsetSums.Adaptive145Third142Leaves29
import NineSeparatedSubsetSums.Adaptive145Third142Leaves40
import NineSeparatedSubsetSums.Adaptive145Third142Leaves43
import NineSeparatedSubsetSums.Adaptive145Third142Leaves51
import NineSeparatedSubsetSums.Adaptive145Third142Leaves10
import NineSeparatedSubsetSums.Adaptive145Third142Leaves30
import NineSeparatedSubsetSums.Adaptive145Third142Leaves35
import NineSeparatedSubsetSums.Adaptive145Third142Leaves33
import NineSeparatedSubsetSums.Adaptive145Third142Leaves34
import NineSeparatedSubsetSums.Adaptive145Third142Leaves27
import NineSeparatedSubsetSums.Adaptive145Third142Leaves53
import NineSeparatedSubsetSums.Adaptive145Third142Leaves36
import NineSeparatedSubsetSums.Adaptive145Third142Leaves38
import NineSeparatedSubsetSums.Adaptive145Third142Leaves39
import NineSeparatedSubsetSums.Adaptive145Third142Leaves24

namespace NineSeparatedSubsetSums

theorem adaptive145Third142Proof19 : runCachedNode 511 130865 Adaptive145Third142Node19 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130865 Adaptive145Third142Node19 = [104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 122, 123, 125, 126] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive145Third142Proof20
  · exact adaptive145Third142Proof21
  · exact adaptive145Third142Proof22
  · exact adaptive145Third142Proof23
  · exact adaptive145Third142Proof24
  · exact adaptive145Third142Proof25
  · exact adaptive145Third142Proof26
  · exact adaptive145Third142Proof27
  · exact adaptive145Third142Proof28
  · exact adaptive145Third142Proof29
  · exact adaptive145Third142Proof30
  · exact adaptive145Third142Proof31
  · exact adaptive145Third142Proof32
  · exact adaptive145Third142Proof33
  · exact adaptive145Third142Proof34
  · exact adaptive145Third142Proof35
  · exact adaptive145Third142Proof36
  · exact adaptive145Third142Proof37
  · exact adaptive145Third142Proof38
  · exact adaptive145Third142Proof39
  · exact adaptive145Third142Proof40

#print axioms adaptive145Third142Proof19

theorem adaptive145Third142Proof41 : runCachedNode 511 130865 Adaptive145Third142Node41 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130865 Adaptive145Third142Node41 = [104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 123, 124, 126, 127] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive145Third142Proof42
  · exact adaptive145Third142Proof43
  · exact adaptive145Third142Proof44
  · exact adaptive145Third142Proof45
  · exact adaptive145Third142Proof46
  · exact adaptive145Third142Proof47
  · exact adaptive145Third142Proof48
  · exact adaptive145Third142Proof49
  · exact adaptive145Third142Proof50
  · exact adaptive145Third142Proof51
  · exact adaptive145Third142Proof52
  · exact adaptive145Third142Proof53
  · exact adaptive145Third142Proof54
  · exact adaptive145Third142Proof55
  · exact adaptive145Third142Proof56
  · exact adaptive145Third142Proof57
  · exact adaptive145Third142Proof58
  · exact adaptive145Third142Proof59
  · exact adaptive145Third142Proof60
  · exact adaptive145Third142Proof61
  · exact adaptive145Third142Proof62
  · exact adaptive145Third142Proof63

#print axioms adaptive145Third142Proof41

theorem adaptive145Third142Proof64 : runCachedNode 511 130865 Adaptive145Third142Node64 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130865 Adaptive145Third142Node64 = [104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 124, 125, 127, 128] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive145Third142Proof65
  · exact adaptive145Third142Proof66
  · exact adaptive145Third142Proof67
  · exact adaptive145Third142Proof68
  · exact adaptive145Third142Proof69
  · exact adaptive145Third142Proof70
  · exact adaptive145Third142Proof71
  · exact adaptive145Third142Proof72
  · exact adaptive145Third142Proof73
  · exact adaptive145Third142Proof74
  · exact adaptive145Third142Proof75
  · exact adaptive145Third142Proof76
  · exact adaptive145Third142Proof77
  · exact adaptive145Third142Proof78
  · exact adaptive145Third142Proof79
  · exact adaptive145Third142Proof80
  · exact adaptive145Third142Proof81
  · exact adaptive145Third142Proof82
  · exact adaptive145Third142Proof83
  · exact adaptive145Third142Proof84
  · exact adaptive145Third142Proof85
  · exact adaptive145Third142Proof86
  · exact adaptive145Third142Proof87

#print axioms adaptive145Third142Proof64

theorem adaptive145Third142Proof88 : runCachedNode 511 130865 Adaptive145Third142Node88 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130865 Adaptive145Third142Node88 = [103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 125, 126, 128, 129] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive145Third142Proof89
  · exact adaptive145Third142Proof90
  · exact adaptive145Third142Proof91
  · exact adaptive145Third142Proof92
  · exact adaptive145Third142Proof93
  · exact adaptive145Third142Proof94
  · exact adaptive145Third142Proof95
  · exact adaptive145Third142Proof96
  · exact adaptive145Third142Proof97
  · exact adaptive145Third142Proof98
  · exact adaptive145Third142Proof99
  · exact adaptive145Third142Proof100
  · exact adaptive145Third142Proof101
  · exact adaptive145Third142Proof102
  · exact adaptive145Third142Proof103
  · exact adaptive145Third142Proof104
  · exact adaptive145Third142Proof105
  · exact adaptive145Third142Proof106
  · exact adaptive145Third142Proof107
  · exact adaptive145Third142Proof108
  · exact adaptive145Third142Proof109
  · exact adaptive145Third142Proof110
  · exact adaptive145Third142Proof111
  · exact adaptive145Third142Proof112
  · exact adaptive145Third142Proof113

#print axioms adaptive145Third142Proof88

theorem adaptive145Third142Proof114 : runCachedNode 511 130865 Adaptive145Third142Node114 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130865 Adaptive145Third142Node114 = [103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 126, 127, 129, 130] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive145Third142Proof115
  · exact adaptive145Third142Proof116
  · exact adaptive145Third142Proof117
  · exact adaptive145Third142Proof118
  · exact adaptive145Third142Proof119
  · exact adaptive145Third142Proof120
  · exact adaptive145Third142Proof121
  · exact adaptive145Third142Proof122
  · exact adaptive145Third142Proof123
  · exact adaptive145Third142Proof124
  · exact adaptive145Third142Proof125
  · exact adaptive145Third142Proof126
  · exact adaptive145Third142Proof127
  · exact adaptive145Third142Proof128
  · exact adaptive145Third142Proof129
  · exact adaptive145Third142Proof130
  · exact adaptive145Third142Proof131
  · exact adaptive145Third142Proof132
  · exact adaptive145Third142Proof133
  · exact adaptive145Third142Proof134
  · exact adaptive145Third142Proof135
  · exact adaptive145Third142Proof136
  · exact adaptive145Third142Proof137
  · exact adaptive145Third142Proof138
  · exact adaptive145Third142Proof139
  · exact adaptive145Third142Proof140

#print axioms adaptive145Third142Proof114

theorem adaptive145Third142Proof141 : runCachedNode 511 130865 Adaptive145Third142Node141 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130865 Adaptive145Third142Node141 = [103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 127, 128, 130, 131] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive145Third142Proof142
  · exact adaptive145Third142Proof143
  · exact adaptive145Third142Proof144
  · exact adaptive145Third142Proof145
  · exact adaptive145Third142Proof146
  · exact adaptive145Third142Proof147
  · exact adaptive145Third142Proof148
  · exact adaptive145Third142Proof149
  · exact adaptive145Third142Proof150
  · exact adaptive145Third142Proof151
  · exact adaptive145Third142Proof152
  · exact adaptive145Third142Proof153
  · exact adaptive145Third142Proof154
  · exact adaptive145Third142Proof155
  · exact adaptive145Third142Proof156
  · exact adaptive145Third142Proof157
  · exact adaptive145Third142Proof158
  · exact adaptive145Third142Proof159
  · exact adaptive145Third142Proof160
  · exact adaptive145Third142Proof161
  · exact adaptive145Third142Proof162
  · exact adaptive145Third142Proof163
  · exact adaptive145Third142Proof164
  · exact adaptive145Third142Proof165
  · exact adaptive145Third142Proof166
  · exact adaptive145Third142Proof167
  · exact adaptive145Third142Proof168

#print axioms adaptive145Third142Proof141

theorem adaptive145Third142Proof169 : runCachedNode 511 130865 Adaptive145Third142Node169 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130865 Adaptive145Third142Node169 = [103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 128, 129, 131, 132] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive145Third142Proof170
  · exact adaptive145Third142Proof171
  · exact adaptive145Third142Proof172
  · exact adaptive145Third142Proof173
  · exact adaptive145Third142Proof174
  · exact adaptive145Third142Proof175
  · exact adaptive145Third142Proof176
  · exact adaptive145Third142Proof177
  · exact adaptive145Third142Proof178
  · exact adaptive145Third142Proof179
  · exact adaptive145Third142Proof180
  · exact adaptive145Third142Proof181
  · exact adaptive145Third142Proof182
  · exact adaptive145Third142Proof183
  · exact adaptive145Third142Proof184
  · exact adaptive145Third142Proof185
  · exact adaptive145Third142Proof186
  · exact adaptive145Third142Proof187
  · exact adaptive145Third142Proof188
  · exact adaptive145Third142Proof189
  · exact adaptive145Third142Proof190
  · exact adaptive145Third142Proof191
  · exact adaptive145Third142Proof192
  · exact adaptive145Third142Proof193
  · exact adaptive145Third142Proof194
  · exact adaptive145Third142Proof195
  · exact adaptive145Third142Proof196
  · exact adaptive145Third142Proof197

#print axioms adaptive145Third142Proof169

theorem adaptive145Third142Proof198 : runCachedNode 511 130865 Adaptive145Third142Node198 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130865 Adaptive145Third142Node198 = [102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 129, 130, 132, 133] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive145Third142Proof199
  · exact adaptive145Third142Proof200
  · exact adaptive145Third142Proof201
  · exact adaptive145Third142Proof202
  · exact adaptive145Third142Proof203
  · exact adaptive145Third142Proof204
  · exact adaptive145Third142Proof205
  · exact adaptive145Third142Proof206
  · exact adaptive145Third142Proof207
  · exact adaptive145Third142Proof208
  · exact adaptive145Third142Proof209
  · exact adaptive145Third142Proof210
  · exact adaptive145Third142Proof211
  · exact adaptive145Third142Proof212
  · exact adaptive145Third142Proof213
  · exact adaptive145Third142Proof214
  · exact adaptive145Third142Proof215
  · exact adaptive145Third142Proof216
  · exact adaptive145Third142Proof217
  · exact adaptive145Third142Proof218
  · exact adaptive145Third142Proof219
  · exact adaptive145Third142Proof220
  · exact adaptive145Third142Proof221
  · exact adaptive145Third142Proof222
  · exact adaptive145Third142Proof223
  · exact adaptive145Third142Proof224
  · exact adaptive145Third142Proof225
  · exact adaptive145Third142Proof226
  · exact adaptive145Third142Proof227
  · exact adaptive145Third142Proof228

#print axioms adaptive145Third142Proof198

end NineSeparatedSubsetSums
