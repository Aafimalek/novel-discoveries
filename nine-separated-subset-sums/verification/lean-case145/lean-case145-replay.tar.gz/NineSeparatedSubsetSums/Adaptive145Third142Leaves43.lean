import NineSeparatedSubsetSums.Adaptive145Third142State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof393 : runCachedNode 511 130865 Adaptive145Third142Node393 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof393

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof811 : runCachedNode 511 130865 Adaptive145Third142Node811 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof811

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof137 : runCachedNode 511 130865 Adaptive145Third142Node137 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof137

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof535 : runCachedNode 511 130865 Adaptive145Third142Node535 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof535

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof158 : runCachedNode 511 130865 Adaptive145Third142Node158 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof158

end NineSeparatedSubsetSums
