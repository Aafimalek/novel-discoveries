import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive145Third105Node0 : CachedSearchNode :=
  ⟨4, 104, computeCenteredMask [148,145,105], 398, 53954⟩

end NineSeparatedSubsetSums
