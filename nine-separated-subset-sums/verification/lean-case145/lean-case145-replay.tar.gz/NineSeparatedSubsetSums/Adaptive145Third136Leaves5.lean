import NineSeparatedSubsetSums.Adaptive145Third136State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third136Proof40 : runCachedNode 511 130013 Adaptive145Third136Node40 = false := by
  decide +kernel

#print axioms adaptive145Third136Proof40

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third136Proof69 : runCachedNode 511 130013 Adaptive145Third136Node69 = false := by
  decide +kernel

#print axioms adaptive145Third136Proof69

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third136Proof149 : runCachedNode 511 130013 Adaptive145Third136Node149 = false := by
  decide +kernel

#print axioms adaptive145Third136Proof149

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third136Proof120 : runCachedNode 511 130013 Adaptive145Third136Node120 = false := by
  decide +kernel

#print axioms adaptive145Third136Proof120

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third136Proof39 : runCachedNode 511 130013 Adaptive145Third136Node39 = false := by
  decide +kernel

#print axioms adaptive145Third136Proof39

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third136Proof134 : runCachedNode 511 130013 Adaptive145Third136Node134 = false := by
  decide +kernel

#print axioms adaptive145Third136Proof134

end NineSeparatedSubsetSums
