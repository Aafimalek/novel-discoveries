import NineSeparatedSubsetSums.Adaptive145Third133State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third133Proof17 : runCachedNode 511 129495 Adaptive145Third133Node17 = false := by
  decide +kernel

#print axioms adaptive145Third133Proof17

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third133Proof16 : runCachedNode 511 129495 Adaptive145Third133Node16 = false := by
  decide +kernel

#print axioms adaptive145Third133Proof16

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third133Proof14 : runCachedNode 511 129495 Adaptive145Third133Node14 = false := by
  decide +kernel

#print axioms adaptive145Third133Proof14

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third133Proof13 : runCachedNode 511 129495 Adaptive145Third133Node13 = false := by
  decide +kernel

#print axioms adaptive145Third133Proof13

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third133Proof34 : runCachedNode 511 129495 Adaptive145Third133Node34 = false := by
  decide +kernel

#print axioms adaptive145Third133Proof34

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third133Proof32 : runCachedNode 511 129495 Adaptive145Third133Node32 = false := by
  decide +kernel

#print axioms adaptive145Third133Proof32

end NineSeparatedSubsetSums
