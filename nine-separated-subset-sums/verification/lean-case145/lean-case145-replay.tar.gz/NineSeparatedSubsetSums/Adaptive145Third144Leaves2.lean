import NineSeparatedSubsetSums.Adaptive145Third144State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third144Proof374 : runCachedNode 511 131183 Adaptive145Third144Node374 = false := by
  decide +kernel

#print axioms adaptive145Third144Proof374

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third144Proof668 : runCachedNode 511 131183 Adaptive145Third144Node668 = false := by
  decide +kernel

#print axioms adaptive145Third144Proof668

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third144Proof2 : runCachedNode 511 131183 Adaptive145Third144Node2 = false := by
  decide +kernel

#print axioms adaptive145Third144Proof2

end NineSeparatedSubsetSums
