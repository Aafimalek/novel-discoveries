import NineSeparatedSubsetSums.Adaptive145Third133State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third133Proof37 : runCachedNode 511 129495 Adaptive145Third133Node37 = false := by
  decide +kernel

#print axioms adaptive145Third133Proof37

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third133Proof6 : runCachedNode 511 129495 Adaptive145Third133Node6 = false := by
  decide +kernel

#print axioms adaptive145Third133Proof6

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third133Proof33 : runCachedNode 511 129495 Adaptive145Third133Node33 = false := by
  decide +kernel

#print axioms adaptive145Third133Proof33

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third133Proof4 : runCachedNode 511 129495 Adaptive145Third133Node4 = false := by
  decide +kernel

#print axioms adaptive145Third133Proof4

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third133Proof29 : runCachedNode 511 129495 Adaptive145Third133Node29 = false := by
  decide +kernel

#print axioms adaptive145Third133Proof29

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third133Proof30 : runCachedNode 511 129495 Adaptive145Third133Node30 = false := by
  decide +kernel

#print axioms adaptive145Third133Proof30

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third133Proof2 : runCachedNode 511 129495 Adaptive145Third133Node2 = false := by
  decide +kernel

#print axioms adaptive145Third133Proof2

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third133Proof27 : runCachedNode 511 129495 Adaptive145Third133Node27 = false := by
  decide +kernel

#print axioms adaptive145Third133Proof27

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third133Proof26 : runCachedNode 511 129495 Adaptive145Third133Node26 = false := by
  decide +kernel

#print axioms adaptive145Third133Proof26

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third133Proof24 : runCachedNode 511 129495 Adaptive145Third133Node24 = false := by
  decide +kernel

#print axioms adaptive145Third133Proof24

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third133Proof25 : runCachedNode 511 129495 Adaptive145Third133Node25 = false := by
  decide +kernel

#print axioms adaptive145Third133Proof25

end NineSeparatedSubsetSums
