import NineSeparatedSubsetSums.Adaptive145Third144State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third144Proof264 : runCachedNode 511 131183 Adaptive145Third144Node264 = false := by
  decide +kernel

#print axioms adaptive145Third144Proof264

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third144Proof227 : runCachedNode 511 131183 Adaptive145Third144Node227 = false := by
  decide +kernel

#print axioms adaptive145Third144Proof227

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third144Proof55 : runCachedNode 511 131183 Adaptive145Third144Node55 = false := by
  decide +kernel

#print axioms adaptive145Third144Proof55

end NineSeparatedSubsetSums
