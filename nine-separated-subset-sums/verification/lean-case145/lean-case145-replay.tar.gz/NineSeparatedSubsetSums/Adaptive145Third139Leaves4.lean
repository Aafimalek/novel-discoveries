import NineSeparatedSubsetSums.Adaptive145Third139State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third139Proof20 : runCachedNode 511 130465 Adaptive145Third139Node20 = false := by
  decide +kernel

#print axioms adaptive145Third139Proof20

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third139Proof191 : runCachedNode 511 130465 Adaptive145Third139Node191 = false := by
  decide +kernel

#print axioms adaptive145Third139Proof191

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third139Proof64 : runCachedNode 511 130465 Adaptive145Third139Node64 = false := by
  decide +kernel

#print axioms adaptive145Third139Proof64

end NineSeparatedSubsetSums
