import NineSeparatedSubsetSums.Adaptive145Third143State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof228 : runCachedNode 511 131040 Adaptive145Third143Node228 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof228

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof17 : runCachedNode 511 131040 Adaptive145Third143Node17 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof17

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof593 : runCachedNode 511 131040 Adaptive145Third143Node593 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof593

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof6 : runCachedNode 511 131040 Adaptive145Third143Node6 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof6

end NineSeparatedSubsetSums
