import NineSeparatedSubsetSums.Adaptive145Third143State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof260 : runCachedNode 511 131040 Adaptive145Third143Node260 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof260

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof18 : runCachedNode 511 131040 Adaptive145Third143Node18 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof18

end NineSeparatedSubsetSums
