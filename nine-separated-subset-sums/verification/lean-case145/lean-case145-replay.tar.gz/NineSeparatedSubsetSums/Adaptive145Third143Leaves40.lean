import NineSeparatedSubsetSums.Adaptive145Third143State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof74 : runCachedNode 511 131040 Adaptive145Third143Node74 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof74

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof73 : runCachedNode 511 131040 Adaptive145Third143Node73 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof73

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof406 : runCachedNode 511 131040 Adaptive145Third143Node406 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof406

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof98 : runCachedNode 511 131040 Adaptive145Third143Node98 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof98

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof579 : runCachedNode 511 131040 Adaptive145Third143Node579 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof579

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof254 : runCachedNode 511 131040 Adaptive145Third143Node254 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof254

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof381 : runCachedNode 511 131040 Adaptive145Third143Node381 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof381

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof336 : runCachedNode 511 131040 Adaptive145Third143Node336 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof336

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof460 : runCachedNode 511 131040 Adaptive145Third143Node460 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof460

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof115 : runCachedNode 511 131040 Adaptive145Third143Node115 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof115

end NineSeparatedSubsetSums
