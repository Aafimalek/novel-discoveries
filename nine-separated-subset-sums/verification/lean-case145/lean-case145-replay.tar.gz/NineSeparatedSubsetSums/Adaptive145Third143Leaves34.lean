import NineSeparatedSubsetSums.Adaptive145Third143State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof546 : runCachedNode 511 131040 Adaptive145Third143Node546 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof546

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof410 : runCachedNode 511 131040 Adaptive145Third143Node410 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof410

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof491 : runCachedNode 511 131040 Adaptive145Third143Node491 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof491

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof382 : runCachedNode 511 131040 Adaptive145Third143Node382 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof382

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof462 : runCachedNode 511 131040 Adaptive145Third143Node462 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof462

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof47 : runCachedNode 511 131040 Adaptive145Third143Node47 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof47

end NineSeparatedSubsetSums
