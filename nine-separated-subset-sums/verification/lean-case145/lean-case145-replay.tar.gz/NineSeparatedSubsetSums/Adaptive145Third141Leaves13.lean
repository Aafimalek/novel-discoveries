import NineSeparatedSubsetSums.Adaptive145Third141State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third141Proof299 : runCachedNode 511 130740 Adaptive145Third141Node299 = false := by
  decide +kernel

#print axioms adaptive145Third141Proof299

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third141Proof266 : runCachedNode 511 130740 Adaptive145Third141Node266 = false := by
  decide +kernel

#print axioms adaptive145Third141Proof266

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third141Proof103 : runCachedNode 511 130740 Adaptive145Third141Node103 = false := by
  decide +kernel

#print axioms adaptive145Third141Proof103

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third141Proof339 : runCachedNode 511 130740 Adaptive145Third141Node339 = false := by
  decide +kernel

#print axioms adaptive145Third141Proof339

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third141Proof231 : runCachedNode 511 130740 Adaptive145Third141Node231 = false := by
  decide +kernel

#print axioms adaptive145Third141Proof231

end NineSeparatedSubsetSums
