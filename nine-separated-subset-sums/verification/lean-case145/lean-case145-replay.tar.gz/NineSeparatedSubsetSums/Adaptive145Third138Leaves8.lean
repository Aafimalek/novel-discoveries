import NineSeparatedSubsetSums.Adaptive145Third138State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third138Proof101 : runCachedNode 511 130311 Adaptive145Third138Node101 = false := by
  decide +kernel

#print axioms adaptive145Third138Proof101

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third138Proof190 : runCachedNode 511 130311 Adaptive145Third138Node190 = false := by
  decide +kernel

#print axioms adaptive145Third138Proof190

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third138Proof157 : runCachedNode 511 130311 Adaptive145Third138Node157 = false := by
  decide +kernel

#print axioms adaptive145Third138Proof157

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third138Proof180 : runCachedNode 511 130311 Adaptive145Third138Node180 = false := by
  decide +kernel

#print axioms adaptive145Third138Proof180

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third138Proof103 : runCachedNode 511 130311 Adaptive145Third138Node103 = false := by
  decide +kernel

#print axioms adaptive145Third138Proof103

end NineSeparatedSubsetSums
