import NineSeparatedSubsetSums.Adaptive145Third142State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof38 : runCachedNode 511 130865 Adaptive145Third142Node38 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof38

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof187 : runCachedNode 511 130865 Adaptive145Third142Node187 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof187

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof57 : runCachedNode 511 130865 Adaptive145Third142Node57 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof57

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof528 : runCachedNode 511 130865 Adaptive145Third142Node528 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof528

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof944 : runCachedNode 511 130865 Adaptive145Third142Node944 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof944

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof249 : runCachedNode 511 130865 Adaptive145Third142Node249 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof249

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof643 : runCachedNode 511 130865 Adaptive145Third142Node643 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof643

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof34 : runCachedNode 511 130865 Adaptive145Third142Node34 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof34

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof247 : runCachedNode 511 130865 Adaptive145Third142Node247 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof247

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof735 : runCachedNode 511 130865 Adaptive145Third142Node735 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof735

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof125 : runCachedNode 511 130865 Adaptive145Third142Node125 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof125

end NineSeparatedSubsetSums
