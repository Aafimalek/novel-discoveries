import NineSeparatedSubsetSums.Adaptive145Third141State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third141Proof126 : runCachedNode 511 130740 Adaptive145Third141Node126 = false := by
  decide +kernel

#print axioms adaptive145Third141Proof126

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third141Proof158 : runCachedNode 511 130740 Adaptive145Third141Node158 = false := by
  decide +kernel

#print axioms adaptive145Third141Proof158

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third141Proof163 : runCachedNode 511 130740 Adaptive145Third141Node163 = false := by
  decide +kernel

#print axioms adaptive145Third141Proof163

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third141Proof224 : runCachedNode 511 130740 Adaptive145Third141Node224 = false := by
  decide +kernel

#print axioms adaptive145Third141Proof224

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third141Proof215 : runCachedNode 511 130740 Adaptive145Third141Node215 = false := by
  decide +kernel

#print axioms adaptive145Third141Proof215

end NineSeparatedSubsetSums
