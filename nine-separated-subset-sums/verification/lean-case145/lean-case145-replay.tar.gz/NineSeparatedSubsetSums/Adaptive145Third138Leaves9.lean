import NineSeparatedSubsetSums.Adaptive145Third138State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third138Proof192 : runCachedNode 511 130311 Adaptive145Third138Node192 = false := by
  decide +kernel

#print axioms adaptive145Third138Proof192

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third138Proof17 : runCachedNode 511 130311 Adaptive145Third138Node17 = false := by
  decide +kernel

#print axioms adaptive145Third138Proof17

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third138Proof130 : runCachedNode 511 130311 Adaptive145Third138Node130 = false := by
  decide +kernel

#print axioms adaptive145Third138Proof130

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third138Proof142 : runCachedNode 511 130311 Adaptive145Third138Node142 = false := by
  decide +kernel

#print axioms adaptive145Third138Proof142

end NineSeparatedSubsetSums
