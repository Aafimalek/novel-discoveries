import NineSeparatedSubsetSums.Adaptive145Third140State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third140Proof259 : runCachedNode 511 130597 Adaptive145Third140Node259 = false := by
  decide +kernel

#print axioms adaptive145Third140Proof259

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third140Proof72 : runCachedNode 511 130597 Adaptive145Third140Node72 = false := by
  decide +kernel

#print axioms adaptive145Third140Proof72

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third140Proof222 : runCachedNode 511 130597 Adaptive145Third140Node222 = false := by
  decide +kernel

#print axioms adaptive145Third140Proof222

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third140Proof154 : runCachedNode 511 130597 Adaptive145Third140Node154 = false := by
  decide +kernel

#print axioms adaptive145Third140Proof154

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third140Proof156 : runCachedNode 511 130597 Adaptive145Third140Node156 = false := by
  decide +kernel

#print axioms adaptive145Third140Proof156

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third140Proof66 : runCachedNode 511 130597 Adaptive145Third140Node66 = false := by
  decide +kernel

#print axioms adaptive145Third140Proof66

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third140Proof2 : runCachedNode 511 130597 Adaptive145Third140Node2 = false := by
  decide +kernel

#print axioms adaptive145Third140Proof2

end NineSeparatedSubsetSums
