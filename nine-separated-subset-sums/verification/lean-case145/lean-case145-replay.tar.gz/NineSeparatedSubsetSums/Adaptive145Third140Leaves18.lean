import NineSeparatedSubsetSums.Adaptive145Third140State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third140Proof14 : runCachedNode 511 130597 Adaptive145Third140Node14 = false := by
  decide +kernel

#print axioms adaptive145Third140Proof14

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third140Proof302 : runCachedNode 511 130597 Adaptive145Third140Node302 = false := by
  decide +kernel

#print axioms adaptive145Third140Proof302

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third140Proof257 : runCachedNode 511 130597 Adaptive145Third140Node257 = false := by
  decide +kernel

#print axioms adaptive145Third140Proof257

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third140Proof125 : runCachedNode 511 130597 Adaptive145Third140Node125 = false := by
  decide +kernel

#print axioms adaptive145Third140Proof125

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third140Proof220 : runCachedNode 511 130597 Adaptive145Third140Node220 = false := by
  decide +kernel

#print axioms adaptive145Third140Proof220

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third140Proof127 : runCachedNode 511 130597 Adaptive145Third140Node127 = false := by
  decide +kernel

#print axioms adaptive145Third140Proof127

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third140Proof83 : runCachedNode 511 130597 Adaptive145Third140Node83 = false := by
  decide +kernel

#print axioms adaptive145Third140Proof83

end NineSeparatedSubsetSums
