import NineSeparatedSubsetSums.Adaptive145Third143State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof543 : runCachedNode 511 131040 Adaptive145Third143Node543 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof543

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof574 : runCachedNode 511 131040 Adaptive145Third143Node574 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof574

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof69 : runCachedNode 511 131040 Adaptive145Third143Node69 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof69

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof404 : runCachedNode 511 131040 Adaptive145Third143Node404 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof404

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof380 : runCachedNode 511 131040 Adaptive145Third143Node380 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof380

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof334 : runCachedNode 511 131040 Adaptive145Third143Node334 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof334

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof575 : runCachedNode 511 131040 Adaptive145Third143Node575 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof575

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof403 : runCachedNode 511 131040 Adaptive145Third143Node403 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof403

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof252 : runCachedNode 511 131040 Adaptive145Third143Node252 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof252

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof576 : runCachedNode 511 131040 Adaptive145Third143Node576 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof576

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof11 : runCachedNode 511 131040 Adaptive145Third143Node11 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof11

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof190 : runCachedNode 511 131040 Adaptive145Third143Node190 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof190

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof295 : runCachedNode 511 131040 Adaptive145Third143Node295 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof295

end NineSeparatedSubsetSums
