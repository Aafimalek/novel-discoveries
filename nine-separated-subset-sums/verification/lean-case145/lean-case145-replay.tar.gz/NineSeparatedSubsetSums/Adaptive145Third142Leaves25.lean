import NineSeparatedSubsetSums.Adaptive145Third142State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof191 : runCachedNode 511 130865 Adaptive145Third142Node191 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof191

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof461 : runCachedNode 511 130865 Adaptive145Third142Node461 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof461

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof124 : runCachedNode 511 130865 Adaptive145Third142Node124 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof124

end NineSeparatedSubsetSums
