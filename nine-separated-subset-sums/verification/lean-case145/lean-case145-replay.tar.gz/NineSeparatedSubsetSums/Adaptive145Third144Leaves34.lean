import NineSeparatedSubsetSums.Adaptive145Third144State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third144Proof491 : runCachedNode 511 131183 Adaptive145Third144Node491 = false := by
  decide +kernel

#print axioms adaptive145Third144Proof491

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third144Proof490 : runCachedNode 511 131183 Adaptive145Third144Node490 = false := by
  decide +kernel

#print axioms adaptive145Third144Proof490

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third144Proof195 : runCachedNode 511 131183 Adaptive145Third144Node195 = false := by
  decide +kernel

#print axioms adaptive145Third144Proof195

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third144Proof15 : runCachedNode 511 131183 Adaptive145Third144Node15 = false := by
  decide +kernel

#print axioms adaptive145Third144Proof15

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third144Proof475 : runCachedNode 511 131183 Adaptive145Third144Node475 = false := by
  decide +kernel

#print axioms adaptive145Third144Proof475

end NineSeparatedSubsetSums
