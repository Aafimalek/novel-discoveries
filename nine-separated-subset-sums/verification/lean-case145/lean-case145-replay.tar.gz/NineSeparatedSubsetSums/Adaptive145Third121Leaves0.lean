import NineSeparatedSubsetSums.Adaptive145Third121State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third121Proof0 : runCachedNode 511 126538 Adaptive145Third121Node0 = false := by
  decide +kernel

#print axioms adaptive145Third121Proof0

end NineSeparatedSubsetSums
