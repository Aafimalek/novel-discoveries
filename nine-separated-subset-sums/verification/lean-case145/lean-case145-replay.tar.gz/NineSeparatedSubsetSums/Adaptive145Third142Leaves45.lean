import NineSeparatedSubsetSums.Adaptive145Third142State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof188 : runCachedNode 511 130865 Adaptive145Third142Node188 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof188

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof650 : runCachedNode 511 130865 Adaptive145Third142Node650 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof650

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof810 : runCachedNode 511 130865 Adaptive145Third142Node810 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof810

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof622 : runCachedNode 511 130865 Adaptive145Third142Node622 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof622

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof40 : runCachedNode 511 130865 Adaptive145Third142Node40 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof40

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof361 : runCachedNode 511 130865 Adaptive145Third142Node361 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof361

end NineSeparatedSubsetSums
