import NineSeparatedSubsetSums.Adaptive145Third137State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third137Proof182 : runCachedNode 511 130164 Adaptive145Third137Node182 = false := by
  decide +kernel

#print axioms adaptive145Third137Proof182

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third137Proof14 : runCachedNode 511 130164 Adaptive145Third137Node14 = false := by
  decide +kernel

#print axioms adaptive145Third137Proof14

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third137Proof3 : runCachedNode 511 130164 Adaptive145Third137Node3 = false := by
  decide +kernel

#print axioms adaptive145Third137Proof3

end NineSeparatedSubsetSums
