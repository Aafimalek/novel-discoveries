import NineSeparatedSubsetSums.Adaptive145Third135State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third135Proof21 : runCachedNode 511 129879 Adaptive145Third135Node21 = false := by
  decide +kernel

#print axioms adaptive145Third135Proof21

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third135Proof46 : runCachedNode 511 129879 Adaptive145Third135Node46 = false := by
  decide +kernel

#print axioms adaptive145Third135Proof46

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third135Proof26 : runCachedNode 511 129879 Adaptive145Third135Node26 = false := by
  decide +kernel

#print axioms adaptive145Third135Proof26

end NineSeparatedSubsetSums
