import NineSeparatedSubsetSums.Adaptive145Third137State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third137Proof122 : runCachedNode 511 130164 Adaptive145Third137Node122 = false := by
  decide +kernel

#print axioms adaptive145Third137Proof122

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third137Proof94 : runCachedNode 511 130164 Adaptive145Third137Node94 = false := by
  decide +kernel

#print axioms adaptive145Third137Proof94

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third137Proof149 : runCachedNode 511 130164 Adaptive145Third137Node149 = false := by
  decide +kernel

#print axioms adaptive145Third137Proof149

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third137Proof68 : runCachedNode 511 130164 Adaptive145Third137Node68 = false := by
  decide +kernel

#print axioms adaptive145Third137Proof68

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third137Proof25 : runCachedNode 511 130164 Adaptive145Third137Node25 = false := by
  decide +kernel

#print axioms adaptive145Third137Proof25

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third137Proof124 : runCachedNode 511 130164 Adaptive145Third137Node124 = false := by
  decide +kernel

#print axioms adaptive145Third137Proof124

end NineSeparatedSubsetSums
