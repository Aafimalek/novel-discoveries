import NineSeparatedSubsetSums.Adaptive145Third129State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third129Proof18 : runCachedNode 511 128639 Adaptive145Third129Node18 = false := by
  decide +kernel

#print axioms adaptive145Third129Proof18

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third129Proof17 : runCachedNode 511 128639 Adaptive145Third129Node17 = false := by
  decide +kernel

#print axioms adaptive145Third129Proof17

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third129Proof16 : runCachedNode 511 128639 Adaptive145Third129Node16 = false := by
  decide +kernel

#print axioms adaptive145Third129Proof16

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third129Proof6 : runCachedNode 511 128639 Adaptive145Third129Node6 = false := by
  decide +kernel

#print axioms adaptive145Third129Proof6

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third129Proof1 : runCachedNode 511 128639 Adaptive145Third129Node1 = false := by
  decide +kernel

#print axioms adaptive145Third129Proof1

end NineSeparatedSubsetSums
