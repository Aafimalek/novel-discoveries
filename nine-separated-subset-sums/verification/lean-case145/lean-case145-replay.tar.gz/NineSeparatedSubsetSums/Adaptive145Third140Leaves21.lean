import NineSeparatedSubsetSums.Adaptive145Third140State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third140Proof300 : runCachedNode 511 130597 Adaptive145Third140Node300 = false := by
  decide +kernel

#print axioms adaptive145Third140Proof300

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third140Proof12 : runCachedNode 511 130597 Adaptive145Third140Node12 = false := by
  decide +kernel

#print axioms adaptive145Third140Proof12

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third140Proof97 : runCachedNode 511 130597 Adaptive145Third140Node97 = false := by
  decide +kernel

#print axioms adaptive145Third140Proof97

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third140Proof187 : runCachedNode 511 130597 Adaptive145Third140Node187 = false := by
  decide +kernel

#print axioms adaptive145Third140Proof187

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third140Proof189 : runCachedNode 511 130597 Adaptive145Third140Node189 = false := by
  decide +kernel

#print axioms adaptive145Third140Proof189

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third140Proof124 : runCachedNode 511 130597 Adaptive145Third140Node124 = false := by
  decide +kernel

#print axioms adaptive145Third140Proof124

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third140Proof255 : runCachedNode 511 130597 Adaptive145Third140Node255 = false := by
  decide +kernel

#print axioms adaptive145Third140Proof255

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third140Proof122 : runCachedNode 511 130597 Adaptive145Third140Node122 = false := by
  decide +kernel

#print axioms adaptive145Third140Proof122

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third140Proof188 : runCachedNode 511 130597 Adaptive145Third140Node188 = false := by
  decide +kernel

#print axioms adaptive145Third140Proof188

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third140Proof67 : runCachedNode 511 130597 Adaptive145Third140Node67 = false := by
  decide +kernel

#print axioms adaptive145Third140Proof67

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third140Proof9 : runCachedNode 511 130597 Adaptive145Third140Node9 = false := by
  decide +kernel

#print axioms adaptive145Third140Proof9

end NineSeparatedSubsetSums
