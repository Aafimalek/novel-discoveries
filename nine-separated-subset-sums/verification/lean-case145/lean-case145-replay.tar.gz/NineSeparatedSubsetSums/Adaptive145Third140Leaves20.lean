import NineSeparatedSubsetSums.Adaptive145Third140State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third140Proof13 : runCachedNode 511 130597 Adaptive145Third140Node13 = false := by
  decide +kernel

#print axioms adaptive145Third140Proof13

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third140Proof70 : runCachedNode 511 130597 Adaptive145Third140Node70 = false := by
  decide +kernel

#print axioms adaptive145Third140Proof70

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third140Proof221 : runCachedNode 511 130597 Adaptive145Third140Node221 = false := by
  decide +kernel

#print axioms adaptive145Third140Proof221

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third140Proof126 : runCachedNode 511 130597 Adaptive145Third140Node126 = false := by
  decide +kernel

#print axioms adaptive145Third140Proof126

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third140Proof155 : runCachedNode 511 130597 Adaptive145Third140Node155 = false := by
  decide +kernel

#print axioms adaptive145Third140Proof155

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third140Proof218 : runCachedNode 511 130597 Adaptive145Third140Node218 = false := by
  decide +kernel

#print axioms adaptive145Third140Proof218

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third140Proof45 : runCachedNode 511 130597 Adaptive145Third140Node45 = false := by
  decide +kernel

#print axioms adaptive145Third140Proof45

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third140Proof46 : runCachedNode 511 130597 Adaptive145Third140Node46 = false := by
  decide +kernel

#print axioms adaptive145Third140Proof46

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third140Proof44 : runCachedNode 511 130597 Adaptive145Third140Node44 = false := by
  decide +kernel

#print axioms adaptive145Third140Proof44

end NineSeparatedSubsetSums
