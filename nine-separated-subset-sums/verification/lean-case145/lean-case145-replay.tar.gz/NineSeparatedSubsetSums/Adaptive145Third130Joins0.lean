import NineSeparatedSubsetSums.Adaptive145Third130State
import NineSeparatedSubsetSums.Adaptive145Third130Leaves1
import NineSeparatedSubsetSums.Adaptive145Third130Leaves2
import NineSeparatedSubsetSums.Adaptive145Third130Leaves0

namespace NineSeparatedSubsetSums

theorem adaptive145Third130Proof0 : runCachedNode 511 128861 Adaptive145Third130Node0 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 128861 Adaptive145Third130Node0 = [110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 128, 129] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive145Third130Proof1
  · exact adaptive145Third130Proof2
  · exact adaptive145Third130Proof3
  · exact adaptive145Third130Proof4
  · exact adaptive145Third130Proof5
  · exact adaptive145Third130Proof6
  · exact adaptive145Third130Proof7
  · exact adaptive145Third130Proof8
  · exact adaptive145Third130Proof9
  · exact adaptive145Third130Proof10
  · exact adaptive145Third130Proof11
  · exact adaptive145Third130Proof12
  · exact adaptive145Third130Proof13
  · exact adaptive145Third130Proof14
  · exact adaptive145Third130Proof15
  · exact adaptive145Third130Proof16
  · exact adaptive145Third130Proof17
  · exact adaptive145Third130Proof18
  · exact adaptive145Third130Proof19

#print axioms adaptive145Third130Proof0

end NineSeparatedSubsetSums
