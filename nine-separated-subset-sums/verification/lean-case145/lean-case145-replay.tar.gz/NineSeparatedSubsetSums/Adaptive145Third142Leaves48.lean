import NineSeparatedSubsetSums.Adaptive145Third142State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof780 : runCachedNode 511 130865 Adaptive145Third142Node780 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof780

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof456 : runCachedNode 511 130865 Adaptive145Third142Node456 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof456

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof316 : runCachedNode 511 130865 Adaptive145Third142Node316 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof316

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof737 : runCachedNode 511 130865 Adaptive145Third142Node737 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof737

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof250 : runCachedNode 511 130865 Adaptive145Third142Node250 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof250

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof448 : runCachedNode 511 130865 Adaptive145Third142Node448 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof448

end NineSeparatedSubsetSums
