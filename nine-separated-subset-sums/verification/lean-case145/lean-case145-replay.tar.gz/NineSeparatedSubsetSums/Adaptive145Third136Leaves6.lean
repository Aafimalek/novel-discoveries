import NineSeparatedSubsetSums.Adaptive145Third136State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third136Proof122 : runCachedNode 511 130013 Adaptive145Third136Node122 = false := by
  decide +kernel

#print axioms adaptive145Third136Proof122

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third136Proof67 : runCachedNode 511 130013 Adaptive145Third136Node67 = false := by
  decide +kernel

#print axioms adaptive145Third136Proof67

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third136Proof44 : runCachedNode 511 130013 Adaptive145Third136Node44 = false := by
  decide +kernel

#print axioms adaptive145Third136Proof44

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third136Proof150 : runCachedNode 511 130013 Adaptive145Third136Node150 = false := by
  decide +kernel

#print axioms adaptive145Third136Proof150

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third136Proof95 : runCachedNode 511 130013 Adaptive145Third136Node95 = false := by
  decide +kernel

#print axioms adaptive145Third136Proof95

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third136Proof91 : runCachedNode 511 130013 Adaptive145Third136Node91 = false := by
  decide +kernel

#print axioms adaptive145Third136Proof91

end NineSeparatedSubsetSums
