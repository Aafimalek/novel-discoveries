import NineSeparatedSubsetSums.Adaptive145Third143State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof250 : runCachedNode 511 131040 Adaptive145Third143Node250 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof250

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof303 : runCachedNode 511 131040 Adaptive145Third143Node303 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof303

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof483 : runCachedNode 511 131040 Adaptive145Third143Node483 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof483

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof43 : runCachedNode 511 131040 Adaptive145Third143Node43 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof43

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof249 : runCachedNode 511 131040 Adaptive145Third143Node249 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof249

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof68 : runCachedNode 511 131040 Adaptive145Third143Node68 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof68

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof187 : runCachedNode 511 131040 Adaptive145Third143Node187 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof187

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof379 : runCachedNode 511 131040 Adaptive145Third143Node379 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof379

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof568 : runCachedNode 511 131040 Adaptive145Third143Node568 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof568

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof125 : runCachedNode 511 131040 Adaptive145Third143Node125 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof125

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof333 : runCachedNode 511 131040 Adaptive145Third143Node333 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof333

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof218 : runCachedNode 511 131040 Adaptive145Third143Node218 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof218

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof248 : runCachedNode 511 131040 Adaptive145Third143Node248 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof248

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof482 : runCachedNode 511 131040 Adaptive145Third143Node482 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof482

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof188 : runCachedNode 511 131040 Adaptive145Third143Node188 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof188

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof457 : runCachedNode 511 131040 Adaptive145Third143Node457 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof457

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof375 : runCachedNode 511 131040 Adaptive145Third143Node375 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof375

end NineSeparatedSubsetSums
