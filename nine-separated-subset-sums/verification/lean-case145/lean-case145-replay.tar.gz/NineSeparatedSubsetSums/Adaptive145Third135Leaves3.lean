import NineSeparatedSubsetSums.Adaptive145Third135State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third135Proof76 : runCachedNode 511 129879 Adaptive145Third135Node76 = false := by
  decide +kernel

#print axioms adaptive145Third135Proof76

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third135Proof48 : runCachedNode 511 129879 Adaptive145Third135Node48 = false := by
  decide +kernel

#print axioms adaptive145Third135Proof48

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third135Proof44 : runCachedNode 511 129879 Adaptive145Third135Node44 = false := by
  decide +kernel

#print axioms adaptive145Third135Proof44

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third135Proof30 : runCachedNode 511 129879 Adaptive145Third135Node30 = false := by
  decide +kernel

#print axioms adaptive145Third135Proof30

end NineSeparatedSubsetSums
