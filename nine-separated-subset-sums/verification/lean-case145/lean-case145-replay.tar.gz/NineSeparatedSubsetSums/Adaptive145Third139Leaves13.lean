import NineSeparatedSubsetSums.Adaptive145Third139State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third139Proof185 : runCachedNode 511 130465 Adaptive145Third139Node185 = false := by
  decide +kernel

#print axioms adaptive145Third139Proof185

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third139Proof70 : runCachedNode 511 130465 Adaptive145Third139Node70 = false := by
  decide +kernel

#print axioms adaptive145Third139Proof70

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third139Proof42 : runCachedNode 511 130465 Adaptive145Third139Node42 = false := by
  decide +kernel

#print axioms adaptive145Third139Proof42

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third139Proof125 : runCachedNode 511 130465 Adaptive145Third139Node125 = false := by
  decide +kernel

#print axioms adaptive145Third139Proof125

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third139Proof124 : runCachedNode 511 130465 Adaptive145Third139Node124 = false := by
  decide +kernel

#print axioms adaptive145Third139Proof124

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third139Proof89 : runCachedNode 511 130465 Adaptive145Third139Node89 = false := by
  decide +kernel

#print axioms adaptive145Third139Proof89

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third139Proof91 : runCachedNode 511 130465 Adaptive145Third139Node91 = false := by
  decide +kernel

#print axioms adaptive145Third139Proof91

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third139Proof122 : runCachedNode 511 130465 Adaptive145Third139Node122 = false := by
  decide +kernel

#print axioms adaptive145Third139Proof122

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third139Proof68 : runCachedNode 511 130465 Adaptive145Third139Node68 = false := by
  decide +kernel

#print axioms adaptive145Third139Proof68

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third139Proof155 : runCachedNode 511 130465 Adaptive145Third139Node155 = false := by
  decide +kernel

#print axioms adaptive145Third139Proof155

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third139Proof182 : runCachedNode 511 130465 Adaptive145Third139Node182 = false := by
  decide +kernel

#print axioms adaptive145Third139Proof182

end NineSeparatedSubsetSums
