import NineSeparatedSubsetSums.Adaptive145Third144State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third144Proof761 : runCachedNode 511 131183 Adaptive145Third144Node761 = false := by
  decide +kernel

#print axioms adaptive145Third144Proof761

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third144Proof616 : runCachedNode 511 131183 Adaptive145Third144Node616 = false := by
  decide +kernel

#print axioms adaptive145Third144Proof616

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third144Proof132 : runCachedNode 511 131183 Adaptive145Third144Node132 = false := by
  decide +kernel

#print axioms adaptive145Third144Proof132

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third144Proof131 : runCachedNode 511 131183 Adaptive145Third144Node131 = false := by
  decide +kernel

#print axioms adaptive145Third144Proof131

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third144Proof103 : runCachedNode 511 131183 Adaptive145Third144Node103 = false := by
  decide +kernel

#print axioms adaptive145Third144Proof103

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third144Proof51 : runCachedNode 511 131183 Adaptive145Third144Node51 = false := by
  decide +kernel

#print axioms adaptive145Third144Proof51

end NineSeparatedSubsetSums
