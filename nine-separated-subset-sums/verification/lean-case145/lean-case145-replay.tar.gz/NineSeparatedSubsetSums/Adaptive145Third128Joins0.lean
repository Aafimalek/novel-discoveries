import NineSeparatedSubsetSums.Adaptive145Third128State
import NineSeparatedSubsetSums.Adaptive145Third128Leaves0
import NineSeparatedSubsetSums.Adaptive145Third128Leaves1

namespace NineSeparatedSubsetSums

theorem adaptive145Third128Proof0 : runCachedNode 511 128446 Adaptive145Third128Node0 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 128446 Adaptive145Third128Node0 = [110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 126, 127] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive145Third128Proof1
  · exact adaptive145Third128Proof2
  · exact adaptive145Third128Proof3
  · exact adaptive145Third128Proof4
  · exact adaptive145Third128Proof5
  · exact adaptive145Third128Proof6
  · exact adaptive145Third128Proof7
  · exact adaptive145Third128Proof8
  · exact adaptive145Third128Proof9
  · exact adaptive145Third128Proof10
  · exact adaptive145Third128Proof11
  · exact adaptive145Third128Proof12
  · exact adaptive145Third128Proof13
  · exact adaptive145Third128Proof14
  · exact adaptive145Third128Proof15
  · exact adaptive145Third128Proof16
  · exact adaptive145Third128Proof17

#print axioms adaptive145Third128Proof0

end NineSeparatedSubsetSums
