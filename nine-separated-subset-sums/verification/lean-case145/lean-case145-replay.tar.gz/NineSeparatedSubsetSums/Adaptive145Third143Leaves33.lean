import NineSeparatedSubsetSums.Adaptive145Third143State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof337 : runCachedNode 511 131040 Adaptive145Third143Node337 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof337

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof492 : runCachedNode 511 131040 Adaptive145Third143Node492 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof492

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof14 : runCachedNode 511 131040 Adaptive145Third143Node14 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof14

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof130 : runCachedNode 511 131040 Adaptive145Third143Node130 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof130

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof131 : runCachedNode 511 131040 Adaptive145Third143Node131 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof131

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof8 : runCachedNode 511 131040 Adaptive145Third143Node8 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof8

end NineSeparatedSubsetSums
