import NineSeparatedSubsetSums.Adaptive145Third142State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof432 : runCachedNode 511 130865 Adaptive145Third142Node432 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof432

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof192 : runCachedNode 511 130865 Adaptive145Third142Node192 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof192

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof506 : runCachedNode 511 130865 Adaptive145Third142Node506 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof506

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof79 : runCachedNode 511 130865 Adaptive145Third142Node79 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof79

end NineSeparatedSubsetSums
