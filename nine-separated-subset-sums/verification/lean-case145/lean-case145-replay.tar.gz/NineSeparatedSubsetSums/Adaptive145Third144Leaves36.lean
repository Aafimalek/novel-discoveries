import NineSeparatedSubsetSums.Adaptive145Third144State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third144Proof585 : runCachedNode 511 131183 Adaptive145Third144Node585 = false := by
  decide +kernel

#print axioms adaptive145Third144Proof585

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third144Proof259 : runCachedNode 511 131183 Adaptive145Third144Node259 = false := by
  decide +kernel

#print axioms adaptive145Third144Proof259

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third144Proof329 : runCachedNode 511 131183 Adaptive145Third144Node329 = false := by
  decide +kernel

#print axioms adaptive145Third144Proof329

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third144Proof716 : runCachedNode 511 131183 Adaptive145Third144Node716 = false := by
  decide +kernel

#print axioms adaptive145Third144Proof716

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third144Proof159 : runCachedNode 511 131183 Adaptive145Third144Node159 = false := by
  decide +kernel

#print axioms adaptive145Third144Proof159

end NineSeparatedSubsetSums
