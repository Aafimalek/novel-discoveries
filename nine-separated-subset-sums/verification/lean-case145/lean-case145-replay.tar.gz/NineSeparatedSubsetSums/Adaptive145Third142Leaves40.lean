import NineSeparatedSubsetSums.Adaptive145Third142State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof164 : runCachedNode 511 130865 Adaptive145Third142Node164 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof164

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof257 : runCachedNode 511 130865 Adaptive145Third142Node257 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof257

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof220 : runCachedNode 511 130865 Adaptive145Third142Node220 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof220

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof136 : runCachedNode 511 130865 Adaptive145Third142Node136 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof136

end NineSeparatedSubsetSums
