import NineSeparatedSubsetSums.Adaptive145Third138State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third138Proof43 : runCachedNode 511 130311 Adaptive145Third138Node43 = false := by
  decide +kernel

#print axioms adaptive145Third138Proof43

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third138Proof13 : runCachedNode 511 130311 Adaptive145Third138Node13 = false := by
  decide +kernel

#print axioms adaptive145Third138Proof13

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third138Proof158 : runCachedNode 511 130311 Adaptive145Third138Node158 = false := by
  decide +kernel

#print axioms adaptive145Third138Proof158

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third138Proof127 : runCachedNode 511 130311 Adaptive145Third138Node127 = false := by
  decide +kernel

#print axioms adaptive145Third138Proof127

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third138Proof69 : runCachedNode 511 130311 Adaptive145Third138Node69 = false := by
  decide +kernel

#print axioms adaptive145Third138Proof69

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third138Proof12 : runCachedNode 511 130311 Adaptive145Third138Node12 = false := by
  decide +kernel

#print axioms adaptive145Third138Proof12

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third138Proof123 : runCachedNode 511 130311 Adaptive145Third138Node123 = false := by
  decide +kernel

#print axioms adaptive145Third138Proof123

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third138Proof67 : runCachedNode 511 130311 Adaptive145Third138Node67 = false := by
  decide +kernel

#print axioms adaptive145Third138Proof67

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third138Proof76 : runCachedNode 511 130311 Adaptive145Third138Node76 = false := by
  decide +kernel

#print axioms adaptive145Third138Proof76

end NineSeparatedSubsetSums
