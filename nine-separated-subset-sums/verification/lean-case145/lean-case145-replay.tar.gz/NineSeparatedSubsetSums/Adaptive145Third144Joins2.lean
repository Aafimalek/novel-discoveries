import NineSeparatedSubsetSums.Adaptive145Third144State
import NineSeparatedSubsetSums.Adaptive145Third144Leaves67
import NineSeparatedSubsetSums.Adaptive145Third144Leaves64
import NineSeparatedSubsetSums.Adaptive145Third144Leaves63
import NineSeparatedSubsetSums.Adaptive145Third144Leaves62
import NineSeparatedSubsetSums.Adaptive145Third144Leaves61
import NineSeparatedSubsetSums.Adaptive145Third144Leaves60
import NineSeparatedSubsetSums.Adaptive145Third144Leaves59
import NineSeparatedSubsetSums.Adaptive145Third144Leaves58
import NineSeparatedSubsetSums.Adaptive145Third144Leaves57
import NineSeparatedSubsetSums.Adaptive145Third144Leaves0
import NineSeparatedSubsetSums.Adaptive145Third144Leaves56
import NineSeparatedSubsetSums.Adaptive145Third144Leaves54
import NineSeparatedSubsetSums.Adaptive145Third144Leaves52
import NineSeparatedSubsetSums.Adaptive145Third144Leaves2
import NineSeparatedSubsetSums.Adaptive145Third144Leaves46
import NineSeparatedSubsetSums.Adaptive145Third144Leaves43
import NineSeparatedSubsetSums.Adaptive145Third144Leaves39
import NineSeparatedSubsetSums.Adaptive145Third144Leaves68
import NineSeparatedSubsetSums.Adaptive145Third144Leaves18
import NineSeparatedSubsetSums.Adaptive145Third144Leaves55
import NineSeparatedSubsetSums.Adaptive145Third144Leaves49
import NineSeparatedSubsetSums.Adaptive145Third144Leaves53
import NineSeparatedSubsetSums.Adaptive145Third144Leaves50
import NineSeparatedSubsetSums.Adaptive145Third144Leaves47
import NineSeparatedSubsetSums.Adaptive145Third144Leaves41
import NineSeparatedSubsetSums.Adaptive145Third144Leaves36
import NineSeparatedSubsetSums.Adaptive145Third144Leaves32
import NineSeparatedSubsetSums.Adaptive145Third144Leaves65
import NineSeparatedSubsetSums.Adaptive145Third144Leaves44
import NineSeparatedSubsetSums.Adaptive145Third144Leaves40
import NineSeparatedSubsetSums.Adaptive145Third144Leaves37
import NineSeparatedSubsetSums.Adaptive145Third144Leaves30
import NineSeparatedSubsetSums.Adaptive145Third144Leaves27
import NineSeparatedSubsetSums.Adaptive145Third144Leaves45
import NineSeparatedSubsetSums.Adaptive145Third144Leaves42
import NineSeparatedSubsetSums.Adaptive145Third144Leaves25
import NineSeparatedSubsetSums.Adaptive145Third144Leaves9
import NineSeparatedSubsetSums.Adaptive145Third144Leaves11
import NineSeparatedSubsetSums.Adaptive145Third144Leaves24
import NineSeparatedSubsetSums.Adaptive145Third144Leaves23
import NineSeparatedSubsetSums.Adaptive145Third144Leaves21
import NineSeparatedSubsetSums.Adaptive145Third144Leaves14
import NineSeparatedSubsetSums.Adaptive145Third144Leaves17
import NineSeparatedSubsetSums.Adaptive145Third144Leaves4
import NineSeparatedSubsetSums.Adaptive145Third144Leaves7
import NineSeparatedSubsetSums.Adaptive145Third144Leaves6
import NineSeparatedSubsetSums.Adaptive145Third144Leaves34
import NineSeparatedSubsetSums.Adaptive145Third144Leaves28
import NineSeparatedSubsetSums.Adaptive145Third144Leaves22
import NineSeparatedSubsetSums.Adaptive145Third144Leaves1
import NineSeparatedSubsetSums.Adaptive145Third144Joins0
import NineSeparatedSubsetSums.Adaptive145Third144Joins1

namespace NineSeparatedSubsetSums

theorem adaptive145Third144Proof628 : runCachedNode 511 131183 Adaptive145Third144Node628 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 131183 Adaptive145Third144Node628 = [87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive145Third144Proof629
  · exact adaptive145Third144Proof630
  · exact adaptive145Third144Proof631
  · exact adaptive145Third144Proof632
  · exact adaptive145Third144Proof633
  · exact adaptive145Third144Proof634
  · exact adaptive145Third144Proof635
  · exact adaptive145Third144Proof636
  · exact adaptive145Third144Proof637
  · exact adaptive145Third144Proof638
  · exact adaptive145Third144Proof639
  · exact adaptive145Third144Proof640
  · exact adaptive145Third144Proof641
  · exact adaptive145Third144Proof642
  · exact adaptive145Third144Proof643
  · exact adaptive145Third144Proof644
  · exact adaptive145Third144Proof645
  · exact adaptive145Third144Proof646
  · exact adaptive145Third144Proof647
  · exact adaptive145Third144Proof648
  · exact adaptive145Third144Proof649
  · exact adaptive145Third144Proof650
  · exact adaptive145Third144Proof651
  · exact adaptive145Third144Proof652
  · exact adaptive145Third144Proof653
  · exact adaptive145Third144Proof654
  · exact adaptive145Third144Proof655
  · exact adaptive145Third144Proof656
  · exact adaptive145Third144Proof657
  · exact adaptive145Third144Proof658
  · exact adaptive145Third144Proof659
  · exact adaptive145Third144Proof660
  · exact adaptive145Third144Proof661
  · exact adaptive145Third144Proof662
  · exact adaptive145Third144Proof663
  · exact adaptive145Third144Proof664
  · exact adaptive145Third144Proof665
  · exact adaptive145Third144Proof666
  · exact adaptive145Third144Proof667
  · exact adaptive145Third144Proof668
  · exact adaptive145Third144Proof669
  · exact adaptive145Third144Proof670
  · exact adaptive145Third144Proof671

#print axioms adaptive145Third144Proof628

theorem adaptive145Third144Proof672 : runCachedNode 511 131183 Adaptive145Third144Node672 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 131183 Adaptive145Third144Node672 = [86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive145Third144Proof673
  · exact adaptive145Third144Proof674
  · exact adaptive145Third144Proof675
  · exact adaptive145Third144Proof676
  · exact adaptive145Third144Proof677
  · exact adaptive145Third144Proof678
  · exact adaptive145Third144Proof679
  · exact adaptive145Third144Proof680
  · exact adaptive145Third144Proof681
  · exact adaptive145Third144Proof682
  · exact adaptive145Third144Proof683
  · exact adaptive145Third144Proof684
  · exact adaptive145Third144Proof685
  · exact adaptive145Third144Proof686
  · exact adaptive145Third144Proof687
  · exact adaptive145Third144Proof688
  · exact adaptive145Third144Proof689
  · exact adaptive145Third144Proof690
  · exact adaptive145Third144Proof691
  · exact adaptive145Third144Proof692
  · exact adaptive145Third144Proof693
  · exact adaptive145Third144Proof694
  · exact adaptive145Third144Proof695
  · exact adaptive145Third144Proof696
  · exact adaptive145Third144Proof697
  · exact adaptive145Third144Proof698
  · exact adaptive145Third144Proof699
  · exact adaptive145Third144Proof700
  · exact adaptive145Third144Proof701
  · exact adaptive145Third144Proof702
  · exact adaptive145Third144Proof703
  · exact adaptive145Third144Proof704
  · exact adaptive145Third144Proof705
  · exact adaptive145Third144Proof706
  · exact adaptive145Third144Proof707
  · exact adaptive145Third144Proof708
  · exact adaptive145Third144Proof709
  · exact adaptive145Third144Proof710
  · exact adaptive145Third144Proof711
  · exact adaptive145Third144Proof712
  · exact adaptive145Third144Proof713
  · exact adaptive145Third144Proof714
  · exact adaptive145Third144Proof715
  · exact adaptive145Third144Proof716
  · exact adaptive145Third144Proof717

#print axioms adaptive145Third144Proof672

theorem adaptive145Third144Proof718 : runCachedNode 511 131183 Adaptive145Third144Node718 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 131183 Adaptive145Third144Node718 = [86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive145Third144Proof719
  · exact adaptive145Third144Proof720
  · exact adaptive145Third144Proof721
  · exact adaptive145Third144Proof722
  · exact adaptive145Third144Proof723
  · exact adaptive145Third144Proof724
  · exact adaptive145Third144Proof725
  · exact adaptive145Third144Proof726
  · exact adaptive145Third144Proof727
  · exact adaptive145Third144Proof728
  · exact adaptive145Third144Proof729
  · exact adaptive145Third144Proof730
  · exact adaptive145Third144Proof731
  · exact adaptive145Third144Proof732
  · exact adaptive145Third144Proof733
  · exact adaptive145Third144Proof734
  · exact adaptive145Third144Proof735
  · exact adaptive145Third144Proof736
  · exact adaptive145Third144Proof737
  · exact adaptive145Third144Proof738
  · exact adaptive145Third144Proof739
  · exact adaptive145Third144Proof740
  · exact adaptive145Third144Proof741
  · exact adaptive145Third144Proof742
  · exact adaptive145Third144Proof743
  · exact adaptive145Third144Proof744
  · exact adaptive145Third144Proof745
  · exact adaptive145Third144Proof746
  · exact adaptive145Third144Proof747
  · exact adaptive145Third144Proof748
  · exact adaptive145Third144Proof749
  · exact adaptive145Third144Proof750
  · exact adaptive145Third144Proof751
  · exact adaptive145Third144Proof752
  · exact adaptive145Third144Proof753
  · exact adaptive145Third144Proof754
  · exact adaptive145Third144Proof755
  · exact adaptive145Third144Proof756
  · exact adaptive145Third144Proof757
  · exact adaptive145Third144Proof758
  · exact adaptive145Third144Proof759
  · exact adaptive145Third144Proof760
  · exact adaptive145Third144Proof761
  · exact adaptive145Third144Proof762
  · exact adaptive145Third144Proof763
  · exact adaptive145Third144Proof764

#print axioms adaptive145Third144Proof718

theorem adaptive145Third144Proof591 : runCachedNode 511 131183 Adaptive145Third144Node591 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 131183 Adaptive145Third144Node591 = [100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 132, 133, 134, 135, 136, 137, 138] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive145Third144Proof592
  · exact adaptive145Third144Proof593
  · exact adaptive145Third144Proof594
  · exact adaptive145Third144Proof595
  · exact adaptive145Third144Proof596
  · exact adaptive145Third144Proof597
  · exact adaptive145Third144Proof598
  · exact adaptive145Third144Proof599
  · exact adaptive145Third144Proof600
  · exact adaptive145Third144Proof601
  · exact adaptive145Third144Proof602
  · exact adaptive145Third144Proof603
  · exact adaptive145Third144Proof604
  · exact adaptive145Third144Proof605
  · exact adaptive145Third144Proof606
  · exact adaptive145Third144Proof607
  · exact adaptive145Third144Proof608
  · exact adaptive145Third144Proof609
  · exact adaptive145Third144Proof610
  · exact adaptive145Third144Proof611
  · exact adaptive145Third144Proof612
  · exact adaptive145Third144Proof613
  · exact adaptive145Third144Proof614
  · exact adaptive145Third144Proof615
  · exact adaptive145Third144Proof616
  · exact adaptive145Third144Proof617
  · exact adaptive145Third144Proof618
  · exact adaptive145Third144Proof619
  · exact adaptive145Third144Proof620
  · exact adaptive145Third144Proof621
  · exact adaptive145Third144Proof622
  · exact adaptive145Third144Proof623
  · exact adaptive145Third144Proof624
  · exact adaptive145Third144Proof625
  · exact adaptive145Third144Proof626
  · exact adaptive145Third144Proof627
  · exact adaptive145Third144Proof628
  · exact adaptive145Third144Proof672
  · exact adaptive145Third144Proof718

#print axioms adaptive145Third144Proof591

theorem adaptive145Third144Proof0 : runCachedNode 511 131183 Adaptive145Third144Node0 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 131183 Adaptive145Third144Node0 = [109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 132, 133, 134, 135, 136, 137, 138, 139, 140, 142, 143] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive145Third144Proof1
  · exact adaptive145Third144Proof2
  · exact adaptive145Third144Proof3
  · exact adaptive145Third144Proof4
  · exact adaptive145Third144Proof5
  · exact adaptive145Third144Proof6
  · exact adaptive145Third144Proof7
  · exact adaptive145Third144Proof8
  · exact adaptive145Third144Proof9
  · exact adaptive145Third144Proof10
  · exact adaptive145Third144Proof11
  · exact adaptive145Third144Proof12
  · exact adaptive145Third144Proof13
  · exact adaptive145Third144Proof14
  · exact adaptive145Third144Proof15
  · exact adaptive145Third144Proof16
  · exact adaptive145Third144Proof17
  · exact adaptive145Third144Proof18
  · exact adaptive145Third144Proof19
  · exact adaptive145Third144Proof20
  · exact adaptive145Third144Proof21
  · exact adaptive145Third144Proof22
  · exact adaptive145Third144Proof23
  · exact adaptive145Third144Proof49
  · exact adaptive145Third144Proof76
  · exact adaptive145Third144Proof105
  · exact adaptive145Third144Proof135
  · exact adaptive145Third144Proof166
  · exact adaptive145Third144Proof198
  · exact adaptive145Third144Proof232
  · exact adaptive145Third144Proof267
  · exact adaptive145Third144Proof303
  · exact adaptive145Third144Proof460
  · exact adaptive145Third144Proof591

#print axioms adaptive145Third144Proof0

end NineSeparatedSubsetSums
