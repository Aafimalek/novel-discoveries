import NineSeparatedSubsetSums.Adaptive145Third142State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof540 : runCachedNode 511 130865 Adaptive145Third142Node540 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof540

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof225 : runCachedNode 511 130865 Adaptive145Third142Node225 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof225

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof20 : runCachedNode 511 130865 Adaptive145Third142Node20 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof20

end NineSeparatedSubsetSums
