import NineSeparatedSubsetSums.Adaptive145Third143State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof265 : runCachedNode 511 131040 Adaptive145Third143Node265 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof265

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof195 : runCachedNode 511 131040 Adaptive145Third143Node195 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof195

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof82 : runCachedNode 511 131040 Adaptive145Third143Node82 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof82

end NineSeparatedSubsetSums
