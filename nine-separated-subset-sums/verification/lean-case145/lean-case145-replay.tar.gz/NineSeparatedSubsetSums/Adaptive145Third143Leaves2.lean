import NineSeparatedSubsetSums.Adaptive145Third143State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof263 : runCachedNode 511 131040 Adaptive145Third143Node263 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof263

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof97 : runCachedNode 511 131040 Adaptive145Third143Node97 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof97

end NineSeparatedSubsetSums
