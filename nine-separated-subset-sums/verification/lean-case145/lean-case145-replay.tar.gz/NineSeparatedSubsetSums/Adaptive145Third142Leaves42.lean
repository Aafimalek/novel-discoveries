import NineSeparatedSubsetSums.Adaptive145Third142State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof948 : runCachedNode 511 130865 Adaptive145Third142Node948 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof948

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof781 : runCachedNode 511 130865 Adaptive145Third142Node781 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof781

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof138 : runCachedNode 511 130865 Adaptive145Third142Node138 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof138

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof814 : runCachedNode 511 130865 Adaptive145Third142Node814 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof814

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof31 : runCachedNode 511 130865 Adaptive145Third142Node31 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof31

end NineSeparatedSubsetSums
