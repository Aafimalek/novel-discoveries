import NineSeparatedSubsetSums.Adaptive145Third143State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof591 : runCachedNode 511 131040 Adaptive145Third143Node591 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof591

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof159 : runCachedNode 511 131040 Adaptive145Third143Node159 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof159

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof411 : runCachedNode 511 131040 Adaptive145Third143Node411 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof411

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof75 : runCachedNode 511 131040 Adaptive145Third143Node75 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof75

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof461 : runCachedNode 511 131040 Adaptive145Third143Node461 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof461

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof281 : runCachedNode 511 131040 Adaptive145Third143Node281 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof281

end NineSeparatedSubsetSums
