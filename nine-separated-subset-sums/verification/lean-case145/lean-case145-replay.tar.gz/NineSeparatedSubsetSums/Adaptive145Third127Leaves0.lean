import NineSeparatedSubsetSums.Adaptive145Third127State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third127Proof16 : runCachedNode 511 128205 Adaptive145Third127Node16 = false := by
  decide +kernel

#print axioms adaptive145Third127Proof16

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third127Proof15 : runCachedNode 511 128205 Adaptive145Third127Node15 = false := by
  decide +kernel

#print axioms adaptive145Third127Proof15

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third127Proof14 : runCachedNode 511 128205 Adaptive145Third127Node14 = false := by
  decide +kernel

#print axioms adaptive145Third127Proof14

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third127Proof12 : runCachedNode 511 128205 Adaptive145Third127Node12 = false := by
  decide +kernel

#print axioms adaptive145Third127Proof12

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third127Proof13 : runCachedNode 511 128205 Adaptive145Third127Node13 = false := by
  decide +kernel

#print axioms adaptive145Third127Proof13

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third127Proof11 : runCachedNode 511 128205 Adaptive145Third127Node11 = false := by
  decide +kernel

#print axioms adaptive145Third127Proof11

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third127Proof3 : runCachedNode 511 128205 Adaptive145Third127Node3 = false := by
  decide +kernel

#print axioms adaptive145Third127Proof3

end NineSeparatedSubsetSums
