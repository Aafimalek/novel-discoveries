import NineSeparatedSubsetSums.Adaptive145Third137State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third137Proof16 : runCachedNode 511 130164 Adaptive145Third137Node16 = false := by
  decide +kernel

#print axioms adaptive145Third137Proof16

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third137Proof180 : runCachedNode 511 130164 Adaptive145Third137Node180 = false := by
  decide +kernel

#print axioms adaptive145Third137Proof180

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third137Proof148 : runCachedNode 511 130164 Adaptive145Third137Node148 = false := by
  decide +kernel

#print axioms adaptive145Third137Proof148

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third137Proof13 : runCachedNode 511 130164 Adaptive145Third137Node13 = false := by
  decide +kernel

#print axioms adaptive145Third137Proof13

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third137Proof56 : runCachedNode 511 130164 Adaptive145Third137Node56 = false := by
  decide +kernel

#print axioms adaptive145Third137Proof56

end NineSeparatedSubsetSums
