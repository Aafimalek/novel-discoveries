import NineSeparatedSubsetSums.Adaptive145Third143State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof20 : runCachedNode 511 131040 Adaptive145Third143Node20 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof20

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof499 : runCachedNode 511 131040 Adaptive145Third143Node499 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof499

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof116 : runCachedNode 511 131040 Adaptive145Third143Node116 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof116

end NineSeparatedSubsetSums
