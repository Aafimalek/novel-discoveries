import NineSeparatedSubsetSums.Adaptive145Third139State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third139Proof100 : runCachedNode 511 130465 Adaptive145Third139Node100 = false := by
  decide +kernel

#print axioms adaptive145Third139Proof100

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third139Proof18 : runCachedNode 511 130465 Adaptive145Third139Node18 = false := by
  decide +kernel

#print axioms adaptive145Third139Proof18

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third139Proof217 : runCachedNode 511 130465 Adaptive145Third139Node217 = false := by
  decide +kernel

#print axioms adaptive145Third139Proof217

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third139Proof22 : runCachedNode 511 130465 Adaptive145Third139Node22 = false := by
  decide +kernel

#print axioms adaptive145Third139Proof22

end NineSeparatedSubsetSums
