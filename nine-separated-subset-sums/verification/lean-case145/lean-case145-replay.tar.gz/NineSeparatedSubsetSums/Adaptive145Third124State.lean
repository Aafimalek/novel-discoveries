import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive145Third124Node0 : CachedSearchNode :=
  ⟨4, 123, computeCenteredMask [148,145,124], 417, 58305⟩

end NineSeparatedSubsetSums
