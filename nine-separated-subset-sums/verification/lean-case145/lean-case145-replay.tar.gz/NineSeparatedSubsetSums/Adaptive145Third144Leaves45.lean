import NineSeparatedSubsetSums.Adaptive145Third144State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third144Proof128 : runCachedNode 511 131183 Adaptive145Third144Node128 = false := by
  decide +kernel

#print axioms adaptive145Third144Proof128

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third144Proof582 : runCachedNode 511 131183 Adaptive145Third144Node582 = false := by
  decide +kernel

#print axioms adaptive145Third144Proof582

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third144Proof191 : runCachedNode 511 131183 Adaptive145Third144Node191 = false := by
  decide +kernel

#print axioms adaptive145Third144Proof191

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third144Proof102 : runCachedNode 511 131183 Adaptive145Third144Node102 = false := by
  decide +kernel

#print axioms adaptive145Third144Proof102

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third144Proof539 : runCachedNode 511 131183 Adaptive145Third144Node539 = false := by
  decide +kernel

#print axioms adaptive145Third144Proof539

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third144Proof12 : runCachedNode 511 131183 Adaptive145Third144Node12 = false := by
  decide +kernel

#print axioms adaptive145Third144Proof12

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third144Proof483 : runCachedNode 511 131183 Adaptive145Third144Node483 = false := by
  decide +kernel

#print axioms adaptive145Third144Proof483

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third144Proof610 : runCachedNode 511 131183 Adaptive145Third144Node610 = false := by
  decide +kernel

#print axioms adaptive145Third144Proof610

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third144Proof579 : runCachedNode 511 131183 Adaptive145Third144Node579 = false := by
  decide +kernel

#print axioms adaptive145Third144Proof579

end NineSeparatedSubsetSums
