import NineSeparatedSubsetSums.Adaptive145Third134State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third134Proof22 : runCachedNode 511 129715 Adaptive145Third134Node22 = false := by
  decide +kernel

#print axioms adaptive145Third134Proof22

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third134Proof40 : runCachedNode 511 129715 Adaptive145Third134Node40 = false := by
  decide +kernel

#print axioms adaptive145Third134Proof40

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third134Proof31 : runCachedNode 511 129715 Adaptive145Third134Node31 = false := by
  decide +kernel

#print axioms adaptive145Third134Proof31

end NineSeparatedSubsetSums
