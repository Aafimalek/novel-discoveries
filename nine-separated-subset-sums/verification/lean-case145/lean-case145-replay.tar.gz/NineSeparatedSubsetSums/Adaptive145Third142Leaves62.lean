import NineSeparatedSubsetSums.Adaptive145Third142State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof578 : runCachedNode 511 130865 Adaptive145Third142Node578 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof578

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof641 : runCachedNode 511 130865 Adaptive145Third142Node641 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof641

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof80 : runCachedNode 511 130865 Adaptive145Third142Node80 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof80

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof388 : runCachedNode 511 130865 Adaptive145Third142Node388 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof388

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof129 : runCachedNode 511 130865 Adaptive145Third142Node129 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof129

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof943 : runCachedNode 511 130865 Adaptive145Third142Node943 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof943

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof36 : runCachedNode 511 130865 Adaptive145Third142Node36 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof36

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof350 : runCachedNode 511 130865 Adaptive145Third142Node350 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof350

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof777 : runCachedNode 511 130865 Adaptive145Third142Node777 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof777

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof502 : runCachedNode 511 130865 Adaptive145Third142Node502 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof502

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof106 : runCachedNode 511 130865 Adaptive145Third142Node106 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof106

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof9 : runCachedNode 511 130865 Adaptive145Third142Node9 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof9

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof526 : runCachedNode 511 130865 Adaptive145Third142Node526 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof526

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof182 : runCachedNode 511 130865 Adaptive145Third142Node182 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof182

end NineSeparatedSubsetSums
