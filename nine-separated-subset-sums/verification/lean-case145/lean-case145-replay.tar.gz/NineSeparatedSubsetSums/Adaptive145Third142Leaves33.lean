import NineSeparatedSubsetSums.Adaptive145Third142State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof812 : runCachedNode 511 130865 Adaptive145Third142Node812 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof812

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof904 : runCachedNode 511 130865 Adaptive145Third142Node904 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof904

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof534 : runCachedNode 511 130865 Adaptive145Third142Node534 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof534

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof175 : runCachedNode 511 130865 Adaptive145Third142Node175 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof175

end NineSeparatedSubsetSums
