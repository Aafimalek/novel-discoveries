import NineSeparatedSubsetSums.Adaptive145Third141State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third141Proof20 : runCachedNode 511 130740 Adaptive145Third141Node20 = false := by
  decide +kernel

#print axioms adaptive145Third141Proof20

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third141Proof375 : runCachedNode 511 130740 Adaptive145Third141Node375 = false := by
  decide +kernel

#print axioms adaptive145Third141Proof375

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third141Proof2 : runCachedNode 511 130740 Adaptive145Third141Node2 = false := by
  decide +kernel

#print axioms adaptive145Third141Proof2

end NineSeparatedSubsetSums
