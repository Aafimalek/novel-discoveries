import NineSeparatedSubsetSums.Adaptive145Third140State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third140Proof162 : runCachedNode 511 130597 Adaptive145Third140Node162 = false := by
  decide +kernel

#print axioms adaptive145Third140Proof162

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third140Proof157 : runCachedNode 511 130597 Adaptive145Third140Node157 = false := by
  decide +kernel

#print axioms adaptive145Third140Proof157

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third140Proof33 : runCachedNode 511 130597 Adaptive145Third140Node33 = false := by
  decide +kernel

#print axioms adaptive145Third140Proof33

end NineSeparatedSubsetSums
