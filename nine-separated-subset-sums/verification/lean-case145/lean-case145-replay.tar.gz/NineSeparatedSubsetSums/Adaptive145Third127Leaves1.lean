import NineSeparatedSubsetSums.Adaptive145Third127State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third127Proof10 : runCachedNode 511 128205 Adaptive145Third127Node10 = false := by
  decide +kernel

#print axioms adaptive145Third127Proof10

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third127Proof9 : runCachedNode 511 128205 Adaptive145Third127Node9 = false := by
  decide +kernel

#print axioms adaptive145Third127Proof9

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third127Proof8 : runCachedNode 511 128205 Adaptive145Third127Node8 = false := by
  decide +kernel

#print axioms adaptive145Third127Proof8

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third127Proof7 : runCachedNode 511 128205 Adaptive145Third127Node7 = false := by
  decide +kernel

#print axioms adaptive145Third127Proof7

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third127Proof6 : runCachedNode 511 128205 Adaptive145Third127Node6 = false := by
  decide +kernel

#print axioms adaptive145Third127Proof6

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third127Proof5 : runCachedNode 511 128205 Adaptive145Third127Node5 = false := by
  decide +kernel

#print axioms adaptive145Third127Proof5

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third127Proof4 : runCachedNode 511 128205 Adaptive145Third127Node4 = false := by
  decide +kernel

#print axioms adaptive145Third127Proof4

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third127Proof2 : runCachedNode 511 128205 Adaptive145Third127Node2 = false := by
  decide +kernel

#print axioms adaptive145Third127Proof2

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third127Proof1 : runCachedNode 511 128205 Adaptive145Third127Node1 = false := by
  decide +kernel

#print axioms adaptive145Third127Proof1

end NineSeparatedSubsetSums
