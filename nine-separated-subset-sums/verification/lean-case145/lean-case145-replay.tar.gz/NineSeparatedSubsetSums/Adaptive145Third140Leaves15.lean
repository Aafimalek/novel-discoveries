import NineSeparatedSubsetSums.Adaptive145Third140State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third140Proof129 : runCachedNode 511 130597 Adaptive145Third140Node129 = false := by
  decide +kernel

#print axioms adaptive145Third140Proof129

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third140Proof159 : runCachedNode 511 130597 Adaptive145Third140Node159 = false := by
  decide +kernel

#print axioms adaptive145Third140Proof159

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third140Proof130 : runCachedNode 511 130597 Adaptive145Third140Node130 = false := by
  decide +kernel

#print axioms adaptive145Third140Proof130

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third140Proof260 : runCachedNode 511 130597 Adaptive145Third140Node260 = false := by
  decide +kernel

#print axioms adaptive145Third140Proof260

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third140Proof231 : runCachedNode 511 130597 Adaptive145Third140Node231 = false := by
  decide +kernel

#print axioms adaptive145Third140Proof231

end NineSeparatedSubsetSums
