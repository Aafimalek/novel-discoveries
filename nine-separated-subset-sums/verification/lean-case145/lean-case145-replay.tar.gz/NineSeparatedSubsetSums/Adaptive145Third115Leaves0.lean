import NineSeparatedSubsetSums.Adaptive145Third115State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third115Proof14 : runCachedNode 511 112442 Adaptive145Third115Node14 = false := by
  decide +kernel

#print axioms adaptive145Third115Proof14

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third115Proof13 : runCachedNode 511 112442 Adaptive145Third115Node13 = false := by
  decide +kernel

#print axioms adaptive145Third115Proof13

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third115Proof12 : runCachedNode 511 112442 Adaptive145Third115Node12 = false := by
  decide +kernel

#print axioms adaptive145Third115Proof12

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third115Proof10 : runCachedNode 511 112442 Adaptive145Third115Node10 = false := by
  decide +kernel

#print axioms adaptive145Third115Proof10

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third115Proof11 : runCachedNode 511 112442 Adaptive145Third115Node11 = false := by
  decide +kernel

#print axioms adaptive145Third115Proof11

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third115Proof7 : runCachedNode 511 112442 Adaptive145Third115Node7 = false := by
  decide +kernel

#print axioms adaptive145Third115Proof7

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third115Proof3 : runCachedNode 511 112442 Adaptive145Third115Node3 = false := by
  decide +kernel

#print axioms adaptive145Third115Proof3

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third115Proof2 : runCachedNode 511 112442 Adaptive145Third115Node2 = false := by
  decide +kernel

#print axioms adaptive145Third115Proof2

end NineSeparatedSubsetSums
