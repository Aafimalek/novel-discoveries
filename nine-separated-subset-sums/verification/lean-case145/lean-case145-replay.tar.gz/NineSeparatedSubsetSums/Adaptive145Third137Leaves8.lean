import NineSeparatedSubsetSums.Adaptive145Third137State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third137Proof65 : runCachedNode 511 130164 Adaptive145Third137Node65 = false := by
  decide +kernel

#print axioms adaptive145Third137Proof65

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third137Proof90 : runCachedNode 511 130164 Adaptive145Third137Node90 = false := by
  decide +kernel

#print axioms adaptive145Third137Proof90

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third137Proof42 : runCachedNode 511 130164 Adaptive145Third137Node42 = false := by
  decide +kernel

#print axioms adaptive145Third137Proof42

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third137Proof117 : runCachedNode 511 130164 Adaptive145Third137Node117 = false := by
  decide +kernel

#print axioms adaptive145Third137Proof117

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third137Proof93 : runCachedNode 511 130164 Adaptive145Third137Node93 = false := by
  decide +kernel

#print axioms adaptive145Third137Proof93

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third137Proof63 : runCachedNode 511 130164 Adaptive145Third137Node63 = false := by
  decide +kernel

#print axioms adaptive145Third137Proof63

end NineSeparatedSubsetSums
