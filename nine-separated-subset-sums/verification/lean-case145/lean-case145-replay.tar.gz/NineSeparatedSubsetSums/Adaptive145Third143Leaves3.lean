import NineSeparatedSubsetSums.Adaptive145Third143State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof22 : runCachedNode 511 131040 Adaptive145Third143Node22 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof22

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof156 : runCachedNode 511 131040 Adaptive145Third143Node156 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof156

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof1 : runCachedNode 511 131040 Adaptive145Third143Node1 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof1

end NineSeparatedSubsetSums
