import NineSeparatedSubsetSums.Adaptive145Third139State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third139Proof127 : runCachedNode 511 130465 Adaptive145Third139Node127 = false := by
  decide +kernel

#print axioms adaptive145Third139Proof127

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third139Proof17 : runCachedNode 511 130465 Adaptive145Third139Node17 = false := by
  decide +kernel

#print axioms adaptive145Third139Proof17

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third139Proof98 : runCachedNode 511 130465 Adaptive145Third139Node98 = false := by
  decide +kernel

#print axioms adaptive145Third139Proof98

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third139Proof186 : runCachedNode 511 130465 Adaptive145Third139Node186 = false := by
  decide +kernel

#print axioms adaptive145Third139Proof186

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third139Proof1 : runCachedNode 511 130465 Adaptive145Third139Node1 = false := by
  decide +kernel

#print axioms adaptive145Third139Proof1

end NineSeparatedSubsetSums
