import NineSeparatedSubsetSums.Adaptive145Third132State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third132Proof21 : runCachedNode 511 129338 Adaptive145Third132Node21 = false := by
  decide +kernel

#print axioms adaptive145Third132Proof21

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third132Proof12 : runCachedNode 511 129338 Adaptive145Third132Node12 = false := by
  decide +kernel

#print axioms adaptive145Third132Proof12

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third132Proof5 : runCachedNode 511 129338 Adaptive145Third132Node5 = false := by
  decide +kernel

#print axioms adaptive145Third132Proof5

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third132Proof4 : runCachedNode 511 129338 Adaptive145Third132Node4 = false := by
  decide +kernel

#print axioms adaptive145Third132Proof4

end NineSeparatedSubsetSums
