import NineSeparatedSubsetSums.Adaptive145Third133State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third133Proof20 : runCachedNode 511 129495 Adaptive145Third133Node20 = false := by
  decide +kernel

#print axioms adaptive145Third133Proof20

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third133Proof46 : runCachedNode 511 129495 Adaptive145Third133Node46 = false := by
  decide +kernel

#print axioms adaptive145Third133Proof46

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third133Proof35 : runCachedNode 511 129495 Adaptive145Third133Node35 = false := by
  decide +kernel

#print axioms adaptive145Third133Proof35

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third133Proof3 : runCachedNode 511 129495 Adaptive145Third133Node3 = false := by
  decide +kernel

#print axioms adaptive145Third133Proof3

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third133Proof23 : runCachedNode 511 129495 Adaptive145Third133Node23 = false := by
  decide +kernel

#print axioms adaptive145Third133Proof23

end NineSeparatedSubsetSums
