import NineSeparatedSubsetSums.Adaptive145Third141State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third141Proof376 : runCachedNode 511 130740 Adaptive145Third141Node376 = false := by
  decide +kernel

#print axioms adaptive145Third141Proof376

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third141Proof223 : runCachedNode 511 130740 Adaptive145Third141Node223 = false := by
  decide +kernel

#print axioms adaptive145Third141Proof223

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third141Proof1 : runCachedNode 511 130740 Adaptive145Third141Node1 = false := by
  decide +kernel

#print axioms adaptive145Third141Proof1

end NineSeparatedSubsetSums
