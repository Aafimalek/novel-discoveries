import NineSeparatedSubsetSums.Adaptive145Third144State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third144Proof588 : runCachedNode 511 131183 Adaptive145Third144Node588 = false := by
  decide +kernel

#print axioms adaptive145Third144Proof588

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third144Proof624 : runCachedNode 511 131183 Adaptive145Third144Node624 = false := by
  decide +kernel

#print axioms adaptive145Third144Proof624

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third144Proof617 : runCachedNode 511 131183 Adaptive145Third144Node617 = false := by
  decide +kernel

#print axioms adaptive145Third144Proof617

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third144Proof25 : runCachedNode 511 131183 Adaptive145Third144Node25 = false := by
  decide +kernel

#print axioms adaptive145Third144Proof25

end NineSeparatedSubsetSums
