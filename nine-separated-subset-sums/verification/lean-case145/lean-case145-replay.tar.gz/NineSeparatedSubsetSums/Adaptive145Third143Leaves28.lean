import NineSeparatedSubsetSums.Adaptive145Third143State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof412 : runCachedNode 511 131040 Adaptive145Third143Node412 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof412

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof164 : runCachedNode 511 131040 Adaptive145Third143Node164 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof164

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof196 : runCachedNode 511 131040 Adaptive145Third143Node196 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof196

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof259 : runCachedNode 511 131040 Adaptive145Third143Node259 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof259

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof140 : runCachedNode 511 131040 Adaptive145Third143Node140 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof140

end NineSeparatedSubsetSums
