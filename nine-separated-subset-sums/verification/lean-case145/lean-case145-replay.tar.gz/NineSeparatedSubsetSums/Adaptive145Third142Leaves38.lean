import NineSeparatedSubsetSums.Adaptive145Third142State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof224 : runCachedNode 511 130865 Adaptive145Third142Node224 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof224

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof255 : runCachedNode 511 130865 Adaptive145Third142Node255 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof255

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof581 : runCachedNode 511 130865 Adaptive145Third142Node581 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof581

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof806 : runCachedNode 511 130865 Adaptive145Third142Node806 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof806

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof360 : runCachedNode 511 130865 Adaptive145Third142Node360 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof360

end NineSeparatedSubsetSums
