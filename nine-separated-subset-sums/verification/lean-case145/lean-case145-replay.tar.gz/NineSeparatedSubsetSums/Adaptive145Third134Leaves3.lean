import NineSeparatedSubsetSums.Adaptive145Third134State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third134Proof20 : runCachedNode 511 129715 Adaptive145Third134Node20 = false := by
  decide +kernel

#print axioms adaptive145Third134Proof20

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third134Proof18 : runCachedNode 511 129715 Adaptive145Third134Node18 = false := by
  decide +kernel

#print axioms adaptive145Third134Proof18

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third134Proof6 : runCachedNode 511 129715 Adaptive145Third134Node6 = false := by
  decide +kernel

#print axioms adaptive145Third134Proof6

end NineSeparatedSubsetSums
