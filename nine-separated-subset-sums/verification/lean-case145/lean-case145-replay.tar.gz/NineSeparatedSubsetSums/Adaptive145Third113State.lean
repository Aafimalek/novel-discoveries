import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive145Third113Node0 : CachedSearchNode :=
  ⟨4, 112, computeCenteredMask [148,145,113], 406, 55698⟩

end NineSeparatedSubsetSums
