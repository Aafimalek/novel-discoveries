import NineSeparatedSubsetSums.Adaptive145Third144State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third144Proof492 : runCachedNode 511 131183 Adaptive145Third144Node492 = false := by
  decide +kernel

#print axioms adaptive145Third144Proof492

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third144Proof763 : runCachedNode 511 131183 Adaptive145Third144Node763 = false := by
  decide +kernel

#print axioms adaptive145Third144Proof763

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third144Proof16 : runCachedNode 511 131183 Adaptive145Third144Node16 = false := by
  decide +kernel

#print axioms adaptive145Third144Proof16

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third144Proof157 : runCachedNode 511 131183 Adaptive145Third144Node157 = false := by
  decide +kernel

#print axioms adaptive145Third144Proof157

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third144Proof199 : runCachedNode 511 131183 Adaptive145Third144Node199 = false := by
  decide +kernel

#print axioms adaptive145Third144Proof199

end NineSeparatedSubsetSums
