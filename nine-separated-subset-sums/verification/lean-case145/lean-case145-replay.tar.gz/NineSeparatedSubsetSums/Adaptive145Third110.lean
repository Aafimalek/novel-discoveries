import NineSeparatedSubsetSums.Adaptive145Third110Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint145Checked

namespace NineSeparatedSubsetSums


theorem adaptive145Third110 : NoDescendingTailAfterThird 145 110 :=
  noDescendingThirdTail_of_cached 145 110 112442 (fun t ht nd => max148_second145_fourPoint_moment_bound (110::t) (by simp [ht]) nd) adaptive145Third110Proof0

#print axioms adaptive145Third110

end NineSeparatedSubsetSums
