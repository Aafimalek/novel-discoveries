import NineSeparatedSubsetSums.Adaptive145Third138State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third138Proof45 : runCachedNode 511 130311 Adaptive145Third138Node45 = false := by
  decide +kernel

#print axioms adaptive145Third138Proof45

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third138Proof14 : runCachedNode 511 130311 Adaptive145Third138Node14 = false := by
  decide +kernel

#print axioms adaptive145Third138Proof14

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third138Proof156 : runCachedNode 511 130311 Adaptive145Third138Node156 = false := by
  decide +kernel

#print axioms adaptive145Third138Proof156

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third138Proof42 : runCachedNode 511 130311 Adaptive145Third138Node42 = false := by
  decide +kernel

#print axioms adaptive145Third138Proof42

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third138Proof70 : runCachedNode 511 130311 Adaptive145Third138Node70 = false := by
  decide +kernel

#print axioms adaptive145Third138Proof70

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third138Proof187 : runCachedNode 511 130311 Adaptive145Third138Node187 = false := by
  decide +kernel

#print axioms adaptive145Third138Proof187

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third138Proof26 : runCachedNode 511 130311 Adaptive145Third138Node26 = false := by
  decide +kernel

#print axioms adaptive145Third138Proof26

end NineSeparatedSubsetSums
