import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive145Third123Node0 : CachedSearchNode :=
  ⟨4, 122, computeCenteredMask [148,145,123], 416, 58058⟩

end NineSeparatedSubsetSums
