import NineSeparatedSubsetSums.Adaptive145Third126State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third126Proof5 : runCachedNode 511 127918 Adaptive145Third126Node5 = false := by
  decide +kernel

#print axioms adaptive145Third126Proof5

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third126Proof1 : runCachedNode 511 127918 Adaptive145Third126Node1 = false := by
  decide +kernel

#print axioms adaptive145Third126Proof1

end NineSeparatedSubsetSums
