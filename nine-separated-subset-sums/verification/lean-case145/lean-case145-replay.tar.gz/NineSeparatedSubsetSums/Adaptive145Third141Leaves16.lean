import NineSeparatedSubsetSums.Adaptive145Third141State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third141Proof129 : runCachedNode 511 130740 Adaptive145Third141Node129 = false := by
  decide +kernel

#print axioms adaptive145Third141Proof129

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third141Proof419 : runCachedNode 511 130740 Adaptive145Third141Node419 = false := by
  decide +kernel

#print axioms adaptive145Third141Proof419

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third141Proof75 : runCachedNode 511 130740 Adaptive145Third141Node75 = false := by
  decide +kernel

#print axioms adaptive145Third141Proof75

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third141Proof128 : runCachedNode 511 130740 Adaptive145Third141Node128 = false := by
  decide +kernel

#print axioms adaptive145Third141Proof128

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third141Proof81 : runCachedNode 511 130740 Adaptive145Third141Node81 = false := by
  decide +kernel

#print axioms adaptive145Third141Proof81

end NineSeparatedSubsetSums
