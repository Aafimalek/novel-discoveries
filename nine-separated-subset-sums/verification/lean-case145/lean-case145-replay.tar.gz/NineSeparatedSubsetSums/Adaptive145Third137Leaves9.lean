import NineSeparatedSubsetSums.Adaptive145Third137State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third137Proof177 : runCachedNode 511 130164 Adaptive145Third137Node177 = false := by
  decide +kernel

#print axioms adaptive145Third137Proof177

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third137Proof39 : runCachedNode 511 130164 Adaptive145Third137Node39 = false := by
  decide +kernel

#print axioms adaptive145Third137Proof39

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third137Proof66 : runCachedNode 511 130164 Adaptive145Third137Node66 = false := by
  decide +kernel

#print axioms adaptive145Third137Proof66

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third137Proof92 : runCachedNode 511 130164 Adaptive145Third137Node92 = false := by
  decide +kernel

#print axioms adaptive145Third137Proof92

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third137Proof179 : runCachedNode 511 130164 Adaptive145Third137Node179 = false := by
  decide +kernel

#print axioms adaptive145Third137Proof179

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third137Proof176 : runCachedNode 511 130164 Adaptive145Third137Node176 = false := by
  decide +kernel

#print axioms adaptive145Third137Proof176

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third137Proof119 : runCachedNode 511 130164 Adaptive145Third137Node119 = false := by
  decide +kernel

#print axioms adaptive145Third137Proof119

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third137Proof142 : runCachedNode 511 130164 Adaptive145Third137Node142 = false := by
  decide +kernel

#print axioms adaptive145Third137Proof142

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third137Proof22 : runCachedNode 511 130164 Adaptive145Third137Node22 = false := by
  decide +kernel

#print axioms adaptive145Third137Proof22

end NineSeparatedSubsetSums
