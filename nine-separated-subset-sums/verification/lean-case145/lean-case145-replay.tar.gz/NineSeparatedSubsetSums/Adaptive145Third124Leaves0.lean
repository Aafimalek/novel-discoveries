import NineSeparatedSubsetSums.Adaptive145Third124State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third124Proof0 : runCachedNode 511 127332 Adaptive145Third124Node0 = false := by
  decide +kernel

#print axioms adaptive145Third124Proof0

end NineSeparatedSubsetSums
