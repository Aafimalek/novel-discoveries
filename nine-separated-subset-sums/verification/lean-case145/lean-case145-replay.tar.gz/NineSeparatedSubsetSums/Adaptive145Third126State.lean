import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive145Third126Node0 : CachedSearchNode :=
  ⟨4, 125, computeCenteredMask [148,145,126], 419, 58805⟩
def Adaptive145Third126Node1 : CachedSearchNode := cachedChild Adaptive145Third126Node0 110
def Adaptive145Third126Node2 : CachedSearchNode := cachedChild Adaptive145Third126Node0 111
def Adaptive145Third126Node3 : CachedSearchNode := cachedChild Adaptive145Third126Node0 112
def Adaptive145Third126Node4 : CachedSearchNode := cachedChild Adaptive145Third126Node0 113
def Adaptive145Third126Node5 : CachedSearchNode := cachedChild Adaptive145Third126Node0 114
def Adaptive145Third126Node6 : CachedSearchNode := cachedChild Adaptive145Third126Node0 115
def Adaptive145Third126Node7 : CachedSearchNode := cachedChild Adaptive145Third126Node0 116
def Adaptive145Third126Node8 : CachedSearchNode := cachedChild Adaptive145Third126Node0 117
def Adaptive145Third126Node9 : CachedSearchNode := cachedChild Adaptive145Third126Node0 118
def Adaptive145Third126Node10 : CachedSearchNode := cachedChild Adaptive145Third126Node0 119
def Adaptive145Third126Node11 : CachedSearchNode := cachedChild Adaptive145Third126Node0 120
def Adaptive145Third126Node12 : CachedSearchNode := cachedChild Adaptive145Third126Node0 121
def Adaptive145Third126Node13 : CachedSearchNode := cachedChild Adaptive145Third126Node0 122
def Adaptive145Third126Node14 : CachedSearchNode := cachedChild Adaptive145Third126Node0 124
def Adaptive145Third126Node15 : CachedSearchNode := cachedChild Adaptive145Third126Node0 125

end NineSeparatedSubsetSums
