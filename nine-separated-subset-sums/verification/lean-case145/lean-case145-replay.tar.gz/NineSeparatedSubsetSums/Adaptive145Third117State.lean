import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive145Third117Node0 : CachedSearchNode :=
  ⟨4, 116, computeCenteredMask [148,145,117], 410, 56618⟩

end NineSeparatedSubsetSums
