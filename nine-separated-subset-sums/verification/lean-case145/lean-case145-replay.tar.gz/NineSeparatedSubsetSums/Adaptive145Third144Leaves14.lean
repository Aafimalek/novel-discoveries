import NineSeparatedSubsetSums.Adaptive145Third144State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third144Proof335 : runCachedNode 511 131183 Adaptive145Third144Node335 = false := by
  decide +kernel

#print axioms adaptive145Third144Proof335

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third144Proof623 : runCachedNode 511 131183 Adaptive145Third144Node623 = false := by
  decide +kernel

#print axioms adaptive145Third144Proof623

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third144Proof109 : runCachedNode 511 131183 Adaptive145Third144Node109 = false := by
  decide +kernel

#print axioms adaptive145Third144Proof109

end NineSeparatedSubsetSums
