import NineSeparatedSubsetSums.Adaptive145Third141State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third141Proof374 : runCachedNode 511 130740 Adaptive145Third141Node374 = false := by
  decide +kernel

#print axioms adaptive145Third141Proof374

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third141Proof300 : runCachedNode 511 130740 Adaptive145Third141Node300 = false := by
  decide +kernel

#print axioms adaptive145Third141Proof300

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third141Proof191 : runCachedNode 511 130740 Adaptive145Third141Node191 = false := by
  decide +kernel

#print axioms adaptive145Third141Proof191

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third141Proof142 : runCachedNode 511 130740 Adaptive145Third141Node142 = false := by
  decide +kernel

#print axioms adaptive145Third141Proof142

end NineSeparatedSubsetSums
