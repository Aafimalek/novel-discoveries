import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive145Third134Node0 : CachedSearchNode :=
  ⟨4, 133, computeCenteredMask [148,145,134], 427, 60885⟩
def Adaptive145Third134Node1 : CachedSearchNode := cachedChild Adaptive145Third134Node0 110
def Adaptive145Third134Node2 : CachedSearchNode := cachedChild Adaptive145Third134Node0 111
def Adaptive145Third134Node3 : CachedSearchNode := cachedChild Adaptive145Third134Node0 112
def Adaptive145Third134Node4 : CachedSearchNode := cachedChild Adaptive145Third134Node0 113
def Adaptive145Third134Node5 : CachedSearchNode := cachedChild Adaptive145Third134Node0 114
def Adaptive145Third134Node6 : CachedSearchNode := cachedChild Adaptive145Third134Node0 115
def Adaptive145Third134Node7 : CachedSearchNode := cachedChild Adaptive145Third134Node0 116
def Adaptive145Third134Node8 : CachedSearchNode := cachedChild Adaptive145Third134Node0 117
def Adaptive145Third134Node9 : CachedSearchNode := cachedChild Adaptive145Third134Node0 118
def Adaptive145Third134Node10 : CachedSearchNode := cachedChild Adaptive145Third134Node0 119
def Adaptive145Third134Node11 : CachedSearchNode := cachedChild Adaptive145Third134Node0 120
def Adaptive145Third134Node12 : CachedSearchNode := cachedChild Adaptive145Third134Node0 121
def Adaptive145Third134Node13 : CachedSearchNode := cachedChild Adaptive145Third134Node0 122
def Adaptive145Third134Node14 : CachedSearchNode := cachedChild Adaptive145Third134Node0 123
def Adaptive145Third134Node15 : CachedSearchNode := cachedChild Adaptive145Third134Node0 124
def Adaptive145Third134Node16 : CachedSearchNode := cachedChild Adaptive145Third134Node0 125
def Adaptive145Third134Node17 : CachedSearchNode := cachedChild Adaptive145Third134Node0 126
def Adaptive145Third134Node18 : CachedSearchNode := cachedChild Adaptive145Third134Node0 127
def Adaptive145Third134Node19 : CachedSearchNode := cachedChild Adaptive145Third134Node0 128
def Adaptive145Third134Node20 : CachedSearchNode := cachedChild Adaptive145Third134Node0 129
def Adaptive145Third134Node21 : CachedSearchNode := cachedChild Adaptive145Third134Node0 130
def Adaptive145Third134Node22 : CachedSearchNode := cachedChild Adaptive145Third134Node0 132
def Adaptive145Third134Node23 : CachedSearchNode := cachedChild Adaptive145Third134Node0 133
def Adaptive145Third134Node24 : CachedSearchNode := cachedChild Adaptive145Third134Node23 104
def Adaptive145Third134Node25 : CachedSearchNode := cachedChild Adaptive145Third134Node23 105
def Adaptive145Third134Node26 : CachedSearchNode := cachedChild Adaptive145Third134Node23 106
def Adaptive145Third134Node27 : CachedSearchNode := cachedChild Adaptive145Third134Node23 107
def Adaptive145Third134Node28 : CachedSearchNode := cachedChild Adaptive145Third134Node23 108
def Adaptive145Third134Node29 : CachedSearchNode := cachedChild Adaptive145Third134Node23 109
def Adaptive145Third134Node30 : CachedSearchNode := cachedChild Adaptive145Third134Node23 110
def Adaptive145Third134Node31 : CachedSearchNode := cachedChild Adaptive145Third134Node23 111
def Adaptive145Third134Node32 : CachedSearchNode := cachedChild Adaptive145Third134Node23 112
def Adaptive145Third134Node33 : CachedSearchNode := cachedChild Adaptive145Third134Node23 113
def Adaptive145Third134Node34 : CachedSearchNode := cachedChild Adaptive145Third134Node23 114
def Adaptive145Third134Node35 : CachedSearchNode := cachedChild Adaptive145Third134Node23 115
def Adaptive145Third134Node36 : CachedSearchNode := cachedChild Adaptive145Third134Node23 116
def Adaptive145Third134Node37 : CachedSearchNode := cachedChild Adaptive145Third134Node23 117
def Adaptive145Third134Node38 : CachedSearchNode := cachedChild Adaptive145Third134Node23 118
def Adaptive145Third134Node39 : CachedSearchNode := cachedChild Adaptive145Third134Node23 120
def Adaptive145Third134Node40 : CachedSearchNode := cachedChild Adaptive145Third134Node23 121
def Adaptive145Third134Node41 : CachedSearchNode := cachedChild Adaptive145Third134Node23 123
def Adaptive145Third134Node42 : CachedSearchNode := cachedChild Adaptive145Third134Node23 124
def Adaptive145Third134Node43 : CachedSearchNode := cachedChild Adaptive145Third134Node23 125
def Adaptive145Third134Node44 : CachedSearchNode := cachedChild Adaptive145Third134Node23 126
def Adaptive145Third134Node45 : CachedSearchNode := cachedChild Adaptive145Third134Node23 127
def Adaptive145Third134Node46 : CachedSearchNode := cachedChild Adaptive145Third134Node23 128
def Adaptive145Third134Node47 : CachedSearchNode := cachedChild Adaptive145Third134Node23 129
def Adaptive145Third134Node48 : CachedSearchNode := cachedChild Adaptive145Third134Node23 132

end NineSeparatedSubsetSums
