import NineSeparatedSubsetSums.Adaptive145Third143State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof100 : runCachedNode 511 131040 Adaptive145Third143Node100 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof100

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof584 : runCachedNode 511 131040 Adaptive145Third143Node584 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof584

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof71 : runCachedNode 511 131040 Adaptive145Third143Node71 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof71

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof580 : runCachedNode 511 131040 Adaptive145Third143Node580 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof580

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof407 : runCachedNode 511 131040 Adaptive145Third143Node407 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof407

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof127 : runCachedNode 511 131040 Adaptive145Third143Node127 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof127

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof12 : runCachedNode 511 131040 Adaptive145Third143Node12 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof12

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof544 : runCachedNode 511 131040 Adaptive145Third143Node544 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof544

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof458 : runCachedNode 511 131040 Adaptive145Third143Node458 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof458

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof272 : runCachedNode 511 131040 Adaptive145Third143Node272 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof272

end NineSeparatedSubsetSums
