import NineSeparatedSubsetSums.Adaptive145Third134State
import NineSeparatedSubsetSums.Adaptive145Third134Leaves2
import NineSeparatedSubsetSums.Adaptive145Third134Leaves4
import NineSeparatedSubsetSums.Adaptive145Third134Leaves5
import NineSeparatedSubsetSums.Adaptive145Third134Leaves1
import NineSeparatedSubsetSums.Adaptive145Third134Leaves6
import NineSeparatedSubsetSums.Adaptive145Third134Leaves0
import NineSeparatedSubsetSums.Adaptive145Third134Leaves3

namespace NineSeparatedSubsetSums

theorem adaptive145Third134Proof23 : runCachedNode 511 129715 Adaptive145Third134Node23 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 129715 Adaptive145Third134Node23 = [104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 120, 121, 123, 124, 125, 126, 127, 128, 129, 132] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive145Third134Proof24
  · exact adaptive145Third134Proof25
  · exact adaptive145Third134Proof26
  · exact adaptive145Third134Proof27
  · exact adaptive145Third134Proof28
  · exact adaptive145Third134Proof29
  · exact adaptive145Third134Proof30
  · exact adaptive145Third134Proof31
  · exact adaptive145Third134Proof32
  · exact adaptive145Third134Proof33
  · exact adaptive145Third134Proof34
  · exact adaptive145Third134Proof35
  · exact adaptive145Third134Proof36
  · exact adaptive145Third134Proof37
  · exact adaptive145Third134Proof38
  · exact adaptive145Third134Proof39
  · exact adaptive145Third134Proof40
  · exact adaptive145Third134Proof41
  · exact adaptive145Third134Proof42
  · exact adaptive145Third134Proof43
  · exact adaptive145Third134Proof44
  · exact adaptive145Third134Proof45
  · exact adaptive145Third134Proof46
  · exact adaptive145Third134Proof47
  · exact adaptive145Third134Proof48

#print axioms adaptive145Third134Proof23

theorem adaptive145Third134Proof0 : runCachedNode 511 129715 Adaptive145Third134Node0 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 129715 Adaptive145Third134Node0 = [110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 132, 133] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive145Third134Proof1
  · exact adaptive145Third134Proof2
  · exact adaptive145Third134Proof3
  · exact adaptive145Third134Proof4
  · exact adaptive145Third134Proof5
  · exact adaptive145Third134Proof6
  · exact adaptive145Third134Proof7
  · exact adaptive145Third134Proof8
  · exact adaptive145Third134Proof9
  · exact adaptive145Third134Proof10
  · exact adaptive145Third134Proof11
  · exact adaptive145Third134Proof12
  · exact adaptive145Third134Proof13
  · exact adaptive145Third134Proof14
  · exact adaptive145Third134Proof15
  · exact adaptive145Third134Proof16
  · exact adaptive145Third134Proof17
  · exact adaptive145Third134Proof18
  · exact adaptive145Third134Proof19
  · exact adaptive145Third134Proof20
  · exact adaptive145Third134Proof21
  · exact adaptive145Third134Proof22
  · exact adaptive145Third134Proof23

#print axioms adaptive145Third134Proof0

end NineSeparatedSubsetSums
