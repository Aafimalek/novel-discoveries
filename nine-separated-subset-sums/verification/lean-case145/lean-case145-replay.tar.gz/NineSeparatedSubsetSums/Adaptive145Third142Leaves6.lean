import NineSeparatedSubsetSums.Adaptive145Third142State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof818 : runCachedNode 511 130865 Adaptive145Third142Node818 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof818

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof647 : runCachedNode 511 130865 Adaptive145Third142Node647 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof647

end NineSeparatedSubsetSums
