import NineSeparatedSubsetSums.Adaptive145Third138State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third138Proof21 : runCachedNode 511 130311 Adaptive145Third138Node21 = false := by
  decide +kernel

#print axioms adaptive145Third138Proof21

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third138Proof68 : runCachedNode 511 130311 Adaptive145Third138Node68 = false := by
  decide +kernel

#print axioms adaptive145Third138Proof68

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third138Proof56 : runCachedNode 511 130311 Adaptive145Third138Node56 = false := by
  decide +kernel

#print axioms adaptive145Third138Proof56

end NineSeparatedSubsetSums
