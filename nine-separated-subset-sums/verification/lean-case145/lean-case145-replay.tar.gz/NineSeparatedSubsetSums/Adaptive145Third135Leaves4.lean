import NineSeparatedSubsetSums.Adaptive145Third135State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third135Proof19 : runCachedNode 511 129879 Adaptive145Third135Node19 = false := by
  decide +kernel

#print axioms adaptive145Third135Proof19

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third135Proof16 : runCachedNode 511 129879 Adaptive145Third135Node16 = false := by
  decide +kernel

#print axioms adaptive145Third135Proof16

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third135Proof32 : runCachedNode 511 129879 Adaptive145Third135Node32 = false := by
  decide +kernel

#print axioms adaptive145Third135Proof32

end NineSeparatedSubsetSums
