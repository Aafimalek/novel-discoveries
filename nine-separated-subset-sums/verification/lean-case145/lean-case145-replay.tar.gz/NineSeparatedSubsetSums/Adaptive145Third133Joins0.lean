import NineSeparatedSubsetSums.Adaptive145Third133State
import NineSeparatedSubsetSums.Adaptive145Third133Leaves1
import NineSeparatedSubsetSums.Adaptive145Third133Leaves5
import NineSeparatedSubsetSums.Adaptive145Third133Leaves2
import NineSeparatedSubsetSums.Adaptive145Third133Leaves4
import NineSeparatedSubsetSums.Adaptive145Third133Leaves3
import NineSeparatedSubsetSums.Adaptive145Third133Leaves0

namespace NineSeparatedSubsetSums

theorem adaptive145Third133Proof22 : runCachedNode 511 129495 Adaptive145Third133Node22 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 129495 Adaptive145Third133Node22 = [104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 118, 119, 121, 122, 123, 124, 125, 126, 127, 128, 131] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive145Third133Proof23
  · exact adaptive145Third133Proof24
  · exact adaptive145Third133Proof25
  · exact adaptive145Third133Proof26
  · exact adaptive145Third133Proof27
  · exact adaptive145Third133Proof28
  · exact adaptive145Third133Proof29
  · exact adaptive145Third133Proof30
  · exact adaptive145Third133Proof31
  · exact adaptive145Third133Proof32
  · exact adaptive145Third133Proof33
  · exact adaptive145Third133Proof34
  · exact adaptive145Third133Proof35
  · exact adaptive145Third133Proof36
  · exact adaptive145Third133Proof37
  · exact adaptive145Third133Proof38
  · exact adaptive145Third133Proof39
  · exact adaptive145Third133Proof40
  · exact adaptive145Third133Proof41
  · exact adaptive145Third133Proof42
  · exact adaptive145Third133Proof43
  · exact adaptive145Third133Proof44
  · exact adaptive145Third133Proof45
  · exact adaptive145Third133Proof46

#print axioms adaptive145Third133Proof22

theorem adaptive145Third133Proof0 : runCachedNode 511 129495 Adaptive145Third133Node0 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 129495 Adaptive145Third133Node0 = [110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 131, 132] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive145Third133Proof1
  · exact adaptive145Third133Proof2
  · exact adaptive145Third133Proof3
  · exact adaptive145Third133Proof4
  · exact adaptive145Third133Proof5
  · exact adaptive145Third133Proof6
  · exact adaptive145Third133Proof7
  · exact adaptive145Third133Proof8
  · exact adaptive145Third133Proof9
  · exact adaptive145Third133Proof10
  · exact adaptive145Third133Proof11
  · exact adaptive145Third133Proof12
  · exact adaptive145Third133Proof13
  · exact adaptive145Third133Proof14
  · exact adaptive145Third133Proof15
  · exact adaptive145Third133Proof16
  · exact adaptive145Third133Proof17
  · exact adaptive145Third133Proof18
  · exact adaptive145Third133Proof19
  · exact adaptive145Third133Proof20
  · exact adaptive145Third133Proof21
  · exact adaptive145Third133Proof22

#print axioms adaptive145Third133Proof0

end NineSeparatedSubsetSums
