import NineSeparatedSubsetSums.Adaptive145Third139State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third139Proof225 : runCachedNode 511 130465 Adaptive145Third139Node225 = false := by
  decide +kernel

#print axioms adaptive145Third139Proof225

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third139Proof224 : runCachedNode 511 130465 Adaptive145Third139Node224 = false := by
  decide +kernel

#print axioms adaptive145Third139Proof224

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third139Proof204 : runCachedNode 511 130465 Adaptive145Third139Node204 = false := by
  decide +kernel

#print axioms adaptive145Third139Proof204

end NineSeparatedSubsetSums
