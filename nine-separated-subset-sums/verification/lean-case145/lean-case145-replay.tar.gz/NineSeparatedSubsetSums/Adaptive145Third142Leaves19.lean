import NineSeparatedSubsetSums.Adaptive145Third142State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof286 : runCachedNode 511 130865 Adaptive145Third142Node286 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof286

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof507 : runCachedNode 511 130865 Adaptive145Third142Node507 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof507

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof95 : runCachedNode 511 130865 Adaptive145Third142Node95 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof95

end NineSeparatedSubsetSums
