import NineSeparatedSubsetSums.Adaptive145Third136State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third136Proof152 : runCachedNode 511 130013 Adaptive145Third136Node152 = false := by
  decide +kernel

#print axioms adaptive145Third136Proof152

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third136Proof151 : runCachedNode 511 130013 Adaptive145Third136Node151 = false := by
  decide +kernel

#print axioms adaptive145Third136Proof151

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third136Proof61 : runCachedNode 511 130013 Adaptive145Third136Node61 = false := by
  decide +kernel

#print axioms adaptive145Third136Proof61

end NineSeparatedSubsetSums
