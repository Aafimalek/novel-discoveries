import NineSeparatedSubsetSums.Adaptive145Third142State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof947 : runCachedNode 511 130865 Adaptive145Third142Node947 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof947

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof505 : runCachedNode 511 130865 Adaptive145Third142Node505 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof505

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof86 : runCachedNode 511 130865 Adaptive145Third142Node86 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof86

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof87 : runCachedNode 511 130865 Adaptive145Third142Node87 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof87

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof221 : runCachedNode 511 130865 Adaptive145Third142Node221 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof221

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof142 : runCachedNode 511 130865 Adaptive145Third142Node142 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof142

end NineSeparatedSubsetSums
