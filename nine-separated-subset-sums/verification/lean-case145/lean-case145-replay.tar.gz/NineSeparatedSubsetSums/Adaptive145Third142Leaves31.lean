import NineSeparatedSubsetSums.Adaptive145Third142State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof459 : runCachedNode 511 130865 Adaptive145Third142Node459 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof459

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof196 : runCachedNode 511 130865 Adaptive145Third142Node196 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof196

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof165 : runCachedNode 511 130865 Adaptive145Third142Node165 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof165

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof23 : runCachedNode 511 130865 Adaptive145Third142Node23 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof23

end NineSeparatedSubsetSums
