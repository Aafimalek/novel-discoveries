import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive145Third108Node0 : CachedSearchNode :=
  ⟨4, 107, computeCenteredMask [148,145,108], 401, 54593⟩

end NineSeparatedSubsetSums
