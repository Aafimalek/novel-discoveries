import NineSeparatedSubsetSums.Adaptive145Third142State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof285 : runCachedNode 511 130865 Adaptive145Third142Node285 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof285

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof227 : runCachedNode 511 130865 Adaptive145Third142Node227 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof227

end NineSeparatedSubsetSums
