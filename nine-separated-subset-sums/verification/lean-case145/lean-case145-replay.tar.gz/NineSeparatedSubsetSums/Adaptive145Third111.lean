import NineSeparatedSubsetSums.Adaptive145Third111Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint145Checked

namespace NineSeparatedSubsetSums


theorem adaptive145Third111 : NoDescendingTailAfterThird 145 111 :=
  noDescendingThirdTail_of_cached 145 111 112442 (fun t ht nd => max148_second145_fourPoint_moment_bound (111::t) (by simp [ht]) nd) adaptive145Third111Proof0

#print axioms adaptive145Third111

end NineSeparatedSubsetSums
