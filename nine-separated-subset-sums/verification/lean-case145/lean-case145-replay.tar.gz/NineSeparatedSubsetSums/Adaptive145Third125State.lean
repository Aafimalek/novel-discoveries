import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive145Third125Node0 : CachedSearchNode :=
  ⟨4, 124, computeCenteredMask [148,145,125], 418, 58554⟩

end NineSeparatedSubsetSums
