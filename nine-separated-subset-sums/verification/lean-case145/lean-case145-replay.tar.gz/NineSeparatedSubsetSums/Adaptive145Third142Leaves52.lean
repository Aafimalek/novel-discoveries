import NineSeparatedSubsetSums.Adaptive145Third142State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof580 : runCachedNode 511 130865 Adaptive145Third142Node580 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof580

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof85 : runCachedNode 511 130865 Adaptive145Third142Node85 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof85

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof646 : runCachedNode 511 130865 Adaptive145Third142Node646 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof646

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof11 : runCachedNode 511 130865 Adaptive145Third142Node11 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof11

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof391 : runCachedNode 511 130865 Adaptive145Third142Node391 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof391

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof355 : runCachedNode 511 130865 Adaptive145Third142Node355 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof355

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof56 : runCachedNode 511 130865 Adaptive145Third142Node56 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof56

end NineSeparatedSubsetSums
