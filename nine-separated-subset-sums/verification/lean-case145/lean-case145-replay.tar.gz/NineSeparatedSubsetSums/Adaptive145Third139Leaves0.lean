import NineSeparatedSubsetSums.Adaptive145Third139State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third139Proof45 : runCachedNode 511 130465 Adaptive145Third139Node45 = false := by
  decide +kernel

#print axioms adaptive145Third139Proof45

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third139Proof13 : runCachedNode 511 130465 Adaptive145Third139Node13 = false := by
  decide +kernel

#print axioms adaptive145Third139Proof13

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third139Proof109 : runCachedNode 511 130465 Adaptive145Third139Node109 = false := by
  decide +kernel

#print axioms adaptive145Third139Proof109

end NineSeparatedSubsetSums
