import NineSeparatedSubsetSums.Adaptive145Third142State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof527 : runCachedNode 511 130865 Adaptive145Third142Node527 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof527

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof186 : runCachedNode 511 130865 Adaptive145Third142Node186 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof186

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof309 : runCachedNode 511 130865 Adaptive145Third142Node309 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof309

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof802 : runCachedNode 511 130865 Adaptive145Third142Node802 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof802

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof185 : runCachedNode 511 130865 Adaptive145Third142Node185 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof185

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof452 : runCachedNode 511 130865 Adaptive145Third142Node452 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof452

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof900 : runCachedNode 511 130865 Adaptive145Third142Node900 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof900

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof352 : runCachedNode 511 130865 Adaptive145Third142Node352 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof352

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof131 : runCachedNode 511 130865 Adaptive145Third142Node131 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof131

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof248 : runCachedNode 511 130865 Adaptive145Third142Node248 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof248

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof37 : runCachedNode 511 130865 Adaptive145Third142Node37 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof37

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof304 : runCachedNode 511 130865 Adaptive145Third142Node304 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof304

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof199 : runCachedNode 511 130865 Adaptive145Third142Node199 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof199

end NineSeparatedSubsetSums
