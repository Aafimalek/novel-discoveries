import NineSeparatedSubsetSums.Adaptive145Third143State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof587 : runCachedNode 511 131040 Adaptive145Third143Node587 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof587

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof488 : runCachedNode 511 131040 Adaptive145Third143Node488 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof488

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof581 : runCachedNode 511 131040 Adaptive145Third143Node581 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof581

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof582 : runCachedNode 511 131040 Adaptive145Third143Node582 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof582

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof586 : runCachedNode 511 131040 Adaptive145Third143Node586 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof586

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof46 : runCachedNode 511 131040 Adaptive145Third143Node46 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof46

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof585 : runCachedNode 511 131040 Adaptive145Third143Node585 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof585

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof45 : runCachedNode 511 131040 Adaptive145Third143Node45 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof45

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof61 : runCachedNode 511 131040 Adaptive145Third143Node61 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof61

end NineSeparatedSubsetSums
