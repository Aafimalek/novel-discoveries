import NineSeparatedSubsetSums.Adaptive145Third104Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint145Checked

namespace NineSeparatedSubsetSums


theorem adaptive145Third104 : NoDescendingTailAfterThird 145 104 :=
  noDescendingThirdTail_of_cached 145 104 112442 (fun t ht nd => max148_second145_fourPoint_moment_bound (104::t) (by simp [ht]) nd) adaptive145Third104Proof0

#print axioms adaptive145Third104

end NineSeparatedSubsetSums
