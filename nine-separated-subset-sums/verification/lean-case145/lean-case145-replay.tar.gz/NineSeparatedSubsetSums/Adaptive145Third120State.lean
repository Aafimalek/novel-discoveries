import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive145Third120Node0 : CachedSearchNode :=
  ⟨4, 119, computeCenteredMask [148,145,120], 413, 57329⟩

end NineSeparatedSubsetSums
