import NineSeparatedSubsetSums.Adaptive145Third105Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint145Checked

namespace NineSeparatedSubsetSums


theorem adaptive145Third105 : NoDescendingTailAfterThird 145 105 :=
  noDescendingThirdTail_of_cached 145 105 112442 (fun t ht nd => max148_second145_fourPoint_moment_bound (105::t) (by simp [ht]) nd) adaptive145Third105Proof0

#print axioms adaptive145Third105

end NineSeparatedSubsetSums
