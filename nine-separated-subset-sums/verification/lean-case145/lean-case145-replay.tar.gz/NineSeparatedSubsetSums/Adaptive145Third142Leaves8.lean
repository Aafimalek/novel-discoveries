import NineSeparatedSubsetSums.Adaptive145Third142State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof18 : runCachedNode 511 130865 Adaptive145Third142Node18 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof18

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof315 : runCachedNode 511 130865 Adaptive145Third142Node315 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof315

end NineSeparatedSubsetSums
