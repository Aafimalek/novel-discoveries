import NineSeparatedSubsetSums.Adaptive145Third144State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third144Proof497 : runCachedNode 511 131183 Adaptive145Third144Node497 = false := by
  decide +kernel

#print axioms adaptive145Third144Proof497

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third144Proof652 : runCachedNode 511 131183 Adaptive145Third144Node652 = false := by
  decide +kernel

#print axioms adaptive145Third144Proof652

end NineSeparatedSubsetSums
