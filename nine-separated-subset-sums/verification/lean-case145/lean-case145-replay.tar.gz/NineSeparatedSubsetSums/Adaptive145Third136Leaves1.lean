import NineSeparatedSubsetSums.Adaptive145Third136State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third136Proof20 : runCachedNode 511 130013 Adaptive145Third136Node20 = false := by
  decide +kernel

#print axioms adaptive145Third136Proof20

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third136Proof94 : runCachedNode 511 130013 Adaptive145Third136Node94 = false := by
  decide +kernel

#print axioms adaptive145Third136Proof94

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third136Proof86 : runCachedNode 511 130013 Adaptive145Third136Node86 = false := by
  decide +kernel

#print axioms adaptive145Third136Proof86

end NineSeparatedSubsetSums
