import NineSeparatedSubsetSums.Adaptive145Third134State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third134Proof15 : runCachedNode 511 129715 Adaptive145Third134Node15 = false := by
  decide +kernel

#print axioms adaptive145Third134Proof15

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third134Proof47 : runCachedNode 511 129715 Adaptive145Third134Node47 = false := by
  decide +kernel

#print axioms adaptive145Third134Proof47

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third134Proof13 : runCachedNode 511 129715 Adaptive145Third134Node13 = false := by
  decide +kernel

#print axioms adaptive145Third134Proof13

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third134Proof11 : runCachedNode 511 129715 Adaptive145Third134Node11 = false := by
  decide +kernel

#print axioms adaptive145Third134Proof11

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third134Proof46 : runCachedNode 511 129715 Adaptive145Third134Node46 = false := by
  decide +kernel

#print axioms adaptive145Third134Proof46

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third134Proof44 : runCachedNode 511 129715 Adaptive145Third134Node44 = false := by
  decide +kernel

#print axioms adaptive145Third134Proof44

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third134Proof43 : runCachedNode 511 129715 Adaptive145Third134Node43 = false := by
  decide +kernel

#print axioms adaptive145Third134Proof43

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third134Proof10 : runCachedNode 511 129715 Adaptive145Third134Node10 = false := by
  decide +kernel

#print axioms adaptive145Third134Proof10

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third134Proof37 : runCachedNode 511 129715 Adaptive145Third134Node37 = false := by
  decide +kernel

#print axioms adaptive145Third134Proof37

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third134Proof26 : runCachedNode 511 129715 Adaptive145Third134Node26 = false := by
  decide +kernel

#print axioms adaptive145Third134Proof26

end NineSeparatedSubsetSums
