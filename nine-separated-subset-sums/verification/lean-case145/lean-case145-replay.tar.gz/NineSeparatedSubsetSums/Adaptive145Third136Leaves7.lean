import NineSeparatedSubsetSums.Adaptive145Third136State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third136Proof93 : runCachedNode 511 130013 Adaptive145Third136Node93 = false := by
  decide +kernel

#print axioms adaptive145Third136Proof93

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third136Proof119 : runCachedNode 511 130013 Adaptive145Third136Node119 = false := by
  decide +kernel

#print axioms adaptive145Third136Proof119

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third136Proof43 : runCachedNode 511 130013 Adaptive145Third136Node43 = false := by
  decide +kernel

#print axioms adaptive145Third136Proof43

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third136Proof147 : runCachedNode 511 130013 Adaptive145Third136Node147 = false := by
  decide +kernel

#print axioms adaptive145Third136Proof147

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third136Proof13 : runCachedNode 511 130013 Adaptive145Third136Node13 = false := by
  decide +kernel

#print axioms adaptive145Third136Proof13

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third136Proof92 : runCachedNode 511 130013 Adaptive145Third136Node92 = false := by
  decide +kernel

#print axioms adaptive145Third136Proof92

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third136Proof41 : runCachedNode 511 130013 Adaptive145Third136Node41 = false := by
  decide +kernel

#print axioms adaptive145Third136Proof41

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third136Proof2 : runCachedNode 511 130013 Adaptive145Third136Node2 = false := by
  decide +kernel

#print axioms adaptive145Third136Proof2

end NineSeparatedSubsetSums
