import NineSeparatedSubsetSums.Adaptive145Third142State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof308 : runCachedNode 511 130865 Adaptive145Third142Node308 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof308

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof450 : runCachedNode 511 130865 Adaptive145Third142Node450 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof450

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof451 : runCachedNode 511 130865 Adaptive145Third142Node451 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof451

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof246 : runCachedNode 511 130865 Adaptive145Third142Node246 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof246

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof899 : runCachedNode 511 130865 Adaptive145Third142Node899 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof899

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof157 : runCachedNode 511 130865 Adaptive145Third142Node157 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof157

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof215 : runCachedNode 511 130865 Adaptive145Third142Node215 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof215

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof856 : runCachedNode 511 130865 Adaptive145Third142Node856 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof856

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof927 : runCachedNode 511 130865 Adaptive145Third142Node927 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof927

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof938 : runCachedNode 511 130865 Adaptive145Third142Node938 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof938

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof928 : runCachedNode 511 130865 Adaptive145Third142Node928 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof928

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof274 : runCachedNode 511 130865 Adaptive145Third142Node274 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof274

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof800 : runCachedNode 511 130865 Adaptive145Third142Node800 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof800

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof936 : runCachedNode 511 130865 Adaptive145Third142Node936 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof936

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof105 : runCachedNode 511 130865 Adaptive145Third142Node105 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof105

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof305 : runCachedNode 511 130865 Adaptive145Third142Node305 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof305

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof213 : runCachedNode 511 130865 Adaptive145Third142Node213 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof213

end NineSeparatedSubsetSums
