import NineSeparatedSubsetSums.Adaptive145Third114Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint145Checked

namespace NineSeparatedSubsetSums


theorem adaptive145Third114 : NoDescendingTailAfterThird 145 114 :=
  noDescendingThirdTail_of_cached 145 114 112442 (fun t ht nd => max148_second145_fourPoint_moment_bound (114::t) (by simp [ht]) nd) adaptive145Third114Proof0

#print axioms adaptive145Third114

end NineSeparatedSubsetSums
