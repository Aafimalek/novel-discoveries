import NineSeparatedSubsetSums.Adaptive145Third142State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof808 : runCachedNode 511 130865 Adaptive145Third142Node808 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof808

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof648 : runCachedNode 511 130865 Adaptive145Third142Node648 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof648

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof902 : runCachedNode 511 130865 Adaptive145Third142Node902 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof902

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof189 : runCachedNode 511 130865 Adaptive145Third142Node189 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof189

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof353 : runCachedNode 511 130865 Adaptive145Third142Node353 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof353

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof736 : runCachedNode 511 130865 Adaptive145Third142Node736 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof736

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof116 : runCachedNode 511 130865 Adaptive145Third142Node116 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof116

end NineSeparatedSubsetSums
