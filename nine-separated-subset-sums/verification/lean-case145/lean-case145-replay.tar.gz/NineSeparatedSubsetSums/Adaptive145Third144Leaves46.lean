import NineSeparatedSubsetSums.Adaptive145Third144State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third144Proof296 : runCachedNode 511 131183 Adaptive145Third144Node296 = false := by
  decide +kernel

#print axioms adaptive145Third144Proof296

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third144Proof156 : runCachedNode 511 131183 Adaptive145Third144Node156 = false := by
  decide +kernel

#print axioms adaptive145Third144Proof156

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third144Proof127 : runCachedNode 511 131183 Adaptive145Third144Node127 = false := by
  decide +kernel

#print axioms adaptive145Third144Proof127

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third144Proof669 : runCachedNode 511 131183 Adaptive145Third144Node669 = false := by
  decide +kernel

#print axioms adaptive145Third144Proof669

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third144Proof158 : runCachedNode 511 131183 Adaptive145Third144Node158 = false := by
  decide +kernel

#print axioms adaptive145Third144Proof158

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third144Proof323 : runCachedNode 511 131183 Adaptive145Third144Node323 = false := by
  decide +kernel

#print axioms adaptive145Third144Proof323

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third144Proof482 : runCachedNode 511 131183 Adaptive145Third144Node482 = false := by
  decide +kernel

#print axioms adaptive145Third144Proof482

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third144Proof255 : runCachedNode 511 131183 Adaptive145Third144Node255 = false := by
  decide +kernel

#print axioms adaptive145Third144Proof255

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third144Proof581 : runCachedNode 511 131183 Adaptive145Third144Node581 = false := by
  decide +kernel

#print axioms adaptive145Third144Proof581

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third144Proof63 : runCachedNode 511 131183 Adaptive145Third144Node63 = false := by
  decide +kernel

#print axioms adaptive145Third144Proof63

end NineSeparatedSubsetSums
