import NineSeparatedSubsetSums.Adaptive145Third144State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third144Proof263 : runCachedNode 511 131183 Adaptive145Third144Node263 = false := by
  decide +kernel

#print axioms adaptive145Third144Proof263

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third144Proof134 : runCachedNode 511 131183 Adaptive145Third144Node134 = false := by
  decide +kernel

#print axioms adaptive145Third144Proof134

end NineSeparatedSubsetSums
