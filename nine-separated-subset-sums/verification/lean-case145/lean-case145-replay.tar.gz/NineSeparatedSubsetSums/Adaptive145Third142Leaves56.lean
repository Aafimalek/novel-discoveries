import NineSeparatedSubsetSums.Adaptive145Third142State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof945 : runCachedNode 511 130865 Adaptive145Third142Node945 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof945

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof694 : runCachedNode 511 130865 Adaptive145Third142Node694 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof694

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof132 : runCachedNode 511 130865 Adaptive145Third142Node132 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof132

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof531 : runCachedNode 511 130865 Adaptive145Third142Node531 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof531

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof83 : runCachedNode 511 130865 Adaptive145Third142Node83 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof83

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof858 : runCachedNode 511 130865 Adaptive145Third142Node858 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof858

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof354 : runCachedNode 511 130865 Adaptive145Third142Node354 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof354

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof620 : runCachedNode 511 130865 Adaptive145Third142Node620 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof620

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof78 : runCachedNode 511 130865 Adaptive145Third142Node78 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof78

end NineSeparatedSubsetSums
