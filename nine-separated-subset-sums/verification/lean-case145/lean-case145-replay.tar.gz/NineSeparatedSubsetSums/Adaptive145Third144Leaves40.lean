import NineSeparatedSubsetSums.Adaptive145Third144State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third144Proof615 : runCachedNode 511 131183 Adaptive145Third144Node615 = false := by
  decide +kernel

#print axioms adaptive145Third144Proof615

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third144Proof160 : runCachedNode 511 131183 Adaptive145Third144Node160 = false := by
  decide +kernel

#print axioms adaptive145Third144Proof160

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third144Proof327 : runCachedNode 511 131183 Adaptive145Third144Node327 = false := by
  decide +kernel

#print axioms adaptive145Third144Proof327

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third144Proof133 : runCachedNode 511 131183 Adaptive145Third144Node133 = false := by
  decide +kernel

#print axioms adaptive145Third144Proof133

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third144Proof760 : runCachedNode 511 131183 Adaptive145Third144Node760 = false := by
  decide +kernel

#print axioms adaptive145Third144Proof760

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third144Proof100 : runCachedNode 511 131183 Adaptive145Third144Node100 = false := by
  decide +kernel

#print axioms adaptive145Third144Proof100

end NineSeparatedSubsetSums
