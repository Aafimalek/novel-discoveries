import NineSeparatedSubsetSums.Adaptive145Third142State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof817 : runCachedNode 511 130865 Adaptive145Third142Node817 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof817

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof223 : runCachedNode 511 130865 Adaptive145Third142Node223 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof223

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof134 : runCachedNode 511 130865 Adaptive145Third142Node134 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof134

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof358 : runCachedNode 511 130865 Adaptive145Third142Node358 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof358

end NineSeparatedSubsetSums
