import NineSeparatedSubsetSums.Adaptive145Third140State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third140Proof17 : runCachedNode 511 130597 Adaptive145Third140Node17 = false := by
  decide +kernel

#print axioms adaptive145Third140Proof17

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third140Proof75 : runCachedNode 511 130597 Adaptive145Third140Node75 = false := by
  decide +kernel

#print axioms adaptive145Third140Proof75

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third140Proof73 : runCachedNode 511 130597 Adaptive145Third140Node73 = false := by
  decide +kernel

#print axioms adaptive145Third140Proof73

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third140Proof71 : runCachedNode 511 130597 Adaptive145Third140Node71 = false := by
  decide +kernel

#print axioms adaptive145Third140Proof71

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third140Proof4 : runCachedNode 511 130597 Adaptive145Third140Node4 = false := by
  decide +kernel

#print axioms adaptive145Third140Proof4

end NineSeparatedSubsetSums
