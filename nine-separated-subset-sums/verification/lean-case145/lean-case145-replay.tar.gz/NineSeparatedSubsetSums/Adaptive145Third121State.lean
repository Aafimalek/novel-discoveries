import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive145Third121Node0 : CachedSearchNode :=
  ⟨4, 120, computeCenteredMask [148,145,121], 414, 57570⟩

end NineSeparatedSubsetSums
