import NineSeparatedSubsetSums.Adaptive145Third143State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof15 : runCachedNode 511 131040 Adaptive145Third143Node15 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof15

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof494 : runCachedNode 511 131040 Adaptive145Third143Node494 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof494

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof224 : runCachedNode 511 131040 Adaptive145Third143Node224 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof224

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof496 : runCachedNode 511 131040 Adaptive145Third143Node496 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof496

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof10 : runCachedNode 511 131040 Adaptive145Third143Node10 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof10

end NineSeparatedSubsetSums
