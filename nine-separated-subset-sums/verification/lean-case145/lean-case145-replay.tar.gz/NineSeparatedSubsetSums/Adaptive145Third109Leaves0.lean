import NineSeparatedSubsetSums.Adaptive145Third109State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third109Proof0 : runCachedNode 511 112442 Adaptive145Third109Node0 = false := by
  decide +kernel

#print axioms adaptive145Third109Proof0

end NineSeparatedSubsetSums
