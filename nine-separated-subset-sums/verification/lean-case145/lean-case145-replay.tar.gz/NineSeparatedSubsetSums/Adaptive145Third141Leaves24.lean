import NineSeparatedSubsetSums.Adaptive145Third141State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third141Proof416 : runCachedNode 511 130740 Adaptive145Third141Node416 = false := by
  decide +kernel

#print axioms adaptive145Third141Proof416

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third141Proof156 : runCachedNode 511 130740 Adaptive145Third141Node156 = false := by
  decide +kernel

#print axioms adaptive145Third141Proof156

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third141Proof12 : runCachedNode 511 130740 Adaptive145Third141Node12 = false := by
  decide +kernel

#print axioms adaptive145Third141Proof12

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third141Proof42 : runCachedNode 511 130740 Adaptive145Third141Node42 = false := by
  decide +kernel

#print axioms adaptive145Third141Proof42

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third141Proof295 : runCachedNode 511 130740 Adaptive145Third141Node295 = false := by
  decide +kernel

#print axioms adaptive145Third141Proof295

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third141Proof45 : runCachedNode 511 130740 Adaptive145Third141Node45 = false := by
  decide +kernel

#print axioms adaptive145Third141Proof45

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third141Proof44 : runCachedNode 511 130740 Adaptive145Third141Node44 = false := by
  decide +kernel

#print axioms adaptive145Third141Proof44

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third141Proof97 : runCachedNode 511 130740 Adaptive145Third141Node97 = false := by
  decide +kernel

#print axioms adaptive145Third141Proof97

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third141Proof366 : runCachedNode 511 130740 Adaptive145Third141Node366 = false := by
  decide +kernel

#print axioms adaptive145Third141Proof366

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third141Proof369 : runCachedNode 511 130740 Adaptive145Third141Node369 = false := by
  decide +kernel

#print axioms adaptive145Third141Proof369

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third141Proof35 : runCachedNode 511 130740 Adaptive145Third141Node35 = false := by
  decide +kernel

#print axioms adaptive145Third141Proof35

end NineSeparatedSubsetSums
