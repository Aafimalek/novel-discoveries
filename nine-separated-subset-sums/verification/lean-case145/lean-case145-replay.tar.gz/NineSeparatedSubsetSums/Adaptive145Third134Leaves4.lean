import NineSeparatedSubsetSums.Adaptive145Third134State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third134Proof48 : runCachedNode 511 129715 Adaptive145Third134Node48 = false := by
  decide +kernel

#print axioms adaptive145Third134Proof48

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third134Proof17 : runCachedNode 511 129715 Adaptive145Third134Node17 = false := by
  decide +kernel

#print axioms adaptive145Third134Proof17

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third134Proof12 : runCachedNode 511 129715 Adaptive145Third134Node12 = false := by
  decide +kernel

#print axioms adaptive145Third134Proof12

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third134Proof25 : runCachedNode 511 129715 Adaptive145Third134Node25 = false := by
  decide +kernel

#print axioms adaptive145Third134Proof25

end NineSeparatedSubsetSums
