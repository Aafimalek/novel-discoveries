import NineSeparatedSubsetSums.Adaptive145Third140State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third140Proof131 : runCachedNode 511 130597 Adaptive145Third140Node131 = false := by
  decide +kernel

#print axioms adaptive145Third140Proof131

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third140Proof227 : runCachedNode 511 130597 Adaptive145Third140Node227 = false := by
  decide +kernel

#print axioms adaptive145Third140Proof227

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third140Proof250 : runCachedNode 511 130597 Adaptive145Third140Node250 = false := by
  decide +kernel

#print axioms adaptive145Third140Proof250

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third140Proof134 : runCachedNode 511 130597 Adaptive145Third140Node134 = false := by
  decide +kernel

#print axioms adaptive145Third140Proof134

end NineSeparatedSubsetSums
