import NineSeparatedSubsetSums.Adaptive145Third142State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof778 : runCachedNode 511 130865 Adaptive145Third142Node778 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof778

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof529 : runCachedNode 511 130865 Adaptive145Third142Node529 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof529

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof454 : runCachedNode 511 130865 Adaptive145Third142Node454 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof454

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof803 : runCachedNode 511 130865 Adaptive145Third142Node803 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof803

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof389 : runCachedNode 511 130865 Adaptive145Third142Node389 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof389

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof59 : runCachedNode 511 130865 Adaptive145Third142Node59 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof59

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof276 : runCachedNode 511 130865 Adaptive145Third142Node276 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof276

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof642 : runCachedNode 511 130865 Adaptive145Third142Node642 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof642

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof58 : runCachedNode 511 130865 Adaptive145Third142Node58 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof58

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof619 : runCachedNode 511 130865 Adaptive145Third142Node619 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof619

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof427 : runCachedNode 511 130865 Adaptive145Third142Node427 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof427

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof325 : runCachedNode 511 130865 Adaptive145Third142Node325 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof325

end NineSeparatedSubsetSums
