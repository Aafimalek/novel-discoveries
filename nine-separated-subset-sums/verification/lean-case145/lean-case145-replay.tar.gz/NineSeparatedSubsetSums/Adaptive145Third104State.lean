import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive145Third104Node0 : CachedSearchNode :=
  ⟨4, 103, computeCenteredMask [148,145,104], 397, 53745⟩

end NineSeparatedSubsetSums
