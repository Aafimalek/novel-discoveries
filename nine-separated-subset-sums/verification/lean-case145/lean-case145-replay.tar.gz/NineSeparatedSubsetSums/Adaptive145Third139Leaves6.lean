import NineSeparatedSubsetSums.Adaptive145Third139State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third139Proof223 : runCachedNode 511 130465 Adaptive145Third139Node223 = false := by
  decide +kernel

#print axioms adaptive145Third139Proof223

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third139Proof99 : runCachedNode 511 130465 Adaptive145Third139Node99 = false := by
  decide +kernel

#print axioms adaptive145Third139Proof99

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third139Proof157 : runCachedNode 511 130465 Adaptive145Third139Node157 = false := by
  decide +kernel

#print axioms adaptive145Third139Proof157

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third139Proof47 : runCachedNode 511 130465 Adaptive145Third139Node47 = false := by
  decide +kernel

#print axioms adaptive145Third139Proof47

end NineSeparatedSubsetSums
