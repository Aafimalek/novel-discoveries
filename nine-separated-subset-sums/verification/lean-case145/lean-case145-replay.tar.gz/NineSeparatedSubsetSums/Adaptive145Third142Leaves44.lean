import NineSeparatedSubsetSums.Adaptive145Third142State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof167 : runCachedNode 511 130865 Adaptive145Third142Node167 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof167

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof140 : runCachedNode 511 130865 Adaptive145Third142Node140 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof140

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof903 : runCachedNode 511 130865 Adaptive145Third142Node903 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof903

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof431 : runCachedNode 511 130865 Adaptive145Third142Node431 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof431

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof39 : runCachedNode 511 130865 Adaptive145Third142Node39 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof39

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof115 : runCachedNode 511 130865 Adaptive145Third142Node115 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof115

end NineSeparatedSubsetSums
