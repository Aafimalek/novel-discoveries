import NineSeparatedSubsetSums.Adaptive145Third141State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third141Proof195 : runCachedNode 511 130740 Adaptive145Third141Node195 = false := by
  decide +kernel

#print axioms adaptive145Third141Proof195

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third141Proof19 : runCachedNode 511 130740 Adaptive145Third141Node19 = false := by
  decide +kernel

#print axioms adaptive145Third141Proof19

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third141Proof68 : runCachedNode 511 130740 Adaptive145Third141Node68 = false := by
  decide +kernel

#print axioms adaptive145Third141Proof68

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third141Proof24 : runCachedNode 511 130740 Adaptive145Third141Node24 = false := by
  decide +kernel

#print axioms adaptive145Third141Proof24

end NineSeparatedSubsetSums
