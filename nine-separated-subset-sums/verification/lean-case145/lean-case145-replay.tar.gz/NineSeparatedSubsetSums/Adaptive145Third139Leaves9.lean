import NineSeparatedSubsetSums.Adaptive145Third139State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third139Proof160 : runCachedNode 511 130465 Adaptive145Third139Node160 = false := by
  decide +kernel

#print axioms adaptive145Third139Proof160

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third139Proof97 : runCachedNode 511 130465 Adaptive145Third139Node97 = false := by
  decide +kernel

#print axioms adaptive145Third139Proof97

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third139Proof190 : runCachedNode 511 130465 Adaptive145Third139Node190 = false := by
  decide +kernel

#print axioms adaptive145Third139Proof190

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third139Proof72 : runCachedNode 511 130465 Adaptive145Third139Node72 = false := by
  decide +kernel

#print axioms adaptive145Third139Proof72

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third139Proof12 : runCachedNode 511 130465 Adaptive145Third139Node12 = false := by
  decide +kernel

#print axioms adaptive145Third139Proof12

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third139Proof139 : runCachedNode 511 130465 Adaptive145Third139Node139 = false := by
  decide +kernel

#print axioms adaptive145Third139Proof139

end NineSeparatedSubsetSums
