import NineSeparatedSubsetSums.Adaptive145Third135State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third135Proof18 : runCachedNode 511 129879 Adaptive145Third135Node18 = false := by
  decide +kernel

#print axioms adaptive145Third135Proof18

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third135Proof17 : runCachedNode 511 129879 Adaptive145Third135Node17 = false := by
  decide +kernel

#print axioms adaptive145Third135Proof17

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third135Proof13 : runCachedNode 511 129879 Adaptive145Third135Node13 = false := by
  decide +kernel

#print axioms adaptive145Third135Proof13

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third135Proof3 : runCachedNode 511 129879 Adaptive145Third135Node3 = false := by
  decide +kernel

#print axioms adaptive145Third135Proof3

end NineSeparatedSubsetSums
