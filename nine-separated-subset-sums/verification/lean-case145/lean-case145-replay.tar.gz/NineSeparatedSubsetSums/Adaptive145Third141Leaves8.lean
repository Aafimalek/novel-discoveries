import NineSeparatedSubsetSums.Adaptive145Third141State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third141Proof226 : runCachedNode 511 130740 Adaptive145Third141Node226 = false := by
  decide +kernel

#print axioms adaptive145Third141Proof226

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third141Proof194 : runCachedNode 511 130740 Adaptive145Third141Node194 = false := by
  decide +kernel

#print axioms adaptive145Third141Proof194

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third141Proof28 : runCachedNode 511 130740 Adaptive145Third141Node28 = false := by
  decide +kernel

#print axioms adaptive145Third141Proof28

end NineSeparatedSubsetSums
