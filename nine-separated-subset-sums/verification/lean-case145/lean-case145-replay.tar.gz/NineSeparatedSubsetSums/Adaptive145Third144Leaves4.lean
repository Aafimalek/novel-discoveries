import NineSeparatedSubsetSums.Adaptive145Third144State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third144Proof627 : runCachedNode 511 131183 Adaptive145Third144Node627 = false := by
  decide +kernel

#print axioms adaptive145Third144Proof627

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third144Proof74 : runCachedNode 511 131183 Adaptive145Third144Node74 = false := by
  decide +kernel

#print axioms adaptive145Third144Proof74

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third144Proof1 : runCachedNode 511 131183 Adaptive145Third144Node1 = false := by
  decide +kernel

#print axioms adaptive145Third144Proof1

end NineSeparatedSubsetSums
