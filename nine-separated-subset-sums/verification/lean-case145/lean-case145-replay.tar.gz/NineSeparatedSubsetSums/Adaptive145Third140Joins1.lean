import NineSeparatedSubsetSums.Adaptive145Third140State
import NineSeparatedSubsetSums.Adaptive145Third140Leaves7
import NineSeparatedSubsetSums.Adaptive145Third140Leaves15
import NineSeparatedSubsetSums.Adaptive145Third140Leaves16
import NineSeparatedSubsetSums.Adaptive145Third140Leaves22
import NineSeparatedSubsetSums.Adaptive145Third140Leaves23
import NineSeparatedSubsetSums.Adaptive145Third140Leaves28
import NineSeparatedSubsetSums.Adaptive145Third140Leaves27
import NineSeparatedSubsetSums.Adaptive145Third140Leaves1
import NineSeparatedSubsetSums.Adaptive145Third140Leaves26
import NineSeparatedSubsetSums.Adaptive145Third140Leaves4
import NineSeparatedSubsetSums.Adaptive145Third140Leaves25
import NineSeparatedSubsetSums.Adaptive145Third140Leaves24
import NineSeparatedSubsetSums.Adaptive145Third140Leaves9
import NineSeparatedSubsetSums.Adaptive145Third140Leaves11
import NineSeparatedSubsetSums.Adaptive145Third140Leaves21
import NineSeparatedSubsetSums.Adaptive145Third140Leaves18
import NineSeparatedSubsetSums.Adaptive145Third140Leaves19
import NineSeparatedSubsetSums.Adaptive145Third140Leaves17
import NineSeparatedSubsetSums.Adaptive145Third140Leaves13
import NineSeparatedSubsetSums.Adaptive145Third140Leaves6
import NineSeparatedSubsetSums.Adaptive145Third140Joins0
import NineSeparatedSubsetSums.Adaptive145Third140Leaves14
import NineSeparatedSubsetSums.Adaptive145Third140Leaves20
import NineSeparatedSubsetSums.Adaptive145Third140Leaves12
import NineSeparatedSubsetSums.Adaptive145Third140Leaves3
import NineSeparatedSubsetSums.Adaptive145Third140Leaves8
import NineSeparatedSubsetSums.Adaptive145Third140Leaves2

namespace NineSeparatedSubsetSums

theorem adaptive145Third140Proof229 : runCachedNode 511 130597 Adaptive145Third140Node229 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130597 Adaptive145Third140Node229 = [101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 132, 133, 135, 138] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive145Third140Proof230
  · exact adaptive145Third140Proof231
  · exact adaptive145Third140Proof232
  · exact adaptive145Third140Proof233
  · exact adaptive145Third140Proof234
  · exact adaptive145Third140Proof235
  · exact adaptive145Third140Proof236
  · exact adaptive145Third140Proof237
  · exact adaptive145Third140Proof238
  · exact adaptive145Third140Proof239
  · exact adaptive145Third140Proof240
  · exact adaptive145Third140Proof241
  · exact adaptive145Third140Proof242
  · exact adaptive145Third140Proof243
  · exact adaptive145Third140Proof244
  · exact adaptive145Third140Proof245
  · exact adaptive145Third140Proof246
  · exact adaptive145Third140Proof247
  · exact adaptive145Third140Proof248
  · exact adaptive145Third140Proof249
  · exact adaptive145Third140Proof250
  · exact adaptive145Third140Proof251
  · exact adaptive145Third140Proof252
  · exact adaptive145Third140Proof253
  · exact adaptive145Third140Proof254
  · exact adaptive145Third140Proof255
  · exact adaptive145Third140Proof256
  · exact adaptive145Third140Proof257
  · exact adaptive145Third140Proof258
  · exact adaptive145Third140Proof259
  · exact adaptive145Third140Proof260
  · exact adaptive145Third140Proof261
  · exact adaptive145Third140Proof262
  · exact adaptive145Third140Proof263

#print axioms adaptive145Third140Proof229

theorem adaptive145Third140Proof0 : runCachedNode 511 130597 Adaptive145Third140Node0 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130597 Adaptive145Third140Node0 = [109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 132, 133, 134, 135, 136, 138, 139] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive145Third140Proof1
  · exact adaptive145Third140Proof2
  · exact adaptive145Third140Proof3
  · exact adaptive145Third140Proof4
  · exact adaptive145Third140Proof5
  · exact adaptive145Third140Proof6
  · exact adaptive145Third140Proof7
  · exact adaptive145Third140Proof8
  · exact adaptive145Third140Proof9
  · exact adaptive145Third140Proof10
  · exact adaptive145Third140Proof11
  · exact adaptive145Third140Proof12
  · exact adaptive145Third140Proof13
  · exact adaptive145Third140Proof14
  · exact adaptive145Third140Proof15
  · exact adaptive145Third140Proof16
  · exact adaptive145Third140Proof17
  · exact adaptive145Third140Proof18
  · exact adaptive145Third140Proof19
  · exact adaptive145Third140Proof20
  · exact adaptive145Third140Proof21
  · exact adaptive145Third140Proof22
  · exact adaptive145Third140Proof23
  · exact adaptive145Third140Proof49
  · exact adaptive145Third140Proof76
  · exact adaptive145Third140Proof104
  · exact adaptive145Third140Proof133
  · exact adaptive145Third140Proof164
  · exact adaptive145Third140Proof196
  · exact adaptive145Third140Proof229

#print axioms adaptive145Third140Proof0

end NineSeparatedSubsetSums
