import NineSeparatedSubsetSums.Adaptive145Third137State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third137Proof19 : runCachedNode 511 130164 Adaptive145Third137Node19 = false := by
  decide +kernel

#print axioms adaptive145Third137Proof19

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third137Proof120 : runCachedNode 511 130164 Adaptive145Third137Node120 = false := by
  decide +kernel

#print axioms adaptive145Third137Proof120

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third137Proof111 : runCachedNode 511 130164 Adaptive145Third137Node111 = false := by
  decide +kernel

#print axioms adaptive145Third137Proof111

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third137Proof96 : runCachedNode 511 130164 Adaptive145Third137Node96 = false := by
  decide +kernel

#print axioms adaptive145Third137Proof96

end NineSeparatedSubsetSums
