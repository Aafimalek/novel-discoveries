import NineSeparatedSubsetSums.Adaptive145Third143State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof229 : runCachedNode 511 131040 Adaptive145Third143Node229 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof229

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof417 : runCachedNode 511 131040 Adaptive145Third143Node417 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof417

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof60 : runCachedNode 511 131040 Adaptive145Third143Node60 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof60

end NineSeparatedSubsetSums
