import NineSeparatedSubsetSums.Adaptive145Third142State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof464 : runCachedNode 511 130865 Adaptive145Third142Node464 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof464

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof653 : runCachedNode 511 130865 Adaptive145Third142Node653 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof653

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof4 : runCachedNode 511 130865 Adaptive145Third142Node4 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof4

end NineSeparatedSubsetSums
