import NineSeparatedSubsetSums.Adaptive145Third138State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third138Proof98 : runCachedNode 511 130311 Adaptive145Third138Node98 = false := by
  decide +kernel

#print axioms adaptive145Third138Proof98

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third138Proof100 : runCachedNode 511 130311 Adaptive145Third138Node100 = false := by
  decide +kernel

#print axioms adaptive145Third138Proof100

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third138Proof46 : runCachedNode 511 130311 Adaptive145Third138Node46 = false := by
  decide +kernel

#print axioms adaptive145Third138Proof46

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third138Proof3 : runCachedNode 511 130311 Adaptive145Third138Node3 = false := by
  decide +kernel

#print axioms adaptive145Third138Proof3

end NineSeparatedSubsetSums
