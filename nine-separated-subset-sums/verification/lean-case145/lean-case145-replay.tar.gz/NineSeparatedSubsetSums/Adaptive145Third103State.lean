import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive145Third103Node0 : CachedSearchNode :=
  ⟨4, 102, computeCenteredMask [148,145,103], 396, 53538⟩

end NineSeparatedSubsetSums
