import NineSeparatedSubsetSums.Adaptive145Third138State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third138Proof161 : runCachedNode 511 130311 Adaptive145Third138Node161 = false := by
  decide +kernel

#print axioms adaptive145Third138Proof161

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third138Proof71 : runCachedNode 511 130311 Adaptive145Third138Node71 = false := by
  decide +kernel

#print axioms adaptive145Third138Proof71

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third138Proof53 : runCachedNode 511 130311 Adaptive145Third138Node53 = false := by
  decide +kernel

#print axioms adaptive145Third138Proof53

end NineSeparatedSubsetSums
