import NineSeparatedSubsetSums.Adaptive145Third130State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third130Proof13 : runCachedNode 511 128861 Adaptive145Third130Node13 = false := by
  decide +kernel

#print axioms adaptive145Third130Proof13

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third130Proof12 : runCachedNode 511 128861 Adaptive145Third130Node12 = false := by
  decide +kernel

#print axioms adaptive145Third130Proof12

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third130Proof10 : runCachedNode 511 128861 Adaptive145Third130Node10 = false := by
  decide +kernel

#print axioms adaptive145Third130Proof10

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third130Proof9 : runCachedNode 511 128861 Adaptive145Third130Node9 = false := by
  decide +kernel

#print axioms adaptive145Third130Proof9

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third130Proof8 : runCachedNode 511 128861 Adaptive145Third130Node8 = false := by
  decide +kernel

#print axioms adaptive145Third130Proof8

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third130Proof7 : runCachedNode 511 128861 Adaptive145Third130Node7 = false := by
  decide +kernel

#print axioms adaptive145Third130Proof7

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third130Proof6 : runCachedNode 511 128861 Adaptive145Third130Node6 = false := by
  decide +kernel

#print axioms adaptive145Third130Proof6

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third130Proof2 : runCachedNode 511 128861 Adaptive145Third130Node2 = false := by
  decide +kernel

#print axioms adaptive145Third130Proof2

end NineSeparatedSubsetSums
