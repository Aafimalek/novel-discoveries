import NineSeparatedSubsetSums.Adaptive145Third143State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof571 : runCachedNode 511 131040 Adaptive145Third143Node571 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof571

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof572 : runCachedNode 511 131040 Adaptive145Third143Node572 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof572

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof405 : runCachedNode 511 131040 Adaptive145Third143Node405 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof405

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof189 : runCachedNode 511 131040 Adaptive145Third143Node189 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof189

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof573 : runCachedNode 511 131040 Adaptive145Third143Node573 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof573

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof459 : runCachedNode 511 131040 Adaptive145Third143Node459 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof459

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof44 : runCachedNode 511 131040 Adaptive145Third143Node44 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof44

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof570 : runCachedNode 511 131040 Adaptive145Third143Node570 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof570

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof485 : runCachedNode 511 131040 Adaptive145Third143Node485 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof485

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof577 : runCachedNode 511 131040 Adaptive145Third143Node577 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof577

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof217 : runCachedNode 511 131040 Adaptive145Third143Node217 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof217

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof273 : runCachedNode 511 131040 Adaptive145Third143Node273 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof273

end NineSeparatedSubsetSums
