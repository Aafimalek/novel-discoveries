import NineSeparatedSubsetSums.Adaptive145Third116Joins0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint145Checked

namespace NineSeparatedSubsetSums


theorem adaptive145Third116 : NoDescendingTailAfterThird 145 116 :=
  noDescendingThirdTail_of_cached 145 116 112442 (fun t ht nd => max148_second145_fourPoint_moment_bound (116::t) (by simp [ht]) nd) adaptive145Third116Proof0

#print axioms adaptive145Third116

end NineSeparatedSubsetSums
