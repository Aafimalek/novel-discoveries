import NineSeparatedSubsetSums.Adaptive145Third133State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third133Proof21 : runCachedNode 511 129495 Adaptive145Third133Node21 = false := by
  decide +kernel

#print axioms adaptive145Third133Proof21

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third133Proof15 : runCachedNode 511 129495 Adaptive145Third133Node15 = false := by
  decide +kernel

#print axioms adaptive145Third133Proof15

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third133Proof36 : runCachedNode 511 129495 Adaptive145Third133Node36 = false := by
  decide +kernel

#print axioms adaptive145Third133Proof36

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third133Proof1 : runCachedNode 511 129495 Adaptive145Third133Node1 = false := by
  decide +kernel

#print axioms adaptive145Third133Proof1

end NineSeparatedSubsetSums
