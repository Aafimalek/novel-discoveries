import NineSeparatedSubsetSums.Adaptive145Third142State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof260 : runCachedNode 511 130865 Adaptive145Third142Node260 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof260

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof166 : runCachedNode 511 130865 Adaptive145Third142Node166 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof166

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof21 : runCachedNode 511 130865 Adaptive145Third142Node21 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof21

end NineSeparatedSubsetSums
