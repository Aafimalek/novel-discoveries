import NineSeparatedSubsetSums.Adaptive145Third142State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof251 : runCachedNode 511 130865 Adaptive145Third142Node251 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof251

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof807 : runCachedNode 511 130865 Adaptive145Third142Node807 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof807

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof161 : runCachedNode 511 130865 Adaptive145Third142Node161 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof161

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof621 : runCachedNode 511 130865 Adaptive145Third142Node621 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof621

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof278 : runCachedNode 511 130865 Adaptive145Third142Node278 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof278

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof946 : runCachedNode 511 130865 Adaptive145Third142Node946 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof946

end NineSeparatedSubsetSums
