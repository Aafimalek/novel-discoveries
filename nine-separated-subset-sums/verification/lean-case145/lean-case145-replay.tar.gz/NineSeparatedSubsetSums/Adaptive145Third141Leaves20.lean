import NineSeparatedSubsetSums.Adaptive145Third141State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third141Proof14 : runCachedNode 511 130740 Adaptive145Third141Node14 = false := by
  decide +kernel

#print axioms adaptive145Third141Proof14

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third141Proof298 : runCachedNode 511 130740 Adaptive145Third141Node298 = false := by
  decide +kernel

#print axioms adaptive145Third141Proof298

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third141Proof219 : runCachedNode 511 130740 Adaptive145Third141Node219 = false := by
  decide +kernel

#print axioms adaptive145Third141Proof219

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third141Proof160 : runCachedNode 511 130740 Adaptive145Third141Node160 = false := by
  decide +kernel

#print axioms adaptive145Third141Proof160

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third141Proof265 : runCachedNode 511 130740 Adaptive145Third141Node265 = false := by
  decide +kernel

#print axioms adaptive145Third141Proof265

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third141Proof102 : runCachedNode 511 130740 Adaptive145Third141Node102 = false := by
  decide +kernel

#print axioms adaptive145Third141Proof102

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third141Proof360 : runCachedNode 511 130740 Adaptive145Third141Node360 = false := by
  decide +kernel

#print axioms adaptive145Third141Proof360

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third141Proof232 : runCachedNode 511 130740 Adaptive145Third141Node232 = false := by
  decide +kernel

#print axioms adaptive145Third141Proof232

end NineSeparatedSubsetSums
