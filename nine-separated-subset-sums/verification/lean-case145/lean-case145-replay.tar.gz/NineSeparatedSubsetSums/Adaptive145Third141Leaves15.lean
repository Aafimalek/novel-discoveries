import NineSeparatedSubsetSums.Adaptive145Third141State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third141Proof373 : runCachedNode 511 130740 Adaptive145Third141Node373 = false := by
  decide +kernel

#print axioms adaptive145Third141Proof373

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third141Proof131 : runCachedNode 511 130740 Adaptive145Third141Node131 = false := by
  decide +kernel

#print axioms adaptive145Third141Proof131

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third141Proof371 : runCachedNode 511 130740 Adaptive145Third141Node371 = false := by
  decide +kernel

#print axioms adaptive145Third141Proof371

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third141Proof48 : runCachedNode 511 130740 Adaptive145Third141Node48 = false := by
  decide +kernel

#print axioms adaptive145Third141Proof48

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third141Proof56 : runCachedNode 511 130740 Adaptive145Third141Node56 = false := by
  decide +kernel

#print axioms adaptive145Third141Proof56

end NineSeparatedSubsetSums
