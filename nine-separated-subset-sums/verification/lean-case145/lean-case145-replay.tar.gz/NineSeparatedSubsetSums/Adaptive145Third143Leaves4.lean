import NineSeparatedSubsetSums.Adaptive145Third143State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof598 : runCachedNode 511 131040 Adaptive145Third143Node598 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof598

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof590 : runCachedNode 511 131040 Adaptive145Third143Node590 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof590

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof2 : runCachedNode 511 131040 Adaptive145Third143Node2 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof2

end NineSeparatedSubsetSums
