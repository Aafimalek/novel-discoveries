import NineSeparatedSubsetSums.Adaptive145Third140State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third140Proof195 : runCachedNode 511 130597 Adaptive145Third140Node195 = false := by
  decide +kernel

#print axioms adaptive145Third140Proof195

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third140Proof161 : runCachedNode 511 130597 Adaptive145Third140Node161 = false := by
  decide +kernel

#print axioms adaptive145Third140Proof161

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third140Proof39 : runCachedNode 511 130597 Adaptive145Third140Node39 = false := by
  decide +kernel

#print axioms adaptive145Third140Proof39

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third140Proof230 : runCachedNode 511 130597 Adaptive145Third140Node230 = false := by
  decide +kernel

#print axioms adaptive145Third140Proof230

end NineSeparatedSubsetSums
