import NineSeparatedSubsetSums.Adaptive145Third144State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third144Proof589 : runCachedNode 511 131183 Adaptive145Third144Node589 = false := by
  decide +kernel

#print axioms adaptive145Third144Proof589

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third144Proof18 : runCachedNode 511 131183 Adaptive145Third144Node18 = false := by
  decide +kernel

#print axioms adaptive145Third144Proof18

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third144Proof72 : runCachedNode 511 131183 Adaptive145Third144Node72 = false := by
  decide +kernel

#print axioms adaptive145Third144Proof72

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third144Proof80 : runCachedNode 511 131183 Adaptive145Third144Node80 = false := by
  decide +kernel

#print axioms adaptive145Third144Proof80

end NineSeparatedSubsetSums
