import NineSeparatedSubsetSums.Adaptive145Third144State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third144Proof331 : runCachedNode 511 131183 Adaptive145Third144Node331 = false := by
  decide +kernel

#print axioms adaptive145Third144Proof331

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third144Proof586 : runCachedNode 511 131183 Adaptive145Third144Node586 = false := by
  decide +kernel

#print axioms adaptive145Third144Proof586

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third144Proof162 : runCachedNode 511 131183 Adaptive145Third144Node162 = false := by
  decide +kernel

#print axioms adaptive145Third144Proof162

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third144Proof487 : runCachedNode 511 131183 Adaptive145Third144Node487 = false := by
  decide +kernel

#print axioms adaptive145Third144Proof487

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third144Proof115 : runCachedNode 511 131183 Adaptive145Third144Node115 = false := by
  decide +kernel

#print axioms adaptive145Third144Proof115

end NineSeparatedSubsetSums
