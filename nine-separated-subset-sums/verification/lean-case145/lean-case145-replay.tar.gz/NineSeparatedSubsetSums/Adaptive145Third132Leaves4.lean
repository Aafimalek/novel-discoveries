import NineSeparatedSubsetSums.Adaptive145Third132State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third132Proof8 : runCachedNode 511 129338 Adaptive145Third132Node8 = false := by
  decide +kernel

#print axioms adaptive145Third132Proof8

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third132Proof6 : runCachedNode 511 129338 Adaptive145Third132Node6 = false := by
  decide +kernel

#print axioms adaptive145Third132Proof6

end NineSeparatedSubsetSums
