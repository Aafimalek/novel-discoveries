import NineSeparatedSubsetSums.Adaptive145Third143State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof419 : runCachedNode 511 131040 Adaptive145Third143Node419 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof419

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof245 : runCachedNode 511 131040 Adaptive145Third143Node245 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof245

end NineSeparatedSubsetSums
