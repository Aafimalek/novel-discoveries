import NineSeparatedSubsetSums.Adaptive145Third140State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third140Proof18 : runCachedNode 511 130597 Adaptive145Third140Node18 = false := by
  decide +kernel

#print axioms adaptive145Third140Proof18

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third140Proof261 : runCachedNode 511 130597 Adaptive145Third140Node261 = false := by
  decide +kernel

#print axioms adaptive145Third140Proof261

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third140Proof223 : runCachedNode 511 130597 Adaptive145Third140Node223 = false := by
  decide +kernel

#print axioms adaptive145Third140Proof223

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third140Proof58 : runCachedNode 511 130597 Adaptive145Third140Node58 = false := by
  decide +kernel

#print axioms adaptive145Third140Proof58

end NineSeparatedSubsetSums
