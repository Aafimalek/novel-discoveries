import NineSeparatedSubsetSums.Adaptive145Third138State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third138Proof20 : runCachedNode 511 130311 Adaptive145Third138Node20 = false := by
  decide +kernel

#print axioms adaptive145Third138Proof20

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third138Proof44 : runCachedNode 511 130311 Adaptive145Third138Node44 = false := by
  decide +kernel

#print axioms adaptive145Third138Proof44

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third138Proof85 : runCachedNode 511 130311 Adaptive145Third138Node85 = false := by
  decide +kernel

#print axioms adaptive145Third138Proof85

end NineSeparatedSubsetSums
