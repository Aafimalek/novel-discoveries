import NineSeparatedSubsetSums.Adaptive145Third144State
import NineSeparatedSubsetSums.Adaptive145Third144Leaves43
import NineSeparatedSubsetSums.Adaptive145Third144Leaves65
import NineSeparatedSubsetSums.Adaptive145Third144Leaves66
import NineSeparatedSubsetSums.Adaptive145Third144Leaves63
import NineSeparatedSubsetSums.Adaptive145Third144Leaves62
import NineSeparatedSubsetSums.Adaptive145Third144Leaves61
import NineSeparatedSubsetSums.Adaptive145Third144Leaves60
import NineSeparatedSubsetSums.Adaptive145Third144Leaves59
import NineSeparatedSubsetSums.Adaptive145Third144Leaves58
import NineSeparatedSubsetSums.Adaptive145Third144Leaves57
import NineSeparatedSubsetSums.Adaptive145Third144Leaves56
import NineSeparatedSubsetSums.Adaptive145Third144Leaves55
import NineSeparatedSubsetSums.Adaptive145Third144Leaves54
import NineSeparatedSubsetSums.Adaptive145Third144Leaves53
import NineSeparatedSubsetSums.Adaptive145Third144Leaves52
import NineSeparatedSubsetSums.Adaptive145Third144Leaves48
import NineSeparatedSubsetSums.Adaptive145Third144Leaves49
import NineSeparatedSubsetSums.Adaptive145Third144Leaves46
import NineSeparatedSubsetSums.Adaptive145Third144Leaves35
import NineSeparatedSubsetSums.Adaptive145Third144Leaves38
import NineSeparatedSubsetSums.Adaptive145Third144Leaves33
import NineSeparatedSubsetSums.Adaptive145Third144Leaves28
import NineSeparatedSubsetSums.Adaptive145Third144Leaves20
import NineSeparatedSubsetSums.Adaptive145Third144Leaves6
import NineSeparatedSubsetSums.Adaptive145Third144Leaves64
import NineSeparatedSubsetSums.Adaptive145Third144Leaves50
import NineSeparatedSubsetSums.Adaptive145Third144Leaves44
import NineSeparatedSubsetSums.Adaptive145Third144Leaves51
import NineSeparatedSubsetSums.Adaptive145Third144Leaves39
import NineSeparatedSubsetSums.Adaptive145Third144Leaves47
import NineSeparatedSubsetSums.Adaptive145Third144Leaves24
import NineSeparatedSubsetSums.Adaptive145Third144Leaves26
import NineSeparatedSubsetSums.Adaptive145Third144Leaves41
import NineSeparatedSubsetSums.Adaptive145Third144Leaves42
import NineSeparatedSubsetSums.Adaptive145Third144Leaves40
import NineSeparatedSubsetSums.Adaptive145Third144Leaves36
import NineSeparatedSubsetSums.Adaptive145Third144Leaves31
import NineSeparatedSubsetSums.Adaptive145Third144Leaves21
import NineSeparatedSubsetSums.Adaptive145Third144Leaves15
import NineSeparatedSubsetSums.Adaptive145Third144Leaves19
import NineSeparatedSubsetSums.Adaptive145Third144Leaves14
import NineSeparatedSubsetSums.Adaptive145Third144Leaves3
import NineSeparatedSubsetSums.Adaptive145Third144Leaves2
import NineSeparatedSubsetSums.Adaptive145Third144Leaves67
import NineSeparatedSubsetSums.Adaptive145Third144Leaves45
import NineSeparatedSubsetSums.Adaptive145Third144Leaves25
import NineSeparatedSubsetSums.Adaptive145Third144Leaves22
import NineSeparatedSubsetSums.Adaptive145Third144Leaves18
import NineSeparatedSubsetSums.Adaptive145Third144Leaves34
import NineSeparatedSubsetSums.Adaptive145Third144Leaves7
import NineSeparatedSubsetSums.Adaptive145Third144Leaves30
import NineSeparatedSubsetSums.Adaptive145Third144Leaves23
import NineSeparatedSubsetSums.Adaptive145Third144Leaves27
import NineSeparatedSubsetSums.Adaptive145Third144Leaves12
import NineSeparatedSubsetSums.Adaptive145Third144Leaves0

namespace NineSeparatedSubsetSums

theorem adaptive145Third144Proof267 : runCachedNode 511 131183 Adaptive145Third144Node267 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 131183 Adaptive145Third144Node267 = [101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 132, 133, 134, 137] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive145Third144Proof268
  · exact adaptive145Third144Proof269
  · exact adaptive145Third144Proof270
  · exact adaptive145Third144Proof271
  · exact adaptive145Third144Proof272
  · exact adaptive145Third144Proof273
  · exact adaptive145Third144Proof274
  · exact adaptive145Third144Proof275
  · exact adaptive145Third144Proof276
  · exact adaptive145Third144Proof277
  · exact adaptive145Third144Proof278
  · exact adaptive145Third144Proof279
  · exact adaptive145Third144Proof280
  · exact adaptive145Third144Proof281
  · exact adaptive145Third144Proof282
  · exact adaptive145Third144Proof283
  · exact adaptive145Third144Proof284
  · exact adaptive145Third144Proof285
  · exact adaptive145Third144Proof286
  · exact adaptive145Third144Proof287
  · exact adaptive145Third144Proof288
  · exact adaptive145Third144Proof289
  · exact adaptive145Third144Proof290
  · exact adaptive145Third144Proof291
  · exact adaptive145Third144Proof292
  · exact adaptive145Third144Proof293
  · exact adaptive145Third144Proof294
  · exact adaptive145Third144Proof295
  · exact adaptive145Third144Proof296
  · exact adaptive145Third144Proof297
  · exact adaptive145Third144Proof298
  · exact adaptive145Third144Proof299
  · exact adaptive145Third144Proof300
  · exact adaptive145Third144Proof301
  · exact adaptive145Third144Proof302

#print axioms adaptive145Third144Proof267

theorem adaptive145Third144Proof336 : runCachedNode 511 131183 Adaptive145Third144Node336 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 131183 Adaptive145Third144Node336 = [89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 126, 130] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive145Third144Proof337
  · exact adaptive145Third144Proof338
  · exact adaptive145Third144Proof339
  · exact adaptive145Third144Proof340
  · exact adaptive145Third144Proof341
  · exact adaptive145Third144Proof342
  · exact adaptive145Third144Proof343
  · exact adaptive145Third144Proof344
  · exact adaptive145Third144Proof345
  · exact adaptive145Third144Proof346
  · exact adaptive145Third144Proof347
  · exact adaptive145Third144Proof348
  · exact adaptive145Third144Proof349
  · exact adaptive145Third144Proof350
  · exact adaptive145Third144Proof351
  · exact adaptive145Third144Proof352
  · exact adaptive145Third144Proof353
  · exact adaptive145Third144Proof354
  · exact adaptive145Third144Proof355
  · exact adaptive145Third144Proof356
  · exact adaptive145Third144Proof357
  · exact adaptive145Third144Proof358
  · exact adaptive145Third144Proof359
  · exact adaptive145Third144Proof360
  · exact adaptive145Third144Proof361
  · exact adaptive145Third144Proof362
  · exact adaptive145Third144Proof363
  · exact adaptive145Third144Proof364
  · exact adaptive145Third144Proof365
  · exact adaptive145Third144Proof366
  · exact adaptive145Third144Proof367
  · exact adaptive145Third144Proof368
  · exact adaptive145Third144Proof369
  · exact adaptive145Third144Proof370
  · exact adaptive145Third144Proof371
  · exact adaptive145Third144Proof372

#print axioms adaptive145Third144Proof336

theorem adaptive145Third144Proof375 : runCachedNode 511 131183 Adaptive145Third144Node375 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 131183 Adaptive145Third144Node375 = [88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 129, 133] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive145Third144Proof376
  · exact adaptive145Third144Proof377
  · exact adaptive145Third144Proof378
  · exact adaptive145Third144Proof379
  · exact adaptive145Third144Proof380
  · exact adaptive145Third144Proof381
  · exact adaptive145Third144Proof382
  · exact adaptive145Third144Proof383
  · exact adaptive145Third144Proof384
  · exact adaptive145Third144Proof385
  · exact adaptive145Third144Proof386
  · exact adaptive145Third144Proof387
  · exact adaptive145Third144Proof388
  · exact adaptive145Third144Proof389
  · exact adaptive145Third144Proof390
  · exact adaptive145Third144Proof391
  · exact adaptive145Third144Proof392
  · exact adaptive145Third144Proof393
  · exact adaptive145Third144Proof394
  · exact adaptive145Third144Proof395
  · exact adaptive145Third144Proof396
  · exact adaptive145Third144Proof397
  · exact adaptive145Third144Proof398
  · exact adaptive145Third144Proof399
  · exact adaptive145Third144Proof400
  · exact adaptive145Third144Proof401
  · exact adaptive145Third144Proof402
  · exact adaptive145Third144Proof403
  · exact adaptive145Third144Proof404
  · exact adaptive145Third144Proof405
  · exact adaptive145Third144Proof406
  · exact adaptive145Third144Proof407
  · exact adaptive145Third144Proof408
  · exact adaptive145Third144Proof409
  · exact adaptive145Third144Proof410
  · exact adaptive145Third144Proof411
  · exact adaptive145Third144Proof412
  · exact adaptive145Third144Proof413
  · exact adaptive145Third144Proof414
  · exact adaptive145Third144Proof415

#print axioms adaptive145Third144Proof375

theorem adaptive145Third144Proof416 : runCachedNode 511 131183 Adaptive145Third144Node416 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 131183 Adaptive145Third144Node416 = [87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 132] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive145Third144Proof417
  · exact adaptive145Third144Proof418
  · exact adaptive145Third144Proof419
  · exact adaptive145Third144Proof420
  · exact adaptive145Third144Proof421
  · exact adaptive145Third144Proof422
  · exact adaptive145Third144Proof423
  · exact adaptive145Third144Proof424
  · exact adaptive145Third144Proof425
  · exact adaptive145Third144Proof426
  · exact adaptive145Third144Proof427
  · exact adaptive145Third144Proof428
  · exact adaptive145Third144Proof429
  · exact adaptive145Third144Proof430
  · exact adaptive145Third144Proof431
  · exact adaptive145Third144Proof432
  · exact adaptive145Third144Proof433
  · exact adaptive145Third144Proof434
  · exact adaptive145Third144Proof435
  · exact adaptive145Third144Proof436
  · exact adaptive145Third144Proof437
  · exact adaptive145Third144Proof438
  · exact adaptive145Third144Proof439
  · exact adaptive145Third144Proof440
  · exact adaptive145Third144Proof441
  · exact adaptive145Third144Proof442
  · exact adaptive145Third144Proof443
  · exact adaptive145Third144Proof444
  · exact adaptive145Third144Proof445
  · exact adaptive145Third144Proof446
  · exact adaptive145Third144Proof447
  · exact adaptive145Third144Proof448
  · exact adaptive145Third144Proof449
  · exact adaptive145Third144Proof450
  · exact adaptive145Third144Proof451
  · exact adaptive145Third144Proof452
  · exact adaptive145Third144Proof453
  · exact adaptive145Third144Proof454
  · exact adaptive145Third144Proof455
  · exact adaptive145Third144Proof456
  · exact adaptive145Third144Proof457
  · exact adaptive145Third144Proof458
  · exact adaptive145Third144Proof459

#print axioms adaptive145Third144Proof416

theorem adaptive145Third144Proof303 : runCachedNode 511 131183 Adaptive145Third144Node303 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 131183 Adaptive145Third144Node303 = [100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 132, 133, 134, 135, 138] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive145Third144Proof304
  · exact adaptive145Third144Proof305
  · exact adaptive145Third144Proof306
  · exact adaptive145Third144Proof307
  · exact adaptive145Third144Proof308
  · exact adaptive145Third144Proof309
  · exact adaptive145Third144Proof310
  · exact adaptive145Third144Proof311
  · exact adaptive145Third144Proof312
  · exact adaptive145Third144Proof313
  · exact adaptive145Third144Proof314
  · exact adaptive145Third144Proof315
  · exact adaptive145Third144Proof316
  · exact adaptive145Third144Proof317
  · exact adaptive145Third144Proof318
  · exact adaptive145Third144Proof319
  · exact adaptive145Third144Proof320
  · exact adaptive145Third144Proof321
  · exact adaptive145Third144Proof322
  · exact adaptive145Third144Proof323
  · exact adaptive145Third144Proof324
  · exact adaptive145Third144Proof325
  · exact adaptive145Third144Proof326
  · exact adaptive145Third144Proof327
  · exact adaptive145Third144Proof328
  · exact adaptive145Third144Proof329
  · exact adaptive145Third144Proof330
  · exact adaptive145Third144Proof331
  · exact adaptive145Third144Proof332
  · exact adaptive145Third144Proof333
  · exact adaptive145Third144Proof334
  · exact adaptive145Third144Proof335
  · exact adaptive145Third144Proof336
  · exact adaptive145Third144Proof373
  · exact adaptive145Third144Proof374
  · exact adaptive145Third144Proof375
  · exact adaptive145Third144Proof416

#print axioms adaptive145Third144Proof303

theorem adaptive145Third144Proof498 : runCachedNode 511 131183 Adaptive145Third144Node498 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 131183 Adaptive145Third144Node498 = [87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive145Third144Proof499
  · exact adaptive145Third144Proof500
  · exact adaptive145Third144Proof501
  · exact adaptive145Third144Proof502
  · exact adaptive145Third144Proof503
  · exact adaptive145Third144Proof504
  · exact adaptive145Third144Proof505
  · exact adaptive145Third144Proof506
  · exact adaptive145Third144Proof507
  · exact adaptive145Third144Proof508
  · exact adaptive145Third144Proof509
  · exact adaptive145Third144Proof510
  · exact adaptive145Third144Proof511
  · exact adaptive145Third144Proof512
  · exact adaptive145Third144Proof513
  · exact adaptive145Third144Proof514
  · exact adaptive145Third144Proof515
  · exact adaptive145Third144Proof516
  · exact adaptive145Third144Proof517
  · exact adaptive145Third144Proof518
  · exact adaptive145Third144Proof519
  · exact adaptive145Third144Proof520
  · exact adaptive145Third144Proof521
  · exact adaptive145Third144Proof522
  · exact adaptive145Third144Proof523
  · exact adaptive145Third144Proof524
  · exact adaptive145Third144Proof525
  · exact adaptive145Third144Proof526
  · exact adaptive145Third144Proof527
  · exact adaptive145Third144Proof528
  · exact adaptive145Third144Proof529
  · exact adaptive145Third144Proof530
  · exact adaptive145Third144Proof531
  · exact adaptive145Third144Proof532
  · exact adaptive145Third144Proof533
  · exact adaptive145Third144Proof534
  · exact adaptive145Third144Proof535
  · exact adaptive145Third144Proof536
  · exact adaptive145Third144Proof537
  · exact adaptive145Third144Proof538
  · exact adaptive145Third144Proof539
  · exact adaptive145Third144Proof540
  · exact adaptive145Third144Proof541

#print axioms adaptive145Third144Proof498

theorem adaptive145Third144Proof542 : runCachedNode 511 131183 Adaptive145Third144Node542 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 131183 Adaptive145Third144Node542 = [85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 132] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive145Third144Proof543
  · exact adaptive145Third144Proof544
  · exact adaptive145Third144Proof545
  · exact adaptive145Third144Proof546
  · exact adaptive145Third144Proof547
  · exact adaptive145Third144Proof548
  · exact adaptive145Third144Proof549
  · exact adaptive145Third144Proof550
  · exact adaptive145Third144Proof551
  · exact adaptive145Third144Proof552
  · exact adaptive145Third144Proof553
  · exact adaptive145Third144Proof554
  · exact adaptive145Third144Proof555
  · exact adaptive145Third144Proof556
  · exact adaptive145Third144Proof557
  · exact adaptive145Third144Proof558
  · exact adaptive145Third144Proof559
  · exact adaptive145Third144Proof560
  · exact adaptive145Third144Proof561
  · exact adaptive145Third144Proof562
  · exact adaptive145Third144Proof563
  · exact adaptive145Third144Proof564
  · exact adaptive145Third144Proof565
  · exact adaptive145Third144Proof566
  · exact adaptive145Third144Proof567
  · exact adaptive145Third144Proof568
  · exact adaptive145Third144Proof569
  · exact adaptive145Third144Proof570
  · exact adaptive145Third144Proof571
  · exact adaptive145Third144Proof572
  · exact adaptive145Third144Proof573
  · exact adaptive145Third144Proof574
  · exact adaptive145Third144Proof575
  · exact adaptive145Third144Proof576
  · exact adaptive145Third144Proof577
  · exact adaptive145Third144Proof578
  · exact adaptive145Third144Proof579
  · exact adaptive145Third144Proof580
  · exact adaptive145Third144Proof581
  · exact adaptive145Third144Proof582
  · exact adaptive145Third144Proof583
  · exact adaptive145Third144Proof584
  · exact adaptive145Third144Proof585
  · exact adaptive145Third144Proof586
  · exact adaptive145Third144Proof587
  · exact adaptive145Third144Proof588
  · exact adaptive145Third144Proof589
  · exact adaptive145Third144Proof590

#print axioms adaptive145Third144Proof542

theorem adaptive145Third144Proof460 : runCachedNode 511 131183 Adaptive145Third144Node460 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 131183 Adaptive145Third144Node460 = [100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 132, 133, 134, 135, 136, 137, 140] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive145Third144Proof461
  · exact adaptive145Third144Proof462
  · exact adaptive145Third144Proof463
  · exact adaptive145Third144Proof464
  · exact adaptive145Third144Proof465
  · exact adaptive145Third144Proof466
  · exact adaptive145Third144Proof467
  · exact adaptive145Third144Proof468
  · exact adaptive145Third144Proof469
  · exact adaptive145Third144Proof470
  · exact adaptive145Third144Proof471
  · exact adaptive145Third144Proof472
  · exact adaptive145Third144Proof473
  · exact adaptive145Third144Proof474
  · exact adaptive145Third144Proof475
  · exact adaptive145Third144Proof476
  · exact adaptive145Third144Proof477
  · exact adaptive145Third144Proof478
  · exact adaptive145Third144Proof479
  · exact adaptive145Third144Proof480
  · exact adaptive145Third144Proof481
  · exact adaptive145Third144Proof482
  · exact adaptive145Third144Proof483
  · exact adaptive145Third144Proof484
  · exact adaptive145Third144Proof485
  · exact adaptive145Third144Proof486
  · exact adaptive145Third144Proof487
  · exact adaptive145Third144Proof488
  · exact adaptive145Third144Proof489
  · exact adaptive145Third144Proof490
  · exact adaptive145Third144Proof491
  · exact adaptive145Third144Proof492
  · exact adaptive145Third144Proof493
  · exact adaptive145Third144Proof494
  · exact adaptive145Third144Proof495
  · exact adaptive145Third144Proof496
  · exact adaptive145Third144Proof497
  · exact adaptive145Third144Proof498
  · exact adaptive145Third144Proof542

#print axioms adaptive145Third144Proof460

end NineSeparatedSubsetSums
