import NineSeparatedSubsetSums.Adaptive145Third132State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third132Proof16 : runCachedNode 511 129338 Adaptive145Third132Node16 = false := by
  decide +kernel

#print axioms adaptive145Third132Proof16

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third132Proof15 : runCachedNode 511 129338 Adaptive145Third132Node15 = false := by
  decide +kernel

#print axioms adaptive145Third132Proof15

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third132Proof14 : runCachedNode 511 129338 Adaptive145Third132Node14 = false := by
  decide +kernel

#print axioms adaptive145Third132Proof14

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third132Proof13 : runCachedNode 511 129338 Adaptive145Third132Node13 = false := by
  decide +kernel

#print axioms adaptive145Third132Proof13

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third132Proof10 : runCachedNode 511 129338 Adaptive145Third132Node10 = false := by
  decide +kernel

#print axioms adaptive145Third132Proof10

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third132Proof9 : runCachedNode 511 129338 Adaptive145Third132Node9 = false := by
  decide +kernel

#print axioms adaptive145Third132Proof9

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third132Proof7 : runCachedNode 511 129338 Adaptive145Third132Node7 = false := by
  decide +kernel

#print axioms adaptive145Third132Proof7

end NineSeparatedSubsetSums
