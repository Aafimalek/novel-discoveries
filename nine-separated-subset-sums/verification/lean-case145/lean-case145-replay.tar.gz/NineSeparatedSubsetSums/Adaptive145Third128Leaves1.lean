import NineSeparatedSubsetSums.Adaptive145Third128State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third128Proof14 : runCachedNode 511 128446 Adaptive145Third128Node14 = false := by
  decide +kernel

#print axioms adaptive145Third128Proof14

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third128Proof12 : runCachedNode 511 128446 Adaptive145Third128Node12 = false := by
  decide +kernel

#print axioms adaptive145Third128Proof12

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third128Proof11 : runCachedNode 511 128446 Adaptive145Third128Node11 = false := by
  decide +kernel

#print axioms adaptive145Third128Proof11

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third128Proof10 : runCachedNode 511 128446 Adaptive145Third128Node10 = false := by
  decide +kernel

#print axioms adaptive145Third128Proof10

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third128Proof8 : runCachedNode 511 128446 Adaptive145Third128Node8 = false := by
  decide +kernel

#print axioms adaptive145Third128Proof8

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third128Proof7 : runCachedNode 511 128446 Adaptive145Third128Node7 = false := by
  decide +kernel

#print axioms adaptive145Third128Proof7

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third128Proof6 : runCachedNode 511 128446 Adaptive145Third128Node6 = false := by
  decide +kernel

#print axioms adaptive145Third128Proof6

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third128Proof5 : runCachedNode 511 128446 Adaptive145Third128Node5 = false := by
  decide +kernel

#print axioms adaptive145Third128Proof5

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third128Proof4 : runCachedNode 511 128446 Adaptive145Third128Node4 = false := by
  decide +kernel

#print axioms adaptive145Third128Proof4

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third128Proof3 : runCachedNode 511 128446 Adaptive145Third128Node3 = false := by
  decide +kernel

#print axioms adaptive145Third128Proof3

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third128Proof2 : runCachedNode 511 128446 Adaptive145Third128Node2 = false := by
  decide +kernel

#print axioms adaptive145Third128Proof2

end NineSeparatedSubsetSums
