import NineSeparatedSubsetSums.Adaptive145Third131State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third131Proof9 : runCachedNode 511 129127 Adaptive145Third131Node9 = false := by
  decide +kernel

#print axioms adaptive145Third131Proof9

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third131Proof8 : runCachedNode 511 129127 Adaptive145Third131Node8 = false := by
  decide +kernel

#print axioms adaptive145Third131Proof8

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third131Proof6 : runCachedNode 511 129127 Adaptive145Third131Node6 = false := by
  decide +kernel

#print axioms adaptive145Third131Proof6

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third131Proof4 : runCachedNode 511 129127 Adaptive145Third131Node4 = false := by
  decide +kernel

#print axioms adaptive145Third131Proof4

end NineSeparatedSubsetSums
