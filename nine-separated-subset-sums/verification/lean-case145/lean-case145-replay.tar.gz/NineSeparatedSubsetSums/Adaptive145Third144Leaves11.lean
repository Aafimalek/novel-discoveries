import NineSeparatedSubsetSums.Adaptive145Third144State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third144Proof20 : runCachedNode 511 131183 Adaptive145Third144Node20 = false := by
  decide +kernel

#print axioms adaptive145Third144Proof20

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third144Proof619 : runCachedNode 511 131183 Adaptive145Third144Node619 = false := by
  decide +kernel

#print axioms adaptive145Third144Proof619

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third144Proof27 : runCachedNode 511 131183 Adaptive145Third144Node27 = false := by
  decide +kernel

#print axioms adaptive145Third144Proof27

end NineSeparatedSubsetSums
