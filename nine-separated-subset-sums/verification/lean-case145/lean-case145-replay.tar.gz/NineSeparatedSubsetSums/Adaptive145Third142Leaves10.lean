import NineSeparatedSubsetSums.Adaptive145Third142State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof816 : runCachedNode 511 130865 Adaptive145Third142Node816 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof816

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof162 : runCachedNode 511 130865 Adaptive145Third142Node162 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof162

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof323 : runCachedNode 511 130865 Adaptive145Third142Node323 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof323

end NineSeparatedSubsetSums
