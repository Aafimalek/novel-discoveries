import NineSeparatedSubsetSums.Adaptive145Third139State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third139Proof159 : runCachedNode 511 130465 Adaptive145Third139Node159 = false := by
  decide +kernel

#print axioms adaptive145Third139Proof159

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third139Proof19 : runCachedNode 511 130465 Adaptive145Third139Node19 = false := by
  decide +kernel

#print axioms adaptive145Third139Proof19

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third139Proof81 : runCachedNode 511 130465 Adaptive145Third139Node81 = false := by
  decide +kernel

#print axioms adaptive145Third139Proof81

end NineSeparatedSubsetSums
