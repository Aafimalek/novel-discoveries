import NineSeparatedSubsetSums.Adaptive145Third139State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third139Proof71 : runCachedNode 511 130465 Adaptive145Third139Node71 = false := by
  decide +kernel

#print axioms adaptive145Third139Proof71

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third139Proof189 : runCachedNode 511 130465 Adaptive145Third139Node189 = false := by
  decide +kernel

#print axioms adaptive145Third139Proof189

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third139Proof221 : runCachedNode 511 130465 Adaptive145Third139Node221 = false := by
  decide +kernel

#print axioms adaptive145Third139Proof221

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third139Proof96 : runCachedNode 511 130465 Adaptive145Third139Node96 = false := by
  decide +kernel

#print axioms adaptive145Third139Proof96

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third139Proof220 : runCachedNode 511 130465 Adaptive145Third139Node220 = false := by
  decide +kernel

#print axioms adaptive145Third139Proof220

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third139Proof140 : runCachedNode 511 130465 Adaptive145Third139Node140 = false := by
  decide +kernel

#print axioms adaptive145Third139Proof140

end NineSeparatedSubsetSums
