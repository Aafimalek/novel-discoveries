import NineSeparatedSubsetSums.Adaptive145Third106Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint145Checked

namespace NineSeparatedSubsetSums


theorem adaptive145Third106 : NoDescendingTailAfterThird 145 106 :=
  noDescendingThirdTail_of_cached 145 106 112442 (fun t ht nd => max148_second145_fourPoint_moment_bound (106::t) (by simp [ht]) nd) adaptive145Third106Proof0

#print axioms adaptive145Third106

end NineSeparatedSubsetSums
