import NineSeparatedSubsetSums.Adaptive145Third130State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third130Proof17 : runCachedNode 511 128861 Adaptive145Third130Node17 = false := by
  decide +kernel

#print axioms adaptive145Third130Proof17

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third130Proof15 : runCachedNode 511 128861 Adaptive145Third130Node15 = false := by
  decide +kernel

#print axioms adaptive145Third130Proof15

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third130Proof16 : runCachedNode 511 128861 Adaptive145Third130Node16 = false := by
  decide +kernel

#print axioms adaptive145Third130Proof16

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third130Proof14 : runCachedNode 511 128861 Adaptive145Third130Node14 = false := by
  decide +kernel

#print axioms adaptive145Third130Proof14

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third130Proof5 : runCachedNode 511 128861 Adaptive145Third130Node5 = false := by
  decide +kernel

#print axioms adaptive145Third130Proof5

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third130Proof4 : runCachedNode 511 128861 Adaptive145Third130Node4 = false := by
  decide +kernel

#print axioms adaptive145Third130Proof4

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third130Proof1 : runCachedNode 511 128861 Adaptive145Third130Node1 = false := by
  decide +kernel

#print axioms adaptive145Third130Proof1

end NineSeparatedSubsetSums
