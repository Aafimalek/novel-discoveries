import NineSeparatedSubsetSums.Adaptive145Third144State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third144Proof262 : runCachedNode 511 131183 Adaptive145Third144Node262 = false := by
  decide +kernel

#print axioms adaptive145Third144Proof262

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third144Proof415 : runCachedNode 511 131183 Adaptive145Third144Node415 = false := by
  decide +kernel

#print axioms adaptive145Third144Proof415

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third144Proof75 : runCachedNode 511 131183 Adaptive145Third144Node75 = false := by
  decide +kernel

#print axioms adaptive145Third144Proof75

end NineSeparatedSubsetSums
