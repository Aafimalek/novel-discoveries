import NineSeparatedSubsetSums.Adaptive145Third122State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third122Proof0 : runCachedNode 511 126804 Adaptive145Third122Node0 = false := by
  decide +kernel

#print axioms adaptive145Third122Proof0

end NineSeparatedSubsetSums
