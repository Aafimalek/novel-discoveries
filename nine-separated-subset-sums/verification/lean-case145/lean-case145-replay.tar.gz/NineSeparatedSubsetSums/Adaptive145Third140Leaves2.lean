import NineSeparatedSubsetSums.Adaptive145Third140State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third140Proof21 : runCachedNode 511 130597 Adaptive145Third140Node21 = false := by
  decide +kernel

#print axioms adaptive145Third140Proof21

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third140Proof47 : runCachedNode 511 130597 Adaptive145Third140Node47 = false := by
  decide +kernel

#print axioms adaptive145Third140Proof47

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third140Proof165 : runCachedNode 511 130597 Adaptive145Third140Node165 = false := by
  decide +kernel

#print axioms adaptive145Third140Proof165

end NineSeparatedSubsetSums
