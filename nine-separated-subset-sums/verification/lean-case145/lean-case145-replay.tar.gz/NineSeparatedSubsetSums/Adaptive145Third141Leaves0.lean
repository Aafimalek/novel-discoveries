import NineSeparatedSubsetSums.Adaptive145Third141State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third141Proof164 : runCachedNode 511 130740 Adaptive145Third141Node164 = false := by
  decide +kernel

#print axioms adaptive145Third141Proof164

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third141Proof15 : runCachedNode 511 130740 Adaptive145Third141Node15 = false := by
  decide +kernel

#print axioms adaptive145Third141Proof15

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third141Proof83 : runCachedNode 511 130740 Adaptive145Third141Node83 = false := by
  decide +kernel

#print axioms adaptive145Third141Proof83

end NineSeparatedSubsetSums
