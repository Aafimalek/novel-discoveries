import NineSeparatedSubsetSums.Adaptive145Third142State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof259 : runCachedNode 511 130865 Adaptive145Third142Node259 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof259

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof656 : runCachedNode 511 130865 Adaptive145Third142Node656 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof656

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof337 : runCachedNode 511 130865 Adaptive145Third142Node337 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof337

end NineSeparatedSubsetSums
