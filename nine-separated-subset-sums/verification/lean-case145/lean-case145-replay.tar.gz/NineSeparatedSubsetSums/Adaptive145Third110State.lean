import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive145Third110Node0 : CachedSearchNode :=
  ⟨4, 109, computeCenteredMask [148,145,110], 403, 55029⟩

end NineSeparatedSubsetSums
