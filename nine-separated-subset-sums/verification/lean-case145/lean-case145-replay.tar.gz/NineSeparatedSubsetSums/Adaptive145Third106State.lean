import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive145Third106Node0 : CachedSearchNode :=
  ⟨4, 105, computeCenteredMask [148,145,106], 399, 54165⟩

end NineSeparatedSubsetSums
