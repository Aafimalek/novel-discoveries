import NineSeparatedSubsetSums.Adaptive145Third142State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof645 : runCachedNode 511 130865 Adaptive145Third142Node645 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof645

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof111 : runCachedNode 511 130865 Adaptive145Third142Node111 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof111

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof217 : runCachedNode 511 130865 Adaptive145Third142Node217 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof217

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof81 : runCachedNode 511 130865 Adaptive145Third142Node81 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof81

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof504 : runCachedNode 511 130865 Adaptive145Third142Node504 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof504

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof110 : runCachedNode 511 130865 Adaptive145Third142Node110 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof110

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof579 : runCachedNode 511 130865 Adaptive145Third142Node579 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof579

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof35 : runCachedNode 511 130865 Adaptive145Third142Node35 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof35

end NineSeparatedSubsetSums
