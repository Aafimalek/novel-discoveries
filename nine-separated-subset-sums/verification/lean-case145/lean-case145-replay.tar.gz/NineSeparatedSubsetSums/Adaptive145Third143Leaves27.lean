import NineSeparatedSubsetSums.Adaptive145Third143State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof163 : runCachedNode 511 131040 Adaptive145Third143Node163 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof163

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof463 : runCachedNode 511 131040 Adaptive145Third143Node463 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof463

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof592 : runCachedNode 511 131040 Adaptive145Third143Node592 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof592

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof48 : runCachedNode 511 131040 Adaptive145Third143Node48 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof48

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof81 : runCachedNode 511 131040 Adaptive145Third143Node81 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof81

end NineSeparatedSubsetSums
