import NineSeparatedSubsetSums.Adaptive145Third138State
import NineSeparatedSubsetSums.Adaptive145Third138Leaves18
import NineSeparatedSubsetSums.Adaptive145Third138Leaves12
import NineSeparatedSubsetSums.Adaptive145Third138Leaves17
import NineSeparatedSubsetSums.Adaptive145Third138Leaves16
import NineSeparatedSubsetSums.Adaptive145Third138Leaves15
import NineSeparatedSubsetSums.Adaptive145Third138Leaves14
import NineSeparatedSubsetSums.Adaptive145Third138Leaves13
import NineSeparatedSubsetSums.Adaptive145Third138Leaves3
import NineSeparatedSubsetSums.Adaptive145Third138Leaves7
import NineSeparatedSubsetSums.Adaptive145Third138Leaves4
import NineSeparatedSubsetSums.Adaptive145Third138Leaves0
import NineSeparatedSubsetSums.Adaptive145Third138Leaves2
import NineSeparatedSubsetSums.Adaptive145Third138Leaves6
import NineSeparatedSubsetSums.Adaptive145Third138Leaves5
import NineSeparatedSubsetSums.Adaptive145Third138Leaves10
import NineSeparatedSubsetSums.Adaptive145Third138Leaves11
import NineSeparatedSubsetSums.Adaptive145Third138Leaves8
import NineSeparatedSubsetSums.Adaptive145Third138Leaves9
import NineSeparatedSubsetSums.Adaptive145Third138Leaves1

namespace NineSeparatedSubsetSums

theorem adaptive145Third138Proof22 : runCachedNode 511 130311 Adaptive145Third138Node22 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130311 Adaptive145Third138Node22 = [104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 122, 123, 125, 126, 127, 129, 130] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive145Third138Proof23
  · exact adaptive145Third138Proof24
  · exact adaptive145Third138Proof25
  · exact adaptive145Third138Proof26
  · exact adaptive145Third138Proof27
  · exact adaptive145Third138Proof28
  · exact adaptive145Third138Proof29
  · exact adaptive145Third138Proof30
  · exact adaptive145Third138Proof31
  · exact adaptive145Third138Proof32
  · exact adaptive145Third138Proof33
  · exact adaptive145Third138Proof34
  · exact adaptive145Third138Proof35
  · exact adaptive145Third138Proof36
  · exact adaptive145Third138Proof37
  · exact adaptive145Third138Proof38
  · exact adaptive145Third138Proof39
  · exact adaptive145Third138Proof40
  · exact adaptive145Third138Proof41
  · exact adaptive145Third138Proof42
  · exact adaptive145Third138Proof43
  · exact adaptive145Third138Proof44
  · exact adaptive145Third138Proof45
  · exact adaptive145Third138Proof46

#print axioms adaptive145Third138Proof22

theorem adaptive145Third138Proof47 : runCachedNode 511 130311 Adaptive145Third138Node47 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130311 Adaptive145Third138Node47 = [103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 123, 124, 126, 127, 128, 130, 131] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive145Third138Proof48
  · exact adaptive145Third138Proof49
  · exact adaptive145Third138Proof50
  · exact adaptive145Third138Proof51
  · exact adaptive145Third138Proof52
  · exact adaptive145Third138Proof53
  · exact adaptive145Third138Proof54
  · exact adaptive145Third138Proof55
  · exact adaptive145Third138Proof56
  · exact adaptive145Third138Proof57
  · exact adaptive145Third138Proof58
  · exact adaptive145Third138Proof59
  · exact adaptive145Third138Proof60
  · exact adaptive145Third138Proof61
  · exact adaptive145Third138Proof62
  · exact adaptive145Third138Proof63
  · exact adaptive145Third138Proof64
  · exact adaptive145Third138Proof65
  · exact adaptive145Third138Proof66
  · exact adaptive145Third138Proof67
  · exact adaptive145Third138Proof68
  · exact adaptive145Third138Proof69
  · exact adaptive145Third138Proof70
  · exact adaptive145Third138Proof71
  · exact adaptive145Third138Proof72
  · exact adaptive145Third138Proof73

#print axioms adaptive145Third138Proof47

theorem adaptive145Third138Proof74 : runCachedNode 511 130311 Adaptive145Third138Node74 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130311 Adaptive145Third138Node74 = [103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 124, 125, 127, 128, 129, 131, 132] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive145Third138Proof75
  · exact adaptive145Third138Proof76
  · exact adaptive145Third138Proof77
  · exact adaptive145Third138Proof78
  · exact adaptive145Third138Proof79
  · exact adaptive145Third138Proof80
  · exact adaptive145Third138Proof81
  · exact adaptive145Third138Proof82
  · exact adaptive145Third138Proof83
  · exact adaptive145Third138Proof84
  · exact adaptive145Third138Proof85
  · exact adaptive145Third138Proof86
  · exact adaptive145Third138Proof87
  · exact adaptive145Third138Proof88
  · exact adaptive145Third138Proof89
  · exact adaptive145Third138Proof90
  · exact adaptive145Third138Proof91
  · exact adaptive145Third138Proof92
  · exact adaptive145Third138Proof93
  · exact adaptive145Third138Proof94
  · exact adaptive145Third138Proof95
  · exact adaptive145Third138Proof96
  · exact adaptive145Third138Proof97
  · exact adaptive145Third138Proof98
  · exact adaptive145Third138Proof99
  · exact adaptive145Third138Proof100
  · exact adaptive145Third138Proof101

#print axioms adaptive145Third138Proof74

theorem adaptive145Third138Proof102 : runCachedNode 511 130311 Adaptive145Third138Node102 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130311 Adaptive145Third138Node102 = [103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 125, 126, 128, 129, 130, 132, 133] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive145Third138Proof103
  · exact adaptive145Third138Proof104
  · exact adaptive145Third138Proof105
  · exact adaptive145Third138Proof106
  · exact adaptive145Third138Proof107
  · exact adaptive145Third138Proof108
  · exact adaptive145Third138Proof109
  · exact adaptive145Third138Proof110
  · exact adaptive145Third138Proof111
  · exact adaptive145Third138Proof112
  · exact adaptive145Third138Proof113
  · exact adaptive145Third138Proof114
  · exact adaptive145Third138Proof115
  · exact adaptive145Third138Proof116
  · exact adaptive145Third138Proof117
  · exact adaptive145Third138Proof118
  · exact adaptive145Third138Proof119
  · exact adaptive145Third138Proof120
  · exact adaptive145Third138Proof121
  · exact adaptive145Third138Proof122
  · exact adaptive145Third138Proof123
  · exact adaptive145Third138Proof124
  · exact adaptive145Third138Proof125
  · exact adaptive145Third138Proof126
  · exact adaptive145Third138Proof127
  · exact adaptive145Third138Proof128
  · exact adaptive145Third138Proof129
  · exact adaptive145Third138Proof130

#print axioms adaptive145Third138Proof102

theorem adaptive145Third138Proof131 : runCachedNode 511 130311 Adaptive145Third138Node131 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130311 Adaptive145Third138Node131 = [102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 127, 128, 130, 131, 132, 134] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive145Third138Proof132
  · exact adaptive145Third138Proof133
  · exact adaptive145Third138Proof134
  · exact adaptive145Third138Proof135
  · exact adaptive145Third138Proof136
  · exact adaptive145Third138Proof137
  · exact adaptive145Third138Proof138
  · exact adaptive145Third138Proof139
  · exact adaptive145Third138Proof140
  · exact adaptive145Third138Proof141
  · exact adaptive145Third138Proof142
  · exact adaptive145Third138Proof143
  · exact adaptive145Third138Proof144
  · exact adaptive145Third138Proof145
  · exact adaptive145Third138Proof146
  · exact adaptive145Third138Proof147
  · exact adaptive145Third138Proof148
  · exact adaptive145Third138Proof149
  · exact adaptive145Third138Proof150
  · exact adaptive145Third138Proof151
  · exact adaptive145Third138Proof152
  · exact adaptive145Third138Proof153
  · exact adaptive145Third138Proof154
  · exact adaptive145Third138Proof155
  · exact adaptive145Third138Proof156
  · exact adaptive145Third138Proof157
  · exact adaptive145Third138Proof158
  · exact adaptive145Third138Proof159
  · exact adaptive145Third138Proof160
  · exact adaptive145Third138Proof161

#print axioms adaptive145Third138Proof131

theorem adaptive145Third138Proof162 : runCachedNode 511 130311 Adaptive145Third138Node162 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130311 Adaptive145Third138Node162 = [102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 128, 129, 131, 132, 133, 136] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive145Third138Proof163
  · exact adaptive145Third138Proof164
  · exact adaptive145Third138Proof165
  · exact adaptive145Third138Proof166
  · exact adaptive145Third138Proof167
  · exact adaptive145Third138Proof168
  · exact adaptive145Third138Proof169
  · exact adaptive145Third138Proof170
  · exact adaptive145Third138Proof171
  · exact adaptive145Third138Proof172
  · exact adaptive145Third138Proof173
  · exact adaptive145Third138Proof174
  · exact adaptive145Third138Proof175
  · exact adaptive145Third138Proof176
  · exact adaptive145Third138Proof177
  · exact adaptive145Third138Proof178
  · exact adaptive145Third138Proof179
  · exact adaptive145Third138Proof180
  · exact adaptive145Third138Proof181
  · exact adaptive145Third138Proof182
  · exact adaptive145Third138Proof183
  · exact adaptive145Third138Proof184
  · exact adaptive145Third138Proof185
  · exact adaptive145Third138Proof186
  · exact adaptive145Third138Proof187
  · exact adaptive145Third138Proof188
  · exact adaptive145Third138Proof189
  · exact adaptive145Third138Proof190
  · exact adaptive145Third138Proof191
  · exact adaptive145Third138Proof192
  · exact adaptive145Third138Proof193

#print axioms adaptive145Third138Proof162

theorem adaptive145Third138Proof0 : runCachedNode 511 130311 Adaptive145Third138Node0 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130311 Adaptive145Third138Node0 = [110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 132, 133, 134, 136, 137] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive145Third138Proof1
  · exact adaptive145Third138Proof2
  · exact adaptive145Third138Proof3
  · exact adaptive145Third138Proof4
  · exact adaptive145Third138Proof5
  · exact adaptive145Third138Proof6
  · exact adaptive145Third138Proof7
  · exact adaptive145Third138Proof8
  · exact adaptive145Third138Proof9
  · exact adaptive145Third138Proof10
  · exact adaptive145Third138Proof11
  · exact adaptive145Third138Proof12
  · exact adaptive145Third138Proof13
  · exact adaptive145Third138Proof14
  · exact adaptive145Third138Proof15
  · exact adaptive145Third138Proof16
  · exact adaptive145Third138Proof17
  · exact adaptive145Third138Proof18
  · exact adaptive145Third138Proof19
  · exact adaptive145Third138Proof20
  · exact adaptive145Third138Proof21
  · exact adaptive145Third138Proof22
  · exact adaptive145Third138Proof47
  · exact adaptive145Third138Proof74
  · exact adaptive145Third138Proof102
  · exact adaptive145Third138Proof131
  · exact adaptive145Third138Proof162

#print axioms adaptive145Third138Proof0

end NineSeparatedSubsetSums
