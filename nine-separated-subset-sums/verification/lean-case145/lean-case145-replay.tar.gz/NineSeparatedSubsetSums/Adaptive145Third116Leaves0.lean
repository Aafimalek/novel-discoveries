import NineSeparatedSubsetSums.Adaptive145Third116State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third116Proof15 : runCachedNode 511 112442 Adaptive145Third116Node15 = false := by
  decide +kernel

#print axioms adaptive145Third116Proof15

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third116Proof14 : runCachedNode 511 112442 Adaptive145Third116Node14 = false := by
  decide +kernel

#print axioms adaptive145Third116Proof14

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third116Proof13 : runCachedNode 511 112442 Adaptive145Third116Node13 = false := by
  decide +kernel

#print axioms adaptive145Third116Proof13

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third116Proof6 : runCachedNode 511 112442 Adaptive145Third116Node6 = false := by
  decide +kernel

#print axioms adaptive145Third116Proof6

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third116Proof3 : runCachedNode 511 112442 Adaptive145Third116Node3 = false := by
  decide +kernel

#print axioms adaptive145Third116Proof3

end NineSeparatedSubsetSums
