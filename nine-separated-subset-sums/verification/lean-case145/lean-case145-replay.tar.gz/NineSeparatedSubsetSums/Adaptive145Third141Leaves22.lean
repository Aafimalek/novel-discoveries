import NineSeparatedSubsetSums.Adaptive145Third141State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third141Proof99 : runCachedNode 511 130740 Adaptive145Third141Node99 = false := by
  decide +kernel

#print axioms adaptive145Third141Proof99

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third141Proof193 : runCachedNode 511 130740 Adaptive145Third141Node193 = false := by
  decide +kernel

#print axioms adaptive145Third141Proof193

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third141Proof72 : runCachedNode 511 130740 Adaptive145Third141Node72 = false := by
  decide +kernel

#print axioms adaptive145Third141Proof72

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third141Proof188 : runCachedNode 511 130740 Adaptive145Third141Node188 = false := by
  decide +kernel

#print axioms adaptive145Third141Proof188

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third141Proof367 : runCachedNode 511 130740 Adaptive145Third141Node367 = false := by
  decide +kernel

#print axioms adaptive145Third141Proof367

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third141Proof47 : runCachedNode 511 130740 Adaptive145Third141Node47 = false := by
  decide +kernel

#print axioms adaptive145Third141Proof47

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third141Proof46 : runCachedNode 511 130740 Adaptive145Third141Node46 = false := by
  decide +kernel

#print axioms adaptive145Third141Proof46

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third141Proof125 : runCachedNode 511 130740 Adaptive145Third141Node125 = false := by
  decide +kernel

#print axioms adaptive145Third141Proof125

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third141Proof233 : runCachedNode 511 130740 Adaptive145Third141Node233 = false := by
  decide +kernel

#print axioms adaptive145Third141Proof233

end NineSeparatedSubsetSums
