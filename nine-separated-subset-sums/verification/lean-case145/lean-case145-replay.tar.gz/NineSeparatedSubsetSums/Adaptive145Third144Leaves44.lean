import NineSeparatedSubsetSums.Adaptive145Third144State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third144Proof759 : runCachedNode 511 131183 Adaptive145Third144Node759 = false := by
  decide +kernel

#print axioms adaptive145Third144Proof759

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third144Proof71 : runCachedNode 511 131183 Adaptive145Third144Node71 = false := by
  decide +kernel

#print axioms adaptive145Third144Proof71

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third144Proof611 : runCachedNode 511 131183 Adaptive145Third144Node611 = false := by
  decide +kernel

#print axioms adaptive145Third144Proof611

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third144Proof368 : runCachedNode 511 131183 Adaptive145Third144Node368 = false := by
  decide +kernel

#print axioms adaptive145Third144Proof368

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third144Proof324 : runCachedNode 511 131183 Adaptive145Third144Node324 = false := by
  decide +kernel

#print axioms adaptive145Third144Proof324

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third144Proof371 : runCachedNode 511 131183 Adaptive145Third144Node371 = false := by
  decide +kernel

#print axioms adaptive145Third144Proof371

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third144Proof47 : runCachedNode 511 131183 Adaptive145Third144Node47 = false := by
  decide +kernel

#print axioms adaptive145Third144Proof47

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third144Proof222 : runCachedNode 511 131183 Adaptive145Third144Node222 = false := by
  decide +kernel

#print axioms adaptive145Third144Proof222

end NineSeparatedSubsetSums
