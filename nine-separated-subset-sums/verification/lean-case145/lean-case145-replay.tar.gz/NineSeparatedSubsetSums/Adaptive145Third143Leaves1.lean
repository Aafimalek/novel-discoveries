import NineSeparatedSubsetSums.Adaptive145Third143State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof502 : runCachedNode 511 131040 Adaptive145Third143Node502 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof502

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof326 : runCachedNode 511 131040 Adaptive145Third143Node326 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof326

end NineSeparatedSubsetSums
