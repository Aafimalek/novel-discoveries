import NineSeparatedSubsetSums.Adaptive145Third139State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third139Proof129 : runCachedNode 511 130465 Adaptive145Third139Node129 = false := by
  decide +kernel

#print axioms adaptive145Third139Proof129

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third139Proof192 : runCachedNode 511 130465 Adaptive145Third139Node192 = false := by
  decide +kernel

#print axioms adaptive145Third139Proof192

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third139Proof60 : runCachedNode 511 130465 Adaptive145Third139Node60 = false := by
  decide +kernel

#print axioms adaptive145Third139Proof60

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third139Proof131 : runCachedNode 511 130465 Adaptive145Third139Node131 = false := by
  decide +kernel

#print axioms adaptive145Third139Proof131

end NineSeparatedSubsetSums
