import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive145Third122Node0 : CachedSearchNode :=
  ⟨4, 121, computeCenteredMask [148,145,122], 415, 57813⟩

end NineSeparatedSubsetSums
