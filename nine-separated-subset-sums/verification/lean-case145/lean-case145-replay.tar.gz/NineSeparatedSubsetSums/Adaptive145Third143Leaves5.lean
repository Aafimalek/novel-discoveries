import NineSeparatedSubsetSums.Adaptive145Third143State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof420 : runCachedNode 511 131040 Adaptive145Third143Node420 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof420

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof225 : runCachedNode 511 131040 Adaptive145Third143Node225 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof225

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof267 : runCachedNode 511 131040 Adaptive145Third143Node267 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof267

end NineSeparatedSubsetSums
