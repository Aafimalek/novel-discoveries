import NineSeparatedSubsetSums.Adaptive145Third142State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof465 : runCachedNode 511 130865 Adaptive145Third142Node465 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof465

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof782 : runCachedNode 511 130865 Adaptive145Third142Node782 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof782

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof44 : runCachedNode 511 130865 Adaptive145Third142Node44 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof44

end NineSeparatedSubsetSums
