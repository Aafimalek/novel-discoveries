import NineSeparatedSubsetSums.Adaptive145Third142State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof539 : runCachedNode 511 130865 Adaptive145Third142Node539 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof539

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof310 : runCachedNode 511 130865 Adaptive145Third142Node310 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof310

end NineSeparatedSubsetSums
