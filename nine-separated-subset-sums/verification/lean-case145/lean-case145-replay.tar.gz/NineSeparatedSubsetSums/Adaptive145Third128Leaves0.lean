import NineSeparatedSubsetSums.Adaptive145Third128State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third128Proof17 : runCachedNode 511 128446 Adaptive145Third128Node17 = false := by
  decide +kernel

#print axioms adaptive145Third128Proof17

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third128Proof16 : runCachedNode 511 128446 Adaptive145Third128Node16 = false := by
  decide +kernel

#print axioms adaptive145Third128Proof16

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third128Proof15 : runCachedNode 511 128446 Adaptive145Third128Node15 = false := by
  decide +kernel

#print axioms adaptive145Third128Proof15

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third128Proof13 : runCachedNode 511 128446 Adaptive145Third128Node13 = false := by
  decide +kernel

#print axioms adaptive145Third128Proof13

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third128Proof9 : runCachedNode 511 128446 Adaptive145Third128Node9 = false := by
  decide +kernel

#print axioms adaptive145Third128Proof9

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third128Proof1 : runCachedNode 511 128446 Adaptive145Third128Node1 = false := by
  decide +kernel

#print axioms adaptive145Third128Proof1

end NineSeparatedSubsetSums
