import NineSeparatedSubsetSums.Adaptive145Third134State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third134Proof41 : runCachedNode 511 129715 Adaptive145Third134Node41 = false := by
  decide +kernel

#print axioms adaptive145Third134Proof41

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third134Proof45 : runCachedNode 511 129715 Adaptive145Third134Node45 = false := by
  decide +kernel

#print axioms adaptive145Third134Proof45

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third134Proof9 : runCachedNode 511 129715 Adaptive145Third134Node9 = false := by
  decide +kernel

#print axioms adaptive145Third134Proof9

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third134Proof8 : runCachedNode 511 129715 Adaptive145Third134Node8 = false := by
  decide +kernel

#print axioms adaptive145Third134Proof8

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third134Proof39 : runCachedNode 511 129715 Adaptive145Third134Node39 = false := by
  decide +kernel

#print axioms adaptive145Third134Proof39

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third134Proof42 : runCachedNode 511 129715 Adaptive145Third134Node42 = false := by
  decide +kernel

#print axioms adaptive145Third134Proof42

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third134Proof38 : runCachedNode 511 129715 Adaptive145Third134Node38 = false := by
  decide +kernel

#print axioms adaptive145Third134Proof38

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third134Proof36 : runCachedNode 511 129715 Adaptive145Third134Node36 = false := by
  decide +kernel

#print axioms adaptive145Third134Proof36

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third134Proof35 : runCachedNode 511 129715 Adaptive145Third134Node35 = false := by
  decide +kernel

#print axioms adaptive145Third134Proof35

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third134Proof5 : runCachedNode 511 129715 Adaptive145Third134Node5 = false := by
  decide +kernel

#print axioms adaptive145Third134Proof5

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third134Proof4 : runCachedNode 511 129715 Adaptive145Third134Node4 = false := by
  decide +kernel

#print axioms adaptive145Third134Proof4

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third134Proof33 : runCachedNode 511 129715 Adaptive145Third134Node33 = false := by
  decide +kernel

#print axioms adaptive145Third134Proof33

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third134Proof32 : runCachedNode 511 129715 Adaptive145Third134Node32 = false := by
  decide +kernel

#print axioms adaptive145Third134Proof32

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third134Proof3 : runCachedNode 511 129715 Adaptive145Third134Node3 = false := by
  decide +kernel

#print axioms adaptive145Third134Proof3

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third134Proof30 : runCachedNode 511 129715 Adaptive145Third134Node30 = false := by
  decide +kernel

#print axioms adaptive145Third134Proof30

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third134Proof29 : runCachedNode 511 129715 Adaptive145Third134Node29 = false := by
  decide +kernel

#print axioms adaptive145Third134Proof29

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third134Proof28 : runCachedNode 511 129715 Adaptive145Third134Node28 = false := by
  decide +kernel

#print axioms adaptive145Third134Proof28

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third134Proof1 : runCachedNode 511 129715 Adaptive145Third134Node1 = false := by
  decide +kernel

#print axioms adaptive145Third134Proof1

end NineSeparatedSubsetSums
