import NineSeparatedSubsetSums.Adaptive145Third142State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof222 : runCachedNode 511 130865 Adaptive145Third142Node222 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof222

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof283 : runCachedNode 511 130865 Adaptive145Third142Node283 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof283

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof738 : runCachedNode 511 130865 Adaptive145Third142Node738 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof738

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof359 : runCachedNode 511 130865 Adaptive145Third142Node359 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof359

end NineSeparatedSubsetSums
