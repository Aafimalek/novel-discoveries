import NineSeparatedSubsetSums.Adaptive145Third143State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof231 : runCachedNode 511 131040 Adaptive145Third143Node231 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof231

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof416 : runCachedNode 511 131040 Adaptive145Third143Node416 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof416

end NineSeparatedSubsetSums
