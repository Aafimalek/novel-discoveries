import NineSeparatedSubsetSums.Adaptive145Third141State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third141Proof196 : runCachedNode 511 130740 Adaptive145Third141Node196 = false := by
  decide +kernel

#print axioms adaptive145Third141Proof196

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third141Proof130 : runCachedNode 511 130740 Adaptive145Third141Node130 = false := by
  decide +kernel

#print axioms adaptive145Third141Proof130

end NineSeparatedSubsetSums
