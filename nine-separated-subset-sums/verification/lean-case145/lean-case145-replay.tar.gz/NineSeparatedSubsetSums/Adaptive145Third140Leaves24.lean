import NineSeparatedSubsetSums.Adaptive145Third140State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third140Proof214 : runCachedNode 511 130597 Adaptive145Third140Node214 = false := by
  decide +kernel

#print axioms adaptive145Third140Proof214

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third140Proof149 : runCachedNode 511 130597 Adaptive145Third140Node149 = false := by
  decide +kernel

#print axioms adaptive145Third140Proof149

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third140Proof42 : runCachedNode 511 130597 Adaptive145Third140Node42 = false := by
  decide +kernel

#print axioms adaptive145Third140Proof42

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third140Proof121 : runCachedNode 511 130597 Adaptive145Third140Node121 = false := by
  decide +kernel

#print axioms adaptive145Third140Proof121

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third140Proof213 : runCachedNode 511 130597 Adaptive145Third140Node213 = false := by
  decide +kernel

#print axioms adaptive145Third140Proof213

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third140Proof120 : runCachedNode 511 130597 Adaptive145Third140Node120 = false := by
  decide +kernel

#print axioms adaptive145Third140Proof120

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third140Proof182 : runCachedNode 511 130597 Adaptive145Third140Node182 = false := by
  decide +kernel

#print axioms adaptive145Third140Proof182

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third140Proof64 : runCachedNode 511 130597 Adaptive145Third140Node64 = false := by
  decide +kernel

#print axioms adaptive145Third140Proof64

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third140Proof40 : runCachedNode 511 130597 Adaptive145Third140Node40 = false := by
  decide +kernel

#print axioms adaptive145Third140Proof40

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third140Proof92 : runCachedNode 511 130597 Adaptive145Third140Node92 = false := by
  decide +kernel

#print axioms adaptive145Third140Proof92

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third140Proof253 : runCachedNode 511 130597 Adaptive145Third140Node253 = false := by
  decide +kernel

#print axioms adaptive145Third140Proof253

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third140Proof249 : runCachedNode 511 130597 Adaptive145Third140Node249 = false := by
  decide +kernel

#print axioms adaptive145Third140Proof249

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third140Proof183 : runCachedNode 511 130597 Adaptive145Third140Node183 = false := by
  decide +kernel

#print axioms adaptive145Third140Proof183

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third140Proof119 : runCachedNode 511 130597 Adaptive145Third140Node119 = false := by
  decide +kernel

#print axioms adaptive145Third140Proof119

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third140Proof212 : runCachedNode 511 130597 Adaptive145Third140Node212 = false := by
  decide +kernel

#print axioms adaptive145Third140Proof212

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third140Proof211 : runCachedNode 511 130597 Adaptive145Third140Node211 = false := by
  decide +kernel

#print axioms adaptive145Third140Proof211

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third140Proof297 : runCachedNode 511 130597 Adaptive145Third140Node297 = false := by
  decide +kernel

#print axioms adaptive145Third140Proof297

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third140Proof148 : runCachedNode 511 130597 Adaptive145Third140Node148 = false := by
  decide +kernel

#print axioms adaptive145Third140Proof148

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third140Proof248 : runCachedNode 511 130597 Adaptive145Third140Node248 = false := by
  decide +kernel

#print axioms adaptive145Third140Proof248

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third140Proof93 : runCachedNode 511 130597 Adaptive145Third140Node93 = false := by
  decide +kernel

#print axioms adaptive145Third140Proof93

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third140Proof247 : runCachedNode 511 130597 Adaptive145Third140Node247 = false := by
  decide +kernel

#print axioms adaptive145Third140Proof247

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third140Proof246 : runCachedNode 511 130597 Adaptive145Third140Node246 = false := by
  decide +kernel

#print axioms adaptive145Third140Proof246

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third140Proof62 : runCachedNode 511 130597 Adaptive145Third140Node62 = false := by
  decide +kernel

#print axioms adaptive145Third140Proof62

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third140Proof146 : runCachedNode 511 130597 Adaptive145Third140Node146 = false := by
  decide +kernel

#print axioms adaptive145Third140Proof146

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third140Proof210 : runCachedNode 511 130597 Adaptive145Third140Node210 = false := by
  decide +kernel

#print axioms adaptive145Third140Proof210

end NineSeparatedSubsetSums
