import NineSeparatedSubsetSums.Adaptive145Third136State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third136Proof123 : runCachedNode 511 130013 Adaptive145Third136Node123 = false := by
  decide +kernel

#print axioms adaptive145Third136Proof123

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third136Proof17 : runCachedNode 511 130013 Adaptive145Third136Node17 = false := by
  decide +kernel

#print axioms adaptive145Third136Proof17

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third136Proof14 : runCachedNode 511 130013 Adaptive145Third136Node14 = false := by
  decide +kernel

#print axioms adaptive145Third136Proof14

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third136Proof28 : runCachedNode 511 130013 Adaptive145Third136Node28 = false := by
  decide +kernel

#print axioms adaptive145Third136Proof28

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third136Proof47 : runCachedNode 511 130013 Adaptive145Third136Node47 = false := by
  decide +kernel

#print axioms adaptive145Third136Proof47

end NineSeparatedSubsetSums
