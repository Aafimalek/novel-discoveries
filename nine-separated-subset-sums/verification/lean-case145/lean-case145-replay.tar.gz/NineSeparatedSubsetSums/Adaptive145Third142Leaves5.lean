import NineSeparatedSubsetSums.Adaptive145Third142State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof541 : runCachedNode 511 130865 Adaptive145Third142Node541 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof541

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof805 : runCachedNode 511 130865 Adaptive145Third142Node805 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof805

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof43 : runCachedNode 511 130865 Adaptive145Third142Node43 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof43

end NineSeparatedSubsetSums
