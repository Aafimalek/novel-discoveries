import NineSeparatedSubsetSums.Adaptive145Third143State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof264 : runCachedNode 511 131040 Adaptive145Third143Node264 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof264

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof464 : runCachedNode 511 131040 Adaptive145Third143Node464 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof464

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof63 : runCachedNode 511 131040 Adaptive145Third143Node63 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof63

end NineSeparatedSubsetSums
