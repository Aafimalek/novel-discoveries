import NineSeparatedSubsetSums.Adaptive145Third135State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third135Proof15 : runCachedNode 511 129879 Adaptive145Third135Node15 = false := by
  decide +kernel

#print axioms adaptive145Third135Proof15

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third135Proof14 : runCachedNode 511 129879 Adaptive145Third135Node14 = false := by
  decide +kernel

#print axioms adaptive145Third135Proof14

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third135Proof43 : runCachedNode 511 129879 Adaptive145Third135Node43 = false := by
  decide +kernel

#print axioms adaptive145Third135Proof43

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third135Proof74 : runCachedNode 511 129879 Adaptive145Third135Node74 = false := by
  decide +kernel

#print axioms adaptive145Third135Proof74

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third135Proof47 : runCachedNode 511 129879 Adaptive145Third135Node47 = false := by
  decide +kernel

#print axioms adaptive145Third135Proof47

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third135Proof72 : runCachedNode 511 129879 Adaptive145Third135Node72 = false := by
  decide +kernel

#print axioms adaptive145Third135Proof72

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third135Proof70 : runCachedNode 511 129879 Adaptive145Third135Node70 = false := by
  decide +kernel

#print axioms adaptive145Third135Proof70

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third135Proof1 : runCachedNode 511 129879 Adaptive145Third135Node1 = false := by
  decide +kernel

#print axioms adaptive145Third135Proof1

end NineSeparatedSubsetSums
