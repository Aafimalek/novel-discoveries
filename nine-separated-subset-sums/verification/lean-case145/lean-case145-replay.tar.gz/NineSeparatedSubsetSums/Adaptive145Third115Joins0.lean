import NineSeparatedSubsetSums.Adaptive145Third115State
import NineSeparatedSubsetSums.Adaptive145Third115Leaves1
import NineSeparatedSubsetSums.Adaptive145Third115Leaves0

namespace NineSeparatedSubsetSums

theorem adaptive145Third115Proof0 : runCachedNode 511 112442 Adaptive145Third115Node0 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 112442 Adaptive145Third115Node0 = [100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 113, 114] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive145Third115Proof1
  · exact adaptive145Third115Proof2
  · exact adaptive145Third115Proof3
  · exact adaptive145Third115Proof4
  · exact adaptive145Third115Proof5
  · exact adaptive145Third115Proof6
  · exact adaptive145Third115Proof7
  · exact adaptive145Third115Proof8
  · exact adaptive145Third115Proof9
  · exact adaptive145Third115Proof10
  · exact adaptive145Third115Proof11
  · exact adaptive145Third115Proof12
  · exact adaptive145Third115Proof13
  · exact adaptive145Third115Proof14

#print axioms adaptive145Third115Proof0

end NineSeparatedSubsetSums
