import NineSeparatedSubsetSums.Adaptive145Third143State
import NineSeparatedSubsetSums.Adaptive145Third143Leaves54
import NineSeparatedSubsetSums.Adaptive145Third143Leaves53
import NineSeparatedSubsetSums.Adaptive145Third143Leaves52
import NineSeparatedSubsetSums.Adaptive145Third143Leaves51
import NineSeparatedSubsetSums.Adaptive145Third143Leaves50
import NineSeparatedSubsetSums.Adaptive145Third143Leaves49
import NineSeparatedSubsetSums.Adaptive145Third143Leaves0
import NineSeparatedSubsetSums.Adaptive145Third143Leaves47
import NineSeparatedSubsetSums.Adaptive145Third143Leaves46
import NineSeparatedSubsetSums.Adaptive145Third143Leaves45
import NineSeparatedSubsetSums.Adaptive145Third143Leaves44
import NineSeparatedSubsetSums.Adaptive145Third143Leaves43
import NineSeparatedSubsetSums.Adaptive145Third143Leaves41
import NineSeparatedSubsetSums.Adaptive145Third143Leaves40
import NineSeparatedSubsetSums.Adaptive145Third143Leaves36
import NineSeparatedSubsetSums.Adaptive145Third143Leaves21
import NineSeparatedSubsetSums.Adaptive145Third143Leaves31
import NineSeparatedSubsetSums.Adaptive145Third143Leaves26
import NineSeparatedSubsetSums.Adaptive145Third143Leaves28
import NineSeparatedSubsetSums.Adaptive145Third143Leaves13
import NineSeparatedSubsetSums.Adaptive145Third143Leaves9
import NineSeparatedSubsetSums.Adaptive145Third143Leaves2
import NineSeparatedSubsetSums.Adaptive145Third143Leaves12
import NineSeparatedSubsetSums.Adaptive145Third143Leaves6
import NineSeparatedSubsetSums.Adaptive145Third143Joins0
import NineSeparatedSubsetSums.Adaptive145Third143Leaves55
import NineSeparatedSubsetSums.Adaptive145Third143Leaves48
import NineSeparatedSubsetSums.Adaptive145Third143Leaves34
import NineSeparatedSubsetSums.Adaptive145Third143Leaves7
import NineSeparatedSubsetSums.Adaptive145Third143Leaves1
import NineSeparatedSubsetSums.Adaptive145Third143Leaves33
import NineSeparatedSubsetSums.Adaptive145Third143Leaves35
import NineSeparatedSubsetSums.Adaptive145Third143Leaves30
import NineSeparatedSubsetSums.Adaptive145Third143Leaves24
import NineSeparatedSubsetSums.Adaptive145Third143Leaves15
import NineSeparatedSubsetSums.Adaptive145Third143Leaves56
import NineSeparatedSubsetSums.Adaptive145Third143Leaves39
import NineSeparatedSubsetSums.Adaptive145Third143Leaves42
import NineSeparatedSubsetSums.Adaptive145Third143Leaves32
import NineSeparatedSubsetSums.Adaptive145Third143Leaves27
import NineSeparatedSubsetSums.Adaptive145Third143Leaves37
import NineSeparatedSubsetSums.Adaptive145Third143Leaves22
import NineSeparatedSubsetSums.Adaptive145Third143Leaves10
import NineSeparatedSubsetSums.Adaptive145Third143Leaves8
import NineSeparatedSubsetSums.Adaptive145Third143Leaves17
import NineSeparatedSubsetSums.Adaptive145Third143Leaves16
import NineSeparatedSubsetSums.Adaptive145Third143Leaves20
import NineSeparatedSubsetSums.Adaptive145Third143Leaves5
import NineSeparatedSubsetSums.Adaptive145Third143Leaves25
import NineSeparatedSubsetSums.Adaptive145Third143Leaves38
import NineSeparatedSubsetSums.Adaptive145Third143Leaves4
import NineSeparatedSubsetSums.Adaptive145Third143Leaves23
import NineSeparatedSubsetSums.Adaptive145Third143Leaves18
import NineSeparatedSubsetSums.Adaptive145Third143Leaves14
import NineSeparatedSubsetSums.Adaptive145Third143Leaves29
import NineSeparatedSubsetSums.Adaptive145Third143Leaves11

namespace NineSeparatedSubsetSums

theorem adaptive145Third143Proof232 : runCachedNode 511 131040 Adaptive145Third143Node232 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 131040 Adaptive145Third143Node232 = [101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 132, 134, 137] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive145Third143Proof233
  · exact adaptive145Third143Proof234
  · exact adaptive145Third143Proof235
  · exact adaptive145Third143Proof236
  · exact adaptive145Third143Proof237
  · exact adaptive145Third143Proof238
  · exact adaptive145Third143Proof239
  · exact adaptive145Third143Proof240
  · exact adaptive145Third143Proof241
  · exact adaptive145Third143Proof242
  · exact adaptive145Third143Proof243
  · exact adaptive145Third143Proof244
  · exact adaptive145Third143Proof245
  · exact adaptive145Third143Proof246
  · exact adaptive145Third143Proof247
  · exact adaptive145Third143Proof248
  · exact adaptive145Third143Proof249
  · exact adaptive145Third143Proof250
  · exact adaptive145Third143Proof251
  · exact adaptive145Third143Proof252
  · exact adaptive145Third143Proof253
  · exact adaptive145Third143Proof254
  · exact adaptive145Third143Proof255
  · exact adaptive145Third143Proof256
  · exact adaptive145Third143Proof257
  · exact adaptive145Third143Proof258
  · exact adaptive145Third143Proof259
  · exact adaptive145Third143Proof260
  · exact adaptive145Third143Proof261
  · exact adaptive145Third143Proof262
  · exact adaptive145Third143Proof263
  · exact adaptive145Third143Proof264
  · exact adaptive145Third143Proof265
  · exact adaptive145Third143Proof266

#print axioms adaptive145Third143Proof232

theorem adaptive145Third143Proof342 : runCachedNode 511 131040 Adaptive145Third143Node342 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 131040 Adaptive145Third143Node342 = [88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 128, 130] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive145Third143Proof343
  · exact adaptive145Third143Proof344
  · exact adaptive145Third143Proof345
  · exact adaptive145Third143Proof346
  · exact adaptive145Third143Proof347
  · exact adaptive145Third143Proof348
  · exact adaptive145Third143Proof349
  · exact adaptive145Third143Proof350
  · exact adaptive145Third143Proof351
  · exact adaptive145Third143Proof352
  · exact adaptive145Third143Proof353
  · exact adaptive145Third143Proof354
  · exact adaptive145Third143Proof355
  · exact adaptive145Third143Proof356
  · exact adaptive145Third143Proof357
  · exact adaptive145Third143Proof358
  · exact adaptive145Third143Proof359
  · exact adaptive145Third143Proof360
  · exact adaptive145Third143Proof361
  · exact adaptive145Third143Proof362
  · exact adaptive145Third143Proof363
  · exact adaptive145Third143Proof364
  · exact adaptive145Third143Proof365
  · exact adaptive145Third143Proof366
  · exact adaptive145Third143Proof367
  · exact adaptive145Third143Proof368
  · exact adaptive145Third143Proof369
  · exact adaptive145Third143Proof370
  · exact adaptive145Third143Proof371
  · exact adaptive145Third143Proof372
  · exact adaptive145Third143Proof373
  · exact adaptive145Third143Proof374
  · exact adaptive145Third143Proof375
  · exact adaptive145Third143Proof376
  · exact adaptive145Third143Proof377
  · exact adaptive145Third143Proof378
  · exact adaptive145Third143Proof379
  · exact adaptive145Third143Proof380
  · exact adaptive145Third143Proof381
  · exact adaptive145Third143Proof382
  · exact adaptive145Third143Proof383

#print axioms adaptive145Third143Proof342

theorem adaptive145Third143Proof307 : runCachedNode 511 131040 Adaptive145Third143Node307 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 131040 Adaptive145Third143Node307 = [101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 132, 133, 135, 138] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive145Third143Proof308
  · exact adaptive145Third143Proof309
  · exact adaptive145Third143Proof310
  · exact adaptive145Third143Proof311
  · exact adaptive145Third143Proof312
  · exact adaptive145Third143Proof313
  · exact adaptive145Third143Proof314
  · exact adaptive145Third143Proof315
  · exact adaptive145Third143Proof316
  · exact adaptive145Third143Proof317
  · exact adaptive145Third143Proof318
  · exact adaptive145Third143Proof319
  · exact adaptive145Third143Proof320
  · exact adaptive145Third143Proof321
  · exact adaptive145Third143Proof322
  · exact adaptive145Third143Proof323
  · exact adaptive145Third143Proof324
  · exact adaptive145Third143Proof325
  · exact adaptive145Third143Proof326
  · exact adaptive145Third143Proof327
  · exact adaptive145Third143Proof328
  · exact adaptive145Third143Proof329
  · exact adaptive145Third143Proof330
  · exact adaptive145Third143Proof331
  · exact adaptive145Third143Proof332
  · exact adaptive145Third143Proof333
  · exact adaptive145Third143Proof334
  · exact adaptive145Third143Proof335
  · exact adaptive145Third143Proof336
  · exact adaptive145Third143Proof337
  · exact adaptive145Third143Proof338
  · exact adaptive145Third143Proof339
  · exact adaptive145Third143Proof340
  · exact adaptive145Third143Proof341
  · exact adaptive145Third143Proof342

#print axioms adaptive145Third143Proof307

theorem adaptive145Third143Proof421 : runCachedNode 511 131040 Adaptive145Third143Node421 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 131040 Adaptive145Third143Node421 = [87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 129, 131] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive145Third143Proof422
  · exact adaptive145Third143Proof423
  · exact adaptive145Third143Proof424
  · exact adaptive145Third143Proof425
  · exact adaptive145Third143Proof426
  · exact adaptive145Third143Proof427
  · exact adaptive145Third143Proof428
  · exact adaptive145Third143Proof429
  · exact adaptive145Third143Proof430
  · exact adaptive145Third143Proof431
  · exact adaptive145Third143Proof432
  · exact adaptive145Third143Proof433
  · exact adaptive145Third143Proof434
  · exact adaptive145Third143Proof435
  · exact adaptive145Third143Proof436
  · exact adaptive145Third143Proof437
  · exact adaptive145Third143Proof438
  · exact adaptive145Third143Proof439
  · exact adaptive145Third143Proof440
  · exact adaptive145Third143Proof441
  · exact adaptive145Third143Proof442
  · exact adaptive145Third143Proof443
  · exact adaptive145Third143Proof444
  · exact adaptive145Third143Proof445
  · exact adaptive145Third143Proof446
  · exact adaptive145Third143Proof447
  · exact adaptive145Third143Proof448
  · exact adaptive145Third143Proof449
  · exact adaptive145Third143Proof450
  · exact adaptive145Third143Proof451
  · exact adaptive145Third143Proof452
  · exact adaptive145Third143Proof453
  · exact adaptive145Third143Proof454
  · exact adaptive145Third143Proof455
  · exact adaptive145Third143Proof456
  · exact adaptive145Third143Proof457
  · exact adaptive145Third143Proof458
  · exact adaptive145Third143Proof459
  · exact adaptive145Third143Proof460
  · exact adaptive145Third143Proof461
  · exact adaptive145Third143Proof462
  · exact adaptive145Third143Proof463
  · exact adaptive145Third143Proof464

#print axioms adaptive145Third143Proof421

theorem adaptive145Third143Proof384 : runCachedNode 511 131040 Adaptive145Third143Node384 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 131040 Adaptive145Third143Node384 = [100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 132, 133, 134, 135, 137] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive145Third143Proof385
  · exact adaptive145Third143Proof386
  · exact adaptive145Third143Proof387
  · exact adaptive145Third143Proof388
  · exact adaptive145Third143Proof389
  · exact adaptive145Third143Proof390
  · exact adaptive145Third143Proof391
  · exact adaptive145Third143Proof392
  · exact adaptive145Third143Proof393
  · exact adaptive145Third143Proof394
  · exact adaptive145Third143Proof395
  · exact adaptive145Third143Proof396
  · exact adaptive145Third143Proof397
  · exact adaptive145Third143Proof398
  · exact adaptive145Third143Proof399
  · exact adaptive145Third143Proof400
  · exact adaptive145Third143Proof401
  · exact adaptive145Third143Proof402
  · exact adaptive145Third143Proof403
  · exact adaptive145Third143Proof404
  · exact adaptive145Third143Proof405
  · exact adaptive145Third143Proof406
  · exact adaptive145Third143Proof407
  · exact adaptive145Third143Proof408
  · exact adaptive145Third143Proof409
  · exact adaptive145Third143Proof410
  · exact adaptive145Third143Proof411
  · exact adaptive145Third143Proof412
  · exact adaptive145Third143Proof413
  · exact adaptive145Third143Proof414
  · exact adaptive145Third143Proof415
  · exact adaptive145Third143Proof416
  · exact adaptive145Third143Proof417
  · exact adaptive145Third143Proof418
  · exact adaptive145Third143Proof419
  · exact adaptive145Third143Proof420
  · exact adaptive145Third143Proof421

#print axioms adaptive145Third143Proof384

theorem adaptive145Third143Proof503 : runCachedNode 511 131040 Adaptive145Third143Node503 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 131040 Adaptive145Third143Node503 = [86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 131] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive145Third143Proof504
  · exact adaptive145Third143Proof505
  · exact adaptive145Third143Proof506
  · exact adaptive145Third143Proof507
  · exact adaptive145Third143Proof508
  · exact adaptive145Third143Proof509
  · exact adaptive145Third143Proof510
  · exact adaptive145Third143Proof511
  · exact adaptive145Third143Proof512
  · exact adaptive145Third143Proof513
  · exact adaptive145Third143Proof514
  · exact adaptive145Third143Proof515
  · exact adaptive145Third143Proof516
  · exact adaptive145Third143Proof517
  · exact adaptive145Third143Proof518
  · exact adaptive145Third143Proof519
  · exact adaptive145Third143Proof520
  · exact adaptive145Third143Proof521
  · exact adaptive145Third143Proof522
  · exact adaptive145Third143Proof523
  · exact adaptive145Third143Proof524
  · exact adaptive145Third143Proof525
  · exact adaptive145Third143Proof526
  · exact adaptive145Third143Proof527
  · exact adaptive145Third143Proof528
  · exact adaptive145Third143Proof529
  · exact adaptive145Third143Proof530
  · exact adaptive145Third143Proof531
  · exact adaptive145Third143Proof532
  · exact adaptive145Third143Proof533
  · exact adaptive145Third143Proof534
  · exact adaptive145Third143Proof535
  · exact adaptive145Third143Proof536
  · exact adaptive145Third143Proof537
  · exact adaptive145Third143Proof538
  · exact adaptive145Third143Proof539
  · exact adaptive145Third143Proof540
  · exact adaptive145Third143Proof541
  · exact adaptive145Third143Proof542
  · exact adaptive145Third143Proof543
  · exact adaptive145Third143Proof544
  · exact adaptive145Third143Proof545
  · exact adaptive145Third143Proof546
  · exact adaptive145Third143Proof547
  · exact adaptive145Third143Proof548

#print axioms adaptive145Third143Proof503

theorem adaptive145Third143Proof549 : runCachedNode 511 131040 Adaptive145Third143Node549 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 131040 Adaptive145Third143Node549 = [85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 132, 134] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive145Third143Proof550
  · exact adaptive145Third143Proof551
  · exact adaptive145Third143Proof552
  · exact adaptive145Third143Proof553
  · exact adaptive145Third143Proof554
  · exact adaptive145Third143Proof555
  · exact adaptive145Third143Proof556
  · exact adaptive145Third143Proof557
  · exact adaptive145Third143Proof558
  · exact adaptive145Third143Proof559
  · exact adaptive145Third143Proof560
  · exact adaptive145Third143Proof561
  · exact adaptive145Third143Proof562
  · exact adaptive145Third143Proof563
  · exact adaptive145Third143Proof564
  · exact adaptive145Third143Proof565
  · exact adaptive145Third143Proof566
  · exact adaptive145Third143Proof567
  · exact adaptive145Third143Proof568
  · exact adaptive145Third143Proof569
  · exact adaptive145Third143Proof570
  · exact adaptive145Third143Proof571
  · exact adaptive145Third143Proof572
  · exact adaptive145Third143Proof573
  · exact adaptive145Third143Proof574
  · exact adaptive145Third143Proof575
  · exact adaptive145Third143Proof576
  · exact adaptive145Third143Proof577
  · exact adaptive145Third143Proof578
  · exact adaptive145Third143Proof579
  · exact adaptive145Third143Proof580
  · exact adaptive145Third143Proof581
  · exact adaptive145Third143Proof582
  · exact adaptive145Third143Proof583
  · exact adaptive145Third143Proof584
  · exact adaptive145Third143Proof585
  · exact adaptive145Third143Proof586
  · exact adaptive145Third143Proof587
  · exact adaptive145Third143Proof588
  · exact adaptive145Third143Proof589
  · exact adaptive145Third143Proof590
  · exact adaptive145Third143Proof591
  · exact adaptive145Third143Proof592
  · exact adaptive145Third143Proof593
  · exact adaptive145Third143Proof594
  · exact adaptive145Third143Proof595
  · exact adaptive145Third143Proof596
  · exact adaptive145Third143Proof597
  · exact adaptive145Third143Proof598

#print axioms adaptive145Third143Proof549

theorem adaptive145Third143Proof465 : runCachedNode 511 131040 Adaptive145Third143Node465 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 131040 Adaptive145Third143Node465 = [100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 132, 133, 134, 135, 136, 138, 141] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive145Third143Proof466
  · exact adaptive145Third143Proof467
  · exact adaptive145Third143Proof468
  · exact adaptive145Third143Proof469
  · exact adaptive145Third143Proof470
  · exact adaptive145Third143Proof471
  · exact adaptive145Third143Proof472
  · exact adaptive145Third143Proof473
  · exact adaptive145Third143Proof474
  · exact adaptive145Third143Proof475
  · exact adaptive145Third143Proof476
  · exact adaptive145Third143Proof477
  · exact adaptive145Third143Proof478
  · exact adaptive145Third143Proof479
  · exact adaptive145Third143Proof480
  · exact adaptive145Third143Proof481
  · exact adaptive145Third143Proof482
  · exact adaptive145Third143Proof483
  · exact adaptive145Third143Proof484
  · exact adaptive145Third143Proof485
  · exact adaptive145Third143Proof486
  · exact adaptive145Third143Proof487
  · exact adaptive145Third143Proof488
  · exact adaptive145Third143Proof489
  · exact adaptive145Third143Proof490
  · exact adaptive145Third143Proof491
  · exact adaptive145Third143Proof492
  · exact adaptive145Third143Proof493
  · exact adaptive145Third143Proof494
  · exact adaptive145Third143Proof495
  · exact adaptive145Third143Proof496
  · exact adaptive145Third143Proof497
  · exact adaptive145Third143Proof498
  · exact adaptive145Third143Proof499
  · exact adaptive145Third143Proof500
  · exact adaptive145Third143Proof501
  · exact adaptive145Third143Proof502
  · exact adaptive145Third143Proof503
  · exact adaptive145Third143Proof549

#print axioms adaptive145Third143Proof465

end NineSeparatedSubsetSums
