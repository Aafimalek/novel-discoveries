import NineSeparatedSubsetSums.Adaptive145Third135State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third135Proof64 : runCachedNode 511 129879 Adaptive145Third135Node64 = false := by
  decide +kernel

#print axioms adaptive145Third135Proof64

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third135Proof6 : runCachedNode 511 129879 Adaptive145Third135Node6 = false := by
  decide +kernel

#print axioms adaptive145Third135Proof6

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third135Proof63 : runCachedNode 511 129879 Adaptive145Third135Node63 = false := by
  decide +kernel

#print axioms adaptive145Third135Proof63

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third135Proof5 : runCachedNode 511 129879 Adaptive145Third135Node5 = false := by
  decide +kernel

#print axioms adaptive145Third135Proof5

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third135Proof36 : runCachedNode 511 129879 Adaptive145Third135Node36 = false := by
  decide +kernel

#print axioms adaptive145Third135Proof36

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third135Proof62 : runCachedNode 511 129879 Adaptive145Third135Node62 = false := by
  decide +kernel

#print axioms adaptive145Third135Proof62

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third135Proof61 : runCachedNode 511 129879 Adaptive145Third135Node61 = false := by
  decide +kernel

#print axioms adaptive145Third135Proof61

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third135Proof34 : runCachedNode 511 129879 Adaptive145Third135Node34 = false := by
  decide +kernel

#print axioms adaptive145Third135Proof34

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third135Proof4 : runCachedNode 511 129879 Adaptive145Third135Node4 = false := by
  decide +kernel

#print axioms adaptive145Third135Proof4

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third135Proof60 : runCachedNode 511 129879 Adaptive145Third135Node60 = false := by
  decide +kernel

#print axioms adaptive145Third135Proof60

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third135Proof33 : runCachedNode 511 129879 Adaptive145Third135Node33 = false := by
  decide +kernel

#print axioms adaptive145Third135Proof33

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third135Proof59 : runCachedNode 511 129879 Adaptive145Third135Node59 = false := by
  decide +kernel

#print axioms adaptive145Third135Proof59

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third135Proof31 : runCachedNode 511 129879 Adaptive145Third135Node31 = false := by
  decide +kernel

#print axioms adaptive145Third135Proof31

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third135Proof58 : runCachedNode 511 129879 Adaptive145Third135Node58 = false := by
  decide +kernel

#print axioms adaptive145Third135Proof58

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third135Proof29 : runCachedNode 511 129879 Adaptive145Third135Node29 = false := by
  decide +kernel

#print axioms adaptive145Third135Proof29

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third135Proof2 : runCachedNode 511 129879 Adaptive145Third135Node2 = false := by
  decide +kernel

#print axioms adaptive145Third135Proof2

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third135Proof28 : runCachedNode 511 129879 Adaptive145Third135Node28 = false := by
  decide +kernel

#print axioms adaptive145Third135Proof28

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third135Proof56 : runCachedNode 511 129879 Adaptive145Third135Node56 = false := by
  decide +kernel

#print axioms adaptive145Third135Proof56

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third135Proof55 : runCachedNode 511 129879 Adaptive145Third135Node55 = false := by
  decide +kernel

#print axioms adaptive145Third135Proof55

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third135Proof27 : runCachedNode 511 129879 Adaptive145Third135Node27 = false := by
  decide +kernel

#print axioms adaptive145Third135Proof27

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third135Proof54 : runCachedNode 511 129879 Adaptive145Third135Node54 = false := by
  decide +kernel

#print axioms adaptive145Third135Proof54

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third135Proof53 : runCachedNode 511 129879 Adaptive145Third135Node53 = false := by
  decide +kernel

#print axioms adaptive145Third135Proof53

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third135Proof24 : runCachedNode 511 129879 Adaptive145Third135Node24 = false := by
  decide +kernel

#print axioms adaptive145Third135Proof24

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third135Proof25 : runCachedNode 511 129879 Adaptive145Third135Node25 = false := by
  decide +kernel

#print axioms adaptive145Third135Proof25

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third135Proof50 : runCachedNode 511 129879 Adaptive145Third135Node50 = false := by
  decide +kernel

#print axioms adaptive145Third135Proof50

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third135Proof51 : runCachedNode 511 129879 Adaptive145Third135Node51 = false := by
  decide +kernel

#print axioms adaptive145Third135Proof51

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third135Proof52 : runCachedNode 511 129879 Adaptive145Third135Node52 = false := by
  decide +kernel

#print axioms adaptive145Third135Proof52

end NineSeparatedSubsetSums
