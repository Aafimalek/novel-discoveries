import NineSeparatedSubsetSums.Adaptive145Third143State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof335 : runCachedNode 511 131040 Adaptive145Third143Node335 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof335

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof102 : runCachedNode 511 131040 Adaptive145Third143Node102 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof102

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof253 : runCachedNode 511 131040 Adaptive145Third143Node253 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof253

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof487 : runCachedNode 511 131040 Adaptive145Third143Node487 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof487

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof223 : runCachedNode 511 131040 Adaptive145Third143Node223 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof223

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof157 : runCachedNode 511 131040 Adaptive145Third143Node157 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof157

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof128 : runCachedNode 511 131040 Adaptive145Third143Node128 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof128

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof486 : runCachedNode 511 131040 Adaptive145Third143Node486 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof486

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof221 : runCachedNode 511 131040 Adaptive145Third143Node221 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof221

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof542 : runCachedNode 511 131040 Adaptive145Third143Node542 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof542

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof3 : runCachedNode 511 131040 Adaptive145Third143Node3 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof3

end NineSeparatedSubsetSums
