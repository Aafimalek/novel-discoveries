import NineSeparatedSubsetSums.Adaptive145Third142State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof281 : runCachedNode 511 130865 Adaptive145Third142Node281 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof281

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof253 : runCachedNode 511 130865 Adaptive145Third142Node253 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof253

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof163 : runCachedNode 511 130865 Adaptive145Third142Node163 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof163

end NineSeparatedSubsetSums
