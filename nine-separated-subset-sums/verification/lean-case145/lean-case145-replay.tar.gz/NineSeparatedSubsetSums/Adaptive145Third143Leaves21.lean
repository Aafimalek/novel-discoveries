import NineSeparatedSubsetSums.Adaptive145Third143State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof261 : runCachedNode 511 131040 Adaptive145Third143Node261 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof261

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof497 : runCachedNode 511 131040 Adaptive145Third143Node497 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof497

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof256 : runCachedNode 511 131040 Adaptive145Third143Node256 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof256

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof53 : runCachedNode 511 131040 Adaptive145Third143Node53 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof53

end NineSeparatedSubsetSums
