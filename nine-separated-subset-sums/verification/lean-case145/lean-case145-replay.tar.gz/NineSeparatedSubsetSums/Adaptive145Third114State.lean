import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive145Third114Node0 : CachedSearchNode :=
  ⟨4, 113, computeCenteredMask [148,145,114], 407, 55925⟩

end NineSeparatedSubsetSums
