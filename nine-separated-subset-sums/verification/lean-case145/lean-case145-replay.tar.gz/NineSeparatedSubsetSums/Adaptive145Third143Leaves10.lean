import NineSeparatedSubsetSums.Adaptive145Third143State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof501 : runCachedNode 511 131040 Adaptive145Third143Node501 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof501

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof414 : runCachedNode 511 131040 Adaptive145Third143Node414 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof414

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof26 : runCachedNode 511 131040 Adaptive145Third143Node26 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof26

end NineSeparatedSubsetSums
