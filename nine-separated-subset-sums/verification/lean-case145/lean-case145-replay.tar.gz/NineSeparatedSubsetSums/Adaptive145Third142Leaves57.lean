import NineSeparatedSubsetSums.Adaptive145Third142State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof108 : runCachedNode 511 130865 Adaptive145Third142Node108 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof108

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof277 : runCachedNode 511 130865 Adaptive145Third142Node277 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof277

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof109 : runCachedNode 511 130865 Adaptive145Third142Node109 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof109

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof453 : runCachedNode 511 130865 Adaptive145Third142Node453 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof453

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof133 : runCachedNode 511 130865 Adaptive145Third142Node133 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof133

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof10 : runCachedNode 511 130865 Adaptive145Third142Node10 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof10

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof311 : runCachedNode 511 130865 Adaptive145Third142Node311 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof311

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof60 : runCachedNode 511 130865 Adaptive145Third142Node60 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof60

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof160 : runCachedNode 511 130865 Adaptive145Third142Node160 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof160

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof67 : runCachedNode 511 130865 Adaptive145Third142Node67 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof67

end NineSeparatedSubsetSums
