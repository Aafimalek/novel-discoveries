import NineSeparatedSubsetSums.Adaptive145Third143State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof21 : runCachedNode 511 131040 Adaptive145Third143Node21 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof21

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof383 : runCachedNode 511 131040 Adaptive145Third143Node383 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof383

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof4 : runCachedNode 511 131040 Adaptive145Third143Node4 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof4

end NineSeparatedSubsetSums
