import NineSeparatedSubsetSums.Adaptive145Third141State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third141Proof418 : runCachedNode 511 130740 Adaptive145Third141Node418 = false := by
  decide +kernel

#print axioms adaptive145Third141Proof418

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third141Proof162 : runCachedNode 511 130740 Adaptive145Third141Node162 = false := by
  decide +kernel

#print axioms adaptive145Third141Proof162

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third141Proof372 : runCachedNode 511 130740 Adaptive145Third141Node372 = false := by
  decide +kernel

#print axioms adaptive145Third141Proof372

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third141Proof159 : runCachedNode 511 130740 Adaptive145Third141Node159 = false := by
  decide +kernel

#print axioms adaptive145Third141Proof159

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third141Proof368 : runCachedNode 511 130740 Adaptive145Third141Node368 = false := by
  decide +kernel

#print axioms adaptive145Third141Proof368

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third141Proof4 : runCachedNode 511 130740 Adaptive145Third141Node4 = false := by
  decide +kernel

#print axioms adaptive145Third141Proof4

end NineSeparatedSubsetSums
