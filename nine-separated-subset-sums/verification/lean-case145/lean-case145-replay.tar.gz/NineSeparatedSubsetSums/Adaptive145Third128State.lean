import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive145Third128Node0 : CachedSearchNode :=
  ⟨4, 127, computeCenteredMask [148,145,128], 421, 59313⟩
def Adaptive145Third128Node1 : CachedSearchNode := cachedChild Adaptive145Third128Node0 110
def Adaptive145Third128Node2 : CachedSearchNode := cachedChild Adaptive145Third128Node0 111
def Adaptive145Third128Node3 : CachedSearchNode := cachedChild Adaptive145Third128Node0 112
def Adaptive145Third128Node4 : CachedSearchNode := cachedChild Adaptive145Third128Node0 113
def Adaptive145Third128Node5 : CachedSearchNode := cachedChild Adaptive145Third128Node0 114
def Adaptive145Third128Node6 : CachedSearchNode := cachedChild Adaptive145Third128Node0 115
def Adaptive145Third128Node7 : CachedSearchNode := cachedChild Adaptive145Third128Node0 116
def Adaptive145Third128Node8 : CachedSearchNode := cachedChild Adaptive145Third128Node0 117
def Adaptive145Third128Node9 : CachedSearchNode := cachedChild Adaptive145Third128Node0 118
def Adaptive145Third128Node10 : CachedSearchNode := cachedChild Adaptive145Third128Node0 119
def Adaptive145Third128Node11 : CachedSearchNode := cachedChild Adaptive145Third128Node0 120
def Adaptive145Third128Node12 : CachedSearchNode := cachedChild Adaptive145Third128Node0 121
def Adaptive145Third128Node13 : CachedSearchNode := cachedChild Adaptive145Third128Node0 122
def Adaptive145Third128Node14 : CachedSearchNode := cachedChild Adaptive145Third128Node0 123
def Adaptive145Third128Node15 : CachedSearchNode := cachedChild Adaptive145Third128Node0 124
def Adaptive145Third128Node16 : CachedSearchNode := cachedChild Adaptive145Third128Node0 126
def Adaptive145Third128Node17 : CachedSearchNode := cachedChild Adaptive145Third128Node0 127

end NineSeparatedSubsetSums
