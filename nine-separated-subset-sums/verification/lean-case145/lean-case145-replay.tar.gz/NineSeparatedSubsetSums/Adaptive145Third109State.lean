import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive145Third109Node0 : CachedSearchNode :=
  ⟨4, 108, computeCenteredMask [148,145,109], 402, 54810⟩

end NineSeparatedSubsetSums
