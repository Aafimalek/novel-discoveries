import NineSeparatedSubsetSums.Adaptive145Third140State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third140Proof20 : runCachedNode 511 130597 Adaptive145Third140Node20 = false := by
  decide +kernel

#print axioms adaptive145Third140Proof20

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third140Proof132 : runCachedNode 511 130597 Adaptive145Third140Node132 = false := by
  decide +kernel

#print axioms adaptive145Third140Proof132

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third140Proof254 : runCachedNode 511 130597 Adaptive145Third140Node254 = false := by
  decide +kernel

#print axioms adaptive145Third140Proof254

end NineSeparatedSubsetSums
