import NineSeparatedSubsetSums.Adaptive145Third139State
import NineSeparatedSubsetSums.Adaptive145Third139Leaves5
import NineSeparatedSubsetSums.Adaptive145Third139Leaves18
import NineSeparatedSubsetSums.Adaptive145Third139Leaves17
import NineSeparatedSubsetSums.Adaptive145Third139Leaves16
import NineSeparatedSubsetSums.Adaptive145Third139Leaves14
import NineSeparatedSubsetSums.Adaptive145Third139Leaves15
import NineSeparatedSubsetSums.Adaptive145Third139Leaves13
import NineSeparatedSubsetSums.Adaptive145Third139Leaves12
import NineSeparatedSubsetSums.Adaptive145Third139Leaves11
import NineSeparatedSubsetSums.Adaptive145Third139Leaves6
import NineSeparatedSubsetSums.Adaptive145Third139Leaves2
import NineSeparatedSubsetSums.Adaptive145Third139Leaves4
import NineSeparatedSubsetSums.Adaptive145Third139Leaves10
import NineSeparatedSubsetSums.Adaptive145Third139Leaves9
import NineSeparatedSubsetSums.Adaptive145Third139Leaves8
import NineSeparatedSubsetSums.Adaptive145Third139Leaves3
import NineSeparatedSubsetSums.Adaptive145Third139Leaves7
import NineSeparatedSubsetSums.Adaptive145Third139Leaves0
import NineSeparatedSubsetSums.Adaptive145Third139Leaves19
import NineSeparatedSubsetSums.Adaptive145Third139Leaves1

namespace NineSeparatedSubsetSums

theorem adaptive145Third139Proof21 : runCachedNode 511 130465 Adaptive145Third139Node21 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130465 Adaptive145Third139Node21 = [104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 122, 123, 125, 126, 128, 129] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive145Third139Proof22
  · exact adaptive145Third139Proof23
  · exact adaptive145Third139Proof24
  · exact adaptive145Third139Proof25
  · exact adaptive145Third139Proof26
  · exact adaptive145Third139Proof27
  · exact adaptive145Third139Proof28
  · exact adaptive145Third139Proof29
  · exact adaptive145Third139Proof30
  · exact adaptive145Third139Proof31
  · exact adaptive145Third139Proof32
  · exact adaptive145Third139Proof33
  · exact adaptive145Third139Proof34
  · exact adaptive145Third139Proof35
  · exact adaptive145Third139Proof36
  · exact adaptive145Third139Proof37
  · exact adaptive145Third139Proof38
  · exact adaptive145Third139Proof39
  · exact adaptive145Third139Proof40
  · exact adaptive145Third139Proof41
  · exact adaptive145Third139Proof42
  · exact adaptive145Third139Proof43
  · exact adaptive145Third139Proof44

#print axioms adaptive145Third139Proof21

theorem adaptive145Third139Proof46 : runCachedNode 511 130465 Adaptive145Third139Node46 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130465 Adaptive145Third139Node46 = [103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 124, 125, 127, 128, 130, 131] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive145Third139Proof47
  · exact adaptive145Third139Proof48
  · exact adaptive145Third139Proof49
  · exact adaptive145Third139Proof50
  · exact adaptive145Third139Proof51
  · exact adaptive145Third139Proof52
  · exact adaptive145Third139Proof53
  · exact adaptive145Third139Proof54
  · exact adaptive145Third139Proof55
  · exact adaptive145Third139Proof56
  · exact adaptive145Third139Proof57
  · exact adaptive145Third139Proof58
  · exact adaptive145Third139Proof59
  · exact adaptive145Third139Proof60
  · exact adaptive145Third139Proof61
  · exact adaptive145Third139Proof62
  · exact adaptive145Third139Proof63
  · exact adaptive145Third139Proof64
  · exact adaptive145Third139Proof65
  · exact adaptive145Third139Proof66
  · exact adaptive145Third139Proof67
  · exact adaptive145Third139Proof68
  · exact adaptive145Third139Proof69
  · exact adaptive145Third139Proof70
  · exact adaptive145Third139Proof71
  · exact adaptive145Third139Proof72

#print axioms adaptive145Third139Proof46

theorem adaptive145Third139Proof73 : runCachedNode 511 130465 Adaptive145Third139Node73 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130465 Adaptive145Third139Node73 = [103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 125, 126, 128, 129, 131, 132] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive145Third139Proof74
  · exact adaptive145Third139Proof75
  · exact adaptive145Third139Proof76
  · exact adaptive145Third139Proof77
  · exact adaptive145Third139Proof78
  · exact adaptive145Third139Proof79
  · exact adaptive145Third139Proof80
  · exact adaptive145Third139Proof81
  · exact adaptive145Third139Proof82
  · exact adaptive145Third139Proof83
  · exact adaptive145Third139Proof84
  · exact adaptive145Third139Proof85
  · exact adaptive145Third139Proof86
  · exact adaptive145Third139Proof87
  · exact adaptive145Third139Proof88
  · exact adaptive145Third139Proof89
  · exact adaptive145Third139Proof90
  · exact adaptive145Third139Proof91
  · exact adaptive145Third139Proof92
  · exact adaptive145Third139Proof93
  · exact adaptive145Third139Proof94
  · exact adaptive145Third139Proof95
  · exact adaptive145Third139Proof96
  · exact adaptive145Third139Proof97
  · exact adaptive145Third139Proof98
  · exact adaptive145Third139Proof99
  · exact adaptive145Third139Proof100

#print axioms adaptive145Third139Proof73

theorem adaptive145Third139Proof101 : runCachedNode 511 130465 Adaptive145Third139Node101 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130465 Adaptive145Third139Node101 = [103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 126, 127, 129, 130, 132, 133] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive145Third139Proof102
  · exact adaptive145Third139Proof103
  · exact adaptive145Third139Proof104
  · exact adaptive145Third139Proof105
  · exact adaptive145Third139Proof106
  · exact adaptive145Third139Proof107
  · exact adaptive145Third139Proof108
  · exact adaptive145Third139Proof109
  · exact adaptive145Third139Proof110
  · exact adaptive145Third139Proof111
  · exact adaptive145Third139Proof112
  · exact adaptive145Third139Proof113
  · exact adaptive145Third139Proof114
  · exact adaptive145Third139Proof115
  · exact adaptive145Third139Proof116
  · exact adaptive145Third139Proof117
  · exact adaptive145Third139Proof118
  · exact adaptive145Third139Proof119
  · exact adaptive145Third139Proof120
  · exact adaptive145Third139Proof121
  · exact adaptive145Third139Proof122
  · exact adaptive145Third139Proof123
  · exact adaptive145Third139Proof124
  · exact adaptive145Third139Proof125
  · exact adaptive145Third139Proof126
  · exact adaptive145Third139Proof127
  · exact adaptive145Third139Proof128
  · exact adaptive145Third139Proof129

#print axioms adaptive145Third139Proof101

theorem adaptive145Third139Proof130 : runCachedNode 511 130465 Adaptive145Third139Node130 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130465 Adaptive145Third139Node130 = [102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 127, 128, 130, 131, 133, 134] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive145Third139Proof131
  · exact adaptive145Third139Proof132
  · exact adaptive145Third139Proof133
  · exact adaptive145Third139Proof134
  · exact adaptive145Third139Proof135
  · exact adaptive145Third139Proof136
  · exact adaptive145Third139Proof137
  · exact adaptive145Third139Proof138
  · exact adaptive145Third139Proof139
  · exact adaptive145Third139Proof140
  · exact adaptive145Third139Proof141
  · exact adaptive145Third139Proof142
  · exact adaptive145Third139Proof143
  · exact adaptive145Third139Proof144
  · exact adaptive145Third139Proof145
  · exact adaptive145Third139Proof146
  · exact adaptive145Third139Proof147
  · exact adaptive145Third139Proof148
  · exact adaptive145Third139Proof149
  · exact adaptive145Third139Proof150
  · exact adaptive145Third139Proof151
  · exact adaptive145Third139Proof152
  · exact adaptive145Third139Proof153
  · exact adaptive145Third139Proof154
  · exact adaptive145Third139Proof155
  · exact adaptive145Third139Proof156
  · exact adaptive145Third139Proof157
  · exact adaptive145Third139Proof158
  · exact adaptive145Third139Proof159
  · exact adaptive145Third139Proof160

#print axioms adaptive145Third139Proof130

theorem adaptive145Third139Proof161 : runCachedNode 511 130465 Adaptive145Third139Node161 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130465 Adaptive145Third139Node161 = [102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 129, 130, 132, 133, 135] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive145Third139Proof162
  · exact adaptive145Third139Proof163
  · exact adaptive145Third139Proof164
  · exact adaptive145Third139Proof165
  · exact adaptive145Third139Proof166
  · exact adaptive145Third139Proof167
  · exact adaptive145Third139Proof168
  · exact adaptive145Third139Proof169
  · exact adaptive145Third139Proof170
  · exact adaptive145Third139Proof171
  · exact adaptive145Third139Proof172
  · exact adaptive145Third139Proof173
  · exact adaptive145Third139Proof174
  · exact adaptive145Third139Proof175
  · exact adaptive145Third139Proof176
  · exact adaptive145Third139Proof177
  · exact adaptive145Third139Proof178
  · exact adaptive145Third139Proof179
  · exact adaptive145Third139Proof180
  · exact adaptive145Third139Proof181
  · exact adaptive145Third139Proof182
  · exact adaptive145Third139Proof183
  · exact adaptive145Third139Proof184
  · exact adaptive145Third139Proof185
  · exact adaptive145Third139Proof186
  · exact adaptive145Third139Proof187
  · exact adaptive145Third139Proof188
  · exact adaptive145Third139Proof189
  · exact adaptive145Third139Proof190
  · exact adaptive145Third139Proof191
  · exact adaptive145Third139Proof192

#print axioms adaptive145Third139Proof161

theorem adaptive145Third139Proof193 : runCachedNode 511 130465 Adaptive145Third139Node193 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130465 Adaptive145Third139Node193 = [102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 130, 131, 133, 134, 137] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive145Third139Proof194
  · exact adaptive145Third139Proof195
  · exact adaptive145Third139Proof196
  · exact adaptive145Third139Proof197
  · exact adaptive145Third139Proof198
  · exact adaptive145Third139Proof199
  · exact adaptive145Third139Proof200
  · exact adaptive145Third139Proof201
  · exact adaptive145Third139Proof202
  · exact adaptive145Third139Proof203
  · exact adaptive145Third139Proof204
  · exact adaptive145Third139Proof205
  · exact adaptive145Third139Proof206
  · exact adaptive145Third139Proof207
  · exact adaptive145Third139Proof208
  · exact adaptive145Third139Proof209
  · exact adaptive145Third139Proof210
  · exact adaptive145Third139Proof211
  · exact adaptive145Third139Proof212
  · exact adaptive145Third139Proof213
  · exact adaptive145Third139Proof214
  · exact adaptive145Third139Proof215
  · exact adaptive145Third139Proof216
  · exact adaptive145Third139Proof217
  · exact adaptive145Third139Proof218
  · exact adaptive145Third139Proof219
  · exact adaptive145Third139Proof220
  · exact adaptive145Third139Proof221
  · exact adaptive145Third139Proof222
  · exact adaptive145Third139Proof223
  · exact adaptive145Third139Proof224
  · exact adaptive145Third139Proof225

#print axioms adaptive145Third139Proof193

theorem adaptive145Third139Proof0 : runCachedNode 511 130465 Adaptive145Third139Node0 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130465 Adaptive145Third139Node0 = [110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 132, 133, 134, 135, 137, 138] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive145Third139Proof1
  · exact adaptive145Third139Proof2
  · exact adaptive145Third139Proof3
  · exact adaptive145Third139Proof4
  · exact adaptive145Third139Proof5
  · exact adaptive145Third139Proof6
  · exact adaptive145Third139Proof7
  · exact adaptive145Third139Proof8
  · exact adaptive145Third139Proof9
  · exact adaptive145Third139Proof10
  · exact adaptive145Third139Proof11
  · exact adaptive145Third139Proof12
  · exact adaptive145Third139Proof13
  · exact adaptive145Third139Proof14
  · exact adaptive145Third139Proof15
  · exact adaptive145Third139Proof16
  · exact adaptive145Third139Proof17
  · exact adaptive145Third139Proof18
  · exact adaptive145Third139Proof19
  · exact adaptive145Third139Proof20
  · exact adaptive145Third139Proof21
  · exact adaptive145Third139Proof45
  · exact adaptive145Third139Proof46
  · exact adaptive145Third139Proof73
  · exact adaptive145Third139Proof101
  · exact adaptive145Third139Proof130
  · exact adaptive145Third139Proof161
  · exact adaptive145Third139Proof193

#print axioms adaptive145Third139Proof0

end NineSeparatedSubsetSums
