import NineSeparatedSubsetSums.Adaptive145Third141State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third141Proof127 : runCachedNode 511 130740 Adaptive145Third141Node127 = false := by
  decide +kernel

#print axioms adaptive145Third141Proof127

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third141Proof341 : runCachedNode 511 130740 Adaptive145Third141Node341 = false := by
  decide +kernel

#print axioms adaptive145Third141Proof341

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third141Proof16 : runCachedNode 511 130740 Adaptive145Third141Node16 = false := by
  decide +kernel

#print axioms adaptive145Third141Proof16

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third141Proof296 : runCachedNode 511 130740 Adaptive145Third141Node296 = false := by
  decide +kernel

#print axioms adaptive145Third141Proof296

end NineSeparatedSubsetSums
