import NineSeparatedSubsetSums.Adaptive145Third136State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third136Proof19 : runCachedNode 511 130013 Adaptive145Third136Node19 = false := by
  decide +kernel

#print axioms adaptive145Third136Proof19

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third136Proof16 : runCachedNode 511 130013 Adaptive145Third136Node16 = false := by
  decide +kernel

#print axioms adaptive145Third136Proof16

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third136Proof114 : runCachedNode 511 130013 Adaptive145Third136Node114 = false := by
  decide +kernel

#print axioms adaptive145Third136Proof114

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third136Proof46 : runCachedNode 511 130013 Adaptive145Third136Node46 = false := by
  decide +kernel

#print axioms adaptive145Third136Proof46

end NineSeparatedSubsetSums
