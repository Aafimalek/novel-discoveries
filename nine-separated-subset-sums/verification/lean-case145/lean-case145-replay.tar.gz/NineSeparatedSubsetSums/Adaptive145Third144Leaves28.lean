import NineSeparatedSubsetSums.Adaptive145Third144State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third144Proof300 : runCachedNode 511 131183 Adaptive145Third144Node300 = false := by
  decide +kernel

#print axioms adaptive145Third144Proof300

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third144Proof17 : runCachedNode 511 131183 Adaptive145Third144Node17 = false := by
  decide +kernel

#print axioms adaptive145Third144Proof17

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third144Proof587 : runCachedNode 511 131183 Adaptive145Third144Node587 = false := by
  decide +kernel

#print axioms adaptive145Third144Proof587

end NineSeparatedSubsetSums
