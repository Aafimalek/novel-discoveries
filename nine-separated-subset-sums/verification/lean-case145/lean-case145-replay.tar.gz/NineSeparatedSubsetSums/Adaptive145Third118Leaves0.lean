import NineSeparatedSubsetSums.Adaptive145Third118State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third118Proof0 : runCachedNode 511 126075 Adaptive145Third118Node0 = false := by
  decide +kernel

#print axioms adaptive145Third118Proof0

end NineSeparatedSubsetSums
