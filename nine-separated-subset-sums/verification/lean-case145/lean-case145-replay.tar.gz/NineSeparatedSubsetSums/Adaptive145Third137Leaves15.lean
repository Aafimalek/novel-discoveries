import NineSeparatedSubsetSums.Adaptive145Third137State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third137Proof155 : runCachedNode 511 130164 Adaptive145Third137Node155 = false := by
  decide +kernel

#print axioms adaptive145Third137Proof155

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third137Proof156 : runCachedNode 511 130164 Adaptive145Third137Node156 = false := by
  decide +kernel

#print axioms adaptive145Third137Proof156

end NineSeparatedSubsetSums
