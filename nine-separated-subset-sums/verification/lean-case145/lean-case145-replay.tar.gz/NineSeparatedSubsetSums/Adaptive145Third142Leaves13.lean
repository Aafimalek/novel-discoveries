import NineSeparatedSubsetSums.Adaptive145Third142State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof654 : runCachedNode 511 130865 Adaptive145Third142Node654 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof654

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof949 : runCachedNode 511 130865 Adaptive145Third142Node949 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof949

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third142Proof46 : runCachedNode 511 130865 Adaptive145Third142Node46 = false := by
  decide +kernel

#print axioms adaptive145Third142Proof46

end NineSeparatedSubsetSums
