import NineSeparatedSubsetSums.Adaptive145Third131State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third131Proof19 : runCachedNode 511 129127 Adaptive145Third131Node19 = false := by
  decide +kernel

#print axioms adaptive145Third131Proof19

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third131Proof18 : runCachedNode 511 129127 Adaptive145Third131Node18 = false := by
  decide +kernel

#print axioms adaptive145Third131Proof18

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third131Proof14 : runCachedNode 511 129127 Adaptive145Third131Node14 = false := by
  decide +kernel

#print axioms adaptive145Third131Proof14

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third131Proof3 : runCachedNode 511 129127 Adaptive145Third131Node3 = false := by
  decide +kernel

#print axioms adaptive145Third131Proof3

end NineSeparatedSubsetSums
