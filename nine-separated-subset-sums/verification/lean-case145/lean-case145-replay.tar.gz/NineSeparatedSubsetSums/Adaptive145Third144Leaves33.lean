import NineSeparatedSubsetSums.Adaptive145Third144State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third144Proof261 : runCachedNode 511 131183 Adaptive145Third144Node261 = false := by
  decide +kernel

#print axioms adaptive145Third144Proof261

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third144Proof489 : runCachedNode 511 131183 Adaptive145Third144Node489 = false := by
  decide +kernel

#print axioms adaptive145Third144Proof489

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third144Proof224 : runCachedNode 511 131183 Adaptive145Third144Node224 = false := by
  decide +kernel

#print axioms adaptive145Third144Proof224

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third144Proof299 : runCachedNode 511 131183 Adaptive145Third144Node299 = false := by
  decide +kernel

#print axioms adaptive145Third144Proof299

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third144Proof89 : runCachedNode 511 131183 Adaptive145Third144Node89 = false := by
  decide +kernel

#print axioms adaptive145Third144Proof89

end NineSeparatedSubsetSums
