import NineSeparatedSubsetSums.Adaptive145Third143State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof597 : runCachedNode 511 131040 Adaptive145Third143Node597 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof597

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof230 : runCachedNode 511 131040 Adaptive145Third143Node230 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof230

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third143Proof85 : runCachedNode 511 131040 Adaptive145Third143Node85 = false := by
  decide +kernel

#print axioms adaptive145Third143Proof85

end NineSeparatedSubsetSums
