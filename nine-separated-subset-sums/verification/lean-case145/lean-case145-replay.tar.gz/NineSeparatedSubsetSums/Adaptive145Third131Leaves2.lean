import NineSeparatedSubsetSums.Adaptive145Third131State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third131Proof17 : runCachedNode 511 129127 Adaptive145Third131Node17 = false := by
  decide +kernel

#print axioms adaptive145Third131Proof17

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third131Proof15 : runCachedNode 511 129127 Adaptive145Third131Node15 = false := by
  decide +kernel

#print axioms adaptive145Third131Proof15

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third131Proof13 : runCachedNode 511 129127 Adaptive145Third131Node13 = false := by
  decide +kernel

#print axioms adaptive145Third131Proof13

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third131Proof12 : runCachedNode 511 129127 Adaptive145Third131Node12 = false := by
  decide +kernel

#print axioms adaptive145Third131Proof12

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third131Proof11 : runCachedNode 511 129127 Adaptive145Third131Node11 = false := by
  decide +kernel

#print axioms adaptive145Third131Proof11

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third131Proof10 : runCachedNode 511 129127 Adaptive145Third131Node10 = false := by
  decide +kernel

#print axioms adaptive145Third131Proof10

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third131Proof7 : runCachedNode 511 129127 Adaptive145Third131Node7 = false := by
  decide +kernel

#print axioms adaptive145Third131Proof7

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third131Proof2 : runCachedNode 511 129127 Adaptive145Third131Node2 = false := by
  decide +kernel

#print axioms adaptive145Third131Proof2

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive145Third131Proof1 : runCachedNode 511 129127 Adaptive145Third131Node1 = false := by
  decide +kernel

#print axioms adaptive145Third131Proof1

end NineSeparatedSubsetSums
