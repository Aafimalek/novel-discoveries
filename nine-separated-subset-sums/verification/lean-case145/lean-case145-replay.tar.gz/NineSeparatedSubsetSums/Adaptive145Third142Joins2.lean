import NineSeparatedSubsetSums.Adaptive145Third142State
import NineSeparatedSubsetSums.Adaptive145Third142Leaves82
import NineSeparatedSubsetSums.Adaptive145Third142Leaves81
import NineSeparatedSubsetSums.Adaptive145Third142Leaves80
import NineSeparatedSubsetSums.Adaptive145Third142Leaves78
import NineSeparatedSubsetSums.Adaptive145Third142Leaves77
import NineSeparatedSubsetSums.Adaptive145Third142Leaves76
import NineSeparatedSubsetSums.Adaptive145Third142Leaves75
import NineSeparatedSubsetSums.Adaptive145Third142Leaves74
import NineSeparatedSubsetSums.Adaptive145Third142Leaves73
import NineSeparatedSubsetSums.Adaptive145Third142Leaves72
import NineSeparatedSubsetSums.Adaptive145Third142Leaves71
import NineSeparatedSubsetSums.Adaptive145Third142Leaves70
import NineSeparatedSubsetSums.Adaptive145Third142Leaves68
import NineSeparatedSubsetSums.Adaptive145Third142Leaves65
import NineSeparatedSubsetSums.Adaptive145Third142Leaves67
import NineSeparatedSubsetSums.Adaptive145Third142Leaves63
import NineSeparatedSubsetSums.Adaptive145Third142Leaves62
import NineSeparatedSubsetSums.Adaptive145Third142Leaves55
import NineSeparatedSubsetSums.Adaptive145Third142Leaves52
import NineSeparatedSubsetSums.Adaptive145Third142Leaves38
import NineSeparatedSubsetSums.Adaptive145Third142Leaves18
import NineSeparatedSubsetSums.Adaptive145Third142Leaves79
import NineSeparatedSubsetSums.Adaptive145Third142Leaves69
import NineSeparatedSubsetSums.Adaptive145Third142Leaves60
import NineSeparatedSubsetSums.Adaptive145Third142Leaves56
import NineSeparatedSubsetSums.Adaptive145Third142Leaves51
import NineSeparatedSubsetSums.Adaptive145Third142Leaves45
import NineSeparatedSubsetSums.Adaptive145Third142Leaves0
import NineSeparatedSubsetSums.Adaptive145Third142Leaves66
import NineSeparatedSubsetSums.Adaptive145Third142Leaves61
import NineSeparatedSubsetSums.Adaptive145Third142Leaves59
import NineSeparatedSubsetSums.Adaptive145Third142Leaves53
import NineSeparatedSubsetSums.Adaptive145Third142Leaves41
import NineSeparatedSubsetSums.Adaptive145Third142Leaves33
import NineSeparatedSubsetSums.Adaptive145Third142Leaves43
import NineSeparatedSubsetSums.Adaptive145Third142Leaves27
import NineSeparatedSubsetSums.Adaptive145Third142Leaves28
import NineSeparatedSubsetSums.Adaptive145Third142Leaves39
import NineSeparatedSubsetSums.Adaptive145Third142Leaves1
import NineSeparatedSubsetSums.Adaptive145Third142Leaves17
import NineSeparatedSubsetSums.Adaptive145Third142Leaves5
import NineSeparatedSubsetSums.Adaptive145Third142Leaves58
import NineSeparatedSubsetSums.Adaptive145Third142Leaves46
import NineSeparatedSubsetSums.Adaptive145Third142Leaves12
import NineSeparatedSubsetSums.Adaptive145Third142Leaves83
import NineSeparatedSubsetSums.Adaptive145Third142Leaves50
import NineSeparatedSubsetSums.Adaptive145Third142Leaves48
import NineSeparatedSubsetSums.Adaptive145Third142Leaves36
import NineSeparatedSubsetSums.Adaptive145Third142Leaves4
import NineSeparatedSubsetSums.Adaptive145Third142Leaves42
import NineSeparatedSubsetSums.Adaptive145Third142Leaves16
import NineSeparatedSubsetSums.Adaptive145Third142Leaves6
import NineSeparatedSubsetSums.Adaptive145Third142Leaves11
import NineSeparatedSubsetSums.Adaptive145Third142Leaves32
import NineSeparatedSubsetSums.Adaptive145Third142Leaves9
import NineSeparatedSubsetSums.Adaptive145Third142Leaves13
import NineSeparatedSubsetSums.Adaptive145Third142Leaves7
import NineSeparatedSubsetSums.Adaptive145Third142Leaves23
import NineSeparatedSubsetSums.Adaptive145Third142Leaves64

namespace NineSeparatedSubsetSums

theorem adaptive145Third142Proof542 : runCachedNode 511 130865 Adaptive145Third142Node542 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130865 Adaptive145Third142Node542 = [89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 124, 125, 127, 128, 131, 134] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive145Third142Proof543
  · exact adaptive145Third142Proof544
  · exact adaptive145Third142Proof545
  · exact adaptive145Third142Proof546
  · exact adaptive145Third142Proof547
  · exact adaptive145Third142Proof548
  · exact adaptive145Third142Proof549
  · exact adaptive145Third142Proof550
  · exact adaptive145Third142Proof551
  · exact adaptive145Third142Proof552
  · exact adaptive145Third142Proof553
  · exact adaptive145Third142Proof554
  · exact adaptive145Third142Proof555
  · exact adaptive145Third142Proof556
  · exact adaptive145Third142Proof557
  · exact adaptive145Third142Proof558
  · exact adaptive145Third142Proof559
  · exact adaptive145Third142Proof560
  · exact adaptive145Third142Proof561
  · exact adaptive145Third142Proof562
  · exact adaptive145Third142Proof563
  · exact adaptive145Third142Proof564
  · exact adaptive145Third142Proof565
  · exact adaptive145Third142Proof566
  · exact adaptive145Third142Proof567
  · exact adaptive145Third142Proof568
  · exact adaptive145Third142Proof569
  · exact adaptive145Third142Proof570
  · exact adaptive145Third142Proof571
  · exact adaptive145Third142Proof572
  · exact adaptive145Third142Proof573
  · exact adaptive145Third142Proof574
  · exact adaptive145Third142Proof575
  · exact adaptive145Third142Proof576
  · exact adaptive145Third142Proof577
  · exact adaptive145Third142Proof578
  · exact adaptive145Third142Proof579
  · exact adaptive145Third142Proof580
  · exact adaptive145Third142Proof581
  · exact adaptive145Third142Proof582

#print axioms adaptive145Third142Proof542

theorem adaptive145Third142Proof583 : runCachedNode 511 130865 Adaptive145Third142Node583 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130865 Adaptive145Third142Node583 = [89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 125, 126, 128, 129] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive145Third142Proof584
  · exact adaptive145Third142Proof585
  · exact adaptive145Third142Proof586
  · exact adaptive145Third142Proof587
  · exact adaptive145Third142Proof588
  · exact adaptive145Third142Proof589
  · exact adaptive145Third142Proof590
  · exact adaptive145Third142Proof591
  · exact adaptive145Third142Proof592
  · exact adaptive145Third142Proof593
  · exact adaptive145Third142Proof594
  · exact adaptive145Third142Proof595
  · exact adaptive145Third142Proof596
  · exact adaptive145Third142Proof597
  · exact adaptive145Third142Proof598
  · exact adaptive145Third142Proof599
  · exact adaptive145Third142Proof600
  · exact adaptive145Third142Proof601
  · exact adaptive145Third142Proof602
  · exact adaptive145Third142Proof603
  · exact adaptive145Third142Proof604
  · exact adaptive145Third142Proof605
  · exact adaptive145Third142Proof606
  · exact adaptive145Third142Proof607
  · exact adaptive145Third142Proof608
  · exact adaptive145Third142Proof609
  · exact adaptive145Third142Proof610
  · exact adaptive145Third142Proof611
  · exact adaptive145Third142Proof612
  · exact adaptive145Third142Proof613
  · exact adaptive145Third142Proof614
  · exact adaptive145Third142Proof615
  · exact adaptive145Third142Proof616
  · exact adaptive145Third142Proof617
  · exact adaptive145Third142Proof618
  · exact adaptive145Third142Proof619
  · exact adaptive145Third142Proof620
  · exact adaptive145Third142Proof621
  · exact adaptive145Third142Proof622

#print axioms adaptive145Third142Proof583

theorem adaptive145Third142Proof508 : runCachedNode 511 130865 Adaptive145Third142Node508 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130865 Adaptive145Third142Node508 = [101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 133, 134, 136, 137] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive145Third142Proof509
  · exact adaptive145Third142Proof510
  · exact adaptive145Third142Proof511
  · exact adaptive145Third142Proof512
  · exact adaptive145Third142Proof513
  · exact adaptive145Third142Proof514
  · exact adaptive145Third142Proof515
  · exact adaptive145Third142Proof516
  · exact adaptive145Third142Proof517
  · exact adaptive145Third142Proof518
  · exact adaptive145Third142Proof519
  · exact adaptive145Third142Proof520
  · exact adaptive145Third142Proof521
  · exact adaptive145Third142Proof522
  · exact adaptive145Third142Proof523
  · exact adaptive145Third142Proof524
  · exact adaptive145Third142Proof525
  · exact adaptive145Third142Proof526
  · exact adaptive145Third142Proof527
  · exact adaptive145Third142Proof528
  · exact adaptive145Third142Proof529
  · exact adaptive145Third142Proof530
  · exact adaptive145Third142Proof531
  · exact adaptive145Third142Proof532
  · exact adaptive145Third142Proof533
  · exact adaptive145Third142Proof534
  · exact adaptive145Third142Proof535
  · exact adaptive145Third142Proof536
  · exact adaptive145Third142Proof537
  · exact adaptive145Third142Proof538
  · exact adaptive145Third142Proof539
  · exact adaptive145Third142Proof540
  · exact adaptive145Third142Proof541
  · exact adaptive145Third142Proof542
  · exact adaptive145Third142Proof583

#print axioms adaptive145Third142Proof508

theorem adaptive145Third142Proof657 : runCachedNode 511 130865 Adaptive145Third142Node657 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130865 Adaptive145Third142Node657 = [89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 125, 126, 128, 131] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive145Third142Proof658
  · exact adaptive145Third142Proof659
  · exact adaptive145Third142Proof660
  · exact adaptive145Third142Proof661
  · exact adaptive145Third142Proof662
  · exact adaptive145Third142Proof663
  · exact adaptive145Third142Proof664
  · exact adaptive145Third142Proof665
  · exact adaptive145Third142Proof666
  · exact adaptive145Third142Proof667
  · exact adaptive145Third142Proof668
  · exact adaptive145Third142Proof669
  · exact adaptive145Third142Proof670
  · exact adaptive145Third142Proof671
  · exact adaptive145Third142Proof672
  · exact adaptive145Third142Proof673
  · exact adaptive145Third142Proof674
  · exact adaptive145Third142Proof675
  · exact adaptive145Third142Proof676
  · exact adaptive145Third142Proof677
  · exact adaptive145Third142Proof678
  · exact adaptive145Third142Proof679
  · exact adaptive145Third142Proof680
  · exact adaptive145Third142Proof681
  · exact adaptive145Third142Proof682
  · exact adaptive145Third142Proof683
  · exact adaptive145Third142Proof684
  · exact adaptive145Third142Proof685
  · exact adaptive145Third142Proof686
  · exact adaptive145Third142Proof687
  · exact adaptive145Third142Proof688
  · exact adaptive145Third142Proof689
  · exact adaptive145Third142Proof690
  · exact adaptive145Third142Proof691
  · exact adaptive145Third142Proof692
  · exact adaptive145Third142Proof693
  · exact adaptive145Third142Proof694
  · exact adaptive145Third142Proof695
  · exact adaptive145Third142Proof696

#print axioms adaptive145Third142Proof657

theorem adaptive145Third142Proof697 : runCachedNode 511 130865 Adaptive145Third142Node697 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130865 Adaptive145Third142Node697 = [88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 126, 127, 129, 132] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive145Third142Proof698
  · exact adaptive145Third142Proof699
  · exact adaptive145Third142Proof700
  · exact adaptive145Third142Proof701
  · exact adaptive145Third142Proof702
  · exact adaptive145Third142Proof703
  · exact adaptive145Third142Proof704
  · exact adaptive145Third142Proof705
  · exact adaptive145Third142Proof706
  · exact adaptive145Third142Proof707
  · exact adaptive145Third142Proof708
  · exact adaptive145Third142Proof709
  · exact adaptive145Third142Proof710
  · exact adaptive145Third142Proof711
  · exact adaptive145Third142Proof712
  · exact adaptive145Third142Proof713
  · exact adaptive145Third142Proof714
  · exact adaptive145Third142Proof715
  · exact adaptive145Third142Proof716
  · exact adaptive145Third142Proof717
  · exact adaptive145Third142Proof718
  · exact adaptive145Third142Proof719
  · exact adaptive145Third142Proof720
  · exact adaptive145Third142Proof721
  · exact adaptive145Third142Proof722
  · exact adaptive145Third142Proof723
  · exact adaptive145Third142Proof724
  · exact adaptive145Third142Proof725
  · exact adaptive145Third142Proof726
  · exact adaptive145Third142Proof727
  · exact adaptive145Third142Proof728
  · exact adaptive145Third142Proof729
  · exact adaptive145Third142Proof730
  · exact adaptive145Third142Proof731
  · exact adaptive145Third142Proof732
  · exact adaptive145Third142Proof733
  · exact adaptive145Third142Proof734
  · exact adaptive145Third142Proof735
  · exact adaptive145Third142Proof736
  · exact adaptive145Third142Proof737
  · exact adaptive145Third142Proof738

#print axioms adaptive145Third142Proof697

theorem adaptive145Third142Proof739 : runCachedNode 511 130865 Adaptive145Third142Node739 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130865 Adaptive145Third142Node739 = [87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 128, 129, 131] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive145Third142Proof740
  · exact adaptive145Third142Proof741
  · exact adaptive145Third142Proof742
  · exact adaptive145Third142Proof743
  · exact adaptive145Third142Proof744
  · exact adaptive145Third142Proof745
  · exact adaptive145Third142Proof746
  · exact adaptive145Third142Proof747
  · exact adaptive145Third142Proof748
  · exact adaptive145Third142Proof749
  · exact adaptive145Third142Proof750
  · exact adaptive145Third142Proof751
  · exact adaptive145Third142Proof752
  · exact adaptive145Third142Proof753
  · exact adaptive145Third142Proof754
  · exact adaptive145Third142Proof755
  · exact adaptive145Third142Proof756
  · exact adaptive145Third142Proof757
  · exact adaptive145Third142Proof758
  · exact adaptive145Third142Proof759
  · exact adaptive145Third142Proof760
  · exact adaptive145Third142Proof761
  · exact adaptive145Third142Proof762
  · exact adaptive145Third142Proof763
  · exact adaptive145Third142Proof764
  · exact adaptive145Third142Proof765
  · exact adaptive145Third142Proof766
  · exact adaptive145Third142Proof767
  · exact adaptive145Third142Proof768
  · exact adaptive145Third142Proof769
  · exact adaptive145Third142Proof770
  · exact adaptive145Third142Proof771
  · exact adaptive145Third142Proof772
  · exact adaptive145Third142Proof773
  · exact adaptive145Third142Proof774
  · exact adaptive145Third142Proof775
  · exact adaptive145Third142Proof776
  · exact adaptive145Third142Proof777
  · exact adaptive145Third142Proof778
  · exact adaptive145Third142Proof779
  · exact adaptive145Third142Proof780
  · exact adaptive145Third142Proof781
  · exact adaptive145Third142Proof782

#print axioms adaptive145Third142Proof739

theorem adaptive145Third142Proof623 : runCachedNode 511 130865 Adaptive145Third142Node623 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130865 Adaptive145Third142Node623 = [101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 132, 133, 135, 136, 138] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive145Third142Proof624
  · exact adaptive145Third142Proof625
  · exact adaptive145Third142Proof626
  · exact adaptive145Third142Proof627
  · exact adaptive145Third142Proof628
  · exact adaptive145Third142Proof629
  · exact adaptive145Third142Proof630
  · exact adaptive145Third142Proof631
  · exact adaptive145Third142Proof632
  · exact adaptive145Third142Proof633
  · exact adaptive145Third142Proof634
  · exact adaptive145Third142Proof635
  · exact adaptive145Third142Proof636
  · exact adaptive145Third142Proof637
  · exact adaptive145Third142Proof638
  · exact adaptive145Third142Proof639
  · exact adaptive145Third142Proof640
  · exact adaptive145Third142Proof641
  · exact adaptive145Third142Proof642
  · exact adaptive145Third142Proof643
  · exact adaptive145Third142Proof644
  · exact adaptive145Third142Proof645
  · exact adaptive145Third142Proof646
  · exact adaptive145Third142Proof647
  · exact adaptive145Third142Proof648
  · exact adaptive145Third142Proof649
  · exact adaptive145Third142Proof650
  · exact adaptive145Third142Proof651
  · exact adaptive145Third142Proof652
  · exact adaptive145Third142Proof653
  · exact adaptive145Third142Proof654
  · exact adaptive145Third142Proof655
  · exact adaptive145Third142Proof656
  · exact adaptive145Third142Proof657
  · exact adaptive145Third142Proof697
  · exact adaptive145Third142Proof739

#print axioms adaptive145Third142Proof623

theorem adaptive145Third142Proof819 : runCachedNode 511 130865 Adaptive145Third142Node819 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130865 Adaptive145Third142Node819 = [88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 127, 128, 131] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive145Third142Proof820
  · exact adaptive145Third142Proof821
  · exact adaptive145Third142Proof822
  · exact adaptive145Third142Proof823
  · exact adaptive145Third142Proof824
  · exact adaptive145Third142Proof825
  · exact adaptive145Third142Proof826
  · exact adaptive145Third142Proof827
  · exact adaptive145Third142Proof828
  · exact adaptive145Third142Proof829
  · exact adaptive145Third142Proof830
  · exact adaptive145Third142Proof831
  · exact adaptive145Third142Proof832
  · exact adaptive145Third142Proof833
  · exact adaptive145Third142Proof834
  · exact adaptive145Third142Proof835
  · exact adaptive145Third142Proof836
  · exact adaptive145Third142Proof837
  · exact adaptive145Third142Proof838
  · exact adaptive145Third142Proof839
  · exact adaptive145Third142Proof840
  · exact adaptive145Third142Proof841
  · exact adaptive145Third142Proof842
  · exact adaptive145Third142Proof843
  · exact adaptive145Third142Proof844
  · exact adaptive145Third142Proof845
  · exact adaptive145Third142Proof846
  · exact adaptive145Third142Proof847
  · exact adaptive145Third142Proof848
  · exact adaptive145Third142Proof849
  · exact adaptive145Third142Proof850
  · exact adaptive145Third142Proof851
  · exact adaptive145Third142Proof852
  · exact adaptive145Third142Proof853
  · exact adaptive145Third142Proof854
  · exact adaptive145Third142Proof855
  · exact adaptive145Third142Proof856
  · exact adaptive145Third142Proof857
  · exact adaptive145Third142Proof858
  · exact adaptive145Third142Proof859
  · exact adaptive145Third142Proof860

#print axioms adaptive145Third142Proof819

end NineSeparatedSubsetSums
