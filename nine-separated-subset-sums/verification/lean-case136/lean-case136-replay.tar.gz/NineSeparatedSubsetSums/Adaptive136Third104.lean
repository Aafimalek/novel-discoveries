import NineSeparatedSubsetSums.Adaptive136Third104Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint136Checked

namespace NineSeparatedSubsetSums


theorem adaptive136Third104 : NoDescendingTailAfterThird 136 104 :=
  noDescendingThirdTail_of_cached 136 104 110825 (fun t ht nd => max148_second136_fourPoint_moment_bound (104::t) (by simp [ht]) nd) adaptive136Third104Proof0

#print axioms adaptive136Third104

end NineSeparatedSubsetSums
