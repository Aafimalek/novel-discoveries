import NineSeparatedSubsetSums.EightPointPackedGeometry
import NineSeparatedSubsetSums.EightPoint136_134PackedBudget0
import NineSeparatedSubsetSums.EightPoint136_134PackedAnchor0Part0
import NineSeparatedSubsetSums.EightPoint136_134PackedAnchor0Part1
import NineSeparatedSubsetSums.EightPoint136_134PackedAnchor0Part2
import NineSeparatedSubsetSums.EightPoint136_134PackedBudget1
import NineSeparatedSubsetSums.EightPoint136_134PackedAnchor1Part0
import NineSeparatedSubsetSums.EightPoint136_134PackedAnchor1Part1
import NineSeparatedSubsetSums.EightPoint136_134PackedAnchor1Part2

namespace NineSeparatedSubsetSums

private theorem packedOct136_134Anchor0 :
  ∀ j : Fin 494, ((j.val : Int)+136+134)%2=0 →
    2412010 ≤ FourPointNumeric.octPackedCharge 136 134 20 packedOct136_134_0 (j.val : Int) := by
  intro j hj
  let k := (j.val-0)/2
  have hk : k < 247 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+0 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint136_134PackedAnchor0Part0 z
    rwa [he,hrep] at ht
  by_cases h1 : k < 240
  · let z : Fin 120 := ⟨k-120, by omega⟩
    have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
    have ht := eightPoint136_134PackedAnchor0Part1 z
    rwa [he,hrep] at ht
  let z : Fin 7 := ⟨k-240, by omega⟩
  have he : (z.val : Int)+240 = k := by dsimp [z] <;> omega
  have ht := eightPoint136_134PackedAnchor0Part2 z
  rwa [he,hrep] at ht

private theorem packedOct136_134Anchor1 :
  ∀ j : Fin 494, ((j.val : Int)+136+134)%2=1 →
    2411714 ≤ FourPointNumeric.octPackedCharge 136 134 20 packedOct136_134_1 (j.val : Int) := by
  intro j hj
  let k := (j.val-1)/2
  have hk : k < 247 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+1 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint136_134PackedAnchor1Part0 z
    rwa [he,hrep] at ht
  by_cases h1 : k < 240
  · let z : Fin 120 := ⟨k-120, by omega⟩
    have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
    have ht := eightPoint136_134PackedAnchor1Part1 z
    rwa [he,hrep] at ht
  let z : Fin 7 := ⟨k-240, by omega⟩
  have he : (z.val : Int)+240 = k := by dsimp [z] <;> omega
  have ht := eightPoint136_134PackedAnchor1Part2 z
  rwa [he,hrep] at ht

def packedOctCertificate136_134_0 : EightPointCertificate 136 134 0 127846 :=
  eightPointCertificateOfPacked 136 134 0 127846 2412010 20 packedOct136_134_0 279 494
    (by decide +kernel) (by decide) packedOct136_134Anchor0
    (by rw [packedOct136_134_0_budget]; decide)

def packedOctCertificate136_134_1 : EightPointCertificate 136 134 1 127846 :=
  eightPointCertificateOfPacked 136 134 1 127846 2411714 20 packedOct136_134_1 280 494
    (by decide +kernel) (by decide) packedOct136_134Anchor1
    (by rw [packedOct136_134_1_budget]; decide)

theorem max148_second136_third134_eightPoint_moment_bound (tail : List ℕ) (len : tail.length=6)
    (distinct : (natSubsetSums (148::136::134::tail)).Nodup) :
    127846 ≤ ((148::136::134::tail).map (· ^ 2)).sum := by
  apply eightPointNatMomentLower 136 134 127846 tail len distinct
  intro p hp
  by_cases h : p=0
  · subst p
    exact packedOctCertificate136_134_0
  · have he : p=1 := hp.resolve_left h
    subst p
    exact packedOctCertificate136_134_1

#print axioms max148_second136_third134_eightPoint_moment_bound

end NineSeparatedSubsetSums
