import NineSeparatedSubsetSums.Adaptive136Third110Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint136Checked

namespace NineSeparatedSubsetSums


theorem adaptive136Third110 : NoDescendingTailAfterThird 136 110 :=
  noDescendingThirdTail_of_cached 136 110 110825 (fun t ht nd => max148_second136_fourPoint_moment_bound (110::t) (by simp [ht]) nd) adaptive136Third110Proof0

#print axioms adaptive136Third110

end NineSeparatedSubsetSums
