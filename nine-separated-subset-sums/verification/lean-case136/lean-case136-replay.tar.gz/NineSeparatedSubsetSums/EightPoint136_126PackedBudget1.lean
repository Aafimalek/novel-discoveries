import NineSeparatedSubsetSums.EightPoint136_126PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct136_126_1_budget :
    FourPointNumeric.packedBudget 20 packedOct136_126_1 260 = 84732794 := by decide +kernel

#print axioms packedOct136_126_1_budget

end NineSeparatedSubsetSums
