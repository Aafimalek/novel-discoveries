import NineSeparatedSubsetSums.Adaptive136Third134State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive136Third134Proof41 : runCachedNode 511 127846 Adaptive136Third134Node41 = false := by
  decide +kernel

#print axioms adaptive136Third134Proof41

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive136Third134Proof40 : runCachedNode 511 127846 Adaptive136Third134Node40 = false := by
  decide +kernel

#print axioms adaptive136Third134Proof40

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive136Third134Proof69 : runCachedNode 511 127846 Adaptive136Third134Node69 = false := by
  decide +kernel

#print axioms adaptive136Third134Proof69

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive136Third134Proof10 : runCachedNode 511 127846 Adaptive136Third134Node10 = false := by
  decide +kernel

#print axioms adaptive136Third134Proof10

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive136Third134Proof12 : runCachedNode 511 127846 Adaptive136Third134Node12 = false := by
  decide +kernel

#print axioms adaptive136Third134Proof12

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive136Third134Proof39 : runCachedNode 511 127846 Adaptive136Third134Node39 = false := by
  decide +kernel

#print axioms adaptive136Third134Proof39

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive136Third134Proof11 : runCachedNode 511 127846 Adaptive136Third134Node11 = false := by
  decide +kernel

#print axioms adaptive136Third134Proof11

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive136Third134Proof68 : runCachedNode 511 127846 Adaptive136Third134Node68 = false := by
  decide +kernel

#print axioms adaptive136Third134Proof68

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive136Third134Proof64 : runCachedNode 511 127846 Adaptive136Third134Node64 = false := by
  decide +kernel

#print axioms adaptive136Third134Proof64

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive136Third134Proof9 : runCachedNode 511 127846 Adaptive136Third134Node9 = false := by
  decide +kernel

#print axioms adaptive136Third134Proof9

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive136Third134Proof8 : runCachedNode 511 127846 Adaptive136Third134Node8 = false := by
  decide +kernel

#print axioms adaptive136Third134Proof8

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive136Third134Proof46 : runCachedNode 511 127846 Adaptive136Third134Node46 = false := by
  decide +kernel

#print axioms adaptive136Third134Proof46

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive136Third134Proof47 : runCachedNode 511 127846 Adaptive136Third134Node47 = false := by
  decide +kernel

#print axioms adaptive136Third134Proof47

end NineSeparatedSubsetSums
