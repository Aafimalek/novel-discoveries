import NineSeparatedSubsetSums.EightPoint136_124PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct136_124_1_budget :
    FourPointNumeric.packedBudget 20 packedOct136_124_1 260 = 82133932 := by decide +kernel

#print axioms packedOct136_124_1_budget

end NineSeparatedSubsetSums
