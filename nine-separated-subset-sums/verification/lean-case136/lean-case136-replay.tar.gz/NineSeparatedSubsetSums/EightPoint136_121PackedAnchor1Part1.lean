import NineSeparatedSubsetSums.EightPoint136_121PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint136_121PackedAnchor1Part1 :
    ∀ j : Fin 120, 2309292 ≤ FourPointNumeric.octPackedCharge 136 121 20 packedOct136_121_1
      (2*((j.val : Int)+120)+0) := by decide +kernel

end NineSeparatedSubsetSums
