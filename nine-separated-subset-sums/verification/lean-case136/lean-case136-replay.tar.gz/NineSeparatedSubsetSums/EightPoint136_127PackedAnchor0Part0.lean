import NineSeparatedSubsetSums.EightPoint136_127PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint136_127PackedAnchor0Part0 :
    ∀ j : Fin 120, 2345694 ≤ FourPointNumeric.octPackedCharge 136 127 20 packedOct136_127_0
      (2*((j.val : Int)+0)+1) := by decide +kernel

end NineSeparatedSubsetSums
