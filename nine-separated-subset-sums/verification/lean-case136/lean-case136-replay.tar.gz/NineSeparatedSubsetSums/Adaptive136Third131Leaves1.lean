import NineSeparatedSubsetSums.Adaptive136Third131State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive136Third131Proof18 : runCachedNode 511 127350 Adaptive136Third131Node18 = false := by
  decide +kernel

#print axioms adaptive136Third131Proof18

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive136Third131Proof15 : runCachedNode 511 127350 Adaptive136Third131Node15 = false := by
  decide +kernel

#print axioms adaptive136Third131Proof15

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive136Third131Proof16 : runCachedNode 511 127350 Adaptive136Third131Node16 = false := by
  decide +kernel

#print axioms adaptive136Third131Proof16

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive136Third131Proof6 : runCachedNode 511 127350 Adaptive136Third131Node6 = false := by
  decide +kernel

#print axioms adaptive136Third131Proof6

end NineSeparatedSubsetSums
