import NineSeparatedSubsetSums.EightPoint136_133PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint136_133PackedAnchor0Part2 :
    ∀ j : Fin 6, 2407705 ≤ FourPointNumeric.octPackedCharge 136 133 20 packedOct136_133_0
      (2*((j.val : Int)+240)+1) := by decide +kernel

end NineSeparatedSubsetSums
