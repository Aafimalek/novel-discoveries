import NineSeparatedSubsetSums.EightPoint136_135PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint136_135PackedAnchor0Part1 :
    ∀ j : Fin 120, 2428283 ≤ FourPointNumeric.octPackedCharge 136 135 20 packedOct136_135_0
      (2*((j.val : Int)+120)+1) := by decide +kernel

end NineSeparatedSubsetSums
