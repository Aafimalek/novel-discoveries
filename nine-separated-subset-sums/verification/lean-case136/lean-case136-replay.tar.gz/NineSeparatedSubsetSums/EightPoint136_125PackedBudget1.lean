import NineSeparatedSubsetSums.EightPoint136_125PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct136_125_1_budget :
    FourPointNumeric.packedBudget 20 packedOct136_125_1 488 = 83089872 := by decide +kernel

#print axioms packedOct136_125_1_budget

end NineSeparatedSubsetSums
