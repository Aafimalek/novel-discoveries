import NineSeparatedSubsetSums.EightPoint136_120PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint136_120PackedAnchor1Part2 :
    ∀ j : Fin 4, 2331062 ≤ FourPointNumeric.octPackedCharge 136 120 20 packedOct136_120_1
      (2*((j.val : Int)+240)+1) := by decide +kernel

end NineSeparatedSubsetSums
