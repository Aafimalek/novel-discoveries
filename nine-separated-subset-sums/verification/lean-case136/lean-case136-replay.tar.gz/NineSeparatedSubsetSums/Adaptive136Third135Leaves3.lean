import NineSeparatedSubsetSums.Adaptive136Third135State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive136Third135Proof20 : runCachedNode 511 128045 Adaptive136Third135Node20 = false := by
  decide +kernel

#print axioms adaptive136Third135Proof20

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive136Third135Proof13 : runCachedNode 511 128045 Adaptive136Third135Node13 = false := by
  decide +kernel

#print axioms adaptive136Third135Proof13

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive136Third135Proof7 : runCachedNode 511 128045 Adaptive136Third135Node7 = false := by
  decide +kernel

#print axioms adaptive136Third135Proof7

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive136Third135Proof26 : runCachedNode 511 128045 Adaptive136Third135Node26 = false := by
  decide +kernel

#print axioms adaptive136Third135Proof26

end NineSeparatedSubsetSums
