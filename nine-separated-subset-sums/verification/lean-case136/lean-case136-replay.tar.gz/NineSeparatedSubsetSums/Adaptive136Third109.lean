import NineSeparatedSubsetSums.Adaptive136Third109Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint136Checked

namespace NineSeparatedSubsetSums


theorem adaptive136Third109 : NoDescendingTailAfterThird 136 109 :=
  noDescendingThirdTail_of_cached 136 109 110825 (fun t ht nd => max148_second136_fourPoint_moment_bound (109::t) (by simp [ht]) nd) adaptive136Third109Proof0

#print axioms adaptive136Third109

end NineSeparatedSubsetSums
