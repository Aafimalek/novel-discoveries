import NineSeparatedSubsetSums.Adaptive136Third133State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive136Third133Proof21 : runCachedNode 511 127674 Adaptive136Third133Node21 = false := by
  decide +kernel

#print axioms adaptive136Third133Proof21

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive136Third133Proof10 : runCachedNode 511 127674 Adaptive136Third133Node10 = false := by
  decide +kernel

#print axioms adaptive136Third133Proof10

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive136Third133Proof4 : runCachedNode 511 127674 Adaptive136Third133Node4 = false := by
  decide +kernel

#print axioms adaptive136Third133Proof4

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive136Third133Proof1 : runCachedNode 511 127674 Adaptive136Third133Node1 = false := by
  decide +kernel

#print axioms adaptive136Third133Proof1

end NineSeparatedSubsetSums
