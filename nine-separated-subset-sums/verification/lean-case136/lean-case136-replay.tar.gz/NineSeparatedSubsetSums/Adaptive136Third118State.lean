import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive136Third118Node0 : CachedSearchNode :=
  ⟨4, 117, computeCenteredMask [148,136,118], 402, 54324⟩

end NineSeparatedSubsetSums
