import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive136Third119Node0 : CachedSearchNode :=
  ⟨4, 118, computeCenteredMask [148,136,119], 403, 54561⟩

end NineSeparatedSubsetSums
