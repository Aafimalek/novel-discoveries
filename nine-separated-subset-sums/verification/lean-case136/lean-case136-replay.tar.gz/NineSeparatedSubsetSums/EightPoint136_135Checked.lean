import NineSeparatedSubsetSums.EightPointPackedGeometry
import NineSeparatedSubsetSums.EightPoint136_135PackedBudget0
import NineSeparatedSubsetSums.EightPoint136_135PackedAnchor0Part0
import NineSeparatedSubsetSums.EightPoint136_135PackedAnchor0Part1
import NineSeparatedSubsetSums.EightPoint136_135PackedAnchor0Part2
import NineSeparatedSubsetSums.EightPoint136_135PackedBudget1
import NineSeparatedSubsetSums.EightPoint136_135PackedAnchor1Part0
import NineSeparatedSubsetSums.EightPoint136_135PackedAnchor1Part1
import NineSeparatedSubsetSums.EightPoint136_135PackedAnchor1Part2

namespace NineSeparatedSubsetSums

private theorem packedOct136_135Anchor0 :
  ∀ j : Fin 495, ((j.val : Int)+136+135)%2=0 →
    2428283 ≤ FourPointNumeric.octPackedCharge 136 135 20 packedOct136_135_0 (j.val : Int) := by
  intro j hj
  let k := (j.val-1)/2
  have hk : k < 247 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+1 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint136_135PackedAnchor0Part0 z
    rwa [he,hrep] at ht
  by_cases h1 : k < 240
  · let z : Fin 120 := ⟨k-120, by omega⟩
    have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
    have ht := eightPoint136_135PackedAnchor0Part1 z
    rwa [he,hrep] at ht
  let z : Fin 7 := ⟨k-240, by omega⟩
  have he : (z.val : Int)+240 = k := by dsimp [z] <;> omega
  have ht := eightPoint136_135PackedAnchor0Part2 z
  rwa [he,hrep] at ht

private theorem packedOct136_135Anchor1 :
  ∀ j : Fin 495, ((j.val : Int)+136+135)%2=1 →
    2427762 ≤ FourPointNumeric.octPackedCharge 136 135 20 packedOct136_135_1 (j.val : Int) := by
  intro j hj
  let k := (j.val-0)/2
  have hk : k < 248 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+0 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint136_135PackedAnchor1Part0 z
    rwa [he,hrep] at ht
  by_cases h1 : k < 240
  · let z : Fin 120 := ⟨k-120, by omega⟩
    have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
    have ht := eightPoint136_135PackedAnchor1Part1 z
    rwa [he,hrep] at ht
  let z : Fin 8 := ⟨k-240, by omega⟩
  have he : (z.val : Int)+240 = k := by dsimp [z] <;> omega
  have ht := eightPoint136_135PackedAnchor1Part2 z
  rwa [he,hrep] at ht

def packedOctCertificate136_135_0 : EightPointCertificate 136 135 0 128045 :=
  eightPointCertificateOfPacked 136 135 0 128045 2428283 20 packedOct136_135_0 453 495
    (by decide +kernel) (by decide) packedOct136_135Anchor0
    (by rw [packedOct136_135_0_budget]; decide)

def packedOctCertificate136_135_1 : EightPointCertificate 136 135 1 128045 :=
  eightPointCertificateOfPacked 136 135 1 128045 2427762 20 packedOct136_135_1 454 495
    (by decide +kernel) (by decide) packedOct136_135Anchor1
    (by rw [packedOct136_135_1_budget]; decide)

theorem max148_second136_third135_eightPoint_moment_bound (tail : List ℕ) (len : tail.length=6)
    (distinct : (natSubsetSums (148::136::135::tail)).Nodup) :
    128045 ≤ ((148::136::135::tail).map (· ^ 2)).sum := by
  apply eightPointNatMomentLower 136 135 128045 tail len distinct
  intro p hp
  by_cases h : p=0
  · subst p
    exact packedOctCertificate136_135_0
  · have he : p=1 := hp.resolve_left h
    subst p
    exact packedOctCertificate136_135_1

#print axioms max148_second136_third135_eightPoint_moment_bound

end NineSeparatedSubsetSums
