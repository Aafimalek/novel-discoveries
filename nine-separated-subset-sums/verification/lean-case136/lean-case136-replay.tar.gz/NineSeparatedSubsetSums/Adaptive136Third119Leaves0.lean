import NineSeparatedSubsetSums.Adaptive136Third119State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive136Third119Proof0 : runCachedNode 511 124714 Adaptive136Third119Node0 = false := by
  decide +kernel

#print axioms adaptive136Third119Proof0

end NineSeparatedSubsetSums
