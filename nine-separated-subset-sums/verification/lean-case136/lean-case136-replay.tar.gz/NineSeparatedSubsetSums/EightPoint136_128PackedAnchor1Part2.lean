import NineSeparatedSubsetSums.EightPoint136_128PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint136_128PackedAnchor1Part2 :
    ∀ j : Fin 2, 2330175 ≤ FourPointNumeric.octPackedCharge 136 128 20 packedOct136_128_1
      (2*((j.val : Int)+240)+1) := by decide +kernel

end NineSeparatedSubsetSums
