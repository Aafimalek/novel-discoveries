import NineSeparatedSubsetSums.Adaptive136Third128State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive136Third128Proof13 : runCachedNode 511 126668 Adaptive136Third128Node13 = false := by
  decide +kernel

#print axioms adaptive136Third128Proof13

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive136Third128Proof15 : runCachedNode 511 126668 Adaptive136Third128Node15 = false := by
  decide +kernel

#print axioms adaptive136Third128Proof15

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive136Third128Proof16 : runCachedNode 511 126668 Adaptive136Third128Node16 = false := by
  decide +kernel

#print axioms adaptive136Third128Proof16

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive136Third128Proof6 : runCachedNode 511 126668 Adaptive136Third128Node6 = false := by
  decide +kernel

#print axioms adaptive136Third128Proof6

end NineSeparatedSubsetSums
