import NineSeparatedSubsetSums.EightPointPackedGeometry
import NineSeparatedSubsetSums.EightPoint136_117PackedBudget0
import NineSeparatedSubsetSums.EightPoint136_117PackedAnchor0Part0
import NineSeparatedSubsetSums.EightPoint136_117PackedAnchor0Part1
import NineSeparatedSubsetSums.EightPoint136_117PackedAnchor0Part2
import NineSeparatedSubsetSums.EightPoint136_117PackedBudget1
import NineSeparatedSubsetSums.EightPoint136_117PackedAnchor1Part0
import NineSeparatedSubsetSums.EightPoint136_117PackedAnchor1Part1
import NineSeparatedSubsetSums.EightPoint136_117PackedAnchor1Part2

namespace NineSeparatedSubsetSums

private theorem packedOct136_117Anchor0 :
  ∀ j : Fin 482, ((j.val : Int)+136+117)%2=0 →
    2284953 ≤ FourPointNumeric.octPackedCharge 136 117 20 packedOct136_117_0 (j.val : Int) := by
  intro j hj
  let k := (j.val-1)/2
  have hk : k < 241 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+1 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint136_117PackedAnchor0Part0 z
    rwa [he,hrep] at ht
  by_cases h1 : k < 240
  · let z : Fin 120 := ⟨k-120, by omega⟩
    have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
    have ht := eightPoint136_117PackedAnchor0Part1 z
    rwa [he,hrep] at ht
  let z : Fin 1 := ⟨k-240, by omega⟩
  have he : (z.val : Int)+240 = k := by dsimp [z] <;> omega
  have ht := eightPoint136_117PackedAnchor0Part2 z
  rwa [he,hrep] at ht

private theorem packedOct136_117Anchor1 :
  ∀ j : Fin 482, ((j.val : Int)+136+117)%2=1 →
    2284693 ≤ FourPointNumeric.octPackedCharge 136 117 20 packedOct136_117_1 (j.val : Int) := by
  intro j hj
  let k := (j.val-0)/2
  have hk : k < 241 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+0 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint136_117PackedAnchor1Part0 z
    rwa [he,hrep] at ht
  by_cases h1 : k < 240
  · let z : Fin 120 := ⟨k-120, by omega⟩
    have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
    have ht := eightPoint136_117PackedAnchor1Part1 z
    rwa [he,hrep] at ht
  let z : Fin 1 := ⟨k-240, by omega⟩
  have he : (z.val : Int)+240 = k := by dsimp [z] <;> omega
  have ht := eightPoint136_117PackedAnchor1Part2 z
  rwa [he,hrep] at ht

def packedOctCertificate136_117_0 : EightPointCertificate 136 117 0 124348 :=
  eightPointCertificateOfPacked 136 117 0 124348 2284953 20 packedOct136_117_0 265 482
    (by decide +kernel) (by decide) packedOct136_117Anchor0
    (by rw [packedOct136_117_0_budget]; decide)

def packedOctCertificate136_117_1 : EightPointCertificate 136 117 1 124348 :=
  eightPointCertificateOfPacked 136 117 1 124348 2284693 20 packedOct136_117_1 352 482
    (by decide +kernel) (by decide) packedOct136_117Anchor1
    (by rw [packedOct136_117_1_budget]; decide)

theorem max148_second136_third117_eightPoint_moment_bound (tail : List ℕ) (len : tail.length=6)
    (distinct : (natSubsetSums (148::136::117::tail)).Nodup) :
    124348 ≤ ((148::136::117::tail).map (· ^ 2)).sum := by
  apply eightPointNatMomentLower 136 117 124348 tail len distinct
  intro p hp
  by_cases h : p=0
  · subst p
    exact packedOctCertificate136_117_0
  · have he : p=1 := hp.resolve_left h
    subst p
    exact packedOctCertificate136_117_1

#print axioms max148_second136_third117_eightPoint_moment_bound

end NineSeparatedSubsetSums
