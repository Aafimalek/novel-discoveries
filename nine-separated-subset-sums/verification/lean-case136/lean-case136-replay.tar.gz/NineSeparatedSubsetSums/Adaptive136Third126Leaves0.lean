import NineSeparatedSubsetSums.Adaptive136Third126State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive136Third126Proof0 : runCachedNode 511 126516 Adaptive136Third126Node0 = false := by
  decide +kernel

#print axioms adaptive136Third126Proof0

end NineSeparatedSubsetSums
