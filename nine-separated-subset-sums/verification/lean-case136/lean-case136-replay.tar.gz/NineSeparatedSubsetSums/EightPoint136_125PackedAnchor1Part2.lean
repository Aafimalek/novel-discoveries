import NineSeparatedSubsetSums.EightPoint136_125PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint136_125PackedAnchor1Part2 :
    ∀ j : Fin 2, 2307833 ≤ FourPointNumeric.octPackedCharge 136 125 20 packedOct136_125_1
      (2*((j.val : Int)+240)+0) := by decide +kernel

end NineSeparatedSubsetSums
