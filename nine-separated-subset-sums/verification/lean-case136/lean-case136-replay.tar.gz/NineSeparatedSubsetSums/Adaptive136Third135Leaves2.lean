import NineSeparatedSubsetSums.Adaptive136Third135State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive136Third135Proof49 : runCachedNode 511 128045 Adaptive136Third135Node49 = false := by
  decide +kernel

#print axioms adaptive136Third135Proof49

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive136Third135Proof14 : runCachedNode 511 128045 Adaptive136Third135Node14 = false := by
  decide +kernel

#print axioms adaptive136Third135Proof14

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive136Third135Proof27 : runCachedNode 511 128045 Adaptive136Third135Node27 = false := by
  decide +kernel

#print axioms adaptive136Third135Proof27

end NineSeparatedSubsetSums
