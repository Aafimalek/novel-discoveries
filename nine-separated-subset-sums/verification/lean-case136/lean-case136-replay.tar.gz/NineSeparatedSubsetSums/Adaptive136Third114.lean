import NineSeparatedSubsetSums.Adaptive136Third114Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint136Checked

namespace NineSeparatedSubsetSums


theorem adaptive136Third114 : NoDescendingTailAfterThird 136 114 :=
  noDescendingThirdTail_of_cached 136 114 110825 (fun t ht nd => max148_second136_fourPoint_moment_bound (114::t) (by simp [ht]) nd) adaptive136Third114Proof0

#print axioms adaptive136Third114

end NineSeparatedSubsetSums
