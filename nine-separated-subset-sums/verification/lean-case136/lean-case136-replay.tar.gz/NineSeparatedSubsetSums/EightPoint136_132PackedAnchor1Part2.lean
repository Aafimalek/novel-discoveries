import NineSeparatedSubsetSums.EightPoint136_132PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint136_132PackedAnchor1Part2 :
    ∀ j : Fin 6, 2404860 ≤ FourPointNumeric.octPackedCharge 136 132 20 packedOct136_132_1
      (2*((j.val : Int)+240)+1) := by decide +kernel

end NineSeparatedSubsetSums
