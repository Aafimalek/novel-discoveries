import NineSeparatedSubsetSums.Adaptive136Third115State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive136Third115Proof13 : runCachedNode 511 110825 Adaptive136Third115Node13 = false := by
  decide +kernel

#print axioms adaptive136Third115Proof13

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive136Third115Proof12 : runCachedNode 511 110825 Adaptive136Third115Node12 = false := by
  decide +kernel

#print axioms adaptive136Third115Proof12

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive136Third115Proof11 : runCachedNode 511 110825 Adaptive136Third115Node11 = false := by
  decide +kernel

#print axioms adaptive136Third115Proof11

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive136Third115Proof10 : runCachedNode 511 110825 Adaptive136Third115Node10 = false := by
  decide +kernel

#print axioms adaptive136Third115Proof10

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive136Third115Proof9 : runCachedNode 511 110825 Adaptive136Third115Node9 = false := by
  decide +kernel

#print axioms adaptive136Third115Proof9

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive136Third115Proof7 : runCachedNode 511 110825 Adaptive136Third115Node7 = false := by
  decide +kernel

#print axioms adaptive136Third115Proof7

end NineSeparatedSubsetSums
