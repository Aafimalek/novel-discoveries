import NineSeparatedSubsetSums.EightPoint136_129PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct136_129_1_budget :
    FourPointNumeric.packedBudget 20 packedOct136_129_1 430 = 85948190 := by decide +kernel

#print axioms packedOct136_129_1_budget

end NineSeparatedSubsetSums
