import NineSeparatedSubsetSums.EightPoint136_126PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint136_126PackedAnchor0Part2 :
    ∀ j : Fin 3, 2336774 ≤ FourPointNumeric.octPackedCharge 136 126 20 packedOct136_126_0
      (2*((j.val : Int)+240)+0) := by decide +kernel

end NineSeparatedSubsetSums
