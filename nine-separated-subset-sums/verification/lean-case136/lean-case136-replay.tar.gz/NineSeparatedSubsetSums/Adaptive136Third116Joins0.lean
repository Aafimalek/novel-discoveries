import NineSeparatedSubsetSums.Adaptive136Third116State
import NineSeparatedSubsetSums.Adaptive136Third116Leaves0
import NineSeparatedSubsetSums.Adaptive136Third116Leaves1

namespace NineSeparatedSubsetSums

theorem adaptive136Third116Proof0 : runCachedNode 511 110825 Adaptive136Third116Node0 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 110825 Adaptive136Third116Node0 = [100, 101, 102, 103, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive136Third116Proof1
  · exact adaptive136Third116Proof2
  · exact adaptive136Third116Proof3
  · exact adaptive136Third116Proof4
  · exact adaptive136Third116Proof5
  · exact adaptive136Third116Proof6
  · exact adaptive136Third116Proof7
  · exact adaptive136Third116Proof8
  · exact adaptive136Third116Proof9
  · exact adaptive136Third116Proof10
  · exact adaptive136Third116Proof11
  · exact adaptive136Third116Proof12
  · exact adaptive136Third116Proof13
  · exact adaptive136Third116Proof14
  · exact adaptive136Third116Proof15

#print axioms adaptive136Third116Proof0

end NineSeparatedSubsetSums
