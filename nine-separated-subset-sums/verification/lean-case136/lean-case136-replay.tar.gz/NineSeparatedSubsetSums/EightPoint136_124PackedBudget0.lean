import NineSeparatedSubsetSums.EightPoint136_124PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct136_124_0_budget :
    FourPointNumeric.packedBudget 20 packedOct136_124_0 255 = 82427819 := by decide +kernel

#print axioms packedOct136_124_0_budget

end NineSeparatedSubsetSums
