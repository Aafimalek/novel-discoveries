import NineSeparatedSubsetSums.Adaptive136Third133State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive136Third133Proof13 : runCachedNode 511 127674 Adaptive136Third133Node13 = false := by
  decide +kernel

#print axioms adaptive136Third133Proof13

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive136Third133Proof16 : runCachedNode 511 127674 Adaptive136Third133Node16 = false := by
  decide +kernel

#print axioms adaptive136Third133Proof16

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive136Third133Proof14 : runCachedNode 511 127674 Adaptive136Third133Node14 = false := by
  decide +kernel

#print axioms adaptive136Third133Proof14

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive136Third133Proof9 : runCachedNode 511 127674 Adaptive136Third133Node9 = false := by
  decide +kernel

#print axioms adaptive136Third133Proof9

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive136Third133Proof5 : runCachedNode 511 127674 Adaptive136Third133Node5 = false := by
  decide +kernel

#print axioms adaptive136Third133Proof5

end NineSeparatedSubsetSums
