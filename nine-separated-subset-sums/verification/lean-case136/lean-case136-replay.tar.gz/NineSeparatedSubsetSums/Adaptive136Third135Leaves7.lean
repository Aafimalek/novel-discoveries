import NineSeparatedSubsetSums.Adaptive136Third135State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive136Third135Proof47 : runCachedNode 511 128045 Adaptive136Third135Node47 = false := by
  decide +kernel

#print axioms adaptive136Third135Proof47

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive136Third135Proof41 : runCachedNode 511 128045 Adaptive136Third135Node41 = false := by
  decide +kernel

#print axioms adaptive136Third135Proof41

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive136Third135Proof12 : runCachedNode 511 128045 Adaptive136Third135Node12 = false := by
  decide +kernel

#print axioms adaptive136Third135Proof12

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive136Third135Proof42 : runCachedNode 511 128045 Adaptive136Third135Node42 = false := by
  decide +kernel

#print axioms adaptive136Third135Proof42

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive136Third135Proof11 : runCachedNode 511 128045 Adaptive136Third135Node11 = false := by
  decide +kernel

#print axioms adaptive136Third135Proof11

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive136Third135Proof9 : runCachedNode 511 128045 Adaptive136Third135Node9 = false := by
  decide +kernel

#print axioms adaptive136Third135Proof9

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive136Third135Proof8 : runCachedNode 511 128045 Adaptive136Third135Node8 = false := by
  decide +kernel

#print axioms adaptive136Third135Proof8

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive136Third135Proof6 : runCachedNode 511 128045 Adaptive136Third135Node6 = false := by
  decide +kernel

#print axioms adaptive136Third135Proof6

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive136Third135Proof36 : runCachedNode 511 128045 Adaptive136Third135Node36 = false := by
  decide +kernel

#print axioms adaptive136Third135Proof36

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive136Third135Proof37 : runCachedNode 511 128045 Adaptive136Third135Node37 = false := by
  decide +kernel

#print axioms adaptive136Third135Proof37

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive136Third135Proof35 : runCachedNode 511 128045 Adaptive136Third135Node35 = false := by
  decide +kernel

#print axioms adaptive136Third135Proof35

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive136Third135Proof5 : runCachedNode 511 128045 Adaptive136Third135Node5 = false := by
  decide +kernel

#print axioms adaptive136Third135Proof5

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive136Third135Proof34 : runCachedNode 511 128045 Adaptive136Third135Node34 = false := by
  decide +kernel

#print axioms adaptive136Third135Proof34

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive136Third135Proof31 : runCachedNode 511 128045 Adaptive136Third135Node31 = false := by
  decide +kernel

#print axioms adaptive136Third135Proof31

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive136Third135Proof32 : runCachedNode 511 128045 Adaptive136Third135Node32 = false := by
  decide +kernel

#print axioms adaptive136Third135Proof32

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive136Third135Proof33 : runCachedNode 511 128045 Adaptive136Third135Node33 = false := by
  decide +kernel

#print axioms adaptive136Third135Proof33

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive136Third135Proof30 : runCachedNode 511 128045 Adaptive136Third135Node30 = false := by
  decide +kernel

#print axioms adaptive136Third135Proof30

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive136Third135Proof29 : runCachedNode 511 128045 Adaptive136Third135Node29 = false := by
  decide +kernel

#print axioms adaptive136Third135Proof29

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive136Third135Proof4 : runCachedNode 511 128045 Adaptive136Third135Node4 = false := by
  decide +kernel

#print axioms adaptive136Third135Proof4

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive136Third135Proof28 : runCachedNode 511 128045 Adaptive136Third135Node28 = false := by
  decide +kernel

#print axioms adaptive136Third135Proof28

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive136Third135Proof2 : runCachedNode 511 128045 Adaptive136Third135Node2 = false := by
  decide +kernel

#print axioms adaptive136Third135Proof2

end NineSeparatedSubsetSums
