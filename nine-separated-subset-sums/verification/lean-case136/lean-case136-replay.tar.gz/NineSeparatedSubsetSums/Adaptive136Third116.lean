import NineSeparatedSubsetSums.Adaptive136Third116Joins0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint136Checked

namespace NineSeparatedSubsetSums


theorem adaptive136Third116 : NoDescendingTailAfterThird 136 116 :=
  noDescendingThirdTail_of_cached 136 116 110825 (fun t ht nd => max148_second136_fourPoint_moment_bound (116::t) (by simp [ht]) nd) adaptive136Third116Proof0

#print axioms adaptive136Third116

end NineSeparatedSubsetSums
