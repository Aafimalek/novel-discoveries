import NineSeparatedSubsetSums.EightPoint136_125PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct136_125_0_budget :
    FourPointNumeric.packedBudget 20 packedOct136_125_0 485 = 83110684 := by decide +kernel

#print axioms packedOct136_125_0_budget

end NineSeparatedSubsetSums
