import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive136Third127Node0 : CachedSearchNode :=
  ⟨4, 126, computeCenteredMask [148,136,127], 411, 56529⟩
def Adaptive136Third127Node1 : CachedSearchNode := cachedChild Adaptive136Third127Node0 111
def Adaptive136Third127Node2 : CachedSearchNode := cachedChild Adaptive136Third127Node0 112
def Adaptive136Third127Node3 : CachedSearchNode := cachedChild Adaptive136Third127Node0 113
def Adaptive136Third127Node4 : CachedSearchNode := cachedChild Adaptive136Third127Node0 114
def Adaptive136Third127Node5 : CachedSearchNode := cachedChild Adaptive136Third127Node0 116
def Adaptive136Third127Node6 : CachedSearchNode := cachedChild Adaptive136Third127Node0 117
def Adaptive136Third127Node7 : CachedSearchNode := cachedChild Adaptive136Third127Node0 118
def Adaptive136Third127Node8 : CachedSearchNode := cachedChild Adaptive136Third127Node0 119
def Adaptive136Third127Node9 : CachedSearchNode := cachedChild Adaptive136Third127Node0 120
def Adaptive136Third127Node10 : CachedSearchNode := cachedChild Adaptive136Third127Node0 121
def Adaptive136Third127Node11 : CachedSearchNode := cachedChild Adaptive136Third127Node0 122
def Adaptive136Third127Node12 : CachedSearchNode := cachedChild Adaptive136Third127Node0 123
def Adaptive136Third127Node13 : CachedSearchNode := cachedChild Adaptive136Third127Node0 124
def Adaptive136Third127Node14 : CachedSearchNode := cachedChild Adaptive136Third127Node0 125
def Adaptive136Third127Node15 : CachedSearchNode := cachedChild Adaptive136Third127Node0 126

end NineSeparatedSubsetSums
