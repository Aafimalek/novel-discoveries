import NineSeparatedSubsetSums.Adaptive136Third111Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint136Checked

namespace NineSeparatedSubsetSums


theorem adaptive136Third111 : NoDescendingTailAfterThird 136 111 :=
  noDescendingThirdTail_of_cached 136 111 110825 (fun t ht nd => max148_second136_fourPoint_moment_bound (111::t) (by simp [ht]) nd) adaptive136Third111Proof0

#print axioms adaptive136Third111

end NineSeparatedSubsetSums
