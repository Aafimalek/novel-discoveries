import NineSeparatedSubsetSums.EightPoint136_130PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct136_130_1_budget :
    FourPointNumeric.packedBudget 20 packedOct136_130_1 436 = 88022528 := by decide +kernel

#print axioms packedOct136_130_1_budget

end NineSeparatedSubsetSums
