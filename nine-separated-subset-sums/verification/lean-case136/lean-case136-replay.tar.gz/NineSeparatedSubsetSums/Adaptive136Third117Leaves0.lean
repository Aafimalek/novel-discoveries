import NineSeparatedSubsetSums.Adaptive136Third117State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive136Third117Proof0 : runCachedNode 511 124348 Adaptive136Third117Node0 = false := by
  decide +kernel

#print axioms adaptive136Third117Proof0

end NineSeparatedSubsetSums
