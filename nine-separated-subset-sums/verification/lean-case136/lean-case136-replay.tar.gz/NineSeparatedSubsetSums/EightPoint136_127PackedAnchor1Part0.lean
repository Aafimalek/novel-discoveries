import NineSeparatedSubsetSums.EightPoint136_127PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint136_127PackedAnchor1Part0 :
    ∀ j : Fin 120, 2345494 ≤ FourPointNumeric.octPackedCharge 136 127 20 packedOct136_127_1
      (2*((j.val : Int)+0)+0) := by decide +kernel

end NineSeparatedSubsetSums
