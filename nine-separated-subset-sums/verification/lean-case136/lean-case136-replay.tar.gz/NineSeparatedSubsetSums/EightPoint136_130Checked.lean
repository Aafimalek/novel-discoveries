import NineSeparatedSubsetSums.EightPointPackedGeometry
import NineSeparatedSubsetSums.EightPoint136_130PackedBudget0
import NineSeparatedSubsetSums.EightPoint136_130PackedAnchor0Part0
import NineSeparatedSubsetSums.EightPoint136_130PackedAnchor0Part1
import NineSeparatedSubsetSums.EightPoint136_130PackedAnchor0Part2
import NineSeparatedSubsetSums.EightPoint136_130PackedBudget1
import NineSeparatedSubsetSums.EightPoint136_130PackedAnchor1Part0
import NineSeparatedSubsetSums.EightPoint136_130PackedAnchor1Part1
import NineSeparatedSubsetSums.EightPoint136_130PackedAnchor1Part2

namespace NineSeparatedSubsetSums

private theorem packedOct136_130Anchor0 :
  ∀ j : Fin 492, ((j.val : Int)+136+130)%2=0 →
    2393725 ≤ FourPointNumeric.octPackedCharge 136 130 20 packedOct136_130_0 (j.val : Int) := by
  intro j hj
  let k := (j.val-0)/2
  have hk : k < 246 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+0 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint136_130PackedAnchor0Part0 z
    rwa [he,hrep] at ht
  by_cases h1 : k < 240
  · let z : Fin 120 := ⟨k-120, by omega⟩
    have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
    have ht := eightPoint136_130PackedAnchor0Part1 z
    rwa [he,hrep] at ht
  let z : Fin 6 := ⟨k-240, by omega⟩
  have he : (z.val : Int)+240 = k := by dsimp [z] <;> omega
  have ht := eightPoint136_130PackedAnchor0Part2 z
  rwa [he,hrep] at ht

private theorem packedOct136_130Anchor1 :
  ∀ j : Fin 492, ((j.val : Int)+136+130)%2=1 →
    2392104 ≤ FourPointNumeric.octPackedCharge 136 130 20 packedOct136_130_1 (j.val : Int) := by
  intro j hj
  let k := (j.val-1)/2
  have hk : k < 246 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+1 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint136_130PackedAnchor1Part0 z
    rwa [he,hrep] at ht
  by_cases h1 : k < 240
  · let z : Fin 120 := ⟨k-120, by omega⟩
    have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
    have ht := eightPoint136_130PackedAnchor1Part1 z
    rwa [he,hrep] at ht
  let z : Fin 6 := ⟨k-240, by omega⟩
  have he : (z.val : Int)+240 = k := by dsimp [z] <;> omega
  have ht := eightPoint136_130PackedAnchor1Part2 z
  rwa [he,hrep] at ht

def packedOctCertificate136_130_0 : EightPointCertificate 136 130 0 127094 :=
  eightPointCertificateOfPacked 136 130 0 127094 2393725 20 packedOct136_130_0 263 492
    (by decide +kernel) (by decide) packedOct136_130Anchor0
    (by rw [packedOct136_130_0_budget]; decide)

def packedOctCertificate136_130_1 : EightPointCertificate 136 130 1 127094 :=
  eightPointCertificateOfPacked 136 130 1 127094 2392104 20 packedOct136_130_1 436 492
    (by decide +kernel) (by decide) packedOct136_130Anchor1
    (by rw [packedOct136_130_1_budget]; decide)

theorem max148_second136_third130_eightPoint_moment_bound (tail : List ℕ) (len : tail.length=6)
    (distinct : (natSubsetSums (148::136::130::tail)).Nodup) :
    127094 ≤ ((148::136::130::tail).map (· ^ 2)).sum := by
  apply eightPointNatMomentLower 136 130 127094 tail len distinct
  intro p hp
  by_cases h : p=0
  · subst p
    exact packedOctCertificate136_130_0
  · have he : p=1 := hp.resolve_left h
    subst p
    exact packedOctCertificate136_130_1

#print axioms max148_second136_third130_eightPoint_moment_bound

end NineSeparatedSubsetSums
