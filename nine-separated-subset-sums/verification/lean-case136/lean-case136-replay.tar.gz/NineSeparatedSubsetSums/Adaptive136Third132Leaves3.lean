import NineSeparatedSubsetSums.Adaptive136Third132State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive136Third132Proof13 : runCachedNode 511 127566 Adaptive136Third132Node13 = false := by
  decide +kernel

#print axioms adaptive136Third132Proof13

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive136Third132Proof14 : runCachedNode 511 127566 Adaptive136Third132Node14 = false := by
  decide +kernel

#print axioms adaptive136Third132Proof14

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive136Third132Proof12 : runCachedNode 511 127566 Adaptive136Third132Node12 = false := by
  decide +kernel

#print axioms adaptive136Third132Proof12

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive136Third132Proof11 : runCachedNode 511 127566 Adaptive136Third132Node11 = false := by
  decide +kernel

#print axioms adaptive136Third132Proof11

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive136Third132Proof9 : runCachedNode 511 127566 Adaptive136Third132Node9 = false := by
  decide +kernel

#print axioms adaptive136Third132Proof9

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive136Third132Proof8 : runCachedNode 511 127566 Adaptive136Third132Node8 = false := by
  decide +kernel

#print axioms adaptive136Third132Proof8

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive136Third132Proof7 : runCachedNode 511 127566 Adaptive136Third132Node7 = false := by
  decide +kernel

#print axioms adaptive136Third132Proof7

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive136Third132Proof6 : runCachedNode 511 127566 Adaptive136Third132Node6 = false := by
  decide +kernel

#print axioms adaptive136Third132Proof6

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive136Third132Proof4 : runCachedNode 511 127566 Adaptive136Third132Node4 = false := by
  decide +kernel

#print axioms adaptive136Third132Proof4

end NineSeparatedSubsetSums
