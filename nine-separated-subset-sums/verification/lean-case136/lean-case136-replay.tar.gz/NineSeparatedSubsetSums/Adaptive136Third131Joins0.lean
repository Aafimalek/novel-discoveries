import NineSeparatedSubsetSums.Adaptive136Third131State
import NineSeparatedSubsetSums.Adaptive136Third131Leaves2
import NineSeparatedSubsetSums.Adaptive136Third131Leaves0
import NineSeparatedSubsetSums.Adaptive136Third131Leaves1

namespace NineSeparatedSubsetSums

theorem adaptive136Third131Proof0 : runCachedNode 511 127350 Adaptive136Third131Node0 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 127350 Adaptive136Third131Node0 = [111, 112, 113, 114, 115, 116, 117, 118, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive136Third131Proof1
  · exact adaptive136Third131Proof2
  · exact adaptive136Third131Proof3
  · exact adaptive136Third131Proof4
  · exact adaptive136Third131Proof5
  · exact adaptive136Third131Proof6
  · exact adaptive136Third131Proof7
  · exact adaptive136Third131Proof8
  · exact adaptive136Third131Proof9
  · exact adaptive136Third131Proof10
  · exact adaptive136Third131Proof11
  · exact adaptive136Third131Proof12
  · exact adaptive136Third131Proof13
  · exact adaptive136Third131Proof14
  · exact adaptive136Third131Proof15
  · exact adaptive136Third131Proof16
  · exact adaptive136Third131Proof17
  · exact adaptive136Third131Proof18
  · exact adaptive136Third131Proof19

#print axioms adaptive136Third131Proof0

end NineSeparatedSubsetSums
