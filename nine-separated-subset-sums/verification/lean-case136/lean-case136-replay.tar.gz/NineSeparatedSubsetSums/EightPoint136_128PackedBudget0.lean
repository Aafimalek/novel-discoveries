import NineSeparatedSubsetSums.EightPoint136_128PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct136_128_0_budget :
    FourPointNumeric.packedBudget 20 packedOct136_128_0 447 = 84266273 := by decide +kernel

#print axioms packedOct136_128_0_budget

end NineSeparatedSubsetSums
