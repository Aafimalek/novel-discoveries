import NineSeparatedSubsetSums.Adaptive136Third108Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint136Checked

namespace NineSeparatedSubsetSums


theorem adaptive136Third108 : NoDescendingTailAfterThird 136 108 :=
  noDescendingThirdTail_of_cached 136 108 110825 (fun t ht nd => max148_second136_fourPoint_moment_bound (108::t) (by simp [ht]) nd) adaptive136Third108Proof0

#print axioms adaptive136Third108

end NineSeparatedSubsetSums
