import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive136Third122Node0 : CachedSearchNode :=
  ⟨4, 121, computeCenteredMask [148,136,122], 406, 55284⟩

end NineSeparatedSubsetSums
