import NineSeparatedSubsetSums.Adaptive136Third134State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive136Third134Proof17 : runCachedNode 511 127846 Adaptive136Third134Node17 = false := by
  decide +kernel

#print axioms adaptive136Third134Proof17

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive136Third134Proof42 : runCachedNode 511 127846 Adaptive136Third134Node42 = false := by
  decide +kernel

#print axioms adaptive136Third134Proof42

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive136Third134Proof14 : runCachedNode 511 127846 Adaptive136Third134Node14 = false := by
  decide +kernel

#print axioms adaptive136Third134Proof14

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive136Third134Proof5 : runCachedNode 511 127846 Adaptive136Third134Node5 = false := by
  decide +kernel

#print axioms adaptive136Third134Proof5

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive136Third134Proof22 : runCachedNode 511 127846 Adaptive136Third134Node22 = false := by
  decide +kernel

#print axioms adaptive136Third134Proof22

end NineSeparatedSubsetSums
