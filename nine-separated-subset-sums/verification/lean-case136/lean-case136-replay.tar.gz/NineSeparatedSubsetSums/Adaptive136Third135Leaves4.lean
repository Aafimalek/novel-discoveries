import NineSeparatedSubsetSums.Adaptive136Third135State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive136Third135Proof19 : runCachedNode 511 128045 Adaptive136Third135Node19 = false := by
  decide +kernel

#print axioms adaptive136Third135Proof19

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive136Third135Proof17 : runCachedNode 511 128045 Adaptive136Third135Node17 = false := by
  decide +kernel

#print axioms adaptive136Third135Proof17

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive136Third135Proof10 : runCachedNode 511 128045 Adaptive136Third135Node10 = false := by
  decide +kernel

#print axioms adaptive136Third135Proof10

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive136Third135Proof24 : runCachedNode 511 128045 Adaptive136Third135Node24 = false := by
  decide +kernel

#print axioms adaptive136Third135Proof24

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive136Third135Proof25 : runCachedNode 511 128045 Adaptive136Third135Node25 = false := by
  decide +kernel

#print axioms adaptive136Third135Proof25

end NineSeparatedSubsetSums
