import NineSeparatedSubsetSums.EightPoint136_117PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct136_117_1_budget :
    FourPointNumeric.packedBudget 20 packedOct136_117_1 352 = 82554006 := by decide +kernel

#print axioms packedOct136_117_1_budget

end NineSeparatedSubsetSums
