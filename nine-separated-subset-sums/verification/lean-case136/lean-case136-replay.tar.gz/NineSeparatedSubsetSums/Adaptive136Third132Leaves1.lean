import NineSeparatedSubsetSums.Adaptive136Third132State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive136Third132Proof19 : runCachedNode 511 127566 Adaptive136Third132Node19 = false := by
  decide +kernel

#print axioms adaptive136Third132Proof19

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive136Third132Proof15 : runCachedNode 511 127566 Adaptive136Third132Node15 = false := by
  decide +kernel

#print axioms adaptive136Third132Proof15

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive136Third132Proof10 : runCachedNode 511 127566 Adaptive136Third132Node10 = false := by
  decide +kernel

#print axioms adaptive136Third132Proof10

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive136Third132Proof2 : runCachedNode 511 127566 Adaptive136Third132Node2 = false := by
  decide +kernel

#print axioms adaptive136Third132Proof2

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive136Third132Proof1 : runCachedNode 511 127566 Adaptive136Third132Node1 = false := by
  decide +kernel

#print axioms adaptive136Third132Proof1

end NineSeparatedSubsetSums
