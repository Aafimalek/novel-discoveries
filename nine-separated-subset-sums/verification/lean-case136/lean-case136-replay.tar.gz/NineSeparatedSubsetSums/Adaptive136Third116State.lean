import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive136Third116Node0 : CachedSearchNode :=
  ⟨4, 115, computeCenteredMask [148,136,116], 400, 53856⟩
def Adaptive136Third116Node1 : CachedSearchNode := cachedChild Adaptive136Third116Node0 100
def Adaptive136Third116Node2 : CachedSearchNode := cachedChild Adaptive136Third116Node0 101
def Adaptive136Third116Node3 : CachedSearchNode := cachedChild Adaptive136Third116Node0 102
def Adaptive136Third116Node4 : CachedSearchNode := cachedChild Adaptive136Third116Node0 103
def Adaptive136Third116Node5 : CachedSearchNode := cachedChild Adaptive136Third116Node0 105
def Adaptive136Third116Node6 : CachedSearchNode := cachedChild Adaptive136Third116Node0 106
def Adaptive136Third116Node7 : CachedSearchNode := cachedChild Adaptive136Third116Node0 107
def Adaptive136Third116Node8 : CachedSearchNode := cachedChild Adaptive136Third116Node0 108
def Adaptive136Third116Node9 : CachedSearchNode := cachedChild Adaptive136Third116Node0 109
def Adaptive136Third116Node10 : CachedSearchNode := cachedChild Adaptive136Third116Node0 110
def Adaptive136Third116Node11 : CachedSearchNode := cachedChild Adaptive136Third116Node0 111
def Adaptive136Third116Node12 : CachedSearchNode := cachedChild Adaptive136Third116Node0 112
def Adaptive136Third116Node13 : CachedSearchNode := cachedChild Adaptive136Third116Node0 113
def Adaptive136Third116Node14 : CachedSearchNode := cachedChild Adaptive136Third116Node0 114
def Adaptive136Third116Node15 : CachedSearchNode := cachedChild Adaptive136Third116Node0 115

end NineSeparatedSubsetSums
