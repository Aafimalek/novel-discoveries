import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive136Third134Node0 : CachedSearchNode :=
  ⟨4, 133, computeCenteredMask [148,136,134], 418, 58356⟩
def Adaptive136Third134Node1 : CachedSearchNode := cachedChild Adaptive136Third134Node0 111
def Adaptive136Third134Node2 : CachedSearchNode := cachedChild Adaptive136Third134Node0 112
def Adaptive136Third134Node3 : CachedSearchNode := cachedChild Adaptive136Third134Node0 113
def Adaptive136Third134Node4 : CachedSearchNode := cachedChild Adaptive136Third134Node0 114
def Adaptive136Third134Node5 : CachedSearchNode := cachedChild Adaptive136Third134Node0 115
def Adaptive136Third134Node6 : CachedSearchNode := cachedChild Adaptive136Third134Node0 116
def Adaptive136Third134Node7 : CachedSearchNode := cachedChild Adaptive136Third134Node0 117
def Adaptive136Third134Node8 : CachedSearchNode := cachedChild Adaptive136Third134Node0 118
def Adaptive136Third134Node9 : CachedSearchNode := cachedChild Adaptive136Third134Node0 119
def Adaptive136Third134Node10 : CachedSearchNode := cachedChild Adaptive136Third134Node0 120
def Adaptive136Third134Node11 : CachedSearchNode := cachedChild Adaptive136Third134Node0 121
def Adaptive136Third134Node12 : CachedSearchNode := cachedChild Adaptive136Third134Node0 123
def Adaptive136Third134Node13 : CachedSearchNode := cachedChild Adaptive136Third134Node0 124
def Adaptive136Third134Node14 : CachedSearchNode := cachedChild Adaptive136Third134Node0 125
def Adaptive136Third134Node15 : CachedSearchNode := cachedChild Adaptive136Third134Node0 126
def Adaptive136Third134Node16 : CachedSearchNode := cachedChild Adaptive136Third134Node0 127
def Adaptive136Third134Node17 : CachedSearchNode := cachedChild Adaptive136Third134Node0 128
def Adaptive136Third134Node18 : CachedSearchNode := cachedChild Adaptive136Third134Node0 129
def Adaptive136Third134Node19 : CachedSearchNode := cachedChild Adaptive136Third134Node0 130
def Adaptive136Third134Node20 : CachedSearchNode := cachedChild Adaptive136Third134Node0 131
def Adaptive136Third134Node21 : CachedSearchNode := cachedChild Adaptive136Third134Node0 132
def Adaptive136Third134Node22 : CachedSearchNode := cachedChild Adaptive136Third134Node21 105
def Adaptive136Third134Node23 : CachedSearchNode := cachedChild Adaptive136Third134Node21 106
def Adaptive136Third134Node24 : CachedSearchNode := cachedChild Adaptive136Third134Node21 107
def Adaptive136Third134Node25 : CachedSearchNode := cachedChild Adaptive136Third134Node21 108
def Adaptive136Third134Node26 : CachedSearchNode := cachedChild Adaptive136Third134Node21 109
def Adaptive136Third134Node27 : CachedSearchNode := cachedChild Adaptive136Third134Node21 110
def Adaptive136Third134Node28 : CachedSearchNode := cachedChild Adaptive136Third134Node21 111
def Adaptive136Third134Node29 : CachedSearchNode := cachedChild Adaptive136Third134Node21 112
def Adaptive136Third134Node30 : CachedSearchNode := cachedChild Adaptive136Third134Node21 113
def Adaptive136Third134Node31 : CachedSearchNode := cachedChild Adaptive136Third134Node21 114
def Adaptive136Third134Node32 : CachedSearchNode := cachedChild Adaptive136Third134Node21 115
def Adaptive136Third134Node33 : CachedSearchNode := cachedChild Adaptive136Third134Node21 116
def Adaptive136Third134Node34 : CachedSearchNode := cachedChild Adaptive136Third134Node21 117
def Adaptive136Third134Node35 : CachedSearchNode := cachedChild Adaptive136Third134Node21 119
def Adaptive136Third134Node36 : CachedSearchNode := cachedChild Adaptive136Third134Node21 121
def Adaptive136Third134Node37 : CachedSearchNode := cachedChild Adaptive136Third134Node21 123
def Adaptive136Third134Node38 : CachedSearchNode := cachedChild Adaptive136Third134Node21 124
def Adaptive136Third134Node39 : CachedSearchNode := cachedChild Adaptive136Third134Node21 125
def Adaptive136Third134Node40 : CachedSearchNode := cachedChild Adaptive136Third134Node21 126
def Adaptive136Third134Node41 : CachedSearchNode := cachedChild Adaptive136Third134Node21 127
def Adaptive136Third134Node42 : CachedSearchNode := cachedChild Adaptive136Third134Node21 128
def Adaptive136Third134Node43 : CachedSearchNode := cachedChild Adaptive136Third134Node21 129
def Adaptive136Third134Node44 : CachedSearchNode := cachedChild Adaptive136Third134Node21 131
def Adaptive136Third134Node45 : CachedSearchNode := cachedChild Adaptive136Third134Node0 133
def Adaptive136Third134Node46 : CachedSearchNode := cachedChild Adaptive136Third134Node45 104
def Adaptive136Third134Node47 : CachedSearchNode := cachedChild Adaptive136Third134Node45 105
def Adaptive136Third134Node48 : CachedSearchNode := cachedChild Adaptive136Third134Node45 106
def Adaptive136Third134Node49 : CachedSearchNode := cachedChild Adaptive136Third134Node45 107
def Adaptive136Third134Node50 : CachedSearchNode := cachedChild Adaptive136Third134Node45 108
def Adaptive136Third134Node51 : CachedSearchNode := cachedChild Adaptive136Third134Node45 109
def Adaptive136Third134Node52 : CachedSearchNode := cachedChild Adaptive136Third134Node45 110
def Adaptive136Third134Node53 : CachedSearchNode := cachedChild Adaptive136Third134Node45 111
def Adaptive136Third134Node54 : CachedSearchNode := cachedChild Adaptive136Third134Node45 112
def Adaptive136Third134Node55 : CachedSearchNode := cachedChild Adaptive136Third134Node45 113
def Adaptive136Third134Node56 : CachedSearchNode := cachedChild Adaptive136Third134Node45 114
def Adaptive136Third134Node57 : CachedSearchNode := cachedChild Adaptive136Third134Node45 115
def Adaptive136Third134Node58 : CachedSearchNode := cachedChild Adaptive136Third134Node45 116
def Adaptive136Third134Node59 : CachedSearchNode := cachedChild Adaptive136Third134Node45 117
def Adaptive136Third134Node60 : CachedSearchNode := cachedChild Adaptive136Third134Node45 118
def Adaptive136Third134Node61 : CachedSearchNode := cachedChild Adaptive136Third134Node45 120
def Adaptive136Third134Node62 : CachedSearchNode := cachedChild Adaptive136Third134Node45 123
def Adaptive136Third134Node63 : CachedSearchNode := cachedChild Adaptive136Third134Node45 124
def Adaptive136Third134Node64 : CachedSearchNode := cachedChild Adaptive136Third134Node45 125
def Adaptive136Third134Node65 : CachedSearchNode := cachedChild Adaptive136Third134Node45 126
def Adaptive136Third134Node66 : CachedSearchNode := cachedChild Adaptive136Third134Node45 127
def Adaptive136Third134Node67 : CachedSearchNode := cachedChild Adaptive136Third134Node45 128
def Adaptive136Third134Node68 : CachedSearchNode := cachedChild Adaptive136Third134Node45 129
def Adaptive136Third134Node69 : CachedSearchNode := cachedChild Adaptive136Third134Node45 130
def Adaptive136Third134Node70 : CachedSearchNode := cachedChild Adaptive136Third134Node45 132

end NineSeparatedSubsetSums
