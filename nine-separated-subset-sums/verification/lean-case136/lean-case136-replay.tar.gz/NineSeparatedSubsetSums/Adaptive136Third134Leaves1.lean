import NineSeparatedSubsetSums.Adaptive136Third134State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive136Third134Proof70 : runCachedNode 511 127846 Adaptive136Third134Node70 = false := by
  decide +kernel

#print axioms adaptive136Third134Proof70

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive136Third134Proof13 : runCachedNode 511 127846 Adaptive136Third134Node13 = false := by
  decide +kernel

#print axioms adaptive136Third134Proof13

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive136Third134Proof67 : runCachedNode 511 127846 Adaptive136Third134Node67 = false := by
  decide +kernel

#print axioms adaptive136Third134Proof67

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive136Third134Proof1 : runCachedNode 511 127846 Adaptive136Third134Node1 = false := by
  decide +kernel

#print axioms adaptive136Third134Proof1

end NineSeparatedSubsetSums
