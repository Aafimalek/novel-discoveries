import NineSeparatedSubsetSums.Adaptive136Third108State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive136Third108Proof0 : runCachedNode 511 110825 Adaptive136Third108Node0 = false := by
  decide +kernel

#print axioms adaptive136Third108Proof0

end NineSeparatedSubsetSums
