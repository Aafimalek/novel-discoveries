import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive136Third123Node0 : CachedSearchNode :=
  ⟨4, 122, computeCenteredMask [148,136,123], 407, 55529⟩

end NineSeparatedSubsetSums
