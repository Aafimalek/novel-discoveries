import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive136Third111Node0 : CachedSearchNode :=
  ⟨4, 110, computeCenteredMask [148,136,111], 395, 52721⟩

end NineSeparatedSubsetSums
