import NineSeparatedSubsetSums.EightPoint136_128PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint136_128PackedAnchor0Part1 :
    ∀ j : Fin 120, 2329998 ≤ FourPointNumeric.octPackedCharge 136 128 20 packedOct136_128_0
      (2*((j.val : Int)+120)+0) := by decide +kernel

end NineSeparatedSubsetSums
