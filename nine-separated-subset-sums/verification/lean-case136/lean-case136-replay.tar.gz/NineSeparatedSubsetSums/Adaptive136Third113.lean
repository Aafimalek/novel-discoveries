import NineSeparatedSubsetSums.Adaptive136Third113Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint136Checked

namespace NineSeparatedSubsetSums


theorem adaptive136Third113 : NoDescendingTailAfterThird 136 113 :=
  noDescendingThirdTail_of_cached 136 113 110825 (fun t ht nd => max148_second136_fourPoint_moment_bound (113::t) (by simp [ht]) nd) adaptive136Third113Proof0

#print axioms adaptive136Third113

end NineSeparatedSubsetSums
