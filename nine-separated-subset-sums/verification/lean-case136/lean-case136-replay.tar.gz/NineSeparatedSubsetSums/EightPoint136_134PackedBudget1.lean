import NineSeparatedSubsetSums.EightPoint136_134PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct136_134_1_budget :
    FourPointNumeric.packedBudget 20 packedOct136_134_1 280 = 88893024 := by decide +kernel

#print axioms packedOct136_134_1_budget

end NineSeparatedSubsetSums
