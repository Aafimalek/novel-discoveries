import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive136Third126Node0 : CachedSearchNode :=
  ⟨4, 125, computeCenteredMask [148,136,126], 410, 56276⟩

end NineSeparatedSubsetSums
