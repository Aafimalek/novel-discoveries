import NineSeparatedSubsetSums.EightPoint136_135PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint136_135PackedAnchor1Part0 :
    ∀ j : Fin 120, 2427762 ≤ FourPointNumeric.octPackedCharge 136 135 20 packedOct136_135_1
      (2*((j.val : Int)+0)+0) := by decide +kernel

end NineSeparatedSubsetSums
