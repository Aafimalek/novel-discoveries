import NineSeparatedSubsetSums.Adaptive136Third134State
import NineSeparatedSubsetSums.Adaptive136Third134Leaves3
import NineSeparatedSubsetSums.Adaptive136Third134Leaves4
import NineSeparatedSubsetSums.Adaptive136Third134Leaves6
import NineSeparatedSubsetSums.Adaptive136Third134Leaves2
import NineSeparatedSubsetSums.Adaptive136Third134Leaves5
import NineSeparatedSubsetSums.Adaptive136Third134Leaves7
import NineSeparatedSubsetSums.Adaptive136Third134Leaves1
import NineSeparatedSubsetSums.Adaptive136Third134Leaves0

namespace NineSeparatedSubsetSums

theorem adaptive136Third134Proof21 : runCachedNode 511 127846 Adaptive136Third134Node21 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 127846 Adaptive136Third134Node21 = [105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 119, 121, 123, 124, 125, 126, 127, 128, 129, 131] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive136Third134Proof22
  · exact adaptive136Third134Proof23
  · exact adaptive136Third134Proof24
  · exact adaptive136Third134Proof25
  · exact adaptive136Third134Proof26
  · exact adaptive136Third134Proof27
  · exact adaptive136Third134Proof28
  · exact adaptive136Third134Proof29
  · exact adaptive136Third134Proof30
  · exact adaptive136Third134Proof31
  · exact adaptive136Third134Proof32
  · exact adaptive136Third134Proof33
  · exact adaptive136Third134Proof34
  · exact adaptive136Third134Proof35
  · exact adaptive136Third134Proof36
  · exact adaptive136Third134Proof37
  · exact adaptive136Third134Proof38
  · exact adaptive136Third134Proof39
  · exact adaptive136Third134Proof40
  · exact adaptive136Third134Proof41
  · exact adaptive136Third134Proof42
  · exact adaptive136Third134Proof43
  · exact adaptive136Third134Proof44

#print axioms adaptive136Third134Proof21

theorem adaptive136Third134Proof45 : runCachedNode 511 127846 Adaptive136Third134Node45 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 127846 Adaptive136Third134Node45 = [104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 120, 123, 124, 125, 126, 127, 128, 129, 130, 132] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive136Third134Proof46
  · exact adaptive136Third134Proof47
  · exact adaptive136Third134Proof48
  · exact adaptive136Third134Proof49
  · exact adaptive136Third134Proof50
  · exact adaptive136Third134Proof51
  · exact adaptive136Third134Proof52
  · exact adaptive136Third134Proof53
  · exact adaptive136Third134Proof54
  · exact adaptive136Third134Proof55
  · exact adaptive136Third134Proof56
  · exact adaptive136Third134Proof57
  · exact adaptive136Third134Proof58
  · exact adaptive136Third134Proof59
  · exact adaptive136Third134Proof60
  · exact adaptive136Third134Proof61
  · exact adaptive136Third134Proof62
  · exact adaptive136Third134Proof63
  · exact adaptive136Third134Proof64
  · exact adaptive136Third134Proof65
  · exact adaptive136Third134Proof66
  · exact adaptive136Third134Proof67
  · exact adaptive136Third134Proof68
  · exact adaptive136Third134Proof69
  · exact adaptive136Third134Proof70

#print axioms adaptive136Third134Proof45

theorem adaptive136Third134Proof0 : runCachedNode 511 127846 Adaptive136Third134Node0 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 127846 Adaptive136Third134Node0 = [111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 123, 124, 125, 126, 127, 128, 129, 130, 131, 132, 133] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive136Third134Proof1
  · exact adaptive136Third134Proof2
  · exact adaptive136Third134Proof3
  · exact adaptive136Third134Proof4
  · exact adaptive136Third134Proof5
  · exact adaptive136Third134Proof6
  · exact adaptive136Third134Proof7
  · exact adaptive136Third134Proof8
  · exact adaptive136Third134Proof9
  · exact adaptive136Third134Proof10
  · exact adaptive136Third134Proof11
  · exact adaptive136Third134Proof12
  · exact adaptive136Third134Proof13
  · exact adaptive136Third134Proof14
  · exact adaptive136Third134Proof15
  · exact adaptive136Third134Proof16
  · exact adaptive136Third134Proof17
  · exact adaptive136Third134Proof18
  · exact adaptive136Third134Proof19
  · exact adaptive136Third134Proof20
  · exact adaptive136Third134Proof21
  · exact adaptive136Third134Proof45

#print axioms adaptive136Third134Proof0

end NineSeparatedSubsetSums
