import NineSeparatedSubsetSums.EightPoint136_134PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint136_134PackedAnchor1Part0 :
    ∀ j : Fin 120, 2411714 ≤ FourPointNumeric.octPackedCharge 136 134 20 packedOct136_134_1
      (2*((j.val : Int)+0)+1) := by decide +kernel

end NineSeparatedSubsetSums
