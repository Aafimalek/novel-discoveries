import NineSeparatedSubsetSums.EightPoint136_132PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct136_132_0_budget :
    FourPointNumeric.packedBudget 20 packedOct136_132_0 451 = 88604357 := by decide +kernel

#print axioms packedOct136_132_0_budget

end NineSeparatedSubsetSums
