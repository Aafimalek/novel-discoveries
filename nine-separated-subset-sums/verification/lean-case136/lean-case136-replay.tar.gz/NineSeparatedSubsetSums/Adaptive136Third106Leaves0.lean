import NineSeparatedSubsetSums.Adaptive136Third106State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive136Third106Proof0 : runCachedNode 511 110825 Adaptive136Third106Node0 = false := by
  decide +kernel

#print axioms adaptive136Third106Proof0

end NineSeparatedSubsetSums
