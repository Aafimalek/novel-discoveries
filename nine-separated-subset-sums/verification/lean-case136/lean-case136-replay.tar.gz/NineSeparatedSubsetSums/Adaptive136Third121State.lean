import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive136Third121Node0 : CachedSearchNode :=
  ⟨4, 120, computeCenteredMask [148,136,121], 405, 55041⟩

end NineSeparatedSubsetSums
