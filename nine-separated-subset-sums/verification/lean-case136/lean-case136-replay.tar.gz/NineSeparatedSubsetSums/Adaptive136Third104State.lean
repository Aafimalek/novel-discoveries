import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive136Third104Node0 : CachedSearchNode :=
  ⟨4, 103, computeCenteredMask [148,136,104], 388, 51216⟩

end NineSeparatedSubsetSums
