import NineSeparatedSubsetSums.EightPointPackedGeometry
import NineSeparatedSubsetSums.EightPoint136_133PackedBudget0
import NineSeparatedSubsetSums.EightPoint136_133PackedAnchor0Part0
import NineSeparatedSubsetSums.EightPoint136_133PackedAnchor0Part1
import NineSeparatedSubsetSums.EightPoint136_133PackedAnchor0Part2
import NineSeparatedSubsetSums.EightPoint136_133PackedBudget1
import NineSeparatedSubsetSums.EightPoint136_133PackedAnchor1Part0
import NineSeparatedSubsetSums.EightPoint136_133PackedAnchor1Part1
import NineSeparatedSubsetSums.EightPoint136_133PackedAnchor1Part2

namespace NineSeparatedSubsetSums

private theorem packedOct136_133Anchor0 :
  ∀ j : Fin 493, ((j.val : Int)+136+133)%2=0 →
    2407705 ≤ FourPointNumeric.octPackedCharge 136 133 20 packedOct136_133_0 (j.val : Int) := by
  intro j hj
  let k := (j.val-1)/2
  have hk : k < 246 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+1 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint136_133PackedAnchor0Part0 z
    rwa [he,hrep] at ht
  by_cases h1 : k < 240
  · let z : Fin 120 := ⟨k-120, by omega⟩
    have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
    have ht := eightPoint136_133PackedAnchor0Part1 z
    rwa [he,hrep] at ht
  let z : Fin 6 := ⟨k-240, by omega⟩
  have he : (z.val : Int)+240 = k := by dsimp [z] <;> omega
  have ht := eightPoint136_133PackedAnchor0Part2 z
  rwa [he,hrep] at ht

private theorem packedOct136_133Anchor1 :
  ∀ j : Fin 493, ((j.val : Int)+136+133)%2=1 →
    2407179 ≤ FourPointNumeric.octPackedCharge 136 133 20 packedOct136_133_1 (j.val : Int) := by
  intro j hj
  let k := (j.val-0)/2
  have hk : k < 247 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+0 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint136_133PackedAnchor1Part0 z
    rwa [he,hrep] at ht
  by_cases h1 : k < 240
  · let z : Fin 120 := ⟨k-120, by omega⟩
    have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
    have ht := eightPoint136_133PackedAnchor1Part1 z
    rwa [he,hrep] at ht
  let z : Fin 7 := ⟨k-240, by omega⟩
  have he : (z.val : Int)+240 = k := by dsimp [z] <;> omega
  have ht := eightPoint136_133PackedAnchor1Part2 z
  rwa [he,hrep] at ht

def packedOctCertificate136_133_0 : EightPointCertificate 136 133 0 127674 :=
  eightPointCertificateOfPacked 136 133 0 127674 2407705 20 packedOct136_133_0 415 493
    (by decide +kernel) (by decide) packedOct136_133Anchor0
    (by rw [packedOct136_133_0_budget]; decide)

def packedOctCertificate136_133_1 : EightPointCertificate 136 133 1 127674 :=
  eightPointCertificateOfPacked 136 133 1 127674 2407179 20 packedOct136_133_1 466 493
    (by decide +kernel) (by decide) packedOct136_133Anchor1
    (by rw [packedOct136_133_1_budget]; decide)

theorem max148_second136_third133_eightPoint_moment_bound (tail : List ℕ) (len : tail.length=6)
    (distinct : (natSubsetSums (148::136::133::tail)).Nodup) :
    127674 ≤ ((148::136::133::tail).map (· ^ 2)).sum := by
  apply eightPointNatMomentLower 136 133 127674 tail len distinct
  intro p hp
  by_cases h : p=0
  · subst p
    exact packedOctCertificate136_133_0
  · have he : p=1 := hp.resolve_left h
    subst p
    exact packedOctCertificate136_133_1

#print axioms max148_second136_third133_eightPoint_moment_bound

end NineSeparatedSubsetSums
