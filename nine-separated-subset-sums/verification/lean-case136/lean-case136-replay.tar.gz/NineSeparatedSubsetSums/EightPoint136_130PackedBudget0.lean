import NineSeparatedSubsetSums.EightPoint136_130PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct136_130_0_budget :
    FourPointNumeric.packedBudget 20 packedOct136_130_0 263 = 88126311 := by decide +kernel

#print axioms packedOct136_130_0_budget

end NineSeparatedSubsetSums
