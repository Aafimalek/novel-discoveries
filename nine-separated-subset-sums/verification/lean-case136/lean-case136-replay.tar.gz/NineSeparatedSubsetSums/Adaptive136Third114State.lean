import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive136Third114Node0 : CachedSearchNode :=
  ⟨4, 113, computeCenteredMask [148,136,114], 398, 53396⟩

end NineSeparatedSubsetSums
