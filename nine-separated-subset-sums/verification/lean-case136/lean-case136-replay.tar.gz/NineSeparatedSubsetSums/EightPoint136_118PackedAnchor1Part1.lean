import NineSeparatedSubsetSums.EightPoint136_118PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint136_118PackedAnchor1Part1 :
    ∀ j : Fin 120, 2272582 ≤ FourPointNumeric.octPackedCharge 136 118 20 packedOct136_118_1
      (2*((j.val : Int)+120)+1) := by decide +kernel

end NineSeparatedSubsetSums
