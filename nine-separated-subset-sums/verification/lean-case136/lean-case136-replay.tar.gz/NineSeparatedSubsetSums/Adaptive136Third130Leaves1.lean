import NineSeparatedSubsetSums.Adaptive136Third130State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive136Third130Proof13 : runCachedNode 511 127094 Adaptive136Third130Node13 = false := by
  decide +kernel

#print axioms adaptive136Third130Proof13

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive136Third130Proof16 : runCachedNode 511 127094 Adaptive136Third130Node16 = false := by
  decide +kernel

#print axioms adaptive136Third130Proof16

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive136Third130Proof14 : runCachedNode 511 127094 Adaptive136Third130Node14 = false := by
  decide +kernel

#print axioms adaptive136Third130Proof14

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive136Third130Proof10 : runCachedNode 511 127094 Adaptive136Third130Node10 = false := by
  decide +kernel

#print axioms adaptive136Third130Proof10

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive136Third130Proof5 : runCachedNode 511 127094 Adaptive136Third130Node5 = false := by
  decide +kernel

#print axioms adaptive136Third130Proof5

end NineSeparatedSubsetSums
