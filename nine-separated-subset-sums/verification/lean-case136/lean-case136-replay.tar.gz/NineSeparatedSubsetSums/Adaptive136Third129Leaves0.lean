import NineSeparatedSubsetSums.Adaptive136Third129State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive136Third129Proof17 : runCachedNode 511 126844 Adaptive136Third129Node17 = false := by
  decide +kernel

#print axioms adaptive136Third129Proof17

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive136Third129Proof16 : runCachedNode 511 126844 Adaptive136Third129Node16 = false := by
  decide +kernel

#print axioms adaptive136Third129Proof16

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive136Third129Proof15 : runCachedNode 511 126844 Adaptive136Third129Node15 = false := by
  decide +kernel

#print axioms adaptive136Third129Proof15

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive136Third129Proof4 : runCachedNode 511 126844 Adaptive136Third129Node4 = false := by
  decide +kernel

#print axioms adaptive136Third129Proof4

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive136Third129Proof1 : runCachedNode 511 126844 Adaptive136Third129Node1 = false := by
  decide +kernel

#print axioms adaptive136Third129Proof1

end NineSeparatedSubsetSums
