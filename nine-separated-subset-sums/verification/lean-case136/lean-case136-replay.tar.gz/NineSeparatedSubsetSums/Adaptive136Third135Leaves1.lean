import NineSeparatedSubsetSums.Adaptive136Third135State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive136Third135Proof21 : runCachedNode 511 128045 Adaptive136Third135Node21 = false := by
  decide +kernel

#print axioms adaptive136Third135Proof21

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive136Third135Proof40 : runCachedNode 511 128045 Adaptive136Third135Node40 = false := by
  decide +kernel

#print axioms adaptive136Third135Proof40

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive136Third135Proof1 : runCachedNode 511 128045 Adaptive136Third135Node1 = false := by
  decide +kernel

#print axioms adaptive136Third135Proof1

end NineSeparatedSubsetSums
