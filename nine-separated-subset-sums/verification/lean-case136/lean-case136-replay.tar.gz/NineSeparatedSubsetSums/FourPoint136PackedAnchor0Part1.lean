import NineSeparatedSubsetSums.FourPoint136PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem fourPoint136PackedAnchor0Part1 :
    ∀ j : Fin 119, 1070720 ≤ FourPointNumeric.packedCharge 136 20 packedWeight136_0
      (2*((j.val : Int)+120)+0) := by decide +kernel

end NineSeparatedSubsetSums
