import NineSeparatedSubsetSums.Adaptive136Third123State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive136Third123Proof0 : runCachedNode 511 125431 Adaptive136Third123Node0 = false := by
  decide +kernel

#print axioms adaptive136Third123Proof0

end NineSeparatedSubsetSums
