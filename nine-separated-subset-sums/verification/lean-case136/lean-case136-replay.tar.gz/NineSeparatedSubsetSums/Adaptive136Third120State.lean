import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive136Third120Node0 : CachedSearchNode :=
  ⟨4, 119, computeCenteredMask [148,136,120], 404, 54800⟩

end NineSeparatedSubsetSums
