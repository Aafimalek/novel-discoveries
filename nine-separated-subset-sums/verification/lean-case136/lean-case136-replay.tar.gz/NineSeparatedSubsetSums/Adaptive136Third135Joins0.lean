import NineSeparatedSubsetSums.Adaptive136Third135State
import NineSeparatedSubsetSums.Adaptive136Third135Leaves4
import NineSeparatedSubsetSums.Adaptive136Third135Leaves3
import NineSeparatedSubsetSums.Adaptive136Third135Leaves2
import NineSeparatedSubsetSums.Adaptive136Third135Leaves7
import NineSeparatedSubsetSums.Adaptive136Third135Leaves5
import NineSeparatedSubsetSums.Adaptive136Third135Leaves6
import NineSeparatedSubsetSums.Adaptive136Third135Leaves1
import NineSeparatedSubsetSums.Adaptive136Third135Leaves0

namespace NineSeparatedSubsetSums

theorem adaptive136Third135Proof23 : runCachedNode 511 128045 Adaptive136Third135Node23 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 128045 Adaptive136Third135Node23 = [104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 124, 125, 126, 127, 128, 129, 130, 131, 132] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive136Third135Proof24
  · exact adaptive136Third135Proof25
  · exact adaptive136Third135Proof26
  · exact adaptive136Third135Proof27
  · exact adaptive136Third135Proof28
  · exact adaptive136Third135Proof29
  · exact adaptive136Third135Proof30
  · exact adaptive136Third135Proof31
  · exact adaptive136Third135Proof32
  · exact adaptive136Third135Proof33
  · exact adaptive136Third135Proof34
  · exact adaptive136Third135Proof35
  · exact adaptive136Third135Proof36
  · exact adaptive136Third135Proof37
  · exact adaptive136Third135Proof38
  · exact adaptive136Third135Proof39
  · exact adaptive136Third135Proof40
  · exact adaptive136Third135Proof41
  · exact adaptive136Third135Proof42
  · exact adaptive136Third135Proof43
  · exact adaptive136Third135Proof44
  · exact adaptive136Third135Proof45
  · exact adaptive136Third135Proof46
  · exact adaptive136Third135Proof47
  · exact adaptive136Third135Proof48
  · exact adaptive136Third135Proof49

#print axioms adaptive136Third135Proof23

theorem adaptive136Third135Proof0 : runCachedNode 511 128045 Adaptive136Third135Node0 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 128045 Adaptive136Third135Node0 = [111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 124, 125, 126, 127, 128, 129, 130, 131, 132, 133, 134] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive136Third135Proof1
  · exact adaptive136Third135Proof2
  · exact adaptive136Third135Proof3
  · exact adaptive136Third135Proof4
  · exact adaptive136Third135Proof5
  · exact adaptive136Third135Proof6
  · exact adaptive136Third135Proof7
  · exact adaptive136Third135Proof8
  · exact adaptive136Third135Proof9
  · exact adaptive136Third135Proof10
  · exact adaptive136Third135Proof11
  · exact adaptive136Third135Proof12
  · exact adaptive136Third135Proof13
  · exact adaptive136Third135Proof14
  · exact adaptive136Third135Proof15
  · exact adaptive136Third135Proof16
  · exact adaptive136Third135Proof17
  · exact adaptive136Third135Proof18
  · exact adaptive136Third135Proof19
  · exact adaptive136Third135Proof20
  · exact adaptive136Third135Proof21
  · exact adaptive136Third135Proof22
  · exact adaptive136Third135Proof23

#print axioms adaptive136Third135Proof0

end NineSeparatedSubsetSums
