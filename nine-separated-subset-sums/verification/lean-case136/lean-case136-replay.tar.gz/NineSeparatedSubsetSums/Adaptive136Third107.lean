import NineSeparatedSubsetSums.Adaptive136Third107Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint136Checked

namespace NineSeparatedSubsetSums


theorem adaptive136Third107 : NoDescendingTailAfterThird 136 107 :=
  noDescendingThirdTail_of_cached 136 107 110825 (fun t ht nd => max148_second136_fourPoint_moment_bound (107::t) (by simp [ht]) nd) adaptive136Third107Proof0

#print axioms adaptive136Third107

end NineSeparatedSubsetSums
