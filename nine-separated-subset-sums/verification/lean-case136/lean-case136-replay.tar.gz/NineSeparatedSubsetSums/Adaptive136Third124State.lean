import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive136Third124Node0 : CachedSearchNode :=
  ⟨4, 123, computeCenteredMask [148,136,124], 408, 55776⟩

end NineSeparatedSubsetSums
