import NineSeparatedSubsetSums.EightPoint136_120PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct136_120_1_budget :
    FourPointNumeric.packedBudget 20 packedOct136_120_1 382 = 85231762 := by decide +kernel

#print axioms packedOct136_120_1_budget

end NineSeparatedSubsetSums
