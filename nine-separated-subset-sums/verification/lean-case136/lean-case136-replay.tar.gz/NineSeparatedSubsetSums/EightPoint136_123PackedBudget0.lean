import NineSeparatedSubsetSums.EightPoint136_123PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct136_123_0_budget :
    FourPointNumeric.packedBudget 20 packedOct136_123_0 409 = 81480637 := by decide +kernel

#print axioms packedOct136_123_0_budget

end NineSeparatedSubsetSums
