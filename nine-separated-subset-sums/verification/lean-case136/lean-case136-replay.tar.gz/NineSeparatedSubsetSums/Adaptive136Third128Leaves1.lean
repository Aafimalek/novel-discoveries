import NineSeparatedSubsetSums.Adaptive136Third128State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive136Third128Proof14 : runCachedNode 511 126668 Adaptive136Third128Node14 = false := by
  decide +kernel

#print axioms adaptive136Third128Proof14

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive136Third128Proof12 : runCachedNode 511 126668 Adaptive136Third128Node12 = false := by
  decide +kernel

#print axioms adaptive136Third128Proof12

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive136Third128Proof11 : runCachedNode 511 126668 Adaptive136Third128Node11 = false := by
  decide +kernel

#print axioms adaptive136Third128Proof11

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive136Third128Proof10 : runCachedNode 511 126668 Adaptive136Third128Node10 = false := by
  decide +kernel

#print axioms adaptive136Third128Proof10

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive136Third128Proof9 : runCachedNode 511 126668 Adaptive136Third128Node9 = false := by
  decide +kernel

#print axioms adaptive136Third128Proof9

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive136Third128Proof8 : runCachedNode 511 126668 Adaptive136Third128Node8 = false := by
  decide +kernel

#print axioms adaptive136Third128Proof8

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive136Third128Proof7 : runCachedNode 511 126668 Adaptive136Third128Node7 = false := by
  decide +kernel

#print axioms adaptive136Third128Proof7

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive136Third128Proof5 : runCachedNode 511 126668 Adaptive136Third128Node5 = false := by
  decide +kernel

#print axioms adaptive136Third128Proof5

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive136Third128Proof4 : runCachedNode 511 126668 Adaptive136Third128Node4 = false := by
  decide +kernel

#print axioms adaptive136Third128Proof4

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive136Third128Proof3 : runCachedNode 511 126668 Adaptive136Third128Node3 = false := by
  decide +kernel

#print axioms adaptive136Third128Proof3

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive136Third128Proof2 : runCachedNode 511 126668 Adaptive136Third128Node2 = false := by
  decide +kernel

#print axioms adaptive136Third128Proof2

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive136Third128Proof1 : runCachedNode 511 126668 Adaptive136Third128Node1 = false := by
  decide +kernel

#print axioms adaptive136Third128Proof1

end NineSeparatedSubsetSums
