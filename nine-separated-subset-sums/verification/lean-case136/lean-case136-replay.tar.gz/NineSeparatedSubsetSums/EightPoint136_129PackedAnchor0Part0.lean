import NineSeparatedSubsetSums.EightPoint136_129PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint136_129PackedAnchor0Part0 :
    ∀ j : Fin 120, 2357650 ≤ FourPointNumeric.octPackedCharge 136 129 20 packedOct136_129_0
      (2*((j.val : Int)+0)+1) := by decide +kernel

end NineSeparatedSubsetSums
