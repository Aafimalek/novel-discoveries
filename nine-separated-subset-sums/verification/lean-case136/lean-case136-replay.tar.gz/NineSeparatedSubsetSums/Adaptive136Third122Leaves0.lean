import NineSeparatedSubsetSums.Adaptive136Third122State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive136Third122Proof0 : runCachedNode 511 125181 Adaptive136Third122Node0 = false := by
  decide +kernel

#print axioms adaptive136Third122Proof0

end NineSeparatedSubsetSums
