import NineSeparatedSubsetSums.EightPoint136_120PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct136_120_0_budget :
    FourPointNumeric.packedBudget 20 packedOct136_120_0 379 = 85564708 := by decide +kernel

#print axioms packedOct136_120_0_budget

end NineSeparatedSubsetSums
