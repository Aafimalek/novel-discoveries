import NineSeparatedSubsetSums.EightPoint136_119PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint136_119PackedAnchor0Part1 :
    ∀ j : Fin 120, 2317950 ≤ FourPointNumeric.octPackedCharge 136 119 20 packedOct136_119_0
      (2*((j.val : Int)+120)+1) := by decide +kernel

end NineSeparatedSubsetSums
