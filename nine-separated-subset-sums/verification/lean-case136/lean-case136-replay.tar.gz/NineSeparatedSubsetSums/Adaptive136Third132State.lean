import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive136Third132Node0 : CachedSearchNode :=
  ⟨4, 131, computeCenteredMask [148,136,132], 416, 57824⟩
def Adaptive136Third132Node1 : CachedSearchNode := cachedChild Adaptive136Third132Node0 111
def Adaptive136Third132Node2 : CachedSearchNode := cachedChild Adaptive136Third132Node0 112
def Adaptive136Third132Node3 : CachedSearchNode := cachedChild Adaptive136Third132Node0 113
def Adaptive136Third132Node4 : CachedSearchNode := cachedChild Adaptive136Third132Node0 114
def Adaptive136Third132Node5 : CachedSearchNode := cachedChild Adaptive136Third132Node0 115
def Adaptive136Third132Node6 : CachedSearchNode := cachedChild Adaptive136Third132Node0 116
def Adaptive136Third132Node7 : CachedSearchNode := cachedChild Adaptive136Third132Node0 117
def Adaptive136Third132Node8 : CachedSearchNode := cachedChild Adaptive136Third132Node0 118
def Adaptive136Third132Node9 : CachedSearchNode := cachedChild Adaptive136Third132Node0 119
def Adaptive136Third132Node10 : CachedSearchNode := cachedChild Adaptive136Third132Node0 121
def Adaptive136Third132Node11 : CachedSearchNode := cachedChild Adaptive136Third132Node0 122
def Adaptive136Third132Node12 : CachedSearchNode := cachedChild Adaptive136Third132Node0 123
def Adaptive136Third132Node13 : CachedSearchNode := cachedChild Adaptive136Third132Node0 124
def Adaptive136Third132Node14 : CachedSearchNode := cachedChild Adaptive136Third132Node0 125
def Adaptive136Third132Node15 : CachedSearchNode := cachedChild Adaptive136Third132Node0 126
def Adaptive136Third132Node16 : CachedSearchNode := cachedChild Adaptive136Third132Node0 127
def Adaptive136Third132Node17 : CachedSearchNode := cachedChild Adaptive136Third132Node0 128
def Adaptive136Third132Node18 : CachedSearchNode := cachedChild Adaptive136Third132Node0 129
def Adaptive136Third132Node19 : CachedSearchNode := cachedChild Adaptive136Third132Node0 130
def Adaptive136Third132Node20 : CachedSearchNode := cachedChild Adaptive136Third132Node0 131

end NineSeparatedSubsetSums
