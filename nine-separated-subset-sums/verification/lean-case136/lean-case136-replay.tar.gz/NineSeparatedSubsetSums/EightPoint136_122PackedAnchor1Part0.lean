import NineSeparatedSubsetSums.EightPoint136_122PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint136_122PackedAnchor1Part0 :
    ∀ j : Fin 120, 2269773 ≤ FourPointNumeric.octPackedCharge 136 122 20 packedOct136_122_1
      (2*((j.val : Int)+0)+1) := by decide +kernel

end NineSeparatedSubsetSums
