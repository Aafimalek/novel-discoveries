import NineSeparatedSubsetSums.Adaptive136Third135State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive136Third135Proof22 : runCachedNode 511 128045 Adaptive136Third135Node22 = false := by
  decide +kernel

#print axioms adaptive136Third135Proof22

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive136Third135Proof43 : runCachedNode 511 128045 Adaptive136Third135Node43 = false := by
  decide +kernel

#print axioms adaptive136Third135Proof43

end NineSeparatedSubsetSums
