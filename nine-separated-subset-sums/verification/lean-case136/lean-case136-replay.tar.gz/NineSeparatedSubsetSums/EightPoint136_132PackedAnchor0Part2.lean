import NineSeparatedSubsetSums.EightPoint136_132PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint136_132PackedAnchor0Part2 :
    ∀ j : Fin 7, 2404969 ≤ FourPointNumeric.octPackedCharge 136 132 20 packedOct136_132_0
      (2*((j.val : Int)+240)+0) := by decide +kernel

end NineSeparatedSubsetSums
