import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive136Third117Node0 : CachedSearchNode :=
  ⟨4, 116, computeCenteredMask [148,136,117], 401, 54089⟩

end NineSeparatedSubsetSums
