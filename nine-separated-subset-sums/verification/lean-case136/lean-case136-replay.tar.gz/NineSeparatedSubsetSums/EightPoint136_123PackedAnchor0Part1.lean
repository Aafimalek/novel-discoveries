import NineSeparatedSubsetSums.EightPoint136_123PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint136_123PackedAnchor0Part1 :
    ∀ j : Fin 119, 2276580 ≤ FourPointNumeric.octPackedCharge 136 123 20 packedOct136_123_0
      (2*((j.val : Int)+120)+1) := by decide +kernel

end NineSeparatedSubsetSums
