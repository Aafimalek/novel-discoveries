import NineSeparatedSubsetSums.Adaptive136Third115Joins0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint136Checked

namespace NineSeparatedSubsetSums


theorem adaptive136Third115 : NoDescendingTailAfterThird 136 115 :=
  noDescendingThirdTail_of_cached 136 115 110825 (fun t ht nd => max148_second136_fourPoint_moment_bound (115::t) (by simp [ht]) nd) adaptive136Third115Proof0

#print axioms adaptive136Third115

end NineSeparatedSubsetSums
