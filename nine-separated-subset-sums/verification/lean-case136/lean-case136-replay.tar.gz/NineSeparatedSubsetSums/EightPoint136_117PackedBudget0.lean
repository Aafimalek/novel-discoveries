import NineSeparatedSubsetSums.EightPoint136_117PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct136_117_0_budget :
    FourPointNumeric.packedBudget 20 packedOct136_117_0 265 = 82570818 := by decide +kernel

#print axioms packedOct136_117_0_budget

end NineSeparatedSubsetSums
