import NineSeparatedSubsetSums.EightPoint136_130PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint136_130PackedAnchor0Part2 :
    ∀ j : Fin 6, 2393725 ≤ FourPointNumeric.octPackedCharge 136 130 20 packedOct136_130_0
      (2*((j.val : Int)+240)+0) := by decide +kernel

end NineSeparatedSubsetSums
