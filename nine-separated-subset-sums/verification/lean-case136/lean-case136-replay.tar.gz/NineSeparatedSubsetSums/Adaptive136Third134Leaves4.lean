import NineSeparatedSubsetSums.Adaptive136Third134State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive136Third134Proof18 : runCachedNode 511 127846 Adaptive136Third134Node18 = false := by
  decide +kernel

#print axioms adaptive136Third134Proof18

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive136Third134Proof43 : runCachedNode 511 127846 Adaptive136Third134Node43 = false := by
  decide +kernel

#print axioms adaptive136Third134Proof43

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive136Third134Proof15 : runCachedNode 511 127846 Adaptive136Third134Node15 = false := by
  decide +kernel

#print axioms adaptive136Third134Proof15

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive136Third134Proof63 : runCachedNode 511 127846 Adaptive136Third134Node63 = false := by
  decide +kernel

#print axioms adaptive136Third134Proof63

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive136Third134Proof23 : runCachedNode 511 127846 Adaptive136Third134Node23 = false := by
  decide +kernel

#print axioms adaptive136Third134Proof23

end NineSeparatedSubsetSums
