import NineSeparatedSubsetSums.Adaptive136Third127State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive136Third127Proof13 : runCachedNode 511 126691 Adaptive136Third127Node13 = false := by
  decide +kernel

#print axioms adaptive136Third127Proof13

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive136Third127Proof15 : runCachedNode 511 126691 Adaptive136Third127Node15 = false := by
  decide +kernel

#print axioms adaptive136Third127Proof15

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive136Third127Proof14 : runCachedNode 511 126691 Adaptive136Third127Node14 = false := by
  decide +kernel

#print axioms adaptive136Third127Proof14

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive136Third127Proof12 : runCachedNode 511 126691 Adaptive136Third127Node12 = false := by
  decide +kernel

#print axioms adaptive136Third127Proof12

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive136Third127Proof11 : runCachedNode 511 126691 Adaptive136Third127Node11 = false := by
  decide +kernel

#print axioms adaptive136Third127Proof11

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive136Third127Proof10 : runCachedNode 511 126691 Adaptive136Third127Node10 = false := by
  decide +kernel

#print axioms adaptive136Third127Proof10

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive136Third127Proof1 : runCachedNode 511 126691 Adaptive136Third127Node1 = false := by
  decide +kernel

#print axioms adaptive136Third127Proof1

end NineSeparatedSubsetSums
