import NineSeparatedSubsetSums.Adaptive136Third132State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive136Third132Proof20 : runCachedNode 511 127566 Adaptive136Third132Node20 = false := by
  decide +kernel

#print axioms adaptive136Third132Proof20

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive136Third132Proof16 : runCachedNode 511 127566 Adaptive136Third132Node16 = false := by
  decide +kernel

#print axioms adaptive136Third132Proof16

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive136Third132Proof3 : runCachedNode 511 127566 Adaptive136Third132Node3 = false := by
  decide +kernel

#print axioms adaptive136Third132Proof3

end NineSeparatedSubsetSums
