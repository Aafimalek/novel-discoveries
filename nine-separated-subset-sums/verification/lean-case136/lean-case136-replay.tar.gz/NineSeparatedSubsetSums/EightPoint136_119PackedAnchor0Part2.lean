import NineSeparatedSubsetSums.EightPoint136_119PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint136_119PackedAnchor0Part2 :
    ∀ j : Fin 2, 2317950 ≤ FourPointNumeric.octPackedCharge 136 119 20 packedOct136_119_0
      (2*((j.val : Int)+240)+1) := by decide +kernel

end NineSeparatedSubsetSums
