import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive136Third113Node0 : CachedSearchNode :=
  ⟨4, 112, computeCenteredMask [148,136,113], 397, 53169⟩

end NineSeparatedSubsetSums
