import NineSeparatedSubsetSums.Adaptive136Third112Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint136Checked

namespace NineSeparatedSubsetSums


theorem adaptive136Third112 : NoDescendingTailAfterThird 136 112 :=
  noDescendingThirdTail_of_cached 136 112 110825 (fun t ht nd => max148_second136_fourPoint_moment_bound (112::t) (by simp [ht]) nd) adaptive136Third112Proof0

#print axioms adaptive136Third112

end NineSeparatedSubsetSums
