import NineSeparatedSubsetSums.EightPointPackedGeometry
import NineSeparatedSubsetSums.EightPoint136_122PackedBudget0
import NineSeparatedSubsetSums.EightPoint136_122PackedAnchor0Part0
import NineSeparatedSubsetSums.EightPoint136_122PackedAnchor0Part1
import NineSeparatedSubsetSums.EightPoint136_122PackedBudget1
import NineSeparatedSubsetSums.EightPoint136_122PackedAnchor1Part0
import NineSeparatedSubsetSums.EightPoint136_122PackedAnchor1Part1

namespace NineSeparatedSubsetSums

private theorem packedOct136_122Anchor0 :
  ∀ j : Fin 479, ((j.val : Int)+136+122)%2=0 →
    2272122 ≤ FourPointNumeric.octPackedCharge 136 122 20 packedOct136_122_0 (j.val : Int) := by
  intro j hj
  let k := (j.val-0)/2
  have hk : k < 240 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+0 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint136_122PackedAnchor0Part0 z
    rwa [he,hrep] at ht
  let z : Fin 120 := ⟨k-120, by omega⟩
  have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
  have ht := eightPoint136_122PackedAnchor0Part1 z
  rwa [he,hrep] at ht

private theorem packedOct136_122Anchor1 :
  ∀ j : Fin 479, ((j.val : Int)+136+122)%2=1 →
    2269773 ≤ FourPointNumeric.octPackedCharge 136 122 20 packedOct136_122_1 (j.val : Int) := by
  intro j hj
  let k := (j.val-1)/2
  have hk : k < 239 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+1 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint136_122PackedAnchor1Part0 z
    rwa [he,hrep] at ht
  let z : Fin 119 := ⟨k-120, by omega⟩
  have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
  have ht := eightPoint136_122PackedAnchor1Part1 z
  rwa [he,hrep] at ht

def packedOctCertificate136_122_0 : EightPointCertificate 136 122 0 125181 :=
  eightPointCertificateOfPacked 136 122 0 125181 2272122 20 packedOct136_122_0 469 479
    (by decide +kernel) (by decide) packedOct136_122Anchor0
    (by rw [packedOct136_122_0_budget]; decide)

def packedOctCertificate136_122_1 : EightPointCertificate 136 122 1 125181 :=
  eightPointCertificateOfPacked 136 122 1 125181 2269773 20 packedOct136_122_1 470 479
    (by decide +kernel) (by decide) packedOct136_122Anchor1
    (by rw [packedOct136_122_1_budget]; decide)

theorem max148_second136_third122_eightPoint_moment_bound (tail : List ℕ) (len : tail.length=6)
    (distinct : (natSubsetSums (148::136::122::tail)).Nodup) :
    125181 ≤ ((148::136::122::tail).map (· ^ 2)).sum := by
  apply eightPointNatMomentLower 136 122 125181 tail len distinct
  intro p hp
  by_cases h : p=0
  · subst p
    exact packedOctCertificate136_122_0
  · have he : p=1 := hp.resolve_left h
    subst p
    exact packedOctCertificate136_122_1

#print axioms max148_second136_third122_eightPoint_moment_bound

end NineSeparatedSubsetSums
