import NineSeparatedSubsetSums.EightPointPackedGeometry
import NineSeparatedSubsetSums.EightPoint136_118PackedBudget0
import NineSeparatedSubsetSums.EightPoint136_118PackedAnchor0Part0
import NineSeparatedSubsetSums.EightPoint136_118PackedAnchor0Part1
import NineSeparatedSubsetSums.EightPoint136_118PackedBudget1
import NineSeparatedSubsetSums.EightPoint136_118PackedAnchor1Part0
import NineSeparatedSubsetSums.EightPoint136_118PackedAnchor1Part1

namespace NineSeparatedSubsetSums

private theorem packedOct136_118Anchor0 :
  ∀ j : Fin 480, ((j.val : Int)+136+118)%2=0 →
    2273581 ≤ FourPointNumeric.octPackedCharge 136 118 20 packedOct136_118_0 (j.val : Int) := by
  intro j hj
  let k := (j.val-0)/2
  have hk : k < 240 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+0 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint136_118PackedAnchor0Part0 z
    rwa [he,hrep] at ht
  let z : Fin 120 := ⟨k-120, by omega⟩
  have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
  have ht := eightPoint136_118PackedAnchor0Part1 z
  rwa [he,hrep] at ht

private theorem packedOct136_118Anchor1 :
  ∀ j : Fin 480, ((j.val : Int)+136+118)%2=1 →
    2272582 ≤ FourPointNumeric.octPackedCharge 136 118 20 packedOct136_118_1 (j.val : Int) := by
  intro j hj
  let k := (j.val-1)/2
  have hk : k < 240 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+1 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint136_118PackedAnchor1Part0 z
    rwa [he,hrep] at ht
  let z : Fin 120 := ⟨k-120, by omega⟩
  have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
  have ht := eightPoint136_118PackedAnchor1Part1 z
  rwa [he,hrep] at ht

def packedOctCertificate136_118_0 : EightPointCertificate 136 118 0 124506 :=
  eightPointCertificateOfPacked 136 118 0 124506 2273581 20 packedOct136_118_0 263 480
    (by decide +kernel) (by decide) packedOct136_118Anchor0
    (by rw [packedOct136_118_0_budget]; decide)

def packedOctCertificate136_118_1 : EightPointCertificate 136 118 1 124506 :=
  eightPointCertificateOfPacked 136 118 1 124506 2272582 20 packedOct136_118_1 260 480
    (by decide +kernel) (by decide) packedOct136_118Anchor1
    (by rw [packedOct136_118_1_budget]; decide)

theorem max148_second136_third118_eightPoint_moment_bound (tail : List ℕ) (len : tail.length=6)
    (distinct : (natSubsetSums (148::136::118::tail)).Nodup) :
    124506 ≤ ((148::136::118::tail).map (· ^ 2)).sum := by
  apply eightPointNatMomentLower 136 118 124506 tail len distinct
  intro p hp
  by_cases h : p=0
  · subst p
    exact packedOctCertificate136_118_0
  · have he : p=1 := hp.resolve_left h
    subst p
    exact packedOctCertificate136_118_1

#print axioms max148_second136_third118_eightPoint_moment_bound

end NineSeparatedSubsetSums
