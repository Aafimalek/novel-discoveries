import NineSeparatedSubsetSums.EightPoint136_126PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint136_126PackedAnchor1Part1 :
    ∀ j : Fin 120, 2336073 ≤ FourPointNumeric.octPackedCharge 136 126 20 packedOct136_126_1
      (2*((j.val : Int)+120)+1) := by decide +kernel

end NineSeparatedSubsetSums
