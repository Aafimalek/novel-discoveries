import NineSeparatedSubsetSums.Adaptive136Third133State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive136Third133Proof20 : runCachedNode 511 127674 Adaptive136Third133Node20 = false := by
  decide +kernel

#print axioms adaptive136Third133Proof20

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive136Third133Proof15 : runCachedNode 511 127674 Adaptive136Third133Node15 = false := by
  decide +kernel

#print axioms adaptive136Third133Proof15

end NineSeparatedSubsetSums
