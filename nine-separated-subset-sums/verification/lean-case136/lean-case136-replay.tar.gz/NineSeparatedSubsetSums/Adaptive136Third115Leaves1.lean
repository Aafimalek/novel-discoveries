import NineSeparatedSubsetSums.Adaptive136Third115State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive136Third115Proof8 : runCachedNode 511 110825 Adaptive136Third115Node8 = false := by
  decide +kernel

#print axioms adaptive136Third115Proof8

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive136Third115Proof6 : runCachedNode 511 110825 Adaptive136Third115Node6 = false := by
  decide +kernel

#print axioms adaptive136Third115Proof6

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive136Third115Proof5 : runCachedNode 511 110825 Adaptive136Third115Node5 = false := by
  decide +kernel

#print axioms adaptive136Third115Proof5

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive136Third115Proof4 : runCachedNode 511 110825 Adaptive136Third115Node4 = false := by
  decide +kernel

#print axioms adaptive136Third115Proof4

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive136Third115Proof3 : runCachedNode 511 110825 Adaptive136Third115Node3 = false := by
  decide +kernel

#print axioms adaptive136Third115Proof3

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive136Third115Proof2 : runCachedNode 511 110825 Adaptive136Third115Node2 = false := by
  decide +kernel

#print axioms adaptive136Third115Proof2

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive136Third115Proof1 : runCachedNode 511 110825 Adaptive136Third115Node1 = false := by
  decide +kernel

#print axioms adaptive136Third115Proof1

end NineSeparatedSubsetSums
