import NineSeparatedSubsetSums.Adaptive136Third131State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive136Third131Proof19 : runCachedNode 511 127350 Adaptive136Third131Node19 = false := by
  decide +kernel

#print axioms adaptive136Third131Proof19

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive136Third131Proof17 : runCachedNode 511 127350 Adaptive136Third131Node17 = false := by
  decide +kernel

#print axioms adaptive136Third131Proof17

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive136Third131Proof3 : runCachedNode 511 127350 Adaptive136Third131Node3 = false := by
  decide +kernel

#print axioms adaptive136Third131Proof3

end NineSeparatedSubsetSums
