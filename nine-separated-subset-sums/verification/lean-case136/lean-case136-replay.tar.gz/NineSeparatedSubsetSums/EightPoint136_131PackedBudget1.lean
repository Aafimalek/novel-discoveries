import NineSeparatedSubsetSums.EightPoint136_131PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct136_131_1_budget :
    FourPointNumeric.packedBudget 20 packedOct136_131_1 444 = 89572396 := by decide +kernel

#print axioms packedOct136_131_1_budget

end NineSeparatedSubsetSums
