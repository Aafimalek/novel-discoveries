import NineSeparatedSubsetSums.Adaptive136Third135State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive136Third135Proof18 : runCachedNode 511 128045 Adaptive136Third135Node18 = false := by
  decide +kernel

#print axioms adaptive136Third135Proof18

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive136Third135Proof48 : runCachedNode 511 128045 Adaptive136Third135Node48 = false := by
  decide +kernel

#print axioms adaptive136Third135Proof48

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive136Third135Proof44 : runCachedNode 511 128045 Adaptive136Third135Node44 = false := by
  decide +kernel

#print axioms adaptive136Third135Proof44

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive136Third135Proof38 : runCachedNode 511 128045 Adaptive136Third135Node38 = false := by
  decide +kernel

#print axioms adaptive136Third135Proof38

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive136Third135Proof3 : runCachedNode 511 128045 Adaptive136Third135Node3 = false := by
  decide +kernel

#print axioms adaptive136Third135Proof3

end NineSeparatedSubsetSums
