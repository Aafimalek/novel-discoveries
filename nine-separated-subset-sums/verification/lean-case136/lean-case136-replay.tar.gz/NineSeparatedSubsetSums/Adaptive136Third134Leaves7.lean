import NineSeparatedSubsetSums.Adaptive136Third134State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive136Third134Proof49 : runCachedNode 511 127846 Adaptive136Third134Node49 = false := by
  decide +kernel

#print axioms adaptive136Third134Proof49

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive136Third134Proof48 : runCachedNode 511 127846 Adaptive136Third134Node48 = false := by
  decide +kernel

#print axioms adaptive136Third134Proof48

end NineSeparatedSubsetSums
