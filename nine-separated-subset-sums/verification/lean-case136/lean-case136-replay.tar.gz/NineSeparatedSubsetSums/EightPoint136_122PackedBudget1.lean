import NineSeparatedSubsetSums.EightPoint136_122PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct136_122_1_budget :
    FourPointNumeric.packedBudget 20 packedOct136_122_1 470 = 81172860 := by decide +kernel

#print axioms packedOct136_122_1_budget

end NineSeparatedSubsetSums
