import NineSeparatedSubsetSums.EightPoint136_131PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct136_131_0_budget :
    FourPointNumeric.packedBudget 20 packedOct136_131_0 445 = 89586319 := by decide +kernel

#print axioms packedOct136_131_0_budget

end NineSeparatedSubsetSums
