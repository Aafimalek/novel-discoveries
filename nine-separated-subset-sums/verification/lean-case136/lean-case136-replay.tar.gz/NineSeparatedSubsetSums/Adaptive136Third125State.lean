import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive136Third125Node0 : CachedSearchNode :=
  ⟨4, 124, computeCenteredMask [148,136,125], 409, 56025⟩

end NineSeparatedSubsetSums
