import NineSeparatedSubsetSums.EightPoint136_135PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct136_135_1_budget :
    FourPointNumeric.packedBudget 20 packedOct136_135_1 454 = 89817602 := by decide +kernel

#print axioms packedOct136_135_1_budget

end NineSeparatedSubsetSums
