import NineSeparatedSubsetSums.Adaptive136Third135State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive136Third135Proof16 : runCachedNode 511 128045 Adaptive136Third135Node16 = false := by
  decide +kernel

#print axioms adaptive136Third135Proof16

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive136Third135Proof15 : runCachedNode 511 128045 Adaptive136Third135Node15 = false := by
  decide +kernel

#print axioms adaptive136Third135Proof15

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive136Third135Proof46 : runCachedNode 511 128045 Adaptive136Third135Node46 = false := by
  decide +kernel

#print axioms adaptive136Third135Proof46

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive136Third135Proof45 : runCachedNode 511 128045 Adaptive136Third135Node45 = false := by
  decide +kernel

#print axioms adaptive136Third135Proof45

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive136Third135Proof39 : runCachedNode 511 128045 Adaptive136Third135Node39 = false := by
  decide +kernel

#print axioms adaptive136Third135Proof39

end NineSeparatedSubsetSums
