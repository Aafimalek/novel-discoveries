import NineSeparatedSubsetSums.Adaptive136Third134State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive136Third134Proof20 : runCachedNode 511 127846 Adaptive136Third134Node20 = false := by
  decide +kernel

#print axioms adaptive136Third134Proof20

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive136Third134Proof16 : runCachedNode 511 127846 Adaptive136Third134Node16 = false := by
  decide +kernel

#print axioms adaptive136Third134Proof16

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive136Third134Proof2 : runCachedNode 511 127846 Adaptive136Third134Node2 = false := by
  decide +kernel

#print axioms adaptive136Third134Proof2

end NineSeparatedSubsetSums
