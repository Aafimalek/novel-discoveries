import NineSeparatedSubsetSums.EightPointPackedGeometry
import NineSeparatedSubsetSums.EightPoint136_125PackedBudget0
import NineSeparatedSubsetSums.EightPoint136_125PackedAnchor0Part0
import NineSeparatedSubsetSums.EightPoint136_125PackedAnchor0Part1
import NineSeparatedSubsetSums.EightPoint136_125PackedAnchor0Part2
import NineSeparatedSubsetSums.EightPoint136_125PackedBudget1
import NineSeparatedSubsetSums.EightPoint136_125PackedAnchor1Part0
import NineSeparatedSubsetSums.EightPoint136_125PackedAnchor1Part1
import NineSeparatedSubsetSums.EightPoint136_125PackedAnchor1Part2

namespace NineSeparatedSubsetSums

private theorem packedOct136_125Anchor0 :
  ∀ j : Fin 483, ((j.val : Int)+136+125)%2=0 →
    2308162 ≤ FourPointNumeric.octPackedCharge 136 125 20 packedOct136_125_0 (j.val : Int) := by
  intro j hj
  let k := (j.val-1)/2
  have hk : k < 241 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+1 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint136_125PackedAnchor0Part0 z
    rwa [he,hrep] at ht
  by_cases h1 : k < 240
  · let z : Fin 120 := ⟨k-120, by omega⟩
    have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
    have ht := eightPoint136_125PackedAnchor0Part1 z
    rwa [he,hrep] at ht
  let z : Fin 1 := ⟨k-240, by omega⟩
  have he : (z.val : Int)+240 = k := by dsimp [z] <;> omega
  have ht := eightPoint136_125PackedAnchor0Part2 z
  rwa [he,hrep] at ht

private theorem packedOct136_125Anchor1 :
  ∀ j : Fin 483, ((j.val : Int)+136+125)%2=1 →
    2307833 ≤ FourPointNumeric.octPackedCharge 136 125 20 packedOct136_125_1 (j.val : Int) := by
  intro j hj
  let k := (j.val-0)/2
  have hk : k < 242 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+0 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint136_125PackedAnchor1Part0 z
    rwa [he,hrep] at ht
  by_cases h1 : k < 240
  · let z : Fin 120 := ⟨k-120, by omega⟩
    have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
    have ht := eightPoint136_125PackedAnchor1Part1 z
    rwa [he,hrep] at ht
  let z : Fin 2 := ⟨k-240, by omega⟩
  have he : (z.val : Int)+240 = k := by dsimp [z] <;> omega
  have ht := eightPoint136_125PackedAnchor1Part2 z
  rwa [he,hrep] at ht

def packedOctCertificate136_125_0 : EightPointCertificate 136 125 0 126195 :=
  eightPointCertificateOfPacked 136 125 0 126195 2308162 20 packedOct136_125_0 485 483
    (by decide +kernel) (by decide) packedOct136_125Anchor0
    (by rw [packedOct136_125_0_budget]; decide)

def packedOctCertificate136_125_1 : EightPointCertificate 136 125 1 126195 :=
  eightPointCertificateOfPacked 136 125 1 126195 2307833 20 packedOct136_125_1 488 483
    (by decide +kernel) (by decide) packedOct136_125Anchor1
    (by rw [packedOct136_125_1_budget]; decide)

theorem max148_second136_third125_eightPoint_moment_bound (tail : List ℕ) (len : tail.length=6)
    (distinct : (natSubsetSums (148::136::125::tail)).Nodup) :
    126195 ≤ ((148::136::125::tail).map (· ^ 2)).sum := by
  apply eightPointNatMomentLower 136 125 126195 tail len distinct
  intro p hp
  by_cases h : p=0
  · subst p
    exact packedOctCertificate136_125_0
  · have he : p=1 := hp.resolve_left h
    subst p
    exact packedOctCertificate136_125_1

#print axioms max148_second136_third125_eightPoint_moment_bound

end NineSeparatedSubsetSums
