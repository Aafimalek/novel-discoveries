import NineSeparatedSubsetSums.Adaptive136Third124State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive136Third124Proof0 : runCachedNode 511 125795 Adaptive136Third124Node0 = false := by
  decide +kernel

#print axioms adaptive136Third124Proof0

end NineSeparatedSubsetSums
