import NineSeparatedSubsetSums.EightPoint136_121PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint136_121PackedAnchor0Part2 :
    ∀ j : Fin 2, 2307267 ≤ FourPointNumeric.octPackedCharge 136 121 20 packedOct136_121_0
      (2*((j.val : Int)+240)+1) := by decide +kernel

end NineSeparatedSubsetSums
