import NineSeparatedSubsetSums.EightPoint136_121PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct136_121_1_budget :
    FourPointNumeric.packedBudget 20 packedOct136_121_1 390 = 83808906 := by decide +kernel

#print axioms packedOct136_121_1_budget

end NineSeparatedSubsetSums
