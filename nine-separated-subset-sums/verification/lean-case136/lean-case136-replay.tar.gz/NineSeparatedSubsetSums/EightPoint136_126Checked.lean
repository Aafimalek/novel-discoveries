import NineSeparatedSubsetSums.EightPointPackedGeometry
import NineSeparatedSubsetSums.EightPoint136_126PackedBudget0
import NineSeparatedSubsetSums.EightPoint136_126PackedAnchor0Part0
import NineSeparatedSubsetSums.EightPoint136_126PackedAnchor0Part1
import NineSeparatedSubsetSums.EightPoint136_126PackedAnchor0Part2
import NineSeparatedSubsetSums.EightPoint136_126PackedBudget1
import NineSeparatedSubsetSums.EightPoint136_126PackedAnchor1Part0
import NineSeparatedSubsetSums.EightPoint136_126PackedAnchor1Part1
import NineSeparatedSubsetSums.EightPoint136_126PackedAnchor1Part2

namespace NineSeparatedSubsetSums

private theorem packedOct136_126Anchor0 :
  ∀ j : Fin 486, ((j.val : Int)+136+126)%2=0 →
    2336774 ≤ FourPointNumeric.octPackedCharge 136 126 20 packedOct136_126_0 (j.val : Int) := by
  intro j hj
  let k := (j.val-0)/2
  have hk : k < 243 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+0 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint136_126PackedAnchor0Part0 z
    rwa [he,hrep] at ht
  by_cases h1 : k < 240
  · let z : Fin 120 := ⟨k-120, by omega⟩
    have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
    have ht := eightPoint136_126PackedAnchor0Part1 z
    rwa [he,hrep] at ht
  let z : Fin 3 := ⟨k-240, by omega⟩
  have he : (z.val : Int)+240 = k := by dsimp [z] <;> omega
  have ht := eightPoint136_126PackedAnchor0Part2 z
  rwa [he,hrep] at ht

private theorem packedOct136_126Anchor1 :
  ∀ j : Fin 486, ((j.val : Int)+136+126)%2=1 →
    2336073 ≤ FourPointNumeric.octPackedCharge 136 126 20 packedOct136_126_1 (j.val : Int) := by
  intro j hj
  let k := (j.val-1)/2
  have hk : k < 243 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+1 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint136_126PackedAnchor1Part0 z
    rwa [he,hrep] at ht
  by_cases h1 : k < 240
  · let z : Fin 120 := ⟨k-120, by omega⟩
    have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
    have ht := eightPoint136_126PackedAnchor1Part1 z
    rwa [he,hrep] at ht
  let z : Fin 3 := ⟨k-240, by omega⟩
  have he : (z.val : Int)+240 = k := by dsimp [z] <;> omega
  have ht := eightPoint136_126PackedAnchor1Part2 z
  rwa [he,hrep] at ht

def packedOctCertificate136_126_0 : EightPointCertificate 136 126 0 126516 :=
  eightPointCertificateOfPacked 136 126 0 126516 2336774 20 packedOct136_126_0 371 486
    (by decide +kernel) (by decide) packedOct136_126Anchor0
    (by rw [packedOct136_126_0_budget]; decide)

def packedOctCertificate136_126_1 : EightPointCertificate 136 126 1 126516 :=
  eightPointCertificateOfPacked 136 126 1 126516 2336073 20 packedOct136_126_1 260 486
    (by decide +kernel) (by decide) packedOct136_126Anchor1
    (by rw [packedOct136_126_1_budget]; decide)

theorem max148_second136_third126_eightPoint_moment_bound (tail : List ℕ) (len : tail.length=6)
    (distinct : (natSubsetSums (148::136::126::tail)).Nodup) :
    126516 ≤ ((148::136::126::tail).map (· ^ 2)).sum := by
  apply eightPointNatMomentLower 136 126 126516 tail len distinct
  intro p hp
  by_cases h : p=0
  · subst p
    exact packedOctCertificate136_126_0
  · have he : p=1 := hp.resolve_left h
    subst p
    exact packedOctCertificate136_126_1

#print axioms max148_second136_third126_eightPoint_moment_bound

end NineSeparatedSubsetSums
