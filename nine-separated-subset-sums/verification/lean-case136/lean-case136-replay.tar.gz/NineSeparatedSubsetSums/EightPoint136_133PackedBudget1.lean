import NineSeparatedSubsetSums.EightPoint136_133PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct136_133_1_budget :
    FourPointNumeric.packedBudget 20 packedOct136_133_1 466 = 88690580 := by decide +kernel

#print axioms packedOct136_133_1_budget

end NineSeparatedSubsetSums
