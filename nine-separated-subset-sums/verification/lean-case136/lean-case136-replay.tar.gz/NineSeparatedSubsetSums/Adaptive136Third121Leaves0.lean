import NineSeparatedSubsetSums.Adaptive136Third121State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive136Third121Proof0 : runCachedNode 511 124973 Adaptive136Third121Node0 = false := by
  decide +kernel

#print axioms adaptive136Third121Proof0

end NineSeparatedSubsetSums
