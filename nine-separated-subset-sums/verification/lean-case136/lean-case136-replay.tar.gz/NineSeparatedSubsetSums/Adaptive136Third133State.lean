import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive136Third133Node0 : CachedSearchNode :=
  ⟨4, 132, computeCenteredMask [148,136,133], 417, 58089⟩
def Adaptive136Third133Node1 : CachedSearchNode := cachedChild Adaptive136Third133Node0 111
def Adaptive136Third133Node2 : CachedSearchNode := cachedChild Adaptive136Third133Node0 112
def Adaptive136Third133Node3 : CachedSearchNode := cachedChild Adaptive136Third133Node0 113
def Adaptive136Third133Node4 : CachedSearchNode := cachedChild Adaptive136Third133Node0 114
def Adaptive136Third133Node5 : CachedSearchNode := cachedChild Adaptive136Third133Node0 115
def Adaptive136Third133Node6 : CachedSearchNode := cachedChild Adaptive136Third133Node0 116
def Adaptive136Third133Node7 : CachedSearchNode := cachedChild Adaptive136Third133Node0 117
def Adaptive136Third133Node8 : CachedSearchNode := cachedChild Adaptive136Third133Node0 118
def Adaptive136Third133Node9 : CachedSearchNode := cachedChild Adaptive136Third133Node0 119
def Adaptive136Third133Node10 : CachedSearchNode := cachedChild Adaptive136Third133Node0 120
def Adaptive136Third133Node11 : CachedSearchNode := cachedChild Adaptive136Third133Node0 122
def Adaptive136Third133Node12 : CachedSearchNode := cachedChild Adaptive136Third133Node0 123
def Adaptive136Third133Node13 : CachedSearchNode := cachedChild Adaptive136Third133Node0 124
def Adaptive136Third133Node14 : CachedSearchNode := cachedChild Adaptive136Third133Node0 125
def Adaptive136Third133Node15 : CachedSearchNode := cachedChild Adaptive136Third133Node0 126
def Adaptive136Third133Node16 : CachedSearchNode := cachedChild Adaptive136Third133Node0 127
def Adaptive136Third133Node17 : CachedSearchNode := cachedChild Adaptive136Third133Node0 128
def Adaptive136Third133Node18 : CachedSearchNode := cachedChild Adaptive136Third133Node0 129
def Adaptive136Third133Node19 : CachedSearchNode := cachedChild Adaptive136Third133Node0 130
def Adaptive136Third133Node20 : CachedSearchNode := cachedChild Adaptive136Third133Node0 131
def Adaptive136Third133Node21 : CachedSearchNode := cachedChild Adaptive136Third133Node0 132

end NineSeparatedSubsetSums
