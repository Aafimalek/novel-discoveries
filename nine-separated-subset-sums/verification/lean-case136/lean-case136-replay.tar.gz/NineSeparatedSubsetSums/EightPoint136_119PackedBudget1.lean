import NineSeparatedSubsetSums.EightPoint136_119PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct136_119_1_budget :
    FourPointNumeric.packedBudget 20 packedOct136_119_1 272 = 84406704 := by decide +kernel

#print axioms packedOct136_119_1_budget

end NineSeparatedSubsetSums
