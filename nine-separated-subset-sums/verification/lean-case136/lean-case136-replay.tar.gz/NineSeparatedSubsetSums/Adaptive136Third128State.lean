import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive136Third128Node0 : CachedSearchNode :=
  ⟨4, 127, computeCenteredMask [148,136,128], 412, 56784⟩
def Adaptive136Third128Node1 : CachedSearchNode := cachedChild Adaptive136Third128Node0 111
def Adaptive136Third128Node2 : CachedSearchNode := cachedChild Adaptive136Third128Node0 112
def Adaptive136Third128Node3 : CachedSearchNode := cachedChild Adaptive136Third128Node0 113
def Adaptive136Third128Node4 : CachedSearchNode := cachedChild Adaptive136Third128Node0 114
def Adaptive136Third128Node5 : CachedSearchNode := cachedChild Adaptive136Third128Node0 115
def Adaptive136Third128Node6 : CachedSearchNode := cachedChild Adaptive136Third128Node0 117
def Adaptive136Third128Node7 : CachedSearchNode := cachedChild Adaptive136Third128Node0 118
def Adaptive136Third128Node8 : CachedSearchNode := cachedChild Adaptive136Third128Node0 119
def Adaptive136Third128Node9 : CachedSearchNode := cachedChild Adaptive136Third128Node0 120
def Adaptive136Third128Node10 : CachedSearchNode := cachedChild Adaptive136Third128Node0 121
def Adaptive136Third128Node11 : CachedSearchNode := cachedChild Adaptive136Third128Node0 122
def Adaptive136Third128Node12 : CachedSearchNode := cachedChild Adaptive136Third128Node0 123
def Adaptive136Third128Node13 : CachedSearchNode := cachedChild Adaptive136Third128Node0 124
def Adaptive136Third128Node14 : CachedSearchNode := cachedChild Adaptive136Third128Node0 125
def Adaptive136Third128Node15 : CachedSearchNode := cachedChild Adaptive136Third128Node0 126
def Adaptive136Third128Node16 : CachedSearchNode := cachedChild Adaptive136Third128Node0 127

end NineSeparatedSubsetSums
