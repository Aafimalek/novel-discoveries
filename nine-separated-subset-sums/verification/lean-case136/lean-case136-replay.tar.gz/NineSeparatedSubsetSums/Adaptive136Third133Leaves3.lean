import NineSeparatedSubsetSums.Adaptive136Third133State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive136Third133Proof18 : runCachedNode 511 127674 Adaptive136Third133Node18 = false := by
  decide +kernel

#print axioms adaptive136Third133Proof18

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive136Third133Proof17 : runCachedNode 511 127674 Adaptive136Third133Node17 = false := by
  decide +kernel

#print axioms adaptive136Third133Proof17

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive136Third133Proof11 : runCachedNode 511 127674 Adaptive136Third133Node11 = false := by
  decide +kernel

#print axioms adaptive136Third133Proof11

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive136Third133Proof8 : runCachedNode 511 127674 Adaptive136Third133Node8 = false := by
  decide +kernel

#print axioms adaptive136Third133Proof8

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive136Third133Proof6 : runCachedNode 511 127674 Adaptive136Third133Node6 = false := by
  decide +kernel

#print axioms adaptive136Third133Proof6

end NineSeparatedSubsetSums
