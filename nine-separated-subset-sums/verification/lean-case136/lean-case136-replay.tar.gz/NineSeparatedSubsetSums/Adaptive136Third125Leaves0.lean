import NineSeparatedSubsetSums.Adaptive136Third125State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive136Third125Proof0 : runCachedNode 511 126195 Adaptive136Third125Node0 = false := by
  decide +kernel

#print axioms adaptive136Third125Proof0

end NineSeparatedSubsetSums
