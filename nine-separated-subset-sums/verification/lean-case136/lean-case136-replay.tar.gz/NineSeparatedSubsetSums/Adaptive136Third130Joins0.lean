import NineSeparatedSubsetSums.Adaptive136Third130State
import NineSeparatedSubsetSums.Adaptive136Third130Leaves2
import NineSeparatedSubsetSums.Adaptive136Third130Leaves0
import NineSeparatedSubsetSums.Adaptive136Third130Leaves1

namespace NineSeparatedSubsetSums

theorem adaptive136Third130Proof0 : runCachedNode 511 127094 Adaptive136Third130Node0 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 127094 Adaptive136Third130Node0 = [111, 112, 113, 114, 115, 116, 117, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive136Third130Proof1
  · exact adaptive136Third130Proof2
  · exact adaptive136Third130Proof3
  · exact adaptive136Third130Proof4
  · exact adaptive136Third130Proof5
  · exact adaptive136Third130Proof6
  · exact adaptive136Third130Proof7
  · exact adaptive136Third130Proof8
  · exact adaptive136Third130Proof9
  · exact adaptive136Third130Proof10
  · exact adaptive136Third130Proof11
  · exact adaptive136Third130Proof12
  · exact adaptive136Third130Proof13
  · exact adaptive136Third130Proof14
  · exact adaptive136Third130Proof15
  · exact adaptive136Third130Proof16
  · exact adaptive136Third130Proof17
  · exact adaptive136Third130Proof18

#print axioms adaptive136Third130Proof0

end NineSeparatedSubsetSums
