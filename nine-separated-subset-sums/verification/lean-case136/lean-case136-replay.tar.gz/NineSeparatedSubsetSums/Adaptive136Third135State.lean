import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive136Third135Node0 : CachedSearchNode :=
  ⟨4, 134, computeCenteredMask [148,136,135], 419, 58625⟩
def Adaptive136Third135Node1 : CachedSearchNode := cachedChild Adaptive136Third135Node0 111
def Adaptive136Third135Node2 : CachedSearchNode := cachedChild Adaptive136Third135Node0 112
def Adaptive136Third135Node3 : CachedSearchNode := cachedChild Adaptive136Third135Node0 113
def Adaptive136Third135Node4 : CachedSearchNode := cachedChild Adaptive136Third135Node0 114
def Adaptive136Third135Node5 : CachedSearchNode := cachedChild Adaptive136Third135Node0 115
def Adaptive136Third135Node6 : CachedSearchNode := cachedChild Adaptive136Third135Node0 116
def Adaptive136Third135Node7 : CachedSearchNode := cachedChild Adaptive136Third135Node0 117
def Adaptive136Third135Node8 : CachedSearchNode := cachedChild Adaptive136Third135Node0 118
def Adaptive136Third135Node9 : CachedSearchNode := cachedChild Adaptive136Third135Node0 119
def Adaptive136Third135Node10 : CachedSearchNode := cachedChild Adaptive136Third135Node0 120
def Adaptive136Third135Node11 : CachedSearchNode := cachedChild Adaptive136Third135Node0 121
def Adaptive136Third135Node12 : CachedSearchNode := cachedChild Adaptive136Third135Node0 122
def Adaptive136Third135Node13 : CachedSearchNode := cachedChild Adaptive136Third135Node0 124
def Adaptive136Third135Node14 : CachedSearchNode := cachedChild Adaptive136Third135Node0 125
def Adaptive136Third135Node15 : CachedSearchNode := cachedChild Adaptive136Third135Node0 126
def Adaptive136Third135Node16 : CachedSearchNode := cachedChild Adaptive136Third135Node0 127
def Adaptive136Third135Node17 : CachedSearchNode := cachedChild Adaptive136Third135Node0 128
def Adaptive136Third135Node18 : CachedSearchNode := cachedChild Adaptive136Third135Node0 129
def Adaptive136Third135Node19 : CachedSearchNode := cachedChild Adaptive136Third135Node0 130
def Adaptive136Third135Node20 : CachedSearchNode := cachedChild Adaptive136Third135Node0 131
def Adaptive136Third135Node21 : CachedSearchNode := cachedChild Adaptive136Third135Node0 132
def Adaptive136Third135Node22 : CachedSearchNode := cachedChild Adaptive136Third135Node0 133
def Adaptive136Third135Node23 : CachedSearchNode := cachedChild Adaptive136Third135Node0 134
def Adaptive136Third135Node24 : CachedSearchNode := cachedChild Adaptive136Third135Node23 104
def Adaptive136Third135Node25 : CachedSearchNode := cachedChild Adaptive136Third135Node23 105
def Adaptive136Third135Node26 : CachedSearchNode := cachedChild Adaptive136Third135Node23 106
def Adaptive136Third135Node27 : CachedSearchNode := cachedChild Adaptive136Third135Node23 107
def Adaptive136Third135Node28 : CachedSearchNode := cachedChild Adaptive136Third135Node23 108
def Adaptive136Third135Node29 : CachedSearchNode := cachedChild Adaptive136Third135Node23 109
def Adaptive136Third135Node30 : CachedSearchNode := cachedChild Adaptive136Third135Node23 110
def Adaptive136Third135Node31 : CachedSearchNode := cachedChild Adaptive136Third135Node23 111
def Adaptive136Third135Node32 : CachedSearchNode := cachedChild Adaptive136Third135Node23 112
def Adaptive136Third135Node33 : CachedSearchNode := cachedChild Adaptive136Third135Node23 113
def Adaptive136Third135Node34 : CachedSearchNode := cachedChild Adaptive136Third135Node23 114
def Adaptive136Third135Node35 : CachedSearchNode := cachedChild Adaptive136Third135Node23 115
def Adaptive136Third135Node36 : CachedSearchNode := cachedChild Adaptive136Third135Node23 116
def Adaptive136Third135Node37 : CachedSearchNode := cachedChild Adaptive136Third135Node23 117
def Adaptive136Third135Node38 : CachedSearchNode := cachedChild Adaptive136Third135Node23 118
def Adaptive136Third135Node39 : CachedSearchNode := cachedChild Adaptive136Third135Node23 119
def Adaptive136Third135Node40 : CachedSearchNode := cachedChild Adaptive136Third135Node23 120
def Adaptive136Third135Node41 : CachedSearchNode := cachedChild Adaptive136Third135Node23 124
def Adaptive136Third135Node42 : CachedSearchNode := cachedChild Adaptive136Third135Node23 125
def Adaptive136Third135Node43 : CachedSearchNode := cachedChild Adaptive136Third135Node23 126
def Adaptive136Third135Node44 : CachedSearchNode := cachedChild Adaptive136Third135Node23 127
def Adaptive136Third135Node45 : CachedSearchNode := cachedChild Adaptive136Third135Node23 128
def Adaptive136Third135Node46 : CachedSearchNode := cachedChild Adaptive136Third135Node23 129
def Adaptive136Third135Node47 : CachedSearchNode := cachedChild Adaptive136Third135Node23 130
def Adaptive136Third135Node48 : CachedSearchNode := cachedChild Adaptive136Third135Node23 131
def Adaptive136Third135Node49 : CachedSearchNode := cachedChild Adaptive136Third135Node23 132

end NineSeparatedSubsetSums
