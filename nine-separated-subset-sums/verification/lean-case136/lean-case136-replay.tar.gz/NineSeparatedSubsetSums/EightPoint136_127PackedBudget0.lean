import NineSeparatedSubsetSums.EightPoint136_127PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct136_127_0_budget :
    FourPointNumeric.packedBudget 20 packedOct136_127_0 423 = 85259017 := by decide +kernel

#print axioms packedOct136_127_0_budget

end NineSeparatedSubsetSums
