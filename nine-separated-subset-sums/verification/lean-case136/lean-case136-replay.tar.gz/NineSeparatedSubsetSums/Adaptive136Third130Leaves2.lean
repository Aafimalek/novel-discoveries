import NineSeparatedSubsetSums.Adaptive136Third130State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive136Third130Proof15 : runCachedNode 511 127094 Adaptive136Third130Node15 = false := by
  decide +kernel

#print axioms adaptive136Third130Proof15

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive136Third130Proof12 : runCachedNode 511 127094 Adaptive136Third130Node12 = false := by
  decide +kernel

#print axioms adaptive136Third130Proof12

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive136Third130Proof9 : runCachedNode 511 127094 Adaptive136Third130Node9 = false := by
  decide +kernel

#print axioms adaptive136Third130Proof9

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive136Third130Proof8 : runCachedNode 511 127094 Adaptive136Third130Node8 = false := by
  decide +kernel

#print axioms adaptive136Third130Proof8

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive136Third130Proof7 : runCachedNode 511 127094 Adaptive136Third130Node7 = false := by
  decide +kernel

#print axioms adaptive136Third130Proof7

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive136Third130Proof6 : runCachedNode 511 127094 Adaptive136Third130Node6 = false := by
  decide +kernel

#print axioms adaptive136Third130Proof6

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive136Third130Proof4 : runCachedNode 511 127094 Adaptive136Third130Node4 = false := by
  decide +kernel

#print axioms adaptive136Third130Proof4

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive136Third130Proof3 : runCachedNode 511 127094 Adaptive136Third130Node3 = false := by
  decide +kernel

#print axioms adaptive136Third130Proof3

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive136Third130Proof1 : runCachedNode 511 127094 Adaptive136Third130Node1 = false := by
  decide +kernel

#print axioms adaptive136Third130Proof1

end NineSeparatedSubsetSums
