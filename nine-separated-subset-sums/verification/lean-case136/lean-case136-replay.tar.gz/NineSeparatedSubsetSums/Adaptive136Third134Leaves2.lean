import NineSeparatedSubsetSums.Adaptive136Third134State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive136Third134Proof19 : runCachedNode 511 127846 Adaptive136Third134Node19 = false := by
  decide +kernel

#print axioms adaptive136Third134Proof19

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive136Third134Proof44 : runCachedNode 511 127846 Adaptive136Third134Node44 = false := by
  decide +kernel

#print axioms adaptive136Third134Proof44

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive136Third134Proof38 : runCachedNode 511 127846 Adaptive136Third134Node38 = false := by
  decide +kernel

#print axioms adaptive136Third134Proof38

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive136Third134Proof6 : runCachedNode 511 127846 Adaptive136Third134Node6 = false := by
  decide +kernel

#print axioms adaptive136Third134Proof6

end NineSeparatedSubsetSums
