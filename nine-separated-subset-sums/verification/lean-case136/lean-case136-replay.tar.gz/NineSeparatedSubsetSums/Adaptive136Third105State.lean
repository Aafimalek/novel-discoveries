import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive136Third105Node0 : CachedSearchNode :=
  ⟨4, 104, computeCenteredMask [148,136,105], 389, 51425⟩

end NineSeparatedSubsetSums
