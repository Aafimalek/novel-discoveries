import NineSeparatedSubsetSums.Adaptive136Third116State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive136Third116Proof12 : runCachedNode 511 110825 Adaptive136Third116Node12 = false := by
  decide +kernel

#print axioms adaptive136Third116Proof12

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive136Third116Proof11 : runCachedNode 511 110825 Adaptive136Third116Node11 = false := by
  decide +kernel

#print axioms adaptive136Third116Proof11

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive136Third116Proof10 : runCachedNode 511 110825 Adaptive136Third116Node10 = false := by
  decide +kernel

#print axioms adaptive136Third116Proof10

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive136Third116Proof8 : runCachedNode 511 110825 Adaptive136Third116Node8 = false := by
  decide +kernel

#print axioms adaptive136Third116Proof8

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive136Third116Proof7 : runCachedNode 511 110825 Adaptive136Third116Node7 = false := by
  decide +kernel

#print axioms adaptive136Third116Proof7

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive136Third116Proof6 : runCachedNode 511 110825 Adaptive136Third116Node6 = false := by
  decide +kernel

#print axioms adaptive136Third116Proof6

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive136Third116Proof5 : runCachedNode 511 110825 Adaptive136Third116Node5 = false := by
  decide +kernel

#print axioms adaptive136Third116Proof5

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive136Third116Proof2 : runCachedNode 511 110825 Adaptive136Third116Node2 = false := by
  decide +kernel

#print axioms adaptive136Third116Proof2

end NineSeparatedSubsetSums
