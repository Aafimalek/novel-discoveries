import NineSeparatedSubsetSums.FourPoint136PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem fourPoint136PackedAnchor1Part0 :
    ∀ j : Fin 120, 1070692 ≤ FourPointNumeric.packedCharge 136 20 packedWeight136_1
      (2*((j.val : Int)+0)+1) := by decide +kernel

end NineSeparatedSubsetSums
