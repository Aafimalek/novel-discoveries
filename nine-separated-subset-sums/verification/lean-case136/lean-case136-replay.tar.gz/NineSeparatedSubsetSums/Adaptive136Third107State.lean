import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive136Third107Node0 : CachedSearchNode :=
  ⟨4, 106, computeCenteredMask [148,136,107], 391, 51849⟩

end NineSeparatedSubsetSums
