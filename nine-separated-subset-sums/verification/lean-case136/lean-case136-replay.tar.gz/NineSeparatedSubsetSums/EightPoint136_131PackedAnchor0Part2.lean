import NineSeparatedSubsetSums.EightPoint136_131PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint136_131PackedAnchor0Part2 :
    ∀ j : Fin 7, 2418587 ≤ FourPointNumeric.octPackedCharge 136 131 20 packedOct136_131_0
      (2*((j.val : Int)+240)+1) := by decide +kernel

end NineSeparatedSubsetSums
