import NineSeparatedSubsetSums.Adaptive136Third105Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint136Checked

namespace NineSeparatedSubsetSums


theorem adaptive136Third105 : NoDescendingTailAfterThird 136 105 :=
  noDescendingThirdTail_of_cached 136 105 110825 (fun t ht nd => max148_second136_fourPoint_moment_bound (105::t) (by simp [ht]) nd) adaptive136Third105Proof0

#print axioms adaptive136Third105

end NineSeparatedSubsetSums
