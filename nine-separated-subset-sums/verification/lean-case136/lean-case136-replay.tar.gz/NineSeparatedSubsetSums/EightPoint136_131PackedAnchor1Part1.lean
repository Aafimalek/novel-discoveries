import NineSeparatedSubsetSums.EightPoint136_131PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint136_131PackedAnchor1Part1 :
    ∀ j : Fin 120, 2418367 ≤ FourPointNumeric.octPackedCharge 136 131 20 packedOct136_131_1
      (2*((j.val : Int)+120)+0) := by decide +kernel

end NineSeparatedSubsetSums
