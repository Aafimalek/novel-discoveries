import NineSeparatedSubsetSums.FourPoint136PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedWeight136_0_budget :
    FourPointNumeric.packedBudget 20 packedWeight136_0 373 = 80309248 := by decide +kernel

#print axioms packedWeight136_0_budget

end NineSeparatedSubsetSums
