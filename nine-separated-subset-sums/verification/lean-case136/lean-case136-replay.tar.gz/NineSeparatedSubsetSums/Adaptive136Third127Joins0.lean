import NineSeparatedSubsetSums.Adaptive136Third127State
import NineSeparatedSubsetSums.Adaptive136Third127Leaves0
import NineSeparatedSubsetSums.Adaptive136Third127Leaves1

namespace NineSeparatedSubsetSums

theorem adaptive136Third127Proof0 : runCachedNode 511 126691 Adaptive136Third127Node0 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 126691 Adaptive136Third127Node0 = [111, 112, 113, 114, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive136Third127Proof1
  · exact adaptive136Third127Proof2
  · exact adaptive136Third127Proof3
  · exact adaptive136Third127Proof4
  · exact adaptive136Third127Proof5
  · exact adaptive136Third127Proof6
  · exact adaptive136Third127Proof7
  · exact adaptive136Third127Proof8
  · exact adaptive136Third127Proof9
  · exact adaptive136Third127Proof10
  · exact adaptive136Third127Proof11
  · exact adaptive136Third127Proof12
  · exact adaptive136Third127Proof13
  · exact adaptive136Third127Proof14
  · exact adaptive136Third127Proof15

#print axioms adaptive136Third127Proof0

end NineSeparatedSubsetSums
