import NineSeparatedSubsetSums.Adaptive136Third114State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive136Third114Proof0 : runCachedNode 511 110825 Adaptive136Third114Node0 = false := by
  decide +kernel

#print axioms adaptive136Third114Proof0

end NineSeparatedSubsetSums
