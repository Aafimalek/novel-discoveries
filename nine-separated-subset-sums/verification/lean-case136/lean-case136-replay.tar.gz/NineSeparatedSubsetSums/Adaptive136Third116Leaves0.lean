import NineSeparatedSubsetSums.Adaptive136Third116State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive136Third116Proof15 : runCachedNode 511 110825 Adaptive136Third116Node15 = false := by
  decide +kernel

#print axioms adaptive136Third116Proof15

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive136Third116Proof14 : runCachedNode 511 110825 Adaptive136Third116Node14 = false := by
  decide +kernel

#print axioms adaptive136Third116Proof14

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive136Third116Proof13 : runCachedNode 511 110825 Adaptive136Third116Node13 = false := by
  decide +kernel

#print axioms adaptive136Third116Proof13

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive136Third116Proof9 : runCachedNode 511 110825 Adaptive136Third116Node9 = false := by
  decide +kernel

#print axioms adaptive136Third116Proof9

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive136Third116Proof4 : runCachedNode 511 110825 Adaptive136Third116Node4 = false := by
  decide +kernel

#print axioms adaptive136Third116Proof4

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive136Third116Proof3 : runCachedNode 511 110825 Adaptive136Third116Node3 = false := by
  decide +kernel

#print axioms adaptive136Third116Proof3

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive136Third116Proof1 : runCachedNode 511 110825 Adaptive136Third116Node1 = false := by
  decide +kernel

#print axioms adaptive136Third116Proof1

end NineSeparatedSubsetSums
