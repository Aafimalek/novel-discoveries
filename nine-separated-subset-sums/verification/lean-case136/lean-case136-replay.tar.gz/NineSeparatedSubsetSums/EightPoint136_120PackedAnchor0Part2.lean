import NineSeparatedSubsetSums.EightPoint136_120PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint136_120PackedAnchor0Part2 :
    ∀ j : Fin 4, 2336270 ≤ FourPointNumeric.octPackedCharge 136 120 20 packedOct136_120_0
      (2*((j.val : Int)+240)+0) := by decide +kernel

end NineSeparatedSubsetSums
