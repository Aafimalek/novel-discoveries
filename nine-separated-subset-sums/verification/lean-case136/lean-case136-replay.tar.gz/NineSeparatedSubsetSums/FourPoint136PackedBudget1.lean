import NineSeparatedSubsetSums.FourPoint136PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedWeight136_1_budget :
    FourPointNumeric.packedBudget 20 packedWeight136_1 356 = 80306176 := by decide +kernel

#print axioms packedWeight136_1_budget

end NineSeparatedSubsetSums
