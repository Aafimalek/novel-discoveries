import NineSeparatedSubsetSums.Adaptive136Third132State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive136Third132Proof18 : runCachedNode 511 127566 Adaptive136Third132Node18 = false := by
  decide +kernel

#print axioms adaptive136Third132Proof18

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive136Third132Proof17 : runCachedNode 511 127566 Adaptive136Third132Node17 = false := by
  decide +kernel

#print axioms adaptive136Third132Proof17

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive136Third132Proof5 : runCachedNode 511 127566 Adaptive136Third132Node5 = false := by
  decide +kernel

#print axioms adaptive136Third132Proof5

end NineSeparatedSubsetSums
