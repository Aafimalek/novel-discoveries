import NineSeparatedSubsetSums.EightPoint136_117PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint136_117PackedAnchor1Part0 :
    ∀ j : Fin 120, 2284693 ≤ FourPointNumeric.octPackedCharge 136 117 20 packedOct136_117_1
      (2*((j.val : Int)+0)+0) := by decide +kernel

end NineSeparatedSubsetSums
