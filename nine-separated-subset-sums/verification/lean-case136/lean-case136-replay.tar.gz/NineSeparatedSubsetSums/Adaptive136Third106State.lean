import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive136Third106Node0 : CachedSearchNode :=
  ⟨4, 105, computeCenteredMask [148,136,106], 390, 51636⟩

end NineSeparatedSubsetSums
