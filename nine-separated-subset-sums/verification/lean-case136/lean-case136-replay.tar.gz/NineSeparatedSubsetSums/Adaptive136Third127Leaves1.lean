import NineSeparatedSubsetSums.Adaptive136Third127State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive136Third127Proof9 : runCachedNode 511 126691 Adaptive136Third127Node9 = false := by
  decide +kernel

#print axioms adaptive136Third127Proof9

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive136Third127Proof8 : runCachedNode 511 126691 Adaptive136Third127Node8 = false := by
  decide +kernel

#print axioms adaptive136Third127Proof8

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive136Third127Proof7 : runCachedNode 511 126691 Adaptive136Third127Node7 = false := by
  decide +kernel

#print axioms adaptive136Third127Proof7

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive136Third127Proof6 : runCachedNode 511 126691 Adaptive136Third127Node6 = false := by
  decide +kernel

#print axioms adaptive136Third127Proof6

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive136Third127Proof5 : runCachedNode 511 126691 Adaptive136Third127Node5 = false := by
  decide +kernel

#print axioms adaptive136Third127Proof5

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive136Third127Proof4 : runCachedNode 511 126691 Adaptive136Third127Node4 = false := by
  decide +kernel

#print axioms adaptive136Third127Proof4

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive136Third127Proof3 : runCachedNode 511 126691 Adaptive136Third127Node3 = false := by
  decide +kernel

#print axioms adaptive136Third127Proof3

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive136Third127Proof2 : runCachedNode 511 126691 Adaptive136Third127Node2 = false := by
  decide +kernel

#print axioms adaptive136Third127Proof2

end NineSeparatedSubsetSums
