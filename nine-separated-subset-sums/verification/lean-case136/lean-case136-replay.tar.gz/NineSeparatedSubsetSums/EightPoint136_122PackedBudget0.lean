import NineSeparatedSubsetSums.EightPoint136_122PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct136_122_0_budget :
    FourPointNumeric.packedBudget 20 packedOct136_122_0 469 = 81322863 := by decide +kernel

#print axioms packedOct136_122_0_budget

end NineSeparatedSubsetSums
