import NineSeparatedSubsetSums.EightPoint136_118PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct136_118_1_budget :
    FourPointNumeric.packedBudget 20 packedOct136_118_1 260 = 81698268 := by decide +kernel

#print axioms packedOct136_118_1_budget

end NineSeparatedSubsetSums
