import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive136Third110Node0 : CachedSearchNode :=
  ⟨4, 109, computeCenteredMask [148,136,110], 394, 52500⟩

end NineSeparatedSubsetSums
