import NineSeparatedSubsetSums.EightPoint136_125PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint136_125PackedAnchor0Part2 :
    ∀ j : Fin 1, 2308162 ≤ FourPointNumeric.octPackedCharge 136 125 20 packedOct136_125_0
      (2*((j.val : Int)+240)+1) := by decide +kernel

end NineSeparatedSubsetSums
