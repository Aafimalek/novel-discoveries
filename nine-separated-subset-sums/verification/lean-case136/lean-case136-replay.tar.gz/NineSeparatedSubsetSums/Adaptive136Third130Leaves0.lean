import NineSeparatedSubsetSums.Adaptive136Third130State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive136Third130Proof18 : runCachedNode 511 127094 Adaptive136Third130Node18 = false := by
  decide +kernel

#print axioms adaptive136Third130Proof18

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive136Third130Proof17 : runCachedNode 511 127094 Adaptive136Third130Node17 = false := by
  decide +kernel

#print axioms adaptive136Third130Proof17

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive136Third130Proof11 : runCachedNode 511 127094 Adaptive136Third130Node11 = false := by
  decide +kernel

#print axioms adaptive136Third130Proof11

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive136Third130Proof2 : runCachedNode 511 127094 Adaptive136Third130Node2 = false := by
  decide +kernel

#print axioms adaptive136Third130Proof2

end NineSeparatedSubsetSums
