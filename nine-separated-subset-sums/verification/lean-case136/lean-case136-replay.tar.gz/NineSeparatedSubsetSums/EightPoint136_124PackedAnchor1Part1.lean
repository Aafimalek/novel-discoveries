import NineSeparatedSubsetSums.EightPoint136_124PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint136_124PackedAnchor1Part1 :
    ∀ j : Fin 120, 2289698 ≤ FourPointNumeric.octPackedCharge 136 124 20 packedOct136_124_1
      (2*((j.val : Int)+120)+1) := by decide +kernel

end NineSeparatedSubsetSums
