import NineSeparatedSubsetSums.FourPointPackedGeometry
import NineSeparatedSubsetSums.FourPoint136PackedBudget0
import NineSeparatedSubsetSums.FourPoint136PackedAnchor0Part0
import NineSeparatedSubsetSums.FourPoint136PackedAnchor0Part1
import NineSeparatedSubsetSums.FourPoint136PackedBudget1
import NineSeparatedSubsetSums.FourPoint136PackedAnchor1Part0
import NineSeparatedSubsetSums.FourPoint136PackedAnchor1Part1

namespace NineSeparatedSubsetSums

private theorem packed136Anchor0 :
  ∀ j : Fin 477, ((j.val : Int)+136)%2=0 →
    1070720 ≤ FourPointNumeric.packedCharge 136 20 packedWeight136_0 (j.val : Int) := by
  intro j hj
  let k := (j.val-0)/2
  have hk : k < 239 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+0 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := fourPoint136PackedAnchor0Part0 z
    rwa [he,hrep] at ht
  let z : Fin 119 := ⟨k-120, by omega⟩
  have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
  have ht := fourPoint136PackedAnchor0Part1 z
  rwa [he,hrep] at ht

private theorem packed136Anchor1 :
  ∀ j : Fin 477, ((j.val : Int)+136)%2=1 →
    1070692 ≤ FourPointNumeric.packedCharge 136 20 packedWeight136_1 (j.val : Int) := by
  intro j hj
  let k := (j.val-1)/2
  have hk : k < 238 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+1 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := fourPoint136PackedAnchor1Part0 z
    rwa [he,hrep] at ht
  let z : Fin 118 := ⟨k-120, by omega⟩
  have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
  have ht := fourPoint136PackedAnchor1Part1 z
  rwa [he,hrep] at ht

def packedCertificate136_0 : FourPointCertificate 136 0 110825 :=
  fourPointCertificateOfPacked 136 0 110825 1070720 20 packedWeight136_0 373 477
    (by decide +kernel) (by decide) (by decide) packed136Anchor0
    (by rw [packedWeight136_0_budget]; decide)

def packedCertificate136_1 : FourPointCertificate 136 1 110825 :=
  fourPointCertificateOfPacked 136 1 110825 1070692 20 packedWeight136_1 356 477
    (by decide +kernel) (by decide) (by decide) packed136Anchor1
    (by rw [packedWeight136_1_budget]; decide)

theorem max148_second136_fourPoint_moment_bound (tail : List ℕ) (len : tail.length=7)
    (distinct : (natSubsetSums (148::136::tail)).Nodup) :
    110825 ≤ ((148::136::tail).map (· ^ 2)).sum := by
  apply fourPointNatMomentLower 136 110825 tail len distinct
  intro p hp
  by_cases h : p=0
  · subst p
    exact packedCertificate136_0
  · have he : p=1 := hp.resolve_left h
    subst p
    exact packedCertificate136_1

#print axioms max148_second136_fourPoint_moment_bound

end NineSeparatedSubsetSums
