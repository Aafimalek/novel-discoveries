import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive136Third109Node0 : CachedSearchNode :=
  ⟨4, 108, computeCenteredMask [148,136,109], 393, 52281⟩

end NineSeparatedSubsetSums
