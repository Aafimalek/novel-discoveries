import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive136Third112Node0 : CachedSearchNode :=
  ⟨4, 111, computeCenteredMask [148,136,112], 396, 52944⟩

end NineSeparatedSubsetSums
