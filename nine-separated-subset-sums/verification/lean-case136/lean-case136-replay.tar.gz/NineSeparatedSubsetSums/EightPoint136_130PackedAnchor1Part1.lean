import NineSeparatedSubsetSums.EightPoint136_130PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint136_130PackedAnchor1Part1 :
    ∀ j : Fin 120, 2392104 ≤ FourPointNumeric.octPackedCharge 136 130 20 packedOct136_130_1
      (2*((j.val : Int)+120)+1) := by decide +kernel

end NineSeparatedSubsetSums
