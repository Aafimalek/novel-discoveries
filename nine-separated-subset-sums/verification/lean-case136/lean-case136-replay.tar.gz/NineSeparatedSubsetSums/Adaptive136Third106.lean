import NineSeparatedSubsetSums.Adaptive136Third106Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint136Checked

namespace NineSeparatedSubsetSums


theorem adaptive136Third106 : NoDescendingTailAfterThird 136 106 :=
  noDescendingThirdTail_of_cached 136 106 110825 (fun t ht nd => max148_second136_fourPoint_moment_bound (106::t) (by simp [ht]) nd) adaptive136Third106Proof0

#print axioms adaptive136Third106

end NineSeparatedSubsetSums
