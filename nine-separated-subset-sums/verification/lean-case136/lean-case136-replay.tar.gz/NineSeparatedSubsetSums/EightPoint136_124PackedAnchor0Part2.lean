import NineSeparatedSubsetSums.EightPoint136_124PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint136_124PackedAnchor0Part2 :
    ∀ j : Fin 1, 2294298 ≤ FourPointNumeric.octPackedCharge 136 124 20 packedOct136_124_0
      (2*((j.val : Int)+240)+0) := by decide +kernel

end NineSeparatedSubsetSums
