import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive136Third108Node0 : CachedSearchNode :=
  ⟨4, 107, computeCenteredMask [148,136,108], 392, 52064⟩

end NineSeparatedSubsetSums
