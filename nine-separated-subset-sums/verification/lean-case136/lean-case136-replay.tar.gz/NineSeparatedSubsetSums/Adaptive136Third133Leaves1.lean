import NineSeparatedSubsetSums.Adaptive136Third133State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive136Third133Proof19 : runCachedNode 511 127674 Adaptive136Third133Node19 = false := by
  decide +kernel

#print axioms adaptive136Third133Proof19

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive136Third133Proof12 : runCachedNode 511 127674 Adaptive136Third133Node12 = false := by
  decide +kernel

#print axioms adaptive136Third133Proof12

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive136Third133Proof7 : runCachedNode 511 127674 Adaptive136Third133Node7 = false := by
  decide +kernel

#print axioms adaptive136Third133Proof7

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive136Third133Proof3 : runCachedNode 511 127674 Adaptive136Third133Node3 = false := by
  decide +kernel

#print axioms adaptive136Third133Proof3

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive136Third133Proof2 : runCachedNode 511 127674 Adaptive136Third133Node2 = false := by
  decide +kernel

#print axioms adaptive136Third133Proof2

end NineSeparatedSubsetSums
