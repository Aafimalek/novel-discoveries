import NineSeparatedSubsetSums.Adaptive136Third118State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive136Third118Proof0 : runCachedNode 511 124506 Adaptive136Third118Node0 = false := by
  decide +kernel

#print axioms adaptive136Third118Proof0

end NineSeparatedSubsetSums
