import NineSeparatedSubsetSums.EightPoint136_129PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct136_129_0_budget :
    FourPointNumeric.packedBudget 20 packedOct136_129_0 437 = 85945565 := by decide +kernel

#print axioms packedOct136_129_0_budget

end NineSeparatedSubsetSums
