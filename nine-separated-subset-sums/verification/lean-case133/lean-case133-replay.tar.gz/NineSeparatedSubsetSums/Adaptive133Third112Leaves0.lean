import NineSeparatedSubsetSums.Adaptive133Third112State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive133Third112Proof0 : runCachedNode 511 110552 Adaptive133Third112Node0 = false := by
  decide +kernel

#print axioms adaptive133Third112Proof0

end NineSeparatedSubsetSums
