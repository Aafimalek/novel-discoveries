import NineSeparatedSubsetSums.Adaptive133Third120State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive133Third120Proof0 : runCachedNode 511 124318 Adaptive133Third120Node0 = false := by
  decide +kernel

#print axioms adaptive133Third120Proof0

end NineSeparatedSubsetSums
