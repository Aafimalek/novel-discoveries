import NineSeparatedSubsetSums.EightPoint133_121PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint133_121PackedAnchor0Part1 :
    ∀ j : Fin 120, 2311788 ≤ FourPointNumeric.octPackedCharge 133 121 20 packedOct133_121_0
      (2*((j.val : Int)+120)+0) := by decide +kernel

end NineSeparatedSubsetSums
