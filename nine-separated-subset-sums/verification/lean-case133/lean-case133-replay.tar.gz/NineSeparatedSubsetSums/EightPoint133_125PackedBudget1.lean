import NineSeparatedSubsetSums.EightPoint133_125PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct133_125_1_budget :
    FourPointNumeric.packedBudget 20 packedOct133_125_1 406 = 83064428 := by decide +kernel

#print axioms packedOct133_125_1_budget

end NineSeparatedSubsetSums
