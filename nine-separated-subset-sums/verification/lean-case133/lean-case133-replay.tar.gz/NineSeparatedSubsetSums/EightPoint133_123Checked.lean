import NineSeparatedSubsetSums.EightPointPackedGeometry
import NineSeparatedSubsetSums.EightPoint133_123PackedBudget0
import NineSeparatedSubsetSums.EightPoint133_123PackedAnchor0Part0
import NineSeparatedSubsetSums.EightPoint133_123PackedAnchor0Part1
import NineSeparatedSubsetSums.EightPoint133_123PackedBudget1
import NineSeparatedSubsetSums.EightPoint133_123PackedAnchor1Part0
import NineSeparatedSubsetSums.EightPoint133_123PackedAnchor1Part1

namespace NineSeparatedSubsetSums

private theorem packedOct133_123Anchor0 :
  ∀ j : Fin 480, ((j.val : Int)+133+123)%2=0 →
    2273467 ≤ FourPointNumeric.octPackedCharge 133 123 20 packedOct133_123_0 (j.val : Int) := by
  intro j hj
  let k := (j.val-0)/2
  have hk : k < 240 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+0 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint133_123PackedAnchor0Part0 z
    rwa [he,hrep] at ht
  let z : Fin 120 := ⟨k-120, by omega⟩
  have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
  have ht := eightPoint133_123PackedAnchor0Part1 z
  rwa [he,hrep] at ht

private theorem packedOct133_123Anchor1 :
  ∀ j : Fin 480, ((j.val : Int)+133+123)%2=1 →
    2274070 ≤ FourPointNumeric.octPackedCharge 133 123 20 packedOct133_123_1 (j.val : Int) := by
  intro j hj
  let k := (j.val-1)/2
  have hk : k < 240 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+1 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint133_123PackedAnchor1Part0 z
    rwa [he,hrep] at ht
  let z : Fin 120 := ⟨k-120, by omega⟩
  have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
  have ht := eightPoint133_123PackedAnchor1Part1 z
  rwa [he,hrep] at ht

def packedOctCertificate133_123_0 : EightPointCertificate 133 123 0 124938 :=
  eightPointCertificateOfPacked 133 123 0 124938 2273467 20 packedOct133_123_0 387 480
    (by decide +kernel) (by decide) packedOct133_123Anchor0
    (by rw [packedOct133_123_0_budget]; decide)

def packedOctCertificate133_123_1 : EightPointCertificate 133 123 1 124938 :=
  eightPointCertificateOfPacked 133 123 1 124938 2274070 20 packedOct133_123_1 386 480
    (by decide +kernel) (by decide) packedOct133_123Anchor1
    (by rw [packedOct133_123_1_budget]; decide)

theorem max148_second133_third123_eightPoint_moment_bound (tail : List ℕ) (len : tail.length=6)
    (distinct : (natSubsetSums (148::133::123::tail)).Nodup) :
    124938 ≤ ((148::133::123::tail).map (· ^ 2)).sum := by
  apply eightPointNatMomentLower 133 123 124938 tail len distinct
  intro p hp
  by_cases h : p=0
  · subst p
    exact packedOctCertificate133_123_0
  · have he : p=1 := hp.resolve_left h
    subst p
    exact packedOctCertificate133_123_1

#print axioms max148_second133_third123_eightPoint_moment_bound

end NineSeparatedSubsetSums
