import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive133Third112Node0 : CachedSearchNode :=
  ⟨4, 111, computeCenteredMask [148,133,112], 393, 52137⟩

end NineSeparatedSubsetSums
