import NineSeparatedSubsetSums.Adaptive133Third127State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive133Third127Proof15 : runCachedNode 511 126028 Adaptive133Third127Node15 = false := by
  decide +kernel

#print axioms adaptive133Third127Proof15

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive133Third127Proof14 : runCachedNode 511 126028 Adaptive133Third127Node14 = false := by
  decide +kernel

#print axioms adaptive133Third127Proof14

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive133Third127Proof13 : runCachedNode 511 126028 Adaptive133Third127Node13 = false := by
  decide +kernel

#print axioms adaptive133Third127Proof13

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive133Third127Proof12 : runCachedNode 511 126028 Adaptive133Third127Node12 = false := by
  decide +kernel

#print axioms adaptive133Third127Proof12

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive133Third127Proof11 : runCachedNode 511 126028 Adaptive133Third127Node11 = false := by
  decide +kernel

#print axioms adaptive133Third127Proof11

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive133Third127Proof10 : runCachedNode 511 126028 Adaptive133Third127Node10 = false := by
  decide +kernel

#print axioms adaptive133Third127Proof10

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive133Third127Proof9 : runCachedNode 511 126028 Adaptive133Third127Node9 = false := by
  decide +kernel

#print axioms adaptive133Third127Proof9

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive133Third127Proof7 : runCachedNode 511 126028 Adaptive133Third127Node7 = false := by
  decide +kernel

#print axioms adaptive133Third127Proof7

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive133Third127Proof8 : runCachedNode 511 126028 Adaptive133Third127Node8 = false := by
  decide +kernel

#print axioms adaptive133Third127Proof8

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive133Third127Proof4 : runCachedNode 511 126028 Adaptive133Third127Node4 = false := by
  decide +kernel

#print axioms adaptive133Third127Proof4

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive133Third127Proof3 : runCachedNode 511 126028 Adaptive133Third127Node3 = false := by
  decide +kernel

#print axioms adaptive133Third127Proof3

end NineSeparatedSubsetSums
