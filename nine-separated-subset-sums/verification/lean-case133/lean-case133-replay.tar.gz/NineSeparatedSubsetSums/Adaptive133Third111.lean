import NineSeparatedSubsetSums.Adaptive133Third111Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint133Checked

namespace NineSeparatedSubsetSums


theorem adaptive133Third111 : NoDescendingTailAfterThird 133 111 :=
  noDescendingThirdTail_of_cached 133 111 110552 (fun t ht nd => max148_second133_fourPoint_moment_bound (111::t) (by simp [ht]) nd) adaptive133Third111Proof0

#print axioms adaptive133Third111

end NineSeparatedSubsetSums
