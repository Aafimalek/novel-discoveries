import NineSeparatedSubsetSums.FourPoint133PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedWeight133_1_budget :
    FourPointNumeric.packedBudget 20 packedWeight133_1 412 = 77415040 := by decide +kernel

#print axioms packedWeight133_1_budget

end NineSeparatedSubsetSums
