import NineSeparatedSubsetSums.EightPoint133_131PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint133_131PackedAnchor1Part2 :
    ∀ j : Fin 5, 2377955 ≤ FourPointNumeric.octPackedCharge 133 131 20 packedOct133_131_1
      (2*((j.val : Int)+240)+1) := by decide +kernel

end NineSeparatedSubsetSums
