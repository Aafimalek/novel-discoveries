import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive133Third123Node0 : CachedSearchNode :=
  ⟨4, 122, computeCenteredMask [148,133,123], 404, 54722⟩

end NineSeparatedSubsetSums
