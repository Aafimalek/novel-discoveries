import NineSeparatedSubsetSums.Adaptive133Third130State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive133Third130Proof16 : runCachedNode 511 126407 Adaptive133Third130Node16 = false := by
  decide +kernel

#print axioms adaptive133Third130Proof16

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive133Third130Proof18 : runCachedNode 511 126407 Adaptive133Third130Node18 = false := by
  decide +kernel

#print axioms adaptive133Third130Proof18

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive133Third130Proof15 : runCachedNode 511 126407 Adaptive133Third130Node15 = false := by
  decide +kernel

#print axioms adaptive133Third130Proof15

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive133Third130Proof6 : runCachedNode 511 126407 Adaptive133Third130Node6 = false := by
  decide +kernel

#print axioms adaptive133Third130Proof6

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive133Third130Proof4 : runCachedNode 511 126407 Adaptive133Third130Node4 = false := by
  decide +kernel

#print axioms adaptive133Third130Proof4

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive133Third130Proof1 : runCachedNode 511 126407 Adaptive133Third130Node1 = false := by
  decide +kernel

#print axioms adaptive133Third130Proof1

end NineSeparatedSubsetSums
