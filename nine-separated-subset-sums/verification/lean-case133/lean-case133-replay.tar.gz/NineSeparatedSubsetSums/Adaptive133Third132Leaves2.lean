import NineSeparatedSubsetSums.Adaptive133Third132State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive133Third132Proof17 : runCachedNode 511 126862 Adaptive133Third132Node17 = false := by
  decide +kernel

#print axioms adaptive133Third132Proof17

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive133Third132Proof16 : runCachedNode 511 126862 Adaptive133Third132Node16 = false := by
  decide +kernel

#print axioms adaptive133Third132Proof16

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive133Third132Proof15 : runCachedNode 511 126862 Adaptive133Third132Node15 = false := by
  decide +kernel

#print axioms adaptive133Third132Proof15

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive133Third132Proof14 : runCachedNode 511 126862 Adaptive133Third132Node14 = false := by
  decide +kernel

#print axioms adaptive133Third132Proof14

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive133Third132Proof8 : runCachedNode 511 126862 Adaptive133Third132Node8 = false := by
  decide +kernel

#print axioms adaptive133Third132Proof8

end NineSeparatedSubsetSums
