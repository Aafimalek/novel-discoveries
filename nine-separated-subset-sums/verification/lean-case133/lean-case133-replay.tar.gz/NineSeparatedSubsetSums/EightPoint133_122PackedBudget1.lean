import NineSeparatedSubsetSums.EightPoint133_122PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct133_122_1_budget :
    FourPointNumeric.packedBudget 20 packedOct133_122_1 468 = 79591782 := by decide +kernel

#print axioms packedOct133_122_1_budget

end NineSeparatedSubsetSums
