import NineSeparatedSubsetSums.EightPoint133_131PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct133_131_1_budget :
    FourPointNumeric.packedBudget 20 packedOct133_131_1 368 = 87347114 := by decide +kernel

#print axioms packedOct133_131_1_budget

end NineSeparatedSubsetSums
