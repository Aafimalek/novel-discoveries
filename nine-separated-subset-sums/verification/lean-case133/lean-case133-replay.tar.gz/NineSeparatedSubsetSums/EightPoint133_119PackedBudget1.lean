import NineSeparatedSubsetSums.EightPoint133_119PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct133_119_1_budget :
    FourPointNumeric.packedBudget 20 packedOct133_119_1 376 = 81977196 := by decide +kernel

#print axioms packedOct133_119_1_budget

end NineSeparatedSubsetSums
