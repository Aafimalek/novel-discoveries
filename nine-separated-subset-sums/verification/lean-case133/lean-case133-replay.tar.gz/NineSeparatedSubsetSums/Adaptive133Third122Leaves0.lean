import NineSeparatedSubsetSums.Adaptive133Third122State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive133Third122Proof0 : runCachedNode 511 124610 Adaptive133Third122Node0 = false := by
  decide +kernel

#print axioms adaptive133Third122Proof0

end NineSeparatedSubsetSums
