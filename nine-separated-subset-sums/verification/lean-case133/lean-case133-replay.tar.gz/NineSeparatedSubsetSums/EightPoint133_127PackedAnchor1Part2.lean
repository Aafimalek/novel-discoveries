import NineSeparatedSubsetSums.EightPoint133_127PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint133_127PackedAnchor1Part2 :
    ∀ j : Fin 2, 2327085 ≤ FourPointNumeric.octPackedCharge 133 127 20 packedOct133_127_1
      (2*((j.val : Int)+240)+1) := by decide +kernel

end NineSeparatedSubsetSums
