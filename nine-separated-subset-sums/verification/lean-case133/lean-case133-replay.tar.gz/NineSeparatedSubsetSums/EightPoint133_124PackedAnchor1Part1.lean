import NineSeparatedSubsetSums.EightPoint133_124PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint133_124PackedAnchor1Part1 :
    ∀ j : Fin 120, 2282121 ≤ FourPointNumeric.octPackedCharge 133 124 20 packedOct133_124_1
      (2*((j.val : Int)+120)+0) := by decide +kernel

end NineSeparatedSubsetSums
