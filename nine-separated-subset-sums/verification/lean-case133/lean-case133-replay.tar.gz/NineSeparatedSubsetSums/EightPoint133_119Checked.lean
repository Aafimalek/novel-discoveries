import NineSeparatedSubsetSums.EightPointPackedGeometry
import NineSeparatedSubsetSums.EightPoint133_119PackedBudget0
import NineSeparatedSubsetSums.EightPoint133_119PackedAnchor0Part0
import NineSeparatedSubsetSums.EightPoint133_119PackedAnchor0Part1
import NineSeparatedSubsetSums.EightPoint133_119PackedAnchor0Part2
import NineSeparatedSubsetSums.EightPoint133_119PackedBudget1
import NineSeparatedSubsetSums.EightPoint133_119PackedAnchor1Part0
import NineSeparatedSubsetSums.EightPoint133_119PackedAnchor1Part1

namespace NineSeparatedSubsetSums

private theorem packedOct133_119Anchor0 :
  ∀ j : Fin 481, ((j.val : Int)+133+119)%2=0 →
    2275100 ≤ FourPointNumeric.octPackedCharge 133 119 20 packedOct133_119_0 (j.val : Int) := by
  intro j hj
  let k := (j.val-0)/2
  have hk : k < 241 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+0 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint133_119PackedAnchor0Part0 z
    rwa [he,hrep] at ht
  by_cases h1 : k < 240
  · let z : Fin 120 := ⟨k-120, by omega⟩
    have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
    have ht := eightPoint133_119PackedAnchor0Part1 z
    rwa [he,hrep] at ht
  let z : Fin 1 := ⟨k-240, by omega⟩
  have he : (z.val : Int)+240 = k := by dsimp [z] <;> omega
  have ht := eightPoint133_119PackedAnchor0Part2 z
  rwa [he,hrep] at ht

private theorem packedOct133_119Anchor1 :
  ∀ j : Fin 481, ((j.val : Int)+133+119)%2=1 →
    2274616 ≤ FourPointNumeric.octPackedCharge 133 119 20 packedOct133_119_1 (j.val : Int) := by
  intro j hj
  let k := (j.val-1)/2
  have hk : k < 240 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+1 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint133_119PackedAnchor1Part0 z
    rwa [he,hrep] at ht
  let z : Fin 120 := ⟨k-120, by omega⟩
  have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
  have ht := eightPoint133_119PackedAnchor1Part1 z
  rwa [he,hrep] at ht

def packedOctCertificate133_119_0 : EightPointCertificate 133 119 0 124216 :=
  eightPointCertificateOfPacked 133 119 0 124216 2275100 20 packedOct133_119_0 377 481
    (by decide +kernel) (by decide) packedOct133_119Anchor0
    (by rw [packedOct133_119_0_budget]; decide)

def packedOctCertificate133_119_1 : EightPointCertificate 133 119 1 124216 :=
  eightPointCertificateOfPacked 133 119 1 124216 2274616 20 packedOct133_119_1 376 481
    (by decide +kernel) (by decide) packedOct133_119Anchor1
    (by rw [packedOct133_119_1_budget]; decide)

theorem max148_second133_third119_eightPoint_moment_bound (tail : List ℕ) (len : tail.length=6)
    (distinct : (natSubsetSums (148::133::119::tail)).Nodup) :
    124216 ≤ ((148::133::119::tail).map (· ^ 2)).sum := by
  apply eightPointNatMomentLower 133 119 124216 tail len distinct
  intro p hp
  by_cases h : p=0
  · subst p
    exact packedOctCertificate133_119_0
  · have he : p=1 := hp.resolve_left h
    subst p
    exact packedOctCertificate133_119_1

#print axioms max148_second133_third119_eightPoint_moment_bound

end NineSeparatedSubsetSums
