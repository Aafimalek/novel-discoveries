import NineSeparatedSubsetSums.EightPoint133_123PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct133_123_1_budget :
    FourPointNumeric.packedBudget 20 packedOct133_123_1 386 = 81572490 := by decide +kernel

#print axioms packedOct133_123_1_budget

end NineSeparatedSubsetSums
