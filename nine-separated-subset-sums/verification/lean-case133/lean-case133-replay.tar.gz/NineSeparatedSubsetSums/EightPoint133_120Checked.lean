import NineSeparatedSubsetSums.EightPointPackedGeometry
import NineSeparatedSubsetSums.EightPoint133_120PackedBudget0
import NineSeparatedSubsetSums.EightPoint133_120PackedAnchor0Part0
import NineSeparatedSubsetSums.EightPoint133_120PackedAnchor0Part1
import NineSeparatedSubsetSums.EightPoint133_120PackedAnchor0Part2
import NineSeparatedSubsetSums.EightPoint133_120PackedBudget1
import NineSeparatedSubsetSums.EightPoint133_120PackedAnchor1Part0
import NineSeparatedSubsetSums.EightPoint133_120PackedAnchor1Part1
import NineSeparatedSubsetSums.EightPoint133_120PackedAnchor1Part2

namespace NineSeparatedSubsetSums

private theorem packedOct133_120Anchor0 :
  ∀ j : Fin 482, ((j.val : Int)+133+120)%2=0 →
    2286047 ≤ FourPointNumeric.octPackedCharge 133 120 20 packedOct133_120_0 (j.val : Int) := by
  intro j hj
  let k := (j.val-1)/2
  have hk : k < 241 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+1 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint133_120PackedAnchor0Part0 z
    rwa [he,hrep] at ht
  by_cases h1 : k < 240
  · let z : Fin 120 := ⟨k-120, by omega⟩
    have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
    have ht := eightPoint133_120PackedAnchor0Part1 z
    rwa [he,hrep] at ht
  let z : Fin 1 := ⟨k-240, by omega⟩
  have he : (z.val : Int)+240 = k := by dsimp [z] <;> omega
  have ht := eightPoint133_120PackedAnchor0Part2 z
  rwa [he,hrep] at ht

private theorem packedOct133_120Anchor1 :
  ∀ j : Fin 482, ((j.val : Int)+133+120)%2=1 →
    2286280 ≤ FourPointNumeric.octPackedCharge 133 120 20 packedOct133_120_1 (j.val : Int) := by
  intro j hj
  let k := (j.val-0)/2
  have hk : k < 241 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+0 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint133_120PackedAnchor1Part0 z
    rwa [he,hrep] at ht
  by_cases h1 : k < 240
  · let z : Fin 120 := ⟨k-120, by omega⟩
    have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
    have ht := eightPoint133_120PackedAnchor1Part1 z
    rwa [he,hrep] at ht
  let z : Fin 1 := ⟨k-240, by omega⟩
  have he : (z.val : Int)+240 = k := by dsimp [z] <;> omega
  have ht := eightPoint133_120PackedAnchor1Part2 z
  rwa [he,hrep] at ht

def packedOctCertificate133_120_0 : EightPointCertificate 133 120 0 124318 :=
  eightPointCertificateOfPacked 133 120 0 124318 2286047 20 packedOct133_120_0 377 482
    (by decide +kernel) (by decide) packedOct133_120Anchor0
    (by rw [packedOct133_120_0_budget]; decide)

def packedOctCertificate133_120_1 : EightPointCertificate 133 120 1 124318 :=
  eightPointCertificateOfPacked 133 120 1 124318 2286280 20 packedOct133_120_1 378 482
    (by decide +kernel) (by decide) packedOct133_120Anchor1
    (by rw [packedOct133_120_1_budget]; decide)

theorem max148_second133_third120_eightPoint_moment_bound (tail : List ℕ) (len : tail.length=6)
    (distinct : (natSubsetSums (148::133::120::tail)).Nodup) :
    124318 ≤ ((148::133::120::tail).map (· ^ 2)).sum := by
  apply eightPointNatMomentLower 133 120 124318 tail len distinct
  intro p hp
  by_cases h : p=0
  · subst p
    exact packedOctCertificate133_120_0
  · have he : p=1 := hp.resolve_left h
    subst p
    exact packedOctCertificate133_120_1

#print axioms max148_second133_third120_eightPoint_moment_bound

end NineSeparatedSubsetSums
