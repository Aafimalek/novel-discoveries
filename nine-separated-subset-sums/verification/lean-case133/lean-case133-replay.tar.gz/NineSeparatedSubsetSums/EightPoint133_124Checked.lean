import NineSeparatedSubsetSums.EightPointPackedGeometry
import NineSeparatedSubsetSums.EightPoint133_124PackedBudget0
import NineSeparatedSubsetSums.EightPoint133_124PackedAnchor0Part0
import NineSeparatedSubsetSums.EightPoint133_124PackedAnchor0Part1
import NineSeparatedSubsetSums.EightPoint133_124PackedBudget1
import NineSeparatedSubsetSums.EightPoint133_124PackedAnchor1Part0
import NineSeparatedSubsetSums.EightPoint133_124PackedAnchor1Part1

namespace NineSeparatedSubsetSums

private theorem packedOct133_124Anchor0 :
  ∀ j : Fin 480, ((j.val : Int)+133+124)%2=0 →
    2282200 ≤ FourPointNumeric.octPackedCharge 133 124 20 packedOct133_124_0 (j.val : Int) := by
  intro j hj
  let k := (j.val-1)/2
  have hk : k < 240 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+1 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint133_124PackedAnchor0Part0 z
    rwa [he,hrep] at ht
  let z : Fin 120 := ⟨k-120, by omega⟩
  have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
  have ht := eightPoint133_124PackedAnchor0Part1 z
  rwa [he,hrep] at ht

private theorem packedOct133_124Anchor1 :
  ∀ j : Fin 480, ((j.val : Int)+133+124)%2=1 →
    2282121 ≤ FourPointNumeric.octPackedCharge 133 124 20 packedOct133_124_1 (j.val : Int) := by
  intro j hj
  let k := (j.val-0)/2
  have hk : k < 240 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+0 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint133_124PackedAnchor1Part0 z
    rwa [he,hrep] at ht
  let z : Fin 120 := ⟨k-120, by omega⟩
  have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
  have ht := eightPoint133_124PackedAnchor1Part1 z
  rwa [he,hrep] at ht

def packedOctCertificate133_124_0 : EightPointCertificate 133 124 0 125230 :=
  eightPointCertificateOfPacked 133 124 0 125230 2282200 20 packedOct133_124_0 403 480
    (by decide +kernel) (by decide) packedOct133_124Anchor0
    (by rw [packedOct133_124_0_budget]; decide)

def packedOctCertificate133_124_1 : EightPointCertificate 133 124 1 125230 :=
  eightPointCertificateOfPacked 133 124 1 125230 2282121 20 packedOct133_124_1 464 480
    (by decide +kernel) (by decide) packedOct133_124Anchor1
    (by rw [packedOct133_124_1_budget]; decide)

theorem max148_second133_third124_eightPoint_moment_bound (tail : List ℕ) (len : tail.length=6)
    (distinct : (natSubsetSums (148::133::124::tail)).Nodup) :
    125230 ≤ ((148::133::124::tail).map (· ^ 2)).sum := by
  apply eightPointNatMomentLower 133 124 125230 tail len distinct
  intro p hp
  by_cases h : p=0
  · subst p
    exact packedOctCertificate133_124_0
  · have he : p=1 := hp.resolve_left h
    subst p
    exact packedOctCertificate133_124_1

#print axioms max148_second133_third124_eightPoint_moment_bound

end NineSeparatedSubsetSums
