import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive133Third107Node0 : CachedSearchNode :=
  ⟨4, 106, computeCenteredMask [148,133,107], 388, 51042⟩

end NineSeparatedSubsetSums
