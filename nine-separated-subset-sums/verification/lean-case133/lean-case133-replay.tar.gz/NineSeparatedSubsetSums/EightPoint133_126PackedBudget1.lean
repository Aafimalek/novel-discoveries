import NineSeparatedSubsetSums.EightPoint133_126PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct133_126_1_budget :
    FourPointNumeric.packedBudget 20 packedOct133_126_1 446 = 84611992 := by decide +kernel

#print axioms packedOct133_126_1_budget

end NineSeparatedSubsetSums
