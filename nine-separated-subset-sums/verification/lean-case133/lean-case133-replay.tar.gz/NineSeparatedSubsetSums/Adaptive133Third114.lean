import NineSeparatedSubsetSums.Adaptive133Third114Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint133Checked

namespace NineSeparatedSubsetSums


theorem adaptive133Third114 : NoDescendingTailAfterThird 133 114 :=
  noDescendingThirdTail_of_cached 133 114 110552 (fun t ht nd => max148_second133_fourPoint_moment_bound (114::t) (by simp [ht]) nd) adaptive133Third114Proof0

#print axioms adaptive133Third114

end NineSeparatedSubsetSums
