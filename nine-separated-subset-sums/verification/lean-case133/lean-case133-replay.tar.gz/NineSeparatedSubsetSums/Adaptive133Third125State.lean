import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive133Third125Node0 : CachedSearchNode :=
  ⟨4, 124, computeCenteredMask [148,133,125], 406, 55218⟩

end NineSeparatedSubsetSums
