import NineSeparatedSubsetSums.Adaptive133Third104Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint133Checked

namespace NineSeparatedSubsetSums


theorem adaptive133Third104 : NoDescendingTailAfterThird 133 104 :=
  noDescendingThirdTail_of_cached 133 104 110552 (fun t ht nd => max148_second133_fourPoint_moment_bound (104::t) (by simp [ht]) nd) adaptive133Third104Proof0

#print axioms adaptive133Third104

end NineSeparatedSubsetSums
