import NineSeparatedSubsetSums.EightPoint133_132PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint133_132PackedAnchor1Part1 :
    ∀ j : Fin 120, 2388618 ≤ FourPointNumeric.octPackedCharge 133 132 20 packedOct133_132_1
      (2*((j.val : Int)+120)+0) := by decide +kernel

end NineSeparatedSubsetSums
