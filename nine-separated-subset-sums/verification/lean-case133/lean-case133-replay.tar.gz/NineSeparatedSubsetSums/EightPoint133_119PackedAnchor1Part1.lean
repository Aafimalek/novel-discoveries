import NineSeparatedSubsetSums.EightPoint133_119PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint133_119PackedAnchor1Part1 :
    ∀ j : Fin 120, 2274616 ≤ FourPointNumeric.octPackedCharge 133 119 20 packedOct133_119_1
      (2*((j.val : Int)+120)+1) := by decide +kernel

end NineSeparatedSubsetSums
