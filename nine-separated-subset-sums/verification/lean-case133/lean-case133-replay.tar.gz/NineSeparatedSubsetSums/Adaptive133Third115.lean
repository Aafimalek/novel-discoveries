import NineSeparatedSubsetSums.Adaptive133Third115Joins0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint133Checked

namespace NineSeparatedSubsetSums


theorem adaptive133Third115 : NoDescendingTailAfterThird 133 115 :=
  noDescendingThirdTail_of_cached 133 115 110552 (fun t ht nd => max148_second133_fourPoint_moment_bound (115::t) (by simp [ht]) nd) adaptive133Third115Proof0

#print axioms adaptive133Third115

end NineSeparatedSubsetSums
