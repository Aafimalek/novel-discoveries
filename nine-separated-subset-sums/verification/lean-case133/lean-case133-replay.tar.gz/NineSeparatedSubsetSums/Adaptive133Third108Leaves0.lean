import NineSeparatedSubsetSums.Adaptive133Third108State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive133Third108Proof0 : runCachedNode 511 110552 Adaptive133Third108Node0 = false := by
  decide +kernel

#print axioms adaptive133Third108Proof0

end NineSeparatedSubsetSums
