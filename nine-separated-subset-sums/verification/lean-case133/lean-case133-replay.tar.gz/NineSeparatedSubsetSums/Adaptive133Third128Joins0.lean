import NineSeparatedSubsetSums.Adaptive133Third128State
import NineSeparatedSubsetSums.Adaptive133Third128Leaves1
import NineSeparatedSubsetSums.Adaptive133Third128Leaves0

namespace NineSeparatedSubsetSums

theorem adaptive133Third128Proof0 : runCachedNode 511 126129 Adaptive133Third128Node0 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 126129 Adaptive133Third128Node0 = [111, 112, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive133Third128Proof1
  · exact adaptive133Third128Proof2
  · exact adaptive133Third128Proof3
  · exact adaptive133Third128Proof4
  · exact adaptive133Third128Proof5
  · exact adaptive133Third128Proof6
  · exact adaptive133Third128Proof7
  · exact adaptive133Third128Proof8
  · exact adaptive133Third128Proof9
  · exact adaptive133Third128Proof10
  · exact adaptive133Third128Proof11
  · exact adaptive133Third128Proof12
  · exact adaptive133Third128Proof13
  · exact adaptive133Third128Proof14
  · exact adaptive133Third128Proof15
  · exact adaptive133Third128Proof16

#print axioms adaptive133Third128Proof0

end NineSeparatedSubsetSums
