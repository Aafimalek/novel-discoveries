import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive133Third104Node0 : CachedSearchNode :=
  ⟨4, 103, computeCenteredMask [148,133,104], 385, 50409⟩

end NineSeparatedSubsetSums
