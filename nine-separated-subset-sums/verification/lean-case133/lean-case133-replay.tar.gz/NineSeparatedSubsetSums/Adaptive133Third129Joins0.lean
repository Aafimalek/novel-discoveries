import NineSeparatedSubsetSums.Adaptive133Third129State
import NineSeparatedSubsetSums.Adaptive133Third129Leaves0
import NineSeparatedSubsetSums.Adaptive133Third129Leaves1

namespace NineSeparatedSubsetSums

theorem adaptive133Third129Proof0 : runCachedNode 511 126235 Adaptive133Third129Node0 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 126235 Adaptive133Third129Node0 = [111, 112, 113, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive133Third129Proof1
  · exact adaptive133Third129Proof2
  · exact adaptive133Third129Proof3
  · exact adaptive133Third129Proof4
  · exact adaptive133Third129Proof5
  · exact adaptive133Third129Proof6
  · exact adaptive133Third129Proof7
  · exact adaptive133Third129Proof8
  · exact adaptive133Third129Proof9
  · exact adaptive133Third129Proof10
  · exact adaptive133Third129Proof11
  · exact adaptive133Third129Proof12
  · exact adaptive133Third129Proof13
  · exact adaptive133Third129Proof14
  · exact adaptive133Third129Proof15
  · exact adaptive133Third129Proof16
  · exact adaptive133Third129Proof17

#print axioms adaptive133Third129Proof0

end NineSeparatedSubsetSums
