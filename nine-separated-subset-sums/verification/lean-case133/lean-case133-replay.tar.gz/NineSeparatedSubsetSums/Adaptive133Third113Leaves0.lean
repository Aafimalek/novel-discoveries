import NineSeparatedSubsetSums.Adaptive133Third113State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive133Third113Proof0 : runCachedNode 511 110552 Adaptive133Third113Node0 = false := by
  decide +kernel

#print axioms adaptive133Third113Proof0

end NineSeparatedSubsetSums
