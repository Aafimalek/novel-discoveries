import NineSeparatedSubsetSums.EightPoint133_128PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct133_128_1_budget :
    FourPointNumeric.packedBudget 20 packedOct133_128_1 456 = 84100038 := by decide +kernel

#print axioms packedOct133_128_1_budget

end NineSeparatedSubsetSums
