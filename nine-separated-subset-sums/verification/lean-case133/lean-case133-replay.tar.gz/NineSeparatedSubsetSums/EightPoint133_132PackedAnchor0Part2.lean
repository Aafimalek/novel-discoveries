import NineSeparatedSubsetSums.EightPoint133_132PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint133_132PackedAnchor0Part2 :
    ∀ j : Fin 6, 2387645 ≤ FourPointNumeric.octPackedCharge 133 132 20 packedOct133_132_0
      (2*((j.val : Int)+240)+1) := by decide +kernel

end NineSeparatedSubsetSums
