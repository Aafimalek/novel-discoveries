import NineSeparatedSubsetSums.FourPointPackedGeometry
import NineSeparatedSubsetSums.FourPoint133PackedBudget0
import NineSeparatedSubsetSums.FourPoint133PackedAnchor0Part0
import NineSeparatedSubsetSums.FourPoint133PackedAnchor0Part1
import NineSeparatedSubsetSums.FourPoint133PackedBudget1
import NineSeparatedSubsetSums.FourPoint133PackedAnchor1Part0
import NineSeparatedSubsetSums.FourPoint133PackedAnchor1Part1

namespace NineSeparatedSubsetSums

private theorem packed133Anchor0 :
  ∀ j : Fin 472, ((j.val : Int)+133)%2=0 →
    1047000 ≤ FourPointNumeric.packedCharge 133 20 packedWeight133_0 (j.val : Int) := by
  intro j hj
  let k := (j.val-1)/2
  have hk : k < 236 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+1 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := fourPoint133PackedAnchor0Part0 z
    rwa [he,hrep] at ht
  let z : Fin 116 := ⟨k-120, by omega⟩
  have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
  have ht := fourPoint133PackedAnchor0Part1 z
  rwa [he,hrep] at ht

private theorem packed133Anchor1 :
  ∀ j : Fin 472, ((j.val : Int)+133)%2=1 →
    1047012 ≤ FourPointNumeric.packedCharge 133 20 packedWeight133_1 (j.val : Int) := by
  intro j hj
  let k := (j.val-0)/2
  have hk : k < 236 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+0 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := fourPoint133PackedAnchor1Part0 z
    rwa [he,hrep] at ht
  let z : Fin 116 := ⟨k-120, by omega⟩
  have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
  have ht := fourPoint133PackedAnchor1Part1 z
  rwa [he,hrep] at ht

def packedCertificate133_0 : FourPointCertificate 133 0 110552 :=
  fourPointCertificateOfPacked 133 0 110552 1047000 20 packedWeight133_0 371 472
    (by decide +kernel) (by decide) (by decide) packed133Anchor0
    (by rw [packedWeight133_0_budget]; decide)

def packedCertificate133_1 : FourPointCertificate 133 1 110552 :=
  fourPointCertificateOfPacked 133 1 110552 1047012 20 packedWeight133_1 412 472
    (by decide +kernel) (by decide) (by decide) packed133Anchor1
    (by rw [packedWeight133_1_budget]; decide)

theorem max148_second133_fourPoint_moment_bound (tail : List ℕ) (len : tail.length=7)
    (distinct : (natSubsetSums (148::133::tail)).Nodup) :
    110552 ≤ ((148::133::tail).map (· ^ 2)).sum := by
  apply fourPointNatMomentLower 133 110552 tail len distinct
  intro p hp
  by_cases h : p=0
  · subst p
    exact packedCertificate133_0
  · have he : p=1 := hp.resolve_left h
    subst p
    exact packedCertificate133_1

#print axioms max148_second133_fourPoint_moment_bound

end NineSeparatedSubsetSums
