import NineSeparatedSubsetSums.EightPoint133_125PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct133_125_0_budget :
    FourPointNumeric.packedBudget 20 packedOct133_125_0 405 = 83082538 := by decide +kernel

#print axioms packedOct133_125_0_budget

end NineSeparatedSubsetSums
