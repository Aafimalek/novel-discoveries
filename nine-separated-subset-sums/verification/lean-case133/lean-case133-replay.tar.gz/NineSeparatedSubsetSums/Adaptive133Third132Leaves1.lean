import NineSeparatedSubsetSums.Adaptive133Third132State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive133Third132Proof19 : runCachedNode 511 126862 Adaptive133Third132Node19 = false := by
  decide +kernel

#print axioms adaptive133Third132Proof19

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive133Third132Proof18 : runCachedNode 511 126862 Adaptive133Third132Node18 = false := by
  decide +kernel

#print axioms adaptive133Third132Proof18

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive133Third132Proof13 : runCachedNode 511 126862 Adaptive133Third132Node13 = false := by
  decide +kernel

#print axioms adaptive133Third132Proof13

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive133Third132Proof4 : runCachedNode 511 126862 Adaptive133Third132Node4 = false := by
  decide +kernel

#print axioms adaptive133Third132Proof4

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive133Third132Proof2 : runCachedNode 511 126862 Adaptive133Third132Node2 = false := by
  decide +kernel

#print axioms adaptive133Third132Proof2

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive133Third132Proof1 : runCachedNode 511 126862 Adaptive133Third132Node1 = false := by
  decide +kernel

#print axioms adaptive133Third132Proof1

end NineSeparatedSubsetSums
