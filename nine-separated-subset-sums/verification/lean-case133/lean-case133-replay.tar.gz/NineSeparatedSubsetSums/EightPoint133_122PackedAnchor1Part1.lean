import NineSeparatedSubsetSums.EightPoint133_122PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint133_122PackedAnchor1Part1 :
    ∀ j : Fin 118, 2240498 ≤ FourPointNumeric.octPackedCharge 133 122 20 packedOct133_122_1
      (2*((j.val : Int)+120)+0) := by decide +kernel

end NineSeparatedSubsetSums
