import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive133Third131Node0 : CachedSearchNode :=
  ⟨4, 130, computeCenteredMask [148,133,131], 412, 56754⟩
def Adaptive133Third131Node1 : CachedSearchNode := cachedChild Adaptive133Third131Node0 111
def Adaptive133Third131Node2 : CachedSearchNode := cachedChild Adaptive133Third131Node0 112
def Adaptive133Third131Node3 : CachedSearchNode := cachedChild Adaptive133Third131Node0 113
def Adaptive133Third131Node4 : CachedSearchNode := cachedChild Adaptive133Third131Node0 114
def Adaptive133Third131Node5 : CachedSearchNode := cachedChild Adaptive133Third131Node0 115
def Adaptive133Third131Node6 : CachedSearchNode := cachedChild Adaptive133Third131Node0 117
def Adaptive133Third131Node7 : CachedSearchNode := cachedChild Adaptive133Third131Node0 118
def Adaptive133Third131Node8 : CachedSearchNode := cachedChild Adaptive133Third131Node0 119
def Adaptive133Third131Node9 : CachedSearchNode := cachedChild Adaptive133Third131Node0 120
def Adaptive133Third131Node10 : CachedSearchNode := cachedChild Adaptive133Third131Node0 121
def Adaptive133Third131Node11 : CachedSearchNode := cachedChild Adaptive133Third131Node0 122
def Adaptive133Third131Node12 : CachedSearchNode := cachedChild Adaptive133Third131Node0 123
def Adaptive133Third131Node13 : CachedSearchNode := cachedChild Adaptive133Third131Node0 124
def Adaptive133Third131Node14 : CachedSearchNode := cachedChild Adaptive133Third131Node0 125
def Adaptive133Third131Node15 : CachedSearchNode := cachedChild Adaptive133Third131Node0 126
def Adaptive133Third131Node16 : CachedSearchNode := cachedChild Adaptive133Third131Node0 127
def Adaptive133Third131Node17 : CachedSearchNode := cachedChild Adaptive133Third131Node0 128
def Adaptive133Third131Node18 : CachedSearchNode := cachedChild Adaptive133Third131Node0 129
def Adaptive133Third131Node19 : CachedSearchNode := cachedChild Adaptive133Third131Node0 130

end NineSeparatedSubsetSums
