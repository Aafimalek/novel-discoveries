import NineSeparatedSubsetSums.Adaptive133Third106State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive133Third106Proof0 : runCachedNode 511 110552 Adaptive133Third106Node0 = false := by
  decide +kernel

#print axioms adaptive133Third106Proof0

end NineSeparatedSubsetSums
