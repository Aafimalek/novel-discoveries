import NineSeparatedSubsetSums.Adaptive133Third131State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive133Third131Proof18 : runCachedNode 511 126645 Adaptive133Third131Node18 = false := by
  decide +kernel

#print axioms adaptive133Third131Proof18

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive133Third131Proof17 : runCachedNode 511 126645 Adaptive133Third131Node17 = false := by
  decide +kernel

#print axioms adaptive133Third131Proof17

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive133Third131Proof14 : runCachedNode 511 126645 Adaptive133Third131Node14 = false := by
  decide +kernel

#print axioms adaptive133Third131Proof14

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive133Third131Proof5 : runCachedNode 511 126645 Adaptive133Third131Node5 = false := by
  decide +kernel

#print axioms adaptive133Third131Proof5

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive133Third131Proof1 : runCachedNode 511 126645 Adaptive133Third131Node1 = false := by
  decide +kernel

#print axioms adaptive133Third131Proof1

end NineSeparatedSubsetSums
