import NineSeparatedSubsetSums.EightPointPackedGeometry
import NineSeparatedSubsetSums.EightPoint133_129PackedBudget0
import NineSeparatedSubsetSums.EightPoint133_129PackedAnchor0Part0
import NineSeparatedSubsetSums.EightPoint133_129PackedAnchor0Part1
import NineSeparatedSubsetSums.EightPoint133_129PackedAnchor0Part2
import NineSeparatedSubsetSums.EightPoint133_129PackedBudget1
import NineSeparatedSubsetSums.EightPoint133_129PackedAnchor1Part0
import NineSeparatedSubsetSums.EightPoint133_129PackedAnchor1Part1
import NineSeparatedSubsetSums.EightPoint133_129PackedAnchor1Part2

namespace NineSeparatedSubsetSums

private theorem packedOct133_129Anchor0 :
  ∀ j : Fin 487, ((j.val : Int)+133+129)%2=0 →
    2339463 ≤ FourPointNumeric.octPackedCharge 133 129 20 packedOct133_129_0 (j.val : Int) := by
  intro j hj
  let k := (j.val-0)/2
  have hk : k < 244 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+0 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint133_129PackedAnchor0Part0 z
    rwa [he,hrep] at ht
  by_cases h1 : k < 240
  · let z : Fin 120 := ⟨k-120, by omega⟩
    have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
    have ht := eightPoint133_129PackedAnchor0Part1 z
    rwa [he,hrep] at ht
  let z : Fin 4 := ⟨k-240, by omega⟩
  have he : (z.val : Int)+240 = k := by dsimp [z] <;> omega
  have ht := eightPoint133_129PackedAnchor0Part2 z
  rwa [he,hrep] at ht

private theorem packedOct133_129Anchor1 :
  ∀ j : Fin 487, ((j.val : Int)+133+129)%2=1 →
    2341094 ≤ FourPointNumeric.octPackedCharge 133 129 20 packedOct133_129_1 (j.val : Int) := by
  intro j hj
  let k := (j.val-1)/2
  have hk : k < 243 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+1 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint133_129PackedAnchor1Part0 z
    rwa [he,hrep] at ht
  by_cases h1 : k < 240
  · let z : Fin 120 := ⟨k-120, by omega⟩
    have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
    have ht := eightPoint133_129PackedAnchor1Part1 z
    rwa [he,hrep] at ht
  let z : Fin 3 := ⟨k-240, by omega⟩
  have he : (z.val : Int)+240 = k := by dsimp [z] <;> omega
  have ht := eightPoint133_129PackedAnchor1Part2 z
  rwa [he,hrep] at ht

def packedOctCertificate133_129_0 : EightPointCertificate 133 129 0 126235 :=
  eightPointCertificateOfPacked 133 129 0 126235 2339463 20 packedOct133_129_0 447 487
    (by decide +kernel) (by decide) packedOct133_129Anchor0
    (by rw [packedOct133_129_0_budget]; decide)

def packedOctCertificate133_129_1 : EightPointCertificate 133 129 1 126235 :=
  eightPointCertificateOfPacked 133 129 1 126235 2341094 20 packedOct133_129_1 448 487
    (by decide +kernel) (by decide) packedOct133_129Anchor1
    (by rw [packedOct133_129_1_budget]; decide)

theorem max148_second133_third129_eightPoint_moment_bound (tail : List ℕ) (len : tail.length=6)
    (distinct : (natSubsetSums (148::133::129::tail)).Nodup) :
    126235 ≤ ((148::133::129::tail).map (· ^ 2)).sum := by
  apply eightPointNatMomentLower 133 129 126235 tail len distinct
  intro p hp
  by_cases h : p=0
  · subst p
    exact packedOctCertificate133_129_0
  · have he : p=1 := hp.resolve_left h
    subst p
    exact packedOctCertificate133_129_1

#print axioms max148_second133_third129_eightPoint_moment_bound

end NineSeparatedSubsetSums
