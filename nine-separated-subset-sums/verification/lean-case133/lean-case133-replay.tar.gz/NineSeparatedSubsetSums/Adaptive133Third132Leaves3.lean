import NineSeparatedSubsetSums.Adaptive133Third132State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive133Third132Proof12 : runCachedNode 511 126862 Adaptive133Third132Node12 = false := by
  decide +kernel

#print axioms adaptive133Third132Proof12

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive133Third132Proof10 : runCachedNode 511 126862 Adaptive133Third132Node10 = false := by
  decide +kernel

#print axioms adaptive133Third132Proof10

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive133Third132Proof7 : runCachedNode 511 126862 Adaptive133Third132Node7 = false := by
  decide +kernel

#print axioms adaptive133Third132Proof7

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive133Third132Proof9 : runCachedNode 511 126862 Adaptive133Third132Node9 = false := by
  decide +kernel

#print axioms adaptive133Third132Proof9

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive133Third132Proof6 : runCachedNode 511 126862 Adaptive133Third132Node6 = false := by
  decide +kernel

#print axioms adaptive133Third132Proof6

end NineSeparatedSubsetSums
