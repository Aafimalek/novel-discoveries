import NineSeparatedSubsetSums.Adaptive133Third109Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint133Checked

namespace NineSeparatedSubsetSums


theorem adaptive133Third109 : NoDescendingTailAfterThird 133 109 :=
  noDescendingThirdTail_of_cached 133 109 110552 (fun t ht nd => max148_second133_fourPoint_moment_bound (109::t) (by simp [ht]) nd) adaptive133Third109Proof0

#print axioms adaptive133Third109

end NineSeparatedSubsetSums
