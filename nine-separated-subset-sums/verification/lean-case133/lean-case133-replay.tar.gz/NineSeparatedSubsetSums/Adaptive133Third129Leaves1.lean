import NineSeparatedSubsetSums.Adaptive133Third129State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive133Third129Proof13 : runCachedNode 511 126235 Adaptive133Third129Node13 = false := by
  decide +kernel

#print axioms adaptive133Third129Proof13

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive133Third129Proof12 : runCachedNode 511 126235 Adaptive133Third129Node12 = false := by
  decide +kernel

#print axioms adaptive133Third129Proof12

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive133Third129Proof10 : runCachedNode 511 126235 Adaptive133Third129Node10 = false := by
  decide +kernel

#print axioms adaptive133Third129Proof10

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive133Third129Proof7 : runCachedNode 511 126235 Adaptive133Third129Node7 = false := by
  decide +kernel

#print axioms adaptive133Third129Proof7

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive133Third129Proof11 : runCachedNode 511 126235 Adaptive133Third129Node11 = false := by
  decide +kernel

#print axioms adaptive133Third129Proof11

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive133Third129Proof9 : runCachedNode 511 126235 Adaptive133Third129Node9 = false := by
  decide +kernel

#print axioms adaptive133Third129Proof9

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive133Third129Proof8 : runCachedNode 511 126235 Adaptive133Third129Node8 = false := by
  decide +kernel

#print axioms adaptive133Third129Proof8

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive133Third129Proof3 : runCachedNode 511 126235 Adaptive133Third129Node3 = false := by
  decide +kernel

#print axioms adaptive133Third129Proof3

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive133Third129Proof2 : runCachedNode 511 126235 Adaptive133Third129Node2 = false := by
  decide +kernel

#print axioms adaptive133Third129Proof2

end NineSeparatedSubsetSums
