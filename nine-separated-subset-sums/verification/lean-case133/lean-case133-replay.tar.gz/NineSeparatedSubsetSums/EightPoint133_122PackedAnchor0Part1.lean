import NineSeparatedSubsetSums.EightPoint133_122PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint133_122PackedAnchor0Part1 :
    ∀ j : Fin 117, 2240462 ≤ FourPointNumeric.octPackedCharge 133 122 20 packedOct133_122_0
      (2*((j.val : Int)+120)+1) := by decide +kernel

end NineSeparatedSubsetSums
