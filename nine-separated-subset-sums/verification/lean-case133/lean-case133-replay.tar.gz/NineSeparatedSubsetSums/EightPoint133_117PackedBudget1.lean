import NineSeparatedSubsetSums.EightPoint133_117PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct133_117_1_budget :
    FourPointNumeric.packedBudget 20 packedOct133_117_1 400 = 77629986 := by decide +kernel

#print axioms packedOct133_117_1_budget

end NineSeparatedSubsetSums
