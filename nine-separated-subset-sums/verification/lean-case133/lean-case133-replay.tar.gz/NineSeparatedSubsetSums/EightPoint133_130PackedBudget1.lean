import NineSeparatedSubsetSums.EightPoint133_130PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct133_130_1_budget :
    FourPointNumeric.packedBudget 20 packedOct133_130_1 442 = 86347480 := by decide +kernel

#print axioms packedOct133_130_1_budget

end NineSeparatedSubsetSums
