import NineSeparatedSubsetSums.Adaptive133Third125State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive133Third125Proof0 : runCachedNode 511 125540 Adaptive133Third125Node0 = false := by
  decide +kernel

#print axioms adaptive133Third125Proof0

end NineSeparatedSubsetSums
