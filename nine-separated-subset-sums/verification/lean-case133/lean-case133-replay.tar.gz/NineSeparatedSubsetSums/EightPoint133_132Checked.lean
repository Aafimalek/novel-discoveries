import NineSeparatedSubsetSums.EightPointPackedGeometry
import NineSeparatedSubsetSums.EightPoint133_132PackedBudget0
import NineSeparatedSubsetSums.EightPoint133_132PackedAnchor0Part0
import NineSeparatedSubsetSums.EightPoint133_132PackedAnchor0Part1
import NineSeparatedSubsetSums.EightPoint133_132PackedAnchor0Part2
import NineSeparatedSubsetSums.EightPoint133_132PackedBudget1
import NineSeparatedSubsetSums.EightPoint133_132PackedAnchor1Part0
import NineSeparatedSubsetSums.EightPoint133_132PackedAnchor1Part1
import NineSeparatedSubsetSums.EightPoint133_132PackedAnchor1Part2

namespace NineSeparatedSubsetSums

private theorem packedOct133_132Anchor0 :
  ∀ j : Fin 492, ((j.val : Int)+133+132)%2=0 →
    2387645 ≤ FourPointNumeric.octPackedCharge 133 132 20 packedOct133_132_0 (j.val : Int) := by
  intro j hj
  let k := (j.val-1)/2
  have hk : k < 246 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+1 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint133_132PackedAnchor0Part0 z
    rwa [he,hrep] at ht
  by_cases h1 : k < 240
  · let z : Fin 120 := ⟨k-120, by omega⟩
    have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
    have ht := eightPoint133_132PackedAnchor0Part1 z
    rwa [he,hrep] at ht
  let z : Fin 6 := ⟨k-240, by omega⟩
  have he : (z.val : Int)+240 = k := by dsimp [z] <;> omega
  have ht := eightPoint133_132PackedAnchor0Part2 z
  rwa [he,hrep] at ht

private theorem packedOct133_132Anchor1 :
  ∀ j : Fin 492, ((j.val : Int)+133+132)%2=1 →
    2388618 ≤ FourPointNumeric.octPackedCharge 133 132 20 packedOct133_132_1 (j.val : Int) := by
  intro j hj
  let k := (j.val-0)/2
  have hk : k < 246 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+0 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint133_132PackedAnchor1Part0 z
    rwa [he,hrep] at ht
  by_cases h1 : k < 240
  · let z : Fin 120 := ⟨k-120, by omega⟩
    have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
    have ht := eightPoint133_132PackedAnchor1Part1 z
    rwa [he,hrep] at ht
  let z : Fin 6 := ⟨k-240, by omega⟩
  have he : (z.val : Int)+240 = k := by dsimp [z] <;> omega
  have ht := eightPoint133_132PackedAnchor1Part2 z
  rwa [he,hrep] at ht

def packedOctCertificate133_132_0 : EightPointCertificate 133 132 0 126862 :=
  eightPointCertificateOfPacked 133 132 0 126862 2387645 20 packedOct133_132_0 471 492
    (by decide +kernel) (by decide) packedOct133_132Anchor0
    (by rw [packedOct133_132_0_budget]; decide)

def packedOctCertificate133_132_1 : EightPointCertificate 133 132 1 126862 :=
  eightPointCertificateOfPacked 133 132 1 126862 2388618 20 packedOct133_132_1 366 492
    (by decide +kernel) (by decide) packedOct133_132Anchor1
    (by rw [packedOct133_132_1_budget]; decide)

theorem max148_second133_third132_eightPoint_moment_bound (tail : List ℕ) (len : tail.length=6)
    (distinct : (natSubsetSums (148::133::132::tail)).Nodup) :
    126862 ≤ ((148::133::132::tail).map (· ^ 2)).sum := by
  apply eightPointNatMomentLower 133 132 126862 tail len distinct
  intro p hp
  by_cases h : p=0
  · subst p
    exact packedOctCertificate133_132_0
  · have he : p=1 := hp.resolve_left h
    subst p
    exact packedOctCertificate133_132_1

#print axioms max148_second133_third132_eightPoint_moment_bound

end NineSeparatedSubsetSums
