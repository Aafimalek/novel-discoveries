import NineSeparatedSubsetSums.EightPoint133_118PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct133_118_0_budget :
    FourPointNumeric.packedBudget 20 packedOct133_118_0 267 = 79819275 := by decide +kernel

#print axioms packedOct133_118_0_budget

end NineSeparatedSubsetSums
