import NineSeparatedSubsetSums.EightPointPackedGeometry
import NineSeparatedSubsetSums.EightPoint133_126PackedBudget0
import NineSeparatedSubsetSums.EightPoint133_126PackedAnchor0Part0
import NineSeparatedSubsetSums.EightPoint133_126PackedAnchor0Part1
import NineSeparatedSubsetSums.EightPoint133_126PackedAnchor0Part2
import NineSeparatedSubsetSums.EightPoint133_126PackedBudget1
import NineSeparatedSubsetSums.EightPoint133_126PackedAnchor1Part0
import NineSeparatedSubsetSums.EightPoint133_126PackedAnchor1Part1
import NineSeparatedSubsetSums.EightPoint133_126PackedAnchor1Part2

namespace NineSeparatedSubsetSums

private theorem packedOct133_126Anchor0 :
  ∀ j : Fin 486, ((j.val : Int)+133+126)%2=0 →
    2328941 ≤ FourPointNumeric.octPackedCharge 133 126 20 packedOct133_126_0 (j.val : Int) := by
  intro j hj
  let k := (j.val-1)/2
  have hk : k < 243 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+1 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint133_126PackedAnchor0Part0 z
    rwa [he,hrep] at ht
  by_cases h1 : k < 240
  · let z : Fin 120 := ⟨k-120, by omega⟩
    have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
    have ht := eightPoint133_126PackedAnchor0Part1 z
    rwa [he,hrep] at ht
  let z : Fin 3 := ⟨k-240, by omega⟩
  have he : (z.val : Int)+240 = k := by dsimp [z] <;> omega
  have ht := eightPoint133_126PackedAnchor0Part2 z
  rwa [he,hrep] at ht

private theorem packedOct133_126Anchor1 :
  ∀ j : Fin 486, ((j.val : Int)+133+126)%2=1 →
    2328898 ≤ FourPointNumeric.octPackedCharge 133 126 20 packedOct133_126_1 (j.val : Int) := by
  intro j hj
  let k := (j.val-0)/2
  have hk : k < 243 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+0 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint133_126PackedAnchor1Part0 z
    rwa [he,hrep] at ht
  by_cases h1 : k < 240
  · let z : Fin 120 := ⟨k-120, by omega⟩
    have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
    have ht := eightPoint133_126PackedAnchor1Part1 z
    rwa [he,hrep] at ht
  let z : Fin 3 := ⟨k-240, by omega⟩
  have he : (z.val : Int)+240 = k := by dsimp [z] <;> omega
  have ht := eightPoint133_126PackedAnchor1Part2 z
  rwa [he,hrep] at ht

def packedOctCertificate133_126_0 : EightPointCertificate 133 126 0 125855 :=
  eightPointCertificateOfPacked 133 126 0 125855 2328941 20 packedOct133_126_0 445 486
    (by decide +kernel) (by decide) packedOct133_126Anchor0
    (by rw [packedOct133_126_0_budget]; decide)

def packedOctCertificate133_126_1 : EightPointCertificate 133 126 1 125855 :=
  eightPointCertificateOfPacked 133 126 1 125855 2328898 20 packedOct133_126_1 446 486
    (by decide +kernel) (by decide) packedOct133_126Anchor1
    (by rw [packedOct133_126_1_budget]; decide)

theorem max148_second133_third126_eightPoint_moment_bound (tail : List ℕ) (len : tail.length=6)
    (distinct : (natSubsetSums (148::133::126::tail)).Nodup) :
    125855 ≤ ((148::133::126::tail).map (· ^ 2)).sum := by
  apply eightPointNatMomentLower 133 126 125855 tail len distinct
  intro p hp
  by_cases h : p=0
  · subst p
    exact packedOctCertificate133_126_0
  · have he : p=1 := hp.resolve_left h
    subst p
    exact packedOctCertificate133_126_1

#print axioms max148_second133_third126_eightPoint_moment_bound

end NineSeparatedSubsetSums
