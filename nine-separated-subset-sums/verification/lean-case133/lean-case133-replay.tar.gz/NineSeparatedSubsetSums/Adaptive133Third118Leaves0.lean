import NineSeparatedSubsetSums.Adaptive133Third118State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive133Third118Proof0 : runCachedNode 511 124076 Adaptive133Third118Node0 = false := by
  decide +kernel

#print axioms adaptive133Third118Proof0

end NineSeparatedSubsetSums
