import NineSeparatedSubsetSums.EightPoint133_129PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct133_129_1_budget :
    FourPointNumeric.packedBudget 20 packedOct133_129_1 448 = 85197796 := by decide +kernel

#print axioms packedOct133_129_1_budget

end NineSeparatedSubsetSums
