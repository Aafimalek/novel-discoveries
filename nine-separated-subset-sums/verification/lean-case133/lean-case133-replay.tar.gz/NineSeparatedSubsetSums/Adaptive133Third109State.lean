import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive133Third109Node0 : CachedSearchNode :=
  ⟨4, 108, computeCenteredMask [148,133,109], 390, 51474⟩

end NineSeparatedSubsetSums
