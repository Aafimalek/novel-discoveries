import NineSeparatedSubsetSums.Adaptive133Third131State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive133Third131Proof13 : runCachedNode 511 126645 Adaptive133Third131Node13 = false := by
  decide +kernel

#print axioms adaptive133Third131Proof13

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive133Third131Proof12 : runCachedNode 511 126645 Adaptive133Third131Node12 = false := by
  decide +kernel

#print axioms adaptive133Third131Proof12

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive133Third131Proof11 : runCachedNode 511 126645 Adaptive133Third131Node11 = false := by
  decide +kernel

#print axioms adaptive133Third131Proof11

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive133Third131Proof10 : runCachedNode 511 126645 Adaptive133Third131Node10 = false := by
  decide +kernel

#print axioms adaptive133Third131Proof10

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive133Third131Proof8 : runCachedNode 511 126645 Adaptive133Third131Node8 = false := by
  decide +kernel

#print axioms adaptive133Third131Proof8

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive133Third131Proof9 : runCachedNode 511 126645 Adaptive133Third131Node9 = false := by
  decide +kernel

#print axioms adaptive133Third131Proof9

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive133Third131Proof6 : runCachedNode 511 126645 Adaptive133Third131Node6 = false := by
  decide +kernel

#print axioms adaptive133Third131Proof6

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive133Third131Proof4 : runCachedNode 511 126645 Adaptive133Third131Node4 = false := by
  decide +kernel

#print axioms adaptive133Third131Proof4

end NineSeparatedSubsetSums
