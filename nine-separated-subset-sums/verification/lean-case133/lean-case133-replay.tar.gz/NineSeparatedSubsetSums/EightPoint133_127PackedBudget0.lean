import NineSeparatedSubsetSums.EightPoint133_127PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct133_127_0_budget :
    FourPointNumeric.packedBudget 20 packedOct133_127_0 447 = 84343227 := by decide +kernel

#print axioms packedOct133_127_0_budget

end NineSeparatedSubsetSums
