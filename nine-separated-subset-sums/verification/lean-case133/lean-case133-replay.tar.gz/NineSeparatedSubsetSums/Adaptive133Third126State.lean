import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive133Third126Node0 : CachedSearchNode :=
  ⟨4, 125, computeCenteredMask [148,133,126], 407, 55469⟩

end NineSeparatedSubsetSums
