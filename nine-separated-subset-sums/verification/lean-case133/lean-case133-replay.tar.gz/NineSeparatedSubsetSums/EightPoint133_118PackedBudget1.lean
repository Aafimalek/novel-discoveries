import NineSeparatedSubsetSums.EightPoint133_118PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct133_118_1_budget :
    FourPointNumeric.packedBudget 20 packedOct133_118_1 266 = 79785162 := by decide +kernel

#print axioms packedOct133_118_1_budget

end NineSeparatedSubsetSums
