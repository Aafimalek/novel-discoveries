import NineSeparatedSubsetSums.EightPoint133_130PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint133_130PackedAnchor1Part0 :
    ∀ j : Fin 120, 2360434 ≤ FourPointNumeric.octPackedCharge 133 130 20 packedOct133_130_1
      (2*((j.val : Int)+0)+0) := by decide +kernel

end NineSeparatedSubsetSums
