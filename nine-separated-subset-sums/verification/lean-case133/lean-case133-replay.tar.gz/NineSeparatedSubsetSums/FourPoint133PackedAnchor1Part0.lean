import NineSeparatedSubsetSums.FourPoint133PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem fourPoint133PackedAnchor1Part0 :
    ∀ j : Fin 120, 1047012 ≤ FourPointNumeric.packedCharge 133 20 packedWeight133_1
      (2*((j.val : Int)+0)+0) := by decide +kernel

end NineSeparatedSubsetSums
