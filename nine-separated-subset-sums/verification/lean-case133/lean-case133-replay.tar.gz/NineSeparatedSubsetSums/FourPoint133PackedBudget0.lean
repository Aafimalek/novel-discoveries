import NineSeparatedSubsetSums.FourPoint133PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedWeight133_0_budget :
    FourPointNumeric.packedBudget 20 packedWeight133_0 371 = 77413056 := by decide +kernel

#print axioms packedWeight133_0_budget

end NineSeparatedSubsetSums
