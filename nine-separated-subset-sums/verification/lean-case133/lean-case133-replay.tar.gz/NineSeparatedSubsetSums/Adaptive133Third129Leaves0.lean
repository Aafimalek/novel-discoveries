import NineSeparatedSubsetSums.Adaptive133Third129State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive133Third129Proof17 : runCachedNode 511 126235 Adaptive133Third129Node17 = false := by
  decide +kernel

#print axioms adaptive133Third129Proof17

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive133Third129Proof16 : runCachedNode 511 126235 Adaptive133Third129Node16 = false := by
  decide +kernel

#print axioms adaptive133Third129Proof16

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive133Third129Proof14 : runCachedNode 511 126235 Adaptive133Third129Node14 = false := by
  decide +kernel

#print axioms adaptive133Third129Proof14

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive133Third129Proof15 : runCachedNode 511 126235 Adaptive133Third129Node15 = false := by
  decide +kernel

#print axioms adaptive133Third129Proof15

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive133Third129Proof6 : runCachedNode 511 126235 Adaptive133Third129Node6 = false := by
  decide +kernel

#print axioms adaptive133Third129Proof6

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive133Third129Proof5 : runCachedNode 511 126235 Adaptive133Third129Node5 = false := by
  decide +kernel

#print axioms adaptive133Third129Proof5

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive133Third129Proof4 : runCachedNode 511 126235 Adaptive133Third129Node4 = false := by
  decide +kernel

#print axioms adaptive133Third129Proof4

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive133Third129Proof1 : runCachedNode 511 126235 Adaptive133Third129Node1 = false := by
  decide +kernel

#print axioms adaptive133Third129Proof1

end NineSeparatedSubsetSums
