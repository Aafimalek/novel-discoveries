import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive133Third114Node0 : CachedSearchNode :=
  ⟨4, 113, computeCenteredMask [148,133,114], 395, 52589⟩

end NineSeparatedSubsetSums
