import NineSeparatedSubsetSums.EightPoint133_132PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct133_132_1_budget :
    FourPointNumeric.packedBudget 20 packedOct133_132_1 366 = 87918092 := by decide +kernel

#print axioms packedOct133_132_1_budget

end NineSeparatedSubsetSums
