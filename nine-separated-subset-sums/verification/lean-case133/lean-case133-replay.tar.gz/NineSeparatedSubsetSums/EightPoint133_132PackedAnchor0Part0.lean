import NineSeparatedSubsetSums.EightPoint133_132PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint133_132PackedAnchor0Part0 :
    ∀ j : Fin 120, 2387645 ≤ FourPointNumeric.octPackedCharge 133 132 20 packedOct133_132_0
      (2*((j.val : Int)+0)+1) := by decide +kernel

end NineSeparatedSubsetSums
