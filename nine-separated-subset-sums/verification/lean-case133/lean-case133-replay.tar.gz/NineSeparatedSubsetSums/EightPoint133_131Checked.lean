import NineSeparatedSubsetSums.EightPointPackedGeometry
import NineSeparatedSubsetSums.EightPoint133_131PackedBudget0
import NineSeparatedSubsetSums.EightPoint133_131PackedAnchor0Part0
import NineSeparatedSubsetSums.EightPoint133_131PackedAnchor0Part1
import NineSeparatedSubsetSums.EightPoint133_131PackedAnchor0Part2
import NineSeparatedSubsetSums.EightPoint133_131PackedBudget1
import NineSeparatedSubsetSums.EightPoint133_131PackedAnchor1Part0
import NineSeparatedSubsetSums.EightPoint133_131PackedAnchor1Part1
import NineSeparatedSubsetSums.EightPoint133_131PackedAnchor1Part2

namespace NineSeparatedSubsetSums

private theorem packedOct133_131Anchor0 :
  ∀ j : Fin 491, ((j.val : Int)+133+131)%2=0 →
    2377993 ≤ FourPointNumeric.octPackedCharge 133 131 20 packedOct133_131_0 (j.val : Int) := by
  intro j hj
  let k := (j.val-0)/2
  have hk : k < 246 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+0 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint133_131PackedAnchor0Part0 z
    rwa [he,hrep] at ht
  by_cases h1 : k < 240
  · let z : Fin 120 := ⟨k-120, by omega⟩
    have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
    have ht := eightPoint133_131PackedAnchor0Part1 z
    rwa [he,hrep] at ht
  let z : Fin 6 := ⟨k-240, by omega⟩
  have he : (z.val : Int)+240 = k := by dsimp [z] <;> omega
  have ht := eightPoint133_131PackedAnchor0Part2 z
  rwa [he,hrep] at ht

private theorem packedOct133_131Anchor1 :
  ∀ j : Fin 491, ((j.val : Int)+133+131)%2=1 →
    2377955 ≤ FourPointNumeric.octPackedCharge 133 131 20 packedOct133_131_1 (j.val : Int) := by
  intro j hj
  let k := (j.val-1)/2
  have hk : k < 245 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+1 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint133_131PackedAnchor1Part0 z
    rwa [he,hrep] at ht
  by_cases h1 : k < 240
  · let z : Fin 120 := ⟨k-120, by omega⟩
    have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
    have ht := eightPoint133_131PackedAnchor1Part1 z
    rwa [he,hrep] at ht
  let z : Fin 5 := ⟨k-240, by omega⟩
  have he : (z.val : Int)+240 = k := by dsimp [z] <;> omega
  have ht := eightPoint133_131PackedAnchor1Part2 z
  rwa [he,hrep] at ht

def packedOctCertificate133_131_0 : EightPointCertificate 133 131 0 126645 :=
  eightPointCertificateOfPacked 133 131 0 126645 2377993 20 packedOct133_131_0 373 491
    (by decide +kernel) (by decide) packedOct133_131Anchor0
    (by rw [packedOct133_131_0_budget]; decide)

def packedOctCertificate133_131_1 : EightPointCertificate 133 131 1 126645 :=
  eightPointCertificateOfPacked 133 131 1 126645 2377955 20 packedOct133_131_1 368 491
    (by decide +kernel) (by decide) packedOct133_131Anchor1
    (by rw [packedOct133_131_1_budget]; decide)

theorem max148_second133_third131_eightPoint_moment_bound (tail : List ℕ) (len : tail.length=6)
    (distinct : (natSubsetSums (148::133::131::tail)).Nodup) :
    126645 ≤ ((148::133::131::tail).map (· ^ 2)).sum := by
  apply eightPointNatMomentLower 133 131 126645 tail len distinct
  intro p hp
  by_cases h : p=0
  · subst p
    exact packedOctCertificate133_131_0
  · have he : p=1 := hp.resolve_left h
    subst p
    exact packedOctCertificate133_131_1

#print axioms max148_second133_third131_eightPoint_moment_bound

end NineSeparatedSubsetSums
