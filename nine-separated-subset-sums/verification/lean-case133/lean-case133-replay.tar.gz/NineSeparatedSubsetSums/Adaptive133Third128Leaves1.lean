import NineSeparatedSubsetSums.Adaptive133Third128State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive133Third128Proof9 : runCachedNode 511 126129 Adaptive133Third128Node9 = false := by
  decide +kernel

#print axioms adaptive133Third128Proof9

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive133Third128Proof7 : runCachedNode 511 126129 Adaptive133Third128Node7 = false := by
  decide +kernel

#print axioms adaptive133Third128Proof7

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive133Third128Proof8 : runCachedNode 511 126129 Adaptive133Third128Node8 = false := by
  decide +kernel

#print axioms adaptive133Third128Proof8

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive133Third128Proof6 : runCachedNode 511 126129 Adaptive133Third128Node6 = false := by
  decide +kernel

#print axioms adaptive133Third128Proof6

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive133Third128Proof4 : runCachedNode 511 126129 Adaptive133Third128Node4 = false := by
  decide +kernel

#print axioms adaptive133Third128Proof4

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive133Third128Proof3 : runCachedNode 511 126129 Adaptive133Third128Node3 = false := by
  decide +kernel

#print axioms adaptive133Third128Proof3

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive133Third128Proof2 : runCachedNode 511 126129 Adaptive133Third128Node2 = false := by
  decide +kernel

#print axioms adaptive133Third128Proof2

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive133Third128Proof1 : runCachedNode 511 126129 Adaptive133Third128Node1 = false := by
  decide +kernel

#print axioms adaptive133Third128Proof1

end NineSeparatedSubsetSums
