import NineSeparatedSubsetSums.EightPoint133_127PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct133_127_1_budget :
    FourPointNumeric.packedBudget 20 packedOct133_127_1 444 = 84407394 := by decide +kernel

#print axioms packedOct133_127_1_budget

end NineSeparatedSubsetSums
