import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive133Third118Node0 : CachedSearchNode :=
  ⟨4, 117, computeCenteredMask [148,133,118], 399, 53517⟩

end NineSeparatedSubsetSums
