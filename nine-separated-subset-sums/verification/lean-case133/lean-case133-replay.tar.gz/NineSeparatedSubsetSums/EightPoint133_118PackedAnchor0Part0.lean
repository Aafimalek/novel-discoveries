import NineSeparatedSubsetSums.EightPoint133_118PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint133_118PackedAnchor0Part0 :
    ∀ j : Fin 120, 2239778 ≤ FourPointNumeric.octPackedCharge 133 118 20 packedOct133_118_0
      (2*((j.val : Int)+0)+1) := by decide +kernel

end NineSeparatedSubsetSums
