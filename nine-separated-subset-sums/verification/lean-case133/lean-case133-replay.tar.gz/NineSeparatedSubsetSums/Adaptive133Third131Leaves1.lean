import NineSeparatedSubsetSums.Adaptive133Third131State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive133Third131Proof19 : runCachedNode 511 126645 Adaptive133Third131Node19 = false := by
  decide +kernel

#print axioms adaptive133Third131Proof19

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive133Third131Proof16 : runCachedNode 511 126645 Adaptive133Third131Node16 = false := by
  decide +kernel

#print axioms adaptive133Third131Proof16

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive133Third131Proof15 : runCachedNode 511 126645 Adaptive133Third131Node15 = false := by
  decide +kernel

#print axioms adaptive133Third131Proof15

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive133Third131Proof7 : runCachedNode 511 126645 Adaptive133Third131Node7 = false := by
  decide +kernel

#print axioms adaptive133Third131Proof7

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive133Third131Proof3 : runCachedNode 511 126645 Adaptive133Third131Node3 = false := by
  decide +kernel

#print axioms adaptive133Third131Proof3

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive133Third131Proof2 : runCachedNode 511 126645 Adaptive133Third131Node2 = false := by
  decide +kernel

#print axioms adaptive133Third131Proof2

end NineSeparatedSubsetSums
