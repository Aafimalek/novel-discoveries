import NineSeparatedSubsetSums.EightPoint133_132PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct133_132_0_budget :
    FourPointNumeric.packedBudget 20 packedOct133_132_0 471 = 87855963 := by decide +kernel

#print axioms packedOct133_132_0_budget

end NineSeparatedSubsetSums
