import NineSeparatedSubsetSums.Adaptive133Third130State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive133Third130Proof17 : runCachedNode 511 126407 Adaptive133Third130Node17 = false := by
  decide +kernel

#print axioms adaptive133Third130Proof17

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive133Third130Proof14 : runCachedNode 511 126407 Adaptive133Third130Node14 = false := by
  decide +kernel

#print axioms adaptive133Third130Proof14

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive133Third130Proof13 : runCachedNode 511 126407 Adaptive133Third130Node13 = false := by
  decide +kernel

#print axioms adaptive133Third130Proof13

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive133Third130Proof12 : runCachedNode 511 126407 Adaptive133Third130Node12 = false := by
  decide +kernel

#print axioms adaptive133Third130Proof12

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive133Third130Proof11 : runCachedNode 511 126407 Adaptive133Third130Node11 = false := by
  decide +kernel

#print axioms adaptive133Third130Proof11

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive133Third130Proof7 : runCachedNode 511 126407 Adaptive133Third130Node7 = false := by
  decide +kernel

#print axioms adaptive133Third130Proof7

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive133Third130Proof9 : runCachedNode 511 126407 Adaptive133Third130Node9 = false := by
  decide +kernel

#print axioms adaptive133Third130Proof9

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive133Third130Proof5 : runCachedNode 511 126407 Adaptive133Third130Node5 = false := by
  decide +kernel

#print axioms adaptive133Third130Proof5

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive133Third130Proof3 : runCachedNode 511 126407 Adaptive133Third130Node3 = false := by
  decide +kernel

#print axioms adaptive133Third130Proof3

end NineSeparatedSubsetSums
