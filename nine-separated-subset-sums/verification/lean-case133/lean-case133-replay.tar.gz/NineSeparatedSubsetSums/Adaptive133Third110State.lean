import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive133Third110Node0 : CachedSearchNode :=
  ⟨4, 109, computeCenteredMask [148,133,110], 391, 51693⟩

end NineSeparatedSubsetSums
