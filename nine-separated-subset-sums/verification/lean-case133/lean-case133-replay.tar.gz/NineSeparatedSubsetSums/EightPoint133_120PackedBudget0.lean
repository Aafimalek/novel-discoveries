import NineSeparatedSubsetSums.EightPoint133_120PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct133_120_0_budget :
    FourPointNumeric.packedBudget 20 packedOct133_120_0 377 = 82656290 := by decide +kernel

#print axioms packedOct133_120_0_budget

end NineSeparatedSubsetSums
