import NineSeparatedSubsetSums.EightPoint133_119PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct133_119_0_budget :
    FourPointNumeric.packedBudget 20 packedOct133_119_0 377 = 82008197 := by decide +kernel

#print axioms packedOct133_119_0_budget

end NineSeparatedSubsetSums
