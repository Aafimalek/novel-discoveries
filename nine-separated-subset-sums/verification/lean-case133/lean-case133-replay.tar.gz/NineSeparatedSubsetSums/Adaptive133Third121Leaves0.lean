import NineSeparatedSubsetSums.Adaptive133Third121State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive133Third121Proof0 : runCachedNode 511 124344 Adaptive133Third121Node0 = false := by
  decide +kernel

#print axioms adaptive133Third121Proof0

end NineSeparatedSubsetSums
