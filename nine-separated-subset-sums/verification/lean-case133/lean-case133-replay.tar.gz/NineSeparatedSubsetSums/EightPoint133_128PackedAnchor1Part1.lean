import NineSeparatedSubsetSums.EightPoint133_128PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint133_128PackedAnchor1Part1 :
    ∀ j : Fin 120, 2323090 ≤ FourPointNumeric.octPackedCharge 133 128 20 packedOct133_128_1
      (2*((j.val : Int)+120)+0) := by decide +kernel

end NineSeparatedSubsetSums
