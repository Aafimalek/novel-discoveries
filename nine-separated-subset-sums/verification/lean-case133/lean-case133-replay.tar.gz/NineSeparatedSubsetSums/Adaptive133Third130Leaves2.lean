import NineSeparatedSubsetSums.Adaptive133Third130State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive133Third130Proof10 : runCachedNode 511 126407 Adaptive133Third130Node10 = false := by
  decide +kernel

#print axioms adaptive133Third130Proof10

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive133Third130Proof8 : runCachedNode 511 126407 Adaptive133Third130Node8 = false := by
  decide +kernel

#print axioms adaptive133Third130Proof8

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive133Third130Proof2 : runCachedNode 511 126407 Adaptive133Third130Node2 = false := by
  decide +kernel

#print axioms adaptive133Third130Proof2

end NineSeparatedSubsetSums
