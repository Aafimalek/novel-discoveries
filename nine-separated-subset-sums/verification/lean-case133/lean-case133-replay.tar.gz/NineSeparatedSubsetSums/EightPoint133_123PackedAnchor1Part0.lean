import NineSeparatedSubsetSums.EightPoint133_123PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint133_123PackedAnchor1Part0 :
    ∀ j : Fin 120, 2274070 ≤ FourPointNumeric.octPackedCharge 133 123 20 packedOct133_123_1
      (2*((j.val : Int)+0)+1) := by decide +kernel

end NineSeparatedSubsetSums
