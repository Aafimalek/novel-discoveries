import NineSeparatedSubsetSums.EightPoint133_121PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint133_121PackedAnchor1Part2 :
    ∀ j : Fin 2, 2308901 ≤ FourPointNumeric.octPackedCharge 133 121 20 packedOct133_121_1
      (2*((j.val : Int)+240)+1) := by decide +kernel

end NineSeparatedSubsetSums
