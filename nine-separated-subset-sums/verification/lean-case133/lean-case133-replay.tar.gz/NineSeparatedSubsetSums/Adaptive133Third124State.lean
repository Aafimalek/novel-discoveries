import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive133Third124Node0 : CachedSearchNode :=
  ⟨4, 123, computeCenteredMask [148,133,124], 405, 54969⟩

end NineSeparatedSubsetSums
