import NineSeparatedSubsetSums.Adaptive133Third109State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive133Third109Proof0 : runCachedNode 511 110552 Adaptive133Third109Node0 = false := by
  decide +kernel

#print axioms adaptive133Third109Proof0

end NineSeparatedSubsetSums
