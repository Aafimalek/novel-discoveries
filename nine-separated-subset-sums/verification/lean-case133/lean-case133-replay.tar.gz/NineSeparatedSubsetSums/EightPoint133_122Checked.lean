import NineSeparatedSubsetSums.EightPointPackedGeometry
import NineSeparatedSubsetSums.EightPoint133_122PackedBudget0
import NineSeparatedSubsetSums.EightPoint133_122PackedAnchor0Part0
import NineSeparatedSubsetSums.EightPoint133_122PackedAnchor0Part1
import NineSeparatedSubsetSums.EightPoint133_122PackedBudget1
import NineSeparatedSubsetSums.EightPoint133_122PackedAnchor1Part0
import NineSeparatedSubsetSums.EightPoint133_122PackedAnchor1Part1

namespace NineSeparatedSubsetSums

private theorem packedOct133_122Anchor0 :
  ∀ j : Fin 475, ((j.val : Int)+133+122)%2=0 →
    2240462 ≤ FourPointNumeric.octPackedCharge 133 122 20 packedOct133_122_0 (j.val : Int) := by
  intro j hj
  let k := (j.val-1)/2
  have hk : k < 237 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+1 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint133_122PackedAnchor0Part0 z
    rwa [he,hrep] at ht
  let z : Fin 117 := ⟨k-120, by omega⟩
  have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
  have ht := eightPoint133_122PackedAnchor0Part1 z
  rwa [he,hrep] at ht

private theorem packedOct133_122Anchor1 :
  ∀ j : Fin 475, ((j.val : Int)+133+122)%2=1 →
    2240498 ≤ FourPointNumeric.octPackedCharge 133 122 20 packedOct133_122_1 (j.val : Int) := by
  intro j hj
  let k := (j.val-0)/2
  have hk : k < 238 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+0 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint133_122PackedAnchor1Part0 z
    rwa [he,hrep] at ht
  let z : Fin 118 := ⟨k-120, by omega⟩
  have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
  have ht := eightPoint133_122PackedAnchor1Part1 z
  rwa [he,hrep] at ht

def packedOctCertificate133_122_0 : EightPointCertificate 133 122 0 124610 :=
  eightPointCertificateOfPacked 133 122 0 124610 2240462 20 packedOct133_122_0 263 475
    (by decide +kernel) (by decide) packedOct133_122Anchor0
    (by rw [packedOct133_122_0_budget]; decide)

def packedOctCertificate133_122_1 : EightPointCertificate 133 122 1 124610 :=
  eightPointCertificateOfPacked 133 122 1 124610 2240498 20 packedOct133_122_1 468 475
    (by decide +kernel) (by decide) packedOct133_122Anchor1
    (by rw [packedOct133_122_1_budget]; decide)

theorem max148_second133_third122_eightPoint_moment_bound (tail : List ℕ) (len : tail.length=6)
    (distinct : (natSubsetSums (148::133::122::tail)).Nodup) :
    124610 ≤ ((148::133::122::tail).map (· ^ 2)).sum := by
  apply eightPointNatMomentLower 133 122 124610 tail len distinct
  intro p hp
  by_cases h : p=0
  · subst p
    exact packedOctCertificate133_122_0
  · have he : p=1 := hp.resolve_left h
    subst p
    exact packedOctCertificate133_122_1

#print axioms max148_second133_third122_eightPoint_moment_bound

end NineSeparatedSubsetSums
