import NineSeparatedSubsetSums.EightPointPackedGeometry
import NineSeparatedSubsetSums.EightPoint133_117PackedBudget0
import NineSeparatedSubsetSums.EightPoint133_117PackedAnchor0Part0
import NineSeparatedSubsetSums.EightPoint133_117PackedAnchor0Part1
import NineSeparatedSubsetSums.EightPoint133_117PackedBudget1
import NineSeparatedSubsetSums.EightPoint133_117PackedAnchor1Part0
import NineSeparatedSubsetSums.EightPoint133_117PackedAnchor1Part1

namespace NineSeparatedSubsetSums

private theorem packedOct133_117Anchor0 :
  ∀ j : Fin 472, ((j.val : Int)+133+117)%2=0 →
    2203248 ≤ FourPointNumeric.octPackedCharge 133 117 20 packedOct133_117_0 (j.val : Int) := by
  intro j hj
  let k := (j.val-0)/2
  have hk : k < 236 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+0 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint133_117PackedAnchor0Part0 z
    rwa [he,hrep] at ht
  let z : Fin 116 := ⟨k-120, by omega⟩
  have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
  have ht := eightPoint133_117PackedAnchor0Part1 z
  rwa [he,hrep] at ht

private theorem packedOct133_117Anchor1 :
  ∀ j : Fin 472, ((j.val : Int)+133+117)%2=1 →
    2204310 ≤ FourPointNumeric.octPackedCharge 133 117 20 packedOct133_117_1 (j.val : Int) := by
  intro j hj
  let k := (j.val-1)/2
  have hk : k < 236 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+1 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint133_117PackedAnchor1Part0 z
    rwa [he,hrep] at ht
  let z : Fin 116 := ⟨k-120, by omega⟩
  have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
  have ht := eightPoint133_117PackedAnchor1Part1 z
  rwa [he,hrep] at ht

def packedOctCertificate133_117_0 : EightPointCertificate 133 117 0 123918 :=
  eightPointCertificateOfPacked 133 117 0 123918 2203248 20 packedOct133_117_0 269 472
    (by decide +kernel) (by decide) packedOct133_117Anchor0
    (by rw [packedOct133_117_0_budget]; decide)

def packedOctCertificate133_117_1 : EightPointCertificate 133 117 1 123918 :=
  eightPointCertificateOfPacked 133 117 1 123918 2204310 20 packedOct133_117_1 400 472
    (by decide +kernel) (by decide) packedOct133_117Anchor1
    (by rw [packedOct133_117_1_budget]; decide)

theorem max148_second133_third117_eightPoint_moment_bound (tail : List ℕ) (len : tail.length=6)
    (distinct : (natSubsetSums (148::133::117::tail)).Nodup) :
    123918 ≤ ((148::133::117::tail).map (· ^ 2)).sum := by
  apply eightPointNatMomentLower 133 117 123918 tail len distinct
  intro p hp
  by_cases h : p=0
  · subst p
    exact packedOctCertificate133_117_0
  · have he : p=1 := hp.resolve_left h
    subst p
    exact packedOctCertificate133_117_1

#print axioms max148_second133_third117_eightPoint_moment_bound

end NineSeparatedSubsetSums
