import NineSeparatedSubsetSums.Adaptive133Third112Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint133Checked

namespace NineSeparatedSubsetSums


theorem adaptive133Third112 : NoDescendingTailAfterThird 133 112 :=
  noDescendingThirdTail_of_cached 133 112 110552 (fun t ht nd => max148_second133_fourPoint_moment_bound (112::t) (by simp [ht]) nd) adaptive133Third112Proof0

#print axioms adaptive133Third112

end NineSeparatedSubsetSums
