import NineSeparatedSubsetSums.EightPoint133_126PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint133_126PackedAnchor0Part2 :
    ∀ j : Fin 3, 2328941 ≤ FourPointNumeric.octPackedCharge 133 126 20 packedOct133_126_0
      (2*((j.val : Int)+240)+1) := by decide +kernel

end NineSeparatedSubsetSums
