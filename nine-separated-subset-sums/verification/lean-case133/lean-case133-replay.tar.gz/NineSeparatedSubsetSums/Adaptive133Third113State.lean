import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive133Third113Node0 : CachedSearchNode :=
  ⟨4, 112, computeCenteredMask [148,133,113], 394, 52362⟩

end NineSeparatedSubsetSums
