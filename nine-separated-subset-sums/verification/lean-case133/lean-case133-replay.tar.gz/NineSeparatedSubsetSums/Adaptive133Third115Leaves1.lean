import NineSeparatedSubsetSums.Adaptive133Third115State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive133Third115Proof7 : runCachedNode 511 110552 Adaptive133Third115Node7 = false := by
  decide +kernel

#print axioms adaptive133Third115Proof7

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive133Third115Proof6 : runCachedNode 511 110552 Adaptive133Third115Node6 = false := by
  decide +kernel

#print axioms adaptive133Third115Proof6

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive133Third115Proof4 : runCachedNode 511 110552 Adaptive133Third115Node4 = false := by
  decide +kernel

#print axioms adaptive133Third115Proof4

end NineSeparatedSubsetSums
