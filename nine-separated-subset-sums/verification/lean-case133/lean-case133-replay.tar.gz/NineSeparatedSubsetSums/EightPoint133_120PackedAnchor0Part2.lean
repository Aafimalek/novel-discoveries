import NineSeparatedSubsetSums.EightPoint133_120PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint133_120PackedAnchor0Part2 :
    ∀ j : Fin 1, 2286047 ≤ FourPointNumeric.octPackedCharge 133 120 20 packedOct133_120_0
      (2*((j.val : Int)+240)+1) := by decide +kernel

end NineSeparatedSubsetSums
