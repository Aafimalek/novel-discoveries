import NineSeparatedSubsetSums.EightPoint133_117PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint133_117PackedAnchor0Part0 :
    ∀ j : Fin 120, 2203248 ≤ FourPointNumeric.octPackedCharge 133 117 20 packedOct133_117_0
      (2*((j.val : Int)+0)+0) := by decide +kernel

end NineSeparatedSubsetSums
