import NineSeparatedSubsetSums.EightPoint133_131PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint133_131PackedAnchor0Part0 :
    ∀ j : Fin 120, 2377993 ≤ FourPointNumeric.octPackedCharge 133 131 20 packedOct133_131_0
      (2*((j.val : Int)+0)+0) := by decide +kernel

end NineSeparatedSubsetSums
