import NineSeparatedSubsetSums.Adaptive133Third105Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint133Checked

namespace NineSeparatedSubsetSums


theorem adaptive133Third105 : NoDescendingTailAfterThird 133 105 :=
  noDescendingThirdTail_of_cached 133 105 110552 (fun t ht nd => max148_second133_fourPoint_moment_bound (105::t) (by simp [ht]) nd) adaptive133Third105Proof0

#print axioms adaptive133Third105

end NineSeparatedSubsetSums
