import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive133Third111Node0 : CachedSearchNode :=
  ⟨4, 110, computeCenteredMask [148,133,111], 392, 51914⟩

end NineSeparatedSubsetSums
