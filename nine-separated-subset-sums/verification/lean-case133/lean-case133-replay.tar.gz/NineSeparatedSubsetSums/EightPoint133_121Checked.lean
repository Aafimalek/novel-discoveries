import NineSeparatedSubsetSums.EightPointPackedGeometry
import NineSeparatedSubsetSums.EightPoint133_121PackedBudget0
import NineSeparatedSubsetSums.EightPoint133_121PackedAnchor0Part0
import NineSeparatedSubsetSums.EightPoint133_121PackedAnchor0Part1
import NineSeparatedSubsetSums.EightPoint133_121PackedAnchor0Part2
import NineSeparatedSubsetSums.EightPoint133_121PackedBudget1
import NineSeparatedSubsetSums.EightPoint133_121PackedAnchor1Part0
import NineSeparatedSubsetSums.EightPoint133_121PackedAnchor1Part1
import NineSeparatedSubsetSums.EightPoint133_121PackedAnchor1Part2

namespace NineSeparatedSubsetSums

private theorem packedOct133_121Anchor0 :
  ∀ j : Fin 485, ((j.val : Int)+133+121)%2=0 →
    2311788 ≤ FourPointNumeric.octPackedCharge 133 121 20 packedOct133_121_0 (j.val : Int) := by
  intro j hj
  let k := (j.val-0)/2
  have hk : k < 243 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+0 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint133_121PackedAnchor0Part0 z
    rwa [he,hrep] at ht
  by_cases h1 : k < 240
  · let z : Fin 120 := ⟨k-120, by omega⟩
    have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
    have ht := eightPoint133_121PackedAnchor0Part1 z
    rwa [he,hrep] at ht
  let z : Fin 3 := ⟨k-240, by omega⟩
  have he : (z.val : Int)+240 = k := by dsimp [z] <;> omega
  have ht := eightPoint133_121PackedAnchor0Part2 z
  rwa [he,hrep] at ht

private theorem packedOct133_121Anchor1 :
  ∀ j : Fin 485, ((j.val : Int)+133+121)%2=1 →
    2308901 ≤ FourPointNumeric.octPackedCharge 133 121 20 packedOct133_121_1 (j.val : Int) := by
  intro j hj
  let k := (j.val-1)/2
  have hk : k < 242 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+1 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint133_121PackedAnchor1Part0 z
    rwa [he,hrep] at ht
  by_cases h1 : k < 240
  · let z : Fin 120 := ⟨k-120, by omega⟩
    have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
    have ht := eightPoint133_121PackedAnchor1Part1 z
    rwa [he,hrep] at ht
  let z : Fin 2 := ⟨k-240, by omega⟩
  have he : (z.val : Int)+240 = k := by dsimp [z] <;> omega
  have ht := eightPoint133_121PackedAnchor1Part2 z
  rwa [he,hrep] at ht

def packedOctCertificate133_121_0 : EightPointCertificate 133 121 0 124344 :=
  eightPointCertificateOfPacked 133 121 0 124344 2311788 20 packedOct133_121_0 267 485
    (by decide +kernel) (by decide) packedOct133_121Anchor0
    (by rw [packedOct133_121_0_budget]; decide)

def packedOctCertificate133_121_1 : EightPointCertificate 133 121 1 124344 :=
  eightPointCertificateOfPacked 133 121 1 124344 2308901 20 packedOct133_121_1 266 485
    (by decide +kernel) (by decide) packedOct133_121Anchor1
    (by rw [packedOct133_121_1_budget]; decide)

theorem max148_second133_third121_eightPoint_moment_bound (tail : List ℕ) (len : tail.length=6)
    (distinct : (natSubsetSums (148::133::121::tail)).Nodup) :
    124344 ≤ ((148::133::121::tail).map (· ^ 2)).sum := by
  apply eightPointNatMomentLower 133 121 124344 tail len distinct
  intro p hp
  by_cases h : p=0
  · subst p
    exact packedOctCertificate133_121_0
  · have he : p=1 := hp.resolve_left h
    subst p
    exact packedOctCertificate133_121_1

#print axioms max148_second133_third121_eightPoint_moment_bound

end NineSeparatedSubsetSums
