import NineSeparatedSubsetSums.Adaptive133Third119State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive133Third119Proof0 : runCachedNode 511 124216 Adaptive133Third119Node0 = false := by
  decide +kernel

#print axioms adaptive133Third119Proof0

end NineSeparatedSubsetSums
