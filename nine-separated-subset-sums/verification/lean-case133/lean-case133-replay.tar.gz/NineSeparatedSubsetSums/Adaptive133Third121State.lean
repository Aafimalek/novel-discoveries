import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive133Third121Node0 : CachedSearchNode :=
  ⟨4, 120, computeCenteredMask [148,133,121], 402, 54234⟩

end NineSeparatedSubsetSums
