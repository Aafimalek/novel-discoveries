import NineSeparatedSubsetSums.EightPoint133_124PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct133_124_1_budget :
    FourPointNumeric.packedBudget 20 packedOct133_124_1 464 = 81937766 := by decide +kernel

#print axioms packedOct133_124_1_budget

end NineSeparatedSubsetSums
