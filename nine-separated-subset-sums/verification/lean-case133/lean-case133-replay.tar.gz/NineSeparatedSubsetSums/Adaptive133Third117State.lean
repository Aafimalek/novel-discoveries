import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive133Third117Node0 : CachedSearchNode :=
  ⟨4, 116, computeCenteredMask [148,133,117], 398, 53282⟩

end NineSeparatedSubsetSums
