import NineSeparatedSubsetSums.EightPoint133_128PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct133_128_0_budget :
    FourPointNumeric.packedBudget 20 packedOct133_128_0 447 = 84076164 := by decide +kernel

#print axioms packedOct133_128_0_budget

end NineSeparatedSubsetSums
