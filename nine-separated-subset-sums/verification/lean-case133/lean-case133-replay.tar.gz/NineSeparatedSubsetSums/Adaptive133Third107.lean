import NineSeparatedSubsetSums.Adaptive133Third107Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint133Checked

namespace NineSeparatedSubsetSums


theorem adaptive133Third107 : NoDescendingTailAfterThird 133 107 :=
  noDescendingThirdTail_of_cached 133 107 110552 (fun t ht nd => max148_second133_fourPoint_moment_bound (107::t) (by simp [ht]) nd) adaptive133Third107Proof0

#print axioms adaptive133Third107

end NineSeparatedSubsetSums
