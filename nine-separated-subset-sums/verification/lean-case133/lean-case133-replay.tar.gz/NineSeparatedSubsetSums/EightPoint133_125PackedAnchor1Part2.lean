import NineSeparatedSubsetSums.EightPoint133_125PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint133_125PackedAnchor1Part2 :
    ∀ j : Fin 1, 2302200 ≤ FourPointNumeric.octPackedCharge 133 125 20 packedOct133_125_1
      (2*((j.val : Int)+240)+1) := by decide +kernel

end NineSeparatedSubsetSums
