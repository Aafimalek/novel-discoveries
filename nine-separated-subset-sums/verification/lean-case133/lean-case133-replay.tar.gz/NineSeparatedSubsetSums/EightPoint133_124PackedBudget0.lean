import NineSeparatedSubsetSums.EightPoint133_124PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct133_124_0_budget :
    FourPointNumeric.packedBudget 20 packedOct133_124_0 403 = 81943053 := by decide +kernel

#print axioms packedOct133_124_0_budget

end NineSeparatedSubsetSums
