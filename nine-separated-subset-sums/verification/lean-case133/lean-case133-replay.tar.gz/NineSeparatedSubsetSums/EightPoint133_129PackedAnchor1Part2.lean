import NineSeparatedSubsetSums.EightPoint133_129PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint133_129PackedAnchor1Part2 :
    ∀ j : Fin 3, 2341094 ≤ FourPointNumeric.octPackedCharge 133 129 20 packedOct133_129_1
      (2*((j.val : Int)+240)+1) := by decide +kernel

end NineSeparatedSubsetSums
