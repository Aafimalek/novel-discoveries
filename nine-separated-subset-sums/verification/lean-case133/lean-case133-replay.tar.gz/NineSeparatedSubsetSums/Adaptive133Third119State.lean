import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive133Third119Node0 : CachedSearchNode :=
  ⟨4, 118, computeCenteredMask [148,133,119], 400, 53754⟩

end NineSeparatedSubsetSums
