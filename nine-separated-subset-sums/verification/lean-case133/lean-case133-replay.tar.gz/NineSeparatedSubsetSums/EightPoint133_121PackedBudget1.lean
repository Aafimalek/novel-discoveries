import NineSeparatedSubsetSums.EightPoint133_121PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct133_121_1_budget :
    FourPointNumeric.packedBudget 20 packedOct133_121_1 266 = 84105938 := by decide +kernel

#print axioms packedOct133_121_1_budget

end NineSeparatedSubsetSums
