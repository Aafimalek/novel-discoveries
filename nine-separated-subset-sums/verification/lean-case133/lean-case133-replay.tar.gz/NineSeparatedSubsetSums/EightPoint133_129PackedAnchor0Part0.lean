import NineSeparatedSubsetSums.EightPoint133_129PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint133_129PackedAnchor0Part0 :
    ∀ j : Fin 120, 2339463 ≤ FourPointNumeric.octPackedCharge 133 129 20 packedOct133_129_0
      (2*((j.val : Int)+0)+0) := by decide +kernel

end NineSeparatedSubsetSums
