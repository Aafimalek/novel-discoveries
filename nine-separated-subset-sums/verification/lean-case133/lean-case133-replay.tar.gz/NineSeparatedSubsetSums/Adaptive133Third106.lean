import NineSeparatedSubsetSums.Adaptive133Third106Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint133Checked

namespace NineSeparatedSubsetSums


theorem adaptive133Third106 : NoDescendingTailAfterThird 133 106 :=
  noDescendingThirdTail_of_cached 133 106 110552 (fun t ht nd => max148_second133_fourPoint_moment_bound (106::t) (by simp [ht]) nd) adaptive133Third106Proof0

#print axioms adaptive133Third106

end NineSeparatedSubsetSums
