import NineSeparatedSubsetSums.EightPoint133_117PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint133_117PackedAnchor1Part0 :
    ∀ j : Fin 120, 2204310 ≤ FourPointNumeric.octPackedCharge 133 117 20 packedOct133_117_1
      (2*((j.val : Int)+0)+1) := by decide +kernel

end NineSeparatedSubsetSums
