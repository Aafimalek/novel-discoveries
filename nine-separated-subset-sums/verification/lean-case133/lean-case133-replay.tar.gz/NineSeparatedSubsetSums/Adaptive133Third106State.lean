import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive133Third106Node0 : CachedSearchNode :=
  ⟨4, 105, computeCenteredMask [148,133,106], 387, 50829⟩

end NineSeparatedSubsetSums
