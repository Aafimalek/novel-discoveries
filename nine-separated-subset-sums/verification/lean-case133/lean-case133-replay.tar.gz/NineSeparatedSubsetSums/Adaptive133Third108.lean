import NineSeparatedSubsetSums.Adaptive133Third108Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint133Checked

namespace NineSeparatedSubsetSums


theorem adaptive133Third108 : NoDescendingTailAfterThird 133 108 :=
  noDescendingThirdTail_of_cached 133 108 110552 (fun t ht nd => max148_second133_fourPoint_moment_bound (108::t) (by simp [ht]) nd) adaptive133Third108Proof0

#print axioms adaptive133Third108

end NineSeparatedSubsetSums
