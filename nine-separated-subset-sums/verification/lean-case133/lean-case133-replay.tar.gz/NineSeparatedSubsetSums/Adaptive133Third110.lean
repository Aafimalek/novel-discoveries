import NineSeparatedSubsetSums.Adaptive133Third110Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint133Checked

namespace NineSeparatedSubsetSums


theorem adaptive133Third110 : NoDescendingTailAfterThird 133 110 :=
  noDescendingThirdTail_of_cached 133 110 110552 (fun t ht nd => max148_second133_fourPoint_moment_bound (110::t) (by simp [ht]) nd) adaptive133Third110Proof0

#print axioms adaptive133Third110

end NineSeparatedSubsetSums
