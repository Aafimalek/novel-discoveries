import NineSeparatedSubsetSums.EightPoint133_122PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct133_122_0_budget :
    FourPointNumeric.packedBudget 20 packedOct133_122_0 263 = 79589350 := by decide +kernel

#print axioms packedOct133_122_0_budget

end NineSeparatedSubsetSums
