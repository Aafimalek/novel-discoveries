import NineSeparatedSubsetSums.FourPoint133PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem fourPoint133PackedAnchor0Part1 :
    ∀ j : Fin 116, 1047000 ≤ FourPointNumeric.packedCharge 133 20 packedWeight133_0
      (2*((j.val : Int)+120)+1) := by decide +kernel

end NineSeparatedSubsetSums
