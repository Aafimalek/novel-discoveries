import NineSeparatedSubsetSums.EightPoint133_118PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint133_118PackedAnchor1Part1 :
    ∀ j : Fin 118, 2239246 ≤ FourPointNumeric.octPackedCharge 133 118 20 packedOct133_118_1
      (2*((j.val : Int)+120)+0) := by decide +kernel

end NineSeparatedSubsetSums
