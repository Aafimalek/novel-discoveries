import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive133Third105Node0 : CachedSearchNode :=
  ⟨4, 104, computeCenteredMask [148,133,105], 386, 50618⟩

end NineSeparatedSubsetSums
