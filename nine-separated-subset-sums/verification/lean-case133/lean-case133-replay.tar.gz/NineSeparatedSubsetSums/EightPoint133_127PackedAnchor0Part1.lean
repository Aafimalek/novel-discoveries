import NineSeparatedSubsetSums.EightPoint133_127PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint133_127PackedAnchor0Part1 :
    ∀ j : Fin 120, 2326084 ≤ FourPointNumeric.octPackedCharge 133 127 20 packedOct133_127_0
      (2*((j.val : Int)+120)+0) := by decide +kernel

end NineSeparatedSubsetSums
