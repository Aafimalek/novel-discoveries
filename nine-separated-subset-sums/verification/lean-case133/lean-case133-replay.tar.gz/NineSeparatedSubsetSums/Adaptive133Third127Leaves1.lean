import NineSeparatedSubsetSums.Adaptive133Third127State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive133Third127Proof6 : runCachedNode 511 126028 Adaptive133Third127Node6 = false := by
  decide +kernel

#print axioms adaptive133Third127Proof6

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive133Third127Proof5 : runCachedNode 511 126028 Adaptive133Third127Node5 = false := by
  decide +kernel

#print axioms adaptive133Third127Proof5

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive133Third127Proof2 : runCachedNode 511 126028 Adaptive133Third127Node2 = false := by
  decide +kernel

#print axioms adaptive133Third127Proof2

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive133Third127Proof1 : runCachedNode 511 126028 Adaptive133Third127Node1 = false := by
  decide +kernel

#print axioms adaptive133Third127Proof1

end NineSeparatedSubsetSums
