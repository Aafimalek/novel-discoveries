import NineSeparatedSubsetSums.Adaptive133Third113Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint133Checked

namespace NineSeparatedSubsetSums


theorem adaptive133Third113 : NoDescendingTailAfterThird 133 113 :=
  noDescendingThirdTail_of_cached 133 113 110552 (fun t ht nd => max148_second133_fourPoint_moment_bound (113::t) (by simp [ht]) nd) adaptive133Third113Proof0

#print axioms adaptive133Third113

end NineSeparatedSubsetSums
