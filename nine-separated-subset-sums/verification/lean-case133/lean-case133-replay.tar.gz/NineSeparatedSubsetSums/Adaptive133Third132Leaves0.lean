import NineSeparatedSubsetSums.Adaptive133Third132State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive133Third132Proof20 : runCachedNode 511 126862 Adaptive133Third132Node20 = false := by
  decide +kernel

#print axioms adaptive133Third132Proof20

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive133Third132Proof11 : runCachedNode 511 126862 Adaptive133Third132Node11 = false := by
  decide +kernel

#print axioms adaptive133Third132Proof11

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive133Third132Proof5 : runCachedNode 511 126862 Adaptive133Third132Node5 = false := by
  decide +kernel

#print axioms adaptive133Third132Proof5

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive133Third132Proof3 : runCachedNode 511 126862 Adaptive133Third132Node3 = false := by
  decide +kernel

#print axioms adaptive133Third132Proof3

end NineSeparatedSubsetSums
