import NineSeparatedSubsetSums.EightPointPackedGeometry
import NineSeparatedSubsetSums.EightPoint133_118PackedBudget0
import NineSeparatedSubsetSums.EightPoint133_118PackedAnchor0Part0
import NineSeparatedSubsetSums.EightPoint133_118PackedAnchor0Part1
import NineSeparatedSubsetSums.EightPoint133_118PackedBudget1
import NineSeparatedSubsetSums.EightPoint133_118PackedAnchor1Part0
import NineSeparatedSubsetSums.EightPoint133_118PackedAnchor1Part1

namespace NineSeparatedSubsetSums

private theorem packedOct133_118Anchor0 :
  ∀ j : Fin 476, ((j.val : Int)+133+118)%2=0 →
    2239778 ≤ FourPointNumeric.octPackedCharge 133 118 20 packedOct133_118_0 (j.val : Int) := by
  intro j hj
  let k := (j.val-1)/2
  have hk : k < 238 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+1 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint133_118PackedAnchor0Part0 z
    rwa [he,hrep] at ht
  let z : Fin 118 := ⟨k-120, by omega⟩
  have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
  have ht := eightPoint133_118PackedAnchor0Part1 z
  rwa [he,hrep] at ht

private theorem packedOct133_118Anchor1 :
  ∀ j : Fin 476, ((j.val : Int)+133+118)%2=1 →
    2239246 ≤ FourPointNumeric.octPackedCharge 133 118 20 packedOct133_118_1 (j.val : Int) := by
  intro j hj
  let k := (j.val-0)/2
  have hk : k < 238 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+0 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint133_118PackedAnchor1Part0 z
    rwa [he,hrep] at ht
  let z : Fin 118 := ⟨k-120, by omega⟩
  have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
  have ht := eightPoint133_118PackedAnchor1Part1 z
  rwa [he,hrep] at ht

def packedOctCertificate133_118_0 : EightPointCertificate 133 118 0 124076 :=
  eightPointCertificateOfPacked 133 118 0 124076 2239778 20 packedOct133_118_0 267 476
    (by decide +kernel) (by decide) packedOct133_118Anchor0
    (by rw [packedOct133_118_0_budget]; decide)

def packedOctCertificate133_118_1 : EightPointCertificate 133 118 1 124076 :=
  eightPointCertificateOfPacked 133 118 1 124076 2239246 20 packedOct133_118_1 266 476
    (by decide +kernel) (by decide) packedOct133_118Anchor1
    (by rw [packedOct133_118_1_budget]; decide)

theorem max148_second133_third118_eightPoint_moment_bound (tail : List ℕ) (len : tail.length=6)
    (distinct : (natSubsetSums (148::133::118::tail)).Nodup) :
    124076 ≤ ((148::133::118::tail).map (· ^ 2)).sum := by
  apply eightPointNatMomentLower 133 118 124076 tail len distinct
  intro p hp
  by_cases h : p=0
  · subst p
    exact packedOctCertificate133_118_0
  · have he : p=1 := hp.resolve_left h
    subst p
    exact packedOctCertificate133_118_1

#print axioms max148_second133_third118_eightPoint_moment_bound

end NineSeparatedSubsetSums
