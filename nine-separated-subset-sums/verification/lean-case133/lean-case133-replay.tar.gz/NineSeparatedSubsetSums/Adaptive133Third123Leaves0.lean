import NineSeparatedSubsetSums.Adaptive133Third123State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive133Third123Proof0 : runCachedNode 511 124938 Adaptive133Third123Node0 = false := by
  decide +kernel

#print axioms adaptive133Third123Proof0

end NineSeparatedSubsetSums
