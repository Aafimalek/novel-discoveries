import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive133Third122Node0 : CachedSearchNode :=
  ⟨4, 121, computeCenteredMask [148,133,122], 403, 54477⟩

end NineSeparatedSubsetSums
