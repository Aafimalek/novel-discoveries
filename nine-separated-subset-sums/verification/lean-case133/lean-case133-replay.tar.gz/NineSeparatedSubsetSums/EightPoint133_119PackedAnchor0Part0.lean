import NineSeparatedSubsetSums.EightPoint133_119PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint133_119PackedAnchor0Part0 :
    ∀ j : Fin 120, 2275100 ≤ FourPointNumeric.octPackedCharge 133 119 20 packedOct133_119_0
      (2*((j.val : Int)+0)+0) := by decide +kernel

end NineSeparatedSubsetSums
