import NineSeparatedSubsetSums.EightPoint133_121PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct133_121_0_budget :
    FourPointNumeric.packedBudget 20 packedOct133_121_0 267 = 84290496 := by decide +kernel

#print axioms packedOct133_121_0_budget

end NineSeparatedSubsetSums
