import NineSeparatedSubsetSums.EightPoint133_130PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint133_130PackedAnchor0Part1 :
    ∀ j : Fin 120, 2360499 ≤ FourPointNumeric.octPackedCharge 133 130 20 packedOct133_130_0
      (2*((j.val : Int)+120)+1) := by decide +kernel

end NineSeparatedSubsetSums
