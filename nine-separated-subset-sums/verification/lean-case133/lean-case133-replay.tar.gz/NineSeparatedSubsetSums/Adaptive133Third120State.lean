import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive133Third120Node0 : CachedSearchNode :=
  ⟨4, 119, computeCenteredMask [148,133,120], 401, 53993⟩

end NineSeparatedSubsetSums
