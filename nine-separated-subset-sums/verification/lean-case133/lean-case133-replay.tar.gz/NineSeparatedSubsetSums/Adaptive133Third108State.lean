import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive133Third108Node0 : CachedSearchNode :=
  ⟨4, 107, computeCenteredMask [148,133,108], 389, 51257⟩

end NineSeparatedSubsetSums
