import NineSeparatedSubsetSums.Adaptive133Third116State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive133Third116Proof14 : runCachedNode 511 110552 Adaptive133Third116Node14 = false := by
  decide +kernel

#print axioms adaptive133Third116Proof14

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive133Third116Proof13 : runCachedNode 511 110552 Adaptive133Third116Node13 = false := by
  decide +kernel

#print axioms adaptive133Third116Proof13

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive133Third116Proof12 : runCachedNode 511 110552 Adaptive133Third116Node12 = false := by
  decide +kernel

#print axioms adaptive133Third116Proof12

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive133Third116Proof11 : runCachedNode 511 110552 Adaptive133Third116Node11 = false := by
  decide +kernel

#print axioms adaptive133Third116Proof11

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive133Third116Proof7 : runCachedNode 511 110552 Adaptive133Third116Node7 = false := by
  decide +kernel

#print axioms adaptive133Third116Proof7

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive133Third116Proof2 : runCachedNode 511 110552 Adaptive133Third116Node2 = false := by
  decide +kernel

#print axioms adaptive133Third116Proof2

end NineSeparatedSubsetSums
