import NineSeparatedSubsetSums.EightPoint133_128PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint133_128PackedAnchor0Part1 :
    ∀ j : Fin 120, 2322718 ≤ FourPointNumeric.octPackedCharge 133 128 20 packedOct133_128_0
      (2*((j.val : Int)+120)+1) := by decide +kernel

end NineSeparatedSubsetSums
