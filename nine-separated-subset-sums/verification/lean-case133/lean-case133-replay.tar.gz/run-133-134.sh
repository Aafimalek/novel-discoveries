#!/usr/bin/env bash
set -eu
cd /tmp/nine-149-next
source env.sh
exec 9>.adaptive-sequential-124-127.lock
flock -n 9 || { echo 'Sequential queue already active'; exit 75; }
first=${1:-133}
[[ "$first" =~ ^(133|134)$ ]] || exit 64
for ((a=first; a<=134; ++a)); do
  free=$(df -Pm /tmp | awk 'NR==2 {print $4}')
  if ((free < 600)); then
    echo "$(date -Iseconds) STOP SHELF $a: /tmp free ${free} MiB < 600 MiB"
    exit 74
  fi
  m="adaptive-$a-full.json"
  log="adaptive-$a-full-run.log"
  if [[ -e "$log" ]]; then
    cp -p "$log" "$log.prior-$(date +%s)"
  fi
  echo "$(date -Iseconds) START SHELF $a (${free} MiB free on /tmp)"
  if [[ ! -e "$m" ]]; then
    python make-adaptive-shelves.py "$a" --cost 1600 --oct-cost 3000 --out "$m" ||
      { echo "$(date -Iseconds) GENERATOR FAILED $a"; exit 1; }
  fi
  rc=0
  timeout --kill-after=10 1800 python -u run-adaptive-queue-guarded.py "$m" \
    --lean "$LEAN" --jobs 1 --seconds 125 --memory 2850 --min-free-mib 400 >"$log" 2>&1 || rc=$?
  echo "$(date -Iseconds) EXIT SHELF $a $rc"
  tail -n 4 "$log"
  if ((rc != 0)); then exit "$rc"; fi
  [[ "$(tail -n 1 "$log")" == "VERIFIED SHELF $a: AdaptiveShelf$a" ]] || exit 1
  cat >"AuditShelf$a.lean" <<AUDIT
import NineSeparatedSubsetSums.AdaptiveShelf$a
example : NineSeparatedSubsetSums.NoDescendingTail $a :=
  NineSeparatedSubsetSums.adaptiveShelf${a}_no_descending_tail
#print axioms NineSeparatedSubsetSums.adaptiveShelf${a}_no_descending_tail
AUDIT
  timeout --kill-after=5 125 "$LEAN" -j 1 -M 2850 "AuditShelf$a.lean" >"AuditShelf$a.log" 2>&1
  python stage-verified-adaptive.py "$a"
  out="/tmp/nine149-verified-through$a"
  cp run-adaptive-queue-guarded.py run-133-134.sh "$out/"
  (cd "$out"; sha256sum run-adaptive-queue-guarded.py run-133-134.sh >> SHA256SUMS;
    sha256sum -c SHA256SUMS >"/tmp/nine149-stage$a-integrity.log")
  echo "$(date -Iseconds) ARCHIVED AND AUDITED SHELF $a ($out)"
done
