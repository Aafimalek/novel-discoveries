import NineSeparatedSubsetSums.EightPoint131_128PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct131_128_1_budget :
    FourPointNumeric.packedBudget 20 packedOct131_128_1 450 = 84026070 := by decide +kernel

#print axioms packedOct131_128_1_budget

end NineSeparatedSubsetSums
