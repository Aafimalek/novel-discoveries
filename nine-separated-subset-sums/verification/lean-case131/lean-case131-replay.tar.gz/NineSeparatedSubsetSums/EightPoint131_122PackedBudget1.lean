import NineSeparatedSubsetSums.EightPoint131_122PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct131_122_1_budget :
    FourPointNumeric.packedBudget 20 packedOct131_122_1 482 = 83306822 := by decide +kernel

#print axioms packedOct131_122_1_budget

end NineSeparatedSubsetSums
