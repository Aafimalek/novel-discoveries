import NineSeparatedSubsetSums.Adaptive131Third115State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive131Third115Proof14 : runCachedNode 511 109968 Adaptive131Third115Node14 = false := by
  decide +kernel

#print axioms adaptive131Third115Proof14

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive131Third115Proof13 : runCachedNode 511 109968 Adaptive131Third115Node13 = false := by
  decide +kernel

#print axioms adaptive131Third115Proof13

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive131Third115Proof12 : runCachedNode 511 109968 Adaptive131Third115Node12 = false := by
  decide +kernel

#print axioms adaptive131Third115Proof12

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive131Third115Proof11 : runCachedNode 511 109968 Adaptive131Third115Node11 = false := by
  decide +kernel

#print axioms adaptive131Third115Proof11

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive131Third115Proof8 : runCachedNode 511 109968 Adaptive131Third115Node8 = false := by
  decide +kernel

#print axioms adaptive131Third115Proof8

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive131Third115Proof3 : runCachedNode 511 109968 Adaptive131Third115Node3 = false := by
  decide +kernel

#print axioms adaptive131Third115Proof3

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive131Third115Proof2 : runCachedNode 511 109968 Adaptive131Third115Node2 = false := by
  decide +kernel

#print axioms adaptive131Third115Proof2

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive131Third115Proof1 : runCachedNode 511 109968 Adaptive131Third115Node1 = false := by
  decide +kernel

#print axioms adaptive131Third115Proof1

end NineSeparatedSubsetSums
