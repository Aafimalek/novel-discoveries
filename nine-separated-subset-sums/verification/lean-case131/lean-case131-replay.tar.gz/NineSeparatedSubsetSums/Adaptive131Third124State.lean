import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive131Third124Node0 : CachedSearchNode :=
  ⟨4, 123, computeCenteredMask [148,131,124], 403, 54441⟩

end NineSeparatedSubsetSums
