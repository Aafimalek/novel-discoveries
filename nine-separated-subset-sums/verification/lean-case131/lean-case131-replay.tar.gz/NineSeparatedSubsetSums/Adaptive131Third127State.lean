import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive131Third127Node0 : CachedSearchNode :=
  ⟨4, 126, computeCenteredMask [148,131,127], 406, 55194⟩

end NineSeparatedSubsetSums
