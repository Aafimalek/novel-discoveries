import NineSeparatedSubsetSums.EightPoint131_123PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint131_123PackedAnchor0Part1 :
    ∀ j : Fin 120, 2310903 ≤ FourPointNumeric.octPackedCharge 131 123 20 packedOct131_123_0
      (2*((j.val : Int)+120)+0) := by decide +kernel

end NineSeparatedSubsetSums
