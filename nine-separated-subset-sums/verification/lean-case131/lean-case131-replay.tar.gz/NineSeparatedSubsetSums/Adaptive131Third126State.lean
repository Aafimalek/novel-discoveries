import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive131Third126Node0 : CachedSearchNode :=
  ⟨4, 125, computeCenteredMask [148,131,126], 405, 54941⟩

end NineSeparatedSubsetSums
