import NineSeparatedSubsetSums.EightPoint131_118PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint131_118PackedAnchor1Part1 :
    ∀ j : Fin 115, 2184057 ≤ FourPointNumeric.octPackedCharge 131 118 20 packedOct131_118_1
      (2*((j.val : Int)+120)+0) := by decide +kernel

end NineSeparatedSubsetSums
