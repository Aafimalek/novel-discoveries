import NineSeparatedSubsetSums.EightPoint131_124PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct131_124_0_budget :
    FourPointNumeric.packedBudget 20 packedOct131_124_0 391 = 84103359 := by decide +kernel

#print axioms packedOct131_124_0_budget

end NineSeparatedSubsetSums
