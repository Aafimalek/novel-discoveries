import NineSeparatedSubsetSums.EightPoint131_118PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct131_118_0_budget :
    FourPointNumeric.packedBudget 20 packedOct131_118_0 273 = 76486599 := by decide +kernel

#print axioms packedOct131_118_0_budget

end NineSeparatedSubsetSums
