import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive131Third106Node0 : CachedSearchNode :=
  ⟨4, 105, computeCenteredMask [148,131,106], 385, 50301⟩

end NineSeparatedSubsetSums
