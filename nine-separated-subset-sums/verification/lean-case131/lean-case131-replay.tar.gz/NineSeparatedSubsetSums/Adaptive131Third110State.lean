import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive131Third110Node0 : CachedSearchNode :=
  ⟨4, 109, computeCenteredMask [148,131,110], 389, 51165⟩

end NineSeparatedSubsetSums
