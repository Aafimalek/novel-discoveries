import NineSeparatedSubsetSums.EightPoint131_130PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct131_130_0_budget :
    FourPointNumeric.packedBudget 20 packedOct131_130_0 381 = 85405208 := by decide +kernel

#print axioms packedOct131_130_0_budget

end NineSeparatedSubsetSums
