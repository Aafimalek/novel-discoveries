import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive131Third109Node0 : CachedSearchNode :=
  ⟨4, 108, computeCenteredMask [148,131,109], 388, 50946⟩

end NineSeparatedSubsetSums
