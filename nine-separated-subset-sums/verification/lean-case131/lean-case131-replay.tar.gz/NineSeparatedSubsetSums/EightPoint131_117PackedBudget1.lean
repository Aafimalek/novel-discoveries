import NineSeparatedSubsetSums.EightPoint131_117PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct131_117_1_budget :
    FourPointNumeric.packedBudget 20 packedOct131_117_1 454 = 75632832 := by decide +kernel

#print axioms packedOct131_117_1_budget

end NineSeparatedSubsetSums
