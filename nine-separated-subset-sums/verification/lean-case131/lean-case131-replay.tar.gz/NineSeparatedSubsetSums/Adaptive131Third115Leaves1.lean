import NineSeparatedSubsetSums.Adaptive131Third115State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive131Third115Proof10 : runCachedNode 511 109968 Adaptive131Third115Node10 = false := by
  decide +kernel

#print axioms adaptive131Third115Proof10

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive131Third115Proof9 : runCachedNode 511 109968 Adaptive131Third115Node9 = false := by
  decide +kernel

#print axioms adaptive131Third115Proof9

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive131Third115Proof7 : runCachedNode 511 109968 Adaptive131Third115Node7 = false := by
  decide +kernel

#print axioms adaptive131Third115Proof7

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive131Third115Proof6 : runCachedNode 511 109968 Adaptive131Third115Node6 = false := by
  decide +kernel

#print axioms adaptive131Third115Proof6

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive131Third115Proof5 : runCachedNode 511 109968 Adaptive131Third115Node5 = false := by
  decide +kernel

#print axioms adaptive131Third115Proof5

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive131Third115Proof4 : runCachedNode 511 109968 Adaptive131Third115Node4 = false := by
  decide +kernel

#print axioms adaptive131Third115Proof4

end NineSeparatedSubsetSums
