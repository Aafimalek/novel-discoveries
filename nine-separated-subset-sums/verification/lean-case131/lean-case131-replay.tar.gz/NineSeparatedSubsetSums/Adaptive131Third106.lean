import NineSeparatedSubsetSums.Adaptive131Third106Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint131Checked

namespace NineSeparatedSubsetSums


theorem adaptive131Third106 : NoDescendingTailAfterThird 131 106 :=
  noDescendingThirdTail_of_cached 131 106 109968 (fun t ht nd => max148_second131_fourPoint_moment_bound (106::t) (by simp [ht]) nd) adaptive131Third106Proof0

#print axioms adaptive131Third106

end NineSeparatedSubsetSums
