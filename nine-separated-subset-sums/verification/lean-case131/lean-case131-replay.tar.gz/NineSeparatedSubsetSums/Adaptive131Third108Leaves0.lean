import NineSeparatedSubsetSums.Adaptive131Third108State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive131Third108Proof0 : runCachedNode 511 109968 Adaptive131Third108Node0 = false := by
  decide +kernel

#print axioms adaptive131Third108Proof0

end NineSeparatedSubsetSums
