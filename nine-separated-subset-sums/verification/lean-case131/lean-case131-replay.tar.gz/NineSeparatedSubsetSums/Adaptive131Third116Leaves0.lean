import NineSeparatedSubsetSums.Adaptive131Third116State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive131Third116Proof14 : runCachedNode 511 109968 Adaptive131Third116Node14 = false := by
  decide +kernel

#print axioms adaptive131Third116Proof14

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive131Third116Proof15 : runCachedNode 511 109968 Adaptive131Third116Node15 = false := by
  decide +kernel

#print axioms adaptive131Third116Proof15

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive131Third116Proof12 : runCachedNode 511 109968 Adaptive131Third116Node12 = false := by
  decide +kernel

#print axioms adaptive131Third116Proof12

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive131Third116Proof4 : runCachedNode 511 109968 Adaptive131Third116Node4 = false := by
  decide +kernel

#print axioms adaptive131Third116Proof4

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive131Third116Proof3 : runCachedNode 511 109968 Adaptive131Third116Node3 = false := by
  decide +kernel

#print axioms adaptive131Third116Proof3

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive131Third116Proof2 : runCachedNode 511 109968 Adaptive131Third116Node2 = false := by
  decide +kernel

#print axioms adaptive131Third116Proof2

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive131Third116Proof1 : runCachedNode 511 109968 Adaptive131Third116Node1 = false := by
  decide +kernel

#print axioms adaptive131Third116Proof1

end NineSeparatedSubsetSums
