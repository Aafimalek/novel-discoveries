import NineSeparatedSubsetSums.EightPoint131_117PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint131_117PackedAnchor1Part1 :
    ∀ j : Fin 114, 2169912 ≤ FourPointNumeric.octPackedCharge 131 117 20 packedOct131_117_1
      (2*((j.val : Int)+120)+1) := by decide +kernel

end NineSeparatedSubsetSums
