import NineSeparatedSubsetSums.Adaptive131Third116State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive131Third116Proof13 : runCachedNode 511 109968 Adaptive131Third116Node13 = false := by
  decide +kernel

#print axioms adaptive131Third116Proof13

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive131Third116Proof11 : runCachedNode 511 109968 Adaptive131Third116Node11 = false := by
  decide +kernel

#print axioms adaptive131Third116Proof11

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive131Third116Proof10 : runCachedNode 511 109968 Adaptive131Third116Node10 = false := by
  decide +kernel

#print axioms adaptive131Third116Proof10

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive131Third116Proof9 : runCachedNode 511 109968 Adaptive131Third116Node9 = false := by
  decide +kernel

#print axioms adaptive131Third116Proof9

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive131Third116Proof8 : runCachedNode 511 109968 Adaptive131Third116Node8 = false := by
  decide +kernel

#print axioms adaptive131Third116Proof8

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive131Third116Proof7 : runCachedNode 511 109968 Adaptive131Third116Node7 = false := by
  decide +kernel

#print axioms adaptive131Third116Proof7

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive131Third116Proof6 : runCachedNode 511 109968 Adaptive131Third116Node6 = false := by
  decide +kernel

#print axioms adaptive131Third116Proof6

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive131Third116Proof5 : runCachedNode 511 109968 Adaptive131Third116Node5 = false := by
  decide +kernel

#print axioms adaptive131Third116Proof5

end NineSeparatedSubsetSums
