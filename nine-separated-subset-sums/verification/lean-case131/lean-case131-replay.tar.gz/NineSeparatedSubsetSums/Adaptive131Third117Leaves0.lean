import NineSeparatedSubsetSums.Adaptive131Third117State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive131Third117Proof0 : runCachedNode 511 123519 Adaptive131Third117Node0 = false := by
  decide +kernel

#print axioms adaptive131Third117Proof0

end NineSeparatedSubsetSums
