import NineSeparatedSubsetSums.Adaptive131Third120State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive131Third120Proof0 : runCachedNode 511 123932 Adaptive131Third120Node0 = false := by
  decide +kernel

#print axioms adaptive131Third120Proof0

end NineSeparatedSubsetSums
