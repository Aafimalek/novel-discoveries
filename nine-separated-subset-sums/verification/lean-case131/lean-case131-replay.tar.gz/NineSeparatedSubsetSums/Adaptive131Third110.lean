import NineSeparatedSubsetSums.Adaptive131Third110Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint131Checked

namespace NineSeparatedSubsetSums


theorem adaptive131Third110 : NoDescendingTailAfterThird 131 110 :=
  noDescendingThirdTail_of_cached 131 110 109968 (fun t ht nd => max148_second131_fourPoint_moment_bound (110::t) (by simp [ht]) nd) adaptive131Third110Proof0

#print axioms adaptive131Third110

end NineSeparatedSubsetSums
