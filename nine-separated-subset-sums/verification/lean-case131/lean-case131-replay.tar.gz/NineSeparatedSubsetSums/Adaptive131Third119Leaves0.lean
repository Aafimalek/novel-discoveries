import NineSeparatedSubsetSums.Adaptive131Third119State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive131Third119Proof0 : runCachedNode 511 123820 Adaptive131Third119Node0 = false := by
  decide +kernel

#print axioms adaptive131Third119Proof0

end NineSeparatedSubsetSums
