import NineSeparatedSubsetSums.EightPoint131_118PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint131_118PackedAnchor0Part1 :
    ∀ j : Fin 115, 2184636 ≤ FourPointNumeric.octPackedCharge 131 118 20 packedOct131_118_0
      (2*((j.val : Int)+120)+1) := by decide +kernel

end NineSeparatedSubsetSums
