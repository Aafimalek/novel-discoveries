import NineSeparatedSubsetSums.Adaptive131Third126State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive131Third126Proof0 : runCachedNode 511 125293 Adaptive131Third126Node0 = false := by
  decide +kernel

#print axioms adaptive131Third126Proof0

end NineSeparatedSubsetSums
