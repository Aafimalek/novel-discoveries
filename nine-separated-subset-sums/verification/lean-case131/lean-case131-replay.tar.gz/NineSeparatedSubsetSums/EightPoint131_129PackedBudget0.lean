import NineSeparatedSubsetSums.EightPoint131_129PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct131_129_0_budget :
    FourPointNumeric.packedBudget 20 packedOct131_129_0 451 = 84739291 := by decide +kernel

#print axioms packedOct131_129_0_budget

end NineSeparatedSubsetSums
