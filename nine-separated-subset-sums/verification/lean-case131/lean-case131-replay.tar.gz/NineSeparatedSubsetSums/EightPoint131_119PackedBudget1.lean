import NineSeparatedSubsetSums.EightPoint131_119PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct131_119_1_budget :
    FourPointNumeric.packedBudget 20 packedOct131_119_1 272 = 78155516 := by decide +kernel

#print axioms packedOct131_119_1_budget

end NineSeparatedSubsetSums
