import NineSeparatedSubsetSums.EightPoint131_130PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint131_130PackedAnchor1Part2 :
    ∀ j : Fin 4, 2343635 ≤ FourPointNumeric.octPackedCharge 131 130 20 packedOct131_130_1
      (2*((j.val : Int)+240)+0) := by decide +kernel

end NineSeparatedSubsetSums
