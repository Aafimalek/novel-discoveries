import NineSeparatedSubsetSums.EightPointPackedGeometry
import NineSeparatedSubsetSums.EightPoint131_130PackedBudget0
import NineSeparatedSubsetSums.EightPoint131_130PackedAnchor0Part0
import NineSeparatedSubsetSums.EightPoint131_130PackedAnchor0Part1
import NineSeparatedSubsetSums.EightPoint131_130PackedAnchor0Part2
import NineSeparatedSubsetSums.EightPoint131_130PackedBudget1
import NineSeparatedSubsetSums.EightPoint131_130PackedAnchor1Part0
import NineSeparatedSubsetSums.EightPoint131_130PackedAnchor1Part1
import NineSeparatedSubsetSums.EightPoint131_130PackedAnchor1Part2

namespace NineSeparatedSubsetSums

private theorem packedOct131_130Anchor0 :
  ∀ j : Fin 487, ((j.val : Int)+131+130)%2=0 →
    2342794 ≤ FourPointNumeric.octPackedCharge 131 130 20 packedOct131_130_0 (j.val : Int) := by
  intro j hj
  let k := (j.val-1)/2
  have hk : k < 243 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+1 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint131_130PackedAnchor0Part0 z
    rwa [he,hrep] at ht
  by_cases h1 : k < 240
  · let z : Fin 120 := ⟨k-120, by omega⟩
    have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
    have ht := eightPoint131_130PackedAnchor0Part1 z
    rwa [he,hrep] at ht
  let z : Fin 3 := ⟨k-240, by omega⟩
  have he : (z.val : Int)+240 = k := by dsimp [z] <;> omega
  have ht := eightPoint131_130PackedAnchor0Part2 z
  rwa [he,hrep] at ht

private theorem packedOct131_130Anchor1 :
  ∀ j : Fin 487, ((j.val : Int)+131+130)%2=1 →
    2343635 ≤ FourPointNumeric.octPackedCharge 131 130 20 packedOct131_130_1 (j.val : Int) := by
  intro j hj
  let k := (j.val-0)/2
  have hk : k < 244 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+0 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint131_130PackedAnchor1Part0 z
    rwa [he,hrep] at ht
  by_cases h1 : k < 240
  · let z : Fin 120 := ⟨k-120, by omega⟩
    have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
    have ht := eightPoint131_130PackedAnchor1Part1 z
    rwa [he,hrep] at ht
  let z : Fin 4 := ⟨k-240, by omega⟩
  have he : (z.val : Int)+240 = k := by dsimp [z] <;> omega
  have ht := eightPoint131_130PackedAnchor1Part2 z
  rwa [he,hrep] at ht

def packedOctCertificate131_130_0 : EightPointCertificate 131 130 0 126043 :=
  eightPointCertificateOfPacked 131 130 0 126043 2342794 20 packedOct131_130_0 381 487
    (by decide +kernel) (by decide) packedOct131_130Anchor0
    (by rw [packedOct131_130_0_budget]; decide)

def packedOctCertificate131_130_1 : EightPointCertificate 131 130 1 126043 :=
  eightPointCertificateOfPacked 131 130 1 126043 2343635 20 packedOct131_130_1 450 487
    (by decide +kernel) (by decide) packedOct131_130Anchor1
    (by rw [packedOct131_130_1_budget]; decide)

theorem max148_second131_third130_eightPoint_moment_bound (tail : List ℕ) (len : tail.length=6)
    (distinct : (natSubsetSums (148::131::130::tail)).Nodup) :
    126043 ≤ ((148::131::130::tail).map (· ^ 2)).sum := by
  apply eightPointNatMomentLower 131 130 126043 tail len distinct
  intro p hp
  by_cases h : p=0
  · subst p
    exact packedOctCertificate131_130_0
  · have he : p=1 := hp.resolve_left h
    subst p
    exact packedOctCertificate131_130_1

#print axioms max148_second131_third130_eightPoint_moment_bound

end NineSeparatedSubsetSums
