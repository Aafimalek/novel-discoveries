import NineSeparatedSubsetSums.EightPoint131_129PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct131_129_1_budget :
    FourPointNumeric.packedBudget 20 packedOct131_129_1 510 = 84743476 := by decide +kernel

#print axioms packedOct131_129_1_budget

end NineSeparatedSubsetSums
