import NineSeparatedSubsetSums.EightPoint131_121PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct131_121_1_budget :
    FourPointNumeric.packedBudget 20 packedOct131_121_1 388 = 80529378 := by decide +kernel

#print axioms packedOct131_121_1_budget

end NineSeparatedSubsetSums
