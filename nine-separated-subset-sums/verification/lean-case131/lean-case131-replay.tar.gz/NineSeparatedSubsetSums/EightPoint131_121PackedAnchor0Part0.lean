import NineSeparatedSubsetSums.EightPoint131_121PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint131_121PackedAnchor0Part0 :
    ∀ j : Fin 120, 2246789 ≤ FourPointNumeric.octPackedCharge 131 121 20 packedOct131_121_0
      (2*((j.val : Int)+0)+0) := by decide +kernel

end NineSeparatedSubsetSums
