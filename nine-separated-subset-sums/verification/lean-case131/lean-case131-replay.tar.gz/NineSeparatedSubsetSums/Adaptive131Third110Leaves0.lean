import NineSeparatedSubsetSums.Adaptive131Third110State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive131Third110Proof0 : runCachedNode 511 109968 Adaptive131Third110Node0 = false := by
  decide +kernel

#print axioms adaptive131Third110Proof0

end NineSeparatedSubsetSums
