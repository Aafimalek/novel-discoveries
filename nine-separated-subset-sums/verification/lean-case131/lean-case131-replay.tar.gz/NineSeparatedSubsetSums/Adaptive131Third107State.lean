import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive131Third107Node0 : CachedSearchNode :=
  ⟨4, 106, computeCenteredMask [148,131,107], 386, 50514⟩

end NineSeparatedSubsetSums
