import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive131Third113Node0 : CachedSearchNode :=
  ⟨4, 112, computeCenteredMask [148,131,113], 392, 51834⟩

end NineSeparatedSubsetSums
