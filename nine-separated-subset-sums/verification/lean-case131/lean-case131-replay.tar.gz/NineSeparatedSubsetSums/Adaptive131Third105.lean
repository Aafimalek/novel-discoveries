import NineSeparatedSubsetSums.Adaptive131Third105Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint131Checked

namespace NineSeparatedSubsetSums


theorem adaptive131Third105 : NoDescendingTailAfterThird 131 105 :=
  noDescendingThirdTail_of_cached 131 105 109968 (fun t ht nd => max148_second131_fourPoint_moment_bound (105::t) (by simp [ht]) nd) adaptive131Third105Proof0

#print axioms adaptive131Third105

end NineSeparatedSubsetSums
