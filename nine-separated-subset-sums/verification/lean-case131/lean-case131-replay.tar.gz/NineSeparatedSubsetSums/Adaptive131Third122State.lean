import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive131Third122Node0 : CachedSearchNode :=
  ⟨4, 121, computeCenteredMask [148,131,122], 401, 53949⟩

end NineSeparatedSubsetSums
