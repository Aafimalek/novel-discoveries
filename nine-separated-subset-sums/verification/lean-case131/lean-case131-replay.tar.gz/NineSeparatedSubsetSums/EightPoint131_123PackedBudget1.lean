import NineSeparatedSubsetSums.EightPoint131_123PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct131_123_1_budget :
    FourPointNumeric.packedBudget 20 packedOct131_123_1 400 = 84045198 := by decide +kernel

#print axioms packedOct131_123_1_budget

end NineSeparatedSubsetSums
