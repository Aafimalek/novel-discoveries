import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive131Third125Node0 : CachedSearchNode :=
  ⟨4, 124, computeCenteredMask [148,131,125], 404, 54690⟩

end NineSeparatedSubsetSums
