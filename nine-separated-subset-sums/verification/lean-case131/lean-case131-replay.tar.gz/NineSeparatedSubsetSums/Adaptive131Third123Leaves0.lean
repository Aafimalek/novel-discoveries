import NineSeparatedSubsetSums.Adaptive131Third123State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive131Third123Proof0 : runCachedNode 511 124735 Adaptive131Third123Node0 = false := by
  decide +kernel

#print axioms adaptive131Third123Proof0

end NineSeparatedSubsetSums
