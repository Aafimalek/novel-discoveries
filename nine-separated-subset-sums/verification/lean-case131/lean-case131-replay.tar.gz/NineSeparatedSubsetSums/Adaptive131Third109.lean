import NineSeparatedSubsetSums.Adaptive131Third109Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint131Checked

namespace NineSeparatedSubsetSums


theorem adaptive131Third109 : NoDescendingTailAfterThird 131 109 :=
  noDescendingThirdTail_of_cached 131 109 109968 (fun t ht nd => max148_second131_fourPoint_moment_bound (109::t) (by simp [ht]) nd) adaptive131Third109Proof0

#print axioms adaptive131Third109

end NineSeparatedSubsetSums
