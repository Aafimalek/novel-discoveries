import NineSeparatedSubsetSums.EightPointPackedGeometry
import NineSeparatedSubsetSums.EightPoint131_123PackedBudget0
import NineSeparatedSubsetSums.EightPoint131_123PackedAnchor0Part0
import NineSeparatedSubsetSums.EightPoint131_123PackedAnchor0Part1
import NineSeparatedSubsetSums.EightPoint131_123PackedAnchor0Part2
import NineSeparatedSubsetSums.EightPoint131_123PackedBudget1
import NineSeparatedSubsetSums.EightPoint131_123PackedAnchor1Part0
import NineSeparatedSubsetSums.EightPoint131_123PackedAnchor1Part1
import NineSeparatedSubsetSums.EightPoint131_123PackedAnchor1Part2

namespace NineSeparatedSubsetSums

private theorem packedOct131_123Anchor0 :
  ∀ j : Fin 485, ((j.val : Int)+131+123)%2=0 →
    2310903 ≤ FourPointNumeric.octPackedCharge 131 123 20 packedOct131_123_0 (j.val : Int) := by
  intro j hj
  let k := (j.val-0)/2
  have hk : k < 243 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+0 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint131_123PackedAnchor0Part0 z
    rwa [he,hrep] at ht
  by_cases h1 : k < 240
  · let z : Fin 120 := ⟨k-120, by omega⟩
    have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
    have ht := eightPoint131_123PackedAnchor0Part1 z
    rwa [he,hrep] at ht
  let z : Fin 3 := ⟨k-240, by omega⟩
  have he : (z.val : Int)+240 = k := by dsimp [z] <;> omega
  have ht := eightPoint131_123PackedAnchor0Part2 z
  rwa [he,hrep] at ht

private theorem packedOct131_123Anchor1 :
  ∀ j : Fin 485, ((j.val : Int)+131+123)%2=1 →
    2311079 ≤ FourPointNumeric.octPackedCharge 131 123 20 packedOct131_123_1 (j.val : Int) := by
  intro j hj
  let k := (j.val-1)/2
  have hk : k < 242 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+1 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint131_123PackedAnchor1Part0 z
    rwa [he,hrep] at ht
  by_cases h1 : k < 240
  · let z : Fin 120 := ⟨k-120, by omega⟩
    have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
    have ht := eightPoint131_123PackedAnchor1Part1 z
    rwa [he,hrep] at ht
  let z : Fin 2 := ⟨k-240, by omega⟩
  have he : (z.val : Int)+240 = k := by dsimp [z] <;> omega
  have ht := eightPoint131_123PackedAnchor1Part2 z
  rwa [he,hrep] at ht

def packedOctCertificate131_123_0 : EightPointCertificate 131 123 0 124735 :=
  eightPointCertificateOfPacked 131 123 0 124735 2310903 20 packedOct131_123_0 383 485
    (by decide +kernel) (by decide) packedOct131_123Anchor0
    (by rw [packedOct131_123_0_budget]; decide)

def packedOctCertificate131_123_1 : EightPointCertificate 131 123 1 124735 :=
  eightPointCertificateOfPacked 131 123 1 124735 2311079 20 packedOct131_123_1 400 485
    (by decide +kernel) (by decide) packedOct131_123Anchor1
    (by rw [packedOct131_123_1_budget]; decide)

theorem max148_second131_third123_eightPoint_moment_bound (tail : List ℕ) (len : tail.length=6)
    (distinct : (natSubsetSums (148::131::123::tail)).Nodup) :
    124735 ≤ ((148::131::123::tail).map (· ^ 2)).sum := by
  apply eightPointNatMomentLower 131 123 124735 tail len distinct
  intro p hp
  by_cases h : p=0
  · subst p
    exact packedOctCertificate131_123_0
  · have he : p=1 := hp.resolve_left h
    subst p
    exact packedOctCertificate131_123_1

#print axioms max148_second131_third123_eightPoint_moment_bound

end NineSeparatedSubsetSums
