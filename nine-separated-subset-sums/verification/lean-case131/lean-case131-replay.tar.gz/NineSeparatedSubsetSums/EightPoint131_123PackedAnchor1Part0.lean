import NineSeparatedSubsetSums.EightPoint131_123PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint131_123PackedAnchor1Part0 :
    ∀ j : Fin 120, 2311079 ≤ FourPointNumeric.octPackedCharge 131 123 20 packedOct131_123_1
      (2*((j.val : Int)+0)+1) := by decide +kernel

end NineSeparatedSubsetSums
