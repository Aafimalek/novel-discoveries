import NineSeparatedSubsetSums.Adaptive131Third128State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive131Third128Proof10 : runCachedNode 511 125698 Adaptive131Third128Node10 = false := by
  decide +kernel

#print axioms adaptive131Third128Proof10

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive131Third128Proof9 : runCachedNode 511 125698 Adaptive131Third128Node9 = false := by
  decide +kernel

#print axioms adaptive131Third128Proof9

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive131Third128Proof8 : runCachedNode 511 125698 Adaptive131Third128Node8 = false := by
  decide +kernel

#print axioms adaptive131Third128Proof8

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive131Third128Proof7 : runCachedNode 511 125698 Adaptive131Third128Node7 = false := by
  decide +kernel

#print axioms adaptive131Third128Proof7

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive131Third128Proof6 : runCachedNode 511 125698 Adaptive131Third128Node6 = false := by
  decide +kernel

#print axioms adaptive131Third128Proof6

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive131Third128Proof3 : runCachedNode 511 125698 Adaptive131Third128Node3 = false := by
  decide +kernel

#print axioms adaptive131Third128Proof3

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive131Third128Proof2 : runCachedNode 511 125698 Adaptive131Third128Node2 = false := by
  decide +kernel

#print axioms adaptive131Third128Proof2

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive131Third128Proof1 : runCachedNode 511 125698 Adaptive131Third128Node1 = false := by
  decide +kernel

#print axioms adaptive131Third128Proof1

end NineSeparatedSubsetSums
