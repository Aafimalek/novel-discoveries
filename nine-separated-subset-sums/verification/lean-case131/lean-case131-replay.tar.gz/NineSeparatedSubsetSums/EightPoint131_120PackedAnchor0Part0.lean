import NineSeparatedSubsetSums.EightPoint131_120PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint131_120PackedAnchor0Part0 :
    ∀ j : Fin 120, 2236159 ≤ FourPointNumeric.octPackedCharge 131 120 20 packedOct131_120_0
      (2*((j.val : Int)+0)+1) := by decide +kernel

end NineSeparatedSubsetSums
