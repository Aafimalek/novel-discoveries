import NineSeparatedSubsetSums.EightPoint131_126PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint131_126PackedAnchor0Part1 :
    ∀ j : Fin 120, 2298481 ≤ FourPointNumeric.octPackedCharge 131 126 20 packedOct131_126_0
      (2*((j.val : Int)+120)+1) := by decide +kernel

end NineSeparatedSubsetSums
