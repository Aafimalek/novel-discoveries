import NineSeparatedSubsetSums.Adaptive131Third125State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive131Third125Proof0 : runCachedNode 511 125080 Adaptive131Third125Node0 = false := by
  decide +kernel

#print axioms adaptive131Third125Proof0

end NineSeparatedSubsetSums
