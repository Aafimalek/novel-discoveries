import NineSeparatedSubsetSums.Adaptive131Third114Joins0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint131Checked

namespace NineSeparatedSubsetSums


theorem adaptive131Third114 : NoDescendingTailAfterThird 131 114 :=
  noDescendingThirdTail_of_cached 131 114 109968 (fun t ht nd => max148_second131_fourPoint_moment_bound (114::t) (by simp [ht]) nd) adaptive131Third114Proof0

#print axioms adaptive131Third114

end NineSeparatedSubsetSums
