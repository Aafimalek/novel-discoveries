import NineSeparatedSubsetSums.Adaptive131Third109State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive131Third109Proof0 : runCachedNode 511 109968 Adaptive131Third109Node0 = false := by
  decide +kernel

#print axioms adaptive131Third109Proof0

end NineSeparatedSubsetSums
