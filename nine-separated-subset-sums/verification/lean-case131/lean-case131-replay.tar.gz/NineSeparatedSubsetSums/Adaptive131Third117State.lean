import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive131Third117Node0 : CachedSearchNode :=
  ⟨4, 116, computeCenteredMask [148,131,117], 396, 52754⟩

end NineSeparatedSubsetSums
