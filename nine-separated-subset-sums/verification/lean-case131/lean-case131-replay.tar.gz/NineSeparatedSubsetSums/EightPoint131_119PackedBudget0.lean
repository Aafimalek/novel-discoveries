import NineSeparatedSubsetSums.EightPoint131_119PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct131_119_0_budget :
    FourPointNumeric.packedBudget 20 packedOct131_119_0 275 = 78161651 := by decide +kernel

#print axioms packedOct131_119_0_budget

end NineSeparatedSubsetSums
