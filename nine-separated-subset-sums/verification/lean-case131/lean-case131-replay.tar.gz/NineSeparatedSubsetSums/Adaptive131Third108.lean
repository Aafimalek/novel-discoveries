import NineSeparatedSubsetSums.Adaptive131Third108Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint131Checked

namespace NineSeparatedSubsetSums


theorem adaptive131Third108 : NoDescendingTailAfterThird 131 108 :=
  noDescendingThirdTail_of_cached 131 108 109968 (fun t ht nd => max148_second131_fourPoint_moment_bound (108::t) (by simp [ht]) nd) adaptive131Third108Proof0

#print axioms adaptive131Third108

end NineSeparatedSubsetSums
