import NineSeparatedSubsetSums.EightPoint131_127PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct131_127_1_budget :
    FourPointNumeric.packedBudget 20 packedOct131_127_1 450 = 83683634 := by decide +kernel

#print axioms packedOct131_127_1_budget

end NineSeparatedSubsetSums
