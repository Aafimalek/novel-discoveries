import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive131Third111Node0 : CachedSearchNode :=
  ⟨4, 110, computeCenteredMask [148,131,111], 390, 51386⟩

end NineSeparatedSubsetSums
