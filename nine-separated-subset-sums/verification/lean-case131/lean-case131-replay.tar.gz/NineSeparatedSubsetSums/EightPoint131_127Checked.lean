import NineSeparatedSubsetSums.EightPointPackedGeometry
import NineSeparatedSubsetSums.EightPoint131_127PackedBudget0
import NineSeparatedSubsetSums.EightPoint131_127PackedAnchor0Part0
import NineSeparatedSubsetSums.EightPoint131_127PackedAnchor0Part1
import NineSeparatedSubsetSums.EightPoint131_127PackedAnchor0Part2
import NineSeparatedSubsetSums.EightPoint131_127PackedBudget1
import NineSeparatedSubsetSums.EightPoint131_127PackedAnchor1Part0
import NineSeparatedSubsetSums.EightPoint131_127PackedAnchor1Part1
import NineSeparatedSubsetSums.EightPoint131_127PackedAnchor1Part2

namespace NineSeparatedSubsetSums

private theorem packedOct131_127Anchor0 :
  ∀ j : Fin 484, ((j.val : Int)+131+127)%2=0 →
    2310964 ≤ FourPointNumeric.octPackedCharge 131 127 20 packedOct131_127_0 (j.val : Int) := by
  intro j hj
  let k := (j.val-0)/2
  have hk : k < 242 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+0 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint131_127PackedAnchor0Part0 z
    rwa [he,hrep] at ht
  by_cases h1 : k < 240
  · let z : Fin 120 := ⟨k-120, by omega⟩
    have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
    have ht := eightPoint131_127PackedAnchor0Part1 z
    rwa [he,hrep] at ht
  let z : Fin 2 := ⟨k-240, by omega⟩
  have he : (z.val : Int)+240 = k := by dsimp [z] <;> omega
  have ht := eightPoint131_127PackedAnchor0Part2 z
  rwa [he,hrep] at ht

private theorem packedOct131_127Anchor1 :
  ∀ j : Fin 484, ((j.val : Int)+131+127)%2=1 →
    2311658 ≤ FourPointNumeric.octPackedCharge 131 127 20 packedOct131_127_1 (j.val : Int) := by
  intro j hj
  let k := (j.val-1)/2
  have hk : k < 242 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+1 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint131_127PackedAnchor1Part0 z
    rwa [he,hrep] at ht
  by_cases h1 : k < 240
  · let z : Fin 120 := ⟨k-120, by omega⟩
    have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
    have ht := eightPoint131_127PackedAnchor1Part1 z
    rwa [he,hrep] at ht
  let z : Fin 2 := ⟨k-240, by omega⟩
  have he : (z.val : Int)+240 = k := by dsimp [z] <;> omega
  have ht := eightPoint131_127PackedAnchor1Part2 z
  rwa [he,hrep] at ht

def packedOctCertificate131_127_0 : EightPointCertificate 131 127 0 125513 :=
  eightPointCertificateOfPacked 131 127 0 125513 2310964 20 packedOct131_127_0 449 484
    (by decide +kernel) (by decide) packedOct131_127Anchor0
    (by rw [packedOct131_127_0_budget]; decide)

def packedOctCertificate131_127_1 : EightPointCertificate 131 127 1 125513 :=
  eightPointCertificateOfPacked 131 127 1 125513 2311658 20 packedOct131_127_1 450 484
    (by decide +kernel) (by decide) packedOct131_127Anchor1
    (by rw [packedOct131_127_1_budget]; decide)

theorem max148_second131_third127_eightPoint_moment_bound (tail : List ℕ) (len : tail.length=6)
    (distinct : (natSubsetSums (148::131::127::tail)).Nodup) :
    125513 ≤ ((148::131::127::tail).map (· ^ 2)).sum := by
  apply eightPointNatMomentLower 131 127 125513 tail len distinct
  intro p hp
  by_cases h : p=0
  · subst p
    exact packedOctCertificate131_127_0
  · have he : p=1 := hp.resolve_left h
    subst p
    exact packedOctCertificate131_127_1

#print axioms max148_second131_third127_eightPoint_moment_bound

end NineSeparatedSubsetSums
