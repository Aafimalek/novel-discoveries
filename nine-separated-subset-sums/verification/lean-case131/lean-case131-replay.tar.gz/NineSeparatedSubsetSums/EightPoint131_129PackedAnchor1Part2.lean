import NineSeparatedSubsetSums.EightPoint131_129PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint131_129PackedAnchor1Part2 :
    ∀ j : Fin 3, 2331056 ≤ FourPointNumeric.octPackedCharge 131 129 20 packedOct131_129_1
      (2*((j.val : Int)+240)+1) := by decide +kernel

end NineSeparatedSubsetSums
