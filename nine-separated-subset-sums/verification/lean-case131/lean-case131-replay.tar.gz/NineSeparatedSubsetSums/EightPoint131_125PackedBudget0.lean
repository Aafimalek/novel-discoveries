import NineSeparatedSubsetSums.EightPoint131_125PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct131_125_0_budget :
    FourPointNumeric.packedBudget 20 packedOct131_125_0 447 = 84105175 := by decide +kernel

#print axioms packedOct131_125_0_budget

end NineSeparatedSubsetSums
