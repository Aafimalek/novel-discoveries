import NineSeparatedSubsetSums.EightPoint131_118PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct131_118_1_budget :
    FourPointNumeric.packedBudget 20 packedOct131_118_1 272 = 76449498 := by decide +kernel

#print axioms packedOct131_118_1_budget

end NineSeparatedSubsetSums
