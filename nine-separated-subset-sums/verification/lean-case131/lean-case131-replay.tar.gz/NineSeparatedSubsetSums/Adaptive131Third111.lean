import NineSeparatedSubsetSums.Adaptive131Third111Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint131Checked

namespace NineSeparatedSubsetSums


theorem adaptive131Third111 : NoDescendingTailAfterThird 131 111 :=
  noDescendingThirdTail_of_cached 131 111 109968 (fun t ht nd => max148_second131_fourPoint_moment_bound (111::t) (by simp [ht]) nd) adaptive131Third111Proof0

#print axioms adaptive131Third111

end NineSeparatedSubsetSums
