import NineSeparatedSubsetSums.EightPoint131_121PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct131_121_0_budget :
    FourPointNumeric.packedBudget 20 packedOct131_121_0 381 = 80353449 := by decide +kernel

#print axioms packedOct131_121_0_budget

end NineSeparatedSubsetSums
