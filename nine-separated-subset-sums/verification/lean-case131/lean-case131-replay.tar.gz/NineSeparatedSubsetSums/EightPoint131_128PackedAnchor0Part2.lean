import NineSeparatedSubsetSums.EightPoint131_128PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint131_128PackedAnchor0Part2 :
    ∀ j : Fin 2, 2318479 ≤ FourPointNumeric.octPackedCharge 131 128 20 packedOct131_128_0
      (2*((j.val : Int)+240)+1) := by decide +kernel

end NineSeparatedSubsetSums
