import NineSeparatedSubsetSums.Adaptive131Third113State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive131Third113Proof0 : runCachedNode 511 109968 Adaptive131Third113Node0 = false := by
  decide +kernel

#print axioms adaptive131Third113Proof0

end NineSeparatedSubsetSums
