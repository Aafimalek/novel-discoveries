import NineSeparatedSubsetSums.FourPoint131PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedWeight131_0_budget :
    FourPointNumeric.packedBudget 20 packedWeight131_0 367 = 77294272 := by decide +kernel

#print axioms packedWeight131_0_budget

end NineSeparatedSubsetSums
