import NineSeparatedSubsetSums.Adaptive131Third124State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive131Third124Proof0 : runCachedNode 511 124900 Adaptive131Third124Node0 = false := by
  decide +kernel

#print axioms adaptive131Third124Proof0

end NineSeparatedSubsetSums
