import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive131Third121Node0 : CachedSearchNode :=
  ⟨4, 120, computeCenteredMask [148,131,121], 400, 53706⟩

end NineSeparatedSubsetSums
