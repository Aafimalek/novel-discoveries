import NineSeparatedSubsetSums.Adaptive131Third128State
import NineSeparatedSubsetSums.Adaptive131Third128Leaves1
import NineSeparatedSubsetSums.Adaptive131Third128Leaves0

namespace NineSeparatedSubsetSums

theorem adaptive131Third128Proof0 : runCachedNode 511 125698 Adaptive131Third128Node0 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 125698 Adaptive131Third128Node0 = [112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive131Third128Proof1
  · exact adaptive131Third128Proof2
  · exact adaptive131Third128Proof3
  · exact adaptive131Third128Proof4
  · exact adaptive131Third128Proof5
  · exact adaptive131Third128Proof6
  · exact adaptive131Third128Proof7
  · exact adaptive131Third128Proof8
  · exact adaptive131Third128Proof9
  · exact adaptive131Third128Proof10
  · exact adaptive131Third128Proof11
  · exact adaptive131Third128Proof12
  · exact adaptive131Third128Proof13
  · exact adaptive131Third128Proof14
  · exact adaptive131Third128Proof15
  · exact adaptive131Third128Proof16

#print axioms adaptive131Third128Proof0

end NineSeparatedSubsetSums
