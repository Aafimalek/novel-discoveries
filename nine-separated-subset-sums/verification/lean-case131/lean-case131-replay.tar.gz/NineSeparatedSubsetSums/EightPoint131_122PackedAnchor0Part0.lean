import NineSeparatedSubsetSums.EightPoint131_122PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint131_122PackedAnchor0Part0 :
    ∀ j : Fin 120, 2294583 ≤ FourPointNumeric.octPackedCharge 131 122 20 packedOct131_122_0
      (2*((j.val : Int)+0)+1) := by decide +kernel

end NineSeparatedSubsetSums
