import NineSeparatedSubsetSums.Adaptive131Third107Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint131Checked

namespace NineSeparatedSubsetSums


theorem adaptive131Third107 : NoDescendingTailAfterThird 131 107 :=
  noDescendingThirdTail_of_cached 131 107 109968 (fun t ht nd => max148_second131_fourPoint_moment_bound (107::t) (by simp [ht]) nd) adaptive131Third107Proof0

#print axioms adaptive131Third107

end NineSeparatedSubsetSums
