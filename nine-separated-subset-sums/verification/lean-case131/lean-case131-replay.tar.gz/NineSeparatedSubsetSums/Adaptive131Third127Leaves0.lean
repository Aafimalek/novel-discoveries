import NineSeparatedSubsetSums.Adaptive131Third127State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive131Third127Proof0 : runCachedNode 511 125513 Adaptive131Third127Node0 = false := by
  decide +kernel

#print axioms adaptive131Third127Proof0

end NineSeparatedSubsetSums
