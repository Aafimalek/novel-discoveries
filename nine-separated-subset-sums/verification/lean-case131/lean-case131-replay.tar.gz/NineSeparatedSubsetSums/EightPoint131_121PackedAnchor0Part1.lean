import NineSeparatedSubsetSums.EightPoint131_121PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint131_121PackedAnchor0Part1 :
    ∀ j : Fin 119, 2246789 ≤ FourPointNumeric.octPackedCharge 131 121 20 packedOct131_121_0
      (2*((j.val : Int)+120)+0) := by decide +kernel

end NineSeparatedSubsetSums
