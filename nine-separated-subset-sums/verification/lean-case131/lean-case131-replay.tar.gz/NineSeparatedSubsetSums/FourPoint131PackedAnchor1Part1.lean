import NineSeparatedSubsetSums.FourPoint131PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem fourPoint131PackedAnchor1Part1 :
    ∀ j : Fin 116, 1043732 ≤ FourPointNumeric.packedCharge 131 20 packedWeight131_1
      (2*((j.val : Int)+120)+0) := by decide +kernel

end NineSeparatedSubsetSums
