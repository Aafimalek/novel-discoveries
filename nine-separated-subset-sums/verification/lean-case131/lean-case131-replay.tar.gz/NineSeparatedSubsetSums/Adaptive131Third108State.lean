import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive131Third108Node0 : CachedSearchNode :=
  ⟨4, 107, computeCenteredMask [148,131,108], 387, 50729⟩

end NineSeparatedSubsetSums
