import NineSeparatedSubsetSums.EightPointPackedGeometry
import NineSeparatedSubsetSums.EightPoint131_120PackedBudget0
import NineSeparatedSubsetSums.EightPoint131_120PackedAnchor0Part0
import NineSeparatedSubsetSums.EightPoint131_120PackedAnchor0Part1
import NineSeparatedSubsetSums.EightPoint131_120PackedBudget1
import NineSeparatedSubsetSums.EightPoint131_120PackedAnchor1Part0
import NineSeparatedSubsetSums.EightPoint131_120PackedAnchor1Part1

namespace NineSeparatedSubsetSums

private theorem packedOct131_120Anchor0 :
  ∀ j : Fin 476, ((j.val : Int)+131+120)%2=0 →
    2236159 ≤ FourPointNumeric.octPackedCharge 131 120 20 packedOct131_120_0 (j.val : Int) := by
  intro j hj
  let k := (j.val-1)/2
  have hk : k < 238 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+1 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint131_120PackedAnchor0Part0 z
    rwa [he,hrep] at ht
  let z : Fin 118 := ⟨k-120, by omega⟩
  have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
  have ht := eightPoint131_120PackedAnchor0Part1 z
  rwa [he,hrep] at ht

private theorem packedOct131_120Anchor1 :
  ∀ j : Fin 476, ((j.val : Int)+131+120)%2=1 →
    2236134 ≤ FourPointNumeric.octPackedCharge 131 120 20 packedOct131_120_1 (j.val : Int) := by
  intro j hj
  let k := (j.val-0)/2
  have hk : k < 238 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+0 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint131_120PackedAnchor1Part0 z
    rwa [he,hrep] at ht
  let z : Fin 118 := ⟨k-120, by omega⟩
  have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
  have ht := eightPoint131_120PackedAnchor1Part1 z
  rwa [he,hrep] at ht

def packedOctCertificate131_120_0 : EightPointCertificate 131 120 0 123932 :=
  eightPointCertificateOfPacked 131 120 0 123932 2236159 20 packedOct131_120_0 379 476
    (by decide +kernel) (by decide) packedOct131_120Anchor0
    (by rw [packedOct131_120_0_budget]; decide)

def packedOctCertificate131_120_1 : EightPointCertificate 131 120 1 123932 :=
  eightPointCertificateOfPacked 131 120 1 123932 2236134 20 packedOct131_120_1 386 476
    (by decide +kernel) (by decide) packedOct131_120Anchor1
    (by rw [packedOct131_120_1_budget]; decide)

theorem max148_second131_third120_eightPoint_moment_bound (tail : List ℕ) (len : tail.length=6)
    (distinct : (natSubsetSums (148::131::120::tail)).Nodup) :
    123932 ≤ ((148::131::120::tail).map (· ^ 2)).sum := by
  apply eightPointNatMomentLower 131 120 123932 tail len distinct
  intro p hp
  by_cases h : p=0
  · subst p
    exact packedOctCertificate131_120_0
  · have he : p=1 := hp.resolve_left h
    subst p
    exact packedOctCertificate131_120_1

#print axioms max148_second131_third120_eightPoint_moment_bound

end NineSeparatedSubsetSums
