import NineSeparatedSubsetSums.Adaptive131Third114State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive131Third114Proof13 : runCachedNode 511 109968 Adaptive131Third114Node13 = false := by
  decide +kernel

#print axioms adaptive131Third114Proof13

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive131Third114Proof12 : runCachedNode 511 109968 Adaptive131Third114Node12 = false := by
  decide +kernel

#print axioms adaptive131Third114Proof12

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive131Third114Proof11 : runCachedNode 511 109968 Adaptive131Third114Node11 = false := by
  decide +kernel

#print axioms adaptive131Third114Proof11

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive131Third114Proof10 : runCachedNode 511 109968 Adaptive131Third114Node10 = false := by
  decide +kernel

#print axioms adaptive131Third114Proof10

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive131Third114Proof9 : runCachedNode 511 109968 Adaptive131Third114Node9 = false := by
  decide +kernel

#print axioms adaptive131Third114Proof9

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive131Third114Proof4 : runCachedNode 511 109968 Adaptive131Third114Node4 = false := by
  decide +kernel

#print axioms adaptive131Third114Proof4

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive131Third114Proof3 : runCachedNode 511 109968 Adaptive131Third114Node3 = false := by
  decide +kernel

#print axioms adaptive131Third114Proof3

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive131Third114Proof1 : runCachedNode 511 109968 Adaptive131Third114Node1 = false := by
  decide +kernel

#print axioms adaptive131Third114Proof1

end NineSeparatedSubsetSums
