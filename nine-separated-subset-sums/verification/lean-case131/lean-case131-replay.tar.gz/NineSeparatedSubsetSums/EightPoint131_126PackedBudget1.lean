import NineSeparatedSubsetSums.EightPoint131_126PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct131_126_1_budget :
    FourPointNumeric.packedBudget 20 packedOct131_126_1 394 = 83073030 := by decide +kernel

#print axioms packedOct131_126_1_budget

end NineSeparatedSubsetSums
