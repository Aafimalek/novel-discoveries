import NineSeparatedSubsetSums.EightPoint131_125PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint131_125PackedAnchor1Part2 :
    ∀ j : Fin 2, 2315856 ≤ FourPointNumeric.octPackedCharge 131 125 20 packedOct131_125_1
      (2*((j.val : Int)+240)+1) := by decide +kernel

end NineSeparatedSubsetSums
