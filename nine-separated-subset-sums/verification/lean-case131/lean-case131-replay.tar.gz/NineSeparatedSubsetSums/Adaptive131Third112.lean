import NineSeparatedSubsetSums.Adaptive131Third112Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint131Checked

namespace NineSeparatedSubsetSums


theorem adaptive131Third112 : NoDescendingTailAfterThird 131 112 :=
  noDescendingThirdTail_of_cached 131 112 109968 (fun t ht nd => max148_second131_fourPoint_moment_bound (112::t) (by simp [ht]) nd) adaptive131Third112Proof0

#print axioms adaptive131Third112

end NineSeparatedSubsetSums
