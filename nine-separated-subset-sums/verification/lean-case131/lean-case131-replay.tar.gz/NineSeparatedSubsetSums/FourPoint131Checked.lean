import NineSeparatedSubsetSums.FourPointPackedGeometry
import NineSeparatedSubsetSums.FourPoint131PackedBudget0
import NineSeparatedSubsetSums.FourPoint131PackedAnchor0Part0
import NineSeparatedSubsetSums.FourPoint131PackedAnchor0Part1
import NineSeparatedSubsetSums.FourPoint131PackedBudget1
import NineSeparatedSubsetSums.FourPoint131PackedAnchor1Part0
import NineSeparatedSubsetSums.FourPoint131PackedAnchor1Part1

namespace NineSeparatedSubsetSums

private theorem packed131Anchor0 :
  ∀ j : Fin 472, ((j.val : Int)+131)%2=0 →
    1043736 ≤ FourPointNumeric.packedCharge 131 20 packedWeight131_0 (j.val : Int) := by
  intro j hj
  let k := (j.val-1)/2
  have hk : k < 236 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+1 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := fourPoint131PackedAnchor0Part0 z
    rwa [he,hrep] at ht
  let z : Fin 116 := ⟨k-120, by omega⟩
  have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
  have ht := fourPoint131PackedAnchor0Part1 z
  rwa [he,hrep] at ht

private theorem packed131Anchor1 :
  ∀ j : Fin 472, ((j.val : Int)+131)%2=1 →
    1043732 ≤ FourPointNumeric.packedCharge 131 20 packedWeight131_1 (j.val : Int) := by
  intro j hj
  let k := (j.val-0)/2
  have hk : k < 236 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+0 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := fourPoint131PackedAnchor1Part0 z
    rwa [he,hrep] at ht
  let z : Fin 116 := ⟨k-120, by omega⟩
  have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
  have ht := fourPoint131PackedAnchor1Part1 z
  rwa [he,hrep] at ht

def packedCertificate131_0 : FourPointCertificate 131 0 109968 :=
  fourPointCertificateOfPacked 131 0 109968 1043736 20 packedWeight131_0 367 472
    (by decide +kernel) (by decide) (by decide) packed131Anchor0
    (by rw [packedWeight131_0_budget]; decide)

def packedCertificate131_1 : FourPointCertificate 131 1 109968 :=
  fourPointCertificateOfPacked 131 1 109968 1043732 20 packedWeight131_1 570 472
    (by decide +kernel) (by decide) (by decide) packed131Anchor1
    (by rw [packedWeight131_1_budget]; decide)

theorem max148_second131_fourPoint_moment_bound (tail : List ℕ) (len : tail.length=7)
    (distinct : (natSubsetSums (148::131::tail)).Nodup) :
    109968 ≤ ((148::131::tail).map (· ^ 2)).sum := by
  apply fourPointNatMomentLower 131 109968 tail len distinct
  intro p hp
  by_cases h : p=0
  · subst p
    exact packedCertificate131_0
  · have he : p=1 := hp.resolve_left h
    subst p
    exact packedCertificate131_1

#print axioms max148_second131_fourPoint_moment_bound

end NineSeparatedSubsetSums
