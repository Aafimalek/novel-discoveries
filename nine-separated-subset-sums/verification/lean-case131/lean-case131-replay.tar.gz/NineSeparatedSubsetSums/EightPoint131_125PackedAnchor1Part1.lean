import NineSeparatedSubsetSums.EightPoint131_125PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint131_125PackedAnchor1Part1 :
    ∀ j : Fin 120, 2315856 ≤ FourPointNumeric.octPackedCharge 131 125 20 packedOct131_125_1
      (2*((j.val : Int)+120)+1) := by decide +kernel

end NineSeparatedSubsetSums
