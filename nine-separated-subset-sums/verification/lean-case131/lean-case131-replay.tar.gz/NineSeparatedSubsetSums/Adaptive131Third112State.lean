import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive131Third112Node0 : CachedSearchNode :=
  ⟨4, 111, computeCenteredMask [148,131,112], 391, 51609⟩

end NineSeparatedSubsetSums
