import NineSeparatedSubsetSums.Adaptive131Third128State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive131Third128Proof15 : runCachedNode 511 125698 Adaptive131Third128Node15 = false := by
  decide +kernel

#print axioms adaptive131Third128Proof15

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive131Third128Proof16 : runCachedNode 511 125698 Adaptive131Third128Node16 = false := by
  decide +kernel

#print axioms adaptive131Third128Proof16

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive131Third128Proof14 : runCachedNode 511 125698 Adaptive131Third128Node14 = false := by
  decide +kernel

#print axioms adaptive131Third128Proof14

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive131Third128Proof13 : runCachedNode 511 125698 Adaptive131Third128Node13 = false := by
  decide +kernel

#print axioms adaptive131Third128Proof13

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive131Third128Proof12 : runCachedNode 511 125698 Adaptive131Third128Node12 = false := by
  decide +kernel

#print axioms adaptive131Third128Proof12

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive131Third128Proof11 : runCachedNode 511 125698 Adaptive131Third128Node11 = false := by
  decide +kernel

#print axioms adaptive131Third128Proof11

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive131Third128Proof5 : runCachedNode 511 125698 Adaptive131Third128Node5 = false := by
  decide +kernel

#print axioms adaptive131Third128Proof5

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive131Third128Proof4 : runCachedNode 511 125698 Adaptive131Third128Node4 = false := by
  decide +kernel

#print axioms adaptive131Third128Proof4

end NineSeparatedSubsetSums
