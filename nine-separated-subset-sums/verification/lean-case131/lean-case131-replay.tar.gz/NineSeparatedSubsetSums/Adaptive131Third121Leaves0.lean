import NineSeparatedSubsetSums.Adaptive131Third121State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive131Third121Proof0 : runCachedNode 511 123909 Adaptive131Third121Node0 = false := by
  decide +kernel

#print axioms adaptive131Third121Proof0

end NineSeparatedSubsetSums
