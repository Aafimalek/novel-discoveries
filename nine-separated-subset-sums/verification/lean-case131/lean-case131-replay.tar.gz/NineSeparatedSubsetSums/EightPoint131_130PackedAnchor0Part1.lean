import NineSeparatedSubsetSums.EightPoint131_130PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint131_130PackedAnchor0Part1 :
    ∀ j : Fin 120, 2342794 ≤ FourPointNumeric.octPackedCharge 131 130 20 packedOct131_130_0
      (2*((j.val : Int)+120)+1) := by decide +kernel

end NineSeparatedSubsetSums
