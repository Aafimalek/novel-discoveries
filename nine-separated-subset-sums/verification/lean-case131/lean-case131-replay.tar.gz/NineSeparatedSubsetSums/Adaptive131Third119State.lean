import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive131Third119Node0 : CachedSearchNode :=
  ⟨4, 118, computeCenteredMask [148,131,119], 398, 53226⟩

end NineSeparatedSubsetSums
