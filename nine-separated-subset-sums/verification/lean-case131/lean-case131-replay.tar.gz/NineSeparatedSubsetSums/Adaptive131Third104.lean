import NineSeparatedSubsetSums.Adaptive131Third104Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint131Checked

namespace NineSeparatedSubsetSums


theorem adaptive131Third104 : NoDescendingTailAfterThird 131 104 :=
  noDescendingThirdTail_of_cached 131 104 109968 (fun t ht nd => max148_second131_fourPoint_moment_bound (104::t) (by simp [ht]) nd) adaptive131Third104Proof0

#print axioms adaptive131Third104

end NineSeparatedSubsetSums
