import NineSeparatedSubsetSums.EightPoint131_122PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct131_122_0_budget :
    FourPointNumeric.packedBudget 20 packedOct131_122_0 485 = 83188377 := by decide +kernel

#print axioms packedOct131_122_0_budget

end NineSeparatedSubsetSums
