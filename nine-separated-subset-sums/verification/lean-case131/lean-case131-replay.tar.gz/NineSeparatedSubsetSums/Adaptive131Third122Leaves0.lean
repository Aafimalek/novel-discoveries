import NineSeparatedSubsetSums.Adaptive131Third122State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive131Third122Proof0 : runCachedNode 511 124345 Adaptive131Third122Node0 = false := by
  decide +kernel

#print axioms adaptive131Third122Proof0

end NineSeparatedSubsetSums
