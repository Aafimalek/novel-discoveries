import NineSeparatedSubsetSums.EightPoint131_120PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct131_120_1_budget :
    FourPointNumeric.packedBudget 20 packedOct131_120_1 386 = 79659554 := by decide +kernel

#print axioms packedOct131_120_1_budget

end NineSeparatedSubsetSums
