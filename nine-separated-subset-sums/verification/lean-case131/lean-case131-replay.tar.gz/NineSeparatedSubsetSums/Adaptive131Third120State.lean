import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive131Third120Node0 : CachedSearchNode :=
  ⟨4, 119, computeCenteredMask [148,131,120], 399, 53465⟩

end NineSeparatedSubsetSums
