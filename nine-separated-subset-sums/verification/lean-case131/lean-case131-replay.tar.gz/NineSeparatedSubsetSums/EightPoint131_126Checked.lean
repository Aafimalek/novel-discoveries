import NineSeparatedSubsetSums.EightPointPackedGeometry
import NineSeparatedSubsetSums.EightPoint131_126PackedBudget0
import NineSeparatedSubsetSums.EightPoint131_126PackedAnchor0Part0
import NineSeparatedSubsetSums.EightPoint131_126PackedAnchor0Part1
import NineSeparatedSubsetSums.EightPoint131_126PackedAnchor0Part2
import NineSeparatedSubsetSums.EightPoint131_126PackedBudget1
import NineSeparatedSubsetSums.EightPoint131_126PackedAnchor1Part0
import NineSeparatedSubsetSums.EightPoint131_126PackedAnchor1Part1
import NineSeparatedSubsetSums.EightPoint131_126PackedAnchor1Part2

namespace NineSeparatedSubsetSums

private theorem packedOct131_126Anchor0 :
  ∀ j : Fin 483, ((j.val : Int)+131+126)%2=0 →
    2298481 ≤ FourPointNumeric.octPackedCharge 131 126 20 packedOct131_126_0 (j.val : Int) := by
  intro j hj
  let k := (j.val-1)/2
  have hk : k < 241 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+1 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint131_126PackedAnchor0Part0 z
    rwa [he,hrep] at ht
  by_cases h1 : k < 240
  · let z : Fin 120 := ⟨k-120, by omega⟩
    have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
    have ht := eightPoint131_126PackedAnchor0Part1 z
    rwa [he,hrep] at ht
  let z : Fin 1 := ⟨k-240, by omega⟩
  have he : (z.val : Int)+240 = k := by dsimp [z] <;> omega
  have ht := eightPoint131_126PackedAnchor0Part2 z
  rwa [he,hrep] at ht

private theorem packedOct131_126Anchor1 :
  ∀ j : Fin 483, ((j.val : Int)+131+126)%2=1 →
    2300358 ≤ FourPointNumeric.octPackedCharge 131 126 20 packedOct131_126_1 (j.val : Int) := by
  intro j hj
  let k := (j.val-0)/2
  have hk : k < 242 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+0 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint131_126PackedAnchor1Part0 z
    rwa [he,hrep] at ht
  by_cases h1 : k < 240
  · let z : Fin 120 := ⟨k-120, by omega⟩
    have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
    have ht := eightPoint131_126PackedAnchor1Part1 z
    rwa [he,hrep] at ht
  let z : Fin 2 := ⟨k-240, by omega⟩
  have he : (z.val : Int)+240 = k := by dsimp [z] <;> omega
  have ht := eightPoint131_126PackedAnchor1Part2 z
  rwa [he,hrep] at ht

def packedOctCertificate131_126_0 : EightPointCertificate 131 126 0 125293 :=
  eightPointCertificateOfPacked 131 126 0 125293 2298481 20 packedOct131_126_0 393 483
    (by decide +kernel) (by decide) packedOct131_126Anchor0
    (by rw [packedOct131_126_0_budget]; decide)

def packedOctCertificate131_126_1 : EightPointCertificate 131 126 1 125293 :=
  eightPointCertificateOfPacked 131 126 1 125293 2300358 20 packedOct131_126_1 394 483
    (by decide +kernel) (by decide) packedOct131_126Anchor1
    (by rw [packedOct131_126_1_budget]; decide)

theorem max148_second131_third126_eightPoint_moment_bound (tail : List ℕ) (len : tail.length=6)
    (distinct : (natSubsetSums (148::131::126::tail)).Nodup) :
    125293 ≤ ((148::131::126::tail).map (· ^ 2)).sum := by
  apply eightPointNatMomentLower 131 126 125293 tail len distinct
  intro p hp
  by_cases h : p=0
  · subst p
    exact packedOctCertificate131_126_0
  · have he : p=1 := hp.resolve_left h
    subst p
    exact packedOctCertificate131_126_1

#print axioms max148_second131_third126_eightPoint_moment_bound

end NineSeparatedSubsetSums
