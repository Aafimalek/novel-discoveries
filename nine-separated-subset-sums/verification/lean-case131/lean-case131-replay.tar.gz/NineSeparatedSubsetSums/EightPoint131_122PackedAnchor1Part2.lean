import NineSeparatedSubsetSums.EightPoint131_122PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint131_122PackedAnchor1Part2 :
    ∀ j : Fin 2, 2296429 ≤ FourPointNumeric.octPackedCharge 131 122 20 packedOct131_122_1
      (2*((j.val : Int)+240)+0) := by decide +kernel

end NineSeparatedSubsetSums
