import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive131Third118Node0 : CachedSearchNode :=
  ⟨4, 117, computeCenteredMask [148,131,118], 397, 52989⟩

end NineSeparatedSubsetSums
