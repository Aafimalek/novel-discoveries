import NineSeparatedSubsetSums.EightPoint131_124PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint131_124PackedAnchor0Part2 :
    ∀ j : Fin 2, 2313309 ≤ FourPointNumeric.octPackedCharge 131 124 20 packedOct131_124_0
      (2*((j.val : Int)+240)+1) := by decide +kernel

end NineSeparatedSubsetSums
