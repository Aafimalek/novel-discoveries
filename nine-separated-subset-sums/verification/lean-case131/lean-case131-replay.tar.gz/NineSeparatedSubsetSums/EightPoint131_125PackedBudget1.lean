import NineSeparatedSubsetSums.EightPoint131_125PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct131_125_1_budget :
    FourPointNumeric.packedBudget 20 packedOct131_125_1 452 = 84173960 := by decide +kernel

#print axioms packedOct131_125_1_budget

end NineSeparatedSubsetSums
