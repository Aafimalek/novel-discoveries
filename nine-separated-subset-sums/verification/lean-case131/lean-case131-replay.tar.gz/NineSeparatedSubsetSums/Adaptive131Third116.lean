import NineSeparatedSubsetSums.Adaptive131Third116Joins0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint131Checked

namespace NineSeparatedSubsetSums


theorem adaptive131Third116 : NoDescendingTailAfterThird 131 116 :=
  noDescendingThirdTail_of_cached 131 116 109968 (fun t ht nd => max148_second131_fourPoint_moment_bound (116::t) (by simp [ht]) nd) adaptive131Third116Proof0

#print axioms adaptive131Third116

end NineSeparatedSubsetSums
