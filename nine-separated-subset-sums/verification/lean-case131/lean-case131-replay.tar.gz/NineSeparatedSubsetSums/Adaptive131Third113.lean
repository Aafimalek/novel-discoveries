import NineSeparatedSubsetSums.Adaptive131Third113Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint131Checked

namespace NineSeparatedSubsetSums


theorem adaptive131Third113 : NoDescendingTailAfterThird 131 113 :=
  noDescendingThirdTail_of_cached 131 113 109968 (fun t ht nd => max148_second131_fourPoint_moment_bound (113::t) (by simp [ht]) nd) adaptive131Third113Proof0

#print axioms adaptive131Third113

end NineSeparatedSubsetSums
