import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive131Third123Node0 : CachedSearchNode :=
  ⟨4, 122, computeCenteredMask [148,131,123], 402, 54194⟩

end NineSeparatedSubsetSums
