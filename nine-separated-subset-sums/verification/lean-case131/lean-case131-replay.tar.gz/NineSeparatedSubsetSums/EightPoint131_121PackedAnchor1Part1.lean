import NineSeparatedSubsetSums.EightPoint131_121PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint131_121PackedAnchor1Part1 :
    ∀ j : Fin 118, 2249546 ≤ FourPointNumeric.octPackedCharge 131 121 20 packedOct131_121_1
      (2*((j.val : Int)+120)+1) := by decide +kernel

end NineSeparatedSubsetSums
