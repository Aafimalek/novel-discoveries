import NineSeparatedSubsetSums.Adaptive131Third129State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive131Third129Proof16 : runCachedNode 511 125868 Adaptive131Third129Node16 = false := by
  decide +kernel

#print axioms adaptive131Third129Proof16

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive131Third129Proof17 : runCachedNode 511 125868 Adaptive131Third129Node17 = false := by
  decide +kernel

#print axioms adaptive131Third129Proof17

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive131Third129Proof15 : runCachedNode 511 125868 Adaptive131Third129Node15 = false := by
  decide +kernel

#print axioms adaptive131Third129Proof15

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive131Third129Proof14 : runCachedNode 511 125868 Adaptive131Third129Node14 = false := by
  decide +kernel

#print axioms adaptive131Third129Proof14

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive131Third129Proof10 : runCachedNode 511 125868 Adaptive131Third129Node10 = false := by
  decide +kernel

#print axioms adaptive131Third129Proof10

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive131Third129Proof5 : runCachedNode 511 125868 Adaptive131Third129Node5 = false := by
  decide +kernel

#print axioms adaptive131Third129Proof5

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive131Third129Proof1 : runCachedNode 511 125868 Adaptive131Third129Node1 = false := by
  decide +kernel

#print axioms adaptive131Third129Proof1

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive131Third129Proof2 : runCachedNode 511 125868 Adaptive131Third129Node2 = false := by
  decide +kernel

#print axioms adaptive131Third129Proof2

end NineSeparatedSubsetSums
