import NineSeparatedSubsetSums.EightPoint131_127PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint131_127PackedAnchor0Part0 :
    ∀ j : Fin 120, 2310964 ≤ FourPointNumeric.octPackedCharge 131 127 20 packedOct131_127_0
      (2*((j.val : Int)+0)+0) := by decide +kernel

end NineSeparatedSubsetSums
