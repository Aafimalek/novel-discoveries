import NineSeparatedSubsetSums.EightPoint131_126PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint131_126PackedAnchor1Part0 :
    ∀ j : Fin 120, 2300358 ≤ FourPointNumeric.octPackedCharge 131 126 20 packedOct131_126_1
      (2*((j.val : Int)+0)+0) := by decide +kernel

end NineSeparatedSubsetSums
