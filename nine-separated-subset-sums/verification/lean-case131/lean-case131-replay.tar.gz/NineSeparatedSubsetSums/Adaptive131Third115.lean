import NineSeparatedSubsetSums.Adaptive131Third115Joins0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint131Checked

namespace NineSeparatedSubsetSums


theorem adaptive131Third115 : NoDescendingTailAfterThird 131 115 :=
  noDescendingThirdTail_of_cached 131 115 109968 (fun t ht nd => max148_second131_fourPoint_moment_bound (115::t) (by simp [ht]) nd) adaptive131Third115Proof0

#print axioms adaptive131Third115

end NineSeparatedSubsetSums
