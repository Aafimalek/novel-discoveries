import NineSeparatedSubsetSums.FourPoint131PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem fourPoint131PackedAnchor0Part0 :
    ∀ j : Fin 120, 1043736 ≤ FourPointNumeric.packedCharge 131 20 packedWeight131_0
      (2*((j.val : Int)+0)+1) := by decide +kernel

end NineSeparatedSubsetSums
