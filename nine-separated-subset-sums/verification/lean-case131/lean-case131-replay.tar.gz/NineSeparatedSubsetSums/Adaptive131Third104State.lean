import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive131Third104Node0 : CachedSearchNode :=
  ⟨4, 103, computeCenteredMask [148,131,104], 383, 49881⟩

end NineSeparatedSubsetSums
