import NineSeparatedSubsetSums.Adaptive131Third130State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive131Third130Proof18 : runCachedNode 511 126043 Adaptive131Third130Node18 = false := by
  decide +kernel

#print axioms adaptive131Third130Proof18

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive131Third130Proof17 : runCachedNode 511 126043 Adaptive131Third130Node17 = false := by
  decide +kernel

#print axioms adaptive131Third130Proof17

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive131Third130Proof15 : runCachedNode 511 126043 Adaptive131Third130Node15 = false := by
  decide +kernel

#print axioms adaptive131Third130Proof15

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive131Third130Proof6 : runCachedNode 511 126043 Adaptive131Third130Node6 = false := by
  decide +kernel

#print axioms adaptive131Third130Proof6

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive131Third130Proof4 : runCachedNode 511 126043 Adaptive131Third130Node4 = false := by
  decide +kernel

#print axioms adaptive131Third130Proof4

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive131Third130Proof2 : runCachedNode 511 126043 Adaptive131Third130Node2 = false := by
  decide +kernel

#print axioms adaptive131Third130Proof2

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive131Third130Proof1 : runCachedNode 511 126043 Adaptive131Third130Node1 = false := by
  decide +kernel

#print axioms adaptive131Third130Proof1

end NineSeparatedSubsetSums
