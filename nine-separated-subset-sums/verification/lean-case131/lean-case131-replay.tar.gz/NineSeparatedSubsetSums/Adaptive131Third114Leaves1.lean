import NineSeparatedSubsetSums.Adaptive131Third114State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive131Third114Proof8 : runCachedNode 511 109968 Adaptive131Third114Node8 = false := by
  decide +kernel

#print axioms adaptive131Third114Proof8

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive131Third114Proof7 : runCachedNode 511 109968 Adaptive131Third114Node7 = false := by
  decide +kernel

#print axioms adaptive131Third114Proof7

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive131Third114Proof6 : runCachedNode 511 109968 Adaptive131Third114Node6 = false := by
  decide +kernel

#print axioms adaptive131Third114Proof6

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive131Third114Proof5 : runCachedNode 511 109968 Adaptive131Third114Node5 = false := by
  decide +kernel

#print axioms adaptive131Third114Proof5

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive131Third114Proof2 : runCachedNode 511 109968 Adaptive131Third114Node2 = false := by
  decide +kernel

#print axioms adaptive131Third114Proof2

end NineSeparatedSubsetSums
