import NineSeparatedSubsetSums.EightPoint131_119PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint131_119PackedAnchor0Part1 :
    ∀ j : Fin 117, 2211835 ≤ FourPointNumeric.octPackedCharge 131 119 20 packedOct131_119_0
      (2*((j.val : Int)+120)+0) := by decide +kernel

end NineSeparatedSubsetSums
