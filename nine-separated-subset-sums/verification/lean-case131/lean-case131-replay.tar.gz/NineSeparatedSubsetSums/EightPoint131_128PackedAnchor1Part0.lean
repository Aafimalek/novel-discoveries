import NineSeparatedSubsetSums.EightPoint131_128PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint131_128PackedAnchor1Part0 :
    ∀ j : Fin 120, 2318490 ≤ FourPointNumeric.octPackedCharge 131 128 20 packedOct131_128_1
      (2*((j.val : Int)+0)+0) := by decide +kernel

end NineSeparatedSubsetSums
