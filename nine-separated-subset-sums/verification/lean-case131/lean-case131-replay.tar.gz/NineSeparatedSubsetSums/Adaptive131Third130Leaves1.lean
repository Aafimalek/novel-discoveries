import NineSeparatedSubsetSums.Adaptive131Third130State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive131Third130Proof16 : runCachedNode 511 126043 Adaptive131Third130Node16 = false := by
  decide +kernel

#print axioms adaptive131Third130Proof16

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive131Third130Proof14 : runCachedNode 511 126043 Adaptive131Third130Node14 = false := by
  decide +kernel

#print axioms adaptive131Third130Proof14

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive131Third130Proof13 : runCachedNode 511 126043 Adaptive131Third130Node13 = false := by
  decide +kernel

#print axioms adaptive131Third130Proof13

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive131Third130Proof12 : runCachedNode 511 126043 Adaptive131Third130Node12 = false := by
  decide +kernel

#print axioms adaptive131Third130Proof12

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive131Third130Proof11 : runCachedNode 511 126043 Adaptive131Third130Node11 = false := by
  decide +kernel

#print axioms adaptive131Third130Proof11

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive131Third130Proof10 : runCachedNode 511 126043 Adaptive131Third130Node10 = false := by
  decide +kernel

#print axioms adaptive131Third130Proof10

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive131Third130Proof9 : runCachedNode 511 126043 Adaptive131Third130Node9 = false := by
  decide +kernel

#print axioms adaptive131Third130Proof9

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive131Third130Proof8 : runCachedNode 511 126043 Adaptive131Third130Node8 = false := by
  decide +kernel

#print axioms adaptive131Third130Proof8

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive131Third130Proof7 : runCachedNode 511 126043 Adaptive131Third130Node7 = false := by
  decide +kernel

#print axioms adaptive131Third130Proof7

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive131Third130Proof5 : runCachedNode 511 126043 Adaptive131Third130Node5 = false := by
  decide +kernel

#print axioms adaptive131Third130Proof5

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive131Third130Proof3 : runCachedNode 511 126043 Adaptive131Third130Node3 = false := by
  decide +kernel

#print axioms adaptive131Third130Proof3

end NineSeparatedSubsetSums
