import NineSeparatedSubsetSums.EightPoint131_125PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint131_125PackedAnchor0Part0 :
    ∀ j : Fin 120, 2314782 ≤ FourPointNumeric.octPackedCharge 131 125 20 packedOct131_125_0
      (2*((j.val : Int)+0)+0) := by decide +kernel

end NineSeparatedSubsetSums
