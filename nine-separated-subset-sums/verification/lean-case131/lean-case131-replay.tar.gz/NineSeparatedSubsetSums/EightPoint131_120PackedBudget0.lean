import NineSeparatedSubsetSums.EightPoint131_120PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct131_120_0_budget :
    FourPointNumeric.packedBudget 20 packedOct131_120_0 379 = 79661071 := by decide +kernel

#print axioms packedOct131_120_0_budget

end NineSeparatedSubsetSums
