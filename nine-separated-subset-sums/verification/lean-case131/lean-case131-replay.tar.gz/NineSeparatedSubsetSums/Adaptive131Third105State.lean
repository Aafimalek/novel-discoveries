import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive131Third105Node0 : CachedSearchNode :=
  ⟨4, 104, computeCenteredMask [148,131,105], 384, 50090⟩

end NineSeparatedSubsetSums
