import NineSeparatedSubsetSums.EightPointPackedGeometry
import NineSeparatedSubsetSums.EightPoint131_121PackedBudget0
import NineSeparatedSubsetSums.EightPoint131_121PackedAnchor0Part0
import NineSeparatedSubsetSums.EightPoint131_121PackedAnchor0Part1
import NineSeparatedSubsetSums.EightPoint131_121PackedBudget1
import NineSeparatedSubsetSums.EightPoint131_121PackedAnchor1Part0
import NineSeparatedSubsetSums.EightPoint131_121PackedAnchor1Part1

namespace NineSeparatedSubsetSums

private theorem packedOct131_121Anchor0 :
  ∀ j : Fin 477, ((j.val : Int)+131+121)%2=0 →
    2246789 ≤ FourPointNumeric.octPackedCharge 131 121 20 packedOct131_121_0 (j.val : Int) := by
  intro j hj
  let k := (j.val-0)/2
  have hk : k < 239 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+0 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint131_121PackedAnchor0Part0 z
    rwa [he,hrep] at ht
  let z : Fin 119 := ⟨k-120, by omega⟩
  have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
  have ht := eightPoint131_121PackedAnchor0Part1 z
  rwa [he,hrep] at ht

private theorem packedOct131_121Anchor1 :
  ∀ j : Fin 477, ((j.val : Int)+131+121)%2=1 →
    2249546 ≤ FourPointNumeric.octPackedCharge 131 121 20 packedOct131_121_1 (j.val : Int) := by
  intro j hj
  let k := (j.val-1)/2
  have hk : k < 238 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+1 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint131_121PackedAnchor1Part0 z
    rwa [he,hrep] at ht
  let z : Fin 118 := ⟨k-120, by omega⟩
  have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
  have ht := eightPoint131_121PackedAnchor1Part1 z
  rwa [he,hrep] at ht

def packedOctCertificate131_121_0 : EightPointCertificate 131 121 0 123909 :=
  eightPointCertificateOfPacked 131 121 0 123909 2246789 20 packedOct131_121_0 381 477
    (by decide +kernel) (by decide) packedOct131_121Anchor0
    (by rw [packedOct131_121_0_budget]; decide)

def packedOctCertificate131_121_1 : EightPointCertificate 131 121 1 123909 :=
  eightPointCertificateOfPacked 131 121 1 123909 2249546 20 packedOct131_121_1 388 477
    (by decide +kernel) (by decide) packedOct131_121Anchor1
    (by rw [packedOct131_121_1_budget]; decide)

theorem max148_second131_third121_eightPoint_moment_bound (tail : List ℕ) (len : tail.length=6)
    (distinct : (natSubsetSums (148::131::121::tail)).Nodup) :
    123909 ≤ ((148::131::121::tail).map (· ^ 2)).sum := by
  apply eightPointNatMomentLower 131 121 123909 tail len distinct
  intro p hp
  by_cases h : p=0
  · subst p
    exact packedOctCertificate131_121_0
  · have he : p=1 := hp.resolve_left h
    subst p
    exact packedOctCertificate131_121_1

#print axioms max148_second131_third121_eightPoint_moment_bound

end NineSeparatedSubsetSums
