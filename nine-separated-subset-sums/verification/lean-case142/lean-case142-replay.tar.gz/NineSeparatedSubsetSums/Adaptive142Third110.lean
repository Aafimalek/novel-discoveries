import NineSeparatedSubsetSums.Adaptive142Third110Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint142Checked

namespace NineSeparatedSubsetSums


theorem adaptive142Third110 : NoDescendingTailAfterThird 142 110 :=
  noDescendingThirdTail_of_cached 142 110 111874 (fun t ht nd => max148_second142_fourPoint_moment_bound (110::t) (by simp [ht]) nd) adaptive142Third110Proof0

#print axioms adaptive142Third110

end NineSeparatedSubsetSums
