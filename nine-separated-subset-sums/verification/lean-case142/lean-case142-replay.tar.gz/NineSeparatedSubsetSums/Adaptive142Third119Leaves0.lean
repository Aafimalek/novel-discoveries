import NineSeparatedSubsetSums.Adaptive142Third119State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third119Proof0 : runCachedNode 511 125684 Adaptive142Third119Node0 = false := by
  decide +kernel

#print axioms adaptive142Third119Proof0

end NineSeparatedSubsetSums
