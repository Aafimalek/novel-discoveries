import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive142Third123Node0 : CachedSearchNode :=
  ⟨4, 122, computeCenteredMask [148,142,123], 413, 57197⟩

end NineSeparatedSubsetSums
