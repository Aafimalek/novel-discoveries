import NineSeparatedSubsetSums.Adaptive142Third137State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third137Proof70 : runCachedNode 511 129593 Adaptive142Third137Node70 = false := by
  decide +kernel

#print axioms adaptive142Third137Proof70

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third137Proof98 : runCachedNode 511 129593 Adaptive142Third137Node98 = false := by
  decide +kernel

#print axioms adaptive142Third137Proof98

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third137Proof193 : runCachedNode 511 129593 Adaptive142Third137Node193 = false := by
  decide +kernel

#print axioms adaptive142Third137Proof193

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third137Proof154 : runCachedNode 511 129593 Adaptive142Third137Node154 = false := by
  decide +kernel

#print axioms adaptive142Third137Proof154

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third137Proof125 : runCachedNode 511 129593 Adaptive142Third137Node125 = false := by
  decide +kernel

#print axioms adaptive142Third137Proof125

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third137Proof192 : runCachedNode 511 129593 Adaptive142Third137Node192 = false := by
  decide +kernel

#print axioms adaptive142Third137Proof192

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third137Proof43 : runCachedNode 511 129593 Adaptive142Third137Node43 = false := by
  decide +kernel

#print axioms adaptive142Third137Proof43

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third137Proof87 : runCachedNode 511 129593 Adaptive142Third137Node87 = false := by
  decide +kernel

#print axioms adaptive142Third137Proof87

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third137Proof103 : runCachedNode 511 129593 Adaptive142Third137Node103 = false := by
  decide +kernel

#print axioms adaptive142Third137Proof103

end NineSeparatedSubsetSums
