import NineSeparatedSubsetSums.Adaptive142Third137State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third137Proof124 : runCachedNode 511 129593 Adaptive142Third137Node124 = false := by
  decide +kernel

#print axioms adaptive142Third137Proof124

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third137Proof40 : runCachedNode 511 129593 Adaptive142Third137Node40 = false := by
  decide +kernel

#print axioms adaptive142Third137Proof40

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third137Proof97 : runCachedNode 511 129593 Adaptive142Third137Node97 = false := by
  decide +kernel

#print axioms adaptive142Third137Proof97

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third137Proof42 : runCachedNode 511 129593 Adaptive142Third137Node42 = false := by
  decide +kernel

#print axioms adaptive142Third137Proof42

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third137Proof151 : runCachedNode 511 129593 Adaptive142Third137Node151 = false := by
  decide +kernel

#print axioms adaptive142Third137Proof151

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third137Proof12 : runCachedNode 511 129593 Adaptive142Third137Node12 = false := by
  decide +kernel

#print axioms adaptive142Third137Proof12

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third137Proof69 : runCachedNode 511 129593 Adaptive142Third137Node69 = false := by
  decide +kernel

#print axioms adaptive142Third137Proof69

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third137Proof11 : runCachedNode 511 129593 Adaptive142Third137Node11 = false := by
  decide +kernel

#print axioms adaptive142Third137Proof11

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third137Proof95 : runCachedNode 511 129593 Adaptive142Third137Node95 = false := by
  decide +kernel

#print axioms adaptive142Third137Proof95

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third137Proof86 : runCachedNode 511 129593 Adaptive142Third137Node86 = false := by
  decide +kernel

#print axioms adaptive142Third137Proof86

end NineSeparatedSubsetSums
