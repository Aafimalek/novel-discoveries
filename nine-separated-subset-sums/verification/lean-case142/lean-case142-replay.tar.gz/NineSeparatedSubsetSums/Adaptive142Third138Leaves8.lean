import NineSeparatedSubsetSums.Adaptive142Third138State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third138Proof18 : runCachedNode 511 129778 Adaptive142Third138Node18 = false := by
  decide +kernel

#print axioms adaptive142Third138Proof18

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third138Proof73 : runCachedNode 511 129778 Adaptive142Third138Node73 = false := by
  decide +kernel

#print axioms adaptive142Third138Proof73

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third138Proof13 : runCachedNode 511 129778 Adaptive142Third138Node13 = false := by
  decide +kernel

#print axioms adaptive142Third138Proof13

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third138Proof26 : runCachedNode 511 129778 Adaptive142Third138Node26 = false := by
  decide +kernel

#print axioms adaptive142Third138Proof26

end NineSeparatedSubsetSums
