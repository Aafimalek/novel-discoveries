import NineSeparatedSubsetSums.EightPoint142_125PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct142_125_1_budget :
    FourPointNumeric.packedBudget 20 packedOct142_125_1 482 = 87767016 := by decide +kernel

#print axioms packedOct142_125_1_budget

end NineSeparatedSubsetSums
