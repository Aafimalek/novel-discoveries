import NineSeparatedSubsetSums.Adaptive142Third136State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third136Proof34 : runCachedNode 511 129404 Adaptive142Third136Node34 = false := by
  decide +kernel

#print axioms adaptive142Third136Proof34

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third136Proof193 : runCachedNode 511 129404 Adaptive142Third136Node193 = false := by
  decide +kernel

#print axioms adaptive142Third136Proof193

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third136Proof221 : runCachedNode 511 129404 Adaptive142Third136Node221 = false := by
  decide +kernel

#print axioms adaptive142Third136Proof221

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third136Proof36 : runCachedNode 511 129404 Adaptive142Third136Node36 = false := by
  decide +kernel

#print axioms adaptive142Third136Proof36

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third136Proof106 : runCachedNode 511 129404 Adaptive142Third136Node106 = false := by
  decide +kernel

#print axioms adaptive142Third136Proof106

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third136Proof219 : runCachedNode 511 129404 Adaptive142Third136Node219 = false := by
  decide +kernel

#print axioms adaptive142Third136Proof219

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third136Proof35 : runCachedNode 511 129404 Adaptive142Third136Node35 = false := by
  decide +kernel

#print axioms adaptive142Third136Proof35

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third136Proof217 : runCachedNode 511 129404 Adaptive142Third136Node217 = false := by
  decide +kernel

#print axioms adaptive142Third136Proof217

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third136Proof57 : runCachedNode 511 129404 Adaptive142Third136Node57 = false := by
  decide +kernel

#print axioms adaptive142Third136Proof57

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third136Proof218 : runCachedNode 511 129404 Adaptive142Third136Node218 = false := by
  decide +kernel

#print axioms adaptive142Third136Proof218

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third136Proof159 : runCachedNode 511 129404 Adaptive142Third136Node159 = false := by
  decide +kernel

#print axioms adaptive142Third136Proof159

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third136Proof7 : runCachedNode 511 129404 Adaptive142Third136Node7 = false := by
  decide +kernel

#print axioms adaptive142Third136Proof7

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third136Proof56 : runCachedNode 511 129404 Adaptive142Third136Node56 = false := by
  decide +kernel

#print axioms adaptive142Third136Proof56

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third136Proof105 : runCachedNode 511 129404 Adaptive142Third136Node105 = false := by
  decide +kernel

#print axioms adaptive142Third136Proof105

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third136Proof81 : runCachedNode 511 129404 Adaptive142Third136Node81 = false := by
  decide +kernel

#print axioms adaptive142Third136Proof81

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third136Proof156 : runCachedNode 511 129404 Adaptive142Third136Node156 = false := by
  decide +kernel

#print axioms adaptive142Third136Proof156

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third136Proof79 : runCachedNode 511 129404 Adaptive142Third136Node79 = false := by
  decide +kernel

#print axioms adaptive142Third136Proof79

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third136Proof129 : runCachedNode 511 129404 Adaptive142Third136Node129 = false := by
  decide +kernel

#print axioms adaptive142Third136Proof129

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third136Proof176 : runCachedNode 511 129404 Adaptive142Third136Node176 = false := by
  decide +kernel

#print axioms adaptive142Third136Proof176

end NineSeparatedSubsetSums
