import NineSeparatedSubsetSums.Adaptive142Third139State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third139Proof104 : runCachedNode 511 129933 Adaptive142Third139Node104 = false := by
  decide +kernel

#print axioms adaptive142Third139Proof104

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third139Proof79 : runCachedNode 511 129933 Adaptive142Third139Node79 = false := by
  decide +kernel

#print axioms adaptive142Third139Proof79

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third139Proof277 : runCachedNode 511 129933 Adaptive142Third139Node277 = false := by
  decide +kernel

#print axioms adaptive142Third139Proof277

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third139Proof32 : runCachedNode 511 129933 Adaptive142Third139Node32 = false := by
  decide +kernel

#print axioms adaptive142Third139Proof32

end NineSeparatedSubsetSums
