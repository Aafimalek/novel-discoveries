import NineSeparatedSubsetSums.Adaptive142Third135State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third135Proof43 : runCachedNode 511 129264 Adaptive142Third135Node43 = false := by
  decide +kernel

#print axioms adaptive142Third135Proof43

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third135Proof11 : runCachedNode 511 129264 Adaptive142Third135Node11 = false := by
  decide +kernel

#print axioms adaptive142Third135Proof11

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third135Proof67 : runCachedNode 511 129264 Adaptive142Third135Node67 = false := by
  decide +kernel

#print axioms adaptive142Third135Proof67

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third135Proof42 : runCachedNode 511 129264 Adaptive142Third135Node42 = false := by
  decide +kernel

#print axioms adaptive142Third135Proof42

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third135Proof95 : runCachedNode 511 129264 Adaptive142Third135Node95 = false := by
  decide +kernel

#print axioms adaptive142Third135Proof95

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third135Proof10 : runCachedNode 511 129264 Adaptive142Third135Node10 = false := by
  decide +kernel

#print axioms adaptive142Third135Proof10

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third135Proof91 : runCachedNode 511 129264 Adaptive142Third135Node91 = false := by
  decide +kernel

#print axioms adaptive142Third135Proof91

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third135Proof93 : runCachedNode 511 129264 Adaptive142Third135Node93 = false := by
  decide +kernel

#print axioms adaptive142Third135Proof93

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third135Proof65 : runCachedNode 511 129264 Adaptive142Third135Node65 = false := by
  decide +kernel

#print axioms adaptive142Third135Proof65

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third135Proof66 : runCachedNode 511 129264 Adaptive142Third135Node66 = false := by
  decide +kernel

#print axioms adaptive142Third135Proof66

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third135Proof9 : runCachedNode 511 129264 Adaptive142Third135Node9 = false := by
  decide +kernel

#print axioms adaptive142Third135Proof9

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third135Proof38 : runCachedNode 511 129264 Adaptive142Third135Node38 = false := by
  decide +kernel

#print axioms adaptive142Third135Proof38

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third135Proof8 : runCachedNode 511 129264 Adaptive142Third135Node8 = false := by
  decide +kernel

#print axioms adaptive142Third135Proof8

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third135Proof90 : runCachedNode 511 129264 Adaptive142Third135Node90 = false := by
  decide +kernel

#print axioms adaptive142Third135Proof90

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third135Proof39 : runCachedNode 511 129264 Adaptive142Third135Node39 = false := by
  decide +kernel

#print axioms adaptive142Third135Proof39

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third135Proof62 : runCachedNode 511 129264 Adaptive142Third135Node62 = false := by
  decide +kernel

#print axioms adaptive142Third135Proof62

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third135Proof37 : runCachedNode 511 129264 Adaptive142Third135Node37 = false := by
  decide +kernel

#print axioms adaptive142Third135Proof37

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third135Proof35 : runCachedNode 511 129264 Adaptive142Third135Node35 = false := by
  decide +kernel

#print axioms adaptive142Third135Proof35

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third135Proof64 : runCachedNode 511 129264 Adaptive142Third135Node64 = false := by
  decide +kernel

#print axioms adaptive142Third135Proof64

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third135Proof63 : runCachedNode 511 129264 Adaptive142Third135Node63 = false := by
  decide +kernel

#print axioms adaptive142Third135Proof63

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third135Proof24 : runCachedNode 511 129264 Adaptive142Third135Node24 = false := by
  decide +kernel

#print axioms adaptive142Third135Proof24

end NineSeparatedSubsetSums
