import NineSeparatedSubsetSums.Adaptive142Third134State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third134Proof21 : runCachedNode 511 129144 Adaptive142Third134Node21 = false := by
  decide +kernel

#print axioms adaptive142Third134Proof21

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third134Proof44 : runCachedNode 511 129144 Adaptive142Third134Node44 = false := by
  decide +kernel

#print axioms adaptive142Third134Proof44

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third134Proof1 : runCachedNode 511 129144 Adaptive142Third134Node1 = false := by
  decide +kernel

#print axioms adaptive142Third134Proof1

end NineSeparatedSubsetSums
