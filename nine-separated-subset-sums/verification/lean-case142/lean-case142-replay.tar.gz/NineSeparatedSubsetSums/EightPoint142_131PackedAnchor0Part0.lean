import NineSeparatedSubsetSums.EightPoint142_131PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint142_131PackedAnchor0Part0 :
    ∀ j : Fin 120, 2431527 ≤ FourPointNumeric.octPackedCharge 142 131 20 packedOct142_131_0
      (2*((j.val : Int)+0)+1) := by decide +kernel

end NineSeparatedSubsetSums
