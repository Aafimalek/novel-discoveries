import NineSeparatedSubsetSums.Adaptive142Third139State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third139Proof47 : runCachedNode 511 129933 Adaptive142Third139Node47 = false := by
  decide +kernel

#print axioms adaptive142Third139Proof47

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third139Proof98 : runCachedNode 511 129933 Adaptive142Third139Node98 = false := by
  decide +kernel

#print axioms adaptive142Third139Proof98

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third139Proof97 : runCachedNode 511 129933 Adaptive142Third139Node97 = false := by
  decide +kernel

#print axioms adaptive142Third139Proof97

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third139Proof206 : runCachedNode 511 129933 Adaptive142Third139Node206 = false := by
  decide +kernel

#print axioms adaptive142Third139Proof206

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third139Proof247 : runCachedNode 511 129933 Adaptive142Third139Node247 = false := by
  decide +kernel

#print axioms adaptive142Third139Proof247

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third139Proof13 : runCachedNode 511 129933 Adaptive142Third139Node13 = false := by
  decide +kernel

#print axioms adaptive142Third139Proof13

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third139Proof178 : runCachedNode 511 129933 Adaptive142Third139Node178 = false := by
  decide +kernel

#print axioms adaptive142Third139Proof178

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third139Proof96 : runCachedNode 511 129933 Adaptive142Third139Node96 = false := by
  decide +kernel

#print axioms adaptive142Third139Proof96

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third139Proof27 : runCachedNode 511 129933 Adaptive142Third139Node27 = false := by
  decide +kernel

#print axioms adaptive142Third139Proof27

end NineSeparatedSubsetSums
