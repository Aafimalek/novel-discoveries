import NineSeparatedSubsetSums.EightPoint142_126PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct142_126_1_budget :
    FourPointNumeric.packedBudget 20 packedOct142_126_1 276 = 86034358 := by decide +kernel

#print axioms packedOct142_126_1_budget

end NineSeparatedSubsetSums
