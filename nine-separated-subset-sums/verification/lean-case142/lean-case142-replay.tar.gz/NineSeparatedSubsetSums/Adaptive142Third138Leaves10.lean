import NineSeparatedSubsetSums.Adaptive142Third138State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third138Proof47 : runCachedNode 511 129778 Adaptive142Third138Node47 = false := by
  decide +kernel

#print axioms adaptive142Third138Proof47

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third138Proof170 : runCachedNode 511 129778 Adaptive142Third138Node170 = false := by
  decide +kernel

#print axioms adaptive142Third138Proof170

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third138Proof164 : runCachedNode 511 129778 Adaptive142Third138Node164 = false := by
  decide +kernel

#print axioms adaptive142Third138Proof164

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third138Proof89 : runCachedNode 511 129778 Adaptive142Third138Node89 = false := by
  decide +kernel

#print axioms adaptive142Third138Proof89

end NineSeparatedSubsetSums
