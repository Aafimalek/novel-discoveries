import NineSeparatedSubsetSums.Adaptive142Third138State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third138Proof238 : runCachedNode 511 129778 Adaptive142Third138Node238 = false := by
  decide +kernel

#print axioms adaptive142Third138Proof238

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third138Proof129 : runCachedNode 511 129778 Adaptive142Third138Node129 = false := by
  decide +kernel

#print axioms adaptive142Third138Proof129

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third138Proof48 : runCachedNode 511 129778 Adaptive142Third138Node48 = false := by
  decide +kernel

#print axioms adaptive142Third138Proof48

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third138Proof200 : runCachedNode 511 129778 Adaptive142Third138Node200 = false := by
  decide +kernel

#print axioms adaptive142Third138Proof200

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third138Proof131 : runCachedNode 511 129778 Adaptive142Third138Node131 = false := by
  decide +kernel

#print axioms adaptive142Third138Proof131

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third138Proof130 : runCachedNode 511 129778 Adaptive142Third138Node130 = false := by
  decide +kernel

#print axioms adaptive142Third138Proof130

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third138Proof39 : runCachedNode 511 129778 Adaptive142Third138Node39 = false := by
  decide +kernel

#print axioms adaptive142Third138Proof39

end NineSeparatedSubsetSums
