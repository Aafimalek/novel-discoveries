import NineSeparatedSubsetSums.Adaptive142Third141State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third141Proof383 : runCachedNode 511 130276 Adaptive142Third141Node383 = false := by
  decide +kernel

#print axioms adaptive142Third141Proof383

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third141Proof339 : runCachedNode 511 130276 Adaptive142Third141Node339 = false := by
  decide +kernel

#print axioms adaptive142Third141Proof339

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third141Proof14 : runCachedNode 511 130276 Adaptive142Third141Node14 = false := by
  decide +kernel

#print axioms adaptive142Third141Proof14

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third141Proof2 : runCachedNode 511 130276 Adaptive142Third141Node2 = false := by
  decide +kernel

#print axioms adaptive142Third141Proof2

end NineSeparatedSubsetSums
