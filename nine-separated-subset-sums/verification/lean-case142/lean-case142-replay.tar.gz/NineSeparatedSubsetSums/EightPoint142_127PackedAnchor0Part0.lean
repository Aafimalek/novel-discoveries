import NineSeparatedSubsetSums.EightPoint142_127PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint142_127PackedAnchor0Part0 :
    ∀ j : Fin 120, 2383430 ≤ FourPointNumeric.octPackedCharge 142 127 20 packedOct142_127_0
      (2*((j.val : Int)+0)+1) := by decide +kernel

end NineSeparatedSubsetSums
