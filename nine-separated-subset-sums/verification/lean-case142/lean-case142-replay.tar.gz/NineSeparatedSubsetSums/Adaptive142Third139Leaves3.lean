import NineSeparatedSubsetSums.Adaptive142Third139State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third139Proof103 : runCachedNode 511 129933 Adaptive142Third139Node103 = false := by
  decide +kernel

#print axioms adaptive142Third139Proof103

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third139Proof14 : runCachedNode 511 129933 Adaptive142Third139Node14 = false := by
  decide +kernel

#print axioms adaptive142Third139Proof14

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third139Proof25 : runCachedNode 511 129933 Adaptive142Third139Node25 = false := by
  decide +kernel

#print axioms adaptive142Third139Proof25

end NineSeparatedSubsetSums
