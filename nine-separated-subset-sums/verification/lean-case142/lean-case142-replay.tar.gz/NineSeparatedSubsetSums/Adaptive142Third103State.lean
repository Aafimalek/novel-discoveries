import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive142Third103Node0 : CachedSearchNode :=
  ⟨4, 102, computeCenteredMask [148,142,103], 393, 52677⟩

end NineSeparatedSubsetSums
