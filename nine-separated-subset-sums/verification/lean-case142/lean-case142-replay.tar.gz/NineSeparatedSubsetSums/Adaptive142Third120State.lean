import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive142Third120Node0 : CachedSearchNode :=
  ⟨4, 119, computeCenteredMask [148,142,120], 410, 56468⟩

end NineSeparatedSubsetSums
