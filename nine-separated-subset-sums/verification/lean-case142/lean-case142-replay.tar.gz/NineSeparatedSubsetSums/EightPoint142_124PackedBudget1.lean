import NineSeparatedSubsetSums.EightPoint142_124PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct142_124_1_budget :
    FourPointNumeric.packedBudget 20 packedOct142_124_1 480 = 84091894 := by decide +kernel

#print axioms packedOct142_124_1_budget

end NineSeparatedSubsetSums
