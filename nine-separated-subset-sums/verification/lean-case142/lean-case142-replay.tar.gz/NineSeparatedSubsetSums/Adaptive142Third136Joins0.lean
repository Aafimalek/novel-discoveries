import NineSeparatedSubsetSums.Adaptive142Third136State
import NineSeparatedSubsetSums.Adaptive142Third136Leaves4
import NineSeparatedSubsetSums.Adaptive142Third136Leaves8
import NineSeparatedSubsetSums.Adaptive142Third136Leaves22
import NineSeparatedSubsetSums.Adaptive142Third136Leaves21
import NineSeparatedSubsetSums.Adaptive142Third136Leaves20
import NineSeparatedSubsetSums.Adaptive142Third136Leaves6
import NineSeparatedSubsetSums.Adaptive142Third136Leaves19
import NineSeparatedSubsetSums.Adaptive142Third136Leaves13
import NineSeparatedSubsetSums.Adaptive142Third136Leaves1
import NineSeparatedSubsetSums.Adaptive142Third136Leaves15
import NineSeparatedSubsetSums.Adaptive142Third136Leaves10
import NineSeparatedSubsetSums.Adaptive142Third136Leaves9
import NineSeparatedSubsetSums.Adaptive142Third136Leaves12
import NineSeparatedSubsetSums.Adaptive142Third136Leaves11
import NineSeparatedSubsetSums.Adaptive142Third136Leaves18
import NineSeparatedSubsetSums.Adaptive142Third136Leaves14
import NineSeparatedSubsetSums.Adaptive142Third136Leaves16
import NineSeparatedSubsetSums.Adaptive142Third136Leaves0
import NineSeparatedSubsetSums.Adaptive142Third136Leaves23
import NineSeparatedSubsetSums.Adaptive142Third136Leaves17
import NineSeparatedSubsetSums.Adaptive142Third136Leaves3
import NineSeparatedSubsetSums.Adaptive142Third136Leaves7
import NineSeparatedSubsetSums.Adaptive142Third136Leaves5
import NineSeparatedSubsetSums.Adaptive142Third136Leaves2

namespace NineSeparatedSubsetSums

theorem adaptive142Third136Proof19 : runCachedNode 511 129404 Adaptive142Third136Node19 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 129404 Adaptive142Third136Node19 = [105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 117, 118, 119, 120, 121, 123, 124, 125, 126, 127] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive142Third136Proof20
  · exact adaptive142Third136Proof21
  · exact adaptive142Third136Proof22
  · exact adaptive142Third136Proof23
  · exact adaptive142Third136Proof24
  · exact adaptive142Third136Proof25
  · exact adaptive142Third136Proof26
  · exact adaptive142Third136Proof27
  · exact adaptive142Third136Proof28
  · exact adaptive142Third136Proof29
  · exact adaptive142Third136Proof30
  · exact adaptive142Third136Proof31
  · exact adaptive142Third136Proof32
  · exact adaptive142Third136Proof33
  · exact adaptive142Third136Proof34
  · exact adaptive142Third136Proof35
  · exact adaptive142Third136Proof36
  · exact adaptive142Third136Proof37
  · exact adaptive142Third136Proof38
  · exact adaptive142Third136Proof39
  · exact adaptive142Third136Proof40

#print axioms adaptive142Third136Proof19

theorem adaptive142Third136Proof41 : runCachedNode 511 129404 Adaptive142Third136Node41 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 129404 Adaptive142Third136Node41 = [105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 118, 119, 120, 121, 122, 124, 125, 126, 127, 128] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive142Third136Proof42
  · exact adaptive142Third136Proof43
  · exact adaptive142Third136Proof44
  · exact adaptive142Third136Proof45
  · exact adaptive142Third136Proof46
  · exact adaptive142Third136Proof47
  · exact adaptive142Third136Proof48
  · exact adaptive142Third136Proof49
  · exact adaptive142Third136Proof50
  · exact adaptive142Third136Proof51
  · exact adaptive142Third136Proof52
  · exact adaptive142Third136Proof53
  · exact adaptive142Third136Proof54
  · exact adaptive142Third136Proof55
  · exact adaptive142Third136Proof56
  · exact adaptive142Third136Proof57
  · exact adaptive142Third136Proof58
  · exact adaptive142Third136Proof59
  · exact adaptive142Third136Proof60
  · exact adaptive142Third136Proof61
  · exact adaptive142Third136Proof62
  · exact adaptive142Third136Proof63

#print axioms adaptive142Third136Proof41

theorem adaptive142Third136Proof64 : runCachedNode 511 129404 Adaptive142Third136Node64 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 129404 Adaptive142Third136Node64 = [104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 120, 121, 122, 123, 124, 126, 127, 128, 129] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive142Third136Proof65
  · exact adaptive142Third136Proof66
  · exact adaptive142Third136Proof67
  · exact adaptive142Third136Proof68
  · exact adaptive142Third136Proof69
  · exact adaptive142Third136Proof70
  · exact adaptive142Third136Proof71
  · exact adaptive142Third136Proof72
  · exact adaptive142Third136Proof73
  · exact adaptive142Third136Proof74
  · exact adaptive142Third136Proof75
  · exact adaptive142Third136Proof76
  · exact adaptive142Third136Proof77
  · exact adaptive142Third136Proof78
  · exact adaptive142Third136Proof79
  · exact adaptive142Third136Proof80
  · exact adaptive142Third136Proof81
  · exact adaptive142Third136Proof82
  · exact adaptive142Third136Proof83
  · exact adaptive142Third136Proof84
  · exact adaptive142Third136Proof85
  · exact adaptive142Third136Proof86
  · exact adaptive142Third136Proof87
  · exact adaptive142Third136Proof88

#print axioms adaptive142Third136Proof64

theorem adaptive142Third136Proof89 : runCachedNode 511 129404 Adaptive142Third136Node89 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 129404 Adaptive142Third136Node89 = [104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 121, 122, 123, 124, 125, 127, 128, 129, 131] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive142Third136Proof90
  · exact adaptive142Third136Proof91
  · exact adaptive142Third136Proof92
  · exact adaptive142Third136Proof93
  · exact adaptive142Third136Proof94
  · exact adaptive142Third136Proof95
  · exact adaptive142Third136Proof96
  · exact adaptive142Third136Proof97
  · exact adaptive142Third136Proof98
  · exact adaptive142Third136Proof99
  · exact adaptive142Third136Proof100
  · exact adaptive142Third136Proof101
  · exact adaptive142Third136Proof102
  · exact adaptive142Third136Proof103
  · exact adaptive142Third136Proof104
  · exact adaptive142Third136Proof105
  · exact adaptive142Third136Proof106
  · exact adaptive142Third136Proof107
  · exact adaptive142Third136Proof108
  · exact adaptive142Third136Proof109
  · exact adaptive142Third136Proof110
  · exact adaptive142Third136Proof111
  · exact adaptive142Third136Proof112
  · exact adaptive142Third136Proof113
  · exact adaptive142Third136Proof114

#print axioms adaptive142Third136Proof89

theorem adaptive142Third136Proof115 : runCachedNode 511 129404 Adaptive142Third136Node115 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 129404 Adaptive142Third136Node115 = [104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 122, 123, 124, 125, 126, 128, 129, 131, 132] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive142Third136Proof116
  · exact adaptive142Third136Proof117
  · exact adaptive142Third136Proof118
  · exact adaptive142Third136Proof119
  · exact adaptive142Third136Proof120
  · exact adaptive142Third136Proof121
  · exact adaptive142Third136Proof122
  · exact adaptive142Third136Proof123
  · exact adaptive142Third136Proof124
  · exact adaptive142Third136Proof125
  · exact adaptive142Third136Proof126
  · exact adaptive142Third136Proof127
  · exact adaptive142Third136Proof128
  · exact adaptive142Third136Proof129
  · exact adaptive142Third136Proof130
  · exact adaptive142Third136Proof131
  · exact adaptive142Third136Proof132
  · exact adaptive142Third136Proof133
  · exact adaptive142Third136Proof134
  · exact adaptive142Third136Proof135
  · exact adaptive142Third136Proof136
  · exact adaptive142Third136Proof137
  · exact adaptive142Third136Proof138
  · exact adaptive142Third136Proof139
  · exact adaptive142Third136Proof140
  · exact adaptive142Third136Proof141

#print axioms adaptive142Third136Proof115

theorem adaptive142Third136Proof169 : runCachedNode 511 129404 Adaptive142Third136Node169 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 129404 Adaptive142Third136Node169 = [93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 113, 114, 115, 116, 117, 119, 121, 123, 125, 127, 129, 131] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive142Third136Proof170
  · exact adaptive142Third136Proof171
  · exact adaptive142Third136Proof172
  · exact adaptive142Third136Proof173
  · exact adaptive142Third136Proof174
  · exact adaptive142Third136Proof175
  · exact adaptive142Third136Proof176
  · exact adaptive142Third136Proof177
  · exact adaptive142Third136Proof178
  · exact adaptive142Third136Proof179
  · exact adaptive142Third136Proof180
  · exact adaptive142Third136Proof181
  · exact adaptive142Third136Proof182
  · exact adaptive142Third136Proof183
  · exact adaptive142Third136Proof184
  · exact adaptive142Third136Proof185
  · exact adaptive142Third136Proof186
  · exact adaptive142Third136Proof187
  · exact adaptive142Third136Proof188
  · exact adaptive142Third136Proof189
  · exact adaptive142Third136Proof190
  · exact adaptive142Third136Proof191
  · exact adaptive142Third136Proof192
  · exact adaptive142Third136Proof193
  · exact adaptive142Third136Proof194
  · exact adaptive142Third136Proof195
  · exact adaptive142Third136Proof196
  · exact adaptive142Third136Proof197
  · exact adaptive142Third136Proof198
  · exact adaptive142Third136Proof199
  · exact adaptive142Third136Proof200

#print axioms adaptive142Third136Proof169

theorem adaptive142Third136Proof142 : runCachedNode 511 129404 Adaptive142Third136Node142 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 129404 Adaptive142Third136Node142 = [103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 123, 124, 125, 126, 127, 129, 131, 132, 133] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive142Third136Proof143
  · exact adaptive142Third136Proof144
  · exact adaptive142Third136Proof145
  · exact adaptive142Third136Proof146
  · exact adaptive142Third136Proof147
  · exact adaptive142Third136Proof148
  · exact adaptive142Third136Proof149
  · exact adaptive142Third136Proof150
  · exact adaptive142Third136Proof151
  · exact adaptive142Third136Proof152
  · exact adaptive142Third136Proof153
  · exact adaptive142Third136Proof154
  · exact adaptive142Third136Proof155
  · exact adaptive142Third136Proof156
  · exact adaptive142Third136Proof157
  · exact adaptive142Third136Proof158
  · exact adaptive142Third136Proof159
  · exact adaptive142Third136Proof160
  · exact adaptive142Third136Proof161
  · exact adaptive142Third136Proof162
  · exact adaptive142Third136Proof163
  · exact adaptive142Third136Proof164
  · exact adaptive142Third136Proof165
  · exact adaptive142Third136Proof166
  · exact adaptive142Third136Proof167
  · exact adaptive142Third136Proof168
  · exact adaptive142Third136Proof169
  · exact adaptive142Third136Proof201

#print axioms adaptive142Third136Proof142

theorem adaptive142Third136Proof202 : runCachedNode 511 129404 Adaptive142Third136Node202 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 129404 Adaptive142Third136Node202 = [103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 124, 125, 126, 127, 128, 131, 132, 133, 134] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive142Third136Proof203
  · exact adaptive142Third136Proof204
  · exact adaptive142Third136Proof205
  · exact adaptive142Third136Proof206
  · exact adaptive142Third136Proof207
  · exact adaptive142Third136Proof208
  · exact adaptive142Third136Proof209
  · exact adaptive142Third136Proof210
  · exact adaptive142Third136Proof211
  · exact adaptive142Third136Proof212
  · exact adaptive142Third136Proof213
  · exact adaptive142Third136Proof214
  · exact adaptive142Third136Proof215
  · exact adaptive142Third136Proof216
  · exact adaptive142Third136Proof217
  · exact adaptive142Third136Proof218
  · exact adaptive142Third136Proof219
  · exact adaptive142Third136Proof220
  · exact adaptive142Third136Proof221
  · exact adaptive142Third136Proof222
  · exact adaptive142Third136Proof223
  · exact adaptive142Third136Proof224
  · exact adaptive142Third136Proof225
  · exact adaptive142Third136Proof226
  · exact adaptive142Third136Proof227
  · exact adaptive142Third136Proof228
  · exact adaptive142Third136Proof229
  · exact adaptive142Third136Proof230
  · exact adaptive142Third136Proof231

#print axioms adaptive142Third136Proof202

end NineSeparatedSubsetSums
