import NineSeparatedSubsetSums.Adaptive142Third107Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint142Checked

namespace NineSeparatedSubsetSums


theorem adaptive142Third107 : NoDescendingTailAfterThird 142 107 :=
  noDescendingThirdTail_of_cached 142 107 111874 (fun t ht nd => max148_second142_fourPoint_moment_bound (107::t) (by simp [ht]) nd) adaptive142Third107Proof0

#print axioms adaptive142Third107

end NineSeparatedSubsetSums
