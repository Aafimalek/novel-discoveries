import NineSeparatedSubsetSums.Adaptive142Third135State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third135Proof97 : runCachedNode 511 129264 Adaptive142Third135Node97 = false := by
  decide +kernel

#print axioms adaptive142Third135Proof97

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third135Proof46 : runCachedNode 511 129264 Adaptive142Third135Node46 = false := by
  decide +kernel

#print axioms adaptive142Third135Proof46

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third135Proof69 : runCachedNode 511 129264 Adaptive142Third135Node69 = false := by
  decide +kernel

#print axioms adaptive142Third135Proof69

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third135Proof40 : runCachedNode 511 129264 Adaptive142Third135Node40 = false := by
  decide +kernel

#print axioms adaptive142Third135Proof40

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third135Proof12 : runCachedNode 511 129264 Adaptive142Third135Node12 = false := by
  decide +kernel

#print axioms adaptive142Third135Proof12

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third135Proof94 : runCachedNode 511 129264 Adaptive142Third135Node94 = false := by
  decide +kernel

#print axioms adaptive142Third135Proof94

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third135Proof41 : runCachedNode 511 129264 Adaptive142Third135Node41 = false := by
  decide +kernel

#print axioms adaptive142Third135Proof41

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third135Proof70 : runCachedNode 511 129264 Adaptive142Third135Node70 = false := by
  decide +kernel

#print axioms adaptive142Third135Proof70

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third135Proof68 : runCachedNode 511 129264 Adaptive142Third135Node68 = false := by
  decide +kernel

#print axioms adaptive142Third135Proof68

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third135Proof33 : runCachedNode 511 129264 Adaptive142Third135Node33 = false := by
  decide +kernel

#print axioms adaptive142Third135Proof33

end NineSeparatedSubsetSums
