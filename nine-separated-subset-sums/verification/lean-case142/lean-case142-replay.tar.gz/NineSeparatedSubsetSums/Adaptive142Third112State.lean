import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive142Third112Node0 : CachedSearchNode :=
  ⟨4, 111, computeCenteredMask [148,142,112], 402, 54612⟩

end NineSeparatedSubsetSums
