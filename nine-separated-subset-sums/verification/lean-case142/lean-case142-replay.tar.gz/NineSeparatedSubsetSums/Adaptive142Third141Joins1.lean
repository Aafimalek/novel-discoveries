import NineSeparatedSubsetSums.Adaptive142Third141State
import NineSeparatedSubsetSums.Adaptive142Third141Leaves37
import NineSeparatedSubsetSums.Adaptive142Third141Leaves36
import NineSeparatedSubsetSums.Adaptive142Third141Leaves35
import NineSeparatedSubsetSums.Adaptive142Third141Leaves34
import NineSeparatedSubsetSums.Adaptive142Third141Leaves33
import NineSeparatedSubsetSums.Adaptive142Third141Leaves16
import NineSeparatedSubsetSums.Adaptive142Third141Leaves31
import NineSeparatedSubsetSums.Adaptive142Third141Leaves30
import NineSeparatedSubsetSums.Adaptive142Third141Leaves29
import NineSeparatedSubsetSums.Adaptive142Third141Leaves28
import NineSeparatedSubsetSums.Adaptive142Third141Leaves27
import NineSeparatedSubsetSums.Adaptive142Third141Leaves24
import NineSeparatedSubsetSums.Adaptive142Third141Leaves23
import NineSeparatedSubsetSums.Adaptive142Third141Leaves19
import NineSeparatedSubsetSums.Adaptive142Third141Leaves13
import NineSeparatedSubsetSums.Adaptive142Third141Leaves3
import NineSeparatedSubsetSums.Adaptive142Third141Leaves6
import NineSeparatedSubsetSums.Adaptive142Third141Leaves32
import NineSeparatedSubsetSums.Adaptive142Third141Leaves25
import NineSeparatedSubsetSums.Adaptive142Third141Leaves14
import NineSeparatedSubsetSums.Adaptive142Third141Leaves38
import NineSeparatedSubsetSums.Adaptive142Third141Leaves26
import NineSeparatedSubsetSums.Adaptive142Third141Leaves22
import NineSeparatedSubsetSums.Adaptive142Third141Leaves20
import NineSeparatedSubsetSums.Adaptive142Third141Leaves17
import NineSeparatedSubsetSums.Adaptive142Third141Leaves21
import NineSeparatedSubsetSums.Adaptive142Third141Leaves18
import NineSeparatedSubsetSums.Adaptive142Third141Leaves12
import NineSeparatedSubsetSums.Adaptive142Third141Leaves2
import NineSeparatedSubsetSums.Adaptive142Third141Leaves0
import NineSeparatedSubsetSums.Adaptive142Third141Leaves1
import NineSeparatedSubsetSums.Adaptive142Third141Leaves9
import NineSeparatedSubsetSums.Adaptive142Third141Leaves10
import NineSeparatedSubsetSums.Adaptive142Third141Leaves5
import NineSeparatedSubsetSums.Adaptive142Third141Leaves8
import NineSeparatedSubsetSums.Adaptive142Third141Joins0

namespace NineSeparatedSubsetSums

theorem adaptive142Third141Proof276 : runCachedNode 511 130276 Adaptive142Third141Node276 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130276 Adaptive142Third141Node276 = [101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 134, 136, 137] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive142Third141Proof277
  · exact adaptive142Third141Proof278
  · exact adaptive142Third141Proof279
  · exact adaptive142Third141Proof280
  · exact adaptive142Third141Proof281
  · exact adaptive142Third141Proof282
  · exact adaptive142Third141Proof283
  · exact adaptive142Third141Proof284
  · exact adaptive142Third141Proof285
  · exact adaptive142Third141Proof286
  · exact adaptive142Third141Proof287
  · exact adaptive142Third141Proof288
  · exact adaptive142Third141Proof289
  · exact adaptive142Third141Proof290
  · exact adaptive142Third141Proof291
  · exact adaptive142Third141Proof292
  · exact adaptive142Third141Proof293
  · exact adaptive142Third141Proof294
  · exact adaptive142Third141Proof295
  · exact adaptive142Third141Proof296
  · exact adaptive142Third141Proof297
  · exact adaptive142Third141Proof298
  · exact adaptive142Third141Proof299
  · exact adaptive142Third141Proof300
  · exact adaptive142Third141Proof301
  · exact adaptive142Third141Proof302
  · exact adaptive142Third141Proof303
  · exact adaptive142Third141Proof304
  · exact adaptive142Third141Proof305
  · exact adaptive142Third141Proof306
  · exact adaptive142Third141Proof307
  · exact adaptive142Third141Proof308
  · exact adaptive142Third141Proof309
  · exact adaptive142Third141Proof310

#print axioms adaptive142Third141Proof276

theorem adaptive142Third141Proof344 : runCachedNode 511 130276 Adaptive142Third141Node344 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130276 Adaptive142Third141Node344 = [89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 132] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive142Third141Proof345
  · exact adaptive142Third141Proof346
  · exact adaptive142Third141Proof347
  · exact adaptive142Third141Proof348
  · exact adaptive142Third141Proof349
  · exact adaptive142Third141Proof350
  · exact adaptive142Third141Proof351
  · exact adaptive142Third141Proof352
  · exact adaptive142Third141Proof353
  · exact adaptive142Third141Proof354
  · exact adaptive142Third141Proof355
  · exact adaptive142Third141Proof356
  · exact adaptive142Third141Proof357
  · exact adaptive142Third141Proof358
  · exact adaptive142Third141Proof359
  · exact adaptive142Third141Proof360
  · exact adaptive142Third141Proof361
  · exact adaptive142Third141Proof362
  · exact adaptive142Third141Proof363
  · exact adaptive142Third141Proof364
  · exact adaptive142Third141Proof365
  · exact adaptive142Third141Proof366
  · exact adaptive142Third141Proof367
  · exact adaptive142Third141Proof368
  · exact adaptive142Third141Proof369
  · exact adaptive142Third141Proof370
  · exact adaptive142Third141Proof371
  · exact adaptive142Third141Proof372
  · exact adaptive142Third141Proof373
  · exact adaptive142Third141Proof374
  · exact adaptive142Third141Proof375
  · exact adaptive142Third141Proof376
  · exact adaptive142Third141Proof377
  · exact adaptive142Third141Proof378
  · exact adaptive142Third141Proof379
  · exact adaptive142Third141Proof380
  · exact adaptive142Third141Proof381
  · exact adaptive142Third141Proof382
  · exact adaptive142Third141Proof383

#print axioms adaptive142Third141Proof344

theorem adaptive142Third141Proof385 : runCachedNode 511 130276 Adaptive142Third141Node385 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130276 Adaptive142Third141Node385 = [88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive142Third141Proof386
  · exact adaptive142Third141Proof387
  · exact adaptive142Third141Proof388
  · exact adaptive142Third141Proof389
  · exact adaptive142Third141Proof390
  · exact adaptive142Third141Proof391
  · exact adaptive142Third141Proof392
  · exact adaptive142Third141Proof393
  · exact adaptive142Third141Proof394
  · exact adaptive142Third141Proof395
  · exact adaptive142Third141Proof396
  · exact adaptive142Third141Proof397
  · exact adaptive142Third141Proof398
  · exact adaptive142Third141Proof399
  · exact adaptive142Third141Proof400
  · exact adaptive142Third141Proof401
  · exact adaptive142Third141Proof402
  · exact adaptive142Third141Proof403
  · exact adaptive142Third141Proof404
  · exact adaptive142Third141Proof405
  · exact adaptive142Third141Proof406
  · exact adaptive142Third141Proof407
  · exact adaptive142Third141Proof408
  · exact adaptive142Third141Proof409
  · exact adaptive142Third141Proof410
  · exact adaptive142Third141Proof411
  · exact adaptive142Third141Proof412
  · exact adaptive142Third141Proof413
  · exact adaptive142Third141Proof414
  · exact adaptive142Third141Proof415
  · exact adaptive142Third141Proof416
  · exact adaptive142Third141Proof417
  · exact adaptive142Third141Proof418
  · exact adaptive142Third141Proof419
  · exact adaptive142Third141Proof420
  · exact adaptive142Third141Proof421
  · exact adaptive142Third141Proof422
  · exact adaptive142Third141Proof423
  · exact adaptive142Third141Proof424
  · exact adaptive142Third141Proof425
  · exact adaptive142Third141Proof426

#print axioms adaptive142Third141Proof385

theorem adaptive142Third141Proof311 : runCachedNode 511 130276 Adaptive142Third141Node311 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130276 Adaptive142Third141Node311 = [101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 132, 136, 137, 138] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive142Third141Proof312
  · exact adaptive142Third141Proof313
  · exact adaptive142Third141Proof314
  · exact adaptive142Third141Proof315
  · exact adaptive142Third141Proof316
  · exact adaptive142Third141Proof317
  · exact adaptive142Third141Proof318
  · exact adaptive142Third141Proof319
  · exact adaptive142Third141Proof320
  · exact adaptive142Third141Proof321
  · exact adaptive142Third141Proof322
  · exact adaptive142Third141Proof323
  · exact adaptive142Third141Proof324
  · exact adaptive142Third141Proof325
  · exact adaptive142Third141Proof326
  · exact adaptive142Third141Proof327
  · exact adaptive142Third141Proof328
  · exact adaptive142Third141Proof329
  · exact adaptive142Third141Proof330
  · exact adaptive142Third141Proof331
  · exact adaptive142Third141Proof332
  · exact adaptive142Third141Proof333
  · exact adaptive142Third141Proof334
  · exact adaptive142Third141Proof335
  · exact adaptive142Third141Proof336
  · exact adaptive142Third141Proof337
  · exact adaptive142Third141Proof338
  · exact adaptive142Third141Proof339
  · exact adaptive142Third141Proof340
  · exact adaptive142Third141Proof341
  · exact adaptive142Third141Proof342
  · exact adaptive142Third141Proof343
  · exact adaptive142Third141Proof344
  · exact adaptive142Third141Proof384
  · exact adaptive142Third141Proof385

#print axioms adaptive142Third141Proof311

theorem adaptive142Third141Proof0 : runCachedNode 511 130276 Adaptive142Third141Node0 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130276 Adaptive142Third141Node0 = [110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 132, 133, 134, 136, 137, 138, 139, 140] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive142Third141Proof1
  · exact adaptive142Third141Proof2
  · exact adaptive142Third141Proof3
  · exact adaptive142Third141Proof4
  · exact adaptive142Third141Proof5
  · exact adaptive142Third141Proof6
  · exact adaptive142Third141Proof7
  · exact adaptive142Third141Proof8
  · exact adaptive142Third141Proof9
  · exact adaptive142Third141Proof10
  · exact adaptive142Third141Proof11
  · exact adaptive142Third141Proof12
  · exact adaptive142Third141Proof13
  · exact adaptive142Third141Proof14
  · exact adaptive142Third141Proof15
  · exact adaptive142Third141Proof16
  · exact adaptive142Third141Proof17
  · exact adaptive142Third141Proof18
  · exact adaptive142Third141Proof19
  · exact adaptive142Third141Proof20
  · exact adaptive142Third141Proof21
  · exact adaptive142Third141Proof22
  · exact adaptive142Third141Proof23
  · exact adaptive142Third141Proof50
  · exact adaptive142Third141Proof78
  · exact adaptive142Third141Proof107
  · exact adaptive142Third141Proof174
  · exact adaptive142Third141Proof206
  · exact adaptive142Third141Proof276
  · exact adaptive142Third141Proof311

#print axioms adaptive142Third141Proof0

end NineSeparatedSubsetSums
