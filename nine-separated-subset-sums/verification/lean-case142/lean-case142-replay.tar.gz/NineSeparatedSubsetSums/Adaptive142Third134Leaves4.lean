import NineSeparatedSubsetSums.Adaptive142Third134State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third134Proof16 : runCachedNode 511 129144 Adaptive142Third134Node16 = false := by
  decide +kernel

#print axioms adaptive142Third134Proof16

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third134Proof15 : runCachedNode 511 129144 Adaptive142Third134Node15 = false := by
  decide +kernel

#print axioms adaptive142Third134Proof15

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third134Proof46 : runCachedNode 511 129144 Adaptive142Third134Node46 = false := by
  decide +kernel

#print axioms adaptive142Third134Proof46

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third134Proof14 : runCachedNode 511 129144 Adaptive142Third134Node14 = false := by
  decide +kernel

#print axioms adaptive142Third134Proof14

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third134Proof40 : runCachedNode 511 129144 Adaptive142Third134Node40 = false := by
  decide +kernel

#print axioms adaptive142Third134Proof40

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third134Proof24 : runCachedNode 511 129144 Adaptive142Third134Node24 = false := by
  decide +kernel

#print axioms adaptive142Third134Proof24

end NineSeparatedSubsetSums
