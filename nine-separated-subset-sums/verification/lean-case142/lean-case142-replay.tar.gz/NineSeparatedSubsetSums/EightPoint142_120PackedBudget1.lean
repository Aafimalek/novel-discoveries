import NineSeparatedSubsetSums.EightPoint142_120PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct142_120_1_budget :
    FourPointNumeric.packedBudget 20 packedOct142_120_1 268 = 85031472 := by decide +kernel

#print axioms packedOct142_120_1_budget

end NineSeparatedSubsetSums
