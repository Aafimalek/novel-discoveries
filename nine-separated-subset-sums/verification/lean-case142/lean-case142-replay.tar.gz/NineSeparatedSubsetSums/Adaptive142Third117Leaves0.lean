import NineSeparatedSubsetSums.Adaptive142Third117State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third117Proof0 : runCachedNode 511 125317 Adaptive142Third117Node0 = false := by
  decide +kernel

#print axioms adaptive142Third117Proof0

end NineSeparatedSubsetSums
