import NineSeparatedSubsetSums.Adaptive142Third105Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint142Checked

namespace NineSeparatedSubsetSums


theorem adaptive142Third105 : NoDescendingTailAfterThird 142 105 :=
  noDescendingThirdTail_of_cached 142 105 111874 (fun t ht nd => max148_second142_fourPoint_moment_bound (105::t) (by simp [ht]) nd) adaptive142Third105Proof0

#print axioms adaptive142Third105

end NineSeparatedSubsetSums
