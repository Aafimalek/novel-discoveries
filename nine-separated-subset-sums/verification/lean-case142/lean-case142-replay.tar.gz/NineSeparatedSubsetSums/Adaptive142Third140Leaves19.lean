import NineSeparatedSubsetSums.Adaptive142Third140State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third140Proof169 : runCachedNode 511 130107 Adaptive142Third140Node169 = false := by
  decide +kernel

#print axioms adaptive142Third140Proof169

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third140Proof197 : runCachedNode 511 130107 Adaptive142Third140Node197 = false := by
  decide +kernel

#print axioms adaptive142Third140Proof197

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third140Proof135 : runCachedNode 511 130107 Adaptive142Third140Node135 = false := by
  decide +kernel

#print axioms adaptive142Third140Proof135

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third140Proof15 : runCachedNode 511 130107 Adaptive142Third140Node15 = false := by
  decide +kernel

#print axioms adaptive142Third140Proof15

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third140Proof72 : runCachedNode 511 130107 Adaptive142Third140Node72 = false := by
  decide +kernel

#print axioms adaptive142Third140Proof72

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third140Proof2 : runCachedNode 511 130107 Adaptive142Third140Node2 = false := by
  decide +kernel

#print axioms adaptive142Third140Proof2

end NineSeparatedSubsetSums
