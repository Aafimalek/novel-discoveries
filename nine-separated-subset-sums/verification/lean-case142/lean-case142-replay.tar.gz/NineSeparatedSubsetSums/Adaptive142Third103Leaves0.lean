import NineSeparatedSubsetSums.Adaptive142Third103State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third103Proof0 : runCachedNode 511 111874 Adaptive142Third103Node0 = false := by
  decide +kernel

#print axioms adaptive142Third103Proof0

end NineSeparatedSubsetSums
