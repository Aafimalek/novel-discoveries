import NineSeparatedSubsetSums.Adaptive142Third137State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third137Proof15 : runCachedNode 511 129593 Adaptive142Third137Node15 = false := by
  decide +kernel

#print axioms adaptive142Third137Proof15

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third137Proof127 : runCachedNode 511 129593 Adaptive142Third137Node127 = false := by
  decide +kernel

#print axioms adaptive142Third137Proof127

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third137Proof44 : runCachedNode 511 129593 Adaptive142Third137Node44 = false := by
  decide +kernel

#print axioms adaptive142Third137Proof44

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third137Proof126 : runCachedNode 511 129593 Adaptive142Third137Node126 = false := by
  decide +kernel

#print axioms adaptive142Third137Proof126

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third137Proof14 : runCachedNode 511 129593 Adaptive142Third137Node14 = false := by
  decide +kernel

#print axioms adaptive142Third137Proof14

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third137Proof10 : runCachedNode 511 129593 Adaptive142Third137Node10 = false := by
  decide +kernel

#print axioms adaptive142Third137Proof10

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third137Proof2 : runCachedNode 511 129593 Adaptive142Third137Node2 = false := by
  decide +kernel

#print axioms adaptive142Third137Proof2

end NineSeparatedSubsetSums
