import NineSeparatedSubsetSums.Adaptive142Third141State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third141Proof237 : runCachedNode 511 130276 Adaptive142Third141Node237 = false := by
  decide +kernel

#print axioms adaptive142Third141Proof237

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third141Proof130 : runCachedNode 511 130276 Adaptive142Third141Node130 = false := by
  decide +kernel

#print axioms adaptive142Third141Proof130

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third141Proof215 : runCachedNode 511 130276 Adaptive142Third141Node215 = false := by
  decide +kernel

#print axioms adaptive142Third141Proof215

end NineSeparatedSubsetSums
