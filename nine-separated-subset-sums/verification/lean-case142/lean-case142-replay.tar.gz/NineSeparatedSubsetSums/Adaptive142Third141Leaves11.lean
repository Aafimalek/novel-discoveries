import NineSeparatedSubsetSums.Adaptive142Third141State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third141Proof275 : runCachedNode 511 130276 Adaptive142Third141Node275 = false := by
  decide +kernel

#print axioms adaptive142Third141Proof275

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third141Proof137 : runCachedNode 511 130276 Adaptive142Third141Node137 = false := by
  decide +kernel

#print axioms adaptive142Third141Proof137

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third141Proof51 : runCachedNode 511 130276 Adaptive142Third141Node51 = false := by
  decide +kernel

#print axioms adaptive142Third141Proof51

end NineSeparatedSubsetSums
