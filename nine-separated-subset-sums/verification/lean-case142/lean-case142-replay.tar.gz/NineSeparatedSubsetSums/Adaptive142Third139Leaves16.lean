import NineSeparatedSubsetSums.Adaptive142Third139State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third139Proof278 : runCachedNode 511 129933 Adaptive142Third139Node278 = false := by
  decide +kernel

#print axioms adaptive142Third139Proof278

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third139Proof179 : runCachedNode 511 129933 Adaptive142Third139Node179 = false := by
  decide +kernel

#print axioms adaptive142Third139Proof179

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third139Proof80 : runCachedNode 511 129933 Adaptive142Third139Node80 = false := by
  decide +kernel

#print axioms adaptive142Third139Proof80

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third139Proof317 : runCachedNode 511 129933 Adaptive142Third139Node317 = false := by
  decide +kernel

#print axioms adaptive142Third139Proof317

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third139Proof77 : runCachedNode 511 129933 Adaptive142Third139Node77 = false := by
  decide +kernel

#print axioms adaptive142Third139Proof77

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third139Proof3 : runCachedNode 511 129933 Adaptive142Third139Node3 = false := by
  decide +kernel

#print axioms adaptive142Third139Proof3

end NineSeparatedSubsetSums
