import NineSeparatedSubsetSums.Adaptive142Third141State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third141Proof135 : runCachedNode 511 130276 Adaptive142Third141Node135 = false := by
  decide +kernel

#print axioms adaptive142Third141Proof135

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third141Proof172 : runCachedNode 511 130276 Adaptive142Third141Node172 = false := by
  decide +kernel

#print axioms adaptive142Third141Proof172

end NineSeparatedSubsetSums
