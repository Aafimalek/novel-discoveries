import NineSeparatedSubsetSums.Adaptive142Third138State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third138Proof21 : runCachedNode 511 129778 Adaptive142Third138Node21 = false := by
  decide +kernel

#print axioms adaptive142Third138Proof21

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third138Proof169 : runCachedNode 511 129778 Adaptive142Third138Node169 = false := by
  decide +kernel

#print axioms adaptive142Third138Proof169

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third138Proof4 : runCachedNode 511 129778 Adaptive142Third138Node4 = false := by
  decide +kernel

#print axioms adaptive142Third138Proof4

end NineSeparatedSubsetSums
