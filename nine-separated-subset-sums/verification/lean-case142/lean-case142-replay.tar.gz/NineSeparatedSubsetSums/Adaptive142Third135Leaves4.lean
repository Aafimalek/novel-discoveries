import NineSeparatedSubsetSums.Adaptive142Third135State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third135Proof17 : runCachedNode 511 129264 Adaptive142Third135Node17 = false := by
  decide +kernel

#print axioms adaptive142Third135Proof17

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third135Proof16 : runCachedNode 511 129264 Adaptive142Third135Node16 = false := by
  decide +kernel

#print axioms adaptive142Third135Proof16

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third135Proof99 : runCachedNode 511 129264 Adaptive142Third135Node99 = false := by
  decide +kernel

#print axioms adaptive142Third135Proof99

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third135Proof98 : runCachedNode 511 129264 Adaptive142Third135Node98 = false := by
  decide +kernel

#print axioms adaptive142Third135Proof98

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third135Proof83 : runCachedNode 511 129264 Adaptive142Third135Node83 = false := by
  decide +kernel

#print axioms adaptive142Third135Proof83

end NineSeparatedSubsetSums
