import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive142Third128Node0 : CachedSearchNode :=
  ⟨4, 127, computeCenteredMask [148,142,128], 418, 58452⟩
def Adaptive142Third128Node1 : CachedSearchNode := cachedChild Adaptive142Third128Node0 111
def Adaptive142Third128Node2 : CachedSearchNode := cachedChild Adaptive142Third128Node0 112
def Adaptive142Third128Node3 : CachedSearchNode := cachedChild Adaptive142Third128Node0 113
def Adaptive142Third128Node4 : CachedSearchNode := cachedChild Adaptive142Third128Node0 114
def Adaptive142Third128Node5 : CachedSearchNode := cachedChild Adaptive142Third128Node0 115
def Adaptive142Third128Node6 : CachedSearchNode := cachedChild Adaptive142Third128Node0 116
def Adaptive142Third128Node7 : CachedSearchNode := cachedChild Adaptive142Third128Node0 117
def Adaptive142Third128Node8 : CachedSearchNode := cachedChild Adaptive142Third128Node0 118
def Adaptive142Third128Node9 : CachedSearchNode := cachedChild Adaptive142Third128Node0 119
def Adaptive142Third128Node10 : CachedSearchNode := cachedChild Adaptive142Third128Node0 120
def Adaptive142Third128Node11 : CachedSearchNode := cachedChild Adaptive142Third128Node0 121
def Adaptive142Third128Node12 : CachedSearchNode := cachedChild Adaptive142Third128Node0 123
def Adaptive142Third128Node13 : CachedSearchNode := cachedChild Adaptive142Third128Node0 124
def Adaptive142Third128Node14 : CachedSearchNode := cachedChild Adaptive142Third128Node0 125
def Adaptive142Third128Node15 : CachedSearchNode := cachedChild Adaptive142Third128Node0 126
def Adaptive142Third128Node16 : CachedSearchNode := cachedChild Adaptive142Third128Node0 127

end NineSeparatedSubsetSums
