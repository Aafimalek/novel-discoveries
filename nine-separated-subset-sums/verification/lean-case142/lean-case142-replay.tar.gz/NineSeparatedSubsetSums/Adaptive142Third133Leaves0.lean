import NineSeparatedSubsetSums.Adaptive142Third133State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third133Proof21 : runCachedNode 511 128920 Adaptive142Third133Node21 = false := by
  decide +kernel

#print axioms adaptive142Third133Proof21

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third133Proof44 : runCachedNode 511 128920 Adaptive142Third133Node44 = false := by
  decide +kernel

#print axioms adaptive142Third133Proof44

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third133Proof27 : runCachedNode 511 128920 Adaptive142Third133Node27 = false := by
  decide +kernel

#print axioms adaptive142Third133Proof27

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third133Proof23 : runCachedNode 511 128920 Adaptive142Third133Node23 = false := by
  decide +kernel

#print axioms adaptive142Third133Proof23

end NineSeparatedSubsetSums
