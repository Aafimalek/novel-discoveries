import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive142Third108Node0 : CachedSearchNode :=
  ⟨4, 107, computeCenteredMask [148,142,108], 398, 53732⟩

end NineSeparatedSubsetSums
