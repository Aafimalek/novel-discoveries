import NineSeparatedSubsetSums.Adaptive142Third141State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third141Proof226 : runCachedNode 511 130276 Adaptive142Third141Node226 = false := by
  decide +kernel

#print axioms adaptive142Third141Proof226

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third141Proof380 : runCachedNode 511 130276 Adaptive142Third141Node380 = false := by
  decide +kernel

#print axioms adaptive142Third141Proof380

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third141Proof197 : runCachedNode 511 130276 Adaptive142Third141Node197 = false := by
  decide +kernel

#print axioms adaptive142Third141Proof197

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third141Proof44 : runCachedNode 511 130276 Adaptive142Third141Node44 = false := by
  decide +kernel

#print axioms adaptive142Third141Proof44

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third141Proof228 : runCachedNode 511 130276 Adaptive142Third141Node228 = false := by
  decide +kernel

#print axioms adaptive142Third141Proof228

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third141Proof331 : runCachedNode 511 130276 Adaptive142Third141Node331 = false := by
  decide +kernel

#print axioms adaptive142Third141Proof331

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third141Proof301 : runCachedNode 511 130276 Adaptive142Third141Node301 = false := by
  decide +kernel

#print axioms adaptive142Third141Proof301

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third141Proof420 : runCachedNode 511 130276 Adaptive142Third141Node420 = false := by
  decide +kernel

#print axioms adaptive142Third141Proof420

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third141Proof43 : runCachedNode 511 130276 Adaptive142Third141Node43 = false := by
  decide +kernel

#print axioms adaptive142Third141Proof43

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third141Proof95 : runCachedNode 511 130276 Adaptive142Third141Node95 = false := by
  decide +kernel

#print axioms adaptive142Third141Proof95

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third141Proof124 : runCachedNode 511 130276 Adaptive142Third141Node124 = false := by
  decide +kernel

#print axioms adaptive142Third141Proof124

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third141Proof125 : runCachedNode 511 130276 Adaptive142Third141Node125 = false := by
  decide +kernel

#print axioms adaptive142Third141Proof125

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third141Proof273 : runCachedNode 511 130276 Adaptive142Third141Node273 = false := by
  decide +kernel

#print axioms adaptive142Third141Proof273

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third141Proof260 : runCachedNode 511 130276 Adaptive142Third141Node260 = false := by
  decide +kernel

#print axioms adaptive142Third141Proof260

end NineSeparatedSubsetSums
