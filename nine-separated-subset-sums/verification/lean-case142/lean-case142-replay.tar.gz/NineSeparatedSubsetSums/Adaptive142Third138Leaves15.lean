import NineSeparatedSubsetSums.Adaptive142Third138State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third138Proof166 : runCachedNode 511 129778 Adaptive142Third138Node166 = false := by
  decide +kernel

#print axioms adaptive142Third138Proof166

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third138Proof104 : runCachedNode 511 129778 Adaptive142Third138Node104 = false := by
  decide +kernel

#print axioms adaptive142Third138Proof104

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third138Proof161 : runCachedNode 511 129778 Adaptive142Third138Node161 = false := by
  decide +kernel

#print axioms adaptive142Third138Proof161

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third138Proof14 : runCachedNode 511 129778 Adaptive142Third138Node14 = false := by
  decide +kernel

#print axioms adaptive142Third138Proof14

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third138Proof165 : runCachedNode 511 129778 Adaptive142Third138Node165 = false := by
  decide +kernel

#print axioms adaptive142Third138Proof165

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third138Proof41 : runCachedNode 511 129778 Adaptive142Third138Node41 = false := by
  decide +kernel

#print axioms adaptive142Third138Proof41

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third138Proof174 : runCachedNode 511 129778 Adaptive142Third138Node174 = false := by
  decide +kernel

#print axioms adaptive142Third138Proof174

end NineSeparatedSubsetSums
