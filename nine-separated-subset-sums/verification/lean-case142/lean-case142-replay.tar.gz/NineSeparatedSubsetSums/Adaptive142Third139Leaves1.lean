import NineSeparatedSubsetSums.Adaptive142Third139State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third139Proof109 : runCachedNode 511 129933 Adaptive142Third139Node109 = false := by
  decide +kernel

#print axioms adaptive142Third139Proof109

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third139Proof200 : runCachedNode 511 129933 Adaptive142Third139Node200 = false := by
  decide +kernel

#print axioms adaptive142Third139Proof200

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third139Proof2 : runCachedNode 511 129933 Adaptive142Third139Node2 = false := by
  decide +kernel

#print axioms adaptive142Third139Proof2

end NineSeparatedSubsetSums
