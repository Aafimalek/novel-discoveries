import NineSeparatedSubsetSums.EightPoint142_119PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint142_119PackedAnchor0Part2 :
    ∀ j : Fin 7, 2395430 ≤ FourPointNumeric.octPackedCharge 142 119 20 packedOct142_119_0
      (2*((j.val : Int)+240)+1) := by decide +kernel

end NineSeparatedSubsetSums
