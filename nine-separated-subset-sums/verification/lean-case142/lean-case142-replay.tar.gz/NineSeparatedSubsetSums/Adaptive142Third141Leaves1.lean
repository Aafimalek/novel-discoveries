import NineSeparatedSubsetSums.Adaptive142Third141State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third141Proof22 : runCachedNode 511 130276 Adaptive142Third141Node22 = false := by
  decide +kernel

#print axioms adaptive142Third141Proof22

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third141Proof37 : runCachedNode 511 130276 Adaptive142Third141Node37 = false := by
  decide +kernel

#print axioms adaptive142Third141Proof37

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third141Proof1 : runCachedNode 511 130276 Adaptive142Third141Node1 = false := by
  decide +kernel

#print axioms adaptive142Third141Proof1

end NineSeparatedSubsetSums
