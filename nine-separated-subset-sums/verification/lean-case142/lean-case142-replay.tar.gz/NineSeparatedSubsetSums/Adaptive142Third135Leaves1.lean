import NineSeparatedSubsetSums.Adaptive142Third135State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third135Proof19 : runCachedNode 511 129264 Adaptive142Third135Node19 = false := by
  decide +kernel

#print axioms adaptive142Third135Proof19

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third135Proof72 : runCachedNode 511 129264 Adaptive142Third135Node72 = false := by
  decide +kernel

#print axioms adaptive142Third135Proof72

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third135Proof29 : runCachedNode 511 129264 Adaptive142Third135Node29 = false := by
  decide +kernel

#print axioms adaptive142Third135Proof29

end NineSeparatedSubsetSums
