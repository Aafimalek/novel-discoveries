import NineSeparatedSubsetSums.Adaptive142Third139State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third139Proof49 : runCachedNode 511 129933 Adaptive142Third139Node49 = false := by
  decide +kernel

#print axioms adaptive142Third139Proof49

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third139Proof50 : runCachedNode 511 129933 Adaptive142Third139Node50 = false := by
  decide +kernel

#print axioms adaptive142Third139Proof50

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third139Proof99 : runCachedNode 511 129933 Adaptive142Third139Node99 = false := by
  decide +kernel

#print axioms adaptive142Third139Proof99

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third139Proof78 : runCachedNode 511 129933 Adaptive142Third139Node78 = false := by
  decide +kernel

#print axioms adaptive142Third139Proof78

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third139Proof142 : runCachedNode 511 129933 Adaptive142Third139Node142 = false := by
  decide +kernel

#print axioms adaptive142Third139Proof142

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third139Proof208 : runCachedNode 511 129933 Adaptive142Third139Node208 = false := by
  decide +kernel

#print axioms adaptive142Third139Proof208

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third139Proof273 : runCachedNode 511 129933 Adaptive142Third139Node273 = false := by
  decide +kernel

#print axioms adaptive142Third139Proof273

end NineSeparatedSubsetSums
