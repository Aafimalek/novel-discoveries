import NineSeparatedSubsetSums.Adaptive142Third132State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third132Proof19 : runCachedNode 511 128761 Adaptive142Third132Node19 = false := by
  decide +kernel

#print axioms adaptive142Third132Proof19

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third132Proof15 : runCachedNode 511 128761 Adaptive142Third132Node15 = false := by
  decide +kernel

#print axioms adaptive142Third132Proof15

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third132Proof13 : runCachedNode 511 128761 Adaptive142Third132Node13 = false := by
  decide +kernel

#print axioms adaptive142Third132Proof13

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third132Proof4 : runCachedNode 511 128761 Adaptive142Third132Node4 = false := by
  decide +kernel

#print axioms adaptive142Third132Proof4

end NineSeparatedSubsetSums
