import NineSeparatedSubsetSums.Adaptive142Third136State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third136Proof227 : runCachedNode 511 129404 Adaptive142Third136Node227 = false := by
  decide +kernel

#print axioms adaptive142Third136Proof227

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third136Proof228 : runCachedNode 511 129404 Adaptive142Third136Node228 = false := by
  decide +kernel

#print axioms adaptive142Third136Proof228

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third136Proof32 : runCachedNode 511 129404 Adaptive142Third136Node32 = false := by
  decide +kernel

#print axioms adaptive142Third136Proof32

end NineSeparatedSubsetSums
