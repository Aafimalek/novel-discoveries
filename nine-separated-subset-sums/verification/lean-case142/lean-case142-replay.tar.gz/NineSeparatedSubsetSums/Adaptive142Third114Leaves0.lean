import NineSeparatedSubsetSums.Adaptive142Third114State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third114Proof0 : runCachedNode 511 111874 Adaptive142Third114Node0 = false := by
  decide +kernel

#print axioms adaptive142Third114Proof0

end NineSeparatedSubsetSums
