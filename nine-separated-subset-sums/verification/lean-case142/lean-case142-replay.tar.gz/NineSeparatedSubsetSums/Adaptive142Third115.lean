import NineSeparatedSubsetSums.Adaptive142Third115Joins0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint142Checked

namespace NineSeparatedSubsetSums


theorem adaptive142Third115 : NoDescendingTailAfterThird 142 115 :=
  noDescendingThirdTail_of_cached 142 115 111874 (fun t ht nd => max148_second142_fourPoint_moment_bound (115::t) (by simp [ht]) nd) adaptive142Third115Proof0

#print axioms adaptive142Third115

end NineSeparatedSubsetSums
