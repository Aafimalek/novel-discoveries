import NineSeparatedSubsetSums.Adaptive142Third140State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third140Proof308 : runCachedNode 511 130107 Adaptive142Third140Node308 = false := by
  decide +kernel

#print axioms adaptive142Third140Proof308

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third140Proof45 : runCachedNode 511 130107 Adaptive142Third140Node45 = false := by
  decide +kernel

#print axioms adaptive142Third140Proof45

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third140Proof198 : runCachedNode 511 130107 Adaptive142Third140Node198 = false := by
  decide +kernel

#print axioms adaptive142Third140Proof198

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third140Proof264 : runCachedNode 511 130107 Adaptive142Third140Node264 = false := by
  decide +kernel

#print axioms adaptive142Third140Proof264

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third140Proof130 : runCachedNode 511 130107 Adaptive142Third140Node130 = false := by
  decide +kernel

#print axioms adaptive142Third140Proof130

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third140Proof307 : runCachedNode 511 130107 Adaptive142Third140Node307 = false := by
  decide +kernel

#print axioms adaptive142Third140Proof307

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third140Proof3 : runCachedNode 511 130107 Adaptive142Third140Node3 = false := by
  decide +kernel

#print axioms adaptive142Third140Proof3

end NineSeparatedSubsetSums
