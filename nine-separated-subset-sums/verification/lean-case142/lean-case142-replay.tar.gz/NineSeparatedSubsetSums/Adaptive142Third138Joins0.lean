import NineSeparatedSubsetSums.Adaptive142Third138State
import NineSeparatedSubsetSums.Adaptive142Third138Leaves14
import NineSeparatedSubsetSums.Adaptive142Third138Leaves23
import NineSeparatedSubsetSums.Adaptive142Third138Leaves8
import NineSeparatedSubsetSums.Adaptive142Third138Leaves18
import NineSeparatedSubsetSums.Adaptive142Third138Leaves1
import NineSeparatedSubsetSums.Adaptive142Third138Leaves12
import NineSeparatedSubsetSums.Adaptive142Third138Leaves19
import NineSeparatedSubsetSums.Adaptive142Third138Leaves22
import NineSeparatedSubsetSums.Adaptive142Third138Leaves2
import NineSeparatedSubsetSums.Adaptive142Third138Leaves21
import NineSeparatedSubsetSums.Adaptive142Third138Leaves20
import NineSeparatedSubsetSums.Adaptive142Third138Leaves16
import NineSeparatedSubsetSums.Adaptive142Third138Leaves15
import NineSeparatedSubsetSums.Adaptive142Third138Leaves7
import NineSeparatedSubsetSums.Adaptive142Third138Leaves10
import NineSeparatedSubsetSums.Adaptive142Third138Leaves13
import NineSeparatedSubsetSums.Adaptive142Third138Leaves9
import NineSeparatedSubsetSums.Adaptive142Third138Leaves17
import NineSeparatedSubsetSums.Adaptive142Third138Leaves11
import NineSeparatedSubsetSums.Adaptive142Third138Leaves4
import NineSeparatedSubsetSums.Adaptive142Third138Leaves6
import NineSeparatedSubsetSums.Adaptive142Third138Leaves3
import NineSeparatedSubsetSums.Adaptive142Third138Leaves5
import NineSeparatedSubsetSums.Adaptive142Third138Leaves0

namespace NineSeparatedSubsetSums

theorem adaptive142Third138Proof23 : runCachedNode 511 129778 Adaptive142Third138Node23 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 129778 Adaptive142Third138Node23 = [103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 124, 125, 126, 128, 130, 131] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive142Third138Proof24
  · exact adaptive142Third138Proof25
  · exact adaptive142Third138Proof26
  · exact adaptive142Third138Proof27
  · exact adaptive142Third138Proof28
  · exact adaptive142Third138Proof29
  · exact adaptive142Third138Proof30
  · exact adaptive142Third138Proof31
  · exact adaptive142Third138Proof32
  · exact adaptive142Third138Proof33
  · exact adaptive142Third138Proof34
  · exact adaptive142Third138Proof35
  · exact adaptive142Third138Proof36
  · exact adaptive142Third138Proof37
  · exact adaptive142Third138Proof38
  · exact adaptive142Third138Proof39
  · exact adaptive142Third138Proof40
  · exact adaptive142Third138Proof41
  · exact adaptive142Third138Proof42
  · exact adaptive142Third138Proof43
  · exact adaptive142Third138Proof44
  · exact adaptive142Third138Proof45
  · exact adaptive142Third138Proof46
  · exact adaptive142Third138Proof47
  · exact adaptive142Third138Proof48
  · exact adaptive142Third138Proof49

#print axioms adaptive142Third138Proof23

theorem adaptive142Third138Proof50 : runCachedNode 511 129778 Adaptive142Third138Node50 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 129778 Adaptive142Third138Node50 = [103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 125, 126, 127, 129, 131, 133] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive142Third138Proof51
  · exact adaptive142Third138Proof52
  · exact adaptive142Third138Proof53
  · exact adaptive142Third138Proof54
  · exact adaptive142Third138Proof55
  · exact adaptive142Third138Proof56
  · exact adaptive142Third138Proof57
  · exact adaptive142Third138Proof58
  · exact adaptive142Third138Proof59
  · exact adaptive142Third138Proof60
  · exact adaptive142Third138Proof61
  · exact adaptive142Third138Proof62
  · exact adaptive142Third138Proof63
  · exact adaptive142Third138Proof64
  · exact adaptive142Third138Proof65
  · exact adaptive142Third138Proof66
  · exact adaptive142Third138Proof67
  · exact adaptive142Third138Proof68
  · exact adaptive142Third138Proof69
  · exact adaptive142Third138Proof70
  · exact adaptive142Third138Proof71
  · exact adaptive142Third138Proof72
  · exact adaptive142Third138Proof73
  · exact adaptive142Third138Proof74
  · exact adaptive142Third138Proof75
  · exact adaptive142Third138Proof76
  · exact adaptive142Third138Proof77

#print axioms adaptive142Third138Proof50

theorem adaptive142Third138Proof78 : runCachedNode 511 129778 Adaptive142Third138Node78 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 129778 Adaptive142Third138Node78 = [103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 126, 127, 128, 130, 133, 134] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive142Third138Proof79
  · exact adaptive142Third138Proof80
  · exact adaptive142Third138Proof81
  · exact adaptive142Third138Proof82
  · exact adaptive142Third138Proof83
  · exact adaptive142Third138Proof84
  · exact adaptive142Third138Proof85
  · exact adaptive142Third138Proof86
  · exact adaptive142Third138Proof87
  · exact adaptive142Third138Proof88
  · exact adaptive142Third138Proof89
  · exact adaptive142Third138Proof90
  · exact adaptive142Third138Proof91
  · exact adaptive142Third138Proof92
  · exact adaptive142Third138Proof93
  · exact adaptive142Third138Proof94
  · exact adaptive142Third138Proof95
  · exact adaptive142Third138Proof96
  · exact adaptive142Third138Proof97
  · exact adaptive142Third138Proof98
  · exact adaptive142Third138Proof99
  · exact adaptive142Third138Proof100
  · exact adaptive142Third138Proof101
  · exact adaptive142Third138Proof102
  · exact adaptive142Third138Proof103
  · exact adaptive142Third138Proof104
  · exact adaptive142Third138Proof105
  · exact adaptive142Third138Proof106

#print axioms adaptive142Third138Proof78

theorem adaptive142Third138Proof136 : runCachedNode 511 129778 Adaptive142Third138Node136 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 129778 Adaptive142Third138Node136 = [92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 119, 120, 121, 123, 125, 127, 129, 131, 133] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive142Third138Proof137
  · exact adaptive142Third138Proof138
  · exact adaptive142Third138Proof139
  · exact adaptive142Third138Proof140
  · exact adaptive142Third138Proof141
  · exact adaptive142Third138Proof142
  · exact adaptive142Third138Proof143
  · exact adaptive142Third138Proof144
  · exact adaptive142Third138Proof145
  · exact adaptive142Third138Proof146
  · exact adaptive142Third138Proof147
  · exact adaptive142Third138Proof148
  · exact adaptive142Third138Proof149
  · exact adaptive142Third138Proof150
  · exact adaptive142Third138Proof151
  · exact adaptive142Third138Proof152
  · exact adaptive142Third138Proof153
  · exact adaptive142Third138Proof154
  · exact adaptive142Third138Proof155
  · exact adaptive142Third138Proof156
  · exact adaptive142Third138Proof157
  · exact adaptive142Third138Proof158
  · exact adaptive142Third138Proof159
  · exact adaptive142Third138Proof160
  · exact adaptive142Third138Proof161
  · exact adaptive142Third138Proof162
  · exact adaptive142Third138Proof163
  · exact adaptive142Third138Proof164
  · exact adaptive142Third138Proof165
  · exact adaptive142Third138Proof166
  · exact adaptive142Third138Proof167
  · exact adaptive142Third138Proof168
  · exact adaptive142Third138Proof169
  · exact adaptive142Third138Proof170
  · exact adaptive142Third138Proof171

#print axioms adaptive142Third138Proof136

theorem adaptive142Third138Proof107 : runCachedNode 511 129778 Adaptive142Third138Node107 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 129778 Adaptive142Third138Node107 = [103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 127, 128, 129, 131, 133, 134, 135] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive142Third138Proof108
  · exact adaptive142Third138Proof109
  · exact adaptive142Third138Proof110
  · exact adaptive142Third138Proof111
  · exact adaptive142Third138Proof112
  · exact adaptive142Third138Proof113
  · exact adaptive142Third138Proof114
  · exact adaptive142Third138Proof115
  · exact adaptive142Third138Proof116
  · exact adaptive142Third138Proof117
  · exact adaptive142Third138Proof118
  · exact adaptive142Third138Proof119
  · exact adaptive142Third138Proof120
  · exact adaptive142Third138Proof121
  · exact adaptive142Third138Proof122
  · exact adaptive142Third138Proof123
  · exact adaptive142Third138Proof124
  · exact adaptive142Third138Proof125
  · exact adaptive142Third138Proof126
  · exact adaptive142Third138Proof127
  · exact adaptive142Third138Proof128
  · exact adaptive142Third138Proof129
  · exact adaptive142Third138Proof130
  · exact adaptive142Third138Proof131
  · exact adaptive142Third138Proof132
  · exact adaptive142Third138Proof133
  · exact adaptive142Third138Proof134
  · exact adaptive142Third138Proof135
  · exact adaptive142Third138Proof136
  · exact adaptive142Third138Proof172

#print axioms adaptive142Third138Proof107

theorem adaptive142Third138Proof204 : runCachedNode 511 129778 Adaptive142Third138Node204 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 129778 Adaptive142Third138Node204 = [91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 122, 123, 124, 128, 134] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive142Third138Proof205
  · exact adaptive142Third138Proof206
  · exact adaptive142Third138Proof207
  · exact adaptive142Third138Proof208
  · exact adaptive142Third138Proof209
  · exact adaptive142Third138Proof210
  · exact adaptive142Third138Proof211
  · exact adaptive142Third138Proof212
  · exact adaptive142Third138Proof213
  · exact adaptive142Third138Proof214
  · exact adaptive142Third138Proof215
  · exact adaptive142Third138Proof216
  · exact adaptive142Third138Proof217
  · exact adaptive142Third138Proof218
  · exact adaptive142Third138Proof219
  · exact adaptive142Third138Proof220
  · exact adaptive142Third138Proof221
  · exact adaptive142Third138Proof222
  · exact adaptive142Third138Proof223
  · exact adaptive142Third138Proof224
  · exact adaptive142Third138Proof225
  · exact adaptive142Third138Proof226
  · exact adaptive142Third138Proof227
  · exact adaptive142Third138Proof228
  · exact adaptive142Third138Proof229
  · exact adaptive142Third138Proof230
  · exact adaptive142Third138Proof231
  · exact adaptive142Third138Proof232
  · exact adaptive142Third138Proof233
  · exact adaptive142Third138Proof234
  · exact adaptive142Third138Proof235
  · exact adaptive142Third138Proof236
  · exact adaptive142Third138Proof237
  · exact adaptive142Third138Proof238
  · exact adaptive142Third138Proof239

#print axioms adaptive142Third138Proof204

theorem adaptive142Third138Proof173 : runCachedNode 511 129778 Adaptive142Third138Node173 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 129778 Adaptive142Third138Node173 = [102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 128, 129, 130, 134, 135, 136] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive142Third138Proof174
  · exact adaptive142Third138Proof175
  · exact adaptive142Third138Proof176
  · exact adaptive142Third138Proof177
  · exact adaptive142Third138Proof178
  · exact adaptive142Third138Proof179
  · exact adaptive142Third138Proof180
  · exact adaptive142Third138Proof181
  · exact adaptive142Third138Proof182
  · exact adaptive142Third138Proof183
  · exact adaptive142Third138Proof184
  · exact adaptive142Third138Proof185
  · exact adaptive142Third138Proof186
  · exact adaptive142Third138Proof187
  · exact adaptive142Third138Proof188
  · exact adaptive142Third138Proof189
  · exact adaptive142Third138Proof190
  · exact adaptive142Third138Proof191
  · exact adaptive142Third138Proof192
  · exact adaptive142Third138Proof193
  · exact adaptive142Third138Proof194
  · exact adaptive142Third138Proof195
  · exact adaptive142Third138Proof196
  · exact adaptive142Third138Proof197
  · exact adaptive142Third138Proof198
  · exact adaptive142Third138Proof199
  · exact adaptive142Third138Proof200
  · exact adaptive142Third138Proof201
  · exact adaptive142Third138Proof202
  · exact adaptive142Third138Proof203
  · exact adaptive142Third138Proof204

#print axioms adaptive142Third138Proof173

theorem adaptive142Third138Proof0 : runCachedNode 511 129778 Adaptive142Third138Node0 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 129778 Adaptive142Third138Node0 = [110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 133, 134, 135, 136, 137] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive142Third138Proof1
  · exact adaptive142Third138Proof2
  · exact adaptive142Third138Proof3
  · exact adaptive142Third138Proof4
  · exact adaptive142Third138Proof5
  · exact adaptive142Third138Proof6
  · exact adaptive142Third138Proof7
  · exact adaptive142Third138Proof8
  · exact adaptive142Third138Proof9
  · exact adaptive142Third138Proof10
  · exact adaptive142Third138Proof11
  · exact adaptive142Third138Proof12
  · exact adaptive142Third138Proof13
  · exact adaptive142Third138Proof14
  · exact adaptive142Third138Proof15
  · exact adaptive142Third138Proof16
  · exact adaptive142Third138Proof17
  · exact adaptive142Third138Proof18
  · exact adaptive142Third138Proof19
  · exact adaptive142Third138Proof20
  · exact adaptive142Third138Proof21
  · exact adaptive142Third138Proof22
  · exact adaptive142Third138Proof23
  · exact adaptive142Third138Proof50
  · exact adaptive142Third138Proof78
  · exact adaptive142Third138Proof107
  · exact adaptive142Third138Proof173

#print axioms adaptive142Third138Proof0

end NineSeparatedSubsetSums
