import NineSeparatedSubsetSums.EightPoint142_128PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct142_128_0_budget :
    FourPointNumeric.packedBudget 20 packedOct142_128_0 271 = 86648299 := by decide +kernel

#print axioms packedOct142_128_0_budget

end NineSeparatedSubsetSums
