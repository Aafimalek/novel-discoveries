import NineSeparatedSubsetSums.Adaptive142Third138State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third138Proof172 : runCachedNode 511 129778 Adaptive142Third138Node172 = false := by
  decide +kernel

#print axioms adaptive142Third138Proof172

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third138Proof159 : runCachedNode 511 129778 Adaptive142Third138Node159 = false := by
  decide +kernel

#print axioms adaptive142Third138Proof159

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third138Proof33 : runCachedNode 511 129778 Adaptive142Third138Node33 = false := by
  decide +kernel

#print axioms adaptive142Third138Proof33

end NineSeparatedSubsetSums
