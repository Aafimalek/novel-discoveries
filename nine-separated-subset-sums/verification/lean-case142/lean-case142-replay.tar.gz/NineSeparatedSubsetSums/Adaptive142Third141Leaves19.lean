import NineSeparatedSubsetSums.Adaptive142Third141State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third141Proof338 : runCachedNode 511 130276 Adaptive142Third141Node338 = false := by
  decide +kernel

#print axioms adaptive142Third141Proof338

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third141Proof337 : runCachedNode 511 130276 Adaptive142Third141Node337 = false := by
  decide +kernel

#print axioms adaptive142Third141Proof337

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third141Proof307 : runCachedNode 511 130276 Adaptive142Third141Node307 = false := by
  decide +kernel

#print axioms adaptive142Third141Proof307

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third141Proof72 : runCachedNode 511 130276 Adaptive142Third141Node72 = false := by
  decide +kernel

#print axioms adaptive142Third141Proof72

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third141Proof79 : runCachedNode 511 130276 Adaptive142Third141Node79 = false := by
  decide +kernel

#print axioms adaptive142Third141Proof79

end NineSeparatedSubsetSums
