import NineSeparatedSubsetSums.Adaptive142Third141State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third141Proof21 : runCachedNode 511 130276 Adaptive142Third141Node21 = false := by
  decide +kernel

#print axioms adaptive142Third141Proof21

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third141Proof205 : runCachedNode 511 130276 Adaptive142Third141Node205 = false := by
  decide +kernel

#print axioms adaptive142Third141Proof205

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third141Proof24 : runCachedNode 511 130276 Adaptive142Third141Node24 = false := by
  decide +kernel

#print axioms adaptive142Third141Proof24

end NineSeparatedSubsetSums
