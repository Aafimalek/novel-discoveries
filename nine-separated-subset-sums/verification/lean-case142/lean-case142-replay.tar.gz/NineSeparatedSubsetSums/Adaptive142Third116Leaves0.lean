import NineSeparatedSubsetSums.Adaptive142Third116State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third116Proof0 : runCachedNode 511 125144 Adaptive142Third116Node0 = false := by
  decide +kernel

#print axioms adaptive142Third116Proof0

end NineSeparatedSubsetSums
