import NineSeparatedSubsetSums.Adaptive142Third138State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third138Proof22 : runCachedNode 511 129778 Adaptive142Third138Node22 = false := by
  decide +kernel

#print axioms adaptive142Third138Proof22

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third138Proof5 : runCachedNode 511 129778 Adaptive142Third138Node5 = false := by
  decide +kernel

#print axioms adaptive142Third138Proof5

end NineSeparatedSubsetSums
