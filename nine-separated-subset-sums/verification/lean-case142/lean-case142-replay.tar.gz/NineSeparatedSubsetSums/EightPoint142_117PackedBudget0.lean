import NineSeparatedSubsetSums.EightPoint142_117PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct142_117_0_budget :
    FourPointNumeric.packedBudget 20 packedOct142_117_0 457 = 87088923 := by decide +kernel

#print axioms packedOct142_117_0_budget

end NineSeparatedSubsetSums
