import NineSeparatedSubsetSums.EightPoint142_120PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint142_120PackedAnchor1Part1 :
    ∀ j : Fin 120, 2335589 ≤ FourPointNumeric.octPackedCharge 142 120 20 packedOct142_120_1
      (2*((j.val : Int)+120)+1) := by decide +kernel

end NineSeparatedSubsetSums
