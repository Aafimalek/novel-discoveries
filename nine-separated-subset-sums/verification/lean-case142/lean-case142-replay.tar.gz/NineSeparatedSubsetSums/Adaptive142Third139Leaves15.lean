import NineSeparatedSubsetSums.Adaptive142Third139State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third139Proof210 : runCachedNode 511 129933 Adaptive142Third139Node210 = false := by
  decide +kernel

#print axioms adaptive142Third139Proof210

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third139Proof248 : runCachedNode 511 129933 Adaptive142Third139Node248 = false := by
  decide +kernel

#print axioms adaptive142Third139Proof248

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third139Proof143 : runCachedNode 511 129933 Adaptive142Third139Node143 = false := by
  decide +kernel

#print axioms adaptive142Third139Proof143

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third139Proof209 : runCachedNode 511 129933 Adaptive142Third139Node209 = false := by
  decide +kernel

#print axioms adaptive142Third139Proof209

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third139Proof48 : runCachedNode 511 129933 Adaptive142Third139Node48 = false := by
  decide +kernel

#print axioms adaptive142Third139Proof48

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third139Proof26 : runCachedNode 511 129933 Adaptive142Third139Node26 = false := by
  decide +kernel

#print axioms adaptive142Third139Proof26

end NineSeparatedSubsetSums
