import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive142Third124Node0 : CachedSearchNode :=
  ⟨4, 123, computeCenteredMask [148,142,124], 414, 57444⟩

end NineSeparatedSubsetSums
