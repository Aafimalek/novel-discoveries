import NineSeparatedSubsetSums.EightPoint142_116PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint142_116PackedAnchor1Part0 :
    ∀ j : Fin 120, 2368295 ≤ FourPointNumeric.octPackedCharge 142 116 20 packedOct142_116_1
      (2*((j.val : Int)+0)+1) := by decide +kernel

end NineSeparatedSubsetSums
