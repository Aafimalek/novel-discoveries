import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive142Third118Node0 : CachedSearchNode :=
  ⟨4, 117, computeCenteredMask [148,142,118], 408, 55992⟩

end NineSeparatedSubsetSums
