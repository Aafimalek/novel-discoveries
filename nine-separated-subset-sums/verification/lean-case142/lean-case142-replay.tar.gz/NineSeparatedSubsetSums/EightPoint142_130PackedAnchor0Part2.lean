import NineSeparatedSubsetSums.EightPoint142_130PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint142_130PackedAnchor0Part2 :
    ∀ j : Fin 7, 2411293 ≤ FourPointNumeric.octPackedCharge 142 130 20 packedOct142_130_0
      (2*((j.val : Int)+240)+0) := by decide +kernel

end NineSeparatedSubsetSums
