import NineSeparatedSubsetSums.Adaptive142Third133State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third133Proof20 : runCachedNode 511 128920 Adaptive142Third133Node20 = false := by
  decide +kernel

#print axioms adaptive142Third133Proof20

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third133Proof17 : runCachedNode 511 128920 Adaptive142Third133Node17 = false := by
  decide +kernel

#print axioms adaptive142Third133Proof17

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third133Proof7 : runCachedNode 511 128920 Adaptive142Third133Node7 = false := by
  decide +kernel

#print axioms adaptive142Third133Proof7

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third133Proof24 : runCachedNode 511 128920 Adaptive142Third133Node24 = false := by
  decide +kernel

#print axioms adaptive142Third133Proof24

end NineSeparatedSubsetSums
