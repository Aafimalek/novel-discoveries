import NineSeparatedSubsetSums.Adaptive142Third112Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint142Checked

namespace NineSeparatedSubsetSums


theorem adaptive142Third112 : NoDescendingTailAfterThird 142 112 :=
  noDescendingThirdTail_of_cached 142 112 111874 (fun t ht nd => max148_second142_fourPoint_moment_bound (112::t) (by simp [ht]) nd) adaptive142Third112Proof0

#print axioms adaptive142Third112

end NineSeparatedSubsetSums
