import NineSeparatedSubsetSums.Adaptive142Third133State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third133Proof4 : runCachedNode 511 128920 Adaptive142Third133Node4 = false := by
  decide +kernel

#print axioms adaptive142Third133Proof4

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third133Proof33 : runCachedNode 511 128920 Adaptive142Third133Node33 = false := by
  decide +kernel

#print axioms adaptive142Third133Proof33

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third133Proof34 : runCachedNode 511 128920 Adaptive142Third133Node34 = false := by
  decide +kernel

#print axioms adaptive142Third133Proof34

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third133Proof32 : runCachedNode 511 128920 Adaptive142Third133Node32 = false := by
  decide +kernel

#print axioms adaptive142Third133Proof32

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third133Proof3 : runCachedNode 511 128920 Adaptive142Third133Node3 = false := by
  decide +kernel

#print axioms adaptive142Third133Proof3

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third133Proof31 : runCachedNode 511 128920 Adaptive142Third133Node31 = false := by
  decide +kernel

#print axioms adaptive142Third133Proof31

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third133Proof30 : runCachedNode 511 128920 Adaptive142Third133Node30 = false := by
  decide +kernel

#print axioms adaptive142Third133Proof30

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third133Proof29 : runCachedNode 511 128920 Adaptive142Third133Node29 = false := by
  decide +kernel

#print axioms adaptive142Third133Proof29

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third133Proof28 : runCachedNode 511 128920 Adaptive142Third133Node28 = false := by
  decide +kernel

#print axioms adaptive142Third133Proof28

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third133Proof26 : runCachedNode 511 128920 Adaptive142Third133Node26 = false := by
  decide +kernel

#print axioms adaptive142Third133Proof26

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third133Proof25 : runCachedNode 511 128920 Adaptive142Third133Node25 = false := by
  decide +kernel

#print axioms adaptive142Third133Proof25

end NineSeparatedSubsetSums
