import NineSeparatedSubsetSums.Adaptive142Third138State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third138Proof127 : runCachedNode 511 129778 Adaptive142Third138Node127 = false := by
  decide +kernel

#print axioms adaptive142Third138Proof127

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third138Proof125 : runCachedNode 511 129778 Adaptive142Third138Node125 = false := by
  decide +kernel

#print axioms adaptive142Third138Proof125

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third138Proof11 : runCachedNode 511 129778 Adaptive142Third138Node11 = false := by
  decide +kernel

#print axioms adaptive142Third138Proof11

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third138Proof99 : runCachedNode 511 129778 Adaptive142Third138Node99 = false := by
  decide +kernel

#print axioms adaptive142Third138Proof99

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third138Proof71 : runCachedNode 511 129778 Adaptive142Third138Node71 = false := by
  decide +kernel

#print axioms adaptive142Third138Proof71

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third138Proof128 : runCachedNode 511 129778 Adaptive142Third138Node128 = false := by
  decide +kernel

#print axioms adaptive142Third138Proof128

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third138Proof68 : runCachedNode 511 129778 Adaptive142Third138Node68 = false := by
  decide +kernel

#print axioms adaptive142Third138Proof68

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third138Proof195 : runCachedNode 511 129778 Adaptive142Third138Node195 = false := by
  decide +kernel

#print axioms adaptive142Third138Proof195

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third138Proof194 : runCachedNode 511 129778 Adaptive142Third138Node194 = false := by
  decide +kernel

#print axioms adaptive142Third138Proof194

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third138Proof160 : runCachedNode 511 129778 Adaptive142Third138Node160 = false := by
  decide +kernel

#print axioms adaptive142Third138Proof160

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third138Proof192 : runCachedNode 511 129778 Adaptive142Third138Node192 = false := by
  decide +kernel

#print axioms adaptive142Third138Proof192

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third138Proof27 : runCachedNode 511 129778 Adaptive142Third138Node27 = false := by
  decide +kernel

#print axioms adaptive142Third138Proof27

end NineSeparatedSubsetSums
