import NineSeparatedSubsetSums.Adaptive142Third130State
import NineSeparatedSubsetSums.Adaptive142Third130Leaves0
import NineSeparatedSubsetSums.Adaptive142Third130Leaves2
import NineSeparatedSubsetSums.Adaptive142Third130Leaves1

namespace NineSeparatedSubsetSums

theorem adaptive142Third130Proof0 : runCachedNode 511 128359 Adaptive142Third130Node0 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 128359 Adaptive142Third130Node0 = [111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 125, 126, 127, 128, 129] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive142Third130Proof1
  · exact adaptive142Third130Proof2
  · exact adaptive142Third130Proof3
  · exact adaptive142Third130Proof4
  · exact adaptive142Third130Proof5
  · exact adaptive142Third130Proof6
  · exact adaptive142Third130Proof7
  · exact adaptive142Third130Proof8
  · exact adaptive142Third130Proof9
  · exact adaptive142Third130Proof10
  · exact adaptive142Third130Proof11
  · exact adaptive142Third130Proof12
  · exact adaptive142Third130Proof13
  · exact adaptive142Third130Proof14
  · exact adaptive142Third130Proof15
  · exact adaptive142Third130Proof16
  · exact adaptive142Third130Proof17
  · exact adaptive142Third130Proof18

#print axioms adaptive142Third130Proof0

end NineSeparatedSubsetSums
