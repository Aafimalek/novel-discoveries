import NineSeparatedSubsetSums.Adaptive142Third140State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third140Proof269 : runCachedNode 511 130107 Adaptive142Third140Node269 = false := by
  decide +kernel

#print axioms adaptive142Third140Proof269

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third140Proof9 : runCachedNode 511 130107 Adaptive142Third140Node9 = false := by
  decide +kernel

#print axioms adaptive142Third140Proof9

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third140Proof51 : runCachedNode 511 130107 Adaptive142Third140Node51 = false := by
  decide +kernel

#print axioms adaptive142Third140Proof51

end NineSeparatedSubsetSums
