import NineSeparatedSubsetSums.Adaptive142Third134State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third134Proof50 : runCachedNode 511 129144 Adaptive142Third134Node50 = false := by
  decide +kernel

#print axioms adaptive142Third134Proof50

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third134Proof51 : runCachedNode 511 129144 Adaptive142Third134Node51 = false := by
  decide +kernel

#print axioms adaptive142Third134Proof51

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third134Proof52 : runCachedNode 511 129144 Adaptive142Third134Node52 = false := by
  decide +kernel

#print axioms adaptive142Third134Proof52

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third134Proof53 : runCachedNode 511 129144 Adaptive142Third134Node53 = false := by
  decide +kernel

#print axioms adaptive142Third134Proof53

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third134Proof26 : runCachedNode 511 129144 Adaptive142Third134Node26 = false := by
  decide +kernel

#print axioms adaptive142Third134Proof26

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third134Proof27 : runCachedNode 511 129144 Adaptive142Third134Node27 = false := by
  decide +kernel

#print axioms adaptive142Third134Proof27

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third134Proof49 : runCachedNode 511 129144 Adaptive142Third134Node49 = false := by
  decide +kernel

#print axioms adaptive142Third134Proof49

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third134Proof25 : runCachedNode 511 129144 Adaptive142Third134Node25 = false := by
  decide +kernel

#print axioms adaptive142Third134Proof25

end NineSeparatedSubsetSums
