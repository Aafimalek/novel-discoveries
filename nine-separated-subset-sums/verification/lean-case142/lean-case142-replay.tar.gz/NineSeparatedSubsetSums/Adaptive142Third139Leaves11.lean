import NineSeparatedSubsetSums.Adaptive142Third139State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third139Proof105 : runCachedNode 511 129933 Adaptive142Third139Node105 = false := by
  decide +kernel

#print axioms adaptive142Third139Proof105

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third139Proof280 : runCachedNode 511 129933 Adaptive142Third139Node280 = false := by
  decide +kernel

#print axioms adaptive142Third139Proof280

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third139Proof93 : runCachedNode 511 129933 Adaptive142Third139Node93 = false := by
  decide +kernel

#print axioms adaptive142Third139Proof93

end NineSeparatedSubsetSums
