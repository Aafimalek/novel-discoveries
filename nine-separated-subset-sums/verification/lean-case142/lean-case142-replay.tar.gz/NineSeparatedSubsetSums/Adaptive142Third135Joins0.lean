import NineSeparatedSubsetSums.Adaptive142Third135State
import NineSeparatedSubsetSums.Adaptive142Third135Leaves9
import NineSeparatedSubsetSums.Adaptive142Third135Leaves7
import NineSeparatedSubsetSums.Adaptive142Third135Leaves8
import NineSeparatedSubsetSums.Adaptive142Third135Leaves3
import NineSeparatedSubsetSums.Adaptive142Third135Leaves1
import NineSeparatedSubsetSums.Adaptive142Third135Leaves0
import NineSeparatedSubsetSums.Adaptive142Third135Leaves6
import NineSeparatedSubsetSums.Adaptive142Third135Leaves5
import NineSeparatedSubsetSums.Adaptive142Third135Leaves2
import NineSeparatedSubsetSums.Adaptive142Third135Leaves4

namespace NineSeparatedSubsetSums

theorem adaptive142Third135Proof22 : runCachedNode 511 129264 Adaptive142Third135Node22 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 129264 Adaptive142Third135Node22 = [104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 120, 121, 122, 123, 124, 127, 128, 130, 131] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive142Third135Proof23
  · exact adaptive142Third135Proof24
  · exact adaptive142Third135Proof25
  · exact adaptive142Third135Proof26
  · exact adaptive142Third135Proof27
  · exact adaptive142Third135Proof28
  · exact adaptive142Third135Proof29
  · exact adaptive142Third135Proof30
  · exact adaptive142Third135Proof31
  · exact adaptive142Third135Proof32
  · exact adaptive142Third135Proof33
  · exact adaptive142Third135Proof34
  · exact adaptive142Third135Proof35
  · exact adaptive142Third135Proof36
  · exact adaptive142Third135Proof37
  · exact adaptive142Third135Proof38
  · exact adaptive142Third135Proof39
  · exact adaptive142Third135Proof40
  · exact adaptive142Third135Proof41
  · exact adaptive142Third135Proof42
  · exact adaptive142Third135Proof43
  · exact adaptive142Third135Proof44
  · exact adaptive142Third135Proof45
  · exact adaptive142Third135Proof46

#print axioms adaptive142Third135Proof22

theorem adaptive142Third135Proof47 : runCachedNode 511 129264 Adaptive142Third135Node47 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 129264 Adaptive142Third135Node47 = [104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 121, 122, 123, 124, 125, 128, 130, 131, 132] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive142Third135Proof48
  · exact adaptive142Third135Proof49
  · exact adaptive142Third135Proof50
  · exact adaptive142Third135Proof51
  · exact adaptive142Third135Proof52
  · exact adaptive142Third135Proof53
  · exact adaptive142Third135Proof54
  · exact adaptive142Third135Proof55
  · exact adaptive142Third135Proof56
  · exact adaptive142Third135Proof57
  · exact adaptive142Third135Proof58
  · exact adaptive142Third135Proof59
  · exact adaptive142Third135Proof60
  · exact adaptive142Third135Proof61
  · exact adaptive142Third135Proof62
  · exact adaptive142Third135Proof63
  · exact adaptive142Third135Proof64
  · exact adaptive142Third135Proof65
  · exact adaptive142Third135Proof66
  · exact adaptive142Third135Proof67
  · exact adaptive142Third135Proof68
  · exact adaptive142Third135Proof69
  · exact adaptive142Third135Proof70
  · exact adaptive142Third135Proof71
  · exact adaptive142Third135Proof72

#print axioms adaptive142Third135Proof47

theorem adaptive142Third135Proof73 : runCachedNode 511 129264 Adaptive142Third135Node73 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 129264 Adaptive142Third135Node73 = [103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 122, 123, 124, 125, 126, 130, 131, 132, 133] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive142Third135Proof74
  · exact adaptive142Third135Proof75
  · exact adaptive142Third135Proof76
  · exact adaptive142Third135Proof77
  · exact adaptive142Third135Proof78
  · exact adaptive142Third135Proof79
  · exact adaptive142Third135Proof80
  · exact adaptive142Third135Proof81
  · exact adaptive142Third135Proof82
  · exact adaptive142Third135Proof83
  · exact adaptive142Third135Proof84
  · exact adaptive142Third135Proof85
  · exact adaptive142Third135Proof86
  · exact adaptive142Third135Proof87
  · exact adaptive142Third135Proof88
  · exact adaptive142Third135Proof89
  · exact adaptive142Third135Proof90
  · exact adaptive142Third135Proof91
  · exact adaptive142Third135Proof92
  · exact adaptive142Third135Proof93
  · exact adaptive142Third135Proof94
  · exact adaptive142Third135Proof95
  · exact adaptive142Third135Proof96
  · exact adaptive142Third135Proof97
  · exact adaptive142Third135Proof98
  · exact adaptive142Third135Proof99
  · exact adaptive142Third135Proof100

#print axioms adaptive142Third135Proof73

theorem adaptive142Third135Proof0 : runCachedNode 511 129264 Adaptive142Third135Node0 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 129264 Adaptive142Third135Node0 = [110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 130, 131, 132, 133, 134] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive142Third135Proof1
  · exact adaptive142Third135Proof2
  · exact adaptive142Third135Proof3
  · exact adaptive142Third135Proof4
  · exact adaptive142Third135Proof5
  · exact adaptive142Third135Proof6
  · exact adaptive142Third135Proof7
  · exact adaptive142Third135Proof8
  · exact adaptive142Third135Proof9
  · exact adaptive142Third135Proof10
  · exact adaptive142Third135Proof11
  · exact adaptive142Third135Proof12
  · exact adaptive142Third135Proof13
  · exact adaptive142Third135Proof14
  · exact adaptive142Third135Proof15
  · exact adaptive142Third135Proof16
  · exact adaptive142Third135Proof17
  · exact adaptive142Third135Proof18
  · exact adaptive142Third135Proof19
  · exact adaptive142Third135Proof20
  · exact adaptive142Third135Proof21
  · exact adaptive142Third135Proof22
  · exact adaptive142Third135Proof47
  · exact adaptive142Third135Proof73

#print axioms adaptive142Third135Proof0

end NineSeparatedSubsetSums
