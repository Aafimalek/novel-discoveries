import NineSeparatedSubsetSums.Adaptive142Third141State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third141Proof19 : runCachedNode 511 130276 Adaptive142Third141Node19 = false := by
  decide +kernel

#print axioms adaptive142Third141Proof19

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third141Proof236 : runCachedNode 511 130276 Adaptive142Third141Node236 = false := by
  decide +kernel

#print axioms adaptive142Third141Proof236

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third141Proof5 : runCachedNode 511 130276 Adaptive142Third141Node5 = false := by
  decide +kernel

#print axioms adaptive142Third141Proof5

end NineSeparatedSubsetSums
