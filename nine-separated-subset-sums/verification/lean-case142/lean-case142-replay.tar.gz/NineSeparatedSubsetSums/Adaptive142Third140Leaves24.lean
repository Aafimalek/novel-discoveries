import NineSeparatedSubsetSums.Adaptive142Third140State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third140Proof165 : runCachedNode 511 130107 Adaptive142Third140Node165 = false := by
  decide +kernel

#print axioms adaptive142Third140Proof165

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third140Proof226 : runCachedNode 511 130107 Adaptive142Third140Node226 = false := by
  decide +kernel

#print axioms adaptive142Third140Proof226

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third140Proof76 : runCachedNode 511 130107 Adaptive142Third140Node76 = false := by
  decide +kernel

#print axioms adaptive142Third140Proof76

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third140Proof12 : runCachedNode 511 130107 Adaptive142Third140Node12 = false := by
  decide +kernel

#print axioms adaptive142Third140Proof12

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third140Proof102 : runCachedNode 511 130107 Adaptive142Third140Node102 = false := by
  decide +kernel

#print axioms adaptive142Third140Proof102

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third140Proof164 : runCachedNode 511 130107 Adaptive142Third140Node164 = false := by
  decide +kernel

#print axioms adaptive142Third140Proof164

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third140Proof131 : runCachedNode 511 130107 Adaptive142Third140Node131 = false := by
  decide +kernel

#print axioms adaptive142Third140Proof131

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third140Proof128 : runCachedNode 511 130107 Adaptive142Third140Node128 = false := by
  decide +kernel

#print axioms adaptive142Third140Proof128

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third140Proof145 : runCachedNode 511 130107 Adaptive142Third140Node145 = false := by
  decide +kernel

#print axioms adaptive142Third140Proof145

end NineSeparatedSubsetSums
