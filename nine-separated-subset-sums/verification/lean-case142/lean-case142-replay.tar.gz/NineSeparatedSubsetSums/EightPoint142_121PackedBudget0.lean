import NineSeparatedSubsetSums.EightPoint142_121PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct142_121_0_budget :
    FourPointNumeric.packedBudget 20 packedOct142_121_0 263 = 82348821 := by decide +kernel

#print axioms packedOct142_121_0_budget

end NineSeparatedSubsetSums
