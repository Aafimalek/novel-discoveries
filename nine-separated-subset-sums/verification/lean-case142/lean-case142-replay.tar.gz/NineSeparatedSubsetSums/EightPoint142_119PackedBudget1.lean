import NineSeparatedSubsetSums.EightPoint142_119PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct142_119_1_budget :
    FourPointNumeric.packedBudget 20 packedOct142_119_1 358 = 89014954 := by decide +kernel

#print axioms packedOct142_119_1_budget

end NineSeparatedSubsetSums
