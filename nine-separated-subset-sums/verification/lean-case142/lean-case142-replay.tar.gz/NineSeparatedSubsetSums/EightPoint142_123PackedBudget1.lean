import NineSeparatedSubsetSums.EightPoint142_123PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct142_123_1_budget :
    FourPointNumeric.packedBudget 20 packedOct142_123_1 474 = 83216418 := by decide +kernel

#print axioms packedOct142_123_1_budget

end NineSeparatedSubsetSums
