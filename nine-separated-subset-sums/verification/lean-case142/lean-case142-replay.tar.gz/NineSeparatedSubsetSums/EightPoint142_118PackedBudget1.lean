import NineSeparatedSubsetSums.EightPoint142_118PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct142_118_1_budget :
    FourPointNumeric.packedBudget 20 packedOct142_118_1 450 = 89253434 := by decide +kernel

#print axioms packedOct142_118_1_budget

end NineSeparatedSubsetSums
