import NineSeparatedSubsetSums.Adaptive142Third136State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third136Proof14 : runCachedNode 511 129404 Adaptive142Third136Node14 = false := by
  decide +kernel

#print axioms adaptive142Third136Proof14

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third136Proof168 : runCachedNode 511 129404 Adaptive142Third136Node168 = false := by
  decide +kernel

#print axioms adaptive142Third136Proof168

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third136Proof139 : runCachedNode 511 129404 Adaptive142Third136Node139 = false := by
  decide +kernel

#print axioms adaptive142Third136Proof139

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third136Proof54 : runCachedNode 511 129404 Adaptive142Third136Node54 = false := by
  decide +kernel

#print axioms adaptive142Third136Proof54

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third136Proof42 : runCachedNode 511 129404 Adaptive142Third136Node42 = false := by
  decide +kernel

#print axioms adaptive142Third136Proof42

end NineSeparatedSubsetSums
