import NineSeparatedSubsetSums.Adaptive142Third139State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third139Proof180 : runCachedNode 511 129933 Adaptive142Third139Node180 = false := by
  decide +kernel

#print axioms adaptive142Third139Proof180

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third139Proof144 : runCachedNode 511 129933 Adaptive142Third139Node144 = false := by
  decide +kernel

#print axioms adaptive142Third139Proof144

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third139Proof17 : runCachedNode 511 129933 Adaptive142Third139Node17 = false := by
  decide +kernel

#print axioms adaptive142Third139Proof17

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third139Proof12 : runCachedNode 511 129933 Adaptive142Third139Node12 = false := by
  decide +kernel

#print axioms adaptive142Third139Proof12

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third139Proof31 : runCachedNode 511 129933 Adaptive142Third139Node31 = false := by
  decide +kernel

#print axioms adaptive142Third139Proof31

end NineSeparatedSubsetSums
