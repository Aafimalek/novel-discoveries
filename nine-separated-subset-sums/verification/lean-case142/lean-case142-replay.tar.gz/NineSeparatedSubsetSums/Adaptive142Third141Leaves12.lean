import NineSeparatedSubsetSums.Adaptive142Third141State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third141Proof203 : runCachedNode 511 130276 Adaptive142Third141Node203 = false := by
  decide +kernel

#print axioms adaptive142Third141Proof203

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third141Proof342 : runCachedNode 511 130276 Adaptive142Third141Node342 = false := by
  decide +kernel

#print axioms adaptive142Third141Proof342

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third141Proof118 : runCachedNode 511 130276 Adaptive142Third141Node118 = false := by
  decide +kernel

#print axioms adaptive142Third141Proof118

end NineSeparatedSubsetSums
