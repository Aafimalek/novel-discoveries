import NineSeparatedSubsetSums.Adaptive142Third134State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third134Proof45 : runCachedNode 511 129144 Adaptive142Third134Node45 = false := by
  decide +kernel

#print axioms adaptive142Third134Proof45

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third134Proof18 : runCachedNode 511 129144 Adaptive142Third134Node18 = false := by
  decide +kernel

#print axioms adaptive142Third134Proof18

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third134Proof37 : runCachedNode 511 129144 Adaptive142Third134Node37 = false := by
  decide +kernel

#print axioms adaptive142Third134Proof37

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third134Proof48 : runCachedNode 511 129144 Adaptive142Third134Node48 = false := by
  decide +kernel

#print axioms adaptive142Third134Proof48

end NineSeparatedSubsetSums
