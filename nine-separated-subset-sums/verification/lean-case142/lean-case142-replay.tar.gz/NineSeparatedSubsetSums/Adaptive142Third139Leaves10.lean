import NineSeparatedSubsetSums.Adaptive142Third139State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third139Proof318 : runCachedNode 511 129933 Adaptive142Third139Node318 = false := by
  decide +kernel

#print axioms adaptive142Third139Proof318

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third139Proof20 : runCachedNode 511 129933 Adaptive142Third139Node20 = false := by
  decide +kernel

#print axioms adaptive142Third139Proof20

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third139Proof33 : runCachedNode 511 129933 Adaptive142Third139Node33 = false := by
  decide +kernel

#print axioms adaptive142Third139Proof33

end NineSeparatedSubsetSums
