import NineSeparatedSubsetSums.Adaptive142Third140State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third140Proof267 : runCachedNode 511 130107 Adaptive142Third140Node267 = false := by
  decide +kernel

#print axioms adaptive142Third140Proof267

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third140Proof47 : runCachedNode 511 130107 Adaptive142Third140Node47 = false := by
  decide +kernel

#print axioms adaptive142Third140Proof47

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third140Proof253 : runCachedNode 511 130107 Adaptive142Third140Node253 = false := by
  decide +kernel

#print axioms adaptive142Third140Proof253

end NineSeparatedSubsetSums
