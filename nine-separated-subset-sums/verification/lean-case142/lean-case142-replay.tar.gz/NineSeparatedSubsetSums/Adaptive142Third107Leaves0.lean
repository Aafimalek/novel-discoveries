import NineSeparatedSubsetSums.Adaptive142Third107State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third107Proof0 : runCachedNode 511 111874 Adaptive142Third107Node0 = false := by
  decide +kernel

#print axioms adaptive142Third107Proof0

end NineSeparatedSubsetSums
