import NineSeparatedSubsetSums.Adaptive142Third132State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third132Proof7 : runCachedNode 511 128761 Adaptive142Third132Node7 = false := by
  decide +kernel

#print axioms adaptive142Third132Proof7

end NineSeparatedSubsetSums
