import NineSeparatedSubsetSums.Adaptive142Third128State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third128Proof16 : runCachedNode 511 127897 Adaptive142Third128Node16 = false := by
  decide +kernel

#print axioms adaptive142Third128Proof16

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third128Proof15 : runCachedNode 511 127897 Adaptive142Third128Node15 = false := by
  decide +kernel

#print axioms adaptive142Third128Proof15

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third128Proof14 : runCachedNode 511 127897 Adaptive142Third128Node14 = false := by
  decide +kernel

#print axioms adaptive142Third128Proof14

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third128Proof13 : runCachedNode 511 127897 Adaptive142Third128Node13 = false := by
  decide +kernel

#print axioms adaptive142Third128Proof13

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third128Proof8 : runCachedNode 511 127897 Adaptive142Third128Node8 = false := by
  decide +kernel

#print axioms adaptive142Third128Proof8

end NineSeparatedSubsetSums
