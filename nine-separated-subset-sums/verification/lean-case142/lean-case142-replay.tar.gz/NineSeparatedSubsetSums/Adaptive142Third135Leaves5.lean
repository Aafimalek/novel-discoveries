import NineSeparatedSubsetSums.Adaptive142Third135State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third135Proof15 : runCachedNode 511 129264 Adaptive142Third135Node15 = false := by
  decide +kernel

#print axioms adaptive142Third135Proof15

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third135Proof44 : runCachedNode 511 129264 Adaptive142Third135Node44 = false := by
  decide +kernel

#print axioms adaptive142Third135Proof44

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third135Proof14 : runCachedNode 511 129264 Adaptive142Third135Node14 = false := by
  decide +kernel

#print axioms adaptive142Third135Proof14

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third135Proof45 : runCachedNode 511 129264 Adaptive142Third135Node45 = false := by
  decide +kernel

#print axioms adaptive142Third135Proof45

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third135Proof96 : runCachedNode 511 129264 Adaptive142Third135Node96 = false := by
  decide +kernel

#print axioms adaptive142Third135Proof96

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third135Proof1 : runCachedNode 511 129264 Adaptive142Third135Node1 = false := by
  decide +kernel

#print axioms adaptive142Third135Proof1

end NineSeparatedSubsetSums
