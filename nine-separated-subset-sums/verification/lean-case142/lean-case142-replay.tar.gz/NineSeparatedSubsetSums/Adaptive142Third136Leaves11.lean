import NineSeparatedSubsetSums.Adaptive142Third136State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third136Proof113 : runCachedNode 511 129404 Adaptive142Third136Node113 = false := by
  decide +kernel

#print axioms adaptive142Third136Proof113

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third136Proof167 : runCachedNode 511 129404 Adaptive142Third136Node167 = false := by
  decide +kernel

#print axioms adaptive142Third136Proof167

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third136Proof223 : runCachedNode 511 129404 Adaptive142Third136Node223 = false := by
  decide +kernel

#print axioms adaptive142Third136Proof223

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third136Proof10 : runCachedNode 511 129404 Adaptive142Third136Node10 = false := by
  decide +kernel

#print axioms adaptive142Third136Proof10

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third136Proof46 : runCachedNode 511 129404 Adaptive142Third136Node46 = false := by
  decide +kernel

#print axioms adaptive142Third136Proof46

end NineSeparatedSubsetSums
