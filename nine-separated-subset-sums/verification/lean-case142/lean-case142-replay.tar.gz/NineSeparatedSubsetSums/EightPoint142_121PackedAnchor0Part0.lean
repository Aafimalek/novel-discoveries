import NineSeparatedSubsetSums.EightPoint142_121PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint142_121PackedAnchor0Part0 :
    ∀ j : Fin 120, 2295298 ≤ FourPointNumeric.octPackedCharge 142 121 20 packedOct142_121_0
      (2*((j.val : Int)+0)+1) := by decide +kernel

end NineSeparatedSubsetSums
