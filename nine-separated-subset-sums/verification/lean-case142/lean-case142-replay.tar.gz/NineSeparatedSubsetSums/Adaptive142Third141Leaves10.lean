import NineSeparatedSubsetSums.Adaptive142Third141State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third141Proof106 : runCachedNode 511 130276 Adaptive142Third141Node106 = false := by
  decide +kernel

#print axioms adaptive142Third141Proof106

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third141Proof105 : runCachedNode 511 130276 Adaptive142Third141Node105 = false := by
  decide +kernel

#print axioms adaptive142Third141Proof105

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third141Proof9 : runCachedNode 511 130276 Adaptive142Third141Node9 = false := by
  decide +kernel

#print axioms adaptive142Third141Proof9

end NineSeparatedSubsetSums
