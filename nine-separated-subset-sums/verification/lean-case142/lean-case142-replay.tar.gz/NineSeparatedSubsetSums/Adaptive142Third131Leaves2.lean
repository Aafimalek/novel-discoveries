import NineSeparatedSubsetSums.Adaptive142Third131State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third131Proof14 : runCachedNode 511 128642 Adaptive142Third131Node14 = false := by
  decide +kernel

#print axioms adaptive142Third131Proof14

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third131Proof13 : runCachedNode 511 128642 Adaptive142Third131Node13 = false := by
  decide +kernel

#print axioms adaptive142Third131Proof13

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third131Proof12 : runCachedNode 511 128642 Adaptive142Third131Node12 = false := by
  decide +kernel

#print axioms adaptive142Third131Proof12

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third131Proof11 : runCachedNode 511 128642 Adaptive142Third131Node11 = false := by
  decide +kernel

#print axioms adaptive142Third131Proof11

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third131Proof10 : runCachedNode 511 128642 Adaptive142Third131Node10 = false := by
  decide +kernel

#print axioms adaptive142Third131Proof10

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third131Proof9 : runCachedNode 511 128642 Adaptive142Third131Node9 = false := by
  decide +kernel

#print axioms adaptive142Third131Proof9

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third131Proof8 : runCachedNode 511 128642 Adaptive142Third131Node8 = false := by
  decide +kernel

#print axioms adaptive142Third131Proof8

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third131Proof7 : runCachedNode 511 128642 Adaptive142Third131Node7 = false := by
  decide +kernel

#print axioms adaptive142Third131Proof7

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third131Proof6 : runCachedNode 511 128642 Adaptive142Third131Node6 = false := by
  decide +kernel

#print axioms adaptive142Third131Proof6

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third131Proof5 : runCachedNode 511 128642 Adaptive142Third131Node5 = false := by
  decide +kernel

#print axioms adaptive142Third131Proof5

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third131Proof4 : runCachedNode 511 128642 Adaptive142Third131Node4 = false := by
  decide +kernel

#print axioms adaptive142Third131Proof4

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third131Proof1 : runCachedNode 511 128642 Adaptive142Third131Node1 = false := by
  decide +kernel

#print axioms adaptive142Third131Proof1

end NineSeparatedSubsetSums
