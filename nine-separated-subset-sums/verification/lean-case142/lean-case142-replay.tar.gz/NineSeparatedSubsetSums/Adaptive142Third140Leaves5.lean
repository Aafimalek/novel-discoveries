import NineSeparatedSubsetSums.Adaptive142Third140State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third140Proof19 : runCachedNode 511 130107 Adaptive142Third140Node19 = false := by
  decide +kernel

#print axioms adaptive142Third140Proof19

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third140Proof16 : runCachedNode 511 130107 Adaptive142Third140Node16 = false := by
  decide +kernel

#print axioms adaptive142Third140Proof16

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third140Proof299 : runCachedNode 511 130107 Adaptive142Third140Node299 = false := by
  decide +kernel

#print axioms adaptive142Third140Proof299

end NineSeparatedSubsetSums
