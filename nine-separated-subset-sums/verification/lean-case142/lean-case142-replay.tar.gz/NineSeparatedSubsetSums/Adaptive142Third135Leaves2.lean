import NineSeparatedSubsetSums.Adaptive142Third135State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third135Proof100 : runCachedNode 511 129264 Adaptive142Third135Node100 = false := by
  decide +kernel

#print axioms adaptive142Third135Proof100

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third135Proof71 : runCachedNode 511 129264 Adaptive142Third135Node71 = false := by
  decide +kernel

#print axioms adaptive142Third135Proof71

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third135Proof48 : runCachedNode 511 129264 Adaptive142Third135Node48 = false := by
  decide +kernel

#print axioms adaptive142Third135Proof48

end NineSeparatedSubsetSums
