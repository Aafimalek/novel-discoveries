import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive142Third114Node0 : CachedSearchNode :=
  ⟨4, 113, computeCenteredMask [148,142,114], 404, 55064⟩

end NineSeparatedSubsetSums
