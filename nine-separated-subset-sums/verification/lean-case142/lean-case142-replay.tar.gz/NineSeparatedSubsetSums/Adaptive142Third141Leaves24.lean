import NineSeparatedSubsetSums.Adaptive142Third141State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third141Proof305 : runCachedNode 511 130276 Adaptive142Third141Node305 = false := by
  decide +kernel

#print axioms adaptive142Third141Proof305

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third141Proof231 : runCachedNode 511 130276 Adaptive142Third141Node231 = false := by
  decide +kernel

#print axioms adaptive142Third141Proof231

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third141Proof335 : runCachedNode 511 130276 Adaptive142Third141Node335 = false := by
  decide +kernel

#print axioms adaptive142Third141Proof335

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third141Proof100 : runCachedNode 511 130276 Adaptive142Third141Node100 = false := by
  decide +kernel

#print axioms adaptive142Third141Proof100

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third141Proof13 : runCachedNode 511 130276 Adaptive142Third141Node13 = false := by
  decide +kernel

#print axioms adaptive142Third141Proof13

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third141Proof47 : runCachedNode 511 130276 Adaptive142Third141Node47 = false := by
  decide +kernel

#print axioms adaptive142Third141Proof47

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third141Proof201 : runCachedNode 511 130276 Adaptive142Third141Node201 = false := by
  decide +kernel

#print axioms adaptive142Third141Proof201

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third141Proof211 : runCachedNode 511 130276 Adaptive142Third141Node211 = false := by
  decide +kernel

#print axioms adaptive142Third141Proof211

end NineSeparatedSubsetSums
