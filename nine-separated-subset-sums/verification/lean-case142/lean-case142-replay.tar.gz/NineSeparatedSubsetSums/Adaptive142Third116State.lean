import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive142Third116Node0 : CachedSearchNode :=
  ⟨4, 115, computeCenteredMask [148,142,116], 406, 55524⟩

end NineSeparatedSubsetSums
