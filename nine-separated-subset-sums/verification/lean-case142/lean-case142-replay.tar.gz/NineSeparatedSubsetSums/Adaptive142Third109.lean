import NineSeparatedSubsetSums.Adaptive142Third109Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint142Checked

namespace NineSeparatedSubsetSums


theorem adaptive142Third109 : NoDescendingTailAfterThird 142 109 :=
  noDescendingThirdTail_of_cached 142 109 111874 (fun t ht nd => max148_second142_fourPoint_moment_bound (109::t) (by simp [ht]) nd) adaptive142Third109Proof0

#print axioms adaptive142Third109

end NineSeparatedSubsetSums
