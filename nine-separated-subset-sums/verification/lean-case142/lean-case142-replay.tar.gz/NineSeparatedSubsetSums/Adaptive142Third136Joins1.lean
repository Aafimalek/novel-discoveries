import NineSeparatedSubsetSums.Adaptive142Third136State
import NineSeparatedSubsetSums.Adaptive142Third136Leaves2
import NineSeparatedSubsetSums.Adaptive142Third136Leaves3
import NineSeparatedSubsetSums.Adaptive142Third136Leaves21
import NineSeparatedSubsetSums.Adaptive142Third136Leaves20
import NineSeparatedSubsetSums.Adaptive142Third136Leaves19
import NineSeparatedSubsetSums.Adaptive142Third136Leaves18
import NineSeparatedSubsetSums.Adaptive142Third136Leaves0
import NineSeparatedSubsetSums.Adaptive142Third136Leaves11
import NineSeparatedSubsetSums.Adaptive142Third136Leaves15
import NineSeparatedSubsetSums.Adaptive142Third136Leaves14
import NineSeparatedSubsetSums.Adaptive142Third136Leaves9
import NineSeparatedSubsetSums.Adaptive142Third136Leaves10
import NineSeparatedSubsetSums.Adaptive142Third136Leaves4
import NineSeparatedSubsetSums.Adaptive142Third136Joins0

namespace NineSeparatedSubsetSums

theorem adaptive142Third136Proof0 : runCachedNode 511 129404 Adaptive142Third136Node0 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 129404 Adaptive142Third136Node0 = [110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 131, 132, 133, 134, 135] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive142Third136Proof1
  · exact adaptive142Third136Proof2
  · exact adaptive142Third136Proof3
  · exact adaptive142Third136Proof4
  · exact adaptive142Third136Proof5
  · exact adaptive142Third136Proof6
  · exact adaptive142Third136Proof7
  · exact adaptive142Third136Proof8
  · exact adaptive142Third136Proof9
  · exact adaptive142Third136Proof10
  · exact adaptive142Third136Proof11
  · exact adaptive142Third136Proof12
  · exact adaptive142Third136Proof13
  · exact adaptive142Third136Proof14
  · exact adaptive142Third136Proof15
  · exact adaptive142Third136Proof16
  · exact adaptive142Third136Proof17
  · exact adaptive142Third136Proof18
  · exact adaptive142Third136Proof19
  · exact adaptive142Third136Proof41
  · exact adaptive142Third136Proof64
  · exact adaptive142Third136Proof89
  · exact adaptive142Third136Proof115
  · exact adaptive142Third136Proof142
  · exact adaptive142Third136Proof202

#print axioms adaptive142Third136Proof0

end NineSeparatedSubsetSums
