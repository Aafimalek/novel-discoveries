import NineSeparatedSubsetSums.EightPoint142_129PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct142_129_1_budget :
    FourPointNumeric.packedBudget 20 packedOct142_129_1 282 = 87390426 := by decide +kernel

#print axioms packedOct142_129_1_budget

end NineSeparatedSubsetSums
