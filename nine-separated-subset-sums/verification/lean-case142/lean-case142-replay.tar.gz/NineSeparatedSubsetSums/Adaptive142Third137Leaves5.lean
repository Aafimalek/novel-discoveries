import NineSeparatedSubsetSums.Adaptive142Third137State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third137Proof72 : runCachedNode 511 129593 Adaptive142Third137Node72 = false := by
  decide +kernel

#print axioms adaptive142Third137Proof72

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third137Proof99 : runCachedNode 511 129593 Adaptive142Third137Node99 = false := by
  decide +kernel

#print axioms adaptive142Third137Proof99

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third137Proof8 : runCachedNode 511 129593 Adaptive142Third137Node8 = false := by
  decide +kernel

#print axioms adaptive142Third137Proof8

end NineSeparatedSubsetSums
