import NineSeparatedSubsetSums.Adaptive142Third139State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third139Proof107 : runCachedNode 511 129933 Adaptive142Third139Node107 = false := by
  decide +kernel

#print axioms adaptive142Third139Proof107

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third139Proof18 : runCachedNode 511 129933 Adaptive142Third139Node18 = false := by
  decide +kernel

#print axioms adaptive142Third139Proof18

end NineSeparatedSubsetSums
