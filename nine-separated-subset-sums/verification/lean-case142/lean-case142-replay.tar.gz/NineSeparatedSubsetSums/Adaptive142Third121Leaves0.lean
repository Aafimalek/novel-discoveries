import NineSeparatedSubsetSums.Adaptive142Third121State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third121Proof0 : runCachedNode 511 126075 Adaptive142Third121Node0 = false := by
  decide +kernel

#print axioms adaptive142Third121Proof0

end NineSeparatedSubsetSums
