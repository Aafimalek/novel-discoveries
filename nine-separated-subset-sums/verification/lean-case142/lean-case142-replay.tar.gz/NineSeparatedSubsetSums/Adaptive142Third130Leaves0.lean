import NineSeparatedSubsetSums.Adaptive142Third130State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third130Proof18 : runCachedNode 511 128359 Adaptive142Third130Node18 = false := by
  decide +kernel

#print axioms adaptive142Third130Proof18

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third130Proof17 : runCachedNode 511 128359 Adaptive142Third130Node17 = false := by
  decide +kernel

#print axioms adaptive142Third130Proof17

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third130Proof16 : runCachedNode 511 128359 Adaptive142Third130Node16 = false := by
  decide +kernel

#print axioms adaptive142Third130Proof16

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third130Proof1 : runCachedNode 511 128359 Adaptive142Third130Node1 = false := by
  decide +kernel

#print axioms adaptive142Third130Proof1

end NineSeparatedSubsetSums
