import NineSeparatedSubsetSums.Adaptive142Third135State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third135Proof21 : runCachedNode 511 129264 Adaptive142Third135Node21 = false := by
  decide +kernel

#print axioms adaptive142Third135Proof21

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third135Proof13 : runCachedNode 511 129264 Adaptive142Third135Node13 = false := by
  decide +kernel

#print axioms adaptive142Third135Proof13

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third135Proof31 : runCachedNode 511 129264 Adaptive142Third135Node31 = false := by
  decide +kernel

#print axioms adaptive142Third135Proof31

end NineSeparatedSubsetSums
