import NineSeparatedSubsetSums.Adaptive142Third138State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third138Proof103 : runCachedNode 511 129778 Adaptive142Third138Node103 = false := by
  decide +kernel

#print axioms adaptive142Third138Proof103

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third138Proof171 : runCachedNode 511 129778 Adaptive142Third138Node171 = false := by
  decide +kernel

#print axioms adaptive142Third138Proof171

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third138Proof15 : runCachedNode 511 129778 Adaptive142Third138Node15 = false := by
  decide +kernel

#print axioms adaptive142Third138Proof15

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third138Proof57 : runCachedNode 511 129778 Adaptive142Third138Node57 = false := by
  decide +kernel

#print axioms adaptive142Third138Proof57

end NineSeparatedSubsetSums
