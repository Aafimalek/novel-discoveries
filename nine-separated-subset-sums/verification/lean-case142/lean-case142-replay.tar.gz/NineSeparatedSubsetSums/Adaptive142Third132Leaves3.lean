import NineSeparatedSubsetSums.Adaptive142Third132State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third132Proof18 : runCachedNode 511 128761 Adaptive142Third132Node18 = false := by
  decide +kernel

#print axioms adaptive142Third132Proof18

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third132Proof14 : runCachedNode 511 128761 Adaptive142Third132Node14 = false := by
  decide +kernel

#print axioms adaptive142Third132Proof14

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third132Proof12 : runCachedNode 511 128761 Adaptive142Third132Node12 = false := by
  decide +kernel

#print axioms adaptive142Third132Proof12

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third132Proof11 : runCachedNode 511 128761 Adaptive142Third132Node11 = false := by
  decide +kernel

#print axioms adaptive142Third132Proof11

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third132Proof9 : runCachedNode 511 128761 Adaptive142Third132Node9 = false := by
  decide +kernel

#print axioms adaptive142Third132Proof9

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third132Proof8 : runCachedNode 511 128761 Adaptive142Third132Node8 = false := by
  decide +kernel

#print axioms adaptive142Third132Proof8

end NineSeparatedSubsetSums
