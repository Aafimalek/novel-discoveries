import NineSeparatedSubsetSums.EightPoint142_123PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct142_123_0_budget :
    FourPointNumeric.packedBudget 20 packedOct142_123_0 473 = 83144529 := by decide +kernel

#print axioms packedOct142_123_0_budget

end NineSeparatedSubsetSums
