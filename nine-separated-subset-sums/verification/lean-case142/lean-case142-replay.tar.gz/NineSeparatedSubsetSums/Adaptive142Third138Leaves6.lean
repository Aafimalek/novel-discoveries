import NineSeparatedSubsetSums.Adaptive142Third138State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third138Proof202 : runCachedNode 511 129778 Adaptive142Third138Node202 = false := by
  decide +kernel

#print axioms adaptive142Third138Proof202

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third138Proof106 : runCachedNode 511 129778 Adaptive142Third138Node106 = false := by
  decide +kernel

#print axioms adaptive142Third138Proof106

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third138Proof156 : runCachedNode 511 129778 Adaptive142Third138Node156 = false := by
  decide +kernel

#print axioms adaptive142Third138Proof156

end NineSeparatedSubsetSums
