import NineSeparatedSubsetSums.Adaptive142Third137State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third137Proof19 : runCachedNode 511 129593 Adaptive142Third137Node19 = false := by
  decide +kernel

#print axioms adaptive142Third137Proof19

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third137Proof194 : runCachedNode 511 129593 Adaptive142Third137Node194 = false := by
  decide +kernel

#print axioms adaptive142Third137Proof194

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third137Proof150 : runCachedNode 511 129593 Adaptive142Third137Node150 = false := by
  decide +kernel

#print axioms adaptive142Third137Proof150

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third137Proof56 : runCachedNode 511 129593 Adaptive142Third137Node56 = false := by
  decide +kernel

#print axioms adaptive142Third137Proof56

end NineSeparatedSubsetSums
