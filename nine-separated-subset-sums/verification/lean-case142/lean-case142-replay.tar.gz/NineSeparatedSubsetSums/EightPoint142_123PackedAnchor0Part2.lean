import NineSeparatedSubsetSums.EightPoint142_123PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint142_123PackedAnchor0Part2 :
    ∀ j : Fin 1, 2311222 ≤ FourPointNumeric.octPackedCharge 142 123 20 packedOct142_123_0
      (2*((j.val : Int)+240)+1) := by decide +kernel

end NineSeparatedSubsetSums
