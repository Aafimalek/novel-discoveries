import NineSeparatedSubsetSums.Adaptive142Third138State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third138Proof239 : runCachedNode 511 129778 Adaptive142Third138Node239 = false := by
  decide +kernel

#print axioms adaptive142Third138Proof239

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third138Proof17 : runCachedNode 511 129778 Adaptive142Third138Node17 = false := by
  decide +kernel

#print axioms adaptive142Third138Proof17

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third138Proof46 : runCachedNode 511 129778 Adaptive142Third138Node46 = false := by
  decide +kernel

#print axioms adaptive142Third138Proof46

end NineSeparatedSubsetSums
