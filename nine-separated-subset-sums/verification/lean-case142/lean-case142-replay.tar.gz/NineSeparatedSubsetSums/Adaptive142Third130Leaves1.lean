import NineSeparatedSubsetSums.Adaptive142Third130State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third130Proof15 : runCachedNode 511 128359 Adaptive142Third130Node15 = false := by
  decide +kernel

#print axioms adaptive142Third130Proof15

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third130Proof14 : runCachedNode 511 128359 Adaptive142Third130Node14 = false := by
  decide +kernel

#print axioms adaptive142Third130Proof14

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third130Proof13 : runCachedNode 511 128359 Adaptive142Third130Node13 = false := by
  decide +kernel

#print axioms adaptive142Third130Proof13

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third130Proof12 : runCachedNode 511 128359 Adaptive142Third130Node12 = false := by
  decide +kernel

#print axioms adaptive142Third130Proof12

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third130Proof11 : runCachedNode 511 128359 Adaptive142Third130Node11 = false := by
  decide +kernel

#print axioms adaptive142Third130Proof11

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third130Proof10 : runCachedNode 511 128359 Adaptive142Third130Node10 = false := by
  decide +kernel

#print axioms adaptive142Third130Proof10

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third130Proof8 : runCachedNode 511 128359 Adaptive142Third130Node8 = false := by
  decide +kernel

#print axioms adaptive142Third130Proof8

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third130Proof9 : runCachedNode 511 128359 Adaptive142Third130Node9 = false := by
  decide +kernel

#print axioms adaptive142Third130Proof9

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third130Proof7 : runCachedNode 511 128359 Adaptive142Third130Node7 = false := by
  decide +kernel

#print axioms adaptive142Third130Proof7

end NineSeparatedSubsetSums
