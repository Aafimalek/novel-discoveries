import NineSeparatedSubsetSums.Adaptive142Third136State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third136Proof37 : runCachedNode 511 129404 Adaptive142Third136Node37 = false := by
  decide +kernel

#print axioms adaptive142Third136Proof37

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third136Proof85 : runCachedNode 511 129404 Adaptive142Third136Node85 = false := by
  decide +kernel

#print axioms adaptive142Third136Proof85

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third136Proof225 : runCachedNode 511 129404 Adaptive142Third136Node225 = false := by
  decide +kernel

#print axioms adaptive142Third136Proof225

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third136Proof59 : runCachedNode 511 129404 Adaptive142Third136Node59 = false := by
  decide +kernel

#print axioms adaptive142Third136Proof59

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third136Proof195 : runCachedNode 511 129404 Adaptive142Third136Node195 = false := by
  decide +kernel

#print axioms adaptive142Third136Proof195

end NineSeparatedSubsetSums
