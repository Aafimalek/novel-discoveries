import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive142Third121Node0 : CachedSearchNode :=
  ⟨4, 120, computeCenteredMask [148,142,121], 411, 56709⟩

end NineSeparatedSubsetSums
