import NineSeparatedSubsetSums.Adaptive142Third137State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third137Proof159 : runCachedNode 511 129593 Adaptive142Third137Node159 = false := by
  decide +kernel

#print axioms adaptive142Third137Proof159

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third137Proof153 : runCachedNode 511 129593 Adaptive142Third137Node153 = false := by
  decide +kernel

#print axioms adaptive142Third137Proof153

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third137Proof111 : runCachedNode 511 129593 Adaptive142Third137Node111 = false := by
  decide +kernel

#print axioms adaptive142Third137Proof111

end NineSeparatedSubsetSums
