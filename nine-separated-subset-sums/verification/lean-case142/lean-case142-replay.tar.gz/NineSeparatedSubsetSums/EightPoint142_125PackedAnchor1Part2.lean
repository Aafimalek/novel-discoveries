import NineSeparatedSubsetSums.EightPoint142_125PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint142_125PackedAnchor1Part2 :
    ∀ j : Fin 6, 2388677 ≤ FourPointNumeric.octPackedCharge 142 125 20 packedOct142_125_1
      (2*((j.val : Int)+240)+0) := by decide +kernel

end NineSeparatedSubsetSums
