import NineSeparatedSubsetSums.Adaptive142Third140State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third140Proof105 : runCachedNode 511 130107 Adaptive142Third140Node105 = false := by
  decide +kernel

#print axioms adaptive142Third140Proof105

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third140Proof309 : runCachedNode 511 130107 Adaptive142Third140Node309 = false := by
  decide +kernel

#print axioms adaptive142Third140Proof309

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third140Proof199 : runCachedNode 511 130107 Adaptive142Third140Node199 = false := by
  decide +kernel

#print axioms adaptive142Third140Proof199

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third140Proof104 : runCachedNode 511 130107 Adaptive142Third140Node104 = false := by
  decide +kernel

#print axioms adaptive142Third140Proof104

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third140Proof116 : runCachedNode 511 130107 Adaptive142Third140Node116 = false := by
  decide +kernel

#print axioms adaptive142Third140Proof116

end NineSeparatedSubsetSums
