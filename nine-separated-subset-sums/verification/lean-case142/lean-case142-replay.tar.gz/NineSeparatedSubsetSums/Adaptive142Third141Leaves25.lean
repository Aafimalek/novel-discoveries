import NineSeparatedSubsetSums.Adaptive142Third141State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third141Proof99 : runCachedNode 511 130276 Adaptive142Third141Node99 = false := by
  decide +kernel

#print axioms adaptive142Third141Proof99

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third141Proof98 : runCachedNode 511 130276 Adaptive142Third141Node98 = false := by
  decide +kernel

#print axioms adaptive142Third141Proof98

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third141Proof73 : runCachedNode 511 130276 Adaptive142Third141Node73 = false := by
  decide +kernel

#print axioms adaptive142Third141Proof73

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third141Proof199 : runCachedNode 511 130276 Adaptive142Third141Node199 = false := by
  decide +kernel

#print axioms adaptive142Third141Proof199

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third141Proof128 : runCachedNode 511 130276 Adaptive142Third141Node128 = false := by
  decide +kernel

#print axioms adaptive142Third141Proof128

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third141Proof76 : runCachedNode 511 130276 Adaptive142Third141Node76 = false := by
  decide +kernel

#print axioms adaptive142Third141Proof76

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third141Proof382 : runCachedNode 511 130276 Adaptive142Third141Node382 = false := by
  decide +kernel

#print axioms adaptive142Third141Proof382

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third141Proof381 : runCachedNode 511 130276 Adaptive142Third141Node381 = false := by
  decide +kernel

#print axioms adaptive142Third141Proof381

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third141Proof57 : runCachedNode 511 130276 Adaptive142Third141Node57 = false := by
  decide +kernel

#print axioms adaptive142Third141Proof57

end NineSeparatedSubsetSums
