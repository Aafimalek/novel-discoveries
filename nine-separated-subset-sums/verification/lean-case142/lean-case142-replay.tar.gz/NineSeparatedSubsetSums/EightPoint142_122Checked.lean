import NineSeparatedSubsetSums.EightPointPackedGeometry
import NineSeparatedSubsetSums.EightPoint142_122PackedBudget0
import NineSeparatedSubsetSums.EightPoint142_122PackedAnchor0Part0
import NineSeparatedSubsetSums.EightPoint142_122PackedAnchor0Part1
import NineSeparatedSubsetSums.EightPoint142_122PackedAnchor0Part2
import NineSeparatedSubsetSums.EightPoint142_122PackedBudget1
import NineSeparatedSubsetSums.EightPoint142_122PackedAnchor1Part0
import NineSeparatedSubsetSums.EightPoint142_122PackedAnchor1Part1

namespace NineSeparatedSubsetSums

private theorem packedOct142_122Anchor0 :
  ∀ j : Fin 481, ((j.val : Int)+142+122)%2=0 →
    2303472 ≤ FourPointNumeric.octPackedCharge 142 122 20 packedOct142_122_0 (j.val : Int) := by
  intro j hj
  let k := (j.val-0)/2
  have hk : k < 241 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+0 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint142_122PackedAnchor0Part0 z
    rwa [he,hrep] at ht
  by_cases h1 : k < 240
  · let z : Fin 120 := ⟨k-120, by omega⟩
    have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
    have ht := eightPoint142_122PackedAnchor0Part1 z
    rwa [he,hrep] at ht
  let z : Fin 1 := ⟨k-240, by omega⟩
  have he : (z.val : Int)+240 = k := by dsimp [z] <;> omega
  have ht := eightPoint142_122PackedAnchor0Part2 z
  rwa [he,hrep] at ht

private theorem packedOct142_122Anchor1 :
  ∀ j : Fin 481, ((j.val : Int)+142+122)%2=1 →
    2303251 ≤ FourPointNumeric.octPackedCharge 142 122 20 packedOct142_122_1 (j.val : Int) := by
  intro j hj
  let k := (j.val-1)/2
  have hk : k < 240 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+1 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint142_122PackedAnchor1Part0 z
    rwa [he,hrep] at ht
  let z : Fin 120 := ⟨k-120, by omega⟩
  have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
  have ht := eightPoint142_122PackedAnchor1Part1 z
  rwa [he,hrep] at ht

def packedOctCertificate142_122_0 : EightPointCertificate 142 122 0 126305 :=
  eightPointCertificateOfPacked 142 122 0 126305 2303472 20 packedOct142_122_0 263 481
    (by decide +kernel) (by decide) packedOct142_122Anchor0
    (by rw [packedOct142_122_0_budget]; decide)

def packedOctCertificate142_122_1 : EightPointCertificate 142 122 1 126305 :=
  eightPointCertificateOfPacked 142 122 1 126305 2303251 20 packedOct142_122_1 264 481
    (by decide +kernel) (by decide) packedOct142_122Anchor1
    (by rw [packedOct142_122_1_budget]; decide)

theorem max148_second142_third122_eightPoint_moment_bound (tail : List ℕ) (len : tail.length=6)
    (distinct : (natSubsetSums (148::142::122::tail)).Nodup) :
    126305 ≤ ((148::142::122::tail).map (· ^ 2)).sum := by
  apply eightPointNatMomentLower 142 122 126305 tail len distinct
  intro p hp
  by_cases h : p=0
  · subst p
    exact packedOctCertificate142_122_0
  · have he : p=1 := hp.resolve_left h
    subst p
    exact packedOctCertificate142_122_1

#print axioms max148_second142_third122_eightPoint_moment_bound

end NineSeparatedSubsetSums
