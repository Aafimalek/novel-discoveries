import NineSeparatedSubsetSums.Adaptive142Third137State
import NineSeparatedSubsetSums.Adaptive142Third137Leaves17
import NineSeparatedSubsetSums.Adaptive142Third137Leaves16
import NineSeparatedSubsetSums.Adaptive142Third137Leaves15
import NineSeparatedSubsetSums.Adaptive142Third137Leaves14
import NineSeparatedSubsetSums.Adaptive142Third137Leaves13
import NineSeparatedSubsetSums.Adaptive142Third137Leaves12
import NineSeparatedSubsetSums.Adaptive142Third137Leaves11
import NineSeparatedSubsetSums.Adaptive142Third137Leaves10
import NineSeparatedSubsetSums.Adaptive142Third137Leaves9
import NineSeparatedSubsetSums.Adaptive142Third137Leaves8
import NineSeparatedSubsetSums.Adaptive142Third137Leaves0
import NineSeparatedSubsetSums.Adaptive142Third137Leaves4
import NineSeparatedSubsetSums.Adaptive142Third137Leaves6
import NineSeparatedSubsetSums.Adaptive142Third137Leaves7
import NineSeparatedSubsetSums.Adaptive142Third137Leaves5
import NineSeparatedSubsetSums.Adaptive142Third137Leaves3
import NineSeparatedSubsetSums.Adaptive142Third137Leaves1
import NineSeparatedSubsetSums.Adaptive142Third137Leaves2

namespace NineSeparatedSubsetSums

theorem adaptive142Third137Proof22 : runCachedNode 511 129593 Adaptive142Third137Node22 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 129593 Adaptive142Third137Node22 = [104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 122, 123, 124, 125, 128, 129, 130] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive142Third137Proof23
  · exact adaptive142Third137Proof24
  · exact adaptive142Third137Proof25
  · exact adaptive142Third137Proof26
  · exact adaptive142Third137Proof27
  · exact adaptive142Third137Proof28
  · exact adaptive142Third137Proof29
  · exact adaptive142Third137Proof30
  · exact adaptive142Third137Proof31
  · exact adaptive142Third137Proof32
  · exact adaptive142Third137Proof33
  · exact adaptive142Third137Proof34
  · exact adaptive142Third137Proof35
  · exact adaptive142Third137Proof36
  · exact adaptive142Third137Proof37
  · exact adaptive142Third137Proof38
  · exact adaptive142Third137Proof39
  · exact adaptive142Third137Proof40
  · exact adaptive142Third137Proof41
  · exact adaptive142Third137Proof42
  · exact adaptive142Third137Proof43
  · exact adaptive142Third137Proof44
  · exact adaptive142Third137Proof45
  · exact adaptive142Third137Proof46

#print axioms adaptive142Third137Proof22

theorem adaptive142Third137Proof47 : runCachedNode 511 129593 Adaptive142Third137Node47 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 129593 Adaptive142Third137Node47 = [104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 123, 124, 125, 126, 129, 130, 132] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive142Third137Proof48
  · exact adaptive142Third137Proof49
  · exact adaptive142Third137Proof50
  · exact adaptive142Third137Proof51
  · exact adaptive142Third137Proof52
  · exact adaptive142Third137Proof53
  · exact adaptive142Third137Proof54
  · exact adaptive142Third137Proof55
  · exact adaptive142Third137Proof56
  · exact adaptive142Third137Proof57
  · exact adaptive142Third137Proof58
  · exact adaptive142Third137Proof59
  · exact adaptive142Third137Proof60
  · exact adaptive142Third137Proof61
  · exact adaptive142Third137Proof62
  · exact adaptive142Third137Proof63
  · exact adaptive142Third137Proof64
  · exact adaptive142Third137Proof65
  · exact adaptive142Third137Proof66
  · exact adaptive142Third137Proof67
  · exact adaptive142Third137Proof68
  · exact adaptive142Third137Proof69
  · exact adaptive142Third137Proof70
  · exact adaptive142Third137Proof71
  · exact adaptive142Third137Proof72

#print axioms adaptive142Third137Proof47

theorem adaptive142Third137Proof73 : runCachedNode 511 129593 Adaptive142Third137Node73 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 129593 Adaptive142Third137Node73 = [103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 124, 125, 126, 127, 130, 132, 133] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive142Third137Proof74
  · exact adaptive142Third137Proof75
  · exact adaptive142Third137Proof76
  · exact adaptive142Third137Proof77
  · exact adaptive142Third137Proof78
  · exact adaptive142Third137Proof79
  · exact adaptive142Third137Proof80
  · exact adaptive142Third137Proof81
  · exact adaptive142Third137Proof82
  · exact adaptive142Third137Proof83
  · exact adaptive142Third137Proof84
  · exact adaptive142Third137Proof85
  · exact adaptive142Third137Proof86
  · exact adaptive142Third137Proof87
  · exact adaptive142Third137Proof88
  · exact adaptive142Third137Proof89
  · exact adaptive142Third137Proof90
  · exact adaptive142Third137Proof91
  · exact adaptive142Third137Proof92
  · exact adaptive142Third137Proof93
  · exact adaptive142Third137Proof94
  · exact adaptive142Third137Proof95
  · exact adaptive142Third137Proof96
  · exact adaptive142Third137Proof97
  · exact adaptive142Third137Proof98
  · exact adaptive142Third137Proof99
  · exact adaptive142Third137Proof100

#print axioms adaptive142Third137Proof73

theorem adaptive142Third137Proof101 : runCachedNode 511 129593 Adaptive142Third137Node101 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 129593 Adaptive142Third137Node101 = [103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 125, 126, 127, 128, 132, 133, 134] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive142Third137Proof102
  · exact adaptive142Third137Proof103
  · exact adaptive142Third137Proof104
  · exact adaptive142Third137Proof105
  · exact adaptive142Third137Proof106
  · exact adaptive142Third137Proof107
  · exact adaptive142Third137Proof108
  · exact adaptive142Third137Proof109
  · exact adaptive142Third137Proof110
  · exact adaptive142Third137Proof111
  · exact adaptive142Third137Proof112
  · exact adaptive142Third137Proof113
  · exact adaptive142Third137Proof114
  · exact adaptive142Third137Proof115
  · exact adaptive142Third137Proof116
  · exact adaptive142Third137Proof117
  · exact adaptive142Third137Proof118
  · exact adaptive142Third137Proof119
  · exact adaptive142Third137Proof120
  · exact adaptive142Third137Proof121
  · exact adaptive142Third137Proof122
  · exact adaptive142Third137Proof123
  · exact adaptive142Third137Proof124
  · exact adaptive142Third137Proof125
  · exact adaptive142Third137Proof126
  · exact adaptive142Third137Proof127
  · exact adaptive142Third137Proof128
  · exact adaptive142Third137Proof129

#print axioms adaptive142Third137Proof101

theorem adaptive142Third137Proof160 : runCachedNode 511 129593 Adaptive142Third137Node160 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 129593 Adaptive142Third137Node160 = [91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 119, 120, 121, 122, 126, 127, 133] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive142Third137Proof161
  · exact adaptive142Third137Proof162
  · exact adaptive142Third137Proof163
  · exact adaptive142Third137Proof164
  · exact adaptive142Third137Proof165
  · exact adaptive142Third137Proof166
  · exact adaptive142Third137Proof167
  · exact adaptive142Third137Proof168
  · exact adaptive142Third137Proof169
  · exact adaptive142Third137Proof170
  · exact adaptive142Third137Proof171
  · exact adaptive142Third137Proof172
  · exact adaptive142Third137Proof173
  · exact adaptive142Third137Proof174
  · exact adaptive142Third137Proof175
  · exact adaptive142Third137Proof176
  · exact adaptive142Third137Proof177
  · exact adaptive142Third137Proof178
  · exact adaptive142Third137Proof179
  · exact adaptive142Third137Proof180
  · exact adaptive142Third137Proof181
  · exact adaptive142Third137Proof182
  · exact adaptive142Third137Proof183
  · exact adaptive142Third137Proof184
  · exact adaptive142Third137Proof185
  · exact adaptive142Third137Proof186
  · exact adaptive142Third137Proof187
  · exact adaptive142Third137Proof188
  · exact adaptive142Third137Proof189
  · exact adaptive142Third137Proof190
  · exact adaptive142Third137Proof191
  · exact adaptive142Third137Proof192
  · exact adaptive142Third137Proof193
  · exact adaptive142Third137Proof194

#print axioms adaptive142Third137Proof160

theorem adaptive142Third137Proof130 : runCachedNode 511 129593 Adaptive142Third137Node130 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 129593 Adaptive142Third137Node130 = [103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 126, 127, 128, 129, 132, 133, 134, 135] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive142Third137Proof131
  · exact adaptive142Third137Proof132
  · exact adaptive142Third137Proof133
  · exact adaptive142Third137Proof134
  · exact adaptive142Third137Proof135
  · exact adaptive142Third137Proof136
  · exact adaptive142Third137Proof137
  · exact adaptive142Third137Proof138
  · exact adaptive142Third137Proof139
  · exact adaptive142Third137Proof140
  · exact adaptive142Third137Proof141
  · exact adaptive142Third137Proof142
  · exact adaptive142Third137Proof143
  · exact adaptive142Third137Proof144
  · exact adaptive142Third137Proof145
  · exact adaptive142Third137Proof146
  · exact adaptive142Third137Proof147
  · exact adaptive142Third137Proof148
  · exact adaptive142Third137Proof149
  · exact adaptive142Third137Proof150
  · exact adaptive142Third137Proof151
  · exact adaptive142Third137Proof152
  · exact adaptive142Third137Proof153
  · exact adaptive142Third137Proof154
  · exact adaptive142Third137Proof155
  · exact adaptive142Third137Proof156
  · exact adaptive142Third137Proof157
  · exact adaptive142Third137Proof158
  · exact adaptive142Third137Proof159
  · exact adaptive142Third137Proof160

#print axioms adaptive142Third137Proof130

theorem adaptive142Third137Proof0 : runCachedNode 511 129593 Adaptive142Third137Node0 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 129593 Adaptive142Third137Node0 = [110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 132, 133, 134, 135, 136] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive142Third137Proof1
  · exact adaptive142Third137Proof2
  · exact adaptive142Third137Proof3
  · exact adaptive142Third137Proof4
  · exact adaptive142Third137Proof5
  · exact adaptive142Third137Proof6
  · exact adaptive142Third137Proof7
  · exact adaptive142Third137Proof8
  · exact adaptive142Third137Proof9
  · exact adaptive142Third137Proof10
  · exact adaptive142Third137Proof11
  · exact adaptive142Third137Proof12
  · exact adaptive142Third137Proof13
  · exact adaptive142Third137Proof14
  · exact adaptive142Third137Proof15
  · exact adaptive142Third137Proof16
  · exact adaptive142Third137Proof17
  · exact adaptive142Third137Proof18
  · exact adaptive142Third137Proof19
  · exact adaptive142Third137Proof20
  · exact adaptive142Third137Proof21
  · exact adaptive142Third137Proof22
  · exact adaptive142Third137Proof47
  · exact adaptive142Third137Proof73
  · exact adaptive142Third137Proof101
  · exact adaptive142Third137Proof130

#print axioms adaptive142Third137Proof0

end NineSeparatedSubsetSums
