import NineSeparatedSubsetSums.Adaptive142Third141State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third141Proof310 : runCachedNode 511 130276 Adaptive142Third141Node310 = false := by
  decide +kernel

#print axioms adaptive142Third141Proof310

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third141Proof173 : runCachedNode 511 130276 Adaptive142Third141Node173 = false := by
  decide +kernel

#print axioms adaptive142Third141Proof173

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third141Proof25 : runCachedNode 511 130276 Adaptive142Third141Node25 = false := by
  decide +kernel

#print axioms adaptive142Third141Proof25

end NineSeparatedSubsetSums
