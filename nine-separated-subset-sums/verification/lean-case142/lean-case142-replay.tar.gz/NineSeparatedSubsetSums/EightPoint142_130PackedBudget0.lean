import NineSeparatedSubsetSums.EightPoint142_130PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct142_130_0_budget :
    FourPointNumeric.packedBudget 20 packedOct142_130_0 445 = 88602997 := by decide +kernel

#print axioms packedOct142_130_0_budget

end NineSeparatedSubsetSums
