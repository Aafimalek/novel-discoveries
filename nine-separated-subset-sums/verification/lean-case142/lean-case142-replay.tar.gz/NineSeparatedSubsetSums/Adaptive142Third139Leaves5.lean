import NineSeparatedSubsetSums.Adaptive142Third139State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third139Proof108 : runCachedNode 511 129933 Adaptive142Third139Node108 = false := by
  decide +kernel

#print axioms adaptive142Third139Proof108

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third139Proof16 : runCachedNode 511 129933 Adaptive142Third139Node16 = false := by
  decide +kernel

#print axioms adaptive142Third139Proof16

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third139Proof1 : runCachedNode 511 129933 Adaptive142Third139Node1 = false := by
  decide +kernel

#print axioms adaptive142Third139Proof1

end NineSeparatedSubsetSums
