import NineSeparatedSubsetSums.Adaptive142Third139State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third139Proof205 : runCachedNode 511 129933 Adaptive142Third139Node205 = false := by
  decide +kernel

#print axioms adaptive142Third139Proof205

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third139Proof75 : runCachedNode 511 129933 Adaptive142Third139Node75 = false := by
  decide +kernel

#print axioms adaptive142Third139Proof75

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third139Proof316 : runCachedNode 511 129933 Adaptive142Third139Node316 = false := by
  decide +kernel

#print axioms adaptive142Third139Proof316

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third139Proof274 : runCachedNode 511 129933 Adaptive142Third139Node274 = false := by
  decide +kernel

#print axioms adaptive142Third139Proof274

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third139Proof141 : runCachedNode 511 129933 Adaptive142Third139Node141 = false := by
  decide +kernel

#print axioms adaptive142Third139Proof141

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third139Proof177 : runCachedNode 511 129933 Adaptive142Third139Node177 = false := by
  decide +kernel

#print axioms adaptive142Third139Proof177

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third139Proof73 : runCachedNode 511 129933 Adaptive142Third139Node73 = false := by
  decide +kernel

#print axioms adaptive142Third139Proof73

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third139Proof246 : runCachedNode 511 129933 Adaptive142Third139Node246 = false := by
  decide +kernel

#print axioms adaptive142Third139Proof246

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third139Proof203 : runCachedNode 511 129933 Adaptive142Third139Node203 = false := by
  decide +kernel

#print axioms adaptive142Third139Proof203

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third139Proof315 : runCachedNode 511 129933 Adaptive142Third139Node315 = false := by
  decide +kernel

#print axioms adaptive142Third139Proof315

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third139Proof44 : runCachedNode 511 129933 Adaptive142Third139Node44 = false := by
  decide +kernel

#print axioms adaptive142Third139Proof44

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third139Proof10 : runCachedNode 511 129933 Adaptive142Third139Node10 = false := by
  decide +kernel

#print axioms adaptive142Third139Proof10

end NineSeparatedSubsetSums
