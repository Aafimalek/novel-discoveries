import NineSeparatedSubsetSums.Adaptive142Third141State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third141Proof169 : runCachedNode 511 130276 Adaptive142Third141Node169 = false := by
  decide +kernel

#print axioms adaptive142Third141Proof169

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third141Proof330 : runCachedNode 511 130276 Adaptive142Third141Node330 = false := by
  decide +kernel

#print axioms adaptive142Third141Proof330

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third141Proof329 : runCachedNode 511 130276 Adaptive142Third141Node329 = false := by
  decide +kernel

#print axioms adaptive142Third141Proof329

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third141Proof10 : runCachedNode 511 130276 Adaptive142Third141Node10 = false := by
  decide +kernel

#print axioms adaptive142Third141Proof10

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third141Proof303 : runCachedNode 511 130276 Adaptive142Third141Node303 = false := by
  decide +kernel

#print axioms adaptive142Third141Proof303

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third141Proof225 : runCachedNode 511 130276 Adaptive142Third141Node225 = false := by
  decide +kernel

#print axioms adaptive142Third141Proof225

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third141Proof299 : runCachedNode 511 130276 Adaptive142Third141Node299 = false := by
  decide +kernel

#print axioms adaptive142Third141Proof299

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third141Proof328 : runCachedNode 511 130276 Adaptive142Third141Node328 = false := by
  decide +kernel

#print axioms adaptive142Third141Proof328

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third141Proof379 : runCachedNode 511 130276 Adaptive142Third141Node379 = false := by
  decide +kernel

#print axioms adaptive142Third141Proof379

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third141Proof300 : runCachedNode 511 130276 Adaptive142Third141Node300 = false := by
  decide +kernel

#print axioms adaptive142Third141Proof300

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third141Proof123 : runCachedNode 511 130276 Adaptive142Third141Node123 = false := by
  decide +kernel

#print axioms adaptive142Third141Proof123

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third141Proof419 : runCachedNode 511 130276 Adaptive142Third141Node419 = false := by
  decide +kernel

#print axioms adaptive142Third141Proof419

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third141Proof196 : runCachedNode 511 130276 Adaptive142Third141Node196 = false := by
  decide +kernel

#print axioms adaptive142Third141Proof196

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third141Proof272 : runCachedNode 511 130276 Adaptive142Third141Node272 = false := by
  decide +kernel

#print axioms adaptive142Third141Proof272

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third141Proof71 : runCachedNode 511 130276 Adaptive142Third141Node71 = false := by
  decide +kernel

#print axioms adaptive142Third141Proof71

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third141Proof94 : runCachedNode 511 130276 Adaptive142Third141Node94 = false := by
  decide +kernel

#print axioms adaptive142Third141Proof94

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third141Proof42 : runCachedNode 511 130276 Adaptive142Third141Node42 = false := by
  decide +kernel

#print axioms adaptive142Third141Proof42

end NineSeparatedSubsetSums
