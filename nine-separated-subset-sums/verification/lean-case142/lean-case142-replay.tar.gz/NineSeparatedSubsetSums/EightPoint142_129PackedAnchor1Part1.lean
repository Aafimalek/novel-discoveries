import NineSeparatedSubsetSums.EightPoint142_129PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint142_129PackedAnchor1Part1 :
    ∀ j : Fin 120, 2390309 ≤ FourPointNumeric.octPackedCharge 142 129 20 packedOct142_129_1
      (2*((j.val : Int)+120)+0) := by decide +kernel

end NineSeparatedSubsetSums
