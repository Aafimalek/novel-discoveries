import NineSeparatedSubsetSums.EightPoint142_126PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint142_126PackedAnchor1Part2 :
    ∀ j : Fin 4, 2364587 ≤ FourPointNumeric.octPackedCharge 142 126 20 packedOct142_126_1
      (2*((j.val : Int)+240)+1) := by decide +kernel

end NineSeparatedSubsetSums
