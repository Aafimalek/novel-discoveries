import NineSeparatedSubsetSums.EightPoint142_131PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct142_131_0_budget :
    FourPointNumeric.packedBudget 20 packedOct142_131_0 393 = 89752957 := by decide +kernel

#print axioms packedOct142_131_0_budget

end NineSeparatedSubsetSums
