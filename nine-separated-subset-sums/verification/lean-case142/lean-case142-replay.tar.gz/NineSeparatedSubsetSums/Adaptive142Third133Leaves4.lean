import NineSeparatedSubsetSums.Adaptive142Third133State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third133Proof13 : runCachedNode 511 128920 Adaptive142Third133Node13 = false := by
  decide +kernel

#print axioms adaptive142Third133Proof13

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third133Proof45 : runCachedNode 511 128920 Adaptive142Third133Node45 = false := by
  decide +kernel

#print axioms adaptive142Third133Proof45

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third133Proof12 : runCachedNode 511 128920 Adaptive142Third133Node12 = false := by
  decide +kernel

#print axioms adaptive142Third133Proof12

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third133Proof41 : runCachedNode 511 128920 Adaptive142Third133Node41 = false := by
  decide +kernel

#print axioms adaptive142Third133Proof41

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third133Proof11 : runCachedNode 511 128920 Adaptive142Third133Node11 = false := by
  decide +kernel

#print axioms adaptive142Third133Proof11

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third133Proof10 : runCachedNode 511 128920 Adaptive142Third133Node10 = false := by
  decide +kernel

#print axioms adaptive142Third133Proof10

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third133Proof40 : runCachedNode 511 128920 Adaptive142Third133Node40 = false := by
  decide +kernel

#print axioms adaptive142Third133Proof40

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third133Proof42 : runCachedNode 511 128920 Adaptive142Third133Node42 = false := by
  decide +kernel

#print axioms adaptive142Third133Proof42

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third133Proof8 : runCachedNode 511 128920 Adaptive142Third133Node8 = false := by
  decide +kernel

#print axioms adaptive142Third133Proof8

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third133Proof38 : runCachedNode 511 128920 Adaptive142Third133Node38 = false := by
  decide +kernel

#print axioms adaptive142Third133Proof38

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third133Proof36 : runCachedNode 511 128920 Adaptive142Third133Node36 = false := by
  decide +kernel

#print axioms adaptive142Third133Proof36

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third133Proof39 : runCachedNode 511 128920 Adaptive142Third133Node39 = false := by
  decide +kernel

#print axioms adaptive142Third133Proof39

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third133Proof6 : runCachedNode 511 128920 Adaptive142Third133Node6 = false := by
  decide +kernel

#print axioms adaptive142Third133Proof6

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third133Proof35 : runCachedNode 511 128920 Adaptive142Third133Node35 = false := by
  decide +kernel

#print axioms adaptive142Third133Proof35

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third133Proof37 : runCachedNode 511 128920 Adaptive142Third133Node37 = false := by
  decide +kernel

#print axioms adaptive142Third133Proof37

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third133Proof5 : runCachedNode 511 128920 Adaptive142Third133Node5 = false := by
  decide +kernel

#print axioms adaptive142Third133Proof5

end NineSeparatedSubsetSums
