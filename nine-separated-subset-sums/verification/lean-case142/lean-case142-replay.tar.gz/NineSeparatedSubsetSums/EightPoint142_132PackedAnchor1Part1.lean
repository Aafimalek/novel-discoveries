import NineSeparatedSubsetSums.EightPoint142_132PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint142_132PackedAnchor1Part1 :
    ∀ j : Fin 120, 2444111 ≤ FourPointNumeric.octPackedCharge 142 132 20 packedOct142_132_1
      (2*((j.val : Int)+120)+1) := by decide +kernel

end NineSeparatedSubsetSums
