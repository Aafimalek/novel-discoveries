import NineSeparatedSubsetSums.Adaptive142Third140State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third140Proof21 : runCachedNode 511 130107 Adaptive142Third140Node21 = false := by
  decide +kernel

#print axioms adaptive142Third140Proof21

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third140Proof103 : runCachedNode 511 130107 Adaptive142Third140Node103 = false := by
  decide +kernel

#print axioms adaptive142Third140Proof103

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third140Proof159 : runCachedNode 511 130107 Adaptive142Third140Node159 = false := by
  decide +kernel

#print axioms adaptive142Third140Proof159

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third140Proof79 : runCachedNode 511 130107 Adaptive142Third140Node79 = false := by
  decide +kernel

#print axioms adaptive142Third140Proof79

end NineSeparatedSubsetSums
