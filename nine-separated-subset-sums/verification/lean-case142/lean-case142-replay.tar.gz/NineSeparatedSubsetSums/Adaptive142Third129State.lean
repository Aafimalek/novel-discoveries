import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive142Third129Node0 : CachedSearchNode :=
  ⟨4, 128, computeCenteredMask [148,142,129], 419, 58709⟩
def Adaptive142Third129Node1 : CachedSearchNode := cachedChild Adaptive142Third129Node0 111
def Adaptive142Third129Node2 : CachedSearchNode := cachedChild Adaptive142Third129Node0 112
def Adaptive142Third129Node3 : CachedSearchNode := cachedChild Adaptive142Third129Node0 113
def Adaptive142Third129Node4 : CachedSearchNode := cachedChild Adaptive142Third129Node0 114
def Adaptive142Third129Node5 : CachedSearchNode := cachedChild Adaptive142Third129Node0 115
def Adaptive142Third129Node6 : CachedSearchNode := cachedChild Adaptive142Third129Node0 116
def Adaptive142Third129Node7 : CachedSearchNode := cachedChild Adaptive142Third129Node0 117
def Adaptive142Third129Node8 : CachedSearchNode := cachedChild Adaptive142Third129Node0 118
def Adaptive142Third129Node9 : CachedSearchNode := cachedChild Adaptive142Third129Node0 119
def Adaptive142Third129Node10 : CachedSearchNode := cachedChild Adaptive142Third129Node0 120
def Adaptive142Third129Node11 : CachedSearchNode := cachedChild Adaptive142Third129Node0 121
def Adaptive142Third129Node12 : CachedSearchNode := cachedChild Adaptive142Third129Node0 122
def Adaptive142Third129Node13 : CachedSearchNode := cachedChild Adaptive142Third129Node0 124
def Adaptive142Third129Node14 : CachedSearchNode := cachedChild Adaptive142Third129Node0 125
def Adaptive142Third129Node15 : CachedSearchNode := cachedChild Adaptive142Third129Node0 126
def Adaptive142Third129Node16 : CachedSearchNode := cachedChild Adaptive142Third129Node0 127
def Adaptive142Third129Node17 : CachedSearchNode := cachedChild Adaptive142Third129Node0 128

end NineSeparatedSubsetSums
