import NineSeparatedSubsetSums.Adaptive142Third139State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third139Proof21 : runCachedNode 511 129933 Adaptive142Third139Node21 = false := by
  decide +kernel

#print axioms adaptive142Third139Proof21

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third139Proof275 : runCachedNode 511 129933 Adaptive142Third139Node275 = false := by
  decide +kernel

#print axioms adaptive142Third139Proof275

end NineSeparatedSubsetSums
