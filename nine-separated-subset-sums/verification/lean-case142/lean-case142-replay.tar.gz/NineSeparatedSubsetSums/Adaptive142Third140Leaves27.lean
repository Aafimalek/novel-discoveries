import NineSeparatedSubsetSums.Adaptive142Third140State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third140Proof222 : runCachedNode 511 130107 Adaptive142Third140Node222 = false := by
  decide +kernel

#print axioms adaptive142Third140Proof222

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third140Proof100 : runCachedNode 511 130107 Adaptive142Third140Node100 = false := by
  decide +kernel

#print axioms adaptive142Third140Proof100

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third140Proof160 : runCachedNode 511 130107 Adaptive142Third140Node160 = false := by
  decide +kernel

#print axioms adaptive142Third140Proof160

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third140Proof304 : runCachedNode 511 130107 Adaptive142Third140Node304 = false := by
  decide +kernel

#print axioms adaptive142Third140Proof304

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third140Proof260 : runCachedNode 511 130107 Adaptive142Third140Node260 = false := by
  decide +kernel

#print axioms adaptive142Third140Proof260

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third140Proof221 : runCachedNode 511 130107 Adaptive142Third140Node221 = false := by
  decide +kernel

#print axioms adaptive142Third140Proof221

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third140Proof263 : runCachedNode 511 130107 Adaptive142Third140Node263 = false := by
  decide +kernel

#print axioms adaptive142Third140Proof263

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third140Proof155 : runCachedNode 511 130107 Adaptive142Third140Node155 = false := by
  decide +kernel

#print axioms adaptive142Third140Proof155

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third140Proof37 : runCachedNode 511 130107 Adaptive142Third140Node37 = false := by
  decide +kernel

#print axioms adaptive142Third140Proof37

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third140Proof259 : runCachedNode 511 130107 Adaptive142Third140Node259 = false := by
  decide +kernel

#print axioms adaptive142Third140Proof259

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third140Proof192 : runCachedNode 511 130107 Adaptive142Third140Node192 = false := by
  decide +kernel

#print axioms adaptive142Third140Proof192

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third140Proof191 : runCachedNode 511 130107 Adaptive142Third140Node191 = false := by
  decide +kernel

#print axioms adaptive142Third140Proof191

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third140Proof220 : runCachedNode 511 130107 Adaptive142Third140Node220 = false := by
  decide +kernel

#print axioms adaptive142Third140Proof220

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third140Proof99 : runCachedNode 511 130107 Adaptive142Third140Node99 = false := by
  decide +kernel

#print axioms adaptive142Third140Proof99

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third140Proof70 : runCachedNode 511 130107 Adaptive142Third140Node70 = false := by
  decide +kernel

#print axioms adaptive142Third140Proof70

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third140Proof124 : runCachedNode 511 130107 Adaptive142Third140Node124 = false := by
  decide +kernel

#print axioms adaptive142Third140Proof124

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third140Proof29 : runCachedNode 511 130107 Adaptive142Third140Node29 = false := by
  decide +kernel

#print axioms adaptive142Third140Proof29

end NineSeparatedSubsetSums
