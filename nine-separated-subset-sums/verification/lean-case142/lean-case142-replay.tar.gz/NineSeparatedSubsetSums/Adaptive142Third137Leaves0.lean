import NineSeparatedSubsetSums.Adaptive142Third137State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third137Proof157 : runCachedNode 511 129593 Adaptive142Third137Node157 = false := by
  decide +kernel

#print axioms adaptive142Third137Proof157

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third137Proof13 : runCachedNode 511 129593 Adaptive142Third137Node13 = false := by
  decide +kernel

#print axioms adaptive142Third137Proof13

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third137Proof48 : runCachedNode 511 129593 Adaptive142Third137Node48 = false := by
  decide +kernel

#print axioms adaptive142Third137Proof48

end NineSeparatedSubsetSums
