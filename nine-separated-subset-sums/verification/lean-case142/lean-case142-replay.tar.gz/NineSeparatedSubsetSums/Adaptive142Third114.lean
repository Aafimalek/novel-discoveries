import NineSeparatedSubsetSums.Adaptive142Third114Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint142Checked

namespace NineSeparatedSubsetSums


theorem adaptive142Third114 : NoDescendingTailAfterThird 142 114 :=
  noDescendingThirdTail_of_cached 142 114 111874 (fun t ht nd => max148_second142_fourPoint_moment_bound (114::t) (by simp [ht]) nd) adaptive142Third114Proof0

#print axioms adaptive142Third114

end NineSeparatedSubsetSums
