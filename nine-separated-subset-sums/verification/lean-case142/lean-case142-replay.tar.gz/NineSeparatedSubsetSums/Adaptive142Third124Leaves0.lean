import NineSeparatedSubsetSums.Adaptive142Third124State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third124Proof0 : runCachedNode 511 126810 Adaptive142Third124Node0 = false := by
  decide +kernel

#print axioms adaptive142Third124Proof0

end NineSeparatedSubsetSums
