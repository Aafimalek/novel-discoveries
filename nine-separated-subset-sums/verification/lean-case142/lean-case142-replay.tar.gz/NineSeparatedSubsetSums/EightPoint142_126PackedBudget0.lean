import NineSeparatedSubsetSums.EightPoint142_126PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct142_126_0_budget :
    FourPointNumeric.packedBudget 20 packedOct142_126_0 479 = 86102202 := by decide +kernel

#print axioms packedOct142_126_0_budget

end NineSeparatedSubsetSums
