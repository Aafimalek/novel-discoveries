import NineSeparatedSubsetSums.Adaptive142Third106State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third106Proof0 : runCachedNode 511 111874 Adaptive142Third106Node0 = false := by
  decide +kernel

#print axioms adaptive142Third106Proof0

end NineSeparatedSubsetSums
