import NineSeparatedSubsetSums.Adaptive142Third137State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third137Proof17 : runCachedNode 511 129593 Adaptive142Third137Node17 = false := by
  decide +kernel

#print axioms adaptive142Third137Proof17

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third137Proof155 : runCachedNode 511 129593 Adaptive142Third137Node155 = false := by
  decide +kernel

#print axioms adaptive142Third137Proof155

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third137Proof46 : runCachedNode 511 129593 Adaptive142Third137Node46 = false := by
  decide +kernel

#print axioms adaptive142Third137Proof46

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third137Proof57 : runCachedNode 511 129593 Adaptive142Third137Node57 = false := by
  decide +kernel

#print axioms adaptive142Third137Proof57

end NineSeparatedSubsetSums
