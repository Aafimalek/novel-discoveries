import NineSeparatedSubsetSums.Adaptive142Third138State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third138Proof75 : runCachedNode 511 129778 Adaptive142Third138Node75 = false := by
  decide +kernel

#print axioms adaptive142Third138Proof75

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third138Proof201 : runCachedNode 511 129778 Adaptive142Third138Node201 = false := by
  decide +kernel

#print axioms adaptive142Third138Proof201

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third138Proof167 : runCachedNode 511 129778 Adaptive142Third138Node167 = false := by
  decide +kernel

#print axioms adaptive142Third138Proof167

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third138Proof198 : runCachedNode 511 129778 Adaptive142Third138Node198 = false := by
  decide +kernel

#print axioms adaptive142Third138Proof198

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third138Proof38 : runCachedNode 511 129778 Adaptive142Third138Node38 = false := by
  decide +kernel

#print axioms adaptive142Third138Proof38

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third138Proof24 : runCachedNode 511 129778 Adaptive142Third138Node24 = false := by
  decide +kernel

#print axioms adaptive142Third138Proof24

end NineSeparatedSubsetSums
