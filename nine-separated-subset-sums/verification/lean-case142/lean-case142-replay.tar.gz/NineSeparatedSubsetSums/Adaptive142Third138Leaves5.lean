import NineSeparatedSubsetSums.Adaptive142Third138State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third138Proof132 : runCachedNode 511 129778 Adaptive142Third138Node132 = false := by
  decide +kernel

#print axioms adaptive142Third138Proof132

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third138Proof134 : runCachedNode 511 129778 Adaptive142Third138Node134 = false := by
  decide +kernel

#print axioms adaptive142Third138Proof134

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third138Proof189 : runCachedNode 511 129778 Adaptive142Third138Node189 = false := by
  decide +kernel

#print axioms adaptive142Third138Proof189

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third138Proof1 : runCachedNode 511 129778 Adaptive142Third138Node1 = false := by
  decide +kernel

#print axioms adaptive142Third138Proof1

end NineSeparatedSubsetSums
