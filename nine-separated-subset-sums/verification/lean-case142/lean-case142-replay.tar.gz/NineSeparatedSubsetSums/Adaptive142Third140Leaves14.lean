import NineSeparatedSubsetSums.Adaptive142Third140State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third140Proof170 : runCachedNode 511 130107 Adaptive142Third140Node170 = false := by
  decide +kernel

#print axioms adaptive142Third140Proof170

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third140Proof18 : runCachedNode 511 130107 Adaptive142Third140Node18 = false := by
  decide +kernel

#print axioms adaptive142Third140Proof18

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third140Proof35 : runCachedNode 511 130107 Adaptive142Third140Node35 = false := by
  decide +kernel

#print axioms adaptive142Third140Proof35

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third140Proof1 : runCachedNode 511 130107 Adaptive142Third140Node1 = false := by
  decide +kernel

#print axioms adaptive142Third140Proof1

end NineSeparatedSubsetSums
