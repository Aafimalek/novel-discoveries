import NineSeparatedSubsetSums.Adaptive142Third141State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third141Proof134 : runCachedNode 511 130276 Adaptive142Third141Node134 = false := by
  decide +kernel

#print axioms adaptive142Third141Proof134

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third141Proof103 : runCachedNode 511 130276 Adaptive142Third141Node103 = false := by
  decide +kernel

#print axioms adaptive142Third141Proof103

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third141Proof132 : runCachedNode 511 130276 Adaptive142Third141Node132 = false := by
  decide +kernel

#print axioms adaptive142Third141Proof132

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third141Proof52 : runCachedNode 511 130276 Adaptive142Third141Node52 = false := by
  decide +kernel

#print axioms adaptive142Third141Proof52

end NineSeparatedSubsetSums
