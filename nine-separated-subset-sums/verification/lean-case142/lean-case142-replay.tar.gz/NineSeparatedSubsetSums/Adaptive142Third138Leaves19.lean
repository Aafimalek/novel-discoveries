import NineSeparatedSubsetSums.Adaptive142Third138State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third138Proof100 : runCachedNode 511 129778 Adaptive142Third138Node100 = false := by
  decide +kernel

#print axioms adaptive142Third138Proof100

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third138Proof155 : runCachedNode 511 129778 Adaptive142Third138Node155 = false := by
  decide +kernel

#print axioms adaptive142Third138Proof155

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third138Proof196 : runCachedNode 511 129778 Adaptive142Third138Node196 = false := by
  decide +kernel

#print axioms adaptive142Third138Proof196

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third138Proof44 : runCachedNode 511 129778 Adaptive142Third138Node44 = false := by
  decide +kernel

#print axioms adaptive142Third138Proof44

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third138Proof126 : runCachedNode 511 129778 Adaptive142Third138Node126 = false := by
  decide +kernel

#print axioms adaptive142Third138Proof126

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third138Proof237 : runCachedNode 511 129778 Adaptive142Third138Node237 = false := by
  decide +kernel

#print axioms adaptive142Third138Proof237

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third138Proof97 : runCachedNode 511 129778 Adaptive142Third138Node97 = false := by
  decide +kernel

#print axioms adaptive142Third138Proof97

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third138Proof69 : runCachedNode 511 129778 Adaptive142Third138Node69 = false := by
  decide +kernel

#print axioms adaptive142Third138Proof69

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third138Proof193 : runCachedNode 511 129778 Adaptive142Third138Node193 = false := by
  decide +kernel

#print axioms adaptive142Third138Proof193

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third138Proof158 : runCachedNode 511 129778 Adaptive142Third138Node158 = false := by
  decide +kernel

#print axioms adaptive142Third138Proof158

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third138Proof43 : runCachedNode 511 129778 Adaptive142Third138Node43 = false := by
  decide +kernel

#print axioms adaptive142Third138Proof43

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third138Proof96 : runCachedNode 511 129778 Adaptive142Third138Node96 = false := by
  decide +kernel

#print axioms adaptive142Third138Proof96

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third138Proof95 : runCachedNode 511 129778 Adaptive142Third138Node95 = false := by
  decide +kernel

#print axioms adaptive142Third138Proof95

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third138Proof153 : runCachedNode 511 129778 Adaptive142Third138Node153 = false := by
  decide +kernel

#print axioms adaptive142Third138Proof153

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third138Proof124 : runCachedNode 511 129778 Adaptive142Third138Node124 = false := by
  decide +kernel

#print axioms adaptive142Third138Proof124

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third138Proof31 : runCachedNode 511 129778 Adaptive142Third138Node31 = false := by
  decide +kernel

#print axioms adaptive142Third138Proof31

end NineSeparatedSubsetSums
