import NineSeparatedSubsetSums.Adaptive142Third140State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third140Proof202 : runCachedNode 511 130107 Adaptive142Third140Node202 = false := by
  decide +kernel

#print axioms adaptive142Third140Proof202

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third140Proof230 : runCachedNode 511 130107 Adaptive142Third140Node230 = false := by
  decide +kernel

#print axioms adaptive142Third140Proof230

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third140Proof196 : runCachedNode 511 130107 Adaptive142Third140Node196 = false := by
  decide +kernel

#print axioms adaptive142Third140Proof196

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third140Proof52 : runCachedNode 511 130107 Adaptive142Third140Node52 = false := by
  decide +kernel

#print axioms adaptive142Third140Proof52

end NineSeparatedSubsetSums
