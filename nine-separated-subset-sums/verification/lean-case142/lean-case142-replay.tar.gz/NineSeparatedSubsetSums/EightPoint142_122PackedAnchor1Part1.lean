import NineSeparatedSubsetSums.EightPoint142_122PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint142_122PackedAnchor1Part1 :
    ∀ j : Fin 120, 2303251 ≤ FourPointNumeric.octPackedCharge 142 122 20 packedOct142_122_1
      (2*((j.val : Int)+120)+1) := by decide +kernel

end NineSeparatedSubsetSums
