import NineSeparatedSubsetSums.Adaptive142Third139State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third139Proof51 : runCachedNode 511 129933 Adaptive142Third139Node51 = false := by
  decide +kernel

#print axioms adaptive142Third139Proof51

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third139Proof102 : runCachedNode 511 129933 Adaptive142Third139Node102 = false := by
  decide +kernel

#print axioms adaptive142Third139Proof102

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third139Proof101 : runCachedNode 511 129933 Adaptive142Third139Node101 = false := by
  decide +kernel

#print axioms adaptive142Third139Proof101

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third139Proof279 : runCachedNode 511 129933 Adaptive142Third139Node279 = false := by
  decide +kernel

#print axioms adaptive142Third139Proof279

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third139Proof61 : runCachedNode 511 129933 Adaptive142Third139Node61 = false := by
  decide +kernel

#print axioms adaptive142Third139Proof61

end NineSeparatedSubsetSums
