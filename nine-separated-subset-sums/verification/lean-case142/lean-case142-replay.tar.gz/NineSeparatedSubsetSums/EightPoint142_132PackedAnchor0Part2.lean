import NineSeparatedSubsetSums.EightPoint142_132PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint142_132PackedAnchor0Part2 :
    ∀ j : Fin 9, 2442280 ≤ FourPointNumeric.octPackedCharge 142 132 20 packedOct142_132_0
      (2*((j.val : Int)+240)+0) := by decide +kernel

end NineSeparatedSubsetSums
