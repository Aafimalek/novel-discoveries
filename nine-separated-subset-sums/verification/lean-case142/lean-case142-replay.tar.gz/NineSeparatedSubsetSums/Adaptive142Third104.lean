import NineSeparatedSubsetSums.Adaptive142Third104Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint142Checked

namespace NineSeparatedSubsetSums


theorem adaptive142Third104 : NoDescendingTailAfterThird 142 104 :=
  noDescendingThirdTail_of_cached 142 104 111874 (fun t ht nd => max148_second142_fourPoint_moment_bound (104::t) (by simp [ht]) nd) adaptive142Third104Proof0

#print axioms adaptive142Third104

end NineSeparatedSubsetSums
