import NineSeparatedSubsetSums.Adaptive142Third139State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third139Proof218 : runCachedNode 511 129933 Adaptive142Third139Node218 = false := by
  decide +kernel

#print axioms adaptive142Third139Proof218

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third139Proof219 : runCachedNode 511 129933 Adaptive142Third139Node219 = false := by
  decide +kernel

#print axioms adaptive142Third139Proof219

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third139Proof220 : runCachedNode 511 129933 Adaptive142Third139Node220 = false := by
  decide +kernel

#print axioms adaptive142Third139Proof220

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third139Proof221 : runCachedNode 511 129933 Adaptive142Third139Node221 = false := by
  decide +kernel

#print axioms adaptive142Third139Proof221

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third139Proof251 : runCachedNode 511 129933 Adaptive142Third139Node251 = false := by
  decide +kernel

#print axioms adaptive142Third139Proof251

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third139Proof282 : runCachedNode 511 129933 Adaptive142Third139Node282 = false := by
  decide +kernel

#print axioms adaptive142Third139Proof282

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third139Proof283 : runCachedNode 511 129933 Adaptive142Third139Node283 = false := by
  decide +kernel

#print axioms adaptive142Third139Proof283

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third139Proof284 : runCachedNode 511 129933 Adaptive142Third139Node284 = false := by
  decide +kernel

#print axioms adaptive142Third139Proof284

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third139Proof285 : runCachedNode 511 129933 Adaptive142Third139Node285 = false := by
  decide +kernel

#print axioms adaptive142Third139Proof285

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third139Proof286 : runCachedNode 511 129933 Adaptive142Third139Node286 = false := by
  decide +kernel

#print axioms adaptive142Third139Proof286

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third139Proof287 : runCachedNode 511 129933 Adaptive142Third139Node287 = false := by
  decide +kernel

#print axioms adaptive142Third139Proof287

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third139Proof288 : runCachedNode 511 129933 Adaptive142Third139Node288 = false := by
  decide +kernel

#print axioms adaptive142Third139Proof288

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third139Proof289 : runCachedNode 511 129933 Adaptive142Third139Node289 = false := by
  decide +kernel

#print axioms adaptive142Third139Proof289

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third139Proof290 : runCachedNode 511 129933 Adaptive142Third139Node290 = false := by
  decide +kernel

#print axioms adaptive142Third139Proof290

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third139Proof291 : runCachedNode 511 129933 Adaptive142Third139Node291 = false := by
  decide +kernel

#print axioms adaptive142Third139Proof291

end NineSeparatedSubsetSums
