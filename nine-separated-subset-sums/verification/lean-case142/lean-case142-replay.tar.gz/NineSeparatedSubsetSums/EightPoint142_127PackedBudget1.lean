import NineSeparatedSubsetSums.EightPoint142_127PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct142_127_1_budget :
    FourPointNumeric.packedBudget 20 packedOct142_127_1 268 = 86890174 := by decide +kernel

#print axioms packedOct142_127_1_budget

end NineSeparatedSubsetSums
