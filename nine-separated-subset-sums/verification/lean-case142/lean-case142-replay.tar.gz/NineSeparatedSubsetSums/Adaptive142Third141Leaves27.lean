import NineSeparatedSubsetSums.Adaptive142Third141State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third141Proof45 : runCachedNode 511 130276 Adaptive142Third141Node45 = false := by
  decide +kernel

#print axioms adaptive142Third141Proof45

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third141Proof332 : runCachedNode 511 130276 Adaptive142Third141Node332 = false := by
  decide +kernel

#print axioms adaptive142Third141Proof332

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third141Proof127 : runCachedNode 511 130276 Adaptive142Third141Node127 = false := by
  decide +kernel

#print axioms adaptive142Third141Proof127

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third141Proof11 : runCachedNode 511 130276 Adaptive142Third141Node11 = false := by
  decide +kernel

#print axioms adaptive142Third141Proof11

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third141Proof200 : runCachedNode 511 130276 Adaptive142Third141Node200 = false := by
  decide +kernel

#print axioms adaptive142Third141Proof200

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third141Proof304 : runCachedNode 511 130276 Adaptive142Third141Node304 = false := by
  decide +kernel

#print axioms adaptive142Third141Proof304

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third141Proof421 : runCachedNode 511 130276 Adaptive142Third141Node421 = false := by
  decide +kernel

#print axioms adaptive142Third141Proof421

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third141Proof227 : runCachedNode 511 130276 Adaptive142Third141Node227 = false := by
  decide +kernel

#print axioms adaptive142Third141Proof227

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third141Proof302 : runCachedNode 511 130276 Adaptive142Third141Node302 = false := by
  decide +kernel

#print axioms adaptive142Third141Proof302

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third141Proof46 : runCachedNode 511 130276 Adaptive142Third141Node46 = false := by
  decide +kernel

#print axioms adaptive142Third141Proof46

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third141Proof126 : runCachedNode 511 130276 Adaptive142Third141Node126 = false := by
  decide +kernel

#print axioms adaptive142Third141Proof126

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third141Proof85 : runCachedNode 511 130276 Adaptive142Third141Node85 = false := by
  decide +kernel

#print axioms adaptive142Third141Proof85

end NineSeparatedSubsetSums
