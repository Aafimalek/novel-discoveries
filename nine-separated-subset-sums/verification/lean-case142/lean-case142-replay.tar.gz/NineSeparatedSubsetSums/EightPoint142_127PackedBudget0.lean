import NineSeparatedSubsetSums.EightPoint142_127PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct142_127_0_budget :
    FourPointNumeric.packedBudget 20 packedOct142_127_0 269 = 87135391 := by decide +kernel

#print axioms packedOct142_127_0_budget

end NineSeparatedSubsetSums
