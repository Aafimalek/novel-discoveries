import NineSeparatedSubsetSums.EightPointPackedGeometry
import NineSeparatedSubsetSums.EightPoint142_118PackedBudget0
import NineSeparatedSubsetSums.EightPoint142_118PackedAnchor0Part0
import NineSeparatedSubsetSums.EightPoint142_118PackedAnchor0Part1
import NineSeparatedSubsetSums.EightPoint142_118PackedAnchor0Part2
import NineSeparatedSubsetSums.EightPoint142_118PackedBudget1
import NineSeparatedSubsetSums.EightPoint142_118PackedAnchor1Part0
import NineSeparatedSubsetSums.EightPoint142_118PackedAnchor1Part1
import NineSeparatedSubsetSums.EightPoint142_118PackedAnchor1Part2

namespace NineSeparatedSubsetSums

private theorem packedOct142_118Anchor0 :
  ∀ j : Fin 494, ((j.val : Int)+142+118)%2=0 →
    2400064 ≤ FourPointNumeric.octPackedCharge 142 118 20 packedOct142_118_0 (j.val : Int) := by
  intro j hj
  let k := (j.val-0)/2
  have hk : k < 247 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+0 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint142_118PackedAnchor0Part0 z
    rwa [he,hrep] at ht
  by_cases h1 : k < 240
  · let z : Fin 120 := ⟨k-120, by omega⟩
    have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
    have ht := eightPoint142_118PackedAnchor0Part1 z
    rwa [he,hrep] at ht
  let z : Fin 7 := ⟨k-240, by omega⟩
  have he : (z.val : Int)+240 = k := by dsimp [z] <;> omega
  have ht := eightPoint142_118PackedAnchor0Part2 z
  rwa [he,hrep] at ht

private theorem packedOct142_118Anchor1 :
  ∀ j : Fin 494, ((j.val : Int)+142+118)%2=1 →
    2398869 ≤ FourPointNumeric.octPackedCharge 142 118 20 packedOct142_118_1 (j.val : Int) := by
  intro j hj
  let k := (j.val-1)/2
  have hk : k < 247 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+1 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint142_118PackedAnchor1Part0 z
    rwa [he,hrep] at ht
  by_cases h1 : k < 240
  · let z : Fin 120 := ⟨k-120, by omega⟩
    have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
    have ht := eightPoint142_118PackedAnchor1Part1 z
    rwa [he,hrep] at ht
  let z : Fin 7 := ⟨k-240, by omega⟩
  have he : (z.val : Int)+240 = k := by dsimp [z] <;> omega
  have ht := eightPoint142_118PackedAnchor1Part2 z
  rwa [he,hrep] at ht

def packedOctCertificate142_118_0 : EightPointCertificate 142 118 0 125536 :=
  eightPointCertificateOfPacked 142 118 0 125536 2400064 20 packedOct142_118_0 449 494
    (by decide +kernel) (by decide) packedOct142_118Anchor0
    (by rw [packedOct142_118_0_budget]; decide)

def packedOctCertificate142_118_1 : EightPointCertificate 142 118 1 125536 :=
  eightPointCertificateOfPacked 142 118 1 125536 2398869 20 packedOct142_118_1 450 494
    (by decide +kernel) (by decide) packedOct142_118Anchor1
    (by rw [packedOct142_118_1_budget]; decide)

theorem max148_second142_third118_eightPoint_moment_bound (tail : List ℕ) (len : tail.length=6)
    (distinct : (natSubsetSums (148::142::118::tail)).Nodup) :
    125536 ≤ ((148::142::118::tail).map (· ^ 2)).sum := by
  apply eightPointNatMomentLower 142 118 125536 tail len distinct
  intro p hp
  by_cases h : p=0
  · subst p
    exact packedOctCertificate142_118_0
  · have he : p=1 := hp.resolve_left h
    subst p
    exact packedOctCertificate142_118_1

#print axioms max148_second142_third118_eightPoint_moment_bound

end NineSeparatedSubsetSums
