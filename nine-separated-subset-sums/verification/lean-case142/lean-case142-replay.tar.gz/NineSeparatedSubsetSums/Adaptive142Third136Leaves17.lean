import NineSeparatedSubsetSums.Adaptive142Third136State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third136Proof164 : runCachedNode 511 129404 Adaptive142Third136Node164 = false := by
  decide +kernel

#print axioms adaptive142Third136Proof164

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third136Proof222 : runCachedNode 511 129404 Adaptive142Third136Node222 = false := by
  decide +kernel

#print axioms adaptive142Third136Proof222

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third136Proof224 : runCachedNode 511 129404 Adaptive142Third136Node224 = false := by
  decide +kernel

#print axioms adaptive142Third136Proof224

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third136Proof197 : runCachedNode 511 129404 Adaptive142Third136Node197 = false := by
  decide +kernel

#print axioms adaptive142Third136Proof197

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third136Proof133 : runCachedNode 511 129404 Adaptive142Third136Node133 = false := by
  decide +kernel

#print axioms adaptive142Third136Proof133

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third136Proof196 : runCachedNode 511 129404 Adaptive142Third136Node196 = false := by
  decide +kernel

#print axioms adaptive142Third136Proof196

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third136Proof108 : runCachedNode 511 129404 Adaptive142Third136Node108 = false := by
  decide +kernel

#print axioms adaptive142Third136Proof108

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third136Proof190 : runCachedNode 511 129404 Adaptive142Third136Node190 = false := by
  decide +kernel

#print axioms adaptive142Third136Proof190

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third136Proof80 : runCachedNode 511 129404 Adaptive142Third136Node80 = false := by
  decide +kernel

#print axioms adaptive142Third136Proof80

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third136Proof203 : runCachedNode 511 129404 Adaptive142Third136Node203 = false := by
  decide +kernel

#print axioms adaptive142Third136Proof203

end NineSeparatedSubsetSums
