import NineSeparatedSubsetSums.EightPointPackedGeometry
import NineSeparatedSubsetSums.EightPoint142_128PackedBudget0
import NineSeparatedSubsetSums.EightPoint142_128PackedAnchor0Part0
import NineSeparatedSubsetSums.EightPoint142_128PackedAnchor0Part1
import NineSeparatedSubsetSums.EightPoint142_128PackedAnchor0Part2
import NineSeparatedSubsetSums.EightPoint142_128PackedBudget1
import NineSeparatedSubsetSums.EightPoint142_128PackedAnchor1Part0
import NineSeparatedSubsetSums.EightPoint142_128PackedAnchor1Part1
import NineSeparatedSubsetSums.EightPoint142_128PackedAnchor1Part2

namespace NineSeparatedSubsetSums

private theorem packedOct142_128Anchor0 :
  ∀ j : Fin 489, ((j.val : Int)+142+128)%2=0 →
    2377055 ≤ FourPointNumeric.octPackedCharge 142 128 20 packedOct142_128_0 (j.val : Int) := by
  intro j hj
  let k := (j.val-0)/2
  have hk : k < 245 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+0 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint142_128PackedAnchor0Part0 z
    rwa [he,hrep] at ht
  by_cases h1 : k < 240
  · let z : Fin 120 := ⟨k-120, by omega⟩
    have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
    have ht := eightPoint142_128PackedAnchor0Part1 z
    rwa [he,hrep] at ht
  let z : Fin 5 := ⟨k-240, by omega⟩
  have he : (z.val : Int)+240 = k := by dsimp [z] <;> omega
  have ht := eightPoint142_128PackedAnchor0Part2 z
  rwa [he,hrep] at ht

private theorem packedOct142_128Anchor1 :
  ∀ j : Fin 489, ((j.val : Int)+142+128)%2=1 →
    2376280 ≤ FourPointNumeric.octPackedCharge 142 128 20 packedOct142_128_1 (j.val : Int) := by
  intro j hj
  let k := (j.val-1)/2
  have hk : k < 244 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+1 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint142_128PackedAnchor1Part0 z
    rwa [he,hrep] at ht
  by_cases h1 : k < 240
  · let z : Fin 120 := ⟨k-120, by omega⟩
    have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
    have ht := eightPoint142_128PackedAnchor1Part1 z
    rwa [he,hrep] at ht
  let z : Fin 4 := ⟨k-240, by omega⟩
  have he : (z.val : Int)+240 = k := by dsimp [z] <;> omega
  have ht := eightPoint142_128PackedAnchor1Part2 z
  rwa [he,hrep] at ht

def packedOctCertificate142_128_0 : EightPointCertificate 142 128 0 127897 :=
  eightPointCertificateOfPacked 142 128 0 127897 2377055 20 packedOct142_128_0 271 489
    (by decide +kernel) (by decide) packedOct142_128Anchor0
    (by rw [packedOct142_128_0_budget]; decide)

def packedOctCertificate142_128_1 : EightPointCertificate 142 128 1 127897 :=
  eightPointCertificateOfPacked 142 128 1 127897 2376280 20 packedOct142_128_1 432 489
    (by decide +kernel) (by decide) packedOct142_128Anchor1
    (by rw [packedOct142_128_1_budget]; decide)

theorem max148_second142_third128_eightPoint_moment_bound (tail : List ℕ) (len : tail.length=6)
    (distinct : (natSubsetSums (148::142::128::tail)).Nodup) :
    127897 ≤ ((148::142::128::tail).map (· ^ 2)).sum := by
  apply eightPointNatMomentLower 142 128 127897 tail len distinct
  intro p hp
  by_cases h : p=0
  · subst p
    exact packedOctCertificate142_128_0
  · have he : p=1 := hp.resolve_left h
    subst p
    exact packedOctCertificate142_128_1

#print axioms max148_second142_third128_eightPoint_moment_bound

end NineSeparatedSubsetSums
