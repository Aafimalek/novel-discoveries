import NineSeparatedSubsetSums.Adaptive142Third139State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third139Proof249 : runCachedNode 511 129933 Adaptive142Third139Node249 = false := by
  decide +kernel

#print axioms adaptive142Third139Proof249

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third139Proof100 : runCachedNode 511 129933 Adaptive142Third139Node100 = false := by
  decide +kernel

#print axioms adaptive142Third139Proof100

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third139Proof207 : runCachedNode 511 129933 Adaptive142Third139Node207 = false := by
  decide +kernel

#print axioms adaptive142Third139Proof207

end NineSeparatedSubsetSums
