import NineSeparatedSubsetSums.Adaptive142Third127State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third127Proof8 : runCachedNode 511 127742 Adaptive142Third127Node8 = false := by
  decide +kernel

#print axioms adaptive142Third127Proof8

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third127Proof7 : runCachedNode 511 127742 Adaptive142Third127Node7 = false := by
  decide +kernel

#print axioms adaptive142Third127Proof7

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third127Proof6 : runCachedNode 511 127742 Adaptive142Third127Node6 = false := by
  decide +kernel

#print axioms adaptive142Third127Proof6

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third127Proof5 : runCachedNode 511 127742 Adaptive142Third127Node5 = false := by
  decide +kernel

#print axioms adaptive142Third127Proof5

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third127Proof4 : runCachedNode 511 127742 Adaptive142Third127Node4 = false := by
  decide +kernel

#print axioms adaptive142Third127Proof4

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third127Proof3 : runCachedNode 511 127742 Adaptive142Third127Node3 = false := by
  decide +kernel

#print axioms adaptive142Third127Proof3

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third127Proof1 : runCachedNode 511 127742 Adaptive142Third127Node1 = false := by
  decide +kernel

#print axioms adaptive142Third127Proof1

end NineSeparatedSubsetSums
