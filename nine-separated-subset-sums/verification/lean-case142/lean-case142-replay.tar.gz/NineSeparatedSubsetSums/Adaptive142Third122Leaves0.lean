import NineSeparatedSubsetSums.Adaptive142Third122State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third122Proof0 : runCachedNode 511 126305 Adaptive142Third122Node0 = false := by
  decide +kernel

#print axioms adaptive142Third122Proof0

end NineSeparatedSubsetSums
