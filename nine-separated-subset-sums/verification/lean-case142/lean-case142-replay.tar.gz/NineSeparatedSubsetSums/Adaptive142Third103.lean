import NineSeparatedSubsetSums.Adaptive142Third103Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint142Checked

namespace NineSeparatedSubsetSums


theorem adaptive142Third103 : NoDescendingTailAfterThird 142 103 :=
  noDescendingThirdTail_of_cached 142 103 111874 (fun t ht nd => max148_second142_fourPoint_moment_bound (103::t) (by simp [ht]) nd) adaptive142Third103Proof0

#print axioms adaptive142Third103

end NineSeparatedSubsetSums
