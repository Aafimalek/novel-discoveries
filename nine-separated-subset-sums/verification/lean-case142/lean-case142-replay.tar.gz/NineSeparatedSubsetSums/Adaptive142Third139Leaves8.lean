import NineSeparatedSubsetSums.Adaptive142Third139State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third139Proof106 : runCachedNode 511 129933 Adaptive142Third139Node106 = false := by
  decide +kernel

#print axioms adaptive142Third139Proof106

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third139Proof211 : runCachedNode 511 129933 Adaptive142Third139Node211 = false := by
  decide +kernel

#print axioms adaptive142Third139Proof211

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third139Proof175 : runCachedNode 511 129933 Adaptive142Third139Node175 = false := by
  decide +kernel

#print axioms adaptive142Third139Proof175

end NineSeparatedSubsetSums
