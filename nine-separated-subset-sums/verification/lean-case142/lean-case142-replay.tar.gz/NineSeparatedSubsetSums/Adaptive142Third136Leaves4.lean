import NineSeparatedSubsetSums.Adaptive142Third136State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third136Proof16 : runCachedNode 511 129404 Adaptive142Third136Node16 = false := by
  decide +kernel

#print axioms adaptive142Third136Proof16

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third136Proof112 : runCachedNode 511 129404 Adaptive142Third136Node112 = false := by
  decide +kernel

#print axioms adaptive142Third136Proof112

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third136Proof74 : runCachedNode 511 129404 Adaptive142Third136Node74 = false := by
  decide +kernel

#print axioms adaptive142Third136Proof74

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third136Proof20 : runCachedNode 511 129404 Adaptive142Third136Node20 = false := by
  decide +kernel

#print axioms adaptive142Third136Proof20

end NineSeparatedSubsetSums
