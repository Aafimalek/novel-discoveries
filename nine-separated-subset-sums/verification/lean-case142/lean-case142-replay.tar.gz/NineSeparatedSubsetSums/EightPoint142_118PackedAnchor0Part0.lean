import NineSeparatedSubsetSums.EightPoint142_118PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint142_118PackedAnchor0Part0 :
    ∀ j : Fin 120, 2400064 ≤ FourPointNumeric.octPackedCharge 142 118 20 packedOct142_118_0
      (2*((j.val : Int)+0)+0) := by decide +kernel

end NineSeparatedSubsetSums
