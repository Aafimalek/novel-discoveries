import NineSeparatedSubsetSums.Adaptive142Third136State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third136Proof136 : runCachedNode 511 129404 Adaptive142Third136Node136 = false := by
  decide +kernel

#print axioms adaptive142Third136Proof136

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third136Proof12 : runCachedNode 511 129404 Adaptive142Third136Node12 = false := by
  decide +kernel

#print axioms adaptive142Third136Proof12

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third136Proof166 : runCachedNode 511 129404 Adaptive142Third136Node166 = false := by
  decide +kernel

#print axioms adaptive142Third136Proof166

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third136Proof200 : runCachedNode 511 129404 Adaptive142Third136Node200 = false := by
  decide +kernel

#print axioms adaptive142Third136Proof200

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third136Proof61 : runCachedNode 511 129404 Adaptive142Third136Node61 = false := by
  decide +kernel

#print axioms adaptive142Third136Proof61

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third136Proof72 : runCachedNode 511 129404 Adaptive142Third136Node72 = false := by
  decide +kernel

#print axioms adaptive142Third136Proof72

end NineSeparatedSubsetSums
