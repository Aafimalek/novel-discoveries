import NineSeparatedSubsetSums.Adaptive142Third136State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third136Proof17 : runCachedNode 511 129404 Adaptive142Third136Node17 = false := by
  decide +kernel

#print axioms adaptive142Third136Proof17

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third136Proof109 : runCachedNode 511 129404 Adaptive142Third136Node109 = false := by
  decide +kernel

#print axioms adaptive142Third136Proof109

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third136Proof1 : runCachedNode 511 129404 Adaptive142Third136Node1 = false := by
  decide +kernel

#print axioms adaptive142Third136Proof1

end NineSeparatedSubsetSums
