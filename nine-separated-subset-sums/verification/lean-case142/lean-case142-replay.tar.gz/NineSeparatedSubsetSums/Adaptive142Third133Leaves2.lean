import NineSeparatedSubsetSums.Adaptive142Third133State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third133Proof19 : runCachedNode 511 128920 Adaptive142Third133Node19 = false := by
  decide +kernel

#print axioms adaptive142Third133Proof19

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third133Proof18 : runCachedNode 511 128920 Adaptive142Third133Node18 = false := by
  decide +kernel

#print axioms adaptive142Third133Proof18

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third133Proof43 : runCachedNode 511 128920 Adaptive142Third133Node43 = false := by
  decide +kernel

#print axioms adaptive142Third133Proof43

end NineSeparatedSubsetSums
