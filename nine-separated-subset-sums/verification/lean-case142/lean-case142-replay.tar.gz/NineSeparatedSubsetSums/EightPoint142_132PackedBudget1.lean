import NineSeparatedSubsetSums.EightPoint142_132PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct142_132_1_budget :
    FourPointNumeric.packedBudget 20 packedOct142_132_1 404 = 90497850 := by decide +kernel

#print axioms packedOct142_132_1_budget

end NineSeparatedSubsetSums
