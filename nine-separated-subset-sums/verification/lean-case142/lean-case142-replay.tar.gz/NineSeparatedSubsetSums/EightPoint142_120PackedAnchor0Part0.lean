import NineSeparatedSubsetSums.EightPoint142_120PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint142_120PackedAnchor0Part0 :
    ∀ j : Fin 120, 2334503 ≤ FourPointNumeric.octPackedCharge 142 120 20 packedOct142_120_0
      (2*((j.val : Int)+0)+0) := by decide +kernel

end NineSeparatedSubsetSums
