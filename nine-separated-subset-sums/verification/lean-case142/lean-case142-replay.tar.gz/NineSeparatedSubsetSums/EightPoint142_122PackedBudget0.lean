import NineSeparatedSubsetSums.EightPoint142_122PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct142_122_0_budget :
    FourPointNumeric.packedBudget 20 packedOct142_122_0 263 = 82754260 := by decide +kernel

#print axioms packedOct142_122_0_budget

end NineSeparatedSubsetSums
