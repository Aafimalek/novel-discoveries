import NineSeparatedSubsetSums.Adaptive142Third139State
import NineSeparatedSubsetSums.Adaptive142Third139Leaves27
import NineSeparatedSubsetSums.Adaptive142Third139Leaves26
import NineSeparatedSubsetSums.Adaptive142Third139Leaves25
import NineSeparatedSubsetSums.Adaptive142Third139Leaves24
import NineSeparatedSubsetSums.Adaptive142Third139Leaves23
import NineSeparatedSubsetSums.Adaptive142Third139Leaves22
import NineSeparatedSubsetSums.Adaptive142Third139Leaves21
import NineSeparatedSubsetSums.Adaptive142Third139Leaves20
import NineSeparatedSubsetSums.Adaptive142Third139Leaves17
import NineSeparatedSubsetSums.Adaptive142Third139Leaves19
import NineSeparatedSubsetSums.Adaptive142Third139Leaves2
import NineSeparatedSubsetSums.Adaptive142Third139Leaves12
import NineSeparatedSubsetSums.Adaptive142Third139Leaves16
import NineSeparatedSubsetSums.Adaptive142Third139Leaves14
import NineSeparatedSubsetSums.Adaptive142Third139Leaves11
import NineSeparatedSubsetSums.Adaptive142Third139Joins0
import NineSeparatedSubsetSums.Adaptive142Third139Leaves7
import NineSeparatedSubsetSums.Adaptive142Third139Leaves5
import NineSeparatedSubsetSums.Adaptive142Third139Leaves1
import NineSeparatedSubsetSums.Adaptive142Third139Leaves13
import NineSeparatedSubsetSums.Adaptive142Third139Leaves18
import NineSeparatedSubsetSums.Adaptive142Third139Leaves3
import NineSeparatedSubsetSums.Adaptive142Third139Leaves4
import NineSeparatedSubsetSums.Adaptive142Third139Leaves6
import NineSeparatedSubsetSums.Adaptive142Third139Leaves10
import NineSeparatedSubsetSums.Adaptive142Third139Leaves0

namespace NineSeparatedSubsetSums

theorem adaptive142Third139Proof250 : runCachedNode 511 129933 Adaptive142Third139Node250 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 129933 Adaptive142Third139Node250 = [102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 130, 131, 134, 136, 137] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive142Third139Proof251
  · exact adaptive142Third139Proof252
  · exact adaptive142Third139Proof253
  · exact adaptive142Third139Proof254
  · exact adaptive142Third139Proof255
  · exact adaptive142Third139Proof256
  · exact adaptive142Third139Proof257
  · exact adaptive142Third139Proof258
  · exact adaptive142Third139Proof259
  · exact adaptive142Third139Proof260
  · exact adaptive142Third139Proof261
  · exact adaptive142Third139Proof262
  · exact adaptive142Third139Proof263
  · exact adaptive142Third139Proof264
  · exact adaptive142Third139Proof265
  · exact adaptive142Third139Proof266
  · exact adaptive142Third139Proof267
  · exact adaptive142Third139Proof268
  · exact adaptive142Third139Proof269
  · exact adaptive142Third139Proof270
  · exact adaptive142Third139Proof271
  · exact adaptive142Third139Proof272
  · exact adaptive142Third139Proof273
  · exact adaptive142Third139Proof274
  · exact adaptive142Third139Proof275
  · exact adaptive142Third139Proof276
  · exact adaptive142Third139Proof277
  · exact adaptive142Third139Proof278
  · exact adaptive142Third139Proof279
  · exact adaptive142Third139Proof280
  · exact adaptive142Third139Proof281
  · exact adaptive142Third139Proof319

#print axioms adaptive142Third139Proof250

theorem adaptive142Third139Proof0 : runCachedNode 511 129933 Adaptive142Third139Node0 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 129933 Adaptive142Third139Node0 = [110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 132, 134, 135, 136, 137, 138] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive142Third139Proof1
  · exact adaptive142Third139Proof2
  · exact adaptive142Third139Proof3
  · exact adaptive142Third139Proof4
  · exact adaptive142Third139Proof5
  · exact adaptive142Third139Proof6
  · exact adaptive142Third139Proof7
  · exact adaptive142Third139Proof8
  · exact adaptive142Third139Proof9
  · exact adaptive142Third139Proof10
  · exact adaptive142Third139Proof11
  · exact adaptive142Third139Proof12
  · exact adaptive142Third139Proof13
  · exact adaptive142Third139Proof14
  · exact adaptive142Third139Proof15
  · exact adaptive142Third139Proof16
  · exact adaptive142Third139Proof17
  · exact adaptive142Third139Proof18
  · exact adaptive142Third139Proof19
  · exact adaptive142Third139Proof20
  · exact adaptive142Third139Proof21
  · exact adaptive142Third139Proof22
  · exact adaptive142Third139Proof23
  · exact adaptive142Third139Proof24
  · exact adaptive142Third139Proof52
  · exact adaptive142Third139Proof81
  · exact adaptive142Third139Proof181
  · exact adaptive142Third139Proof250

#print axioms adaptive142Third139Proof0

end NineSeparatedSubsetSums
