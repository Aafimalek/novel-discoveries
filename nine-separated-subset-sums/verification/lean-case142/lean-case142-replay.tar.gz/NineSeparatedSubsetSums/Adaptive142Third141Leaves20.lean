import NineSeparatedSubsetSums.Adaptive142Third141State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third141Proof16 : runCachedNode 511 130276 Adaptive142Third141Node16 = false := by
  decide +kernel

#print axioms adaptive142Third141Proof16

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third141Proof204 : runCachedNode 511 130276 Adaptive142Third141Node204 = false := by
  decide +kernel

#print axioms adaptive142Third141Proof204

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third141Proof48 : runCachedNode 511 130276 Adaptive142Third141Node48 = false := by
  decide +kernel

#print axioms adaptive142Third141Proof48

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third141Proof425 : runCachedNode 511 130276 Adaptive142Third141Node425 = false := by
  decide +kernel

#print axioms adaptive142Third141Proof425

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third141Proof108 : runCachedNode 511 130276 Adaptive142Third141Node108 = false := by
  decide +kernel

#print axioms adaptive142Third141Proof108

end NineSeparatedSubsetSums
