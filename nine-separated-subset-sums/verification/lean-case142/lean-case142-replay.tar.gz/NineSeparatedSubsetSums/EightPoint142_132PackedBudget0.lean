import NineSeparatedSubsetSums.EightPoint142_132PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct142_132_0_budget :
    FourPointNumeric.packedBudget 20 packedOct142_132_0 271 = 90380588 := by decide +kernel

#print axioms packedOct142_132_0_budget

end NineSeparatedSubsetSums
