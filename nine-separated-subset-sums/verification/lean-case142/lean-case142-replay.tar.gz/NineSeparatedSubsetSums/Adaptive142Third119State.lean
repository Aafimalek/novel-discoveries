import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive142Third119Node0 : CachedSearchNode :=
  ⟨4, 118, computeCenteredMask [148,142,119], 409, 56229⟩

end NineSeparatedSubsetSums
