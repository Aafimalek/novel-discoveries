import NineSeparatedSubsetSums.Adaptive142Third138State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third138Proof20 : runCachedNode 511 129778 Adaptive142Third138Node20 = false := by
  decide +kernel

#print axioms adaptive142Third138Proof20

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third138Proof105 : runCachedNode 511 129778 Adaptive142Third138Node105 = false := by
  decide +kernel

#print axioms adaptive142Third138Proof105

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third138Proof182 : runCachedNode 511 129778 Adaptive142Third138Node182 = false := by
  decide +kernel

#print axioms adaptive142Third138Proof182

end NineSeparatedSubsetSums
