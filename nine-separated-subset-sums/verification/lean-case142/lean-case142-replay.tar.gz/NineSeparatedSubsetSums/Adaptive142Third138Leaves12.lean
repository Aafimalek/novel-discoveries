import NineSeparatedSubsetSums.Adaptive142Third138State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third138Proof203 : runCachedNode 511 129778 Adaptive142Third138Node203 = false := by
  decide +kernel

#print axioms adaptive142Third138Proof203

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third138Proof199 : runCachedNode 511 129778 Adaptive142Third138Node199 = false := by
  decide +kernel

#print axioms adaptive142Third138Proof199

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third138Proof133 : runCachedNode 511 129778 Adaptive142Third138Node133 = false := by
  decide +kernel

#print axioms adaptive142Third138Proof133

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third138Proof101 : runCachedNode 511 129778 Adaptive142Third138Node101 = false := by
  decide +kernel

#print axioms adaptive142Third138Proof101

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third138Proof30 : runCachedNode 511 129778 Adaptive142Third138Node30 = false := by
  decide +kernel

#print axioms adaptive142Third138Proof30

end NineSeparatedSubsetSums
