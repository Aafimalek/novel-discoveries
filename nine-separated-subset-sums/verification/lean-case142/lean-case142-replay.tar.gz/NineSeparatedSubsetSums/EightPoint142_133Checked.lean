import NineSeparatedSubsetSums.EightPointPackedGeometry
import NineSeparatedSubsetSums.EightPoint142_133PackedBudget0
import NineSeparatedSubsetSums.EightPoint142_133PackedAnchor0Part0
import NineSeparatedSubsetSums.EightPoint142_133PackedAnchor0Part1
import NineSeparatedSubsetSums.EightPoint142_133PackedAnchor0Part2
import NineSeparatedSubsetSums.EightPoint142_133PackedBudget1
import NineSeparatedSubsetSums.EightPoint142_133PackedAnchor1Part0
import NineSeparatedSubsetSums.EightPoint142_133PackedAnchor1Part1
import NineSeparatedSubsetSums.EightPoint142_133PackedAnchor1Part2

namespace NineSeparatedSubsetSums

private theorem packedOct142_133Anchor0 :
  ∀ j : Fin 498, ((j.val : Int)+142+133)%2=0 →
    2457475 ≤ FourPointNumeric.octPackedCharge 142 133 20 packedOct142_133_0 (j.val : Int) := by
  intro j hj
  let k := (j.val-1)/2
  have hk : k < 249 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+1 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint142_133PackedAnchor0Part0 z
    rwa [he,hrep] at ht
  by_cases h1 : k < 240
  · let z : Fin 120 := ⟨k-120, by omega⟩
    have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
    have ht := eightPoint142_133PackedAnchor0Part1 z
    rwa [he,hrep] at ht
  let z : Fin 9 := ⟨k-240, by omega⟩
  have he : (z.val : Int)+240 = k := by dsimp [z] <;> omega
  have ht := eightPoint142_133PackedAnchor0Part2 z
  rwa [he,hrep] at ht

private theorem packedOct142_133Anchor1 :
  ∀ j : Fin 498, ((j.val : Int)+142+133)%2=1 →
    2457938 ≤ FourPointNumeric.octPackedCharge 142 133 20 packedOct142_133_1 (j.val : Int) := by
  intro j hj
  let k := (j.val-0)/2
  have hk : k < 249 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+0 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint142_133PackedAnchor1Part0 z
    rwa [he,hrep] at ht
  by_cases h1 : k < 240
  · let z : Fin 120 := ⟨k-120, by omega⟩
    have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
    have ht := eightPoint142_133PackedAnchor1Part1 z
    rwa [he,hrep] at ht
  let z : Fin 9 := ⟨k-240, by omega⟩
  have he : (z.val : Int)+240 = k := by dsimp [z] <;> omega
  have ht := eightPoint142_133PackedAnchor1Part2 z
  rwa [he,hrep] at ht

def packedOctCertificate142_133_0 : EightPointCertificate 142 133 0 128920 :=
  eightPointCertificateOfPacked 142 133 0 128920 2457475 20 packedOct142_133_0 457 498
    (by decide +kernel) (by decide) packedOct142_133Anchor0
    (by rw [packedOct142_133_0_budget]; decide)

def packedOctCertificate142_133_1 : EightPointCertificate 142 133 1 128920 :=
  eightPointCertificateOfPacked 142 133 1 128920 2457938 20 packedOct142_133_1 456 498
    (by decide +kernel) (by decide) packedOct142_133Anchor1
    (by rw [packedOct142_133_1_budget]; decide)

theorem max148_second142_third133_eightPoint_moment_bound (tail : List ℕ) (len : tail.length=6)
    (distinct : (natSubsetSums (148::142::133::tail)).Nodup) :
    128920 ≤ ((148::142::133::tail).map (· ^ 2)).sum := by
  apply eightPointNatMomentLower 142 133 128920 tail len distinct
  intro p hp
  by_cases h : p=0
  · subst p
    exact packedOctCertificate142_133_0
  · have he : p=1 := hp.resolve_left h
    subst p
    exact packedOctCertificate142_133_1

#print axioms max148_second142_third133_eightPoint_moment_bound

end NineSeparatedSubsetSums
