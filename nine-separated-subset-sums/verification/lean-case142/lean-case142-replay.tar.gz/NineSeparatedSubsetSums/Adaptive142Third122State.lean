import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive142Third122Node0 : CachedSearchNode :=
  ⟨4, 121, computeCenteredMask [148,142,122], 412, 56952⟩

end NineSeparatedSubsetSums
