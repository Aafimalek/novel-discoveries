import NineSeparatedSubsetSums.Adaptive142Third137State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third137Proof129 : runCachedNode 511 129593 Adaptive142Third137Node129 = false := by
  decide +kernel

#print axioms adaptive142Third137Proof129

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third137Proof16 : runCachedNode 511 129593 Adaptive142Third137Node16 = false := by
  decide +kernel

#print axioms adaptive142Third137Proof16

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third137Proof71 : runCachedNode 511 129593 Adaptive142Third137Node71 = false := by
  decide +kernel

#print axioms adaptive142Third137Proof71

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third137Proof80 : runCachedNode 511 129593 Adaptive142Third137Node80 = false := by
  decide +kernel

#print axioms adaptive142Third137Proof80

end NineSeparatedSubsetSums
