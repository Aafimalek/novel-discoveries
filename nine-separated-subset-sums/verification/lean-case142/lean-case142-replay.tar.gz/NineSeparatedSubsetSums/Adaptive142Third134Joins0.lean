import NineSeparatedSubsetSums.Adaptive142Third134State
import NineSeparatedSubsetSums.Adaptive142Third134Leaves2
import NineSeparatedSubsetSums.Adaptive142Third134Leaves4
import NineSeparatedSubsetSums.Adaptive142Third134Leaves7
import NineSeparatedSubsetSums.Adaptive142Third134Leaves6
import NineSeparatedSubsetSums.Adaptive142Third134Leaves3
import NineSeparatedSubsetSums.Adaptive142Third134Leaves1
import NineSeparatedSubsetSums.Adaptive142Third134Leaves0
import NineSeparatedSubsetSums.Adaptive142Third134Leaves5

namespace NineSeparatedSubsetSums

theorem adaptive142Third134Proof22 : runCachedNode 511 129144 Adaptive142Third134Node22 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 129144 Adaptive142Third134Node22 = [104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 119, 120, 121, 122, 123, 125, 127, 129, 130, 131] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive142Third134Proof23
  · exact adaptive142Third134Proof24
  · exact adaptive142Third134Proof25
  · exact adaptive142Third134Proof26
  · exact adaptive142Third134Proof27
  · exact adaptive142Third134Proof28
  · exact adaptive142Third134Proof29
  · exact adaptive142Third134Proof30
  · exact adaptive142Third134Proof31
  · exact adaptive142Third134Proof32
  · exact adaptive142Third134Proof33
  · exact adaptive142Third134Proof34
  · exact adaptive142Third134Proof35
  · exact adaptive142Third134Proof36
  · exact adaptive142Third134Proof37
  · exact adaptive142Third134Proof38
  · exact adaptive142Third134Proof39
  · exact adaptive142Third134Proof40
  · exact adaptive142Third134Proof41
  · exact adaptive142Third134Proof42
  · exact adaptive142Third134Proof43
  · exact adaptive142Third134Proof44
  · exact adaptive142Third134Proof45
  · exact adaptive142Third134Proof46

#print axioms adaptive142Third134Proof22

theorem adaptive142Third134Proof47 : runCachedNode 511 129144 Adaptive142Third134Node47 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 129144 Adaptive142Third134Node47 = [104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 120, 121, 122, 123, 124, 126, 129, 130, 131, 132] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive142Third134Proof48
  · exact adaptive142Third134Proof49
  · exact adaptive142Third134Proof50
  · exact adaptive142Third134Proof51
  · exact adaptive142Third134Proof52
  · exact adaptive142Third134Proof53
  · exact adaptive142Third134Proof54
  · exact adaptive142Third134Proof55
  · exact adaptive142Third134Proof56
  · exact adaptive142Third134Proof57
  · exact adaptive142Third134Proof58
  · exact adaptive142Third134Proof59
  · exact adaptive142Third134Proof60
  · exact adaptive142Third134Proof61
  · exact adaptive142Third134Proof62
  · exact adaptive142Third134Proof63
  · exact adaptive142Third134Proof64
  · exact adaptive142Third134Proof65
  · exact adaptive142Third134Proof66
  · exact adaptive142Third134Proof67
  · exact adaptive142Third134Proof68
  · exact adaptive142Third134Proof69
  · exact adaptive142Third134Proof70
  · exact adaptive142Third134Proof71
  · exact adaptive142Third134Proof72

#print axioms adaptive142Third134Proof47

theorem adaptive142Third134Proof0 : runCachedNode 511 129144 Adaptive142Third134Node0 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 129144 Adaptive142Third134Node0 = [110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 129, 130, 131, 132, 133] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive142Third134Proof1
  · exact adaptive142Third134Proof2
  · exact adaptive142Third134Proof3
  · exact adaptive142Third134Proof4
  · exact adaptive142Third134Proof5
  · exact adaptive142Third134Proof6
  · exact adaptive142Third134Proof7
  · exact adaptive142Third134Proof8
  · exact adaptive142Third134Proof9
  · exact adaptive142Third134Proof10
  · exact adaptive142Third134Proof11
  · exact adaptive142Third134Proof12
  · exact adaptive142Third134Proof13
  · exact adaptive142Third134Proof14
  · exact adaptive142Third134Proof15
  · exact adaptive142Third134Proof16
  · exact adaptive142Third134Proof17
  · exact adaptive142Third134Proof18
  · exact adaptive142Third134Proof19
  · exact adaptive142Third134Proof20
  · exact adaptive142Third134Proof21
  · exact adaptive142Third134Proof22
  · exact adaptive142Third134Proof47

#print axioms adaptive142Third134Proof0

end NineSeparatedSubsetSums
