import NineSeparatedSubsetSums.EightPoint142_119PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint142_119PackedAnchor1Part1 :
    ∀ j : Fin 120, 2396330 ≤ FourPointNumeric.octPackedCharge 142 119 20 packedOct142_119_1
      (2*((j.val : Int)+120)+0) := by decide +kernel

end NineSeparatedSubsetSums
