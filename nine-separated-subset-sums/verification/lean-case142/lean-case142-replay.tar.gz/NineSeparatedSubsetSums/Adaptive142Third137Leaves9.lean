import NineSeparatedSubsetSums.Adaptive142Third137State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third137Proof152 : runCachedNode 511 129593 Adaptive142Third137Node152 = false := by
  decide +kernel

#print axioms adaptive142Third137Proof152

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third137Proof96 : runCachedNode 511 129593 Adaptive142Third137Node96 = false := by
  decide +kernel

#print axioms adaptive142Third137Proof96

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third137Proof100 : runCachedNode 511 129593 Adaptive142Third137Node100 = false := by
  decide +kernel

#print axioms adaptive142Third137Proof100

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third137Proof45 : runCachedNode 511 129593 Adaptive142Third137Node45 = false := by
  decide +kernel

#print axioms adaptive142Third137Proof45

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third137Proof179 : runCachedNode 511 129593 Adaptive142Third137Node179 = false := by
  decide +kernel

#print axioms adaptive142Third137Proof179

end NineSeparatedSubsetSums
