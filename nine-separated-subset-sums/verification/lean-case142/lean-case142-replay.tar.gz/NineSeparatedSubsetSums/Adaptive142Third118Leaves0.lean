import NineSeparatedSubsetSums.Adaptive142Third118State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third118Proof0 : runCachedNode 511 125536 Adaptive142Third118Node0 = false := by
  decide +kernel

#print axioms adaptive142Third118Proof0

end NineSeparatedSubsetSums
