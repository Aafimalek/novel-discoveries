import NineSeparatedSubsetSums.Adaptive142Third111Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint142Checked

namespace NineSeparatedSubsetSums


theorem adaptive142Third111 : NoDescendingTailAfterThird 142 111 :=
  noDescendingThirdTail_of_cached 142 111 111874 (fun t ht nd => max148_second142_fourPoint_moment_bound (111::t) (by simp [ht]) nd) adaptive142Third111Proof0

#print axioms adaptive142Third111

end NineSeparatedSubsetSums
