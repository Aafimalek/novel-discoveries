import NineSeparatedSubsetSums.EightPoint142_124PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint142_124PackedAnchor1Part2 :
    ∀ j : Fin 2, 2328417 ≤ FourPointNumeric.octPackedCharge 142 124 20 packedOct142_124_1
      (2*((j.val : Int)+240)+1) := by decide +kernel

end NineSeparatedSubsetSums
