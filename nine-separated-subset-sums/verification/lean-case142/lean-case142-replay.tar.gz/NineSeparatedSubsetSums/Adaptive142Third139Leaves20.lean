import NineSeparatedSubsetSums.Adaptive142Third139State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third139Proof11 : runCachedNode 511 129933 Adaptive142Third139Node11 = false := by
  decide +kernel

#print axioms adaptive142Third139Proof11

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third139Proof46 : runCachedNode 511 129933 Adaptive142Third139Node46 = false := by
  decide +kernel

#print axioms adaptive142Third139Proof46

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third139Proof276 : runCachedNode 511 129933 Adaptive142Third139Node276 = false := by
  decide +kernel

#print axioms adaptive142Third139Proof276

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third139Proof140 : runCachedNode 511 129933 Adaptive142Third139Node140 = false := by
  decide +kernel

#print axioms adaptive142Third139Proof140

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third139Proof272 : runCachedNode 511 129933 Adaptive142Third139Node272 = false := by
  decide +kernel

#print axioms adaptive142Third139Proof272

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third139Proof204 : runCachedNode 511 129933 Adaptive142Third139Node204 = false := by
  decide +kernel

#print axioms adaptive142Third139Proof204

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third139Proof95 : runCachedNode 511 129933 Adaptive142Third139Node95 = false := by
  decide +kernel

#print axioms adaptive142Third139Proof95

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third139Proof271 : runCachedNode 511 129933 Adaptive142Third139Node271 = false := by
  decide +kernel

#print axioms adaptive142Third139Proof271

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third139Proof45 : runCachedNode 511 129933 Adaptive142Third139Node45 = false := by
  decide +kernel

#print axioms adaptive142Third139Proof45

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third139Proof72 : runCachedNode 511 129933 Adaptive142Third139Node72 = false := by
  decide +kernel

#print axioms adaptive142Third139Proof72

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third139Proof74 : runCachedNode 511 129933 Adaptive142Third139Node74 = false := by
  decide +kernel

#print axioms adaptive142Third139Proof74

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third139Proof245 : runCachedNode 511 129933 Adaptive142Third139Node245 = false := by
  decide +kernel

#print axioms adaptive142Third139Proof245

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third139Proof42 : runCachedNode 511 129933 Adaptive142Third139Node42 = false := by
  decide +kernel

#print axioms adaptive142Third139Proof42

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third139Proof94 : runCachedNode 511 129933 Adaptive142Third139Node94 = false := by
  decide +kernel

#print axioms adaptive142Third139Proof94

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third139Proof202 : runCachedNode 511 129933 Adaptive142Third139Node202 = false := by
  decide +kernel

#print axioms adaptive142Third139Proof202

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third139Proof176 : runCachedNode 511 129933 Adaptive142Third139Node176 = false := by
  decide +kernel

#print axioms adaptive142Third139Proof176

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third139Proof112 : runCachedNode 511 129933 Adaptive142Third139Node112 = false := by
  decide +kernel

#print axioms adaptive142Third139Proof112

end NineSeparatedSubsetSums
