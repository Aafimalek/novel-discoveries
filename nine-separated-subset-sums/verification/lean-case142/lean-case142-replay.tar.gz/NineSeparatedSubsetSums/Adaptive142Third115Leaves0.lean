import NineSeparatedSubsetSums.Adaptive142Third115State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third115Proof14 : runCachedNode 511 111874 Adaptive142Third115Node14 = false := by
  decide +kernel

#print axioms adaptive142Third115Proof14

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third115Proof13 : runCachedNode 511 111874 Adaptive142Third115Node13 = false := by
  decide +kernel

#print axioms adaptive142Third115Proof13

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third115Proof12 : runCachedNode 511 111874 Adaptive142Third115Node12 = false := by
  decide +kernel

#print axioms adaptive142Third115Proof12

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third115Proof11 : runCachedNode 511 111874 Adaptive142Third115Node11 = false := by
  decide +kernel

#print axioms adaptive142Third115Proof11

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third115Proof9 : runCachedNode 511 111874 Adaptive142Third115Node9 = false := by
  decide +kernel

#print axioms adaptive142Third115Proof9

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third115Proof1 : runCachedNode 511 111874 Adaptive142Third115Node1 = false := by
  decide +kernel

#print axioms adaptive142Third115Proof1

end NineSeparatedSubsetSums
