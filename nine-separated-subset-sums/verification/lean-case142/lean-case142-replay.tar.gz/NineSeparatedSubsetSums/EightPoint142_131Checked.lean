import NineSeparatedSubsetSums.EightPointPackedGeometry
import NineSeparatedSubsetSums.EightPoint142_131PackedBudget0
import NineSeparatedSubsetSums.EightPoint142_131PackedAnchor0Part0
import NineSeparatedSubsetSums.EightPoint142_131PackedAnchor0Part1
import NineSeparatedSubsetSums.EightPoint142_131PackedAnchor0Part2
import NineSeparatedSubsetSums.EightPoint142_131PackedBudget1
import NineSeparatedSubsetSums.EightPoint142_131PackedAnchor1Part0
import NineSeparatedSubsetSums.EightPoint142_131PackedAnchor1Part1
import NineSeparatedSubsetSums.EightPoint142_131PackedAnchor1Part2

namespace NineSeparatedSubsetSums

private theorem packedOct142_131Anchor0 :
  ∀ j : Fin 495, ((j.val : Int)+142+131)%2=0 →
    2431527 ≤ FourPointNumeric.octPackedCharge 142 131 20 packedOct142_131_0 (j.val : Int) := by
  intro j hj
  let k := (j.val-1)/2
  have hk : k < 247 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+1 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint142_131PackedAnchor0Part0 z
    rwa [he,hrep] at ht
  by_cases h1 : k < 240
  · let z : Fin 120 := ⟨k-120, by omega⟩
    have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
    have ht := eightPoint142_131PackedAnchor0Part1 z
    rwa [he,hrep] at ht
  let z : Fin 7 := ⟨k-240, by omega⟩
  have he : (z.val : Int)+240 = k := by dsimp [z] <;> omega
  have ht := eightPoint142_131PackedAnchor0Part2 z
  rwa [he,hrep] at ht

private theorem packedOct142_131Anchor1 :
  ∀ j : Fin 495, ((j.val : Int)+142+131)%2=1 →
    2431242 ≤ FourPointNumeric.octPackedCharge 142 131 20 packedOct142_131_1 (j.val : Int) := by
  intro j hj
  let k := (j.val-0)/2
  have hk : k < 248 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+0 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint142_131PackedAnchor1Part0 z
    rwa [he,hrep] at ht
  by_cases h1 : k < 240
  · let z : Fin 120 := ⟨k-120, by omega⟩
    have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
    have ht := eightPoint142_131PackedAnchor1Part1 z
    rwa [he,hrep] at ht
  let z : Fin 8 := ⟨k-240, by omega⟩
  have he : (z.val : Int)+240 = k := by dsimp [z] <;> omega
  have ht := eightPoint142_131PackedAnchor1Part2 z
  rwa [he,hrep] at ht

def packedOctCertificate142_131_0 : EightPointCertificate 142 131 0 128642 :=
  eightPointCertificateOfPacked 142 131 0 128642 2431527 20 packedOct142_131_0 393 495
    (by decide +kernel) (by decide) packedOct142_131Anchor0
    (by rw [packedOct142_131_0_budget]; decide)

def packedOctCertificate142_131_1 : EightPointCertificate 142 131 1 128642 :=
  eightPointCertificateOfPacked 142 131 1 128642 2431242 20 packedOct142_131_1 394 495
    (by decide +kernel) (by decide) packedOct142_131Anchor1
    (by rw [packedOct142_131_1_budget]; decide)

theorem max148_second142_third131_eightPoint_moment_bound (tail : List ℕ) (len : tail.length=6)
    (distinct : (natSubsetSums (148::142::131::tail)).Nodup) :
    128642 ≤ ((148::142::131::tail).map (· ^ 2)).sum := by
  apply eightPointNatMomentLower 142 131 128642 tail len distinct
  intro p hp
  by_cases h : p=0
  · subst p
    exact packedOctCertificate142_131_0
  · have he : p=1 := hp.resolve_left h
    subst p
    exact packedOctCertificate142_131_1

#print axioms max148_second142_third131_eightPoint_moment_bound

end NineSeparatedSubsetSums
