import NineSeparatedSubsetSums.Adaptive142Third140State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third140Proof201 : runCachedNode 511 130107 Adaptive142Third140Node201 = false := by
  decide +kernel

#print axioms adaptive142Third140Proof201

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third140Proof48 : runCachedNode 511 130107 Adaptive142Third140Node48 = false := by
  decide +kernel

#print axioms adaptive142Third140Proof48

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third140Proof88 : runCachedNode 511 130107 Adaptive142Third140Node88 = false := by
  decide +kernel

#print axioms adaptive142Third140Proof88

end NineSeparatedSubsetSums
