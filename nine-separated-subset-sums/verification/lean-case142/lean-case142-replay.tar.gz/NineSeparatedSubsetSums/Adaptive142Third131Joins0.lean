import NineSeparatedSubsetSums.Adaptive142Third131State
import NineSeparatedSubsetSums.Adaptive142Third131Leaves2
import NineSeparatedSubsetSums.Adaptive142Third131Leaves0
import NineSeparatedSubsetSums.Adaptive142Third131Leaves1

namespace NineSeparatedSubsetSums

theorem adaptive142Third131Proof0 : runCachedNode 511 128642 Adaptive142Third131Node0 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 128642 Adaptive142Third131Node0 = [111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 126, 127, 128, 129, 130] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive142Third131Proof1
  · exact adaptive142Third131Proof2
  · exact adaptive142Third131Proof3
  · exact adaptive142Third131Proof4
  · exact adaptive142Third131Proof5
  · exact adaptive142Third131Proof6
  · exact adaptive142Third131Proof7
  · exact adaptive142Third131Proof8
  · exact adaptive142Third131Proof9
  · exact adaptive142Third131Proof10
  · exact adaptive142Third131Proof11
  · exact adaptive142Third131Proof12
  · exact adaptive142Third131Proof13
  · exact adaptive142Third131Proof14
  · exact adaptive142Third131Proof15
  · exact adaptive142Third131Proof16
  · exact adaptive142Third131Proof17
  · exact adaptive142Third131Proof18
  · exact adaptive142Third131Proof19

#print axioms adaptive142Third131Proof0

end NineSeparatedSubsetSums
