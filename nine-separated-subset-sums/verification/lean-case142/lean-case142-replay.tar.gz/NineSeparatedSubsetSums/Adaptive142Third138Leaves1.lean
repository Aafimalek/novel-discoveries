import NineSeparatedSubsetSums.Adaptive142Third138State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third138Proof19 : runCachedNode 511 129778 Adaptive142Third138Node19 = false := by
  decide +kernel

#print axioms adaptive142Third138Proof19

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third138Proof102 : runCachedNode 511 129778 Adaptive142Third138Node102 = false := by
  decide +kernel

#print axioms adaptive142Third138Proof102

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third138Proof29 : runCachedNode 511 129778 Adaptive142Third138Node29 = false := by
  decide +kernel

#print axioms adaptive142Third138Proof29

end NineSeparatedSubsetSums
