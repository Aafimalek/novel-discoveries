import NineSeparatedSubsetSums.Adaptive142Third135State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third135Proof20 : runCachedNode 511 129264 Adaptive142Third135Node20 = false := by
  decide +kernel

#print axioms adaptive142Third135Proof20

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third135Proof18 : runCachedNode 511 129264 Adaptive142Third135Node18 = false := by
  decide +kernel

#print axioms adaptive142Third135Proof18

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third135Proof92 : runCachedNode 511 129264 Adaptive142Third135Node92 = false := by
  decide +kernel

#print axioms adaptive142Third135Proof92

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third135Proof27 : runCachedNode 511 129264 Adaptive142Third135Node27 = false := by
  decide +kernel

#print axioms adaptive142Third135Proof27

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third135Proof75 : runCachedNode 511 129264 Adaptive142Third135Node75 = false := by
  decide +kernel

#print axioms adaptive142Third135Proof75

end NineSeparatedSubsetSums
