import NineSeparatedSubsetSums.Adaptive142Third106Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint142Checked

namespace NineSeparatedSubsetSums


theorem adaptive142Third106 : NoDescendingTailAfterThird 142 106 :=
  noDescendingThirdTail_of_cached 142 106 111874 (fun t ht nd => max148_second142_fourPoint_moment_bound (106::t) (by simp [ht]) nd) adaptive142Third106Proof0

#print axioms adaptive142Third106

end NineSeparatedSubsetSums
