import NineSeparatedSubsetSums.Adaptive142Third136State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third136Proof231 : runCachedNode 511 129404 Adaptive142Third136Node231 = false := by
  decide +kernel

#print axioms adaptive142Third136Proof231

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third136Proof38 : runCachedNode 511 129404 Adaptive142Third136Node38 = false := by
  decide +kernel

#print axioms adaptive142Third136Proof38

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third136Proof117 : runCachedNode 511 129404 Adaptive142Third136Node117 = false := by
  decide +kernel

#print axioms adaptive142Third136Proof117

end NineSeparatedSubsetSums
