import NineSeparatedSubsetSums.Adaptive142Third141State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third141Proof20 : runCachedNode 511 130276 Adaptive142Third141Node20 = false := by
  decide +kernel

#print axioms adaptive142Third141Proof20

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third141Proof234 : runCachedNode 511 130276 Adaptive142Third141Node234 = false := by
  decide +kernel

#print axioms adaptive142Third141Proof234

end NineSeparatedSubsetSums
