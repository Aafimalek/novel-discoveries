import NineSeparatedSubsetSums.EightPoint142_116PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct142_116_0_budget :
    FourPointNumeric.packedBudget 20 packedOct142_116_0 411 = 87501340 := by decide +kernel

#print axioms packedOct142_116_0_budget

end NineSeparatedSubsetSums
