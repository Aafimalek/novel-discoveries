import NineSeparatedSubsetSums.EightPoint142_116PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct142_116_1_budget :
    FourPointNumeric.packedBudget 20 packedOct142_116_1 458 = 87497094 := by decide +kernel

#print axioms packedOct142_116_1_budget

end NineSeparatedSubsetSums
