import NineSeparatedSubsetSums.Adaptive142Third140State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third140Proof235 : runCachedNode 511 130107 Adaptive142Third140Node235 = false := by
  decide +kernel

#print axioms adaptive142Third140Proof235

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third140Proof227 : runCachedNode 511 130107 Adaptive142Third140Node227 = false := by
  decide +kernel

#print axioms adaptive142Third140Proof227

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third140Proof258 : runCachedNode 511 130107 Adaptive142Third140Node258 = false := by
  decide +kernel

#print axioms adaptive142Third140Proof258

end NineSeparatedSubsetSums
