import NineSeparatedSubsetSums.Adaptive142Third136State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third136Proof163 : runCachedNode 511 129404 Adaptive142Third136Node163 = false := by
  decide +kernel

#print axioms adaptive142Third136Proof163

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third136Proof199 : runCachedNode 511 129404 Adaptive142Third136Node199 = false := by
  decide +kernel

#print axioms adaptive142Third136Proof199

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third136Proof39 : runCachedNode 511 129404 Adaptive142Third136Node39 = false := by
  decide +kernel

#print axioms adaptive142Third136Proof39

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third136Proof11 : runCachedNode 511 129404 Adaptive142Third136Node11 = false := by
  decide +kernel

#print axioms adaptive142Third136Proof11

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third136Proof40 : runCachedNode 511 129404 Adaptive142Third136Node40 = false := by
  decide +kernel

#print axioms adaptive142Third136Proof40

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third136Proof111 : runCachedNode 511 129404 Adaptive142Third136Node111 = false := by
  decide +kernel

#print axioms adaptive142Third136Proof111

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third136Proof70 : runCachedNode 511 129404 Adaptive142Third136Node70 = false := by
  decide +kernel

#print axioms adaptive142Third136Proof70

end NineSeparatedSubsetSums
