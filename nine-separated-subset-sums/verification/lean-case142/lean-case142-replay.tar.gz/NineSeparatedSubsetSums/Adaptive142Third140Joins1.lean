import NineSeparatedSubsetSums.Adaptive142Third140State
import NineSeparatedSubsetSums.Adaptive142Third140Leaves17
import NineSeparatedSubsetSums.Adaptive142Third140Leaves25
import NineSeparatedSubsetSums.Adaptive142Third140Leaves32
import NineSeparatedSubsetSums.Adaptive142Third140Leaves31
import NineSeparatedSubsetSums.Adaptive142Third140Leaves30
import NineSeparatedSubsetSums.Adaptive142Third140Leaves29
import NineSeparatedSubsetSums.Adaptive142Third140Leaves16
import NineSeparatedSubsetSums.Adaptive142Third140Leaves28
import NineSeparatedSubsetSums.Adaptive142Third140Leaves7
import NineSeparatedSubsetSums.Adaptive142Third140Leaves27
import NineSeparatedSubsetSums.Adaptive142Third140Leaves26
import NineSeparatedSubsetSums.Adaptive142Third140Leaves22
import NineSeparatedSubsetSums.Adaptive142Third140Leaves20
import NineSeparatedSubsetSums.Adaptive142Third140Leaves9
import NineSeparatedSubsetSums.Adaptive142Third140Leaves2
import NineSeparatedSubsetSums.Adaptive142Third140Joins0
import NineSeparatedSubsetSums.Adaptive142Third140Leaves14
import NineSeparatedSubsetSums.Adaptive142Third140Leaves19
import NineSeparatedSubsetSums.Adaptive142Third140Leaves24
import NineSeparatedSubsetSums.Adaptive142Third140Leaves23
import NineSeparatedSubsetSums.Adaptive142Third140Leaves21
import NineSeparatedSubsetSums.Adaptive142Third140Leaves5
import NineSeparatedSubsetSums.Adaptive142Third140Leaves12
import NineSeparatedSubsetSums.Adaptive142Third140Leaves6
import NineSeparatedSubsetSums.Adaptive142Third140Leaves11
import NineSeparatedSubsetSums.Adaptive142Third140Leaves1

namespace NineSeparatedSubsetSums

theorem adaptive142Third140Proof237 : runCachedNode 511 130107 Adaptive142Third140Node237 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130107 Adaptive142Third140Node237 = [102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 132, 135, 136, 138] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive142Third140Proof238
  · exact adaptive142Third140Proof239
  · exact adaptive142Third140Proof240
  · exact adaptive142Third140Proof241
  · exact adaptive142Third140Proof242
  · exact adaptive142Third140Proof243
  · exact adaptive142Third140Proof244
  · exact adaptive142Third140Proof245
  · exact adaptive142Third140Proof246
  · exact adaptive142Third140Proof247
  · exact adaptive142Third140Proof248
  · exact adaptive142Third140Proof249
  · exact adaptive142Third140Proof250
  · exact adaptive142Third140Proof251
  · exact adaptive142Third140Proof252
  · exact adaptive142Third140Proof253
  · exact adaptive142Third140Proof254
  · exact adaptive142Third140Proof255
  · exact adaptive142Third140Proof256
  · exact adaptive142Third140Proof257
  · exact adaptive142Third140Proof258
  · exact adaptive142Third140Proof259
  · exact adaptive142Third140Proof260
  · exact adaptive142Third140Proof261
  · exact adaptive142Third140Proof262
  · exact adaptive142Third140Proof263
  · exact adaptive142Third140Proof264
  · exact adaptive142Third140Proof265
  · exact adaptive142Third140Proof266
  · exact adaptive142Third140Proof267
  · exact adaptive142Third140Proof268
  · exact adaptive142Third140Proof269
  · exact adaptive142Third140Proof270

#print axioms adaptive142Third140Proof237

theorem adaptive142Third140Proof0 : runCachedNode 511 130107 Adaptive142Third140Node0 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130107 Adaptive142Third140Node0 = [110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 132, 133, 135, 136, 137, 138, 139] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive142Third140Proof1
  · exact adaptive142Third140Proof2
  · exact adaptive142Third140Proof3
  · exact adaptive142Third140Proof4
  · exact adaptive142Third140Proof5
  · exact adaptive142Third140Proof6
  · exact adaptive142Third140Proof7
  · exact adaptive142Third140Proof8
  · exact adaptive142Third140Proof9
  · exact adaptive142Third140Proof10
  · exact adaptive142Third140Proof11
  · exact adaptive142Third140Proof12
  · exact adaptive142Third140Proof13
  · exact adaptive142Third140Proof14
  · exact adaptive142Third140Proof15
  · exact adaptive142Third140Proof16
  · exact adaptive142Third140Proof17
  · exact adaptive142Third140Proof18
  · exact adaptive142Third140Proof19
  · exact adaptive142Third140Proof20
  · exact adaptive142Third140Proof21
  · exact adaptive142Third140Proof22
  · exact adaptive142Third140Proof23
  · exact adaptive142Third140Proof50
  · exact adaptive142Third140Proof78
  · exact adaptive142Third140Proof107
  · exact adaptive142Third140Proof172
  · exact adaptive142Third140Proof204
  · exact adaptive142Third140Proof237

#print axioms adaptive142Third140Proof0

end NineSeparatedSubsetSums
