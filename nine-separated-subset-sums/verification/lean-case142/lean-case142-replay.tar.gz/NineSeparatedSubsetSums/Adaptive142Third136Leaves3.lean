import NineSeparatedSubsetSums.Adaptive142Third136State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third136Proof15 : runCachedNode 511 129404 Adaptive142Third136Node15 = false := by
  decide +kernel

#print axioms adaptive142Third136Proof15

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third136Proof88 : runCachedNode 511 129404 Adaptive142Third136Node88 = false := by
  decide +kernel

#print axioms adaptive142Third136Proof88

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third136Proof2 : runCachedNode 511 129404 Adaptive142Third136Node2 = false := by
  decide +kernel

#print axioms adaptive142Third136Proof2

end NineSeparatedSubsetSums
