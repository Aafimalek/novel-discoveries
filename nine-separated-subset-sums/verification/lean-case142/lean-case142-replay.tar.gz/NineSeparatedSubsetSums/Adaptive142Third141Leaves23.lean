import NineSeparatedSubsetSums.Adaptive142Third141State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third141Proof202 : runCachedNode 511 130276 Adaptive142Third141Node202 = false := by
  decide +kernel

#print axioms adaptive142Third141Proof202

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third141Proof49 : runCachedNode 511 130276 Adaptive142Third141Node49 = false := by
  decide +kernel

#print axioms adaptive142Third141Proof49

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third141Proof74 : runCachedNode 511 130276 Adaptive142Third141Node74 = false := by
  decide +kernel

#print axioms adaptive142Third141Proof74

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third141Proof306 : runCachedNode 511 130276 Adaptive142Third141Node306 = false := by
  decide +kernel

#print axioms adaptive142Third141Proof306

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third141Proof232 : runCachedNode 511 130276 Adaptive142Third141Node232 = false := by
  decide +kernel

#print axioms adaptive142Third141Proof232

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third141Proof423 : runCachedNode 511 130276 Adaptive142Third141Node423 = false := by
  decide +kernel

#print axioms adaptive142Third141Proof423

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third141Proof28 : runCachedNode 511 130276 Adaptive142Third141Node28 = false := by
  decide +kernel

#print axioms adaptive142Third141Proof28

end NineSeparatedSubsetSums
