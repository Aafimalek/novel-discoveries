import NineSeparatedSubsetSums.Adaptive142Third141State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third141Proof334 : runCachedNode 511 130276 Adaptive142Third141Node334 = false := by
  decide +kernel

#print axioms adaptive142Third141Proof334

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third141Proof96 : runCachedNode 511 130276 Adaptive142Third141Node96 = false := by
  decide +kernel

#print axioms adaptive142Third141Proof96

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third141Proof422 : runCachedNode 511 130276 Adaptive142Third141Node422 = false := by
  decide +kernel

#print axioms adaptive142Third141Proof422

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third141Proof171 : runCachedNode 511 130276 Adaptive142Third141Node171 = false := by
  decide +kernel

#print axioms adaptive142Third141Proof171

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third141Proof12 : runCachedNode 511 130276 Adaptive142Third141Node12 = false := by
  decide +kernel

#print axioms adaptive142Third141Proof12

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third141Proof333 : runCachedNode 511 130276 Adaptive142Third141Node333 = false := by
  decide +kernel

#print axioms adaptive142Third141Proof333

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third141Proof75 : runCachedNode 511 130276 Adaptive142Third141Node75 = false := by
  decide +kernel

#print axioms adaptive142Third141Proof75

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third141Proof229 : runCachedNode 511 130276 Adaptive142Third141Node229 = false := by
  decide +kernel

#print axioms adaptive142Third141Proof229

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third141Proof170 : runCachedNode 511 130276 Adaptive142Third141Node170 = false := by
  decide +kernel

#print axioms adaptive142Third141Proof170

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third141Proof27 : runCachedNode 511 130276 Adaptive142Third141Node27 = false := by
  decide +kernel

#print axioms adaptive142Third141Proof27

end NineSeparatedSubsetSums
