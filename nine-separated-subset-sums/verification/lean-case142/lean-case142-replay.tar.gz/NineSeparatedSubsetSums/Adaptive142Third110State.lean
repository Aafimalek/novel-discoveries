import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive142Third110Node0 : CachedSearchNode :=
  ⟨4, 109, computeCenteredMask [148,142,110], 400, 54168⟩

end NineSeparatedSubsetSums
