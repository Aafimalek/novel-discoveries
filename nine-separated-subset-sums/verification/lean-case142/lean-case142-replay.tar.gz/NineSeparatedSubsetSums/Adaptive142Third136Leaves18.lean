import NineSeparatedSubsetSums.Adaptive142Third136State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third136Proof58 : runCachedNode 511 129404 Adaptive142Third136Node58 = false := by
  decide +kernel

#print axioms adaptive142Third136Proof58

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third136Proof160 : runCachedNode 511 129404 Adaptive142Third136Node160 = false := by
  decide +kernel

#print axioms adaptive142Third136Proof160

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third136Proof162 : runCachedNode 511 129404 Adaptive142Third136Node162 = false := by
  decide +kernel

#print axioms adaptive142Third136Proof162

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third136Proof82 : runCachedNode 511 129404 Adaptive142Third136Node82 = false := by
  decide +kernel

#print axioms adaptive142Third136Proof82

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third136Proof60 : runCachedNode 511 129404 Adaptive142Third136Node60 = false := by
  decide +kernel

#print axioms adaptive142Third136Proof60

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third136Proof130 : runCachedNode 511 129404 Adaptive142Third136Node130 = false := by
  decide +kernel

#print axioms adaptive142Third136Proof130

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third136Proof161 : runCachedNode 511 129404 Adaptive142Third136Node161 = false := by
  decide +kernel

#print axioms adaptive142Third136Proof161

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third136Proof220 : runCachedNode 511 129404 Adaptive142Third136Node220 = false := by
  decide +kernel

#print axioms adaptive142Third136Proof220

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third136Proof132 : runCachedNode 511 129404 Adaptive142Third136Node132 = false := by
  decide +kernel

#print axioms adaptive142Third136Proof132

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third136Proof194 : runCachedNode 511 129404 Adaptive142Third136Node194 = false := by
  decide +kernel

#print axioms adaptive142Third136Proof194

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third136Proof83 : runCachedNode 511 129404 Adaptive142Third136Node83 = false := by
  decide +kernel

#print axioms adaptive142Third136Proof83

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third136Proof8 : runCachedNode 511 129404 Adaptive142Third136Node8 = false := by
  decide +kernel

#print axioms adaptive142Third136Proof8

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third136Proof131 : runCachedNode 511 129404 Adaptive142Third136Node131 = false := by
  decide +kernel

#print axioms adaptive142Third136Proof131

end NineSeparatedSubsetSums
