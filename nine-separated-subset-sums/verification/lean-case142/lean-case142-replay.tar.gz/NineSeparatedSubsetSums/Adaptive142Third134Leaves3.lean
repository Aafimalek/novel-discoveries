import NineSeparatedSubsetSums.Adaptive142Third134State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third134Proof19 : runCachedNode 511 129144 Adaptive142Third134Node19 = false := by
  decide +kernel

#print axioms adaptive142Third134Proof19

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third134Proof17 : runCachedNode 511 129144 Adaptive142Third134Node17 = false := by
  decide +kernel

#print axioms adaptive142Third134Proof17

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third134Proof33 : runCachedNode 511 129144 Adaptive142Third134Node33 = false := by
  decide +kernel

#print axioms adaptive142Third134Proof33

end NineSeparatedSubsetSums
