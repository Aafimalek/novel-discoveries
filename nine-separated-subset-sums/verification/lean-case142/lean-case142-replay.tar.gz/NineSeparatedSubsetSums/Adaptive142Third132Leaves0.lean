import NineSeparatedSubsetSums.Adaptive142Third132State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third132Proof21 : runCachedNode 511 128761 Adaptive142Third132Node21 = false := by
  decide +kernel

#print axioms adaptive142Third132Proof21

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third132Proof16 : runCachedNode 511 128761 Adaptive142Third132Node16 = false := by
  decide +kernel

#print axioms adaptive142Third132Proof16

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third132Proof6 : runCachedNode 511 128761 Adaptive142Third132Node6 = false := by
  decide +kernel

#print axioms adaptive142Third132Proof6

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third132Proof3 : runCachedNode 511 128761 Adaptive142Third132Node3 = false := by
  decide +kernel

#print axioms adaptive142Third132Proof3

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third132Proof1 : runCachedNode 511 128761 Adaptive142Third132Node1 = false := by
  decide +kernel

#print axioms adaptive142Third132Proof1

end NineSeparatedSubsetSums
