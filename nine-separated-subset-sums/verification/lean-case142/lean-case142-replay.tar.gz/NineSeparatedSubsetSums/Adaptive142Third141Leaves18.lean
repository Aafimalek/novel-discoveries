import NineSeparatedSubsetSums.Adaptive142Third141State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third141Proof17 : runCachedNode 511 130276 Adaptive142Third141Node17 = false := by
  decide +kernel

#print axioms adaptive142Third141Proof17

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third141Proof340 : runCachedNode 511 130276 Adaptive142Third141Node340 = false := by
  decide +kernel

#print axioms adaptive142Third141Proof340

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third141Proof235 : runCachedNode 511 130276 Adaptive142Third141Node235 = false := by
  decide +kernel

#print axioms adaptive142Third141Proof235

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third141Proof3 : runCachedNode 511 130276 Adaptive142Third141Node3 = false := by
  decide +kernel

#print axioms adaptive142Third141Proof3

end NineSeparatedSubsetSums
