import NineSeparatedSubsetSums.Adaptive142Third141State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third141Proof136 : runCachedNode 511 130276 Adaptive142Third141Node136 = false := by
  decide +kernel

#print axioms adaptive142Third141Proof136

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third141Proof308 : runCachedNode 511 130276 Adaptive142Third141Node308 = false := by
  decide +kernel

#print axioms adaptive142Third141Proof308

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third141Proof198 : runCachedNode 511 130276 Adaptive142Third141Node198 = false := by
  decide +kernel

#print axioms adaptive142Third141Proof198

end NineSeparatedSubsetSums
