import NineSeparatedSubsetSums.Adaptive142Third140State
import NineSeparatedSubsetSums.Adaptive142Third140Leaves20
import NineSeparatedSubsetSums.Adaptive142Third140Leaves23
import NineSeparatedSubsetSums.Adaptive142Third140Leaves31
import NineSeparatedSubsetSums.Adaptive142Third140Leaves30
import NineSeparatedSubsetSums.Adaptive142Third140Leaves27
import NineSeparatedSubsetSums.Adaptive142Third140Leaves6
import NineSeparatedSubsetSums.Adaptive142Third140Leaves13
import NineSeparatedSubsetSums.Adaptive142Third140Leaves29
import NineSeparatedSubsetSums.Adaptive142Third140Leaves14
import NineSeparatedSubsetSums.Adaptive142Third140Leaves28
import NineSeparatedSubsetSums.Adaptive142Third140Leaves26
import NineSeparatedSubsetSums.Adaptive142Third140Leaves25
import NineSeparatedSubsetSums.Adaptive142Third140Leaves21
import NineSeparatedSubsetSums.Adaptive142Third140Leaves22
import NineSeparatedSubsetSums.Adaptive142Third140Leaves16
import NineSeparatedSubsetSums.Adaptive142Third140Leaves8
import NineSeparatedSubsetSums.Adaptive142Third140Leaves2
import NineSeparatedSubsetSums.Adaptive142Third140Leaves10
import NineSeparatedSubsetSums.Adaptive142Third140Leaves12
import NineSeparatedSubsetSums.Adaptive142Third140Leaves19
import NineSeparatedSubsetSums.Adaptive142Third140Leaves24
import NineSeparatedSubsetSums.Adaptive142Third140Leaves11
import NineSeparatedSubsetSums.Adaptive142Third140Leaves32
import NineSeparatedSubsetSums.Adaptive142Third140Leaves1
import NineSeparatedSubsetSums.Adaptive142Third140Leaves15
import NineSeparatedSubsetSums.Adaptive142Third140Leaves18
import NineSeparatedSubsetSums.Adaptive142Third140Leaves4
import NineSeparatedSubsetSums.Adaptive142Third140Leaves3
import NineSeparatedSubsetSums.Adaptive142Third140Leaves0
import NineSeparatedSubsetSums.Adaptive142Third140Leaves9
import NineSeparatedSubsetSums.Adaptive142Third140Leaves17
import NineSeparatedSubsetSums.Adaptive142Third140Leaves7
import NineSeparatedSubsetSums.Adaptive142Third140Leaves5

namespace NineSeparatedSubsetSums

theorem adaptive142Third140Proof23 : runCachedNode 511 130107 Adaptive142Third140Node23 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130107 Adaptive142Third140Node23 = [103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 125, 127, 128, 129, 131] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive142Third140Proof24
  · exact adaptive142Third140Proof25
  · exact adaptive142Third140Proof26
  · exact adaptive142Third140Proof27
  · exact adaptive142Third140Proof28
  · exact adaptive142Third140Proof29
  · exact adaptive142Third140Proof30
  · exact adaptive142Third140Proof31
  · exact adaptive142Third140Proof32
  · exact adaptive142Third140Proof33
  · exact adaptive142Third140Proof34
  · exact adaptive142Third140Proof35
  · exact adaptive142Third140Proof36
  · exact adaptive142Third140Proof37
  · exact adaptive142Third140Proof38
  · exact adaptive142Third140Proof39
  · exact adaptive142Third140Proof40
  · exact adaptive142Third140Proof41
  · exact adaptive142Third140Proof42
  · exact adaptive142Third140Proof43
  · exact adaptive142Third140Proof44
  · exact adaptive142Third140Proof45
  · exact adaptive142Third140Proof46
  · exact adaptive142Third140Proof47
  · exact adaptive142Third140Proof48
  · exact adaptive142Third140Proof49

#print axioms adaptive142Third140Proof23

theorem adaptive142Third140Proof50 : runCachedNode 511 130107 Adaptive142Third140Node50 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130107 Adaptive142Third140Node50 = [103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 126, 128, 129, 130, 132] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive142Third140Proof51
  · exact adaptive142Third140Proof52
  · exact adaptive142Third140Proof53
  · exact adaptive142Third140Proof54
  · exact adaptive142Third140Proof55
  · exact adaptive142Third140Proof56
  · exact adaptive142Third140Proof57
  · exact adaptive142Third140Proof58
  · exact adaptive142Third140Proof59
  · exact adaptive142Third140Proof60
  · exact adaptive142Third140Proof61
  · exact adaptive142Third140Proof62
  · exact adaptive142Third140Proof63
  · exact adaptive142Third140Proof64
  · exact adaptive142Third140Proof65
  · exact adaptive142Third140Proof66
  · exact adaptive142Third140Proof67
  · exact adaptive142Third140Proof68
  · exact adaptive142Third140Proof69
  · exact adaptive142Third140Proof70
  · exact adaptive142Third140Proof71
  · exact adaptive142Third140Proof72
  · exact adaptive142Third140Proof73
  · exact adaptive142Third140Proof74
  · exact adaptive142Third140Proof75
  · exact adaptive142Third140Proof76
  · exact adaptive142Third140Proof77

#print axioms adaptive142Third140Proof50

theorem adaptive142Third140Proof78 : runCachedNode 511 130107 Adaptive142Third140Node78 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130107 Adaptive142Third140Node78 = [103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 128, 130, 131, 132] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive142Third140Proof79
  · exact adaptive142Third140Proof80
  · exact adaptive142Third140Proof81
  · exact adaptive142Third140Proof82
  · exact adaptive142Third140Proof83
  · exact adaptive142Third140Proof84
  · exact adaptive142Third140Proof85
  · exact adaptive142Third140Proof86
  · exact adaptive142Third140Proof87
  · exact adaptive142Third140Proof88
  · exact adaptive142Third140Proof89
  · exact adaptive142Third140Proof90
  · exact adaptive142Third140Proof91
  · exact adaptive142Third140Proof92
  · exact adaptive142Third140Proof93
  · exact adaptive142Third140Proof94
  · exact adaptive142Third140Proof95
  · exact adaptive142Third140Proof96
  · exact adaptive142Third140Proof97
  · exact adaptive142Third140Proof98
  · exact adaptive142Third140Proof99
  · exact adaptive142Third140Proof100
  · exact adaptive142Third140Proof101
  · exact adaptive142Third140Proof102
  · exact adaptive142Third140Proof103
  · exact adaptive142Third140Proof104
  · exact adaptive142Third140Proof105
  · exact adaptive142Third140Proof106

#print axioms adaptive142Third140Proof78

theorem adaptive142Third140Proof136 : runCachedNode 511 130107 Adaptive142Third140Node136 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130107 Adaptive142Third140Node136 = [92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 119, 121, 123, 125, 127, 129, 131] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive142Third140Proof137
  · exact adaptive142Third140Proof138
  · exact adaptive142Third140Proof139
  · exact adaptive142Third140Proof140
  · exact adaptive142Third140Proof141
  · exact adaptive142Third140Proof142
  · exact adaptive142Third140Proof143
  · exact adaptive142Third140Proof144
  · exact adaptive142Third140Proof145
  · exact adaptive142Third140Proof146
  · exact adaptive142Third140Proof147
  · exact adaptive142Third140Proof148
  · exact adaptive142Third140Proof149
  · exact adaptive142Third140Proof150
  · exact adaptive142Third140Proof151
  · exact adaptive142Third140Proof152
  · exact adaptive142Third140Proof153
  · exact adaptive142Third140Proof154
  · exact adaptive142Third140Proof155
  · exact adaptive142Third140Proof156
  · exact adaptive142Third140Proof157
  · exact adaptive142Third140Proof158
  · exact adaptive142Third140Proof159
  · exact adaptive142Third140Proof160
  · exact adaptive142Third140Proof161
  · exact adaptive142Third140Proof162
  · exact adaptive142Third140Proof163
  · exact adaptive142Third140Proof164
  · exact adaptive142Third140Proof165
  · exact adaptive142Third140Proof166
  · exact adaptive142Third140Proof167
  · exact adaptive142Third140Proof168
  · exact adaptive142Third140Proof169

#print axioms adaptive142Third140Proof136

theorem adaptive142Third140Proof107 : runCachedNode 511 130107 Adaptive142Third140Node107 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130107 Adaptive142Third140Node107 = [102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 129, 131, 132, 133, 135] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive142Third140Proof108
  · exact adaptive142Third140Proof109
  · exact adaptive142Third140Proof110
  · exact adaptive142Third140Proof111
  · exact adaptive142Third140Proof112
  · exact adaptive142Third140Proof113
  · exact adaptive142Third140Proof114
  · exact adaptive142Third140Proof115
  · exact adaptive142Third140Proof116
  · exact adaptive142Third140Proof117
  · exact adaptive142Third140Proof118
  · exact adaptive142Third140Proof119
  · exact adaptive142Third140Proof120
  · exact adaptive142Third140Proof121
  · exact adaptive142Third140Proof122
  · exact adaptive142Third140Proof123
  · exact adaptive142Third140Proof124
  · exact adaptive142Third140Proof125
  · exact adaptive142Third140Proof126
  · exact adaptive142Third140Proof127
  · exact adaptive142Third140Proof128
  · exact adaptive142Third140Proof129
  · exact adaptive142Third140Proof130
  · exact adaptive142Third140Proof131
  · exact adaptive142Third140Proof132
  · exact adaptive142Third140Proof133
  · exact adaptive142Third140Proof134
  · exact adaptive142Third140Proof135
  · exact adaptive142Third140Proof136
  · exact adaptive142Third140Proof170
  · exact adaptive142Third140Proof171

#print axioms adaptive142Third140Proof107

theorem adaptive142Third140Proof172 : runCachedNode 511 130107 Adaptive142Third140Node172 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130107 Adaptive142Third140Node172 = [102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 130, 132, 133, 136] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive142Third140Proof173
  · exact adaptive142Third140Proof174
  · exact adaptive142Third140Proof175
  · exact adaptive142Third140Proof176
  · exact adaptive142Third140Proof177
  · exact adaptive142Third140Proof178
  · exact adaptive142Third140Proof179
  · exact adaptive142Third140Proof180
  · exact adaptive142Third140Proof181
  · exact adaptive142Third140Proof182
  · exact adaptive142Third140Proof183
  · exact adaptive142Third140Proof184
  · exact adaptive142Third140Proof185
  · exact adaptive142Third140Proof186
  · exact adaptive142Third140Proof187
  · exact adaptive142Third140Proof188
  · exact adaptive142Third140Proof189
  · exact adaptive142Third140Proof190
  · exact adaptive142Third140Proof191
  · exact adaptive142Third140Proof192
  · exact adaptive142Third140Proof193
  · exact adaptive142Third140Proof194
  · exact adaptive142Third140Proof195
  · exact adaptive142Third140Proof196
  · exact adaptive142Third140Proof197
  · exact adaptive142Third140Proof198
  · exact adaptive142Third140Proof199
  · exact adaptive142Third140Proof200
  · exact adaptive142Third140Proof201
  · exact adaptive142Third140Proof202
  · exact adaptive142Third140Proof203

#print axioms adaptive142Third140Proof172

theorem adaptive142Third140Proof204 : runCachedNode 511 130107 Adaptive142Third140Node204 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130107 Adaptive142Third140Node204 = [102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 131, 133, 135, 137] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive142Third140Proof205
  · exact adaptive142Third140Proof206
  · exact adaptive142Third140Proof207
  · exact adaptive142Third140Proof208
  · exact adaptive142Third140Proof209
  · exact adaptive142Third140Proof210
  · exact adaptive142Third140Proof211
  · exact adaptive142Third140Proof212
  · exact adaptive142Third140Proof213
  · exact adaptive142Third140Proof214
  · exact adaptive142Third140Proof215
  · exact adaptive142Third140Proof216
  · exact adaptive142Third140Proof217
  · exact adaptive142Third140Proof218
  · exact adaptive142Third140Proof219
  · exact adaptive142Third140Proof220
  · exact adaptive142Third140Proof221
  · exact adaptive142Third140Proof222
  · exact adaptive142Third140Proof223
  · exact adaptive142Third140Proof224
  · exact adaptive142Third140Proof225
  · exact adaptive142Third140Proof226
  · exact adaptive142Third140Proof227
  · exact adaptive142Third140Proof228
  · exact adaptive142Third140Proof229
  · exact adaptive142Third140Proof230
  · exact adaptive142Third140Proof231
  · exact adaptive142Third140Proof232
  · exact adaptive142Third140Proof233
  · exact adaptive142Third140Proof234
  · exact adaptive142Third140Proof235
  · exact adaptive142Third140Proof236

#print axioms adaptive142Third140Proof204

theorem adaptive142Third140Proof270 : runCachedNode 511 130107 Adaptive142Third140Node270 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130107 Adaptive142Third140Node270 = [89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 128] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive142Third140Proof271
  · exact adaptive142Third140Proof272
  · exact adaptive142Third140Proof273
  · exact adaptive142Third140Proof274
  · exact adaptive142Third140Proof275
  · exact adaptive142Third140Proof276
  · exact adaptive142Third140Proof277
  · exact adaptive142Third140Proof278
  · exact adaptive142Third140Proof279
  · exact adaptive142Third140Proof280
  · exact adaptive142Third140Proof281
  · exact adaptive142Third140Proof282
  · exact adaptive142Third140Proof283
  · exact adaptive142Third140Proof284
  · exact adaptive142Third140Proof285
  · exact adaptive142Third140Proof286
  · exact adaptive142Third140Proof287
  · exact adaptive142Third140Proof288
  · exact adaptive142Third140Proof289
  · exact adaptive142Third140Proof290
  · exact adaptive142Third140Proof291
  · exact adaptive142Third140Proof292
  · exact adaptive142Third140Proof293
  · exact adaptive142Third140Proof294
  · exact adaptive142Third140Proof295
  · exact adaptive142Third140Proof296
  · exact adaptive142Third140Proof297
  · exact adaptive142Third140Proof298
  · exact adaptive142Third140Proof299
  · exact adaptive142Third140Proof300
  · exact adaptive142Third140Proof301
  · exact adaptive142Third140Proof302
  · exact adaptive142Third140Proof303
  · exact adaptive142Third140Proof304
  · exact adaptive142Third140Proof305
  · exact adaptive142Third140Proof306
  · exact adaptive142Third140Proof307
  · exact adaptive142Third140Proof308
  · exact adaptive142Third140Proof309

#print axioms adaptive142Third140Proof270

end NineSeparatedSubsetSums
