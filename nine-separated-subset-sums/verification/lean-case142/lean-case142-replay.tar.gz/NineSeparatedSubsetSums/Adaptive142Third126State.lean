import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive142Third126Node0 : CachedSearchNode :=
  ⟨4, 125, computeCenteredMask [148,142,126], 416, 57944⟩

end NineSeparatedSubsetSums
