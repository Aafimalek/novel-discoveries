import NineSeparatedSubsetSums.Adaptive142Third136State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third136Proof107 : runCachedNode 511 129404 Adaptive142Third136Node107 = false := by
  decide +kernel

#print axioms adaptive142Third136Proof107

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third136Proof62 : runCachedNode 511 129404 Adaptive142Third136Node62 = false := by
  decide +kernel

#print axioms adaptive142Third136Proof62

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third136Proof110 : runCachedNode 511 129404 Adaptive142Third136Node110 = false := by
  decide +kernel

#print axioms adaptive142Third136Proof110

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third136Proof226 : runCachedNode 511 129404 Adaptive142Third136Node226 = false := by
  decide +kernel

#print axioms adaptive142Third136Proof226

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third136Proof198 : runCachedNode 511 129404 Adaptive142Third136Node198 = false := by
  decide +kernel

#print axioms adaptive142Third136Proof198

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third136Proof86 : runCachedNode 511 129404 Adaptive142Third136Node86 = false := by
  decide +kernel

#print axioms adaptive142Third136Proof86

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third136Proof192 : runCachedNode 511 129404 Adaptive142Third136Node192 = false := by
  decide +kernel

#print axioms adaptive142Third136Proof192

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third136Proof67 : runCachedNode 511 129404 Adaptive142Third136Node67 = false := by
  decide +kernel

#print axioms adaptive142Third136Proof67

end NineSeparatedSubsetSums
