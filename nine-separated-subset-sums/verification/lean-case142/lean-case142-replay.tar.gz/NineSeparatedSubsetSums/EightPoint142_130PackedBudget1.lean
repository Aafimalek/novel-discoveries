import NineSeparatedSubsetSums.EightPoint142_130PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct142_130_1_budget :
    FourPointNumeric.packedBudget 20 packedOct142_130_1 500 = 88589434 := by decide +kernel

#print axioms packedOct142_130_1_budget

end NineSeparatedSubsetSums
