import NineSeparatedSubsetSums.Adaptive142Third129State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third129Proof17 : runCachedNode 511 128104 Adaptive142Third129Node17 = false := by
  decide +kernel

#print axioms adaptive142Third129Proof17

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third129Proof16 : runCachedNode 511 128104 Adaptive142Third129Node16 = false := by
  decide +kernel

#print axioms adaptive142Third129Proof16

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third129Proof15 : runCachedNode 511 128104 Adaptive142Third129Node15 = false := by
  decide +kernel

#print axioms adaptive142Third129Proof15

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third129Proof6 : runCachedNode 511 128104 Adaptive142Third129Node6 = false := by
  decide +kernel

#print axioms adaptive142Third129Proof6

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third129Proof3 : runCachedNode 511 128104 Adaptive142Third129Node3 = false := by
  decide +kernel

#print axioms adaptive142Third129Proof3

end NineSeparatedSubsetSums
