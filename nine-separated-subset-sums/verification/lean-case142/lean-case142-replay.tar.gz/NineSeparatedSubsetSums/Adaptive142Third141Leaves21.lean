import NineSeparatedSubsetSums.Adaptive142Third141State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third141Proof131 : runCachedNode 511 130276 Adaptive142Third141Node131 = false := by
  decide +kernel

#print axioms adaptive142Third141Proof131

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third141Proof15 : runCachedNode 511 130276 Adaptive142Third141Node15 = false := by
  decide +kernel

#print axioms adaptive142Third141Proof15

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third141Proof336 : runCachedNode 511 130276 Adaptive142Third141Node336 = false := by
  decide +kernel

#print axioms adaptive142Third141Proof336

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third141Proof129 : runCachedNode 511 130276 Adaptive142Third141Node129 = false := by
  decide +kernel

#print axioms adaptive142Third141Proof129

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third141Proof97 : runCachedNode 511 130276 Adaptive142Third141Node97 = false := by
  decide +kernel

#print axioms adaptive142Third141Proof97

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third141Proof210 : runCachedNode 511 130276 Adaptive142Third141Node210 = false := by
  decide +kernel

#print axioms adaptive142Third141Proof210

end NineSeparatedSubsetSums
