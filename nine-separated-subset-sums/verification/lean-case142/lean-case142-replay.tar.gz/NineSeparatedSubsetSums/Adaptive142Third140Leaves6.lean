import NineSeparatedSubsetSums.Adaptive142Third140State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third140Proof20 : runCachedNode 511 130107 Adaptive142Third140Node20 = false := by
  decide +kernel

#print axioms adaptive142Third140Proof20

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third140Proof132 : runCachedNode 511 130107 Adaptive142Third140Node132 = false := by
  decide +kernel

#print axioms adaptive142Third140Proof132

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third140Proof31 : runCachedNode 511 130107 Adaptive142Third140Node31 = false := by
  decide +kernel

#print axioms adaptive142Third140Proof31

end NineSeparatedSubsetSums
