import NineSeparatedSubsetSums.EightPoint142_128PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint142_128PackedAnchor0Part1 :
    ∀ j : Fin 120, 2377055 ≤ FourPointNumeric.octPackedCharge 142 128 20 packedOct142_128_0
      (2*((j.val : Int)+120)+0) := by decide +kernel

end NineSeparatedSubsetSums
