import NineSeparatedSubsetSums.EightPoint142_122PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint142_122PackedAnchor0Part2 :
    ∀ j : Fin 1, 2303472 ≤ FourPointNumeric.octPackedCharge 142 122 20 packedOct142_122_0
      (2*((j.val : Int)+240)+0) := by decide +kernel

end NineSeparatedSubsetSums
