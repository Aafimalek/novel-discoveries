import NineSeparatedSubsetSums.EightPoint142_128PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint142_128PackedAnchor1Part2 :
    ∀ j : Fin 4, 2376280 ≤ FourPointNumeric.octPackedCharge 142 128 20 packedOct142_128_1
      (2*((j.val : Int)+240)+1) := by decide +kernel

end NineSeparatedSubsetSums
