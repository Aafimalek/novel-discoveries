import NineSeparatedSubsetSums.Adaptive142Third141State
import NineSeparatedSubsetSums.Adaptive142Third141Leaves8
import NineSeparatedSubsetSums.Adaptive142Third141Leaves6
import NineSeparatedSubsetSums.Adaptive142Third141Leaves0
import NineSeparatedSubsetSums.Adaptive142Third141Leaves26
import NineSeparatedSubsetSums.Adaptive142Third141Leaves23
import NineSeparatedSubsetSums.Adaptive142Third141Leaves35
import NineSeparatedSubsetSums.Adaptive142Third141Leaves34
import NineSeparatedSubsetSums.Adaptive142Third141Leaves33
import NineSeparatedSubsetSums.Adaptive142Third141Leaves32
import NineSeparatedSubsetSums.Adaptive142Third141Leaves1
import NineSeparatedSubsetSums.Adaptive142Third141Leaves31
import NineSeparatedSubsetSums.Adaptive142Third141Leaves30
import NineSeparatedSubsetSums.Adaptive142Third141Leaves29
import NineSeparatedSubsetSums.Adaptive142Third141Leaves28
import NineSeparatedSubsetSums.Adaptive142Third141Leaves27
import NineSeparatedSubsetSums.Adaptive142Third141Leaves24
import NineSeparatedSubsetSums.Adaptive142Third141Leaves20
import NineSeparatedSubsetSums.Adaptive142Third141Leaves11
import NineSeparatedSubsetSums.Adaptive142Third141Leaves15
import NineSeparatedSubsetSums.Adaptive142Third141Leaves22
import NineSeparatedSubsetSums.Adaptive142Third141Leaves25
import NineSeparatedSubsetSums.Adaptive142Third141Leaves2
import NineSeparatedSubsetSums.Adaptive142Third141Leaves19
import NineSeparatedSubsetSums.Adaptive142Third141Leaves21
import NineSeparatedSubsetSums.Adaptive142Third141Leaves16
import NineSeparatedSubsetSums.Adaptive142Third141Leaves10
import NineSeparatedSubsetSums.Adaptive142Third141Leaves36
import NineSeparatedSubsetSums.Adaptive142Third141Leaves3
import NineSeparatedSubsetSums.Adaptive142Third141Leaves17
import NineSeparatedSubsetSums.Adaptive142Third141Leaves4
import NineSeparatedSubsetSums.Adaptive142Third141Leaves12
import NineSeparatedSubsetSums.Adaptive142Third141Leaves7
import NineSeparatedSubsetSums.Adaptive142Third141Leaves13
import NineSeparatedSubsetSums.Adaptive142Third141Leaves37
import NineSeparatedSubsetSums.Adaptive142Third141Leaves5
import NineSeparatedSubsetSums.Adaptive142Third141Leaves18
import NineSeparatedSubsetSums.Adaptive142Third141Leaves9

namespace NineSeparatedSubsetSums

theorem adaptive142Third141Proof23 : runCachedNode 511 130276 Adaptive142Third141Node23 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130276 Adaptive142Third141Node23 = [103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 127, 128, 129, 130] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive142Third141Proof24
  · exact adaptive142Third141Proof25
  · exact adaptive142Third141Proof26
  · exact adaptive142Third141Proof27
  · exact adaptive142Third141Proof28
  · exact adaptive142Third141Proof29
  · exact adaptive142Third141Proof30
  · exact adaptive142Third141Proof31
  · exact adaptive142Third141Proof32
  · exact adaptive142Third141Proof33
  · exact adaptive142Third141Proof34
  · exact adaptive142Third141Proof35
  · exact adaptive142Third141Proof36
  · exact adaptive142Third141Proof37
  · exact adaptive142Third141Proof38
  · exact adaptive142Third141Proof39
  · exact adaptive142Third141Proof40
  · exact adaptive142Third141Proof41
  · exact adaptive142Third141Proof42
  · exact adaptive142Third141Proof43
  · exact adaptive142Third141Proof44
  · exact adaptive142Third141Proof45
  · exact adaptive142Third141Proof46
  · exact adaptive142Third141Proof47
  · exact adaptive142Third141Proof48
  · exact adaptive142Third141Proof49

#print axioms adaptive142Third141Proof23

theorem adaptive142Third141Proof50 : runCachedNode 511 130276 Adaptive142Third141Node50 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130276 Adaptive142Third141Node50 = [103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 128, 129, 130, 131] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive142Third141Proof51
  · exact adaptive142Third141Proof52
  · exact adaptive142Third141Proof53
  · exact adaptive142Third141Proof54
  · exact adaptive142Third141Proof55
  · exact adaptive142Third141Proof56
  · exact adaptive142Third141Proof57
  · exact adaptive142Third141Proof58
  · exact adaptive142Third141Proof59
  · exact adaptive142Third141Proof60
  · exact adaptive142Third141Proof61
  · exact adaptive142Third141Proof62
  · exact adaptive142Third141Proof63
  · exact adaptive142Third141Proof64
  · exact adaptive142Third141Proof65
  · exact adaptive142Third141Proof66
  · exact adaptive142Third141Proof67
  · exact adaptive142Third141Proof68
  · exact adaptive142Third141Proof69
  · exact adaptive142Third141Proof70
  · exact adaptive142Third141Proof71
  · exact adaptive142Third141Proof72
  · exact adaptive142Third141Proof73
  · exact adaptive142Third141Proof74
  · exact adaptive142Third141Proof75
  · exact adaptive142Third141Proof76
  · exact adaptive142Third141Proof77

#print axioms adaptive142Third141Proof50

theorem adaptive142Third141Proof78 : runCachedNode 511 130276 Adaptive142Third141Node78 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130276 Adaptive142Third141Node78 = [103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 129, 130, 131, 132] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive142Third141Proof79
  · exact adaptive142Third141Proof80
  · exact adaptive142Third141Proof81
  · exact adaptive142Third141Proof82
  · exact adaptive142Third141Proof83
  · exact adaptive142Third141Proof84
  · exact adaptive142Third141Proof85
  · exact adaptive142Third141Proof86
  · exact adaptive142Third141Proof87
  · exact adaptive142Third141Proof88
  · exact adaptive142Third141Proof89
  · exact adaptive142Third141Proof90
  · exact adaptive142Third141Proof91
  · exact adaptive142Third141Proof92
  · exact adaptive142Third141Proof93
  · exact adaptive142Third141Proof94
  · exact adaptive142Third141Proof95
  · exact adaptive142Third141Proof96
  · exact adaptive142Third141Proof97
  · exact adaptive142Third141Proof98
  · exact adaptive142Third141Proof99
  · exact adaptive142Third141Proof100
  · exact adaptive142Third141Proof101
  · exact adaptive142Third141Proof102
  · exact adaptive142Third141Proof103
  · exact adaptive142Third141Proof104
  · exact adaptive142Third141Proof105
  · exact adaptive142Third141Proof106

#print axioms adaptive142Third141Proof78

theorem adaptive142Third141Proof138 : runCachedNode 511 130276 Adaptive142Third141Node138 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130276 Adaptive142Third141Node138 = [91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 124, 125, 126, 131, 132] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive142Third141Proof139
  · exact adaptive142Third141Proof140
  · exact adaptive142Third141Proof141
  · exact adaptive142Third141Proof142
  · exact adaptive142Third141Proof143
  · exact adaptive142Third141Proof144
  · exact adaptive142Third141Proof145
  · exact adaptive142Third141Proof146
  · exact adaptive142Third141Proof147
  · exact adaptive142Third141Proof148
  · exact adaptive142Third141Proof149
  · exact adaptive142Third141Proof150
  · exact adaptive142Third141Proof151
  · exact adaptive142Third141Proof152
  · exact adaptive142Third141Proof153
  · exact adaptive142Third141Proof154
  · exact adaptive142Third141Proof155
  · exact adaptive142Third141Proof156
  · exact adaptive142Third141Proof157
  · exact adaptive142Third141Proof158
  · exact adaptive142Third141Proof159
  · exact adaptive142Third141Proof160
  · exact adaptive142Third141Proof161
  · exact adaptive142Third141Proof162
  · exact adaptive142Third141Proof163
  · exact adaptive142Third141Proof164
  · exact adaptive142Third141Proof165
  · exact adaptive142Third141Proof166
  · exact adaptive142Third141Proof167
  · exact adaptive142Third141Proof168
  · exact adaptive142Third141Proof169
  · exact adaptive142Third141Proof170
  · exact adaptive142Third141Proof171
  · exact adaptive142Third141Proof172
  · exact adaptive142Third141Proof173

#print axioms adaptive142Third141Proof138

theorem adaptive142Third141Proof107 : runCachedNode 511 130276 Adaptive142Third141Node107 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130276 Adaptive142Third141Node107 = [102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 131, 132, 133, 134] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive142Third141Proof108
  · exact adaptive142Third141Proof109
  · exact adaptive142Third141Proof110
  · exact adaptive142Third141Proof111
  · exact adaptive142Third141Proof112
  · exact adaptive142Third141Proof113
  · exact adaptive142Third141Proof114
  · exact adaptive142Third141Proof115
  · exact adaptive142Third141Proof116
  · exact adaptive142Third141Proof117
  · exact adaptive142Third141Proof118
  · exact adaptive142Third141Proof119
  · exact adaptive142Third141Proof120
  · exact adaptive142Third141Proof121
  · exact adaptive142Third141Proof122
  · exact adaptive142Third141Proof123
  · exact adaptive142Third141Proof124
  · exact adaptive142Third141Proof125
  · exact adaptive142Third141Proof126
  · exact adaptive142Third141Proof127
  · exact adaptive142Third141Proof128
  · exact adaptive142Third141Proof129
  · exact adaptive142Third141Proof130
  · exact adaptive142Third141Proof131
  · exact adaptive142Third141Proof132
  · exact adaptive142Third141Proof133
  · exact adaptive142Third141Proof134
  · exact adaptive142Third141Proof135
  · exact adaptive142Third141Proof136
  · exact adaptive142Third141Proof137
  · exact adaptive142Third141Proof138

#print axioms adaptive142Third141Proof107

theorem adaptive142Third141Proof174 : runCachedNode 511 130276 Adaptive142Third141Node174 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130276 Adaptive142Third141Node174 = [102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 132, 133, 134] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive142Third141Proof175
  · exact adaptive142Third141Proof176
  · exact adaptive142Third141Proof177
  · exact adaptive142Third141Proof178
  · exact adaptive142Third141Proof179
  · exact adaptive142Third141Proof180
  · exact adaptive142Third141Proof181
  · exact adaptive142Third141Proof182
  · exact adaptive142Third141Proof183
  · exact adaptive142Third141Proof184
  · exact adaptive142Third141Proof185
  · exact adaptive142Third141Proof186
  · exact adaptive142Third141Proof187
  · exact adaptive142Third141Proof188
  · exact adaptive142Third141Proof189
  · exact adaptive142Third141Proof190
  · exact adaptive142Third141Proof191
  · exact adaptive142Third141Proof192
  · exact adaptive142Third141Proof193
  · exact adaptive142Third141Proof194
  · exact adaptive142Third141Proof195
  · exact adaptive142Third141Proof196
  · exact adaptive142Third141Proof197
  · exact adaptive142Third141Proof198
  · exact adaptive142Third141Proof199
  · exact adaptive142Third141Proof200
  · exact adaptive142Third141Proof201
  · exact adaptive142Third141Proof202
  · exact adaptive142Third141Proof203
  · exact adaptive142Third141Proof204
  · exact adaptive142Third141Proof205

#print axioms adaptive142Third141Proof174

theorem adaptive142Third141Proof238 : runCachedNode 511 130276 Adaptive142Third141Node238 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130276 Adaptive142Third141Node238 = [90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 128, 134] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive142Third141Proof239
  · exact adaptive142Third141Proof240
  · exact adaptive142Third141Proof241
  · exact adaptive142Third141Proof242
  · exact adaptive142Third141Proof243
  · exact adaptive142Third141Proof244
  · exact adaptive142Third141Proof245
  · exact adaptive142Third141Proof246
  · exact adaptive142Third141Proof247
  · exact adaptive142Third141Proof248
  · exact adaptive142Third141Proof249
  · exact adaptive142Third141Proof250
  · exact adaptive142Third141Proof251
  · exact adaptive142Third141Proof252
  · exact adaptive142Third141Proof253
  · exact adaptive142Third141Proof254
  · exact adaptive142Third141Proof255
  · exact adaptive142Third141Proof256
  · exact adaptive142Third141Proof257
  · exact adaptive142Third141Proof258
  · exact adaptive142Third141Proof259
  · exact adaptive142Third141Proof260
  · exact adaptive142Third141Proof261
  · exact adaptive142Third141Proof262
  · exact adaptive142Third141Proof263
  · exact adaptive142Third141Proof264
  · exact adaptive142Third141Proof265
  · exact adaptive142Third141Proof266
  · exact adaptive142Third141Proof267
  · exact adaptive142Third141Proof268
  · exact adaptive142Third141Proof269
  · exact adaptive142Third141Proof270
  · exact adaptive142Third141Proof271
  · exact adaptive142Third141Proof272
  · exact adaptive142Third141Proof273
  · exact adaptive142Third141Proof274
  · exact adaptive142Third141Proof275

#print axioms adaptive142Third141Proof238

theorem adaptive142Third141Proof206 : runCachedNode 511 130276 Adaptive142Third141Node206 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130276 Adaptive142Third141Node206 = [102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 133, 134, 136] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive142Third141Proof207
  · exact adaptive142Third141Proof208
  · exact adaptive142Third141Proof209
  · exact adaptive142Third141Proof210
  · exact adaptive142Third141Proof211
  · exact adaptive142Third141Proof212
  · exact adaptive142Third141Proof213
  · exact adaptive142Third141Proof214
  · exact adaptive142Third141Proof215
  · exact adaptive142Third141Proof216
  · exact adaptive142Third141Proof217
  · exact adaptive142Third141Proof218
  · exact adaptive142Third141Proof219
  · exact adaptive142Third141Proof220
  · exact adaptive142Third141Proof221
  · exact adaptive142Third141Proof222
  · exact adaptive142Third141Proof223
  · exact adaptive142Third141Proof224
  · exact adaptive142Third141Proof225
  · exact adaptive142Third141Proof226
  · exact adaptive142Third141Proof227
  · exact adaptive142Third141Proof228
  · exact adaptive142Third141Proof229
  · exact adaptive142Third141Proof230
  · exact adaptive142Third141Proof231
  · exact adaptive142Third141Proof232
  · exact adaptive142Third141Proof233
  · exact adaptive142Third141Proof234
  · exact adaptive142Third141Proof235
  · exact adaptive142Third141Proof236
  · exact adaptive142Third141Proof237
  · exact adaptive142Third141Proof238

#print axioms adaptive142Third141Proof206

end NineSeparatedSubsetSums
