import NineSeparatedSubsetSums.Adaptive142Third108Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint142Checked

namespace NineSeparatedSubsetSums


theorem adaptive142Third108 : NoDescendingTailAfterThird 142 108 :=
  noDescendingThirdTail_of_cached 142 108 111874 (fun t ht nd => max148_second142_fourPoint_moment_bound (108::t) (by simp [ht]) nd) adaptive142Third108Proof0

#print axioms adaptive142Third108

end NineSeparatedSubsetSums
