import NineSeparatedSubsetSums.Adaptive142Third136State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third136Proof201 : runCachedNode 511 129404 Adaptive142Third136Node201 = false := by
  decide +kernel

#print axioms adaptive142Third136Proof201

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third136Proof230 : runCachedNode 511 129404 Adaptive142Third136Node230 = false := by
  decide +kernel

#print axioms adaptive142Third136Proof230

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third136Proof103 : runCachedNode 511 129404 Adaptive142Third136Node103 = false := by
  decide +kernel

#print axioms adaptive142Third136Proof103

end NineSeparatedSubsetSums
