import NineSeparatedSubsetSums.Adaptive142Third130State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third130Proof6 : runCachedNode 511 128359 Adaptive142Third130Node6 = false := by
  decide +kernel

#print axioms adaptive142Third130Proof6

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third130Proof5 : runCachedNode 511 128359 Adaptive142Third130Node5 = false := by
  decide +kernel

#print axioms adaptive142Third130Proof5

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third130Proof4 : runCachedNode 511 128359 Adaptive142Third130Node4 = false := by
  decide +kernel

#print axioms adaptive142Third130Proof4

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third130Proof3 : runCachedNode 511 128359 Adaptive142Third130Node3 = false := by
  decide +kernel

#print axioms adaptive142Third130Proof3

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third130Proof2 : runCachedNode 511 128359 Adaptive142Third130Node2 = false := by
  decide +kernel

#print axioms adaptive142Third130Proof2

end NineSeparatedSubsetSums
