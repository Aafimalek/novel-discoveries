import NineSeparatedSubsetSums.Adaptive142Third140State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third140Proof229 : runCachedNode 511 130107 Adaptive142Third140Node229 = false := by
  decide +kernel

#print axioms adaptive142Third140Proof229

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third140Proof106 : runCachedNode 511 130107 Adaptive142Third140Node106 = false := by
  decide +kernel

#print axioms adaptive142Third140Proof106

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third140Proof91 : runCachedNode 511 130107 Adaptive142Third140Node91 = false := by
  decide +kernel

#print axioms adaptive142Third140Proof91

end NineSeparatedSubsetSums
