import NineSeparatedSubsetSums.Adaptive142Third140State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third140Proof77 : runCachedNode 511 130107 Adaptive142Third140Node77 = false := by
  decide +kernel

#print axioms adaptive142Third140Proof77

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third140Proof17 : runCachedNode 511 130107 Adaptive142Third140Node17 = false := by
  decide +kernel

#print axioms adaptive142Third140Proof17

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third140Proof62 : runCachedNode 511 130107 Adaptive142Third140Node62 = false := by
  decide +kernel

#print axioms adaptive142Third140Proof62

end NineSeparatedSubsetSums
