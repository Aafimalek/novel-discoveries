import NineSeparatedSubsetSums.Adaptive142Third138State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third138Proof77 : runCachedNode 511 129778 Adaptive142Third138Node77 = false := by
  decide +kernel

#print axioms adaptive142Third138Proof77

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third138Proof76 : runCachedNode 511 129778 Adaptive142Third138Node76 = false := by
  decide +kernel

#print axioms adaptive142Third138Proof76

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third138Proof135 : runCachedNode 511 129778 Adaptive142Third138Node135 = false := by
  decide +kernel

#print axioms adaptive142Third138Proof135

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third138Proof2 : runCachedNode 511 129778 Adaptive142Third138Node2 = false := by
  decide +kernel

#print axioms adaptive142Third138Proof2

end NineSeparatedSubsetSums
