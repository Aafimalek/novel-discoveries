import NineSeparatedSubsetSums.Adaptive142Third140State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third140Proof14 : runCachedNode 511 130107 Adaptive142Third140Node14 = false := by
  decide +kernel

#print axioms adaptive142Third140Proof14

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third140Proof43 : runCachedNode 511 130107 Adaptive142Third140Node43 = false := by
  decide +kernel

#print axioms adaptive142Third140Proof43

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third140Proof228 : runCachedNode 511 130107 Adaptive142Third140Node228 = false := by
  decide +kernel

#print axioms adaptive142Third140Proof228

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third140Proof133 : runCachedNode 511 130107 Adaptive142Third140Node133 = false := by
  decide +kernel

#print axioms adaptive142Third140Proof133

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third140Proof167 : runCachedNode 511 130107 Adaptive142Third140Node167 = false := by
  decide +kernel

#print axioms adaptive142Third140Proof167

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third140Proof71 : runCachedNode 511 130107 Adaptive142Third140Node71 = false := by
  decide +kernel

#print axioms adaptive142Third140Proof71

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third140Proof57 : runCachedNode 511 130107 Adaptive142Third140Node57 = false := by
  decide +kernel

#print axioms adaptive142Third140Proof57

end NineSeparatedSubsetSums
