import NineSeparatedSubsetSums.Adaptive142Third140State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third140Proof157 : runCachedNode 511 130107 Adaptive142Third140Node157 = false := by
  decide +kernel

#print axioms adaptive142Third140Proof157

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third140Proof223 : runCachedNode 511 130107 Adaptive142Third140Node223 = false := by
  decide +kernel

#print axioms adaptive142Third140Proof223

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third140Proof224 : runCachedNode 511 130107 Adaptive142Third140Node224 = false := by
  decide +kernel

#print axioms adaptive142Third140Proof224

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third140Proof129 : runCachedNode 511 130107 Adaptive142Third140Node129 = false := by
  decide +kernel

#print axioms adaptive142Third140Proof129

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third140Proof261 : runCachedNode 511 130107 Adaptive142Third140Node261 = false := by
  decide +kernel

#print axioms adaptive142Third140Proof261

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third140Proof305 : runCachedNode 511 130107 Adaptive142Third140Node305 = false := by
  decide +kernel

#print axioms adaptive142Third140Proof305

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third140Proof101 : runCachedNode 511 130107 Adaptive142Third140Node101 = false := by
  decide +kernel

#print axioms adaptive142Third140Proof101

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third140Proof39 : runCachedNode 511 130107 Adaptive142Third140Node39 = false := by
  decide +kernel

#print axioms adaptive142Third140Proof39

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third140Proof98 : runCachedNode 511 130107 Adaptive142Third140Node98 = false := by
  decide +kernel

#print axioms adaptive142Third140Proof98

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third140Proof10 : runCachedNode 511 130107 Adaptive142Third140Node10 = false := by
  decide +kernel

#print axioms adaptive142Third140Proof10

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third140Proof193 : runCachedNode 511 130107 Adaptive142Third140Node193 = false := by
  decide +kernel

#print axioms adaptive142Third140Proof193

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third140Proof126 : runCachedNode 511 130107 Adaptive142Third140Node126 = false := by
  decide +kernel

#print axioms adaptive142Third140Proof126

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third140Proof92 : runCachedNode 511 130107 Adaptive142Third140Node92 = false := by
  decide +kernel

#print axioms adaptive142Third140Proof92

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third140Proof53 : runCachedNode 511 130107 Adaptive142Third140Node53 = false := by
  decide +kernel

#print axioms adaptive142Third140Proof53

end NineSeparatedSubsetSums
