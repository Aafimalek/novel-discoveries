import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive142Third109Node0 : CachedSearchNode :=
  ⟨4, 108, computeCenteredMask [148,142,109], 399, 53949⟩

end NineSeparatedSubsetSums
