import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive142Third104Node0 : CachedSearchNode :=
  ⟨4, 103, computeCenteredMask [148,142,104], 394, 52884⟩

end NineSeparatedSubsetSums
