import NineSeparatedSubsetSums.Adaptive142Third141State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third141Proof384 : runCachedNode 511 130276 Adaptive142Third141Node384 = false := by
  decide +kernel

#print axioms adaptive142Third141Proof384

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third141Proof26 : runCachedNode 511 130276 Adaptive142Third141Node26 = false := by
  decide +kernel

#print axioms adaptive142Third141Proof26

end NineSeparatedSubsetSums
