import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive142Third107Node0 : CachedSearchNode :=
  ⟨4, 106, computeCenteredMask [148,142,107], 397, 53517⟩

end NineSeparatedSubsetSums
