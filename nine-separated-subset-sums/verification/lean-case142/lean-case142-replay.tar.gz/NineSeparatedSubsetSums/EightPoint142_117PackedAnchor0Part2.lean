import NineSeparatedSubsetSums.EightPoint142_117PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint142_117PackedAnchor0Part2 :
    ∀ j : Fin 5, 2363304 ≤ FourPointNumeric.octPackedCharge 142 117 20 packedOct142_117_0
      (2*((j.val : Int)+240)+1) := by decide +kernel

end NineSeparatedSubsetSums
