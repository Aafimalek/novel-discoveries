import NineSeparatedSubsetSums.Adaptive142Third136State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third136Proof18 : runCachedNode 511 129404 Adaptive142Third136Node18 = false := by
  decide +kernel

#print axioms adaptive142Third136Proof18

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third136Proof9 : runCachedNode 511 129404 Adaptive142Third136Node9 = false := by
  decide +kernel

#print axioms adaptive142Third136Proof9

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third136Proof120 : runCachedNode 511 129404 Adaptive142Third136Node120 = false := by
  decide +kernel

#print axioms adaptive142Third136Proof120

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third136Proof65 : runCachedNode 511 129404 Adaptive142Third136Node65 = false := by
  decide +kernel

#print axioms adaptive142Third136Proof65

end NineSeparatedSubsetSums
