import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive142Third125Node0 : CachedSearchNode :=
  ⟨4, 124, computeCenteredMask [148,142,125], 415, 57693⟩

end NineSeparatedSubsetSums
