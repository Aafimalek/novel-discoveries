import NineSeparatedSubsetSums.Adaptive142Third139State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third139Proof319 : runCachedNode 511 129933 Adaptive142Third139Node319 = false := by
  decide +kernel

#print axioms adaptive142Third139Proof319

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third139Proof19 : runCachedNode 511 129933 Adaptive142Third139Node19 = false := by
  decide +kernel

#print axioms adaptive142Third139Proof19

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third139Proof40 : runCachedNode 511 129933 Adaptive142Third139Node40 = false := by
  decide +kernel

#print axioms adaptive142Third139Proof40

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third139Proof111 : runCachedNode 511 129933 Adaptive142Third139Node111 = false := by
  decide +kernel

#print axioms adaptive142Third139Proof111

end NineSeparatedSubsetSums
