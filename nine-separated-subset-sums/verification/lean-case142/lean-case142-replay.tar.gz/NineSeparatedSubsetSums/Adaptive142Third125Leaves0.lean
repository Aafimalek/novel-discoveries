import NineSeparatedSubsetSums.Adaptive142Third125State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third125Proof0 : runCachedNode 511 127165 Adaptive142Third125Node0 = false := by
  decide +kernel

#print axioms adaptive142Third125Proof0

end NineSeparatedSubsetSums
