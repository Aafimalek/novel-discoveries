import NineSeparatedSubsetSums.Adaptive142Third138State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third138Proof163 : runCachedNode 511 129778 Adaptive142Third138Node163 = false := by
  decide +kernel

#print axioms adaptive142Third138Proof163

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third138Proof12 : runCachedNode 511 129778 Adaptive142Third138Node12 = false := by
  decide +kernel

#print axioms adaptive142Third138Proof12

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third138Proof98 : runCachedNode 511 129778 Adaptive142Third138Node98 = false := by
  decide +kernel

#print axioms adaptive142Third138Proof98

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third138Proof162 : runCachedNode 511 129778 Adaptive142Third138Node162 = false := by
  decide +kernel

#print axioms adaptive142Third138Proof162

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third138Proof197 : runCachedNode 511 129778 Adaptive142Third138Node197 = false := by
  decide +kernel

#print axioms adaptive142Third138Proof197

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third138Proof70 : runCachedNode 511 129778 Adaptive142Third138Node70 = false := by
  decide +kernel

#print axioms adaptive142Third138Proof70

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third138Proof157 : runCachedNode 511 129778 Adaptive142Third138Node157 = false := by
  decide +kernel

#print axioms adaptive142Third138Proof157

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third138Proof72 : runCachedNode 511 129778 Adaptive142Third138Node72 = false := by
  decide +kernel

#print axioms adaptive142Third138Proof72

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third138Proof10 : runCachedNode 511 129778 Adaptive142Third138Node10 = false := by
  decide +kernel

#print axioms adaptive142Third138Proof10

end NineSeparatedSubsetSums
