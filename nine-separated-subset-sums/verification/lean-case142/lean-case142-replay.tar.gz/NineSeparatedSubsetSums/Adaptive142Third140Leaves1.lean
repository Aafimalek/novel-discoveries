import NineSeparatedSubsetSums.Adaptive142Third140State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third140Proof22 : runCachedNode 511 130107 Adaptive142Third140Node22 = false := by
  decide +kernel

#print axioms adaptive142Third140Proof22

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third140Proof189 : runCachedNode 511 130107 Adaptive142Third140Node189 = false := by
  decide +kernel

#print axioms adaptive142Third140Proof189

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third140Proof81 : runCachedNode 511 130107 Adaptive142Third140Node81 = false := by
  decide +kernel

#print axioms adaptive142Third140Proof81

end NineSeparatedSubsetSums
