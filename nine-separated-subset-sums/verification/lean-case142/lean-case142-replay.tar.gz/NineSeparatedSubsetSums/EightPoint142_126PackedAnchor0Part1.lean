import NineSeparatedSubsetSums.EightPoint142_126PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint142_126PackedAnchor0Part1 :
    ∀ j : Fin 120, 2365648 ≤ FourPointNumeric.octPackedCharge 142 126 20 packedOct142_126_0
      (2*((j.val : Int)+120)+0) := by decide +kernel

end NineSeparatedSubsetSums
