import NineSeparatedSubsetSums.EightPoint142_117PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint142_117PackedAnchor1Part1 :
    ∀ j : Fin 120, 2363009 ≤ FourPointNumeric.octPackedCharge 142 117 20 packedOct142_117_1
      (2*((j.val : Int)+120)+0) := by decide +kernel

end NineSeparatedSubsetSums
