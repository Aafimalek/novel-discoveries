import NineSeparatedSubsetSums.Adaptive142Third140State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third140Proof231 : runCachedNode 511 130107 Adaptive142Third140Node231 = false := by
  decide +kernel

#print axioms adaptive142Third140Proof231

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third140Proof121 : runCachedNode 511 130107 Adaptive142Third140Node121 = false := by
  decide +kernel

#print axioms adaptive142Third140Proof121

end NineSeparatedSubsetSums
