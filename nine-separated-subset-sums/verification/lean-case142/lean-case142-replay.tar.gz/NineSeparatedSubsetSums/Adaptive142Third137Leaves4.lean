import NineSeparatedSubsetSums.Adaptive142Third137State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third137Proof20 : runCachedNode 511 129593 Adaptive142Third137Node20 = false := by
  decide +kernel

#print axioms adaptive142Third137Proof20

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third137Proof18 : runCachedNode 511 129593 Adaptive142Third137Node18 = false := by
  decide +kernel

#print axioms adaptive142Third137Proof18

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third137Proof49 : runCachedNode 511 129593 Adaptive142Third137Node49 = false := by
  decide +kernel

#print axioms adaptive142Third137Proof49

end NineSeparatedSubsetSums
