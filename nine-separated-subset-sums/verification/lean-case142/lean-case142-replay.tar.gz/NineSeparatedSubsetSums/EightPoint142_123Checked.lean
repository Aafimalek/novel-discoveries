import NineSeparatedSubsetSums.EightPointPackedGeometry
import NineSeparatedSubsetSums.EightPoint142_123PackedBudget0
import NineSeparatedSubsetSums.EightPoint142_123PackedAnchor0Part0
import NineSeparatedSubsetSums.EightPoint142_123PackedAnchor0Part1
import NineSeparatedSubsetSums.EightPoint142_123PackedAnchor0Part2
import NineSeparatedSubsetSums.EightPoint142_123PackedBudget1
import NineSeparatedSubsetSums.EightPoint142_123PackedAnchor1Part0
import NineSeparatedSubsetSums.EightPoint142_123PackedAnchor1Part1
import NineSeparatedSubsetSums.EightPoint142_123PackedAnchor1Part2

namespace NineSeparatedSubsetSums

private theorem packedOct142_123Anchor0 :
  ∀ j : Fin 482, ((j.val : Int)+142+123)%2=0 →
    2311222 ≤ FourPointNumeric.octPackedCharge 142 123 20 packedOct142_123_0 (j.val : Int) := by
  intro j hj
  let k := (j.val-1)/2
  have hk : k < 241 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+1 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint142_123PackedAnchor0Part0 z
    rwa [he,hrep] at ht
  by_cases h1 : k < 240
  · let z : Fin 120 := ⟨k-120, by omega⟩
    have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
    have ht := eightPoint142_123PackedAnchor0Part1 z
    rwa [he,hrep] at ht
  let z : Fin 1 := ⟨k-240, by omega⟩
  have he : (z.val : Int)+240 = k := by dsimp [z] <;> omega
  have ht := eightPoint142_123PackedAnchor0Part2 z
  rwa [he,hrep] at ht

private theorem packedOct142_123Anchor1 :
  ∀ j : Fin 482, ((j.val : Int)+142+123)%2=1 →
    2312342 ≤ FourPointNumeric.octPackedCharge 142 123 20 packedOct142_123_1 (j.val : Int) := by
  intro j hj
  let k := (j.val-0)/2
  have hk : k < 241 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+0 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint142_123PackedAnchor1Part0 z
    rwa [he,hrep] at ht
  by_cases h1 : k < 240
  · let z : Fin 120 := ⟨k-120, by omega⟩
    have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
    have ht := eightPoint142_123PackedAnchor1Part1 z
    rwa [he,hrep] at ht
  let z : Fin 1 := ⟨k-240, by omega⟩
  have he : (z.val : Int)+240 = k := by dsimp [z] <;> omega
  have ht := eightPoint142_123PackedAnchor1Part2 z
  rwa [he,hrep] at ht

def packedOctCertificate142_123_0 : EightPointCertificate 142 123 0 126511 :=
  eightPointCertificateOfPacked 142 123 0 126511 2311222 20 packedOct142_123_0 473 482
    (by decide +kernel) (by decide) packedOct142_123Anchor0
    (by rw [packedOct142_123_0_budget]; decide)

def packedOctCertificate142_123_1 : EightPointCertificate 142 123 1 126511 :=
  eightPointCertificateOfPacked 142 123 1 126511 2312342 20 packedOct142_123_1 474 482
    (by decide +kernel) (by decide) packedOct142_123Anchor1
    (by rw [packedOct142_123_1_budget]; decide)

theorem max148_second142_third123_eightPoint_moment_bound (tail : List ℕ) (len : tail.length=6)
    (distinct : (natSubsetSums (148::142::123::tail)).Nodup) :
    126511 ≤ ((148::142::123::tail).map (· ^ 2)).sum := by
  apply eightPointNatMomentLower 142 123 126511 tail len distinct
  intro p hp
  by_cases h : p=0
  · subst p
    exact packedOctCertificate142_123_0
  · have he : p=1 := hp.resolve_left h
    subst p
    exact packedOctCertificate142_123_1

#print axioms max148_second142_third123_eightPoint_moment_bound

end NineSeparatedSubsetSums
