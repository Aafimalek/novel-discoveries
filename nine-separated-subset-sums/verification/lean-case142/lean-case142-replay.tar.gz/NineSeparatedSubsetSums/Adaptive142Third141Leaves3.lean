import NineSeparatedSubsetSums.Adaptive142Third141State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third141Proof309 : runCachedNode 511 130276 Adaptive142Third141Node309 = false := by
  decide +kernel

#print axioms adaptive142Third141Proof309

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third141Proof230 : runCachedNode 511 130276 Adaptive142Third141Node230 = false := by
  decide +kernel

#print axioms adaptive142Third141Proof230

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third141Proof150 : runCachedNode 511 130276 Adaptive142Third141Node150 = false := by
  decide +kernel

#print axioms adaptive142Third141Proof150

end NineSeparatedSubsetSums
