import NineSeparatedSubsetSums.Adaptive142Third126State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third126Proof0 : runCachedNode 511 127538 Adaptive142Third126Node0 = false := by
  decide +kernel

#print axioms adaptive142Third126Proof0

end NineSeparatedSubsetSums
