import NineSeparatedSubsetSums.EightPoint142_130PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint142_130PackedAnchor1Part2 :
    ∀ j : Fin 6, 2411084 ≤ FourPointNumeric.octPackedCharge 142 130 20 packedOct142_130_1
      (2*((j.val : Int)+240)+1) := by decide +kernel

end NineSeparatedSubsetSums
