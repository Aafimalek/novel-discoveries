import NineSeparatedSubsetSums.Adaptive142Third131State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third131Proof17 : runCachedNode 511 128642 Adaptive142Third131Node17 = false := by
  decide +kernel

#print axioms adaptive142Third131Proof17

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third131Proof16 : runCachedNode 511 128642 Adaptive142Third131Node16 = false := by
  decide +kernel

#print axioms adaptive142Third131Proof16

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third131Proof15 : runCachedNode 511 128642 Adaptive142Third131Node15 = false := by
  decide +kernel

#print axioms adaptive142Third131Proof15

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third131Proof3 : runCachedNode 511 128642 Adaptive142Third131Node3 = false := by
  decide +kernel

#print axioms adaptive142Third131Proof3

end NineSeparatedSubsetSums
