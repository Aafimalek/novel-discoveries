import NineSeparatedSubsetSums.Adaptive142Third141State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third141Proof390 : runCachedNode 511 130276 Adaptive142Third141Node390 = false := by
  decide +kernel

#print axioms adaptive142Third141Proof390

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third141Proof391 : runCachedNode 511 130276 Adaptive142Third141Node391 = false := by
  decide +kernel

#print axioms adaptive142Third141Proof391

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third141Proof392 : runCachedNode 511 130276 Adaptive142Third141Node392 = false := by
  decide +kernel

#print axioms adaptive142Third141Proof392

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third141Proof393 : runCachedNode 511 130276 Adaptive142Third141Node393 = false := by
  decide +kernel

#print axioms adaptive142Third141Proof393

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third141Proof394 : runCachedNode 511 130276 Adaptive142Third141Node394 = false := by
  decide +kernel

#print axioms adaptive142Third141Proof394

end NineSeparatedSubsetSums
