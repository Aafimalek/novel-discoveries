import NineSeparatedSubsetSums.Adaptive142Third140State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third140Proof171 : runCachedNode 511 130107 Adaptive142Third140Node171 = false := by
  decide +kernel

#print axioms adaptive142Third140Proof171

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third140Proof268 : runCachedNode 511 130107 Adaptive142Third140Node268 = false := by
  decide +kernel

#print axioms adaptive142Third140Proof268

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third140Proof289 : runCachedNode 511 130107 Adaptive142Third140Node289 = false := by
  decide +kernel

#print axioms adaptive142Third140Proof289

end NineSeparatedSubsetSums
