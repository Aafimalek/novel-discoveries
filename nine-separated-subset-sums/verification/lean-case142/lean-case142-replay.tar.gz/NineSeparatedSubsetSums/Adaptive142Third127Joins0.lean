import NineSeparatedSubsetSums.Adaptive142Third127State
import NineSeparatedSubsetSums.Adaptive142Third127Leaves1
import NineSeparatedSubsetSums.Adaptive142Third127Leaves0

namespace NineSeparatedSubsetSums

theorem adaptive142Third127Proof0 : runCachedNode 511 127742 Adaptive142Third127Node0 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 127742 Adaptive142Third127Node0 = [111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 122, 123, 124, 125, 126] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive142Third127Proof1
  · exact adaptive142Third127Proof2
  · exact adaptive142Third127Proof3
  · exact adaptive142Third127Proof4
  · exact adaptive142Third127Proof5
  · exact adaptive142Third127Proof6
  · exact adaptive142Third127Proof7
  · exact adaptive142Third127Proof8
  · exact adaptive142Third127Proof9
  · exact adaptive142Third127Proof10
  · exact adaptive142Third127Proof11
  · exact adaptive142Third127Proof12
  · exact adaptive142Third127Proof13
  · exact adaptive142Third127Proof14
  · exact adaptive142Third127Proof15

#print axioms adaptive142Third127Proof0

end NineSeparatedSubsetSums
