import NineSeparatedSubsetSums.Adaptive142Third141State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third141Proof233 : runCachedNode 511 130276 Adaptive142Third141Node233 = false := by
  decide +kernel

#print axioms adaptive142Third141Proof233

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third141Proof102 : runCachedNode 511 130276 Adaptive142Third141Node102 = false := by
  decide +kernel

#print axioms adaptive142Third141Proof102

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third141Proof104 : runCachedNode 511 130276 Adaptive142Third141Node104 = false := by
  decide +kernel

#print axioms adaptive142Third141Proof104

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third141Proof292 : runCachedNode 511 130276 Adaptive142Third141Node292 = false := by
  decide +kernel

#print axioms adaptive142Third141Proof292

end NineSeparatedSubsetSums
