import NineSeparatedSubsetSums.Adaptive142Third136State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third136Proof138 : runCachedNode 511 129404 Adaptive142Third136Node138 = false := by
  decide +kernel

#print axioms adaptive142Third136Proof138

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third136Proof87 : runCachedNode 511 129404 Adaptive142Third136Node87 = false := by
  decide +kernel

#print axioms adaptive142Third136Proof87

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third136Proof63 : runCachedNode 511 129404 Adaptive142Third136Node63 = false := by
  decide +kernel

#print axioms adaptive142Third136Proof63

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third136Proof137 : runCachedNode 511 129404 Adaptive142Third136Node137 = false := by
  decide +kernel

#print axioms adaptive142Third136Proof137

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third136Proof44 : runCachedNode 511 129404 Adaptive142Third136Node44 = false := by
  decide +kernel

#print axioms adaptive142Third136Proof44

end NineSeparatedSubsetSums
