import NineSeparatedSubsetSums.Adaptive142Third134State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third134Proof13 : runCachedNode 511 129144 Adaptive142Third134Node13 = false := by
  decide +kernel

#print axioms adaptive142Third134Proof13

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third134Proof68 : runCachedNode 511 129144 Adaptive142Third134Node68 = false := by
  decide +kernel

#print axioms adaptive142Third134Proof68

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third134Proof71 : runCachedNode 511 129144 Adaptive142Third134Node71 = false := by
  decide +kernel

#print axioms adaptive142Third134Proof71

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third134Proof11 : runCachedNode 511 129144 Adaptive142Third134Node11 = false := by
  decide +kernel

#print axioms adaptive142Third134Proof11

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third134Proof70 : runCachedNode 511 129144 Adaptive142Third134Node70 = false := by
  decide +kernel

#print axioms adaptive142Third134Proof70

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third134Proof12 : runCachedNode 511 129144 Adaptive142Third134Node12 = false := by
  decide +kernel

#print axioms adaptive142Third134Proof12

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third134Proof67 : runCachedNode 511 129144 Adaptive142Third134Node67 = false := by
  decide +kernel

#print axioms adaptive142Third134Proof67

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third134Proof8 : runCachedNode 511 129144 Adaptive142Third134Node8 = false := by
  decide +kernel

#print axioms adaptive142Third134Proof8

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third134Proof54 : runCachedNode 511 129144 Adaptive142Third134Node54 = false := by
  decide +kernel

#print axioms adaptive142Third134Proof54

end NineSeparatedSubsetSums
