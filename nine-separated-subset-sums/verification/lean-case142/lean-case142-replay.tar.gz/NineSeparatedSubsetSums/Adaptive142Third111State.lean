import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive142Third111Node0 : CachedSearchNode :=
  ⟨4, 110, computeCenteredMask [148,142,111], 401, 54389⟩

end NineSeparatedSubsetSums
