import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive142Third113Node0 : CachedSearchNode :=
  ⟨4, 112, computeCenteredMask [148,142,113], 403, 54837⟩

end NineSeparatedSubsetSums
