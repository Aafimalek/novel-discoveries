import NineSeparatedSubsetSums.Adaptive142Third139State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third139Proof23 : runCachedNode 511 129933 Adaptive142Third139Node23 = false := by
  decide +kernel

#print axioms adaptive142Third139Proof23

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third139Proof174 : runCachedNode 511 129933 Adaptive142Third139Node174 = false := by
  decide +kernel

#print axioms adaptive142Third139Proof174

end NineSeparatedSubsetSums
