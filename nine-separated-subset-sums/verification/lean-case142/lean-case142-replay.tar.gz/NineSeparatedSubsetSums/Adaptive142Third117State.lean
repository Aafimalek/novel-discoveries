import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive142Third117Node0 : CachedSearchNode :=
  ⟨4, 116, computeCenteredMask [148,142,117], 407, 55757⟩

end NineSeparatedSubsetSums
