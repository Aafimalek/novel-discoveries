import NineSeparatedSubsetSums.Adaptive142Third136State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third136Proof145 : runCachedNode 511 129404 Adaptive142Third136Node145 = false := by
  decide +kernel

#print axioms adaptive142Third136Proof145

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third136Proof146 : runCachedNode 511 129404 Adaptive142Third136Node146 = false := by
  decide +kernel

#print axioms adaptive142Third136Proof146

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third136Proof172 : runCachedNode 511 129404 Adaptive142Third136Node172 = false := by
  decide +kernel

#print axioms adaptive142Third136Proof172

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third136Proof204 : runCachedNode 511 129404 Adaptive142Third136Node204 = false := by
  decide +kernel

#print axioms adaptive142Third136Proof204

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third136Proof66 : runCachedNode 511 129404 Adaptive142Third136Node66 = false := by
  decide +kernel

#print axioms adaptive142Third136Proof66

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third136Proof90 : runCachedNode 511 129404 Adaptive142Third136Node90 = false := by
  decide +kernel

#print axioms adaptive142Third136Proof90

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third136Proof143 : runCachedNode 511 129404 Adaptive142Third136Node143 = false := by
  decide +kernel

#print axioms adaptive142Third136Proof143

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third136Proof144 : runCachedNode 511 129404 Adaptive142Third136Node144 = false := by
  decide +kernel

#print axioms adaptive142Third136Proof144

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third136Proof170 : runCachedNode 511 129404 Adaptive142Third136Node170 = false := by
  decide +kernel

#print axioms adaptive142Third136Proof170

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third136Proof171 : runCachedNode 511 129404 Adaptive142Third136Node171 = false := by
  decide +kernel

#print axioms adaptive142Third136Proof171

end NineSeparatedSubsetSums
