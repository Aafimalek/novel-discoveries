import NineSeparatedSubsetSums.Adaptive142Third140State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third140Proof265 : runCachedNode 511 130107 Adaptive142Third140Node265 = false := by
  decide +kernel

#print axioms adaptive142Third140Proof265

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third140Proof262 : runCachedNode 511 130107 Adaptive142Third140Node262 = false := by
  decide +kernel

#print axioms adaptive142Third140Proof262

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third140Proof306 : runCachedNode 511 130107 Adaptive142Third140Node306 = false := by
  decide +kernel

#print axioms adaptive142Third140Proof306

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third140Proof41 : runCachedNode 511 130107 Adaptive142Third140Node41 = false := by
  decide +kernel

#print axioms adaptive142Third140Proof41

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third140Proof163 : runCachedNode 511 130107 Adaptive142Third140Node163 = false := by
  decide +kernel

#print axioms adaptive142Third140Proof163

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third140Proof42 : runCachedNode 511 130107 Adaptive142Third140Node42 = false := by
  decide +kernel

#print axioms adaptive142Third140Proof42

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third140Proof11 : runCachedNode 511 130107 Adaptive142Third140Node11 = false := by
  decide +kernel

#print axioms adaptive142Third140Proof11

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third140Proof194 : runCachedNode 511 130107 Adaptive142Third140Node194 = false := by
  decide +kernel

#print axioms adaptive142Third140Proof194

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third140Proof162 : runCachedNode 511 130107 Adaptive142Third140Node162 = false := by
  decide +kernel

#print axioms adaptive142Third140Proof162

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third140Proof127 : runCachedNode 511 130107 Adaptive142Third140Node127 = false := by
  decide +kernel

#print axioms adaptive142Third140Proof127

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third140Proof239 : runCachedNode 511 130107 Adaptive142Third140Node239 = false := by
  decide +kernel

#print axioms adaptive142Third140Proof239

end NineSeparatedSubsetSums
