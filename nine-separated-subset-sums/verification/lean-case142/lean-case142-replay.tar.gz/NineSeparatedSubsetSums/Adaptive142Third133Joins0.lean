import NineSeparatedSubsetSums.Adaptive142Third133State
import NineSeparatedSubsetSums.Adaptive142Third133Leaves0
import NineSeparatedSubsetSums.Adaptive142Third133Leaves1
import NineSeparatedSubsetSums.Adaptive142Third133Leaves5
import NineSeparatedSubsetSums.Adaptive142Third133Leaves4
import NineSeparatedSubsetSums.Adaptive142Third133Leaves2
import NineSeparatedSubsetSums.Adaptive142Third133Leaves3

namespace NineSeparatedSubsetSums

theorem adaptive142Third133Proof22 : runCachedNode 511 128920 Adaptive142Third133Node22 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 128920 Adaptive142Third133Node22 = [104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 118, 119, 120, 121, 122, 124, 125, 128, 129, 130, 131] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive142Third133Proof23
  · exact adaptive142Third133Proof24
  · exact adaptive142Third133Proof25
  · exact adaptive142Third133Proof26
  · exact adaptive142Third133Proof27
  · exact adaptive142Third133Proof28
  · exact adaptive142Third133Proof29
  · exact adaptive142Third133Proof30
  · exact adaptive142Third133Proof31
  · exact adaptive142Third133Proof32
  · exact adaptive142Third133Proof33
  · exact adaptive142Third133Proof34
  · exact adaptive142Third133Proof35
  · exact adaptive142Third133Proof36
  · exact adaptive142Third133Proof37
  · exact adaptive142Third133Proof38
  · exact adaptive142Third133Proof39
  · exact adaptive142Third133Proof40
  · exact adaptive142Third133Proof41
  · exact adaptive142Third133Proof42
  · exact adaptive142Third133Proof43
  · exact adaptive142Third133Proof44
  · exact adaptive142Third133Proof45
  · exact adaptive142Third133Proof46

#print axioms adaptive142Third133Proof22

theorem adaptive142Third133Proof0 : runCachedNode 511 128920 Adaptive142Third133Node0 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 128920 Adaptive142Third133Node0 = [110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 128, 129, 130, 131, 132] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive142Third133Proof1
  · exact adaptive142Third133Proof2
  · exact adaptive142Third133Proof3
  · exact adaptive142Third133Proof4
  · exact adaptive142Third133Proof5
  · exact adaptive142Third133Proof6
  · exact adaptive142Third133Proof7
  · exact adaptive142Third133Proof8
  · exact adaptive142Third133Proof9
  · exact adaptive142Third133Proof10
  · exact adaptive142Third133Proof11
  · exact adaptive142Third133Proof12
  · exact adaptive142Third133Proof13
  · exact adaptive142Third133Proof14
  · exact adaptive142Third133Proof15
  · exact adaptive142Third133Proof16
  · exact adaptive142Third133Proof17
  · exact adaptive142Third133Proof18
  · exact adaptive142Third133Proof19
  · exact adaptive142Third133Proof20
  · exact adaptive142Third133Proof21
  · exact adaptive142Third133Proof22

#print axioms adaptive142Third133Proof0

end NineSeparatedSubsetSums
