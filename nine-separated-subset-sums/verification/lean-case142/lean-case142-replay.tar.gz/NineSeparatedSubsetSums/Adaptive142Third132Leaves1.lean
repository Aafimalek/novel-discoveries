import NineSeparatedSubsetSums.Adaptive142Third132State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third132Proof20 : runCachedNode 511 128761 Adaptive142Third132Node20 = false := by
  decide +kernel

#print axioms adaptive142Third132Proof20

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third132Proof17 : runCachedNode 511 128761 Adaptive142Third132Node17 = false := by
  decide +kernel

#print axioms adaptive142Third132Proof17

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third132Proof10 : runCachedNode 511 128761 Adaptive142Third132Node10 = false := by
  decide +kernel

#print axioms adaptive142Third132Proof10

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third132Proof5 : runCachedNode 511 128761 Adaptive142Third132Node5 = false := by
  decide +kernel

#print axioms adaptive142Third132Proof5

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third132Proof2 : runCachedNode 511 128761 Adaptive142Third132Node2 = false := by
  decide +kernel

#print axioms adaptive142Third132Proof2

end NineSeparatedSubsetSums
