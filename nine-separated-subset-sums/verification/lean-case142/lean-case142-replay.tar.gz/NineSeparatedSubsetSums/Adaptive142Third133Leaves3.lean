import NineSeparatedSubsetSums.Adaptive142Third133State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third133Proof15 : runCachedNode 511 128920 Adaptive142Third133Node15 = false := by
  decide +kernel

#print axioms adaptive142Third133Proof15

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third133Proof16 : runCachedNode 511 128920 Adaptive142Third133Node16 = false := by
  decide +kernel

#print axioms adaptive142Third133Proof16

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third133Proof46 : runCachedNode 511 128920 Adaptive142Third133Node46 = false := by
  decide +kernel

#print axioms adaptive142Third133Proof46

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third133Proof14 : runCachedNode 511 128920 Adaptive142Third133Node14 = false := by
  decide +kernel

#print axioms adaptive142Third133Proof14

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third133Proof9 : runCachedNode 511 128920 Adaptive142Third133Node9 = false := by
  decide +kernel

#print axioms adaptive142Third133Proof9

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third133Proof2 : runCachedNode 511 128920 Adaptive142Third133Node2 = false := by
  decide +kernel

#print axioms adaptive142Third133Proof2

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third133Proof1 : runCachedNode 511 128920 Adaptive142Third133Node1 = false := by
  decide +kernel

#print axioms adaptive142Third133Proof1

end NineSeparatedSubsetSums
