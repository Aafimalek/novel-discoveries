import NineSeparatedSubsetSums.Adaptive142Third137State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third137Proof67 : runCachedNode 511 129593 Adaptive142Third137Node67 = false := by
  decide +kernel

#print axioms adaptive142Third137Proof67

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third137Proof148 : runCachedNode 511 129593 Adaptive142Third137Node148 = false := by
  decide +kernel

#print axioms adaptive142Third137Proof148

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third137Proof68 : runCachedNode 511 129593 Adaptive142Third137Node68 = false := by
  decide +kernel

#print axioms adaptive142Third137Proof68

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third137Proof147 : runCachedNode 511 129593 Adaptive142Third137Node147 = false := by
  decide +kernel

#print axioms adaptive142Third137Proof147

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third137Proof91 : runCachedNode 511 129593 Adaptive142Third137Node91 = false := by
  decide +kernel

#print axioms adaptive142Third137Proof91

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third137Proof122 : runCachedNode 511 129593 Adaptive142Third137Node122 = false := by
  decide +kernel

#print axioms adaptive142Third137Proof122

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third137Proof94 : runCachedNode 511 129593 Adaptive142Third137Node94 = false := by
  decide +kernel

#print axioms adaptive142Third137Proof94

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third137Proof191 : runCachedNode 511 129593 Adaptive142Third137Node191 = false := by
  decide +kernel

#print axioms adaptive142Third137Proof191

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third137Proof123 : runCachedNode 511 129593 Adaptive142Third137Node123 = false := by
  decide +kernel

#print axioms adaptive142Third137Proof123

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third137Proof39 : runCachedNode 511 129593 Adaptive142Third137Node39 = false := by
  decide +kernel

#print axioms adaptive142Third137Proof39

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third137Proof93 : runCachedNode 511 129593 Adaptive142Third137Node93 = false := by
  decide +kernel

#print axioms adaptive142Third137Proof93

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third137Proof149 : runCachedNode 511 129593 Adaptive142Third137Node149 = false := by
  decide +kernel

#print axioms adaptive142Third137Proof149

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third137Proof109 : runCachedNode 511 129593 Adaptive142Third137Node109 = false := by
  decide +kernel

#print axioms adaptive142Third137Proof109

end NineSeparatedSubsetSums
