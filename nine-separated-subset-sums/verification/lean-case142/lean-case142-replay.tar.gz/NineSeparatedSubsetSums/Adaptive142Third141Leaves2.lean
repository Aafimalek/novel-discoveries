import NineSeparatedSubsetSums.Adaptive142Third141State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third141Proof343 : runCachedNode 511 130276 Adaptive142Third141Node343 = false := by
  decide +kernel

#print axioms adaptive142Third141Proof343

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third141Proof70 : runCachedNode 511 130276 Adaptive142Third141Node70 = false := by
  decide +kernel

#print axioms adaptive142Third141Proof70

end NineSeparatedSubsetSums
