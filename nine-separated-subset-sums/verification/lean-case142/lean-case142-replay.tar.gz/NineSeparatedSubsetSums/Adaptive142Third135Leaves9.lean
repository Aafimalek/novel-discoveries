import NineSeparatedSubsetSums.Adaptive142Third135State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third135Proof78 : runCachedNode 511 129264 Adaptive142Third135Node78 = false := by
  decide +kernel

#print axioms adaptive142Third135Proof78

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third135Proof79 : runCachedNode 511 129264 Adaptive142Third135Node79 = false := by
  decide +kernel

#print axioms adaptive142Third135Proof79

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third135Proof51 : runCachedNode 511 129264 Adaptive142Third135Node51 = false := by
  decide +kernel

#print axioms adaptive142Third135Proof51

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third135Proof52 : runCachedNode 511 129264 Adaptive142Third135Node52 = false := by
  decide +kernel

#print axioms adaptive142Third135Proof52

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third135Proof76 : runCachedNode 511 129264 Adaptive142Third135Node76 = false := by
  decide +kernel

#print axioms adaptive142Third135Proof76

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third135Proof23 : runCachedNode 511 129264 Adaptive142Third135Node23 = false := by
  decide +kernel

#print axioms adaptive142Third135Proof23

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third135Proof49 : runCachedNode 511 129264 Adaptive142Third135Node49 = false := by
  decide +kernel

#print axioms adaptive142Third135Proof49

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third135Proof50 : runCachedNode 511 129264 Adaptive142Third135Node50 = false := by
  decide +kernel

#print axioms adaptive142Third135Proof50

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third135Proof74 : runCachedNode 511 129264 Adaptive142Third135Node74 = false := by
  decide +kernel

#print axioms adaptive142Third135Proof74

end NineSeparatedSubsetSums
