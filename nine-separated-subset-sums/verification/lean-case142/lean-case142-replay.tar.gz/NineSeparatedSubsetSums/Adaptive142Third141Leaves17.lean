import NineSeparatedSubsetSums.Adaptive142Third141State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third141Proof18 : runCachedNode 511 130276 Adaptive142Third141Node18 = false := by
  decide +kernel

#print axioms adaptive142Third141Proof18

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third141Proof341 : runCachedNode 511 130276 Adaptive142Third141Node341 = false := by
  decide +kernel

#print axioms adaptive142Third141Proof341

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third141Proof426 : runCachedNode 511 130276 Adaptive142Third141Node426 = false := by
  decide +kernel

#print axioms adaptive142Third141Proof426

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third141Proof161 : runCachedNode 511 130276 Adaptive142Third141Node161 = false := by
  decide +kernel

#print axioms adaptive142Third141Proof161

end NineSeparatedSubsetSums
