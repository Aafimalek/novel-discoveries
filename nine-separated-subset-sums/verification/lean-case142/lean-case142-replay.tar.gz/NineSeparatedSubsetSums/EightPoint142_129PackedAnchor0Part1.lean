import NineSeparatedSubsetSums.EightPoint142_129PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint142_129PackedAnchor0Part1 :
    ∀ j : Fin 120, 2389954 ≤ FourPointNumeric.octPackedCharge 142 129 20 packedOct142_129_0
      (2*((j.val : Int)+120)+1) := by decide +kernel

end NineSeparatedSubsetSums
