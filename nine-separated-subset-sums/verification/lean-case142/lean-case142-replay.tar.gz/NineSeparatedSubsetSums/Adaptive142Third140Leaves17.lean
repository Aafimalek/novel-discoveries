import NineSeparatedSubsetSums.Adaptive142Third140State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third140Proof233 : runCachedNode 511 130107 Adaptive142Third140Node233 = false := by
  decide +kernel

#print axioms adaptive142Third140Proof233

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third140Proof232 : runCachedNode 511 130107 Adaptive142Third140Node232 = false := by
  decide +kernel

#print axioms adaptive142Third140Proof232

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third140Proof195 : runCachedNode 511 130107 Adaptive142Third140Node195 = false := by
  decide +kernel

#print axioms adaptive142Third140Proof195

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third140Proof238 : runCachedNode 511 130107 Adaptive142Third140Node238 = false := by
  decide +kernel

#print axioms adaptive142Third140Proof238

end NineSeparatedSubsetSums
