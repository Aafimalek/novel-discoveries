import NineSeparatedSubsetSums.Adaptive142Third137State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third137Proof21 : runCachedNode 511 129593 Adaptive142Third137Node21 = false := by
  decide +kernel

#print axioms adaptive142Third137Proof21

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third137Proof158 : runCachedNode 511 129593 Adaptive142Third137Node158 = false := by
  decide +kernel

#print axioms adaptive142Third137Proof158

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third137Proof1 : runCachedNode 511 129593 Adaptive142Third137Node1 = false := by
  decide +kernel

#print axioms adaptive142Third137Proof1

end NineSeparatedSubsetSums
