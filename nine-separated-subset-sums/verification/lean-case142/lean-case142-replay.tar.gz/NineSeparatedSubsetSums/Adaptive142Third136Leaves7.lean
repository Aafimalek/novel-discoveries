import NineSeparatedSubsetSums.Adaptive142Third136State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third136Proof135 : runCachedNode 511 129404 Adaptive142Third136Node135 = false := by
  decide +kernel

#print axioms adaptive142Third136Proof135

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third136Proof229 : runCachedNode 511 129404 Adaptive142Third136Node229 = false := by
  decide +kernel

#print axioms adaptive142Third136Proof229

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third136Proof134 : runCachedNode 511 129404 Adaptive142Third136Node134 = false := by
  decide +kernel

#print axioms adaptive142Third136Proof134

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third136Proof99 : runCachedNode 511 129404 Adaptive142Third136Node99 = false := by
  decide +kernel

#print axioms adaptive142Third136Proof99

end NineSeparatedSubsetSums
