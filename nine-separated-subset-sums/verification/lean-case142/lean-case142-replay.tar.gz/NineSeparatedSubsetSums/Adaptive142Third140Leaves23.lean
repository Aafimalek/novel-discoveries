import NineSeparatedSubsetSums.Adaptive142Third140State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third140Proof161 : runCachedNode 511 130107 Adaptive142Third140Node161 = false := by
  decide +kernel

#print axioms adaptive142Third140Proof161

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third140Proof166 : runCachedNode 511 130107 Adaptive142Third140Node166 = false := by
  decide +kernel

#print axioms adaptive142Third140Proof166

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third140Proof13 : runCachedNode 511 130107 Adaptive142Third140Node13 = false := by
  decide +kernel

#print axioms adaptive142Third140Proof13

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third140Proof73 : runCachedNode 511 130107 Adaptive142Third140Node73 = false := by
  decide +kernel

#print axioms adaptive142Third140Proof73

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third140Proof74 : runCachedNode 511 130107 Adaptive142Third140Node74 = false := by
  decide +kernel

#print axioms adaptive142Third140Proof74

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third140Proof44 : runCachedNode 511 130107 Adaptive142Third140Node44 = false := by
  decide +kernel

#print axioms adaptive142Third140Proof44

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third140Proof40 : runCachedNode 511 130107 Adaptive142Third140Node40 = false := by
  decide +kernel

#print axioms adaptive142Third140Proof40

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third140Proof25 : runCachedNode 511 130107 Adaptive142Third140Node25 = false := by
  decide +kernel

#print axioms adaptive142Third140Proof25

end NineSeparatedSubsetSums
