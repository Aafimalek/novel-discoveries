import NineSeparatedSubsetSums.Adaptive142Third139State
import NineSeparatedSubsetSums.Adaptive142Third139Leaves3
import NineSeparatedSubsetSums.Adaptive142Third139Leaves15
import NineSeparatedSubsetSums.Adaptive142Third139Leaves18
import NineSeparatedSubsetSums.Adaptive142Third139Leaves25
import NineSeparatedSubsetSums.Adaptive142Third139Leaves13
import NineSeparatedSubsetSums.Adaptive142Third139Leaves12
import NineSeparatedSubsetSums.Adaptive142Third139Leaves10
import NineSeparatedSubsetSums.Adaptive142Third139Leaves24
import NineSeparatedSubsetSums.Adaptive142Third139Leaves23
import NineSeparatedSubsetSums.Adaptive142Third139Leaves22
import NineSeparatedSubsetSums.Adaptive142Third139Leaves21
import NineSeparatedSubsetSums.Adaptive142Third139Leaves7
import NineSeparatedSubsetSums.Adaptive142Third139Leaves20
import NineSeparatedSubsetSums.Adaptive142Third139Leaves19
import NineSeparatedSubsetSums.Adaptive142Third139Leaves17
import NineSeparatedSubsetSums.Adaptive142Third139Leaves14
import NineSeparatedSubsetSums.Adaptive142Third139Leaves16
import NineSeparatedSubsetSums.Adaptive142Third139Leaves26
import NineSeparatedSubsetSums.Adaptive142Third139Leaves0
import NineSeparatedSubsetSums.Adaptive142Third139Leaves8
import NineSeparatedSubsetSums.Adaptive142Third139Leaves11
import NineSeparatedSubsetSums.Adaptive142Third139Leaves9
import NineSeparatedSubsetSums.Adaptive142Third139Leaves6
import NineSeparatedSubsetSums.Adaptive142Third139Leaves5
import NineSeparatedSubsetSums.Adaptive142Third139Leaves1
import NineSeparatedSubsetSums.Adaptive142Third139Leaves27

namespace NineSeparatedSubsetSums

theorem adaptive142Third139Proof24 : runCachedNode 511 129933 Adaptive142Third139Node24 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 129933 Adaptive142Third139Node24 = [103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 126, 127, 129, 130, 132] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive142Third139Proof25
  · exact adaptive142Third139Proof26
  · exact adaptive142Third139Proof27
  · exact adaptive142Third139Proof28
  · exact adaptive142Third139Proof29
  · exact adaptive142Third139Proof30
  · exact adaptive142Third139Proof31
  · exact adaptive142Third139Proof32
  · exact adaptive142Third139Proof33
  · exact adaptive142Third139Proof34
  · exact adaptive142Third139Proof35
  · exact adaptive142Third139Proof36
  · exact adaptive142Third139Proof37
  · exact adaptive142Third139Proof38
  · exact adaptive142Third139Proof39
  · exact adaptive142Third139Proof40
  · exact adaptive142Third139Proof41
  · exact adaptive142Third139Proof42
  · exact adaptive142Third139Proof43
  · exact adaptive142Third139Proof44
  · exact adaptive142Third139Proof45
  · exact adaptive142Third139Proof46
  · exact adaptive142Third139Proof47
  · exact adaptive142Third139Proof48
  · exact adaptive142Third139Proof49
  · exact adaptive142Third139Proof50
  · exact adaptive142Third139Proof51

#print axioms adaptive142Third139Proof24

theorem adaptive142Third139Proof52 : runCachedNode 511 129933 Adaptive142Third139Node52 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 129933 Adaptive142Third139Node52 = [103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 127, 128, 130, 131, 134] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive142Third139Proof53
  · exact adaptive142Third139Proof54
  · exact adaptive142Third139Proof55
  · exact adaptive142Third139Proof56
  · exact adaptive142Third139Proof57
  · exact adaptive142Third139Proof58
  · exact adaptive142Third139Proof59
  · exact adaptive142Third139Proof60
  · exact adaptive142Third139Proof61
  · exact adaptive142Third139Proof62
  · exact adaptive142Third139Proof63
  · exact adaptive142Third139Proof64
  · exact adaptive142Third139Proof65
  · exact adaptive142Third139Proof66
  · exact adaptive142Third139Proof67
  · exact adaptive142Third139Proof68
  · exact adaptive142Third139Proof69
  · exact adaptive142Third139Proof70
  · exact adaptive142Third139Proof71
  · exact adaptive142Third139Proof72
  · exact adaptive142Third139Proof73
  · exact adaptive142Third139Proof74
  · exact adaptive142Third139Proof75
  · exact adaptive142Third139Proof76
  · exact adaptive142Third139Proof77
  · exact adaptive142Third139Proof78
  · exact adaptive142Third139Proof79
  · exact adaptive142Third139Proof80

#print axioms adaptive142Third139Proof52

theorem adaptive142Third139Proof110 : runCachedNode 511 129933 Adaptive142Third139Node110 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 129933 Adaptive142Third139Node110 = [92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 120, 121, 123, 124, 126, 129, 132] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive142Third139Proof111
  · exact adaptive142Third139Proof112
  · exact adaptive142Third139Proof113
  · exact adaptive142Third139Proof114
  · exact adaptive142Third139Proof115
  · exact adaptive142Third139Proof116
  · exact adaptive142Third139Proof117
  · exact adaptive142Third139Proof118
  · exact adaptive142Third139Proof119
  · exact adaptive142Third139Proof120
  · exact adaptive142Third139Proof121
  · exact adaptive142Third139Proof122
  · exact adaptive142Third139Proof123
  · exact adaptive142Third139Proof124
  · exact adaptive142Third139Proof125
  · exact adaptive142Third139Proof126
  · exact adaptive142Third139Proof127
  · exact adaptive142Third139Proof128
  · exact adaptive142Third139Proof129
  · exact adaptive142Third139Proof130
  · exact adaptive142Third139Proof131
  · exact adaptive142Third139Proof132
  · exact adaptive142Third139Proof133
  · exact adaptive142Third139Proof134
  · exact adaptive142Third139Proof135
  · exact adaptive142Third139Proof136
  · exact adaptive142Third139Proof137
  · exact adaptive142Third139Proof138
  · exact adaptive142Third139Proof139
  · exact adaptive142Third139Proof140
  · exact adaptive142Third139Proof141
  · exact adaptive142Third139Proof142
  · exact adaptive142Third139Proof143
  · exact adaptive142Third139Proof144

#print axioms adaptive142Third139Proof110

theorem adaptive142Third139Proof145 : runCachedNode 511 129933 Adaptive142Third139Node145 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 129933 Adaptive142Third139Node145 = [91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 121, 122, 124, 125, 128, 131] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive142Third139Proof146
  · exact adaptive142Third139Proof147
  · exact adaptive142Third139Proof148
  · exact adaptive142Third139Proof149
  · exact adaptive142Third139Proof150
  · exact adaptive142Third139Proof151
  · exact adaptive142Third139Proof152
  · exact adaptive142Third139Proof153
  · exact adaptive142Third139Proof154
  · exact adaptive142Third139Proof155
  · exact adaptive142Third139Proof156
  · exact adaptive142Third139Proof157
  · exact adaptive142Third139Proof158
  · exact adaptive142Third139Proof159
  · exact adaptive142Third139Proof160
  · exact adaptive142Third139Proof161
  · exact adaptive142Third139Proof162
  · exact adaptive142Third139Proof163
  · exact adaptive142Third139Proof164
  · exact adaptive142Third139Proof165
  · exact adaptive142Third139Proof166
  · exact adaptive142Third139Proof167
  · exact adaptive142Third139Proof168
  · exact adaptive142Third139Proof169
  · exact adaptive142Third139Proof170
  · exact adaptive142Third139Proof171
  · exact adaptive142Third139Proof172
  · exact adaptive142Third139Proof173
  · exact adaptive142Third139Proof174
  · exact adaptive142Third139Proof175
  · exact adaptive142Third139Proof176
  · exact adaptive142Third139Proof177
  · exact adaptive142Third139Proof178
  · exact adaptive142Third139Proof179
  · exact adaptive142Third139Proof180

#print axioms adaptive142Third139Proof145

theorem adaptive142Third139Proof81 : runCachedNode 511 129933 Adaptive142Third139Node81 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 129933 Adaptive142Third139Node81 = [103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 128, 129, 131, 132, 134, 135] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive142Third139Proof82
  · exact adaptive142Third139Proof83
  · exact adaptive142Third139Proof84
  · exact adaptive142Third139Proof85
  · exact adaptive142Third139Proof86
  · exact adaptive142Third139Proof87
  · exact adaptive142Third139Proof88
  · exact adaptive142Third139Proof89
  · exact adaptive142Third139Proof90
  · exact adaptive142Third139Proof91
  · exact adaptive142Third139Proof92
  · exact adaptive142Third139Proof93
  · exact adaptive142Third139Proof94
  · exact adaptive142Third139Proof95
  · exact adaptive142Third139Proof96
  · exact adaptive142Third139Proof97
  · exact adaptive142Third139Proof98
  · exact adaptive142Third139Proof99
  · exact adaptive142Third139Proof100
  · exact adaptive142Third139Proof101
  · exact adaptive142Third139Proof102
  · exact adaptive142Third139Proof103
  · exact adaptive142Third139Proof104
  · exact adaptive142Third139Proof105
  · exact adaptive142Third139Proof106
  · exact adaptive142Third139Proof107
  · exact adaptive142Third139Proof108
  · exact adaptive142Third139Proof109
  · exact adaptive142Third139Proof110
  · exact adaptive142Third139Proof145

#print axioms adaptive142Third139Proof81

theorem adaptive142Third139Proof212 : runCachedNode 511 129933 Adaptive142Third139Node212 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 129933 Adaptive142Third139Node212 = [90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 123, 124, 126, 129, 135] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive142Third139Proof213
  · exact adaptive142Third139Proof214
  · exact adaptive142Third139Proof215
  · exact adaptive142Third139Proof216
  · exact adaptive142Third139Proof217
  · exact adaptive142Third139Proof218
  · exact adaptive142Third139Proof219
  · exact adaptive142Third139Proof220
  · exact adaptive142Third139Proof221
  · exact adaptive142Third139Proof222
  · exact adaptive142Third139Proof223
  · exact adaptive142Third139Proof224
  · exact adaptive142Third139Proof225
  · exact adaptive142Third139Proof226
  · exact adaptive142Third139Proof227
  · exact adaptive142Third139Proof228
  · exact adaptive142Third139Proof229
  · exact adaptive142Third139Proof230
  · exact adaptive142Third139Proof231
  · exact adaptive142Third139Proof232
  · exact adaptive142Third139Proof233
  · exact adaptive142Third139Proof234
  · exact adaptive142Third139Proof235
  · exact adaptive142Third139Proof236
  · exact adaptive142Third139Proof237
  · exact adaptive142Third139Proof238
  · exact adaptive142Third139Proof239
  · exact adaptive142Third139Proof240
  · exact adaptive142Third139Proof241
  · exact adaptive142Third139Proof242
  · exact adaptive142Third139Proof243
  · exact adaptive142Third139Proof244
  · exact adaptive142Third139Proof245
  · exact adaptive142Third139Proof246
  · exact adaptive142Third139Proof247
  · exact adaptive142Third139Proof248
  · exact adaptive142Third139Proof249

#print axioms adaptive142Third139Proof212

theorem adaptive142Third139Proof181 : runCachedNode 511 129933 Adaptive142Third139Node181 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 129933 Adaptive142Third139Node181 = [102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 129, 130, 132, 135, 136] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive142Third139Proof182
  · exact adaptive142Third139Proof183
  · exact adaptive142Third139Proof184
  · exact adaptive142Third139Proof185
  · exact adaptive142Third139Proof186
  · exact adaptive142Third139Proof187
  · exact adaptive142Third139Proof188
  · exact adaptive142Third139Proof189
  · exact adaptive142Third139Proof190
  · exact adaptive142Third139Proof191
  · exact adaptive142Third139Proof192
  · exact adaptive142Third139Proof193
  · exact adaptive142Third139Proof194
  · exact adaptive142Third139Proof195
  · exact adaptive142Third139Proof196
  · exact adaptive142Third139Proof197
  · exact adaptive142Third139Proof198
  · exact adaptive142Third139Proof199
  · exact adaptive142Third139Proof200
  · exact adaptive142Third139Proof201
  · exact adaptive142Third139Proof202
  · exact adaptive142Third139Proof203
  · exact adaptive142Third139Proof204
  · exact adaptive142Third139Proof205
  · exact adaptive142Third139Proof206
  · exact adaptive142Third139Proof207
  · exact adaptive142Third139Proof208
  · exact adaptive142Third139Proof209
  · exact adaptive142Third139Proof210
  · exact adaptive142Third139Proof211
  · exact adaptive142Third139Proof212

#print axioms adaptive142Third139Proof181

theorem adaptive142Third139Proof281 : runCachedNode 511 129933 Adaptive142Third139Node281 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 129933 Adaptive142Third139Node281 = [90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 124, 125, 128, 134] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive142Third139Proof282
  · exact adaptive142Third139Proof283
  · exact adaptive142Third139Proof284
  · exact adaptive142Third139Proof285
  · exact adaptive142Third139Proof286
  · exact adaptive142Third139Proof287
  · exact adaptive142Third139Proof288
  · exact adaptive142Third139Proof289
  · exact adaptive142Third139Proof290
  · exact adaptive142Third139Proof291
  · exact adaptive142Third139Proof292
  · exact adaptive142Third139Proof293
  · exact adaptive142Third139Proof294
  · exact adaptive142Third139Proof295
  · exact adaptive142Third139Proof296
  · exact adaptive142Third139Proof297
  · exact adaptive142Third139Proof298
  · exact adaptive142Third139Proof299
  · exact adaptive142Third139Proof300
  · exact adaptive142Third139Proof301
  · exact adaptive142Third139Proof302
  · exact adaptive142Third139Proof303
  · exact adaptive142Third139Proof304
  · exact adaptive142Third139Proof305
  · exact adaptive142Third139Proof306
  · exact adaptive142Third139Proof307
  · exact adaptive142Third139Proof308
  · exact adaptive142Third139Proof309
  · exact adaptive142Third139Proof310
  · exact adaptive142Third139Proof311
  · exact adaptive142Third139Proof312
  · exact adaptive142Third139Proof313
  · exact adaptive142Third139Proof314
  · exact adaptive142Third139Proof315
  · exact adaptive142Third139Proof316
  · exact adaptive142Third139Proof317
  · exact adaptive142Third139Proof318

#print axioms adaptive142Third139Proof281

end NineSeparatedSubsetSums
