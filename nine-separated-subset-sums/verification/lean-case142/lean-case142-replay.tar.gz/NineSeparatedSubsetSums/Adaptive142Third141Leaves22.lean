import NineSeparatedSubsetSums.Adaptive142Third141State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third141Proof133 : runCachedNode 511 130276 Adaptive142Third141Node133 = false := by
  decide +kernel

#print axioms adaptive142Third141Proof133

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third141Proof77 : runCachedNode 511 130276 Adaptive142Third141Node77 = false := by
  decide +kernel

#print axioms adaptive142Third141Proof77

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third141Proof424 : runCachedNode 511 130276 Adaptive142Third141Node424 = false := by
  decide +kernel

#print axioms adaptive142Third141Proof424

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third141Proof274 : runCachedNode 511 130276 Adaptive142Third141Node274 = false := by
  decide +kernel

#print axioms adaptive142Third141Proof274

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third141Proof101 : runCachedNode 511 130276 Adaptive142Third141Node101 = false := by
  decide +kernel

#print axioms adaptive142Third141Proof101

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third141Proof327 : runCachedNode 511 130276 Adaptive142Third141Node327 = false := by
  decide +kernel

#print axioms adaptive142Third141Proof327

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third141Proof53 : runCachedNode 511 130276 Adaptive142Third141Node53 = false := by
  decide +kernel

#print axioms adaptive142Third141Proof53

end NineSeparatedSubsetSums
