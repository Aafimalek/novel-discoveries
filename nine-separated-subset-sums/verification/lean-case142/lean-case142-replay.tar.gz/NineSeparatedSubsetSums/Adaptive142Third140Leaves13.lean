import NineSeparatedSubsetSums.Adaptive142Third140State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third140Proof234 : runCachedNode 511 130107 Adaptive142Third140Node234 = false := by
  decide +kernel

#print axioms adaptive142Third140Proof234

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third140Proof49 : runCachedNode 511 130107 Adaptive142Third140Node49 = false := by
  decide +kernel

#print axioms adaptive142Third140Proof49

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third140Proof32 : runCachedNode 511 130107 Adaptive142Third140Node32 = false := by
  decide +kernel

#print axioms adaptive142Third140Proof32

end NineSeparatedSubsetSums
