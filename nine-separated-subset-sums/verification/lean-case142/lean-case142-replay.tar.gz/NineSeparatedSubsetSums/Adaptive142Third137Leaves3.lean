import NineSeparatedSubsetSums.Adaptive142Third137State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third137Proof128 : runCachedNode 511 129593 Adaptive142Third137Node128 = false := by
  decide +kernel

#print axioms adaptive142Third137Proof128

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third137Proof156 : runCachedNode 511 129593 Adaptive142Third137Node156 = false := by
  decide +kernel

#print axioms adaptive142Third137Proof156

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third137Proof102 : runCachedNode 511 129593 Adaptive142Third137Node102 = false := by
  decide +kernel

#print axioms adaptive142Third137Proof102

end NineSeparatedSubsetSums
