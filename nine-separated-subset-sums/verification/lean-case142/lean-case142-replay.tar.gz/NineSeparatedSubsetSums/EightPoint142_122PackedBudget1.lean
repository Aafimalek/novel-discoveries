import NineSeparatedSubsetSums.EightPoint142_122PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct142_122_1_budget :
    FourPointNumeric.packedBudget 20 packedOct142_122_1 264 = 82740126 := by decide +kernel

#print axioms packedOct142_122_1_budget

end NineSeparatedSubsetSums
