import NineSeparatedSubsetSums.Adaptive142Third120State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third120Proof0 : runCachedNode 511 125872 Adaptive142Third120Node0 = false := by
  decide +kernel

#print axioms adaptive142Third120Proof0

end NineSeparatedSubsetSums
