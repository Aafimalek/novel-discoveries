import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive142Third105Node0 : CachedSearchNode :=
  ⟨4, 104, computeCenteredMask [148,142,105], 395, 53093⟩

end NineSeparatedSubsetSums
