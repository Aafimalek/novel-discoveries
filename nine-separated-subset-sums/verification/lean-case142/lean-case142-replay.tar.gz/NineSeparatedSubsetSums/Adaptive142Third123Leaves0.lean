import NineSeparatedSubsetSums.Adaptive142Third123State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third123Proof0 : runCachedNode 511 126511 Adaptive142Third123Node0 = false := by
  decide +kernel

#print axioms adaptive142Third123Proof0

end NineSeparatedSubsetSums
