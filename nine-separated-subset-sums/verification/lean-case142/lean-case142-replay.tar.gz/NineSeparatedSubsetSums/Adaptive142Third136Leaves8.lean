import NineSeparatedSubsetSums.Adaptive142Third136State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third136Proof114 : runCachedNode 511 129404 Adaptive142Third136Node114 = false := by
  decide +kernel

#print axioms adaptive142Third136Proof114

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third136Proof140 : runCachedNode 511 129404 Adaptive142Third136Node140 = false := by
  decide +kernel

#print axioms adaptive142Third136Proof140

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third136Proof84 : runCachedNode 511 129404 Adaptive142Third136Node84 = false := by
  decide +kernel

#print axioms adaptive142Third136Proof84

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third136Proof21 : runCachedNode 511 129404 Adaptive142Third136Node21 = false := by
  decide +kernel

#print axioms adaptive142Third136Proof21

end NineSeparatedSubsetSums
