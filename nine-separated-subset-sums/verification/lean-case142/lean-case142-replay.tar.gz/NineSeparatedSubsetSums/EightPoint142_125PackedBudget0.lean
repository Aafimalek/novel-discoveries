import NineSeparatedSubsetSums.EightPoint142_125PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct142_125_0_budget :
    FourPointNumeric.packedBudget 20 packedOct142_125_0 483 = 87596223 := by decide +kernel

#print axioms packedOct142_125_0_budget

end NineSeparatedSubsetSums
