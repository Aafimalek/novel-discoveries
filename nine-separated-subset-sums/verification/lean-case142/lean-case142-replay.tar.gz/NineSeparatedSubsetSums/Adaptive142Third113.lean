import NineSeparatedSubsetSums.Adaptive142Third113Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint142Checked

namespace NineSeparatedSubsetSums


theorem adaptive142Third113 : NoDescendingTailAfterThird 142 113 :=
  noDescendingThirdTail_of_cached 142 113 111874 (fun t ht nd => max148_second142_fourPoint_moment_bound (113::t) (by simp [ht]) nd) adaptive142Third113Proof0

#print axioms adaptive142Third113

end NineSeparatedSubsetSums
