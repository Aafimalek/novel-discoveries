import NineSeparatedSubsetSums.Adaptive142Third138State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third138Proof16 : runCachedNode 511 129778 Adaptive142Third138Node16 = false := by
  decide +kernel

#print axioms adaptive142Third138Proof16

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third138Proof49 : runCachedNode 511 129778 Adaptive142Third138Node49 = false := by
  decide +kernel

#print axioms adaptive142Third138Proof49

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third138Proof168 : runCachedNode 511 129778 Adaptive142Third138Node168 = false := by
  decide +kernel

#print axioms adaptive142Third138Proof168

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third138Proof74 : runCachedNode 511 129778 Adaptive142Third138Node74 = false := by
  decide +kernel

#print axioms adaptive142Third138Proof74

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third138Proof3 : runCachedNode 511 129778 Adaptive142Third138Node3 = false := by
  decide +kernel

#print axioms adaptive142Third138Proof3

end NineSeparatedSubsetSums
