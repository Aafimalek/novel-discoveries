import NineSeparatedSubsetSums.Adaptive142Third140State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third140Proof134 : runCachedNode 511 130107 Adaptive142Third140Node134 = false := by
  decide +kernel

#print axioms adaptive142Third140Proof134

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third140Proof200 : runCachedNode 511 130107 Adaptive142Third140Node200 = false := by
  decide +kernel

#print axioms adaptive142Third140Proof200

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third140Proof75 : runCachedNode 511 130107 Adaptive142Third140Node75 = false := by
  decide +kernel

#print axioms adaptive142Third140Proof75

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third140Proof46 : runCachedNode 511 130107 Adaptive142Third140Node46 = false := by
  decide +kernel

#print axioms adaptive142Third140Proof46

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third140Proof266 : runCachedNode 511 130107 Adaptive142Third140Node266 = false := by
  decide +kernel

#print axioms adaptive142Third140Proof266

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third140Proof24 : runCachedNode 511 130107 Adaptive142Third140Node24 = false := by
  decide +kernel

#print axioms adaptive142Third140Proof24

end NineSeparatedSubsetSums
