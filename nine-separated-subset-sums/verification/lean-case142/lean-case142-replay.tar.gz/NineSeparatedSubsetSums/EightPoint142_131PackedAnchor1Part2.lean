import NineSeparatedSubsetSums.EightPoint142_131PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint142_131PackedAnchor1Part2 :
    ∀ j : Fin 8, 2431242 ≤ FourPointNumeric.octPackedCharge 142 131 20 packedOct142_131_1
      (2*((j.val : Int)+240)+0) := by decide +kernel

end NineSeparatedSubsetSums
