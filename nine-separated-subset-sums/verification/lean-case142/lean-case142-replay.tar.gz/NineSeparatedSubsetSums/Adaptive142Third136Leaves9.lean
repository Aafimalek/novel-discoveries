import NineSeparatedSubsetSums.Adaptive142Third136State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third136Proof141 : runCachedNode 511 129404 Adaptive142Third136Node141 = false := by
  decide +kernel

#print axioms adaptive142Third136Proof141

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third136Proof165 : runCachedNode 511 129404 Adaptive142Third136Node165 = false := by
  decide +kernel

#print axioms adaptive142Third136Proof165

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third136Proof13 : runCachedNode 511 129404 Adaptive142Third136Node13 = false := by
  decide +kernel

#print axioms adaptive142Third136Proof13

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third136Proof43 : runCachedNode 511 129404 Adaptive142Third136Node43 = false := by
  decide +kernel

#print axioms adaptive142Third136Proof43

end NineSeparatedSubsetSums
