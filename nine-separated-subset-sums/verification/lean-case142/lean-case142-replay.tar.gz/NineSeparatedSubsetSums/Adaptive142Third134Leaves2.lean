import NineSeparatedSubsetSums.Adaptive142Third134State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third134Proof20 : runCachedNode 511 129144 Adaptive142Third134Node20 = false := by
  decide +kernel

#print axioms adaptive142Third134Proof20

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third134Proof72 : runCachedNode 511 129144 Adaptive142Third134Node72 = false := by
  decide +kernel

#print axioms adaptive142Third134Proof72

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third134Proof69 : runCachedNode 511 129144 Adaptive142Third134Node69 = false := by
  decide +kernel

#print axioms adaptive142Third134Proof69

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third134Proof4 : runCachedNode 511 129144 Adaptive142Third134Node4 = false := by
  decide +kernel

#print axioms adaptive142Third134Proof4

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive142Third134Proof23 : runCachedNode 511 129144 Adaptive142Third134Node23 = false := by
  decide +kernel

#print axioms adaptive142Third134Proof23

end NineSeparatedSubsetSums
