import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive142Third106Node0 : CachedSearchNode :=
  ⟨4, 105, computeCenteredMask [148,142,106], 396, 53304⟩

end NineSeparatedSubsetSums
