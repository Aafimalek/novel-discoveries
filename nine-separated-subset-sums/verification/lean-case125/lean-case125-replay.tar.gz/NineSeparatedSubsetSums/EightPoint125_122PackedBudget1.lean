import NineSeparatedSubsetSums.EightPoint125_122PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct125_122_1_budget :
    FourPointNumeric.packedBudget 20 packedOct125_122_1 382 = 83558506 := by decide +kernel

#print axioms packedOct125_122_1_budget

end NineSeparatedSubsetSums
