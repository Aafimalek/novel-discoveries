import NineSeparatedSubsetSums.EightPoint125_121PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint125_121PackedAnchor0Part0 :
    ∀ j : Fin 120, 2282377 ≤ FourPointNumeric.octPackedCharge 125 121 20 packedOct125_121_0
      (2*((j.val : Int)+0)+0) := by decide +kernel

end NineSeparatedSubsetSums
