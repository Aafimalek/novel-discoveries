import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive125Third109Node0 : CachedSearchNode :=
  ⟨4, 108, computeCenteredMask [148,125,109], 382, 49410⟩

end NineSeparatedSubsetSums
