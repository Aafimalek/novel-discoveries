import NineSeparatedSubsetSums.EightPoint125_121PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint125_121PackedAnchor1Part0 :
    ∀ j : Fin 120, 2285985 ≤ FourPointNumeric.octPackedCharge 125 121 20 packedOct125_121_1
      (2*((j.val : Int)+0)+1) := by decide +kernel

end NineSeparatedSubsetSums
