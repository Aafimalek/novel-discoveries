import NineSeparatedSubsetSums.Adaptive125Third111State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive125Third111Proof0 : runCachedNode 511 109272 Adaptive125Third111Node0 = false := by
  decide +kernel

#print axioms adaptive125Third111Proof0

end NineSeparatedSubsetSums
