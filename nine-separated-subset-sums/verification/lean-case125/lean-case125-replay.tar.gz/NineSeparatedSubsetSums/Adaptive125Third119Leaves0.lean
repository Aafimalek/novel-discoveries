import NineSeparatedSubsetSums.Adaptive125Third119State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive125Third119Proof0 : runCachedNode 511 122497 Adaptive125Third119Node0 = false := by
  decide +kernel

#print axioms adaptive125Third119Proof0

end NineSeparatedSubsetSums
