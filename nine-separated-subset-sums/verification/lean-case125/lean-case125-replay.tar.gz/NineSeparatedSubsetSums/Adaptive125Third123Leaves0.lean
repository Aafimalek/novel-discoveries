import NineSeparatedSubsetSums.Adaptive125Third123State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive125Third123Proof0 : runCachedNode 511 123450 Adaptive125Third123Node0 = false := by
  decide +kernel

#print axioms adaptive125Third123Proof0

end NineSeparatedSubsetSums
