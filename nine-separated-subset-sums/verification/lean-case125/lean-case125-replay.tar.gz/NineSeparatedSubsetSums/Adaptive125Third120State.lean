import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive125Third120Node0 : CachedSearchNode :=
  ⟨4, 119, computeCenteredMask [148,125,120], 393, 51929⟩

end NineSeparatedSubsetSums
