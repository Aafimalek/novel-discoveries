import NineSeparatedSubsetSums.Adaptive125Third114Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint125Checked

namespace NineSeparatedSubsetSums


theorem adaptive125Third114 : NoDescendingTailAfterThird 125 114 :=
  noDescendingThirdTail_of_cached 125 114 109272 (fun t ht nd => max148_second125_fourPoint_moment_bound (114::t) (by simp [ht]) nd) adaptive125Third114Proof0

#print axioms adaptive125Third114

end NineSeparatedSubsetSums
