import NineSeparatedSubsetSums.Adaptive125Third112Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint125Checked

namespace NineSeparatedSubsetSums


theorem adaptive125Third112 : NoDescendingTailAfterThird 125 112 :=
  noDescendingThirdTail_of_cached 125 112 109272 (fun t ht nd => max148_second125_fourPoint_moment_bound (112::t) (by simp [ht]) nd) adaptive125Third112Proof0

#print axioms adaptive125Third112

end NineSeparatedSubsetSums
