import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive125Third122Node0 : CachedSearchNode :=
  ⟨4, 121, computeCenteredMask [148,125,122], 395, 52413⟩

end NineSeparatedSubsetSums
