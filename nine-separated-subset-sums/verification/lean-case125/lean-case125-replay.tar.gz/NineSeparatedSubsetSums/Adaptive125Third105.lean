import NineSeparatedSubsetSums.Adaptive125Third105Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint125Checked

namespace NineSeparatedSubsetSums


theorem adaptive125Third105 : NoDescendingTailAfterThird 125 105 :=
  noDescendingThirdTail_of_cached 125 105 109272 (fun t ht nd => max148_second125_fourPoint_moment_bound (105::t) (by simp [ht]) nd) adaptive125Third105Proof0

#print axioms adaptive125Third105

end NineSeparatedSubsetSums
