import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive125Third112Node0 : CachedSearchNode :=
  ⟨4, 111, computeCenteredMask [148,125,112], 385, 50073⟩

end NineSeparatedSubsetSums
