import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive125Third123Node0 : CachedSearchNode :=
  ⟨4, 122, computeCenteredMask [148,125,123], 396, 52658⟩

end NineSeparatedSubsetSums
