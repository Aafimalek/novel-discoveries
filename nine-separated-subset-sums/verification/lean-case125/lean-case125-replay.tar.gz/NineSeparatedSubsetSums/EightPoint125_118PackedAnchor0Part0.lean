import NineSeparatedSubsetSums.EightPoint125_118PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint125_118PackedAnchor0Part0 :
    ∀ j : Fin 120, 2173346 ≤ FourPointNumeric.octPackedCharge 125 118 20 packedOct125_118_0
      (2*((j.val : Int)+0)+1) := by decide +kernel

end NineSeparatedSubsetSums
