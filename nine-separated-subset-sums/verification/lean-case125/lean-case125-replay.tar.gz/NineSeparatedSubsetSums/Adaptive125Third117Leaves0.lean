import NineSeparatedSubsetSums.Adaptive125Third117State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive125Third117Proof0 : runCachedNode 511 122145 Adaptive125Third117Node0 = false := by
  decide +kernel

#print axioms adaptive125Third117Proof0

end NineSeparatedSubsetSums
