import NineSeparatedSubsetSums.Adaptive125Third113Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint125Checked

namespace NineSeparatedSubsetSums


theorem adaptive125Third113 : NoDescendingTailAfterThird 125 113 :=
  noDescendingThirdTail_of_cached 125 113 109272 (fun t ht nd => max148_second125_fourPoint_moment_bound (113::t) (by simp [ht]) nd) adaptive125Third113Proof0

#print axioms adaptive125Third113

end NineSeparatedSubsetSums
