import NineSeparatedSubsetSums.Adaptive125Third108Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint125Checked

namespace NineSeparatedSubsetSums


theorem adaptive125Third108 : NoDescendingTailAfterThird 125 108 :=
  noDescendingThirdTail_of_cached 125 108 109272 (fun t ht nd => max148_second125_fourPoint_moment_bound (108::t) (by simp [ht]) nd) adaptive125Third108Proof0

#print axioms adaptive125Third108

end NineSeparatedSubsetSums
