import NineSeparatedSubsetSums.FourPoint125PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem fourPoint125PackedAnchor0Part0 :
    ∀ j : Fin 120, 1111992 ≤ FourPointNumeric.packedCharge 125 20 packedWeight125_0
      (2*((j.val : Int)+0)+1) := by decide +kernel

end NineSeparatedSubsetSums
