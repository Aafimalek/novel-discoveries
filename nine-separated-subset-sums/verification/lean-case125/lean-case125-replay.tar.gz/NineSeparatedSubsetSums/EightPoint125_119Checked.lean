import NineSeparatedSubsetSums.EightPointPackedGeometry
import NineSeparatedSubsetSums.EightPoint125_119PackedBudget0
import NineSeparatedSubsetSums.EightPoint125_119PackedAnchor0Part0
import NineSeparatedSubsetSums.EightPoint125_119PackedAnchor0Part1
import NineSeparatedSubsetSums.EightPoint125_119PackedBudget1
import NineSeparatedSubsetSums.EightPoint125_119PackedAnchor1Part0
import NineSeparatedSubsetSums.EightPoint125_119PackedAnchor1Part1

namespace NineSeparatedSubsetSums

private theorem packedOct125_119Anchor0 :
  ∀ j : Fin 471, ((j.val : Int)+125+119)%2=0 →
    2184815 ≤ FourPointNumeric.octPackedCharge 125 119 20 packedOct125_119_0 (j.val : Int) := by
  intro j hj
  let k := (j.val-0)/2
  have hk : k < 236 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+0 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint125_119PackedAnchor0Part0 z
    rwa [he,hrep] at ht
  let z : Fin 116 := ⟨k-120, by omega⟩
  have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
  have ht := eightPoint125_119PackedAnchor0Part1 z
  rwa [he,hrep] at ht

private theorem packedOct125_119Anchor1 :
  ∀ j : Fin 471, ((j.val : Int)+125+119)%2=1 →
    2186153 ≤ FourPointNumeric.octPackedCharge 125 119 20 packedOct125_119_1 (j.val : Int) := by
  intro j hj
  let k := (j.val-1)/2
  have hk : k < 235 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+1 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint125_119PackedAnchor1Part0 z
    rwa [he,hrep] at ht
  let z : Fin 115 := ⟨k-120, by omega⟩
  have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
  have ht := eightPoint125_119PackedAnchor1Part1 z
  rwa [he,hrep] at ht

def packedOctCertificate125_119_0 : EightPointCertificate 125 119 0 122497 :=
  eightPointCertificateOfPacked 125 119 0 122497 2184815 20 packedOct125_119_0 391 471
    (by decide +kernel) (by decide) packedOct125_119Anchor0
    (by rw [packedOct125_119_0_budget]; decide)

def packedOctCertificate125_119_1 : EightPointCertificate 125 119 1 122497 :=
  eightPointCertificateOfPacked 125 119 1 122497 2186153 20 packedOct125_119_1 392 471
    (by decide +kernel) (by decide) packedOct125_119Anchor1
    (by rw [packedOct125_119_1_budget]; decide)

theorem max148_second125_third119_eightPoint_moment_bound (tail : List ℕ) (len : tail.length=6)
    (distinct : (natSubsetSums (148::125::119::tail)).Nodup) :
    122497 ≤ ((148::125::119::tail).map (· ^ 2)).sum := by
  apply eightPointNatMomentLower 125 119 122497 tail len distinct
  intro p hp
  by_cases h : p=0
  · subst p
    exact packedOctCertificate125_119_0
  · have he : p=1 := hp.resolve_left h
    subst p
    exact packedOctCertificate125_119_1

#print axioms max148_second125_third119_eightPoint_moment_bound

end NineSeparatedSubsetSums
