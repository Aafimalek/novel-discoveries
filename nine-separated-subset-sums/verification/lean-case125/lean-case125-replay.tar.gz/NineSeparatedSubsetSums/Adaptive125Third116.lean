import NineSeparatedSubsetSums.Adaptive125Third116Joins0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint125Checked

namespace NineSeparatedSubsetSums


theorem adaptive125Third116 : NoDescendingTailAfterThird 125 116 :=
  noDescendingThirdTail_of_cached 125 116 109272 (fun t ht nd => max148_second125_fourPoint_moment_bound (116::t) (by simp [ht]) nd) adaptive125Third116Proof0

#print axioms adaptive125Third116

end NineSeparatedSubsetSums
