import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive125Third118Node0 : CachedSearchNode :=
  ⟨4, 117, computeCenteredMask [148,125,118], 391, 51453⟩

end NineSeparatedSubsetSums
