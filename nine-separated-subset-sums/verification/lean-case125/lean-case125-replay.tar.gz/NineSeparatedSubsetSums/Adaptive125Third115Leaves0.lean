import NineSeparatedSubsetSums.Adaptive125Third115State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive125Third115Proof13 : runCachedNode 511 109272 Adaptive125Third115Node13 = false := by
  decide +kernel

#print axioms adaptive125Third115Proof13

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive125Third115Proof12 : runCachedNode 511 109272 Adaptive125Third115Node12 = false := by
  decide +kernel

#print axioms adaptive125Third115Proof12

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive125Third115Proof11 : runCachedNode 511 109272 Adaptive125Third115Node11 = false := by
  decide +kernel

#print axioms adaptive125Third115Proof11

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive125Third115Proof10 : runCachedNode 511 109272 Adaptive125Third115Node10 = false := by
  decide +kernel

#print axioms adaptive125Third115Proof10

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive125Third115Proof9 : runCachedNode 511 109272 Adaptive125Third115Node9 = false := by
  decide +kernel

#print axioms adaptive125Third115Proof9

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive125Third115Proof8 : runCachedNode 511 109272 Adaptive125Third115Node8 = false := by
  decide +kernel

#print axioms adaptive125Third115Proof8

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive125Third115Proof3 : runCachedNode 511 109272 Adaptive125Third115Node3 = false := by
  decide +kernel

#print axioms adaptive125Third115Proof3

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive125Third115Proof1 : runCachedNode 511 109272 Adaptive125Third115Node1 = false := by
  decide +kernel

#print axioms adaptive125Third115Proof1

end NineSeparatedSubsetSums
