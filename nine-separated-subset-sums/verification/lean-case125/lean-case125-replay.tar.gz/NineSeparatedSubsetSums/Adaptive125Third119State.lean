import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive125Third119Node0 : CachedSearchNode :=
  ⟨4, 118, computeCenteredMask [148,125,119], 392, 51690⟩

end NineSeparatedSubsetSums
