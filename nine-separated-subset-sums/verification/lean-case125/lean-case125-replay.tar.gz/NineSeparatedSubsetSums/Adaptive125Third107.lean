import NineSeparatedSubsetSums.Adaptive125Third107Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint125Checked

namespace NineSeparatedSubsetSums


theorem adaptive125Third107 : NoDescendingTailAfterThird 125 107 :=
  noDescendingThirdTail_of_cached 125 107 109272 (fun t ht nd => max148_second125_fourPoint_moment_bound (107::t) (by simp [ht]) nd) adaptive125Third107Proof0

#print axioms adaptive125Third107

end NineSeparatedSubsetSums
