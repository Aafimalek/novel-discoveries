import NineSeparatedSubsetSums.Adaptive125Third111Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint125Checked

namespace NineSeparatedSubsetSums


theorem adaptive125Third111 : NoDescendingTailAfterThird 125 111 :=
  noDescendingThirdTail_of_cached 125 111 109272 (fun t ht nd => max148_second125_fourPoint_moment_bound (111::t) (by simp [ht]) nd) adaptive125Third111Proof0

#print axioms adaptive125Third111

end NineSeparatedSubsetSums
