import NineSeparatedSubsetSums.EightPointPackedGeometry
import NineSeparatedSubsetSums.EightPoint125_121PackedBudget0
import NineSeparatedSubsetSums.EightPoint125_121PackedAnchor0Part0
import NineSeparatedSubsetSums.EightPoint125_121PackedAnchor0Part1
import NineSeparatedSubsetSums.EightPoint125_121PackedAnchor0Part2
import NineSeparatedSubsetSums.EightPoint125_121PackedBudget1
import NineSeparatedSubsetSums.EightPoint125_121PackedAnchor1Part0
import NineSeparatedSubsetSums.EightPoint125_121PackedAnchor1Part1
import NineSeparatedSubsetSums.EightPoint125_121PackedAnchor1Part2

namespace NineSeparatedSubsetSums

private theorem packedOct125_121Anchor0 :
  ∀ j : Fin 484, ((j.val : Int)+125+121)%2=0 →
    2282377 ≤ FourPointNumeric.octPackedCharge 125 121 20 packedOct125_121_0 (j.val : Int) := by
  intro j hj
  let k := (j.val-0)/2
  have hk : k < 242 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+0 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint125_121PackedAnchor0Part0 z
    rwa [he,hrep] at ht
  by_cases h1 : k < 240
  · let z : Fin 120 := ⟨k-120, by omega⟩
    have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
    have ht := eightPoint125_121PackedAnchor0Part1 z
    rwa [he,hrep] at ht
  let z : Fin 2 := ⟨k-240, by omega⟩
  have he : (z.val : Int)+240 = k := by dsimp [z] <;> omega
  have ht := eightPoint125_121PackedAnchor0Part2 z
  rwa [he,hrep] at ht

private theorem packedOct125_121Anchor1 :
  ∀ j : Fin 484, ((j.val : Int)+125+121)%2=1 →
    2285985 ≤ FourPointNumeric.octPackedCharge 125 121 20 packedOct125_121_1 (j.val : Int) := by
  intro j hj
  let k := (j.val-1)/2
  have hk : k < 242 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+1 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint125_121PackedAnchor1Part0 z
    rwa [he,hrep] at ht
  by_cases h1 : k < 240
  · let z : Fin 120 := ⟨k-120, by omega⟩
    have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
    have ht := eightPoint125_121PackedAnchor1Part1 z
    rwa [he,hrep] at ht
  let z : Fin 2 := ⟨k-240, by omega⟩
  have he : (z.val : Int)+240 = k := by dsimp [z] <;> omega
  have ht := eightPoint125_121PackedAnchor1Part2 z
  rwa [he,hrep] at ht

def packedOctCertificate125_121_0 : EightPointCertificate 125 121 0 122967 :=
  eightPointCertificateOfPacked 125 121 0 122967 2282377 20 packedOct125_121_0 387 484
    (by decide +kernel) (by decide) packedOct125_121Anchor0
    (by rw [packedOct125_121_0_budget]; decide)

def packedOctCertificate125_121_1 : EightPointCertificate 125 121 1 122967 :=
  eightPointCertificateOfPacked 125 121 1 122967 2285985 20 packedOct125_121_1 480 484
    (by decide +kernel) (by decide) packedOct125_121Anchor1
    (by rw [packedOct125_121_1_budget]; decide)

theorem max148_second125_third121_eightPoint_moment_bound (tail : List ℕ) (len : tail.length=6)
    (distinct : (natSubsetSums (148::125::121::tail)).Nodup) :
    122967 ≤ ((148::125::121::tail).map (· ^ 2)).sum := by
  apply eightPointNatMomentLower 125 121 122967 tail len distinct
  intro p hp
  by_cases h : p=0
  · subst p
    exact packedOctCertificate125_121_0
  · have he : p=1 := hp.resolve_left h
    subst p
    exact packedOctCertificate125_121_1

#print axioms max148_second125_third121_eightPoint_moment_bound

end NineSeparatedSubsetSums
