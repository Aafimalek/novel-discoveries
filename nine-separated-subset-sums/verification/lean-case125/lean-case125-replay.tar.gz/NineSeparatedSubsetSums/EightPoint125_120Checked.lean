import NineSeparatedSubsetSums.EightPointPackedGeometry
import NineSeparatedSubsetSums.EightPoint125_120PackedBudget0
import NineSeparatedSubsetSums.EightPoint125_120PackedAnchor0Part0
import NineSeparatedSubsetSums.EightPoint125_120PackedAnchor0Part1
import NineSeparatedSubsetSums.EightPoint125_120PackedBudget1
import NineSeparatedSubsetSums.EightPoint125_120PackedAnchor1Part0
import NineSeparatedSubsetSums.EightPoint125_120PackedAnchor1Part1

namespace NineSeparatedSubsetSums

private theorem packedOct125_120Anchor0 :
  ∀ j : Fin 475, ((j.val : Int)+125+120)%2=0 →
    2219182 ≤ FourPointNumeric.octPackedCharge 125 120 20 packedOct125_120_0 (j.val : Int) := by
  intro j hj
  let k := (j.val-1)/2
  have hk : k < 237 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+1 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint125_120PackedAnchor0Part0 z
    rwa [he,hrep] at ht
  let z : Fin 117 := ⟨k-120, by omega⟩
  have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
  have ht := eightPoint125_120PackedAnchor0Part1 z
  rwa [he,hrep] at ht

private theorem packedOct125_120Anchor1 :
  ∀ j : Fin 475, ((j.val : Int)+125+120)%2=1 →
    2219780 ≤ FourPointNumeric.octPackedCharge 125 120 20 packedOct125_120_1 (j.val : Int) := by
  intro j hj
  let k := (j.val-0)/2
  have hk : k < 238 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+0 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint125_120PackedAnchor1Part0 z
    rwa [he,hrep] at ht
  let z : Fin 118 := ⟨k-120, by omega⟩
  have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
  have ht := eightPoint125_120PackedAnchor1Part1 z
  rwa [he,hrep] at ht

def packedOctCertificate125_120_0 : EightPointCertificate 125 120 0 122727 :=
  eightPointCertificateOfPacked 125 120 0 122727 2219182 20 packedOct125_120_0 385 475
    (by decide +kernel) (by decide) packedOct125_120Anchor0
    (by rw [packedOct125_120_0_budget]; decide)

def packedOctCertificate125_120_1 : EightPointCertificate 125 120 1 122727 :=
  eightPointCertificateOfPacked 125 120 1 122727 2219780 20 packedOct125_120_1 382 475
    (by decide +kernel) (by decide) packedOct125_120Anchor1
    (by rw [packedOct125_120_1_budget]; decide)

theorem max148_second125_third120_eightPoint_moment_bound (tail : List ℕ) (len : tail.length=6)
    (distinct : (natSubsetSums (148::125::120::tail)).Nodup) :
    122727 ≤ ((148::125::120::tail).map (· ^ 2)).sum := by
  apply eightPointNatMomentLower 125 120 122727 tail len distinct
  intro p hp
  by_cases h : p=0
  · subst p
    exact packedOctCertificate125_120_0
  · have he : p=1 := hp.resolve_left h
    subst p
    exact packedOctCertificate125_120_1

#print axioms max148_second125_third120_eightPoint_moment_bound

end NineSeparatedSubsetSums
