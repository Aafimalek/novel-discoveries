import NineSeparatedSubsetSums.FourPoint125PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem fourPoint125PackedAnchor1Part1 :
    ∀ j : Fin 120, 1111988 ≤ FourPointNumeric.packedCharge 125 20 packedWeight125_1
      (2*((j.val : Int)+120)+0) := by decide +kernel

end NineSeparatedSubsetSums
