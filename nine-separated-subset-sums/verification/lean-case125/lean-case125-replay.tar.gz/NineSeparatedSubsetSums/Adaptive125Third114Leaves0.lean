import NineSeparatedSubsetSums.Adaptive125Third114State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive125Third114Proof0 : runCachedNode 511 109272 Adaptive125Third114Node0 = false := by
  decide +kernel

#print axioms adaptive125Third114Proof0

end NineSeparatedSubsetSums
