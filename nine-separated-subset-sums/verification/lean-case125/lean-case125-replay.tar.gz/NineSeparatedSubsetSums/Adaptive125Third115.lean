import NineSeparatedSubsetSums.Adaptive125Third115Joins0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint125Checked

namespace NineSeparatedSubsetSums


theorem adaptive125Third115 : NoDescendingTailAfterThird 125 115 :=
  noDescendingThirdTail_of_cached 125 115 109272 (fun t ht nd => max148_second125_fourPoint_moment_bound (115::t) (by simp [ht]) nd) adaptive125Third115Proof0

#print axioms adaptive125Third115

end NineSeparatedSubsetSums
