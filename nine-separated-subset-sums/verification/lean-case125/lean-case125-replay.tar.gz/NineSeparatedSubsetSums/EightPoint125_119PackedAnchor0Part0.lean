import NineSeparatedSubsetSums.EightPoint125_119PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint125_119PackedAnchor0Part0 :
    ∀ j : Fin 120, 2184815 ≤ FourPointNumeric.octPackedCharge 125 119 20 packedOct125_119_0
      (2*((j.val : Int)+0)+0) := by decide +kernel

end NineSeparatedSubsetSums
