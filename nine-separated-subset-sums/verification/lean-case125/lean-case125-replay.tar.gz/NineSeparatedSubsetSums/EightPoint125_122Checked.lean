import NineSeparatedSubsetSums.EightPointPackedGeometry
import NineSeparatedSubsetSums.EightPoint125_122PackedBudget0
import NineSeparatedSubsetSums.EightPoint125_122PackedAnchor0Part0
import NineSeparatedSubsetSums.EightPoint125_122PackedAnchor0Part1
import NineSeparatedSubsetSums.EightPoint125_122PackedAnchor0Part2
import NineSeparatedSubsetSums.EightPoint125_122PackedBudget1
import NineSeparatedSubsetSums.EightPoint125_122PackedAnchor1Part0
import NineSeparatedSubsetSums.EightPoint125_122PackedAnchor1Part1
import NineSeparatedSubsetSums.EightPoint125_122PackedAnchor1Part2

namespace NineSeparatedSubsetSums

private theorem packedOct125_122Anchor0 :
  ∀ j : Fin 484, ((j.val : Int)+125+122)%2=0 →
    2291828 ≤ FourPointNumeric.octPackedCharge 125 122 20 packedOct125_122_0 (j.val : Int) := by
  intro j hj
  let k := (j.val-1)/2
  have hk : k < 242 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+1 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint125_122PackedAnchor0Part0 z
    rwa [he,hrep] at ht
  by_cases h1 : k < 240
  · let z : Fin 120 := ⟨k-120, by omega⟩
    have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
    have ht := eightPoint125_122PackedAnchor0Part1 z
    rwa [he,hrep] at ht
  let z : Fin 2 := ⟨k-240, by omega⟩
  have he : (z.val : Int)+240 = k := by dsimp [z] <;> omega
  have ht := eightPoint125_122PackedAnchor0Part2 z
  rwa [he,hrep] at ht

private theorem packedOct125_122Anchor1 :
  ∀ j : Fin 484, ((j.val : Int)+125+122)%2=1 →
    2291440 ≤ FourPointNumeric.octPackedCharge 125 122 20 packedOct125_122_1 (j.val : Int) := by
  intro j hj
  let k := (j.val-0)/2
  have hk : k < 242 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+0 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint125_122PackedAnchor1Part0 z
    rwa [he,hrep] at ht
  by_cases h1 : k < 240
  · let z : Fin 120 := ⟨k-120, by omega⟩
    have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
    have ht := eightPoint125_122PackedAnchor1Part1 z
    rwa [he,hrep] at ht
  let z : Fin 2 := ⟨k-240, by omega⟩
  have he : (z.val : Int)+240 = k := by dsimp [z] <;> omega
  have ht := eightPoint125_122PackedAnchor1Part2 z
  rwa [he,hrep] at ht

def packedOctCertificate125_122_0 : EightPointCertificate 125 122 0 123230 :=
  eightPointCertificateOfPacked 125 122 0 123230 2291828 20 packedOct125_122_0 391 484
    (by decide +kernel) (by decide) packedOct125_122Anchor0
    (by rw [packedOct125_122_0_budget]; decide)

def packedOctCertificate125_122_1 : EightPointCertificate 125 122 1 123230 :=
  eightPointCertificateOfPacked 125 122 1 123230 2291440 20 packedOct125_122_1 382 484
    (by decide +kernel) (by decide) packedOct125_122Anchor1
    (by rw [packedOct125_122_1_budget]; decide)

theorem max148_second125_third122_eightPoint_moment_bound (tail : List ℕ) (len : tail.length=6)
    (distinct : (natSubsetSums (148::125::122::tail)).Nodup) :
    123230 ≤ ((148::125::122::tail).map (· ^ 2)).sum := by
  apply eightPointNatMomentLower 125 122 123230 tail len distinct
  intro p hp
  by_cases h : p=0
  · subst p
    exact packedOctCertificate125_122_0
  · have he : p=1 := hp.resolve_left h
    subst p
    exact packedOctCertificate125_122_1

#print axioms max148_second125_third122_eightPoint_moment_bound

end NineSeparatedSubsetSums
