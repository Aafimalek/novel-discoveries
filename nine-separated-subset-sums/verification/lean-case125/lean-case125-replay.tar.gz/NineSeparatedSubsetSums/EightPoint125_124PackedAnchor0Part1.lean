import NineSeparatedSubsetSums.EightPoint125_124PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint125_124PackedAnchor0Part1 :
    ∀ j : Fin 120, 2338933 ≤ FourPointNumeric.octPackedCharge 125 124 20 packedOct125_124_0
      (2*((j.val : Int)+120)+1) := by decide +kernel

end NineSeparatedSubsetSums
