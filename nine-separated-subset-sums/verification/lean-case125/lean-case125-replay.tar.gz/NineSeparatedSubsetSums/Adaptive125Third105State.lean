import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive125Third105Node0 : CachedSearchNode :=
  ⟨4, 104, computeCenteredMask [148,125,105], 378, 48554⟩

end NineSeparatedSubsetSums
