import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive125Third121Node0 : CachedSearchNode :=
  ⟨4, 120, computeCenteredMask [148,125,121], 394, 52170⟩

end NineSeparatedSubsetSums
