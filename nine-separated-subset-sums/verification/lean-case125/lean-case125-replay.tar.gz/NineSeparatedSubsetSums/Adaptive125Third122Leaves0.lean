import NineSeparatedSubsetSums.Adaptive125Third122State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive125Third122Proof0 : runCachedNode 511 123230 Adaptive125Third122Node0 = false := by
  decide +kernel

#print axioms adaptive125Third122Proof0

end NineSeparatedSubsetSums
