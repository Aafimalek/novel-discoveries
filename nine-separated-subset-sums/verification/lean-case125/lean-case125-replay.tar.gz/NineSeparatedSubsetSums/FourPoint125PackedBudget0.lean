import NineSeparatedSubsetSums.FourPoint125PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedWeight125_0_budget :
    FourPointNumeric.packedBudget 20 packedWeight125_0 603 = 86387584 := by decide +kernel

#print axioms packedWeight125_0_budget

end NineSeparatedSubsetSums
