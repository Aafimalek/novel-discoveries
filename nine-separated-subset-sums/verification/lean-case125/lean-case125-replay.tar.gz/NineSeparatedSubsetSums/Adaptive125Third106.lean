import NineSeparatedSubsetSums.Adaptive125Third106Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint125Checked

namespace NineSeparatedSubsetSums


theorem adaptive125Third106 : NoDescendingTailAfterThird 125 106 :=
  noDescendingThirdTail_of_cached 125 106 109272 (fun t ht nd => max148_second125_fourPoint_moment_bound (106::t) (by simp [ht]) nd) adaptive125Third106Proof0

#print axioms adaptive125Third106

end NineSeparatedSubsetSums
