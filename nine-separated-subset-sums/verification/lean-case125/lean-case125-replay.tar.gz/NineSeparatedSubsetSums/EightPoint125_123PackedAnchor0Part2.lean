import NineSeparatedSubsetSums.EightPoint125_123PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint125_123PackedAnchor0Part2 :
    ∀ j : Fin 4, 2320507 ≤ FourPointNumeric.octPackedCharge 125 123 20 packedOct125_123_0
      (2*((j.val : Int)+240)+0) := by decide +kernel

end NineSeparatedSubsetSums
