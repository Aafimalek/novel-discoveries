import NineSeparatedSubsetSums.FourPointPackedGeometry
import NineSeparatedSubsetSums.FourPoint125PackedBudget0
import NineSeparatedSubsetSums.FourPoint125PackedAnchor0Part0
import NineSeparatedSubsetSums.FourPoint125PackedAnchor0Part1
import NineSeparatedSubsetSums.FourPoint125PackedAnchor0Part2
import NineSeparatedSubsetSums.FourPoint125PackedBudget1
import NineSeparatedSubsetSums.FourPoint125PackedAnchor1Part0
import NineSeparatedSubsetSums.FourPoint125PackedAnchor1Part1
import NineSeparatedSubsetSums.FourPoint125PackedAnchor1Part2

namespace NineSeparatedSubsetSums

private theorem packed125Anchor0 :
  ∀ j : Fin 491, ((j.val : Int)+125)%2=0 →
    1111992 ≤ FourPointNumeric.packedCharge 125 20 packedWeight125_0 (j.val : Int) := by
  intro j hj
  let k := (j.val-1)/2
  have hk : k < 245 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+1 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := fourPoint125PackedAnchor0Part0 z
    rwa [he,hrep] at ht
  by_cases h1 : k < 240
  · let z : Fin 120 := ⟨k-120, by omega⟩
    have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
    have ht := fourPoint125PackedAnchor0Part1 z
    rwa [he,hrep] at ht
  let z : Fin 5 := ⟨k-240, by omega⟩
  have he : (z.val : Int)+240 = k := by dsimp [z] <;> omega
  have ht := fourPoint125PackedAnchor0Part2 z
  rwa [he,hrep] at ht

private theorem packed125Anchor1 :
  ∀ j : Fin 491, ((j.val : Int)+125)%2=1 →
    1111988 ≤ FourPointNumeric.packedCharge 125 20 packedWeight125_1 (j.val : Int) := by
  intro j hj
  let k := (j.val-0)/2
  have hk : k < 246 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+0 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := fourPoint125PackedAnchor1Part0 z
    rwa [he,hrep] at ht
  by_cases h1 : k < 240
  · let z : Fin 120 := ⟨k-120, by omega⟩
    have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
    have ht := fourPoint125PackedAnchor1Part1 z
    rwa [he,hrep] at ht
  let z : Fin 6 := ⟨k-240, by omega⟩
  have he : (z.val : Int)+240 = k := by dsimp [z] <;> omega
  have ht := fourPoint125PackedAnchor1Part2 z
  rwa [he,hrep] at ht

def packedCertificate125_0 : FourPointCertificate 125 0 109272 :=
  fourPointCertificateOfPacked 125 0 109272 1111992 20 packedWeight125_0 603 491
    (by decide +kernel) (by decide) (by decide) packed125Anchor0
    (by rw [packedWeight125_0_budget]; decide)

def packedCertificate125_1 : FourPointCertificate 125 1 109272 :=
  fourPointCertificateOfPacked 125 1 109272 1111988 20 packedWeight125_1 382 491
    (by decide +kernel) (by decide) (by decide) packed125Anchor1
    (by rw [packedWeight125_1_budget]; decide)

theorem max148_second125_fourPoint_moment_bound (tail : List ℕ) (len : tail.length=7)
    (distinct : (natSubsetSums (148::125::tail)).Nodup) :
    109272 ≤ ((148::125::tail).map (· ^ 2)).sum := by
  apply fourPointNatMomentLower 125 109272 tail len distinct
  intro p hp
  by_cases h : p=0
  · subst p
    exact packedCertificate125_0
  · have he : p=1 := hp.resolve_left h
    subst p
    exact packedCertificate125_1

#print axioms max148_second125_fourPoint_moment_bound

end NineSeparatedSubsetSums
