import NineSeparatedSubsetSums.Adaptive125Third120State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive125Third120Proof0 : runCachedNode 511 122727 Adaptive125Third120Node0 = false := by
  decide +kernel

#print axioms adaptive125Third120Proof0

end NineSeparatedSubsetSums
