import NineSeparatedSubsetSums.EightPoint125_120PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint125_120PackedAnchor1Part0 :
    ∀ j : Fin 120, 2219780 ≤ FourPointNumeric.octPackedCharge 125 120 20 packedOct125_120_1
      (2*((j.val : Int)+0)+0) := by decide +kernel

end NineSeparatedSubsetSums
