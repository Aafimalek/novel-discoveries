import NineSeparatedSubsetSums.EightPoint125_123PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct125_123_0_budget :
    FourPointNumeric.packedBudget 20 packedOct125_123_0 393 = 85306230 := by decide +kernel

#print axioms packedOct125_123_0_budget

end NineSeparatedSubsetSums
