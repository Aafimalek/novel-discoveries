import NineSeparatedSubsetSums.EightPoint125_120PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct125_120_1_budget :
    FourPointNumeric.packedBudget 20 packedOct125_120_1 382 = 79230146 := by decide +kernel

#print axioms packedOct125_120_1_budget

end NineSeparatedSubsetSums
