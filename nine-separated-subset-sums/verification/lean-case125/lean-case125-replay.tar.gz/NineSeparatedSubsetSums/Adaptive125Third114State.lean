import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive125Third114Node0 : CachedSearchNode :=
  ⟨4, 113, computeCenteredMask [148,125,114], 387, 50525⟩

end NineSeparatedSubsetSums
