import NineSeparatedSubsetSums.EightPoint125_123PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint125_123PackedAnchor1Part2 :
    ∀ j : Fin 4, 2323533 ≤ FourPointNumeric.octPackedCharge 125 123 20 packedOct125_123_1
      (2*((j.val : Int)+240)+1) := by decide +kernel

end NineSeparatedSubsetSums
