import NineSeparatedSubsetSums.EightPoint125_121PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct125_121_1_budget :
    FourPointNumeric.packedBudget 20 packedOct125_121_1 480 = 83344096 := by decide +kernel

#print axioms packedOct125_121_1_budget

end NineSeparatedSubsetSums
