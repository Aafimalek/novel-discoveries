import NineSeparatedSubsetSums.EightPointPackedGeometry
import NineSeparatedSubsetSums.EightPoint125_118PackedBudget0
import NineSeparatedSubsetSums.EightPoint125_118PackedAnchor0Part0
import NineSeparatedSubsetSums.EightPoint125_118PackedAnchor0Part1
import NineSeparatedSubsetSums.EightPoint125_118PackedBudget1
import NineSeparatedSubsetSums.EightPoint125_118PackedAnchor1Part0
import NineSeparatedSubsetSums.EightPoint125_118PackedAnchor1Part1

namespace NineSeparatedSubsetSums

private theorem packedOct125_118Anchor0 :
  ∀ j : Fin 470, ((j.val : Int)+125+118)%2=0 →
    2173346 ≤ FourPointNumeric.octPackedCharge 125 118 20 packedOct125_118_0 (j.val : Int) := by
  intro j hj
  let k := (j.val-1)/2
  have hk : k < 235 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+1 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint125_118PackedAnchor0Part0 z
    rwa [he,hrep] at ht
  let z : Fin 115 := ⟨k-120, by omega⟩
  have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
  have ht := eightPoint125_118PackedAnchor0Part1 z
  rwa [he,hrep] at ht

private theorem packedOct125_118Anchor1 :
  ∀ j : Fin 470, ((j.val : Int)+125+118)%2=1 →
    2174412 ≤ FourPointNumeric.octPackedCharge 125 118 20 packedOct125_118_1 (j.val : Int) := by
  intro j hj
  let k := (j.val-0)/2
  have hk : k < 235 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+0 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint125_118PackedAnchor1Part0 z
    rwa [he,hrep] at ht
  let z : Fin 115 := ⟨k-120, by omega⟩
  have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
  have ht := eightPoint125_118PackedAnchor1Part1 z
  rwa [he,hrep] at ht

def packedOctCertificate125_118_0 : EightPointCertificate 125 118 0 122311 :=
  eightPointCertificateOfPacked 125 118 0 122311 2173346 20 packedOct125_118_0 389 470
    (by decide +kernel) (by decide) packedOct125_118Anchor0
    (by rw [packedOct125_118_0_budget]; decide)

def packedOctCertificate125_118_1 : EightPointCertificate 125 118 1 122311 :=
  eightPointCertificateOfPacked 125 118 1 122311 2174412 20 packedOct125_118_1 398 470
    (by decide +kernel) (by decide) packedOct125_118Anchor1
    (by rw [packedOct125_118_1_budget]; decide)

theorem max148_second125_third118_eightPoint_moment_bound (tail : List ℕ) (len : tail.length=6)
    (distinct : (natSubsetSums (148::125::118::tail)).Nodup) :
    122311 ≤ ((148::125::118::tail).map (· ^ 2)).sum := by
  apply eightPointNatMomentLower 125 118 122311 tail len distinct
  intro p hp
  by_cases h : p=0
  · subst p
    exact packedOctCertificate125_118_0
  · have he : p=1 := hp.resolve_left h
    subst p
    exact packedOctCertificate125_118_1

#print axioms max148_second125_third118_eightPoint_moment_bound

end NineSeparatedSubsetSums
