import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive125Third108Node0 : CachedSearchNode :=
  ⟨4, 107, computeCenteredMask [148,125,108], 381, 49193⟩

end NineSeparatedSubsetSums
