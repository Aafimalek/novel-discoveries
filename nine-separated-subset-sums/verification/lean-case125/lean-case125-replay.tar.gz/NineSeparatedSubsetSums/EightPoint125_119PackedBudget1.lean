import NineSeparatedSubsetSums.EightPoint125_119PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct125_119_1_budget :
    FourPointNumeric.packedBudget 20 packedOct125_119_1 392 = 77195430 := by decide +kernel

#print axioms packedOct125_119_1_budget

end NineSeparatedSubsetSums
