import NineSeparatedSubsetSums.EightPoint125_122PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint125_122PackedAnchor0Part1 :
    ∀ j : Fin 120, 2291828 ≤ FourPointNumeric.octPackedCharge 125 122 20 packedOct125_122_0
      (2*((j.val : Int)+120)+1) := by decide +kernel

end NineSeparatedSubsetSums
