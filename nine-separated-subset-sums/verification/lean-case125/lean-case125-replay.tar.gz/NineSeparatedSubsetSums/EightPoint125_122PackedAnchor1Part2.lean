import NineSeparatedSubsetSums.EightPoint125_122PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint125_122PackedAnchor1Part2 :
    ∀ j : Fin 2, 2291440 ≤ FourPointNumeric.octPackedCharge 125 122 20 packedOct125_122_1
      (2*((j.val : Int)+240)+0) := by decide +kernel

end NineSeparatedSubsetSums
