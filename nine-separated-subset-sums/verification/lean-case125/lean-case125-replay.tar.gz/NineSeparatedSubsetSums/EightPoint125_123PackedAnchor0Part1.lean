import NineSeparatedSubsetSums.EightPoint125_123PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint125_123PackedAnchor0Part1 :
    ∀ j : Fin 120, 2320507 ≤ FourPointNumeric.octPackedCharge 125 123 20 packedOct125_123_0
      (2*((j.val : Int)+120)+0) := by decide +kernel

end NineSeparatedSubsetSums
