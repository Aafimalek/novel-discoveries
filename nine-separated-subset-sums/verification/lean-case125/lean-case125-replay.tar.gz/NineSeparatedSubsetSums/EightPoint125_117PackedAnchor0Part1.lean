import NineSeparatedSubsetSums.EightPoint125_117PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint125_117PackedAnchor0Part1 :
    ∀ j : Fin 115, 2163105 ≤ FourPointNumeric.octPackedCharge 125 117 20 packedOct125_117_0
      (2*((j.val : Int)+120)+0) := by decide +kernel

end NineSeparatedSubsetSums
