import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive125Third113Node0 : CachedSearchNode :=
  ⟨4, 112, computeCenteredMask [148,125,113], 386, 50298⟩

end NineSeparatedSubsetSums
