import NineSeparatedSubsetSums.Adaptive125Third109Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint125Checked

namespace NineSeparatedSubsetSums


theorem adaptive125Third109 : NoDescendingTailAfterThird 125 109 :=
  noDescendingThirdTail_of_cached 125 109 109272 (fun t ht nd => max148_second125_fourPoint_moment_bound (109::t) (by simp [ht]) nd) adaptive125Third109Proof0

#print axioms adaptive125Third109

end NineSeparatedSubsetSums
