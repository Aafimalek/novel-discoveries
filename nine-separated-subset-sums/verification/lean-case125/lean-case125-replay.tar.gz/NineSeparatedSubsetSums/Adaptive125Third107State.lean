import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive125Third107Node0 : CachedSearchNode :=
  ⟨4, 106, computeCenteredMask [148,125,107], 380, 48978⟩

end NineSeparatedSubsetSums
