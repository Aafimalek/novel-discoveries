import NineSeparatedSubsetSums.FourPoint125PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedWeight125_1_budget :
    FourPointNumeric.packedBudget 20 packedWeight125_1 382 = 86387424 := by decide +kernel

#print axioms packedWeight125_1_budget

end NineSeparatedSubsetSums
