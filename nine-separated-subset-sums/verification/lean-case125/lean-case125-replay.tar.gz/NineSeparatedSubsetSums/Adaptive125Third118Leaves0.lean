import NineSeparatedSubsetSums.Adaptive125Third118State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive125Third118Proof0 : runCachedNode 511 122311 Adaptive125Third118Node0 = false := by
  decide +kernel

#print axioms adaptive125Third118Proof0

end NineSeparatedSubsetSums
