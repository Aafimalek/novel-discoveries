import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive125Third106Node0 : CachedSearchNode :=
  ⟨4, 105, computeCenteredMask [148,125,106], 379, 48765⟩

end NineSeparatedSubsetSums
