import NineSeparatedSubsetSums.EightPoint125_122PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct125_122_0_budget :
    FourPointNumeric.packedBudget 20 packedOct125_122_0 391 = 83583243 := by decide +kernel

#print axioms packedOct125_122_0_budget

end NineSeparatedSubsetSums
