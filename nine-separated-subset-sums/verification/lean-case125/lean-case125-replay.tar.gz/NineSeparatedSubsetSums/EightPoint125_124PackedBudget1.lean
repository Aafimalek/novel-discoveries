import NineSeparatedSubsetSums.EightPoint125_124PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct125_124_1_budget :
    FourPointNumeric.packedBudget 20 packedOct125_124_1 396 = 86070018 := by decide +kernel

#print axioms packedOct125_124_1_budget

end NineSeparatedSubsetSums
