import NineSeparatedSubsetSums.EightPointPackedGeometry
import NineSeparatedSubsetSums.EightPoint125_117PackedBudget0
import NineSeparatedSubsetSums.EightPoint125_117PackedAnchor0Part0
import NineSeparatedSubsetSums.EightPoint125_117PackedAnchor0Part1
import NineSeparatedSubsetSums.EightPoint125_117PackedBudget1
import NineSeparatedSubsetSums.EightPoint125_117PackedAnchor1Part0
import NineSeparatedSubsetSums.EightPoint125_117PackedAnchor1Part1

namespace NineSeparatedSubsetSums

private theorem packedOct125_117Anchor0 :
  ∀ j : Fin 469, ((j.val : Int)+125+117)%2=0 →
    2163105 ≤ FourPointNumeric.octPackedCharge 125 117 20 packedOct125_117_0 (j.val : Int) := by
  intro j hj
  let k := (j.val-0)/2
  have hk : k < 235 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+0 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint125_117PackedAnchor0Part0 z
    rwa [he,hrep] at ht
  let z : Fin 115 := ⟨k-120, by omega⟩
  have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
  have ht := eightPoint125_117PackedAnchor0Part1 z
  rwa [he,hrep] at ht

private theorem packedOct125_117Anchor1 :
  ∀ j : Fin 469, ((j.val : Int)+125+117)%2=1 →
    2160501 ≤ FourPointNumeric.octPackedCharge 125 117 20 packedOct125_117_1 (j.val : Int) := by
  intro j hj
  let k := (j.val-1)/2
  have hk : k < 234 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+1 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint125_117PackedAnchor1Part0 z
    rwa [he,hrep] at ht
  let z : Fin 114 := ⟨k-120, by omega⟩
  have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
  have ht := eightPoint125_117PackedAnchor1Part1 z
  rwa [he,hrep] at ht

def packedOctCertificate125_117_0 : EightPointCertificate 125 117 0 122145 :=
  eightPointCertificateOfPacked 125 117 0 122145 2163105 20 packedOct125_117_0 267 469
    (by decide +kernel) (by decide) packedOct125_117Anchor0
    (by rw [packedOct125_117_0_budget]; decide)

def packedOctCertificate125_117_1 : EightPointCertificate 125 117 1 122145 :=
  eightPointCertificateOfPacked 125 117 1 122145 2160501 20 packedOct125_117_1 396 469
    (by decide +kernel) (by decide) packedOct125_117Anchor1
    (by rw [packedOct125_117_1_budget]; decide)

theorem max148_second125_third117_eightPoint_moment_bound (tail : List ℕ) (len : tail.length=6)
    (distinct : (natSubsetSums (148::125::117::tail)).Nodup) :
    122145 ≤ ((148::125::117::tail).map (· ^ 2)).sum := by
  apply eightPointNatMomentLower 125 117 122145 tail len distinct
  intro p hp
  by_cases h : p=0
  · subst p
    exact packedOctCertificate125_117_0
  · have he : p=1 := hp.resolve_left h
    subst p
    exact packedOctCertificate125_117_1

#print axioms max148_second125_third117_eightPoint_moment_bound

end NineSeparatedSubsetSums
