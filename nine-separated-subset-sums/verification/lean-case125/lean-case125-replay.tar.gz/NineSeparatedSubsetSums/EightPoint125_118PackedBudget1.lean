import NineSeparatedSubsetSums.EightPoint125_118PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct125_118_1_budget :
    FourPointNumeric.packedBudget 20 packedOct125_118_1 398 = 76539428 := by decide +kernel

#print axioms packedOct125_118_1_budget

end NineSeparatedSubsetSums
