import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive125Third117Node0 : CachedSearchNode :=
  ⟨4, 116, computeCenteredMask [148,125,117], 390, 51218⟩

end NineSeparatedSubsetSums
