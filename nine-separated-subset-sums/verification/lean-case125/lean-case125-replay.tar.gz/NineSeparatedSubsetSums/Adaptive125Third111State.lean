import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive125Third111Node0 : CachedSearchNode :=
  ⟨4, 110, computeCenteredMask [148,125,111], 384, 49850⟩

end NineSeparatedSubsetSums
