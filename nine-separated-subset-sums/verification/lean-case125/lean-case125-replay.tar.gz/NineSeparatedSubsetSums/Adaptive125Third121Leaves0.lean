import NineSeparatedSubsetSums.Adaptive125Third121State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive125Third121Proof0 : runCachedNode 511 122967 Adaptive125Third121Node0 = false := by
  decide +kernel

#print axioms adaptive125Third121Proof0

end NineSeparatedSubsetSums
