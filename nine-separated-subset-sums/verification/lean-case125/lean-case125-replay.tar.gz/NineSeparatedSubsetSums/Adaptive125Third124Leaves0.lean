import NineSeparatedSubsetSums.Adaptive125Third124State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive125Third124Proof0 : runCachedNode 511 123686 Adaptive125Third124Node0 = false := by
  decide +kernel

#print axioms adaptive125Third124Proof0

end NineSeparatedSubsetSums
