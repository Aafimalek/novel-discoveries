import NineSeparatedSubsetSums.EightPoint125_118PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct125_118_0_budget :
    FourPointNumeric.packedBudget 20 packedOct125_118_0 389 = 76471270 := by decide +kernel

#print axioms packedOct125_118_0_budget

end NineSeparatedSubsetSums
