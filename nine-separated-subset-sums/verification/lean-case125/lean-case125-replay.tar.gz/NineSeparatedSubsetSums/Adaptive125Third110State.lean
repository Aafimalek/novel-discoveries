import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive125Third110Node0 : CachedSearchNode :=
  ⟨4, 109, computeCenteredMask [148,125,110], 383, 49629⟩

end NineSeparatedSubsetSums
