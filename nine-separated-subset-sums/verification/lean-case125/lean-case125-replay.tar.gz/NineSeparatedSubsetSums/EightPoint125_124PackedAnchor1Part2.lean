import NineSeparatedSubsetSums.EightPoint125_124PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint125_124PackedAnchor1Part2 :
    ∀ j : Fin 5, 2334326 ≤ FourPointNumeric.octPackedCharge 125 124 20 packedOct125_124_1
      (2*((j.val : Int)+240)+0) := by decide +kernel

end NineSeparatedSubsetSums
