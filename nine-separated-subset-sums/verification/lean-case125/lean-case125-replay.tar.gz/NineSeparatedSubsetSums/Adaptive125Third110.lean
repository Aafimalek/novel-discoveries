import NineSeparatedSubsetSums.Adaptive125Third110Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint125Checked

namespace NineSeparatedSubsetSums


theorem adaptive125Third110 : NoDescendingTailAfterThird 125 110 :=
  noDescendingThirdTail_of_cached 125 110 109272 (fun t ht nd => max148_second125_fourPoint_moment_bound (110::t) (by simp [ht]) nd) adaptive125Third110Proof0

#print axioms adaptive125Third110

end NineSeparatedSubsetSums
