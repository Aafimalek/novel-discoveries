import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive125Third124Node0 : CachedSearchNode :=
  ⟨4, 123, computeCenteredMask [148,125,124], 397, 52905⟩

end NineSeparatedSubsetSums
