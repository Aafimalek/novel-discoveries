import NineSeparatedSubsetSums.EightPoint125_117PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint125_117PackedAnchor1Part0 :
    ∀ j : Fin 120, 2160501 ≤ FourPointNumeric.octPackedCharge 125 117 20 packedOct125_117_1
      (2*((j.val : Int)+0)+1) := by decide +kernel

end NineSeparatedSubsetSums
