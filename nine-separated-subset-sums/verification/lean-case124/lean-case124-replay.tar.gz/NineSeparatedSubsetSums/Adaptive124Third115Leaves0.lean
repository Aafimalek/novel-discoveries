import NineSeparatedSubsetSums.Adaptive124Third115State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive124Third115Proof13 : runCachedNode 511 109260 Adaptive124Third115Node13 = false := by
  decide +kernel

#print axioms adaptive124Third115Proof13

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive124Third115Proof12 : runCachedNode 511 109260 Adaptive124Third115Node12 = false := by
  decide +kernel

#print axioms adaptive124Third115Proof12

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive124Third115Proof11 : runCachedNode 511 109260 Adaptive124Third115Node11 = false := by
  decide +kernel

#print axioms adaptive124Third115Proof11

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive124Third115Proof10 : runCachedNode 511 109260 Adaptive124Third115Node10 = false := by
  decide +kernel

#print axioms adaptive124Third115Proof10

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive124Third115Proof9 : runCachedNode 511 109260 Adaptive124Third115Node9 = false := by
  decide +kernel

#print axioms adaptive124Third115Proof9

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive124Third115Proof8 : runCachedNode 511 109260 Adaptive124Third115Node8 = false := by
  decide +kernel

#print axioms adaptive124Third115Proof8

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive124Third115Proof4 : runCachedNode 511 109260 Adaptive124Third115Node4 = false := by
  decide +kernel

#print axioms adaptive124Third115Proof4

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive124Third115Proof1 : runCachedNode 511 109260 Adaptive124Third115Node1 = false := by
  decide +kernel

#print axioms adaptive124Third115Proof1

end NineSeparatedSubsetSums
