import NineSeparatedSubsetSums.Adaptive124Third115Joins0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint124Checked

namespace NineSeparatedSubsetSums


theorem adaptive124Third115 : NoDescendingTailAfterThird 124 115 :=
  noDescendingThirdTail_of_cached 124 115 109260 (fun t ht nd => max148_second124_fourPoint_moment_bound (115::t) (by simp [ht]) nd) adaptive124Third115Proof0

#print axioms adaptive124Third115

end NineSeparatedSubsetSums
