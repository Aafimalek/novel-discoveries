import NineSeparatedSubsetSums.EightPoint124_119PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint124_119PackedAnchor1Part1 :
    ∀ j : Fin 116, 2193158 ≤ FourPointNumeric.octPackedCharge 124 119 20 packedOct124_119_1
      (2*((j.val : Int)+120)+0) := by decide +kernel

end NineSeparatedSubsetSums
