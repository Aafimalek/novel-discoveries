import NineSeparatedSubsetSums.Adaptive124Third116Joins0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint124Checked

namespace NineSeparatedSubsetSums


theorem adaptive124Third116 : NoDescendingTailAfterThird 124 116 :=
  noDescendingThirdTail_of_cached 124 116 109260 (fun t ht nd => max148_second124_fourPoint_moment_bound (116::t) (by simp [ht]) nd) adaptive124Third116Proof0

#print axioms adaptive124Third116

end NineSeparatedSubsetSums
