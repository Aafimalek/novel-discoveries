import NineSeparatedSubsetSums.EightPoint124_121PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct124_121_0_budget :
    FourPointNumeric.packedBudget 20 packedOct124_121_0 497 = 82669063 := by decide +kernel

#print axioms packedOct124_121_0_budget

end NineSeparatedSubsetSums
