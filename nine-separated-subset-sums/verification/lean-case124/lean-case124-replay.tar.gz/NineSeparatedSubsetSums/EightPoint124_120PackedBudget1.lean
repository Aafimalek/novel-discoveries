import NineSeparatedSubsetSums.EightPoint124_120PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct124_120_1_budget :
    FourPointNumeric.packedBudget 20 packedOct124_120_1 386 = 78547024 := by decide +kernel

#print axioms packedOct124_120_1_budget

end NineSeparatedSubsetSums
