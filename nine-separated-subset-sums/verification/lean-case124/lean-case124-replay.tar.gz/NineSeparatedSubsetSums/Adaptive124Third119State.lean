import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive124Third119Node0 : CachedSearchNode :=
  ⟨4, 118, computeCenteredMask [148,124,119], 391, 51441⟩

end NineSeparatedSubsetSums
