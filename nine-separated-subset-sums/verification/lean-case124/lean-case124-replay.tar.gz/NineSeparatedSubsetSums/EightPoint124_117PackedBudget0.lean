import NineSeparatedSubsetSums.EightPoint124_117PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct124_117_0_budget :
    FourPointNumeric.packedBudget 20 packedOct124_117_0 507 = 76883395 := by decide +kernel

#print axioms packedOct124_117_0_budget

end NineSeparatedSubsetSums
