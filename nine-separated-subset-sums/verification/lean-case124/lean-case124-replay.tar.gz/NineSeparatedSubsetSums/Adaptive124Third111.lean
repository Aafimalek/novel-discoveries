import NineSeparatedSubsetSums.Adaptive124Third111Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint124Checked

namespace NineSeparatedSubsetSums


theorem adaptive124Third111 : NoDescendingTailAfterThird 124 111 :=
  noDescendingThirdTail_of_cached 124 111 109260 (fun t ht nd => max148_second124_fourPoint_moment_bound (111::t) (by simp [ht]) nd) adaptive124Third111Proof0

#print axioms adaptive124Third111

end NineSeparatedSubsetSums
