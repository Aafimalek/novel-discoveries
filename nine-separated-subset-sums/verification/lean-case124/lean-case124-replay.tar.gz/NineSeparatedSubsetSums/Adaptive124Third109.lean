import NineSeparatedSubsetSums.Adaptive124Third109Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint124Checked

namespace NineSeparatedSubsetSums


theorem adaptive124Third109 : NoDescendingTailAfterThird 124 109 :=
  noDescendingThirdTail_of_cached 124 109 109260 (fun t ht nd => max148_second124_fourPoint_moment_bound (109::t) (by simp [ht]) nd) adaptive124Third109Proof0

#print axioms adaptive124Third109

end NineSeparatedSubsetSums
