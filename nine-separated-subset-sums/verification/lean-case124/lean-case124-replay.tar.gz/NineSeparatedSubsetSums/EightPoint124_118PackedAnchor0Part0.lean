import NineSeparatedSubsetSums.EightPoint124_118PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint124_118PackedAnchor0Part0 :
    ∀ j : Fin 120, 2171619 ≤ FourPointNumeric.octPackedCharge 124 118 20 packedOct124_118_0
      (2*((j.val : Int)+0)+0) := by decide +kernel

end NineSeparatedSubsetSums
