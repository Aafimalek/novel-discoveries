import NineSeparatedSubsetSums.Adaptive124Third106Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint124Checked

namespace NineSeparatedSubsetSums


theorem adaptive124Third106 : NoDescendingTailAfterThird 124 106 :=
  noDescendingThirdTail_of_cached 124 106 109260 (fun t ht nd => max148_second124_fourPoint_moment_bound (106::t) (by simp [ht]) nd) adaptive124Third106Proof0

#print axioms adaptive124Third106

end NineSeparatedSubsetSums
