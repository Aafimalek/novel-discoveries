import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive124Third110Node0 : CachedSearchNode :=
  ⟨4, 109, computeCenteredMask [148,124,110], 382, 49380⟩

end NineSeparatedSubsetSums
