import NineSeparatedSubsetSums.EightPoint124_123PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint124_123PackedAnchor1Part2 :
    ∀ j : Fin 3, 2298519 ≤ FourPointNumeric.octPackedCharge 124 123 20 packedOct124_123_1
      (2*((j.val : Int)+240)+0) := by decide +kernel

end NineSeparatedSubsetSums
