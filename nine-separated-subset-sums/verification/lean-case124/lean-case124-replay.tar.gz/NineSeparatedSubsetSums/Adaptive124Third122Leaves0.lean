import NineSeparatedSubsetSums.Adaptive124Third122State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive124Third122Proof0 : runCachedNode 511 122970 Adaptive124Third122Node0 = false := by
  decide +kernel

#print axioms adaptive124Third122Proof0

end NineSeparatedSubsetSums
