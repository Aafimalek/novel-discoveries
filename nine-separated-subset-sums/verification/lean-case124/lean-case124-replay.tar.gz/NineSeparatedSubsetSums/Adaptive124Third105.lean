import NineSeparatedSubsetSums.Adaptive124Third105Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint124Checked

namespace NineSeparatedSubsetSums


theorem adaptive124Third105 : NoDescendingTailAfterThird 124 105 :=
  noDescendingThirdTail_of_cached 124 105 109260 (fun t ht nd => max148_second124_fourPoint_moment_bound (105::t) (by simp [ht]) nd) adaptive124Third105Proof0

#print axioms adaptive124Third105

end NineSeparatedSubsetSums
