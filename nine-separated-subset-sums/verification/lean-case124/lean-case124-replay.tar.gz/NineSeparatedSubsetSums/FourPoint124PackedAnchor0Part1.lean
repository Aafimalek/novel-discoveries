import NineSeparatedSubsetSums.FourPoint124PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem fourPoint124PackedAnchor0Part1 :
    ∀ j : Fin 120, 1102464 ≤ FourPointNumeric.packedCharge 124 20 packedWeight124_0
      (2*((j.val : Int)+120)+0) := by decide +kernel

end NineSeparatedSubsetSums
