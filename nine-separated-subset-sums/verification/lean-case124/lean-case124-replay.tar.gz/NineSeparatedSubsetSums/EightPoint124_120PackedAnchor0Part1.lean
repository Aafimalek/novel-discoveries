import NineSeparatedSubsetSums.EightPoint124_120PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint124_120PackedAnchor0Part1 :
    ∀ j : Fin 118, 2213419 ≤ FourPointNumeric.octPackedCharge 124 120 20 packedOct124_120_0
      (2*((j.val : Int)+120)+0) := by decide +kernel

end NineSeparatedSubsetSums
