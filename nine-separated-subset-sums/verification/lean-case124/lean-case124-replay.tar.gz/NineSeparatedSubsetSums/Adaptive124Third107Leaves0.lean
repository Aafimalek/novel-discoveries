import NineSeparatedSubsetSums.Adaptive124Third107State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive124Third107Proof0 : runCachedNode 511 109260 Adaptive124Third107Node0 = false := by
  decide +kernel

#print axioms adaptive124Third107Proof0

end NineSeparatedSubsetSums
