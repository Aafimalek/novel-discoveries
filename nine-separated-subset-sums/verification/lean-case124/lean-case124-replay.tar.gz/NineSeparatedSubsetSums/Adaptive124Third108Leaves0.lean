import NineSeparatedSubsetSums.Adaptive124Third108State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive124Third108Proof0 : runCachedNode 511 109260 Adaptive124Third108Node0 = false := by
  decide +kernel

#print axioms adaptive124Third108Proof0

end NineSeparatedSubsetSums
