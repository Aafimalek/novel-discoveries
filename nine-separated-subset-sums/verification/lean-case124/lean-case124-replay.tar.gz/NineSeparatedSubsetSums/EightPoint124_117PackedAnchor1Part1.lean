import NineSeparatedSubsetSums.EightPoint124_117PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint124_117PackedAnchor1Part1 :
    ∀ j : Fin 116, 2178817 ≤ FourPointNumeric.octPackedCharge 124 117 20 packedOct124_117_1
      (2*((j.val : Int)+120)+0) := by decide +kernel

end NineSeparatedSubsetSums
