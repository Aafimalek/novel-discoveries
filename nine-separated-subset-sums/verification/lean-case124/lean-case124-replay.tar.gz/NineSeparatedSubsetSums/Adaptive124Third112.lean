import NineSeparatedSubsetSums.Adaptive124Third112Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint124Checked

namespace NineSeparatedSubsetSums


theorem adaptive124Third112 : NoDescendingTailAfterThird 124 112 :=
  noDescendingThirdTail_of_cached 124 112 109260 (fun t ht nd => max148_second124_fourPoint_moment_bound (112::t) (by simp [ht]) nd) adaptive124Third112Proof0

#print axioms adaptive124Third112

end NineSeparatedSubsetSums
