import NineSeparatedSubsetSums.EightPointPackedGeometry
import NineSeparatedSubsetSums.EightPoint124_118PackedBudget0
import NineSeparatedSubsetSums.EightPoint124_118PackedAnchor0Part0
import NineSeparatedSubsetSums.EightPoint124_118PackedAnchor0Part1
import NineSeparatedSubsetSums.EightPoint124_118PackedBudget1
import NineSeparatedSubsetSums.EightPoint124_118PackedAnchor1Part0
import NineSeparatedSubsetSums.EightPoint124_118PackedAnchor1Part1

namespace NineSeparatedSubsetSums

private theorem packedOct124_118Anchor0 :
  ∀ j : Fin 470, ((j.val : Int)+124+118)%2=0 →
    2171619 ≤ FourPointNumeric.octPackedCharge 124 118 20 packedOct124_118_0 (j.val : Int) := by
  intro j hj
  let k := (j.val-0)/2
  have hk : k < 235 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+0 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint124_118PackedAnchor0Part0 z
    rwa [he,hrep] at ht
  let z : Fin 115 := ⟨k-120, by omega⟩
  have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
  have ht := eightPoint124_118PackedAnchor0Part1 z
  rwa [he,hrep] at ht

private theorem packedOct124_118Anchor1 :
  ∀ j : Fin 470, ((j.val : Int)+124+118)%2=1 →
    2170469 ≤ FourPointNumeric.octPackedCharge 124 118 20 packedOct124_118_1 (j.val : Int) := by
  intro j hj
  let k := (j.val-1)/2
  have hk : k < 235 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+1 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint124_118PackedAnchor1Part0 z
    rwa [he,hrep] at ht
  let z : Fin 115 := ⟨k-120, by omega⟩
  have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
  have ht := eightPoint124_118PackedAnchor1Part1 z
  rwa [he,hrep] at ht

def packedOctCertificate124_118_0 : EightPointCertificate 124 118 0 122165 :=
  eightPointCertificateOfPacked 124 118 0 122165 2171619 20 packedOct124_118_0 401 470
    (by decide +kernel) (by decide) packedOct124_118Anchor0
    (by rw [packedOct124_118_0_budget]; decide)

def packedOctCertificate124_118_1 : EightPointCertificate 124 118 1 122165 :=
  eightPointCertificateOfPacked 124 118 1 122165 2170469 20 packedOct124_118_1 402 470
    (by decide +kernel) (by decide) packedOct124_118Anchor1
    (by rw [packedOct124_118_1_budget]; decide)

theorem max148_second124_third118_eightPoint_moment_bound (tail : List ℕ) (len : tail.length=6)
    (distinct : (natSubsetSums (148::124::118::tail)).Nodup) :
    122165 ≤ ((148::124::118::tail).map (· ^ 2)).sum := by
  apply eightPointNatMomentLower 124 118 122165 tail len distinct
  intro p hp
  by_cases h : p=0
  · subst p
    exact packedOctCertificate124_118_0
  · have he : p=1 := hp.resolve_left h
    subst p
    exact packedOctCertificate124_118_1

#print axioms max148_second124_third118_eightPoint_moment_bound

end NineSeparatedSubsetSums
