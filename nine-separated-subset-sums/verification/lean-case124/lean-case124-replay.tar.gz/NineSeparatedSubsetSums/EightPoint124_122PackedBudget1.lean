import NineSeparatedSubsetSums.EightPoint124_122PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct124_122_1_budget :
    FourPointNumeric.packedBudget 20 packedOct124_122_1 386 = 81531196 := by decide +kernel

#print axioms packedOct124_122_1_budget

end NineSeparatedSubsetSums
