import NineSeparatedSubsetSums.EightPoint124_121PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint124_121PackedAnchor0Part1 :
    ∀ j : Fin 120, 2273832 ≤ FourPointNumeric.octPackedCharge 124 121 20 packedOct124_121_0
      (2*((j.val : Int)+120)+1) := by decide +kernel

end NineSeparatedSubsetSums
