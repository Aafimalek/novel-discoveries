import NineSeparatedSubsetSums.Adaptive124Third108Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint124Checked

namespace NineSeparatedSubsetSums


theorem adaptive124Third108 : NoDescendingTailAfterThird 124 108 :=
  noDescendingThirdTail_of_cached 124 108 109260 (fun t ht nd => max148_second124_fourPoint_moment_bound (108::t) (by simp [ht]) nd) adaptive124Third108Proof0

#print axioms adaptive124Third108

end NineSeparatedSubsetSums
