import NineSeparatedSubsetSums.FourPoint124PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem fourPoint124PackedAnchor1Part0 :
    ∀ j : Fin 120, 1101508 ≤ FourPointNumeric.packedCharge 124 20 packedWeight124_1
      (2*((j.val : Int)+0)+1) := by decide +kernel

end NineSeparatedSubsetSums
