import NineSeparatedSubsetSums.EightPointPackedGeometry
import NineSeparatedSubsetSums.EightPoint124_119PackedBudget0
import NineSeparatedSubsetSums.EightPoint124_119PackedAnchor0Part0
import NineSeparatedSubsetSums.EightPoint124_119PackedAnchor0Part1
import NineSeparatedSubsetSums.EightPoint124_119PackedBudget1
import NineSeparatedSubsetSums.EightPoint124_119PackedAnchor1Part0
import NineSeparatedSubsetSums.EightPoint124_119PackedAnchor1Part1

namespace NineSeparatedSubsetSums

private theorem packedOct124_119Anchor0 :
  ∀ j : Fin 472, ((j.val : Int)+124+119)%2=0 →
    2192891 ≤ FourPointNumeric.octPackedCharge 124 119 20 packedOct124_119_0 (j.val : Int) := by
  intro j hj
  let k := (j.val-1)/2
  have hk : k < 236 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+1 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint124_119PackedAnchor0Part0 z
    rwa [he,hrep] at ht
  let z : Fin 116 := ⟨k-120, by omega⟩
  have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
  have ht := eightPoint124_119PackedAnchor0Part1 z
  rwa [he,hrep] at ht

private theorem packedOct124_119Anchor1 :
  ∀ j : Fin 472, ((j.val : Int)+124+119)%2=1 →
    2193158 ≤ FourPointNumeric.octPackedCharge 124 119 20 packedOct124_119_1 (j.val : Int) := by
  intro j hj
  let k := (j.val-0)/2
  have hk : k < 236 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+0 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint124_119PackedAnchor1Part0 z
    rwa [he,hrep] at ht
  let z : Fin 116 := ⟨k-120, by omega⟩
  have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
  have ht := eightPoint124_119PackedAnchor1Part1 z
  rwa [he,hrep] at ht

def packedOctCertificate124_119_0 : EightPointCertificate 124 119 0 122318 :=
  eightPointCertificateOfPacked 124 119 0 122318 2192891 20 packedOct124_119_0 507 472
    (by decide +kernel) (by decide) packedOct124_119Anchor0
    (by rw [packedOct124_119_0_budget]; decide)

def packedOctCertificate124_119_1 : EightPointCertificate 124 119 1 122318 :=
  eightPointCertificateOfPacked 124 119 1 122318 2193158 20 packedOct124_119_1 394 472
    (by decide +kernel) (by decide) packedOct124_119Anchor1
    (by rw [packedOct124_119_1_budget]; decide)

theorem max148_second124_third119_eightPoint_moment_bound (tail : List ℕ) (len : tail.length=6)
    (distinct : (natSubsetSums (148::124::119::tail)).Nodup) :
    122318 ≤ ((148::124::119::tail).map (· ^ 2)).sum := by
  apply eightPointNatMomentLower 124 119 122318 tail len distinct
  intro p hp
  by_cases h : p=0
  · subst p
    exact packedOctCertificate124_119_0
  · have he : p=1 := hp.resolve_left h
    subst p
    exact packedOctCertificate124_119_1

#print axioms max148_second124_third119_eightPoint_moment_bound

end NineSeparatedSubsetSums
