import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive124Third114Node0 : CachedSearchNode :=
  ⟨4, 113, computeCenteredMask [148,124,114], 386, 50276⟩

end NineSeparatedSubsetSums
