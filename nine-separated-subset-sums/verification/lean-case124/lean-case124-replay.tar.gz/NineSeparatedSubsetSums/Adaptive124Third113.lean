import NineSeparatedSubsetSums.Adaptive124Third113Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint124Checked

namespace NineSeparatedSubsetSums


theorem adaptive124Third113 : NoDescendingTailAfterThird 124 113 :=
  noDescendingThirdTail_of_cached 124 113 109260 (fun t ht nd => max148_second124_fourPoint_moment_bound (113::t) (by simp [ht]) nd) adaptive124Third113Proof0

#print axioms adaptive124Third113

end NineSeparatedSubsetSums
