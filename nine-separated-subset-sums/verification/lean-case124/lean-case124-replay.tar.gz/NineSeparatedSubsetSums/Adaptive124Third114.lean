import NineSeparatedSubsetSums.Adaptive124Third114Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint124Checked

namespace NineSeparatedSubsetSums


theorem adaptive124Third114 : NoDescendingTailAfterThird 124 114 :=
  noDescendingThirdTail_of_cached 124 114 109260 (fun t ht nd => max148_second124_fourPoint_moment_bound (114::t) (by simp [ht]) nd) adaptive124Third114Proof0

#print axioms adaptive124Third114

end NineSeparatedSubsetSums
