import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive124Third123Node0 : CachedSearchNode :=
  ⟨4, 122, computeCenteredMask [148,124,123], 395, 52409⟩

end NineSeparatedSubsetSums
