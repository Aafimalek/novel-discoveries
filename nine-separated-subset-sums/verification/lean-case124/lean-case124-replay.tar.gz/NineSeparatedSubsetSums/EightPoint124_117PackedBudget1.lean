import NineSeparatedSubsetSums.EightPoint124_117PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct124_117_1_budget :
    FourPointNumeric.packedBudget 20 packedOct124_117_1 506 = 76952254 := by decide +kernel

#print axioms packedOct124_117_1_budget

end NineSeparatedSubsetSums
