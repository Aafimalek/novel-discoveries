import NineSeparatedSubsetSums.Adaptive124Third116State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive124Third116Proof14 : runCachedNode 511 109260 Adaptive124Third116Node14 = false := by
  decide +kernel

#print axioms adaptive124Third116Proof14

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive124Third116Proof13 : runCachedNode 511 109260 Adaptive124Third116Node13 = false := by
  decide +kernel

#print axioms adaptive124Third116Proof13

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive124Third116Proof12 : runCachedNode 511 109260 Adaptive124Third116Node12 = false := by
  decide +kernel

#print axioms adaptive124Third116Proof12

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive124Third116Proof10 : runCachedNode 511 109260 Adaptive124Third116Node10 = false := by
  decide +kernel

#print axioms adaptive124Third116Proof10

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive124Third116Proof5 : runCachedNode 511 109260 Adaptive124Third116Node5 = false := by
  decide +kernel

#print axioms adaptive124Third116Proof5

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive124Third116Proof1 : runCachedNode 511 109260 Adaptive124Third116Node1 = false := by
  decide +kernel

#print axioms adaptive124Third116Proof1

end NineSeparatedSubsetSums
