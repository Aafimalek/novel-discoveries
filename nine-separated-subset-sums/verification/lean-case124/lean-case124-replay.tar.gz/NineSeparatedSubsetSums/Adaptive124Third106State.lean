import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive124Third106Node0 : CachedSearchNode :=
  ⟨4, 105, computeCenteredMask [148,124,106], 378, 48516⟩

end NineSeparatedSubsetSums
