import NineSeparatedSubsetSums.EightPoint124_123PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint124_123PackedAnchor0Part0 :
    ∀ j : Fin 120, 2296149 ≤ FourPointNumeric.octPackedCharge 124 123 20 packedOct124_123_0
      (2*((j.val : Int)+0)+1) := by decide +kernel

end NineSeparatedSubsetSums
