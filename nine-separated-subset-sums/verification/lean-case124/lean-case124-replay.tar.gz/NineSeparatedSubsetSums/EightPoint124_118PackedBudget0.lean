import NineSeparatedSubsetSums.EightPoint124_118PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct124_118_0_budget :
    FourPointNumeric.packedBudget 20 packedOct124_118_0 401 = 76435103 := by decide +kernel

#print axioms packedOct124_118_0_budget

end NineSeparatedSubsetSums
