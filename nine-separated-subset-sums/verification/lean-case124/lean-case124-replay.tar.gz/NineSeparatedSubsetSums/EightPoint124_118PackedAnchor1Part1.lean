import NineSeparatedSubsetSums.EightPoint124_118PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint124_118PackedAnchor1Part1 :
    ∀ j : Fin 115, 2170469 ≤ FourPointNumeric.octPackedCharge 124 118 20 packedOct124_118_1
      (2*((j.val : Int)+120)+1) := by decide +kernel

end NineSeparatedSubsetSums
