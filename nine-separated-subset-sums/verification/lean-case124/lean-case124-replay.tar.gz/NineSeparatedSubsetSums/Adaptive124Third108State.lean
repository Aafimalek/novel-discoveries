import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive124Third108Node0 : CachedSearchNode :=
  ⟨4, 107, computeCenteredMask [148,124,108], 380, 48944⟩

end NineSeparatedSubsetSums
