import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive124Third120Node0 : CachedSearchNode :=
  ⟨4, 119, computeCenteredMask [148,124,120], 392, 51680⟩

end NineSeparatedSubsetSums
