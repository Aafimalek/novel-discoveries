import NineSeparatedSubsetSums.Adaptive124Third115State
import NineSeparatedSubsetSums.Adaptive124Third115Leaves0
import NineSeparatedSubsetSums.Adaptive124Third115Leaves1

namespace NineSeparatedSubsetSums

theorem adaptive124Third115Proof0 : runCachedNode 511 109260 Adaptive124Third115Node0 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 109260 Adaptive124Third115Node0 = [102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive124Third115Proof1
  · exact adaptive124Third115Proof2
  · exact adaptive124Third115Proof3
  · exact adaptive124Third115Proof4
  · exact adaptive124Third115Proof5
  · exact adaptive124Third115Proof6
  · exact adaptive124Third115Proof7
  · exact adaptive124Third115Proof8
  · exact adaptive124Third115Proof9
  · exact adaptive124Third115Proof10
  · exact adaptive124Third115Proof11
  · exact adaptive124Third115Proof12
  · exact adaptive124Third115Proof13

#print axioms adaptive124Third115Proof0

end NineSeparatedSubsetSums
