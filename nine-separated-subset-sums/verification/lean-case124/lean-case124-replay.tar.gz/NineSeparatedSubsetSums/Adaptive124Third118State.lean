import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive124Third118Node0 : CachedSearchNode :=
  ⟨4, 117, computeCenteredMask [148,124,118], 390, 51204⟩

end NineSeparatedSubsetSums
