import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive124Third105Node0 : CachedSearchNode :=
  ⟨4, 104, computeCenteredMask [148,124,105], 377, 48305⟩

end NineSeparatedSubsetSums
