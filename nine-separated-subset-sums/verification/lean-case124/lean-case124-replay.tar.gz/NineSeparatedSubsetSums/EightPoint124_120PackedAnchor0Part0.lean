import NineSeparatedSubsetSums.EightPoint124_120PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint124_120PackedAnchor0Part0 :
    ∀ j : Fin 120, 2213419 ≤ FourPointNumeric.octPackedCharge 124 120 20 packedOct124_120_0
      (2*((j.val : Int)+0)+0) := by decide +kernel

end NineSeparatedSubsetSums
