import NineSeparatedSubsetSums.Adaptive124Third110State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive124Third110Proof0 : runCachedNode 511 109260 Adaptive124Third110Node0 = false := by
  decide +kernel

#print axioms adaptive124Third110Proof0

end NineSeparatedSubsetSums
