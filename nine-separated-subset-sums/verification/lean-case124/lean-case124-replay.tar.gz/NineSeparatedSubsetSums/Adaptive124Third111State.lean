import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive124Third111Node0 : CachedSearchNode :=
  ⟨4, 110, computeCenteredMask [148,124,111], 383, 49601⟩

end NineSeparatedSubsetSums
