import NineSeparatedSubsetSums.EightPoint124_119PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint124_119PackedAnchor0Part0 :
    ∀ j : Fin 120, 2192891 ≤ FourPointNumeric.octPackedCharge 124 119 20 packedOct124_119_0
      (2*((j.val : Int)+0)+1) := by decide +kernel

end NineSeparatedSubsetSums
