import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive124Third112Node0 : CachedSearchNode :=
  ⟨4, 111, computeCenteredMask [148,124,112], 384, 49824⟩

end NineSeparatedSubsetSums
