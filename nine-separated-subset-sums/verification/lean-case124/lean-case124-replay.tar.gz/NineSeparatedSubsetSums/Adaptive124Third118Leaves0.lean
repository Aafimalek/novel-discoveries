import NineSeparatedSubsetSums.Adaptive124Third118State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive124Third118Proof0 : runCachedNode 511 122165 Adaptive124Third118Node0 = false := by
  decide +kernel

#print axioms adaptive124Third118Proof0

end NineSeparatedSubsetSums
