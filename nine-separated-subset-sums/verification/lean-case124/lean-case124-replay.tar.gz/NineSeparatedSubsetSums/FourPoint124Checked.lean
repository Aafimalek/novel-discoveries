import NineSeparatedSubsetSums.FourPointPackedGeometry
import NineSeparatedSubsetSums.FourPoint124PackedBudget0
import NineSeparatedSubsetSums.FourPoint124PackedAnchor0Part0
import NineSeparatedSubsetSums.FourPoint124PackedAnchor0Part1
import NineSeparatedSubsetSums.FourPoint124PackedAnchor0Part2
import NineSeparatedSubsetSums.FourPoint124PackedBudget1
import NineSeparatedSubsetSums.FourPoint124PackedAnchor1Part0
import NineSeparatedSubsetSums.FourPoint124PackedAnchor1Part1
import NineSeparatedSubsetSums.FourPoint124PackedAnchor1Part2

namespace NineSeparatedSubsetSums

private theorem packed124Anchor0 :
  ∀ j : Fin 489, ((j.val : Int)+124)%2=0 →
    1102464 ≤ FourPointNumeric.packedCharge 124 20 packedWeight124_0 (j.val : Int) := by
  intro j hj
  let k := (j.val-0)/2
  have hk : k < 245 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+0 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := fourPoint124PackedAnchor0Part0 z
    rwa [he,hrep] at ht
  by_cases h1 : k < 240
  · let z : Fin 120 := ⟨k-120, by omega⟩
    have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
    have ht := fourPoint124PackedAnchor0Part1 z
    rwa [he,hrep] at ht
  let z : Fin 5 := ⟨k-240, by omega⟩
  have he : (z.val : Int)+240 = k := by dsimp [z] <;> omega
  have ht := fourPoint124PackedAnchor0Part2 z
  rwa [he,hrep] at ht

private theorem packed124Anchor1 :
  ∀ j : Fin 489, ((j.val : Int)+124)%2=1 →
    1101508 ≤ FourPointNumeric.packedCharge 124 20 packedWeight124_1 (j.val : Int) := by
  intro j hj
  let k := (j.val-1)/2
  have hk : k < 244 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+1 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := fourPoint124PackedAnchor1Part0 z
    rwa [he,hrep] at ht
  by_cases h1 : k < 240
  · let z : Fin 120 := ⟨k-120, by omega⟩
    have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
    have ht := fourPoint124PackedAnchor1Part1 z
    rwa [he,hrep] at ht
  let z : Fin 4 := ⟨k-240, by omega⟩
  have he : (z.val : Int)+240 = k := by dsimp [z] <;> omega
  have ht := fourPoint124PackedAnchor1Part2 z
  rwa [he,hrep] at ht

def packedCertificate124_0 : FourPointCertificate 124 0 109260 :=
  fourPointCertificateOfPacked 124 0 109260 1102464 20 packedWeight124_0 445 489
    (by decide +kernel) (by decide) (by decide) packed124Anchor0
    (by rw [packedWeight124_0_budget]; decide)

def packedCertificate124_1 : FourPointCertificate 124 1 109260 :=
  fourPointCertificateOfPacked 124 1 109260 1101508 20 packedWeight124_1 556 489
    (by decide +kernel) (by decide) (by decide) packed124Anchor1
    (by rw [packedWeight124_1_budget]; decide)

theorem max148_second124_fourPoint_moment_bound (tail : List ℕ) (len : tail.length=7)
    (distinct : (natSubsetSums (148::124::tail)).Nodup) :
    109260 ≤ ((148::124::tail).map (· ^ 2)).sum := by
  apply fourPointNatMomentLower 124 109260 tail len distinct
  intro p hp
  by_cases h : p=0
  · subst p
    exact packedCertificate124_0
  · have he : p=1 := hp.resolve_left h
    subst p
    exact packedCertificate124_1

#print axioms max148_second124_fourPoint_moment_bound

end NineSeparatedSubsetSums
