import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive124Third117Node0 : CachedSearchNode :=
  ⟨4, 116, computeCenteredMask [148,124,117], 389, 50969⟩

end NineSeparatedSubsetSums
