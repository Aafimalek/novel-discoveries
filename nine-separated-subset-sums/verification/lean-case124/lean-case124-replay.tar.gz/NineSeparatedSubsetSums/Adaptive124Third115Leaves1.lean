import NineSeparatedSubsetSums.Adaptive124Third115State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive124Third115Proof7 : runCachedNode 511 109260 Adaptive124Third115Node7 = false := by
  decide +kernel

#print axioms adaptive124Third115Proof7

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive124Third115Proof6 : runCachedNode 511 109260 Adaptive124Third115Node6 = false := by
  decide +kernel

#print axioms adaptive124Third115Proof6

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive124Third115Proof5 : runCachedNode 511 109260 Adaptive124Third115Node5 = false := by
  decide +kernel

#print axioms adaptive124Third115Proof5

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive124Third115Proof3 : runCachedNode 511 109260 Adaptive124Third115Node3 = false := by
  decide +kernel

#print axioms adaptive124Third115Proof3

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive124Third115Proof2 : runCachedNode 511 109260 Adaptive124Third115Node2 = false := by
  decide +kernel

#print axioms adaptive124Third115Proof2

end NineSeparatedSubsetSums
