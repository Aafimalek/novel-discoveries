import NineSeparatedSubsetSums.FourPoint124PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedWeight124_0_budget :
    FourPointNumeric.packedBudget 20 packedWeight124_0 445 = 85173760 := by decide +kernel

#print axioms packedWeight124_0_budget

end NineSeparatedSubsetSums
