import NineSeparatedSubsetSums.Adaptive124Third119State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive124Third119Proof0 : runCachedNode 511 122318 Adaptive124Third119Node0 = false := by
  decide +kernel

#print axioms adaptive124Third119Proof0

end NineSeparatedSubsetSums
