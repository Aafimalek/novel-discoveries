import NineSeparatedSubsetSums.EightPoint124_118PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct124_118_1_budget :
    FourPointNumeric.packedBudget 20 packedOct124_118_1 402 = 76361780 := by decide +kernel

#print axioms packedOct124_118_1_budget

end NineSeparatedSubsetSums
