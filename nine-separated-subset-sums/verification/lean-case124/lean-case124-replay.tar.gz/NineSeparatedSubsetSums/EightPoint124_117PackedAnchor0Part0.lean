import NineSeparatedSubsetSums.EightPoint124_117PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint124_117PackedAnchor0Part0 :
    ∀ j : Fin 120, 2177740 ≤ FourPointNumeric.octPackedCharge 124 117 20 packedOct124_117_0
      (2*((j.val : Int)+0)+1) := by decide +kernel

end NineSeparatedSubsetSums
