import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive124Third109Node0 : CachedSearchNode :=
  ⟨4, 108, computeCenteredMask [148,124,109], 381, 49161⟩

end NineSeparatedSubsetSums
