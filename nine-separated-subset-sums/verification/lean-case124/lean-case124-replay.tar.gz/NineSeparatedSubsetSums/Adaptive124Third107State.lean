import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive124Third107Node0 : CachedSearchNode :=
  ⟨4, 106, computeCenteredMask [148,124,107], 379, 48729⟩

end NineSeparatedSubsetSums
