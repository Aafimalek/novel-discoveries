import NineSeparatedSubsetSums.EightPointPackedGeometry
import NineSeparatedSubsetSums.EightPoint124_122PackedBudget0
import NineSeparatedSubsetSums.EightPoint124_122PackedAnchor0Part0
import NineSeparatedSubsetSums.EightPoint124_122PackedAnchor0Part1
import NineSeparatedSubsetSums.EightPoint124_122PackedBudget1
import NineSeparatedSubsetSums.EightPoint124_122PackedAnchor1Part0
import NineSeparatedSubsetSums.EightPoint124_122PackedAnchor1Part1

namespace NineSeparatedSubsetSums

private theorem packedOct124_122Anchor0 :
  ∀ j : Fin 480, ((j.val : Int)+124+122)%2=0 →
    2258539 ≤ FourPointNumeric.octPackedCharge 124 122 20 packedOct124_122_0 (j.val : Int) := by
  intro j hj
  let k := (j.val-0)/2
  have hk : k < 240 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+0 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint124_122PackedAnchor0Part0 z
    rwa [he,hrep] at ht
  let z : Fin 120 := ⟨k-120, by omega⟩
  have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
  have ht := eightPoint124_122PackedAnchor0Part1 z
  rwa [he,hrep] at ht

private theorem packedOct124_122Anchor1 :
  ∀ j : Fin 480, ((j.val : Int)+124+122)%2=1 →
    2257683 ≤ FourPointNumeric.octPackedCharge 124 122 20 packedOct124_122_1 (j.val : Int) := by
  intro j hj
  let k := (j.val-1)/2
  have hk : k < 240 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+1 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint124_122PackedAnchor1Part0 z
    rwa [he,hrep] at ht
  let z : Fin 120 := ⟨k-120, by omega⟩
  have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
  have ht := eightPoint124_122PackedAnchor1Part1 z
  rwa [he,hrep] at ht

def packedOctCertificate124_122_0 : EightPointCertificate 124 122 0 122970 :=
  eightPointCertificateOfPacked 124 122 0 122970 2258539 20 packedOct124_122_0 387 480
    (by decide +kernel) (by decide) packedOct124_122Anchor0
    (by rw [packedOct124_122_0_budget]; decide)

def packedOctCertificate124_122_1 : EightPointCertificate 124 122 1 122970 :=
  eightPointCertificateOfPacked 124 122 1 122970 2257683 20 packedOct124_122_1 386 480
    (by decide +kernel) (by decide) packedOct124_122Anchor1
    (by rw [packedOct124_122_1_budget]; decide)

theorem max148_second124_third122_eightPoint_moment_bound (tail : List ℕ) (len : tail.length=6)
    (distinct : (natSubsetSums (148::124::122::tail)).Nodup) :
    122970 ≤ ((148::124::122::tail).map (· ^ 2)).sum := by
  apply eightPointNatMomentLower 124 122 122970 tail len distinct
  intro p hp
  by_cases h : p=0
  · subst p
    exact packedOctCertificate124_122_0
  · have he : p=1 := hp.resolve_left h
    subst p
    exact packedOctCertificate124_122_1

#print axioms max148_second124_third122_eightPoint_moment_bound

end NineSeparatedSubsetSums
