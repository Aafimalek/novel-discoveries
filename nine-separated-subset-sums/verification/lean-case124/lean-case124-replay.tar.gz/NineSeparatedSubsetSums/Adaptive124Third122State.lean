import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive124Third122Node0 : CachedSearchNode :=
  ⟨4, 121, computeCenteredMask [148,124,122], 394, 52164⟩

end NineSeparatedSubsetSums
