import NineSeparatedSubsetSums.EightPoint124_120PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint124_120PackedAnchor1Part1 :
    ∀ j : Fin 117, 2207475 ≤ FourPointNumeric.octPackedCharge 124 120 20 packedOct124_120_1
      (2*((j.val : Int)+120)+1) := by decide +kernel

end NineSeparatedSubsetSums
