import NineSeparatedSubsetSums.Adaptive124Third116State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive124Third116Proof11 : runCachedNode 511 109260 Adaptive124Third116Node11 = false := by
  decide +kernel

#print axioms adaptive124Third116Proof11

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive124Third116Proof9 : runCachedNode 511 109260 Adaptive124Third116Node9 = false := by
  decide +kernel

#print axioms adaptive124Third116Proof9

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive124Third116Proof8 : runCachedNode 511 109260 Adaptive124Third116Node8 = false := by
  decide +kernel

#print axioms adaptive124Third116Proof8

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive124Third116Proof7 : runCachedNode 511 109260 Adaptive124Third116Node7 = false := by
  decide +kernel

#print axioms adaptive124Third116Proof7

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive124Third116Proof6 : runCachedNode 511 109260 Adaptive124Third116Node6 = false := by
  decide +kernel

#print axioms adaptive124Third116Proof6

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive124Third116Proof4 : runCachedNode 511 109260 Adaptive124Third116Node4 = false := by
  decide +kernel

#print axioms adaptive124Third116Proof4

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive124Third116Proof3 : runCachedNode 511 109260 Adaptive124Third116Node3 = false := by
  decide +kernel

#print axioms adaptive124Third116Proof3

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive124Third116Proof2 : runCachedNode 511 109260 Adaptive124Third116Node2 = false := by
  decide +kernel

#print axioms adaptive124Third116Proof2

end NineSeparatedSubsetSums
