import NineSeparatedSubsetSums.EightPoint124_122PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct124_122_0_budget :
    FourPointNumeric.packedBudget 20 packedOct124_122_0 387 = 81585456 := by decide +kernel

#print axioms packedOct124_122_0_budget

end NineSeparatedSubsetSums
