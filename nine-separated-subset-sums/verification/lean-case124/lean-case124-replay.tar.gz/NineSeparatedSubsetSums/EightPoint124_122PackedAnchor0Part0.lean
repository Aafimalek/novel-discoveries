import NineSeparatedSubsetSums.EightPoint124_122PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint124_122PackedAnchor0Part0 :
    ∀ j : Fin 120, 2258539 ≤ FourPointNumeric.octPackedCharge 124 122 20 packedOct124_122_0
      (2*((j.val : Int)+0)+0) := by decide +kernel

end NineSeparatedSubsetSums
