import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive124Third121Node0 : CachedSearchNode :=
  ⟨4, 120, computeCenteredMask [148,124,121], 393, 51921⟩

end NineSeparatedSubsetSums
