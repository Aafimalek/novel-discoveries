import NineSeparatedSubsetSums.Adaptive124Third120State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive124Third120Proof0 : runCachedNode 511 122523 Adaptive124Third120Node0 = false := by
  decide +kernel

#print axioms adaptive124Third120Proof0

end NineSeparatedSubsetSums
