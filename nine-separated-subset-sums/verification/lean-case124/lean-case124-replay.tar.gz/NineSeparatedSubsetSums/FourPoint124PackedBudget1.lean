import NineSeparatedSubsetSums.FourPoint124PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedWeight124_1_budget :
    FourPointNumeric.packedBudget 20 packedWeight124_1 556 = 85051904 := by decide +kernel

#print axioms packedWeight124_1_budget

end NineSeparatedSubsetSums
