import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive124Third113Node0 : CachedSearchNode :=
  ⟨4, 112, computeCenteredMask [148,124,113], 385, 50049⟩

end NineSeparatedSubsetSums
