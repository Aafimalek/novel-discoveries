import NineSeparatedSubsetSums.EightPointPackedGeometry
import NineSeparatedSubsetSums.EightPoint124_121PackedBudget0
import NineSeparatedSubsetSums.EightPoint124_121PackedAnchor0Part0
import NineSeparatedSubsetSums.EightPoint124_121PackedAnchor0Part1
import NineSeparatedSubsetSums.EightPoint124_121PackedAnchor0Part2
import NineSeparatedSubsetSums.EightPoint124_121PackedBudget1
import NineSeparatedSubsetSums.EightPoint124_121PackedAnchor1Part0
import NineSeparatedSubsetSums.EightPoint124_121PackedAnchor1Part1
import NineSeparatedSubsetSums.EightPoint124_121PackedAnchor1Part2

namespace NineSeparatedSubsetSums

private theorem packedOct124_121Anchor0 :
  ∀ j : Fin 482, ((j.val : Int)+124+121)%2=0 →
    2273832 ≤ FourPointNumeric.octPackedCharge 124 121 20 packedOct124_121_0 (j.val : Int) := by
  intro j hj
  let k := (j.val-1)/2
  have hk : k < 241 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+1 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint124_121PackedAnchor0Part0 z
    rwa [he,hrep] at ht
  by_cases h1 : k < 240
  · let z : Fin 120 := ⟨k-120, by omega⟩
    have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
    have ht := eightPoint124_121PackedAnchor0Part1 z
    rwa [he,hrep] at ht
  let z : Fin 1 := ⟨k-240, by omega⟩
  have he : (z.val : Int)+240 = k := by dsimp [z] <;> omega
  have ht := eightPoint124_121PackedAnchor0Part2 z
  rwa [he,hrep] at ht

private theorem packedOct124_121Anchor1 :
  ∀ j : Fin 482, ((j.val : Int)+124+121)%2=1 →
    2273800 ≤ FourPointNumeric.octPackedCharge 124 121 20 packedOct124_121_1 (j.val : Int) := by
  intro j hj
  let k := (j.val-0)/2
  have hk : k < 241 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+0 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint124_121PackedAnchor1Part0 z
    rwa [he,hrep] at ht
  by_cases h1 : k < 240
  · let z : Fin 120 := ⟨k-120, by omega⟩
    have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
    have ht := eightPoint124_121PackedAnchor1Part1 z
    rwa [he,hrep] at ht
  let z : Fin 1 := ⟨k-240, by omega⟩
  have he : (z.val : Int)+240 = k := by dsimp [z] <;> omega
  have ht := eightPoint124_121PackedAnchor1Part2 z
  rwa [he,hrep] at ht

def packedOctCertificate124_121_0 : EightPointCertificate 124 121 0 122766 :=
  eightPointCertificateOfPacked 124 121 0 122766 2273832 20 packedOct124_121_0 497 482
    (by decide +kernel) (by decide) packedOct124_121Anchor0
    (by rw [packedOct124_121_0_budget]; decide)

def packedOctCertificate124_121_1 : EightPointCertificate 124 121 1 122766 :=
  eightPointCertificateOfPacked 124 121 1 122766 2273800 20 packedOct124_121_1 392 482
    (by decide +kernel) (by decide) packedOct124_121Anchor1
    (by rw [packedOct124_121_1_budget]; decide)

theorem max148_second124_third121_eightPoint_moment_bound (tail : List ℕ) (len : tail.length=6)
    (distinct : (natSubsetSums (148::124::121::tail)).Nodup) :
    122766 ≤ ((148::124::121::tail).map (· ^ 2)).sum := by
  apply eightPointNatMomentLower 124 121 122766 tail len distinct
  intro p hp
  by_cases h : p=0
  · subst p
    exact packedOctCertificate124_121_0
  · have he : p=1 := hp.resolve_left h
    subst p
    exact packedOctCertificate124_121_1

#print axioms max148_second124_third121_eightPoint_moment_bound

end NineSeparatedSubsetSums
