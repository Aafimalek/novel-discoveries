import NineSeparatedSubsetSums.EightPointPackedGeometry
import NineSeparatedSubsetSums.EightPoint124_117PackedBudget0
import NineSeparatedSubsetSums.EightPoint124_117PackedAnchor0Part0
import NineSeparatedSubsetSums.EightPoint124_117PackedAnchor0Part1
import NineSeparatedSubsetSums.EightPoint124_117PackedBudget1
import NineSeparatedSubsetSums.EightPoint124_117PackedAnchor1Part0
import NineSeparatedSubsetSums.EightPoint124_117PackedAnchor1Part1

namespace NineSeparatedSubsetSums

private theorem packedOct124_117Anchor0 :
  ∀ j : Fin 471, ((j.val : Int)+124+117)%2=0 →
    2177740 ≤ FourPointNumeric.octPackedCharge 124 117 20 packedOct124_117_0 (j.val : Int) := by
  intro j hj
  let k := (j.val-1)/2
  have hk : k < 235 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+1 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint124_117PackedAnchor0Part0 z
    rwa [he,hrep] at ht
  let z : Fin 115 := ⟨k-120, by omega⟩
  have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
  have ht := eightPoint124_117PackedAnchor0Part1 z
  rwa [he,hrep] at ht

private theorem packedOct124_117Anchor1 :
  ∀ j : Fin 471, ((j.val : Int)+124+117)%2=1 →
    2178817 ≤ FourPointNumeric.octPackedCharge 124 117 20 packedOct124_117_1 (j.val : Int) := by
  intro j hj
  let k := (j.val-0)/2
  have hk : k < 236 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+0 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint124_117PackedAnchor1Part0 z
    rwa [he,hrep] at ht
  let z : Fin 116 := ⟨k-120, by omega⟩
  have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
  have ht := eightPoint124_117PackedAnchor1Part1 z
  rwa [he,hrep] at ht

def packedOctCertificate124_117_0 : EightPointCertificate 124 117 0 122055 :=
  eightPointCertificateOfPacked 124 117 0 122055 2177740 20 packedOct124_117_0 507 471
    (by decide +kernel) (by decide) packedOct124_117Anchor0
    (by rw [packedOct124_117_0_budget]; decide)

def packedOctCertificate124_117_1 : EightPointCertificate 124 117 1 122055 :=
  eightPointCertificateOfPacked 124 117 1 122055 2178817 20 packedOct124_117_1 506 471
    (by decide +kernel) (by decide) packedOct124_117Anchor1
    (by rw [packedOct124_117_1_budget]; decide)

theorem max148_second124_third117_eightPoint_moment_bound (tail : List ℕ) (len : tail.length=6)
    (distinct : (natSubsetSums (148::124::117::tail)).Nodup) :
    122055 ≤ ((148::124::117::tail).map (· ^ 2)).sum := by
  apply eightPointNatMomentLower 124 117 122055 tail len distinct
  intro p hp
  by_cases h : p=0
  · subst p
    exact packedOctCertificate124_117_0
  · have he : p=1 := hp.resolve_left h
    subst p
    exact packedOctCertificate124_117_1

#print axioms max148_second124_third117_eightPoint_moment_bound

end NineSeparatedSubsetSums
