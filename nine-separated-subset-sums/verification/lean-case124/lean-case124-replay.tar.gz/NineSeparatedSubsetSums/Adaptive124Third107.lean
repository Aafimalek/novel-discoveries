import NineSeparatedSubsetSums.Adaptive124Third107Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint124Checked

namespace NineSeparatedSubsetSums


theorem adaptive124Third107 : NoDescendingTailAfterThird 124 107 :=
  noDescendingThirdTail_of_cached 124 107 109260 (fun t ht nd => max148_second124_fourPoint_moment_bound (107::t) (by simp [ht]) nd) adaptive124Third107Proof0

#print axioms adaptive124Third107

end NineSeparatedSubsetSums
