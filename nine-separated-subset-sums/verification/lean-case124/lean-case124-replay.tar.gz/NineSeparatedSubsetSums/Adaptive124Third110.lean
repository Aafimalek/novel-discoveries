import NineSeparatedSubsetSums.Adaptive124Third110Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint124Checked

namespace NineSeparatedSubsetSums


theorem adaptive124Third110 : NoDescendingTailAfterThird 124 110 :=
  noDescendingThirdTail_of_cached 124 110 109260 (fun t ht nd => max148_second124_fourPoint_moment_bound (110::t) (by simp [ht]) nd) adaptive124Third110Proof0

#print axioms adaptive124Third110

end NineSeparatedSubsetSums
