import NineSeparatedSubsetSums.Adaptive124Third121State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive124Third121Proof0 : runCachedNode 511 122766 Adaptive124Third121Node0 = false := by
  decide +kernel

#print axioms adaptive124Third121Proof0

end NineSeparatedSubsetSums
