import NineSeparatedSubsetSums.EightPoint124_121PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint124_121PackedAnchor1Part2 :
    ∀ j : Fin 1, 2273800 ≤ FourPointNumeric.octPackedCharge 124 121 20 packedOct124_121_1
      (2*((j.val : Int)+240)+0) := by decide +kernel

end NineSeparatedSubsetSums
