import NineSeparatedSubsetSums.Adaptive121Third115Joins0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint121Checked

namespace NineSeparatedSubsetSums


theorem adaptive121Third115 : NoDescendingTailAfterThird 121 115 :=
  noDescendingThirdTail_of_cached 121 115 108868 (fun t ht nd => max148_second121_fourPoint_moment_bound (115::t) (by simp [ht]) nd) adaptive121Third115Proof0

#print axioms adaptive121Third115

end NineSeparatedSubsetSums
