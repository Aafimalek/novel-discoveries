import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive121Third113Node0 : CachedSearchNode :=
  ⟨4, 112, computeCenteredMask [148,121,113], 382, 49314⟩

end NineSeparatedSubsetSums
