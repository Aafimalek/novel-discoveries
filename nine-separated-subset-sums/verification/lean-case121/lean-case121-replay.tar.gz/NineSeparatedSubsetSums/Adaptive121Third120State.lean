import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive121Third120Node0 : CachedSearchNode :=
  ⟨4, 119, computeCenteredMask [148,121,120], 389, 50945⟩

end NineSeparatedSubsetSums
