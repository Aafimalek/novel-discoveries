import NineSeparatedSubsetSums.Adaptive121Third105Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint121Checked

namespace NineSeparatedSubsetSums


theorem adaptive121Third105 : NoDescendingTailAfterThird 121 105 :=
  noDescendingThirdTail_of_cached 121 105 108868 (fun t ht nd => max148_second121_fourPoint_moment_bound (105::t) (by simp [ht]) nd) adaptive121Third105Proof0

#print axioms adaptive121Third105

end NineSeparatedSubsetSums
