import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive121Third107Node0 : CachedSearchNode :=
  ⟨4, 106, computeCenteredMask [148,121,107], 376, 47994⟩

end NineSeparatedSubsetSums
