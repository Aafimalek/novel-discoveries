import NineSeparatedSubsetSums.EightPoint121_120PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct121_120_1_budget :
    FourPointNumeric.packedBudget 20 packedOct121_120_1 512 = 78171460 := by decide +kernel

#print axioms packedOct121_120_1_budget

end NineSeparatedSubsetSums
