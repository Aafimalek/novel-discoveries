import NineSeparatedSubsetSums.Adaptive121Third116State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive121Third116Proof11 : runCachedNode 511 108868 Adaptive121Third116Node11 = false := by
  decide +kernel

#print axioms adaptive121Third116Proof11

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive121Third116Proof8 : runCachedNode 511 108868 Adaptive121Third116Node8 = false := by
  decide +kernel

#print axioms adaptive121Third116Proof8

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive121Third116Proof7 : runCachedNode 511 108868 Adaptive121Third116Node7 = false := by
  decide +kernel

#print axioms adaptive121Third116Proof7

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive121Third116Proof6 : runCachedNode 511 108868 Adaptive121Third116Node6 = false := by
  decide +kernel

#print axioms adaptive121Third116Proof6

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive121Third116Proof5 : runCachedNode 511 108868 Adaptive121Third116Node5 = false := by
  decide +kernel

#print axioms adaptive121Third116Proof5

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive121Third116Proof4 : runCachedNode 511 108868 Adaptive121Third116Node4 = false := by
  decide +kernel

#print axioms adaptive121Third116Proof4

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive121Third116Proof3 : runCachedNode 511 108868 Adaptive121Third116Node3 = false := by
  decide +kernel

#print axioms adaptive121Third116Proof3

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive121Third116Proof1 : runCachedNode 511 108868 Adaptive121Third116Node1 = false := by
  decide +kernel

#print axioms adaptive121Third116Proof1

end NineSeparatedSubsetSums
