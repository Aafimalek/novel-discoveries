import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive121Third105Node0 : CachedSearchNode :=
  ⟨4, 104, computeCenteredMask [148,121,105], 374, 47570⟩

end NineSeparatedSubsetSums
