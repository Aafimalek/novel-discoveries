import NineSeparatedSubsetSums.Adaptive121Third106Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint121Checked

namespace NineSeparatedSubsetSums


theorem adaptive121Third106 : NoDescendingTailAfterThird 121 106 :=
  noDescendingThirdTail_of_cached 121 106 108868 (fun t ht nd => max148_second121_fourPoint_moment_bound (106::t) (by simp [ht]) nd) adaptive121Third106Proof0

#print axioms adaptive121Third106

end NineSeparatedSubsetSums
