import NineSeparatedSubsetSums.EightPoint121_119PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint121_119PackedAnchor0Part0 :
    ∀ j : Fin 120, 2178934 ≤ FourPointNumeric.octPackedCharge 121 119 20 packedOct121_119_0
      (2*((j.val : Int)+0)+0) := by decide +kernel

end NineSeparatedSubsetSums
