import NineSeparatedSubsetSums.EightPoint121_119PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct121_119_1_budget :
    FourPointNumeric.packedBudget 20 packedOct121_119_1 400 = 76933830 := by decide +kernel

#print axioms packedOct121_119_1_budget

end NineSeparatedSubsetSums
