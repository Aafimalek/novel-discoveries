import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive121Third109Node0 : CachedSearchNode :=
  ⟨4, 108, computeCenteredMask [148,121,109], 378, 48426⟩

end NineSeparatedSubsetSums
