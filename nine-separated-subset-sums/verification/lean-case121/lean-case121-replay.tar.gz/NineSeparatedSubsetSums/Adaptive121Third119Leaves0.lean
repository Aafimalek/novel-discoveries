import NineSeparatedSubsetSums.Adaptive121Third119State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive121Third119Proof0 : runCachedNode 511 121921 Adaptive121Third119Node0 = false := by
  decide +kernel

#print axioms adaptive121Third119Proof0

end NineSeparatedSubsetSums
