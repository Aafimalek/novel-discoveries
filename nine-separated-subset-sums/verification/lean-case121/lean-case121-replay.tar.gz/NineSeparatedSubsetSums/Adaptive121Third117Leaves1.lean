import NineSeparatedSubsetSums.Adaptive121Third117State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive121Third117Proof13 : runCachedNode 511 108868 Adaptive121Third117Node13 = false := by
  decide +kernel

#print axioms adaptive121Third117Proof13

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive121Third117Proof11 : runCachedNode 511 108868 Adaptive121Third117Node11 = false := by
  decide +kernel

#print axioms adaptive121Third117Proof11

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive121Third117Proof10 : runCachedNode 511 108868 Adaptive121Third117Node10 = false := by
  decide +kernel

#print axioms adaptive121Third117Proof10

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive121Third117Proof8 : runCachedNode 511 108868 Adaptive121Third117Node8 = false := by
  decide +kernel

#print axioms adaptive121Third117Proof8

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive121Third117Proof7 : runCachedNode 511 108868 Adaptive121Third117Node7 = false := by
  decide +kernel

#print axioms adaptive121Third117Proof7

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive121Third117Proof6 : runCachedNode 511 108868 Adaptive121Third117Node6 = false := by
  decide +kernel

#print axioms adaptive121Third117Proof6

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive121Third117Proof5 : runCachedNode 511 108868 Adaptive121Third117Node5 = false := by
  decide +kernel

#print axioms adaptive121Third117Proof5

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive121Third117Proof4 : runCachedNode 511 108868 Adaptive121Third117Node4 = false := by
  decide +kernel

#print axioms adaptive121Third117Proof4

end NineSeparatedSubsetSums
