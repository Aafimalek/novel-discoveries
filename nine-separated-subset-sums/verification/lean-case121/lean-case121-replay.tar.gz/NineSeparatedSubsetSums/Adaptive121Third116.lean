import NineSeparatedSubsetSums.Adaptive121Third116Joins0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint121Checked

namespace NineSeparatedSubsetSums


theorem adaptive121Third116 : NoDescendingTailAfterThird 121 116 :=
  noDescendingThirdTail_of_cached 121 116 108868 (fun t ht nd => max148_second121_fourPoint_moment_bound (116::t) (by simp [ht]) nd) adaptive121Third116Proof0

#print axioms adaptive121Third116

end NineSeparatedSubsetSums
