import NineSeparatedSubsetSums.EightPoint121_120PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct121_120_0_budget :
    FourPointNumeric.packedBudget 20 packedOct121_120_0 387 = 78037606 := by decide +kernel

#print axioms packedOct121_120_0_budget

end NineSeparatedSubsetSums
