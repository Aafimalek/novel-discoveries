import NineSeparatedSubsetSums.Adaptive121Third117State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive121Third117Proof15 : runCachedNode 511 108868 Adaptive121Third117Node15 = false := by
  decide +kernel

#print axioms adaptive121Third117Proof15

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive121Third117Proof14 : runCachedNode 511 108868 Adaptive121Third117Node14 = false := by
  decide +kernel

#print axioms adaptive121Third117Proof14

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive121Third117Proof12 : runCachedNode 511 108868 Adaptive121Third117Node12 = false := by
  decide +kernel

#print axioms adaptive121Third117Proof12

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive121Third117Proof9 : runCachedNode 511 108868 Adaptive121Third117Node9 = false := by
  decide +kernel

#print axioms adaptive121Third117Proof9

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive121Third117Proof3 : runCachedNode 511 108868 Adaptive121Third117Node3 = false := by
  decide +kernel

#print axioms adaptive121Third117Proof3

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive121Third117Proof2 : runCachedNode 511 108868 Adaptive121Third117Node2 = false := by
  decide +kernel

#print axioms adaptive121Third117Proof2

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive121Third117Proof1 : runCachedNode 511 108868 Adaptive121Third117Node1 = false := by
  decide +kernel

#print axioms adaptive121Third117Proof1

end NineSeparatedSubsetSums
