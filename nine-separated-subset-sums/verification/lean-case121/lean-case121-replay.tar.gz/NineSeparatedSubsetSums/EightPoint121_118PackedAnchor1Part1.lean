import NineSeparatedSubsetSums.EightPoint121_118PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint121_118PackedAnchor1Part1 :
    ∀ j : Fin 117, 2187860 ≤ FourPointNumeric.octPackedCharge 121 118 20 packedOct121_118_1
      (2*((j.val : Int)+120)+0) := by decide +kernel

end NineSeparatedSubsetSums
