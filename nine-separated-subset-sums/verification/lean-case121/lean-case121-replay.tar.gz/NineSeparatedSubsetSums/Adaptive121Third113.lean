import NineSeparatedSubsetSums.Adaptive121Third113Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint121Checked

namespace NineSeparatedSubsetSums


theorem adaptive121Third113 : NoDescendingTailAfterThird 121 113 :=
  noDescendingThirdTail_of_cached 121 113 108868 (fun t ht nd => max148_second121_fourPoint_moment_bound (113::t) (by simp [ht]) nd) adaptive121Third113Proof0

#print axioms adaptive121Third113

end NineSeparatedSubsetSums
