import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive121Third118Node0 : CachedSearchNode :=
  ⟨4, 117, computeCenteredMask [148,121,118], 387, 50469⟩

end NineSeparatedSubsetSums
