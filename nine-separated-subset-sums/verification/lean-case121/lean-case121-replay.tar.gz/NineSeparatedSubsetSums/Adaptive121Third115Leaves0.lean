import NineSeparatedSubsetSums.Adaptive121Third115State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive121Third115Proof13 : runCachedNode 511 108868 Adaptive121Third115Node13 = false := by
  decide +kernel

#print axioms adaptive121Third115Proof13

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive121Third115Proof12 : runCachedNode 511 108868 Adaptive121Third115Node12 = false := by
  decide +kernel

#print axioms adaptive121Third115Proof12

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive121Third115Proof11 : runCachedNode 511 108868 Adaptive121Third115Node11 = false := by
  decide +kernel

#print axioms adaptive121Third115Proof11

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive121Third115Proof10 : runCachedNode 511 108868 Adaptive121Third115Node10 = false := by
  decide +kernel

#print axioms adaptive121Third115Proof10

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive121Third115Proof9 : runCachedNode 511 108868 Adaptive121Third115Node9 = false := by
  decide +kernel

#print axioms adaptive121Third115Proof9

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive121Third115Proof8 : runCachedNode 511 108868 Adaptive121Third115Node8 = false := by
  decide +kernel

#print axioms adaptive121Third115Proof8

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive121Third115Proof7 : runCachedNode 511 108868 Adaptive121Third115Node7 = false := by
  decide +kernel

#print axioms adaptive121Third115Proof7

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive121Third115Proof6 : runCachedNode 511 108868 Adaptive121Third115Node6 = false := by
  decide +kernel

#print axioms adaptive121Third115Proof6

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive121Third115Proof4 : runCachedNode 511 108868 Adaptive121Third115Node4 = false := by
  decide +kernel

#print axioms adaptive121Third115Proof4

end NineSeparatedSubsetSums
