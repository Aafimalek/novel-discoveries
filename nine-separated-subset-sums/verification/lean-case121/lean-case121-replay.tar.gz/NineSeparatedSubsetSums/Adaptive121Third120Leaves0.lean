import NineSeparatedSubsetSums.Adaptive121Third120State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive121Third120Proof0 : runCachedNode 511 122054 Adaptive121Third120Node0 = false := by
  decide +kernel

#print axioms adaptive121Third120Proof0

end NineSeparatedSubsetSums
