import NineSeparatedSubsetSums.Adaptive121Third111Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint121Checked

namespace NineSeparatedSubsetSums


theorem adaptive121Third111 : NoDescendingTailAfterThird 121 111 :=
  noDescendingThirdTail_of_cached 121 111 108868 (fun t ht nd => max148_second121_fourPoint_moment_bound (111::t) (by simp [ht]) nd) adaptive121Third111Proof0

#print axioms adaptive121Third111

end NineSeparatedSubsetSums
