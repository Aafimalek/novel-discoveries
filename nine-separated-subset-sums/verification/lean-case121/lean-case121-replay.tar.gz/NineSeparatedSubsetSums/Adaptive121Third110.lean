import NineSeparatedSubsetSums.Adaptive121Third110Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint121Checked

namespace NineSeparatedSubsetSums


theorem adaptive121Third110 : NoDescendingTailAfterThird 121 110 :=
  noDescendingThirdTail_of_cached 121 110 108868 (fun t ht nd => max148_second121_fourPoint_moment_bound (110::t) (by simp [ht]) nd) adaptive121Third110Proof0

#print axioms adaptive121Third110

end NineSeparatedSubsetSums
