import NineSeparatedSubsetSums.EightPoint121_118PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint121_118PackedAnchor1Part0 :
    ∀ j : Fin 120, 2187860 ≤ FourPointNumeric.octPackedCharge 121 118 20 packedOct121_118_1
      (2*((j.val : Int)+0)+0) := by decide +kernel

end NineSeparatedSubsetSums
