import NineSeparatedSubsetSums.Adaptive121Third108Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint121Checked

namespace NineSeparatedSubsetSums


theorem adaptive121Third108 : NoDescendingTailAfterThird 121 108 :=
  noDescendingThirdTail_of_cached 121 108 108868 (fun t ht nd => max148_second121_fourPoint_moment_bound (108::t) (by simp [ht]) nd) adaptive121Third108Proof0

#print axioms adaptive121Third108

end NineSeparatedSubsetSums
