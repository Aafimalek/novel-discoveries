import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive121Third117Node0 : CachedSearchNode :=
  ⟨4, 116, computeCenteredMask [148,121,117], 386, 50234⟩
def Adaptive121Third117Node1 : CachedSearchNode := cachedChild Adaptive121Third117Node0 102
def Adaptive121Third117Node2 : CachedSearchNode := cachedChild Adaptive121Third117Node0 103
def Adaptive121Third117Node3 : CachedSearchNode := cachedChild Adaptive121Third117Node0 104
def Adaptive121Third117Node4 : CachedSearchNode := cachedChild Adaptive121Third117Node0 105
def Adaptive121Third117Node5 : CachedSearchNode := cachedChild Adaptive121Third117Node0 106
def Adaptive121Third117Node6 : CachedSearchNode := cachedChild Adaptive121Third117Node0 107
def Adaptive121Third117Node7 : CachedSearchNode := cachedChild Adaptive121Third117Node0 108
def Adaptive121Third117Node8 : CachedSearchNode := cachedChild Adaptive121Third117Node0 109
def Adaptive121Third117Node9 : CachedSearchNode := cachedChild Adaptive121Third117Node0 110
def Adaptive121Third117Node10 : CachedSearchNode := cachedChild Adaptive121Third117Node0 111
def Adaptive121Third117Node11 : CachedSearchNode := cachedChild Adaptive121Third117Node0 112
def Adaptive121Third117Node12 : CachedSearchNode := cachedChild Adaptive121Third117Node0 113
def Adaptive121Third117Node13 : CachedSearchNode := cachedChild Adaptive121Third117Node0 114
def Adaptive121Third117Node14 : CachedSearchNode := cachedChild Adaptive121Third117Node0 115
def Adaptive121Third117Node15 : CachedSearchNode := cachedChild Adaptive121Third117Node0 116

end NineSeparatedSubsetSums
