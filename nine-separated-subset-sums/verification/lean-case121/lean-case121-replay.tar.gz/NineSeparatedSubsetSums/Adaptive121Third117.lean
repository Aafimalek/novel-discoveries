import NineSeparatedSubsetSums.Adaptive121Third117Joins0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint121Checked

namespace NineSeparatedSubsetSums


theorem adaptive121Third117 : NoDescendingTailAfterThird 121 117 :=
  noDescendingThirdTail_of_cached 121 117 108868 (fun t ht nd => max148_second121_fourPoint_moment_bound (117::t) (by simp [ht]) nd) adaptive121Third117Proof0

#print axioms adaptive121Third117

end NineSeparatedSubsetSums
