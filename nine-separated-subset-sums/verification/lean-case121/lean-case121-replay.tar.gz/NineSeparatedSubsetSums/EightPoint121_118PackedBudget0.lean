import NineSeparatedSubsetSums.EightPoint121_118PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct121_118_0_budget :
    FourPointNumeric.packedBudget 20 packedOct121_118_0 517 = 77657096 := by decide +kernel

#print axioms packedOct121_118_0_budget

end NineSeparatedSubsetSums
