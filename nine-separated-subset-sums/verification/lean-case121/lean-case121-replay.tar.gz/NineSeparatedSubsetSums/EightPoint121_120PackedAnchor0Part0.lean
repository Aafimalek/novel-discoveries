import NineSeparatedSubsetSums.EightPoint121_120PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint121_120PackedAnchor0Part0 :
    ∀ j : Fin 120, 2195772 ≤ FourPointNumeric.octPackedCharge 121 120 20 packedOct121_120_0
      (2*((j.val : Int)+0)+1) := by decide +kernel

end NineSeparatedSubsetSums
