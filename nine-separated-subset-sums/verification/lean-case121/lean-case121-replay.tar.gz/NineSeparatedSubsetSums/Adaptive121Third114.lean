import NineSeparatedSubsetSums.Adaptive121Third114Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint121Checked

namespace NineSeparatedSubsetSums


theorem adaptive121Third114 : NoDescendingTailAfterThird 121 114 :=
  noDescendingThirdTail_of_cached 121 114 108868 (fun t ht nd => max148_second121_fourPoint_moment_bound (114::t) (by simp [ht]) nd) adaptive121Third114Proof0

#print axioms adaptive121Third114

end NineSeparatedSubsetSums
