import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive121Third112Node0 : CachedSearchNode :=
  ⟨4, 111, computeCenteredMask [148,121,112], 381, 49089⟩

end NineSeparatedSubsetSums
