import NineSeparatedSubsetSums.EightPointPackedGeometry
import NineSeparatedSubsetSums.EightPoint121_119PackedBudget0
import NineSeparatedSubsetSums.EightPoint121_119PackedAnchor0Part0
import NineSeparatedSubsetSums.EightPoint121_119PackedAnchor0Part1
import NineSeparatedSubsetSums.EightPoint121_119PackedBudget1
import NineSeparatedSubsetSums.EightPoint121_119PackedAnchor1Part0
import NineSeparatedSubsetSums.EightPoint121_119PackedAnchor1Part1

namespace NineSeparatedSubsetSums

private theorem packedOct121_119Anchor0 :
  ∀ j : Fin 471, ((j.val : Int)+121+119)%2=0 →
    2178934 ≤ FourPointNumeric.octPackedCharge 121 119 20 packedOct121_119_0 (j.val : Int) := by
  intro j hj
  let k := (j.val-0)/2
  have hk : k < 236 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+0 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint121_119PackedAnchor0Part0 z
    rwa [he,hrep] at ht
  let z : Fin 116 := ⟨k-120, by omega⟩
  have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
  have ht := eightPoint121_119PackedAnchor0Part1 z
  rwa [he,hrep] at ht

private theorem packedOct121_119Anchor1 :
  ∀ j : Fin 471, ((j.val : Int)+121+119)%2=1 →
    2177455 ≤ FourPointNumeric.octPackedCharge 121 119 20 packedOct121_119_1 (j.val : Int) := by
  intro j hj
  let k := (j.val-1)/2
  have hk : k < 235 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+1 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint121_119PackedAnchor1Part0 z
    rwa [he,hrep] at ht
  let z : Fin 115 := ⟨k-120, by omega⟩
  have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
  have ht := eightPoint121_119PackedAnchor1Part1 z
  rwa [he,hrep] at ht

def packedOctCertificate121_119_0 : EightPointCertificate 121 119 0 121921 :=
  eightPointCertificateOfPacked 121 119 0 121921 2178934 20 packedOct121_119_0 511 471
    (by decide +kernel) (by decide) packedOct121_119Anchor0
    (by rw [packedOct121_119_0_budget]; decide)

def packedOctCertificate121_119_1 : EightPointCertificate 121 119 1 121921 :=
  eightPointCertificateOfPacked 121 119 1 121921 2177455 20 packedOct121_119_1 400 471
    (by decide +kernel) (by decide) packedOct121_119Anchor1
    (by rw [packedOct121_119_1_budget]; decide)

theorem max148_second121_third119_eightPoint_moment_bound (tail : List ℕ) (len : tail.length=6)
    (distinct : (natSubsetSums (148::121::119::tail)).Nodup) :
    121921 ≤ ((148::121::119::tail).map (· ^ 2)).sum := by
  apply eightPointNatMomentLower 121 119 121921 tail len distinct
  intro p hp
  by_cases h : p=0
  · subst p
    exact packedOctCertificate121_119_0
  · have he : p=1 := hp.resolve_left h
    subst p
    exact packedOctCertificate121_119_1

#print axioms max148_second121_third119_eightPoint_moment_bound

end NineSeparatedSubsetSums
