import NineSeparatedSubsetSums.Adaptive121Third111State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive121Third111Proof0 : runCachedNode 511 108868 Adaptive121Third111Node0 = false := by
  decide +kernel

#print axioms adaptive121Third111Proof0

end NineSeparatedSubsetSums
