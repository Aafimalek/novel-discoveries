import NineSeparatedSubsetSums.EightPoint121_120PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint121_120PackedAnchor1Part0 :
    ∀ j : Fin 120, 2197856 ≤ FourPointNumeric.octPackedCharge 121 120 20 packedOct121_120_1
      (2*((j.val : Int)+0)+0) := by decide +kernel

end NineSeparatedSubsetSums
