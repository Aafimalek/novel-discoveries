import NineSeparatedSubsetSums.Adaptive121Third112State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive121Third112Proof0 : runCachedNode 511 108868 Adaptive121Third112Node0 = false := by
  decide +kernel

#print axioms adaptive121Third112Proof0

end NineSeparatedSubsetSums
