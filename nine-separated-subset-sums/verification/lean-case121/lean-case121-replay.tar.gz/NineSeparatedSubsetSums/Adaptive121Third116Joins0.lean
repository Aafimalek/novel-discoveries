import NineSeparatedSubsetSums.Adaptive121Third116State
import NineSeparatedSubsetSums.Adaptive121Third116Leaves1
import NineSeparatedSubsetSums.Adaptive121Third116Leaves0

namespace NineSeparatedSubsetSums

theorem adaptive121Third116Proof0 : runCachedNode 511 108868 Adaptive121Third116Node0 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 108868 Adaptive121Third116Node0 = [102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive121Third116Proof1
  · exact adaptive121Third116Proof2
  · exact adaptive121Third116Proof3
  · exact adaptive121Third116Proof4
  · exact adaptive121Third116Proof5
  · exact adaptive121Third116Proof6
  · exact adaptive121Third116Proof7
  · exact adaptive121Third116Proof8
  · exact adaptive121Third116Proof9
  · exact adaptive121Third116Proof10
  · exact adaptive121Third116Proof11
  · exact adaptive121Third116Proof12
  · exact adaptive121Third116Proof13
  · exact adaptive121Third116Proof14

#print axioms adaptive121Third116Proof0

end NineSeparatedSubsetSums
