import NineSeparatedSubsetSums.EightPointPackedGeometry
import NineSeparatedSubsetSums.EightPoint121_118PackedBudget0
import NineSeparatedSubsetSums.EightPoint121_118PackedAnchor0Part0
import NineSeparatedSubsetSums.EightPoint121_118PackedAnchor0Part1
import NineSeparatedSubsetSums.EightPoint121_118PackedBudget1
import NineSeparatedSubsetSums.EightPoint121_118PackedAnchor1Part0
import NineSeparatedSubsetSums.EightPoint121_118PackedAnchor1Part1

namespace NineSeparatedSubsetSums

private theorem packedOct121_118Anchor0 :
  ∀ j : Fin 473, ((j.val : Int)+121+118)%2=0 →
    2187857 ≤ FourPointNumeric.octPackedCharge 121 118 20 packedOct121_118_0 (j.val : Int) := by
  intro j hj
  let k := (j.val-1)/2
  have hk : k < 236 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+1 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint121_118PackedAnchor0Part0 z
    rwa [he,hrep] at ht
  let z : Fin 116 := ⟨k-120, by omega⟩
  have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
  have ht := eightPoint121_118PackedAnchor0Part1 z
  rwa [he,hrep] at ht

private theorem packedOct121_118Anchor1 :
  ∀ j : Fin 473, ((j.val : Int)+121+118)%2=1 →
    2187860 ≤ FourPointNumeric.octPackedCharge 121 118 20 packedOct121_118_1 (j.val : Int) := by
  intro j hj
  let k := (j.val-0)/2
  have hk : k < 237 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+0 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint121_118PackedAnchor1Part0 z
    rwa [he,hrep] at ht
  let z : Fin 117 := ⟨k-120, by omega⟩
  have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
  have ht := eightPoint121_118PackedAnchor1Part1 z
  rwa [he,hrep] at ht

def packedOctCertificate121_118_0 : EightPointCertificate 121 118 0 121808 :=
  eightPointCertificateOfPacked 121 118 0 121808 2187857 20 packedOct121_118_0 517 473
    (by decide +kernel) (by decide) packedOct121_118Anchor0
    (by rw [packedOct121_118_0_budget]; decide)

def packedOctCertificate121_118_1 : EightPointCertificate 121 118 1 121808 :=
  eightPointCertificateOfPacked 121 118 1 121808 2187860 20 packedOct121_118_1 512 473
    (by decide +kernel) (by decide) packedOct121_118Anchor1
    (by rw [packedOct121_118_1_budget]; decide)

theorem max148_second121_third118_eightPoint_moment_bound (tail : List ℕ) (len : tail.length=6)
    (distinct : (natSubsetSums (148::121::118::tail)).Nodup) :
    121808 ≤ ((148::121::118::tail).map (· ^ 2)).sum := by
  apply eightPointNatMomentLower 121 118 121808 tail len distinct
  intro p hp
  by_cases h : p=0
  · subst p
    exact packedOctCertificate121_118_0
  · have he : p=1 := hp.resolve_left h
    subst p
    exact packedOctCertificate121_118_1

#print axioms max148_second121_third118_eightPoint_moment_bound

end NineSeparatedSubsetSums
