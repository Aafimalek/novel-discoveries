import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive121Third111Node0 : CachedSearchNode :=
  ⟨4, 110, computeCenteredMask [148,121,111], 380, 48866⟩

end NineSeparatedSubsetSums
