import NineSeparatedSubsetSums.Adaptive121Third116State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive121Third116Proof14 : runCachedNode 511 108868 Adaptive121Third116Node14 = false := by
  decide +kernel

#print axioms adaptive121Third116Proof14

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive121Third116Proof13 : runCachedNode 511 108868 Adaptive121Third116Node13 = false := by
  decide +kernel

#print axioms adaptive121Third116Proof13

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive121Third116Proof12 : runCachedNode 511 108868 Adaptive121Third116Node12 = false := by
  decide +kernel

#print axioms adaptive121Third116Proof12

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive121Third116Proof10 : runCachedNode 511 108868 Adaptive121Third116Node10 = false := by
  decide +kernel

#print axioms adaptive121Third116Proof10

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive121Third116Proof9 : runCachedNode 511 108868 Adaptive121Third116Node9 = false := by
  decide +kernel

#print axioms adaptive121Third116Proof9

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive121Third116Proof2 : runCachedNode 511 108868 Adaptive121Third116Node2 = false := by
  decide +kernel

#print axioms adaptive121Third116Proof2

end NineSeparatedSubsetSums
