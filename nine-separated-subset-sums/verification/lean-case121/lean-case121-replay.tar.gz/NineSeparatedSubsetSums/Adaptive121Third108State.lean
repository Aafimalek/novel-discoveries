import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive121Third108Node0 : CachedSearchNode :=
  ⟨4, 107, computeCenteredMask [148,121,108], 377, 48209⟩

end NineSeparatedSubsetSums
