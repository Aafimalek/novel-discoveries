import NineSeparatedSubsetSums.Adaptive121Third109Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint121Checked

namespace NineSeparatedSubsetSums


theorem adaptive121Third109 : NoDescendingTailAfterThird 121 109 :=
  noDescendingThirdTail_of_cached 121 109 108868 (fun t ht nd => max148_second121_fourPoint_moment_bound (109::t) (by simp [ht]) nd) adaptive121Third109Proof0

#print axioms adaptive121Third109

end NineSeparatedSubsetSums
