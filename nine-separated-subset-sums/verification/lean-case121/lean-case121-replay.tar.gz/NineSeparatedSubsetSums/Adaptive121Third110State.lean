import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive121Third110Node0 : CachedSearchNode :=
  ⟨4, 109, computeCenteredMask [148,121,110], 379, 48645⟩

end NineSeparatedSubsetSums
