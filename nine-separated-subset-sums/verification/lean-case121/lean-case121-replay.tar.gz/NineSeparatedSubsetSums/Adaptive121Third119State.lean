import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive121Third119Node0 : CachedSearchNode :=
  ⟨4, 118, computeCenteredMask [148,121,119], 388, 50706⟩

end NineSeparatedSubsetSums
