import NineSeparatedSubsetSums.Adaptive121Third112Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint121Checked

namespace NineSeparatedSubsetSums


theorem adaptive121Third112 : NoDescendingTailAfterThird 121 112 :=
  noDescendingThirdTail_of_cached 121 112 108868 (fun t ht nd => max148_second121_fourPoint_moment_bound (112::t) (by simp [ht]) nd) adaptive121Third112Proof0

#print axioms adaptive121Third112

end NineSeparatedSubsetSums
