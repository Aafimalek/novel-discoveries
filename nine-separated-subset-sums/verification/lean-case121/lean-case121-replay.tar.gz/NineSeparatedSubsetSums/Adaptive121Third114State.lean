import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive121Third114Node0 : CachedSearchNode :=
  ⟨4, 113, computeCenteredMask [148,121,114], 383, 49541⟩

end NineSeparatedSubsetSums
