import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive121Third106Node0 : CachedSearchNode :=
  ⟨4, 105, computeCenteredMask [148,121,106], 375, 47781⟩

end NineSeparatedSubsetSums
