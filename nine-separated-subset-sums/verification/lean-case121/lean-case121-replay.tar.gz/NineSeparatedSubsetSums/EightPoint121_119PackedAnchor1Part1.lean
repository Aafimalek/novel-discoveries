import NineSeparatedSubsetSums.EightPoint121_119PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint121_119PackedAnchor1Part1 :
    ∀ j : Fin 115, 2177455 ≤ FourPointNumeric.octPackedCharge 121 119 20 packedOct121_119_1
      (2*((j.val : Int)+120)+1) := by decide +kernel

end NineSeparatedSubsetSums
