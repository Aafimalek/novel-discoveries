import NineSeparatedSubsetSums.Adaptive121Third115State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive121Third115Proof5 : runCachedNode 511 108868 Adaptive121Third115Node5 = false := by
  decide +kernel

#print axioms adaptive121Third115Proof5

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive121Third115Proof3 : runCachedNode 511 108868 Adaptive121Third115Node3 = false := by
  decide +kernel

#print axioms adaptive121Third115Proof3

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive121Third115Proof2 : runCachedNode 511 108868 Adaptive121Third115Node2 = false := by
  decide +kernel

#print axioms adaptive121Third115Proof2

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive121Third115Proof1 : runCachedNode 511 108868 Adaptive121Third115Node1 = false := by
  decide +kernel

#print axioms adaptive121Third115Proof1

end NineSeparatedSubsetSums
