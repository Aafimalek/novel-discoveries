import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive122Third119Node0 : CachedSearchNode :=
  ⟨4, 118, computeCenteredMask [148,122,119], 389, 50949⟩

end NineSeparatedSubsetSums
