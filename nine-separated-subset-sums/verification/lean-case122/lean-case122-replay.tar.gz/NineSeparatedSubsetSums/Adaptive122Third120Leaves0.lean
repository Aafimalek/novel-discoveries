import NineSeparatedSubsetSums.Adaptive122Third120State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive122Third120Proof0 : runCachedNode 511 122193 Adaptive122Third120Node0 = false := by
  decide +kernel

#print axioms adaptive122Third120Proof0

end NineSeparatedSubsetSums
