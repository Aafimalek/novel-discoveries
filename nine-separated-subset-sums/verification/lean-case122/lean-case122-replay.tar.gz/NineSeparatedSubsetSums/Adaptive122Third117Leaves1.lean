import NineSeparatedSubsetSums.Adaptive122Third117State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive122Third117Proof11 : runCachedNode 511 109064 Adaptive122Third117Node11 = false := by
  decide +kernel

#print axioms adaptive122Third117Proof11

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive122Third117Proof12 : runCachedNode 511 109064 Adaptive122Third117Node12 = false := by
  decide +kernel

#print axioms adaptive122Third117Proof12

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive122Third117Proof10 : runCachedNode 511 109064 Adaptive122Third117Node10 = false := by
  decide +kernel

#print axioms adaptive122Third117Proof10

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive122Third117Proof9 : runCachedNode 511 109064 Adaptive122Third117Node9 = false := by
  decide +kernel

#print axioms adaptive122Third117Proof9

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive122Third117Proof7 : runCachedNode 511 109064 Adaptive122Third117Node7 = false := by
  decide +kernel

#print axioms adaptive122Third117Proof7

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive122Third117Proof6 : runCachedNode 511 109064 Adaptive122Third117Node6 = false := by
  decide +kernel

#print axioms adaptive122Third117Proof6

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive122Third117Proof5 : runCachedNode 511 109064 Adaptive122Third117Node5 = false := by
  decide +kernel

#print axioms adaptive122Third117Proof5

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive122Third117Proof4 : runCachedNode 511 109064 Adaptive122Third117Node4 = false := by
  decide +kernel

#print axioms adaptive122Third117Proof4

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive122Third117Proof3 : runCachedNode 511 109064 Adaptive122Third117Node3 = false := by
  decide +kernel

#print axioms adaptive122Third117Proof3

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive122Third117Proof2 : runCachedNode 511 109064 Adaptive122Third117Node2 = false := by
  decide +kernel

#print axioms adaptive122Third117Proof2

end NineSeparatedSubsetSums
