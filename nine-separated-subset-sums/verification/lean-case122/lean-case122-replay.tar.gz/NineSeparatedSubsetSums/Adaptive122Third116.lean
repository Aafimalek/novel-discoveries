import NineSeparatedSubsetSums.Adaptive122Third116Joins0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint122Checked

namespace NineSeparatedSubsetSums


theorem adaptive122Third116 : NoDescendingTailAfterThird 122 116 :=
  noDescendingThirdTail_of_cached 122 116 109064 (fun t ht nd => max148_second122_fourPoint_moment_bound (116::t) (by simp [ht]) nd) adaptive122Third116Proof0

#print axioms adaptive122Third116

end NineSeparatedSubsetSums
