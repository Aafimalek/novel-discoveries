import NineSeparatedSubsetSums.EightPoint122_121PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint122_121PackedAnchor0Part0 :
    ∀ j : Fin 120, 2230122 ≤ FourPointNumeric.octPackedCharge 122 121 20 packedOct122_121_0
      (2*((j.val : Int)+0)+1) := by decide +kernel

end NineSeparatedSubsetSums
