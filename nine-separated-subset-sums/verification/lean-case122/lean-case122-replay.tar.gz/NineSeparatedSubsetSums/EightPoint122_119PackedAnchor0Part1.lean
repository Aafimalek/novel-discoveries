import NineSeparatedSubsetSums.EightPoint122_119PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint122_119PackedAnchor0Part1 :
    ∀ j : Fin 115, 2180286 ≤ FourPointNumeric.octPackedCharge 122 119 20 packedOct122_119_0
      (2*((j.val : Int)+120)+1) := by decide +kernel

end NineSeparatedSubsetSums
