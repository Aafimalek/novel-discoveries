import NineSeparatedSubsetSums.FourPoint122PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedWeight122_1_budget :
    FourPointNumeric.packedBudget 20 packedWeight122_1 552 = 81623552 := by decide +kernel

#print axioms packedWeight122_1_budget

end NineSeparatedSubsetSums
