import NineSeparatedSubsetSums.Adaptive122Third111Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint122Checked

namespace NineSeparatedSubsetSums


theorem adaptive122Third111 : NoDescendingTailAfterThird 122 111 :=
  noDescendingThirdTail_of_cached 122 111 109064 (fun t ht nd => max148_second122_fourPoint_moment_bound (111::t) (by simp [ht]) nd) adaptive122Third111Proof0

#print axioms adaptive122Third111

end NineSeparatedSubsetSums
