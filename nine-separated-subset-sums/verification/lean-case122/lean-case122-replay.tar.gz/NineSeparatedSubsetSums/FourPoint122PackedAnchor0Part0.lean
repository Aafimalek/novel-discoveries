import NineSeparatedSubsetSums.FourPoint122PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem fourPoint122PackedAnchor0Part0 :
    ∀ j : Fin 120, 1073952 ≤ FourPointNumeric.packedCharge 122 20 packedWeight122_0
      (2*((j.val : Int)+0)+0) := by decide +kernel

end NineSeparatedSubsetSums
