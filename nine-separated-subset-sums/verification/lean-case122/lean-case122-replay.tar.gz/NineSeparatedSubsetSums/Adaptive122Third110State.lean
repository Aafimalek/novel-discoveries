import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive122Third110Node0 : CachedSearchNode :=
  ⟨4, 109, computeCenteredMask [148,122,110], 380, 48888⟩

end NineSeparatedSubsetSums
