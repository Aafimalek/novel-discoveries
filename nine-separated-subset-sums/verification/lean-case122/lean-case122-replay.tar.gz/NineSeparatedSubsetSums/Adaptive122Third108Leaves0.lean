import NineSeparatedSubsetSums.Adaptive122Third108State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive122Third108Proof0 : runCachedNode 511 109064 Adaptive122Third108Node0 = false := by
  decide +kernel

#print axioms adaptive122Third108Proof0

end NineSeparatedSubsetSums
