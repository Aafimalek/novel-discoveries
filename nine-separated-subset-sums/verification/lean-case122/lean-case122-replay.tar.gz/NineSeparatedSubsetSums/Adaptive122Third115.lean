import NineSeparatedSubsetSums.Adaptive122Third115Joins0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint122Checked

namespace NineSeparatedSubsetSums


theorem adaptive122Third115 : NoDescendingTailAfterThird 122 115 :=
  noDescendingThirdTail_of_cached 122 115 109064 (fun t ht nd => max148_second122_fourPoint_moment_bound (115::t) (by simp [ht]) nd) adaptive122Third115Proof0

#print axioms adaptive122Third115

end NineSeparatedSubsetSums
