import NineSeparatedSubsetSums.Adaptive122Third117Joins0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint122Checked

namespace NineSeparatedSubsetSums


theorem adaptive122Third117 : NoDescendingTailAfterThird 122 117 :=
  noDescendingThirdTail_of_cached 122 117 109064 (fun t ht nd => max148_second122_fourPoint_moment_bound (117::t) (by simp [ht]) nd) adaptive122Third117Proof0

#print axioms adaptive122Third117

end NineSeparatedSubsetSums
