import NineSeparatedSubsetSums.Adaptive122Third114Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint122Checked

namespace NineSeparatedSubsetSums


theorem adaptive122Third114 : NoDescendingTailAfterThird 122 114 :=
  noDescendingThirdTail_of_cached 122 114 109064 (fun t ht nd => max148_second122_fourPoint_moment_bound (114::t) (by simp [ht]) nd) adaptive122Third114Proof0

#print axioms adaptive122Third114

end NineSeparatedSubsetSums
