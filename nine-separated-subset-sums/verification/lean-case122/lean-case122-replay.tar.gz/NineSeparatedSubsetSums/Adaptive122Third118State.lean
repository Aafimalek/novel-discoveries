import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive122Third118Node0 : CachedSearchNode :=
  ⟨4, 117, computeCenteredMask [148,122,118], 388, 50712⟩

end NineSeparatedSubsetSums
