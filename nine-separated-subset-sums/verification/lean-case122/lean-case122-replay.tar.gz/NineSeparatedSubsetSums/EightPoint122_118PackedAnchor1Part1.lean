import NineSeparatedSubsetSums.EightPoint122_118PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint122_118PackedAnchor1Part1 :
    ∀ j : Fin 116, 2188904 ≤ FourPointNumeric.octPackedCharge 122 118 20 packedOct122_118_1
      (2*((j.val : Int)+120)+1) := by decide +kernel

end NineSeparatedSubsetSums
