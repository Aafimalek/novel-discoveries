import NineSeparatedSubsetSums.EightPointPackedGeometry
import NineSeparatedSubsetSums.EightPoint122_119PackedBudget0
import NineSeparatedSubsetSums.EightPoint122_119PackedAnchor0Part0
import NineSeparatedSubsetSums.EightPoint122_119PackedAnchor0Part1
import NineSeparatedSubsetSums.EightPoint122_119PackedBudget1
import NineSeparatedSubsetSums.EightPoint122_119PackedAnchor1Part0
import NineSeparatedSubsetSums.EightPoint122_119PackedAnchor1Part1

namespace NineSeparatedSubsetSums

private theorem packedOct122_119Anchor0 :
  ∀ j : Fin 471, ((j.val : Int)+122+119)%2=0 →
    2180286 ≤ FourPointNumeric.octPackedCharge 122 119 20 packedOct122_119_0 (j.val : Int) := by
  intro j hj
  let k := (j.val-1)/2
  have hk : k < 235 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+1 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint122_119PackedAnchor0Part0 z
    rwa [he,hrep] at ht
  let z : Fin 115 := ⟨k-120, by omega⟩
  have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
  have ht := eightPoint122_119PackedAnchor0Part1 z
  rwa [he,hrep] at ht

private theorem packedOct122_119Anchor1 :
  ∀ j : Fin 471, ((j.val : Int)+122+119)%2=1 →
    2179827 ≤ FourPointNumeric.octPackedCharge 122 119 20 packedOct122_119_1 (j.val : Int) := by
  intro j hj
  let k := (j.val-0)/2
  have hk : k < 236 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+0 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint122_119PackedAnchor1Part0 z
    rwa [he,hrep] at ht
  let z : Fin 116 := ⟨k-120, by omega⟩
  have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
  have ht := eightPoint122_119PackedAnchor1Part1 z
  rwa [he,hrep] at ht

def packedOctCertificate122_119_0 : EightPointCertificate 122 119 0 122058 :=
  eightPointCertificateOfPacked 122 119 0 122058 2180286 20 packedOct122_119_0 499 471
    (by decide +kernel) (by decide) packedOct122_119Anchor0
    (by rw [packedOct122_119_0_budget]; decide)

def packedOctCertificate122_119_1 : EightPointCertificate 122 119 1 122058 :=
  eightPointCertificateOfPacked 122 119 1 122058 2179827 20 packedOct122_119_1 396 471
    (by decide +kernel) (by decide) packedOct122_119Anchor1
    (by rw [packedOct122_119_1_budget]; decide)

theorem max148_second122_third119_eightPoint_moment_bound (tail : List ℕ) (len : tail.length=6)
    (distinct : (natSubsetSums (148::122::119::tail)).Nodup) :
    122058 ≤ ((148::122::119::tail).map (· ^ 2)).sum := by
  apply eightPointNatMomentLower 122 119 122058 tail len distinct
  intro p hp
  by_cases h : p=0
  · subst p
    exact packedOctCertificate122_119_0
  · have he : p=1 := hp.resolve_left h
    subst p
    exact packedOctCertificate122_119_1

#print axioms max148_second122_third119_eightPoint_moment_bound

end NineSeparatedSubsetSums
