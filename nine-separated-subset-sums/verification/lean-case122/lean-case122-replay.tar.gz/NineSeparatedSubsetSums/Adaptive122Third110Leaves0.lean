import NineSeparatedSubsetSums.Adaptive122Third110State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive122Third110Proof0 : runCachedNode 511 109064 Adaptive122Third110Node0 = false := by
  decide +kernel

#print axioms adaptive122Third110Proof0

end NineSeparatedSubsetSums
