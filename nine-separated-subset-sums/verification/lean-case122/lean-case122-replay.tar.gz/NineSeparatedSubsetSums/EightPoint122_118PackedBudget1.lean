import NineSeparatedSubsetSums.EightPoint122_118PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct122_118_1_budget :
    FourPointNumeric.packedBudget 20 packedOct122_118_1 498 = 77642240 := by decide +kernel

#print axioms packedOct122_118_1_budget

end NineSeparatedSubsetSums
