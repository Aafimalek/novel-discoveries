import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive122Third113Node0 : CachedSearchNode :=
  ⟨4, 112, computeCenteredMask [148,122,113], 383, 49557⟩

end NineSeparatedSubsetSums
