import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive122Third111Node0 : CachedSearchNode :=
  ⟨4, 110, computeCenteredMask [148,122,111], 381, 49109⟩

end NineSeparatedSubsetSums
