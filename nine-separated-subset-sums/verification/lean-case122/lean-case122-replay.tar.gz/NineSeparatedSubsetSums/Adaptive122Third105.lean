import NineSeparatedSubsetSums.Adaptive122Third105Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint122Checked

namespace NineSeparatedSubsetSums


theorem adaptive122Third105 : NoDescendingTailAfterThird 122 105 :=
  noDescendingThirdTail_of_cached 122 105 109064 (fun t ht nd => max148_second122_fourPoint_moment_bound (105::t) (by simp [ht]) nd) adaptive122Third105Proof0

#print axioms adaptive122Third105

end NineSeparatedSubsetSums
