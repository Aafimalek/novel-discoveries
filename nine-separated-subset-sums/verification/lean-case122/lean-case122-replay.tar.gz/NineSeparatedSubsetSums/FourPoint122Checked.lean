import NineSeparatedSubsetSums.FourPointPackedGeometry
import NineSeparatedSubsetSums.FourPoint122PackedBudget0
import NineSeparatedSubsetSums.FourPoint122PackedAnchor0Part0
import NineSeparatedSubsetSums.FourPoint122PackedAnchor0Part1
import NineSeparatedSubsetSums.FourPoint122PackedAnchor0Part2
import NineSeparatedSubsetSums.FourPoint122PackedBudget1
import NineSeparatedSubsetSums.FourPoint122PackedAnchor1Part0
import NineSeparatedSubsetSums.FourPoint122PackedAnchor1Part1
import NineSeparatedSubsetSums.FourPoint122PackedAnchor1Part2

namespace NineSeparatedSubsetSums

private theorem packed122Anchor0 :
  ∀ j : Fin 482, ((j.val : Int)+122)%2=0 →
    1073952 ≤ FourPointNumeric.packedCharge 122 20 packedWeight122_0 (j.val : Int) := by
  intro j hj
  let k := (j.val-0)/2
  have hk : k < 241 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+0 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := fourPoint122PackedAnchor0Part0 z
    rwa [he,hrep] at ht
  by_cases h1 : k < 240
  · let z : Fin 120 := ⟨k-120, by omega⟩
    have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
    have ht := fourPoint122PackedAnchor0Part1 z
    rwa [he,hrep] at ht
  let z : Fin 1 := ⟨k-240, by omega⟩
  have he : (z.val : Int)+240 = k := by dsimp [z] <;> omega
  have ht := fourPoint122PackedAnchor0Part2 z
  rwa [he,hrep] at ht

private theorem packed122Anchor1 :
  ∀ j : Fin 482, ((j.val : Int)+122)%2=1 →
    1073940 ≤ FourPointNumeric.packedCharge 122 20 packedWeight122_1 (j.val : Int) := by
  intro j hj
  let k := (j.val-1)/2
  have hk : k < 241 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+1 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := fourPoint122PackedAnchor1Part0 z
    rwa [he,hrep] at ht
  by_cases h1 : k < 240
  · let z : Fin 120 := ⟨k-120, by omega⟩
    have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
    have ht := fourPoint122PackedAnchor1Part1 z
    rwa [he,hrep] at ht
  let z : Fin 1 := ⟨k-240, by omega⟩
  have he : (z.val : Int)+240 = k := by dsimp [z] <;> omega
  have ht := fourPoint122PackedAnchor1Part2 z
  rwa [he,hrep] at ht

def packedCertificate122_0 : FourPointCertificate 122 0 109064 :=
  fourPointCertificateOfPacked 122 0 109064 1073952 20 packedWeight122_0 549 482
    (by decide +kernel) (by decide) (by decide) packed122Anchor0
    (by rw [packedWeight122_0_budget]; decide)

def packedCertificate122_1 : FourPointCertificate 122 1 109064 :=
  fourPointCertificateOfPacked 122 1 109064 1073940 20 packedWeight122_1 552 482
    (by decide +kernel) (by decide) (by decide) packed122Anchor1
    (by rw [packedWeight122_1_budget]; decide)

theorem max148_second122_fourPoint_moment_bound (tail : List ℕ) (len : tail.length=7)
    (distinct : (natSubsetSums (148::122::tail)).Nodup) :
    109064 ≤ ((148::122::tail).map (· ^ 2)).sum := by
  apply fourPointNatMomentLower 122 109064 tail len distinct
  intro p hp
  by_cases h : p=0
  · subst p
    exact packedCertificate122_0
  · have he : p=1 := hp.resolve_left h
    subst p
    exact packedCertificate122_1

#print axioms max148_second122_fourPoint_moment_bound

end NineSeparatedSubsetSums
