import NineSeparatedSubsetSums.EightPoint122_120PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint122_120PackedAnchor1Part0 :
    ∀ j : Fin 120, 2209918 ≤ FourPointNumeric.octPackedCharge 122 120 20 packedOct122_120_1
      (2*((j.val : Int)+0)+1) := by decide +kernel

end NineSeparatedSubsetSums
