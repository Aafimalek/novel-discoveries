import NineSeparatedSubsetSums.EightPointPackedGeometry
import NineSeparatedSubsetSums.EightPoint122_118PackedBudget0
import NineSeparatedSubsetSums.EightPoint122_118PackedAnchor0Part0
import NineSeparatedSubsetSums.EightPoint122_118PackedAnchor0Part1
import NineSeparatedSubsetSums.EightPoint122_118PackedBudget1
import NineSeparatedSubsetSums.EightPoint122_118PackedAnchor1Part0
import NineSeparatedSubsetSums.EightPoint122_118PackedAnchor1Part1

namespace NineSeparatedSubsetSums

private theorem packedOct122_118Anchor0 :
  ∀ j : Fin 473, ((j.val : Int)+122+118)%2=0 →
    2189376 ≤ FourPointNumeric.octPackedCharge 122 118 20 packedOct122_118_0 (j.val : Int) := by
  intro j hj
  let k := (j.val-0)/2
  have hk : k < 237 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+0 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint122_118PackedAnchor0Part0 z
    rwa [he,hrep] at ht
  let z : Fin 117 := ⟨k-120, by omega⟩
  have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
  have ht := eightPoint122_118PackedAnchor0Part1 z
  rwa [he,hrep] at ht

private theorem packedOct122_118Anchor1 :
  ∀ j : Fin 473, ((j.val : Int)+122+118)%2=1 →
    2188904 ≤ FourPointNumeric.octPackedCharge 122 118 20 packedOct122_118_1 (j.val : Int) := by
  intro j hj
  let k := (j.val-1)/2
  have hk : k < 236 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+1 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint122_118PackedAnchor1Part0 z
    rwa [he,hrep] at ht
  let z : Fin 116 := ⟨k-120, by omega⟩
  have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
  have ht := eightPoint122_118PackedAnchor1Part1 z
  rwa [he,hrep] at ht

def packedOctCertificate122_118_0 : EightPointCertificate 122 118 0 121968 :=
  eightPointCertificateOfPacked 122 118 0 121968 2189376 20 packedOct122_118_0 511 473
    (by decide +kernel) (by decide) packedOct122_118Anchor0
    (by rw [packedOct122_118_0_budget]; decide)

def packedOctCertificate122_118_1 : EightPointCertificate 122 118 1 121968 :=
  eightPointCertificateOfPacked 122 118 1 121968 2188904 20 packedOct122_118_1 498 473
    (by decide +kernel) (by decide) packedOct122_118Anchor1
    (by rw [packedOct122_118_1_budget]; decide)

theorem max148_second122_third118_eightPoint_moment_bound (tail : List ℕ) (len : tail.length=6)
    (distinct : (natSubsetSums (148::122::118::tail)).Nodup) :
    121968 ≤ ((148::122::118::tail).map (· ^ 2)).sum := by
  apply eightPointNatMomentLower 122 118 121968 tail len distinct
  intro p hp
  by_cases h : p=0
  · subst p
    exact packedOctCertificate122_118_0
  · have he : p=1 := hp.resolve_left h
    subst p
    exact packedOctCertificate122_118_1

#print axioms max148_second122_third118_eightPoint_moment_bound

end NineSeparatedSubsetSums
