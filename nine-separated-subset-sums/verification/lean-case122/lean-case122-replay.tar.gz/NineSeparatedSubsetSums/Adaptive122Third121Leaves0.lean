import NineSeparatedSubsetSums.Adaptive122Third121State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive122Third121Proof0 : runCachedNode 511 122376 Adaptive122Third121Node0 = false := by
  decide +kernel

#print axioms adaptive122Third121Proof0

end NineSeparatedSubsetSums
