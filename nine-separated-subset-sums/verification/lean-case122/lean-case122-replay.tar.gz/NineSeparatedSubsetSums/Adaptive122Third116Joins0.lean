import NineSeparatedSubsetSums.Adaptive122Third116State
import NineSeparatedSubsetSums.Adaptive122Third116Leaves0
import NineSeparatedSubsetSums.Adaptive122Third116Leaves1

namespace NineSeparatedSubsetSums

theorem adaptive122Third116Proof0 : runCachedNode 511 109064 Adaptive122Third116Node0 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 109064 Adaptive122Third116Node0 = [102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive122Third116Proof1
  · exact adaptive122Third116Proof2
  · exact adaptive122Third116Proof3
  · exact adaptive122Third116Proof4
  · exact adaptive122Third116Proof5
  · exact adaptive122Third116Proof6
  · exact adaptive122Third116Proof7
  · exact adaptive122Third116Proof8
  · exact adaptive122Third116Proof9
  · exact adaptive122Third116Proof10
  · exact adaptive122Third116Proof11
  · exact adaptive122Third116Proof12
  · exact adaptive122Third116Proof13
  · exact adaptive122Third116Proof14

#print axioms adaptive122Third116Proof0

end NineSeparatedSubsetSums
