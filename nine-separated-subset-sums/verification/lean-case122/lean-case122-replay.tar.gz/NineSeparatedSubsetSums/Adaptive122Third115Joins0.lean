import NineSeparatedSubsetSums.Adaptive122Third115State
import NineSeparatedSubsetSums.Adaptive122Third115Leaves0
import NineSeparatedSubsetSums.Adaptive122Third115Leaves1

namespace NineSeparatedSubsetSums

theorem adaptive122Third115Proof0 : runCachedNode 511 109064 Adaptive122Third115Node0 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 109064 Adaptive122Third115Node0 = [102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive122Third115Proof1
  · exact adaptive122Third115Proof2
  · exact adaptive122Third115Proof3
  · exact adaptive122Third115Proof4
  · exact adaptive122Third115Proof5
  · exact adaptive122Third115Proof6
  · exact adaptive122Third115Proof7
  · exact adaptive122Third115Proof8
  · exact adaptive122Third115Proof9
  · exact adaptive122Third115Proof10
  · exact adaptive122Third115Proof11
  · exact adaptive122Third115Proof12
  · exact adaptive122Third115Proof13

#print axioms adaptive122Third115Proof0

end NineSeparatedSubsetSums
