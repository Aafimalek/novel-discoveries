import NineSeparatedSubsetSums.Adaptive122Third115State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive122Third115Proof6 : runCachedNode 511 109064 Adaptive122Third115Node6 = false := by
  decide +kernel

#print axioms adaptive122Third115Proof6

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive122Third115Proof5 : runCachedNode 511 109064 Adaptive122Third115Node5 = false := by
  decide +kernel

#print axioms adaptive122Third115Proof5

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive122Third115Proof3 : runCachedNode 511 109064 Adaptive122Third115Node3 = false := by
  decide +kernel

#print axioms adaptive122Third115Proof3

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive122Third115Proof2 : runCachedNode 511 109064 Adaptive122Third115Node2 = false := by
  decide +kernel

#print axioms adaptive122Third115Proof2

end NineSeparatedSubsetSums
