import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive122Third114Node0 : CachedSearchNode :=
  ⟨4, 113, computeCenteredMask [148,122,114], 384, 49784⟩

end NineSeparatedSubsetSums
