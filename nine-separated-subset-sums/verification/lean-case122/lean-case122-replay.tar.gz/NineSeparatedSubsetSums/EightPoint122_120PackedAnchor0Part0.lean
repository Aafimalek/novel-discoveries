import NineSeparatedSubsetSums.EightPoint122_120PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint122_120PackedAnchor0Part0 :
    ∀ j : Fin 120, 2240183 ≤ FourPointNumeric.octPackedCharge 122 120 20 packedOct122_120_0
      (2*((j.val : Int)+0)+0) := by decide +kernel

end NineSeparatedSubsetSums
