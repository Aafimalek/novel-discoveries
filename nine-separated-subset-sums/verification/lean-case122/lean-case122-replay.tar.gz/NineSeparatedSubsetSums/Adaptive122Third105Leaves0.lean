import NineSeparatedSubsetSums.Adaptive122Third105State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive122Third105Proof0 : runCachedNode 511 109064 Adaptive122Third105Node0 = false := by
  decide +kernel

#print axioms adaptive122Third105Proof0

end NineSeparatedSubsetSums
