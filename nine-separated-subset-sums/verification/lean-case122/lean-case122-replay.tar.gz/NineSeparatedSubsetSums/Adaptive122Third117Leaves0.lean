import NineSeparatedSubsetSums.Adaptive122Third117State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive122Third117Proof15 : runCachedNode 511 109064 Adaptive122Third117Node15 = false := by
  decide +kernel

#print axioms adaptive122Third117Proof15

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive122Third117Proof14 : runCachedNode 511 109064 Adaptive122Third117Node14 = false := by
  decide +kernel

#print axioms adaptive122Third117Proof14

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive122Third117Proof13 : runCachedNode 511 109064 Adaptive122Third117Node13 = false := by
  decide +kernel

#print axioms adaptive122Third117Proof13

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive122Third117Proof8 : runCachedNode 511 109064 Adaptive122Third117Node8 = false := by
  decide +kernel

#print axioms adaptive122Third117Proof8

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive122Third117Proof1 : runCachedNode 511 109064 Adaptive122Third117Node1 = false := by
  decide +kernel

#print axioms adaptive122Third117Proof1

end NineSeparatedSubsetSums
