import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive122Third117Node0 : CachedSearchNode :=
  ⟨4, 116, computeCenteredMask [148,122,117], 387, 50477⟩
def Adaptive122Third117Node1 : CachedSearchNode := cachedChild Adaptive122Third117Node0 102
def Adaptive122Third117Node2 : CachedSearchNode := cachedChild Adaptive122Third117Node0 103
def Adaptive122Third117Node3 : CachedSearchNode := cachedChild Adaptive122Third117Node0 104
def Adaptive122Third117Node4 : CachedSearchNode := cachedChild Adaptive122Third117Node0 105
def Adaptive122Third117Node5 : CachedSearchNode := cachedChild Adaptive122Third117Node0 106
def Adaptive122Third117Node6 : CachedSearchNode := cachedChild Adaptive122Third117Node0 107
def Adaptive122Third117Node7 : CachedSearchNode := cachedChild Adaptive122Third117Node0 108
def Adaptive122Third117Node8 : CachedSearchNode := cachedChild Adaptive122Third117Node0 109
def Adaptive122Third117Node9 : CachedSearchNode := cachedChild Adaptive122Third117Node0 110
def Adaptive122Third117Node10 : CachedSearchNode := cachedChild Adaptive122Third117Node0 111
def Adaptive122Third117Node11 : CachedSearchNode := cachedChild Adaptive122Third117Node0 112
def Adaptive122Third117Node12 : CachedSearchNode := cachedChild Adaptive122Third117Node0 113
def Adaptive122Third117Node13 : CachedSearchNode := cachedChild Adaptive122Third117Node0 114
def Adaptive122Third117Node14 : CachedSearchNode := cachedChild Adaptive122Third117Node0 115
def Adaptive122Third117Node15 : CachedSearchNode := cachedChild Adaptive122Third117Node0 116

end NineSeparatedSubsetSums
