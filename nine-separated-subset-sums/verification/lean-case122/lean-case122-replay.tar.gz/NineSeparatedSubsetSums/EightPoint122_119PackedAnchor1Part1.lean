import NineSeparatedSubsetSums.EightPoint122_119PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint122_119PackedAnchor1Part1 :
    ∀ j : Fin 116, 2179827 ≤ FourPointNumeric.octPackedCharge 122 119 20 packedOct122_119_1
      (2*((j.val : Int)+120)+0) := by decide +kernel

end NineSeparatedSubsetSums
