import NineSeparatedSubsetSums.FourPoint122PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedWeight122_0_budget :
    FourPointNumeric.packedBudget 20 packedWeight122_0 549 = 81624576 := by decide +kernel

#print axioms packedWeight122_0_budget

end NineSeparatedSubsetSums
