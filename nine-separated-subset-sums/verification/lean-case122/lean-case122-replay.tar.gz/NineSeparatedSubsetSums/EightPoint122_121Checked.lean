import NineSeparatedSubsetSums.EightPointPackedGeometry
import NineSeparatedSubsetSums.EightPoint122_121PackedBudget0
import NineSeparatedSubsetSums.EightPoint122_121PackedAnchor0Part0
import NineSeparatedSubsetSums.EightPoint122_121PackedAnchor0Part1
import NineSeparatedSubsetSums.EightPoint122_121PackedBudget1
import NineSeparatedSubsetSums.EightPoint122_121PackedAnchor1Part0
import NineSeparatedSubsetSums.EightPoint122_121PackedAnchor1Part1

namespace NineSeparatedSubsetSums

private theorem packedOct122_121Anchor0 :
  ∀ j : Fin 477, ((j.val : Int)+122+121)%2=0 →
    2230122 ≤ FourPointNumeric.octPackedCharge 122 121 20 packedOct122_121_0 (j.val : Int) := by
  intro j hj
  let k := (j.val-1)/2
  have hk : k < 238 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+1 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint122_121PackedAnchor0Part0 z
    rwa [he,hrep] at ht
  let z : Fin 118 := ⟨k-120, by omega⟩
  have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
  have ht := eightPoint122_121PackedAnchor0Part1 z
  rwa [he,hrep] at ht

private theorem packedOct122_121Anchor1 :
  ∀ j : Fin 477, ((j.val : Int)+122+121)%2=1 →
    2230114 ≤ FourPointNumeric.octPackedCharge 122 121 20 packedOct122_121_1 (j.val : Int) := by
  intro j hj
  let k := (j.val-0)/2
  have hk : k < 239 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+0 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint122_121PackedAnchor1Part0 z
    rwa [he,hrep] at ht
  let z : Fin 119 := ⟨k-120, by omega⟩
  have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
  have ht := eightPoint122_121PackedAnchor1Part1 z
  rwa [he,hrep] at ht

def packedOctCertificate122_121_0 : EightPointCertificate 122 121 0 122376 :=
  eightPointCertificateOfPacked 122 121 0 122376 2230122 20 packedOct122_121_0 395 477
    (by decide +kernel) (by decide) packedOct122_121Anchor0
    (by rw [packedOct122_121_0_budget]; decide)

def packedOctCertificate122_121_1 : EightPointCertificate 122 121 1 122376 :=
  eightPointCertificateOfPacked 122 121 1 122376 2230114 20 packedOct122_121_1 386 477
    (by decide +kernel) (by decide) packedOct122_121Anchor1
    (by rw [packedOct122_121_1_budget]; decide)

theorem max148_second122_third121_eightPoint_moment_bound (tail : List ℕ) (len : tail.length=6)
    (distinct : (natSubsetSums (148::122::121::tail)).Nodup) :
    122376 ≤ ((148::122::121::tail).map (· ^ 2)).sum := by
  apply eightPointNatMomentLower 122 121 122376 tail len distinct
  intro p hp
  by_cases h : p=0
  · subst p
    exact packedOctCertificate122_121_0
  · have he : p=1 := hp.resolve_left h
    subst p
    exact packedOctCertificate122_121_1

#print axioms max148_second122_third121_eightPoint_moment_bound

end NineSeparatedSubsetSums
