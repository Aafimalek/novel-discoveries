import NineSeparatedSubsetSums.EightPoint122_121PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct122_121_0_budget :
    FourPointNumeric.packedBudget 20 packedOct122_121_0 395 = 80070831 := by decide +kernel

#print axioms packedOct122_121_0_budget

end NineSeparatedSubsetSums
