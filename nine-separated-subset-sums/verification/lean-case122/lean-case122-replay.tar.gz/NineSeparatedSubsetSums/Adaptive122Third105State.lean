import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive122Third105Node0 : CachedSearchNode :=
  ⟨4, 104, computeCenteredMask [148,122,105], 375, 47813⟩

end NineSeparatedSubsetSums
