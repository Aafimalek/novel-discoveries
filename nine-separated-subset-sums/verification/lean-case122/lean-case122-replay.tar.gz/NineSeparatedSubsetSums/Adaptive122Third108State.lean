import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive122Third108Node0 : CachedSearchNode :=
  ⟨4, 107, computeCenteredMask [148,122,108], 378, 48452⟩

end NineSeparatedSubsetSums
