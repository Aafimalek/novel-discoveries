import NineSeparatedSubsetSums.EightPoint122_120PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct122_120_1_budget :
    FourPointNumeric.packedBudget 20 packedOct122_120_1 372 = 78872004 := by decide +kernel

#print axioms packedOct122_120_1_budget

end NineSeparatedSubsetSums
