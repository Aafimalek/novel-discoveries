import NineSeparatedSubsetSums.EightPointPackedGeometry
import NineSeparatedSubsetSums.EightPoint122_120PackedBudget0
import NineSeparatedSubsetSums.EightPoint122_120PackedAnchor0Part0
import NineSeparatedSubsetSums.EightPoint122_120PackedAnchor0Part1
import NineSeparatedSubsetSums.EightPoint122_120PackedBudget1
import NineSeparatedSubsetSums.EightPoint122_120PackedAnchor1Part0
import NineSeparatedSubsetSums.EightPoint122_120PackedAnchor1Part1

namespace NineSeparatedSubsetSums

private theorem packedOct122_120Anchor0 :
  ∀ j : Fin 479, ((j.val : Int)+122+120)%2=0 →
    2240183 ≤ FourPointNumeric.octPackedCharge 122 120 20 packedOct122_120_0 (j.val : Int) := by
  intro j hj
  let k := (j.val-0)/2
  have hk : k < 240 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+0 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint122_120PackedAnchor0Part0 z
    rwa [he,hrep] at ht
  let z : Fin 120 := ⟨k-120, by omega⟩
  have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
  have ht := eightPoint122_120PackedAnchor0Part1 z
  rwa [he,hrep] at ht

private theorem packedOct122_120Anchor1 :
  ∀ j : Fin 479, ((j.val : Int)+122+120)%2=1 →
    2209918 ≤ FourPointNumeric.octPackedCharge 122 120 20 packedOct122_120_1 (j.val : Int) := by
  intro j hj
  let k := (j.val-1)/2
  have hk : k < 239 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+1 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint122_120PackedAnchor1Part0 z
    rwa [he,hrep] at ht
  let z : Fin 119 := ⟨k-120, by omega⟩
  have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
  have ht := eightPoint122_120PackedAnchor1Part1 z
  rwa [he,hrep] at ht

def packedOctCertificate122_120_0 : EightPointCertificate 122 120 0 122193 :=
  eightPointCertificateOfPacked 122 120 0 122193 2240183 20 packedOct122_120_0 385 479
    (by decide +kernel) (by decide) packedOct122_120Anchor0
    (by rw [packedOct122_120_0_budget]; decide)

def packedOctCertificate122_120_1 : EightPointCertificate 122 120 1 122193 :=
  eightPointCertificateOfPacked 122 120 1 122193 2209918 20 packedOct122_120_1 372 479
    (by decide +kernel) (by decide) packedOct122_120Anchor1
    (by rw [packedOct122_120_1_budget]; decide)

theorem max148_second122_third120_eightPoint_moment_bound (tail : List ℕ) (len : tail.length=6)
    (distinct : (natSubsetSums (148::122::120::tail)).Nodup) :
    122193 ≤ ((148::122::120::tail).map (· ^ 2)).sum := by
  apply eightPointNatMomentLower 122 120 122193 tail len distinct
  intro p hp
  by_cases h : p=0
  · subst p
    exact packedOctCertificate122_120_0
  · have he : p=1 := hp.resolve_left h
    subst p
    exact packedOctCertificate122_120_1

#print axioms max148_second122_third120_eightPoint_moment_bound

end NineSeparatedSubsetSums
