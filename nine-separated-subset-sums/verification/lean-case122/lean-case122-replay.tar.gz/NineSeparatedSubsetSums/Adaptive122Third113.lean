import NineSeparatedSubsetSums.Adaptive122Third113Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint122Checked

namespace NineSeparatedSubsetSums


theorem adaptive122Third113 : NoDescendingTailAfterThird 122 113 :=
  noDescendingThirdTail_of_cached 122 113 109064 (fun t ht nd => max148_second122_fourPoint_moment_bound (113::t) (by simp [ht]) nd) adaptive122Third113Proof0

#print axioms adaptive122Third113

end NineSeparatedSubsetSums
