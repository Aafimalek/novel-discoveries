import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive122Third121Node0 : CachedSearchNode :=
  ⟨4, 120, computeCenteredMask [148,122,121], 391, 51429⟩

end NineSeparatedSubsetSums
