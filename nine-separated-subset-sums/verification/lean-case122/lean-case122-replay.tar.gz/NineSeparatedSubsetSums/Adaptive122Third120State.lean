import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive122Third120Node0 : CachedSearchNode :=
  ⟨4, 119, computeCenteredMask [148,122,120], 390, 51188⟩

end NineSeparatedSubsetSums
