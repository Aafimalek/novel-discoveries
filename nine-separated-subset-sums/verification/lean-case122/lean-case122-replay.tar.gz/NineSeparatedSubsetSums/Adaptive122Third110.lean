import NineSeparatedSubsetSums.Adaptive122Third110Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint122Checked

namespace NineSeparatedSubsetSums


theorem adaptive122Third110 : NoDescendingTailAfterThird 122 110 :=
  noDescendingThirdTail_of_cached 122 110 109064 (fun t ht nd => max148_second122_fourPoint_moment_bound (110::t) (by simp [ht]) nd) adaptive122Third110Proof0

#print axioms adaptive122Third110

end NineSeparatedSubsetSums
