import NineSeparatedSubsetSums.Adaptive122Third107Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint122Checked

namespace NineSeparatedSubsetSums


theorem adaptive122Third107 : NoDescendingTailAfterThird 122 107 :=
  noDescendingThirdTail_of_cached 122 107 109064 (fun t ht nd => max148_second122_fourPoint_moment_bound (107::t) (by simp [ht]) nd) adaptive122Third107Proof0

#print axioms adaptive122Third107

end NineSeparatedSubsetSums
