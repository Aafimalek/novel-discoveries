import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive122Third107Node0 : CachedSearchNode :=
  ⟨4, 106, computeCenteredMask [148,122,107], 377, 48237⟩

end NineSeparatedSubsetSums
