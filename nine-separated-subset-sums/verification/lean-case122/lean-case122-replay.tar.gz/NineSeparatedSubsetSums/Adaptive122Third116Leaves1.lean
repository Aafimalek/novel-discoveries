import NineSeparatedSubsetSums.Adaptive122Third116State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive122Third116Proof9 : runCachedNode 511 109064 Adaptive122Third116Node9 = false := by
  decide +kernel

#print axioms adaptive122Third116Proof9

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive122Third116Proof10 : runCachedNode 511 109064 Adaptive122Third116Node10 = false := by
  decide +kernel

#print axioms adaptive122Third116Proof10

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive122Third116Proof8 : runCachedNode 511 109064 Adaptive122Third116Node8 = false := by
  decide +kernel

#print axioms adaptive122Third116Proof8

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive122Third116Proof7 : runCachedNode 511 109064 Adaptive122Third116Node7 = false := by
  decide +kernel

#print axioms adaptive122Third116Proof7

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive122Third116Proof6 : runCachedNode 511 109064 Adaptive122Third116Node6 = false := by
  decide +kernel

#print axioms adaptive122Third116Proof6

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive122Third116Proof4 : runCachedNode 511 109064 Adaptive122Third116Node4 = false := by
  decide +kernel

#print axioms adaptive122Third116Proof4

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive122Third116Proof3 : runCachedNode 511 109064 Adaptive122Third116Node3 = false := by
  decide +kernel

#print axioms adaptive122Third116Proof3

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive122Third116Proof2 : runCachedNode 511 109064 Adaptive122Third116Node2 = false := by
  decide +kernel

#print axioms adaptive122Third116Proof2

end NineSeparatedSubsetSums
