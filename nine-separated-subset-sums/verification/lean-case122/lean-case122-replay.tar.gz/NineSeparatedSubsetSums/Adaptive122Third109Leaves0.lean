import NineSeparatedSubsetSums.Adaptive122Third109State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive122Third109Proof0 : runCachedNode 511 109064 Adaptive122Third109Node0 = false := by
  decide +kernel

#print axioms adaptive122Third109Proof0

end NineSeparatedSubsetSums
