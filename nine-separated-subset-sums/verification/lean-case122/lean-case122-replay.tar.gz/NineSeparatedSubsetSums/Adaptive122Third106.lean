import NineSeparatedSubsetSums.Adaptive122Third106Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint122Checked

namespace NineSeparatedSubsetSums


theorem adaptive122Third106 : NoDescendingTailAfterThird 122 106 :=
  noDescendingThirdTail_of_cached 122 106 109064 (fun t ht nd => max148_second122_fourPoint_moment_bound (106::t) (by simp [ht]) nd) adaptive122Third106Proof0

#print axioms adaptive122Third106

end NineSeparatedSubsetSums
