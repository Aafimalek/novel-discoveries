import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive122Third109Node0 : CachedSearchNode :=
  ⟨4, 108, computeCenteredMask [148,122,109], 379, 48669⟩

end NineSeparatedSubsetSums
