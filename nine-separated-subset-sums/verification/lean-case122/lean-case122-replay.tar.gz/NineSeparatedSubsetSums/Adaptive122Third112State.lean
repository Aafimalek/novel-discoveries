import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive122Third112Node0 : CachedSearchNode :=
  ⟨4, 111, computeCenteredMask [148,122,112], 382, 49332⟩

end NineSeparatedSubsetSums
