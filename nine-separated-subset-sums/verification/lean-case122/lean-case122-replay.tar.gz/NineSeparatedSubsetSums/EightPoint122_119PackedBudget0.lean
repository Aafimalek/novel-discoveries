import NineSeparatedSubsetSums.EightPoint122_119PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct122_119_0_budget :
    FourPointNumeric.packedBudget 20 packedOct122_119_0 499 = 77044667 := by decide +kernel

#print axioms packedOct122_119_0_budget

end NineSeparatedSubsetSums
