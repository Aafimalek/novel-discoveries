import NineSeparatedSubsetSums.Adaptive122Third106State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive122Third106Proof0 : runCachedNode 511 109064 Adaptive122Third106Node0 = false := by
  decide +kernel

#print axioms adaptive122Third106Proof0

end NineSeparatedSubsetSums
