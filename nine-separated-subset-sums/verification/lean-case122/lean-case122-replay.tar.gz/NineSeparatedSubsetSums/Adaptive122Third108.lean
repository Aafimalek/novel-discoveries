import NineSeparatedSubsetSums.Adaptive122Third108Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint122Checked

namespace NineSeparatedSubsetSums


theorem adaptive122Third108 : NoDescendingTailAfterThird 122 108 :=
  noDescendingThirdTail_of_cached 122 108 109064 (fun t ht nd => max148_second122_fourPoint_moment_bound (108::t) (by simp [ht]) nd) adaptive122Third108Proof0

#print axioms adaptive122Third108

end NineSeparatedSubsetSums
