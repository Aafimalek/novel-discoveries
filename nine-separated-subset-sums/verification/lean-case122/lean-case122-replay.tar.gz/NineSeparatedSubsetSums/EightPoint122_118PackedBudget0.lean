import NineSeparatedSubsetSums.EightPoint122_118PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct122_118_0_budget :
    FourPointNumeric.packedBudget 20 packedOct122_118_0 511 = 77672508 := by decide +kernel

#print axioms packedOct122_118_0_budget

end NineSeparatedSubsetSums
