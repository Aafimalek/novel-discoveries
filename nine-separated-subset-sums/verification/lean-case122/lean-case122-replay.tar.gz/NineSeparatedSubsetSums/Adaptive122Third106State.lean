import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive122Third106Node0 : CachedSearchNode :=
  ⟨4, 105, computeCenteredMask [148,122,106], 376, 48024⟩

end NineSeparatedSubsetSums
