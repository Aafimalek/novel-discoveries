import NineSeparatedSubsetSums.Adaptive122Third118State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive122Third118Proof0 : runCachedNode 511 121968 Adaptive122Third118Node0 = false := by
  decide +kernel

#print axioms adaptive122Third118Proof0

end NineSeparatedSubsetSums
