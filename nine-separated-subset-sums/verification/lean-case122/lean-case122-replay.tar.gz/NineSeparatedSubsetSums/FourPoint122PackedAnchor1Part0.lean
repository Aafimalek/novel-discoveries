import NineSeparatedSubsetSums.FourPoint122PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem fourPoint122PackedAnchor1Part0 :
    ∀ j : Fin 120, 1073940 ≤ FourPointNumeric.packedCharge 122 20 packedWeight122_1
      (2*((j.val : Int)+0)+1) := by decide +kernel

end NineSeparatedSubsetSums
