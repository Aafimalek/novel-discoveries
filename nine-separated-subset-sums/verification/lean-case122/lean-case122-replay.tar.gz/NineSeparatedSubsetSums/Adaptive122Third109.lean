import NineSeparatedSubsetSums.Adaptive122Third109Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint122Checked

namespace NineSeparatedSubsetSums


theorem adaptive122Third109 : NoDescendingTailAfterThird 122 109 :=
  noDescendingThirdTail_of_cached 122 109 109064 (fun t ht nd => max148_second122_fourPoint_moment_bound (109::t) (by simp [ht]) nd) adaptive122Third109Proof0

#print axioms adaptive122Third109

end NineSeparatedSubsetSums
