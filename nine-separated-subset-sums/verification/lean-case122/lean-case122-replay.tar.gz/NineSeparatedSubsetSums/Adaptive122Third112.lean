import NineSeparatedSubsetSums.Adaptive122Third112Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint122Checked

namespace NineSeparatedSubsetSums


theorem adaptive122Third112 : NoDescendingTailAfterThird 122 112 :=
  noDescendingThirdTail_of_cached 122 112 109064 (fun t ht nd => max148_second122_fourPoint_moment_bound (112::t) (by simp [ht]) nd) adaptive122Third112Proof0

#print axioms adaptive122Third112

end NineSeparatedSubsetSums
