import NineSeparatedSubsetSums.Adaptive122Third117State
import NineSeparatedSubsetSums.Adaptive122Third117Leaves0
import NineSeparatedSubsetSums.Adaptive122Third117Leaves1

namespace NineSeparatedSubsetSums

theorem adaptive122Third117Proof0 : runCachedNode 511 109064 Adaptive122Third117Node0 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 109064 Adaptive122Third117Node0 = [102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive122Third117Proof1
  · exact adaptive122Third117Proof2
  · exact adaptive122Third117Proof3
  · exact adaptive122Third117Proof4
  · exact adaptive122Third117Proof5
  · exact adaptive122Third117Proof6
  · exact adaptive122Third117Proof7
  · exact adaptive122Third117Proof8
  · exact adaptive122Third117Proof9
  · exact adaptive122Third117Proof10
  · exact adaptive122Third117Proof11
  · exact adaptive122Third117Proof12
  · exact adaptive122Third117Proof13
  · exact adaptive122Third117Proof14
  · exact adaptive122Third117Proof15

#print axioms adaptive122Third117Proof0

end NineSeparatedSubsetSums
