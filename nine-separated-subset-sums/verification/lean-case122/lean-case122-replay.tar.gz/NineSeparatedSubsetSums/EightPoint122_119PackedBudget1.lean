import NineSeparatedSubsetSums.EightPoint122_119PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct122_119_1_budget :
    FourPointNumeric.packedBudget 20 packedOct122_119_1 396 = 77015596 := by decide +kernel

#print axioms packedOct122_119_1_budget

end NineSeparatedSubsetSums
