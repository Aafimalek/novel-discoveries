import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive146Third104Node0 : CachedSearchNode :=
  ⟨4, 103, computeCenteredMask [148,146,104], 398, 54036⟩

end NineSeparatedSubsetSums
