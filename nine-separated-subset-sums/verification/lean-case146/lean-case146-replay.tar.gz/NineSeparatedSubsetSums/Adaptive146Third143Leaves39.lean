import NineSeparatedSubsetSums.Adaptive146Third143State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third143Proof330 : runCachedNode 511 131193 Adaptive146Third143Node330 = false := by
  decide +kernel

#print axioms adaptive146Third143Proof330

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third143Proof497 : runCachedNode 511 131193 Adaptive146Third143Node497 = false := by
  decide +kernel

#print axioms adaptive146Third143Proof497

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third143Proof405 : runCachedNode 511 131193 Adaptive146Third143Node405 = false := by
  decide +kernel

#print axioms adaptive146Third143Proof405

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third143Proof69 : runCachedNode 511 131193 Adaptive146Third143Node69 = false := by
  decide +kernel

#print axioms adaptive146Third143Proof69

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third143Proof222 : runCachedNode 511 131193 Adaptive146Third143Node222 = false := by
  decide +kernel

#print axioms adaptive146Third143Proof222

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third143Proof455 : runCachedNode 511 131193 Adaptive146Third143Node455 = false := by
  decide +kernel

#print axioms adaptive146Third143Proof455

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third143Proof11 : runCachedNode 511 131193 Adaptive146Third143Node11 = false := by
  decide +kernel

#print axioms adaptive146Third143Proof11

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third143Proof381 : runCachedNode 511 131193 Adaptive146Third143Node381 = false := by
  decide +kernel

#print axioms adaptive146Third143Proof381

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third143Proof404 : runCachedNode 511 131193 Adaptive146Third143Node404 = false := by
  decide +kernel

#print axioms adaptive146Third143Proof404

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third143Proof251 : runCachedNode 511 131193 Adaptive146Third143Node251 = false := by
  decide +kernel

#print axioms adaptive146Third143Proof251

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third143Proof156 : runCachedNode 511 131193 Adaptive146Third143Node156 = false := by
  decide +kernel

#print axioms adaptive146Third143Proof156

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third143Proof221 : runCachedNode 511 131193 Adaptive146Third143Node221 = false := by
  decide +kernel

#print axioms adaptive146Third143Proof221

end NineSeparatedSubsetSums
