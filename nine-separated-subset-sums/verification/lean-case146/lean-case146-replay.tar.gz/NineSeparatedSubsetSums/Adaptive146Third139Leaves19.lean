import NineSeparatedSubsetSums.Adaptive146Third139State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third139Proof10 : runCachedNode 511 130638 Adaptive146Third139Node10 = false := by
  decide +kernel

#print axioms adaptive146Third139Proof10

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third139Proof87 : runCachedNode 511 130638 Adaptive146Third139Node87 = false := by
  decide +kernel

#print axioms adaptive146Third139Proof87

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third139Proof40 : runCachedNode 511 130638 Adaptive146Third139Node40 = false := by
  decide +kernel

#print axioms adaptive146Third139Proof40

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third139Proof89 : runCachedNode 511 130638 Adaptive146Third139Node89 = false := by
  decide +kernel

#print axioms adaptive146Third139Proof89

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third139Proof144 : runCachedNode 511 130638 Adaptive146Third139Node144 = false := by
  decide +kernel

#print axioms adaptive146Third139Proof144

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third139Proof207 : runCachedNode 511 130638 Adaptive146Third139Node207 = false := by
  decide +kernel

#print axioms adaptive146Third139Proof207

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third139Proof118 : runCachedNode 511 130638 Adaptive146Third139Node118 = false := by
  decide +kernel

#print axioms adaptive146Third139Proof118

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third139Proof38 : runCachedNode 511 130638 Adaptive146Third139Node38 = false := by
  decide +kernel

#print axioms adaptive146Third139Proof38

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third139Proof65 : runCachedNode 511 130638 Adaptive146Third139Node65 = false := by
  decide +kernel

#print axioms adaptive146Third139Proof65

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third139Proof177 : runCachedNode 511 130638 Adaptive146Third139Node177 = false := by
  decide +kernel

#print axioms adaptive146Third139Proof177

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third139Proof175 : runCachedNode 511 130638 Adaptive146Third139Node175 = false := by
  decide +kernel

#print axioms adaptive146Third139Proof175

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third139Proof174 : runCachedNode 511 130638 Adaptive146Third139Node174 = false := by
  decide +kernel

#print axioms adaptive146Third139Proof174

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third139Proof236 : runCachedNode 511 130638 Adaptive146Third139Node236 = false := by
  decide +kernel

#print axioms adaptive146Third139Proof236

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third139Proof9 : runCachedNode 511 130638 Adaptive146Third139Node9 = false := by
  decide +kernel

#print axioms adaptive146Third139Proof9

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third139Proof46 : runCachedNode 511 130638 Adaptive146Third139Node46 = false := by
  decide +kernel

#print axioms adaptive146Third139Proof46

end NineSeparatedSubsetSums
