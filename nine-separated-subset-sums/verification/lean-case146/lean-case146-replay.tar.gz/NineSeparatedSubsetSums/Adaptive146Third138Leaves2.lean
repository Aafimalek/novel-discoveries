import NineSeparatedSubsetSums.Adaptive146Third138State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third138Proof20 : runCachedNode 511 130484 Adaptive146Third138Node20 = false := by
  decide +kernel

#print axioms adaptive146Third138Proof20

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third138Proof43 : runCachedNode 511 130484 Adaptive146Third138Node43 = false := by
  decide +kernel

#print axioms adaptive146Third138Proof43

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third138Proof155 : runCachedNode 511 130484 Adaptive146Third138Node155 = false := by
  decide +kernel

#print axioms adaptive146Third138Proof155

end NineSeparatedSubsetSums
