import NineSeparatedSubsetSums.Adaptive146Third140State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third140Proof241 : runCachedNode 511 130775 Adaptive146Third140Node241 = false := by
  decide +kernel

#print axioms adaptive146Third140Proof241

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third140Proof92 : runCachedNode 511 130775 Adaptive146Third140Node92 = false := by
  decide +kernel

#print axioms adaptive146Third140Proof92

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third140Proof43 : runCachedNode 511 130775 Adaptive146Third140Node43 = false := by
  decide +kernel

#print axioms adaptive146Third140Proof43

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third140Proof69 : runCachedNode 511 130775 Adaptive146Third140Node69 = false := by
  decide +kernel

#print axioms adaptive146Third140Proof69

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third140Proof151 : runCachedNode 511 130775 Adaptive146Third140Node151 = false := by
  decide +kernel

#print axioms adaptive146Third140Proof151

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third140Proof181 : runCachedNode 511 130775 Adaptive146Third140Node181 = false := by
  decide +kernel

#print axioms adaptive146Third140Proof181

end NineSeparatedSubsetSums
