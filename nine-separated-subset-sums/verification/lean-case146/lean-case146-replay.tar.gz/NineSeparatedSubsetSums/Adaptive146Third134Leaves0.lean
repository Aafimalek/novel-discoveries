import NineSeparatedSubsetSums.Adaptive146Third134State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third134Proof45 : runCachedNode 511 129871 Adaptive146Third134Node45 = false := by
  decide +kernel

#print axioms adaptive146Third134Proof45

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third134Proof37 : runCachedNode 511 129871 Adaptive146Third134Node37 = false := by
  decide +kernel

#print axioms adaptive146Third134Proof37

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third134Proof25 : runCachedNode 511 129871 Adaptive146Third134Node25 = false := by
  decide +kernel

#print axioms adaptive146Third134Proof25

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third134Proof47 : runCachedNode 511 129871 Adaptive146Third134Node47 = false := by
  decide +kernel

#print axioms adaptive146Third134Proof47

end NineSeparatedSubsetSums
