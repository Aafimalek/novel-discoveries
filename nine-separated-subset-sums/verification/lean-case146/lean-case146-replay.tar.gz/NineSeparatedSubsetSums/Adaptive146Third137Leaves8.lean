import NineSeparatedSubsetSums.Adaptive146Third137State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third137Proof119 : runCachedNode 511 130354 Adaptive146Third137Node119 = false := by
  decide +kernel

#print axioms adaptive146Third137Proof119

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third137Proof42 : runCachedNode 511 130354 Adaptive146Third137Node42 = false := by
  decide +kernel

#print axioms adaptive146Third137Proof42

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third137Proof151 : runCachedNode 511 130354 Adaptive146Third137Node151 = false := by
  decide +kernel

#print axioms adaptive146Third137Proof151

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third137Proof14 : runCachedNode 511 130354 Adaptive146Third137Node14 = false := by
  decide +kernel

#print axioms adaptive146Third137Proof14

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third137Proof13 : runCachedNode 511 130354 Adaptive146Third137Node13 = false := by
  decide +kernel

#print axioms adaptive146Third137Proof13

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third137Proof57 : runCachedNode 511 130354 Adaptive146Third137Node57 = false := by
  decide +kernel

#print axioms adaptive146Third137Proof57

end NineSeparatedSubsetSums
