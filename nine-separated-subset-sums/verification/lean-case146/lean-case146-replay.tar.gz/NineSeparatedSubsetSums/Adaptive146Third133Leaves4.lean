import NineSeparatedSubsetSums.Adaptive146Third133State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third133Proof13 : runCachedNode 511 129683 Adaptive146Third133Node13 = false := by
  decide +kernel

#print axioms adaptive146Third133Proof13

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third133Proof45 : runCachedNode 511 129683 Adaptive146Third133Node45 = false := by
  decide +kernel

#print axioms adaptive146Third133Proof45

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third133Proof12 : runCachedNode 511 129683 Adaptive146Third133Node12 = false := by
  decide +kernel

#print axioms adaptive146Third133Proof12

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third133Proof43 : runCachedNode 511 129683 Adaptive146Third133Node43 = false := by
  decide +kernel

#print axioms adaptive146Third133Proof43

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third133Proof42 : runCachedNode 511 129683 Adaptive146Third133Node42 = false := by
  decide +kernel

#print axioms adaptive146Third133Proof42

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third133Proof10 : runCachedNode 511 129683 Adaptive146Third133Node10 = false := by
  decide +kernel

#print axioms adaptive146Third133Proof10

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third133Proof9 : runCachedNode 511 129683 Adaptive146Third133Node9 = false := by
  decide +kernel

#print axioms adaptive146Third133Proof9

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third133Proof37 : runCachedNode 511 129683 Adaptive146Third133Node37 = false := by
  decide +kernel

#print axioms adaptive146Third133Proof37

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third133Proof41 : runCachedNode 511 129683 Adaptive146Third133Node41 = false := by
  decide +kernel

#print axioms adaptive146Third133Proof41

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third133Proof39 : runCachedNode 511 129683 Adaptive146Third133Node39 = false := by
  decide +kernel

#print axioms adaptive146Third133Proof39

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third133Proof30 : runCachedNode 511 129683 Adaptive146Third133Node30 = false := by
  decide +kernel

#print axioms adaptive146Third133Proof30

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third133Proof26 : runCachedNode 511 129683 Adaptive146Third133Node26 = false := by
  decide +kernel

#print axioms adaptive146Third133Proof26

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third133Proof25 : runCachedNode 511 129683 Adaptive146Third133Node25 = false := by
  decide +kernel

#print axioms adaptive146Third133Proof25

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third133Proof23 : runCachedNode 511 129683 Adaptive146Third133Node23 = false := by
  decide +kernel

#print axioms adaptive146Third133Proof23

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third133Proof24 : runCachedNode 511 129683 Adaptive146Third133Node24 = false := by
  decide +kernel

#print axioms adaptive146Third133Proof24

end NineSeparatedSubsetSums
