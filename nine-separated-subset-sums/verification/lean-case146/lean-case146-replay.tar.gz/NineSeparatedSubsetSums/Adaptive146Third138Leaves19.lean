import NineSeparatedSubsetSums.Adaptive146Third138State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third138Proof138 : runCachedNode 511 130484 Adaptive146Third138Node138 = false := by
  decide +kernel

#print axioms adaptive146Third138Proof138

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third138Proof82 : runCachedNode 511 130484 Adaptive146Third138Node82 = false := by
  decide +kernel

#print axioms adaptive146Third138Proof82

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third138Proof83 : runCachedNode 511 130484 Adaptive146Third138Node83 = false := by
  decide +kernel

#print axioms adaptive146Third138Proof83

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third138Proof137 : runCachedNode 511 130484 Adaptive146Third138Node137 = false := by
  decide +kernel

#print axioms adaptive146Third138Proof137

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third138Proof168 : runCachedNode 511 130484 Adaptive146Third138Node168 = false := by
  decide +kernel

#print axioms adaptive146Third138Proof168

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third138Proof110 : runCachedNode 511 130484 Adaptive146Third138Node110 = false := by
  decide +kernel

#print axioms adaptive146Third138Proof110

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third138Proof6 : runCachedNode 511 130484 Adaptive146Third138Node6 = false := by
  decide +kernel

#print axioms adaptive146Third138Proof6

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third138Proof167 : runCachedNode 511 130484 Adaptive146Third138Node167 = false := by
  decide +kernel

#print axioms adaptive146Third138Proof167

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third138Proof197 : runCachedNode 511 130484 Adaptive146Third138Node197 = false := by
  decide +kernel

#print axioms adaptive146Third138Proof197

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third138Proof55 : runCachedNode 511 130484 Adaptive146Third138Node55 = false := by
  decide +kernel

#print axioms adaptive146Third138Proof55

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third138Proof81 : runCachedNode 511 130484 Adaptive146Third138Node81 = false := by
  decide +kernel

#print axioms adaptive146Third138Proof81

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third138Proof109 : runCachedNode 511 130484 Adaptive146Third138Node109 = false := by
  decide +kernel

#print axioms adaptive146Third138Proof109

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third138Proof196 : runCachedNode 511 130484 Adaptive146Third138Node196 = false := by
  decide +kernel

#print axioms adaptive146Third138Proof196

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third138Proof28 : runCachedNode 511 130484 Adaptive146Third138Node28 = false := by
  decide +kernel

#print axioms adaptive146Third138Proof28

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third138Proof166 : runCachedNode 511 130484 Adaptive146Third138Node166 = false := by
  decide +kernel

#print axioms adaptive146Third138Proof166

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third138Proof5 : runCachedNode 511 130484 Adaptive146Third138Node5 = false := by
  decide +kernel

#print axioms adaptive146Third138Proof5

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third138Proof54 : runCachedNode 511 130484 Adaptive146Third138Node54 = false := by
  decide +kernel

#print axioms adaptive146Third138Proof54

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third138Proof108 : runCachedNode 511 130484 Adaptive146Third138Node108 = false := by
  decide +kernel

#print axioms adaptive146Third138Proof108

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third138Proof80 : runCachedNode 511 130484 Adaptive146Third138Node80 = false := by
  decide +kernel

#print axioms adaptive146Third138Proof80

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third138Proof195 : runCachedNode 511 130484 Adaptive146Third138Node195 = false := by
  decide +kernel

#print axioms adaptive146Third138Proof195

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third138Proof4 : runCachedNode 511 130484 Adaptive146Third138Node4 = false := by
  decide +kernel

#print axioms adaptive146Third138Proof4

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third138Proof135 : runCachedNode 511 130484 Adaptive146Third138Node135 = false := by
  decide +kernel

#print axioms adaptive146Third138Proof135

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third138Proof27 : runCachedNode 511 130484 Adaptive146Third138Node27 = false := by
  decide +kernel

#print axioms adaptive146Third138Proof27

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third138Proof53 : runCachedNode 511 130484 Adaptive146Third138Node53 = false := by
  decide +kernel

#print axioms adaptive146Third138Proof53

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third138Proof79 : runCachedNode 511 130484 Adaptive146Third138Node79 = false := by
  decide +kernel

#print axioms adaptive146Third138Proof79

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third138Proof165 : runCachedNode 511 130484 Adaptive146Third138Node165 = false := by
  decide +kernel

#print axioms adaptive146Third138Proof165

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third138Proof107 : runCachedNode 511 130484 Adaptive146Third138Node107 = false := by
  decide +kernel

#print axioms adaptive146Third138Proof107

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third138Proof26 : runCachedNode 511 130484 Adaptive146Third138Node26 = false := by
  decide +kernel

#print axioms adaptive146Third138Proof26

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third138Proof194 : runCachedNode 511 130484 Adaptive146Third138Node194 = false := by
  decide +kernel

#print axioms adaptive146Third138Proof194

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third138Proof52 : runCachedNode 511 130484 Adaptive146Third138Node52 = false := by
  decide +kernel

#print axioms adaptive146Third138Proof52

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third138Proof78 : runCachedNode 511 130484 Adaptive146Third138Node78 = false := by
  decide +kernel

#print axioms adaptive146Third138Proof78

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third138Proof164 : runCachedNode 511 130484 Adaptive146Third138Node164 = false := by
  decide +kernel

#print axioms adaptive146Third138Proof164

end NineSeparatedSubsetSums
