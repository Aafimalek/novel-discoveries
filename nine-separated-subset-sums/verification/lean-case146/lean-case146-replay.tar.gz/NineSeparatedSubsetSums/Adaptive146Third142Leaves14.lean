import NineSeparatedSubsetSums.Adaptive146Third142State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third142Proof145 : runCachedNode 511 131054 Adaptive146Third142Node145 = false := by
  decide +kernel

#print axioms adaptive146Third142Proof145

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third142Proof401 : runCachedNode 511 131054 Adaptive146Third142Node401 = false := by
  decide +kernel

#print axioms adaptive146Third142Proof401

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third142Proof386 : runCachedNode 511 131054 Adaptive146Third142Node386 = false := by
  decide +kernel

#print axioms adaptive146Third142Proof386

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third142Proof251 : runCachedNode 511 131054 Adaptive146Third142Node251 = false := by
  decide +kernel

#print axioms adaptive146Third142Proof251

end NineSeparatedSubsetSums
