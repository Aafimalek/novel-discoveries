import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive146Third113Node0 : CachedSearchNode :=
  ⟨4, 112, computeCenteredMask [148,146,113], 407, 55989⟩

end NineSeparatedSubsetSums
