import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive146Third123Node0 : CachedSearchNode :=
  ⟨4, 122, computeCenteredMask [148,146,123], 417, 58349⟩

end NineSeparatedSubsetSums
