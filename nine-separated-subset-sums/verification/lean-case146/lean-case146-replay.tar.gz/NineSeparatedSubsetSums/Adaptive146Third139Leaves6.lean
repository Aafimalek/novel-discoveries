import NineSeparatedSubsetSums.Adaptive146Third139State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third139Proof249 : runCachedNode 511 130638 Adaptive146Third139Node249 = false := by
  decide +kernel

#print axioms adaptive146Third139Proof249

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third139Proof182 : runCachedNode 511 130638 Adaptive146Third139Node182 = false := by
  decide +kernel

#print axioms adaptive146Third139Proof182

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third139Proof102 : runCachedNode 511 130638 Adaptive146Third139Node102 = false := by
  decide +kernel

#print axioms adaptive146Third139Proof102

end NineSeparatedSubsetSums
