import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive146Third105Node0 : CachedSearchNode :=
  ⟨4, 104, computeCenteredMask [148,146,105], 399, 54245⟩

end NineSeparatedSubsetSums
