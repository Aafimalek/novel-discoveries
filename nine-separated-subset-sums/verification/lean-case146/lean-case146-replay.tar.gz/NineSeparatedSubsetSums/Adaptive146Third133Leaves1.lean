import NineSeparatedSubsetSums.Adaptive146Third133State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third133Proof20 : runCachedNode 511 129683 Adaptive146Third133Node20 = false := by
  decide +kernel

#print axioms adaptive146Third133Proof20

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third133Proof14 : runCachedNode 511 129683 Adaptive146Third133Node14 = false := by
  decide +kernel

#print axioms adaptive146Third133Proof14

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third133Proof35 : runCachedNode 511 129683 Adaptive146Third133Node35 = false := by
  decide +kernel

#print axioms adaptive146Third133Proof35

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third133Proof2 : runCachedNode 511 129683 Adaptive146Third133Node2 = false := by
  decide +kernel

#print axioms adaptive146Third133Proof2

end NineSeparatedSubsetSums
