import NineSeparatedSubsetSums.Adaptive146Third143State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third143Proof574 : runCachedNode 511 131193 Adaptive146Third143Node574 = false := by
  decide +kernel

#print axioms adaptive146Third143Proof574

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third143Proof573 : runCachedNode 511 131193 Adaptive146Third143Node573 = false := by
  decide +kernel

#print axioms adaptive146Third143Proof573

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third143Proof625 : runCachedNode 511 131193 Adaptive146Third143Node625 = false := by
  decide +kernel

#print axioms adaptive146Third143Proof625

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third143Proof189 : runCachedNode 511 131193 Adaptive146Third143Node189 = false := by
  decide +kernel

#print axioms adaptive146Third143Proof189

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third143Proof410 : runCachedNode 511 131193 Adaptive146Third143Node410 = false := by
  decide +kernel

#print axioms adaptive146Third143Proof410

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third143Proof95 : runCachedNode 511 131193 Adaptive146Third143Node95 = false := by
  decide +kernel

#print axioms adaptive146Third143Proof95

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third143Proof269 : runCachedNode 511 131193 Adaptive146Third143Node269 = false := by
  decide +kernel

#print axioms adaptive146Third143Proof269

end NineSeparatedSubsetSums
