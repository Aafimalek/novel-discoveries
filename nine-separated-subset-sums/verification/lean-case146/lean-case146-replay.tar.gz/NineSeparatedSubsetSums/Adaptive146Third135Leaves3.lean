import NineSeparatedSubsetSums.Adaptive146Third135State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third135Proof18 : runCachedNode 511 130049 Adaptive146Third135Node18 = false := by
  decide +kernel

#print axioms adaptive146Third135Proof18

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third135Proof16 : runCachedNode 511 130049 Adaptive146Third135Node16 = false := by
  decide +kernel

#print axioms adaptive146Third135Proof16

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third135Proof97 : runCachedNode 511 130049 Adaptive146Third135Node97 = false := by
  decide +kernel

#print axioms adaptive146Third135Proof97

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third135Proof67 : runCachedNode 511 130049 Adaptive146Third135Node67 = false := by
  decide +kernel

#print axioms adaptive146Third135Proof67

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third135Proof1 : runCachedNode 511 130049 Adaptive146Third135Node1 = false := by
  decide +kernel

#print axioms adaptive146Third135Proof1

end NineSeparatedSubsetSums
