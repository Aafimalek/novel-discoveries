import NineSeparatedSubsetSums.Adaptive146Third139State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third139Proof176 : runCachedNode 511 130638 Adaptive146Third139Node176 = false := by
  decide +kernel

#print axioms adaptive146Third139Proof176

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third139Proof209 : runCachedNode 511 130638 Adaptive146Third139Node209 = false := by
  decide +kernel

#print axioms adaptive146Third139Proof209

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third139Proof90 : runCachedNode 511 130638 Adaptive146Third139Node90 = false := by
  decide +kernel

#print axioms adaptive146Third139Proof90

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third139Proof179 : runCachedNode 511 130638 Adaptive146Third139Node179 = false := by
  decide +kernel

#print axioms adaptive146Third139Proof179

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third139Proof68 : runCachedNode 511 130638 Adaptive146Third139Node68 = false := by
  decide +kernel

#print axioms adaptive146Third139Proof68

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third139Proof241 : runCachedNode 511 130638 Adaptive146Third139Node241 = false := by
  decide +kernel

#print axioms adaptive146Third139Proof241

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third139Proof11 : runCachedNode 511 130638 Adaptive146Third139Node11 = false := by
  decide +kernel

#print axioms adaptive146Third139Proof11

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third139Proof146 : runCachedNode 511 130638 Adaptive146Third139Node146 = false := by
  decide +kernel

#print axioms adaptive146Third139Proof146

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third139Proof67 : runCachedNode 511 130638 Adaptive146Third139Node67 = false := by
  decide +kernel

#print axioms adaptive146Third139Proof67

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third139Proof77 : runCachedNode 511 130638 Adaptive146Third139Node77 = false := by
  decide +kernel

#print axioms adaptive146Third139Proof77

end NineSeparatedSubsetSums
