import NineSeparatedSubsetSums.Adaptive146Third144State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third144Proof601 : runCachedNode 511 131319 Adaptive146Third144Node601 = false := by
  decide +kernel

#print axioms adaptive146Third144Proof601

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third144Proof1098 : runCachedNode 511 131319 Adaptive146Third144Node1098 = false := by
  decide +kernel

#print axioms adaptive146Third144Proof1098

end NineSeparatedSubsetSums
