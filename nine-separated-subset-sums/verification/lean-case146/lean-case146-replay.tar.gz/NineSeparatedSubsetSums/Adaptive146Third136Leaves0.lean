import NineSeparatedSubsetSums.Adaptive146Third136State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third136Proof21 : runCachedNode 511 130191 Adaptive146Third136Node21 = false := by
  decide +kernel

#print axioms adaptive146Third136Proof21

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third136Proof121 : runCachedNode 511 130191 Adaptive146Third136Node121 = false := by
  decide +kernel

#print axioms adaptive146Third136Proof121

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third136Proof78 : runCachedNode 511 130191 Adaptive146Third136Node78 = false := by
  decide +kernel

#print axioms adaptive146Third136Proof78

end NineSeparatedSubsetSums
