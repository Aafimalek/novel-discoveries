import NineSeparatedSubsetSums.Adaptive146Third141State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third141Proof225 : runCachedNode 511 130916 Adaptive146Third141Node225 = false := by
  decide +kernel

#print axioms adaptive146Third141Proof225

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third141Proof258 : runCachedNode 511 130916 Adaptive146Third141Node258 = false := by
  decide +kernel

#print axioms adaptive146Third141Proof258

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third141Proof259 : runCachedNode 511 130916 Adaptive146Third141Node259 = false := by
  decide +kernel

#print axioms adaptive146Third141Proof259

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third141Proof128 : runCachedNode 511 130916 Adaptive146Third141Node128 = false := by
  decide +kernel

#print axioms adaptive146Third141Proof128

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third141Proof156 : runCachedNode 511 130916 Adaptive146Third141Node156 = false := by
  decide +kernel

#print axioms adaptive146Third141Proof156

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third141Proof95 : runCachedNode 511 130916 Adaptive146Third141Node95 = false := by
  decide +kernel

#print axioms adaptive146Third141Proof95

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third141Proof129 : runCachedNode 511 130916 Adaptive146Third141Node129 = false := by
  decide +kernel

#print axioms adaptive146Third141Proof129

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third141Proof223 : runCachedNode 511 130916 Adaptive146Third141Node223 = false := by
  decide +kernel

#print axioms adaptive146Third141Proof223

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third141Proof224 : runCachedNode 511 130916 Adaptive146Third141Node224 = false := by
  decide +kernel

#print axioms adaptive146Third141Proof224

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third141Proof67 : runCachedNode 511 130916 Adaptive146Third141Node67 = false := by
  decide +kernel

#print axioms adaptive146Third141Proof67

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third141Proof257 : runCachedNode 511 130916 Adaptive146Third141Node257 = false := by
  decide +kernel

#print axioms adaptive146Third141Proof257

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third141Proof222 : runCachedNode 511 130916 Adaptive146Third141Node222 = false := by
  decide +kernel

#print axioms adaptive146Third141Proof222

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third141Proof68 : runCachedNode 511 130916 Adaptive146Third141Node68 = false := by
  decide +kernel

#print axioms adaptive146Third141Proof68

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third141Proof127 : runCachedNode 511 130916 Adaptive146Third141Node127 = false := by
  decide +kernel

#print axioms adaptive146Third141Proof127

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third141Proof94 : runCachedNode 511 130916 Adaptive146Third141Node94 = false := by
  decide +kernel

#print axioms adaptive146Third141Proof94

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third141Proof155 : runCachedNode 511 130916 Adaptive146Third141Node155 = false := by
  decide +kernel

#print axioms adaptive146Third141Proof155

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third141Proof188 : runCachedNode 511 130916 Adaptive146Third141Node188 = false := by
  decide +kernel

#print axioms adaptive146Third141Proof188

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third141Proof221 : runCachedNode 511 130916 Adaptive146Third141Node221 = false := by
  decide +kernel

#print axioms adaptive146Third141Proof221

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third141Proof256 : runCachedNode 511 130916 Adaptive146Third141Node256 = false := by
  decide +kernel

#print axioms adaptive146Third141Proof256

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third141Proof93 : runCachedNode 511 130916 Adaptive146Third141Node93 = false := by
  decide +kernel

#print axioms adaptive146Third141Proof93

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third141Proof187 : runCachedNode 511 130916 Adaptive146Third141Node187 = false := by
  decide +kernel

#print axioms adaptive146Third141Proof187

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third141Proof153 : runCachedNode 511 130916 Adaptive146Third141Node153 = false := by
  decide +kernel

#print axioms adaptive146Third141Proof153

end NineSeparatedSubsetSums
