import NineSeparatedSubsetSums.Adaptive146Third144State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third144Proof713 : runCachedNode 511 131319 Adaptive146Third144Node713 = false := by
  decide +kernel

#print axioms adaptive146Third144Proof713

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third144Proof940 : runCachedNode 511 131319 Adaptive146Third144Node940 = false := by
  decide +kernel

#print axioms adaptive146Third144Proof940

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third144Proof21 : runCachedNode 511 131319 Adaptive146Third144Node21 = false := by
  decide +kernel

#print axioms adaptive146Third144Proof21

end NineSeparatedSubsetSums
