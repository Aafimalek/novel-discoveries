import NineSeparatedSubsetSums.Adaptive146Third137State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third137Proof183 : runCachedNode 511 130354 Adaptive146Third137Node183 = false := by
  decide +kernel

#print axioms adaptive146Third137Proof183

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third137Proof179 : runCachedNode 511 130354 Adaptive146Third137Node179 = false := by
  decide +kernel

#print axioms adaptive146Third137Proof179

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third137Proof15 : runCachedNode 511 130354 Adaptive146Third137Node15 = false := by
  decide +kernel

#print axioms adaptive146Third137Proof15

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third137Proof77 : runCachedNode 511 130354 Adaptive146Third137Node77 = false := by
  decide +kernel

#print axioms adaptive146Third137Proof77

end NineSeparatedSubsetSums
