import NineSeparatedSubsetSums.Adaptive146Third143State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third143Proof260 : runCachedNode 511 131193 Adaptive146Third143Node260 = false := by
  decide +kernel

#print axioms adaptive146Third143Proof260

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third143Proof338 : runCachedNode 511 131193 Adaptive146Third143Node338 = false := by
  decide +kernel

#print axioms adaptive146Third143Proof338

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third143Proof146 : runCachedNode 511 131193 Adaptive146Third143Node146 = false := by
  decide +kernel

#print axioms adaptive146Third143Proof146

end NineSeparatedSubsetSums
