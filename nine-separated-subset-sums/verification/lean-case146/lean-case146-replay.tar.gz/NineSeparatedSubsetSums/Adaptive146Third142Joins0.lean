import NineSeparatedSubsetSums.Adaptive146Third142State
import NineSeparatedSubsetSums.Adaptive146Third142Leaves29
import NineSeparatedSubsetSums.Adaptive146Third142Leaves40
import NineSeparatedSubsetSums.Adaptive146Third142Leaves3
import NineSeparatedSubsetSums.Adaptive146Third142Leaves39
import NineSeparatedSubsetSums.Adaptive146Third142Leaves38
import NineSeparatedSubsetSums.Adaptive146Third142Leaves5
import NineSeparatedSubsetSums.Adaptive146Third142Leaves7
import NineSeparatedSubsetSums.Adaptive146Third142Leaves37
import NineSeparatedSubsetSums.Adaptive146Third142Leaves36
import NineSeparatedSubsetSums.Adaptive146Third142Leaves35
import NineSeparatedSubsetSums.Adaptive146Third142Leaves34
import NineSeparatedSubsetSums.Adaptive146Third142Leaves32
import NineSeparatedSubsetSums.Adaptive146Third142Leaves33
import NineSeparatedSubsetSums.Adaptive146Third142Leaves31
import NineSeparatedSubsetSums.Adaptive146Third142Leaves30
import NineSeparatedSubsetSums.Adaptive146Third142Leaves26
import NineSeparatedSubsetSums.Adaptive146Third142Leaves27
import NineSeparatedSubsetSums.Adaptive146Third142Leaves25
import NineSeparatedSubsetSums.Adaptive146Third142Leaves8
import NineSeparatedSubsetSums.Adaptive146Third142Leaves4
import NineSeparatedSubsetSums.Adaptive146Third142Leaves23
import NineSeparatedSubsetSums.Adaptive146Third142Leaves21
import NineSeparatedSubsetSums.Adaptive146Third142Leaves16
import NineSeparatedSubsetSums.Adaptive146Third142Leaves28
import NineSeparatedSubsetSums.Adaptive146Third142Leaves22
import NineSeparatedSubsetSums.Adaptive146Third142Leaves24
import NineSeparatedSubsetSums.Adaptive146Third142Leaves17
import NineSeparatedSubsetSums.Adaptive146Third142Leaves11
import NineSeparatedSubsetSums.Adaptive146Third142Leaves6
import NineSeparatedSubsetSums.Adaptive146Third142Leaves19
import NineSeparatedSubsetSums.Adaptive146Third142Leaves13
import NineSeparatedSubsetSums.Adaptive146Third142Leaves14
import NineSeparatedSubsetSums.Adaptive146Third142Leaves41
import NineSeparatedSubsetSums.Adaptive146Third142Leaves10
import NineSeparatedSubsetSums.Adaptive146Third142Leaves2
import NineSeparatedSubsetSums.Adaptive146Third142Leaves20
import NineSeparatedSubsetSums.Adaptive146Third142Leaves9
import NineSeparatedSubsetSums.Adaptive146Third142Leaves12
import NineSeparatedSubsetSums.Adaptive146Third142Leaves18
import NineSeparatedSubsetSums.Adaptive146Third142Leaves0
import NineSeparatedSubsetSums.Adaptive146Third142Leaves15

namespace NineSeparatedSubsetSums

theorem adaptive146Third142Proof25 : runCachedNode 511 131054 Adaptive146Third142Node25 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 131054 Adaptive146Third142Node25 = [102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 128, 130, 132] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive146Third142Proof26
  · exact adaptive146Third142Proof27
  · exact adaptive146Third142Proof28
  · exact adaptive146Third142Proof29
  · exact adaptive146Third142Proof30
  · exact adaptive146Third142Proof31
  · exact adaptive146Third142Proof32
  · exact adaptive146Third142Proof33
  · exact adaptive146Third142Proof34
  · exact adaptive146Third142Proof35
  · exact adaptive146Third142Proof36
  · exact adaptive146Third142Proof37
  · exact adaptive146Third142Proof38
  · exact adaptive146Third142Proof39
  · exact adaptive146Third142Proof40
  · exact adaptive146Third142Proof41
  · exact adaptive146Third142Proof42
  · exact adaptive146Third142Proof43
  · exact adaptive146Third142Proof44
  · exact adaptive146Third142Proof45
  · exact adaptive146Third142Proof46
  · exact adaptive146Third142Proof47
  · exact adaptive146Third142Proof48
  · exact adaptive146Third142Proof49
  · exact adaptive146Third142Proof50
  · exact adaptive146Third142Proof51
  · exact adaptive146Third142Proof52
  · exact adaptive146Third142Proof53

#print axioms adaptive146Third142Proof25

theorem adaptive146Third142Proof54 : runCachedNode 511 131054 Adaptive146Third142Node54 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 131054 Adaptive146Third142Node54 = [102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 129, 131, 133] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive146Third142Proof55
  · exact adaptive146Third142Proof56
  · exact adaptive146Third142Proof57
  · exact adaptive146Third142Proof58
  · exact adaptive146Third142Proof59
  · exact adaptive146Third142Proof60
  · exact adaptive146Third142Proof61
  · exact adaptive146Third142Proof62
  · exact adaptive146Third142Proof63
  · exact adaptive146Third142Proof64
  · exact adaptive146Third142Proof65
  · exact adaptive146Third142Proof66
  · exact adaptive146Third142Proof67
  · exact adaptive146Third142Proof68
  · exact adaptive146Third142Proof69
  · exact adaptive146Third142Proof70
  · exact adaptive146Third142Proof71
  · exact adaptive146Third142Proof72
  · exact adaptive146Third142Proof73
  · exact adaptive146Third142Proof74
  · exact adaptive146Third142Proof75
  · exact adaptive146Third142Proof76
  · exact adaptive146Third142Proof77
  · exact adaptive146Third142Proof78
  · exact adaptive146Third142Proof79
  · exact adaptive146Third142Proof80
  · exact adaptive146Third142Proof81
  · exact adaptive146Third142Proof82
  · exact adaptive146Third142Proof83

#print axioms adaptive146Third142Proof54

theorem adaptive146Third142Proof84 : runCachedNode 511 131054 Adaptive146Third142Node84 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 131054 Adaptive146Third142Node84 = [102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 130, 132, 134] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive146Third142Proof85
  · exact adaptive146Third142Proof86
  · exact adaptive146Third142Proof87
  · exact adaptive146Third142Proof88
  · exact adaptive146Third142Proof89
  · exact adaptive146Third142Proof90
  · exact adaptive146Third142Proof91
  · exact adaptive146Third142Proof92
  · exact adaptive146Third142Proof93
  · exact adaptive146Third142Proof94
  · exact adaptive146Third142Proof95
  · exact adaptive146Third142Proof96
  · exact adaptive146Third142Proof97
  · exact adaptive146Third142Proof98
  · exact adaptive146Third142Proof99
  · exact adaptive146Third142Proof100
  · exact adaptive146Third142Proof101
  · exact adaptive146Third142Proof102
  · exact adaptive146Third142Proof103
  · exact adaptive146Third142Proof104
  · exact adaptive146Third142Proof105
  · exact adaptive146Third142Proof106
  · exact adaptive146Third142Proof107
  · exact adaptive146Third142Proof108
  · exact adaptive146Third142Proof109
  · exact adaptive146Third142Proof110
  · exact adaptive146Third142Proof111
  · exact adaptive146Third142Proof112
  · exact adaptive146Third142Proof113
  · exact adaptive146Third142Proof114

#print axioms adaptive146Third142Proof84

theorem adaptive146Third142Proof115 : runCachedNode 511 131054 Adaptive146Third142Node115 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 131054 Adaptive146Third142Node115 = [102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 131, 133, 135] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive146Third142Proof116
  · exact adaptive146Third142Proof117
  · exact adaptive146Third142Proof118
  · exact adaptive146Third142Proof119
  · exact adaptive146Third142Proof120
  · exact adaptive146Third142Proof121
  · exact adaptive146Third142Proof122
  · exact adaptive146Third142Proof123
  · exact adaptive146Third142Proof124
  · exact adaptive146Third142Proof125
  · exact adaptive146Third142Proof126
  · exact adaptive146Third142Proof127
  · exact adaptive146Third142Proof128
  · exact adaptive146Third142Proof129
  · exact adaptive146Third142Proof130
  · exact adaptive146Third142Proof131
  · exact adaptive146Third142Proof132
  · exact adaptive146Third142Proof133
  · exact adaptive146Third142Proof134
  · exact adaptive146Third142Proof135
  · exact adaptive146Third142Proof136
  · exact adaptive146Third142Proof137
  · exact adaptive146Third142Proof138
  · exact adaptive146Third142Proof139
  · exact adaptive146Third142Proof140
  · exact adaptive146Third142Proof141
  · exact adaptive146Third142Proof142
  · exact adaptive146Third142Proof143
  · exact adaptive146Third142Proof144
  · exact adaptive146Third142Proof145
  · exact adaptive146Third142Proof146

#print axioms adaptive146Third142Proof115

theorem adaptive146Third142Proof147 : runCachedNode 511 131054 Adaptive146Third142Node147 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 131054 Adaptive146Third142Node147 = [101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 132, 134, 136] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive146Third142Proof148
  · exact adaptive146Third142Proof149
  · exact adaptive146Third142Proof150
  · exact adaptive146Third142Proof151
  · exact adaptive146Third142Proof152
  · exact adaptive146Third142Proof153
  · exact adaptive146Third142Proof154
  · exact adaptive146Third142Proof155
  · exact adaptive146Third142Proof156
  · exact adaptive146Third142Proof157
  · exact adaptive146Third142Proof158
  · exact adaptive146Third142Proof159
  · exact adaptive146Third142Proof160
  · exact adaptive146Third142Proof161
  · exact adaptive146Third142Proof162
  · exact adaptive146Third142Proof163
  · exact adaptive146Third142Proof164
  · exact adaptive146Third142Proof165
  · exact adaptive146Third142Proof166
  · exact adaptive146Third142Proof167
  · exact adaptive146Third142Proof168
  · exact adaptive146Third142Proof169
  · exact adaptive146Third142Proof170
  · exact adaptive146Third142Proof171
  · exact adaptive146Third142Proof172
  · exact adaptive146Third142Proof173
  · exact adaptive146Third142Proof174
  · exact adaptive146Third142Proof175
  · exact adaptive146Third142Proof176
  · exact adaptive146Third142Proof177
  · exact adaptive146Third142Proof178
  · exact adaptive146Third142Proof179
  · exact adaptive146Third142Proof180

#print axioms adaptive146Third142Proof147

theorem adaptive146Third142Proof211 : runCachedNode 511 131054 Adaptive146Third142Node211 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 131054 Adaptive146Third142Node211 = [91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 117, 118, 119, 121, 123, 125, 127, 129] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive146Third142Proof212
  · exact adaptive146Third142Proof213
  · exact adaptive146Third142Proof214
  · exact adaptive146Third142Proof215
  · exact adaptive146Third142Proof216
  · exact adaptive146Third142Proof217
  · exact adaptive146Third142Proof218
  · exact adaptive146Third142Proof219
  · exact adaptive146Third142Proof220
  · exact adaptive146Third142Proof221
  · exact adaptive146Third142Proof222
  · exact adaptive146Third142Proof223
  · exact adaptive146Third142Proof224
  · exact adaptive146Third142Proof225
  · exact adaptive146Third142Proof226
  · exact adaptive146Third142Proof227
  · exact adaptive146Third142Proof228
  · exact adaptive146Third142Proof229
  · exact adaptive146Third142Proof230
  · exact adaptive146Third142Proof231
  · exact adaptive146Third142Proof232
  · exact adaptive146Third142Proof233
  · exact adaptive146Third142Proof234
  · exact adaptive146Third142Proof235
  · exact adaptive146Third142Proof236
  · exact adaptive146Third142Proof237
  · exact adaptive146Third142Proof238
  · exact adaptive146Third142Proof239
  · exact adaptive146Third142Proof240
  · exact adaptive146Third142Proof241
  · exact adaptive146Third142Proof242
  · exact adaptive146Third142Proof243
  · exact adaptive146Third142Proof244

#print axioms adaptive146Third142Proof211

theorem adaptive146Third142Proof248 : runCachedNode 511 131054 Adaptive146Third142Node248 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 131054 Adaptive146Third142Node248 = [88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 124, 125, 126, 128, 130] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive146Third142Proof249
  · exact adaptive146Third142Proof250
  · exact adaptive146Third142Proof251
  · exact adaptive146Third142Proof252
  · exact adaptive146Third142Proof253
  · exact adaptive146Third142Proof254
  · exact adaptive146Third142Proof255
  · exact adaptive146Third142Proof256
  · exact adaptive146Third142Proof257
  · exact adaptive146Third142Proof258
  · exact adaptive146Third142Proof259
  · exact adaptive146Third142Proof260
  · exact adaptive146Third142Proof261
  · exact adaptive146Third142Proof262
  · exact adaptive146Third142Proof263
  · exact adaptive146Third142Proof264
  · exact adaptive146Third142Proof265
  · exact adaptive146Third142Proof266
  · exact adaptive146Third142Proof267
  · exact adaptive146Third142Proof268
  · exact adaptive146Third142Proof269
  · exact adaptive146Third142Proof270
  · exact adaptive146Third142Proof271
  · exact adaptive146Third142Proof272
  · exact adaptive146Third142Proof273
  · exact adaptive146Third142Proof274
  · exact adaptive146Third142Proof275
  · exact adaptive146Third142Proof276
  · exact adaptive146Third142Proof277
  · exact adaptive146Third142Proof278
  · exact adaptive146Third142Proof279
  · exact adaptive146Third142Proof280
  · exact adaptive146Third142Proof281
  · exact adaptive146Third142Proof282
  · exact adaptive146Third142Proof283
  · exact adaptive146Third142Proof284
  · exact adaptive146Third142Proof285
  · exact adaptive146Third142Proof286
  · exact adaptive146Third142Proof287
  · exact adaptive146Third142Proof288

#print axioms adaptive146Third142Proof248

theorem adaptive146Third142Proof181 : runCachedNode 511 131054 Adaptive146Third142Node181 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 131054 Adaptive146Third142Node181 = [101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 133, 135, 137] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive146Third142Proof182
  · exact adaptive146Third142Proof183
  · exact adaptive146Third142Proof184
  · exact adaptive146Third142Proof185
  · exact adaptive146Third142Proof186
  · exact adaptive146Third142Proof187
  · exact adaptive146Third142Proof188
  · exact adaptive146Third142Proof189
  · exact adaptive146Third142Proof190
  · exact adaptive146Third142Proof191
  · exact adaptive146Third142Proof192
  · exact adaptive146Third142Proof193
  · exact adaptive146Third142Proof194
  · exact adaptive146Third142Proof195
  · exact adaptive146Third142Proof196
  · exact adaptive146Third142Proof197
  · exact adaptive146Third142Proof198
  · exact adaptive146Third142Proof199
  · exact adaptive146Third142Proof200
  · exact adaptive146Third142Proof201
  · exact adaptive146Third142Proof202
  · exact adaptive146Third142Proof203
  · exact adaptive146Third142Proof204
  · exact adaptive146Third142Proof205
  · exact adaptive146Third142Proof206
  · exact adaptive146Third142Proof207
  · exact adaptive146Third142Proof208
  · exact adaptive146Third142Proof209
  · exact adaptive146Third142Proof210
  · exact adaptive146Third142Proof211
  · exact adaptive146Third142Proof245
  · exact adaptive146Third142Proof246
  · exact adaptive146Third142Proof247
  · exact adaptive146Third142Proof248

#print axioms adaptive146Third142Proof181

end NineSeparatedSubsetSums
