import NineSeparatedSubsetSums.Adaptive146Third144State
import NineSeparatedSubsetSums.Adaptive146Third144Leaves31
import NineSeparatedSubsetSums.Adaptive146Third144Leaves34
import NineSeparatedSubsetSums.Adaptive146Third144Leaves16
import NineSeparatedSubsetSums.Adaptive146Third144Leaves22
import NineSeparatedSubsetSums.Adaptive146Third144Leaves94
import NineSeparatedSubsetSums.Adaptive146Third144Leaves119
import NineSeparatedSubsetSums.Adaptive146Third144Leaves116
import NineSeparatedSubsetSums.Adaptive146Third144Leaves112
import NineSeparatedSubsetSums.Adaptive146Third144Leaves86
import NineSeparatedSubsetSums.Adaptive146Third144Leaves108
import NineSeparatedSubsetSums.Adaptive146Third144Leaves70
import NineSeparatedSubsetSums.Adaptive146Third144Leaves110
import NineSeparatedSubsetSums.Adaptive146Third144Leaves107
import NineSeparatedSubsetSums.Adaptive146Third144Leaves60
import NineSeparatedSubsetSums.Adaptive146Third144Leaves103
import NineSeparatedSubsetSums.Adaptive146Third144Leaves89
import NineSeparatedSubsetSums.Adaptive146Third144Leaves96
import NineSeparatedSubsetSums.Adaptive146Third144Leaves88
import NineSeparatedSubsetSums.Adaptive146Third144Leaves80
import NineSeparatedSubsetSums.Adaptive146Third144Leaves51
import NineSeparatedSubsetSums.Adaptive146Third144Leaves24
import NineSeparatedSubsetSums.Adaptive146Third144Leaves50
import NineSeparatedSubsetSums.Adaptive146Third144Leaves27
import NineSeparatedSubsetSums.Adaptive146Third144Leaves121
import NineSeparatedSubsetSums.Adaptive146Third144Leaves118
import NineSeparatedSubsetSums.Adaptive146Third144Leaves114
import NineSeparatedSubsetSums.Adaptive146Third144Leaves109
import NineSeparatedSubsetSums.Adaptive146Third144Leaves97
import NineSeparatedSubsetSums.Adaptive146Third144Leaves102
import NineSeparatedSubsetSums.Adaptive146Third144Leaves101
import NineSeparatedSubsetSums.Adaptive146Third144Leaves82
import NineSeparatedSubsetSums.Adaptive146Third144Leaves73
import NineSeparatedSubsetSums.Adaptive146Third144Leaves52
import NineSeparatedSubsetSums.Adaptive146Third144Leaves54
import NineSeparatedSubsetSums.Adaptive146Third144Leaves29
import NineSeparatedSubsetSums.Adaptive146Third144Leaves55
import NineSeparatedSubsetSums.Adaptive146Third144Leaves37
import NineSeparatedSubsetSums.Adaptive146Third144Leaves111
import NineSeparatedSubsetSums.Adaptive146Third144Leaves106
import NineSeparatedSubsetSums.Adaptive146Third144Leaves95
import NineSeparatedSubsetSums.Adaptive146Third144Leaves45
import NineSeparatedSubsetSums.Adaptive146Third144Leaves71
import NineSeparatedSubsetSums.Adaptive146Third144Leaves84
import NineSeparatedSubsetSums.Adaptive146Third144Leaves76
import NineSeparatedSubsetSums.Adaptive146Third144Leaves18
import NineSeparatedSubsetSums.Adaptive146Third144Leaves66
import NineSeparatedSubsetSums.Adaptive146Third144Leaves40
import NineSeparatedSubsetSums.Adaptive146Third144Leaves28
import NineSeparatedSubsetSums.Adaptive146Third144Leaves23
import NineSeparatedSubsetSums.Adaptive146Third144Leaves113
import NineSeparatedSubsetSums.Adaptive146Third144Leaves104
import NineSeparatedSubsetSums.Adaptive146Third144Leaves79
import NineSeparatedSubsetSums.Adaptive146Third144Leaves91
import NineSeparatedSubsetSums.Adaptive146Third144Leaves75
import NineSeparatedSubsetSums.Adaptive146Third144Leaves64
import NineSeparatedSubsetSums.Adaptive146Third144Leaves130
import NineSeparatedSubsetSums.Adaptive146Third144Leaves42
import NineSeparatedSubsetSums.Adaptive146Third144Leaves124
import NineSeparatedSubsetSums.Adaptive146Third144Leaves122
import NineSeparatedSubsetSums.Adaptive146Third144Leaves120
import NineSeparatedSubsetSums.Adaptive146Third144Leaves117
import NineSeparatedSubsetSums.Adaptive146Third144Leaves78
import NineSeparatedSubsetSums.Adaptive146Third144Leaves92
import NineSeparatedSubsetSums.Adaptive146Third144Leaves90
import NineSeparatedSubsetSums.Adaptive146Third144Leaves6
import NineSeparatedSubsetSums.Adaptive146Third144Leaves11
import NineSeparatedSubsetSums.Adaptive146Third144Leaves17
import NineSeparatedSubsetSums.Adaptive146Third144Leaves67
import NineSeparatedSubsetSums.Adaptive146Third144Leaves57
import NineSeparatedSubsetSums.Adaptive146Third144Leaves44
import NineSeparatedSubsetSums.Adaptive146Third144Leaves115
import NineSeparatedSubsetSums.Adaptive146Third144Leaves100
import NineSeparatedSubsetSums.Adaptive146Third144Leaves93
import NineSeparatedSubsetSums.Adaptive146Third144Leaves83
import NineSeparatedSubsetSums.Adaptive146Third144Leaves77
import NineSeparatedSubsetSums.Adaptive146Third144Leaves65
import NineSeparatedSubsetSums.Adaptive146Third144Leaves72
import NineSeparatedSubsetSums.Adaptive146Third144Leaves61
import NineSeparatedSubsetSums.Adaptive146Third144Leaves32
import NineSeparatedSubsetSums.Adaptive146Third144Leaves128
import NineSeparatedSubsetSums.Adaptive146Third144Leaves126
import NineSeparatedSubsetSums.Adaptive146Third144Leaves123
import NineSeparatedSubsetSums.Adaptive146Third144Leaves105
import NineSeparatedSubsetSums.Adaptive146Third144Leaves85
import NineSeparatedSubsetSums.Adaptive146Third144Leaves8
import NineSeparatedSubsetSums.Adaptive146Third144Leaves21
import NineSeparatedSubsetSums.Adaptive146Third144Leaves53
import NineSeparatedSubsetSums.Adaptive146Third144Leaves39
import NineSeparatedSubsetSums.Adaptive146Third144Leaves129
import NineSeparatedSubsetSums.Adaptive146Third144Leaves38
import NineSeparatedSubsetSums.Adaptive146Third144Leaves14
import NineSeparatedSubsetSums.Adaptive146Third144Leaves58
import NineSeparatedSubsetSums.Adaptive146Third144Leaves19
import NineSeparatedSubsetSums.Adaptive146Third144Leaves30

namespace NineSeparatedSubsetSums

theorem adaptive146Third144Proof18 : runCachedNode 511 131319 Adaptive146Third144Node18 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 131319 Adaptive146Third144Node18 = [104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 123, 125] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive146Third144Proof19
  · exact adaptive146Third144Proof20
  · exact adaptive146Third144Proof21
  · exact adaptive146Third144Proof22
  · exact adaptive146Third144Proof23
  · exact adaptive146Third144Proof24
  · exact adaptive146Third144Proof25
  · exact adaptive146Third144Proof26
  · exact adaptive146Third144Proof27
  · exact adaptive146Third144Proof28
  · exact adaptive146Third144Proof29
  · exact adaptive146Third144Proof30
  · exact adaptive146Third144Proof31
  · exact adaptive146Third144Proof32
  · exact adaptive146Third144Proof33
  · exact adaptive146Third144Proof34
  · exact adaptive146Third144Proof35
  · exact adaptive146Third144Proof36
  · exact adaptive146Third144Proof37
  · exact adaptive146Third144Proof38

#print axioms adaptive146Third144Proof18

theorem adaptive146Third144Proof39 : runCachedNode 511 131319 Adaptive146Third144Node39 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 131319 Adaptive146Third144Node39 = [104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 124, 126] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive146Third144Proof40
  · exact adaptive146Third144Proof41
  · exact adaptive146Third144Proof42
  · exact adaptive146Third144Proof43
  · exact adaptive146Third144Proof44
  · exact adaptive146Third144Proof45
  · exact adaptive146Third144Proof46
  · exact adaptive146Third144Proof47
  · exact adaptive146Third144Proof48
  · exact adaptive146Third144Proof49
  · exact adaptive146Third144Proof50
  · exact adaptive146Third144Proof51
  · exact adaptive146Third144Proof52
  · exact adaptive146Third144Proof53
  · exact adaptive146Third144Proof54
  · exact adaptive146Third144Proof55
  · exact adaptive146Third144Proof56
  · exact adaptive146Third144Proof57
  · exact adaptive146Third144Proof58
  · exact adaptive146Third144Proof59
  · exact adaptive146Third144Proof60

#print axioms adaptive146Third144Proof39

theorem adaptive146Third144Proof61 : runCachedNode 511 131319 Adaptive146Third144Node61 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 131319 Adaptive146Third144Node61 = [103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 125, 127] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive146Third144Proof62
  · exact adaptive146Third144Proof63
  · exact adaptive146Third144Proof64
  · exact adaptive146Third144Proof65
  · exact adaptive146Third144Proof66
  · exact adaptive146Third144Proof67
  · exact adaptive146Third144Proof68
  · exact adaptive146Third144Proof69
  · exact adaptive146Third144Proof70
  · exact adaptive146Third144Proof71
  · exact adaptive146Third144Proof72
  · exact adaptive146Third144Proof73
  · exact adaptive146Third144Proof74
  · exact adaptive146Third144Proof75
  · exact adaptive146Third144Proof76
  · exact adaptive146Third144Proof77
  · exact adaptive146Third144Proof78
  · exact adaptive146Third144Proof79
  · exact adaptive146Third144Proof80
  · exact adaptive146Third144Proof81
  · exact adaptive146Third144Proof82
  · exact adaptive146Third144Proof83
  · exact adaptive146Third144Proof84

#print axioms adaptive146Third144Proof61

theorem adaptive146Third144Proof85 : runCachedNode 511 131319 Adaptive146Third144Node85 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 131319 Adaptive146Third144Node85 = [103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 126, 128] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive146Third144Proof86
  · exact adaptive146Third144Proof87
  · exact adaptive146Third144Proof88
  · exact adaptive146Third144Proof89
  · exact adaptive146Third144Proof90
  · exact adaptive146Third144Proof91
  · exact adaptive146Third144Proof92
  · exact adaptive146Third144Proof93
  · exact adaptive146Third144Proof94
  · exact adaptive146Third144Proof95
  · exact adaptive146Third144Proof96
  · exact adaptive146Third144Proof97
  · exact adaptive146Third144Proof98
  · exact adaptive146Third144Proof99
  · exact adaptive146Third144Proof100
  · exact adaptive146Third144Proof101
  · exact adaptive146Third144Proof102
  · exact adaptive146Third144Proof103
  · exact adaptive146Third144Proof104
  · exact adaptive146Third144Proof105
  · exact adaptive146Third144Proof106
  · exact adaptive146Third144Proof107
  · exact adaptive146Third144Proof108
  · exact adaptive146Third144Proof109

#print axioms adaptive146Third144Proof85

theorem adaptive146Third144Proof110 : runCachedNode 511 131319 Adaptive146Third144Node110 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 131319 Adaptive146Third144Node110 = [103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 127, 129] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive146Third144Proof111
  · exact adaptive146Third144Proof112
  · exact adaptive146Third144Proof113
  · exact adaptive146Third144Proof114
  · exact adaptive146Third144Proof115
  · exact adaptive146Third144Proof116
  · exact adaptive146Third144Proof117
  · exact adaptive146Third144Proof118
  · exact adaptive146Third144Proof119
  · exact adaptive146Third144Proof120
  · exact adaptive146Third144Proof121
  · exact adaptive146Third144Proof122
  · exact adaptive146Third144Proof123
  · exact adaptive146Third144Proof124
  · exact adaptive146Third144Proof125
  · exact adaptive146Third144Proof126
  · exact adaptive146Third144Proof127
  · exact adaptive146Third144Proof128
  · exact adaptive146Third144Proof129
  · exact adaptive146Third144Proof130
  · exact adaptive146Third144Proof131
  · exact adaptive146Third144Proof132
  · exact adaptive146Third144Proof133
  · exact adaptive146Third144Proof134
  · exact adaptive146Third144Proof135

#print axioms adaptive146Third144Proof110

theorem adaptive146Third144Proof136 : runCachedNode 511 131319 Adaptive146Third144Node136 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 131319 Adaptive146Third144Node136 = [103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 128, 130] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive146Third144Proof137
  · exact adaptive146Third144Proof138
  · exact adaptive146Third144Proof139
  · exact adaptive146Third144Proof140
  · exact adaptive146Third144Proof141
  · exact adaptive146Third144Proof142
  · exact adaptive146Third144Proof143
  · exact adaptive146Third144Proof144
  · exact adaptive146Third144Proof145
  · exact adaptive146Third144Proof146
  · exact adaptive146Third144Proof147
  · exact adaptive146Third144Proof148
  · exact adaptive146Third144Proof149
  · exact adaptive146Third144Proof150
  · exact adaptive146Third144Proof151
  · exact adaptive146Third144Proof152
  · exact adaptive146Third144Proof153
  · exact adaptive146Third144Proof154
  · exact adaptive146Third144Proof155
  · exact adaptive146Third144Proof156
  · exact adaptive146Third144Proof157
  · exact adaptive146Third144Proof158
  · exact adaptive146Third144Proof159
  · exact adaptive146Third144Proof160
  · exact adaptive146Third144Proof161
  · exact adaptive146Third144Proof162

#print axioms adaptive146Third144Proof136

theorem adaptive146Third144Proof163 : runCachedNode 511 131319 Adaptive146Third144Node163 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 131319 Adaptive146Third144Node163 = [102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 129, 131] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive146Third144Proof164
  · exact adaptive146Third144Proof165
  · exact adaptive146Third144Proof166
  · exact adaptive146Third144Proof167
  · exact adaptive146Third144Proof168
  · exact adaptive146Third144Proof169
  · exact adaptive146Third144Proof170
  · exact adaptive146Third144Proof171
  · exact adaptive146Third144Proof172
  · exact adaptive146Third144Proof173
  · exact adaptive146Third144Proof174
  · exact adaptive146Third144Proof175
  · exact adaptive146Third144Proof176
  · exact adaptive146Third144Proof177
  · exact adaptive146Third144Proof178
  · exact adaptive146Third144Proof179
  · exact adaptive146Third144Proof180
  · exact adaptive146Third144Proof181
  · exact adaptive146Third144Proof182
  · exact adaptive146Third144Proof183
  · exact adaptive146Third144Proof184
  · exact adaptive146Third144Proof185
  · exact adaptive146Third144Proof186
  · exact adaptive146Third144Proof187
  · exact adaptive146Third144Proof188
  · exact adaptive146Third144Proof189
  · exact adaptive146Third144Proof190
  · exact adaptive146Third144Proof191

#print axioms adaptive146Third144Proof163

theorem adaptive146Third144Proof192 : runCachedNode 511 131319 Adaptive146Third144Node192 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 131319 Adaptive146Third144Node192 = [102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 130, 132] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive146Third144Proof193
  · exact adaptive146Third144Proof194
  · exact adaptive146Third144Proof195
  · exact adaptive146Third144Proof196
  · exact adaptive146Third144Proof197
  · exact adaptive146Third144Proof198
  · exact adaptive146Third144Proof199
  · exact adaptive146Third144Proof200
  · exact adaptive146Third144Proof201
  · exact adaptive146Third144Proof202
  · exact adaptive146Third144Proof203
  · exact adaptive146Third144Proof204
  · exact adaptive146Third144Proof205
  · exact adaptive146Third144Proof206
  · exact adaptive146Third144Proof207
  · exact adaptive146Third144Proof208
  · exact adaptive146Third144Proof209
  · exact adaptive146Third144Proof210
  · exact adaptive146Third144Proof211
  · exact adaptive146Third144Proof212
  · exact adaptive146Third144Proof213
  · exact adaptive146Third144Proof214
  · exact adaptive146Third144Proof215
  · exact adaptive146Third144Proof216
  · exact adaptive146Third144Proof217
  · exact adaptive146Third144Proof218
  · exact adaptive146Third144Proof219
  · exact adaptive146Third144Proof220
  · exact adaptive146Third144Proof221

#print axioms adaptive146Third144Proof192

end NineSeparatedSubsetSums
