import NineSeparatedSubsetSums.Adaptive146Third141State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third141Proof273 : runCachedNode 511 130916 Adaptive146Third141Node273 = false := by
  decide +kernel

#print axioms adaptive146Third141Proof273

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third141Proof98 : runCachedNode 511 130916 Adaptive146Third141Node98 = false := by
  decide +kernel

#print axioms adaptive146Third141Proof98

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third141Proof1 : runCachedNode 511 130916 Adaptive146Third141Node1 = false := by
  decide +kernel

#print axioms adaptive146Third141Proof1

end NineSeparatedSubsetSums
