import NineSeparatedSubsetSums.Adaptive146Third142State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third142Proof439 : runCachedNode 511 131054 Adaptive146Third142Node439 = false := by
  decide +kernel

#print axioms adaptive146Third142Proof439

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third142Proof47 : runCachedNode 511 131054 Adaptive146Third142Node47 = false := by
  decide +kernel

#print axioms adaptive146Third142Proof47

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third142Proof135 : runCachedNode 511 131054 Adaptive146Third142Node135 = false := by
  decide +kernel

#print axioms adaptive146Third142Proof135

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third142Proof285 : runCachedNode 511 131054 Adaptive146Third142Node285 = false := by
  decide +kernel

#print axioms adaptive146Third142Proof285

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third142Proof198 : runCachedNode 511 131054 Adaptive146Third142Node198 = false := by
  decide +kernel

#print axioms adaptive146Third142Proof198

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third142Proof105 : runCachedNode 511 131054 Adaptive146Third142Node105 = false := by
  decide +kernel

#print axioms adaptive146Third142Proof105

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third142Proof481 : runCachedNode 511 131054 Adaptive146Third142Node481 = false := by
  decide +kernel

#print axioms adaptive146Third142Proof481

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third142Proof237 : runCachedNode 511 131054 Adaptive146Third142Node237 = false := by
  decide +kernel

#print axioms adaptive146Third142Proof237

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third142Proof46 : runCachedNode 511 131054 Adaptive146Third142Node46 = false := by
  decide +kernel

#print axioms adaptive146Third142Proof46

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third142Proof390 : runCachedNode 511 131054 Adaptive146Third142Node390 = false := by
  decide +kernel

#print axioms adaptive146Third142Proof390

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third142Proof76 : runCachedNode 511 131054 Adaptive146Third142Node76 = false := by
  decide +kernel

#print axioms adaptive146Third142Proof76

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third142Proof169 : runCachedNode 511 131054 Adaptive146Third142Node169 = false := by
  decide +kernel

#print axioms adaptive146Third142Proof169

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third142Proof389 : runCachedNode 511 131054 Adaptive146Third142Node389 = false := by
  decide +kernel

#print axioms adaptive146Third142Proof389

end NineSeparatedSubsetSums
