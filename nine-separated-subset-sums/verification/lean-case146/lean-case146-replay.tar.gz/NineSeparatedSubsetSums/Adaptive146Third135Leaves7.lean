import NineSeparatedSubsetSums.Adaptive146Third135State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third135Proof11 : runCachedNode 511 130049 Adaptive146Third135Node11 = false := by
  decide +kernel

#print axioms adaptive146Third135Proof11

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third135Proof39 : runCachedNode 511 130049 Adaptive146Third135Node39 = false := by
  decide +kernel

#print axioms adaptive146Third135Proof39

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third135Proof69 : runCachedNode 511 130049 Adaptive146Third135Node69 = false := by
  decide +kernel

#print axioms adaptive146Third135Proof69

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third135Proof66 : runCachedNode 511 130049 Adaptive146Third135Node66 = false := by
  decide +kernel

#print axioms adaptive146Third135Proof66

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third135Proof43 : runCachedNode 511 130049 Adaptive146Third135Node43 = false := by
  decide +kernel

#print axioms adaptive146Third135Proof43

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third135Proof96 : runCachedNode 511 130049 Adaptive146Third135Node96 = false := by
  decide +kernel

#print axioms adaptive146Third135Proof96

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third135Proof68 : runCachedNode 511 130049 Adaptive146Third135Node68 = false := by
  decide +kernel

#print axioms adaptive146Third135Proof68

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third135Proof91 : runCachedNode 511 130049 Adaptive146Third135Node91 = false := by
  decide +kernel

#print axioms adaptive146Third135Proof91

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third135Proof64 : runCachedNode 511 130049 Adaptive146Third135Node64 = false := by
  decide +kernel

#print axioms adaptive146Third135Proof64

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third135Proof10 : runCachedNode 511 130049 Adaptive146Third135Node10 = false := by
  decide +kernel

#print axioms adaptive146Third135Proof10

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third135Proof40 : runCachedNode 511 130049 Adaptive146Third135Node40 = false := by
  decide +kernel

#print axioms adaptive146Third135Proof40

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third135Proof9 : runCachedNode 511 130049 Adaptive146Third135Node9 = false := by
  decide +kernel

#print axioms adaptive146Third135Proof9

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third135Proof6 : runCachedNode 511 130049 Adaptive146Third135Node6 = false := by
  decide +kernel

#print axioms adaptive146Third135Proof6

end NineSeparatedSubsetSums
