import NineSeparatedSubsetSums.Adaptive146Third142State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third142Proof240 : runCachedNode 511 131054 Adaptive146Third142Node240 = false := by
  decide +kernel

#print axioms adaptive146Third142Proof240

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third142Proof201 : runCachedNode 511 131054 Adaptive146Third142Node201 = false := by
  decide +kernel

#print axioms adaptive146Third142Proof201

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third142Proof315 : runCachedNode 511 131054 Adaptive146Third142Node315 = false := by
  decide +kernel

#print axioms adaptive146Third142Proof315

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third142Proof171 : runCachedNode 511 131054 Adaptive146Third142Node171 = false := by
  decide +kernel

#print axioms adaptive146Third142Proof171

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third142Proof286 : runCachedNode 511 131054 Adaptive146Third142Node286 = false := by
  decide +kernel

#print axioms adaptive146Third142Proof286

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third142Proof394 : runCachedNode 511 131054 Adaptive146Third142Node394 = false := by
  decide +kernel

#print axioms adaptive146Third142Proof394

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third142Proof108 : runCachedNode 511 131054 Adaptive146Third142Node108 = false := by
  decide +kernel

#print axioms adaptive146Third142Proof108

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third142Proof200 : runCachedNode 511 131054 Adaptive146Third142Node200 = false := by
  decide +kernel

#print axioms adaptive146Third142Proof200

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third142Proof75 : runCachedNode 511 131054 Adaptive146Third142Node75 = false := by
  decide +kernel

#print axioms adaptive146Third142Proof75

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third142Proof132 : runCachedNode 511 131054 Adaptive146Third142Node132 = false := by
  decide +kernel

#print axioms adaptive146Third142Proof132

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third142Proof26 : runCachedNode 511 131054 Adaptive146Third142Node26 = false := by
  decide +kernel

#print axioms adaptive146Third142Proof26

end NineSeparatedSubsetSums
