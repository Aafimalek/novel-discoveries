import NineSeparatedSubsetSums.Adaptive146Third142State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third142Proof142 : runCachedNode 511 131054 Adaptive146Third142Node142 = false := by
  decide +kernel

#print axioms adaptive146Third142Proof142

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third142Proof138 : runCachedNode 511 131054 Adaptive146Third142Node138 = false := by
  decide +kernel

#print axioms adaptive146Third142Proof138

end NineSeparatedSubsetSums
