import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive146Third108Node0 : CachedSearchNode :=
  ⟨4, 107, computeCenteredMask [148,146,108], 402, 54884⟩

end NineSeparatedSubsetSums
