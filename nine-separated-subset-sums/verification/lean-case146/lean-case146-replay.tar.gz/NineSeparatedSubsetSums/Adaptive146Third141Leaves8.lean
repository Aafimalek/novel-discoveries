import NineSeparatedSubsetSums.Adaptive146Third141State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third141Proof237 : runCachedNode 511 130916 Adaptive146Third141Node237 = false := by
  decide +kernel

#print axioms adaptive146Third141Proof237

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third141Proof201 : runCachedNode 511 130916 Adaptive146Third141Node201 = false := by
  decide +kernel

#print axioms adaptive146Third141Proof201

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third141Proof208 : runCachedNode 511 130916 Adaptive146Third141Node208 = false := by
  decide +kernel

#print axioms adaptive146Third141Proof208

end NineSeparatedSubsetSums
