import NineSeparatedSubsetSums.Adaptive146Third140State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third140Proof313 : runCachedNode 511 130775 Adaptive146Third140Node313 = false := by
  decide +kernel

#print axioms adaptive146Third140Proof313

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third140Proof185 : runCachedNode 511 130775 Adaptive146Third140Node185 = false := by
  decide +kernel

#print axioms adaptive146Third140Proof185

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third140Proof8 : runCachedNode 511 130775 Adaptive146Third140Node8 = false := by
  decide +kernel

#print axioms adaptive146Third140Proof8

end NineSeparatedSubsetSums
