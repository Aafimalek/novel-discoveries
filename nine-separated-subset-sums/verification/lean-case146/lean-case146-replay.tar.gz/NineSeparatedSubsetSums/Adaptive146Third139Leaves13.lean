import NineSeparatedSubsetSums.Adaptive146Third139State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third139Proof96 : runCachedNode 511 130638 Adaptive146Third139Node96 = false := by
  decide +kernel

#print axioms adaptive146Third139Proof96

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third139Proof15 : runCachedNode 511 130638 Adaptive146Third139Node15 = false := by
  decide +kernel

#print axioms adaptive146Third139Proof15

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third139Proof213 : runCachedNode 511 130638 Adaptive146Third139Node213 = false := by
  decide +kernel

#print axioms adaptive146Third139Proof213

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third139Proof122 : runCachedNode 511 130638 Adaptive146Third139Node122 = false := by
  decide +kernel

#print axioms adaptive146Third139Proof122

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third139Proof160 : runCachedNode 511 130638 Adaptive146Third139Node160 = false := by
  decide +kernel

#print axioms adaptive146Third139Proof160

end NineSeparatedSubsetSums
