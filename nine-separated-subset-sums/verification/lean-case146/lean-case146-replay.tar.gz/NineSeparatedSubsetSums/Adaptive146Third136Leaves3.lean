import NineSeparatedSubsetSums.Adaptive146Third136State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third136Proof17 : runCachedNode 511 130191 Adaptive146Third136Node17 = false := by
  decide +kernel

#print axioms adaptive146Third136Proof17

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third136Proof129 : runCachedNode 511 130191 Adaptive146Third136Node129 = false := by
  decide +kernel

#print axioms adaptive146Third136Proof129

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third136Proof59 : runCachedNode 511 130191 Adaptive146Third136Node59 = false := by
  decide +kernel

#print axioms adaptive146Third136Proof59

end NineSeparatedSubsetSums
