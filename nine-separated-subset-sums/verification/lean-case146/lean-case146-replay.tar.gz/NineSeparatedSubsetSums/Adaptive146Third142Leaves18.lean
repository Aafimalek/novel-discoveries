import NineSeparatedSubsetSums.Adaptive146Third142State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third142Proof399 : runCachedNode 511 131054 Adaptive146Third142Node399 = false := by
  decide +kernel

#print axioms adaptive146Third142Proof399

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third142Proof365 : runCachedNode 511 131054 Adaptive146Third142Node365 = false := by
  decide +kernel

#print axioms adaptive146Third142Proof365

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third142Proof16 : runCachedNode 511 131054 Adaptive146Third142Node16 = false := by
  decide +kernel

#print axioms adaptive146Third142Proof16

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third142Proof320 : runCachedNode 511 131054 Adaptive146Third142Node320 = false := by
  decide +kernel

#print axioms adaptive146Third142Proof320

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third142Proof253 : runCachedNode 511 131054 Adaptive146Third142Node253 = false := by
  decide +kernel

#print axioms adaptive146Third142Proof253

end NineSeparatedSubsetSums
