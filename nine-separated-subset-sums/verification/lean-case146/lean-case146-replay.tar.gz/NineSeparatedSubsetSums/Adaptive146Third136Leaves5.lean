import NineSeparatedSubsetSums.Adaptive146Third136State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third136Proof100 : runCachedNode 511 130191 Adaptive146Third136Node100 = false := by
  decide +kernel

#print axioms adaptive146Third136Proof100

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third136Proof16 : runCachedNode 511 130191 Adaptive146Third136Node16 = false := by
  decide +kernel

#print axioms adaptive146Third136Proof16

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third136Proof70 : runCachedNode 511 130191 Adaptive146Third136Node70 = false := by
  decide +kernel

#print axioms adaptive146Third136Proof70

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third136Proof6 : runCachedNode 511 130191 Adaptive146Third136Node6 = false := by
  decide +kernel

#print axioms adaptive146Third136Proof6

end NineSeparatedSubsetSums
