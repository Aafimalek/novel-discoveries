import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive146Third106Node0 : CachedSearchNode :=
  ⟨4, 105, computeCenteredMask [148,146,106], 400, 54456⟩

end NineSeparatedSubsetSums
