import NineSeparatedSubsetSums.Adaptive146Third144State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third144Proof477 : runCachedNode 511 131319 Adaptive146Third144Node477 = false := by
  decide +kernel

#print axioms adaptive146Third144Proof477

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third144Proof1155 : runCachedNode 511 131319 Adaptive146Third144Node1155 = false := by
  decide +kernel

#print axioms adaptive146Third144Proof1155

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third144Proof1333 : runCachedNode 511 131319 Adaptive146Third144Node1333 = false := by
  decide +kernel

#print axioms adaptive146Third144Proof1333

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third144Proof150 : runCachedNode 511 131319 Adaptive146Third144Node150 = false := by
  decide +kernel

#print axioms adaptive146Third144Proof150

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third144Proof744 : runCachedNode 511 131319 Adaptive146Third144Node744 = false := by
  decide +kernel

#print axioms adaptive146Third144Proof744

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third144Proof817 : runCachedNode 511 131319 Adaptive146Third144Node817 = false := by
  decide +kernel

#print axioms adaptive146Third144Proof817

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third144Proof843 : runCachedNode 511 131319 Adaptive146Third144Node843 = false := by
  decide +kernel

#print axioms adaptive146Third144Proof843

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third144Proof369 : runCachedNode 511 131319 Adaptive146Third144Node369 = false := by
  decide +kernel

#print axioms adaptive146Third144Proof369

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third144Proof344 : runCachedNode 511 131319 Adaptive146Third144Node344 = false := by
  decide +kernel

#print axioms adaptive146Third144Proof344

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third144Proof1199 : runCachedNode 511 131319 Adaptive146Third144Node1199 = false := by
  decide +kernel

#print axioms adaptive146Third144Proof1199

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third144Proof1378 : runCachedNode 511 131319 Adaptive146Third144Node1378 = false := by
  decide +kernel

#print axioms adaptive146Third144Proof1378

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third144Proof1424 : runCachedNode 511 131319 Adaptive146Third144Node1424 = false := by
  decide +kernel

#print axioms adaptive146Third144Proof1424

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third144Proof981 : runCachedNode 511 131319 Adaptive146Third144Node981 = false := by
  decide +kernel

#print axioms adaptive146Third144Proof981

end NineSeparatedSubsetSums
