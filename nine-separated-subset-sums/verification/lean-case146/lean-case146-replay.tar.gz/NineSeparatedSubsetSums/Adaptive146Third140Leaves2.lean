import NineSeparatedSubsetSums.Adaptive146Third140State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third140Proof383 : runCachedNode 511 130775 Adaptive146Third140Node383 = false := by
  decide +kernel

#print axioms adaptive146Third140Proof383

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third140Proof71 : runCachedNode 511 130775 Adaptive146Third140Node71 = false := by
  decide +kernel

#print axioms adaptive146Third140Proof71

end NineSeparatedSubsetSums
