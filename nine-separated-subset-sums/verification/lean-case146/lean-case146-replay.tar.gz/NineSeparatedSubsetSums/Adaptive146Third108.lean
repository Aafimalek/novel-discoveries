import NineSeparatedSubsetSums.Adaptive146Third108Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint146Checked

namespace NineSeparatedSubsetSums


theorem adaptive146Third108 : NoDescendingTailAfterThird 146 108 :=
  noDescendingThirdTail_of_cached 146 108 112631 (fun t ht nd => max148_second146_fourPoint_moment_bound (108::t) (by simp [ht]) nd) adaptive146Third108Proof0

#print axioms adaptive146Third108

end NineSeparatedSubsetSums
