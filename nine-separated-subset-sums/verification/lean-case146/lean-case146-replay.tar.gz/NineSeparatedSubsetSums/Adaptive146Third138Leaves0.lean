import NineSeparatedSubsetSums.Adaptive146Third138State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third138Proof19 : runCachedNode 511 130484 Adaptive146Third138Node19 = false := by
  decide +kernel

#print axioms adaptive146Third138Proof19

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third138Proof60 : runCachedNode 511 130484 Adaptive146Third138Node60 = false := by
  decide +kernel

#print axioms adaptive146Third138Proof60

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third138Proof1 : runCachedNode 511 130484 Adaptive146Third138Node1 = false := by
  decide +kernel

#print axioms adaptive146Third138Proof1

end NineSeparatedSubsetSums
