import NineSeparatedSubsetSums.Adaptive146Third143State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third143Proof196 : runCachedNode 511 131193 Adaptive146Third143Node196 = false := by
  decide +kernel

#print axioms adaptive146Third143Proof196

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third143Proof17 : runCachedNode 511 131193 Adaptive146Third143Node17 = false := by
  decide +kernel

#print axioms adaptive146Third143Proof17

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third143Proof133 : runCachedNode 511 131193 Adaptive146Third143Node133 = false := by
  decide +kernel

#print axioms adaptive146Third143Proof133

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third143Proof2 : runCachedNode 511 131193 Adaptive146Third143Node2 = false := by
  decide +kernel

#print axioms adaptive146Third143Proof2

end NineSeparatedSubsetSums
