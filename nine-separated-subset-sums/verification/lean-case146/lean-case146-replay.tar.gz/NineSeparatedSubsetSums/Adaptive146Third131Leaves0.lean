import NineSeparatedSubsetSums.Adaptive146Third131State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third131Proof20 : runCachedNode 511 129268 Adaptive146Third131Node20 = false := by
  decide +kernel

#print axioms adaptive146Third131Proof20

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third131Proof16 : runCachedNode 511 129268 Adaptive146Third131Node16 = false := by
  decide +kernel

#print axioms adaptive146Third131Proof16

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third131Proof6 : runCachedNode 511 129268 Adaptive146Third131Node6 = false := by
  decide +kernel

#print axioms adaptive146Third131Proof6

end NineSeparatedSubsetSums
