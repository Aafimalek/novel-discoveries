import NineSeparatedSubsetSums.Adaptive146Third137State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third137Proof17 : runCachedNode 511 130354 Adaptive146Third137Node17 = false := by
  decide +kernel

#print axioms adaptive146Third137Proof17

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third137Proof153 : runCachedNode 511 130354 Adaptive146Third137Node153 = false := by
  decide +kernel

#print axioms adaptive146Third137Proof153

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third137Proof90 : runCachedNode 511 130354 Adaptive146Third137Node90 = false := by
  decide +kernel

#print axioms adaptive146Third137Proof90

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third137Proof3 : runCachedNode 511 130354 Adaptive146Third137Node3 = false := by
  decide +kernel

#print axioms adaptive146Third137Proof3

end NineSeparatedSubsetSums
