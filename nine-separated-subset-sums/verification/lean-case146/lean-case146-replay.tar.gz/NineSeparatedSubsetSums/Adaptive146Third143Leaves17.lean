import NineSeparatedSubsetSums.Adaptive146Third143State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third143Proof341 : runCachedNode 511 131193 Adaptive146Third143Node341 = false := by
  decide +kernel

#print axioms adaptive146Third143Proof341

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third143Proof545 : runCachedNode 511 131193 Adaptive146Third143Node545 = false := by
  decide +kernel

#print axioms adaptive146Third143Proof545

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third143Proof47 : runCachedNode 511 131193 Adaptive146Third143Node47 = false := by
  decide +kernel

#print axioms adaptive146Third143Proof47

end NineSeparatedSubsetSums
