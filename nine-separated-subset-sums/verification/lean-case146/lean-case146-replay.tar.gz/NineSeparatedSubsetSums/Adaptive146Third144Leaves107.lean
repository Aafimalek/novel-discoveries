import NineSeparatedSubsetSums.Adaptive146Third144State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third144Proof269 : runCachedNode 511 131319 Adaptive146Third144Node269 = false := by
  decide +kernel

#print axioms adaptive146Third144Proof269

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third144Proof1198 : runCachedNode 511 131319 Adaptive146Third144Node1198 = false := by
  decide +kernel

#print axioms adaptive146Third144Proof1198

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third144Proof1240 : runCachedNode 511 131319 Adaptive146Third144Node1240 = false := by
  decide +kernel

#print axioms adaptive146Third144Proof1240

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third144Proof1331 : runCachedNode 511 131319 Adaptive146Third144Node1331 = false := by
  decide +kernel

#print axioms adaptive146Third144Proof1331

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third144Proof1377 : runCachedNode 511 131319 Adaptive146Third144Node1377 = false := by
  decide +kernel

#print axioms adaptive146Third144Proof1377

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third144Proof1423 : runCachedNode 511 131319 Adaptive146Third144Node1423 = false := by
  decide +kernel

#print axioms adaptive146Third144Proof1423

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third144Proof1063 : runCachedNode 511 131319 Adaptive146Third144Node1063 = false := by
  decide +kernel

#print axioms adaptive146Third144Proof1063

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third144Proof1235 : runCachedNode 511 131319 Adaptive146Third144Node1235 = false := by
  decide +kernel

#print axioms adaptive146Third144Proof1235

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third144Proof32 : runCachedNode 511 131319 Adaptive146Third144Node32 = false := by
  decide +kernel

#print axioms adaptive146Third144Proof32

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third144Proof54 : runCachedNode 511 131319 Adaptive146Third144Node54 = false := by
  decide +kernel

#print axioms adaptive146Third144Proof54

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third144Proof100 : runCachedNode 511 131319 Adaptive146Third144Node100 = false := by
  decide +kernel

#print axioms adaptive146Third144Proof100

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third144Proof125 : runCachedNode 511 131319 Adaptive146Third144Node125 = false := by
  decide +kernel

#print axioms adaptive146Third144Proof125

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third144Proof208 : runCachedNode 511 131319 Adaptive146Third144Node208 = false := by
  decide +kernel

#print axioms adaptive146Third144Proof208

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third144Proof890 : runCachedNode 511 131319 Adaptive146Third144Node890 = false := by
  decide +kernel

#print axioms adaptive146Third144Proof890

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third144Proof1019 : runCachedNode 511 131319 Adaptive146Third144Node1019 = false := by
  decide +kernel

#print axioms adaptive146Third144Proof1019

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third144Proof977 : runCachedNode 511 131319 Adaptive146Third144Node977 = false := by
  decide +kernel

#print axioms adaptive146Third144Proof977

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third144Proof400 : runCachedNode 511 131319 Adaptive146Third144Node400 = false := by
  decide +kernel

#print axioms adaptive146Third144Proof400

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third144Proof547 : runCachedNode 511 131319 Adaptive146Third144Node547 = false := by
  decide +kernel

#print axioms adaptive146Third144Proof547

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third144Proof87 : runCachedNode 511 131319 Adaptive146Third144Node87 = false := by
  decide +kernel

#print axioms adaptive146Third144Proof87

end NineSeparatedSubsetSums
