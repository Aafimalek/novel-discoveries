import NineSeparatedSubsetSums.Adaptive146Third142State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third142Proof323 : runCachedNode 511 131054 Adaptive146Third142Node323 = false := by
  decide +kernel

#print axioms adaptive146Third142Proof323

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third142Proof356 : runCachedNode 511 131054 Adaptive146Third142Node356 = false := by
  decide +kernel

#print axioms adaptive146Third142Proof356

end NineSeparatedSubsetSums
