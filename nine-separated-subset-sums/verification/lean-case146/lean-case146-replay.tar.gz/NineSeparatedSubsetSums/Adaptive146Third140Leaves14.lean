import NineSeparatedSubsetSums.Adaptive146Third140State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third140Proof282 : runCachedNode 511 130775 Adaptive146Third140Node282 = false := by
  decide +kernel

#print axioms adaptive146Third140Proof282

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third140Proof19 : runCachedNode 511 130775 Adaptive146Third140Node19 = false := by
  decide +kernel

#print axioms adaptive146Third140Proof19

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third140Proof158 : runCachedNode 511 130775 Adaptive146Third140Node158 = false := by
  decide +kernel

#print axioms adaptive146Third140Proof158

end NineSeparatedSubsetSums
