import NineSeparatedSubsetSums.Adaptive146Third140State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third140Proof209 : runCachedNode 511 130775 Adaptive146Third140Node209 = false := by
  decide +kernel

#print axioms adaptive146Third140Proof209

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third140Proof306 : runCachedNode 511 130775 Adaptive146Third140Node306 = false := by
  decide +kernel

#print axioms adaptive146Third140Proof306

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third140Proof308 : runCachedNode 511 130775 Adaptive146Third140Node308 = false := by
  decide +kernel

#print axioms adaptive146Third140Proof308

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third140Proof346 : runCachedNode 511 130775 Adaptive146Third140Node346 = false := by
  decide +kernel

#print axioms adaptive146Third140Proof346

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third140Proof10 : runCachedNode 511 130775 Adaptive146Third140Node10 = false := by
  decide +kernel

#print axioms adaptive146Third140Proof10

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third140Proof40 : runCachedNode 511 130775 Adaptive146Third140Node40 = false := by
  decide +kernel

#print axioms adaptive146Third140Proof40

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third140Proof372 : runCachedNode 511 130775 Adaptive146Third140Node372 = false := by
  decide +kernel

#print axioms adaptive146Third140Proof372

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third140Proof118 : runCachedNode 511 130775 Adaptive146Third140Node118 = false := by
  decide +kernel

#print axioms adaptive146Third140Proof118

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third140Proof373 : runCachedNode 511 130775 Adaptive146Third140Node373 = false := by
  decide +kernel

#print axioms adaptive146Third140Proof373

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third140Proof267 : runCachedNode 511 130775 Adaptive146Third140Node267 = false := by
  decide +kernel

#print axioms adaptive146Third140Proof267

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third140Proof173 : runCachedNode 511 130775 Adaptive146Third140Node173 = false := by
  decide +kernel

#print axioms adaptive146Third140Proof173

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third140Proof65 : runCachedNode 511 130775 Adaptive146Third140Node65 = false := by
  decide +kernel

#print axioms adaptive146Third140Proof65

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third140Proof305 : runCachedNode 511 130775 Adaptive146Third140Node305 = false := by
  decide +kernel

#print axioms adaptive146Third140Proof305

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third140Proof64 : runCachedNode 511 130775 Adaptive146Third140Node64 = false := by
  decide +kernel

#print axioms adaptive146Third140Proof64

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third140Proof144 : runCachedNode 511 130775 Adaptive146Third140Node144 = false := by
  decide +kernel

#print axioms adaptive146Third140Proof144

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third140Proof370 : runCachedNode 511 130775 Adaptive146Third140Node370 = false := by
  decide +kernel

#print axioms adaptive146Third140Proof370

end NineSeparatedSubsetSums
