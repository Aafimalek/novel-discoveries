import NineSeparatedSubsetSums.Adaptive146Third143State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third143Proof263 : runCachedNode 511 131193 Adaptive146Third143Node263 = false := by
  decide +kernel

#print axioms adaptive146Third143Proof263

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third143Proof499 : runCachedNode 511 131193 Adaptive146Third143Node499 = false := by
  decide +kernel

#print axioms adaptive146Third143Proof499

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third143Proof267 : runCachedNode 511 131193 Adaptive146Third143Node267 = false := by
  decide +kernel

#print axioms adaptive146Third143Proof267

end NineSeparatedSubsetSums
