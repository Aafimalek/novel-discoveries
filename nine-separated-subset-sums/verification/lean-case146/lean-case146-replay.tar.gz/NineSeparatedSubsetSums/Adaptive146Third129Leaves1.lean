import NineSeparatedSubsetSums.Adaptive146Third129State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third129Proof17 : runCachedNode 511 128829 Adaptive146Third129Node17 = false := by
  decide +kernel

#print axioms adaptive146Third129Proof17

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third129Proof14 : runCachedNode 511 128829 Adaptive146Third129Node14 = false := by
  decide +kernel

#print axioms adaptive146Third129Proof14

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third129Proof13 : runCachedNode 511 128829 Adaptive146Third129Node13 = false := by
  decide +kernel

#print axioms adaptive146Third129Proof13

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third129Proof12 : runCachedNode 511 128829 Adaptive146Third129Node12 = false := by
  decide +kernel

#print axioms adaptive146Third129Proof12

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third129Proof11 : runCachedNode 511 128829 Adaptive146Third129Node11 = false := by
  decide +kernel

#print axioms adaptive146Third129Proof11

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third129Proof10 : runCachedNode 511 128829 Adaptive146Third129Node10 = false := by
  decide +kernel

#print axioms adaptive146Third129Proof10

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third129Proof9 : runCachedNode 511 128829 Adaptive146Third129Node9 = false := by
  decide +kernel

#print axioms adaptive146Third129Proof9

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third129Proof4 : runCachedNode 511 128829 Adaptive146Third129Node4 = false := by
  decide +kernel

#print axioms adaptive146Third129Proof4

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third129Proof3 : runCachedNode 511 128829 Adaptive146Third129Node3 = false := by
  decide +kernel

#print axioms adaptive146Third129Proof3

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third129Proof1 : runCachedNode 511 128829 Adaptive146Third129Node1 = false := by
  decide +kernel

#print axioms adaptive146Third129Proof1

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third129Proof2 : runCachedNode 511 128829 Adaptive146Third129Node2 = false := by
  decide +kernel

#print axioms adaptive146Third129Proof2

end NineSeparatedSubsetSums
