import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive146Third126Node0 : CachedSearchNode :=
  ⟨4, 125, computeCenteredMask [148,146,126], 420, 59096⟩
def Adaptive146Third126Node1 : CachedSearchNode := cachedChild Adaptive146Third126Node0 110
def Adaptive146Third126Node2 : CachedSearchNode := cachedChild Adaptive146Third126Node0 111
def Adaptive146Third126Node3 : CachedSearchNode := cachedChild Adaptive146Third126Node0 112
def Adaptive146Third126Node4 : CachedSearchNode := cachedChild Adaptive146Third126Node0 113
def Adaptive146Third126Node5 : CachedSearchNode := cachedChild Adaptive146Third126Node0 114
def Adaptive146Third126Node6 : CachedSearchNode := cachedChild Adaptive146Third126Node0 115
def Adaptive146Third126Node7 : CachedSearchNode := cachedChild Adaptive146Third126Node0 116
def Adaptive146Third126Node8 : CachedSearchNode := cachedChild Adaptive146Third126Node0 117
def Adaptive146Third126Node9 : CachedSearchNode := cachedChild Adaptive146Third126Node0 118
def Adaptive146Third126Node10 : CachedSearchNode := cachedChild Adaptive146Third126Node0 119
def Adaptive146Third126Node11 : CachedSearchNode := cachedChild Adaptive146Third126Node0 120
def Adaptive146Third126Node12 : CachedSearchNode := cachedChild Adaptive146Third126Node0 121
def Adaptive146Third126Node13 : CachedSearchNode := cachedChild Adaptive146Third126Node0 122
def Adaptive146Third126Node14 : CachedSearchNode := cachedChild Adaptive146Third126Node0 123
def Adaptive146Third126Node15 : CachedSearchNode := cachedChild Adaptive146Third126Node0 125

end NineSeparatedSubsetSums
