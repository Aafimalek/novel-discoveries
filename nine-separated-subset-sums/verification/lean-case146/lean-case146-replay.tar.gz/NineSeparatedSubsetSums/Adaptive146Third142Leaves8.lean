import NineSeparatedSubsetSums.Adaptive146Third142State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third142Proof180 : runCachedNode 511 131054 Adaptive146Third142Node180 = false := by
  decide +kernel

#print axioms adaptive146Third142Proof180

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third142Proof17 : runCachedNode 511 131054 Adaptive146Third142Node17 = false := by
  decide +kernel

#print axioms adaptive146Third142Proof17

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third142Proof68 : runCachedNode 511 131054 Adaptive146Third142Node68 = false := by
  decide +kernel

#print axioms adaptive146Third142Proof68

end NineSeparatedSubsetSums
