import NineSeparatedSubsetSums.Adaptive146Third116State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third116Proof14 : runCachedNode 511 112631 Adaptive146Third116Node14 = false := by
  decide +kernel

#print axioms adaptive146Third116Proof14

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third116Proof12 : runCachedNode 511 112631 Adaptive146Third116Node12 = false := by
  decide +kernel

#print axioms adaptive146Third116Proof12

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third116Proof10 : runCachedNode 511 112631 Adaptive146Third116Node10 = false := by
  decide +kernel

#print axioms adaptive146Third116Proof10

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third116Proof9 : runCachedNode 511 112631 Adaptive146Third116Node9 = false := by
  decide +kernel

#print axioms adaptive146Third116Proof9

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third116Proof8 : runCachedNode 511 112631 Adaptive146Third116Node8 = false := by
  decide +kernel

#print axioms adaptive146Third116Proof8

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third116Proof7 : runCachedNode 511 112631 Adaptive146Third116Node7 = false := by
  decide +kernel

#print axioms adaptive146Third116Proof7

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third116Proof5 : runCachedNode 511 112631 Adaptive146Third116Node5 = false := by
  decide +kernel

#print axioms adaptive146Third116Proof5

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third116Proof4 : runCachedNode 511 112631 Adaptive146Third116Node4 = false := by
  decide +kernel

#print axioms adaptive146Third116Proof4

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third116Proof3 : runCachedNode 511 112631 Adaptive146Third116Node3 = false := by
  decide +kernel

#print axioms adaptive146Third116Proof3

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third116Proof2 : runCachedNode 511 112631 Adaptive146Third116Node2 = false := by
  decide +kernel

#print axioms adaptive146Third116Proof2

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third116Proof1 : runCachedNode 511 112631 Adaptive146Third116Node1 = false := by
  decide +kernel

#print axioms adaptive146Third116Proof1

end NineSeparatedSubsetSums
