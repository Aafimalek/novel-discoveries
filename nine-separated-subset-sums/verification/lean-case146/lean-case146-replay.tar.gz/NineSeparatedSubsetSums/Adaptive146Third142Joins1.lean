import NineSeparatedSubsetSums.Adaptive146Third142State
import NineSeparatedSubsetSums.Adaptive146Third142Leaves41
import NineSeparatedSubsetSums.Adaptive146Third142Leaves40
import NineSeparatedSubsetSums.Adaptive146Third142Leaves39
import NineSeparatedSubsetSums.Adaptive146Third142Leaves38
import NineSeparatedSubsetSums.Adaptive146Third142Leaves37
import NineSeparatedSubsetSums.Adaptive146Third142Leaves36
import NineSeparatedSubsetSums.Adaptive146Third142Leaves35
import NineSeparatedSubsetSums.Adaptive146Third142Leaves34
import NineSeparatedSubsetSums.Adaptive146Third142Leaves1
import NineSeparatedSubsetSums.Adaptive146Third142Leaves30
import NineSeparatedSubsetSums.Adaptive146Third142Leaves33
import NineSeparatedSubsetSums.Adaptive146Third142Leaves32
import NineSeparatedSubsetSums.Adaptive146Third142Leaves28
import NineSeparatedSubsetSums.Adaptive146Third142Leaves26
import NineSeparatedSubsetSums.Adaptive146Third142Leaves24
import NineSeparatedSubsetSums.Adaptive146Third142Leaves18
import NineSeparatedSubsetSums.Adaptive146Third142Leaves13
import NineSeparatedSubsetSums.Adaptive146Third142Leaves27
import NineSeparatedSubsetSums.Adaptive146Third142Leaves29
import NineSeparatedSubsetSums.Adaptive146Third142Leaves25
import NineSeparatedSubsetSums.Adaptive146Third142Leaves22
import NineSeparatedSubsetSums.Adaptive146Third142Leaves19
import NineSeparatedSubsetSums.Adaptive146Third142Leaves9
import NineSeparatedSubsetSums.Adaptive146Third142Leaves42
import NineSeparatedSubsetSums.Adaptive146Third142Leaves20
import NineSeparatedSubsetSums.Adaptive146Third142Leaves31
import NineSeparatedSubsetSums.Adaptive146Third142Leaves23
import NineSeparatedSubsetSums.Adaptive146Third142Leaves17
import NineSeparatedSubsetSums.Adaptive146Third142Leaves14
import NineSeparatedSubsetSums.Adaptive146Third142Leaves21
import NineSeparatedSubsetSums.Adaptive146Third142Leaves4
import NineSeparatedSubsetSums.Adaptive146Third142Leaves15
import NineSeparatedSubsetSums.Adaptive146Third142Leaves5
import NineSeparatedSubsetSums.Adaptive146Third142Leaves8
import NineSeparatedSubsetSums.Adaptive146Third142Leaves12
import NineSeparatedSubsetSums.Adaptive146Third142Leaves11
import NineSeparatedSubsetSums.Adaptive146Third142Leaves2
import NineSeparatedSubsetSums.Adaptive146Third142Joins0

namespace NineSeparatedSubsetSums

theorem adaptive146Third142Proof324 : runCachedNode 511 131054 Adaptive146Third142Node324 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 131054 Adaptive146Third142Node324 = [88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 126, 127, 128, 130] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive146Third142Proof325
  · exact adaptive146Third142Proof326
  · exact adaptive146Third142Proof327
  · exact adaptive146Third142Proof328
  · exact adaptive146Third142Proof329
  · exact adaptive146Third142Proof330
  · exact adaptive146Third142Proof331
  · exact adaptive146Third142Proof332
  · exact adaptive146Third142Proof333
  · exact adaptive146Third142Proof334
  · exact adaptive146Third142Proof335
  · exact adaptive146Third142Proof336
  · exact adaptive146Third142Proof337
  · exact adaptive146Third142Proof338
  · exact adaptive146Third142Proof339
  · exact adaptive146Third142Proof340
  · exact adaptive146Third142Proof341
  · exact adaptive146Third142Proof342
  · exact adaptive146Third142Proof343
  · exact adaptive146Third142Proof344
  · exact adaptive146Third142Proof345
  · exact adaptive146Third142Proof346
  · exact adaptive146Third142Proof347
  · exact adaptive146Third142Proof348
  · exact adaptive146Third142Proof349
  · exact adaptive146Third142Proof350
  · exact adaptive146Third142Proof351
  · exact adaptive146Third142Proof352
  · exact adaptive146Third142Proof353
  · exact adaptive146Third142Proof354
  · exact adaptive146Third142Proof355
  · exact adaptive146Third142Proof356
  · exact adaptive146Third142Proof357
  · exact adaptive146Third142Proof358
  · exact adaptive146Third142Proof359
  · exact adaptive146Third142Proof360
  · exact adaptive146Third142Proof361
  · exact adaptive146Third142Proof362
  · exact adaptive146Third142Proof363
  · exact adaptive146Third142Proof364
  · exact adaptive146Third142Proof365

#print axioms adaptive146Third142Proof324

theorem adaptive146Third142Proof289 : runCachedNode 511 131054 Adaptive146Third142Node289 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 131054 Adaptive146Third142Node289 = [101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 132, 134, 136, 138] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive146Third142Proof290
  · exact adaptive146Third142Proof291
  · exact adaptive146Third142Proof292
  · exact adaptive146Third142Proof293
  · exact adaptive146Third142Proof294
  · exact adaptive146Third142Proof295
  · exact adaptive146Third142Proof296
  · exact adaptive146Third142Proof297
  · exact adaptive146Third142Proof298
  · exact adaptive146Third142Proof299
  · exact adaptive146Third142Proof300
  · exact adaptive146Third142Proof301
  · exact adaptive146Third142Proof302
  · exact adaptive146Third142Proof303
  · exact adaptive146Third142Proof304
  · exact adaptive146Third142Proof305
  · exact adaptive146Third142Proof306
  · exact adaptive146Third142Proof307
  · exact adaptive146Third142Proof308
  · exact adaptive146Third142Proof309
  · exact adaptive146Third142Proof310
  · exact adaptive146Third142Proof311
  · exact adaptive146Third142Proof312
  · exact adaptive146Third142Proof313
  · exact adaptive146Third142Proof314
  · exact adaptive146Third142Proof315
  · exact adaptive146Third142Proof316
  · exact adaptive146Third142Proof317
  · exact adaptive146Third142Proof318
  · exact adaptive146Third142Proof319
  · exact adaptive146Third142Proof320
  · exact adaptive146Third142Proof321
  · exact adaptive146Third142Proof322
  · exact adaptive146Third142Proof323
  · exact adaptive146Third142Proof324

#print axioms adaptive146Third142Proof289

theorem adaptive146Third142Proof402 : runCachedNode 511 131054 Adaptive146Third142Node402 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 131054 Adaptive146Third142Node402 = [88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 126, 127, 128] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive146Third142Proof403
  · exact adaptive146Third142Proof404
  · exact adaptive146Third142Proof405
  · exact adaptive146Third142Proof406
  · exact adaptive146Third142Proof407
  · exact adaptive146Third142Proof408
  · exact adaptive146Third142Proof409
  · exact adaptive146Third142Proof410
  · exact adaptive146Third142Proof411
  · exact adaptive146Third142Proof412
  · exact adaptive146Third142Proof413
  · exact adaptive146Third142Proof414
  · exact adaptive146Third142Proof415
  · exact adaptive146Third142Proof416
  · exact adaptive146Third142Proof417
  · exact adaptive146Third142Proof418
  · exact adaptive146Third142Proof419
  · exact adaptive146Third142Proof420
  · exact adaptive146Third142Proof421
  · exact adaptive146Third142Proof422
  · exact adaptive146Third142Proof423
  · exact adaptive146Third142Proof424
  · exact adaptive146Third142Proof425
  · exact adaptive146Third142Proof426
  · exact adaptive146Third142Proof427
  · exact adaptive146Third142Proof428
  · exact adaptive146Third142Proof429
  · exact adaptive146Third142Proof430
  · exact adaptive146Third142Proof431
  · exact adaptive146Third142Proof432
  · exact adaptive146Third142Proof433
  · exact adaptive146Third142Proof434
  · exact adaptive146Third142Proof435
  · exact adaptive146Third142Proof436
  · exact adaptive146Third142Proof437
  · exact adaptive146Third142Proof438
  · exact adaptive146Third142Proof439
  · exact adaptive146Third142Proof440
  · exact adaptive146Third142Proof441
  · exact adaptive146Third142Proof442

#print axioms adaptive146Third142Proof402

theorem adaptive146Third142Proof443 : runCachedNode 511 131054 Adaptive146Third142Node443 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 131054 Adaptive146Third142Node443 = [87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 128, 129, 130] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive146Third142Proof444
  · exact adaptive146Third142Proof445
  · exact adaptive146Third142Proof446
  · exact adaptive146Third142Proof447
  · exact adaptive146Third142Proof448
  · exact adaptive146Third142Proof449
  · exact adaptive146Third142Proof450
  · exact adaptive146Third142Proof451
  · exact adaptive146Third142Proof452
  · exact adaptive146Third142Proof453
  · exact adaptive146Third142Proof454
  · exact adaptive146Third142Proof455
  · exact adaptive146Third142Proof456
  · exact adaptive146Third142Proof457
  · exact adaptive146Third142Proof458
  · exact adaptive146Third142Proof459
  · exact adaptive146Third142Proof460
  · exact adaptive146Third142Proof461
  · exact adaptive146Third142Proof462
  · exact adaptive146Third142Proof463
  · exact adaptive146Third142Proof464
  · exact adaptive146Third142Proof465
  · exact adaptive146Third142Proof466
  · exact adaptive146Third142Proof467
  · exact adaptive146Third142Proof468
  · exact adaptive146Third142Proof469
  · exact adaptive146Third142Proof470
  · exact adaptive146Third142Proof471
  · exact adaptive146Third142Proof472
  · exact adaptive146Third142Proof473
  · exact adaptive146Third142Proof474
  · exact adaptive146Third142Proof475
  · exact adaptive146Third142Proof476
  · exact adaptive146Third142Proof477
  · exact adaptive146Third142Proof478
  · exact adaptive146Third142Proof479
  · exact adaptive146Third142Proof480
  · exact adaptive146Third142Proof481
  · exact adaptive146Third142Proof482
  · exact adaptive146Third142Proof483
  · exact adaptive146Third142Proof484
  · exact adaptive146Third142Proof485
  · exact adaptive146Third142Proof486

#print axioms adaptive146Third142Proof443

theorem adaptive146Third142Proof366 : runCachedNode 511 131054 Adaptive146Third142Node366 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 131054 Adaptive146Third142Node366 = [100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 132, 133, 134, 136, 138] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive146Third142Proof367
  · exact adaptive146Third142Proof368
  · exact adaptive146Third142Proof369
  · exact adaptive146Third142Proof370
  · exact adaptive146Third142Proof371
  · exact adaptive146Third142Proof372
  · exact adaptive146Third142Proof373
  · exact adaptive146Third142Proof374
  · exact adaptive146Third142Proof375
  · exact adaptive146Third142Proof376
  · exact adaptive146Third142Proof377
  · exact adaptive146Third142Proof378
  · exact adaptive146Third142Proof379
  · exact adaptive146Third142Proof380
  · exact adaptive146Third142Proof381
  · exact adaptive146Third142Proof382
  · exact adaptive146Third142Proof383
  · exact adaptive146Third142Proof384
  · exact adaptive146Third142Proof385
  · exact adaptive146Third142Proof386
  · exact adaptive146Third142Proof387
  · exact adaptive146Third142Proof388
  · exact adaptive146Third142Proof389
  · exact adaptive146Third142Proof390
  · exact adaptive146Third142Proof391
  · exact adaptive146Third142Proof392
  · exact adaptive146Third142Proof393
  · exact adaptive146Third142Proof394
  · exact adaptive146Third142Proof395
  · exact adaptive146Third142Proof396
  · exact adaptive146Third142Proof397
  · exact adaptive146Third142Proof398
  · exact adaptive146Third142Proof399
  · exact adaptive146Third142Proof400
  · exact adaptive146Third142Proof401
  · exact adaptive146Third142Proof402
  · exact adaptive146Third142Proof443

#print axioms adaptive146Third142Proof366

theorem adaptive146Third142Proof0 : runCachedNode 511 131054 Adaptive146Third142Node0 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 131054 Adaptive146Third142Node0 = [109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 132, 133, 134, 135, 136, 137, 138, 139, 141] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive146Third142Proof1
  · exact adaptive146Third142Proof2
  · exact adaptive146Third142Proof3
  · exact adaptive146Third142Proof4
  · exact adaptive146Third142Proof5
  · exact adaptive146Third142Proof6
  · exact adaptive146Third142Proof7
  · exact adaptive146Third142Proof8
  · exact adaptive146Third142Proof9
  · exact adaptive146Third142Proof10
  · exact adaptive146Third142Proof11
  · exact adaptive146Third142Proof12
  · exact adaptive146Third142Proof13
  · exact adaptive146Third142Proof14
  · exact adaptive146Third142Proof15
  · exact adaptive146Third142Proof16
  · exact adaptive146Third142Proof17
  · exact adaptive146Third142Proof18
  · exact adaptive146Third142Proof19
  · exact adaptive146Third142Proof20
  · exact adaptive146Third142Proof21
  · exact adaptive146Third142Proof22
  · exact adaptive146Third142Proof23
  · exact adaptive146Third142Proof24
  · exact adaptive146Third142Proof25
  · exact adaptive146Third142Proof54
  · exact adaptive146Third142Proof84
  · exact adaptive146Third142Proof115
  · exact adaptive146Third142Proof147
  · exact adaptive146Third142Proof181
  · exact adaptive146Third142Proof289
  · exact adaptive146Third142Proof366

#print axioms adaptive146Third142Proof0

end NineSeparatedSubsetSums
