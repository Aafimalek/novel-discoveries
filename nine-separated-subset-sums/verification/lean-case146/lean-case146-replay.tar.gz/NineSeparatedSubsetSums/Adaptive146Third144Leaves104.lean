import NineSeparatedSubsetSums.Adaptive146Third144State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third144Proof1069 : runCachedNode 511 131319 Adaptive146Third144Node1069 = false := by
  decide +kernel

#print axioms adaptive146Third144Proof1069

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third144Proof1237 : runCachedNode 511 131319 Adaptive146Third144Node1237 = false := by
  decide +kernel

#print axioms adaptive146Third144Proof1237

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third144Proof124 : runCachedNode 511 131319 Adaptive146Third144Node124 = false := by
  decide +kernel

#print axioms adaptive146Third144Proof124

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third144Proof237 : runCachedNode 511 131319 Adaptive146Third144Node237 = false := by
  decide +kernel

#print axioms adaptive146Third144Proof237

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third144Proof681 : runCachedNode 511 131319 Adaptive146Third144Node681 = false := by
  decide +kernel

#print axioms adaptive146Third144Proof681

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third144Proof1238 : runCachedNode 511 131319 Adaptive146Third144Node1238 = false := by
  decide +kernel

#print axioms adaptive146Third144Proof1238

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third144Proof102 : runCachedNode 511 131319 Adaptive146Third144Node102 = false := by
  decide +kernel

#print axioms adaptive146Third144Proof102

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third144Proof892 : runCachedNode 511 131319 Adaptive146Third144Node892 = false := by
  decide +kernel

#print axioms adaptive146Third144Proof892

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third144Proof1458 : runCachedNode 511 131319 Adaptive146Third144Node1458 = false := by
  decide +kernel

#print axioms adaptive146Third144Proof1458

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third144Proof700 : runCachedNode 511 131319 Adaptive146Third144Node700 = false := by
  decide +kernel

#print axioms adaptive146Third144Proof700

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third144Proof735 : runCachedNode 511 131319 Adaptive146Third144Node735 = false := by
  decide +kernel

#print axioms adaptive146Third144Proof735

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third144Proof816 : runCachedNode 511 131319 Adaptive146Third144Node816 = false := by
  decide +kernel

#print axioms adaptive146Third144Proof816

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third144Proof895 : runCachedNode 511 131319 Adaptive146Third144Node895 = false := by
  decide +kernel

#print axioms adaptive146Third144Proof895

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third144Proof1460 : runCachedNode 511 131319 Adaptive146Third144Node1460 = false := by
  decide +kernel

#print axioms adaptive146Third144Proof1460

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third144Proof303 : runCachedNode 511 131319 Adaptive146Third144Node303 = false := by
  decide +kernel

#print axioms adaptive146Third144Proof303

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third144Proof399 : runCachedNode 511 131319 Adaptive146Third144Node399 = false := by
  decide +kernel

#print axioms adaptive146Third144Proof399

end NineSeparatedSubsetSums
