import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive146Third117Node0 : CachedSearchNode :=
  ⟨4, 116, computeCenteredMask [148,146,117], 411, 56909⟩

end NineSeparatedSubsetSums
