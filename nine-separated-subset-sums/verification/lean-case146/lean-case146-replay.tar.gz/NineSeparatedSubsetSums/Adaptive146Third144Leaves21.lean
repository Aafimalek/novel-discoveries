import NineSeparatedSubsetSums.Adaptive146Third144State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third144Proof16 : runCachedNode 511 131319 Adaptive146Third144Node16 = false := by
  decide +kernel

#print axioms adaptive146Third144Proof16

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third144Proof189 : runCachedNode 511 131319 Adaptive146Third144Node189 = false := by
  decide +kernel

#print axioms adaptive146Third144Proof189

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third144Proof495 : runCachedNode 511 131319 Adaptive146Third144Node495 = false := by
  decide +kernel

#print axioms adaptive146Third144Proof495

end NineSeparatedSubsetSums
