import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive146Third103Node0 : CachedSearchNode :=
  ⟨4, 102, computeCenteredMask [148,146,103], 397, 53829⟩

end NineSeparatedSubsetSums
