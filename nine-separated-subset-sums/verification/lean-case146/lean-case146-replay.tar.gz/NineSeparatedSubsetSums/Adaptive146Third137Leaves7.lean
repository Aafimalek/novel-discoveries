import NineSeparatedSubsetSums.Adaptive146Third137State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third137Proof124 : runCachedNode 511 130354 Adaptive146Third137Node124 = false := by
  decide +kernel

#print axioms adaptive146Third137Proof124

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third137Proof181 : runCachedNode 511 130354 Adaptive146Third137Node181 = false := by
  decide +kernel

#print axioms adaptive146Third137Proof181

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third137Proof182 : runCachedNode 511 130354 Adaptive146Third137Node182 = false := by
  decide +kernel

#print axioms adaptive146Third137Proof182

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third137Proof68 : runCachedNode 511 130354 Adaptive146Third137Node68 = false := by
  decide +kernel

#print axioms adaptive146Third137Proof68

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third137Proof62 : runCachedNode 511 130354 Adaptive146Third137Node62 = false := by
  decide +kernel

#print axioms adaptive146Third137Proof62

end NineSeparatedSubsetSums
