import NineSeparatedSubsetSums.Adaptive146Third137State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third137Proof19 : runCachedNode 511 130354 Adaptive146Third137Node19 = false := by
  decide +kernel

#print axioms adaptive146Third137Proof19

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third137Proof147 : runCachedNode 511 130354 Adaptive146Third137Node147 = false := by
  decide +kernel

#print axioms adaptive146Third137Proof147

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third137Proof5 : runCachedNode 511 130354 Adaptive146Third137Node5 = false := by
  decide +kernel

#print axioms adaptive146Third137Proof5

end NineSeparatedSubsetSums
