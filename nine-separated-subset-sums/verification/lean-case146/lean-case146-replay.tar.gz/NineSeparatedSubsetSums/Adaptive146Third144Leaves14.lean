import NineSeparatedSubsetSums.Adaptive146Third144State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third144Proof1291 : runCachedNode 511 131319 Adaptive146Third144Node1291 = false := by
  decide +kernel

#print axioms adaptive146Third144Proof1291

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third144Proof215 : runCachedNode 511 131319 Adaptive146Third144Node215 = false := by
  decide +kernel

#print axioms adaptive146Third144Proof215

end NineSeparatedSubsetSums
