import NineSeparatedSubsetSums.Adaptive146Third142State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third142Proof207 : runCachedNode 511 131054 Adaptive146Third142Node207 = false := by
  decide +kernel

#print axioms adaptive146Third142Proof207

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third142Proof19 : runCachedNode 511 131054 Adaptive146Third142Node19 = false := by
  decide +kernel

#print axioms adaptive146Third142Proof19

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third142Proof249 : runCachedNode 511 131054 Adaptive146Third142Node249 = false := by
  decide +kernel

#print axioms adaptive146Third142Proof249

end NineSeparatedSubsetSums
