import NineSeparatedSubsetSums.Adaptive146Third138State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third138Proof180 : runCachedNode 511 130484 Adaptive146Third138Node180 = false := by
  decide +kernel

#print axioms adaptive146Third138Proof180

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third138Proof66 : runCachedNode 511 130484 Adaptive146Third138Node66 = false := by
  decide +kernel

#print axioms adaptive146Third138Proof66

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third138Proof209 : runCachedNode 511 130484 Adaptive146Third138Node209 = false := by
  decide +kernel

#print axioms adaptive146Third138Proof209

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third138Proof182 : runCachedNode 511 130484 Adaptive146Third138Node182 = false := by
  decide +kernel

#print axioms adaptive146Third138Proof182

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third138Proof93 : runCachedNode 511 130484 Adaptive146Third138Node93 = false := by
  decide +kernel

#print axioms adaptive146Third138Proof93

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third138Proof41 : runCachedNode 511 130484 Adaptive146Third138Node41 = false := by
  decide +kernel

#print axioms adaptive146Third138Proof41

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third138Proof120 : runCachedNode 511 130484 Adaptive146Third138Node120 = false := by
  decide +kernel

#print axioms adaptive146Third138Proof120

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third138Proof202 : runCachedNode 511 130484 Adaptive146Third138Node202 = false := by
  decide +kernel

#print axioms adaptive146Third138Proof202

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third138Proof100 : runCachedNode 511 130484 Adaptive146Third138Node100 = false := by
  decide +kernel

#print axioms adaptive146Third138Proof100

end NineSeparatedSubsetSums
