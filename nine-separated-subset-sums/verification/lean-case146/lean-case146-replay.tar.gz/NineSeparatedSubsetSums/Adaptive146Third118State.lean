import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive146Third118Node0 : CachedSearchNode :=
  ⟨4, 117, computeCenteredMask [148,146,118], 412, 57144⟩

end NineSeparatedSubsetSums
