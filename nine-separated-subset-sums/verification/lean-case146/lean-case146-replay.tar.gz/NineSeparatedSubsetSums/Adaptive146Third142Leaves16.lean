import NineSeparatedSubsetSums.Adaptive146Third142State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third142Proof143 : runCachedNode 511 131054 Adaptive146Third142Node143 = false := by
  decide +kernel

#print axioms adaptive146Third142Proof143

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third142Proof208 : runCachedNode 511 131054 Adaptive146Third142Node208 = false := by
  decide +kernel

#print axioms adaptive146Third142Proof208

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third142Proof205 : runCachedNode 511 131054 Adaptive146Third142Node205 = false := by
  decide +kernel

#print axioms adaptive146Third142Proof205

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third142Proof98 : runCachedNode 511 131054 Adaptive146Third142Node98 = false := by
  decide +kernel

#print axioms adaptive146Third142Proof98

end NineSeparatedSubsetSums
