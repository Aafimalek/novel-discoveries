import NineSeparatedSubsetSums.Adaptive146Third112Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint146Checked

namespace NineSeparatedSubsetSums


theorem adaptive146Third112 : NoDescendingTailAfterThird 146 112 :=
  noDescendingThirdTail_of_cached 146 112 112631 (fun t ht nd => max148_second146_fourPoint_moment_bound (112::t) (by simp [ht]) nd) adaptive146Third112Proof0

#print axioms adaptive146Third112

end NineSeparatedSubsetSums
