import NineSeparatedSubsetSums.Adaptive146Third138State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third138Proof214 : runCachedNode 511 130484 Adaptive146Third138Node214 = false := by
  decide +kernel

#print axioms adaptive146Third138Proof214

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third138Proof153 : runCachedNode 511 130484 Adaptive146Third138Node153 = false := by
  decide +kernel

#print axioms adaptive146Third138Proof153

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third138Proof210 : runCachedNode 511 130484 Adaptive146Third138Node210 = false := by
  decide +kernel

#print axioms adaptive146Third138Proof210

end NineSeparatedSubsetSums
