import NineSeparatedSubsetSums.Adaptive146Third139State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third139Proof215 : runCachedNode 511 130638 Adaptive146Third139Node215 = false := by
  decide +kernel

#print axioms adaptive146Third139Proof215

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third139Proof18 : runCachedNode 511 130638 Adaptive146Third139Node18 = false := by
  decide +kernel

#print axioms adaptive146Third139Proof18

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third139Proof149 : runCachedNode 511 130638 Adaptive146Third139Node149 = false := by
  decide +kernel

#print axioms adaptive146Third139Proof149

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third139Proof131 : runCachedNode 511 130638 Adaptive146Third139Node131 = false := by
  decide +kernel

#print axioms adaptive146Third139Proof131

end NineSeparatedSubsetSums
