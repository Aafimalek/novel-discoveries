import NineSeparatedSubsetSums.Adaptive146Third126State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third126Proof15 : runCachedNode 511 128058 Adaptive146Third126Node15 = false := by
  decide +kernel

#print axioms adaptive146Third126Proof15

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third126Proof13 : runCachedNode 511 128058 Adaptive146Third126Node13 = false := by
  decide +kernel

#print axioms adaptive146Third126Proof13

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third126Proof14 : runCachedNode 511 128058 Adaptive146Third126Node14 = false := by
  decide +kernel

#print axioms adaptive146Third126Proof14

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third126Proof12 : runCachedNode 511 128058 Adaptive146Third126Node12 = false := by
  decide +kernel

#print axioms adaptive146Third126Proof12

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third126Proof11 : runCachedNode 511 128058 Adaptive146Third126Node11 = false := by
  decide +kernel

#print axioms adaptive146Third126Proof11

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third126Proof10 : runCachedNode 511 128058 Adaptive146Third126Node10 = false := by
  decide +kernel

#print axioms adaptive146Third126Proof10

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third126Proof9 : runCachedNode 511 128058 Adaptive146Third126Node9 = false := by
  decide +kernel

#print axioms adaptive146Third126Proof9

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third126Proof8 : runCachedNode 511 128058 Adaptive146Third126Node8 = false := by
  decide +kernel

#print axioms adaptive146Third126Proof8

end NineSeparatedSubsetSums
