import NineSeparatedSubsetSums.Adaptive146Third129State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third129Proof18 : runCachedNode 511 128829 Adaptive146Third129Node18 = false := by
  decide +kernel

#print axioms adaptive146Third129Proof18

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third129Proof16 : runCachedNode 511 128829 Adaptive146Third129Node16 = false := by
  decide +kernel

#print axioms adaptive146Third129Proof16

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third129Proof15 : runCachedNode 511 128829 Adaptive146Third129Node15 = false := by
  decide +kernel

#print axioms adaptive146Third129Proof15

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third129Proof5 : runCachedNode 511 128829 Adaptive146Third129Node5 = false := by
  decide +kernel

#print axioms adaptive146Third129Proof5

end NineSeparatedSubsetSums
