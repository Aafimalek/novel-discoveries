import NineSeparatedSubsetSums.Adaptive146Third128State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third128Proof17 : runCachedNode 511 128614 Adaptive146Third128Node17 = false := by
  decide +kernel

#print axioms adaptive146Third128Proof17

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third128Proof15 : runCachedNode 511 128614 Adaptive146Third128Node15 = false := by
  decide +kernel

#print axioms adaptive146Third128Proof15

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third128Proof16 : runCachedNode 511 128614 Adaptive146Third128Node16 = false := by
  decide +kernel

#print axioms adaptive146Third128Proof16

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third128Proof13 : runCachedNode 511 128614 Adaptive146Third128Node13 = false := by
  decide +kernel

#print axioms adaptive146Third128Proof13

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third128Proof4 : runCachedNode 511 128614 Adaptive146Third128Node4 = false := by
  decide +kernel

#print axioms adaptive146Third128Proof4

end NineSeparatedSubsetSums
