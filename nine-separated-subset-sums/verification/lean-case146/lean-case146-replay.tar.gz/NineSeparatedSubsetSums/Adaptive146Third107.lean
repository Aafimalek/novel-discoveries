import NineSeparatedSubsetSums.Adaptive146Third107Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint146Checked

namespace NineSeparatedSubsetSums


theorem adaptive146Third107 : NoDescendingTailAfterThird 146 107 :=
  noDescendingThirdTail_of_cached 146 107 112631 (fun t ht nd => max148_second146_fourPoint_moment_bound (107::t) (by simp [ht]) nd) adaptive146Third107Proof0

#print axioms adaptive146Third107

end NineSeparatedSubsetSums
