import NineSeparatedSubsetSums.Adaptive146Third143State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third143Proof265 : runCachedNode 511 131193 Adaptive146Third143Node265 = false := by
  decide +kernel

#print axioms adaptive146Third143Proof265

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third143Proof500 : runCachedNode 511 131193 Adaptive146Third143Node500 = false := by
  decide +kernel

#print axioms adaptive146Third143Proof500

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third143Proof59 : runCachedNode 511 131193 Adaptive146Third143Node59 = false := by
  decide +kernel

#print axioms adaptive146Third143Proof59

end NineSeparatedSubsetSums
