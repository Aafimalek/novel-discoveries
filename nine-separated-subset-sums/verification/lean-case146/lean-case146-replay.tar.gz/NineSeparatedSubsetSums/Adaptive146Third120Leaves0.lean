import NineSeparatedSubsetSums.Adaptive146Third120State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third120Proof0 : runCachedNode 511 126551 Adaptive146Third120Node0 = false := by
  decide +kernel

#print axioms adaptive146Third120Proof0

end NineSeparatedSubsetSums
