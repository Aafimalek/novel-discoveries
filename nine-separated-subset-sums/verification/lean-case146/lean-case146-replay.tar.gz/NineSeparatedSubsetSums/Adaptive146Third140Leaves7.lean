import NineSeparatedSubsetSums.Adaptive146Third140State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third140Proof217 : runCachedNode 511 130775 Adaptive146Third140Node217 = false := by
  decide +kernel

#print axioms adaptive146Third140Proof217

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third140Proof18 : runCachedNode 511 130775 Adaptive146Third140Node18 = false := by
  decide +kernel

#print axioms adaptive146Third140Proof18

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third140Proof60 : runCachedNode 511 130775 Adaptive146Third140Node60 = false := by
  decide +kernel

#print axioms adaptive146Third140Proof60

end NineSeparatedSubsetSums
