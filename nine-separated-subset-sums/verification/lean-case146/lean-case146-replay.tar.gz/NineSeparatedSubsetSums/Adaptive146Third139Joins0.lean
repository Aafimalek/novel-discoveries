import NineSeparatedSubsetSums.Adaptive146Third139State
import NineSeparatedSubsetSums.Adaptive146Third139Leaves12
import NineSeparatedSubsetSums.Adaptive146Third139Leaves23
import NineSeparatedSubsetSums.Adaptive146Third139Leaves22
import NineSeparatedSubsetSums.Adaptive146Third139Leaves10
import NineSeparatedSubsetSums.Adaptive146Third139Leaves21
import NineSeparatedSubsetSums.Adaptive146Third139Leaves20
import NineSeparatedSubsetSums.Adaptive146Third139Leaves18
import NineSeparatedSubsetSums.Adaptive146Third139Leaves19
import NineSeparatedSubsetSums.Adaptive146Third139Leaves16
import NineSeparatedSubsetSums.Adaptive146Third139Leaves15
import NineSeparatedSubsetSums.Adaptive146Third139Leaves5
import NineSeparatedSubsetSums.Adaptive146Third139Leaves0
import NineSeparatedSubsetSums.Adaptive146Third139Leaves2
import NineSeparatedSubsetSums.Adaptive146Third139Leaves14
import NineSeparatedSubsetSums.Adaptive146Third139Leaves7
import NineSeparatedSubsetSums.Adaptive146Third139Leaves17
import NineSeparatedSubsetSums.Adaptive146Third139Leaves24
import NineSeparatedSubsetSums.Adaptive146Third139Leaves1
import NineSeparatedSubsetSums.Adaptive146Third139Leaves11
import NineSeparatedSubsetSums.Adaptive146Third139Leaves13
import NineSeparatedSubsetSums.Adaptive146Third139Leaves9
import NineSeparatedSubsetSums.Adaptive146Third139Leaves6
import NineSeparatedSubsetSums.Adaptive146Third139Leaves8
import NineSeparatedSubsetSums.Adaptive146Third139Leaves4
import NineSeparatedSubsetSums.Adaptive146Third139Leaves3

namespace NineSeparatedSubsetSums

theorem adaptive146Third139Proof21 : runCachedNode 511 130638 Adaptive146Third139Node21 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130638 Adaptive146Third139Node21 = [104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 122, 124, 125, 126, 127, 129] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive146Third139Proof22
  · exact adaptive146Third139Proof23
  · exact adaptive146Third139Proof24
  · exact adaptive146Third139Proof25
  · exact adaptive146Third139Proof26
  · exact adaptive146Third139Proof27
  · exact adaptive146Third139Proof28
  · exact adaptive146Third139Proof29
  · exact adaptive146Third139Proof30
  · exact adaptive146Third139Proof31
  · exact adaptive146Third139Proof32
  · exact adaptive146Third139Proof33
  · exact adaptive146Third139Proof34
  · exact adaptive146Third139Proof35
  · exact adaptive146Third139Proof36
  · exact adaptive146Third139Proof37
  · exact adaptive146Third139Proof38
  · exact adaptive146Third139Proof39
  · exact adaptive146Third139Proof40
  · exact adaptive146Third139Proof41
  · exact adaptive146Third139Proof42
  · exact adaptive146Third139Proof43
  · exact adaptive146Third139Proof44

#print axioms adaptive146Third139Proof21

theorem adaptive146Third139Proof45 : runCachedNode 511 130638 Adaptive146Third139Node45 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130638 Adaptive146Third139Node45 = [103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 123, 125, 126, 127, 128, 130] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive146Third139Proof46
  · exact adaptive146Third139Proof47
  · exact adaptive146Third139Proof48
  · exact adaptive146Third139Proof49
  · exact adaptive146Third139Proof50
  · exact adaptive146Third139Proof51
  · exact adaptive146Third139Proof52
  · exact adaptive146Third139Proof53
  · exact adaptive146Third139Proof54
  · exact adaptive146Third139Proof55
  · exact adaptive146Third139Proof56
  · exact adaptive146Third139Proof57
  · exact adaptive146Third139Proof58
  · exact adaptive146Third139Proof59
  · exact adaptive146Third139Proof60
  · exact adaptive146Third139Proof61
  · exact adaptive146Third139Proof62
  · exact adaptive146Third139Proof63
  · exact adaptive146Third139Proof64
  · exact adaptive146Third139Proof65
  · exact adaptive146Third139Proof66
  · exact adaptive146Third139Proof67
  · exact adaptive146Third139Proof68
  · exact adaptive146Third139Proof69
  · exact adaptive146Third139Proof70

#print axioms adaptive146Third139Proof45

theorem adaptive146Third139Proof71 : runCachedNode 511 130638 Adaptive146Third139Node71 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130638 Adaptive146Third139Node71 = [103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 124, 126, 127, 128, 129, 131] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive146Third139Proof72
  · exact adaptive146Third139Proof73
  · exact adaptive146Third139Proof74
  · exact adaptive146Third139Proof75
  · exact adaptive146Third139Proof76
  · exact adaptive146Third139Proof77
  · exact adaptive146Third139Proof78
  · exact adaptive146Third139Proof79
  · exact adaptive146Third139Proof80
  · exact adaptive146Third139Proof81
  · exact adaptive146Third139Proof82
  · exact adaptive146Third139Proof83
  · exact adaptive146Third139Proof84
  · exact adaptive146Third139Proof85
  · exact adaptive146Third139Proof86
  · exact adaptive146Third139Proof87
  · exact adaptive146Third139Proof88
  · exact adaptive146Third139Proof89
  · exact adaptive146Third139Proof90
  · exact adaptive146Third139Proof91
  · exact adaptive146Third139Proof92
  · exact adaptive146Third139Proof93
  · exact adaptive146Third139Proof94
  · exact adaptive146Third139Proof95
  · exact adaptive146Third139Proof96
  · exact adaptive146Third139Proof97

#print axioms adaptive146Third139Proof71

theorem adaptive146Third139Proof98 : runCachedNode 511 130638 Adaptive146Third139Node98 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130638 Adaptive146Third139Node98 = [103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 125, 127, 128, 129, 130, 132] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive146Third139Proof99
  · exact adaptive146Third139Proof100
  · exact adaptive146Third139Proof101
  · exact adaptive146Third139Proof102
  · exact adaptive146Third139Proof103
  · exact adaptive146Third139Proof104
  · exact adaptive146Third139Proof105
  · exact adaptive146Third139Proof106
  · exact adaptive146Third139Proof107
  · exact adaptive146Third139Proof108
  · exact adaptive146Third139Proof109
  · exact adaptive146Third139Proof110
  · exact adaptive146Third139Proof111
  · exact adaptive146Third139Proof112
  · exact adaptive146Third139Proof113
  · exact adaptive146Third139Proof114
  · exact adaptive146Third139Proof115
  · exact adaptive146Third139Proof116
  · exact adaptive146Third139Proof117
  · exact adaptive146Third139Proof118
  · exact adaptive146Third139Proof119
  · exact adaptive146Third139Proof120
  · exact adaptive146Third139Proof121
  · exact adaptive146Third139Proof122
  · exact adaptive146Third139Proof123
  · exact adaptive146Third139Proof124
  · exact adaptive146Third139Proof125

#print axioms adaptive146Third139Proof98

theorem adaptive146Third139Proof126 : runCachedNode 511 130638 Adaptive146Third139Node126 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130638 Adaptive146Third139Node126 = [103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 126, 128, 129, 130, 131, 133] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive146Third139Proof127
  · exact adaptive146Third139Proof128
  · exact adaptive146Third139Proof129
  · exact adaptive146Third139Proof130
  · exact adaptive146Third139Proof131
  · exact adaptive146Third139Proof132
  · exact adaptive146Third139Proof133
  · exact adaptive146Third139Proof134
  · exact adaptive146Third139Proof135
  · exact adaptive146Third139Proof136
  · exact adaptive146Third139Proof137
  · exact adaptive146Third139Proof138
  · exact adaptive146Third139Proof139
  · exact adaptive146Third139Proof140
  · exact adaptive146Third139Proof141
  · exact adaptive146Third139Proof142
  · exact adaptive146Third139Proof143
  · exact adaptive146Third139Proof144
  · exact adaptive146Third139Proof145
  · exact adaptive146Third139Proof146
  · exact adaptive146Third139Proof147
  · exact adaptive146Third139Proof148
  · exact adaptive146Third139Proof149
  · exact adaptive146Third139Proof150
  · exact adaptive146Third139Proof151
  · exact adaptive146Third139Proof152
  · exact adaptive146Third139Proof153
  · exact adaptive146Third139Proof154

#print axioms adaptive146Third139Proof126

theorem adaptive146Third139Proof155 : runCachedNode 511 130638 Adaptive146Third139Node155 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130638 Adaptive146Third139Node155 = [102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 127, 129, 130, 131, 132, 134] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive146Third139Proof156
  · exact adaptive146Third139Proof157
  · exact adaptive146Third139Proof158
  · exact adaptive146Third139Proof159
  · exact adaptive146Third139Proof160
  · exact adaptive146Third139Proof161
  · exact adaptive146Third139Proof162
  · exact adaptive146Third139Proof163
  · exact adaptive146Third139Proof164
  · exact adaptive146Third139Proof165
  · exact adaptive146Third139Proof166
  · exact adaptive146Third139Proof167
  · exact adaptive146Third139Proof168
  · exact adaptive146Third139Proof169
  · exact adaptive146Third139Proof170
  · exact adaptive146Third139Proof171
  · exact adaptive146Third139Proof172
  · exact adaptive146Third139Proof173
  · exact adaptive146Third139Proof174
  · exact adaptive146Third139Proof175
  · exact adaptive146Third139Proof176
  · exact adaptive146Third139Proof177
  · exact adaptive146Third139Proof178
  · exact adaptive146Third139Proof179
  · exact adaptive146Third139Proof180
  · exact adaptive146Third139Proof181
  · exact adaptive146Third139Proof182
  · exact adaptive146Third139Proof183
  · exact adaptive146Third139Proof184
  · exact adaptive146Third139Proof185

#print axioms adaptive146Third139Proof155

theorem adaptive146Third139Proof186 : runCachedNode 511 130638 Adaptive146Third139Node186 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130638 Adaptive146Third139Node186 = [102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 128, 130, 131, 132, 133, 135] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive146Third139Proof187
  · exact adaptive146Third139Proof188
  · exact adaptive146Third139Proof189
  · exact adaptive146Third139Proof190
  · exact adaptive146Third139Proof191
  · exact adaptive146Third139Proof192
  · exact adaptive146Third139Proof193
  · exact adaptive146Third139Proof194
  · exact adaptive146Third139Proof195
  · exact adaptive146Third139Proof196
  · exact adaptive146Third139Proof197
  · exact adaptive146Third139Proof198
  · exact adaptive146Third139Proof199
  · exact adaptive146Third139Proof200
  · exact adaptive146Third139Proof201
  · exact adaptive146Third139Proof202
  · exact adaptive146Third139Proof203
  · exact adaptive146Third139Proof204
  · exact adaptive146Third139Proof205
  · exact adaptive146Third139Proof206
  · exact adaptive146Third139Proof207
  · exact adaptive146Third139Proof208
  · exact adaptive146Third139Proof209
  · exact adaptive146Third139Proof210
  · exact adaptive146Third139Proof211
  · exact adaptive146Third139Proof212
  · exact adaptive146Third139Proof213
  · exact adaptive146Third139Proof214
  · exact adaptive146Third139Proof215
  · exact adaptive146Third139Proof216
  · exact adaptive146Third139Proof217

#print axioms adaptive146Third139Proof186

theorem adaptive146Third139Proof218 : runCachedNode 511 130638 Adaptive146Third139Node218 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130638 Adaptive146Third139Node218 = [102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 130, 132, 133, 134, 135] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive146Third139Proof219
  · exact adaptive146Third139Proof220
  · exact adaptive146Third139Proof221
  · exact adaptive146Third139Proof222
  · exact adaptive146Third139Proof223
  · exact adaptive146Third139Proof224
  · exact adaptive146Third139Proof225
  · exact adaptive146Third139Proof226
  · exact adaptive146Third139Proof227
  · exact adaptive146Third139Proof228
  · exact adaptive146Third139Proof229
  · exact adaptive146Third139Proof230
  · exact adaptive146Third139Proof231
  · exact adaptive146Third139Proof232
  · exact adaptive146Third139Proof233
  · exact adaptive146Third139Proof234
  · exact adaptive146Third139Proof235
  · exact adaptive146Third139Proof236
  · exact adaptive146Third139Proof237
  · exact adaptive146Third139Proof238
  · exact adaptive146Third139Proof239
  · exact adaptive146Third139Proof240
  · exact adaptive146Third139Proof241
  · exact adaptive146Third139Proof242
  · exact adaptive146Third139Proof243
  · exact adaptive146Third139Proof244
  · exact adaptive146Third139Proof245
  · exact adaptive146Third139Proof246
  · exact adaptive146Third139Proof247
  · exact adaptive146Third139Proof248
  · exact adaptive146Third139Proof249
  · exact adaptive146Third139Proof250

#print axioms adaptive146Third139Proof218

end NineSeparatedSubsetSums
