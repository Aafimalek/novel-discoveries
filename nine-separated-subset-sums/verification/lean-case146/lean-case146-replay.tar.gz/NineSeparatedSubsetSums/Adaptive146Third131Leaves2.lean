import NineSeparatedSubsetSums.Adaptive146Third131State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third131Proof17 : runCachedNode 511 129268 Adaptive146Third131Node17 = false := by
  decide +kernel

#print axioms adaptive146Third131Proof17

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third131Proof15 : runCachedNode 511 129268 Adaptive146Third131Node15 = false := by
  decide +kernel

#print axioms adaptive146Third131Proof15

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third131Proof14 : runCachedNode 511 129268 Adaptive146Third131Node14 = false := by
  decide +kernel

#print axioms adaptive146Third131Proof14

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third131Proof13 : runCachedNode 511 129268 Adaptive146Third131Node13 = false := by
  decide +kernel

#print axioms adaptive146Third131Proof13

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third131Proof12 : runCachedNode 511 129268 Adaptive146Third131Node12 = false := by
  decide +kernel

#print axioms adaptive146Third131Proof12

end NineSeparatedSubsetSums
