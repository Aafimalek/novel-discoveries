import NineSeparatedSubsetSums.Adaptive146Third140State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third140Proof21 : runCachedNode 511 130775 Adaptive146Third140Node21 = false := by
  decide +kernel

#print axioms adaptive146Third140Proof21

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third140Proof314 : runCachedNode 511 130775 Adaptive146Third140Node314 = false := by
  decide +kernel

#print axioms adaptive146Third140Proof314

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third140Proof132 : runCachedNode 511 130775 Adaptive146Third140Node132 = false := by
  decide +kernel

#print axioms adaptive146Third140Proof132

end NineSeparatedSubsetSums
