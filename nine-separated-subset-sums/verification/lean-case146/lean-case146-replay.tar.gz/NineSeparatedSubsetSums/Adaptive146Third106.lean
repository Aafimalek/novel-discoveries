import NineSeparatedSubsetSums.Adaptive146Third106Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint146Checked

namespace NineSeparatedSubsetSums


theorem adaptive146Third106 : NoDescendingTailAfterThird 146 106 :=
  noDescendingThirdTail_of_cached 146 106 112631 (fun t ht nd => max148_second146_fourPoint_moment_bound (106::t) (by simp [ht]) nd) adaptive146Third106Proof0

#print axioms adaptive146Third106

end NineSeparatedSubsetSums
