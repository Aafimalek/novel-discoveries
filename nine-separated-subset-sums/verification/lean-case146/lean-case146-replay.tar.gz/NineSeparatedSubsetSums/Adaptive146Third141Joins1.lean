import NineSeparatedSubsetSums.Adaptive146Third141State
import NineSeparatedSubsetSums.Adaptive146Third141Leaves21
import NineSeparatedSubsetSums.Adaptive146Third141Leaves22
import NineSeparatedSubsetSums.Adaptive146Third141Leaves35
import NineSeparatedSubsetSums.Adaptive146Third141Leaves34
import NineSeparatedSubsetSums.Adaptive146Third141Leaves33
import NineSeparatedSubsetSums.Adaptive146Third141Leaves32
import NineSeparatedSubsetSums.Adaptive146Third141Leaves31
import NineSeparatedSubsetSums.Adaptive146Third141Leaves30
import NineSeparatedSubsetSums.Adaptive146Third141Leaves29
import NineSeparatedSubsetSums.Adaptive146Third141Leaves27
import NineSeparatedSubsetSums.Adaptive146Third141Leaves26
import NineSeparatedSubsetSums.Adaptive146Third141Leaves24
import NineSeparatedSubsetSums.Adaptive146Third141Leaves5
import NineSeparatedSubsetSums.Adaptive146Third141Leaves25
import NineSeparatedSubsetSums.Adaptive146Third141Leaves20
import NineSeparatedSubsetSums.Adaptive146Third141Leaves14
import NineSeparatedSubsetSums.Adaptive146Third141Leaves3
import NineSeparatedSubsetSums.Adaptive146Third141Joins0
import NineSeparatedSubsetSums.Adaptive146Third141Leaves6
import NineSeparatedSubsetSums.Adaptive146Third141Leaves17
import NineSeparatedSubsetSums.Adaptive146Third141Leaves7
import NineSeparatedSubsetSums.Adaptive146Third141Leaves12
import NineSeparatedSubsetSums.Adaptive146Third141Leaves1
import NineSeparatedSubsetSums.Adaptive146Third141Leaves28
import NineSeparatedSubsetSums.Adaptive146Third141Leaves19
import NineSeparatedSubsetSums.Adaptive146Third141Leaves13
import NineSeparatedSubsetSums.Adaptive146Third141Leaves16
import NineSeparatedSubsetSums.Adaptive146Third141Leaves11

namespace NineSeparatedSubsetSums

theorem adaptive146Third141Proof240 : runCachedNode 511 130916 Adaptive146Third141Node240 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130916 Adaptive146Third141Node240 = [101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 132, 134, 136, 137] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive146Third141Proof241
  · exact adaptive146Third141Proof242
  · exact adaptive146Third141Proof243
  · exact adaptive146Third141Proof244
  · exact adaptive146Third141Proof245
  · exact adaptive146Third141Proof246
  · exact adaptive146Third141Proof247
  · exact adaptive146Third141Proof248
  · exact adaptive146Third141Proof249
  · exact adaptive146Third141Proof250
  · exact adaptive146Third141Proof251
  · exact adaptive146Third141Proof252
  · exact adaptive146Third141Proof253
  · exact adaptive146Third141Proof254
  · exact adaptive146Third141Proof255
  · exact adaptive146Third141Proof256
  · exact adaptive146Third141Proof257
  · exact adaptive146Third141Proof258
  · exact adaptive146Third141Proof259
  · exact adaptive146Third141Proof260
  · exact adaptive146Third141Proof261
  · exact adaptive146Third141Proof262
  · exact adaptive146Third141Proof263
  · exact adaptive146Third141Proof264
  · exact adaptive146Third141Proof265
  · exact adaptive146Third141Proof266
  · exact adaptive146Third141Proof267
  · exact adaptive146Third141Proof268
  · exact adaptive146Third141Proof269
  · exact adaptive146Third141Proof270
  · exact adaptive146Third141Proof271
  · exact adaptive146Third141Proof272
  · exact adaptive146Third141Proof273
  · exact adaptive146Third141Proof274
  · exact adaptive146Third141Proof315

#print axioms adaptive146Third141Proof240

theorem adaptive146Third141Proof0 : runCachedNode 511 130916 Adaptive146Third141Node0 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130916 Adaptive146Third141Node0 = [109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 132, 133, 134, 135, 136, 137, 138, 140] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive146Third141Proof1
  · exact adaptive146Third141Proof2
  · exact adaptive146Third141Proof3
  · exact adaptive146Third141Proof4
  · exact adaptive146Third141Proof5
  · exact adaptive146Third141Proof6
  · exact adaptive146Third141Proof7
  · exact adaptive146Third141Proof8
  · exact adaptive146Third141Proof9
  · exact adaptive146Third141Proof10
  · exact adaptive146Third141Proof11
  · exact adaptive146Third141Proof12
  · exact adaptive146Third141Proof13
  · exact adaptive146Third141Proof14
  · exact adaptive146Third141Proof15
  · exact adaptive146Third141Proof16
  · exact adaptive146Third141Proof17
  · exact adaptive146Third141Proof18
  · exact adaptive146Third141Proof19
  · exact adaptive146Third141Proof20
  · exact adaptive146Third141Proof21
  · exact adaptive146Third141Proof22
  · exact adaptive146Third141Proof23
  · exact adaptive146Third141Proof24
  · exact adaptive146Third141Proof51
  · exact adaptive146Third141Proof79
  · exact adaptive146Third141Proof109
  · exact adaptive146Third141Proof140
  · exact adaptive146Third141Proof172
  · exact adaptive146Third141Proof205
  · exact adaptive146Third141Proof240

#print axioms adaptive146Third141Proof0

end NineSeparatedSubsetSums
