import NineSeparatedSubsetSums.Adaptive146Third142State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third142Proof177 : runCachedNode 511 131054 Adaptive146Third142Node177 = false := by
  decide +kernel

#print axioms adaptive146Third142Proof177

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third142Proof175 : runCachedNode 511 131054 Adaptive146Third142Node175 = false := by
  decide +kernel

#print axioms adaptive146Third142Proof175

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third142Proof321 : runCachedNode 511 131054 Adaptive146Third142Node321 = false := by
  decide +kernel

#print axioms adaptive146Third142Proof321

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third142Proof141 : runCachedNode 511 131054 Adaptive146Third142Node141 = false := by
  decide +kernel

#print axioms adaptive146Third142Proof141

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third142Proof254 : runCachedNode 511 131054 Adaptive146Third142Node254 = false := by
  decide +kernel

#print axioms adaptive146Third142Proof254

end NineSeparatedSubsetSums
