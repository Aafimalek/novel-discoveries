import NineSeparatedSubsetSums.Adaptive146Third131State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third131Proof19 : runCachedNode 511 129268 Adaptive146Third131Node19 = false := by
  decide +kernel

#print axioms adaptive146Third131Proof19

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third131Proof18 : runCachedNode 511 129268 Adaptive146Third131Node18 = false := by
  decide +kernel

#print axioms adaptive146Third131Proof18

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third131Proof5 : runCachedNode 511 129268 Adaptive146Third131Node5 = false := by
  decide +kernel

#print axioms adaptive146Third131Proof5

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third131Proof4 : runCachedNode 511 129268 Adaptive146Third131Node4 = false := by
  decide +kernel

#print axioms adaptive146Third131Proof4

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third131Proof3 : runCachedNode 511 129268 Adaptive146Third131Node3 = false := by
  decide +kernel

#print axioms adaptive146Third131Proof3

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third131Proof2 : runCachedNode 511 129268 Adaptive146Third131Node2 = false := by
  decide +kernel

#print axioms adaptive146Third131Proof2

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third131Proof1 : runCachedNode 511 129268 Adaptive146Third131Node1 = false := by
  decide +kernel

#print axioms adaptive146Third131Proof1

end NineSeparatedSubsetSums
