import NineSeparatedSubsetSums.Adaptive146Third124State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third124Proof0 : runCachedNode 511 127488 Adaptive146Third124Node0 = false := by
  decide +kernel

#print axioms adaptive146Third124Proof0

end NineSeparatedSubsetSums
