import NineSeparatedSubsetSums.Adaptive146Third144State
import NineSeparatedSubsetSums.Adaptive146Third144Leaves130
import NineSeparatedSubsetSums.Adaptive146Third144Leaves129
import NineSeparatedSubsetSums.Adaptive146Third144Leaves96
import NineSeparatedSubsetSums.Adaptive146Third144Leaves43
import NineSeparatedSubsetSums.Adaptive146Third144Leaves123
import NineSeparatedSubsetSums.Adaptive146Third144Leaves122
import NineSeparatedSubsetSums.Adaptive146Third144Leaves121
import NineSeparatedSubsetSums.Adaptive146Third144Leaves120
import NineSeparatedSubsetSums.Adaptive146Third144Leaves119
import NineSeparatedSubsetSums.Adaptive146Third144Leaves116
import NineSeparatedSubsetSums.Adaptive146Third144Leaves112
import NineSeparatedSubsetSums.Adaptive146Third144Leaves110
import NineSeparatedSubsetSums.Adaptive146Third144Leaves104
import NineSeparatedSubsetSums.Adaptive146Third144Leaves105
import NineSeparatedSubsetSums.Adaptive146Third144Leaves92
import NineSeparatedSubsetSums.Adaptive146Third144Leaves95
import NineSeparatedSubsetSums.Adaptive146Third144Leaves77
import NineSeparatedSubsetSums.Adaptive146Third144Leaves85
import NineSeparatedSubsetSums.Adaptive146Third144Leaves59
import NineSeparatedSubsetSums.Adaptive146Third144Leaves75
import NineSeparatedSubsetSums.Adaptive146Third144Leaves62
import NineSeparatedSubsetSums.Adaptive146Third144Leaves66
import NineSeparatedSubsetSums.Adaptive146Third144Leaves40
import NineSeparatedSubsetSums.Adaptive146Third144Leaves24
import NineSeparatedSubsetSums.Adaptive146Third144Leaves10
import NineSeparatedSubsetSums.Adaptive146Third144Leaves48
import NineSeparatedSubsetSums.Adaptive146Third144Leaves27
import NineSeparatedSubsetSums.Adaptive146Third144Leaves127
import NineSeparatedSubsetSums.Adaptive146Third144Leaves64
import NineSeparatedSubsetSums.Adaptive146Third144Leaves117
import NineSeparatedSubsetSums.Adaptive146Third144Leaves113
import NineSeparatedSubsetSums.Adaptive146Third144Leaves106
import NineSeparatedSubsetSums.Adaptive146Third144Leaves107
import NineSeparatedSubsetSums.Adaptive146Third144Leaves98
import NineSeparatedSubsetSums.Adaptive146Third144Leaves87
import NineSeparatedSubsetSums.Adaptive146Third144Leaves89
import NineSeparatedSubsetSums.Adaptive146Third144Leaves72
import NineSeparatedSubsetSums.Adaptive146Third144Leaves81
import NineSeparatedSubsetSums.Adaptive146Third144Leaves55
import NineSeparatedSubsetSums.Adaptive146Third144Leaves52
import NineSeparatedSubsetSums.Adaptive146Third144Leaves49
import NineSeparatedSubsetSums.Adaptive146Third144Leaves45
import NineSeparatedSubsetSums.Adaptive146Third144Leaves25
import NineSeparatedSubsetSums.Adaptive146Third144Leaves38
import NineSeparatedSubsetSums.Adaptive146Third144Leaves32
import NineSeparatedSubsetSums.Adaptive146Third144Leaves22
import NineSeparatedSubsetSums.Adaptive146Third144Leaves128
import NineSeparatedSubsetSums.Adaptive146Third144Leaves126
import NineSeparatedSubsetSums.Adaptive146Third144Leaves58
import NineSeparatedSubsetSums.Adaptive146Third144Leaves124
import NineSeparatedSubsetSums.Adaptive146Third144Leaves118
import NineSeparatedSubsetSums.Adaptive146Third144Leaves102
import NineSeparatedSubsetSums.Adaptive146Third144Leaves99
import NineSeparatedSubsetSums.Adaptive146Third144Leaves91
import NineSeparatedSubsetSums.Adaptive146Third144Leaves103
import NineSeparatedSubsetSums.Adaptive146Third144Leaves100
import NineSeparatedSubsetSums.Adaptive146Third144Leaves97
import NineSeparatedSubsetSums.Adaptive146Third144Leaves94
import NineSeparatedSubsetSums.Adaptive146Third144Leaves65
import NineSeparatedSubsetSums.Adaptive146Third144Leaves114
import NineSeparatedSubsetSums.Adaptive146Third144Leaves108
import NineSeparatedSubsetSums.Adaptive146Third144Leaves88
import NineSeparatedSubsetSums.Adaptive146Third144Leaves9
import NineSeparatedSubsetSums.Adaptive146Third144Leaves83
import NineSeparatedSubsetSums.Adaptive146Third144Leaves29
import NineSeparatedSubsetSums.Adaptive146Third144Leaves12
import NineSeparatedSubsetSums.Adaptive146Third144Leaves42
import NineSeparatedSubsetSums.Adaptive146Third144Leaves41
import NineSeparatedSubsetSums.Adaptive146Third144Leaves109
import NineSeparatedSubsetSums.Adaptive146Third144Leaves80
import NineSeparatedSubsetSums.Adaptive146Third144Leaves86
import NineSeparatedSubsetSums.Adaptive146Third144Leaves54
import NineSeparatedSubsetSums.Adaptive146Third144Leaves74
import NineSeparatedSubsetSums.Adaptive146Third144Leaves47
import NineSeparatedSubsetSums.Adaptive146Third144Leaves68
import NineSeparatedSubsetSums.Adaptive146Third144Leaves28
import NineSeparatedSubsetSums.Adaptive146Third144Leaves34
import NineSeparatedSubsetSums.Adaptive146Third144Leaves17
import NineSeparatedSubsetSums.Adaptive146Third144Leaves7
import NineSeparatedSubsetSums.Adaptive146Third144Leaves8
import NineSeparatedSubsetSums.Adaptive146Third144Leaves15
import NineSeparatedSubsetSums.Adaptive146Third144Leaves131
import NineSeparatedSubsetSums.Adaptive146Third144Leaves125
import NineSeparatedSubsetSums.Adaptive146Third144Leaves111
import NineSeparatedSubsetSums.Adaptive146Third144Leaves1
import NineSeparatedSubsetSums.Adaptive146Third144Leaves93
import NineSeparatedSubsetSums.Adaptive146Third144Leaves82
import NineSeparatedSubsetSums.Adaptive146Third144Leaves90
import NineSeparatedSubsetSums.Adaptive146Third144Leaves69
import NineSeparatedSubsetSums.Adaptive146Third144Leaves46
import NineSeparatedSubsetSums.Adaptive146Third144Leaves84
import NineSeparatedSubsetSums.Adaptive146Third144Leaves78
import NineSeparatedSubsetSums.Adaptive146Third144Leaves4
import NineSeparatedSubsetSums.Adaptive146Third144Leaves11
import NineSeparatedSubsetSums.Adaptive146Third144Leaves21
import NineSeparatedSubsetSums.Adaptive146Third144Leaves30
import NineSeparatedSubsetSums.Adaptive146Third144Leaves33
import NineSeparatedSubsetSums.Adaptive146Third144Leaves115
import NineSeparatedSubsetSums.Adaptive146Third144Leaves101

namespace NineSeparatedSubsetSums

theorem adaptive146Third144Proof222 : runCachedNode 511 131319 Adaptive146Third144Node222 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 131319 Adaptive146Third144Node222 = [102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 131, 133] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive146Third144Proof223
  · exact adaptive146Third144Proof224
  · exact adaptive146Third144Proof225
  · exact adaptive146Third144Proof226
  · exact adaptive146Third144Proof227
  · exact adaptive146Third144Proof228
  · exact adaptive146Third144Proof229
  · exact adaptive146Third144Proof230
  · exact adaptive146Third144Proof231
  · exact adaptive146Third144Proof232
  · exact adaptive146Third144Proof233
  · exact adaptive146Third144Proof234
  · exact adaptive146Third144Proof235
  · exact adaptive146Third144Proof236
  · exact adaptive146Third144Proof237
  · exact adaptive146Third144Proof238
  · exact adaptive146Third144Proof239
  · exact adaptive146Third144Proof240
  · exact adaptive146Third144Proof241
  · exact adaptive146Third144Proof242
  · exact adaptive146Third144Proof243
  · exact adaptive146Third144Proof244
  · exact adaptive146Third144Proof245
  · exact adaptive146Third144Proof246
  · exact adaptive146Third144Proof247
  · exact adaptive146Third144Proof248
  · exact adaptive146Third144Proof249
  · exact adaptive146Third144Proof250
  · exact adaptive146Third144Proof251
  · exact adaptive146Third144Proof252

#print axioms adaptive146Third144Proof222

theorem adaptive146Third144Proof253 : runCachedNode 511 131319 Adaptive146Third144Node253 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 131319 Adaptive146Third144Node253 = [102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 132, 134] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive146Third144Proof254
  · exact adaptive146Third144Proof255
  · exact adaptive146Third144Proof256
  · exact adaptive146Third144Proof257
  · exact adaptive146Third144Proof258
  · exact adaptive146Third144Proof259
  · exact adaptive146Third144Proof260
  · exact adaptive146Third144Proof261
  · exact adaptive146Third144Proof262
  · exact adaptive146Third144Proof263
  · exact adaptive146Third144Proof264
  · exact adaptive146Third144Proof265
  · exact adaptive146Third144Proof266
  · exact adaptive146Third144Proof267
  · exact adaptive146Third144Proof268
  · exact adaptive146Third144Proof269
  · exact adaptive146Third144Proof270
  · exact adaptive146Third144Proof271
  · exact adaptive146Third144Proof272
  · exact adaptive146Third144Proof273
  · exact adaptive146Third144Proof274
  · exact adaptive146Third144Proof275
  · exact adaptive146Third144Proof276
  · exact adaptive146Third144Proof277
  · exact adaptive146Third144Proof278
  · exact adaptive146Third144Proof279
  · exact adaptive146Third144Proof280
  · exact adaptive146Third144Proof281
  · exact adaptive146Third144Proof282
  · exact adaptive146Third144Proof283
  · exact adaptive146Third144Proof284

#print axioms adaptive146Third144Proof253

theorem adaptive146Third144Proof315 : runCachedNode 511 131319 Adaptive146Third144Node315 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 131319 Adaptive146Third144Node315 = [91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 117, 119, 121, 123, 125, 127, 129] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive146Third144Proof316
  · exact adaptive146Third144Proof317
  · exact adaptive146Third144Proof318
  · exact adaptive146Third144Proof319
  · exact adaptive146Third144Proof320
  · exact adaptive146Third144Proof321
  · exact adaptive146Third144Proof322
  · exact adaptive146Third144Proof323
  · exact adaptive146Third144Proof324
  · exact adaptive146Third144Proof325
  · exact adaptive146Third144Proof326
  · exact adaptive146Third144Proof327
  · exact adaptive146Third144Proof328
  · exact adaptive146Third144Proof329
  · exact adaptive146Third144Proof330
  · exact adaptive146Third144Proof331
  · exact adaptive146Third144Proof332
  · exact adaptive146Third144Proof333
  · exact adaptive146Third144Proof334
  · exact adaptive146Third144Proof335
  · exact adaptive146Third144Proof336
  · exact adaptive146Third144Proof337
  · exact adaptive146Third144Proof338
  · exact adaptive146Third144Proof339
  · exact adaptive146Third144Proof340
  · exact adaptive146Third144Proof341
  · exact adaptive146Third144Proof342
  · exact adaptive146Third144Proof343
  · exact adaptive146Third144Proof344
  · exact adaptive146Third144Proof345
  · exact adaptive146Third144Proof346
  · exact adaptive146Third144Proof347

#print axioms adaptive146Third144Proof315

theorem adaptive146Third144Proof285 : runCachedNode 511 131319 Adaptive146Third144Node285 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 131319 Adaptive146Third144Node285 = [101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 133, 135] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive146Third144Proof286
  · exact adaptive146Third144Proof287
  · exact adaptive146Third144Proof288
  · exact adaptive146Third144Proof289
  · exact adaptive146Third144Proof290
  · exact adaptive146Third144Proof291
  · exact adaptive146Third144Proof292
  · exact adaptive146Third144Proof293
  · exact adaptive146Third144Proof294
  · exact adaptive146Third144Proof295
  · exact adaptive146Third144Proof296
  · exact adaptive146Third144Proof297
  · exact adaptive146Third144Proof298
  · exact adaptive146Third144Proof299
  · exact adaptive146Third144Proof300
  · exact adaptive146Third144Proof301
  · exact adaptive146Third144Proof302
  · exact adaptive146Third144Proof303
  · exact adaptive146Third144Proof304
  · exact adaptive146Third144Proof305
  · exact adaptive146Third144Proof306
  · exact adaptive146Third144Proof307
  · exact adaptive146Third144Proof308
  · exact adaptive146Third144Proof309
  · exact adaptive146Third144Proof310
  · exact adaptive146Third144Proof311
  · exact adaptive146Third144Proof312
  · exact adaptive146Third144Proof313
  · exact adaptive146Third144Proof314
  · exact adaptive146Third144Proof315
  · exact adaptive146Third144Proof348
  · exact adaptive146Third144Proof349
  · exact adaptive146Third144Proof350

#print axioms adaptive146Third144Proof285

theorem adaptive146Third144Proof351 : runCachedNode 511 131319 Adaptive146Third144Node351 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 131319 Adaptive146Third144Node351 = [101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 132, 134, 136] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive146Third144Proof352
  · exact adaptive146Third144Proof353
  · exact adaptive146Third144Proof354
  · exact adaptive146Third144Proof355
  · exact adaptive146Third144Proof356
  · exact adaptive146Third144Proof357
  · exact adaptive146Third144Proof358
  · exact adaptive146Third144Proof359
  · exact adaptive146Third144Proof360
  · exact adaptive146Third144Proof361
  · exact adaptive146Third144Proof362
  · exact adaptive146Third144Proof363
  · exact adaptive146Third144Proof364
  · exact adaptive146Third144Proof365
  · exact adaptive146Third144Proof366
  · exact adaptive146Third144Proof367
  · exact adaptive146Third144Proof368
  · exact adaptive146Third144Proof369
  · exact adaptive146Third144Proof370
  · exact adaptive146Third144Proof371
  · exact adaptive146Third144Proof372
  · exact adaptive146Third144Proof373
  · exact adaptive146Third144Proof374
  · exact adaptive146Third144Proof375
  · exact adaptive146Third144Proof376
  · exact adaptive146Third144Proof377
  · exact adaptive146Third144Proof378
  · exact adaptive146Third144Proof379
  · exact adaptive146Third144Proof380
  · exact adaptive146Third144Proof381
  · exact adaptive146Third144Proof382
  · exact adaptive146Third144Proof383
  · exact adaptive146Third144Proof384
  · exact adaptive146Third144Proof385

#print axioms adaptive146Third144Proof351

theorem adaptive146Third144Proof416 : runCachedNode 511 131319 Adaptive146Third144Node416 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 131319 Adaptive146Third144Node416 = [91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 119, 121, 123, 125, 127, 129] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive146Third144Proof417
  · exact adaptive146Third144Proof418
  · exact adaptive146Third144Proof419
  · exact adaptive146Third144Proof420
  · exact adaptive146Third144Proof421
  · exact adaptive146Third144Proof422
  · exact adaptive146Third144Proof423
  · exact adaptive146Third144Proof424
  · exact adaptive146Third144Proof425
  · exact adaptive146Third144Proof426
  · exact adaptive146Third144Proof427
  · exact adaptive146Third144Proof428
  · exact adaptive146Third144Proof429
  · exact adaptive146Third144Proof430
  · exact adaptive146Third144Proof431
  · exact adaptive146Third144Proof432
  · exact adaptive146Third144Proof433
  · exact adaptive146Third144Proof434
  · exact adaptive146Third144Proof435
  · exact adaptive146Third144Proof436
  · exact adaptive146Third144Proof437
  · exact adaptive146Third144Proof438
  · exact adaptive146Third144Proof439
  · exact adaptive146Third144Proof440
  · exact adaptive146Third144Proof441
  · exact adaptive146Third144Proof442
  · exact adaptive146Third144Proof443
  · exact adaptive146Third144Proof444
  · exact adaptive146Third144Proof445
  · exact adaptive146Third144Proof446
  · exact adaptive146Third144Proof447
  · exact adaptive146Third144Proof448
  · exact adaptive146Third144Proof449

#print axioms adaptive146Third144Proof416

theorem adaptive146Third144Proof451 : runCachedNode 511 131319 Adaptive146Third144Node451 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 131319 Adaptive146Third144Node451 = [90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 121, 123, 125, 127, 129, 131] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive146Third144Proof452
  · exact adaptive146Third144Proof453
  · exact adaptive146Third144Proof454
  · exact adaptive146Third144Proof455
  · exact adaptive146Third144Proof456
  · exact adaptive146Third144Proof457
  · exact adaptive146Third144Proof458
  · exact adaptive146Third144Proof459
  · exact adaptive146Third144Proof460
  · exact adaptive146Third144Proof461
  · exact adaptive146Third144Proof462
  · exact adaptive146Third144Proof463
  · exact adaptive146Third144Proof464
  · exact adaptive146Third144Proof465
  · exact adaptive146Third144Proof466
  · exact adaptive146Third144Proof467
  · exact adaptive146Third144Proof468
  · exact adaptive146Third144Proof469
  · exact adaptive146Third144Proof470
  · exact adaptive146Third144Proof471
  · exact adaptive146Third144Proof472
  · exact adaptive146Third144Proof473
  · exact adaptive146Third144Proof474
  · exact adaptive146Third144Proof475
  · exact adaptive146Third144Proof476
  · exact adaptive146Third144Proof477
  · exact adaptive146Third144Proof478
  · exact adaptive146Third144Proof479
  · exact adaptive146Third144Proof480
  · exact adaptive146Third144Proof481
  · exact adaptive146Third144Proof482
  · exact adaptive146Third144Proof483
  · exact adaptive146Third144Proof484
  · exact adaptive146Third144Proof485
  · exact adaptive146Third144Proof486
  · exact adaptive146Third144Proof487

#print axioms adaptive146Third144Proof451

theorem adaptive146Third144Proof490 : runCachedNode 511 131319 Adaptive146Third144Node490 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 131319 Adaptive146Third144Node490 = [88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 126, 128, 130, 132] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive146Third144Proof491
  · exact adaptive146Third144Proof492
  · exact adaptive146Third144Proof493
  · exact adaptive146Third144Proof494
  · exact adaptive146Third144Proof495
  · exact adaptive146Third144Proof496
  · exact adaptive146Third144Proof497
  · exact adaptive146Third144Proof498
  · exact adaptive146Third144Proof499
  · exact adaptive146Third144Proof500
  · exact adaptive146Third144Proof501
  · exact adaptive146Third144Proof502
  · exact adaptive146Third144Proof503
  · exact adaptive146Third144Proof504
  · exact adaptive146Third144Proof505
  · exact adaptive146Third144Proof506
  · exact adaptive146Third144Proof507
  · exact adaptive146Third144Proof508
  · exact adaptive146Third144Proof509
  · exact adaptive146Third144Proof510
  · exact adaptive146Third144Proof511
  · exact adaptive146Third144Proof512
  · exact adaptive146Third144Proof513
  · exact adaptive146Third144Proof514
  · exact adaptive146Third144Proof515
  · exact adaptive146Third144Proof516
  · exact adaptive146Third144Proof517
  · exact adaptive146Third144Proof518
  · exact adaptive146Third144Proof519
  · exact adaptive146Third144Proof520
  · exact adaptive146Third144Proof521
  · exact adaptive146Third144Proof522
  · exact adaptive146Third144Proof523
  · exact adaptive146Third144Proof524
  · exact adaptive146Third144Proof525
  · exact adaptive146Third144Proof526
  · exact adaptive146Third144Proof527
  · exact adaptive146Third144Proof528
  · exact adaptive146Third144Proof529
  · exact adaptive146Third144Proof530
  · exact adaptive146Third144Proof531

#print axioms adaptive146Third144Proof490

end NineSeparatedSubsetSums
