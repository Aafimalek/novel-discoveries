import NineSeparatedSubsetSums.Adaptive146Third143State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third143Proof130 : runCachedNode 511 131193 Adaptive146Third143Node130 = false := by
  decide +kernel

#print axioms adaptive146Third143Proof130

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third143Proof457 : runCachedNode 511 131193 Adaptive146Third143Node457 = false := by
  decide +kernel

#print axioms adaptive146Third143Proof457

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third143Proof624 : runCachedNode 511 131193 Adaptive146Third143Node624 = false := by
  decide +kernel

#print axioms adaptive146Third143Proof624

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third143Proof409 : runCachedNode 511 131193 Adaptive146Third143Node409 = false := by
  decide +kernel

#print axioms adaptive146Third143Proof409

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third143Proof71 : runCachedNode 511 131193 Adaptive146Third143Node71 = false := by
  decide +kernel

#print axioms adaptive146Third143Proof71

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third143Proof256 : runCachedNode 511 131193 Adaptive146Third143Node256 = false := by
  decide +kernel

#print axioms adaptive146Third143Proof256

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third143Proof190 : runCachedNode 511 131193 Adaptive146Third143Node190 = false := by
  decide +kernel

#print axioms adaptive146Third143Proof190

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third143Proof25 : runCachedNode 511 131193 Adaptive146Third143Node25 = false := by
  decide +kernel

#print axioms adaptive146Third143Proof25

end NineSeparatedSubsetSums
