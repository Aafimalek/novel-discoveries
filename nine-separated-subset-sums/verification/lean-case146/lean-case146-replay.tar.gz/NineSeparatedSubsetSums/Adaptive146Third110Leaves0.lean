import NineSeparatedSubsetSums.Adaptive146Third110State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third110Proof0 : runCachedNode 511 112631 Adaptive146Third110Node0 = false := by
  decide +kernel

#print axioms adaptive146Third110Proof0

end NineSeparatedSubsetSums
