import NineSeparatedSubsetSums.Adaptive146Third141State
import NineSeparatedSubsetSums.Adaptive146Third141Leaves23
import NineSeparatedSubsetSums.Adaptive146Third141Leaves34
import NineSeparatedSubsetSums.Adaptive146Third141Leaves2
import NineSeparatedSubsetSums.Adaptive146Third141Leaves33
import NineSeparatedSubsetSums.Adaptive146Third141Leaves0
import NineSeparatedSubsetSums.Adaptive146Third141Leaves32
import NineSeparatedSubsetSums.Adaptive146Third141Leaves29
import NineSeparatedSubsetSums.Adaptive146Third141Leaves16
import NineSeparatedSubsetSums.Adaptive146Third141Leaves30
import NineSeparatedSubsetSums.Adaptive146Third141Leaves25
import NineSeparatedSubsetSums.Adaptive146Third141Leaves26
import NineSeparatedSubsetSums.Adaptive146Third141Leaves6
import NineSeparatedSubsetSums.Adaptive146Third141Leaves28
import NineSeparatedSubsetSums.Adaptive146Third141Leaves14
import NineSeparatedSubsetSums.Adaptive146Third141Leaves5
import NineSeparatedSubsetSums.Adaptive146Third141Leaves13
import NineSeparatedSubsetSums.Adaptive146Third141Leaves15
import NineSeparatedSubsetSums.Adaptive146Third141Leaves31
import NineSeparatedSubsetSums.Adaptive146Third141Leaves22
import NineSeparatedSubsetSums.Adaptive146Third141Leaves27
import NineSeparatedSubsetSums.Adaptive146Third141Leaves7
import NineSeparatedSubsetSums.Adaptive146Third141Leaves35
import NineSeparatedSubsetSums.Adaptive146Third141Leaves3
import NineSeparatedSubsetSums.Adaptive146Third141Leaves21
import NineSeparatedSubsetSums.Adaptive146Third141Leaves18
import NineSeparatedSubsetSums.Adaptive146Third141Leaves20
import NineSeparatedSubsetSums.Adaptive146Third141Leaves17
import NineSeparatedSubsetSums.Adaptive146Third141Leaves4
import NineSeparatedSubsetSums.Adaptive146Third141Leaves9
import NineSeparatedSubsetSums.Adaptive146Third141Leaves19
import NineSeparatedSubsetSums.Adaptive146Third141Leaves24
import NineSeparatedSubsetSums.Adaptive146Third141Leaves11
import NineSeparatedSubsetSums.Adaptive146Third141Leaves10
import NineSeparatedSubsetSums.Adaptive146Third141Leaves8
import NineSeparatedSubsetSums.Adaptive146Third141Leaves12
import NineSeparatedSubsetSums.Adaptive146Third141Leaves36

namespace NineSeparatedSubsetSums

theorem adaptive146Third141Proof24 : runCachedNode 511 130916 Adaptive146Third141Node24 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130916 Adaptive146Third141Node24 = [103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 126, 128, 129, 131] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive146Third141Proof25
  · exact adaptive146Third141Proof26
  · exact adaptive146Third141Proof27
  · exact adaptive146Third141Proof28
  · exact adaptive146Third141Proof29
  · exact adaptive146Third141Proof30
  · exact adaptive146Third141Proof31
  · exact adaptive146Third141Proof32
  · exact adaptive146Third141Proof33
  · exact adaptive146Third141Proof34
  · exact adaptive146Third141Proof35
  · exact adaptive146Third141Proof36
  · exact adaptive146Third141Proof37
  · exact adaptive146Third141Proof38
  · exact adaptive146Third141Proof39
  · exact adaptive146Third141Proof40
  · exact adaptive146Third141Proof41
  · exact adaptive146Third141Proof42
  · exact adaptive146Third141Proof43
  · exact adaptive146Third141Proof44
  · exact adaptive146Third141Proof45
  · exact adaptive146Third141Proof46
  · exact adaptive146Third141Proof47
  · exact adaptive146Third141Proof48
  · exact adaptive146Third141Proof49
  · exact adaptive146Third141Proof50

#print axioms adaptive146Third141Proof24

theorem adaptive146Third141Proof51 : runCachedNode 511 130916 Adaptive146Third141Node51 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130916 Adaptive146Third141Node51 = [103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 127, 129, 130, 132] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive146Third141Proof52
  · exact adaptive146Third141Proof53
  · exact adaptive146Third141Proof54
  · exact adaptive146Third141Proof55
  · exact adaptive146Third141Proof56
  · exact adaptive146Third141Proof57
  · exact adaptive146Third141Proof58
  · exact adaptive146Third141Proof59
  · exact adaptive146Third141Proof60
  · exact adaptive146Third141Proof61
  · exact adaptive146Third141Proof62
  · exact adaptive146Third141Proof63
  · exact adaptive146Third141Proof64
  · exact adaptive146Third141Proof65
  · exact adaptive146Third141Proof66
  · exact adaptive146Third141Proof67
  · exact adaptive146Third141Proof68
  · exact adaptive146Third141Proof69
  · exact adaptive146Third141Proof70
  · exact adaptive146Third141Proof71
  · exact adaptive146Third141Proof72
  · exact adaptive146Third141Proof73
  · exact adaptive146Third141Proof74
  · exact adaptive146Third141Proof75
  · exact adaptive146Third141Proof76
  · exact adaptive146Third141Proof77
  · exact adaptive146Third141Proof78

#print axioms adaptive146Third141Proof51

theorem adaptive146Third141Proof79 : runCachedNode 511 130916 Adaptive146Third141Node79 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130916 Adaptive146Third141Node79 = [102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 128, 130, 131, 133] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive146Third141Proof80
  · exact adaptive146Third141Proof81
  · exact adaptive146Third141Proof82
  · exact adaptive146Third141Proof83
  · exact adaptive146Third141Proof84
  · exact adaptive146Third141Proof85
  · exact adaptive146Third141Proof86
  · exact adaptive146Third141Proof87
  · exact adaptive146Third141Proof88
  · exact adaptive146Third141Proof89
  · exact adaptive146Third141Proof90
  · exact adaptive146Third141Proof91
  · exact adaptive146Third141Proof92
  · exact adaptive146Third141Proof93
  · exact adaptive146Third141Proof94
  · exact adaptive146Third141Proof95
  · exact adaptive146Third141Proof96
  · exact adaptive146Third141Proof97
  · exact adaptive146Third141Proof98
  · exact adaptive146Third141Proof99
  · exact adaptive146Third141Proof100
  · exact adaptive146Third141Proof101
  · exact adaptive146Third141Proof102
  · exact adaptive146Third141Proof103
  · exact adaptive146Third141Proof104
  · exact adaptive146Third141Proof105
  · exact adaptive146Third141Proof106
  · exact adaptive146Third141Proof107
  · exact adaptive146Third141Proof108

#print axioms adaptive146Third141Proof79

theorem adaptive146Third141Proof109 : runCachedNode 511 130916 Adaptive146Third141Node109 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130916 Adaptive146Third141Node109 = [102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 129, 131, 132, 134] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive146Third141Proof110
  · exact adaptive146Third141Proof111
  · exact adaptive146Third141Proof112
  · exact adaptive146Third141Proof113
  · exact adaptive146Third141Proof114
  · exact adaptive146Third141Proof115
  · exact adaptive146Third141Proof116
  · exact adaptive146Third141Proof117
  · exact adaptive146Third141Proof118
  · exact adaptive146Third141Proof119
  · exact adaptive146Third141Proof120
  · exact adaptive146Third141Proof121
  · exact adaptive146Third141Proof122
  · exact adaptive146Third141Proof123
  · exact adaptive146Third141Proof124
  · exact adaptive146Third141Proof125
  · exact adaptive146Third141Proof126
  · exact adaptive146Third141Proof127
  · exact adaptive146Third141Proof128
  · exact adaptive146Third141Proof129
  · exact adaptive146Third141Proof130
  · exact adaptive146Third141Proof131
  · exact adaptive146Third141Proof132
  · exact adaptive146Third141Proof133
  · exact adaptive146Third141Proof134
  · exact adaptive146Third141Proof135
  · exact adaptive146Third141Proof136
  · exact adaptive146Third141Proof137
  · exact adaptive146Third141Proof138
  · exact adaptive146Third141Proof139

#print axioms adaptive146Third141Proof109

theorem adaptive146Third141Proof140 : runCachedNode 511 130916 Adaptive146Third141Node140 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130916 Adaptive146Third141Node140 = [102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 130, 132, 133, 135] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive146Third141Proof141
  · exact adaptive146Third141Proof142
  · exact adaptive146Third141Proof143
  · exact adaptive146Third141Proof144
  · exact adaptive146Third141Proof145
  · exact adaptive146Third141Proof146
  · exact adaptive146Third141Proof147
  · exact adaptive146Third141Proof148
  · exact adaptive146Third141Proof149
  · exact adaptive146Third141Proof150
  · exact adaptive146Third141Proof151
  · exact adaptive146Third141Proof152
  · exact adaptive146Third141Proof153
  · exact adaptive146Third141Proof154
  · exact adaptive146Third141Proof155
  · exact adaptive146Third141Proof156
  · exact adaptive146Third141Proof157
  · exact adaptive146Third141Proof158
  · exact adaptive146Third141Proof159
  · exact adaptive146Third141Proof160
  · exact adaptive146Third141Proof161
  · exact adaptive146Third141Proof162
  · exact adaptive146Third141Proof163
  · exact adaptive146Third141Proof164
  · exact adaptive146Third141Proof165
  · exact adaptive146Third141Proof166
  · exact adaptive146Third141Proof167
  · exact adaptive146Third141Proof168
  · exact adaptive146Third141Proof169
  · exact adaptive146Third141Proof170
  · exact adaptive146Third141Proof171

#print axioms adaptive146Third141Proof140

theorem adaptive146Third141Proof172 : runCachedNode 511 130916 Adaptive146Third141Node172 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130916 Adaptive146Third141Node172 = [102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 131, 133, 134, 136] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive146Third141Proof173
  · exact adaptive146Third141Proof174
  · exact adaptive146Third141Proof175
  · exact adaptive146Third141Proof176
  · exact adaptive146Third141Proof177
  · exact adaptive146Third141Proof178
  · exact adaptive146Third141Proof179
  · exact adaptive146Third141Proof180
  · exact adaptive146Third141Proof181
  · exact adaptive146Third141Proof182
  · exact adaptive146Third141Proof183
  · exact adaptive146Third141Proof184
  · exact adaptive146Third141Proof185
  · exact adaptive146Third141Proof186
  · exact adaptive146Third141Proof187
  · exact adaptive146Third141Proof188
  · exact adaptive146Third141Proof189
  · exact adaptive146Third141Proof190
  · exact adaptive146Third141Proof191
  · exact adaptive146Third141Proof192
  · exact adaptive146Third141Proof193
  · exact adaptive146Third141Proof194
  · exact adaptive146Third141Proof195
  · exact adaptive146Third141Proof196
  · exact adaptive146Third141Proof197
  · exact adaptive146Third141Proof198
  · exact adaptive146Third141Proof199
  · exact adaptive146Third141Proof200
  · exact adaptive146Third141Proof201
  · exact adaptive146Third141Proof202
  · exact adaptive146Third141Proof203
  · exact adaptive146Third141Proof204

#print axioms adaptive146Third141Proof172

theorem adaptive146Third141Proof205 : runCachedNode 511 130916 Adaptive146Third141Node205 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130916 Adaptive146Third141Node205 = [101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 132, 134, 135, 137] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive146Third141Proof206
  · exact adaptive146Third141Proof207
  · exact adaptive146Third141Proof208
  · exact adaptive146Third141Proof209
  · exact adaptive146Third141Proof210
  · exact adaptive146Third141Proof211
  · exact adaptive146Third141Proof212
  · exact adaptive146Third141Proof213
  · exact adaptive146Third141Proof214
  · exact adaptive146Third141Proof215
  · exact adaptive146Third141Proof216
  · exact adaptive146Third141Proof217
  · exact adaptive146Third141Proof218
  · exact adaptive146Third141Proof219
  · exact adaptive146Third141Proof220
  · exact adaptive146Third141Proof221
  · exact adaptive146Third141Proof222
  · exact adaptive146Third141Proof223
  · exact adaptive146Third141Proof224
  · exact adaptive146Third141Proof225
  · exact adaptive146Third141Proof226
  · exact adaptive146Third141Proof227
  · exact adaptive146Third141Proof228
  · exact adaptive146Third141Proof229
  · exact adaptive146Third141Proof230
  · exact adaptive146Third141Proof231
  · exact adaptive146Third141Proof232
  · exact adaptive146Third141Proof233
  · exact adaptive146Third141Proof234
  · exact adaptive146Third141Proof235
  · exact adaptive146Third141Proof236
  · exact adaptive146Third141Proof237
  · exact adaptive146Third141Proof238
  · exact adaptive146Third141Proof239

#print axioms adaptive146Third141Proof205

theorem adaptive146Third141Proof274 : runCachedNode 511 130916 Adaptive146Third141Node274 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130916 Adaptive146Third141Node274 = [88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 124, 125, 126, 127, 132] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive146Third141Proof275
  · exact adaptive146Third141Proof276
  · exact adaptive146Third141Proof277
  · exact adaptive146Third141Proof278
  · exact adaptive146Third141Proof279
  · exact adaptive146Third141Proof280
  · exact adaptive146Third141Proof281
  · exact adaptive146Third141Proof282
  · exact adaptive146Third141Proof283
  · exact adaptive146Third141Proof284
  · exact adaptive146Third141Proof285
  · exact adaptive146Third141Proof286
  · exact adaptive146Third141Proof287
  · exact adaptive146Third141Proof288
  · exact adaptive146Third141Proof289
  · exact adaptive146Third141Proof290
  · exact adaptive146Third141Proof291
  · exact adaptive146Third141Proof292
  · exact adaptive146Third141Proof293
  · exact adaptive146Third141Proof294
  · exact adaptive146Third141Proof295
  · exact adaptive146Third141Proof296
  · exact adaptive146Third141Proof297
  · exact adaptive146Third141Proof298
  · exact adaptive146Third141Proof299
  · exact adaptive146Third141Proof300
  · exact adaptive146Third141Proof301
  · exact adaptive146Third141Proof302
  · exact adaptive146Third141Proof303
  · exact adaptive146Third141Proof304
  · exact adaptive146Third141Proof305
  · exact adaptive146Third141Proof306
  · exact adaptive146Third141Proof307
  · exact adaptive146Third141Proof308
  · exact adaptive146Third141Proof309
  · exact adaptive146Third141Proof310
  · exact adaptive146Third141Proof311
  · exact adaptive146Third141Proof312
  · exact adaptive146Third141Proof313
  · exact adaptive146Third141Proof314

#print axioms adaptive146Third141Proof274

end NineSeparatedSubsetSums
