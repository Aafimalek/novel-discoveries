import NineSeparatedSubsetSums.Adaptive146Third141State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third141Proof239 : runCachedNode 511 130916 Adaptive146Third141Node239 = false := by
  decide +kernel

#print axioms adaptive146Third141Proof239

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third141Proof166 : runCachedNode 511 130916 Adaptive146Third141Node166 = false := by
  decide +kernel

#print axioms adaptive146Third141Proof166

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third141Proof113 : runCachedNode 511 130916 Adaptive146Third141Node113 = false := by
  decide +kernel

#print axioms adaptive146Third141Proof113

end NineSeparatedSubsetSums
