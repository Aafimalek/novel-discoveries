import NineSeparatedSubsetSums.Adaptive146Third141State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third141Proof272 : runCachedNode 511 130916 Adaptive146Third141Node272 = false := by
  decide +kernel

#print axioms adaptive146Third141Proof272

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third141Proof138 : runCachedNode 511 130916 Adaptive146Third141Node138 = false := by
  decide +kernel

#print axioms adaptive146Third141Proof138

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third141Proof54 : runCachedNode 511 130916 Adaptive146Third141Node54 = false := by
  decide +kernel

#print axioms adaptive146Third141Proof54

end NineSeparatedSubsetSums
