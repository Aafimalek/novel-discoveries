import NineSeparatedSubsetSums.Adaptive146Third138State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third138Proof123 : runCachedNode 511 130484 Adaptive146Third138Node123 = false := by
  decide +kernel

#print axioms adaptive146Third138Proof123

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third138Proof121 : runCachedNode 511 130484 Adaptive146Third138Node121 = false := by
  decide +kernel

#print axioms adaptive146Third138Proof121

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third138Proof122 : runCachedNode 511 130484 Adaptive146Third138Node122 = false := by
  decide +kernel

#print axioms adaptive146Third138Proof122

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third138Proof136 : runCachedNode 511 130484 Adaptive146Third138Node136 = false := by
  decide +kernel

#print axioms adaptive146Third138Proof136

end NineSeparatedSubsetSums
