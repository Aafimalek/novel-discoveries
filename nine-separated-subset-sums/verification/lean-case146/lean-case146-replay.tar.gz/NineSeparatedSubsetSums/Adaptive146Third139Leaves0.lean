import NineSeparatedSubsetSums.Adaptive146Third139State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third139Proof20 : runCachedNode 511 130638 Adaptive146Third139Node20 = false := by
  decide +kernel

#print axioms adaptive146Third139Proof20

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third139Proof124 : runCachedNode 511 130638 Adaptive146Third139Node124 = false := by
  decide +kernel

#print axioms adaptive146Third139Proof124

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third139Proof50 : runCachedNode 511 130638 Adaptive146Third139Node50 = false := by
  decide +kernel

#print axioms adaptive146Third139Proof50

end NineSeparatedSubsetSums
