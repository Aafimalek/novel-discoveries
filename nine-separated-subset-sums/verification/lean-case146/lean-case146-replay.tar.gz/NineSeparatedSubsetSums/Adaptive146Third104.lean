import NineSeparatedSubsetSums.Adaptive146Third104Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint146Checked

namespace NineSeparatedSubsetSums


theorem adaptive146Third104 : NoDescendingTailAfterThird 146 104 :=
  noDescendingThirdTail_of_cached 146 104 112631 (fun t ht nd => max148_second146_fourPoint_moment_bound (104::t) (by simp [ht]) nd) adaptive146Third104Proof0

#print axioms adaptive146Third104

end NineSeparatedSubsetSums
