import NineSeparatedSubsetSums.Adaptive146Third142State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third142Proof21 : runCachedNode 511 131054 Adaptive146Third142Node21 = false := by
  decide +kernel

#print axioms adaptive146Third142Proof21

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third142Proof322 : runCachedNode 511 131054 Adaptive146Third142Node322 = false := by
  decide +kernel

#print axioms adaptive146Third142Proof322

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third142Proof219 : runCachedNode 511 131054 Adaptive146Third142Node219 = false := by
  decide +kernel

#print axioms adaptive146Third142Proof219

end NineSeparatedSubsetSums
