import NineSeparatedSubsetSums.Adaptive146Third132State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third132Proof12 : runCachedNode 511 129510 Adaptive146Third132Node12 = false := by
  decide +kernel

#print axioms adaptive146Third132Proof12

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third132Proof9 : runCachedNode 511 129510 Adaptive146Third132Node9 = false := by
  decide +kernel

#print axioms adaptive146Third132Proof9

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third132Proof8 : runCachedNode 511 129510 Adaptive146Third132Node8 = false := by
  decide +kernel

#print axioms adaptive146Third132Proof8

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third132Proof7 : runCachedNode 511 129510 Adaptive146Third132Node7 = false := by
  decide +kernel

#print axioms adaptive146Third132Proof7

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third132Proof6 : runCachedNode 511 129510 Adaptive146Third132Node6 = false := by
  decide +kernel

#print axioms adaptive146Third132Proof6

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third132Proof5 : runCachedNode 511 129510 Adaptive146Third132Node5 = false := by
  decide +kernel

#print axioms adaptive146Third132Proof5

end NineSeparatedSubsetSums
