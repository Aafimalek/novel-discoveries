import NineSeparatedSubsetSums.Adaptive146Third143State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third143Proof575 : runCachedNode 511 131193 Adaptive146Third143Node575 = false := by
  decide +kernel

#print axioms adaptive146Third143Proof575

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third143Proof104 : runCachedNode 511 131193 Adaptive146Third143Node104 = false := by
  decide +kernel

#print axioms adaptive146Third143Proof104

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third143Proof228 : runCachedNode 511 131193 Adaptive146Third143Node228 = false := by
  decide +kernel

#print axioms adaptive146Third143Proof228

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third143Proof48 : runCachedNode 511 131193 Adaptive146Third143Node48 = false := by
  decide +kernel

#print axioms adaptive146Third143Proof48

end NineSeparatedSubsetSums
