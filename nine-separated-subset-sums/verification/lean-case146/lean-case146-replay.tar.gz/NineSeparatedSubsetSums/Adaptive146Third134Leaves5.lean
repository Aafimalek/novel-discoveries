import NineSeparatedSubsetSums.Adaptive146Third134State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third134Proof12 : runCachedNode 511 129871 Adaptive146Third134Node12 = false := by
  decide +kernel

#print axioms adaptive146Third134Proof12

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third134Proof11 : runCachedNode 511 129871 Adaptive146Third134Node11 = false := by
  decide +kernel

#print axioms adaptive146Third134Proof11

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third134Proof43 : runCachedNode 511 129871 Adaptive146Third134Node43 = false := by
  decide +kernel

#print axioms adaptive146Third134Proof43

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third134Proof69 : runCachedNode 511 129871 Adaptive146Third134Node69 = false := by
  decide +kernel

#print axioms adaptive146Third134Proof69

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third134Proof68 : runCachedNode 511 129871 Adaptive146Third134Node68 = false := by
  decide +kernel

#print axioms adaptive146Third134Proof68

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third134Proof42 : runCachedNode 511 129871 Adaptive146Third134Node42 = false := by
  decide +kernel

#print axioms adaptive146Third134Proof42

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third134Proof40 : runCachedNode 511 129871 Adaptive146Third134Node40 = false := by
  decide +kernel

#print axioms adaptive146Third134Proof40

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third134Proof38 : runCachedNode 511 129871 Adaptive146Third134Node38 = false := by
  decide +kernel

#print axioms adaptive146Third134Proof38

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third134Proof62 : runCachedNode 511 129871 Adaptive146Third134Node62 = false := by
  decide +kernel

#print axioms adaptive146Third134Proof62

end NineSeparatedSubsetSums
