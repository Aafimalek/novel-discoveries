import NineSeparatedSubsetSums.Adaptive146Third122State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third122Proof0 : runCachedNode 511 126977 Adaptive146Third122Node0 = false := by
  decide +kernel

#print axioms adaptive146Third122Proof0

end NineSeparatedSubsetSums
