import NineSeparatedSubsetSums.Adaptive146Third143State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third143Proof570 : runCachedNode 511 131193 Adaptive146Third143Node570 = false := by
  decide +kernel

#print axioms adaptive146Third143Proof570

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third143Proof98 : runCachedNode 511 131193 Adaptive146Third143Node98 = false := by
  decide +kernel

#print axioms adaptive146Third143Proof98

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third143Proof128 : runCachedNode 511 131193 Adaptive146Third143Node128 = false := by
  decide +kernel

#print axioms adaptive146Third143Proof128

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third143Proof12 : runCachedNode 511 131193 Adaptive146Third143Node12 = false := by
  decide +kernel

#print axioms adaptive146Third143Proof12

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third143Proof498 : runCachedNode 511 131193 Adaptive146Third143Node498 = false := by
  decide +kernel

#print axioms adaptive146Third143Proof498

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third143Proof331 : runCachedNode 511 131193 Adaptive146Third143Node331 = false := by
  decide +kernel

#print axioms adaptive146Third143Proof331

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third143Proof407 : runCachedNode 511 131193 Adaptive146Third143Node407 = false := by
  decide +kernel

#print axioms adaptive146Third143Proof407

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third143Proof540 : runCachedNode 511 131193 Adaptive146Third143Node540 = false := by
  decide +kernel

#print axioms adaptive146Third143Proof540

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third143Proof70 : runCachedNode 511 131193 Adaptive146Third143Node70 = false := by
  decide +kernel

#print axioms adaptive146Third143Proof70

end NineSeparatedSubsetSums
