import NineSeparatedSubsetSums.Adaptive146Third144State
import NineSeparatedSubsetSums.Adaptive146Third144Leaves130
import NineSeparatedSubsetSums.Adaptive146Third144Leaves129
import NineSeparatedSubsetSums.Adaptive146Third144Leaves128
import NineSeparatedSubsetSums.Adaptive146Third144Leaves127
import NineSeparatedSubsetSums.Adaptive146Third144Leaves126
import NineSeparatedSubsetSums.Adaptive146Third144Leaves124
import NineSeparatedSubsetSums.Adaptive146Third144Leaves122
import NineSeparatedSubsetSums.Adaptive146Third144Leaves120
import NineSeparatedSubsetSums.Adaptive146Third144Leaves117
import NineSeparatedSubsetSums.Adaptive146Third144Leaves114
import NineSeparatedSubsetSums.Adaptive146Third144Leaves104
import NineSeparatedSubsetSums.Adaptive146Third144Leaves107
import NineSeparatedSubsetSums.Adaptive146Third144Leaves90
import NineSeparatedSubsetSums.Adaptive146Third144Leaves97
import NineSeparatedSubsetSums.Adaptive146Third144Leaves83
import NineSeparatedSubsetSums.Adaptive146Third144Leaves92
import NineSeparatedSubsetSums.Adaptive146Third144Leaves93
import NineSeparatedSubsetSums.Adaptive146Third144Leaves94
import NineSeparatedSubsetSums.Adaptive146Third144Leaves87
import NineSeparatedSubsetSums.Adaptive146Third144Leaves84
import NineSeparatedSubsetSums.Adaptive146Third144Leaves79
import NineSeparatedSubsetSums.Adaptive146Third144Leaves68
import NineSeparatedSubsetSums.Adaptive146Third144Leaves70
import NineSeparatedSubsetSums.Adaptive146Third144Leaves35
import NineSeparatedSubsetSums.Adaptive146Third144Leaves20
import NineSeparatedSubsetSums.Adaptive146Third144Leaves5
import NineSeparatedSubsetSums.Adaptive146Third144Leaves50
import NineSeparatedSubsetSums.Adaptive146Third144Joins1
import NineSeparatedSubsetSums.Adaptive146Third144Leaves33
import NineSeparatedSubsetSums.Adaptive146Third144Leaves9
import NineSeparatedSubsetSums.Adaptive146Third144Leaves1
import NineSeparatedSubsetSums.Adaptive146Third144Leaves131
import NineSeparatedSubsetSums.Adaptive146Third144Leaves125
import NineSeparatedSubsetSums.Adaptive146Third144Leaves121
import NineSeparatedSubsetSums.Adaptive146Third144Leaves118
import NineSeparatedSubsetSums.Adaptive146Third144Leaves116
import NineSeparatedSubsetSums.Adaptive146Third144Leaves111
import NineSeparatedSubsetSums.Adaptive146Third144Leaves110
import NineSeparatedSubsetSums.Adaptive146Third144Leaves105
import NineSeparatedSubsetSums.Adaptive146Third144Leaves109
import NineSeparatedSubsetSums.Adaptive146Third144Leaves106
import NineSeparatedSubsetSums.Adaptive146Third144Leaves3
import NineSeparatedSubsetSums.Adaptive146Third144Leaves103
import NineSeparatedSubsetSums.Adaptive146Third144Leaves88
import NineSeparatedSubsetSums.Adaptive146Third144Leaves49
import NineSeparatedSubsetSums.Adaptive146Third144Leaves73
import NineSeparatedSubsetSums.Adaptive146Third144Leaves123
import NineSeparatedSubsetSums.Adaptive146Third144Leaves119
import NineSeparatedSubsetSums.Adaptive146Third144Leaves115
import NineSeparatedSubsetSums.Adaptive146Third144Leaves113
import NineSeparatedSubsetSums.Adaptive146Third144Leaves0
import NineSeparatedSubsetSums.Adaptive146Third144Leaves98
import NineSeparatedSubsetSums.Adaptive146Third144Leaves91
import NineSeparatedSubsetSums.Adaptive146Third144Leaves47
import NineSeparatedSubsetSums.Adaptive146Third144Leaves63
import NineSeparatedSubsetSums.Adaptive146Third144Leaves76
import NineSeparatedSubsetSums.Adaptive146Third144Leaves132
import NineSeparatedSubsetSums.Adaptive146Third144Leaves69
import NineSeparatedSubsetSums.Adaptive146Third144Leaves85
import NineSeparatedSubsetSums.Adaptive146Third144Leaves51
import NineSeparatedSubsetSums.Adaptive146Third144Leaves57
import NineSeparatedSubsetSums.Adaptive146Third144Leaves101
import NineSeparatedSubsetSums.Adaptive146Third144Leaves72
import NineSeparatedSubsetSums.Adaptive146Third144Leaves86
import NineSeparatedSubsetSums.Adaptive146Third144Leaves59
import NineSeparatedSubsetSums.Adaptive146Third144Leaves71
import NineSeparatedSubsetSums.Adaptive146Third144Leaves44
import NineSeparatedSubsetSums.Adaptive146Third144Leaves65
import NineSeparatedSubsetSums.Adaptive146Third144Leaves18
import NineSeparatedSubsetSums.Adaptive146Third144Leaves2
import NineSeparatedSubsetSums.Adaptive146Third144Leaves4
import NineSeparatedSubsetSums.Adaptive146Third144Leaves112
import NineSeparatedSubsetSums.Adaptive146Third144Leaves96
import NineSeparatedSubsetSums.Adaptive146Third144Leaves81
import NineSeparatedSubsetSums.Adaptive146Third144Leaves102
import NineSeparatedSubsetSums.Adaptive146Third144Leaves100
import NineSeparatedSubsetSums.Adaptive146Third144Leaves99
import NineSeparatedSubsetSums.Adaptive146Third144Leaves89

namespace NineSeparatedSubsetSums

theorem adaptive146Third144Proof386 : runCachedNode 511 131319 Adaptive146Third144Node386 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 131319 Adaptive146Third144Node386 = [101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 132, 133, 135, 137] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive146Third144Proof387
  · exact adaptive146Third144Proof388
  · exact adaptive146Third144Proof389
  · exact adaptive146Third144Proof390
  · exact adaptive146Third144Proof391
  · exact adaptive146Third144Proof392
  · exact adaptive146Third144Proof393
  · exact adaptive146Third144Proof394
  · exact adaptive146Third144Proof395
  · exact adaptive146Third144Proof396
  · exact adaptive146Third144Proof397
  · exact adaptive146Third144Proof398
  · exact adaptive146Third144Proof399
  · exact adaptive146Third144Proof400
  · exact adaptive146Third144Proof401
  · exact adaptive146Third144Proof402
  · exact adaptive146Third144Proof403
  · exact adaptive146Third144Proof404
  · exact adaptive146Third144Proof405
  · exact adaptive146Third144Proof406
  · exact adaptive146Third144Proof407
  · exact adaptive146Third144Proof408
  · exact adaptive146Third144Proof409
  · exact adaptive146Third144Proof410
  · exact adaptive146Third144Proof411
  · exact adaptive146Third144Proof412
  · exact adaptive146Third144Proof413
  · exact adaptive146Third144Proof414
  · exact adaptive146Third144Proof415
  · exact adaptive146Third144Proof416
  · exact adaptive146Third144Proof450
  · exact adaptive146Third144Proof451
  · exact adaptive146Third144Proof488
  · exact adaptive146Third144Proof489
  · exact adaptive146Third144Proof490

#print axioms adaptive146Third144Proof386

theorem adaptive146Third144Proof564 : runCachedNode 511 131319 Adaptive146Third144Node564 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 131319 Adaptive146Third144Node564 = [89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 122, 124, 126, 131] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive146Third144Proof565
  · exact adaptive146Third144Proof566
  · exact adaptive146Third144Proof567
  · exact adaptive146Third144Proof568
  · exact adaptive146Third144Proof569
  · exact adaptive146Third144Proof570
  · exact adaptive146Third144Proof571
  · exact adaptive146Third144Proof572
  · exact adaptive146Third144Proof573
  · exact adaptive146Third144Proof574
  · exact adaptive146Third144Proof575
  · exact adaptive146Third144Proof576
  · exact adaptive146Third144Proof577
  · exact adaptive146Third144Proof578
  · exact adaptive146Third144Proof579
  · exact adaptive146Third144Proof580
  · exact adaptive146Third144Proof581
  · exact adaptive146Third144Proof582
  · exact adaptive146Third144Proof583
  · exact adaptive146Third144Proof584
  · exact adaptive146Third144Proof585
  · exact adaptive146Third144Proof586
  · exact adaptive146Third144Proof587
  · exact adaptive146Third144Proof588
  · exact adaptive146Third144Proof589
  · exact adaptive146Third144Proof590
  · exact adaptive146Third144Proof591
  · exact adaptive146Third144Proof592
  · exact adaptive146Third144Proof593
  · exact adaptive146Third144Proof594
  · exact adaptive146Third144Proof595
  · exact adaptive146Third144Proof596
  · exact adaptive146Third144Proof597
  · exact adaptive146Third144Proof598
  · exact adaptive146Third144Proof599
  · exact adaptive146Third144Proof600

#print axioms adaptive146Third144Proof564

theorem adaptive146Third144Proof602 : runCachedNode 511 131319 Adaptive146Third144Node602 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 131319 Adaptive146Third144Node602 = [89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 124, 126, 128, 133] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive146Third144Proof603
  · exact adaptive146Third144Proof604
  · exact adaptive146Third144Proof605
  · exact adaptive146Third144Proof606
  · exact adaptive146Third144Proof607
  · exact adaptive146Third144Proof608
  · exact adaptive146Third144Proof609
  · exact adaptive146Third144Proof610
  · exact adaptive146Third144Proof611
  · exact adaptive146Third144Proof612
  · exact adaptive146Third144Proof613
  · exact adaptive146Third144Proof614
  · exact adaptive146Third144Proof615
  · exact adaptive146Third144Proof616
  · exact adaptive146Third144Proof617
  · exact adaptive146Third144Proof618
  · exact adaptive146Third144Proof619
  · exact adaptive146Third144Proof620
  · exact adaptive146Third144Proof621
  · exact adaptive146Third144Proof622
  · exact adaptive146Third144Proof623
  · exact adaptive146Third144Proof624
  · exact adaptive146Third144Proof625
  · exact adaptive146Third144Proof626
  · exact adaptive146Third144Proof627
  · exact adaptive146Third144Proof628
  · exact adaptive146Third144Proof629
  · exact adaptive146Third144Proof630
  · exact adaptive146Third144Proof631
  · exact adaptive146Third144Proof632
  · exact adaptive146Third144Proof633
  · exact adaptive146Third144Proof634
  · exact adaptive146Third144Proof635
  · exact adaptive146Third144Proof636
  · exact adaptive146Third144Proof637
  · exact adaptive146Third144Proof638
  · exact adaptive146Third144Proof639
  · exact adaptive146Third144Proof640

#print axioms adaptive146Third144Proof602

theorem adaptive146Third144Proof642 : runCachedNode 511 131319 Adaptive146Third144Node642 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 131319 Adaptive146Third144Node642 = [87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 128, 130, 132] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive146Third144Proof643
  · exact adaptive146Third144Proof644
  · exact adaptive146Third144Proof645
  · exact adaptive146Third144Proof646
  · exact adaptive146Third144Proof647
  · exact adaptive146Third144Proof648
  · exact adaptive146Third144Proof649
  · exact adaptive146Third144Proof650
  · exact adaptive146Third144Proof651
  · exact adaptive146Third144Proof652
  · exact adaptive146Third144Proof653
  · exact adaptive146Third144Proof654
  · exact adaptive146Third144Proof655
  · exact adaptive146Third144Proof656
  · exact adaptive146Third144Proof657
  · exact adaptive146Third144Proof658
  · exact adaptive146Third144Proof659
  · exact adaptive146Third144Proof660
  · exact adaptive146Third144Proof661
  · exact adaptive146Third144Proof662
  · exact adaptive146Third144Proof663
  · exact adaptive146Third144Proof664
  · exact adaptive146Third144Proof665
  · exact adaptive146Third144Proof666
  · exact adaptive146Third144Proof667
  · exact adaptive146Third144Proof668
  · exact adaptive146Third144Proof669
  · exact adaptive146Third144Proof670
  · exact adaptive146Third144Proof671
  · exact adaptive146Third144Proof672
  · exact adaptive146Third144Proof673
  · exact adaptive146Third144Proof674
  · exact adaptive146Third144Proof675
  · exact adaptive146Third144Proof676
  · exact adaptive146Third144Proof677
  · exact adaptive146Third144Proof678
  · exact adaptive146Third144Proof679
  · exact adaptive146Third144Proof680
  · exact adaptive146Third144Proof681
  · exact adaptive146Third144Proof682
  · exact adaptive146Third144Proof683
  · exact adaptive146Third144Proof684
  · exact adaptive146Third144Proof685

#print axioms adaptive146Third144Proof642

theorem adaptive146Third144Proof532 : runCachedNode 511 131319 Adaptive146Third144Node532 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 131319 Adaptive146Third144Node532 = [101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 132, 133, 134, 136, 138] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive146Third144Proof533
  · exact adaptive146Third144Proof534
  · exact adaptive146Third144Proof535
  · exact adaptive146Third144Proof536
  · exact adaptive146Third144Proof537
  · exact adaptive146Third144Proof538
  · exact adaptive146Third144Proof539
  · exact adaptive146Third144Proof540
  · exact adaptive146Third144Proof541
  · exact adaptive146Third144Proof542
  · exact adaptive146Third144Proof543
  · exact adaptive146Third144Proof544
  · exact adaptive146Third144Proof545
  · exact adaptive146Third144Proof546
  · exact adaptive146Third144Proof547
  · exact adaptive146Third144Proof548
  · exact adaptive146Third144Proof549
  · exact adaptive146Third144Proof550
  · exact adaptive146Third144Proof551
  · exact adaptive146Third144Proof552
  · exact adaptive146Third144Proof553
  · exact adaptive146Third144Proof554
  · exact adaptive146Third144Proof555
  · exact adaptive146Third144Proof556
  · exact adaptive146Third144Proof557
  · exact adaptive146Third144Proof558
  · exact adaptive146Third144Proof559
  · exact adaptive146Third144Proof560
  · exact adaptive146Third144Proof561
  · exact adaptive146Third144Proof562
  · exact adaptive146Third144Proof563
  · exact adaptive146Third144Proof564
  · exact adaptive146Third144Proof601
  · exact adaptive146Third144Proof602
  · exact adaptive146Third144Proof641
  · exact adaptive146Third144Proof642

#print axioms adaptive146Third144Proof532

theorem adaptive146Third144Proof715 : runCachedNode 511 131319 Adaptive146Third144Node715 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 131319 Adaptive146Third144Node715 = [91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 119, 121, 123, 125, 127] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive146Third144Proof716
  · exact adaptive146Third144Proof717
  · exact adaptive146Third144Proof718
  · exact adaptive146Third144Proof719
  · exact adaptive146Third144Proof720
  · exact adaptive146Third144Proof721
  · exact adaptive146Third144Proof722
  · exact adaptive146Third144Proof723
  · exact adaptive146Third144Proof724
  · exact adaptive146Third144Proof725
  · exact adaptive146Third144Proof726
  · exact adaptive146Third144Proof727
  · exact adaptive146Third144Proof728
  · exact adaptive146Third144Proof729
  · exact adaptive146Third144Proof730
  · exact adaptive146Third144Proof731
  · exact adaptive146Third144Proof732
  · exact adaptive146Third144Proof733
  · exact adaptive146Third144Proof734
  · exact adaptive146Third144Proof735
  · exact adaptive146Third144Proof736
  · exact adaptive146Third144Proof737
  · exact adaptive146Third144Proof738
  · exact adaptive146Third144Proof739
  · exact adaptive146Third144Proof740
  · exact adaptive146Third144Proof741
  · exact adaptive146Third144Proof742
  · exact adaptive146Third144Proof743
  · exact adaptive146Third144Proof744
  · exact adaptive146Third144Proof745
  · exact adaptive146Third144Proof746
  · exact adaptive146Third144Proof747

#print axioms adaptive146Third144Proof715

theorem adaptive146Third144Proof749 : runCachedNode 511 131319 Adaptive146Third144Node749 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 131319 Adaptive146Third144Node749 = [90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 121, 123, 125, 127, 129] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive146Third144Proof750
  · exact adaptive146Third144Proof751
  · exact adaptive146Third144Proof752
  · exact adaptive146Third144Proof753
  · exact adaptive146Third144Proof754
  · exact adaptive146Third144Proof755
  · exact adaptive146Third144Proof756
  · exact adaptive146Third144Proof757
  · exact adaptive146Third144Proof758
  · exact adaptive146Third144Proof759
  · exact adaptive146Third144Proof760
  · exact adaptive146Third144Proof761
  · exact adaptive146Third144Proof762
  · exact adaptive146Third144Proof763
  · exact adaptive146Third144Proof764
  · exact adaptive146Third144Proof765
  · exact adaptive146Third144Proof766
  · exact adaptive146Third144Proof767
  · exact adaptive146Third144Proof768
  · exact adaptive146Third144Proof769
  · exact adaptive146Third144Proof770
  · exact adaptive146Third144Proof771
  · exact adaptive146Third144Proof772
  · exact adaptive146Third144Proof773
  · exact adaptive146Third144Proof774
  · exact adaptive146Third144Proof775
  · exact adaptive146Third144Proof776
  · exact adaptive146Third144Proof777
  · exact adaptive146Third144Proof778
  · exact adaptive146Third144Proof779
  · exact adaptive146Third144Proof780
  · exact adaptive146Third144Proof781
  · exact adaptive146Third144Proof782
  · exact adaptive146Third144Proof783
  · exact adaptive146Third144Proof784

#print axioms adaptive146Third144Proof749

theorem adaptive146Third144Proof785 : runCachedNode 511 131319 Adaptive146Third144Node785 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 131319 Adaptive146Third144Node785 = [89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 122, 124, 126, 128, 130] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive146Third144Proof786
  · exact adaptive146Third144Proof787
  · exact adaptive146Third144Proof788
  · exact adaptive146Third144Proof789
  · exact adaptive146Third144Proof790
  · exact adaptive146Third144Proof791
  · exact adaptive146Third144Proof792
  · exact adaptive146Third144Proof793
  · exact adaptive146Third144Proof794
  · exact adaptive146Third144Proof795
  · exact adaptive146Third144Proof796
  · exact adaptive146Third144Proof797
  · exact adaptive146Third144Proof798
  · exact adaptive146Third144Proof799
  · exact adaptive146Third144Proof800
  · exact adaptive146Third144Proof801
  · exact adaptive146Third144Proof802
  · exact adaptive146Third144Proof803
  · exact adaptive146Third144Proof804
  · exact adaptive146Third144Proof805
  · exact adaptive146Third144Proof806
  · exact adaptive146Third144Proof807
  · exact adaptive146Third144Proof808
  · exact adaptive146Third144Proof809
  · exact adaptive146Third144Proof810
  · exact adaptive146Third144Proof811
  · exact adaptive146Third144Proof812
  · exact adaptive146Third144Proof813
  · exact adaptive146Third144Proof814
  · exact adaptive146Third144Proof815
  · exact adaptive146Third144Proof816
  · exact adaptive146Third144Proof817
  · exact adaptive146Third144Proof818
  · exact adaptive146Third144Proof819
  · exact adaptive146Third144Proof820
  · exact adaptive146Third144Proof821
  · exact adaptive146Third144Proof822

#print axioms adaptive146Third144Proof785

end NineSeparatedSubsetSums
