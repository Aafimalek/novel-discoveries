import NineSeparatedSubsetSums.Adaptive146Third144State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third144Proof489 : runCachedNode 511 131319 Adaptive146Third144Node489 = false := by
  decide +kernel

#print axioms adaptive146Third144Proof489

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third144Proof444 : runCachedNode 511 131319 Adaptive146Third144Node444 = false := by
  decide +kernel

#print axioms adaptive146Third144Proof444

end NineSeparatedSubsetSums
