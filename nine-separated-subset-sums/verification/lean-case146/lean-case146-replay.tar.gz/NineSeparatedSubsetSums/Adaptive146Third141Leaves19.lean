import NineSeparatedSubsetSums.Adaptive146Third141State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third141Proof233 : runCachedNode 511 130916 Adaptive146Third141Node233 = false := by
  decide +kernel

#print axioms adaptive146Third141Proof233

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third141Proof17 : runCachedNode 511 130916 Adaptive146Third141Node17 = false := by
  decide +kernel

#print axioms adaptive146Third141Proof17

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third141Proof168 : runCachedNode 511 130916 Adaptive146Third141Node168 = false := by
  decide +kernel

#print axioms adaptive146Third141Proof168

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third141Proof115 : runCachedNode 511 130916 Adaptive146Third141Node115 = false := by
  decide +kernel

#print axioms adaptive146Third141Proof115

end NineSeparatedSubsetSums
