import NineSeparatedSubsetSums.Adaptive146Third142State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third142Proof238 : runCachedNode 511 131054 Adaptive146Third142Node238 = false := by
  decide +kernel

#print axioms adaptive146Third142Proof238

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third142Proof112 : runCachedNode 511 131054 Adaptive146Third142Node112 = false := by
  decide +kernel

#print axioms adaptive146Third142Proof112

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third142Proof319 : runCachedNode 511 131054 Adaptive146Third142Node319 = false := by
  decide +kernel

#print axioms adaptive146Third142Proof319

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third142Proof398 : runCachedNode 511 131054 Adaptive146Third142Node398 = false := by
  decide +kernel

#print axioms adaptive146Third142Proof398

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third142Proof109 : runCachedNode 511 131054 Adaptive146Third142Node109 = false := by
  decide +kernel

#print axioms adaptive146Third142Proof109

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third142Proof4 : runCachedNode 511 131054 Adaptive146Third142Node4 = false := by
  decide +kernel

#print axioms adaptive146Third142Proof4

end NineSeparatedSubsetSums
