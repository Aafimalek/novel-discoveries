import NineSeparatedSubsetSums.Adaptive146Third143State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third143Proof411 : runCachedNode 511 131193 Adaptive146Third143Node411 = false := by
  decide +kernel

#print axioms adaptive146Third143Proof411

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third143Proof383 : runCachedNode 511 131193 Adaptive146Third143Node383 = false := by
  decide +kernel

#print axioms adaptive146Third143Proof383

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third143Proof224 : runCachedNode 511 131193 Adaptive146Third143Node224 = false := by
  decide +kernel

#print axioms adaptive146Third143Proof224

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third143Proof74 : runCachedNode 511 131193 Adaptive146Third143Node74 = false := by
  decide +kernel

#print axioms adaptive146Third143Proof74

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third143Proof101 : runCachedNode 511 131193 Adaptive146Third143Node101 = false := by
  decide +kernel

#print axioms adaptive146Third143Proof101

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third143Proof102 : runCachedNode 511 131193 Adaptive146Third143Node102 = false := by
  decide +kernel

#print axioms adaptive146Third143Proof102

end NineSeparatedSubsetSums
