import NineSeparatedSubsetSums.Adaptive146Third114Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint146Checked

namespace NineSeparatedSubsetSums


theorem adaptive146Third114 : NoDescendingTailAfterThird 146 114 :=
  noDescendingThirdTail_of_cached 146 114 112631 (fun t ht nd => max148_second146_fourPoint_moment_bound (114::t) (by simp [ht]) nd) adaptive146Third114Proof0

#print axioms adaptive146Third114

end NineSeparatedSubsetSums
