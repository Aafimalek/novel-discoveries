import NineSeparatedSubsetSums.Adaptive146Third127State
import NineSeparatedSubsetSums.Adaptive146Third127Leaves1
import NineSeparatedSubsetSums.Adaptive146Third127Leaves0

namespace NineSeparatedSubsetSums

theorem adaptive146Third127Proof0 : runCachedNode 511 128361 Adaptive146Third127Node0 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 128361 Adaptive146Third127Node0 = [110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 126] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive146Third127Proof1
  · exact adaptive146Third127Proof2
  · exact adaptive146Third127Proof3
  · exact adaptive146Third127Proof4
  · exact adaptive146Third127Proof5
  · exact adaptive146Third127Proof6
  · exact adaptive146Third127Proof7
  · exact adaptive146Third127Proof8
  · exact adaptive146Third127Proof9
  · exact adaptive146Third127Proof10
  · exact adaptive146Third127Proof11
  · exact adaptive146Third127Proof12
  · exact adaptive146Third127Proof13
  · exact adaptive146Third127Proof14
  · exact adaptive146Third127Proof15
  · exact adaptive146Third127Proof16

#print axioms adaptive146Third127Proof0

end NineSeparatedSubsetSums
