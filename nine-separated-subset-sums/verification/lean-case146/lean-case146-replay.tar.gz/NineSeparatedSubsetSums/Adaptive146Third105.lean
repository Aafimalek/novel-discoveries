import NineSeparatedSubsetSums.Adaptive146Third105Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint146Checked

namespace NineSeparatedSubsetSums


theorem adaptive146Third105 : NoDescendingTailAfterThird 146 105 :=
  noDescendingThirdTail_of_cached 146 105 112631 (fun t ht nd => max148_second146_fourPoint_moment_bound (105::t) (by simp [ht]) nd) adaptive146Third105Proof0

#print axioms adaptive146Third105

end NineSeparatedSubsetSums
