import NineSeparatedSubsetSums.Adaptive146Third139State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third139Proof217 : runCachedNode 511 130638 Adaptive146Third139Node217 = false := by
  decide +kernel

#print axioms adaptive146Third139Proof217

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third139Proof97 : runCachedNode 511 130638 Adaptive146Third139Node97 = false := by
  decide +kernel

#print axioms adaptive146Third139Proof97

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third139Proof150 : runCachedNode 511 130638 Adaptive146Third139Node150 = false := by
  decide +kernel

#print axioms adaptive146Third139Proof150

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third139Proof4 : runCachedNode 511 130638 Adaptive146Third139Node4 = false := by
  decide +kernel

#print axioms adaptive146Third139Proof4

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third139Proof1 : runCachedNode 511 130638 Adaptive146Third139Node1 = false := by
  decide +kernel

#print axioms adaptive146Third139Proof1

end NineSeparatedSubsetSums
