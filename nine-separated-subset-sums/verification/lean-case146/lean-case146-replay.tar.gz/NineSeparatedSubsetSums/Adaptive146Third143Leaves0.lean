import NineSeparatedSubsetSums.Adaptive146Third143State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third143Proof418 : runCachedNode 511 131193 Adaptive146Third143Node418 = false := by
  decide +kernel

#print axioms adaptive146Third143Proof418

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third143Proof64 : runCachedNode 511 131193 Adaptive146Third143Node64 = false := by
  decide +kernel

#print axioms adaptive146Third143Proof64

end NineSeparatedSubsetSums
