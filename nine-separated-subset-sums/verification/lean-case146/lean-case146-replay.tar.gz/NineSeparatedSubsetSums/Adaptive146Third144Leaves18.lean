import NineSeparatedSubsetSums.Adaptive146Third144State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third144Proof562 : runCachedNode 511 131319 Adaptive146Third144Node562 = false := by
  decide +kernel

#print axioms adaptive146Third144Proof562

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third144Proof84 : runCachedNode 511 131319 Adaptive146Third144Node84 = false := by
  decide +kernel

#print axioms adaptive146Third144Proof84

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third144Proof5 : runCachedNode 511 131319 Adaptive146Third144Node5 = false := by
  decide +kernel

#print axioms adaptive146Third144Proof5

end NineSeparatedSubsetSums
