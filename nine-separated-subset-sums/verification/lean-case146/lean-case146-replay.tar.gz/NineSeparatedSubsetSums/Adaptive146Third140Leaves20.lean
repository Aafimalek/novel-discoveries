import NineSeparatedSubsetSums.Adaptive146Third140State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third140Proof280 : runCachedNode 511 130775 Adaptive146Third140Node280 = false := by
  decide +kernel

#print axioms adaptive146Third140Proof280

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third140Proof148 : runCachedNode 511 130775 Adaptive146Third140Node148 = false := by
  decide +kernel

#print axioms adaptive146Third140Proof148

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third140Proof380 : runCachedNode 511 130775 Adaptive146Third140Node380 = false := by
  decide +kernel

#print axioms adaptive146Third140Proof380

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third140Proof272 : runCachedNode 511 130775 Adaptive146Third140Node272 = false := by
  decide +kernel

#print axioms adaptive146Third140Proof272

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third140Proof45 : runCachedNode 511 130775 Adaptive146Third140Node45 = false := by
  decide +kernel

#print axioms adaptive146Third140Proof45

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third140Proof13 : runCachedNode 511 130775 Adaptive146Third140Node13 = false := by
  decide +kernel

#print axioms adaptive146Third140Proof13

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third140Proof81 : runCachedNode 511 130775 Adaptive146Third140Node81 = false := by
  decide +kernel

#print axioms adaptive146Third140Proof81

end NineSeparatedSubsetSums
