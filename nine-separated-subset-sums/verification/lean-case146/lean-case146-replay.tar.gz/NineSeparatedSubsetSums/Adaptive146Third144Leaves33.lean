import NineSeparatedSubsetSums.Adaptive146Third144State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third144Proof450 : runCachedNode 511 131319 Adaptive146Third144Node450 = false := by
  decide +kernel

#print axioms adaptive146Third144Proof450

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third144Proof1252 : runCachedNode 511 131319 Adaptive146Third144Node1252 = false := by
  decide +kernel

#print axioms adaptive146Third144Proof1252

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third144Proof498 : runCachedNode 511 131319 Adaptive146Third144Node498 = false := by
  decide +kernel

#print axioms adaptive146Third144Proof498

end NineSeparatedSubsetSums
