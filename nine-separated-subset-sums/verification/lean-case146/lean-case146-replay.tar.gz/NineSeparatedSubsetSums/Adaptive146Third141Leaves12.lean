import NineSeparatedSubsetSums.Adaptive146Third141State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third141Proof20 : runCachedNode 511 130916 Adaptive146Third141Node20 = false := by
  decide +kernel

#print axioms adaptive146Third141Proof20

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third141Proof236 : runCachedNode 511 130916 Adaptive146Third141Node236 = false := by
  decide +kernel

#print axioms adaptive146Third141Proof236

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third141Proof6 : runCachedNode 511 130916 Adaptive146Third141Node6 = false := by
  decide +kernel

#print axioms adaptive146Third141Proof6

end NineSeparatedSubsetSums
