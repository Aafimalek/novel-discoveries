import NineSeparatedSubsetSums.Adaptive146Third144State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third144Proof1480 : runCachedNode 511 131319 Adaptive146Third144Node1480 = false := by
  decide +kernel

#print axioms adaptive146Third144Proof1480

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third144Proof413 : runCachedNode 511 131319 Adaptive146Third144Node413 = false := by
  decide +kernel

#print axioms adaptive146Third144Proof413

end NineSeparatedSubsetSums
