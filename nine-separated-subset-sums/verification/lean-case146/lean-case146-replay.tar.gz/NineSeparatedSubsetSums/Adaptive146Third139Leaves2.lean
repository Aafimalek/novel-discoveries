import NineSeparatedSubsetSums.Adaptive146Third139State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third139Proof184 : runCachedNode 511 130638 Adaptive146Third139Node184 = false := by
  decide +kernel

#print axioms adaptive146Third139Proof184

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third139Proof245 : runCachedNode 511 130638 Adaptive146Third139Node245 = false := by
  decide +kernel

#print axioms adaptive146Third139Proof245

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third139Proof51 : runCachedNode 511 130638 Adaptive146Third139Node51 = false := by
  decide +kernel

#print axioms adaptive146Third139Proof51

end NineSeparatedSubsetSums
