import NineSeparatedSubsetSums.Adaptive146Third136State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third136Proof14 : runCachedNode 511 130191 Adaptive146Third136Node14 = false := by
  decide +kernel

#print axioms adaptive146Third136Proof14

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third136Proof125 : runCachedNode 511 130191 Adaptive146Third136Node125 = false := by
  decide +kernel

#print axioms adaptive146Third136Proof125

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third136Proof122 : runCachedNode 511 130191 Adaptive146Third136Node122 = false := by
  decide +kernel

#print axioms adaptive146Third136Proof122

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third136Proof13 : runCachedNode 511 130191 Adaptive146Third136Node13 = false := by
  decide +kernel

#print axioms adaptive146Third136Proof13

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third136Proof66 : runCachedNode 511 130191 Adaptive146Third136Node66 = false := by
  decide +kernel

#print axioms adaptive146Third136Proof66

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third136Proof94 : runCachedNode 511 130191 Adaptive146Third136Node94 = false := by
  decide +kernel

#print axioms adaptive146Third136Proof94

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third136Proof2 : runCachedNode 511 130191 Adaptive146Third136Node2 = false := by
  decide +kernel

#print axioms adaptive146Third136Proof2

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third136Proof74 : runCachedNode 511 130191 Adaptive146Third136Node74 = false := by
  decide +kernel

#print axioms adaptive146Third136Proof74

end NineSeparatedSubsetSums
