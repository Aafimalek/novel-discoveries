import NineSeparatedSubsetSums.Adaptive146Third136State
import NineSeparatedSubsetSums.Adaptive146Third136Leaves12
import NineSeparatedSubsetSums.Adaptive146Third136Leaves2
import NineSeparatedSubsetSums.Adaptive146Third136Leaves4
import NineSeparatedSubsetSums.Adaptive146Third136Leaves11
import NineSeparatedSubsetSums.Adaptive146Third136Leaves7
import NineSeparatedSubsetSums.Adaptive146Third136Leaves9
import NineSeparatedSubsetSums.Adaptive146Third136Leaves10
import NineSeparatedSubsetSums.Adaptive146Third136Leaves6
import NineSeparatedSubsetSums.Adaptive146Third136Leaves3
import NineSeparatedSubsetSums.Adaptive146Third136Leaves8
import NineSeparatedSubsetSums.Adaptive146Third136Leaves5
import NineSeparatedSubsetSums.Adaptive146Third136Leaves0
import NineSeparatedSubsetSums.Adaptive146Third136Leaves1

namespace NineSeparatedSubsetSums

theorem adaptive146Third136Proof22 : runCachedNode 511 130191 Adaptive146Third136Node22 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130191 Adaptive146Third136Node22 = [104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 120, 122, 123, 124, 125, 126, 127, 128, 130] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive146Third136Proof23
  · exact adaptive146Third136Proof24
  · exact adaptive146Third136Proof25
  · exact adaptive146Third136Proof26
  · exact adaptive146Third136Proof27
  · exact adaptive146Third136Proof28
  · exact adaptive146Third136Proof29
  · exact adaptive146Third136Proof30
  · exact adaptive146Third136Proof31
  · exact adaptive146Third136Proof32
  · exact adaptive146Third136Proof33
  · exact adaptive146Third136Proof34
  · exact adaptive146Third136Proof35
  · exact adaptive146Third136Proof36
  · exact adaptive146Third136Proof37
  · exact adaptive146Third136Proof38
  · exact adaptive146Third136Proof39
  · exact adaptive146Third136Proof40
  · exact adaptive146Third136Proof41
  · exact adaptive146Third136Proof42
  · exact adaptive146Third136Proof43
  · exact adaptive146Third136Proof44
  · exact adaptive146Third136Proof45
  · exact adaptive146Third136Proof46

#print axioms adaptive146Third136Proof22

theorem adaptive146Third136Proof47 : runCachedNode 511 130191 Adaptive146Third136Node47 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130191 Adaptive146Third136Node47 = [104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 121, 123, 124, 125, 126, 127, 128, 129, 131] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive146Third136Proof48
  · exact adaptive146Third136Proof49
  · exact adaptive146Third136Proof50
  · exact adaptive146Third136Proof51
  · exact adaptive146Third136Proof52
  · exact adaptive146Third136Proof53
  · exact adaptive146Third136Proof54
  · exact adaptive146Third136Proof55
  · exact adaptive146Third136Proof56
  · exact adaptive146Third136Proof57
  · exact adaptive146Third136Proof58
  · exact adaptive146Third136Proof59
  · exact adaptive146Third136Proof60
  · exact adaptive146Third136Proof61
  · exact adaptive146Third136Proof62
  · exact adaptive146Third136Proof63
  · exact adaptive146Third136Proof64
  · exact adaptive146Third136Proof65
  · exact adaptive146Third136Proof66
  · exact adaptive146Third136Proof67
  · exact adaptive146Third136Proof68
  · exact adaptive146Third136Proof69
  · exact adaptive146Third136Proof70
  · exact adaptive146Third136Proof71
  · exact adaptive146Third136Proof72

#print axioms adaptive146Third136Proof47

theorem adaptive146Third136Proof73 : runCachedNode 511 130191 Adaptive146Third136Node73 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130191 Adaptive146Third136Node73 = [103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 122, 124, 125, 126, 127, 128, 129, 130, 132] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive146Third136Proof74
  · exact adaptive146Third136Proof75
  · exact adaptive146Third136Proof76
  · exact adaptive146Third136Proof77
  · exact adaptive146Third136Proof78
  · exact adaptive146Third136Proof79
  · exact adaptive146Third136Proof80
  · exact adaptive146Third136Proof81
  · exact adaptive146Third136Proof82
  · exact adaptive146Third136Proof83
  · exact adaptive146Third136Proof84
  · exact adaptive146Third136Proof85
  · exact adaptive146Third136Proof86
  · exact adaptive146Third136Proof87
  · exact adaptive146Third136Proof88
  · exact adaptive146Third136Proof89
  · exact adaptive146Third136Proof90
  · exact adaptive146Third136Proof91
  · exact adaptive146Third136Proof92
  · exact adaptive146Third136Proof93
  · exact adaptive146Third136Proof94
  · exact adaptive146Third136Proof95
  · exact adaptive146Third136Proof96
  · exact adaptive146Third136Proof97
  · exact adaptive146Third136Proof98
  · exact adaptive146Third136Proof99
  · exact adaptive146Third136Proof100

#print axioms adaptive146Third136Proof73

theorem adaptive146Third136Proof101 : runCachedNode 511 130191 Adaptive146Third136Node101 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130191 Adaptive146Third136Node101 = [103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 124, 126, 127, 128, 129, 130, 131, 132] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive146Third136Proof102
  · exact adaptive146Third136Proof103
  · exact adaptive146Third136Proof104
  · exact adaptive146Third136Proof105
  · exact adaptive146Third136Proof106
  · exact adaptive146Third136Proof107
  · exact adaptive146Third136Proof108
  · exact adaptive146Third136Proof109
  · exact adaptive146Third136Proof110
  · exact adaptive146Third136Proof111
  · exact adaptive146Third136Proof112
  · exact adaptive146Third136Proof113
  · exact adaptive146Third136Proof114
  · exact adaptive146Third136Proof115
  · exact adaptive146Third136Proof116
  · exact adaptive146Third136Proof117
  · exact adaptive146Third136Proof118
  · exact adaptive146Third136Proof119
  · exact adaptive146Third136Proof120
  · exact adaptive146Third136Proof121
  · exact adaptive146Third136Proof122
  · exact adaptive146Third136Proof123
  · exact adaptive146Third136Proof124
  · exact adaptive146Third136Proof125
  · exact adaptive146Third136Proof126
  · exact adaptive146Third136Proof127
  · exact adaptive146Third136Proof128
  · exact adaptive146Third136Proof129

#print axioms adaptive146Third136Proof101

theorem adaptive146Third136Proof0 : runCachedNode 511 130191 Adaptive146Third136Node0 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130191 Adaptive146Third136Node0 = [110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 132, 133, 135] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive146Third136Proof1
  · exact adaptive146Third136Proof2
  · exact adaptive146Third136Proof3
  · exact adaptive146Third136Proof4
  · exact adaptive146Third136Proof5
  · exact adaptive146Third136Proof6
  · exact adaptive146Third136Proof7
  · exact adaptive146Third136Proof8
  · exact adaptive146Third136Proof9
  · exact adaptive146Third136Proof10
  · exact adaptive146Third136Proof11
  · exact adaptive146Third136Proof12
  · exact adaptive146Third136Proof13
  · exact adaptive146Third136Proof14
  · exact adaptive146Third136Proof15
  · exact adaptive146Third136Proof16
  · exact adaptive146Third136Proof17
  · exact adaptive146Third136Proof18
  · exact adaptive146Third136Proof19
  · exact adaptive146Third136Proof20
  · exact adaptive146Third136Proof21
  · exact adaptive146Third136Proof22
  · exact adaptive146Third136Proof47
  · exact adaptive146Third136Proof73
  · exact adaptive146Third136Proof101

#print axioms adaptive146Third136Proof0

end NineSeparatedSubsetSums
