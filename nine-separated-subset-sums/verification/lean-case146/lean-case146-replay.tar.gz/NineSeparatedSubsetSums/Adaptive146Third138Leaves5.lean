import NineSeparatedSubsetSums.Adaptive146Third138State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third138Proof149 : runCachedNode 511 130484 Adaptive146Third138Node149 = false := by
  decide +kernel

#print axioms adaptive146Third138Proof149

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third138Proof17 : runCachedNode 511 130484 Adaptive146Third138Node17 = false := by
  decide +kernel

#print axioms adaptive146Third138Proof17

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third138Proof177 : runCachedNode 511 130484 Adaptive146Third138Node177 = false := by
  decide +kernel

#print axioms adaptive146Third138Proof177

end NineSeparatedSubsetSums
