import NineSeparatedSubsetSums.Adaptive146Third141State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third141Proof23 : runCachedNode 511 130916 Adaptive146Third141Node23 = false := by
  decide +kernel

#print axioms adaptive146Third141Proof23

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third141Proof10 : runCachedNode 511 130916 Adaptive146Third141Node10 = false := by
  decide +kernel

#print axioms adaptive146Third141Proof10

end NineSeparatedSubsetSums
