import NineSeparatedSubsetSums.Adaptive146Third127State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third127Proof16 : runCachedNode 511 128361 Adaptive146Third127Node16 = false := by
  decide +kernel

#print axioms adaptive146Third127Proof16

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third127Proof14 : runCachedNode 511 128361 Adaptive146Third127Node14 = false := by
  decide +kernel

#print axioms adaptive146Third127Proof14

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third127Proof15 : runCachedNode 511 128361 Adaptive146Third127Node15 = false := by
  decide +kernel

#print axioms adaptive146Third127Proof15

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third127Proof13 : runCachedNode 511 128361 Adaptive146Third127Node13 = false := by
  decide +kernel

#print axioms adaptive146Third127Proof13

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third127Proof12 : runCachedNode 511 128361 Adaptive146Third127Node12 = false := by
  decide +kernel

#print axioms adaptive146Third127Proof12

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third127Proof7 : runCachedNode 511 128361 Adaptive146Third127Node7 = false := by
  decide +kernel

#print axioms adaptive146Third127Proof7

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third127Proof4 : runCachedNode 511 128361 Adaptive146Third127Node4 = false := by
  decide +kernel

#print axioms adaptive146Third127Proof4

end NineSeparatedSubsetSums
