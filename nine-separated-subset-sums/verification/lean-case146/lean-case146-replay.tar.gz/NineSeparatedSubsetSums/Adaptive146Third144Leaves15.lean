import NineSeparatedSubsetSums.Adaptive146Third144State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third144Proof385 : runCachedNode 511 131319 Adaptive146Third144Node385 = false := by
  decide +kernel

#print axioms adaptive146Third144Proof385

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third144Proof1111 : runCachedNode 511 131319 Adaptive146Third144Node1111 = false := by
  decide +kernel

#print axioms adaptive146Third144Proof1111

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third144Proof494 : runCachedNode 511 131319 Adaptive146Third144Node494 = false := by
  decide +kernel

#print axioms adaptive146Third144Proof494

end NineSeparatedSubsetSums
