import NineSeparatedSubsetSums.Adaptive146Third136State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third136Proof45 : runCachedNode 511 130191 Adaptive146Third136Node45 = false := by
  decide +kernel

#print axioms adaptive146Third136Proof45

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third136Proof95 : runCachedNode 511 130191 Adaptive146Third136Node95 = false := by
  decide +kernel

#print axioms adaptive146Third136Proof95

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third136Proof126 : runCachedNode 511 130191 Adaptive146Third136Node126 = false := by
  decide +kernel

#print axioms adaptive146Third136Proof126

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third136Proof46 : runCachedNode 511 130191 Adaptive146Third136Node46 = false := by
  decide +kernel

#print axioms adaptive146Third136Proof46

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third136Proof124 : runCachedNode 511 130191 Adaptive146Third136Node124 = false := by
  decide +kernel

#print axioms adaptive146Third136Proof124

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third136Proof12 : runCachedNode 511 130191 Adaptive146Third136Node12 = false := by
  decide +kernel

#print axioms adaptive146Third136Proof12

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third136Proof41 : runCachedNode 511 130191 Adaptive146Third136Node41 = false := by
  decide +kernel

#print axioms adaptive146Third136Proof41

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third136Proof52 : runCachedNode 511 130191 Adaptive146Third136Node52 = false := by
  decide +kernel

#print axioms adaptive146Third136Proof52

end NineSeparatedSubsetSums
