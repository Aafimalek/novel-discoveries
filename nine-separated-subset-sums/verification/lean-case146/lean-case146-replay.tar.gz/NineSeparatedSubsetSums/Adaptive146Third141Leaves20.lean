import NineSeparatedSubsetSums.Adaptive146Third141State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third141Proof314 : runCachedNode 511 130916 Adaptive146Third141Node314 = false := by
  decide +kernel

#print axioms adaptive146Third141Proof314

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third141Proof106 : runCachedNode 511 130916 Adaptive146Third141Node106 = false := by
  decide +kernel

#print axioms adaptive146Third141Proof106

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third141Proof270 : runCachedNode 511 130916 Adaptive146Third141Node270 = false := by
  decide +kernel

#print axioms adaptive146Third141Proof270

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third141Proof189 : runCachedNode 511 130916 Adaptive146Third141Node189 = false := by
  decide +kernel

#print axioms adaptive146Third141Proof189

end NineSeparatedSubsetSums
