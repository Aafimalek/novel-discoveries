import NineSeparatedSubsetSums.Adaptive146Third142State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third142Proof24 : runCachedNode 511 131054 Adaptive146Third142Node24 = false := by
  decide +kernel

#print axioms adaptive146Third142Proof24

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third142Proof77 : runCachedNode 511 131054 Adaptive146Third142Node77 = false := by
  decide +kernel

#print axioms adaptive146Third142Proof77

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third142Proof1 : runCachedNode 511 131054 Adaptive146Third142Node1 = false := by
  decide +kernel

#print axioms adaptive146Third142Proof1

end NineSeparatedSubsetSums
