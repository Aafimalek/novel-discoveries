import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive146Third109Node0 : CachedSearchNode :=
  ⟨4, 108, computeCenteredMask [148,146,109], 403, 55101⟩

end NineSeparatedSubsetSums
