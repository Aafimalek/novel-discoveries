import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive146Third114Node0 : CachedSearchNode :=
  ⟨4, 113, computeCenteredMask [148,146,114], 408, 56216⟩

end NineSeparatedSubsetSums
