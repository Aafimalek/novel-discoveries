import NineSeparatedSubsetSums.Adaptive146Third144State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third144Proof1303 : runCachedNode 511 131319 Adaptive146Third144Node1303 = false := by
  decide +kernel

#print axioms adaptive146Third144Proof1303

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third144Proof1338 : runCachedNode 511 131319 Adaptive146Third144Node1338 = false := by
  decide +kernel

#print axioms adaptive146Third144Proof1338

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third144Proof1339 : runCachedNode 511 131319 Adaptive146Third144Node1339 = false := by
  decide +kernel

#print axioms adaptive146Third144Proof1339

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third144Proof1340 : runCachedNode 511 131319 Adaptive146Third144Node1340 = false := by
  decide +kernel

#print axioms adaptive146Third144Proof1340

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third144Proof1341 : runCachedNode 511 131319 Adaptive146Third144Node1341 = false := by
  decide +kernel

#print axioms adaptive146Third144Proof1341

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third144Proof1342 : runCachedNode 511 131319 Adaptive146Third144Node1342 = false := by
  decide +kernel

#print axioms adaptive146Third144Proof1342

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third144Proof1343 : runCachedNode 511 131319 Adaptive146Third144Node1343 = false := by
  decide +kernel

#print axioms adaptive146Third144Proof1343

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third144Proof1344 : runCachedNode 511 131319 Adaptive146Third144Node1344 = false := by
  decide +kernel

#print axioms adaptive146Third144Proof1344

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third144Proof1345 : runCachedNode 511 131319 Adaptive146Third144Node1345 = false := by
  decide +kernel

#print axioms adaptive146Third144Proof1345

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third144Proof1346 : runCachedNode 511 131319 Adaptive146Third144Node1346 = false := by
  decide +kernel

#print axioms adaptive146Third144Proof1346

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third144Proof1347 : runCachedNode 511 131319 Adaptive146Third144Node1347 = false := by
  decide +kernel

#print axioms adaptive146Third144Proof1347

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third144Proof1384 : runCachedNode 511 131319 Adaptive146Third144Node1384 = false := by
  decide +kernel

#print axioms adaptive146Third144Proof1384

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third144Proof1385 : runCachedNode 511 131319 Adaptive146Third144Node1385 = false := by
  decide +kernel

#print axioms adaptive146Third144Proof1385

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third144Proof1386 : runCachedNode 511 131319 Adaptive146Third144Node1386 = false := by
  decide +kernel

#print axioms adaptive146Third144Proof1386

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third144Proof1387 : runCachedNode 511 131319 Adaptive146Third144Node1387 = false := by
  decide +kernel

#print axioms adaptive146Third144Proof1387

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third144Proof1388 : runCachedNode 511 131319 Adaptive146Third144Node1388 = false := by
  decide +kernel

#print axioms adaptive146Third144Proof1388

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third144Proof1389 : runCachedNode 511 131319 Adaptive146Third144Node1389 = false := by
  decide +kernel

#print axioms adaptive146Third144Proof1389

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third144Proof1390 : runCachedNode 511 131319 Adaptive146Third144Node1390 = false := by
  decide +kernel

#print axioms adaptive146Third144Proof1390

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third144Proof1391 : runCachedNode 511 131319 Adaptive146Third144Node1391 = false := by
  decide +kernel

#print axioms adaptive146Third144Proof1391

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third144Proof1392 : runCachedNode 511 131319 Adaptive146Third144Node1392 = false := by
  decide +kernel

#print axioms adaptive146Third144Proof1392

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third144Proof1393 : runCachedNode 511 131319 Adaptive146Third144Node1393 = false := by
  decide +kernel

#print axioms adaptive146Third144Proof1393

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third144Proof1432 : runCachedNode 511 131319 Adaptive146Third144Node1432 = false := by
  decide +kernel

#print axioms adaptive146Third144Proof1432

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third144Proof1433 : runCachedNode 511 131319 Adaptive146Third144Node1433 = false := by
  decide +kernel

#print axioms adaptive146Third144Proof1433

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third144Proof1434 : runCachedNode 511 131319 Adaptive146Third144Node1434 = false := by
  decide +kernel

#print axioms adaptive146Third144Proof1434

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third144Proof1435 : runCachedNode 511 131319 Adaptive146Third144Node1435 = false := by
  decide +kernel

#print axioms adaptive146Third144Proof1435

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third144Proof1436 : runCachedNode 511 131319 Adaptive146Third144Node1436 = false := by
  decide +kernel

#print axioms adaptive146Third144Proof1436

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third144Proof1437 : runCachedNode 511 131319 Adaptive146Third144Node1437 = false := by
  decide +kernel

#print axioms adaptive146Third144Proof1437

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third144Proof1438 : runCachedNode 511 131319 Adaptive146Third144Node1438 = false := by
  decide +kernel

#print axioms adaptive146Third144Proof1438

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third144Proof1439 : runCachedNode 511 131319 Adaptive146Third144Node1439 = false := by
  decide +kernel

#print axioms adaptive146Third144Proof1439

end NineSeparatedSubsetSums
