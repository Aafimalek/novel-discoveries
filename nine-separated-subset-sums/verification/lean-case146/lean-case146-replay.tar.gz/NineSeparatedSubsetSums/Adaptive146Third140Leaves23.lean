import NineSeparatedSubsetSums.Adaptive146Third140State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third140Proof149 : runCachedNode 511 130775 Adaptive146Third140Node149 = false := by
  decide +kernel

#print axioms adaptive146Third140Proof149

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third140Proof90 : runCachedNode 511 130775 Adaptive146Third140Node90 = false := by
  decide +kernel

#print axioms adaptive146Third140Proof90

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third140Proof184 : runCachedNode 511 130775 Adaptive146Third140Node184 = false := by
  decide +kernel

#print axioms adaptive146Third140Proof184

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third140Proof12 : runCachedNode 511 130775 Adaptive146Third140Node12 = false := by
  decide +kernel

#print axioms adaptive146Third140Proof12

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third140Proof239 : runCachedNode 511 130775 Adaptive146Third140Node239 = false := by
  decide +kernel

#print axioms adaptive146Third140Proof239

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third140Proof211 : runCachedNode 511 130775 Adaptive146Third140Node211 = false := by
  decide +kernel

#print axioms adaptive146Third140Proof211

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third140Proof210 : runCachedNode 511 130775 Adaptive146Third140Node210 = false := by
  decide +kernel

#print axioms adaptive146Third140Proof210

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third140Proof310 : runCachedNode 511 130775 Adaptive146Third140Node310 = false := by
  decide +kernel

#print axioms adaptive146Third140Proof310

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third140Proof270 : runCachedNode 511 130775 Adaptive146Third140Node270 = false := by
  decide +kernel

#print axioms adaptive146Third140Proof270

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third140Proof47 : runCachedNode 511 130775 Adaptive146Third140Node47 = false := by
  decide +kernel

#print axioms adaptive146Third140Proof47

end NineSeparatedSubsetSums
