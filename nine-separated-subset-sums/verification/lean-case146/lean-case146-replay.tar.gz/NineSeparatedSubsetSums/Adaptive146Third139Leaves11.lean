import NineSeparatedSubsetSums.Adaptive146Third139State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third139Proof154 : runCachedNode 511 130638 Adaptive146Third139Node154 = false := by
  decide +kernel

#print axioms adaptive146Third139Proof154

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third139Proof95 : runCachedNode 511 130638 Adaptive146Third139Node95 = false := by
  decide +kernel

#print axioms adaptive146Third139Proof95

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third139Proof216 : runCachedNode 511 130638 Adaptive146Third139Node216 = false := by
  decide +kernel

#print axioms adaptive146Third139Proof216

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third139Proof173 : runCachedNode 511 130638 Adaptive146Third139Node173 = false := by
  decide +kernel

#print axioms adaptive146Third139Proof173

end NineSeparatedSubsetSums
