import NineSeparatedSubsetSums.Adaptive146Third141State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third141Proof169 : runCachedNode 511 130916 Adaptive146Third141Node169 = false := by
  decide +kernel

#print axioms adaptive146Third141Proof169

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third141Proof165 : runCachedNode 511 130916 Adaptive146Third141Node165 = false := by
  decide +kernel

#print axioms adaptive146Third141Proof165

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third141Proof66 : runCachedNode 511 130916 Adaptive146Third141Node66 = false := by
  decide +kernel

#print axioms adaptive146Third141Proof66

end NineSeparatedSubsetSums
