import NineSeparatedSubsetSums.Adaptive146Third139State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third139Proof19 : runCachedNode 511 130638 Adaptive146Third139Node19 = false := by
  decide +kernel

#print axioms adaptive146Third139Proof19

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third139Proof151 : runCachedNode 511 130638 Adaptive146Third139Node151 = false := by
  decide +kernel

#print axioms adaptive146Third139Proof151

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third139Proof74 : runCachedNode 511 130638 Adaptive146Third139Node74 = false := by
  decide +kernel

#print axioms adaptive146Third139Proof74

end NineSeparatedSubsetSums
