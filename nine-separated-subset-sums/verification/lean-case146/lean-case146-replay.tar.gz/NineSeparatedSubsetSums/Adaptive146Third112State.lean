import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive146Third112Node0 : CachedSearchNode :=
  ⟨4, 111, computeCenteredMask [148,146,112], 406, 55764⟩

end NineSeparatedSubsetSums
