import NineSeparatedSubsetSums.Adaptive146Third144State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third144Proof1461 : runCachedNode 511 131319 Adaptive146Third144Node1461 = false := by
  decide +kernel

#print axioms adaptive146Third144Proof1461

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third144Proof548 : runCachedNode 511 131319 Adaptive146Third144Node548 = false := by
  decide +kernel

#print axioms adaptive146Third144Proof548

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third144Proof342 : runCachedNode 511 131319 Adaptive146Third144Node342 = false := by
  decide +kernel

#print axioms adaptive146Third144Proof342

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third144Proof597 : runCachedNode 511 131319 Adaptive146Third144Node597 = false := by
  decide +kernel

#print axioms adaptive146Third144Proof597

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third144Proof1097 : runCachedNode 511 131319 Adaptive146Third144Node1097 = false := by
  decide +kernel

#print axioms adaptive146Third144Proof1097

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third144Proof813 : runCachedNode 511 131319 Adaptive146Third144Node813 = false := by
  decide +kernel

#print axioms adaptive146Third144Proof813

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third144Proof368 : runCachedNode 511 131319 Adaptive146Third144Node368 = false := by
  decide +kernel

#print axioms adaptive146Third144Proof368

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third144Proof1096 : runCachedNode 511 131319 Adaptive146Third144Node1096 = false := by
  decide +kernel

#print axioms adaptive146Third144Proof1096

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third144Proof34 : runCachedNode 511 131319 Adaptive146Third144Node34 = false := by
  decide +kernel

#print axioms adaptive146Third144Proof34

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third144Proof304 : runCachedNode 511 131319 Adaptive146Third144Node304 = false := by
  decide +kernel

#print axioms adaptive146Third144Proof304

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third144Proof341 : runCachedNode 511 131319 Adaptive146Third144Node341 = false := by
  decide +kernel

#print axioms adaptive146Third144Proof341

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third144Proof1229 : runCachedNode 511 131319 Adaptive146Third144Node1229 = false := by
  decide +kernel

#print axioms adaptive146Third144Proof1229

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third144Proof897 : runCachedNode 511 131319 Adaptive146Third144Node897 = false := by
  decide +kernel

#print axioms adaptive146Third144Proof897

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third144Proof1025 : runCachedNode 511 131319 Adaptive146Third144Node1025 = false := by
  decide +kernel

#print axioms adaptive146Third144Proof1025

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third144Proof73 : runCachedNode 511 131319 Adaptive146Third144Node73 = false := by
  decide +kernel

#print axioms adaptive146Third144Proof73

end NineSeparatedSubsetSums
