import NineSeparatedSubsetSums.Adaptive146Third138State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third138Proof44 : runCachedNode 511 130484 Adaptive146Third138Node44 = false := by
  decide +kernel

#print axioms adaptive146Third138Proof44

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third138Proof15 : runCachedNode 511 130484 Adaptive146Third138Node15 = false := by
  decide +kernel

#print axioms adaptive146Third138Proof15

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third138Proof95 : runCachedNode 511 130484 Adaptive146Third138Node95 = false := by
  decide +kernel

#print axioms adaptive146Third138Proof95

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third138Proof68 : runCachedNode 511 130484 Adaptive146Third138Node68 = false := by
  decide +kernel

#print axioms adaptive146Third138Proof68

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third138Proof33 : runCachedNode 511 130484 Adaptive146Third138Node33 = false := by
  decide +kernel

#print axioms adaptive146Third138Proof33

end NineSeparatedSubsetSums
