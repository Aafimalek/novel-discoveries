import NineSeparatedSubsetSums.Adaptive146Third137State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third137Proof44 : runCachedNode 511 130354 Adaptive146Third137Node44 = false := by
  decide +kernel

#print axioms adaptive146Third137Proof44

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third137Proof177 : runCachedNode 511 130354 Adaptive146Third137Node177 = false := by
  decide +kernel

#print axioms adaptive146Third137Proof177

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third137Proof66 : runCachedNode 511 130354 Adaptive146Third137Node66 = false := by
  decide +kernel

#print axioms adaptive146Third137Proof66

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third137Proof92 : runCachedNode 511 130354 Adaptive146Third137Node92 = false := by
  decide +kernel

#print axioms adaptive146Third137Proof92

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third137Proof43 : runCachedNode 511 130354 Adaptive146Third137Node43 = false := by
  decide +kernel

#print axioms adaptive146Third137Proof43

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third137Proof67 : runCachedNode 511 130354 Adaptive146Third137Node67 = false := by
  decide +kernel

#print axioms adaptive146Third137Proof67

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third137Proof93 : runCachedNode 511 130354 Adaptive146Third137Node93 = false := by
  decide +kernel

#print axioms adaptive146Third137Proof93

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third137Proof7 : runCachedNode 511 130354 Adaptive146Third137Node7 = false := by
  decide +kernel

#print axioms adaptive146Third137Proof7

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third137Proof1 : runCachedNode 511 130354 Adaptive146Third137Node1 = false := by
  decide +kernel

#print axioms adaptive146Third137Proof1

end NineSeparatedSubsetSums
