import NineSeparatedSubsetSums.Adaptive146Third143State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third143Proof340 : runCachedNode 511 131193 Adaptive146Third143Node340 = false := by
  decide +kernel

#print axioms adaptive146Third143Proof340

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third143Proof18 : runCachedNode 511 131193 Adaptive146Third143Node18 = false := by
  decide +kernel

#print axioms adaptive146Third143Proof18

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third143Proof122 : runCachedNode 511 131193 Adaptive146Third143Node122 = false := by
  decide +kernel

#print axioms adaptive146Third143Proof122

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third143Proof268 : runCachedNode 511 131193 Adaptive146Third143Node268 = false := by
  decide +kernel

#print axioms adaptive146Third143Proof268

end NineSeparatedSubsetSums
