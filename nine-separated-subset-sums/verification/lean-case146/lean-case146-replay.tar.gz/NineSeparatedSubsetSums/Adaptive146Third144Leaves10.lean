import NineSeparatedSubsetSums.Adaptive146Third144State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third144Proof249 : runCachedNode 511 131319 Adaptive146Third144Node249 = false := by
  decide +kernel

#print axioms adaptive146Third144Proof249

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third144Proof860 : runCachedNode 511 131319 Adaptive146Third144Node860 = false := by
  decide +kernel

#print axioms adaptive146Third144Proof860

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third144Proof3 : runCachedNode 511 131319 Adaptive146Third144Node3 = false := by
  decide +kernel

#print axioms adaptive146Third144Proof3

end NineSeparatedSubsetSums
