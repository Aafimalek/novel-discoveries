import NineSeparatedSubsetSums.Adaptive146Third142State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third142Proof245 : runCachedNode 511 131054 Adaptive146Third142Node245 = false := by
  decide +kernel

#print axioms adaptive146Third142Proof245

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third142Proof179 : runCachedNode 511 131054 Adaptive146Third142Node179 = false := by
  decide +kernel

#print axioms adaptive146Third142Proof179

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third142Proof162 : runCachedNode 511 131054 Adaptive146Third142Node162 = false := by
  decide +kernel

#print axioms adaptive146Third142Proof162

end NineSeparatedSubsetSums
