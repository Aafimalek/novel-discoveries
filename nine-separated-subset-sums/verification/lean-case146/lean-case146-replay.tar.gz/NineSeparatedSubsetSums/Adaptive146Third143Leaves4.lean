import NineSeparatedSubsetSums.Adaptive146Third143State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third143Proof21 : runCachedNode 511 131193 Adaptive146Third143Node21 = false := by
  decide +kernel

#print axioms adaptive146Third143Proof21

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third143Proof163 : runCachedNode 511 131193 Adaptive146Third143Node163 = false := by
  decide +kernel

#print axioms adaptive146Third143Proof163

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third143Proof27 : runCachedNode 511 131193 Adaptive146Third143Node27 = false := by
  decide +kernel

#print axioms adaptive146Third143Proof27

end NineSeparatedSubsetSums
