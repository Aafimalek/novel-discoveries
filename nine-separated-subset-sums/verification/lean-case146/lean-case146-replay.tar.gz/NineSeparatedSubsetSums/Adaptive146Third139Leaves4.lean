import NineSeparatedSubsetSums.Adaptive146Third139State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third139Proof247 : runCachedNode 511 130638 Adaptive146Third139Node247 = false := by
  decide +kernel

#print axioms adaptive146Third139Proof247

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third139Proof183 : runCachedNode 511 130638 Adaptive146Third139Node183 = false := by
  decide +kernel

#print axioms adaptive146Third139Proof183

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third139Proof135 : runCachedNode 511 130638 Adaptive146Third139Node135 = false := by
  decide +kernel

#print axioms adaptive146Third139Proof135

end NineSeparatedSubsetSums
