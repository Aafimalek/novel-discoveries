import NineSeparatedSubsetSums.Adaptive146Third110Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint146Checked

namespace NineSeparatedSubsetSums


theorem adaptive146Third110 : NoDescendingTailAfterThird 146 110 :=
  noDescendingThirdTail_of_cached 146 110 112631 (fun t ht nd => max148_second146_fourPoint_moment_bound (110::t) (by simp [ht]) nd) adaptive146Third110Proof0

#print axioms adaptive146Third110

end NineSeparatedSubsetSums
