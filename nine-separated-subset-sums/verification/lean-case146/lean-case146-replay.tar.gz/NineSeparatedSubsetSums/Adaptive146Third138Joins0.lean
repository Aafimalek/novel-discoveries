import NineSeparatedSubsetSums.Adaptive146Third138State
import NineSeparatedSubsetSums.Adaptive146Third138Leaves21
import NineSeparatedSubsetSums.Adaptive146Third138Leaves20
import NineSeparatedSubsetSums.Adaptive146Third138Leaves11
import NineSeparatedSubsetSums.Adaptive146Third138Leaves19
import NineSeparatedSubsetSums.Adaptive146Third138Leaves18
import NineSeparatedSubsetSums.Adaptive146Third138Leaves13
import NineSeparatedSubsetSums.Adaptive146Third138Leaves17
import NineSeparatedSubsetSums.Adaptive146Third138Leaves16
import NineSeparatedSubsetSums.Adaptive146Third138Leaves14
import NineSeparatedSubsetSums.Adaptive146Third138Leaves15
import NineSeparatedSubsetSums.Adaptive146Third138Leaves12
import NineSeparatedSubsetSums.Adaptive146Third138Leaves2
import NineSeparatedSubsetSums.Adaptive146Third138Leaves0
import NineSeparatedSubsetSums.Adaptive146Third138Leaves7
import NineSeparatedSubsetSums.Adaptive146Third138Leaves1
import NineSeparatedSubsetSums.Adaptive146Third138Leaves3
import NineSeparatedSubsetSums.Adaptive146Third138Leaves8
import NineSeparatedSubsetSums.Adaptive146Third138Leaves10
import NineSeparatedSubsetSums.Adaptive146Third138Leaves5
import NineSeparatedSubsetSums.Adaptive146Third138Leaves9
import NineSeparatedSubsetSums.Adaptive146Third138Leaves4
import NineSeparatedSubsetSums.Adaptive146Third138Leaves6

namespace NineSeparatedSubsetSums

theorem adaptive146Third138Proof21 : runCachedNode 511 130484 Adaptive146Third138Node21 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130484 Adaptive146Third138Node21 = [104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 121, 123, 124, 125, 126, 127, 129] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive146Third138Proof22
  · exact adaptive146Third138Proof23
  · exact adaptive146Third138Proof24
  · exact adaptive146Third138Proof25
  · exact adaptive146Third138Proof26
  · exact adaptive146Third138Proof27
  · exact adaptive146Third138Proof28
  · exact adaptive146Third138Proof29
  · exact adaptive146Third138Proof30
  · exact adaptive146Third138Proof31
  · exact adaptive146Third138Proof32
  · exact adaptive146Third138Proof33
  · exact adaptive146Third138Proof34
  · exact adaptive146Third138Proof35
  · exact adaptive146Third138Proof36
  · exact adaptive146Third138Proof37
  · exact adaptive146Third138Proof38
  · exact adaptive146Third138Proof39
  · exact adaptive146Third138Proof40
  · exact adaptive146Third138Proof41
  · exact adaptive146Third138Proof42
  · exact adaptive146Third138Proof43
  · exact adaptive146Third138Proof44

#print axioms adaptive146Third138Proof21

theorem adaptive146Third138Proof45 : runCachedNode 511 130484 Adaptive146Third138Node45 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130484 Adaptive146Third138Node45 = [104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 122, 124, 125, 126, 127, 128, 130] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive146Third138Proof46
  · exact adaptive146Third138Proof47
  · exact adaptive146Third138Proof48
  · exact adaptive146Third138Proof49
  · exact adaptive146Third138Proof50
  · exact adaptive146Third138Proof51
  · exact adaptive146Third138Proof52
  · exact adaptive146Third138Proof53
  · exact adaptive146Third138Proof54
  · exact adaptive146Third138Proof55
  · exact adaptive146Third138Proof56
  · exact adaptive146Third138Proof57
  · exact adaptive146Third138Proof58
  · exact adaptive146Third138Proof59
  · exact adaptive146Third138Proof60
  · exact adaptive146Third138Proof61
  · exact adaptive146Third138Proof62
  · exact adaptive146Third138Proof63
  · exact adaptive146Third138Proof64
  · exact adaptive146Third138Proof65
  · exact adaptive146Third138Proof66
  · exact adaptive146Third138Proof67
  · exact adaptive146Third138Proof68
  · exact adaptive146Third138Proof69

#print axioms adaptive146Third138Proof45

theorem adaptive146Third138Proof70 : runCachedNode 511 130484 Adaptive146Third138Node70 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130484 Adaptive146Third138Node70 = [103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 123, 125, 126, 127, 128, 129, 131] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive146Third138Proof71
  · exact adaptive146Third138Proof72
  · exact adaptive146Third138Proof73
  · exact adaptive146Third138Proof74
  · exact adaptive146Third138Proof75
  · exact adaptive146Third138Proof76
  · exact adaptive146Third138Proof77
  · exact adaptive146Third138Proof78
  · exact adaptive146Third138Proof79
  · exact adaptive146Third138Proof80
  · exact adaptive146Third138Proof81
  · exact adaptive146Third138Proof82
  · exact adaptive146Third138Proof83
  · exact adaptive146Third138Proof84
  · exact adaptive146Third138Proof85
  · exact adaptive146Third138Proof86
  · exact adaptive146Third138Proof87
  · exact adaptive146Third138Proof88
  · exact adaptive146Third138Proof89
  · exact adaptive146Third138Proof90
  · exact adaptive146Third138Proof91
  · exact adaptive146Third138Proof92
  · exact adaptive146Third138Proof93
  · exact adaptive146Third138Proof94
  · exact adaptive146Third138Proof95
  · exact adaptive146Third138Proof96

#print axioms adaptive146Third138Proof70

theorem adaptive146Third138Proof97 : runCachedNode 511 130484 Adaptive146Third138Node97 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130484 Adaptive146Third138Node97 = [103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 124, 126, 127, 128, 129, 130, 132] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive146Third138Proof98
  · exact adaptive146Third138Proof99
  · exact adaptive146Third138Proof100
  · exact adaptive146Third138Proof101
  · exact adaptive146Third138Proof102
  · exact adaptive146Third138Proof103
  · exact adaptive146Third138Proof104
  · exact adaptive146Third138Proof105
  · exact adaptive146Third138Proof106
  · exact adaptive146Third138Proof107
  · exact adaptive146Third138Proof108
  · exact adaptive146Third138Proof109
  · exact adaptive146Third138Proof110
  · exact adaptive146Third138Proof111
  · exact adaptive146Third138Proof112
  · exact adaptive146Third138Proof113
  · exact adaptive146Third138Proof114
  · exact adaptive146Third138Proof115
  · exact adaptive146Third138Proof116
  · exact adaptive146Third138Proof117
  · exact adaptive146Third138Proof118
  · exact adaptive146Third138Proof119
  · exact adaptive146Third138Proof120
  · exact adaptive146Third138Proof121
  · exact adaptive146Third138Proof122
  · exact adaptive146Third138Proof123
  · exact adaptive146Third138Proof124

#print axioms adaptive146Third138Proof97

theorem adaptive146Third138Proof125 : runCachedNode 511 130484 Adaptive146Third138Node125 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130484 Adaptive146Third138Node125 = [103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 125, 127, 128, 129, 130, 131, 133] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive146Third138Proof126
  · exact adaptive146Third138Proof127
  · exact adaptive146Third138Proof128
  · exact adaptive146Third138Proof129
  · exact adaptive146Third138Proof130
  · exact adaptive146Third138Proof131
  · exact adaptive146Third138Proof132
  · exact adaptive146Third138Proof133
  · exact adaptive146Third138Proof134
  · exact adaptive146Third138Proof135
  · exact adaptive146Third138Proof136
  · exact adaptive146Third138Proof137
  · exact adaptive146Third138Proof138
  · exact adaptive146Third138Proof139
  · exact adaptive146Third138Proof140
  · exact adaptive146Third138Proof141
  · exact adaptive146Third138Proof142
  · exact adaptive146Third138Proof143
  · exact adaptive146Third138Proof144
  · exact adaptive146Third138Proof145
  · exact adaptive146Third138Proof146
  · exact adaptive146Third138Proof147
  · exact adaptive146Third138Proof148
  · exact adaptive146Third138Proof149
  · exact adaptive146Third138Proof150
  · exact adaptive146Third138Proof151
  · exact adaptive146Third138Proof152
  · exact adaptive146Third138Proof153

#print axioms adaptive146Third138Proof125

theorem adaptive146Third138Proof154 : runCachedNode 511 130484 Adaptive146Third138Node154 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130484 Adaptive146Third138Node154 = [102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 126, 128, 129, 130, 131, 132, 134] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive146Third138Proof155
  · exact adaptive146Third138Proof156
  · exact adaptive146Third138Proof157
  · exact adaptive146Third138Proof158
  · exact adaptive146Third138Proof159
  · exact adaptive146Third138Proof160
  · exact adaptive146Third138Proof161
  · exact adaptive146Third138Proof162
  · exact adaptive146Third138Proof163
  · exact adaptive146Third138Proof164
  · exact adaptive146Third138Proof165
  · exact adaptive146Third138Proof166
  · exact adaptive146Third138Proof167
  · exact adaptive146Third138Proof168
  · exact adaptive146Third138Proof169
  · exact adaptive146Third138Proof170
  · exact adaptive146Third138Proof171
  · exact adaptive146Third138Proof172
  · exact adaptive146Third138Proof173
  · exact adaptive146Third138Proof174
  · exact adaptive146Third138Proof175
  · exact adaptive146Third138Proof176
  · exact adaptive146Third138Proof177
  · exact adaptive146Third138Proof178
  · exact adaptive146Third138Proof179
  · exact adaptive146Third138Proof180
  · exact adaptive146Third138Proof181
  · exact adaptive146Third138Proof182
  · exact adaptive146Third138Proof183
  · exact adaptive146Third138Proof184

#print axioms adaptive146Third138Proof154

theorem adaptive146Third138Proof185 : runCachedNode 511 130484 Adaptive146Third138Node185 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130484 Adaptive146Third138Node185 = [102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 128, 130, 131, 132, 133, 134] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive146Third138Proof186
  · exact adaptive146Third138Proof187
  · exact adaptive146Third138Proof188
  · exact adaptive146Third138Proof189
  · exact adaptive146Third138Proof190
  · exact adaptive146Third138Proof191
  · exact adaptive146Third138Proof192
  · exact adaptive146Third138Proof193
  · exact adaptive146Third138Proof194
  · exact adaptive146Third138Proof195
  · exact adaptive146Third138Proof196
  · exact adaptive146Third138Proof197
  · exact adaptive146Third138Proof198
  · exact adaptive146Third138Proof199
  · exact adaptive146Third138Proof200
  · exact adaptive146Third138Proof201
  · exact adaptive146Third138Proof202
  · exact adaptive146Third138Proof203
  · exact adaptive146Third138Proof204
  · exact adaptive146Third138Proof205
  · exact adaptive146Third138Proof206
  · exact adaptive146Third138Proof207
  · exact adaptive146Third138Proof208
  · exact adaptive146Third138Proof209
  · exact adaptive146Third138Proof210
  · exact adaptive146Third138Proof211
  · exact adaptive146Third138Proof212
  · exact adaptive146Third138Proof213
  · exact adaptive146Third138Proof214
  · exact adaptive146Third138Proof215
  · exact adaptive146Third138Proof216

#print axioms adaptive146Third138Proof185

theorem adaptive146Third138Proof0 : runCachedNode 511 130484 Adaptive146Third138Node0 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130484 Adaptive146Third138Node0 = [110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 132, 133, 134, 135, 137] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive146Third138Proof1
  · exact adaptive146Third138Proof2
  · exact adaptive146Third138Proof3
  · exact adaptive146Third138Proof4
  · exact adaptive146Third138Proof5
  · exact adaptive146Third138Proof6
  · exact adaptive146Third138Proof7
  · exact adaptive146Third138Proof8
  · exact adaptive146Third138Proof9
  · exact adaptive146Third138Proof10
  · exact adaptive146Third138Proof11
  · exact adaptive146Third138Proof12
  · exact adaptive146Third138Proof13
  · exact adaptive146Third138Proof14
  · exact adaptive146Third138Proof15
  · exact adaptive146Third138Proof16
  · exact adaptive146Third138Proof17
  · exact adaptive146Third138Proof18
  · exact adaptive146Third138Proof19
  · exact adaptive146Third138Proof20
  · exact adaptive146Third138Proof21
  · exact adaptive146Third138Proof45
  · exact adaptive146Third138Proof70
  · exact adaptive146Third138Proof97
  · exact adaptive146Third138Proof125
  · exact adaptive146Third138Proof154
  · exact adaptive146Third138Proof185

#print axioms adaptive146Third138Proof0

end NineSeparatedSubsetSums
