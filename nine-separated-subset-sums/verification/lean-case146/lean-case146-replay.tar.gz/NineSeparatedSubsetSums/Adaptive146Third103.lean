import NineSeparatedSubsetSums.Adaptive146Third103Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint146Checked

namespace NineSeparatedSubsetSums


theorem adaptive146Third103 : NoDescendingTailAfterThird 146 103 :=
  noDescendingThirdTail_of_cached 146 103 112631 (fun t ht nd => max148_second146_fourPoint_moment_bound (103::t) (by simp [ht]) nd) adaptive146Third103Proof0

#print axioms adaptive146Third103

end NineSeparatedSubsetSums
