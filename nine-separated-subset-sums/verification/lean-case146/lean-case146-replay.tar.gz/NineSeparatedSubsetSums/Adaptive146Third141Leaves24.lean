import NineSeparatedSubsetSums.Adaptive146Third141State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third141Proof200 : runCachedNode 511 130916 Adaptive146Third141Node200 = false := by
  decide +kernel

#print axioms adaptive146Third141Proof200

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third141Proof14 : runCachedNode 511 130916 Adaptive146Third141Node14 = false := by
  decide +kernel

#print axioms adaptive146Third141Proof14

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third141Proof267 : runCachedNode 511 130916 Adaptive146Third141Node267 = false := by
  decide +kernel

#print axioms adaptive146Third141Proof267

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third141Proof164 : runCachedNode 511 130916 Adaptive146Third141Node164 = false := by
  decide +kernel

#print axioms adaptive146Third141Proof164

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third141Proof198 : runCachedNode 511 130916 Adaptive146Third141Node198 = false := by
  decide +kernel

#print axioms adaptive146Third141Proof198

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third141Proof131 : runCachedNode 511 130916 Adaptive146Third141Node131 = false := by
  decide +kernel

#print axioms adaptive146Third141Proof131

end NineSeparatedSubsetSums
