import NineSeparatedSubsetSums.Adaptive146Third141State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third141Proof204 : runCachedNode 511 130916 Adaptive146Third141Node204 = false := by
  decide +kernel

#print axioms adaptive146Third141Proof204

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third141Proof35 : runCachedNode 511 130916 Adaptive146Third141Node35 = false := by
  decide +kernel

#print axioms adaptive146Third141Proof35

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third141Proof206 : runCachedNode 511 130916 Adaptive146Third141Node206 = false := by
  decide +kernel

#print axioms adaptive146Third141Proof206

end NineSeparatedSubsetSums
