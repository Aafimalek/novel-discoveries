import NineSeparatedSubsetSums.Adaptive146Third135State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third135Proof100 : runCachedNode 511 130049 Adaptive146Third135Node100 = false := by
  decide +kernel

#print axioms adaptive146Third135Proof100

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third135Proof72 : runCachedNode 511 130049 Adaptive146Third135Node72 = false := by
  decide +kernel

#print axioms adaptive146Third135Proof72

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third135Proof99 : runCachedNode 511 130049 Adaptive146Third135Node99 = false := by
  decide +kernel

#print axioms adaptive146Third135Proof99

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third135Proof70 : runCachedNode 511 130049 Adaptive146Third135Node70 = false := by
  decide +kernel

#print axioms adaptive146Third135Proof70

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third135Proof63 : runCachedNode 511 130049 Adaptive146Third135Node63 = false := by
  decide +kernel

#print axioms adaptive146Third135Proof63

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third135Proof2 : runCachedNode 511 130049 Adaptive146Third135Node2 = false := by
  decide +kernel

#print axioms adaptive146Third135Proof2

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third135Proof49 : runCachedNode 511 130049 Adaptive146Third135Node49 = false := by
  decide +kernel

#print axioms adaptive146Third135Proof49

end NineSeparatedSubsetSums
