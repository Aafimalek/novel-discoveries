import NineSeparatedSubsetSums.Adaptive146Third144State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third144Proof221 : runCachedNode 511 131319 Adaptive146Third144Node221 = false := by
  decide +kernel

#print axioms adaptive146Third144Proof221

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third144Proof1478 : runCachedNode 511 131319 Adaptive146Third144Node1478 = false := by
  decide +kernel

#print axioms adaptive146Third144Proof1478

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third144Proof497 : runCachedNode 511 131319 Adaptive146Third144Node497 = false := by
  decide +kernel

#print axioms adaptive146Third144Proof497

end NineSeparatedSubsetSums
