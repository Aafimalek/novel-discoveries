import NineSeparatedSubsetSums.Adaptive146Third143State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third143Proof68 : runCachedNode 511 131193 Adaptive146Third143Node68 = false := by
  decide +kernel

#print axioms adaptive146Third143Proof68

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third143Proof328 : runCachedNode 511 131193 Adaptive146Third143Node328 = false := by
  decide +kernel

#print axioms adaptive146Third143Proof328

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third143Proof565 : runCachedNode 511 131193 Adaptive146Third143Node565 = false := by
  decide +kernel

#print axioms adaptive146Third143Proof565

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third143Proof622 : runCachedNode 511 131193 Adaptive146Third143Node622 = false := by
  decide +kernel

#print axioms adaptive146Third143Proof622

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third143Proof223 : runCachedNode 511 131193 Adaptive146Third143Node223 = false := by
  decide +kernel

#print axioms adaptive146Third143Proof223

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third143Proof42 : runCachedNode 511 131193 Adaptive146Third143Node42 = false := by
  decide +kernel

#print axioms adaptive146Third143Proof42

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third143Proof99 : runCachedNode 511 131193 Adaptive146Third143Node99 = false := by
  decide +kernel

#print axioms adaptive146Third143Proof99

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third143Proof380 : runCachedNode 511 131193 Adaptive146Third143Node380 = false := by
  decide +kernel

#print axioms adaptive146Third143Proof380

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third143Proof454 : runCachedNode 511 131193 Adaptive146Third143Node454 = false := by
  decide +kernel

#print axioms adaptive146Third143Proof454

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third143Proof621 : runCachedNode 511 131193 Adaptive146Third143Node621 = false := by
  decide +kernel

#print axioms adaptive146Third143Proof621

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third143Proof327 : runCachedNode 511 131193 Adaptive146Third143Node327 = false := by
  decide +kernel

#print axioms adaptive146Third143Proof327

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third143Proof124 : runCachedNode 511 131193 Adaptive146Third143Node124 = false := by
  decide +kernel

#print axioms adaptive146Third143Proof124

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third143Proof303 : runCachedNode 511 131193 Adaptive146Third143Node303 = false := by
  decide +kernel

#print axioms adaptive146Third143Proof303

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third143Proof321 : runCachedNode 511 131193 Adaptive146Third143Node321 = false := by
  decide +kernel

#print axioms adaptive146Third143Proof321

end NineSeparatedSubsetSums
