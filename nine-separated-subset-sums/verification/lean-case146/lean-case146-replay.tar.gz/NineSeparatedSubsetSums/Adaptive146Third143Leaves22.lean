import NineSeparatedSubsetSums.Adaptive146Third143State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third143Proof193 : runCachedNode 511 131193 Adaptive146Third143Node193 = false := by
  decide +kernel

#print axioms adaptive146Third143Proof193

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third143Proof258 : runCachedNode 511 131193 Adaptive146Third143Node258 = false := by
  decide +kernel

#print axioms adaptive146Third143Proof258

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third143Proof306 : runCachedNode 511 131193 Adaptive146Third143Node306 = false := by
  decide +kernel

#print axioms adaptive146Third143Proof306

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third143Proof305 : runCachedNode 511 131193 Adaptive146Third143Node305 = false := by
  decide +kernel

#print axioms adaptive146Third143Proof305

end NineSeparatedSubsetSums
