import NineSeparatedSubsetSums.Adaptive146Third135State
import NineSeparatedSubsetSums.Adaptive146Third135Leaves9
import NineSeparatedSubsetSums.Adaptive146Third135Leaves2
import NineSeparatedSubsetSums.Adaptive146Third135Leaves8
import NineSeparatedSubsetSums.Adaptive146Third135Leaves1
import NineSeparatedSubsetSums.Adaptive146Third135Leaves7
import NineSeparatedSubsetSums.Adaptive146Third135Leaves6
import NineSeparatedSubsetSums.Adaptive146Third135Leaves5
import NineSeparatedSubsetSums.Adaptive146Third135Leaves4
import NineSeparatedSubsetSums.Adaptive146Third135Leaves3
import NineSeparatedSubsetSums.Adaptive146Third135Leaves0

namespace NineSeparatedSubsetSums

theorem adaptive146Third135Proof22 : runCachedNode 511 130049 Adaptive146Third135Node22 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130049 Adaptive146Third135Node22 = [104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 119, 121, 122, 123, 124, 125, 126, 127, 128, 130] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive146Third135Proof23
  · exact adaptive146Third135Proof24
  · exact adaptive146Third135Proof25
  · exact adaptive146Third135Proof26
  · exact adaptive146Third135Proof27
  · exact adaptive146Third135Proof28
  · exact adaptive146Third135Proof29
  · exact adaptive146Third135Proof30
  · exact adaptive146Third135Proof31
  · exact adaptive146Third135Proof32
  · exact adaptive146Third135Proof33
  · exact adaptive146Third135Proof34
  · exact adaptive146Third135Proof35
  · exact adaptive146Third135Proof36
  · exact adaptive146Third135Proof37
  · exact adaptive146Third135Proof38
  · exact adaptive146Third135Proof39
  · exact adaptive146Third135Proof40
  · exact adaptive146Third135Proof41
  · exact adaptive146Third135Proof42
  · exact adaptive146Third135Proof43
  · exact adaptive146Third135Proof44
  · exact adaptive146Third135Proof45
  · exact adaptive146Third135Proof46

#print axioms adaptive146Third135Proof22

theorem adaptive146Third135Proof47 : runCachedNode 511 130049 Adaptive146Third135Node47 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130049 Adaptive146Third135Node47 = [104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 120, 122, 123, 124, 125, 126, 127, 128, 129, 131] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive146Third135Proof48
  · exact adaptive146Third135Proof49
  · exact adaptive146Third135Proof50
  · exact adaptive146Third135Proof51
  · exact adaptive146Third135Proof52
  · exact adaptive146Third135Proof53
  · exact adaptive146Third135Proof54
  · exact adaptive146Third135Proof55
  · exact adaptive146Third135Proof56
  · exact adaptive146Third135Proof57
  · exact adaptive146Third135Proof58
  · exact adaptive146Third135Proof59
  · exact adaptive146Third135Proof60
  · exact adaptive146Third135Proof61
  · exact adaptive146Third135Proof62
  · exact adaptive146Third135Proof63
  · exact adaptive146Third135Proof64
  · exact adaptive146Third135Proof65
  · exact adaptive146Third135Proof66
  · exact adaptive146Third135Proof67
  · exact adaptive146Third135Proof68
  · exact adaptive146Third135Proof69
  · exact adaptive146Third135Proof70
  · exact adaptive146Third135Proof71
  · exact adaptive146Third135Proof72

#print axioms adaptive146Third135Proof47

theorem adaptive146Third135Proof73 : runCachedNode 511 130049 Adaptive146Third135Node73 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130049 Adaptive146Third135Node73 = [103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 122, 124, 125, 126, 127, 128, 129, 130, 131] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive146Third135Proof74
  · exact adaptive146Third135Proof75
  · exact adaptive146Third135Proof76
  · exact adaptive146Third135Proof77
  · exact adaptive146Third135Proof78
  · exact adaptive146Third135Proof79
  · exact adaptive146Third135Proof80
  · exact adaptive146Third135Proof81
  · exact adaptive146Third135Proof82
  · exact adaptive146Third135Proof83
  · exact adaptive146Third135Proof84
  · exact adaptive146Third135Proof85
  · exact adaptive146Third135Proof86
  · exact adaptive146Third135Proof87
  · exact adaptive146Third135Proof88
  · exact adaptive146Third135Proof89
  · exact adaptive146Third135Proof90
  · exact adaptive146Third135Proof91
  · exact adaptive146Third135Proof92
  · exact adaptive146Third135Proof93
  · exact adaptive146Third135Proof94
  · exact adaptive146Third135Proof95
  · exact adaptive146Third135Proof96
  · exact adaptive146Third135Proof97
  · exact adaptive146Third135Proof98
  · exact adaptive146Third135Proof99
  · exact adaptive146Third135Proof100

#print axioms adaptive146Third135Proof73

theorem adaptive146Third135Proof0 : runCachedNode 511 130049 Adaptive146Third135Node0 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130049 Adaptive146Third135Node0 = [110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 132, 134] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive146Third135Proof1
  · exact adaptive146Third135Proof2
  · exact adaptive146Third135Proof3
  · exact adaptive146Third135Proof4
  · exact adaptive146Third135Proof5
  · exact adaptive146Third135Proof6
  · exact adaptive146Third135Proof7
  · exact adaptive146Third135Proof8
  · exact adaptive146Third135Proof9
  · exact adaptive146Third135Proof10
  · exact adaptive146Third135Proof11
  · exact adaptive146Third135Proof12
  · exact adaptive146Third135Proof13
  · exact adaptive146Third135Proof14
  · exact adaptive146Third135Proof15
  · exact adaptive146Third135Proof16
  · exact adaptive146Third135Proof17
  · exact adaptive146Third135Proof18
  · exact adaptive146Third135Proof19
  · exact adaptive146Third135Proof20
  · exact adaptive146Third135Proof21
  · exact adaptive146Third135Proof22
  · exact adaptive146Third135Proof47
  · exact adaptive146Third135Proof73

#print axioms adaptive146Third135Proof0

end NineSeparatedSubsetSums
