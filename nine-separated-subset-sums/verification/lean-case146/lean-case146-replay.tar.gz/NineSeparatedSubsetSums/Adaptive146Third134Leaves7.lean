import NineSeparatedSubsetSums.Adaptive146Third134State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third134Proof58 : runCachedNode 511 129871 Adaptive146Third134Node58 = false := by
  decide +kernel

#print axioms adaptive146Third134Proof58

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third134Proof30 : runCachedNode 511 129871 Adaptive146Third134Node30 = false := by
  decide +kernel

#print axioms adaptive146Third134Proof30

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third134Proof31 : runCachedNode 511 129871 Adaptive146Third134Node31 = false := by
  decide +kernel

#print axioms adaptive146Third134Proof31

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third134Proof57 : runCachedNode 511 129871 Adaptive146Third134Node57 = false := by
  decide +kernel

#print axioms adaptive146Third134Proof57

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third134Proof55 : runCachedNode 511 129871 Adaptive146Third134Node55 = false := by
  decide +kernel

#print axioms adaptive146Third134Proof55

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third134Proof56 : runCachedNode 511 129871 Adaptive146Third134Node56 = false := by
  decide +kernel

#print axioms adaptive146Third134Proof56

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third134Proof4 : runCachedNode 511 129871 Adaptive146Third134Node4 = false := by
  decide +kernel

#print axioms adaptive146Third134Proof4

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third134Proof54 : runCachedNode 511 129871 Adaptive146Third134Node54 = false := by
  decide +kernel

#print axioms adaptive146Third134Proof54

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third134Proof28 : runCachedNode 511 129871 Adaptive146Third134Node28 = false := by
  decide +kernel

#print axioms adaptive146Third134Proof28

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third134Proof53 : runCachedNode 511 129871 Adaptive146Third134Node53 = false := by
  decide +kernel

#print axioms adaptive146Third134Proof53

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third134Proof26 : runCachedNode 511 129871 Adaptive146Third134Node26 = false := by
  decide +kernel

#print axioms adaptive146Third134Proof26

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third134Proof51 : runCachedNode 511 129871 Adaptive146Third134Node51 = false := by
  decide +kernel

#print axioms adaptive146Third134Proof51

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third134Proof24 : runCachedNode 511 129871 Adaptive146Third134Node24 = false := by
  decide +kernel

#print axioms adaptive146Third134Proof24

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third134Proof23 : runCachedNode 511 129871 Adaptive146Third134Node23 = false := by
  decide +kernel

#print axioms adaptive146Third134Proof23

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third134Proof50 : runCachedNode 511 129871 Adaptive146Third134Node50 = false := by
  decide +kernel

#print axioms adaptive146Third134Proof50

end NineSeparatedSubsetSums
