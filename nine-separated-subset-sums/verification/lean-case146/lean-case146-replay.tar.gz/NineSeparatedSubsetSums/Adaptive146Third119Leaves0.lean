import NineSeparatedSubsetSums.Adaptive146Third119State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third119Proof0 : runCachedNode 511 126450 Adaptive146Third119Node0 = false := by
  decide +kernel

#print axioms adaptive146Third119Proof0

end NineSeparatedSubsetSums
