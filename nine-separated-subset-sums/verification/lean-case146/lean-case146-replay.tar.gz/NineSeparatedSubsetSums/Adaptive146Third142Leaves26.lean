import NineSeparatedSubsetSums.Adaptive146Third142State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third142Proof244 : runCachedNode 511 131054 Adaptive146Third142Node244 = false := by
  decide +kernel

#print axioms adaptive146Third142Proof244

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third142Proof51 : runCachedNode 511 131054 Adaptive146Third142Node51 = false := by
  decide +kernel

#print axioms adaptive146Third142Proof51

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third142Proof363 : runCachedNode 511 131054 Adaptive146Third142Node363 = false := by
  decide +kernel

#print axioms adaptive146Third142Proof363

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third142Proof80 : runCachedNode 511 131054 Adaptive146Third142Node80 = false := by
  decide +kernel

#print axioms adaptive146Third142Proof80

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third142Proof49 : runCachedNode 511 131054 Adaptive146Third142Node49 = false := by
  decide +kernel

#print axioms adaptive146Third142Proof49

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third142Proof53 : runCachedNode 511 131054 Adaptive146Third142Node53 = false := by
  decide +kernel

#print axioms adaptive146Third142Proof53

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third142Proof393 : runCachedNode 511 131054 Adaptive146Third142Node393 = false := by
  decide +kernel

#print axioms adaptive146Third142Proof393

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third142Proof256 : runCachedNode 511 131054 Adaptive146Third142Node256 = false := by
  decide +kernel

#print axioms adaptive146Third142Proof256

end NineSeparatedSubsetSums
