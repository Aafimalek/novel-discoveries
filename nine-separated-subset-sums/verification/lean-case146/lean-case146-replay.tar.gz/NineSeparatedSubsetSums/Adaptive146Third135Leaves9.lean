import NineSeparatedSubsetSums.Adaptive146Third135State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third135Proof3 : runCachedNode 511 130049 Adaptive146Third135Node3 = false := by
  decide +kernel

#print axioms adaptive146Third135Proof3

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third135Proof27 : runCachedNode 511 130049 Adaptive146Third135Node27 = false := by
  decide +kernel

#print axioms adaptive146Third135Proof27

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third135Proof53 : runCachedNode 511 130049 Adaptive146Third135Node53 = false := by
  decide +kernel

#print axioms adaptive146Third135Proof53

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third135Proof52 : runCachedNode 511 130049 Adaptive146Third135Node52 = false := by
  decide +kernel

#print axioms adaptive146Third135Proof52

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third135Proof78 : runCachedNode 511 130049 Adaptive146Third135Node78 = false := by
  decide +kernel

#print axioms adaptive146Third135Proof78

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third135Proof25 : runCachedNode 511 130049 Adaptive146Third135Node25 = false := by
  decide +kernel

#print axioms adaptive146Third135Proof25

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third135Proof77 : runCachedNode 511 130049 Adaptive146Third135Node77 = false := by
  decide +kernel

#print axioms adaptive146Third135Proof77

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third135Proof23 : runCachedNode 511 130049 Adaptive146Third135Node23 = false := by
  decide +kernel

#print axioms adaptive146Third135Proof23

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third135Proof24 : runCachedNode 511 130049 Adaptive146Third135Node24 = false := by
  decide +kernel

#print axioms adaptive146Third135Proof24

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third135Proof50 : runCachedNode 511 130049 Adaptive146Third135Node50 = false := by
  decide +kernel

#print axioms adaptive146Third135Proof50

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third135Proof51 : runCachedNode 511 130049 Adaptive146Third135Node51 = false := by
  decide +kernel

#print axioms adaptive146Third135Proof51

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third135Proof74 : runCachedNode 511 130049 Adaptive146Third135Node74 = false := by
  decide +kernel

#print axioms adaptive146Third135Proof74

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third135Proof75 : runCachedNode 511 130049 Adaptive146Third135Node75 = false := by
  decide +kernel

#print axioms adaptive146Third135Proof75

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third135Proof76 : runCachedNode 511 130049 Adaptive146Third135Node76 = false := by
  decide +kernel

#print axioms adaptive146Third135Proof76

end NineSeparatedSubsetSums
