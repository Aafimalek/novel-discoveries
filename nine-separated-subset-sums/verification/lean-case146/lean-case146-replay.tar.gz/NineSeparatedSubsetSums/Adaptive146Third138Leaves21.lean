import NineSeparatedSubsetSums.Adaptive146Third138State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third138Proof127 : runCachedNode 511 130484 Adaptive146Third138Node127 = false := by
  decide +kernel

#print axioms adaptive146Third138Proof127

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third138Proof128 : runCachedNode 511 130484 Adaptive146Third138Node128 = false := by
  decide +kernel

#print axioms adaptive146Third138Proof128

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third138Proof159 : runCachedNode 511 130484 Adaptive146Third138Node159 = false := by
  decide +kernel

#print axioms adaptive146Third138Proof159

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third138Proof189 : runCachedNode 511 130484 Adaptive146Third138Node189 = false := by
  decide +kernel

#print axioms adaptive146Third138Proof189

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third138Proof22 : runCachedNode 511 130484 Adaptive146Third138Node22 = false := by
  decide +kernel

#print axioms adaptive146Third138Proof22

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third138Proof46 : runCachedNode 511 130484 Adaptive146Third138Node46 = false := by
  decide +kernel

#print axioms adaptive146Third138Proof46

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third138Proof71 : runCachedNode 511 130484 Adaptive146Third138Node71 = false := by
  decide +kernel

#print axioms adaptive146Third138Proof71

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third138Proof72 : runCachedNode 511 130484 Adaptive146Third138Node72 = false := by
  decide +kernel

#print axioms adaptive146Third138Proof72

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third138Proof98 : runCachedNode 511 130484 Adaptive146Third138Node98 = false := by
  decide +kernel

#print axioms adaptive146Third138Proof98

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third138Proof99 : runCachedNode 511 130484 Adaptive146Third138Node99 = false := by
  decide +kernel

#print axioms adaptive146Third138Proof99

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third138Proof126 : runCachedNode 511 130484 Adaptive146Third138Node126 = false := by
  decide +kernel

#print axioms adaptive146Third138Proof126

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third138Proof158 : runCachedNode 511 130484 Adaptive146Third138Node158 = false := by
  decide +kernel

#print axioms adaptive146Third138Proof158

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third138Proof188 : runCachedNode 511 130484 Adaptive146Third138Node188 = false := by
  decide +kernel

#print axioms adaptive146Third138Proof188

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third138Proof186 : runCachedNode 511 130484 Adaptive146Third138Node186 = false := by
  decide +kernel

#print axioms adaptive146Third138Proof186

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third138Proof187 : runCachedNode 511 130484 Adaptive146Third138Node187 = false := by
  decide +kernel

#print axioms adaptive146Third138Proof187

end NineSeparatedSubsetSums
