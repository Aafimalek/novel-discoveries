import NineSeparatedSubsetSums.Adaptive146Third140State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third140Proof16 : runCachedNode 511 130775 Adaptive146Third140Node16 = false := by
  decide +kernel

#print axioms adaptive146Third140Proof16

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third140Proof125 : runCachedNode 511 130775 Adaptive146Third140Node125 = false := by
  decide +kernel

#print axioms adaptive146Third140Proof125

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third140Proof150 : runCachedNode 511 130775 Adaptive146Third140Node150 = false := by
  decide +kernel

#print axioms adaptive146Third140Proof150

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third140Proof152 : runCachedNode 511 130775 Adaptive146Third140Node152 = false := by
  decide +kernel

#print axioms adaptive146Third140Proof152

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third140Proof101 : runCachedNode 511 130775 Adaptive146Third140Node101 = false := by
  decide +kernel

#print axioms adaptive146Third140Proof101

end NineSeparatedSubsetSums
