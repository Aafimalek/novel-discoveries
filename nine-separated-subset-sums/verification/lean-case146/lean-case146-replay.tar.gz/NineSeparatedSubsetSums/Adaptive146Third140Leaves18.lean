import NineSeparatedSubsetSums.Adaptive146Third140State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third140Proof244 : runCachedNode 511 130775 Adaptive146Third140Node244 = false := by
  decide +kernel

#print axioms adaptive146Third140Proof244

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third140Proof95 : runCachedNode 511 130775 Adaptive146Third140Node95 = false := by
  decide +kernel

#print axioms adaptive146Third140Proof95

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third140Proof281 : runCachedNode 511 130775 Adaptive146Third140Node281 = false := by
  decide +kernel

#print axioms adaptive146Third140Proof281

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third140Proof14 : runCachedNode 511 130775 Adaptive146Third140Node14 = false := by
  decide +kernel

#print axioms adaptive146Third140Proof14

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third140Proof94 : runCachedNode 511 130775 Adaptive146Third140Node94 = false := by
  decide +kernel

#print axioms adaptive146Third140Proof94

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third140Proof299 : runCachedNode 511 130775 Adaptive146Third140Node299 = false := by
  decide +kernel

#print axioms adaptive146Third140Proof299

end NineSeparatedSubsetSums
