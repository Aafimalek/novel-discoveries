import NineSeparatedSubsetSums.Adaptive146Third132State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third132Proof20 : runCachedNode 511 129510 Adaptive146Third132Node20 = false := by
  decide +kernel

#print axioms adaptive146Third132Proof20

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third132Proof18 : runCachedNode 511 129510 Adaptive146Third132Node18 = false := by
  decide +kernel

#print axioms adaptive146Third132Proof18

end NineSeparatedSubsetSums
