import NineSeparatedSubsetSums.Adaptive146Third111Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint146Checked

namespace NineSeparatedSubsetSums


theorem adaptive146Third111 : NoDescendingTailAfterThird 146 111 :=
  noDescendingThirdTail_of_cached 146 111 112631 (fun t ht nd => max148_second146_fourPoint_moment_bound (111::t) (by simp [ht]) nd) adaptive146Third111Proof0

#print axioms adaptive146Third111

end NineSeparatedSubsetSums
