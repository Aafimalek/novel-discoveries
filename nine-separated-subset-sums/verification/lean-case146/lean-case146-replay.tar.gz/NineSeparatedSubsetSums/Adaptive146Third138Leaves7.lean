import NineSeparatedSubsetSums.Adaptive146Third138State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third138Proof211 : runCachedNode 511 130484 Adaptive146Third138Node211 = false := by
  decide +kernel

#print axioms adaptive146Third138Proof211

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third138Proof184 : runCachedNode 511 130484 Adaptive146Third138Node184 = false := by
  decide +kernel

#print axioms adaptive146Third138Proof184

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third138Proof67 : runCachedNode 511 130484 Adaptive146Third138Node67 = false := by
  decide +kernel

#print axioms adaptive146Third138Proof67

end NineSeparatedSubsetSums
