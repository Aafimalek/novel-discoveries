import NineSeparatedSubsetSums.Adaptive146Third116State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third116Proof15 : runCachedNode 511 112631 Adaptive146Third116Node15 = false := by
  decide +kernel

#print axioms adaptive146Third116Proof15

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third116Proof13 : runCachedNode 511 112631 Adaptive146Third116Node13 = false := by
  decide +kernel

#print axioms adaptive146Third116Proof13

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third116Proof11 : runCachedNode 511 112631 Adaptive146Third116Node11 = false := by
  decide +kernel

#print axioms adaptive146Third116Proof11

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third116Proof6 : runCachedNode 511 112631 Adaptive146Third116Node6 = false := by
  decide +kernel

#print axioms adaptive146Third116Proof6

end NineSeparatedSubsetSums
