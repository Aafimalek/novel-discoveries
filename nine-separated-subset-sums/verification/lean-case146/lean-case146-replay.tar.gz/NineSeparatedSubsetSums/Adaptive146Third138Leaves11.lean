import NineSeparatedSubsetSums.Adaptive146Third138State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third138Proof69 : runCachedNode 511 130484 Adaptive146Third138Node69 = false := by
  decide +kernel

#print axioms adaptive146Third138Proof69

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third138Proof92 : runCachedNode 511 130484 Adaptive146Third138Node92 = false := by
  decide +kernel

#print axioms adaptive146Third138Proof92

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third138Proof124 : runCachedNode 511 130484 Adaptive146Third138Node124 = false := by
  decide +kernel

#print axioms adaptive146Third138Proof124

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third138Proof10 : runCachedNode 511 130484 Adaptive146Third138Node10 = false := by
  decide +kernel

#print axioms adaptive146Third138Proof10

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third138Proof25 : runCachedNode 511 130484 Adaptive146Third138Node25 = false := by
  decide +kernel

#print axioms adaptive146Third138Proof25

end NineSeparatedSubsetSums
