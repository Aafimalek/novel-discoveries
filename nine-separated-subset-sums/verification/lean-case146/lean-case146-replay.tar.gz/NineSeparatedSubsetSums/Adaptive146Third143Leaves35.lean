import NineSeparatedSubsetSums.Adaptive146Third143State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third143Proof225 : runCachedNode 511 131193 Adaptive146Third143Node225 = false := by
  decide +kernel

#print axioms adaptive146Third143Proof225

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third143Proof129 : runCachedNode 511 131193 Adaptive146Third143Node129 = false := by
  decide +kernel

#print axioms adaptive146Third143Proof129

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third143Proof159 : runCachedNode 511 131193 Adaptive146Third143Node159 = false := by
  decide +kernel

#print axioms adaptive146Third143Proof159

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third143Proof254 : runCachedNode 511 131193 Adaptive146Third143Node254 = false := by
  decide +kernel

#print axioms adaptive146Third143Proof254

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third143Proof667 : runCachedNode 511 131193 Adaptive146Third143Node667 = false := by
  decide +kernel

#print axioms adaptive146Third143Proof667

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third143Proof408 : runCachedNode 511 131193 Adaptive146Third143Node408 = false := by
  decide +kernel

#print axioms adaptive146Third143Proof408

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third143Proof541 : runCachedNode 511 131193 Adaptive146Third143Node541 = false := by
  decide +kernel

#print axioms adaptive146Third143Proof541

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third143Proof44 : runCachedNode 511 131193 Adaptive146Third143Node44 = false := by
  decide +kernel

#print axioms adaptive146Third143Proof44

end NineSeparatedSubsetSums
