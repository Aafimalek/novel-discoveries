import NineSeparatedSubsetSums.Adaptive146Third143State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third143Proof581 : runCachedNode 511 131193 Adaptive146Third143Node581 = false := by
  decide +kernel

#print axioms adaptive146Third143Proof581

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third143Proof337 : runCachedNode 511 131193 Adaptive146Third143Node337 = false := by
  decide +kernel

#print axioms adaptive146Third143Proof337

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third143Proof28 : runCachedNode 511 131193 Adaptive146Third143Node28 = false := by
  decide +kernel

#print axioms adaptive146Third143Proof28

end NineSeparatedSubsetSums
