import NineSeparatedSubsetSums.Adaptive146Third143State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third143Proof20 : runCachedNode 511 131193 Adaptive146Third143Node20 = false := by
  decide +kernel

#print axioms adaptive146Third143Proof20

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third143Proof580 : runCachedNode 511 131193 Adaptive146Third143Node580 = false := by
  decide +kernel

#print axioms adaptive146Third143Proof580

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third143Proof85 : runCachedNode 511 131193 Adaptive146Third143Node85 = false := by
  decide +kernel

#print axioms adaptive146Third143Proof85

end NineSeparatedSubsetSums
