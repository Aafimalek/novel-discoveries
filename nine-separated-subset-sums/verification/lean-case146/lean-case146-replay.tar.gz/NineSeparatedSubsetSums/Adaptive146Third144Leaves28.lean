import NineSeparatedSubsetSums.Adaptive146Third144State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third144Proof379 : runCachedNode 511 131319 Adaptive146Third144Node379 = false := by
  decide +kernel

#print axioms adaptive146Third144Proof379

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third144Proof132 : runCachedNode 511 131319 Adaptive146Third144Node132 = false := by
  decide +kernel

#print axioms adaptive146Third144Proof132

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third144Proof89 : runCachedNode 511 131319 Adaptive146Third144Node89 = false := by
  decide +kernel

#print axioms adaptive146Third144Proof89

end NineSeparatedSubsetSums
