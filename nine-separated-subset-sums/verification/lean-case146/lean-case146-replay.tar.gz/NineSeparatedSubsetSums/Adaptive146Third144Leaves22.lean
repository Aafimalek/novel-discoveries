import NineSeparatedSubsetSums.Adaptive146Third144State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third144Proof284 : runCachedNode 511 131319 Adaptive146Third144Node284 = false := by
  decide +kernel

#print axioms adaptive146Third144Proof284

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third144Proof219 : runCachedNode 511 131319 Adaptive146Third144Node219 = false := by
  decide +kernel

#print axioms adaptive146Third144Proof219

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third144Proof22 : runCachedNode 511 131319 Adaptive146Third144Node22 = false := by
  decide +kernel

#print axioms adaptive146Third144Proof22

end NineSeparatedSubsetSums
