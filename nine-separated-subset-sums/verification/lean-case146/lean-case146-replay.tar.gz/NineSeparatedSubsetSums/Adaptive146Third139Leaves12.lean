import NineSeparatedSubsetSums.Adaptive146Third139State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third139Proof16 : runCachedNode 511 130638 Adaptive146Third139Node16 = false := by
  decide +kernel

#print axioms adaptive146Third139Proof16

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third139Proof153 : runCachedNode 511 130638 Adaptive146Third139Node153 = false := by
  decide +kernel

#print axioms adaptive146Third139Proof153

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third139Proof44 : runCachedNode 511 130638 Adaptive146Third139Node44 = false := by
  decide +kernel

#print axioms adaptive146Third139Proof44

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third139Proof211 : runCachedNode 511 130638 Adaptive146Third139Node211 = false := by
  decide +kernel

#print axioms adaptive146Third139Proof211

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third139Proof22 : runCachedNode 511 130638 Adaptive146Third139Node22 = false := by
  decide +kernel

#print axioms adaptive146Third139Proof22

end NineSeparatedSubsetSums
