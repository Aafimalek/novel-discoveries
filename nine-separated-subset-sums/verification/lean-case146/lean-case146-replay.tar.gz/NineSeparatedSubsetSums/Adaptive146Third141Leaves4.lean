import NineSeparatedSubsetSums.Adaptive146Third141State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third141Proof170 : runCachedNode 511 130916 Adaptive146Third141Node170 = false := by
  decide +kernel

#print axioms adaptive146Third141Proof170

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third141Proof135 : runCachedNode 511 130916 Adaptive146Third141Node135 = false := by
  decide +kernel

#print axioms adaptive146Third141Proof135

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third141Proof112 : runCachedNode 511 130916 Adaptive146Third141Node112 = false := by
  decide +kernel

#print axioms adaptive146Third141Proof112

end NineSeparatedSubsetSums
