import NineSeparatedSubsetSums.Adaptive146Third143State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third143Proof195 : runCachedNode 511 131193 Adaptive146Third143Node195 = false := by
  decide +kernel

#print axioms adaptive146Third143Proof195

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third143Proof261 : runCachedNode 511 131193 Adaptive146Third143Node261 = false := by
  decide +kernel

#print axioms adaptive146Third143Proof261

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third143Proof16 : runCachedNode 511 131193 Adaptive146Third143Node16 = false := by
  decide +kernel

#print axioms adaptive146Third143Proof16

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third143Proof149 : runCachedNode 511 131193 Adaptive146Third143Node149 = false := by
  decide +kernel

#print axioms adaptive146Third143Proof149

end NineSeparatedSubsetSums
