import NineSeparatedSubsetSums.Adaptive146Third144State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third144Proof15 : runCachedNode 511 131319 Adaptive146Third144Node15 = false := by
  decide +kernel

#print axioms adaptive146Third144Proof15

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third144Proof412 : runCachedNode 511 131319 Adaptive146Third144Node412 = false := by
  decide +kernel

#print axioms adaptive146Third144Proof412

end NineSeparatedSubsetSums
