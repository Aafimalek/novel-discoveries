import NineSeparatedSubsetSums.Adaptive146Third138State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third138Proof215 : runCachedNode 511 130484 Adaptive146Third138Node215 = false := by
  decide +kernel

#print axioms adaptive146Third138Proof215

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third138Proof152 : runCachedNode 511 130484 Adaptive146Third138Node152 = false := by
  decide +kernel

#print axioms adaptive146Third138Proof152

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third138Proof16 : runCachedNode 511 130484 Adaptive146Third138Node16 = false := by
  decide +kernel

#print axioms adaptive146Third138Proof16

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third138Proof140 : runCachedNode 511 130484 Adaptive146Third138Node140 = false := by
  decide +kernel

#print axioms adaptive146Third138Proof140

end NineSeparatedSubsetSums
