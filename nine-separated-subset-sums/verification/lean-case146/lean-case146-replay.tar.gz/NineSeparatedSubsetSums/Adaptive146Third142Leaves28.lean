import NineSeparatedSubsetSums.Adaptive146Third142State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third142Proof483 : runCachedNode 511 131054 Adaptive146Third142Node483 = false := by
  decide +kernel

#print axioms adaptive146Third142Proof483

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third142Proof174 : runCachedNode 511 131054 Adaptive146Third142Node174 = false := by
  decide +kernel

#print axioms adaptive146Third142Proof174

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third142Proof242 : runCachedNode 511 131054 Adaptive146Third142Node242 = false := by
  decide +kernel

#print axioms adaptive146Third142Proof242

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third142Proof107 : runCachedNode 511 131054 Adaptive146Third142Node107 = false := by
  decide +kernel

#print axioms adaptive146Third142Proof107

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third142Proof440 : runCachedNode 511 131054 Adaptive146Third142Node440 = false := by
  decide +kernel

#print axioms adaptive146Third142Proof440

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third142Proof362 : runCachedNode 511 131054 Adaptive146Third142Node362 = false := by
  decide +kernel

#print axioms adaptive146Third142Proof362

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third142Proof318 : runCachedNode 511 131054 Adaptive146Third142Node318 = false := by
  decide +kernel

#print axioms adaptive146Third142Proof318

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third142Proof199 : runCachedNode 511 131054 Adaptive146Third142Node199 = false := by
  decide +kernel

#print axioms adaptive146Third142Proof199

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third142Proof101 : runCachedNode 511 131054 Adaptive146Third142Node101 = false := by
  decide +kernel

#print axioms adaptive146Third142Proof101

end NineSeparatedSubsetSums
