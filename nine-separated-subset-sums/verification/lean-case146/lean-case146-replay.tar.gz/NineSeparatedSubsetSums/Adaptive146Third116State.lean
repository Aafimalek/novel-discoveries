import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive146Third116Node0 : CachedSearchNode :=
  ⟨4, 115, computeCenteredMask [148,146,116], 410, 56676⟩
def Adaptive146Third116Node1 : CachedSearchNode := cachedChild Adaptive146Third116Node0 100
def Adaptive146Third116Node2 : CachedSearchNode := cachedChild Adaptive146Third116Node0 101
def Adaptive146Third116Node3 : CachedSearchNode := cachedChild Adaptive146Third116Node0 102
def Adaptive146Third116Node4 : CachedSearchNode := cachedChild Adaptive146Third116Node0 103
def Adaptive146Third116Node5 : CachedSearchNode := cachedChild Adaptive146Third116Node0 104
def Adaptive146Third116Node6 : CachedSearchNode := cachedChild Adaptive146Third116Node0 105
def Adaptive146Third116Node7 : CachedSearchNode := cachedChild Adaptive146Third116Node0 106
def Adaptive146Third116Node8 : CachedSearchNode := cachedChild Adaptive146Third116Node0 107
def Adaptive146Third116Node9 : CachedSearchNode := cachedChild Adaptive146Third116Node0 108
def Adaptive146Third116Node10 : CachedSearchNode := cachedChild Adaptive146Third116Node0 109
def Adaptive146Third116Node11 : CachedSearchNode := cachedChild Adaptive146Third116Node0 110
def Adaptive146Third116Node12 : CachedSearchNode := cachedChild Adaptive146Third116Node0 111
def Adaptive146Third116Node13 : CachedSearchNode := cachedChild Adaptive146Third116Node0 112
def Adaptive146Third116Node14 : CachedSearchNode := cachedChild Adaptive146Third116Node0 113
def Adaptive146Third116Node15 : CachedSearchNode := cachedChild Adaptive146Third116Node0 115

end NineSeparatedSubsetSums
