import NineSeparatedSubsetSums.Adaptive146Third115State
import NineSeparatedSubsetSums.Adaptive146Third115Leaves0
import NineSeparatedSubsetSums.Adaptive146Third115Leaves1

namespace NineSeparatedSubsetSums

theorem adaptive146Third115Proof0 : runCachedNode 511 112631 Adaptive146Third115Node0 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 112631 Adaptive146Third115Node0 = [100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 114] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive146Third115Proof1
  · exact adaptive146Third115Proof2
  · exact adaptive146Third115Proof3
  · exact adaptive146Third115Proof4
  · exact adaptive146Third115Proof5
  · exact adaptive146Third115Proof6
  · exact adaptive146Third115Proof7
  · exact adaptive146Third115Proof8
  · exact adaptive146Third115Proof9
  · exact adaptive146Third115Proof10
  · exact adaptive146Third115Proof11
  · exact adaptive146Third115Proof12
  · exact adaptive146Third115Proof13
  · exact adaptive146Third115Proof14

#print axioms adaptive146Third115Proof0

end NineSeparatedSubsetSums
