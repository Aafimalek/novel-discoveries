import NineSeparatedSubsetSums.Adaptive146Third126State
import NineSeparatedSubsetSums.Adaptive146Third126Leaves1
import NineSeparatedSubsetSums.Adaptive146Third126Leaves0

namespace NineSeparatedSubsetSums

theorem adaptive146Third126Proof0 : runCachedNode 511 128058 Adaptive146Third126Node0 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 128058 Adaptive146Third126Node0 = [110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 125] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive146Third126Proof1
  · exact adaptive146Third126Proof2
  · exact adaptive146Third126Proof3
  · exact adaptive146Third126Proof4
  · exact adaptive146Third126Proof5
  · exact adaptive146Third126Proof6
  · exact adaptive146Third126Proof7
  · exact adaptive146Third126Proof8
  · exact adaptive146Third126Proof9
  · exact adaptive146Third126Proof10
  · exact adaptive146Third126Proof11
  · exact adaptive146Third126Proof12
  · exact adaptive146Third126Proof13
  · exact adaptive146Third126Proof14
  · exact adaptive146Third126Proof15

#print axioms adaptive146Third126Proof0

end NineSeparatedSubsetSums
