import NineSeparatedSubsetSums.Adaptive146Third140State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third140Proof216 : runCachedNode 511 130775 Adaptive146Third140Node216 = false := by
  decide +kernel

#print axioms adaptive146Third140Proof216

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third140Proof215 : runCachedNode 511 130775 Adaptive146Third140Node215 = false := by
  decide +kernel

#print axioms adaptive146Third140Proof215

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third140Proof5 : runCachedNode 511 130775 Adaptive146Third140Node5 = false := by
  decide +kernel

#print axioms adaptive146Third140Proof5

end NineSeparatedSubsetSums
