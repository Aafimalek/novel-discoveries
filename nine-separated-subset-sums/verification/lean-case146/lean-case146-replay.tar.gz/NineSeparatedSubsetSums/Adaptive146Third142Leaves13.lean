import NineSeparatedSubsetSums.Adaptive146Third142State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third142Proof146 : runCachedNode 511 131054 Adaptive146Third142Node146 = false := by
  decide +kernel

#print axioms adaptive146Third142Proof146

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third142Proof144 : runCachedNode 511 131054 Adaptive146Third142Node144 = false := by
  decide +kernel

#print axioms adaptive146Third142Proof144

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third142Proof309 : runCachedNode 511 131054 Adaptive146Third142Node309 = false := by
  decide +kernel

#print axioms adaptive146Third142Proof309

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third142Proof250 : runCachedNode 511 131054 Adaptive146Third142Node250 = false := by
  decide +kernel

#print axioms adaptive146Third142Proof250

end NineSeparatedSubsetSums
