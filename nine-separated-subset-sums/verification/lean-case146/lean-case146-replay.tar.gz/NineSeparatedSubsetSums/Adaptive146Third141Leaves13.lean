import NineSeparatedSubsetSums.Adaptive146Third141State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third141Proof139 : runCachedNode 511 130916 Adaptive146Third141Node139 = false := by
  decide +kernel

#print axioms adaptive146Third141Proof139

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third141Proof18 : runCachedNode 511 130916 Adaptive146Third141Node18 = false := by
  decide +kernel

#print axioms adaptive146Third141Proof18

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third141Proof60 : runCachedNode 511 130916 Adaptive146Third141Node60 = false := by
  decide +kernel

#print axioms adaptive146Third141Proof60

end NineSeparatedSubsetSums
