import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive146Third111Node0 : CachedSearchNode :=
  ⟨4, 110, computeCenteredMask [148,146,111], 405, 55541⟩

end NineSeparatedSubsetSums
