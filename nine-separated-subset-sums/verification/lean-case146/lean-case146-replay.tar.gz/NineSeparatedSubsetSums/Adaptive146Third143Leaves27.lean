import NineSeparatedSubsetSums.Adaptive146Third143State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third143Proof75 : runCachedNode 511 131193 Adaptive146Third143Node75 = false := by
  decide +kernel

#print axioms adaptive146Third143Proof75

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third143Proof161 : runCachedNode 511 131193 Adaptive146Third143Node161 = false := by
  decide +kernel

#print axioms adaptive146Third143Proof161

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third143Proof412 : runCachedNode 511 131193 Adaptive146Third143Node412 = false := by
  decide +kernel

#print axioms adaptive146Third143Proof412

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third143Proof458 : runCachedNode 511 131193 Adaptive146Third143Node458 = false := by
  decide +kernel

#print axioms adaptive146Third143Proof458

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third143Proof218 : runCachedNode 511 131193 Adaptive146Third143Node218 = false := by
  decide +kernel

#print axioms adaptive146Third143Proof218

end NineSeparatedSubsetSums
