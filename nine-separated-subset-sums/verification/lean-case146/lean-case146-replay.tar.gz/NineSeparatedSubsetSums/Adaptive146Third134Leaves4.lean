import NineSeparatedSubsetSums.Adaptive146Third134State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third134Proof72 : runCachedNode 511 129871 Adaptive146Third134Node72 = false := by
  decide +kernel

#print axioms adaptive146Third134Proof72

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third134Proof13 : runCachedNode 511 129871 Adaptive146Third134Node13 = false := by
  decide +kernel

#print axioms adaptive146Third134Proof13

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third134Proof71 : runCachedNode 511 129871 Adaptive146Third134Node71 = false := by
  decide +kernel

#print axioms adaptive146Third134Proof71

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third134Proof44 : runCachedNode 511 129871 Adaptive146Third134Node44 = false := by
  decide +kernel

#print axioms adaptive146Third134Proof44

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third134Proof70 : runCachedNode 511 129871 Adaptive146Third134Node70 = false := by
  decide +kernel

#print axioms adaptive146Third134Proof70

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third134Proof66 : runCachedNode 511 129871 Adaptive146Third134Node66 = false := by
  decide +kernel

#print axioms adaptive146Third134Proof66

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third134Proof52 : runCachedNode 511 129871 Adaptive146Third134Node52 = false := by
  decide +kernel

#print axioms adaptive146Third134Proof52

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third134Proof49 : runCachedNode 511 129871 Adaptive146Third134Node49 = false := by
  decide +kernel

#print axioms adaptive146Third134Proof49

end NineSeparatedSubsetSums
