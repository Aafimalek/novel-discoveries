import NineSeparatedSubsetSums.Adaptive146Third136State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third136Proof20 : runCachedNode 511 130191 Adaptive146Third136Node20 = false := by
  decide +kernel

#print axioms adaptive146Third136Proof20

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third136Proof97 : runCachedNode 511 130191 Adaptive146Third136Node97 = false := by
  decide +kernel

#print axioms adaptive146Third136Proof97

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third136Proof82 : runCachedNode 511 130191 Adaptive146Third136Node82 = false := by
  decide +kernel

#print axioms adaptive146Third136Proof82

end NineSeparatedSubsetSums
