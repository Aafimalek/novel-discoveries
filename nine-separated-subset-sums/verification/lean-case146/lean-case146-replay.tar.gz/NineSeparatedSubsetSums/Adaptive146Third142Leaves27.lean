import NineSeparatedSubsetSums.Adaptive146Third142State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third142Proof202 : runCachedNode 511 131054 Adaptive146Third142Node202 = false := by
  decide +kernel

#print axioms adaptive146Third142Proof202

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third142Proof441 : runCachedNode 511 131054 Adaptive146Third142Node441 = false := by
  decide +kernel

#print axioms adaptive146Third142Proof441

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third142Proof243 : runCachedNode 511 131054 Adaptive146Third142Node243 = false := by
  decide +kernel

#print axioms adaptive146Third142Proof243

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third142Proof136 : runCachedNode 511 131054 Adaptive146Third142Node136 = false := by
  decide +kernel

#print axioms adaptive146Third142Proof136

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third142Proof13 : runCachedNode 511 131054 Adaptive146Third142Node13 = false := by
  decide +kernel

#print axioms adaptive146Third142Proof13

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third142Proof50 : runCachedNode 511 131054 Adaptive146Third142Node50 = false := by
  decide +kernel

#print axioms adaptive146Third142Proof50

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third142Proof235 : runCachedNode 511 131054 Adaptive146Third142Node235 = false := by
  decide +kernel

#print axioms adaptive146Third142Proof235

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third142Proof314 : runCachedNode 511 131054 Adaptive146Third142Node314 = false := by
  decide +kernel

#print axioms adaptive146Third142Proof314

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third142Proof58 : runCachedNode 511 131054 Adaptive146Third142Node58 = false := by
  decide +kernel

#print axioms adaptive146Third142Proof58

end NineSeparatedSubsetSums
