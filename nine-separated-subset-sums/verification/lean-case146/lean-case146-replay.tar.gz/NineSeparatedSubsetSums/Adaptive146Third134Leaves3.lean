import NineSeparatedSubsetSums.Adaptive146Third134State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third134Proof18 : runCachedNode 511 129871 Adaptive146Third134Node18 = false := by
  decide +kernel

#print axioms adaptive146Third134Proof18

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third134Proof15 : runCachedNode 511 129871 Adaptive146Third134Node15 = false := by
  decide +kernel

#print axioms adaptive146Third134Proof15

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third134Proof14 : runCachedNode 511 129871 Adaptive146Third134Node14 = false := by
  decide +kernel

#print axioms adaptive146Third134Proof14

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third134Proof3 : runCachedNode 511 129871 Adaptive146Third134Node3 = false := by
  decide +kernel

#print axioms adaptive146Third134Proof3

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third134Proof1 : runCachedNode 511 129871 Adaptive146Third134Node1 = false := by
  decide +kernel

#print axioms adaptive146Third134Proof1

end NineSeparatedSubsetSums
