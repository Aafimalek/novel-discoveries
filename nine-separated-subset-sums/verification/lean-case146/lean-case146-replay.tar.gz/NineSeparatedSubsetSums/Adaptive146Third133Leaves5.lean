import NineSeparatedSubsetSums.Adaptive146Third133State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third133Proof8 : runCachedNode 511 129683 Adaptive146Third133Node8 = false := by
  decide +kernel

#print axioms adaptive146Third133Proof8

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third133Proof36 : runCachedNode 511 129683 Adaptive146Third133Node36 = false := by
  decide +kernel

#print axioms adaptive146Third133Proof36

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third133Proof38 : runCachedNode 511 129683 Adaptive146Third133Node38 = false := by
  decide +kernel

#print axioms adaptive146Third133Proof38

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third133Proof7 : runCachedNode 511 129683 Adaptive146Third133Node7 = false := by
  decide +kernel

#print axioms adaptive146Third133Proof7

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third133Proof40 : runCachedNode 511 129683 Adaptive146Third133Node40 = false := by
  decide +kernel

#print axioms adaptive146Third133Proof40

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third133Proof6 : runCachedNode 511 129683 Adaptive146Third133Node6 = false := by
  decide +kernel

#print axioms adaptive146Third133Proof6

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third133Proof34 : runCachedNode 511 129683 Adaptive146Third133Node34 = false := by
  decide +kernel

#print axioms adaptive146Third133Proof34

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third133Proof33 : runCachedNode 511 129683 Adaptive146Third133Node33 = false := by
  decide +kernel

#print axioms adaptive146Third133Proof33

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third133Proof31 : runCachedNode 511 129683 Adaptive146Third133Node31 = false := by
  decide +kernel

#print axioms adaptive146Third133Proof31

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third133Proof32 : runCachedNode 511 129683 Adaptive146Third133Node32 = false := by
  decide +kernel

#print axioms adaptive146Third133Proof32

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third133Proof29 : runCachedNode 511 129683 Adaptive146Third133Node29 = false := by
  decide +kernel

#print axioms adaptive146Third133Proof29

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third133Proof4 : runCachedNode 511 129683 Adaptive146Third133Node4 = false := by
  decide +kernel

#print axioms adaptive146Third133Proof4

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third133Proof28 : runCachedNode 511 129683 Adaptive146Third133Node28 = false := by
  decide +kernel

#print axioms adaptive146Third133Proof28

end NineSeparatedSubsetSums
