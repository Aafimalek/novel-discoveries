import NineSeparatedSubsetSums.Adaptive146Third136State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third136Proof68 : runCachedNode 511 130191 Adaptive146Third136Node68 = false := by
  decide +kernel

#print axioms adaptive146Third136Proof68

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third136Proof128 : runCachedNode 511 130191 Adaptive146Third136Node128 = false := by
  decide +kernel

#print axioms adaptive146Third136Proof128

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third136Proof72 : runCachedNode 511 130191 Adaptive146Third136Node72 = false := by
  decide +kernel

#print axioms adaptive146Third136Proof72

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third136Proof69 : runCachedNode 511 130191 Adaptive146Third136Node69 = false := by
  decide +kernel

#print axioms adaptive146Third136Proof69

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third136Proof53 : runCachedNode 511 130191 Adaptive146Third136Node53 = false := by
  decide +kernel

#print axioms adaptive146Third136Proof53

end NineSeparatedSubsetSums
