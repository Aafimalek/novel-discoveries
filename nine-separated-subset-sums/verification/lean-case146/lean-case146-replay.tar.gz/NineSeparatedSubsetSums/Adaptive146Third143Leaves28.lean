import NineSeparatedSubsetSums.Adaptive146Third143State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third143Proof576 : runCachedNode 511 131193 Adaptive146Third143Node576 = false := by
  decide +kernel

#print axioms adaptive146Third143Proof576

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third143Proof226 : runCachedNode 511 131193 Adaptive146Third143Node226 = false := by
  decide +kernel

#print axioms adaptive146Third143Proof226

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third143Proof335 : runCachedNode 511 131193 Adaptive146Third143Node335 = false := by
  decide +kernel

#print axioms adaptive146Third143Proof335

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third143Proof131 : runCachedNode 511 131193 Adaptive146Third143Node131 = false := by
  decide +kernel

#print axioms adaptive146Third143Proof131

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third143Proof332 : runCachedNode 511 131193 Adaptive146Third143Node332 = false := by
  decide +kernel

#print axioms adaptive146Third143Proof332

end NineSeparatedSubsetSums
