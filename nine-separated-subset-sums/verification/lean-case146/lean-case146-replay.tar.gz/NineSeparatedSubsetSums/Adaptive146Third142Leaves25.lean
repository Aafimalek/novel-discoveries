import NineSeparatedSubsetSums.Adaptive146Third142State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third142Proof173 : runCachedNode 511 131054 Adaptive146Third142Node173 = false := by
  decide +kernel

#print axioms adaptive146Third142Proof173

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third142Proof203 : runCachedNode 511 131054 Adaptive146Third142Node203 = false := by
  decide +kernel

#print axioms adaptive146Third142Proof203

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third142Proof52 : runCachedNode 511 131054 Adaptive146Third142Node52 = false := by
  decide +kernel

#print axioms adaptive146Third142Proof52

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third142Proof139 : runCachedNode 511 131054 Adaptive146Third142Node139 = false := by
  decide +kernel

#print axioms adaptive146Third142Proof139

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third142Proof81 : runCachedNode 511 131054 Adaptive146Third142Node81 = false := by
  decide +kernel

#print axioms adaptive146Third142Proof81

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third142Proof317 : runCachedNode 511 131054 Adaptive146Third142Node317 = false := by
  decide +kernel

#print axioms adaptive146Third142Proof317

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third142Proof275 : runCachedNode 511 131054 Adaptive146Third142Node275 = false := by
  decide +kernel

#print axioms adaptive146Third142Proof275

end NineSeparatedSubsetSums
