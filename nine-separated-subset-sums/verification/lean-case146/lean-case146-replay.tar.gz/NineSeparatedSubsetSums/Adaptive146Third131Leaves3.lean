import NineSeparatedSubsetSums.Adaptive146Third131State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third131Proof11 : runCachedNode 511 129268 Adaptive146Third131Node11 = false := by
  decide +kernel

#print axioms adaptive146Third131Proof11

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third131Proof10 : runCachedNode 511 129268 Adaptive146Third131Node10 = false := by
  decide +kernel

#print axioms adaptive146Third131Proof10

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third131Proof9 : runCachedNode 511 129268 Adaptive146Third131Node9 = false := by
  decide +kernel

#print axioms adaptive146Third131Proof9

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third131Proof8 : runCachedNode 511 129268 Adaptive146Third131Node8 = false := by
  decide +kernel

#print axioms adaptive146Third131Proof8

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third131Proof7 : runCachedNode 511 129268 Adaptive146Third131Node7 = false := by
  decide +kernel

#print axioms adaptive146Third131Proof7

end NineSeparatedSubsetSums
