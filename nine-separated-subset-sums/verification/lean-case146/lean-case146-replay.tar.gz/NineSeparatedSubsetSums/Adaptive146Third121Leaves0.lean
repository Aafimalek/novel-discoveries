import NineSeparatedSubsetSums.Adaptive146Third121State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third121Proof0 : runCachedNode 511 126743 Adaptive146Third121Node0 = false := by
  decide +kernel

#print axioms adaptive146Third121Proof0

end NineSeparatedSubsetSums
