import NineSeparatedSubsetSums.Adaptive146Third137State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third137Proof12 : runCachedNode 511 130354 Adaptive146Third137Node12 = false := by
  decide +kernel

#print axioms adaptive146Third137Proof12

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third137Proof150 : runCachedNode 511 130354 Adaptive146Third137Node150 = false := by
  decide +kernel

#print axioms adaptive146Third137Proof150

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third137Proof146 : runCachedNode 511 130354 Adaptive146Third137Node146 = false := by
  decide +kernel

#print axioms adaptive146Third137Proof146

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third137Proof39 : runCachedNode 511 130354 Adaptive146Third137Node39 = false := by
  decide +kernel

#print axioms adaptive146Third137Proof39

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third137Proof11 : runCachedNode 511 130354 Adaptive146Third137Node11 = false := by
  decide +kernel

#print axioms adaptive146Third137Proof11

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third137Proof91 : runCachedNode 511 130354 Adaptive146Third137Node91 = false := by
  decide +kernel

#print axioms adaptive146Third137Proof91

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third137Proof117 : runCachedNode 511 130354 Adaptive146Third137Node117 = false := by
  decide +kernel

#print axioms adaptive146Third137Proof117

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third137Proof64 : runCachedNode 511 130354 Adaptive146Third137Node64 = false := by
  decide +kernel

#print axioms adaptive146Third137Proof64

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third137Proof65 : runCachedNode 511 130354 Adaptive146Third137Node65 = false := by
  decide +kernel

#print axioms adaptive146Third137Proof65

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third137Proof41 : runCachedNode 511 130354 Adaptive146Third137Node41 = false := by
  decide +kernel

#print axioms adaptive146Third137Proof41

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third137Proof173 : runCachedNode 511 130354 Adaptive146Third137Node173 = false := by
  decide +kernel

#print axioms adaptive146Third137Proof173

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third137Proof127 : runCachedNode 511 130354 Adaptive146Third137Node127 = false := by
  decide +kernel

#print axioms adaptive146Third137Proof127

end NineSeparatedSubsetSums
