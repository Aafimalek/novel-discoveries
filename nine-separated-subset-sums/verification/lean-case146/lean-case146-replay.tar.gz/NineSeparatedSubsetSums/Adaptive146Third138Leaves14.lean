import NineSeparatedSubsetSums.Adaptive146Third138State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third138Proof179 : runCachedNode 511 130484 Adaptive146Third138Node179 = false := by
  decide +kernel

#print axioms adaptive146Third138Proof179

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third138Proof14 : runCachedNode 511 130484 Adaptive146Third138Node14 = false := by
  decide +kernel

#print axioms adaptive146Third138Proof14

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third138Proof40 : runCachedNode 511 130484 Adaptive146Third138Node40 = false := by
  decide +kernel

#print axioms adaptive146Third138Proof40

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third138Proof150 : runCachedNode 511 130484 Adaptive146Third138Node150 = false := by
  decide +kernel

#print axioms adaptive146Third138Proof150

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third138Proof13 : runCachedNode 511 130484 Adaptive146Third138Node13 = false := by
  decide +kernel

#print axioms adaptive146Third138Proof13

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third138Proof8 : runCachedNode 511 130484 Adaptive146Third138Node8 = false := by
  decide +kernel

#print axioms adaptive146Third138Proof8

end NineSeparatedSubsetSums
