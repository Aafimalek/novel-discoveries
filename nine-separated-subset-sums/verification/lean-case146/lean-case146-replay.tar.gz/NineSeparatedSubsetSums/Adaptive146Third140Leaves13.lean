import NineSeparatedSubsetSums.Adaptive146Third140State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third140Proof96 : runCachedNode 511 130775 Adaptive146Third140Node96 = false := by
  decide +kernel

#print axioms adaptive146Third140Proof96

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third140Proof214 : runCachedNode 511 130775 Adaptive146Third140Node214 = false := by
  decide +kernel

#print axioms adaptive146Third140Proof214

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third140Proof274 : runCachedNode 511 130775 Adaptive146Third140Node274 = false := by
  decide +kernel

#print axioms adaptive146Third140Proof274

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third140Proof2 : runCachedNode 511 130775 Adaptive146Third140Node2 = false := by
  decide +kernel

#print axioms adaptive146Third140Proof2

end NineSeparatedSubsetSums
