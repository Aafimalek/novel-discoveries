import NineSeparatedSubsetSums.Adaptive146Third138State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third138Proof151 : runCachedNode 511 130484 Adaptive146Third138Node151 = false := by
  decide +kernel

#print axioms adaptive146Third138Proof151

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third138Proof147 : runCachedNode 511 130484 Adaptive146Third138Node147 = false := by
  decide +kernel

#print axioms adaptive146Third138Proof147

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third138Proof73 : runCachedNode 511 130484 Adaptive146Third138Node73 = false := by
  decide +kernel

#print axioms adaptive146Third138Proof73

end NineSeparatedSubsetSums
