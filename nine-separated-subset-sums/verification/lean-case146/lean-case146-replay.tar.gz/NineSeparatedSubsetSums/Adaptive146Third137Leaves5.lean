import NineSeparatedSubsetSums.Adaptive146Third137State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third137Proof178 : runCachedNode 511 130354 Adaptive146Third137Node178 = false := by
  decide +kernel

#print axioms adaptive146Third137Proof178

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third137Proof152 : runCachedNode 511 130354 Adaptive146Third137Node152 = false := by
  decide +kernel

#print axioms adaptive146Third137Proof152

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third137Proof122 : runCachedNode 511 130354 Adaptive146Third137Node122 = false := by
  decide +kernel

#print axioms adaptive146Third137Proof122

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third137Proof148 : runCachedNode 511 130354 Adaptive146Third137Node148 = false := by
  decide +kernel

#print axioms adaptive146Third137Proof148

end NineSeparatedSubsetSums
