import NineSeparatedSubsetSums.Adaptive146Third143State
import NineSeparatedSubsetSums.Adaptive146Third143Leaves53
import NineSeparatedSubsetSums.Adaptive146Third143Leaves52
import NineSeparatedSubsetSums.Adaptive146Third143Leaves51
import NineSeparatedSubsetSums.Adaptive146Third143Leaves50
import NineSeparatedSubsetSums.Adaptive146Third143Leaves49
import NineSeparatedSubsetSums.Adaptive146Third143Leaves47
import NineSeparatedSubsetSums.Adaptive146Third143Leaves46
import NineSeparatedSubsetSums.Adaptive146Third143Leaves45
import NineSeparatedSubsetSums.Adaptive146Third143Leaves43
import NineSeparatedSubsetSums.Adaptive146Third143Leaves42
import NineSeparatedSubsetSums.Adaptive146Third143Leaves41
import NineSeparatedSubsetSums.Adaptive146Third143Leaves39
import NineSeparatedSubsetSums.Adaptive146Third143Leaves38
import NineSeparatedSubsetSums.Adaptive146Third143Leaves35
import NineSeparatedSubsetSums.Adaptive146Third143Leaves32
import NineSeparatedSubsetSums.Adaptive146Third143Leaves33
import NineSeparatedSubsetSums.Adaptive146Third143Leaves26
import NineSeparatedSubsetSums.Adaptive146Third143Leaves22
import NineSeparatedSubsetSums.Adaptive146Third143Leaves21
import NineSeparatedSubsetSums.Adaptive146Third143Leaves9
import NineSeparatedSubsetSums.Adaptive146Third143Leaves20
import NineSeparatedSubsetSums.Adaptive146Third143Leaves3
import NineSeparatedSubsetSums.Adaptive146Third143Leaves2
import NineSeparatedSubsetSums.Adaptive146Third143Leaves5
import NineSeparatedSubsetSums.Adaptive146Third143Leaves7
import NineSeparatedSubsetSums.Adaptive146Third143Joins0
import NineSeparatedSubsetSums.Adaptive146Third143Leaves54
import NineSeparatedSubsetSums.Adaptive146Third143Leaves48
import NineSeparatedSubsetSums.Adaptive146Third143Leaves44
import NineSeparatedSubsetSums.Adaptive146Third143Leaves40
import NineSeparatedSubsetSums.Adaptive146Third143Leaves34
import NineSeparatedSubsetSums.Adaptive146Third143Leaves31
import NineSeparatedSubsetSums.Adaptive146Third143Leaves25
import NineSeparatedSubsetSums.Adaptive146Third143Leaves37
import NineSeparatedSubsetSums.Adaptive146Third143Leaves36
import NineSeparatedSubsetSums.Adaptive146Third143Leaves28
import NineSeparatedSubsetSums.Adaptive146Third143Leaves29
import NineSeparatedSubsetSums.Adaptive146Third143Leaves15
import NineSeparatedSubsetSums.Adaptive146Third143Leaves6
import NineSeparatedSubsetSums.Adaptive146Third143Leaves13
import NineSeparatedSubsetSums.Adaptive146Third143Leaves17
import NineSeparatedSubsetSums.Adaptive146Third143Leaves27
import NineSeparatedSubsetSums.Adaptive146Third143Leaves55
import NineSeparatedSubsetSums.Adaptive146Third143Leaves1
import NineSeparatedSubsetSums.Adaptive146Third143Leaves30
import NineSeparatedSubsetSums.Adaptive146Third143Leaves12
import NineSeparatedSubsetSums.Adaptive146Third143Leaves16
import NineSeparatedSubsetSums.Adaptive146Third143Leaves10
import NineSeparatedSubsetSums.Adaptive146Third143Leaves0
import NineSeparatedSubsetSums.Adaptive146Third143Leaves11

namespace NineSeparatedSubsetSums

theorem adaptive146Third143Proof232 : runCachedNode 511 131193 Adaptive146Third143Node232 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 131193 Adaptive146Third143Node232 = [101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 132, 134, 137] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive146Third143Proof233
  · exact adaptive146Third143Proof234
  · exact adaptive146Third143Proof235
  · exact adaptive146Third143Proof236
  · exact adaptive146Third143Proof237
  · exact adaptive146Third143Proof238
  · exact adaptive146Third143Proof239
  · exact adaptive146Third143Proof240
  · exact adaptive146Third143Proof241
  · exact adaptive146Third143Proof242
  · exact adaptive146Third143Proof243
  · exact adaptive146Third143Proof244
  · exact adaptive146Third143Proof245
  · exact adaptive146Third143Proof246
  · exact adaptive146Third143Proof247
  · exact adaptive146Third143Proof248
  · exact adaptive146Third143Proof249
  · exact adaptive146Third143Proof250
  · exact adaptive146Third143Proof251
  · exact adaptive146Third143Proof252
  · exact adaptive146Third143Proof253
  · exact adaptive146Third143Proof254
  · exact adaptive146Third143Proof255
  · exact adaptive146Third143Proof256
  · exact adaptive146Third143Proof257
  · exact adaptive146Third143Proof258
  · exact adaptive146Third143Proof259
  · exact adaptive146Third143Proof260
  · exact adaptive146Third143Proof261
  · exact adaptive146Third143Proof262
  · exact adaptive146Third143Proof263
  · exact adaptive146Third143Proof264
  · exact adaptive146Third143Proof265
  · exact adaptive146Third143Proof266

#print axioms adaptive146Third143Proof232

theorem adaptive146Third143Proof342 : runCachedNode 511 131193 Adaptive146Third143Node342 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 131193 Adaptive146Third143Node342 = [87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 127, 128, 130] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive146Third143Proof343
  · exact adaptive146Third143Proof344
  · exact adaptive146Third143Proof345
  · exact adaptive146Third143Proof346
  · exact adaptive146Third143Proof347
  · exact adaptive146Third143Proof348
  · exact adaptive146Third143Proof349
  · exact adaptive146Third143Proof350
  · exact adaptive146Third143Proof351
  · exact adaptive146Third143Proof352
  · exact adaptive146Third143Proof353
  · exact adaptive146Third143Proof354
  · exact adaptive146Third143Proof355
  · exact adaptive146Third143Proof356
  · exact adaptive146Third143Proof357
  · exact adaptive146Third143Proof358
  · exact adaptive146Third143Proof359
  · exact adaptive146Third143Proof360
  · exact adaptive146Third143Proof361
  · exact adaptive146Third143Proof362
  · exact adaptive146Third143Proof363
  · exact adaptive146Third143Proof364
  · exact adaptive146Third143Proof365
  · exact adaptive146Third143Proof366
  · exact adaptive146Third143Proof367
  · exact adaptive146Third143Proof368
  · exact adaptive146Third143Proof369
  · exact adaptive146Third143Proof370
  · exact adaptive146Third143Proof371
  · exact adaptive146Third143Proof372
  · exact adaptive146Third143Proof373
  · exact adaptive146Third143Proof374
  · exact adaptive146Third143Proof375
  · exact adaptive146Third143Proof376
  · exact adaptive146Third143Proof377
  · exact adaptive146Third143Proof378
  · exact adaptive146Third143Proof379
  · exact adaptive146Third143Proof380
  · exact adaptive146Third143Proof381
  · exact adaptive146Third143Proof382
  · exact adaptive146Third143Proof383
  · exact adaptive146Third143Proof384

#print axioms adaptive146Third143Proof342

theorem adaptive146Third143Proof307 : runCachedNode 511 131193 Adaptive146Third143Node307 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 131193 Adaptive146Third143Node307 = [101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 132, 133, 135, 138] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive146Third143Proof308
  · exact adaptive146Third143Proof309
  · exact adaptive146Third143Proof310
  · exact adaptive146Third143Proof311
  · exact adaptive146Third143Proof312
  · exact adaptive146Third143Proof313
  · exact adaptive146Third143Proof314
  · exact adaptive146Third143Proof315
  · exact adaptive146Third143Proof316
  · exact adaptive146Third143Proof317
  · exact adaptive146Third143Proof318
  · exact adaptive146Third143Proof319
  · exact adaptive146Third143Proof320
  · exact adaptive146Third143Proof321
  · exact adaptive146Third143Proof322
  · exact adaptive146Third143Proof323
  · exact adaptive146Third143Proof324
  · exact adaptive146Third143Proof325
  · exact adaptive146Third143Proof326
  · exact adaptive146Third143Proof327
  · exact adaptive146Third143Proof328
  · exact adaptive146Third143Proof329
  · exact adaptive146Third143Proof330
  · exact adaptive146Third143Proof331
  · exact adaptive146Third143Proof332
  · exact adaptive146Third143Proof333
  · exact adaptive146Third143Proof334
  · exact adaptive146Third143Proof335
  · exact adaptive146Third143Proof336
  · exact adaptive146Third143Proof337
  · exact adaptive146Third143Proof338
  · exact adaptive146Third143Proof339
  · exact adaptive146Third143Proof340
  · exact adaptive146Third143Proof341
  · exact adaptive146Third143Proof342

#print axioms adaptive146Third143Proof307

theorem adaptive146Third143Proof420 : runCachedNode 511 131193 Adaptive146Third143Node420 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 131193 Adaptive146Third143Node420 = [89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 124, 125, 127, 130] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive146Third143Proof421
  · exact adaptive146Third143Proof422
  · exact adaptive146Third143Proof423
  · exact adaptive146Third143Proof424
  · exact adaptive146Third143Proof425
  · exact adaptive146Third143Proof426
  · exact adaptive146Third143Proof427
  · exact adaptive146Third143Proof428
  · exact adaptive146Third143Proof429
  · exact adaptive146Third143Proof430
  · exact adaptive146Third143Proof431
  · exact adaptive146Third143Proof432
  · exact adaptive146Third143Proof433
  · exact adaptive146Third143Proof434
  · exact adaptive146Third143Proof435
  · exact adaptive146Third143Proof436
  · exact adaptive146Third143Proof437
  · exact adaptive146Third143Proof438
  · exact adaptive146Third143Proof439
  · exact adaptive146Third143Proof440
  · exact adaptive146Third143Proof441
  · exact adaptive146Third143Proof442
  · exact adaptive146Third143Proof443
  · exact adaptive146Third143Proof444
  · exact adaptive146Third143Proof445
  · exact adaptive146Third143Proof446
  · exact adaptive146Third143Proof447
  · exact adaptive146Third143Proof448
  · exact adaptive146Third143Proof449
  · exact adaptive146Third143Proof450
  · exact adaptive146Third143Proof451
  · exact adaptive146Third143Proof452
  · exact adaptive146Third143Proof453
  · exact adaptive146Third143Proof454
  · exact adaptive146Third143Proof455
  · exact adaptive146Third143Proof456
  · exact adaptive146Third143Proof457
  · exact adaptive146Third143Proof458

#print axioms adaptive146Third143Proof420

theorem adaptive146Third143Proof459 : runCachedNode 511 131193 Adaptive146Third143Node459 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 131193 Adaptive146Third143Node459 = [88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 126, 127, 129, 132] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive146Third143Proof460
  · exact adaptive146Third143Proof461
  · exact adaptive146Third143Proof462
  · exact adaptive146Third143Proof463
  · exact adaptive146Third143Proof464
  · exact adaptive146Third143Proof465
  · exact adaptive146Third143Proof466
  · exact adaptive146Third143Proof467
  · exact adaptive146Third143Proof468
  · exact adaptive146Third143Proof469
  · exact adaptive146Third143Proof470
  · exact adaptive146Third143Proof471
  · exact adaptive146Third143Proof472
  · exact adaptive146Third143Proof473
  · exact adaptive146Third143Proof474
  · exact adaptive146Third143Proof475
  · exact adaptive146Third143Proof476
  · exact adaptive146Third143Proof477
  · exact adaptive146Third143Proof478
  · exact adaptive146Third143Proof479
  · exact adaptive146Third143Proof480
  · exact adaptive146Third143Proof481
  · exact adaptive146Third143Proof482
  · exact adaptive146Third143Proof483
  · exact adaptive146Third143Proof484
  · exact adaptive146Third143Proof485
  · exact adaptive146Third143Proof486
  · exact adaptive146Third143Proof487
  · exact adaptive146Third143Proof488
  · exact adaptive146Third143Proof489
  · exact adaptive146Third143Proof490
  · exact adaptive146Third143Proof491
  · exact adaptive146Third143Proof492
  · exact adaptive146Third143Proof493
  · exact adaptive146Third143Proof494
  · exact adaptive146Third143Proof495
  · exact adaptive146Third143Proof496
  · exact adaptive146Third143Proof497
  · exact adaptive146Third143Proof498
  · exact adaptive146Third143Proof499
  · exact adaptive146Third143Proof500

#print axioms adaptive146Third143Proof459

theorem adaptive146Third143Proof501 : runCachedNode 511 131193 Adaptive146Third143Node501 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 131193 Adaptive146Third143Node501 = [87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 129, 130, 132] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive146Third143Proof502
  · exact adaptive146Third143Proof503
  · exact adaptive146Third143Proof504
  · exact adaptive146Third143Proof505
  · exact adaptive146Third143Proof506
  · exact adaptive146Third143Proof507
  · exact adaptive146Third143Proof508
  · exact adaptive146Third143Proof509
  · exact adaptive146Third143Proof510
  · exact adaptive146Third143Proof511
  · exact adaptive146Third143Proof512
  · exact adaptive146Third143Proof513
  · exact adaptive146Third143Proof514
  · exact adaptive146Third143Proof515
  · exact adaptive146Third143Proof516
  · exact adaptive146Third143Proof517
  · exact adaptive146Third143Proof518
  · exact adaptive146Third143Proof519
  · exact adaptive146Third143Proof520
  · exact adaptive146Third143Proof521
  · exact adaptive146Third143Proof522
  · exact adaptive146Third143Proof523
  · exact adaptive146Third143Proof524
  · exact adaptive146Third143Proof525
  · exact adaptive146Third143Proof526
  · exact adaptive146Third143Proof527
  · exact adaptive146Third143Proof528
  · exact adaptive146Third143Proof529
  · exact adaptive146Third143Proof530
  · exact adaptive146Third143Proof531
  · exact adaptive146Third143Proof532
  · exact adaptive146Third143Proof533
  · exact adaptive146Third143Proof534
  · exact adaptive146Third143Proof535
  · exact adaptive146Third143Proof536
  · exact adaptive146Third143Proof537
  · exact adaptive146Third143Proof538
  · exact adaptive146Third143Proof539
  · exact adaptive146Third143Proof540
  · exact adaptive146Third143Proof541
  · exact adaptive146Third143Proof542
  · exact adaptive146Third143Proof543
  · exact adaptive146Third143Proof544
  · exact adaptive146Third143Proof545

#print axioms adaptive146Third143Proof501

theorem adaptive146Third143Proof385 : runCachedNode 511 131193 Adaptive146Third143Node385 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 131193 Adaptive146Third143Node385 = [100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 132, 133, 134, 136, 139] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive146Third143Proof386
  · exact adaptive146Third143Proof387
  · exact adaptive146Third143Proof388
  · exact adaptive146Third143Proof389
  · exact adaptive146Third143Proof390
  · exact adaptive146Third143Proof391
  · exact adaptive146Third143Proof392
  · exact adaptive146Third143Proof393
  · exact adaptive146Third143Proof394
  · exact adaptive146Third143Proof395
  · exact adaptive146Third143Proof396
  · exact adaptive146Third143Proof397
  · exact adaptive146Third143Proof398
  · exact adaptive146Third143Proof399
  · exact adaptive146Third143Proof400
  · exact adaptive146Third143Proof401
  · exact adaptive146Third143Proof402
  · exact adaptive146Third143Proof403
  · exact adaptive146Third143Proof404
  · exact adaptive146Third143Proof405
  · exact adaptive146Third143Proof406
  · exact adaptive146Third143Proof407
  · exact adaptive146Third143Proof408
  · exact adaptive146Third143Proof409
  · exact adaptive146Third143Proof410
  · exact adaptive146Third143Proof411
  · exact adaptive146Third143Proof412
  · exact adaptive146Third143Proof413
  · exact adaptive146Third143Proof414
  · exact adaptive146Third143Proof415
  · exact adaptive146Third143Proof416
  · exact adaptive146Third143Proof417
  · exact adaptive146Third143Proof418
  · exact adaptive146Third143Proof419
  · exact adaptive146Third143Proof420
  · exact adaptive146Third143Proof459
  · exact adaptive146Third143Proof501

#print axioms adaptive146Third143Proof385

theorem adaptive146Third143Proof583 : runCachedNode 511 131193 Adaptive146Third143Node583 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 131193 Adaptive146Third143Node583 = [87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 128, 129] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive146Third143Proof584
  · exact adaptive146Third143Proof585
  · exact adaptive146Third143Proof586
  · exact adaptive146Third143Proof587
  · exact adaptive146Third143Proof588
  · exact adaptive146Third143Proof589
  · exact adaptive146Third143Proof590
  · exact adaptive146Third143Proof591
  · exact adaptive146Third143Proof592
  · exact adaptive146Third143Proof593
  · exact adaptive146Third143Proof594
  · exact adaptive146Third143Proof595
  · exact adaptive146Third143Proof596
  · exact adaptive146Third143Proof597
  · exact adaptive146Third143Proof598
  · exact adaptive146Third143Proof599
  · exact adaptive146Third143Proof600
  · exact adaptive146Third143Proof601
  · exact adaptive146Third143Proof602
  · exact adaptive146Third143Proof603
  · exact adaptive146Third143Proof604
  · exact adaptive146Third143Proof605
  · exact adaptive146Third143Proof606
  · exact adaptive146Third143Proof607
  · exact adaptive146Third143Proof608
  · exact adaptive146Third143Proof609
  · exact adaptive146Third143Proof610
  · exact adaptive146Third143Proof611
  · exact adaptive146Third143Proof612
  · exact adaptive146Third143Proof613
  · exact adaptive146Third143Proof614
  · exact adaptive146Third143Proof615
  · exact adaptive146Third143Proof616
  · exact adaptive146Third143Proof617
  · exact adaptive146Third143Proof618
  · exact adaptive146Third143Proof619
  · exact adaptive146Third143Proof620
  · exact adaptive146Third143Proof621
  · exact adaptive146Third143Proof622
  · exact adaptive146Third143Proof623
  · exact adaptive146Third143Proof624
  · exact adaptive146Third143Proof625

#print axioms adaptive146Third143Proof583

end NineSeparatedSubsetSums
