import NineSeparatedSubsetSums.Adaptive146Third140State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third140Proof283 : runCachedNode 511 130775 Adaptive146Third140Node283 = false := by
  decide +kernel

#print axioms adaptive146Third140Proof283

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third140Proof98 : runCachedNode 511 130775 Adaptive146Third140Node98 = false := by
  decide +kernel

#print axioms adaptive146Third140Proof98

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third140Proof6 : runCachedNode 511 130775 Adaptive146Third140Node6 = false := by
  decide +kernel

#print axioms adaptive146Third140Proof6

end NineSeparatedSubsetSums
