import NineSeparatedSubsetSums.Adaptive146Third143State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third143Proof134 : runCachedNode 511 131193 Adaptive146Third143Node134 = false := by
  decide +kernel

#print axioms adaptive146Third143Proof134

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third143Proof15 : runCachedNode 511 131193 Adaptive146Third143Node15 = false := by
  decide +kernel

#print axioms adaptive146Third143Proof15

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third143Proof257 : runCachedNode 511 131193 Adaptive146Third143Node257 = false := by
  decide +kernel

#print axioms adaptive146Third143Proof257

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third143Proof543 : runCachedNode 511 131193 Adaptive146Third143Node543 = false := by
  decide +kernel

#print axioms adaptive146Third143Proof543

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third143Proof108 : runCachedNode 511 131193 Adaptive146Third143Node108 = false := by
  decide +kernel

#print axioms adaptive146Third143Proof108

end NineSeparatedSubsetSums
