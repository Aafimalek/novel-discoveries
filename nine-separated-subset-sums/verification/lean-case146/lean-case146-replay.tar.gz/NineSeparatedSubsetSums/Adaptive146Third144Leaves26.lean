import NineSeparatedSubsetSums.Adaptive146Third144State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third144Proof714 : runCachedNode 511 131319 Adaptive146Third144Node714 = false := by
  decide +kernel

#print axioms adaptive146Third144Proof714

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third144Proof1204 : runCachedNode 511 131319 Adaptive146Third144Node1204 = false := by
  decide +kernel

#print axioms adaptive146Third144Proof1204

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third144Proof2 : runCachedNode 511 131319 Adaptive146Third144Node2 = false := by
  decide +kernel

#print axioms adaptive146Third144Proof2

end NineSeparatedSubsetSums
