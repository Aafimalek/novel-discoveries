import NineSeparatedSubsetSums.Adaptive146Third140State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third140Proof44 : runCachedNode 511 130775 Adaptive146Third140Node44 = false := by
  decide +kernel

#print axioms adaptive146Third140Proof44

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third140Proof349 : runCachedNode 511 130775 Adaptive146Third140Node349 = false := by
  decide +kernel

#print axioms adaptive146Third140Proof349

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third140Proof279 : runCachedNode 511 130775 Adaptive146Third140Node279 = false := by
  decide +kernel

#print axioms adaptive146Third140Proof279

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third140Proof379 : runCachedNode 511 130775 Adaptive146Third140Node379 = false := by
  decide +kernel

#print axioms adaptive146Third140Proof379

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third140Proof377 : runCachedNode 511 130775 Adaptive146Third140Node377 = false := by
  decide +kernel

#print axioms adaptive146Third140Proof377

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third140Proof93 : runCachedNode 511 130775 Adaptive146Third140Node93 = false := by
  decide +kernel

#print axioms adaptive146Third140Proof93

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third140Proof275 : runCachedNode 511 130775 Adaptive146Third140Node275 = false := by
  decide +kernel

#print axioms adaptive146Third140Proof275

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third140Proof23 : runCachedNode 511 130775 Adaptive146Third140Node23 = false := by
  decide +kernel

#print axioms adaptive146Third140Proof23

end NineSeparatedSubsetSums
