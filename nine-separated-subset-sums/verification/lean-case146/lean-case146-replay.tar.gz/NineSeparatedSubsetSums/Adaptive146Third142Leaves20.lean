import NineSeparatedSubsetSums.Adaptive146Third142State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third142Proof178 : runCachedNode 511 131054 Adaptive146Third142Node178 = false := by
  decide +kernel

#print axioms adaptive146Third142Proof178

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third142Proof288 : runCachedNode 511 131054 Adaptive146Third142Node288 = false := by
  decide +kernel

#print axioms adaptive146Third142Proof288

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third142Proof206 : runCachedNode 511 131054 Adaptive146Third142Node206 = false := by
  decide +kernel

#print axioms adaptive146Third142Proof206

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third142Proof485 : runCachedNode 511 131054 Adaptive146Third142Node485 = false := by
  decide +kernel

#print axioms adaptive146Third142Proof485

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third142Proof422 : runCachedNode 511 131054 Adaptive146Third142Node422 = false := by
  decide +kernel

#print axioms adaptive146Third142Proof422

end NineSeparatedSubsetSums
