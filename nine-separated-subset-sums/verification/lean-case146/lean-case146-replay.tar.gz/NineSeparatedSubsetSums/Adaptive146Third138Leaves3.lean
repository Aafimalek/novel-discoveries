import NineSeparatedSubsetSums.Adaptive146Third138State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third138Proof94 : runCachedNode 511 130484 Adaptive146Third138Node94 = false := by
  decide +kernel

#print axioms adaptive146Third138Proof94

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third138Proof18 : runCachedNode 511 130484 Adaptive146Third138Node18 = false := by
  decide +kernel

#print axioms adaptive146Third138Proof18

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third138Proof171 : runCachedNode 511 130484 Adaptive146Third138Node171 = false := by
  decide +kernel

#print axioms adaptive146Third138Proof171

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third138Proof156 : runCachedNode 511 130484 Adaptive146Third138Node156 = false := by
  decide +kernel

#print axioms adaptive146Third138Proof156

end NineSeparatedSubsetSums
