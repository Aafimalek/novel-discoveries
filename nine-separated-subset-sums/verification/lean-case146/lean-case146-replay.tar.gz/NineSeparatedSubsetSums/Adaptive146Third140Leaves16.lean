import NineSeparatedSubsetSums.Adaptive146Third140State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third140Proof312 : runCachedNode 511 130775 Adaptive146Third140Node312 = false := by
  decide +kernel

#print axioms adaptive146Third140Proof312

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third140Proof245 : runCachedNode 511 130775 Adaptive146Third140Node245 = false := by
  decide +kernel

#print axioms adaptive146Third140Proof245

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third140Proof246 : runCachedNode 511 130775 Adaptive146Third140Node246 = false := by
  decide +kernel

#print axioms adaptive146Third140Proof246

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third140Proof15 : runCachedNode 511 130775 Adaptive146Third140Node15 = false := by
  decide +kernel

#print axioms adaptive146Third140Proof15

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third140Proof236 : runCachedNode 511 130775 Adaptive146Third140Node236 = false := by
  decide +kernel

#print axioms adaptive146Third140Proof236

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third140Proof317 : runCachedNode 511 130775 Adaptive146Third140Node317 = false := by
  decide +kernel

#print axioms adaptive146Third140Proof317

end NineSeparatedSubsetSums
