import NineSeparatedSubsetSums.Adaptive146Third140State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third140Proof70 : runCachedNode 511 130775 Adaptive146Third140Node70 = false := by
  decide +kernel

#print axioms adaptive146Third140Proof70

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third140Proof146 : runCachedNode 511 130775 Adaptive146Third140Node146 = false := by
  decide +kernel

#print axioms adaptive146Third140Proof146

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third140Proof278 : runCachedNode 511 130775 Adaptive146Third140Node278 = false := by
  decide +kernel

#print axioms adaptive146Third140Proof278

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third140Proof378 : runCachedNode 511 130775 Adaptive146Third140Node378 = false := by
  decide +kernel

#print axioms adaptive146Third140Proof378

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third140Proof213 : runCachedNode 511 130775 Adaptive146Third140Node213 = false := by
  decide +kernel

#print axioms adaptive146Third140Proof213

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third140Proof376 : runCachedNode 511 130775 Adaptive146Third140Node376 = false := by
  decide +kernel

#print axioms adaptive146Third140Proof376

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third140Proof122 : runCachedNode 511 130775 Adaptive146Third140Node122 = false := by
  decide +kernel

#print axioms adaptive146Third140Proof122

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third140Proof115 : runCachedNode 511 130775 Adaptive146Third140Node115 = false := by
  decide +kernel

#print axioms adaptive146Third140Proof115

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third140Proof318 : runCachedNode 511 130775 Adaptive146Third140Node318 = false := by
  decide +kernel

#print axioms adaptive146Third140Proof318

end NineSeparatedSubsetSums
