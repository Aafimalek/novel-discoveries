import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive146Third119Node0 : CachedSearchNode :=
  ⟨4, 118, computeCenteredMask [148,146,119], 413, 57381⟩

end NineSeparatedSubsetSums
