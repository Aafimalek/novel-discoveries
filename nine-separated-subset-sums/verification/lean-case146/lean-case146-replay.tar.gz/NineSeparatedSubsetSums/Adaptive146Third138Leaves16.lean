import NineSeparatedSubsetSums.Adaptive146Third138State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third138Proof65 : runCachedNode 511 130484 Adaptive146Third138Node65 = false := by
  decide +kernel

#print axioms adaptive146Third138Proof65

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third138Proof11 : runCachedNode 511 130484 Adaptive146Third138Node11 = false := by
  decide +kernel

#print axioms adaptive146Third138Proof11

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third138Proof119 : runCachedNode 511 130484 Adaptive146Third138Node119 = false := by
  decide +kernel

#print axioms adaptive146Third138Proof119

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third138Proof208 : runCachedNode 511 130484 Adaptive146Third138Node208 = false := by
  decide +kernel

#print axioms adaptive146Third138Proof208

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third138Proof145 : runCachedNode 511 130484 Adaptive146Third138Node145 = false := by
  decide +kernel

#print axioms adaptive146Third138Proof145

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third138Proof38 : runCachedNode 511 130484 Adaptive146Third138Node38 = false := by
  decide +kernel

#print axioms adaptive146Third138Proof38

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third138Proof207 : runCachedNode 511 130484 Adaptive146Third138Node207 = false := by
  decide +kernel

#print axioms adaptive146Third138Proof207

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third138Proof175 : runCachedNode 511 130484 Adaptive146Third138Node175 = false := by
  decide +kernel

#print axioms adaptive146Third138Proof175

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third138Proof176 : runCachedNode 511 130484 Adaptive146Third138Node176 = false := by
  decide +kernel

#print axioms adaptive146Third138Proof176

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third138Proof39 : runCachedNode 511 130484 Adaptive146Third138Node39 = false := by
  decide +kernel

#print axioms adaptive146Third138Proof39

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third138Proof148 : runCachedNode 511 130484 Adaptive146Third138Node148 = false := by
  decide +kernel

#print axioms adaptive146Third138Proof148

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third138Proof36 : runCachedNode 511 130484 Adaptive146Third138Node36 = false := by
  decide +kernel

#print axioms adaptive146Third138Proof36

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third138Proof101 : runCachedNode 511 130484 Adaptive146Third138Node101 = false := by
  decide +kernel

#print axioms adaptive146Third138Proof101

end NineSeparatedSubsetSums
