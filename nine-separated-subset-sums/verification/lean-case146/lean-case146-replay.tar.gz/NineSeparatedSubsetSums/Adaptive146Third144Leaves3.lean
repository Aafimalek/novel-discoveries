import NineSeparatedSubsetSums.Adaptive146Third144State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third144Proof1290 : runCachedNode 511 131319 Adaptive146Third144Node1290 = false := by
  decide +kernel

#print axioms adaptive146Third144Proof1290

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third144Proof596 : runCachedNode 511 131319 Adaptive146Third144Node596 = false := by
  decide +kernel

#print axioms adaptive146Third144Proof596

end NineSeparatedSubsetSums
