import NineSeparatedSubsetSums.Adaptive146Third128State
import NineSeparatedSubsetSums.Adaptive146Third128Leaves1
import NineSeparatedSubsetSums.Adaptive146Third128Leaves0

namespace NineSeparatedSubsetSums

theorem adaptive146Third128Proof0 : runCachedNode 511 128614 Adaptive146Third128Node0 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 128614 Adaptive146Third128Node0 = [110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 127] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive146Third128Proof1
  · exact adaptive146Third128Proof2
  · exact adaptive146Third128Proof3
  · exact adaptive146Third128Proof4
  · exact adaptive146Third128Proof5
  · exact adaptive146Third128Proof6
  · exact adaptive146Third128Proof7
  · exact adaptive146Third128Proof8
  · exact adaptive146Third128Proof9
  · exact adaptive146Third128Proof10
  · exact adaptive146Third128Proof11
  · exact adaptive146Third128Proof12
  · exact adaptive146Third128Proof13
  · exact adaptive146Third128Proof14
  · exact adaptive146Third128Proof15
  · exact adaptive146Third128Proof16
  · exact adaptive146Third128Proof17

#print axioms adaptive146Third128Proof0

end NineSeparatedSubsetSums
