import NineSeparatedSubsetSums.Adaptive146Third139State
import NineSeparatedSubsetSums.Adaptive146Third139Leaves9
import NineSeparatedSubsetSums.Adaptive146Third139Leaves23
import NineSeparatedSubsetSums.Adaptive146Third139Leaves22
import NineSeparatedSubsetSums.Adaptive146Third139Leaves21
import NineSeparatedSubsetSums.Adaptive146Third139Leaves20
import NineSeparatedSubsetSums.Adaptive146Third139Leaves19
import NineSeparatedSubsetSums.Adaptive146Third139Leaves17
import NineSeparatedSubsetSums.Adaptive146Third139Leaves16
import NineSeparatedSubsetSums.Adaptive146Third139Leaves15
import NineSeparatedSubsetSums.Adaptive146Third139Leaves14
import NineSeparatedSubsetSums.Adaptive146Third139Leaves13
import NineSeparatedSubsetSums.Adaptive146Third139Leaves12
import NineSeparatedSubsetSums.Adaptive146Third139Leaves10
import NineSeparatedSubsetSums.Adaptive146Third139Leaves8
import NineSeparatedSubsetSums.Adaptive146Third139Leaves1
import NineSeparatedSubsetSums.Adaptive146Third139Leaves0
import NineSeparatedSubsetSums.Adaptive146Third139Joins0

namespace NineSeparatedSubsetSums

theorem adaptive146Third139Proof0 : runCachedNode 511 130638 Adaptive146Third139Node0 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130638 Adaptive146Third139Node0 = [110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 132, 133, 134, 135, 136, 138] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive146Third139Proof1
  · exact adaptive146Third139Proof2
  · exact adaptive146Third139Proof3
  · exact adaptive146Third139Proof4
  · exact adaptive146Third139Proof5
  · exact adaptive146Third139Proof6
  · exact adaptive146Third139Proof7
  · exact adaptive146Third139Proof8
  · exact adaptive146Third139Proof9
  · exact adaptive146Third139Proof10
  · exact adaptive146Third139Proof11
  · exact adaptive146Third139Proof12
  · exact adaptive146Third139Proof13
  · exact adaptive146Third139Proof14
  · exact adaptive146Third139Proof15
  · exact adaptive146Third139Proof16
  · exact adaptive146Third139Proof17
  · exact adaptive146Third139Proof18
  · exact adaptive146Third139Proof19
  · exact adaptive146Third139Proof20
  · exact adaptive146Third139Proof21
  · exact adaptive146Third139Proof45
  · exact adaptive146Third139Proof71
  · exact adaptive146Third139Proof98
  · exact adaptive146Third139Proof126
  · exact adaptive146Third139Proof155
  · exact adaptive146Third139Proof186
  · exact adaptive146Third139Proof218

#print axioms adaptive146Third139Proof0

end NineSeparatedSubsetSums
