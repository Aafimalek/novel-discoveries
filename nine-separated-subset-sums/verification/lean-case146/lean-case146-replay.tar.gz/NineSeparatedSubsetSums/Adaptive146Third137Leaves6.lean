import NineSeparatedSubsetSums.Adaptive146Third137State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third137Proof16 : runCachedNode 511 130354 Adaptive146Third137Node16 = false := by
  decide +kernel

#print axioms adaptive146Third137Proof16

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third137Proof121 : runCachedNode 511 130354 Adaptive146Third137Node121 = false := by
  decide +kernel

#print axioms adaptive146Third137Proof121

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third137Proof94 : runCachedNode 511 130354 Adaptive146Third137Node94 = false := by
  decide +kernel

#print axioms adaptive146Third137Proof94

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third137Proof69 : runCachedNode 511 130354 Adaptive146Third137Node69 = false := by
  decide +kernel

#print axioms adaptive146Third137Proof69

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third137Proof133 : runCachedNode 511 130354 Adaptive146Third137Node133 = false := by
  decide +kernel

#print axioms adaptive146Third137Proof133

end NineSeparatedSubsetSums
