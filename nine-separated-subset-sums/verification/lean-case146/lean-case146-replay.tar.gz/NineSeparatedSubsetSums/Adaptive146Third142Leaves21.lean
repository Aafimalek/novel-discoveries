import NineSeparatedSubsetSums.Adaptive146Third142State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third142Proof176 : runCachedNode 511 131054 Adaptive146Third142Node176 = false := by
  decide +kernel

#print axioms adaptive146Third142Proof176

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third142Proof83 : runCachedNode 511 131054 Adaptive146Third142Node83 = false := by
  decide +kernel

#print axioms adaptive146Third142Proof83

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third142Proof111 : runCachedNode 511 131054 Adaptive146Third142Node111 = false := by
  decide +kernel

#print axioms adaptive146Third142Proof111

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third142Proof397 : runCachedNode 511 131054 Adaptive146Third142Node397 = false := by
  decide +kernel

#print axioms adaptive146Third142Proof397

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third142Proof170 : runCachedNode 511 131054 Adaptive146Third142Node170 = false := by
  decide +kernel

#print axioms adaptive146Third142Proof170

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third142Proof255 : runCachedNode 511 131054 Adaptive146Third142Node255 = false := by
  decide +kernel

#print axioms adaptive146Third142Proof255

end NineSeparatedSubsetSums
