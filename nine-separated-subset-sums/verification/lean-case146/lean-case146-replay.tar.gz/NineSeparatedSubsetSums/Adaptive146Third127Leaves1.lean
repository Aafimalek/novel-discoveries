import NineSeparatedSubsetSums.Adaptive146Third127State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third127Proof11 : runCachedNode 511 128361 Adaptive146Third127Node11 = false := by
  decide +kernel

#print axioms adaptive146Third127Proof11

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third127Proof10 : runCachedNode 511 128361 Adaptive146Third127Node10 = false := by
  decide +kernel

#print axioms adaptive146Third127Proof10

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third127Proof9 : runCachedNode 511 128361 Adaptive146Third127Node9 = false := by
  decide +kernel

#print axioms adaptive146Third127Proof9

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third127Proof8 : runCachedNode 511 128361 Adaptive146Third127Node8 = false := by
  decide +kernel

#print axioms adaptive146Third127Proof8

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third127Proof6 : runCachedNode 511 128361 Adaptive146Third127Node6 = false := by
  decide +kernel

#print axioms adaptive146Third127Proof6

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third127Proof5 : runCachedNode 511 128361 Adaptive146Third127Node5 = false := by
  decide +kernel

#print axioms adaptive146Third127Proof5

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third127Proof3 : runCachedNode 511 128361 Adaptive146Third127Node3 = false := by
  decide +kernel

#print axioms adaptive146Third127Proof3

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third127Proof1 : runCachedNode 511 128361 Adaptive146Third127Node1 = false := by
  decide +kernel

#print axioms adaptive146Third127Proof1

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third127Proof2 : runCachedNode 511 128361 Adaptive146Third127Node2 = false := by
  decide +kernel

#print axioms adaptive146Third127Proof2

end NineSeparatedSubsetSums
