import NineSeparatedSubsetSums.Adaptive146Third142State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third142Proof247 : runCachedNode 511 131054 Adaptive146Third142Node247 = false := by
  decide +kernel

#print axioms adaptive146Third142Proof247

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third142Proof241 : runCachedNode 511 131054 Adaptive146Third142Node241 = false := by
  decide +kernel

#print axioms adaptive146Third142Proof241

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third142Proof30 : runCachedNode 511 131054 Adaptive146Third142Node30 = false := by
  decide +kernel

#print axioms adaptive146Third142Proof30

end NineSeparatedSubsetSums
