import NineSeparatedSubsetSums.Adaptive146Third135State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third135Proof46 : runCachedNode 511 130049 Adaptive146Third135Node46 = false := by
  decide +kernel

#print axioms adaptive146Third135Proof46

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third135Proof95 : runCachedNode 511 130049 Adaptive146Third135Node95 = false := by
  decide +kernel

#print axioms adaptive146Third135Proof95

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third135Proof41 : runCachedNode 511 130049 Adaptive146Third135Node41 = false := by
  decide +kernel

#print axioms adaptive146Third135Proof41

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third135Proof92 : runCachedNode 511 130049 Adaptive146Third135Node92 = false := by
  decide +kernel

#print axioms adaptive146Third135Proof92

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third135Proof12 : runCachedNode 511 130049 Adaptive146Third135Node12 = false := by
  decide +kernel

#print axioms adaptive146Third135Proof12

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third135Proof42 : runCachedNode 511 130049 Adaptive146Third135Node42 = false := by
  decide +kernel

#print axioms adaptive146Third135Proof42

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third135Proof45 : runCachedNode 511 130049 Adaptive146Third135Node45 = false := by
  decide +kernel

#print axioms adaptive146Third135Proof45

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third135Proof94 : runCachedNode 511 130049 Adaptive146Third135Node94 = false := by
  decide +kernel

#print axioms adaptive146Third135Proof94

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third135Proof62 : runCachedNode 511 130049 Adaptive146Third135Node62 = false := by
  decide +kernel

#print axioms adaptive146Third135Proof62

end NineSeparatedSubsetSums
