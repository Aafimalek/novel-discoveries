import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive146Third124Node0 : CachedSearchNode :=
  ⟨4, 123, computeCenteredMask [148,146,124], 418, 58596⟩

end NineSeparatedSubsetSums
