import NineSeparatedSubsetSums.Adaptive146Third144State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third144Proof188 : runCachedNode 511 131319 Adaptive146Third144Node188 = false := by
  decide +kernel

#print axioms adaptive146Third144Proof188

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third144Proof380 : runCachedNode 511 131319 Adaptive146Third144Node380 = false := by
  decide +kernel

#print axioms adaptive146Third144Proof380

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third144Proof20 : runCachedNode 511 131319 Adaptive146Third144Node20 = false := by
  decide +kernel

#print axioms adaptive146Third144Proof20

end NineSeparatedSubsetSums
