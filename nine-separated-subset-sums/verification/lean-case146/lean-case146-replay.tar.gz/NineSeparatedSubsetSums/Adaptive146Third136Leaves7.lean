import NineSeparatedSubsetSums.Adaptive146Third136State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third136Proof127 : runCachedNode 511 130191 Adaptive146Third136Node127 = false := by
  decide +kernel

#print axioms adaptive146Third136Proof127

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third136Proof43 : runCachedNode 511 130191 Adaptive146Third136Node43 = false := by
  decide +kernel

#print axioms adaptive146Third136Proof43

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third136Proof123 : runCachedNode 511 130191 Adaptive146Third136Node123 = false := by
  decide +kernel

#print axioms adaptive146Third136Proof123

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third136Proof99 : runCachedNode 511 130191 Adaptive146Third136Node99 = false := by
  decide +kernel

#print axioms adaptive146Third136Proof99

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third136Proof40 : runCachedNode 511 130191 Adaptive146Third136Node40 = false := by
  decide +kernel

#print axioms adaptive146Third136Proof40

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third136Proof51 : runCachedNode 511 130191 Adaptive146Third136Node51 = false := by
  decide +kernel

#print axioms adaptive146Third136Proof51

end NineSeparatedSubsetSums
