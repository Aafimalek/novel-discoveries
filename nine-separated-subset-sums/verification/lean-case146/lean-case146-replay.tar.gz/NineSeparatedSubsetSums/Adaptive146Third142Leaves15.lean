import NineSeparatedSubsetSums.Adaptive146Third142State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third142Proof210 : runCachedNode 511 131054 Adaptive146Third142Node210 = false := by
  decide +kernel

#print axioms adaptive146Third142Proof210

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third142Proof18 : runCachedNode 511 131054 Adaptive146Third142Node18 = false := by
  decide +kernel

#print axioms adaptive146Third142Proof18

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third142Proof287 : runCachedNode 511 131054 Adaptive146Third142Node287 = false := by
  decide +kernel

#print axioms adaptive146Third142Proof287

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third142Proof2 : runCachedNode 511 131054 Adaptive146Third142Node2 = false := by
  decide +kernel

#print axioms adaptive146Third142Proof2

end NineSeparatedSubsetSums
