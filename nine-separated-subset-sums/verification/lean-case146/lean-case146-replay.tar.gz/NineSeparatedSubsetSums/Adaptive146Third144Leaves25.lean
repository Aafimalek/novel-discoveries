import NineSeparatedSubsetSums.Adaptive146Third144State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third144Proof281 : runCachedNode 511 131319 Adaptive146Third144Node281 = false := by
  decide +kernel

#print axioms adaptive146Third144Proof281

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third144Proof709 : runCachedNode 511 131319 Adaptive146Third144Node709 = false := by
  decide +kernel

#print axioms adaptive146Third144Proof709

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third144Proof496 : runCachedNode 511 131319 Adaptive146Third144Node496 = false := by
  decide +kernel

#print axioms adaptive146Third144Proof496

end NineSeparatedSubsetSums
