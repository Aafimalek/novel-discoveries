import NineSeparatedSubsetSums.Adaptive146Third133State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third133Proof21 : runCachedNode 511 129683 Adaptive146Third133Node21 = false := by
  decide +kernel

#print axioms adaptive146Third133Proof21

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third133Proof46 : runCachedNode 511 129683 Adaptive146Third133Node46 = false := by
  decide +kernel

#print axioms adaptive146Third133Proof46

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third133Proof5 : runCachedNode 511 129683 Adaptive146Third133Node5 = false := by
  decide +kernel

#print axioms adaptive146Third133Proof5

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third133Proof27 : runCachedNode 511 129683 Adaptive146Third133Node27 = false := by
  decide +kernel

#print axioms adaptive146Third133Proof27

end NineSeparatedSubsetSums
