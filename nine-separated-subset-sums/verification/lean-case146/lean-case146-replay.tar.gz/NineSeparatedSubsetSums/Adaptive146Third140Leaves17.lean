import NineSeparatedSubsetSums.Adaptive146Third140State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third140Proof153 : runCachedNode 511 130775 Adaptive146Third140Node153 = false := by
  decide +kernel

#print axioms adaptive146Third140Proof153

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third140Proof381 : runCachedNode 511 130775 Adaptive146Third140Node381 = false := by
  decide +kernel

#print axioms adaptive146Third140Proof381

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third140Proof350 : runCachedNode 511 130775 Adaptive146Third140Node350 = false := by
  decide +kernel

#print axioms adaptive146Third140Proof350

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third140Proof179 : runCachedNode 511 130775 Adaptive146Third140Node179 = false := by
  decide +kernel

#print axioms adaptive146Third140Proof179

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third140Proof277 : runCachedNode 511 130775 Adaptive146Third140Node277 = false := by
  decide +kernel

#print axioms adaptive146Third140Proof277

end NineSeparatedSubsetSums
