import NineSeparatedSubsetSums.Adaptive146Third140State
import NineSeparatedSubsetSums.Adaptive146Third140Leaves34
import NineSeparatedSubsetSums.Adaptive146Third140Leaves33
import NineSeparatedSubsetSums.Adaptive146Third140Leaves32
import NineSeparatedSubsetSums.Adaptive146Third140Leaves31
import NineSeparatedSubsetSums.Adaptive146Third140Leaves30
import NineSeparatedSubsetSums.Adaptive146Third140Leaves29
import NineSeparatedSubsetSums.Adaptive146Third140Leaves28
import NineSeparatedSubsetSums.Adaptive146Third140Leaves26
import NineSeparatedSubsetSums.Adaptive146Third140Leaves16
import NineSeparatedSubsetSums.Adaptive146Third140Leaves23
import NineSeparatedSubsetSums.Adaptive146Third140Leaves24
import NineSeparatedSubsetSums.Adaptive146Third140Leaves19
import NineSeparatedSubsetSums.Adaptive146Third140Leaves12
import NineSeparatedSubsetSums.Adaptive146Third140Leaves10
import NineSeparatedSubsetSums.Adaptive146Third140Leaves18
import NineSeparatedSubsetSums.Adaptive146Third140Joins0
import NineSeparatedSubsetSums.Adaptive146Third140Leaves14
import NineSeparatedSubsetSums.Adaptive146Third140Leaves6
import NineSeparatedSubsetSums.Adaptive146Third140Leaves22
import NineSeparatedSubsetSums.Adaptive146Third140Leaves27
import NineSeparatedSubsetSums.Adaptive146Third140Leaves25
import NineSeparatedSubsetSums.Adaptive146Third140Leaves21
import NineSeparatedSubsetSums.Adaptive146Third140Leaves17
import NineSeparatedSubsetSums.Adaptive146Third140Leaves4
import NineSeparatedSubsetSums.Adaptive146Third140Leaves9
import NineSeparatedSubsetSums.Adaptive146Third140Leaves0
import NineSeparatedSubsetSums.Adaptive146Third140Leaves1
import NineSeparatedSubsetSums.Adaptive146Third140Leaves8
import NineSeparatedSubsetSums.Adaptive146Third140Leaves3
import NineSeparatedSubsetSums.Adaptive146Third140Leaves20
import NineSeparatedSubsetSums.Adaptive146Third140Leaves11
import NineSeparatedSubsetSums.Adaptive146Third140Leaves2
import NineSeparatedSubsetSums.Adaptive146Third140Leaves13
import NineSeparatedSubsetSums.Adaptive146Third140Leaves5
import NineSeparatedSubsetSums.Adaptive146Third140Leaves15
import NineSeparatedSubsetSums.Adaptive146Third140Leaves7

namespace NineSeparatedSubsetSums

theorem adaptive146Third140Proof218 : runCachedNode 511 130775 Adaptive146Third140Node218 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130775 Adaptive146Third140Node218 = [102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 129, 131, 132, 133, 135] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive146Third140Proof219
  · exact adaptive146Third140Proof220
  · exact adaptive146Third140Proof221
  · exact adaptive146Third140Proof222
  · exact adaptive146Third140Proof223
  · exact adaptive146Third140Proof224
  · exact adaptive146Third140Proof225
  · exact adaptive146Third140Proof226
  · exact adaptive146Third140Proof227
  · exact adaptive146Third140Proof228
  · exact adaptive146Third140Proof229
  · exact adaptive146Third140Proof230
  · exact adaptive146Third140Proof231
  · exact adaptive146Third140Proof232
  · exact adaptive146Third140Proof233
  · exact adaptive146Third140Proof234
  · exact adaptive146Third140Proof235
  · exact adaptive146Third140Proof236
  · exact adaptive146Third140Proof237
  · exact adaptive146Third140Proof238
  · exact adaptive146Third140Proof239
  · exact adaptive146Third140Proof240
  · exact adaptive146Third140Proof241
  · exact adaptive146Third140Proof242
  · exact adaptive146Third140Proof243
  · exact adaptive146Third140Proof244
  · exact adaptive146Third140Proof245
  · exact adaptive146Third140Proof246
  · exact adaptive146Third140Proof247
  · exact adaptive146Third140Proof282
  · exact adaptive146Third140Proof283

#print axioms adaptive146Third140Proof218

theorem adaptive146Third140Proof315 : runCachedNode 511 130775 Adaptive146Third140Node315 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130775 Adaptive146Third140Node315 = [90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 118, 119, 120, 121, 122, 124, 127, 130] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive146Third140Proof316
  · exact adaptive146Third140Proof317
  · exact adaptive146Third140Proof318
  · exact adaptive146Third140Proof319
  · exact adaptive146Third140Proof320
  · exact adaptive146Third140Proof321
  · exact adaptive146Third140Proof322
  · exact adaptive146Third140Proof323
  · exact adaptive146Third140Proof324
  · exact adaptive146Third140Proof325
  · exact adaptive146Third140Proof326
  · exact adaptive146Third140Proof327
  · exact adaptive146Third140Proof328
  · exact adaptive146Third140Proof329
  · exact adaptive146Third140Proof330
  · exact adaptive146Third140Proof331
  · exact adaptive146Third140Proof332
  · exact adaptive146Third140Proof333
  · exact adaptive146Third140Proof334
  · exact adaptive146Third140Proof335
  · exact adaptive146Third140Proof336
  · exact adaptive146Third140Proof337
  · exact adaptive146Third140Proof338
  · exact adaptive146Third140Proof339
  · exact adaptive146Third140Proof340
  · exact adaptive146Third140Proof341
  · exact adaptive146Third140Proof342
  · exact adaptive146Third140Proof343
  · exact adaptive146Third140Proof344
  · exact adaptive146Third140Proof345
  · exact adaptive146Third140Proof346
  · exact adaptive146Third140Proof347
  · exact adaptive146Third140Proof348
  · exact adaptive146Third140Proof349
  · exact adaptive146Third140Proof350

#print axioms adaptive146Third140Proof315

theorem adaptive146Third140Proof284 : runCachedNode 511 130775 Adaptive146Third140Node284 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130775 Adaptive146Third140Node284 = [102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 130, 132, 133, 134, 136] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive146Third140Proof285
  · exact adaptive146Third140Proof286
  · exact adaptive146Third140Proof287
  · exact adaptive146Third140Proof288
  · exact adaptive146Third140Proof289
  · exact adaptive146Third140Proof290
  · exact adaptive146Third140Proof291
  · exact adaptive146Third140Proof292
  · exact adaptive146Third140Proof293
  · exact adaptive146Third140Proof294
  · exact adaptive146Third140Proof295
  · exact adaptive146Third140Proof296
  · exact adaptive146Third140Proof297
  · exact adaptive146Third140Proof298
  · exact adaptive146Third140Proof299
  · exact adaptive146Third140Proof300
  · exact adaptive146Third140Proof301
  · exact adaptive146Third140Proof302
  · exact adaptive146Third140Proof303
  · exact adaptive146Third140Proof304
  · exact adaptive146Third140Proof305
  · exact adaptive146Third140Proof306
  · exact adaptive146Third140Proof307
  · exact adaptive146Third140Proof308
  · exact adaptive146Third140Proof309
  · exact adaptive146Third140Proof310
  · exact adaptive146Third140Proof311
  · exact adaptive146Third140Proof312
  · exact adaptive146Third140Proof313
  · exact adaptive146Third140Proof314
  · exact adaptive146Third140Proof315
  · exact adaptive146Third140Proof351

#print axioms adaptive146Third140Proof284

theorem adaptive146Third140Proof352 : runCachedNode 511 130775 Adaptive146Third140Node352 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130775 Adaptive146Third140Node352 = [101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 132, 134, 135, 136] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive146Third140Proof353
  · exact adaptive146Third140Proof354
  · exact adaptive146Third140Proof355
  · exact adaptive146Third140Proof356
  · exact adaptive146Third140Proof357
  · exact adaptive146Third140Proof358
  · exact adaptive146Third140Proof359
  · exact adaptive146Third140Proof360
  · exact adaptive146Third140Proof361
  · exact adaptive146Third140Proof362
  · exact adaptive146Third140Proof363
  · exact adaptive146Third140Proof364
  · exact adaptive146Third140Proof365
  · exact adaptive146Third140Proof366
  · exact adaptive146Third140Proof367
  · exact adaptive146Third140Proof368
  · exact adaptive146Third140Proof369
  · exact adaptive146Third140Proof370
  · exact adaptive146Third140Proof371
  · exact adaptive146Third140Proof372
  · exact adaptive146Third140Proof373
  · exact adaptive146Third140Proof374
  · exact adaptive146Third140Proof375
  · exact adaptive146Third140Proof376
  · exact adaptive146Third140Proof377
  · exact adaptive146Third140Proof378
  · exact adaptive146Third140Proof379
  · exact adaptive146Third140Proof380
  · exact adaptive146Third140Proof381
  · exact adaptive146Third140Proof382
  · exact adaptive146Third140Proof383
  · exact adaptive146Third140Proof384
  · exact adaptive146Third140Proof385
  · exact adaptive146Third140Proof386

#print axioms adaptive146Third140Proof352

theorem adaptive146Third140Proof0 : runCachedNode 511 130775 Adaptive146Third140Node0 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130775 Adaptive146Third140Node0 = [109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 132, 133, 134, 135, 136, 137, 139] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive146Third140Proof1
  · exact adaptive146Third140Proof2
  · exact adaptive146Third140Proof3
  · exact adaptive146Third140Proof4
  · exact adaptive146Third140Proof5
  · exact adaptive146Third140Proof6
  · exact adaptive146Third140Proof7
  · exact adaptive146Third140Proof8
  · exact adaptive146Third140Proof9
  · exact adaptive146Third140Proof10
  · exact adaptive146Third140Proof11
  · exact adaptive146Third140Proof12
  · exact adaptive146Third140Proof13
  · exact adaptive146Third140Proof14
  · exact adaptive146Third140Proof15
  · exact adaptive146Third140Proof16
  · exact adaptive146Third140Proof17
  · exact adaptive146Third140Proof18
  · exact adaptive146Third140Proof19
  · exact adaptive146Third140Proof20
  · exact adaptive146Third140Proof21
  · exact adaptive146Third140Proof22
  · exact adaptive146Third140Proof46
  · exact adaptive146Third140Proof72
  · exact adaptive146Third140Proof99
  · exact adaptive146Third140Proof127
  · exact adaptive146Third140Proof187
  · exact adaptive146Third140Proof218
  · exact adaptive146Third140Proof284
  · exact adaptive146Third140Proof352

#print axioms adaptive146Third140Proof0

end NineSeparatedSubsetSums
