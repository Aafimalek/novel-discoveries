import NineSeparatedSubsetSums.Adaptive146Third141State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third141Proof234 : runCachedNode 511 130916 Adaptive146Third141Node234 = false := by
  decide +kernel

#print axioms adaptive146Third141Proof234

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third141Proof102 : runCachedNode 511 130916 Adaptive146Third141Node102 = false := by
  decide +kernel

#print axioms adaptive146Third141Proof102

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third141Proof100 : runCachedNode 511 130916 Adaptive146Third141Node100 = false := by
  decide +kernel

#print axioms adaptive146Third141Proof100

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third141Proof104 : runCachedNode 511 130916 Adaptive146Third141Node104 = false := by
  decide +kernel

#print axioms adaptive146Third141Proof104

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third141Proof231 : runCachedNode 511 130916 Adaptive146Third141Node231 = false := by
  decide +kernel

#print axioms adaptive146Third141Proof231

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third141Proof25 : runCachedNode 511 130916 Adaptive146Third141Node25 = false := by
  decide +kernel

#print axioms adaptive146Third141Proof25

end NineSeparatedSubsetSums
