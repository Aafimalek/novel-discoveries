import NineSeparatedSubsetSums.Adaptive146Third109Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint146Checked

namespace NineSeparatedSubsetSums


theorem adaptive146Third109 : NoDescendingTailAfterThird 146 109 :=
  noDescendingThirdTail_of_cached 146 109 112631 (fun t ht nd => max148_second146_fourPoint_moment_bound (109::t) (by simp [ht]) nd) adaptive146Third109Proof0

#print axioms adaptive146Third109

end NineSeparatedSubsetSums
