import NineSeparatedSubsetSums.Adaptive146Third144State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third144Proof1114 : runCachedNode 511 131319 Adaptive146Third144Node1114 = false := by
  decide +kernel

#print axioms adaptive146Third144Proof1114

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third144Proof634 : runCachedNode 511 131319 Adaptive146Third144Node634 = false := by
  decide +kernel

#print axioms adaptive146Third144Proof634

end NineSeparatedSubsetSums
