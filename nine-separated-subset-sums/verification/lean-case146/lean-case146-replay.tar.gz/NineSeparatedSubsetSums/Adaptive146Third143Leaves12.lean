import NineSeparatedSubsetSums.Adaptive146Third143State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third143Proof231 : runCachedNode 511 131193 Adaptive146Third143Node231 = false := by
  decide +kernel

#print axioms adaptive146Third143Proof231

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third143Proof415 : runCachedNode 511 131193 Adaptive146Third143Node415 = false := by
  decide +kernel

#print axioms adaptive146Third143Proof415

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third143Proof120 : runCachedNode 511 131193 Adaptive146Third143Node120 = false := by
  decide +kernel

#print axioms adaptive146Third143Proof120

end NineSeparatedSubsetSums
