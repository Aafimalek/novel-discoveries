import NineSeparatedSubsetSums.Adaptive146Third144State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third144Proof1253 : runCachedNode 511 131319 Adaptive146Third144Node1253 = false := by
  decide +kernel

#print axioms adaptive146Third144Proof1253

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third144Proof711 : runCachedNode 511 131319 Adaptive146Third144Node711 = false := by
  decide +kernel

#print axioms adaptive146Third144Proof711

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third144Proof19 : runCachedNode 511 131319 Adaptive146Third144Node19 = false := by
  decide +kernel

#print axioms adaptive146Third144Proof19

end NineSeparatedSubsetSums
