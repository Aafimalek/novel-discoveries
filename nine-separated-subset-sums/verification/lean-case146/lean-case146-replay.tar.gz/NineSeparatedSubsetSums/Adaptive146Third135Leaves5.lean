import NineSeparatedSubsetSums.Adaptive146Third135State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third135Proof98 : runCachedNode 511 130049 Adaptive146Third135Node98 = false := by
  decide +kernel

#print axioms adaptive146Third135Proof98

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third135Proof71 : runCachedNode 511 130049 Adaptive146Third135Node71 = false := by
  decide +kernel

#print axioms adaptive146Third135Proof71

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third135Proof13 : runCachedNode 511 130049 Adaptive146Third135Node13 = false := by
  decide +kernel

#print axioms adaptive146Third135Proof13

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third135Proof44 : runCachedNode 511 130049 Adaptive146Third135Node44 = false := by
  decide +kernel

#print axioms adaptive146Third135Proof44

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third135Proof14 : runCachedNode 511 130049 Adaptive146Third135Node14 = false := by
  decide +kernel

#print axioms adaptive146Third135Proof14

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third135Proof56 : runCachedNode 511 130049 Adaptive146Third135Node56 = false := by
  decide +kernel

#print axioms adaptive146Third135Proof56

end NineSeparatedSubsetSums
