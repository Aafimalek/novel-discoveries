import NineSeparatedSubsetSums.Adaptive146Third106State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third106Proof0 : runCachedNode 511 112631 Adaptive146Third106Node0 = false := by
  decide +kernel

#print axioms adaptive146Third106Proof0

end NineSeparatedSubsetSums
