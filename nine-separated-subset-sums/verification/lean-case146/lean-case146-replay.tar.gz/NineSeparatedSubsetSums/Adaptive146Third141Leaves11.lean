import NineSeparatedSubsetSums.Adaptive146Third141State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third141Proof21 : runCachedNode 511 130916 Adaptive146Third141Node21 = false := by
  decide +kernel

#print axioms adaptive146Third141Proof21

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third141Proof167 : runCachedNode 511 130916 Adaptive146Third141Node167 = false := by
  decide +kernel

#print axioms adaptive146Third141Proof167

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third141Proof181 : runCachedNode 511 130916 Adaptive146Third141Node181 = false := by
  decide +kernel

#print axioms adaptive146Third141Proof181

end NineSeparatedSubsetSums
