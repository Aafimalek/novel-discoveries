import NineSeparatedSubsetSums.Adaptive146Third143State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third143Proof416 : runCachedNode 511 131193 Adaptive146Third143Node416 = false := by
  decide +kernel

#print axioms adaptive146Third143Proof416

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third143Proof229 : runCachedNode 511 131193 Adaptive146Third143Node229 = false := by
  decide +kernel

#print axioms adaptive146Third143Proof229

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third143Proof665 : runCachedNode 511 131193 Adaptive146Third143Node665 = false := by
  decide +kernel

#print axioms adaptive146Third143Proof665

end NineSeparatedSubsetSums
