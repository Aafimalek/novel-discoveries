import NineSeparatedSubsetSums.Adaptive146Third118State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third118Proof0 : runCachedNode 511 126216 Adaptive146Third118Node0 = false := by
  decide +kernel

#print axioms adaptive146Third118Proof0

end NineSeparatedSubsetSums
