import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive146Third120Node0 : CachedSearchNode :=
  ⟨4, 119, computeCenteredMask [148,146,120], 414, 57620⟩

end NineSeparatedSubsetSums
