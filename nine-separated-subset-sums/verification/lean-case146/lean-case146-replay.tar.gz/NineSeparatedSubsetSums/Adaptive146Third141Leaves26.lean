import NineSeparatedSubsetSums.Adaptive146Third141State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third141Proof48 : runCachedNode 511 130916 Adaptive146Third141Node48 = false := by
  decide +kernel

#print axioms adaptive146Third141Proof48

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third141Proof266 : runCachedNode 511 130916 Adaptive146Third141Node266 = false := by
  decide +kernel

#print axioms adaptive146Third141Proof266

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third141Proof161 : runCachedNode 511 130916 Adaptive146Third141Node161 = false := by
  decide +kernel

#print axioms adaptive146Third141Proof161

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third141Proof47 : runCachedNode 511 130916 Adaptive146Third141Node47 = false := by
  decide +kernel

#print axioms adaptive146Third141Proof47

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third141Proof13 : runCachedNode 511 130916 Adaptive146Third141Node13 = false := by
  decide +kernel

#print axioms adaptive146Third141Proof13

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third141Proof196 : runCachedNode 511 130916 Adaptive146Third141Node196 = false := by
  decide +kernel

#print axioms adaptive146Third141Proof196

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third141Proof312 : runCachedNode 511 130916 Adaptive146Third141Node312 = false := by
  decide +kernel

#print axioms adaptive146Third141Proof312

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third141Proof178 : runCachedNode 511 130916 Adaptive146Third141Node178 = false := by
  decide +kernel

#print axioms adaptive146Third141Proof178

end NineSeparatedSubsetSums
