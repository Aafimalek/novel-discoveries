import NineSeparatedSubsetSums.Adaptive146Third138State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third138Proof205 : runCachedNode 511 130484 Adaptive146Third138Node205 = false := by
  decide +kernel

#print axioms adaptive146Third138Proof205

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third138Proof146 : runCachedNode 511 130484 Adaptive146Third138Node146 = false := by
  decide +kernel

#print axioms adaptive146Third138Proof146

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third138Proof206 : runCachedNode 511 130484 Adaptive146Third138Node206 = false := by
  decide +kernel

#print axioms adaptive146Third138Proof206

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third138Proof88 : runCachedNode 511 130484 Adaptive146Third138Node88 = false := by
  decide +kernel

#print axioms adaptive146Third138Proof88

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third138Proof90 : runCachedNode 511 130484 Adaptive146Third138Node90 = false := by
  decide +kernel

#print axioms adaptive146Third138Proof90

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third138Proof64 : runCachedNode 511 130484 Adaptive146Third138Node64 = false := by
  decide +kernel

#print axioms adaptive146Third138Proof64

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third138Proof143 : runCachedNode 511 130484 Adaptive146Third138Node143 = false := by
  decide +kernel

#print axioms adaptive146Third138Proof143

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third138Proof203 : runCachedNode 511 130484 Adaptive146Third138Node203 = false := by
  decide +kernel

#print axioms adaptive146Third138Proof203

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third138Proof9 : runCachedNode 511 130484 Adaptive146Third138Node9 = false := by
  decide +kernel

#print axioms adaptive146Third138Proof9

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third138Proof37 : runCachedNode 511 130484 Adaptive146Third138Node37 = false := by
  decide +kernel

#print axioms adaptive146Third138Proof37

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third138Proof204 : runCachedNode 511 130484 Adaptive146Third138Node204 = false := by
  decide +kernel

#print axioms adaptive146Third138Proof204

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third138Proof91 : runCachedNode 511 130484 Adaptive146Third138Node91 = false := by
  decide +kernel

#print axioms adaptive146Third138Proof91

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third138Proof118 : runCachedNode 511 130484 Adaptive146Third138Node118 = false := by
  decide +kernel

#print axioms adaptive146Third138Proof118

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third138Proof63 : runCachedNode 511 130484 Adaptive146Third138Node63 = false := by
  decide +kernel

#print axioms adaptive146Third138Proof63

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third138Proof117 : runCachedNode 511 130484 Adaptive146Third138Node117 = false := by
  decide +kernel

#print axioms adaptive146Third138Proof117

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third138Proof144 : runCachedNode 511 130484 Adaptive146Third138Node144 = false := by
  decide +kernel

#print axioms adaptive146Third138Proof144

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third138Proof89 : runCachedNode 511 130484 Adaptive146Third138Node89 = false := by
  decide +kernel

#print axioms adaptive146Third138Proof89

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third138Proof34 : runCachedNode 511 130484 Adaptive146Third138Node34 = false := by
  decide +kernel

#print axioms adaptive146Third138Proof34

end NineSeparatedSubsetSums
