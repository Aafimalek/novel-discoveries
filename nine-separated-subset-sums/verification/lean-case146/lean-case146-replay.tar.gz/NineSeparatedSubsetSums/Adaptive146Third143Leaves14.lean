import NineSeparatedSubsetSums.Adaptive146Third143State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third143Proof19 : runCachedNode 511 131193 Adaptive146Third143Node19 = false := by
  decide +kernel

#print axioms adaptive146Third143Proof19

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third143Proof194 : runCachedNode 511 131193 Adaptive146Third143Node194 = false := by
  decide +kernel

#print axioms adaptive146Third143Proof194

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third143Proof110 : runCachedNode 511 131193 Adaptive146Third143Node110 = false := by
  decide +kernel

#print axioms adaptive146Third143Proof110

end NineSeparatedSubsetSums
