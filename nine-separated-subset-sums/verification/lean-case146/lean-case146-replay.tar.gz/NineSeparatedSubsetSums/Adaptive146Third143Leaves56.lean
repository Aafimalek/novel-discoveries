import NineSeparatedSubsetSums.Adaptive146Third143State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third143Proof632 : runCachedNode 511 131193 Adaptive146Third143Node632 = false := by
  decide +kernel

#print axioms adaptive146Third143Proof632

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third143Proof633 : runCachedNode 511 131193 Adaptive146Third143Node633 = false := by
  decide +kernel

#print axioms adaptive146Third143Proof633

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third143Proof634 : runCachedNode 511 131193 Adaptive146Third143Node634 = false := by
  decide +kernel

#print axioms adaptive146Third143Proof634

end NineSeparatedSubsetSums
