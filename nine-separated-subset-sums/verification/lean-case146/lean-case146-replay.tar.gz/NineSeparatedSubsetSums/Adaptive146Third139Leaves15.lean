import NineSeparatedSubsetSums.Adaptive146Third139State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third139Proof178 : runCachedNode 511 130638 Adaptive146Third139Node178 = false := by
  decide +kernel

#print axioms adaptive146Third139Proof178

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third139Proof181 : runCachedNode 511 130638 Adaptive146Third139Node181 = false := by
  decide +kernel

#print axioms adaptive146Third139Proof181

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third139Proof180 : runCachedNode 511 130638 Adaptive146Third139Node180 = false := by
  decide +kernel

#print axioms adaptive146Third139Proof180

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third139Proof13 : runCachedNode 511 130638 Adaptive146Third139Node13 = false := by
  decide +kernel

#print axioms adaptive146Third139Proof13

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third139Proof42 : runCachedNode 511 130638 Adaptive146Third139Node42 = false := by
  decide +kernel

#print axioms adaptive146Third139Proof42

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third139Proof148 : runCachedNode 511 130638 Adaptive146Third139Node148 = false := by
  decide +kernel

#print axioms adaptive146Third139Proof148

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third139Proof193 : runCachedNode 511 130638 Adaptive146Third139Node193 = false := by
  decide +kernel

#print axioms adaptive146Third139Proof193

end NineSeparatedSubsetSums
