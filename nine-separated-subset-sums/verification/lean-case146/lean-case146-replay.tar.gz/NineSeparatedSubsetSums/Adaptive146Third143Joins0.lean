import NineSeparatedSubsetSums.Adaptive146Third143State
import NineSeparatedSubsetSums.Adaptive146Third143Leaves29
import NineSeparatedSubsetSums.Adaptive146Third143Leaves33
import NineSeparatedSubsetSums.Adaptive146Third143Leaves6
import NineSeparatedSubsetSums.Adaptive146Third143Leaves4
import NineSeparatedSubsetSums.Adaptive146Third143Leaves15
import NineSeparatedSubsetSums.Adaptive146Third143Leaves49
import NineSeparatedSubsetSums.Adaptive146Third143Leaves48
import NineSeparatedSubsetSums.Adaptive146Third143Leaves47
import NineSeparatedSubsetSums.Adaptive146Third143Leaves46
import NineSeparatedSubsetSums.Adaptive146Third143Leaves45
import NineSeparatedSubsetSums.Adaptive146Third143Leaves44
import NineSeparatedSubsetSums.Adaptive146Third143Leaves42
import NineSeparatedSubsetSums.Adaptive146Third143Leaves43
import NineSeparatedSubsetSums.Adaptive146Third143Leaves40
import NineSeparatedSubsetSums.Adaptive146Third143Leaves41
import NineSeparatedSubsetSums.Adaptive146Third143Leaves35
import NineSeparatedSubsetSums.Adaptive146Third143Leaves34
import NineSeparatedSubsetSums.Adaptive146Third143Leaves37
import NineSeparatedSubsetSums.Adaptive146Third143Leaves17
import NineSeparatedSubsetSums.Adaptive146Third143Leaves23
import NineSeparatedSubsetSums.Adaptive146Third143Leaves52
import NineSeparatedSubsetSums.Adaptive146Third143Leaves53
import NineSeparatedSubsetSums.Adaptive146Third143Leaves11
import NineSeparatedSubsetSums.Adaptive146Third143Leaves10
import NineSeparatedSubsetSums.Adaptive146Third143Leaves19
import NineSeparatedSubsetSums.Adaptive146Third143Leaves5
import NineSeparatedSubsetSums.Adaptive146Third143Leaves7
import NineSeparatedSubsetSums.Adaptive146Third143Leaves0
import NineSeparatedSubsetSums.Adaptive146Third143Leaves39
import NineSeparatedSubsetSums.Adaptive146Third143Leaves36
import NineSeparatedSubsetSums.Adaptive146Third143Leaves32
import NineSeparatedSubsetSums.Adaptive146Third143Leaves31
import NineSeparatedSubsetSums.Adaptive146Third143Leaves27
import NineSeparatedSubsetSums.Adaptive146Third143Leaves51
import NineSeparatedSubsetSums.Adaptive146Third143Leaves50
import NineSeparatedSubsetSums.Adaptive146Third143Leaves8
import NineSeparatedSubsetSums.Adaptive146Third143Leaves30
import NineSeparatedSubsetSums.Adaptive146Third143Leaves26
import NineSeparatedSubsetSums.Adaptive146Third143Leaves14
import NineSeparatedSubsetSums.Adaptive146Third143Leaves12
import NineSeparatedSubsetSums.Adaptive146Third143Leaves13
import NineSeparatedSubsetSums.Adaptive146Third143Leaves38
import NineSeparatedSubsetSums.Adaptive146Third143Leaves28
import NineSeparatedSubsetSums.Adaptive146Third143Leaves3
import NineSeparatedSubsetSums.Adaptive146Third143Leaves18
import NineSeparatedSubsetSums.Adaptive146Third143Leaves9
import NineSeparatedSubsetSums.Adaptive146Third143Leaves20
import NineSeparatedSubsetSums.Adaptive146Third143Leaves25
import NineSeparatedSubsetSums.Adaptive146Third143Leaves24
import NineSeparatedSubsetSums.Adaptive146Third143Leaves22
import NineSeparatedSubsetSums.Adaptive146Third143Leaves16
import NineSeparatedSubsetSums.Adaptive146Third143Leaves2
import NineSeparatedSubsetSums.Adaptive146Third143Leaves54

namespace NineSeparatedSubsetSums

theorem adaptive146Third143Proof23 : runCachedNode 511 131193 Adaptive146Third143Node23 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 131193 Adaptive146Third143Node23 = [103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 127, 130] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive146Third143Proof24
  · exact adaptive146Third143Proof25
  · exact adaptive146Third143Proof26
  · exact adaptive146Third143Proof27
  · exact adaptive146Third143Proof28
  · exact adaptive146Third143Proof29
  · exact adaptive146Third143Proof30
  · exact adaptive146Third143Proof31
  · exact adaptive146Third143Proof32
  · exact adaptive146Third143Proof33
  · exact adaptive146Third143Proof34
  · exact adaptive146Third143Proof35
  · exact adaptive146Third143Proof36
  · exact adaptive146Third143Proof37
  · exact adaptive146Third143Proof38
  · exact adaptive146Third143Proof39
  · exact adaptive146Third143Proof40
  · exact adaptive146Third143Proof41
  · exact adaptive146Third143Proof42
  · exact adaptive146Third143Proof43
  · exact adaptive146Third143Proof44
  · exact adaptive146Third143Proof45
  · exact adaptive146Third143Proof46
  · exact adaptive146Third143Proof47
  · exact adaptive146Third143Proof48

#print axioms adaptive146Third143Proof23

theorem adaptive146Third143Proof49 : runCachedNode 511 131193 Adaptive146Third143Node49 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 131193 Adaptive146Third143Node49 = [103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 128, 131] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive146Third143Proof50
  · exact adaptive146Third143Proof51
  · exact adaptive146Third143Proof52
  · exact adaptive146Third143Proof53
  · exact adaptive146Third143Proof54
  · exact adaptive146Third143Proof55
  · exact adaptive146Third143Proof56
  · exact adaptive146Third143Proof57
  · exact adaptive146Third143Proof58
  · exact adaptive146Third143Proof59
  · exact adaptive146Third143Proof60
  · exact adaptive146Third143Proof61
  · exact adaptive146Third143Proof62
  · exact adaptive146Third143Proof63
  · exact adaptive146Third143Proof64
  · exact adaptive146Third143Proof65
  · exact adaptive146Third143Proof66
  · exact adaptive146Third143Proof67
  · exact adaptive146Third143Proof68
  · exact adaptive146Third143Proof69
  · exact adaptive146Third143Proof70
  · exact adaptive146Third143Proof71
  · exact adaptive146Third143Proof72
  · exact adaptive146Third143Proof73
  · exact adaptive146Third143Proof74
  · exact adaptive146Third143Proof75

#print axioms adaptive146Third143Proof49

theorem adaptive146Third143Proof76 : runCachedNode 511 131193 Adaptive146Third143Node76 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 131193 Adaptive146Third143Node76 = [102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 129, 132] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive146Third143Proof77
  · exact adaptive146Third143Proof78
  · exact adaptive146Third143Proof79
  · exact adaptive146Third143Proof80
  · exact adaptive146Third143Proof81
  · exact adaptive146Third143Proof82
  · exact adaptive146Third143Proof83
  · exact adaptive146Third143Proof84
  · exact adaptive146Third143Proof85
  · exact adaptive146Third143Proof86
  · exact adaptive146Third143Proof87
  · exact adaptive146Third143Proof88
  · exact adaptive146Third143Proof89
  · exact adaptive146Third143Proof90
  · exact adaptive146Third143Proof91
  · exact adaptive146Third143Proof92
  · exact adaptive146Third143Proof93
  · exact adaptive146Third143Proof94
  · exact adaptive146Third143Proof95
  · exact adaptive146Third143Proof96
  · exact adaptive146Third143Proof97
  · exact adaptive146Third143Proof98
  · exact adaptive146Third143Proof99
  · exact adaptive146Third143Proof100
  · exact adaptive146Third143Proof101
  · exact adaptive146Third143Proof102
  · exact adaptive146Third143Proof103
  · exact adaptive146Third143Proof104

#print axioms adaptive146Third143Proof76

theorem adaptive146Third143Proof105 : runCachedNode 511 131193 Adaptive146Third143Node105 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 131193 Adaptive146Third143Node105 = [102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 130, 133] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive146Third143Proof106
  · exact adaptive146Third143Proof107
  · exact adaptive146Third143Proof108
  · exact adaptive146Third143Proof109
  · exact adaptive146Third143Proof110
  · exact adaptive146Third143Proof111
  · exact adaptive146Third143Proof112
  · exact adaptive146Third143Proof113
  · exact adaptive146Third143Proof114
  · exact adaptive146Third143Proof115
  · exact adaptive146Third143Proof116
  · exact adaptive146Third143Proof117
  · exact adaptive146Third143Proof118
  · exact adaptive146Third143Proof119
  · exact adaptive146Third143Proof120
  · exact adaptive146Third143Proof121
  · exact adaptive146Third143Proof122
  · exact adaptive146Third143Proof123
  · exact adaptive146Third143Proof124
  · exact adaptive146Third143Proof125
  · exact adaptive146Third143Proof126
  · exact adaptive146Third143Proof127
  · exact adaptive146Third143Proof128
  · exact adaptive146Third143Proof129
  · exact adaptive146Third143Proof130
  · exact adaptive146Third143Proof131
  · exact adaptive146Third143Proof132
  · exact adaptive146Third143Proof133
  · exact adaptive146Third143Proof134

#print axioms adaptive146Third143Proof105

theorem adaptive146Third143Proof135 : runCachedNode 511 131193 Adaptive146Third143Node135 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 131193 Adaptive146Third143Node135 = [102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 131, 134] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive146Third143Proof136
  · exact adaptive146Third143Proof137
  · exact adaptive146Third143Proof138
  · exact adaptive146Third143Proof139
  · exact adaptive146Third143Proof140
  · exact adaptive146Third143Proof141
  · exact adaptive146Third143Proof142
  · exact adaptive146Third143Proof143
  · exact adaptive146Third143Proof144
  · exact adaptive146Third143Proof145
  · exact adaptive146Third143Proof146
  · exact adaptive146Third143Proof147
  · exact adaptive146Third143Proof148
  · exact adaptive146Third143Proof149
  · exact adaptive146Third143Proof150
  · exact adaptive146Third143Proof151
  · exact adaptive146Third143Proof152
  · exact adaptive146Third143Proof153
  · exact adaptive146Third143Proof154
  · exact adaptive146Third143Proof155
  · exact adaptive146Third143Proof156
  · exact adaptive146Third143Proof157
  · exact adaptive146Third143Proof158
  · exact adaptive146Third143Proof159
  · exact adaptive146Third143Proof160
  · exact adaptive146Third143Proof161
  · exact adaptive146Third143Proof162
  · exact adaptive146Third143Proof163
  · exact adaptive146Third143Proof164
  · exact adaptive146Third143Proof165

#print axioms adaptive146Third143Proof135

theorem adaptive146Third143Proof166 : runCachedNode 511 131193 Adaptive146Third143Node166 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 131193 Adaptive146Third143Node166 = [102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 132, 135] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive146Third143Proof167
  · exact adaptive146Third143Proof168
  · exact adaptive146Third143Proof169
  · exact adaptive146Third143Proof170
  · exact adaptive146Third143Proof171
  · exact adaptive146Third143Proof172
  · exact adaptive146Third143Proof173
  · exact adaptive146Third143Proof174
  · exact adaptive146Third143Proof175
  · exact adaptive146Third143Proof176
  · exact adaptive146Third143Proof177
  · exact adaptive146Third143Proof178
  · exact adaptive146Third143Proof179
  · exact adaptive146Third143Proof180
  · exact adaptive146Third143Proof181
  · exact adaptive146Third143Proof182
  · exact adaptive146Third143Proof183
  · exact adaptive146Third143Proof184
  · exact adaptive146Third143Proof185
  · exact adaptive146Third143Proof186
  · exact adaptive146Third143Proof187
  · exact adaptive146Third143Proof188
  · exact adaptive146Third143Proof189
  · exact adaptive146Third143Proof190
  · exact adaptive146Third143Proof191
  · exact adaptive146Third143Proof192
  · exact adaptive146Third143Proof193
  · exact adaptive146Third143Proof194
  · exact adaptive146Third143Proof195
  · exact adaptive146Third143Proof196
  · exact adaptive146Third143Proof197

#print axioms adaptive146Third143Proof166

theorem adaptive146Third143Proof198 : runCachedNode 511 131193 Adaptive146Third143Node198 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 131193 Adaptive146Third143Node198 = [101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 133, 136] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive146Third143Proof199
  · exact adaptive146Third143Proof200
  · exact adaptive146Third143Proof201
  · exact adaptive146Third143Proof202
  · exact adaptive146Third143Proof203
  · exact adaptive146Third143Proof204
  · exact adaptive146Third143Proof205
  · exact adaptive146Third143Proof206
  · exact adaptive146Third143Proof207
  · exact adaptive146Third143Proof208
  · exact adaptive146Third143Proof209
  · exact adaptive146Third143Proof210
  · exact adaptive146Third143Proof211
  · exact adaptive146Third143Proof212
  · exact adaptive146Third143Proof213
  · exact adaptive146Third143Proof214
  · exact adaptive146Third143Proof215
  · exact adaptive146Third143Proof216
  · exact adaptive146Third143Proof217
  · exact adaptive146Third143Proof218
  · exact adaptive146Third143Proof219
  · exact adaptive146Third143Proof220
  · exact adaptive146Third143Proof221
  · exact adaptive146Third143Proof222
  · exact adaptive146Third143Proof223
  · exact adaptive146Third143Proof224
  · exact adaptive146Third143Proof225
  · exact adaptive146Third143Proof226
  · exact adaptive146Third143Proof227
  · exact adaptive146Third143Proof228
  · exact adaptive146Third143Proof229
  · exact adaptive146Third143Proof230
  · exact adaptive146Third143Proof231

#print axioms adaptive146Third143Proof198

theorem adaptive146Third143Proof266 : runCachedNode 511 131193 Adaptive146Third143Node266 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 131193 Adaptive146Third143Node266 = [88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 125, 126, 128, 131] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive146Third143Proof267
  · exact adaptive146Third143Proof268
  · exact adaptive146Third143Proof269
  · exact adaptive146Third143Proof270
  · exact adaptive146Third143Proof271
  · exact adaptive146Third143Proof272
  · exact adaptive146Third143Proof273
  · exact adaptive146Third143Proof274
  · exact adaptive146Third143Proof275
  · exact adaptive146Third143Proof276
  · exact adaptive146Third143Proof277
  · exact adaptive146Third143Proof278
  · exact adaptive146Third143Proof279
  · exact adaptive146Third143Proof280
  · exact adaptive146Third143Proof281
  · exact adaptive146Third143Proof282
  · exact adaptive146Third143Proof283
  · exact adaptive146Third143Proof284
  · exact adaptive146Third143Proof285
  · exact adaptive146Third143Proof286
  · exact adaptive146Third143Proof287
  · exact adaptive146Third143Proof288
  · exact adaptive146Third143Proof289
  · exact adaptive146Third143Proof290
  · exact adaptive146Third143Proof291
  · exact adaptive146Third143Proof292
  · exact adaptive146Third143Proof293
  · exact adaptive146Third143Proof294
  · exact adaptive146Third143Proof295
  · exact adaptive146Third143Proof296
  · exact adaptive146Third143Proof297
  · exact adaptive146Third143Proof298
  · exact adaptive146Third143Proof299
  · exact adaptive146Third143Proof300
  · exact adaptive146Third143Proof301
  · exact adaptive146Third143Proof302
  · exact adaptive146Third143Proof303
  · exact adaptive146Third143Proof304
  · exact adaptive146Third143Proof305
  · exact adaptive146Third143Proof306

#print axioms adaptive146Third143Proof266

end NineSeparatedSubsetSums
