import NineSeparatedSubsetSums.Adaptive146Third136State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third136Proof19 : runCachedNode 511 130191 Adaptive146Third136Node19 = false := by
  decide +kernel

#print axioms adaptive146Third136Proof19

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third136Proof71 : runCachedNode 511 130191 Adaptive146Third136Node71 = false := by
  decide +kernel

#print axioms adaptive146Third136Proof71

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third136Proof27 : runCachedNode 511 130191 Adaptive146Third136Node27 = false := by
  decide +kernel

#print axioms adaptive146Third136Proof27

end NineSeparatedSubsetSums
