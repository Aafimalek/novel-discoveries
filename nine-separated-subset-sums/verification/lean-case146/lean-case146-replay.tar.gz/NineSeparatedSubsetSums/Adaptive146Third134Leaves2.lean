import NineSeparatedSubsetSums.Adaptive146Third134State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third134Proof19 : runCachedNode 511 129871 Adaptive146Third134Node19 = false := by
  decide +kernel

#print axioms adaptive146Third134Proof19

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third134Proof17 : runCachedNode 511 129871 Adaptive146Third134Node17 = false := by
  decide +kernel

#print axioms adaptive146Third134Proof17

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third134Proof61 : runCachedNode 511 129871 Adaptive146Third134Node61 = false := by
  decide +kernel

#print axioms adaptive146Third134Proof61

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third134Proof27 : runCachedNode 511 129871 Adaptive146Third134Node27 = false := by
  decide +kernel

#print axioms adaptive146Third134Proof27

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third134Proof48 : runCachedNode 511 129871 Adaptive146Third134Node48 = false := by
  decide +kernel

#print axioms adaptive146Third134Proof48

end NineSeparatedSubsetSums
