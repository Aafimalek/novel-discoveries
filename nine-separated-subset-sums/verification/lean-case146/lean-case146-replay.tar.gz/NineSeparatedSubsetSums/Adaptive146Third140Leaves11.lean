import NineSeparatedSubsetSums.Adaptive146Third140State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third140Proof126 : runCachedNode 511 130775 Adaptive146Third140Node126 = false := by
  decide +kernel

#print axioms adaptive146Third140Proof126

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third140Proof382 : runCachedNode 511 130775 Adaptive146Third140Node382 = false := by
  decide +kernel

#print axioms adaptive146Third140Proof382

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third140Proof29 : runCachedNode 511 130775 Adaptive146Third140Node29 = false := by
  decide +kernel

#print axioms adaptive146Third140Proof29

end NineSeparatedSubsetSums
