import NineSeparatedSubsetSums.Adaptive146Third144State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third144Proof283 : runCachedNode 511 131319 Adaptive146Third144Node283 = false := by
  decide +kernel

#print axioms adaptive146Third144Proof283

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third144Proof162 : runCachedNode 511 131319 Adaptive146Third144Node162 = false := by
  decide +kernel

#print axioms adaptive146Third144Proof162

end NineSeparatedSubsetSums
