import NineSeparatedSubsetSums.Adaptive146Third109State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third109Proof0 : runCachedNode 511 112631 Adaptive146Third109Node0 = false := by
  decide +kernel

#print axioms adaptive146Third109Proof0

end NineSeparatedSubsetSums
