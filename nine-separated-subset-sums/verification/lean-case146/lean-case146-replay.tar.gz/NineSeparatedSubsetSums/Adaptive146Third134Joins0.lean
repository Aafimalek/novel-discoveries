import NineSeparatedSubsetSums.Adaptive146Third134State
import NineSeparatedSubsetSums.Adaptive146Third134Leaves6
import NineSeparatedSubsetSums.Adaptive146Third134Leaves7
import NineSeparatedSubsetSums.Adaptive146Third134Leaves0
import NineSeparatedSubsetSums.Adaptive146Third134Leaves2
import NineSeparatedSubsetSums.Adaptive146Third134Leaves5
import NineSeparatedSubsetSums.Adaptive146Third134Leaves4
import NineSeparatedSubsetSums.Adaptive146Third134Leaves1
import NineSeparatedSubsetSums.Adaptive146Third134Leaves3

namespace NineSeparatedSubsetSums

theorem adaptive146Third134Proof21 : runCachedNode 511 129871 Adaptive146Third134Node21 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 129871 Adaptive146Third134Node21 = [104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 117, 119, 120, 121, 122, 123, 124, 125, 126, 127, 129] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive146Third134Proof22
  · exact adaptive146Third134Proof23
  · exact adaptive146Third134Proof24
  · exact adaptive146Third134Proof25
  · exact adaptive146Third134Proof26
  · exact adaptive146Third134Proof27
  · exact adaptive146Third134Proof28
  · exact adaptive146Third134Proof29
  · exact adaptive146Third134Proof30
  · exact adaptive146Third134Proof31
  · exact adaptive146Third134Proof32
  · exact adaptive146Third134Proof33
  · exact adaptive146Third134Proof34
  · exact adaptive146Third134Proof35
  · exact adaptive146Third134Proof36
  · exact adaptive146Third134Proof37
  · exact adaptive146Third134Proof38
  · exact adaptive146Third134Proof39
  · exact adaptive146Third134Proof40
  · exact adaptive146Third134Proof41
  · exact adaptive146Third134Proof42
  · exact adaptive146Third134Proof43
  · exact adaptive146Third134Proof44

#print axioms adaptive146Third134Proof21

theorem adaptive146Third134Proof46 : runCachedNode 511 129871 Adaptive146Third134Node46 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 129871 Adaptive146Third134Node46 = [103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 120, 122, 123, 124, 125, 126, 127, 128, 129, 130] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive146Third134Proof47
  · exact adaptive146Third134Proof48
  · exact adaptive146Third134Proof49
  · exact adaptive146Third134Proof50
  · exact adaptive146Third134Proof51
  · exact adaptive146Third134Proof52
  · exact adaptive146Third134Proof53
  · exact adaptive146Third134Proof54
  · exact adaptive146Third134Proof55
  · exact adaptive146Third134Proof56
  · exact adaptive146Third134Proof57
  · exact adaptive146Third134Proof58
  · exact adaptive146Third134Proof59
  · exact adaptive146Third134Proof60
  · exact adaptive146Third134Proof61
  · exact adaptive146Third134Proof62
  · exact adaptive146Third134Proof63
  · exact adaptive146Third134Proof64
  · exact adaptive146Third134Proof65
  · exact adaptive146Third134Proof66
  · exact adaptive146Third134Proof67
  · exact adaptive146Third134Proof68
  · exact adaptive146Third134Proof69
  · exact adaptive146Third134Proof70
  · exact adaptive146Third134Proof71
  · exact adaptive146Third134Proof72

#print axioms adaptive146Third134Proof46

theorem adaptive146Third134Proof0 : runCachedNode 511 129871 Adaptive146Third134Node0 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 129871 Adaptive146Third134Node0 = [110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 133] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive146Third134Proof1
  · exact adaptive146Third134Proof2
  · exact adaptive146Third134Proof3
  · exact adaptive146Third134Proof4
  · exact adaptive146Third134Proof5
  · exact adaptive146Third134Proof6
  · exact adaptive146Third134Proof7
  · exact adaptive146Third134Proof8
  · exact adaptive146Third134Proof9
  · exact adaptive146Third134Proof10
  · exact adaptive146Third134Proof11
  · exact adaptive146Third134Proof12
  · exact adaptive146Third134Proof13
  · exact adaptive146Third134Proof14
  · exact adaptive146Third134Proof15
  · exact adaptive146Third134Proof16
  · exact adaptive146Third134Proof17
  · exact adaptive146Third134Proof18
  · exact adaptive146Third134Proof19
  · exact adaptive146Third134Proof20
  · exact adaptive146Third134Proof21
  · exact adaptive146Third134Proof45
  · exact adaptive146Third134Proof46

#print axioms adaptive146Third134Proof0

end NineSeparatedSubsetSums
