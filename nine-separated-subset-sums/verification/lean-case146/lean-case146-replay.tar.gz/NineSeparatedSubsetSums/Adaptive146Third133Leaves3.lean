import NineSeparatedSubsetSums.Adaptive146Third133State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third133Proof17 : runCachedNode 511 129683 Adaptive146Third133Node17 = false := by
  decide +kernel

#print axioms adaptive146Third133Proof17

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third133Proof16 : runCachedNode 511 129683 Adaptive146Third133Node16 = false := by
  decide +kernel

#print axioms adaptive146Third133Proof16

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third133Proof15 : runCachedNode 511 129683 Adaptive146Third133Node15 = false := by
  decide +kernel

#print axioms adaptive146Third133Proof15

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third133Proof11 : runCachedNode 511 129683 Adaptive146Third133Node11 = false := by
  decide +kernel

#print axioms adaptive146Third133Proof11

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third133Proof1 : runCachedNode 511 129683 Adaptive146Third133Node1 = false := by
  decide +kernel

#print axioms adaptive146Third133Proof1

end NineSeparatedSubsetSums
