import NineSeparatedSubsetSums.Adaptive146Third143State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third143Proof582 : runCachedNode 511 131193 Adaptive146Third143Node582 = false := by
  decide +kernel

#print axioms adaptive146Third143Proof582

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third143Proof417 : runCachedNode 511 131193 Adaptive146Third143Node417 = false := by
  decide +kernel

#print axioms adaptive146Third143Proof417

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third143Proof53 : runCachedNode 511 131193 Adaptive146Third143Node53 = false := by
  decide +kernel

#print axioms adaptive146Third143Proof53

end NineSeparatedSubsetSums
