import NineSeparatedSubsetSums.Adaptive146Third143State
import NineSeparatedSubsetSums.Adaptive146Third143Leaves55
import NineSeparatedSubsetSums.Adaptive146Third143Leaves56
import NineSeparatedSubsetSums.Adaptive146Third143Leaves54
import NineSeparatedSubsetSums.Adaptive146Third143Leaves52
import NineSeparatedSubsetSums.Adaptive146Third143Leaves51
import NineSeparatedSubsetSums.Adaptive146Third143Leaves50
import NineSeparatedSubsetSums.Adaptive146Third143Leaves49
import NineSeparatedSubsetSums.Adaptive146Third143Leaves47
import NineSeparatedSubsetSums.Adaptive146Third143Leaves46
import NineSeparatedSubsetSums.Adaptive146Third143Leaves45
import NineSeparatedSubsetSums.Adaptive146Third143Leaves44
import NineSeparatedSubsetSums.Adaptive146Third143Leaves43
import NineSeparatedSubsetSums.Adaptive146Third143Leaves42
import NineSeparatedSubsetSums.Adaptive146Third143Leaves41
import NineSeparatedSubsetSums.Adaptive146Third143Leaves16
import NineSeparatedSubsetSums.Adaptive146Third143Leaves38
import NineSeparatedSubsetSums.Adaptive146Third143Leaves35
import NineSeparatedSubsetSums.Adaptive146Third143Leaves32
import NineSeparatedSubsetSums.Adaptive146Third143Leaves29
import NineSeparatedSubsetSums.Adaptive146Third143Leaves21
import NineSeparatedSubsetSums.Adaptive146Third143Leaves19
import NineSeparatedSubsetSums.Adaptive146Third143Leaves48
import NineSeparatedSubsetSums.Adaptive146Third143Leaves40
import NineSeparatedSubsetSums.Adaptive146Third143Leaves37
import NineSeparatedSubsetSums.Adaptive146Third143Leaves36
import NineSeparatedSubsetSums.Adaptive146Third143Leaves34
import NineSeparatedSubsetSums.Adaptive146Third143Leaves30
import NineSeparatedSubsetSums.Adaptive146Third143Leaves23
import NineSeparatedSubsetSums.Adaptive146Third143Leaves28
import NineSeparatedSubsetSums.Adaptive146Third143Leaves24
import NineSeparatedSubsetSums.Adaptive146Third143Leaves8
import NineSeparatedSubsetSums.Adaptive146Third143Leaves15
import NineSeparatedSubsetSums.Adaptive146Third143Leaves10
import NineSeparatedSubsetSums.Adaptive146Third143Joins1
import NineSeparatedSubsetSums.Adaptive146Third143Leaves3
import NineSeparatedSubsetSums.Adaptive146Third143Leaves18
import NineSeparatedSubsetSums.Adaptive146Third143Leaves39
import NineSeparatedSubsetSums.Adaptive146Third143Leaves26
import NineSeparatedSubsetSums.Adaptive146Third143Leaves20
import NineSeparatedSubsetSums.Adaptive146Third143Leaves13
import NineSeparatedSubsetSums.Adaptive146Third143Leaves14
import NineSeparatedSubsetSums.Adaptive146Third143Leaves4
import NineSeparatedSubsetSums.Adaptive146Third143Leaves1
import NineSeparatedSubsetSums.Adaptive146Third143Joins0

namespace NineSeparatedSubsetSums

theorem adaptive146Third143Proof626 : runCachedNode 511 131193 Adaptive146Third143Node626 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 131193 Adaptive146Third143Node626 = [86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 130, 131] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive146Third143Proof627
  · exact adaptive146Third143Proof628
  · exact adaptive146Third143Proof629
  · exact adaptive146Third143Proof630
  · exact adaptive146Third143Proof631
  · exact adaptive146Third143Proof632
  · exact adaptive146Third143Proof633
  · exact adaptive146Third143Proof634
  · exact adaptive146Third143Proof635
  · exact adaptive146Third143Proof636
  · exact adaptive146Third143Proof637
  · exact adaptive146Third143Proof638
  · exact adaptive146Third143Proof639
  · exact adaptive146Third143Proof640
  · exact adaptive146Third143Proof641
  · exact adaptive146Third143Proof642
  · exact adaptive146Third143Proof643
  · exact adaptive146Third143Proof644
  · exact adaptive146Third143Proof645
  · exact adaptive146Third143Proof646
  · exact adaptive146Third143Proof647
  · exact adaptive146Third143Proof648
  · exact adaptive146Third143Proof649
  · exact adaptive146Third143Proof650
  · exact adaptive146Third143Proof651
  · exact adaptive146Third143Proof652
  · exact adaptive146Third143Proof653
  · exact adaptive146Third143Proof654
  · exact adaptive146Third143Proof655
  · exact adaptive146Third143Proof656
  · exact adaptive146Third143Proof657
  · exact adaptive146Third143Proof658
  · exact adaptive146Third143Proof659
  · exact adaptive146Third143Proof660
  · exact adaptive146Third143Proof661
  · exact adaptive146Third143Proof662
  · exact adaptive146Third143Proof663
  · exact adaptive146Third143Proof664
  · exact adaptive146Third143Proof665
  · exact adaptive146Third143Proof666
  · exact adaptive146Third143Proof667
  · exact adaptive146Third143Proof668
  · exact adaptive146Third143Proof669
  · exact adaptive146Third143Proof670
  · exact adaptive146Third143Proof671

#print axioms adaptive146Third143Proof626

theorem adaptive146Third143Proof546 : runCachedNode 511 131193 Adaptive146Third143Node546 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 131193 Adaptive146Third143Node546 = [100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 132, 133, 134, 135, 136, 138] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive146Third143Proof547
  · exact adaptive146Third143Proof548
  · exact adaptive146Third143Proof549
  · exact adaptive146Third143Proof550
  · exact adaptive146Third143Proof551
  · exact adaptive146Third143Proof552
  · exact adaptive146Third143Proof553
  · exact adaptive146Third143Proof554
  · exact adaptive146Third143Proof555
  · exact adaptive146Third143Proof556
  · exact adaptive146Third143Proof557
  · exact adaptive146Third143Proof558
  · exact adaptive146Third143Proof559
  · exact adaptive146Third143Proof560
  · exact adaptive146Third143Proof561
  · exact adaptive146Third143Proof562
  · exact adaptive146Third143Proof563
  · exact adaptive146Third143Proof564
  · exact adaptive146Third143Proof565
  · exact adaptive146Third143Proof566
  · exact adaptive146Third143Proof567
  · exact adaptive146Third143Proof568
  · exact adaptive146Third143Proof569
  · exact adaptive146Third143Proof570
  · exact adaptive146Third143Proof571
  · exact adaptive146Third143Proof572
  · exact adaptive146Third143Proof573
  · exact adaptive146Third143Proof574
  · exact adaptive146Third143Proof575
  · exact adaptive146Third143Proof576
  · exact adaptive146Third143Proof577
  · exact adaptive146Third143Proof578
  · exact adaptive146Third143Proof579
  · exact adaptive146Third143Proof580
  · exact adaptive146Third143Proof581
  · exact adaptive146Third143Proof582
  · exact adaptive146Third143Proof583
  · exact adaptive146Third143Proof626

#print axioms adaptive146Third143Proof546

theorem adaptive146Third143Proof0 : runCachedNode 511 131193 Adaptive146Third143Node0 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 131193 Adaptive146Third143Node0 = [109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 132, 133, 134, 135, 136, 137, 138, 139, 140, 142] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive146Third143Proof1
  · exact adaptive146Third143Proof2
  · exact adaptive146Third143Proof3
  · exact adaptive146Third143Proof4
  · exact adaptive146Third143Proof5
  · exact adaptive146Third143Proof6
  · exact adaptive146Third143Proof7
  · exact adaptive146Third143Proof8
  · exact adaptive146Third143Proof9
  · exact adaptive146Third143Proof10
  · exact adaptive146Third143Proof11
  · exact adaptive146Third143Proof12
  · exact adaptive146Third143Proof13
  · exact adaptive146Third143Proof14
  · exact adaptive146Third143Proof15
  · exact adaptive146Third143Proof16
  · exact adaptive146Third143Proof17
  · exact adaptive146Third143Proof18
  · exact adaptive146Third143Proof19
  · exact adaptive146Third143Proof20
  · exact adaptive146Third143Proof21
  · exact adaptive146Third143Proof22
  · exact adaptive146Third143Proof23
  · exact adaptive146Third143Proof49
  · exact adaptive146Third143Proof76
  · exact adaptive146Third143Proof105
  · exact adaptive146Third143Proof135
  · exact adaptive146Third143Proof166
  · exact adaptive146Third143Proof198
  · exact adaptive146Third143Proof232
  · exact adaptive146Third143Proof307
  · exact adaptive146Third143Proof385
  · exact adaptive146Third143Proof546

#print axioms adaptive146Third143Proof0

end NineSeparatedSubsetSums
