import NineSeparatedSubsetSums.Adaptive146Third141State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third141Proof107 : runCachedNode 511 130916 Adaptive146Third141Node107 = false := by
  decide +kernel

#print axioms adaptive146Third141Proof107

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third141Proof19 : runCachedNode 511 130916 Adaptive146Third141Node19 = false := by
  decide +kernel

#print axioms adaptive146Third141Proof19

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third141Proof40 : runCachedNode 511 130916 Adaptive146Third141Node40 = false := by
  decide +kernel

#print axioms adaptive146Third141Proof40

end NineSeparatedSubsetSums
