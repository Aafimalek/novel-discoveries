import NineSeparatedSubsetSums.Adaptive146Third144State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third144Proof1115 : runCachedNode 511 131319 Adaptive146Third144Node1115 = false := by
  decide +kernel

#print axioms adaptive146Third144Proof1115

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third144Proof851 : runCachedNode 511 131319 Adaptive146Third144Node851 = false := by
  decide +kernel

#print axioms adaptive146Third144Proof851

end NineSeparatedSubsetSums
