import NineSeparatedSubsetSums.Adaptive146Third138State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third138Proof42 : runCachedNode 511 130484 Adaptive146Third138Node42 = false := by
  decide +kernel

#print axioms adaptive146Third138Proof42

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third138Proof96 : runCachedNode 511 130484 Adaptive146Third138Node96 = false := by
  decide +kernel

#print axioms adaptive146Third138Proof96

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third138Proof213 : runCachedNode 511 130484 Adaptive146Third138Node213 = false := by
  decide +kernel

#print axioms adaptive146Third138Proof213

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third138Proof12 : runCachedNode 511 130484 Adaptive146Third138Node12 = false := by
  decide +kernel

#print axioms adaptive146Third138Proof12

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third138Proof84 : runCachedNode 511 130484 Adaptive146Third138Node84 = false := by
  decide +kernel

#print axioms adaptive146Third138Proof84

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third138Proof157 : runCachedNode 511 130484 Adaptive146Third138Node157 = false := by
  decide +kernel

#print axioms adaptive146Third138Proof157

end NineSeparatedSubsetSums
