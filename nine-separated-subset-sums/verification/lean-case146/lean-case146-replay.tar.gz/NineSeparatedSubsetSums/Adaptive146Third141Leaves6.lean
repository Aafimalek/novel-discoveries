import NineSeparatedSubsetSums.Adaptive146Third141State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third141Proof315 : runCachedNode 511 130916 Adaptive146Third141Node315 = false := by
  decide +kernel

#print axioms adaptive146Third141Proof315

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third141Proof49 : runCachedNode 511 130916 Adaptive146Third141Node49 = false := by
  decide +kernel

#print axioms adaptive146Third141Proof49

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third141Proof207 : runCachedNode 511 130916 Adaptive146Third141Node207 = false := by
  decide +kernel

#print axioms adaptive146Third141Proof207

end NineSeparatedSubsetSums
