import NineSeparatedSubsetSums.Adaptive146Third142State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third142Proof20 : runCachedNode 511 131054 Adaptive146Third142Node20 = false := by
  decide +kernel

#print axioms adaptive146Third142Proof20

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third142Proof140 : runCachedNode 511 131054 Adaptive146Third142Node140 = false := by
  decide +kernel

#print axioms adaptive146Third142Proof140

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third142Proof124 : runCachedNode 511 131054 Adaptive146Third142Node124 = false := by
  decide +kernel

#print axioms adaptive146Third142Proof124

end NineSeparatedSubsetSums
