import NineSeparatedSubsetSums.Adaptive146Third139State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third139Proof93 : runCachedNode 511 130638 Adaptive146Third139Node93 = false := by
  decide +kernel

#print axioms adaptive146Third139Proof93

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third139Proof239 : runCachedNode 511 130638 Adaptive146Third139Node239 = false := by
  decide +kernel

#print axioms adaptive146Third139Proof239

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third139Proof91 : runCachedNode 511 130638 Adaptive146Third139Node91 = false := by
  decide +kernel

#print axioms adaptive146Third139Proof91

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third139Proof147 : runCachedNode 511 130638 Adaptive146Third139Node147 = false := by
  decide +kernel

#print axioms adaptive146Third139Proof147

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third139Proof39 : runCachedNode 511 130638 Adaptive146Third139Node39 = false := by
  decide +kernel

#print axioms adaptive146Third139Proof39

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third139Proof120 : runCachedNode 511 130638 Adaptive146Third139Node120 = false := by
  decide +kernel

#print axioms adaptive146Third139Proof120

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third139Proof210 : runCachedNode 511 130638 Adaptive146Third139Node210 = false := by
  decide +kernel

#print axioms adaptive146Third139Proof210

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third139Proof240 : runCachedNode 511 130638 Adaptive146Third139Node240 = false := by
  decide +kernel

#print axioms adaptive146Third139Proof240

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third139Proof37 : runCachedNode 511 130638 Adaptive146Third139Node37 = false := by
  decide +kernel

#print axioms adaptive146Third139Proof37

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third139Proof242 : runCachedNode 511 130638 Adaptive146Third139Node242 = false := by
  decide +kernel

#print axioms adaptive146Third139Proof242

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third139Proof238 : runCachedNode 511 130638 Adaptive146Third139Node238 = false := by
  decide +kernel

#print axioms adaptive146Third139Proof238

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third139Proof194 : runCachedNode 511 130638 Adaptive146Third139Node194 = false := by
  decide +kernel

#print axioms adaptive146Third139Proof194

end NineSeparatedSubsetSums
