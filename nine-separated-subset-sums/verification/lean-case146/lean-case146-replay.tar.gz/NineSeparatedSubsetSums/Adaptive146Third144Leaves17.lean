import NineSeparatedSubsetSums.Adaptive146Third144State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third144Proof381 : runCachedNode 511 131319 Adaptive146Third144Node381 = false := by
  decide +kernel

#print axioms adaptive146Third144Proof381

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third144Proof134 : runCachedNode 511 131319 Adaptive146Third144Node134 = false := by
  decide +kernel

#print axioms adaptive146Third144Proof134

end NineSeparatedSubsetSums
