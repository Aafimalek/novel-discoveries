import NineSeparatedSubsetSums.Adaptive146Third141State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third141Proof203 : runCachedNode 511 130916 Adaptive146Third141Node203 = false := by
  decide +kernel

#print axioms adaptive146Third141Proof203

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third141Proof44 : runCachedNode 511 130916 Adaptive146Third141Node44 = false := by
  decide +kernel

#print axioms adaptive146Third141Proof44

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third141Proof27 : runCachedNode 511 130916 Adaptive146Third141Node27 = false := by
  decide +kernel

#print axioms adaptive146Third141Proof27

end NineSeparatedSubsetSums
