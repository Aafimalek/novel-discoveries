import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive146Third107Node0 : CachedSearchNode :=
  ⟨4, 106, computeCenteredMask [148,146,107], 401, 54669⟩

end NineSeparatedSubsetSums
