import NineSeparatedSubsetSums.Adaptive146Third139State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third139Proof17 : runCachedNode 511 130638 Adaptive146Third139Node17 = false := by
  decide +kernel

#print axioms adaptive146Third139Proof17

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third139Proof70 : runCachedNode 511 130638 Adaptive146Third139Node70 = false := by
  decide +kernel

#print axioms adaptive146Third139Proof70

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third139Proof94 : runCachedNode 511 130638 Adaptive146Third139Node94 = false := by
  decide +kernel

#print axioms adaptive146Third139Proof94

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third139Proof27 : runCachedNode 511 130638 Adaptive146Third139Node27 = false := by
  decide +kernel

#print axioms adaptive146Third139Proof27

end NineSeparatedSubsetSums
