import NineSeparatedSubsetSums.Adaptive146Third140State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third140Proof186 : runCachedNode 511 130775 Adaptive146Third140Node186 = false := by
  decide +kernel

#print axioms adaptive146Third140Proof186

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third140Proof17 : runCachedNode 511 130775 Adaptive146Third140Node17 = false := by
  decide +kernel

#print axioms adaptive146Third140Proof17

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third140Proof242 : runCachedNode 511 130775 Adaptive146Third140Node242 = false := by
  decide +kernel

#print axioms adaptive146Third140Proof242

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third140Proof316 : runCachedNode 511 130775 Adaptive146Third140Node316 = false := by
  decide +kernel

#print axioms adaptive146Third140Proof316

end NineSeparatedSubsetSums
