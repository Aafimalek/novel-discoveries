import NineSeparatedSubsetSums.Adaptive146Third125State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third125Proof0 : runCachedNode 511 127768 Adaptive146Third125Node0 = false := by
  decide +kernel

#print axioms adaptive146Third125Proof0

end NineSeparatedSubsetSums
