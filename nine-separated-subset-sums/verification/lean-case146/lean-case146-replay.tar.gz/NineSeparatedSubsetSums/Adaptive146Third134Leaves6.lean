import NineSeparatedSubsetSums.Adaptive146Third134State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third134Proof64 : runCachedNode 511 129871 Adaptive146Third134Node64 = false := by
  decide +kernel

#print axioms adaptive146Third134Proof64

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third134Proof41 : runCachedNode 511 129871 Adaptive146Third134Node41 = false := by
  decide +kernel

#print axioms adaptive146Third134Proof41

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third134Proof10 : runCachedNode 511 129871 Adaptive146Third134Node10 = false := by
  decide +kernel

#print axioms adaptive146Third134Proof10

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third134Proof63 : runCachedNode 511 129871 Adaptive146Third134Node63 = false := by
  decide +kernel

#print axioms adaptive146Third134Proof63

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third134Proof39 : runCachedNode 511 129871 Adaptive146Third134Node39 = false := by
  decide +kernel

#print axioms adaptive146Third134Proof39

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third134Proof9 : runCachedNode 511 129871 Adaptive146Third134Node9 = false := by
  decide +kernel

#print axioms adaptive146Third134Proof9

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third134Proof36 : runCachedNode 511 129871 Adaptive146Third134Node36 = false := by
  decide +kernel

#print axioms adaptive146Third134Proof36

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third134Proof65 : runCachedNode 511 129871 Adaptive146Third134Node65 = false := by
  decide +kernel

#print axioms adaptive146Third134Proof65

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third134Proof67 : runCachedNode 511 129871 Adaptive146Third134Node67 = false := by
  decide +kernel

#print axioms adaptive146Third134Proof67

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third134Proof8 : runCachedNode 511 129871 Adaptive146Third134Node8 = false := by
  decide +kernel

#print axioms adaptive146Third134Proof8

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third134Proof7 : runCachedNode 511 129871 Adaptive146Third134Node7 = false := by
  decide +kernel

#print axioms adaptive146Third134Proof7

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third134Proof6 : runCachedNode 511 129871 Adaptive146Third134Node6 = false := by
  decide +kernel

#print axioms adaptive146Third134Proof6

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third134Proof34 : runCachedNode 511 129871 Adaptive146Third134Node34 = false := by
  decide +kernel

#print axioms adaptive146Third134Proof34

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third134Proof60 : runCachedNode 511 129871 Adaptive146Third134Node60 = false := by
  decide +kernel

#print axioms adaptive146Third134Proof60

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third134Proof35 : runCachedNode 511 129871 Adaptive146Third134Node35 = false := by
  decide +kernel

#print axioms adaptive146Third134Proof35

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third134Proof32 : runCachedNode 511 129871 Adaptive146Third134Node32 = false := by
  decide +kernel

#print axioms adaptive146Third134Proof32

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third134Proof33 : runCachedNode 511 129871 Adaptive146Third134Node33 = false := by
  decide +kernel

#print axioms adaptive146Third134Proof33

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third134Proof5 : runCachedNode 511 129871 Adaptive146Third134Node5 = false := by
  decide +kernel

#print axioms adaptive146Third134Proof5

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third134Proof29 : runCachedNode 511 129871 Adaptive146Third134Node29 = false := by
  decide +kernel

#print axioms adaptive146Third134Proof29

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third134Proof22 : runCachedNode 511 129871 Adaptive146Third134Node22 = false := by
  decide +kernel

#print axioms adaptive146Third134Proof22

end NineSeparatedSubsetSums
