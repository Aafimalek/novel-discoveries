import NineSeparatedSubsetSums.Adaptive146Third144State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third144Proof252 : runCachedNode 511 131319 Adaptive146Third144Node252 = false := by
  decide +kernel

#print axioms adaptive146Third144Proof252

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third144Proof135 : runCachedNode 511 131319 Adaptive146Third144Node135 = false := by
  decide +kernel

#print axioms adaptive146Third144Proof135

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third144Proof43 : runCachedNode 511 131319 Adaptive146Third144Node43 = false := by
  decide +kernel

#print axioms adaptive146Third144Proof43

end NineSeparatedSubsetSums
