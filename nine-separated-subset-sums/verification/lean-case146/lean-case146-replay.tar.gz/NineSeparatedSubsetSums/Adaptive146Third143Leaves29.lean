import NineSeparatedSubsetSums.Adaptive146Third143State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third143Proof334 : runCachedNode 511 131193 Adaptive146Third143Node334 = false := by
  decide +kernel

#print axioms adaptive146Third143Proof334

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third143Proof14 : runCachedNode 511 131193 Adaptive146Third143Node14 = false := by
  decide +kernel

#print axioms adaptive146Third143Proof14

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third143Proof164 : runCachedNode 511 131193 Adaptive146Third143Node164 = false := by
  decide +kernel

#print axioms adaptive146Third143Proof164

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third143Proof669 : runCachedNode 511 131193 Adaptive146Third143Node669 = false := by
  decide +kernel

#print axioms adaptive146Third143Proof669

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third143Proof162 : runCachedNode 511 131193 Adaptive146Third143Node162 = false := by
  decide +kernel

#print axioms adaptive146Third143Proof162

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third143Proof24 : runCachedNode 511 131193 Adaptive146Third143Node24 = false := by
  decide +kernel

#print axioms adaptive146Third143Proof24

end NineSeparatedSubsetSums
