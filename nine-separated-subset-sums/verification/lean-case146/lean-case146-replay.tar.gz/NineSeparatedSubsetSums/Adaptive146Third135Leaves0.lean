import NineSeparatedSubsetSums.Adaptive146Third135State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third135Proof21 : runCachedNode 511 130049 Adaptive146Third135Node21 = false := by
  decide +kernel

#print axioms adaptive146Third135Proof21

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third135Proof93 : runCachedNode 511 130049 Adaptive146Third135Node93 = false := by
  decide +kernel

#print axioms adaptive146Third135Proof93

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third135Proof85 : runCachedNode 511 130049 Adaptive146Third135Node85 = false := by
  decide +kernel

#print axioms adaptive146Third135Proof85

end NineSeparatedSubsetSums
