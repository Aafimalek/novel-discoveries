import NineSeparatedSubsetSums.Adaptive146Third144State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third144Proof17 : runCachedNode 511 131319 Adaptive146Third144Node17 = false := by
  decide +kernel

#print axioms adaptive146Third144Proof17

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third144Proof133 : runCachedNode 511 131319 Adaptive146Third144Node133 = false := by
  decide +kernel

#print axioms adaptive146Third144Proof133

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third144Proof493 : runCachedNode 511 131319 Adaptive146Third144Node493 = false := by
  decide +kernel

#print axioms adaptive146Third144Proof493

end NineSeparatedSubsetSums
