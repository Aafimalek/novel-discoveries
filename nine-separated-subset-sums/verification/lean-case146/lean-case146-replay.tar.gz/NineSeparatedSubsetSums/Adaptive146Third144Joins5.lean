import NineSeparatedSubsetSums.Adaptive146Third144State
import NineSeparatedSubsetSums.Adaptive146Third144Leaves7
import NineSeparatedSubsetSums.Adaptive146Third144Leaves26
import NineSeparatedSubsetSums.Adaptive146Third144Leaves10
import NineSeparatedSubsetSums.Adaptive146Third144Leaves113
import NineSeparatedSubsetSums.Adaptive146Third144Leaves18
import NineSeparatedSubsetSums.Adaptive146Third144Leaves120
import NineSeparatedSubsetSums.Adaptive146Third144Leaves116
import NineSeparatedSubsetSums.Adaptive146Third144Leaves76
import NineSeparatedSubsetSums.Adaptive146Third144Leaves101
import NineSeparatedSubsetSums.Adaptive146Third144Leaves89
import NineSeparatedSubsetSums.Adaptive146Third144Leaves49
import NineSeparatedSubsetSums.Adaptive146Third144Leaves67
import NineSeparatedSubsetSums.Adaptive146Third144Leaves58
import NineSeparatedSubsetSums.Adaptive146Third144Leaves46
import NineSeparatedSubsetSums.Adaptive146Third144Leaves35
import NineSeparatedSubsetSums.Adaptive146Third144Leaves21
import NineSeparatedSubsetSums.Adaptive146Third144Leaves11
import NineSeparatedSubsetSums.Adaptive146Third144Joins0
import NineSeparatedSubsetSums.Adaptive146Third144Joins1
import NineSeparatedSubsetSums.Adaptive146Third144Joins2
import NineSeparatedSubsetSums.Adaptive146Third144Joins3
import NineSeparatedSubsetSums.Adaptive146Third144Joins4

namespace NineSeparatedSubsetSums

theorem adaptive146Third144Proof0 : runCachedNode 511 131319 Adaptive146Third144Node0 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 131319 Adaptive146Third144Node0 = [109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 132, 133, 134, 135, 136, 137, 138, 139, 140, 141, 143] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive146Third144Proof1
  · exact adaptive146Third144Proof2
  · exact adaptive146Third144Proof3
  · exact adaptive146Third144Proof4
  · exact adaptive146Third144Proof5
  · exact adaptive146Third144Proof6
  · exact adaptive146Third144Proof7
  · exact adaptive146Third144Proof8
  · exact adaptive146Third144Proof9
  · exact adaptive146Third144Proof10
  · exact adaptive146Third144Proof11
  · exact adaptive146Third144Proof12
  · exact adaptive146Third144Proof13
  · exact adaptive146Third144Proof14
  · exact adaptive146Third144Proof15
  · exact adaptive146Third144Proof16
  · exact adaptive146Third144Proof17
  · exact adaptive146Third144Proof18
  · exact adaptive146Third144Proof39
  · exact adaptive146Third144Proof61
  · exact adaptive146Third144Proof85
  · exact adaptive146Third144Proof110
  · exact adaptive146Third144Proof136
  · exact adaptive146Third144Proof163
  · exact adaptive146Third144Proof192
  · exact adaptive146Third144Proof222
  · exact adaptive146Third144Proof253
  · exact adaptive146Third144Proof285
  · exact adaptive146Third144Proof351
  · exact adaptive146Third144Proof386
  · exact adaptive146Third144Proof532
  · exact adaptive146Third144Proof686
  · exact adaptive146Third144Proof1079
  · exact adaptive146Third144Proof1254

#print axioms adaptive146Third144Proof0

end NineSeparatedSubsetSums
