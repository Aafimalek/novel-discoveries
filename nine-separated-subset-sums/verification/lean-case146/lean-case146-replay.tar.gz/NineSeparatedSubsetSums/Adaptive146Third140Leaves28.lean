import NineSeparatedSubsetSums.Adaptive146Third140State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third140Proof145 : runCachedNode 511 130775 Adaptive146Third140Node145 = false := by
  decide +kernel

#print axioms adaptive146Third140Proof145

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third140Proof271 : runCachedNode 511 130775 Adaptive146Third140Node271 = false := by
  decide +kernel

#print axioms adaptive146Third140Proof271

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third140Proof303 : runCachedNode 511 130775 Adaptive146Third140Node303 = false := by
  decide +kernel

#print axioms adaptive146Third140Proof303

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third140Proof37 : runCachedNode 511 130775 Adaptive146Third140Node37 = false := by
  decide +kernel

#print axioms adaptive146Third140Proof37

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third140Proof87 : runCachedNode 511 130775 Adaptive146Third140Node87 = false := by
  decide +kernel

#print axioms adaptive146Third140Proof87

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third140Proof207 : runCachedNode 511 130775 Adaptive146Third140Node207 = false := by
  decide +kernel

#print axioms adaptive146Third140Proof207

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third140Proof178 : runCachedNode 511 130775 Adaptive146Third140Node178 = false := by
  decide +kernel

#print axioms adaptive146Third140Proof178

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third140Proof371 : runCachedNode 511 130775 Adaptive146Third140Node371 = false := by
  decide +kernel

#print axioms adaptive146Third140Proof371

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third140Proof177 : runCachedNode 511 130775 Adaptive146Third140Node177 = false := by
  decide +kernel

#print axioms adaptive146Third140Proof177

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third140Proof304 : runCachedNode 511 130775 Adaptive146Third140Node304 = false := by
  decide +kernel

#print axioms adaptive146Third140Proof304

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third140Proof206 : runCachedNode 511 130775 Adaptive146Third140Node206 = false := by
  decide +kernel

#print axioms adaptive146Third140Proof206

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third140Proof344 : runCachedNode 511 130775 Adaptive146Third140Node344 = false := by
  decide +kernel

#print axioms adaptive146Third140Proof344

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third140Proof116 : runCachedNode 511 130775 Adaptive146Third140Node116 = false := by
  decide +kernel

#print axioms adaptive146Third140Proof116

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third140Proof234 : runCachedNode 511 130775 Adaptive146Third140Node234 = false := by
  decide +kernel

#print axioms adaptive146Third140Proof234

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third140Proof233 : runCachedNode 511 130775 Adaptive146Third140Node233 = false := by
  decide +kernel

#print axioms adaptive146Third140Proof233

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third140Proof38 : runCachedNode 511 130775 Adaptive146Third140Node38 = false := by
  decide +kernel

#print axioms adaptive146Third140Proof38

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third140Proof143 : runCachedNode 511 130775 Adaptive146Third140Node143 = false := by
  decide +kernel

#print axioms adaptive146Third140Proof143

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third140Proof9 : runCachedNode 511 130775 Adaptive146Third140Node9 = false := by
  decide +kernel

#print axioms adaptive146Third140Proof9

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third140Proof343 : runCachedNode 511 130775 Adaptive146Third140Node343 = false := by
  decide +kernel

#print axioms adaptive146Third140Proof343

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third140Proof301 : runCachedNode 511 130775 Adaptive146Third140Node301 = false := by
  decide +kernel

#print axioms adaptive146Third140Proof301

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third140Proof27 : runCachedNode 511 130775 Adaptive146Third140Node27 = false := by
  decide +kernel

#print axioms adaptive146Third140Proof27

end NineSeparatedSubsetSums
