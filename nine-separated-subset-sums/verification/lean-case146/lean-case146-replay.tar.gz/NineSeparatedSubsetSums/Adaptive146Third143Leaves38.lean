import NineSeparatedSubsetSums.Adaptive146Third143State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third143Proof252 : runCachedNode 511 131193 Adaptive146Third143Node252 = false := by
  decide +kernel

#print axioms adaptive146Third143Proof252

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third143Proof567 : runCachedNode 511 131193 Adaptive146Third143Node567 = false := by
  decide +kernel

#print axioms adaptive146Third143Proof567

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third143Proof666 : runCachedNode 511 131193 Adaptive146Third143Node666 = false := by
  decide +kernel

#print axioms adaptive146Third143Proof666

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third143Proof160 : runCachedNode 511 131193 Adaptive146Third143Node160 = false := by
  decide +kernel

#print axioms adaptive146Third143Proof160

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third143Proof187 : runCachedNode 511 131193 Adaptive146Third143Node187 = false := by
  decide +kernel

#print axioms adaptive146Third143Proof187

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third143Proof126 : runCachedNode 511 131193 Adaptive146Third143Node126 = false := by
  decide +kernel

#print axioms adaptive146Third143Proof126

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third143Proof253 : runCachedNode 511 131193 Adaptive146Third143Node253 = false := by
  decide +kernel

#print axioms adaptive146Third143Proof253

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third143Proof186 : runCachedNode 511 131193 Adaptive146Third143Node186 = false := by
  decide +kernel

#print axioms adaptive146Third143Proof186

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third143Proof566 : runCachedNode 511 131193 Adaptive146Third143Node566 = false := by
  decide +kernel

#print axioms adaptive146Third143Proof566

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third143Proof127 : runCachedNode 511 131193 Adaptive146Third143Node127 = false := by
  decide +kernel

#print axioms adaptive146Third143Proof127

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third143Proof157 : runCachedNode 511 131193 Adaptive146Third143Node157 = false := by
  decide +kernel

#print axioms adaptive146Third143Proof157

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third143Proof270 : runCachedNode 511 131193 Adaptive146Third143Node270 = false := by
  decide +kernel

#print axioms adaptive146Third143Proof270

end NineSeparatedSubsetSums
