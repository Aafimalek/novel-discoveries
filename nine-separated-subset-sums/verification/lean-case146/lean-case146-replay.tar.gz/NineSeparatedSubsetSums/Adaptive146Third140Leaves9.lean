import NineSeparatedSubsetSums.Adaptive146Third140State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third140Proof20 : runCachedNode 511 130775 Adaptive146Third140Node20 = false := by
  decide +kernel

#print axioms adaptive146Third140Proof20

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third140Proof97 : runCachedNode 511 130775 Adaptive146Third140Node97 = false := by
  decide +kernel

#print axioms adaptive146Third140Proof97

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third140Proof11 : runCachedNode 511 130775 Adaptive146Third140Node11 = false := by
  decide +kernel

#print axioms adaptive146Third140Proof11

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third140Proof286 : runCachedNode 511 130775 Adaptive146Third140Node286 = false := by
  decide +kernel

#print axioms adaptive146Third140Proof286

end NineSeparatedSubsetSums
