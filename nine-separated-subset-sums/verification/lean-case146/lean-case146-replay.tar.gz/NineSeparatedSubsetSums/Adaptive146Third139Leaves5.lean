import NineSeparatedSubsetSums.Adaptive146Third139State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third139Proof250 : runCachedNode 511 130638 Adaptive146Third139Node250 = false := by
  decide +kernel

#print axioms adaptive146Third139Proof250

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third139Proof185 : runCachedNode 511 130638 Adaptive146Third139Node185 = false := by
  decide +kernel

#print axioms adaptive146Third139Proof185

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third139Proof49 : runCachedNode 511 130638 Adaptive146Third139Node49 = false := by
  decide +kernel

#print axioms adaptive146Third139Proof49

end NineSeparatedSubsetSums
