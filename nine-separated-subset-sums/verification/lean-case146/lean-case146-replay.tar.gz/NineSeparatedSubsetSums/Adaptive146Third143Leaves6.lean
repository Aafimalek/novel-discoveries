import NineSeparatedSubsetSums.Adaptive146Third143State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third143Proof339 : runCachedNode 511 131193 Adaptive146Third143Node339 = false := by
  decide +kernel

#print axioms adaptive146Third143Proof339

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third143Proof413 : runCachedNode 511 131193 Adaptive146Third143Node413 = false := by
  decide +kernel

#print axioms adaptive146Third143Proof413

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third143Proof26 : runCachedNode 511 131193 Adaptive146Third143Node26 = false := by
  decide +kernel

#print axioms adaptive146Third143Proof26

end NineSeparatedSubsetSums
