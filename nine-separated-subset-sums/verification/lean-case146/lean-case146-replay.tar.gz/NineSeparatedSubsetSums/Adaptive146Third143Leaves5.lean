import NineSeparatedSubsetSums.Adaptive146Third143State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third143Proof264 : runCachedNode 511 131193 Adaptive146Third143Node264 = false := by
  decide +kernel

#print axioms adaptive146Third143Proof264

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third143Proof165 : runCachedNode 511 131193 Adaptive146Third143Node165 = false := by
  decide +kernel

#print axioms adaptive146Third143Proof165

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third143Proof56 : runCachedNode 511 131193 Adaptive146Third143Node56 = false := by
  decide +kernel

#print axioms adaptive146Third143Proof56

end NineSeparatedSubsetSums
