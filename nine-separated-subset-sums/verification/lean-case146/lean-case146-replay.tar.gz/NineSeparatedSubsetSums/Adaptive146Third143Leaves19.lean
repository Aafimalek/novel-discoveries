import NineSeparatedSubsetSums.Adaptive146Third143State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third143Proof671 : runCachedNode 511 131193 Adaptive146Third143Node671 = false := by
  decide +kernel

#print axioms adaptive146Third143Proof671

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third143Proof578 : runCachedNode 511 131193 Adaptive146Third143Node578 = false := by
  decide +kernel

#print axioms adaptive146Third143Proof578

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third143Proof579 : runCachedNode 511 131193 Adaptive146Third143Node579 = false := by
  decide +kernel

#print axioms adaptive146Third143Proof579

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third143Proof54 : runCachedNode 511 131193 Adaptive146Third143Node54 = false := by
  decide +kernel

#print axioms adaptive146Third143Proof54

end NineSeparatedSubsetSums
