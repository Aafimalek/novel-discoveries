import NineSeparatedSubsetSums.Adaptive146Third126State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third126Proof7 : runCachedNode 511 128058 Adaptive146Third126Node7 = false := by
  decide +kernel

#print axioms adaptive146Third126Proof7

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third126Proof6 : runCachedNode 511 128058 Adaptive146Third126Node6 = false := by
  decide +kernel

#print axioms adaptive146Third126Proof6

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third126Proof5 : runCachedNode 511 128058 Adaptive146Third126Node5 = false := by
  decide +kernel

#print axioms adaptive146Third126Proof5

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third126Proof4 : runCachedNode 511 128058 Adaptive146Third126Node4 = false := by
  decide +kernel

#print axioms adaptive146Third126Proof4

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third126Proof3 : runCachedNode 511 128058 Adaptive146Third126Node3 = false := by
  decide +kernel

#print axioms adaptive146Third126Proof3

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third126Proof1 : runCachedNode 511 128058 Adaptive146Third126Node1 = false := by
  decide +kernel

#print axioms adaptive146Third126Proof1

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third126Proof2 : runCachedNode 511 128058 Adaptive146Third126Node2 = false := by
  decide +kernel

#print axioms adaptive146Third126Proof2

end NineSeparatedSubsetSums
