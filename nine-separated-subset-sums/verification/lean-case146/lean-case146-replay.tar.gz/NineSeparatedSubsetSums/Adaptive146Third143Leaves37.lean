import NineSeparatedSubsetSums.Adaptive146Third143State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third143Proof406 : runCachedNode 511 131193 Adaptive146Third143Node406 = false := by
  decide +kernel

#print axioms adaptive146Third143Proof406

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third143Proof568 : runCachedNode 511 131193 Adaptive146Third143Node568 = false := by
  decide +kernel

#print axioms adaptive146Third143Proof568

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third143Proof569 : runCachedNode 511 131193 Adaptive146Third143Node569 = false := by
  decide +kernel

#print axioms adaptive146Third143Proof569

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third143Proof158 : runCachedNode 511 131193 Adaptive146Third143Node158 = false := by
  decide +kernel

#print axioms adaptive146Third143Proof158

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third143Proof188 : runCachedNode 511 131193 Adaptive146Third143Node188 = false := by
  decide +kernel

#print axioms adaptive146Third143Proof188

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third143Proof329 : runCachedNode 511 131193 Adaptive146Third143Node329 = false := by
  decide +kernel

#print axioms adaptive146Third143Proof329

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third143Proof304 : runCachedNode 511 131193 Adaptive146Third143Node304 = false := by
  decide +kernel

#print axioms adaptive146Third143Proof304

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third143Proof623 : runCachedNode 511 131193 Adaptive146Third143Node623 = false := by
  decide +kernel

#print axioms adaptive146Third143Proof623

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third143Proof46 : runCachedNode 511 131193 Adaptive146Third143Node46 = false := by
  decide +kernel

#print axioms adaptive146Third143Proof46

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third143Proof539 : runCachedNode 511 131193 Adaptive146Third143Node539 = false := by
  decide +kernel

#print axioms adaptive146Third143Proof539

end NineSeparatedSubsetSums
