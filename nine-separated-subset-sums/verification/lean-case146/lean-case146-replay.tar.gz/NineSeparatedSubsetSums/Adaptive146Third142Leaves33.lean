import NineSeparatedSubsetSums.Adaptive146Third142State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third142Proof45 : runCachedNode 511 131054 Adaptive146Third142Node45 = false := by
  decide +kernel

#print axioms adaptive146Third142Proof45

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third142Proof103 : runCachedNode 511 131054 Adaptive146Third142Node103 = false := by
  decide +kernel

#print axioms adaptive146Third142Proof103

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third142Proof234 : runCachedNode 511 131054 Adaptive146Third142Node234 = false := by
  decide +kernel

#print axioms adaptive146Third142Proof234

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third142Proof385 : runCachedNode 511 131054 Adaptive146Third142Node385 = false := by
  decide +kernel

#print axioms adaptive146Third142Proof385

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third142Proof437 : runCachedNode 511 131054 Adaptive146Third142Node437 = false := by
  decide +kernel

#print axioms adaptive146Third142Proof437

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third142Proof479 : runCachedNode 511 131054 Adaptive146Third142Node479 = false := by
  decide +kernel

#print axioms adaptive146Third142Proof479

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third142Proof74 : runCachedNode 511 131054 Adaptive146Third142Node74 = false := by
  decide +kernel

#print axioms adaptive146Third142Proof74

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third142Proof167 : runCachedNode 511 131054 Adaptive146Third142Node167 = false := by
  decide +kernel

#print axioms adaptive146Third142Proof167

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third142Proof195 : runCachedNode 511 131054 Adaptive146Third142Node195 = false := by
  decide +kernel

#print axioms adaptive146Third142Proof195

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third142Proof311 : runCachedNode 511 131054 Adaptive146Third142Node311 = false := by
  decide +kernel

#print axioms adaptive146Third142Proof311

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third142Proof360 : runCachedNode 511 131054 Adaptive146Third142Node360 = false := by
  decide +kernel

#print axioms adaptive146Third142Proof360

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third142Proof384 : runCachedNode 511 131054 Adaptive146Third142Node384 = false := by
  decide +kernel

#print axioms adaptive146Third142Proof384

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third142Proof131 : runCachedNode 511 131054 Adaptive146Third142Node131 = false := by
  decide +kernel

#print axioms adaptive146Third142Proof131

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third142Proof168 : runCachedNode 511 131054 Adaptive146Third142Node168 = false := by
  decide +kernel

#print axioms adaptive146Third142Proof168

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third142Proof312 : runCachedNode 511 131054 Adaptive146Third142Node312 = false := by
  decide +kernel

#print axioms adaptive146Third142Proof312

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third142Proof71 : runCachedNode 511 131054 Adaptive146Third142Node71 = false := by
  decide +kernel

#print axioms adaptive146Third142Proof71

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third142Proof283 : runCachedNode 511 131054 Adaptive146Third142Node283 = false := by
  decide +kernel

#print axioms adaptive146Third142Proof283

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third142Proof310 : runCachedNode 511 131054 Adaptive146Third142Node310 = false := by
  decide +kernel

#print axioms adaptive146Third142Proof310

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third142Proof10 : runCachedNode 511 131054 Adaptive146Third142Node10 = false := by
  decide +kernel

#print axioms adaptive146Third142Proof10

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third142Proof104 : runCachedNode 511 131054 Adaptive146Third142Node104 = false := by
  decide +kernel

#print axioms adaptive146Third142Proof104

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third142Proof224 : runCachedNode 511 131054 Adaptive146Third142Node224 = false := by
  decide +kernel

#print axioms adaptive146Third142Proof224

end NineSeparatedSubsetSums
