import NineSeparatedSubsetSums.Adaptive146Third132State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third132Proof19 : runCachedNode 511 129510 Adaptive146Third132Node19 = false := by
  decide +kernel

#print axioms adaptive146Third132Proof19

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third132Proof17 : runCachedNode 511 129510 Adaptive146Third132Node17 = false := by
  decide +kernel

#print axioms adaptive146Third132Proof17

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third132Proof3 : runCachedNode 511 129510 Adaptive146Third132Node3 = false := by
  decide +kernel

#print axioms adaptive146Third132Proof3

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third132Proof2 : runCachedNode 511 129510 Adaptive146Third132Node2 = false := by
  decide +kernel

#print axioms adaptive146Third132Proof2

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third132Proof1 : runCachedNode 511 129510 Adaptive146Third132Node1 = false := by
  decide +kernel

#print axioms adaptive146Third132Proof1

end NineSeparatedSubsetSums
