import NineSeparatedSubsetSums.Adaptive146Third140State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third140Proof345 : runCachedNode 511 130775 Adaptive146Third140Node345 = false := by
  decide +kernel

#print axioms adaptive146Third140Proof345

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third140Proof41 : runCachedNode 511 130775 Adaptive146Third140Node41 = false := by
  decide +kernel

#print axioms adaptive146Third140Proof41

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third140Proof89 : runCachedNode 511 130775 Adaptive146Third140Node89 = false := by
  decide +kernel

#print axioms adaptive146Third140Proof89

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third140Proof180 : runCachedNode 511 130775 Adaptive146Third140Node180 = false := by
  decide +kernel

#print axioms adaptive146Third140Proof180

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third140Proof238 : runCachedNode 511 130775 Adaptive146Third140Node238 = false := by
  decide +kernel

#print axioms adaptive146Third140Proof238

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third140Proof235 : runCachedNode 511 130775 Adaptive146Third140Node235 = false := by
  decide +kernel

#print axioms adaptive146Third140Proof235

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third140Proof67 : runCachedNode 511 130775 Adaptive146Third140Node67 = false := by
  decide +kernel

#print axioms adaptive146Third140Proof67

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third140Proof68 : runCachedNode 511 130775 Adaptive146Third140Node68 = false := by
  decide +kernel

#print axioms adaptive146Third140Proof68

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third140Proof273 : runCachedNode 511 130775 Adaptive146Third140Node273 = false := by
  decide +kernel

#print axioms adaptive146Third140Proof273

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third140Proof237 : runCachedNode 511 130775 Adaptive146Third140Node237 = false := by
  decide +kernel

#print axioms adaptive146Third140Proof237

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third140Proof86 : runCachedNode 511 130775 Adaptive146Third140Node86 = false := by
  decide +kernel

#print axioms adaptive146Third140Proof86

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third140Proof307 : runCachedNode 511 130775 Adaptive146Third140Node307 = false := by
  decide +kernel

#print axioms adaptive146Third140Proof307

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third140Proof119 : runCachedNode 511 130775 Adaptive146Third140Node119 = false := by
  decide +kernel

#print axioms adaptive146Third140Proof119

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third140Proof319 : runCachedNode 511 130775 Adaptive146Third140Node319 = false := by
  decide +kernel

#print axioms adaptive146Third140Proof319

end NineSeparatedSubsetSums
