import NineSeparatedSubsetSums.Adaptive146Third143State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third143Proof419 : runCachedNode 511 131193 Adaptive146Third143Node419 = false := by
  decide +kernel

#print axioms adaptive146Third143Proof419

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third143Proof197 : runCachedNode 511 131193 Adaptive146Third143Node197 = false := by
  decide +kernel

#print axioms adaptive146Third143Proof197

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third143Proof52 : runCachedNode 511 131193 Adaptive146Third143Node52 = false := by
  decide +kernel

#print axioms adaptive146Third143Proof52

end NineSeparatedSubsetSums
