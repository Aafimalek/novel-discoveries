import NineSeparatedSubsetSums.Adaptive146Third141State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third141Proof46 : runCachedNode 511 130916 Adaptive146Third141Node46 = false := by
  decide +kernel

#print axioms adaptive146Third141Proof46

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third141Proof76 : runCachedNode 511 130916 Adaptive146Third141Node76 = false := by
  decide +kernel

#print axioms adaptive146Third141Proof76

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third141Proof158 : runCachedNode 511 130916 Adaptive146Third141Node158 = false := by
  decide +kernel

#print axioms adaptive146Third141Proof158

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third141Proof192 : runCachedNode 511 130916 Adaptive146Third141Node192 = false := by
  decide +kernel

#print axioms adaptive146Third141Proof192

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third141Proof264 : runCachedNode 511 130916 Adaptive146Third141Node264 = false := by
  decide +kernel

#print axioms adaptive146Third141Proof264

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third141Proof262 : runCachedNode 511 130916 Adaptive146Third141Node262 = false := by
  decide +kernel

#print axioms adaptive146Third141Proof262

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third141Proof311 : runCachedNode 511 130916 Adaptive146Third141Node311 = false := by
  decide +kernel

#print axioms adaptive146Third141Proof311

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third141Proof226 : runCachedNode 511 130916 Adaptive146Third141Node226 = false := by
  decide +kernel

#print axioms adaptive146Third141Proof226

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third141Proof263 : runCachedNode 511 130916 Adaptive146Third141Node263 = false := by
  decide +kernel

#print axioms adaptive146Third141Proof263

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third141Proof43 : runCachedNode 511 130916 Adaptive146Third141Node43 = false := by
  decide +kernel

#print axioms adaptive146Third141Proof43

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third141Proof11 : runCachedNode 511 130916 Adaptive146Third141Node11 = false := by
  decide +kernel

#print axioms adaptive146Third141Proof11

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third141Proof38 : runCachedNode 511 130916 Adaptive146Third141Node38 = false := by
  decide +kernel

#print axioms adaptive146Third141Proof38

end NineSeparatedSubsetSums
