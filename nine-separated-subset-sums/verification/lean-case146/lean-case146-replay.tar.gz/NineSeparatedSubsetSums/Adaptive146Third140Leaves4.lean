import NineSeparatedSubsetSums.Adaptive146Third140State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third140Proof351 : runCachedNode 511 130775 Adaptive146Third140Node351 = false := by
  decide +kernel

#print axioms adaptive146Third140Proof351

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third140Proof124 : runCachedNode 511 130775 Adaptive146Third140Node124 = false := by
  decide +kernel

#print axioms adaptive146Third140Proof124

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third140Proof176 : runCachedNode 511 130775 Adaptive146Third140Node176 = false := by
  decide +kernel

#print axioms adaptive146Third140Proof176

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third140Proof285 : runCachedNode 511 130775 Adaptive146Third140Node285 = false := by
  decide +kernel

#print axioms adaptive146Third140Proof285

end NineSeparatedSubsetSums
