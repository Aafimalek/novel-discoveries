import NineSeparatedSubsetSums.Adaptive146Third140State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third140Proof183 : runCachedNode 511 130775 Adaptive146Third140Node183 = false := by
  decide +kernel

#print axioms adaptive146Third140Proof183

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third140Proof276 : runCachedNode 511 130775 Adaptive146Third140Node276 = false := by
  decide +kernel

#print axioms adaptive146Third140Proof276

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third140Proof123 : runCachedNode 511 130775 Adaptive146Third140Node123 = false := by
  decide +kernel

#print axioms adaptive146Third140Proof123

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third140Proof212 : runCachedNode 511 130775 Adaptive146Third140Node212 = false := by
  decide +kernel

#print axioms adaptive146Third140Proof212

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third140Proof182 : runCachedNode 511 130775 Adaptive146Third140Node182 = false := by
  decide +kernel

#print axioms adaptive146Third140Proof182

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third140Proof240 : runCachedNode 511 130775 Adaptive146Third140Node240 = false := by
  decide +kernel

#print axioms adaptive146Third140Proof240

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third140Proof39 : runCachedNode 511 130775 Adaptive146Third140Node39 = false := by
  decide +kernel

#print axioms adaptive146Third140Proof39

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third140Proof347 : runCachedNode 511 130775 Adaptive146Third140Node347 = false := by
  decide +kernel

#print axioms adaptive146Third140Proof347

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third140Proof374 : runCachedNode 511 130775 Adaptive146Third140Node374 = false := by
  decide +kernel

#print axioms adaptive146Third140Proof374

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third140Proof117 : runCachedNode 511 130775 Adaptive146Third140Node117 = false := by
  decide +kernel

#print axioms adaptive146Third140Proof117

end NineSeparatedSubsetSums
