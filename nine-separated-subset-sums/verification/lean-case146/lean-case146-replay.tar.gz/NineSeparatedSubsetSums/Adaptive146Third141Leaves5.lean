import NineSeparatedSubsetSums.Adaptive146Third141State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third141Proof22 : runCachedNode 511 130916 Adaptive146Third141Node22 = false := by
  decide +kernel

#print axioms adaptive146Third141Proof22

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third141Proof268 : runCachedNode 511 130916 Adaptive146Third141Node268 = false := by
  decide +kernel

#print axioms adaptive146Third141Proof268

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third141Proof59 : runCachedNode 511 130916 Adaptive146Third141Node59 = false := by
  decide +kernel

#print axioms adaptive146Third141Proof59

end NineSeparatedSubsetSums
