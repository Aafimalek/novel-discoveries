import NineSeparatedSubsetSums.Adaptive146Third141State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third141Proof74 : runCachedNode 511 130916 Adaptive146Third141Node74 = false := by
  decide +kernel

#print axioms adaptive146Third141Proof74

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third141Proof195 : runCachedNode 511 130916 Adaptive146Third141Node195 = false := by
  decide +kernel

#print axioms adaptive146Third141Proof195

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third141Proof75 : runCachedNode 511 130916 Adaptive146Third141Node75 = false := by
  decide +kernel

#print axioms adaptive146Third141Proof75

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third141Proof162 : runCachedNode 511 130916 Adaptive146Third141Node162 = false := by
  decide +kernel

#print axioms adaptive146Third141Proof162

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third141Proof265 : runCachedNode 511 130916 Adaptive146Third141Node265 = false := by
  decide +kernel

#print axioms adaptive146Third141Proof265

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third141Proof132 : runCachedNode 511 130916 Adaptive146Third141Node132 = false := by
  decide +kernel

#print axioms adaptive146Third141Proof132

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third141Proof230 : runCachedNode 511 130916 Adaptive146Third141Node230 = false := by
  decide +kernel

#print axioms adaptive146Third141Proof230

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third141Proof232 : runCachedNode 511 130916 Adaptive146Third141Node232 = false := by
  decide +kernel

#print axioms adaptive146Third141Proof232

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third141Proof3 : runCachedNode 511 130916 Adaptive146Third141Node3 = false := by
  decide +kernel

#print axioms adaptive146Third141Proof3

end NineSeparatedSubsetSums
