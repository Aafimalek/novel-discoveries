import NineSeparatedSubsetSums.Adaptive146Third141State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third141Proof163 : runCachedNode 511 130916 Adaptive146Third141Node163 = false := by
  decide +kernel

#print axioms adaptive146Third141Proof163

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third141Proof105 : runCachedNode 511 130916 Adaptive146Third141Node105 = false := by
  decide +kernel

#print axioms adaptive146Third141Proof105

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third141Proof16 : runCachedNode 511 130916 Adaptive146Third141Node16 = false := by
  decide +kernel

#print axioms adaptive146Third141Proof16

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third141Proof99 : runCachedNode 511 130916 Adaptive146Third141Node99 = false := by
  decide +kernel

#print axioms adaptive146Third141Proof99

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third141Proof241 : runCachedNode 511 130916 Adaptive146Third141Node241 = false := by
  decide +kernel

#print axioms adaptive146Third141Proof241

end NineSeparatedSubsetSums
