import NineSeparatedSubsetSums.Adaptive146Third113State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third113Proof0 : runCachedNode 511 112631 Adaptive146Third113Node0 = false := by
  decide +kernel

#print axioms adaptive146Third113Proof0

end NineSeparatedSubsetSums
