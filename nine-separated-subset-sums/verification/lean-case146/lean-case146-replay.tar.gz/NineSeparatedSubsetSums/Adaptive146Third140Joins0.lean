import NineSeparatedSubsetSums.Adaptive146Third140State
import NineSeparatedSubsetSums.Adaptive146Third140Leaves21
import NineSeparatedSubsetSums.Adaptive146Third140Leaves33
import NineSeparatedSubsetSums.Adaptive146Third140Leaves32
import NineSeparatedSubsetSums.Adaptive146Third140Leaves31
import NineSeparatedSubsetSums.Adaptive146Third140Leaves28
import NineSeparatedSubsetSums.Adaptive146Third140Leaves11
import NineSeparatedSubsetSums.Adaptive146Third140Leaves30
import NineSeparatedSubsetSums.Adaptive146Third140Leaves29
import NineSeparatedSubsetSums.Adaptive146Third140Leaves24
import NineSeparatedSubsetSums.Adaptive146Third140Leaves27
import NineSeparatedSubsetSums.Adaptive146Third140Leaves26
import NineSeparatedSubsetSums.Adaptive146Third140Leaves25
import NineSeparatedSubsetSums.Adaptive146Third140Leaves19
import NineSeparatedSubsetSums.Adaptive146Third140Leaves20
import NineSeparatedSubsetSums.Adaptive146Third140Leaves23
import NineSeparatedSubsetSums.Adaptive146Third140Leaves0
import NineSeparatedSubsetSums.Adaptive146Third140Leaves7
import NineSeparatedSubsetSums.Adaptive146Third140Leaves22
import NineSeparatedSubsetSums.Adaptive146Third140Leaves2
import NineSeparatedSubsetSums.Adaptive146Third140Leaves10
import NineSeparatedSubsetSums.Adaptive146Third140Leaves18
import NineSeparatedSubsetSums.Adaptive146Third140Leaves13
import NineSeparatedSubsetSums.Adaptive146Third140Leaves9
import NineSeparatedSubsetSums.Adaptive146Third140Leaves6
import NineSeparatedSubsetSums.Adaptive146Third140Leaves34
import NineSeparatedSubsetSums.Adaptive146Third140Leaves15
import NineSeparatedSubsetSums.Adaptive146Third140Leaves4
import NineSeparatedSubsetSums.Adaptive146Third140Leaves14
import NineSeparatedSubsetSums.Adaptive146Third140Leaves17
import NineSeparatedSubsetSums.Adaptive146Third140Leaves3
import NineSeparatedSubsetSums.Adaptive146Third140Leaves8
import NineSeparatedSubsetSums.Adaptive146Third140Leaves12
import NineSeparatedSubsetSums.Adaptive146Third140Leaves5

namespace NineSeparatedSubsetSums

theorem adaptive146Third140Proof22 : runCachedNode 511 130775 Adaptive146Third140Node22 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130775 Adaptive146Third140Node22 = [104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 123, 125, 126, 127, 129] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive146Third140Proof23
  · exact adaptive146Third140Proof24
  · exact adaptive146Third140Proof25
  · exact adaptive146Third140Proof26
  · exact adaptive146Third140Proof27
  · exact adaptive146Third140Proof28
  · exact adaptive146Third140Proof29
  · exact adaptive146Third140Proof30
  · exact adaptive146Third140Proof31
  · exact adaptive146Third140Proof32
  · exact adaptive146Third140Proof33
  · exact adaptive146Third140Proof34
  · exact adaptive146Third140Proof35
  · exact adaptive146Third140Proof36
  · exact adaptive146Third140Proof37
  · exact adaptive146Third140Proof38
  · exact adaptive146Third140Proof39
  · exact adaptive146Third140Proof40
  · exact adaptive146Third140Proof41
  · exact adaptive146Third140Proof42
  · exact adaptive146Third140Proof43
  · exact adaptive146Third140Proof44
  · exact adaptive146Third140Proof45

#print axioms adaptive146Third140Proof22

theorem adaptive146Third140Proof46 : runCachedNode 511 130775 Adaptive146Third140Node46 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130775 Adaptive146Third140Node46 = [103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 124, 126, 127, 128, 130] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive146Third140Proof47
  · exact adaptive146Third140Proof48
  · exact adaptive146Third140Proof49
  · exact adaptive146Third140Proof50
  · exact adaptive146Third140Proof51
  · exact adaptive146Third140Proof52
  · exact adaptive146Third140Proof53
  · exact adaptive146Third140Proof54
  · exact adaptive146Third140Proof55
  · exact adaptive146Third140Proof56
  · exact adaptive146Third140Proof57
  · exact adaptive146Third140Proof58
  · exact adaptive146Third140Proof59
  · exact adaptive146Third140Proof60
  · exact adaptive146Third140Proof61
  · exact adaptive146Third140Proof62
  · exact adaptive146Third140Proof63
  · exact adaptive146Third140Proof64
  · exact adaptive146Third140Proof65
  · exact adaptive146Third140Proof66
  · exact adaptive146Third140Proof67
  · exact adaptive146Third140Proof68
  · exact adaptive146Third140Proof69
  · exact adaptive146Third140Proof70
  · exact adaptive146Third140Proof71

#print axioms adaptive146Third140Proof46

theorem adaptive146Third140Proof72 : runCachedNode 511 130775 Adaptive146Third140Node72 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130775 Adaptive146Third140Node72 = [103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 125, 127, 128, 129, 131] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive146Third140Proof73
  · exact adaptive146Third140Proof74
  · exact adaptive146Third140Proof75
  · exact adaptive146Third140Proof76
  · exact adaptive146Third140Proof77
  · exact adaptive146Third140Proof78
  · exact adaptive146Third140Proof79
  · exact adaptive146Third140Proof80
  · exact adaptive146Third140Proof81
  · exact adaptive146Third140Proof82
  · exact adaptive146Third140Proof83
  · exact adaptive146Third140Proof84
  · exact adaptive146Third140Proof85
  · exact adaptive146Third140Proof86
  · exact adaptive146Third140Proof87
  · exact adaptive146Third140Proof88
  · exact adaptive146Third140Proof89
  · exact adaptive146Third140Proof90
  · exact adaptive146Third140Proof91
  · exact adaptive146Third140Proof92
  · exact adaptive146Third140Proof93
  · exact adaptive146Third140Proof94
  · exact adaptive146Third140Proof95
  · exact adaptive146Third140Proof96
  · exact adaptive146Third140Proof97
  · exact adaptive146Third140Proof98

#print axioms adaptive146Third140Proof72

theorem adaptive146Third140Proof99 : runCachedNode 511 130775 Adaptive146Third140Node99 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130775 Adaptive146Third140Node99 = [103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 126, 128, 129, 130, 132] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive146Third140Proof100
  · exact adaptive146Third140Proof101
  · exact adaptive146Third140Proof102
  · exact adaptive146Third140Proof103
  · exact adaptive146Third140Proof104
  · exact adaptive146Third140Proof105
  · exact adaptive146Third140Proof106
  · exact adaptive146Third140Proof107
  · exact adaptive146Third140Proof108
  · exact adaptive146Third140Proof109
  · exact adaptive146Third140Proof110
  · exact adaptive146Third140Proof111
  · exact adaptive146Third140Proof112
  · exact adaptive146Third140Proof113
  · exact adaptive146Third140Proof114
  · exact adaptive146Third140Proof115
  · exact adaptive146Third140Proof116
  · exact adaptive146Third140Proof117
  · exact adaptive146Third140Proof118
  · exact adaptive146Third140Proof119
  · exact adaptive146Third140Proof120
  · exact adaptive146Third140Proof121
  · exact adaptive146Third140Proof122
  · exact adaptive146Third140Proof123
  · exact adaptive146Third140Proof124
  · exact adaptive146Third140Proof125
  · exact adaptive146Third140Proof126

#print axioms adaptive146Third140Proof99

theorem adaptive146Third140Proof154 : runCachedNode 511 130775 Adaptive146Third140Node154 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130775 Adaptive146Third140Node154 = [93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 111, 112, 113, 114, 115, 117, 119, 120, 121, 123, 125, 127, 129] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive146Third140Proof155
  · exact adaptive146Third140Proof156
  · exact adaptive146Third140Proof157
  · exact adaptive146Third140Proof158
  · exact adaptive146Third140Proof159
  · exact adaptive146Third140Proof160
  · exact adaptive146Third140Proof161
  · exact adaptive146Third140Proof162
  · exact adaptive146Third140Proof163
  · exact adaptive146Third140Proof164
  · exact adaptive146Third140Proof165
  · exact adaptive146Third140Proof166
  · exact adaptive146Third140Proof167
  · exact adaptive146Third140Proof168
  · exact adaptive146Third140Proof169
  · exact adaptive146Third140Proof170
  · exact adaptive146Third140Proof171
  · exact adaptive146Third140Proof172
  · exact adaptive146Third140Proof173
  · exact adaptive146Third140Proof174
  · exact adaptive146Third140Proof175
  · exact adaptive146Third140Proof176
  · exact adaptive146Third140Proof177
  · exact adaptive146Third140Proof178
  · exact adaptive146Third140Proof179
  · exact adaptive146Third140Proof180
  · exact adaptive146Third140Proof181
  · exact adaptive146Third140Proof182
  · exact adaptive146Third140Proof183
  · exact adaptive146Third140Proof184

#print axioms adaptive146Third140Proof154

theorem adaptive146Third140Proof127 : runCachedNode 511 130775 Adaptive146Third140Node127 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130775 Adaptive146Third140Node127 = [102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 127, 129, 130, 131, 133] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive146Third140Proof128
  · exact adaptive146Third140Proof129
  · exact adaptive146Third140Proof130
  · exact adaptive146Third140Proof131
  · exact adaptive146Third140Proof132
  · exact adaptive146Third140Proof133
  · exact adaptive146Third140Proof134
  · exact adaptive146Third140Proof135
  · exact adaptive146Third140Proof136
  · exact adaptive146Third140Proof137
  · exact adaptive146Third140Proof138
  · exact adaptive146Third140Proof139
  · exact adaptive146Third140Proof140
  · exact adaptive146Third140Proof141
  · exact adaptive146Third140Proof142
  · exact adaptive146Third140Proof143
  · exact adaptive146Third140Proof144
  · exact adaptive146Third140Proof145
  · exact adaptive146Third140Proof146
  · exact adaptive146Third140Proof147
  · exact adaptive146Third140Proof148
  · exact adaptive146Third140Proof149
  · exact adaptive146Third140Proof150
  · exact adaptive146Third140Proof151
  · exact adaptive146Third140Proof152
  · exact adaptive146Third140Proof153
  · exact adaptive146Third140Proof154
  · exact adaptive146Third140Proof185
  · exact adaptive146Third140Proof186

#print axioms adaptive146Third140Proof127

theorem adaptive146Third140Proof187 : runCachedNode 511 130775 Adaptive146Third140Node187 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130775 Adaptive146Third140Node187 = [102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 128, 130, 131, 132, 134] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive146Third140Proof188
  · exact adaptive146Third140Proof189
  · exact adaptive146Third140Proof190
  · exact adaptive146Third140Proof191
  · exact adaptive146Third140Proof192
  · exact adaptive146Third140Proof193
  · exact adaptive146Third140Proof194
  · exact adaptive146Third140Proof195
  · exact adaptive146Third140Proof196
  · exact adaptive146Third140Proof197
  · exact adaptive146Third140Proof198
  · exact adaptive146Third140Proof199
  · exact adaptive146Third140Proof200
  · exact adaptive146Third140Proof201
  · exact adaptive146Third140Proof202
  · exact adaptive146Third140Proof203
  · exact adaptive146Third140Proof204
  · exact adaptive146Third140Proof205
  · exact adaptive146Third140Proof206
  · exact adaptive146Third140Proof207
  · exact adaptive146Third140Proof208
  · exact adaptive146Third140Proof209
  · exact adaptive146Third140Proof210
  · exact adaptive146Third140Proof211
  · exact adaptive146Third140Proof212
  · exact adaptive146Third140Proof213
  · exact adaptive146Third140Proof214
  · exact adaptive146Third140Proof215
  · exact adaptive146Third140Proof216
  · exact adaptive146Third140Proof217

#print axioms adaptive146Third140Proof187

theorem adaptive146Third140Proof247 : runCachedNode 511 130775 Adaptive146Third140Node247 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130775 Adaptive146Third140Node247 = [91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 115, 116, 117, 118, 119, 121, 123, 125, 127, 129, 131] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive146Third140Proof248
  · exact adaptive146Third140Proof249
  · exact adaptive146Third140Proof250
  · exact adaptive146Third140Proof251
  · exact adaptive146Third140Proof252
  · exact adaptive146Third140Proof253
  · exact adaptive146Third140Proof254
  · exact adaptive146Third140Proof255
  · exact adaptive146Third140Proof256
  · exact adaptive146Third140Proof257
  · exact adaptive146Third140Proof258
  · exact adaptive146Third140Proof259
  · exact adaptive146Third140Proof260
  · exact adaptive146Third140Proof261
  · exact adaptive146Third140Proof262
  · exact adaptive146Third140Proof263
  · exact adaptive146Third140Proof264
  · exact adaptive146Third140Proof265
  · exact adaptive146Third140Proof266
  · exact adaptive146Third140Proof267
  · exact adaptive146Third140Proof268
  · exact adaptive146Third140Proof269
  · exact adaptive146Third140Proof270
  · exact adaptive146Third140Proof271
  · exact adaptive146Third140Proof272
  · exact adaptive146Third140Proof273
  · exact adaptive146Third140Proof274
  · exact adaptive146Third140Proof275
  · exact adaptive146Third140Proof276
  · exact adaptive146Third140Proof277
  · exact adaptive146Third140Proof278
  · exact adaptive146Third140Proof279
  · exact adaptive146Third140Proof280
  · exact adaptive146Third140Proof281

#print axioms adaptive146Third140Proof247

end NineSeparatedSubsetSums
