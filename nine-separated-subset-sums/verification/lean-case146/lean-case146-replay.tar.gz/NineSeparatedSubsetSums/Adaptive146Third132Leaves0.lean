import NineSeparatedSubsetSums.Adaptive146Third132State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third132Proof21 : runCachedNode 511 129510 Adaptive146Third132Node21 = false := by
  decide +kernel

#print axioms adaptive146Third132Proof21

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third132Proof11 : runCachedNode 511 129510 Adaptive146Third132Node11 = false := by
  decide +kernel

#print axioms adaptive146Third132Proof11

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third132Proof4 : runCachedNode 511 129510 Adaptive146Third132Node4 = false := by
  decide +kernel

#print axioms adaptive146Third132Proof4

end NineSeparatedSubsetSums
