import NineSeparatedSubsetSums.Adaptive146Third143State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third143Proof262 : runCachedNode 511 131193 Adaptive146Third143Node262 = false := by
  decide +kernel

#print axioms adaptive146Third143Proof262

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third143Proof132 : runCachedNode 511 131193 Adaptive146Third143Node132 = false := by
  decide +kernel

#print axioms adaptive146Third143Proof132

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third143Proof1 : runCachedNode 511 131193 Adaptive146Third143Node1 = false := by
  decide +kernel

#print axioms adaptive146Third143Proof1

end NineSeparatedSubsetSums
