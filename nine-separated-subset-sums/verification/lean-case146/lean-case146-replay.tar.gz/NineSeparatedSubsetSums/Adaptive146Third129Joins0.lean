import NineSeparatedSubsetSums.Adaptive146Third129State
import NineSeparatedSubsetSums.Adaptive146Third129Leaves1
import NineSeparatedSubsetSums.Adaptive146Third129Leaves0
import NineSeparatedSubsetSums.Adaptive146Third129Leaves2

namespace NineSeparatedSubsetSums

theorem adaptive146Third129Proof0 : runCachedNode 511 128829 Adaptive146Third129Node0 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 128829 Adaptive146Third129Node0 = [110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 128] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive146Third129Proof1
  · exact adaptive146Third129Proof2
  · exact adaptive146Third129Proof3
  · exact adaptive146Third129Proof4
  · exact adaptive146Third129Proof5
  · exact adaptive146Third129Proof6
  · exact adaptive146Third129Proof7
  · exact adaptive146Third129Proof8
  · exact adaptive146Third129Proof9
  · exact adaptive146Third129Proof10
  · exact adaptive146Third129Proof11
  · exact adaptive146Third129Proof12
  · exact adaptive146Third129Proof13
  · exact adaptive146Third129Proof14
  · exact adaptive146Third129Proof15
  · exact adaptive146Third129Proof16
  · exact adaptive146Third129Proof17
  · exact adaptive146Third129Proof18

#print axioms adaptive146Third129Proof0

end NineSeparatedSubsetSums
