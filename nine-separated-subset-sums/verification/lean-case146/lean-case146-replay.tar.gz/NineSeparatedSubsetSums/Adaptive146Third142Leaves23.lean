import NineSeparatedSubsetSums.Adaptive146Third142State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third142Proof484 : runCachedNode 511 131054 Adaptive146Third142Node484 = false := by
  decide +kernel

#print axioms adaptive146Third142Proof484

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third142Proof82 : runCachedNode 511 131054 Adaptive146Third142Node82 = false := by
  decide +kernel

#print axioms adaptive146Third142Proof82

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third142Proof204 : runCachedNode 511 131054 Adaptive146Third142Node204 = false := by
  decide +kernel

#print axioms adaptive146Third142Proof204

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third142Proof113 : runCachedNode 511 131054 Adaptive146Third142Node113 = false := by
  decide +kernel

#print axioms adaptive146Third142Proof113

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third142Proof395 : runCachedNode 511 131054 Adaptive146Third142Node395 = false := by
  decide +kernel

#print axioms adaptive146Third142Proof395

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third142Proof229 : runCachedNode 511 131054 Adaptive146Third142Node229 = false := by
  decide +kernel

#print axioms adaptive146Third142Proof229

end NineSeparatedSubsetSums
