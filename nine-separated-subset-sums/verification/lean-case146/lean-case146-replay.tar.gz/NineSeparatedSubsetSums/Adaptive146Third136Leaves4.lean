import NineSeparatedSubsetSums.Adaptive146Third136State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third136Proof18 : runCachedNode 511 130191 Adaptive146Third136Node18 = false := by
  decide +kernel

#print axioms adaptive146Third136Proof18

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third136Proof15 : runCachedNode 511 130191 Adaptive146Third136Node15 = false := by
  decide +kernel

#print axioms adaptive146Third136Proof15

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third136Proof44 : runCachedNode 511 130191 Adaptive146Third136Node44 = false := by
  decide +kernel

#print axioms adaptive146Third136Proof44

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third136Proof30 : runCachedNode 511 130191 Adaptive146Third136Node30 = false := by
  decide +kernel

#print axioms adaptive146Third136Proof30

end NineSeparatedSubsetSums
