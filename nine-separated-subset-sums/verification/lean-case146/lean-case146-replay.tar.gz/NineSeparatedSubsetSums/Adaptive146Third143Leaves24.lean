import NineSeparatedSubsetSums.Adaptive146Third143State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third143Proof577 : runCachedNode 511 131193 Adaptive146Third143Node577 = false := by
  decide +kernel

#print axioms adaptive146Third143Proof577

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third143Proof227 : runCachedNode 511 131193 Adaptive146Third143Node227 = false := by
  decide +kernel

#print axioms adaptive146Third143Proof227

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third143Proof230 : runCachedNode 511 131193 Adaptive146Third143Node230 = false := by
  decide +kernel

#print axioms adaptive146Third143Proof230

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third143Proof192 : runCachedNode 511 131193 Adaptive146Third143Node192 = false := by
  decide +kernel

#print axioms adaptive146Third143Proof192

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third143Proof3 : runCachedNode 511 131193 Adaptive146Third143Node3 = false := by
  decide +kernel

#print axioms adaptive146Third143Proof3

end NineSeparatedSubsetSums
