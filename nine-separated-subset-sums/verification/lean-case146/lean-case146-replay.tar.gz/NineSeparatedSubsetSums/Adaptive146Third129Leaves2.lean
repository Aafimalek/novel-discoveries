import NineSeparatedSubsetSums.Adaptive146Third129State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third129Proof8 : runCachedNode 511 128829 Adaptive146Third129Node8 = false := by
  decide +kernel

#print axioms adaptive146Third129Proof8

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third129Proof7 : runCachedNode 511 128829 Adaptive146Third129Node7 = false := by
  decide +kernel

#print axioms adaptive146Third129Proof7

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third129Proof6 : runCachedNode 511 128829 Adaptive146Third129Node6 = false := by
  decide +kernel

#print axioms adaptive146Third129Proof6

end NineSeparatedSubsetSums
