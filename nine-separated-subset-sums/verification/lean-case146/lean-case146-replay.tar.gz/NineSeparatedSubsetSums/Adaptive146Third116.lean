import NineSeparatedSubsetSums.Adaptive146Third116Joins0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint146Checked

namespace NineSeparatedSubsetSums


theorem adaptive146Third116 : NoDescendingTailAfterThird 146 116 :=
  noDescendingThirdTail_of_cached 146 116 112631 (fun t ht nd => max148_second146_fourPoint_moment_bound (116::t) (by simp [ht]) nd) adaptive146Third116Proof0

#print axioms adaptive146Third116

end NineSeparatedSubsetSums
