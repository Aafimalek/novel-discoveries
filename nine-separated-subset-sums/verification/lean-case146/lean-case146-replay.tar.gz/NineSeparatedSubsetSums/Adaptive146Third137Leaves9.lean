import NineSeparatedSubsetSums.Adaptive146Third137State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third137Proof149 : runCachedNode 511 130354 Adaptive146Third137Node149 = false := by
  decide +kernel

#print axioms adaptive146Third137Proof149

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third137Proof180 : runCachedNode 511 130354 Adaptive146Third137Node180 = false := by
  decide +kernel

#print axioms adaptive146Third137Proof180

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third137Proof96 : runCachedNode 511 130354 Adaptive146Third137Node96 = false := by
  decide +kernel

#print axioms adaptive146Third137Proof96

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third137Proof95 : runCachedNode 511 130354 Adaptive146Third137Node95 = false := by
  decide +kernel

#print axioms adaptive146Third137Proof95

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third137Proof120 : runCachedNode 511 130354 Adaptive146Third137Node120 = false := by
  decide +kernel

#print axioms adaptive146Third137Proof120

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third137Proof176 : runCachedNode 511 130354 Adaptive146Third137Node176 = false := by
  decide +kernel

#print axioms adaptive146Third137Proof176

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third137Proof23 : runCachedNode 511 130354 Adaptive146Third137Node23 = false := by
  decide +kernel

#print axioms adaptive146Third137Proof23

end NineSeparatedSubsetSums
