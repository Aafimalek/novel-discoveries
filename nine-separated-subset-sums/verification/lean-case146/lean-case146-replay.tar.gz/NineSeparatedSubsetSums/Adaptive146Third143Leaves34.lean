import NineSeparatedSubsetSums.Adaptive146Third143State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third143Proof100 : runCachedNode 511 131193 Adaptive146Third143Node100 = false := by
  decide +kernel

#print axioms adaptive146Third143Proof100

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third143Proof73 : runCachedNode 511 131193 Adaptive146Third143Node73 = false := by
  decide +kernel

#print axioms adaptive146Third143Proof73

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third143Proof571 : runCachedNode 511 131193 Adaptive146Third143Node571 = false := by
  decide +kernel

#print axioms adaptive146Third143Proof571

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third143Proof456 : runCachedNode 511 131193 Adaptive146Third143Node456 = false := by
  decide +kernel

#print axioms adaptive146Third143Proof456

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third143Proof382 : runCachedNode 511 131193 Adaptive146Third143Node382 = false := by
  decide +kernel

#print axioms adaptive146Third143Proof382

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third143Proof45 : runCachedNode 511 131193 Adaptive146Third143Node45 = false := by
  decide +kernel

#print axioms adaptive146Third143Proof45

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third143Proof103 : runCachedNode 511 131193 Adaptive146Third143Node103 = false := by
  decide +kernel

#print axioms adaptive146Third143Proof103

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third143Proof63 : runCachedNode 511 131193 Adaptive146Third143Node63 = false := by
  decide +kernel

#print axioms adaptive146Third143Proof63

end NineSeparatedSubsetSums
