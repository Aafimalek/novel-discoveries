import NineSeparatedSubsetSums.Adaptive146Third143State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third143Proof22 : runCachedNode 511 131193 Adaptive146Third143Node22 = false := by
  decide +kernel

#print axioms adaptive146Third143Proof22

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third143Proof524 : runCachedNode 511 131193 Adaptive146Third143Node524 = false := by
  decide +kernel

#print axioms adaptive146Third143Proof524

end NineSeparatedSubsetSums
