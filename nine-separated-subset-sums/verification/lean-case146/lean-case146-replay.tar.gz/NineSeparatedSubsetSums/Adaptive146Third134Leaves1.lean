import NineSeparatedSubsetSums.Adaptive146Third134State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third134Proof20 : runCachedNode 511 129871 Adaptive146Third134Node20 = false := by
  decide +kernel

#print axioms adaptive146Third134Proof20

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third134Proof16 : runCachedNode 511 129871 Adaptive146Third134Node16 = false := by
  decide +kernel

#print axioms adaptive146Third134Proof16

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third134Proof59 : runCachedNode 511 129871 Adaptive146Third134Node59 = false := by
  decide +kernel

#print axioms adaptive146Third134Proof59

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third134Proof2 : runCachedNode 511 129871 Adaptive146Third134Node2 = false := by
  decide +kernel

#print axioms adaptive146Third134Proof2

end NineSeparatedSubsetSums
