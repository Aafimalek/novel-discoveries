import NineSeparatedSubsetSums.Adaptive146Third144State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third144Proof1112 : runCachedNode 511 131319 Adaptive146Third144Node1112 = false := by
  decide +kernel

#print axioms adaptive146Third144Proof1112

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third144Proof933 : runCachedNode 511 131319 Adaptive146Third144Node933 = false := by
  decide +kernel

#print axioms adaptive146Third144Proof933

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third144Proof90 : runCachedNode 511 131319 Adaptive146Third144Node90 = false := by
  decide +kernel

#print axioms adaptive146Third144Proof90

end NineSeparatedSubsetSums
