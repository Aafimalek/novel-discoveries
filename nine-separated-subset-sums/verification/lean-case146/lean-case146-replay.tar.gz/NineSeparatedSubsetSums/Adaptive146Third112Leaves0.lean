import NineSeparatedSubsetSums.Adaptive146Third112State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third112Proof0 : runCachedNode 511 112631 Adaptive146Third112Node0 = false := by
  decide +kernel

#print axioms adaptive146Third112Proof0

end NineSeparatedSubsetSums
