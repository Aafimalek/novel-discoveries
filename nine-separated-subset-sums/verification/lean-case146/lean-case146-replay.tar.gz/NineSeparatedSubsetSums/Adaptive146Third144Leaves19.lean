import NineSeparatedSubsetSums.Adaptive146Third144State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third144Proof1288 : runCachedNode 511 131319 Adaptive146Third144Node1288 = false := by
  decide +kernel

#print axioms adaptive146Third144Proof1288

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third144Proof217 : runCachedNode 511 131319 Adaptive146Third144Node217 = false := by
  decide +kernel

#print axioms adaptive146Third144Proof217

end NineSeparatedSubsetSums
