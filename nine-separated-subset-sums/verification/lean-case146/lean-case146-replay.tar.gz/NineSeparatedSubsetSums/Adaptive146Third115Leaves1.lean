import NineSeparatedSubsetSums.Adaptive146Third115State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third115Proof9 : runCachedNode 511 112631 Adaptive146Third115Node9 = false := by
  decide +kernel

#print axioms adaptive146Third115Proof9

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third115Proof8 : runCachedNode 511 112631 Adaptive146Third115Node8 = false := by
  decide +kernel

#print axioms adaptive146Third115Proof8

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third115Proof7 : runCachedNode 511 112631 Adaptive146Third115Node7 = false := by
  decide +kernel

#print axioms adaptive146Third115Proof7

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third115Proof6 : runCachedNode 511 112631 Adaptive146Third115Node6 = false := by
  decide +kernel

#print axioms adaptive146Third115Proof6

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third115Proof5 : runCachedNode 511 112631 Adaptive146Third115Node5 = false := by
  decide +kernel

#print axioms adaptive146Third115Proof5

end NineSeparatedSubsetSums
