import NineSeparatedSubsetSums.Adaptive146Third144State
import NineSeparatedSubsetSums.Adaptive146Third144Leaves133
import NineSeparatedSubsetSums.Adaptive146Third144Leaves134
import NineSeparatedSubsetSums.Adaptive146Third144Leaves132
import NineSeparatedSubsetSums.Adaptive146Third144Leaves130
import NineSeparatedSubsetSums.Adaptive146Third144Leaves128
import NineSeparatedSubsetSums.Adaptive146Third144Leaves126
import NineSeparatedSubsetSums.Adaptive146Third144Leaves124
import NineSeparatedSubsetSums.Adaptive146Third144Leaves123
import NineSeparatedSubsetSums.Adaptive146Third144Leaves122
import NineSeparatedSubsetSums.Adaptive146Third144Leaves120
import NineSeparatedSubsetSums.Adaptive146Third144Leaves118
import NineSeparatedSubsetSums.Adaptive146Third144Leaves115
import NineSeparatedSubsetSums.Adaptive146Third144Leaves112
import NineSeparatedSubsetSums.Adaptive146Third144Leaves113
import NineSeparatedSubsetSums.Adaptive146Third144Leaves114
import NineSeparatedSubsetSums.Adaptive146Third144Leaves116
import NineSeparatedSubsetSums.Adaptive146Third144Leaves111
import NineSeparatedSubsetSums.Adaptive146Third144Leaves108
import NineSeparatedSubsetSums.Adaptive146Third144Leaves107
import NineSeparatedSubsetSums.Adaptive146Third144Leaves100
import NineSeparatedSubsetSums.Adaptive146Third144Leaves93
import NineSeparatedSubsetSums.Adaptive146Third144Leaves87
import NineSeparatedSubsetSums.Adaptive146Third144Leaves81
import NineSeparatedSubsetSums.Adaptive146Third144Leaves67
import NineSeparatedSubsetSums.Adaptive146Third144Leaves26
import NineSeparatedSubsetSums.Adaptive146Third144Leaves127
import NineSeparatedSubsetSums.Adaptive146Third144Leaves117
import NineSeparatedSubsetSums.Adaptive146Third144Leaves106
import NineSeparatedSubsetSums.Adaptive146Third144Leaves105
import NineSeparatedSubsetSums.Adaptive146Third144Leaves103
import NineSeparatedSubsetSums.Adaptive146Third144Leaves104
import NineSeparatedSubsetSums.Adaptive146Third144Leaves102
import NineSeparatedSubsetSums.Adaptive146Third144Leaves101
import NineSeparatedSubsetSums.Adaptive146Third144Leaves95
import NineSeparatedSubsetSums.Adaptive146Third144Leaves89
import NineSeparatedSubsetSums.Adaptive146Third144Leaves86
import NineSeparatedSubsetSums.Adaptive146Third144Leaves48
import NineSeparatedSubsetSums.Adaptive146Third144Leaves73
import NineSeparatedSubsetSums.Adaptive146Third144Leaves66
import NineSeparatedSubsetSums.Adaptive146Third144Leaves60
import NineSeparatedSubsetSums.Adaptive146Third144Leaves33
import NineSeparatedSubsetSums.Adaptive146Third144Leaves31
import NineSeparatedSubsetSums.Adaptive146Third144Leaves125
import NineSeparatedSubsetSums.Adaptive146Third144Leaves2
import NineSeparatedSubsetSums.Adaptive146Third144Leaves90
import NineSeparatedSubsetSums.Adaptive146Third144Leaves84
import NineSeparatedSubsetSums.Adaptive146Third144Leaves82
import NineSeparatedSubsetSums.Adaptive146Third144Leaves74
import NineSeparatedSubsetSums.Adaptive146Third144Leaves76
import NineSeparatedSubsetSums.Adaptive146Third144Leaves65
import NineSeparatedSubsetSums.Adaptive146Third144Leaves69
import NineSeparatedSubsetSums.Adaptive146Third144Leaves54
import NineSeparatedSubsetSums.Adaptive146Third144Leaves64
import NineSeparatedSubsetSums.Adaptive146Third144Leaves42
import NineSeparatedSubsetSums.Adaptive146Third144Leaves15
import NineSeparatedSubsetSums.Adaptive146Third144Leaves23
import NineSeparatedSubsetSums.Adaptive146Third144Leaves46
import NineSeparatedSubsetSums.Adaptive146Third144Leaves0
import NineSeparatedSubsetSums.Adaptive146Third144Leaves13
import NineSeparatedSubsetSums.Adaptive146Third144Joins3
import NineSeparatedSubsetSums.Adaptive146Third144Leaves135
import NineSeparatedSubsetSums.Adaptive146Third144Leaves119
import NineSeparatedSubsetSums.Adaptive146Third144Leaves110
import NineSeparatedSubsetSums.Adaptive146Third144Leaves68
import NineSeparatedSubsetSums.Adaptive146Third144Leaves121
import NineSeparatedSubsetSums.Adaptive146Third144Leaves109
import NineSeparatedSubsetSums.Adaptive146Third144Leaves94
import NineSeparatedSubsetSums.Adaptive146Third144Leaves75
import NineSeparatedSubsetSums.Adaptive146Third144Leaves55
import NineSeparatedSubsetSums.Adaptive146Third144Leaves99
import NineSeparatedSubsetSums.Adaptive146Third144Leaves98
import NineSeparatedSubsetSums.Adaptive146Third144Leaves71
import NineSeparatedSubsetSums.Adaptive146Third144Leaves96
import NineSeparatedSubsetSums.Adaptive146Third144Leaves61
import NineSeparatedSubsetSums.Adaptive146Third144Leaves57
import NineSeparatedSubsetSums.Adaptive146Third144Leaves30
import NineSeparatedSubsetSums.Adaptive146Third144Leaves38
import NineSeparatedSubsetSums.Adaptive146Third144Leaves20
import NineSeparatedSubsetSums.Adaptive146Third144Leaves92
import NineSeparatedSubsetSums.Adaptive146Third144Leaves85
import NineSeparatedSubsetSums.Adaptive146Third144Leaves80
import NineSeparatedSubsetSums.Adaptive146Third144Leaves78
import NineSeparatedSubsetSums.Adaptive146Third144Leaves51
import NineSeparatedSubsetSums.Adaptive146Third144Leaves36
import NineSeparatedSubsetSums.Adaptive146Third144Leaves41
import NineSeparatedSubsetSums.Adaptive146Third144Leaves37
import NineSeparatedSubsetSums.Adaptive146Third144Leaves43
import NineSeparatedSubsetSums.Adaptive146Third144Leaves19
import NineSeparatedSubsetSums.Adaptive146Third144Leaves47
import NineSeparatedSubsetSums.Adaptive146Third144Leaves3
import NineSeparatedSubsetSums.Adaptive146Third144Leaves14

namespace NineSeparatedSubsetSums

theorem adaptive146Third144Proof1159 : runCachedNode 511 131319 Adaptive146Third144Node1159 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 131319 Adaptive146Third144Node1159 = [86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 130, 132] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive146Third144Proof1160
  · exact adaptive146Third144Proof1161
  · exact adaptive146Third144Proof1162
  · exact adaptive146Third144Proof1163
  · exact adaptive146Third144Proof1164
  · exact adaptive146Third144Proof1165
  · exact adaptive146Third144Proof1166
  · exact adaptive146Third144Proof1167
  · exact adaptive146Third144Proof1168
  · exact adaptive146Third144Proof1169
  · exact adaptive146Third144Proof1170
  · exact adaptive146Third144Proof1171
  · exact adaptive146Third144Proof1172
  · exact adaptive146Third144Proof1173
  · exact adaptive146Third144Proof1174
  · exact adaptive146Third144Proof1175
  · exact adaptive146Third144Proof1176
  · exact adaptive146Third144Proof1177
  · exact adaptive146Third144Proof1178
  · exact adaptive146Third144Proof1179
  · exact adaptive146Third144Proof1180
  · exact adaptive146Third144Proof1181
  · exact adaptive146Third144Proof1182
  · exact adaptive146Third144Proof1183
  · exact adaptive146Third144Proof1184
  · exact adaptive146Third144Proof1185
  · exact adaptive146Third144Proof1186
  · exact adaptive146Third144Proof1187
  · exact adaptive146Third144Proof1188
  · exact adaptive146Third144Proof1189
  · exact adaptive146Third144Proof1190
  · exact adaptive146Third144Proof1191
  · exact adaptive146Third144Proof1192
  · exact adaptive146Third144Proof1193
  · exact adaptive146Third144Proof1194
  · exact adaptive146Third144Proof1195
  · exact adaptive146Third144Proof1196
  · exact adaptive146Third144Proof1197
  · exact adaptive146Third144Proof1198
  · exact adaptive146Third144Proof1199
  · exact adaptive146Third144Proof1200
  · exact adaptive146Third144Proof1201
  · exact adaptive146Third144Proof1202
  · exact adaptive146Third144Proof1203
  · exact adaptive146Third144Proof1204

#print axioms adaptive146Third144Proof1159

theorem adaptive146Third144Proof1205 : runCachedNode 511 131319 Adaptive146Third144Node1205 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 131319 Adaptive146Third144Node1205 = [85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 132, 134] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive146Third144Proof1206
  · exact adaptive146Third144Proof1207
  · exact adaptive146Third144Proof1208
  · exact adaptive146Third144Proof1209
  · exact adaptive146Third144Proof1210
  · exact adaptive146Third144Proof1211
  · exact adaptive146Third144Proof1212
  · exact adaptive146Third144Proof1213
  · exact adaptive146Third144Proof1214
  · exact adaptive146Third144Proof1215
  · exact adaptive146Third144Proof1216
  · exact adaptive146Third144Proof1217
  · exact adaptive146Third144Proof1218
  · exact adaptive146Third144Proof1219
  · exact adaptive146Third144Proof1220
  · exact adaptive146Third144Proof1221
  · exact adaptive146Third144Proof1222
  · exact adaptive146Third144Proof1223
  · exact adaptive146Third144Proof1224
  · exact adaptive146Third144Proof1225
  · exact adaptive146Third144Proof1226
  · exact adaptive146Third144Proof1227
  · exact adaptive146Third144Proof1228
  · exact adaptive146Third144Proof1229
  · exact adaptive146Third144Proof1230
  · exact adaptive146Third144Proof1231
  · exact adaptive146Third144Proof1232
  · exact adaptive146Third144Proof1233
  · exact adaptive146Third144Proof1234
  · exact adaptive146Third144Proof1235
  · exact adaptive146Third144Proof1236
  · exact adaptive146Third144Proof1237
  · exact adaptive146Third144Proof1238
  · exact adaptive146Third144Proof1239
  · exact adaptive146Third144Proof1240
  · exact adaptive146Third144Proof1241
  · exact adaptive146Third144Proof1242
  · exact adaptive146Third144Proof1243
  · exact adaptive146Third144Proof1244
  · exact adaptive146Third144Proof1245
  · exact adaptive146Third144Proof1246
  · exact adaptive146Third144Proof1247
  · exact adaptive146Third144Proof1248
  · exact adaptive146Third144Proof1249
  · exact adaptive146Third144Proof1250
  · exact adaptive146Third144Proof1251
  · exact adaptive146Third144Proof1252
  · exact adaptive146Third144Proof1253

#print axioms adaptive146Third144Proof1205

theorem adaptive146Third144Proof1079 : runCachedNode 511 131319 Adaptive146Third144Node1079 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 131319 Adaptive146Third144Node1079 = [100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 132, 133, 134, 135, 136, 138, 140] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive146Third144Proof1080
  · exact adaptive146Third144Proof1081
  · exact adaptive146Third144Proof1082
  · exact adaptive146Third144Proof1083
  · exact adaptive146Third144Proof1084
  · exact adaptive146Third144Proof1085
  · exact adaptive146Third144Proof1086
  · exact adaptive146Third144Proof1087
  · exact adaptive146Third144Proof1088
  · exact adaptive146Third144Proof1089
  · exact adaptive146Third144Proof1090
  · exact adaptive146Third144Proof1091
  · exact adaptive146Third144Proof1092
  · exact adaptive146Third144Proof1093
  · exact adaptive146Third144Proof1094
  · exact adaptive146Third144Proof1095
  · exact adaptive146Third144Proof1096
  · exact adaptive146Third144Proof1097
  · exact adaptive146Third144Proof1098
  · exact adaptive146Third144Proof1099
  · exact adaptive146Third144Proof1100
  · exact adaptive146Third144Proof1101
  · exact adaptive146Third144Proof1102
  · exact adaptive146Third144Proof1103
  · exact adaptive146Third144Proof1104
  · exact adaptive146Third144Proof1105
  · exact adaptive146Third144Proof1106
  · exact adaptive146Third144Proof1107
  · exact adaptive146Third144Proof1108
  · exact adaptive146Third144Proof1109
  · exact adaptive146Third144Proof1110
  · exact adaptive146Third144Proof1111
  · exact adaptive146Third144Proof1112
  · exact adaptive146Third144Proof1113
  · exact adaptive146Third144Proof1114
  · exact adaptive146Third144Proof1115
  · exact adaptive146Third144Proof1116
  · exact adaptive146Third144Proof1159
  · exact adaptive146Third144Proof1205

#print axioms adaptive146Third144Proof1079

theorem adaptive146Third144Proof1292 : runCachedNode 511 131319 Adaptive146Third144Node1292 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 131319 Adaptive146Third144Node1292 = [86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 130] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive146Third144Proof1293
  · exact adaptive146Third144Proof1294
  · exact adaptive146Third144Proof1295
  · exact adaptive146Third144Proof1296
  · exact adaptive146Third144Proof1297
  · exact adaptive146Third144Proof1298
  · exact adaptive146Third144Proof1299
  · exact adaptive146Third144Proof1300
  · exact adaptive146Third144Proof1301
  · exact adaptive146Third144Proof1302
  · exact adaptive146Third144Proof1303
  · exact adaptive146Third144Proof1304
  · exact adaptive146Third144Proof1305
  · exact adaptive146Third144Proof1306
  · exact adaptive146Third144Proof1307
  · exact adaptive146Third144Proof1308
  · exact adaptive146Third144Proof1309
  · exact adaptive146Third144Proof1310
  · exact adaptive146Third144Proof1311
  · exact adaptive146Third144Proof1312
  · exact adaptive146Third144Proof1313
  · exact adaptive146Third144Proof1314
  · exact adaptive146Third144Proof1315
  · exact adaptive146Third144Proof1316
  · exact adaptive146Third144Proof1317
  · exact adaptive146Third144Proof1318
  · exact adaptive146Third144Proof1319
  · exact adaptive146Third144Proof1320
  · exact adaptive146Third144Proof1321
  · exact adaptive146Third144Proof1322
  · exact adaptive146Third144Proof1323
  · exact adaptive146Third144Proof1324
  · exact adaptive146Third144Proof1325
  · exact adaptive146Third144Proof1326
  · exact adaptive146Third144Proof1327
  · exact adaptive146Third144Proof1328
  · exact adaptive146Third144Proof1329
  · exact adaptive146Third144Proof1330
  · exact adaptive146Third144Proof1331
  · exact adaptive146Third144Proof1332
  · exact adaptive146Third144Proof1333
  · exact adaptive146Third144Proof1334
  · exact adaptive146Third144Proof1335
  · exact adaptive146Third144Proof1336

#print axioms adaptive146Third144Proof1292

theorem adaptive146Third144Proof1337 : runCachedNode 511 131319 Adaptive146Third144Node1337 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 131319 Adaptive146Third144Node1337 = [86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 131] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive146Third144Proof1338
  · exact adaptive146Third144Proof1339
  · exact adaptive146Third144Proof1340
  · exact adaptive146Third144Proof1341
  · exact adaptive146Third144Proof1342
  · exact adaptive146Third144Proof1343
  · exact adaptive146Third144Proof1344
  · exact adaptive146Third144Proof1345
  · exact adaptive146Third144Proof1346
  · exact adaptive146Third144Proof1347
  · exact adaptive146Third144Proof1348
  · exact adaptive146Third144Proof1349
  · exact adaptive146Third144Proof1350
  · exact adaptive146Third144Proof1351
  · exact adaptive146Third144Proof1352
  · exact adaptive146Third144Proof1353
  · exact adaptive146Third144Proof1354
  · exact adaptive146Third144Proof1355
  · exact adaptive146Third144Proof1356
  · exact adaptive146Third144Proof1357
  · exact adaptive146Third144Proof1358
  · exact adaptive146Third144Proof1359
  · exact adaptive146Third144Proof1360
  · exact adaptive146Third144Proof1361
  · exact adaptive146Third144Proof1362
  · exact adaptive146Third144Proof1363
  · exact adaptive146Third144Proof1364
  · exact adaptive146Third144Proof1365
  · exact adaptive146Third144Proof1366
  · exact adaptive146Third144Proof1367
  · exact adaptive146Third144Proof1368
  · exact adaptive146Third144Proof1369
  · exact adaptive146Third144Proof1370
  · exact adaptive146Third144Proof1371
  · exact adaptive146Third144Proof1372
  · exact adaptive146Third144Proof1373
  · exact adaptive146Third144Proof1374
  · exact adaptive146Third144Proof1375
  · exact adaptive146Third144Proof1376
  · exact adaptive146Third144Proof1377
  · exact adaptive146Third144Proof1378
  · exact adaptive146Third144Proof1379
  · exact adaptive146Third144Proof1380
  · exact adaptive146Third144Proof1381
  · exact adaptive146Third144Proof1382

#print axioms adaptive146Third144Proof1337

theorem adaptive146Third144Proof1383 : runCachedNode 511 131319 Adaptive146Third144Node1383 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 131319 Adaptive146Third144Node1383 = [85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 132] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive146Third144Proof1384
  · exact adaptive146Third144Proof1385
  · exact adaptive146Third144Proof1386
  · exact adaptive146Third144Proof1387
  · exact adaptive146Third144Proof1388
  · exact adaptive146Third144Proof1389
  · exact adaptive146Third144Proof1390
  · exact adaptive146Third144Proof1391
  · exact adaptive146Third144Proof1392
  · exact adaptive146Third144Proof1393
  · exact adaptive146Third144Proof1394
  · exact adaptive146Third144Proof1395
  · exact adaptive146Third144Proof1396
  · exact adaptive146Third144Proof1397
  · exact adaptive146Third144Proof1398
  · exact adaptive146Third144Proof1399
  · exact adaptive146Third144Proof1400
  · exact adaptive146Third144Proof1401
  · exact adaptive146Third144Proof1402
  · exact adaptive146Third144Proof1403
  · exact adaptive146Third144Proof1404
  · exact adaptive146Third144Proof1405
  · exact adaptive146Third144Proof1406
  · exact adaptive146Third144Proof1407
  · exact adaptive146Third144Proof1408
  · exact adaptive146Third144Proof1409
  · exact adaptive146Third144Proof1410
  · exact adaptive146Third144Proof1411
  · exact adaptive146Third144Proof1412
  · exact adaptive146Third144Proof1413
  · exact adaptive146Third144Proof1414
  · exact adaptive146Third144Proof1415
  · exact adaptive146Third144Proof1416
  · exact adaptive146Third144Proof1417
  · exact adaptive146Third144Proof1418
  · exact adaptive146Third144Proof1419
  · exact adaptive146Third144Proof1420
  · exact adaptive146Third144Proof1421
  · exact adaptive146Third144Proof1422
  · exact adaptive146Third144Proof1423
  · exact adaptive146Third144Proof1424
  · exact adaptive146Third144Proof1425
  · exact adaptive146Third144Proof1426
  · exact adaptive146Third144Proof1427
  · exact adaptive146Third144Proof1428
  · exact adaptive146Third144Proof1429
  · exact adaptive146Third144Proof1430

#print axioms adaptive146Third144Proof1383

theorem adaptive146Third144Proof1431 : runCachedNode 511 131319 Adaptive146Third144Node1431 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 131319 Adaptive146Third144Node1431 = [85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 132, 134] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive146Third144Proof1432
  · exact adaptive146Third144Proof1433
  · exact adaptive146Third144Proof1434
  · exact adaptive146Third144Proof1435
  · exact adaptive146Third144Proof1436
  · exact adaptive146Third144Proof1437
  · exact adaptive146Third144Proof1438
  · exact adaptive146Third144Proof1439
  · exact adaptive146Third144Proof1440
  · exact adaptive146Third144Proof1441
  · exact adaptive146Third144Proof1442
  · exact adaptive146Third144Proof1443
  · exact adaptive146Third144Proof1444
  · exact adaptive146Third144Proof1445
  · exact adaptive146Third144Proof1446
  · exact adaptive146Third144Proof1447
  · exact adaptive146Third144Proof1448
  · exact adaptive146Third144Proof1449
  · exact adaptive146Third144Proof1450
  · exact adaptive146Third144Proof1451
  · exact adaptive146Third144Proof1452
  · exact adaptive146Third144Proof1453
  · exact adaptive146Third144Proof1454
  · exact adaptive146Third144Proof1455
  · exact adaptive146Third144Proof1456
  · exact adaptive146Third144Proof1457
  · exact adaptive146Third144Proof1458
  · exact adaptive146Third144Proof1459
  · exact adaptive146Third144Proof1460
  · exact adaptive146Third144Proof1461
  · exact adaptive146Third144Proof1462
  · exact adaptive146Third144Proof1463
  · exact adaptive146Third144Proof1464
  · exact adaptive146Third144Proof1465
  · exact adaptive146Third144Proof1466
  · exact adaptive146Third144Proof1467
  · exact adaptive146Third144Proof1468
  · exact adaptive146Third144Proof1469
  · exact adaptive146Third144Proof1470
  · exact adaptive146Third144Proof1471
  · exact adaptive146Third144Proof1472
  · exact adaptive146Third144Proof1473
  · exact adaptive146Third144Proof1474
  · exact adaptive146Third144Proof1475
  · exact adaptive146Third144Proof1476
  · exact adaptive146Third144Proof1477
  · exact adaptive146Third144Proof1478
  · exact adaptive146Third144Proof1479
  · exact adaptive146Third144Proof1480

#print axioms adaptive146Third144Proof1431

theorem adaptive146Third144Proof1254 : runCachedNode 511 131319 Adaptive146Third144Node1254 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 131319 Adaptive146Third144Node1254 = [99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 132, 133, 134, 135, 136, 137, 138, 140] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive146Third144Proof1255
  · exact adaptive146Third144Proof1256
  · exact adaptive146Third144Proof1257
  · exact adaptive146Third144Proof1258
  · exact adaptive146Third144Proof1259
  · exact adaptive146Third144Proof1260
  · exact adaptive146Third144Proof1261
  · exact adaptive146Third144Proof1262
  · exact adaptive146Third144Proof1263
  · exact adaptive146Third144Proof1264
  · exact adaptive146Third144Proof1265
  · exact adaptive146Third144Proof1266
  · exact adaptive146Third144Proof1267
  · exact adaptive146Third144Proof1268
  · exact adaptive146Third144Proof1269
  · exact adaptive146Third144Proof1270
  · exact adaptive146Third144Proof1271
  · exact adaptive146Third144Proof1272
  · exact adaptive146Third144Proof1273
  · exact adaptive146Third144Proof1274
  · exact adaptive146Third144Proof1275
  · exact adaptive146Third144Proof1276
  · exact adaptive146Third144Proof1277
  · exact adaptive146Third144Proof1278
  · exact adaptive146Third144Proof1279
  · exact adaptive146Third144Proof1280
  · exact adaptive146Third144Proof1281
  · exact adaptive146Third144Proof1282
  · exact adaptive146Third144Proof1283
  · exact adaptive146Third144Proof1284
  · exact adaptive146Third144Proof1285
  · exact adaptive146Third144Proof1286
  · exact adaptive146Third144Proof1287
  · exact adaptive146Third144Proof1288
  · exact adaptive146Third144Proof1289
  · exact adaptive146Third144Proof1290
  · exact adaptive146Third144Proof1291
  · exact adaptive146Third144Proof1292
  · exact adaptive146Third144Proof1337
  · exact adaptive146Third144Proof1383
  · exact adaptive146Third144Proof1431

#print axioms adaptive146Third144Proof1254

end NineSeparatedSubsetSums
