import NineSeparatedSubsetSums.Adaptive146Third143State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third143Proof259 : runCachedNode 511 131193 Adaptive146Third143Node259 = false := by
  decide +kernel

#print axioms adaptive146Third143Proof259

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third143Proof670 : runCachedNode 511 131193 Adaptive146Third143Node670 = false := by
  decide +kernel

#print axioms adaptive146Third143Proof670

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third143Proof544 : runCachedNode 511 131193 Adaptive146Third143Node544 = false := by
  decide +kernel

#print axioms adaptive146Third143Proof544

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third143Proof333 : runCachedNode 511 131193 Adaptive146Third143Node333 = false := by
  decide +kernel

#print axioms adaptive146Third143Proof333

end NineSeparatedSubsetSums
