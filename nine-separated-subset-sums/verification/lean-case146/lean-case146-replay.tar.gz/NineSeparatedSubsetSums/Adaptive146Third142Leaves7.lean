import NineSeparatedSubsetSums.Adaptive146Third142State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third142Proof246 : runCachedNode 511 131054 Adaptive146Third142Node246 = false := by
  decide +kernel

#print axioms adaptive146Third142Proof246

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third142Proof79 : runCachedNode 511 131054 Adaptive146Third142Node79 = false := by
  decide +kernel

#print axioms adaptive146Third142Proof79

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third142Proof36 : runCachedNode 511 131054 Adaptive146Third142Node36 = false := by
  decide +kernel

#print axioms adaptive146Third142Proof36

end NineSeparatedSubsetSums
