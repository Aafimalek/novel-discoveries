import NineSeparatedSubsetSums.Adaptive146Third141State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third141Proof238 : runCachedNode 511 130916 Adaptive146Third141Node238 = false := by
  decide +kernel

#print axioms adaptive146Third141Proof238

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third141Proof77 : runCachedNode 511 130916 Adaptive146Third141Node77 = false := by
  decide +kernel

#print axioms adaptive146Third141Proof77

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third141Proof4 : runCachedNode 511 130916 Adaptive146Third141Node4 = false := by
  decide +kernel

#print axioms adaptive146Third141Proof4

end NineSeparatedSubsetSums
