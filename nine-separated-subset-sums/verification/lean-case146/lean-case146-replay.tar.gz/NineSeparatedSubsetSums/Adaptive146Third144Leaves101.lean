import NineSeparatedSubsetSums.Adaptive146Third144State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third144Proof1456 : runCachedNode 511 131319 Adaptive146Third144Node1456 = false := by
  decide +kernel

#print axioms adaptive146Third144Proof1456

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third144Proof56 : runCachedNode 511 131319 Adaptive146Third144Node56 = false := by
  decide +kernel

#print axioms adaptive146Third144Proof56

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third144Proof549 : runCachedNode 511 131319 Adaptive146Third144Node549 = false := by
  decide +kernel

#print axioms adaptive146Third144Proof549

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third144Proof815 : runCachedNode 511 131319 Adaptive146Third144Node815 = false := by
  decide +kernel

#print axioms adaptive146Third144Proof815

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third144Proof101 : runCachedNode 511 131319 Adaptive146Third144Node101 = false := by
  decide +kernel

#print axioms adaptive146Third144Proof101

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third144Proof743 : runCachedNode 511 131319 Adaptive146Third144Node743 = false := by
  decide +kernel

#print axioms adaptive146Third144Proof743

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third144Proof9 : runCachedNode 511 131319 Adaptive146Third144Node9 = false := by
  decide +kernel

#print axioms adaptive146Third144Proof9

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third144Proof1241 : runCachedNode 511 131319 Adaptive146Third144Node1241 = false := by
  decide +kernel

#print axioms adaptive146Third144Proof1241

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third144Proof1243 : runCachedNode 511 131319 Adaptive146Third144Node1243 = false := by
  decide +kernel

#print axioms adaptive146Third144Proof1243

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third144Proof1468 : runCachedNode 511 131319 Adaptive146Third144Node1468 = false := by
  decide +kernel

#print axioms adaptive146Third144Proof1468

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third144Proof820 : runCachedNode 511 131319 Adaptive146Third144Node820 = false := by
  decide +kernel

#print axioms adaptive146Third144Proof820

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third144Proof926 : runCachedNode 511 131319 Adaptive146Third144Node926 = false := by
  decide +kernel

#print axioms adaptive146Third144Proof926

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third144Proof1026 : runCachedNode 511 131319 Adaptive146Third144Node1026 = false := by
  decide +kernel

#print axioms adaptive146Third144Proof1026

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third144Proof520 : runCachedNode 511 131319 Adaptive146Third144Node520 = false := by
  decide +kernel

#print axioms adaptive146Third144Proof520

end NineSeparatedSubsetSums
