import NineSeparatedSubsetSums.Adaptive146Third144State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third144Proof313 : runCachedNode 511 131319 Adaptive146Third144Node313 = false := by
  decide +kernel

#print axioms adaptive146Third144Proof313

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third144Proof248 : runCachedNode 511 131319 Adaptive146Third144Node248 = false := by
  decide +kernel

#print axioms adaptive146Third144Proof248

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third144Proof41 : runCachedNode 511 131319 Adaptive146Third144Node41 = false := by
  decide +kernel

#print axioms adaptive146Third144Proof41

end NineSeparatedSubsetSums
