import NineSeparatedSubsetSums.Adaptive146Third141State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third141Proof159 : runCachedNode 511 130916 Adaptive146Third141Node159 = false := by
  decide +kernel

#print axioms adaptive146Third141Proof159

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third141Proof193 : runCachedNode 511 130916 Adaptive146Third141Node193 = false := by
  decide +kernel

#print axioms adaptive146Third141Proof193

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third141Proof42 : runCachedNode 511 130916 Adaptive146Third141Node42 = false := by
  decide +kernel

#print axioms adaptive146Third141Proof42

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third141Proof260 : runCachedNode 511 130916 Adaptive146Third141Node260 = false := by
  decide +kernel

#print axioms adaptive146Third141Proof260

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third141Proof71 : runCachedNode 511 130916 Adaptive146Third141Node71 = false := by
  decide +kernel

#print axioms adaptive146Third141Proof71

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third141Proof227 : runCachedNode 511 130916 Adaptive146Third141Node227 = false := by
  decide +kernel

#print axioms adaptive146Third141Proof227

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third141Proof96 : runCachedNode 511 130916 Adaptive146Third141Node96 = false := by
  decide +kernel

#print axioms adaptive146Third141Proof96

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third141Proof69 : runCachedNode 511 130916 Adaptive146Third141Node69 = false := by
  decide +kernel

#print axioms adaptive146Third141Proof69

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third141Proof261 : runCachedNode 511 130916 Adaptive146Third141Node261 = false := by
  decide +kernel

#print axioms adaptive146Third141Proof261

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third141Proof157 : runCachedNode 511 130916 Adaptive146Third141Node157 = false := by
  decide +kernel

#print axioms adaptive146Third141Proof157

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third141Proof310 : runCachedNode 511 130916 Adaptive146Third141Node310 = false := by
  decide +kernel

#print axioms adaptive146Third141Proof310

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third141Proof97 : runCachedNode 511 130916 Adaptive146Third141Node97 = false := by
  decide +kernel

#print axioms adaptive146Third141Proof97

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third141Proof190 : runCachedNode 511 130916 Adaptive146Third141Node190 = false := by
  decide +kernel

#print axioms adaptive146Third141Proof190

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third141Proof191 : runCachedNode 511 130916 Adaptive146Third141Node191 = false := by
  decide +kernel

#print axioms adaptive146Third141Proof191

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third141Proof41 : runCachedNode 511 130916 Adaptive146Third141Node41 = false := by
  decide +kernel

#print axioms adaptive146Third141Proof41

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third141Proof275 : runCachedNode 511 130916 Adaptive146Third141Node275 = false := by
  decide +kernel

#print axioms adaptive146Third141Proof275

end NineSeparatedSubsetSums
