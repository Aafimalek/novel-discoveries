import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive146Third121Node0 : CachedSearchNode :=
  ⟨4, 120, computeCenteredMask [148,146,121], 415, 57861⟩

end NineSeparatedSubsetSums
