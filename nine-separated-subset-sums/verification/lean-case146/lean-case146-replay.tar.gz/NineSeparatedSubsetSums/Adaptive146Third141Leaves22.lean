import NineSeparatedSubsetSums.Adaptive146Third141State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third141Proof78 : runCachedNode 511 130916 Adaptive146Third141Node78 = false := by
  decide +kernel

#print axioms adaptive146Third141Proof78

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third141Proof136 : runCachedNode 511 130916 Adaptive146Third141Node136 = false := by
  decide +kernel

#print axioms adaptive146Third141Proof136

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third141Proof15 : runCachedNode 511 130916 Adaptive146Third141Node15 = false := by
  decide +kernel

#print axioms adaptive146Third141Proof15

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third141Proof271 : runCachedNode 511 130916 Adaptive146Third141Node271 = false := by
  decide +kernel

#print axioms adaptive146Third141Proof271

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third141Proof70 : runCachedNode 511 130916 Adaptive146Third141Node70 = false := by
  decide +kernel

#print axioms adaptive146Third141Proof70

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third141Proof242 : runCachedNode 511 130916 Adaptive146Third141Node242 = false := by
  decide +kernel

#print axioms adaptive146Third141Proof242

end NineSeparatedSubsetSums
