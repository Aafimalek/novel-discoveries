import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive146Third122Node0 : CachedSearchNode :=
  ⟨4, 121, computeCenteredMask [148,146,122], 416, 58104⟩

end NineSeparatedSubsetSums
