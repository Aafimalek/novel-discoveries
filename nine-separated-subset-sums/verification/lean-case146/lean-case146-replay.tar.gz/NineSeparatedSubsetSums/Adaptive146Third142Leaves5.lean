import NineSeparatedSubsetSums.Adaptive146Third142State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third142Proof22 : runCachedNode 511 131054 Adaptive146Third142Node22 = false := by
  decide +kernel

#print axioms adaptive146Third142Proof22

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third142Proof15 : runCachedNode 511 131054 Adaptive146Third142Node15 = false := by
  decide +kernel

#print axioms adaptive146Third142Proof15

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third142Proof34 : runCachedNode 511 131054 Adaptive146Third142Node34 = false := by
  decide +kernel

#print axioms adaptive146Third142Proof34

end NineSeparatedSubsetSums
