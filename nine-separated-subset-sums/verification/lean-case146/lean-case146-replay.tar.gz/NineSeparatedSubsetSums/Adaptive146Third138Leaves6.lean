import NineSeparatedSubsetSums.Adaptive146Third138State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third138Proof183 : runCachedNode 511 130484 Adaptive146Third138Node183 = false := by
  decide +kernel

#print axioms adaptive146Third138Proof183

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third138Proof181 : runCachedNode 511 130484 Adaptive146Third138Node181 = false := by
  decide +kernel

#print axioms adaptive146Third138Proof181

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third138Proof178 : runCachedNode 511 130484 Adaptive146Third138Node178 = false := by
  decide +kernel

#print axioms adaptive146Third138Proof178

end NineSeparatedSubsetSums
