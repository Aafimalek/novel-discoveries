import NineSeparatedSubsetSums.Adaptive146Third139State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third139Proof246 : runCachedNode 511 130638 Adaptive146Third139Node246 = false := by
  decide +kernel

#print axioms adaptive146Third139Proof246

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third139Proof248 : runCachedNode 511 130638 Adaptive146Third139Node248 = false := by
  decide +kernel

#print axioms adaptive146Third139Proof248

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third139Proof187 : runCachedNode 511 130638 Adaptive146Third139Node187 = false := by
  decide +kernel

#print axioms adaptive146Third139Proof187

end NineSeparatedSubsetSums
