import NineSeparatedSubsetSums.Adaptive146Third139State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third139Proof152 : runCachedNode 511 130638 Adaptive146Third139Node152 = false := by
  decide +kernel

#print axioms adaptive146Third139Proof152

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third139Proof125 : runCachedNode 511 130638 Adaptive146Third139Node125 = false := by
  decide +kernel

#print axioms adaptive146Third139Proof125

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third139Proof64 : runCachedNode 511 130638 Adaptive146Third139Node64 = false := by
  decide +kernel

#print axioms adaptive146Third139Proof64

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third139Proof73 : runCachedNode 511 130638 Adaptive146Third139Node73 = false := by
  decide +kernel

#print axioms adaptive146Third139Proof73

end NineSeparatedSubsetSums
