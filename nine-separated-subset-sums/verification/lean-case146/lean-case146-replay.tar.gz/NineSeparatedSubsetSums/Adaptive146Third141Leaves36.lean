import NineSeparatedSubsetSums.Adaptive146Third141State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third141Proof279 : runCachedNode 511 130916 Adaptive146Third141Node279 = false := by
  decide +kernel

#print axioms adaptive146Third141Proof279

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third141Proof280 : runCachedNode 511 130916 Adaptive146Third141Node280 = false := by
  decide +kernel

#print axioms adaptive146Third141Proof280

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third141Proof281 : runCachedNode 511 130916 Adaptive146Third141Node281 = false := by
  decide +kernel

#print axioms adaptive146Third141Proof281

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third141Proof282 : runCachedNode 511 130916 Adaptive146Third141Node282 = false := by
  decide +kernel

#print axioms adaptive146Third141Proof282

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third141Proof283 : runCachedNode 511 130916 Adaptive146Third141Node283 = false := by
  decide +kernel

#print axioms adaptive146Third141Proof283

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third141Proof284 : runCachedNode 511 130916 Adaptive146Third141Node284 = false := by
  decide +kernel

#print axioms adaptive146Third141Proof284

end NineSeparatedSubsetSums
