import NineSeparatedSubsetSums.Adaptive146Third140State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third140Proof385 : runCachedNode 511 130775 Adaptive146Third140Node385 = false := by
  decide +kernel

#print axioms adaptive146Third140Proof385

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third140Proof243 : runCachedNode 511 130775 Adaptive146Third140Node243 = false := by
  decide +kernel

#print axioms adaptive146Third140Proof243

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third140Proof91 : runCachedNode 511 130775 Adaptive146Third140Node91 = false := by
  decide +kernel

#print axioms adaptive146Third140Proof91

end NineSeparatedSubsetSums
