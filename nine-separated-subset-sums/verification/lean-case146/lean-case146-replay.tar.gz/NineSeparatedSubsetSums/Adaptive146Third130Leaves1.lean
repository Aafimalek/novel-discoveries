import NineSeparatedSubsetSums.Adaptive146Third130State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third130Proof18 : runCachedNode 511 129031 Adaptive146Third130Node18 = false := by
  decide +kernel

#print axioms adaptive146Third130Proof18

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third130Proof16 : runCachedNode 511 129031 Adaptive146Third130Node16 = false := by
  decide +kernel

#print axioms adaptive146Third130Proof16

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third130Proof15 : runCachedNode 511 129031 Adaptive146Third130Node15 = false := by
  decide +kernel

#print axioms adaptive146Third130Proof15

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third130Proof13 : runCachedNode 511 129031 Adaptive146Third130Node13 = false := by
  decide +kernel

#print axioms adaptive146Third130Proof13

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third130Proof5 : runCachedNode 511 129031 Adaptive146Third130Node5 = false := by
  decide +kernel

#print axioms adaptive146Third130Proof5

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third130Proof1 : runCachedNode 511 129031 Adaptive146Third130Node1 = false := by
  decide +kernel

#print axioms adaptive146Third130Proof1

end NineSeparatedSubsetSums
