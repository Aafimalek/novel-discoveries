import NineSeparatedSubsetSums.Adaptive146Third143State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third143Proof384 : runCachedNode 511 131193 Adaptive146Third143Node384 = false := by
  decide +kernel

#print axioms adaptive146Third143Proof384

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third143Proof336 : runCachedNode 511 131193 Adaptive146Third143Node336 = false := by
  decide +kernel

#print axioms adaptive146Third143Proof336

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third143Proof191 : runCachedNode 511 131193 Adaptive146Third143Node191 = false := by
  decide +kernel

#print axioms adaptive146Third143Proof191

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third143Proof414 : runCachedNode 511 131193 Adaptive146Third143Node414 = false := by
  decide +kernel

#print axioms adaptive146Third143Proof414

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third143Proof287 : runCachedNode 511 131193 Adaptive146Third143Node287 = false := by
  decide +kernel

#print axioms adaptive146Third143Proof287

end NineSeparatedSubsetSums
