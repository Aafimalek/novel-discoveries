import NineSeparatedSubsetSums.Adaptive146Third132State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third132Proof16 : runCachedNode 511 129510 Adaptive146Third132Node16 = false := by
  decide +kernel

#print axioms adaptive146Third132Proof16

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third132Proof15 : runCachedNode 511 129510 Adaptive146Third132Node15 = false := by
  decide +kernel

#print axioms adaptive146Third132Proof15

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third132Proof14 : runCachedNode 511 129510 Adaptive146Third132Node14 = false := by
  decide +kernel

#print axioms adaptive146Third132Proof14

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third132Proof13 : runCachedNode 511 129510 Adaptive146Third132Node13 = false := by
  decide +kernel

#print axioms adaptive146Third132Proof13

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third132Proof10 : runCachedNode 511 129510 Adaptive146Third132Node10 = false := by
  decide +kernel

#print axioms adaptive146Third132Proof10

end NineSeparatedSubsetSums
