import NineSeparatedSubsetSums.Adaptive146Third141State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third141Proof108 : runCachedNode 511 130916 Adaptive146Third141Node108 = false := by
  decide +kernel

#print axioms adaptive146Third141Proof108

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third141Proof235 : runCachedNode 511 130916 Adaptive146Third141Node235 = false := by
  decide +kernel

#print axioms adaptive146Third141Proof235

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third141Proof133 : runCachedNode 511 130916 Adaptive146Third141Node133 = false := by
  decide +kernel

#print axioms adaptive146Third141Proof133

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third141Proof2 : runCachedNode 511 130916 Adaptive146Third141Node2 = false := by
  decide +kernel

#print axioms adaptive146Third141Proof2

end NineSeparatedSubsetSums
