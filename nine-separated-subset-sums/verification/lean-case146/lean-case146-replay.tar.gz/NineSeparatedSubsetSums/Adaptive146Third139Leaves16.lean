import NineSeparatedSubsetSums.Adaptive146Third139State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third139Proof41 : runCachedNode 511 130638 Adaptive146Third139Node41 = false := by
  decide +kernel

#print axioms adaptive146Third139Proof41

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third139Proof243 : runCachedNode 511 130638 Adaptive146Third139Node243 = false := by
  decide +kernel

#print axioms adaptive146Third139Proof243

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third139Proof92 : runCachedNode 511 130638 Adaptive146Third139Node92 = false := by
  decide +kernel

#print axioms adaptive146Third139Proof92

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third139Proof43 : runCachedNode 511 130638 Adaptive146Third139Node43 = false := by
  decide +kernel

#print axioms adaptive146Third139Proof43

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third139Proof69 : runCachedNode 511 130638 Adaptive146Third139Node69 = false := by
  decide +kernel

#print axioms adaptive146Third139Proof69

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third139Proof12 : runCachedNode 511 130638 Adaptive146Third139Node12 = false := by
  decide +kernel

#print axioms adaptive146Third139Proof12

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third139Proof121 : runCachedNode 511 130638 Adaptive146Third139Node121 = false := by
  decide +kernel

#print axioms adaptive146Third139Proof121

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third139Proof83 : runCachedNode 511 130638 Adaptive146Third139Node83 = false := by
  decide +kernel

#print axioms adaptive146Third139Proof83

end NineSeparatedSubsetSums
