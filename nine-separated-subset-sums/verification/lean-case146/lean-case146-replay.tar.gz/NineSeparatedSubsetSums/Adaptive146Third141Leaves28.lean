import NineSeparatedSubsetSums.Adaptive146Third141State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third141Proof313 : runCachedNode 511 130916 Adaptive146Third141Node313 = false := by
  decide +kernel

#print axioms adaptive146Third141Proof313

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third141Proof73 : runCachedNode 511 130916 Adaptive146Third141Node73 = false := by
  decide +kernel

#print axioms adaptive146Third141Proof73

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third141Proof194 : runCachedNode 511 130916 Adaptive146Third141Node194 = false := by
  decide +kernel

#print axioms adaptive146Third141Proof194

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third141Proof229 : runCachedNode 511 130916 Adaptive146Third141Node229 = false := by
  decide +kernel

#print axioms adaptive146Third141Proof229

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third141Proof228 : runCachedNode 511 130916 Adaptive146Third141Node228 = false := by
  decide +kernel

#print axioms adaptive146Third141Proof228

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third141Proof12 : runCachedNode 511 130916 Adaptive146Third141Node12 = false := by
  decide +kernel

#print axioms adaptive146Third141Proof12

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third141Proof72 : runCachedNode 511 130916 Adaptive146Third141Node72 = false := by
  decide +kernel

#print axioms adaptive146Third141Proof72

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third141Proof130 : runCachedNode 511 130916 Adaptive146Third141Node130 = false := by
  decide +kernel

#print axioms adaptive146Third141Proof130

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third141Proof160 : runCachedNode 511 130916 Adaptive146Third141Node160 = false := by
  decide +kernel

#print axioms adaptive146Third141Proof160

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third141Proof52 : runCachedNode 511 130916 Adaptive146Third141Node52 = false := by
  decide +kernel

#print axioms adaptive146Third141Proof52

end NineSeparatedSubsetSums
