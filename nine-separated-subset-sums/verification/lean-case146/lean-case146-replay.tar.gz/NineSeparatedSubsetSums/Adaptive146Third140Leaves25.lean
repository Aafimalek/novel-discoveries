import NineSeparatedSubsetSums.Adaptive146Third140State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third140Proof375 : runCachedNode 511 130775 Adaptive146Third140Node375 = false := by
  decide +kernel

#print axioms adaptive146Third140Proof375

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third140Proof120 : runCachedNode 511 130775 Adaptive146Third140Node120 = false := by
  decide +kernel

#print axioms adaptive146Third140Proof120

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third140Proof88 : runCachedNode 511 130775 Adaptive146Third140Node88 = false := by
  decide +kernel

#print axioms adaptive146Third140Proof88

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third140Proof42 : runCachedNode 511 130775 Adaptive146Third140Node42 = false := by
  decide +kernel

#print axioms adaptive146Third140Proof42

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third140Proof147 : runCachedNode 511 130775 Adaptive146Third140Node147 = false := by
  decide +kernel

#print axioms adaptive146Third140Proof147

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third140Proof348 : runCachedNode 511 130775 Adaptive146Third140Node348 = false := by
  decide +kernel

#print axioms adaptive146Third140Proof348

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third140Proof269 : runCachedNode 511 130775 Adaptive146Third140Node269 = false := by
  decide +kernel

#print axioms adaptive146Third140Proof269

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third140Proof121 : runCachedNode 511 130775 Adaptive146Third140Node121 = false := by
  decide +kernel

#print axioms adaptive146Third140Proof121

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third140Proof175 : runCachedNode 511 130775 Adaptive146Third140Node175 = false := by
  decide +kernel

#print axioms adaptive146Third140Proof175

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third140Proof208 : runCachedNode 511 130775 Adaptive146Third140Node208 = false := by
  decide +kernel

#print axioms adaptive146Third140Proof208

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third140Proof66 : runCachedNode 511 130775 Adaptive146Third140Node66 = false := by
  decide +kernel

#print axioms adaptive146Third140Proof66

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third140Proof56 : runCachedNode 511 130775 Adaptive146Third140Node56 = false := by
  decide +kernel

#print axioms adaptive146Third140Proof56

end NineSeparatedSubsetSums
