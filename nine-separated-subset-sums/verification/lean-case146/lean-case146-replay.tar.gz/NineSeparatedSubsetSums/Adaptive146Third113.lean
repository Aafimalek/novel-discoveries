import NineSeparatedSubsetSums.Adaptive146Third113Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint146Checked

namespace NineSeparatedSubsetSums


theorem adaptive146Third113 : NoDescendingTailAfterThird 146 113 :=
  noDescendingThirdTail_of_cached 146 113 112631 (fun t ht nd => max148_second146_fourPoint_moment_bound (113::t) (by simp [ht]) nd) adaptive146Third113Proof0

#print axioms adaptive146Third113

end NineSeparatedSubsetSums
