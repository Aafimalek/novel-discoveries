import NineSeparatedSubsetSums.Adaptive146Third141State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third141Proof101 : runCachedNode 511 130916 Adaptive146Third141Node101 = false := by
  decide +kernel

#print axioms adaptive146Third141Proof101

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third141Proof50 : runCachedNode 511 130916 Adaptive146Third141Node50 = false := by
  decide +kernel

#print axioms adaptive146Third141Proof50

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third141Proof134 : runCachedNode 511 130916 Adaptive146Third141Node134 = false := by
  decide +kernel

#print axioms adaptive146Third141Proof134

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third141Proof45 : runCachedNode 511 130916 Adaptive146Third141Node45 = false := by
  decide +kernel

#print axioms adaptive146Third141Proof45

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third141Proof269 : runCachedNode 511 130916 Adaptive146Third141Node269 = false := by
  decide +kernel

#print axioms adaptive146Third141Proof269

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third141Proof137 : runCachedNode 511 130916 Adaptive146Third141Node137 = false := by
  decide +kernel

#print axioms adaptive146Third141Proof137

end NineSeparatedSubsetSums
