import NineSeparatedSubsetSums.Adaptive146Third132State
import NineSeparatedSubsetSums.Adaptive146Third132Leaves1
import NineSeparatedSubsetSums.Adaptive146Third132Leaves0
import NineSeparatedSubsetSums.Adaptive146Third132Leaves4
import NineSeparatedSubsetSums.Adaptive146Third132Leaves3
import NineSeparatedSubsetSums.Adaptive146Third132Leaves2

namespace NineSeparatedSubsetSums

theorem adaptive146Third132Proof0 : runCachedNode 511 129510 Adaptive146Third132Node0 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 129510 Adaptive146Third132Node0 = [110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 131] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive146Third132Proof1
  · exact adaptive146Third132Proof2
  · exact adaptive146Third132Proof3
  · exact adaptive146Third132Proof4
  · exact adaptive146Third132Proof5
  · exact adaptive146Third132Proof6
  · exact adaptive146Third132Proof7
  · exact adaptive146Third132Proof8
  · exact adaptive146Third132Proof9
  · exact adaptive146Third132Proof10
  · exact adaptive146Third132Proof11
  · exact adaptive146Third132Proof12
  · exact adaptive146Third132Proof13
  · exact adaptive146Third132Proof14
  · exact adaptive146Third132Proof15
  · exact adaptive146Third132Proof16
  · exact adaptive146Third132Proof17
  · exact adaptive146Third132Proof18
  · exact adaptive146Third132Proof19
  · exact adaptive146Third132Proof20
  · exact adaptive146Third132Proof21

#print axioms adaptive146Third132Proof0

end NineSeparatedSubsetSums
