import NineSeparatedSubsetSums.Adaptive146Third138State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third138Proof216 : runCachedNode 511 130484 Adaptive146Third138Node216 = false := by
  decide +kernel

#print axioms adaptive146Third138Proof216

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third138Proof212 : runCachedNode 511 130484 Adaptive146Third138Node212 = false := by
  decide +kernel

#print axioms adaptive146Third138Proof212

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third138Proof172 : runCachedNode 511 130484 Adaptive146Third138Node172 = false := by
  decide +kernel

#print axioms adaptive146Third138Proof172

end NineSeparatedSubsetSums
