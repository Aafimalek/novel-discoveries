import NineSeparatedSubsetSums.Adaptive146Third133State
import NineSeparatedSubsetSums.Adaptive146Third133Leaves4
import NineSeparatedSubsetSums.Adaptive146Third133Leaves0
import NineSeparatedSubsetSums.Adaptive146Third133Leaves5
import NineSeparatedSubsetSums.Adaptive146Third133Leaves1
import NineSeparatedSubsetSums.Adaptive146Third133Leaves2
import NineSeparatedSubsetSums.Adaptive146Third133Leaves3

namespace NineSeparatedSubsetSums

theorem adaptive146Third133Proof22 : runCachedNode 511 129683 Adaptive146Third133Node22 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 129683 Adaptive146Third133Node22 = [104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 118, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive146Third133Proof23
  · exact adaptive146Third133Proof24
  · exact adaptive146Third133Proof25
  · exact adaptive146Third133Proof26
  · exact adaptive146Third133Proof27
  · exact adaptive146Third133Proof28
  · exact adaptive146Third133Proof29
  · exact adaptive146Third133Proof30
  · exact adaptive146Third133Proof31
  · exact adaptive146Third133Proof32
  · exact adaptive146Third133Proof33
  · exact adaptive146Third133Proof34
  · exact adaptive146Third133Proof35
  · exact adaptive146Third133Proof36
  · exact adaptive146Third133Proof37
  · exact adaptive146Third133Proof38
  · exact adaptive146Third133Proof39
  · exact adaptive146Third133Proof40
  · exact adaptive146Third133Proof41
  · exact adaptive146Third133Proof42
  · exact adaptive146Third133Proof43
  · exact adaptive146Third133Proof44
  · exact adaptive146Third133Proof45
  · exact adaptive146Third133Proof46

#print axioms adaptive146Third133Proof22

theorem adaptive146Third133Proof0 : runCachedNode 511 129683 Adaptive146Third133Node0 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 129683 Adaptive146Third133Node0 = [110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 132] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive146Third133Proof1
  · exact adaptive146Third133Proof2
  · exact adaptive146Third133Proof3
  · exact adaptive146Third133Proof4
  · exact adaptive146Third133Proof5
  · exact adaptive146Third133Proof6
  · exact adaptive146Third133Proof7
  · exact adaptive146Third133Proof8
  · exact adaptive146Third133Proof9
  · exact adaptive146Third133Proof10
  · exact adaptive146Third133Proof11
  · exact adaptive146Third133Proof12
  · exact adaptive146Third133Proof13
  · exact adaptive146Third133Proof14
  · exact adaptive146Third133Proof15
  · exact adaptive146Third133Proof16
  · exact adaptive146Third133Proof17
  · exact adaptive146Third133Proof18
  · exact adaptive146Third133Proof19
  · exact adaptive146Third133Proof20
  · exact adaptive146Third133Proof21
  · exact adaptive146Third133Proof22

#print axioms adaptive146Third133Proof0

end NineSeparatedSubsetSums
