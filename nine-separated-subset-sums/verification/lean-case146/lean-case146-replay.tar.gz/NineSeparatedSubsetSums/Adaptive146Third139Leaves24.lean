import NineSeparatedSubsetSums.Adaptive146Third139State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third139Proof158 : runCachedNode 511 130638 Adaptive146Third139Node158 = false := by
  decide +kernel

#print axioms adaptive146Third139Proof158

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third139Proof159 : runCachedNode 511 130638 Adaptive146Third139Node159 = false := by
  decide +kernel

#print axioms adaptive146Third139Proof159

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third139Proof72 : runCachedNode 511 130638 Adaptive146Third139Node72 = false := by
  decide +kernel

#print axioms adaptive146Third139Proof72

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third139Proof99 : runCachedNode 511 130638 Adaptive146Third139Node99 = false := by
  decide +kernel

#print axioms adaptive146Third139Proof99

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third139Proof127 : runCachedNode 511 130638 Adaptive146Third139Node127 = false := by
  decide +kernel

#print axioms adaptive146Third139Proof127

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third139Proof128 : runCachedNode 511 130638 Adaptive146Third139Node128 = false := by
  decide +kernel

#print axioms adaptive146Third139Proof128

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third139Proof156 : runCachedNode 511 130638 Adaptive146Third139Node156 = false := by
  decide +kernel

#print axioms adaptive146Third139Proof156

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third139Proof157 : runCachedNode 511 130638 Adaptive146Third139Node157 = false := by
  decide +kernel

#print axioms adaptive146Third139Proof157

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third139Proof189 : runCachedNode 511 130638 Adaptive146Third139Node189 = false := by
  decide +kernel

#print axioms adaptive146Third139Proof189

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third139Proof190 : runCachedNode 511 130638 Adaptive146Third139Node190 = false := by
  decide +kernel

#print axioms adaptive146Third139Proof190

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third139Proof221 : runCachedNode 511 130638 Adaptive146Third139Node221 = false := by
  decide +kernel

#print axioms adaptive146Third139Proof221

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third139Proof188 : runCachedNode 511 130638 Adaptive146Third139Node188 = false := by
  decide +kernel

#print axioms adaptive146Third139Proof188

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third139Proof219 : runCachedNode 511 130638 Adaptive146Third139Node219 = false := by
  decide +kernel

#print axioms adaptive146Third139Proof219

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third139Proof220 : runCachedNode 511 130638 Adaptive146Third139Node220 = false := by
  decide +kernel

#print axioms adaptive146Third139Proof220

end NineSeparatedSubsetSums
