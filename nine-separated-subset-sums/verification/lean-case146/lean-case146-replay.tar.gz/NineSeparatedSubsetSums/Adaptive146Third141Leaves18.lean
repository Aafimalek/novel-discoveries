import NineSeparatedSubsetSums.Adaptive146Third141State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third141Proof199 : runCachedNode 511 130916 Adaptive146Third141Node199 = false := by
  decide +kernel

#print axioms adaptive146Third141Proof199

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third141Proof103 : runCachedNode 511 130916 Adaptive146Third141Node103 = false := by
  decide +kernel

#print axioms adaptive146Third141Proof103

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third141Proof197 : runCachedNode 511 130916 Adaptive146Third141Node197 = false := by
  decide +kernel

#print axioms adaptive146Third141Proof197

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third141Proof150 : runCachedNode 511 130916 Adaptive146Third141Node150 = false := by
  decide +kernel

#print axioms adaptive146Third141Proof150

end NineSeparatedSubsetSums
