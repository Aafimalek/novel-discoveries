import NineSeparatedSubsetSums.Adaptive146Third139State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third139Proof214 : runCachedNode 511 130638 Adaptive146Third139Node214 = false := by
  decide +kernel

#print axioms adaptive146Third139Proof214

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third139Proof244 : runCachedNode 511 130638 Adaptive146Third139Node244 = false := by
  decide +kernel

#print axioms adaptive146Third139Proof244

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third139Proof212 : runCachedNode 511 130638 Adaptive146Third139Node212 = false := by
  decide +kernel

#print axioms adaptive146Third139Proof212

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third139Proof14 : runCachedNode 511 130638 Adaptive146Third139Node14 = false := by
  decide +kernel

#print axioms adaptive146Third139Proof14

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third139Proof123 : runCachedNode 511 130638 Adaptive146Third139Node123 = false := by
  decide +kernel

#print axioms adaptive146Third139Proof123

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third139Proof53 : runCachedNode 511 130638 Adaptive146Third139Node53 = false := by
  decide +kernel

#print axioms adaptive146Third139Proof53

end NineSeparatedSubsetSums
