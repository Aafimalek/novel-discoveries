import NineSeparatedSubsetSums.Adaptive146Third130State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third130Proof19 : runCachedNode 511 129031 Adaptive146Third130Node19 = false := by
  decide +kernel

#print axioms adaptive146Third130Proof19

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third130Proof17 : runCachedNode 511 129031 Adaptive146Third130Node17 = false := by
  decide +kernel

#print axioms adaptive146Third130Proof17

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third130Proof2 : runCachedNode 511 129031 Adaptive146Third130Node2 = false := by
  decide +kernel

#print axioms adaptive146Third130Proof2

end NineSeparatedSubsetSums
