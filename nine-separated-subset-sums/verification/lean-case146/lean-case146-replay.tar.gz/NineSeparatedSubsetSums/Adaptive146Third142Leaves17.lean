import NineSeparatedSubsetSums.Adaptive146Third142State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third142Proof400 : runCachedNode 511 131054 Adaptive146Third142Node400 = false := by
  decide +kernel

#print axioms adaptive146Third142Proof400

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third142Proof486 : runCachedNode 511 131054 Adaptive146Third142Node486 = false := by
  decide +kernel

#print axioms adaptive146Third142Proof486

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third142Proof114 : runCachedNode 511 131054 Adaptive146Third142Node114 = false := by
  decide +kernel

#print axioms adaptive146Third142Proof114

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third142Proof197 : runCachedNode 511 131054 Adaptive146Third142Node197 = false := by
  decide +kernel

#print axioms adaptive146Third142Proof197

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third142Proof252 : runCachedNode 511 131054 Adaptive146Third142Node252 = false := by
  decide +kernel

#print axioms adaptive146Third142Proof252

end NineSeparatedSubsetSums
