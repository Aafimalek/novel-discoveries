import NineSeparatedSubsetSums.Adaptive146Third135State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third135Proof20 : runCachedNode 511 130049 Adaptive146Third135Node20 = false := by
  decide +kernel

#print axioms adaptive146Third135Proof20

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third135Proof15 : runCachedNode 511 130049 Adaptive146Third135Node15 = false := by
  decide +kernel

#print axioms adaptive146Third135Proof15

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third135Proof35 : runCachedNode 511 130049 Adaptive146Third135Node35 = false := by
  decide +kernel

#print axioms adaptive146Third135Proof35

end NineSeparatedSubsetSums
