import NineSeparatedSubsetSums.Adaptive146Third142State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third142Proof23 : runCachedNode 511 131054 Adaptive146Third142Node23 = false := by
  decide +kernel

#print axioms adaptive146Third142Proof23

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third142Proof172 : runCachedNode 511 131054 Adaptive146Third142Node172 = false := by
  decide +kernel

#print axioms adaptive146Third142Proof172

end NineSeparatedSubsetSums
