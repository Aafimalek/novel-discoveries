import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive146Third125Node0 : CachedSearchNode :=
  ⟨4, 124, computeCenteredMask [148,146,125], 419, 58845⟩

end NineSeparatedSubsetSums
