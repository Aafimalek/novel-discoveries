import NineSeparatedSubsetSums.Adaptive146Third140State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third140Proof384 : runCachedNode 511 130775 Adaptive146Third140Node384 = false := by
  decide +kernel

#print axioms adaptive146Third140Proof384

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third140Proof309 : runCachedNode 511 130775 Adaptive146Third140Node309 = false := by
  decide +kernel

#print axioms adaptive146Third140Proof309

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third140Proof48 : runCachedNode 511 130775 Adaptive146Third140Node48 = false := by
  decide +kernel

#print axioms adaptive146Third140Proof48

end NineSeparatedSubsetSums
