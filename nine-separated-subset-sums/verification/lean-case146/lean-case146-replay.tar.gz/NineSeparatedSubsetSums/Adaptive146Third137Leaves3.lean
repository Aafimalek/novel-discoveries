import NineSeparatedSubsetSums.Adaptive146Third137State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third137Proof18 : runCachedNode 511 130354 Adaptive146Third137Node18 = false := by
  decide +kernel

#print axioms adaptive146Third137Proof18

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third137Proof184 : runCachedNode 511 130354 Adaptive146Third137Node184 = false := by
  decide +kernel

#print axioms adaptive146Third137Proof184

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third137Proof113 : runCachedNode 511 130354 Adaptive146Third137Node113 = false := by
  decide +kernel

#print axioms adaptive146Third137Proof113

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third137Proof103 : runCachedNode 511 130354 Adaptive146Third137Node103 = false := by
  decide +kernel

#print axioms adaptive146Third137Proof103

end NineSeparatedSubsetSums
