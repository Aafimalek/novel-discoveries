import NineSeparatedSubsetSums.Adaptive146Third133State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third133Proof19 : runCachedNode 511 129683 Adaptive146Third133Node19 = false := by
  decide +kernel

#print axioms adaptive146Third133Proof19

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third133Proof18 : runCachedNode 511 129683 Adaptive146Third133Node18 = false := by
  decide +kernel

#print axioms adaptive146Third133Proof18

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third133Proof44 : runCachedNode 511 129683 Adaptive146Third133Node44 = false := by
  decide +kernel

#print axioms adaptive146Third133Proof44

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third133Proof3 : runCachedNode 511 129683 Adaptive146Third133Node3 = false := by
  decide +kernel

#print axioms adaptive146Third133Proof3

end NineSeparatedSubsetSums
