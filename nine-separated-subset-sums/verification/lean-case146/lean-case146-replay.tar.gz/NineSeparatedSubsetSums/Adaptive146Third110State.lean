import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive146Third110Node0 : CachedSearchNode :=
  ⟨4, 109, computeCenteredMask [148,146,110], 404, 55320⟩

end NineSeparatedSubsetSums
