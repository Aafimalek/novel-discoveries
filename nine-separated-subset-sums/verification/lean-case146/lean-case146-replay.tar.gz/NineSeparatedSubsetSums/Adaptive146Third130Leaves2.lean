import NineSeparatedSubsetSums.Adaptive146Third130State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third130Proof14 : runCachedNode 511 129031 Adaptive146Third130Node14 = false := by
  decide +kernel

#print axioms adaptive146Third130Proof14

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third130Proof12 : runCachedNode 511 129031 Adaptive146Third130Node12 = false := by
  decide +kernel

#print axioms adaptive146Third130Proof12

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third130Proof11 : runCachedNode 511 129031 Adaptive146Third130Node11 = false := by
  decide +kernel

#print axioms adaptive146Third130Proof11

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third130Proof10 : runCachedNode 511 129031 Adaptive146Third130Node10 = false := by
  decide +kernel

#print axioms adaptive146Third130Proof10

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third130Proof9 : runCachedNode 511 129031 Adaptive146Third130Node9 = false := by
  decide +kernel

#print axioms adaptive146Third130Proof9

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third130Proof8 : runCachedNode 511 129031 Adaptive146Third130Node8 = false := by
  decide +kernel

#print axioms adaptive146Third130Proof8

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third130Proof7 : runCachedNode 511 129031 Adaptive146Third130Node7 = false := by
  decide +kernel

#print axioms adaptive146Third130Proof7

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third130Proof6 : runCachedNode 511 129031 Adaptive146Third130Node6 = false := by
  decide +kernel

#print axioms adaptive146Third130Proof6

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third130Proof4 : runCachedNode 511 129031 Adaptive146Third130Node4 = false := by
  decide +kernel

#print axioms adaptive146Third130Proof4

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third130Proof3 : runCachedNode 511 129031 Adaptive146Third130Node3 = false := by
  decide +kernel

#print axioms adaptive146Third130Proof3

end NineSeparatedSubsetSums
