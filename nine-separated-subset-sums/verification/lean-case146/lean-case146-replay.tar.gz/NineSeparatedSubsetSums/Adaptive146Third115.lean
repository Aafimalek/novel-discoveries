import NineSeparatedSubsetSums.Adaptive146Third115Joins0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint146Checked

namespace NineSeparatedSubsetSums


theorem adaptive146Third115 : NoDescendingTailAfterThird 146 115 :=
  noDescendingThirdTail_of_cached 146 115 112631 (fun t ht nd => max148_second146_fourPoint_moment_bound (115::t) (by simp [ht]) nd) adaptive146Third115Proof0

#print axioms adaptive146Third115

end NineSeparatedSubsetSums
