import NineSeparatedSubsetSums.Adaptive146Third142State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third142Proof239 : runCachedNode 511 131054 Adaptive146Third142Node239 = false := by
  decide +kernel

#print axioms adaptive146Third142Proof239

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third142Proof482 : runCachedNode 511 131054 Adaptive146Third142Node482 = false := by
  decide +kernel

#print axioms adaptive146Third142Proof482

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third142Proof12 : runCachedNode 511 131054 Adaptive146Third142Node12 = false := by
  decide +kernel

#print axioms adaptive146Third142Proof12

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third142Proof233 : runCachedNode 511 131054 Adaptive146Third142Node233 = false := by
  decide +kernel

#print axioms adaptive146Third142Proof233

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third142Proof48 : runCachedNode 511 131054 Adaptive146Third142Node48 = false := by
  decide +kernel

#print axioms adaptive146Third142Proof48

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third142Proof392 : runCachedNode 511 131054 Adaptive146Third142Node392 = false := by
  decide +kernel

#print axioms adaptive146Third142Proof392

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third142Proof78 : runCachedNode 511 131054 Adaptive146Third142Node78 = false := by
  decide +kernel

#print axioms adaptive146Third142Proof78

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third142Proof391 : runCachedNode 511 131054 Adaptive146Third142Node391 = false := by
  decide +kernel

#print axioms adaptive146Third142Proof391

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third142Proof134 : runCachedNode 511 131054 Adaptive146Third142Node134 = false := by
  decide +kernel

#print axioms adaptive146Third142Proof134

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third142Proof316 : runCachedNode 511 131054 Adaptive146Third142Node316 = false := by
  decide +kernel

#print axioms adaptive146Third142Proof316

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third142Proof359 : runCachedNode 511 131054 Adaptive146Third142Node359 = false := by
  decide +kernel

#print axioms adaptive146Third142Proof359

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third142Proof60 : runCachedNode 511 131054 Adaptive146Third142Node60 = false := by
  decide +kernel

#print axioms adaptive146Third142Proof60

end NineSeparatedSubsetSums
