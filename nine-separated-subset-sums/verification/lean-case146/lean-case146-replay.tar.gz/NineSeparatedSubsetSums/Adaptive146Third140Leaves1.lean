import NineSeparatedSubsetSums.Adaptive146Third140State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third140Proof386 : runCachedNode 511 130775 Adaptive146Third140Node386 = false := by
  decide +kernel

#print axioms adaptive146Third140Proof386

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third140Proof311 : runCachedNode 511 130775 Adaptive146Third140Node311 = false := by
  decide +kernel

#print axioms adaptive146Third140Proof311

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third140Proof1 : runCachedNode 511 130775 Adaptive146Third140Node1 = false := by
  decide +kernel

#print axioms adaptive146Third140Proof1

end NineSeparatedSubsetSums
