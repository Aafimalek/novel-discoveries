import NineSeparatedSubsetSums.Adaptive146Third137State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third137Proof20 : runCachedNode 511 130354 Adaptive146Third137Node20 = false := by
  decide +kernel

#print axioms adaptive146Third137Proof20

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third137Proof123 : runCachedNode 511 130354 Adaptive146Third137Node123 = false := by
  decide +kernel

#print axioms adaptive146Third137Proof123

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third137Proof126 : runCachedNode 511 130354 Adaptive146Third137Node126 = false := by
  decide +kernel

#print axioms adaptive146Third137Proof126

end NineSeparatedSubsetSums
