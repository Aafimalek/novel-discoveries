import NineSeparatedSubsetSums.Adaptive146Third144State
import NineSeparatedSubsetSums.Adaptive146Third144Leaves131
import NineSeparatedSubsetSums.Adaptive146Third144Leaves130
import NineSeparatedSubsetSums.Adaptive146Third144Leaves128
import NineSeparatedSubsetSums.Adaptive146Third144Leaves127
import NineSeparatedSubsetSums.Adaptive146Third144Leaves126
import NineSeparatedSubsetSums.Adaptive146Third144Leaves125
import NineSeparatedSubsetSums.Adaptive146Third144Leaves124
import NineSeparatedSubsetSums.Adaptive146Third144Leaves123
import NineSeparatedSubsetSums.Adaptive146Third144Leaves122
import NineSeparatedSubsetSums.Adaptive146Third144Leaves119
import NineSeparatedSubsetSums.Adaptive146Third144Leaves121
import NineSeparatedSubsetSums.Adaptive146Third144Leaves113
import NineSeparatedSubsetSums.Adaptive146Third144Leaves117
import NineSeparatedSubsetSums.Adaptive146Third144Leaves108
import NineSeparatedSubsetSums.Adaptive146Third144Leaves114
import NineSeparatedSubsetSums.Adaptive146Third144Leaves100
import NineSeparatedSubsetSums.Adaptive146Third144Leaves110
import NineSeparatedSubsetSums.Adaptive146Third144Leaves92
import NineSeparatedSubsetSums.Adaptive146Third144Leaves59
import NineSeparatedSubsetSums.Adaptive146Third144Leaves85
import NineSeparatedSubsetSums.Adaptive146Third144Leaves102
import NineSeparatedSubsetSums.Adaptive146Third144Leaves78
import NineSeparatedSubsetSums.Adaptive146Third144Leaves97
import NineSeparatedSubsetSums.Adaptive146Third144Leaves13
import NineSeparatedSubsetSums.Adaptive146Third144Leaves62
import NineSeparatedSubsetSums.Adaptive146Third144Leaves88
import NineSeparatedSubsetSums.Adaptive146Third144Leaves56
import NineSeparatedSubsetSums.Adaptive146Third144Leaves74
import NineSeparatedSubsetSums.Adaptive146Third144Leaves79
import NineSeparatedSubsetSums.Adaptive146Third144Leaves76
import NineSeparatedSubsetSums.Adaptive146Third144Leaves10
import NineSeparatedSubsetSums.Adaptive146Third144Leaves71
import NineSeparatedSubsetSums.Adaptive146Third144Leaves132
import NineSeparatedSubsetSums.Adaptive146Third144Leaves120
import NineSeparatedSubsetSums.Adaptive146Third144Leaves118
import NineSeparatedSubsetSums.Adaptive146Third144Leaves99
import NineSeparatedSubsetSums.Adaptive146Third144Leaves116
import NineSeparatedSubsetSums.Adaptive146Third144Leaves107
import NineSeparatedSubsetSums.Adaptive146Third144Leaves112
import NineSeparatedSubsetSums.Adaptive146Third144Leaves104
import NineSeparatedSubsetSums.Adaptive146Third144Leaves98
import NineSeparatedSubsetSums.Adaptive146Third144Leaves103
import NineSeparatedSubsetSums.Adaptive146Third144Leaves65
import NineSeparatedSubsetSums.Adaptive146Third144Leaves115
import NineSeparatedSubsetSums.Adaptive146Third144Leaves109
import NineSeparatedSubsetSums.Adaptive146Third144Leaves94
import NineSeparatedSubsetSums.Adaptive146Third144Leaves106
import NineSeparatedSubsetSums.Adaptive146Third144Leaves86
import NineSeparatedSubsetSums.Adaptive146Third144Leaves101
import NineSeparatedSubsetSums.Adaptive146Third144Leaves80
import NineSeparatedSubsetSums.Adaptive146Third144Leaves96
import NineSeparatedSubsetSums.Adaptive146Third144Leaves73
import NineSeparatedSubsetSums.Adaptive146Third144Leaves64
import NineSeparatedSubsetSums.Adaptive146Third144Leaves87
import NineSeparatedSubsetSums.Adaptive146Third144Leaves23
import NineSeparatedSubsetSums.Adaptive146Third144Leaves82
import NineSeparatedSubsetSums.Adaptive146Third144Leaves51
import NineSeparatedSubsetSums.Adaptive146Third144Leaves77
import NineSeparatedSubsetSums.Adaptive146Third144Leaves37
import NineSeparatedSubsetSums.Adaptive146Third144Leaves72
import NineSeparatedSubsetSums.Adaptive146Third144Leaves70
import NineSeparatedSubsetSums.Adaptive146Third144Leaves16
import NineSeparatedSubsetSums.Adaptive146Third144Leaves63
import NineSeparatedSubsetSums.Adaptive146Third144Leaves60
import NineSeparatedSubsetSums.Adaptive146Third144Leaves133
import NineSeparatedSubsetSums.Adaptive146Third144Leaves111
import NineSeparatedSubsetSums.Adaptive146Third144Leaves95
import NineSeparatedSubsetSums.Adaptive146Third144Leaves50
import NineSeparatedSubsetSums.Adaptive146Third144Leaves58
import NineSeparatedSubsetSums.Adaptive146Third144Leaves39
import NineSeparatedSubsetSums.Adaptive146Third144Leaves105
import NineSeparatedSubsetSums.Adaptive146Third144Leaves90
import NineSeparatedSubsetSums.Adaptive146Third144Leaves83
import NineSeparatedSubsetSums.Adaptive146Third144Leaves52
import NineSeparatedSubsetSums.Adaptive146Third144Leaves41
import NineSeparatedSubsetSums.Adaptive146Third144Leaves129
import NineSeparatedSubsetSums.Adaptive146Third144Leaves93
import NineSeparatedSubsetSums.Adaptive146Third144Leaves53
import NineSeparatedSubsetSums.Adaptive146Third144Leaves61
import NineSeparatedSubsetSums.Adaptive146Third144Leaves25
import NineSeparatedSubsetSums.Adaptive146Third144Leaves48
import NineSeparatedSubsetSums.Adaptive146Third144Leaves31
import NineSeparatedSubsetSums.Adaptive146Third144Leaves36
import NineSeparatedSubsetSums.Adaptive146Third144Leaves26
import NineSeparatedSubsetSums.Adaptive146Third144Joins2
import NineSeparatedSubsetSums.Adaptive146Third144Leaves6
import NineSeparatedSubsetSums.Adaptive146Third144Leaves67

namespace NineSeparatedSubsetSums

theorem adaptive146Third144Proof823 : runCachedNode 511 131319 Adaptive146Third144Node823 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 131319 Adaptive146Third144Node823 = [89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 123, 125, 127, 129, 131] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive146Third144Proof824
  · exact adaptive146Third144Proof825
  · exact adaptive146Third144Proof826
  · exact adaptive146Third144Proof827
  · exact adaptive146Third144Proof828
  · exact adaptive146Third144Proof829
  · exact adaptive146Third144Proof830
  · exact adaptive146Third144Proof831
  · exact adaptive146Third144Proof832
  · exact adaptive146Third144Proof833
  · exact adaptive146Third144Proof834
  · exact adaptive146Third144Proof835
  · exact adaptive146Third144Proof836
  · exact adaptive146Third144Proof837
  · exact adaptive146Third144Proof838
  · exact adaptive146Third144Proof839
  · exact adaptive146Third144Proof840
  · exact adaptive146Third144Proof841
  · exact adaptive146Third144Proof842
  · exact adaptive146Third144Proof843
  · exact adaptive146Third144Proof844
  · exact adaptive146Third144Proof845
  · exact adaptive146Third144Proof846
  · exact adaptive146Third144Proof847
  · exact adaptive146Third144Proof848
  · exact adaptive146Third144Proof849
  · exact adaptive146Third144Proof850
  · exact adaptive146Third144Proof851
  · exact adaptive146Third144Proof852
  · exact adaptive146Third144Proof853
  · exact adaptive146Third144Proof854
  · exact adaptive146Third144Proof855
  · exact adaptive146Third144Proof856
  · exact adaptive146Third144Proof857
  · exact adaptive146Third144Proof858
  · exact adaptive146Third144Proof859
  · exact adaptive146Third144Proof860
  · exact adaptive146Third144Proof861

#print axioms adaptive146Third144Proof823

theorem adaptive146Third144Proof862 : runCachedNode 511 131319 Adaptive146Third144Node862 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 131319 Adaptive146Third144Node862 = [89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 124, 126, 128, 130, 132] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive146Third144Proof863
  · exact adaptive146Third144Proof864
  · exact adaptive146Third144Proof865
  · exact adaptive146Third144Proof866
  · exact adaptive146Third144Proof867
  · exact adaptive146Third144Proof868
  · exact adaptive146Third144Proof869
  · exact adaptive146Third144Proof870
  · exact adaptive146Third144Proof871
  · exact adaptive146Third144Proof872
  · exact adaptive146Third144Proof873
  · exact adaptive146Third144Proof874
  · exact adaptive146Third144Proof875
  · exact adaptive146Third144Proof876
  · exact adaptive146Third144Proof877
  · exact adaptive146Third144Proof878
  · exact adaptive146Third144Proof879
  · exact adaptive146Third144Proof880
  · exact adaptive146Third144Proof881
  · exact adaptive146Third144Proof882
  · exact adaptive146Third144Proof883
  · exact adaptive146Third144Proof884
  · exact adaptive146Third144Proof885
  · exact adaptive146Third144Proof886
  · exact adaptive146Third144Proof887
  · exact adaptive146Third144Proof888
  · exact adaptive146Third144Proof889
  · exact adaptive146Third144Proof890
  · exact adaptive146Third144Proof891
  · exact adaptive146Third144Proof892
  · exact adaptive146Third144Proof893
  · exact adaptive146Third144Proof894
  · exact adaptive146Third144Proof895
  · exact adaptive146Third144Proof896
  · exact adaptive146Third144Proof897
  · exact adaptive146Third144Proof898
  · exact adaptive146Third144Proof899
  · exact adaptive146Third144Proof900
  · exact adaptive146Third144Proof901

#print axioms adaptive146Third144Proof862

theorem adaptive146Third144Proof902 : runCachedNode 511 131319 Adaptive146Third144Node902 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 131319 Adaptive146Third144Node902 = [88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 125, 127, 129, 131, 133] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive146Third144Proof903
  · exact adaptive146Third144Proof904
  · exact adaptive146Third144Proof905
  · exact adaptive146Third144Proof906
  · exact adaptive146Third144Proof907
  · exact adaptive146Third144Proof908
  · exact adaptive146Third144Proof909
  · exact adaptive146Third144Proof910
  · exact adaptive146Third144Proof911
  · exact adaptive146Third144Proof912
  · exact adaptive146Third144Proof913
  · exact adaptive146Third144Proof914
  · exact adaptive146Third144Proof915
  · exact adaptive146Third144Proof916
  · exact adaptive146Third144Proof917
  · exact adaptive146Third144Proof918
  · exact adaptive146Third144Proof919
  · exact adaptive146Third144Proof920
  · exact adaptive146Third144Proof921
  · exact adaptive146Third144Proof922
  · exact adaptive146Third144Proof923
  · exact adaptive146Third144Proof924
  · exact adaptive146Third144Proof925
  · exact adaptive146Third144Proof926
  · exact adaptive146Third144Proof927
  · exact adaptive146Third144Proof928
  · exact adaptive146Third144Proof929
  · exact adaptive146Third144Proof930
  · exact adaptive146Third144Proof931
  · exact adaptive146Third144Proof932
  · exact adaptive146Third144Proof933
  · exact adaptive146Third144Proof934
  · exact adaptive146Third144Proof935
  · exact adaptive146Third144Proof936
  · exact adaptive146Third144Proof937
  · exact adaptive146Third144Proof938
  · exact adaptive146Third144Proof939
  · exact adaptive146Third144Proof940
  · exact adaptive146Third144Proof941
  · exact adaptive146Third144Proof942
  · exact adaptive146Third144Proof943

#print axioms adaptive146Third144Proof902

theorem adaptive146Third144Proof944 : runCachedNode 511 131319 Adaptive146Third144Node944 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 131319 Adaptive146Third144Node944 = [88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 126, 128, 130, 132, 134] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive146Third144Proof945
  · exact adaptive146Third144Proof946
  · exact adaptive146Third144Proof947
  · exact adaptive146Third144Proof948
  · exact adaptive146Third144Proof949
  · exact adaptive146Third144Proof950
  · exact adaptive146Third144Proof951
  · exact adaptive146Third144Proof952
  · exact adaptive146Third144Proof953
  · exact adaptive146Third144Proof954
  · exact adaptive146Third144Proof955
  · exact adaptive146Third144Proof956
  · exact adaptive146Third144Proof957
  · exact adaptive146Third144Proof958
  · exact adaptive146Third144Proof959
  · exact adaptive146Third144Proof960
  · exact adaptive146Third144Proof961
  · exact adaptive146Third144Proof962
  · exact adaptive146Third144Proof963
  · exact adaptive146Third144Proof964
  · exact adaptive146Third144Proof965
  · exact adaptive146Third144Proof966
  · exact adaptive146Third144Proof967
  · exact adaptive146Third144Proof968
  · exact adaptive146Third144Proof969
  · exact adaptive146Third144Proof970
  · exact adaptive146Third144Proof971
  · exact adaptive146Third144Proof972
  · exact adaptive146Third144Proof973
  · exact adaptive146Third144Proof974
  · exact adaptive146Third144Proof975
  · exact adaptive146Third144Proof976
  · exact adaptive146Third144Proof977
  · exact adaptive146Third144Proof978
  · exact adaptive146Third144Proof979
  · exact adaptive146Third144Proof980
  · exact adaptive146Third144Proof981
  · exact adaptive146Third144Proof982
  · exact adaptive146Third144Proof983
  · exact adaptive146Third144Proof984
  · exact adaptive146Third144Proof985
  · exact adaptive146Third144Proof986

#print axioms adaptive146Third144Proof944

theorem adaptive146Third144Proof987 : runCachedNode 511 131319 Adaptive146Third144Node987 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 131319 Adaptive146Third144Node987 = [87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 128, 130, 132, 134] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive146Third144Proof988
  · exact adaptive146Third144Proof989
  · exact adaptive146Third144Proof990
  · exact adaptive146Third144Proof991
  · exact adaptive146Third144Proof992
  · exact adaptive146Third144Proof993
  · exact adaptive146Third144Proof994
  · exact adaptive146Third144Proof995
  · exact adaptive146Third144Proof996
  · exact adaptive146Third144Proof997
  · exact adaptive146Third144Proof998
  · exact adaptive146Third144Proof999
  · exact adaptive146Third144Proof1000
  · exact adaptive146Third144Proof1001
  · exact adaptive146Third144Proof1002
  · exact adaptive146Third144Proof1003
  · exact adaptive146Third144Proof1004
  · exact adaptive146Third144Proof1005
  · exact adaptive146Third144Proof1006
  · exact adaptive146Third144Proof1007
  · exact adaptive146Third144Proof1008
  · exact adaptive146Third144Proof1009
  · exact adaptive146Third144Proof1010
  · exact adaptive146Third144Proof1011
  · exact adaptive146Third144Proof1012
  · exact adaptive146Third144Proof1013
  · exact adaptive146Third144Proof1014
  · exact adaptive146Third144Proof1015
  · exact adaptive146Third144Proof1016
  · exact adaptive146Third144Proof1017
  · exact adaptive146Third144Proof1018
  · exact adaptive146Third144Proof1019
  · exact adaptive146Third144Proof1020
  · exact adaptive146Third144Proof1021
  · exact adaptive146Third144Proof1022
  · exact adaptive146Third144Proof1023
  · exact adaptive146Third144Proof1024
  · exact adaptive146Third144Proof1025
  · exact adaptive146Third144Proof1026
  · exact adaptive146Third144Proof1027
  · exact adaptive146Third144Proof1028
  · exact adaptive146Third144Proof1029
  · exact adaptive146Third144Proof1030
  · exact adaptive146Third144Proof1031

#print axioms adaptive146Third144Proof987

theorem adaptive146Third144Proof1032 : runCachedNode 511 131319 Adaptive146Third144Node1032 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 131319 Adaptive146Third144Node1032 = [86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 130, 132, 134] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive146Third144Proof1033
  · exact adaptive146Third144Proof1034
  · exact adaptive146Third144Proof1035
  · exact adaptive146Third144Proof1036
  · exact adaptive146Third144Proof1037
  · exact adaptive146Third144Proof1038
  · exact adaptive146Third144Proof1039
  · exact adaptive146Third144Proof1040
  · exact adaptive146Third144Proof1041
  · exact adaptive146Third144Proof1042
  · exact adaptive146Third144Proof1043
  · exact adaptive146Third144Proof1044
  · exact adaptive146Third144Proof1045
  · exact adaptive146Third144Proof1046
  · exact adaptive146Third144Proof1047
  · exact adaptive146Third144Proof1048
  · exact adaptive146Third144Proof1049
  · exact adaptive146Third144Proof1050
  · exact adaptive146Third144Proof1051
  · exact adaptive146Third144Proof1052
  · exact adaptive146Third144Proof1053
  · exact adaptive146Third144Proof1054
  · exact adaptive146Third144Proof1055
  · exact adaptive146Third144Proof1056
  · exact adaptive146Third144Proof1057
  · exact adaptive146Third144Proof1058
  · exact adaptive146Third144Proof1059
  · exact adaptive146Third144Proof1060
  · exact adaptive146Third144Proof1061
  · exact adaptive146Third144Proof1062
  · exact adaptive146Third144Proof1063
  · exact adaptive146Third144Proof1064
  · exact adaptive146Third144Proof1065
  · exact adaptive146Third144Proof1066
  · exact adaptive146Third144Proof1067
  · exact adaptive146Third144Proof1068
  · exact adaptive146Third144Proof1069
  · exact adaptive146Third144Proof1070
  · exact adaptive146Third144Proof1071
  · exact adaptive146Third144Proof1072
  · exact adaptive146Third144Proof1073
  · exact adaptive146Third144Proof1074
  · exact adaptive146Third144Proof1075
  · exact adaptive146Third144Proof1076
  · exact adaptive146Third144Proof1077
  · exact adaptive146Third144Proof1078

#print axioms adaptive146Third144Proof1032

theorem adaptive146Third144Proof686 : runCachedNode 511 131319 Adaptive146Third144Node686 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 131319 Adaptive146Third144Node686 = [100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 132, 133, 134, 135, 137, 139] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive146Third144Proof687
  · exact adaptive146Third144Proof688
  · exact adaptive146Third144Proof689
  · exact adaptive146Third144Proof690
  · exact adaptive146Third144Proof691
  · exact adaptive146Third144Proof692
  · exact adaptive146Third144Proof693
  · exact adaptive146Third144Proof694
  · exact adaptive146Third144Proof695
  · exact adaptive146Third144Proof696
  · exact adaptive146Third144Proof697
  · exact adaptive146Third144Proof698
  · exact adaptive146Third144Proof699
  · exact adaptive146Third144Proof700
  · exact adaptive146Third144Proof701
  · exact adaptive146Third144Proof702
  · exact adaptive146Third144Proof703
  · exact adaptive146Third144Proof704
  · exact adaptive146Third144Proof705
  · exact adaptive146Third144Proof706
  · exact adaptive146Third144Proof707
  · exact adaptive146Third144Proof708
  · exact adaptive146Third144Proof709
  · exact adaptive146Third144Proof710
  · exact adaptive146Third144Proof711
  · exact adaptive146Third144Proof712
  · exact adaptive146Third144Proof713
  · exact adaptive146Third144Proof714
  · exact adaptive146Third144Proof715
  · exact adaptive146Third144Proof748
  · exact adaptive146Third144Proof749
  · exact adaptive146Third144Proof785
  · exact adaptive146Third144Proof823
  · exact adaptive146Third144Proof862
  · exact adaptive146Third144Proof902
  · exact adaptive146Third144Proof944
  · exact adaptive146Third144Proof987
  · exact adaptive146Third144Proof1032

#print axioms adaptive146Third144Proof686

theorem adaptive146Third144Proof1116 : runCachedNode 511 131319 Adaptive146Third144Node1116 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 131319 Adaptive146Third144Node1116 = [87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 128, 130] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive146Third144Proof1117
  · exact adaptive146Third144Proof1118
  · exact adaptive146Third144Proof1119
  · exact adaptive146Third144Proof1120
  · exact adaptive146Third144Proof1121
  · exact adaptive146Third144Proof1122
  · exact adaptive146Third144Proof1123
  · exact adaptive146Third144Proof1124
  · exact adaptive146Third144Proof1125
  · exact adaptive146Third144Proof1126
  · exact adaptive146Third144Proof1127
  · exact adaptive146Third144Proof1128
  · exact adaptive146Third144Proof1129
  · exact adaptive146Third144Proof1130
  · exact adaptive146Third144Proof1131
  · exact adaptive146Third144Proof1132
  · exact adaptive146Third144Proof1133
  · exact adaptive146Third144Proof1134
  · exact adaptive146Third144Proof1135
  · exact adaptive146Third144Proof1136
  · exact adaptive146Third144Proof1137
  · exact adaptive146Third144Proof1138
  · exact adaptive146Third144Proof1139
  · exact adaptive146Third144Proof1140
  · exact adaptive146Third144Proof1141
  · exact adaptive146Third144Proof1142
  · exact adaptive146Third144Proof1143
  · exact adaptive146Third144Proof1144
  · exact adaptive146Third144Proof1145
  · exact adaptive146Third144Proof1146
  · exact adaptive146Third144Proof1147
  · exact adaptive146Third144Proof1148
  · exact adaptive146Third144Proof1149
  · exact adaptive146Third144Proof1150
  · exact adaptive146Third144Proof1151
  · exact adaptive146Third144Proof1152
  · exact adaptive146Third144Proof1153
  · exact adaptive146Third144Proof1154
  · exact adaptive146Third144Proof1155
  · exact adaptive146Third144Proof1156
  · exact adaptive146Third144Proof1157
  · exact adaptive146Third144Proof1158

#print axioms adaptive146Third144Proof1116

end NineSeparatedSubsetSums
