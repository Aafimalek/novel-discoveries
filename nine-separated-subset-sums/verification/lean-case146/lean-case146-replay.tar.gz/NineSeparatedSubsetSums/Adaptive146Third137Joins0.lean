import NineSeparatedSubsetSums.Adaptive146Third137State
import NineSeparatedSubsetSums.Adaptive146Third137Leaves15
import NineSeparatedSubsetSums.Adaptive146Third137Leaves9
import NineSeparatedSubsetSums.Adaptive146Third137Leaves14
import NineSeparatedSubsetSums.Adaptive146Third137Leaves13
import NineSeparatedSubsetSums.Adaptive146Third137Leaves12
import NineSeparatedSubsetSums.Adaptive146Third137Leaves11
import NineSeparatedSubsetSums.Adaptive146Third137Leaves8
import NineSeparatedSubsetSums.Adaptive146Third137Leaves10
import NineSeparatedSubsetSums.Adaptive146Third137Leaves7
import NineSeparatedSubsetSums.Adaptive146Third137Leaves6
import NineSeparatedSubsetSums.Adaptive146Third137Leaves4
import NineSeparatedSubsetSums.Adaptive146Third137Leaves2
import NineSeparatedSubsetSums.Adaptive146Third137Leaves3
import NineSeparatedSubsetSums.Adaptive146Third137Leaves5
import NineSeparatedSubsetSums.Adaptive146Third137Leaves1
import NineSeparatedSubsetSums.Adaptive146Third137Leaves0

namespace NineSeparatedSubsetSums

theorem adaptive146Third137Proof21 : runCachedNode 511 130354 Adaptive146Third137Node21 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130354 Adaptive146Third137Node21 = [104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 120, 122, 123, 124, 125, 126, 127, 129] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive146Third137Proof22
  · exact adaptive146Third137Proof23
  · exact adaptive146Third137Proof24
  · exact adaptive146Third137Proof25
  · exact adaptive146Third137Proof26
  · exact adaptive146Third137Proof27
  · exact adaptive146Third137Proof28
  · exact adaptive146Third137Proof29
  · exact adaptive146Third137Proof30
  · exact adaptive146Third137Proof31
  · exact adaptive146Third137Proof32
  · exact adaptive146Third137Proof33
  · exact adaptive146Third137Proof34
  · exact adaptive146Third137Proof35
  · exact adaptive146Third137Proof36
  · exact adaptive146Third137Proof37
  · exact adaptive146Third137Proof38
  · exact adaptive146Third137Proof39
  · exact adaptive146Third137Proof40
  · exact adaptive146Third137Proof41
  · exact adaptive146Third137Proof42
  · exact adaptive146Third137Proof43
  · exact adaptive146Third137Proof44

#print axioms adaptive146Third137Proof21

theorem adaptive146Third137Proof45 : runCachedNode 511 130354 Adaptive146Third137Node45 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130354 Adaptive146Third137Node45 = [104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 121, 123, 124, 125, 126, 127, 128, 130] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive146Third137Proof46
  · exact adaptive146Third137Proof47
  · exact adaptive146Third137Proof48
  · exact adaptive146Third137Proof49
  · exact adaptive146Third137Proof50
  · exact adaptive146Third137Proof51
  · exact adaptive146Third137Proof52
  · exact adaptive146Third137Proof53
  · exact adaptive146Third137Proof54
  · exact adaptive146Third137Proof55
  · exact adaptive146Third137Proof56
  · exact adaptive146Third137Proof57
  · exact adaptive146Third137Proof58
  · exact adaptive146Third137Proof59
  · exact adaptive146Third137Proof60
  · exact adaptive146Third137Proof61
  · exact adaptive146Third137Proof62
  · exact adaptive146Third137Proof63
  · exact adaptive146Third137Proof64
  · exact adaptive146Third137Proof65
  · exact adaptive146Third137Proof66
  · exact adaptive146Third137Proof67
  · exact adaptive146Third137Proof68
  · exact adaptive146Third137Proof69

#print axioms adaptive146Third137Proof45

theorem adaptive146Third137Proof70 : runCachedNode 511 130354 Adaptive146Third137Node70 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130354 Adaptive146Third137Node70 = [103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 122, 124, 125, 126, 127, 128, 129, 131] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive146Third137Proof71
  · exact adaptive146Third137Proof72
  · exact adaptive146Third137Proof73
  · exact adaptive146Third137Proof74
  · exact adaptive146Third137Proof75
  · exact adaptive146Third137Proof76
  · exact adaptive146Third137Proof77
  · exact adaptive146Third137Proof78
  · exact adaptive146Third137Proof79
  · exact adaptive146Third137Proof80
  · exact adaptive146Third137Proof81
  · exact adaptive146Third137Proof82
  · exact adaptive146Third137Proof83
  · exact adaptive146Third137Proof84
  · exact adaptive146Third137Proof85
  · exact adaptive146Third137Proof86
  · exact adaptive146Third137Proof87
  · exact adaptive146Third137Proof88
  · exact adaptive146Third137Proof89
  · exact adaptive146Third137Proof90
  · exact adaptive146Third137Proof91
  · exact adaptive146Third137Proof92
  · exact adaptive146Third137Proof93
  · exact adaptive146Third137Proof94
  · exact adaptive146Third137Proof95
  · exact adaptive146Third137Proof96

#print axioms adaptive146Third137Proof70

theorem adaptive146Third137Proof97 : runCachedNode 511 130354 Adaptive146Third137Node97 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130354 Adaptive146Third137Node97 = [103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 123, 125, 126, 127, 128, 129, 130, 132] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive146Third137Proof98
  · exact adaptive146Third137Proof99
  · exact adaptive146Third137Proof100
  · exact adaptive146Third137Proof101
  · exact adaptive146Third137Proof102
  · exact adaptive146Third137Proof103
  · exact adaptive146Third137Proof104
  · exact adaptive146Third137Proof105
  · exact adaptive146Third137Proof106
  · exact adaptive146Third137Proof107
  · exact adaptive146Third137Proof108
  · exact adaptive146Third137Proof109
  · exact adaptive146Third137Proof110
  · exact adaptive146Third137Proof111
  · exact adaptive146Third137Proof112
  · exact adaptive146Third137Proof113
  · exact adaptive146Third137Proof114
  · exact adaptive146Third137Proof115
  · exact adaptive146Third137Proof116
  · exact adaptive146Third137Proof117
  · exact adaptive146Third137Proof118
  · exact adaptive146Third137Proof119
  · exact adaptive146Third137Proof120
  · exact adaptive146Third137Proof121
  · exact adaptive146Third137Proof122
  · exact adaptive146Third137Proof123
  · exact adaptive146Third137Proof124

#print axioms adaptive146Third137Proof97

theorem adaptive146Third137Proof125 : runCachedNode 511 130354 Adaptive146Third137Node125 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130354 Adaptive146Third137Node125 = [103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 124, 126, 127, 128, 129, 130, 131, 133] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive146Third137Proof126
  · exact adaptive146Third137Proof127
  · exact adaptive146Third137Proof128
  · exact adaptive146Third137Proof129
  · exact adaptive146Third137Proof130
  · exact adaptive146Third137Proof131
  · exact adaptive146Third137Proof132
  · exact adaptive146Third137Proof133
  · exact adaptive146Third137Proof134
  · exact adaptive146Third137Proof135
  · exact adaptive146Third137Proof136
  · exact adaptive146Third137Proof137
  · exact adaptive146Third137Proof138
  · exact adaptive146Third137Proof139
  · exact adaptive146Third137Proof140
  · exact adaptive146Third137Proof141
  · exact adaptive146Third137Proof142
  · exact adaptive146Third137Proof143
  · exact adaptive146Third137Proof144
  · exact adaptive146Third137Proof145
  · exact adaptive146Third137Proof146
  · exact adaptive146Third137Proof147
  · exact adaptive146Third137Proof148
  · exact adaptive146Third137Proof149
  · exact adaptive146Third137Proof150
  · exact adaptive146Third137Proof151
  · exact adaptive146Third137Proof152
  · exact adaptive146Third137Proof153

#print axioms adaptive146Third137Proof125

theorem adaptive146Third137Proof154 : runCachedNode 511 130354 Adaptive146Third137Node154 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130354 Adaptive146Third137Node154 = [102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 126, 128, 129, 130, 131, 132, 133] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive146Third137Proof155
  · exact adaptive146Third137Proof156
  · exact adaptive146Third137Proof157
  · exact adaptive146Third137Proof158
  · exact adaptive146Third137Proof159
  · exact adaptive146Third137Proof160
  · exact adaptive146Third137Proof161
  · exact adaptive146Third137Proof162
  · exact adaptive146Third137Proof163
  · exact adaptive146Third137Proof164
  · exact adaptive146Third137Proof165
  · exact adaptive146Third137Proof166
  · exact adaptive146Third137Proof167
  · exact adaptive146Third137Proof168
  · exact adaptive146Third137Proof169
  · exact adaptive146Third137Proof170
  · exact adaptive146Third137Proof171
  · exact adaptive146Third137Proof172
  · exact adaptive146Third137Proof173
  · exact adaptive146Third137Proof174
  · exact adaptive146Third137Proof175
  · exact adaptive146Third137Proof176
  · exact adaptive146Third137Proof177
  · exact adaptive146Third137Proof178
  · exact adaptive146Third137Proof179
  · exact adaptive146Third137Proof180
  · exact adaptive146Third137Proof181
  · exact adaptive146Third137Proof182
  · exact adaptive146Third137Proof183
  · exact adaptive146Third137Proof184

#print axioms adaptive146Third137Proof154

theorem adaptive146Third137Proof0 : runCachedNode 511 130354 Adaptive146Third137Node0 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130354 Adaptive146Third137Node0 = [110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 132, 133, 134, 136] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive146Third137Proof1
  · exact adaptive146Third137Proof2
  · exact adaptive146Third137Proof3
  · exact adaptive146Third137Proof4
  · exact adaptive146Third137Proof5
  · exact adaptive146Third137Proof6
  · exact adaptive146Third137Proof7
  · exact adaptive146Third137Proof8
  · exact adaptive146Third137Proof9
  · exact adaptive146Third137Proof10
  · exact adaptive146Third137Proof11
  · exact adaptive146Third137Proof12
  · exact adaptive146Third137Proof13
  · exact adaptive146Third137Proof14
  · exact adaptive146Third137Proof15
  · exact adaptive146Third137Proof16
  · exact adaptive146Third137Proof17
  · exact adaptive146Third137Proof18
  · exact adaptive146Third137Proof19
  · exact adaptive146Third137Proof20
  · exact adaptive146Third137Proof21
  · exact adaptive146Third137Proof45
  · exact adaptive146Third137Proof70
  · exact adaptive146Third137Proof97
  · exact adaptive146Third137Proof125
  · exact adaptive146Third137Proof154

#print axioms adaptive146Third137Proof0

end NineSeparatedSubsetSums
