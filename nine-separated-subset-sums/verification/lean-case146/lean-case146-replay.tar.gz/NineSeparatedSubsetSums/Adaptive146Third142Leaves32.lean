import NineSeparatedSubsetSums.Adaptive146Third142State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third142Proof106 : runCachedNode 511 131054 Adaptive146Third142Node106 = false := by
  decide +kernel

#print axioms adaptive146Third142Proof106

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third142Proof236 : runCachedNode 511 131054 Adaptive146Third142Node236 = false := by
  decide +kernel

#print axioms adaptive146Third142Proof236

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third142Proof313 : runCachedNode 511 131054 Adaptive146Third142Node313 = false := by
  decide +kernel

#print axioms adaptive146Third142Proof313

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third142Proof387 : runCachedNode 511 131054 Adaptive146Third142Node387 = false := by
  decide +kernel

#print axioms adaptive146Third142Proof387

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third142Proof11 : runCachedNode 511 131054 Adaptive146Third142Node11 = false := by
  decide +kernel

#print axioms adaptive146Third142Proof11

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third142Proof231 : runCachedNode 511 131054 Adaptive146Third142Node231 = false := by
  decide +kernel

#print axioms adaptive146Third142Proof231

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third142Proof388 : runCachedNode 511 131054 Adaptive146Third142Node388 = false := by
  decide +kernel

#print axioms adaptive146Third142Proof388

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third142Proof73 : runCachedNode 511 131054 Adaptive146Third142Node73 = false := by
  decide +kernel

#print axioms adaptive146Third142Proof73

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third142Proof361 : runCachedNode 511 131054 Adaptive146Third142Node361 = false := by
  decide +kernel

#print axioms adaptive146Third142Proof361

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third142Proof44 : runCachedNode 511 131054 Adaptive146Third142Node44 = false := by
  decide +kernel

#print axioms adaptive146Third142Proof44

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third142Proof133 : runCachedNode 511 131054 Adaptive146Third142Node133 = false := by
  decide +kernel

#print axioms adaptive146Third142Proof133

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third142Proof284 : runCachedNode 511 131054 Adaptive146Third142Node284 = false := by
  decide +kernel

#print axioms adaptive146Third142Proof284

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third142Proof480 : runCachedNode 511 131054 Adaptive146Third142Node480 = false := by
  decide +kernel

#print axioms adaptive146Third142Proof480

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third142Proof196 : runCachedNode 511 131054 Adaptive146Third142Node196 = false := by
  decide +kernel

#print axioms adaptive146Third142Proof196

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third142Proof438 : runCachedNode 511 131054 Adaptive146Third142Node438 = false := by
  decide +kernel

#print axioms adaptive146Third142Proof438

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third142Proof128 : runCachedNode 511 131054 Adaptive146Third142Node128 = false := by
  decide +kernel

#print axioms adaptive146Third142Proof128

end NineSeparatedSubsetSums
