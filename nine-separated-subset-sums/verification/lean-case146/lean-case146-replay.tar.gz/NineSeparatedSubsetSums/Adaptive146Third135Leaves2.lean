import NineSeparatedSubsetSums.Adaptive146Third135State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third135Proof19 : runCachedNode 511 130049 Adaptive146Third135Node19 = false := by
  decide +kernel

#print axioms adaptive146Third135Proof19

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third135Proof17 : runCachedNode 511 130049 Adaptive146Third135Node17 = false := by
  decide +kernel

#print axioms adaptive146Third135Proof17

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third135Proof60 : runCachedNode 511 130049 Adaptive146Third135Node60 = false := by
  decide +kernel

#print axioms adaptive146Third135Proof60

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third135Proof26 : runCachedNode 511 130049 Adaptive146Third135Node26 = false := by
  decide +kernel

#print axioms adaptive146Third135Proof26

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third135Proof48 : runCachedNode 511 130049 Adaptive146Third135Node48 = false := by
  decide +kernel

#print axioms adaptive146Third135Proof48

end NineSeparatedSubsetSums
