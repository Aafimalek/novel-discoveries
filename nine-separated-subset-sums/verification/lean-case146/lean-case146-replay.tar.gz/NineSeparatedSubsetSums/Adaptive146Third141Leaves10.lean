import NineSeparatedSubsetSums.Adaptive146Third141State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third141Proof171 : runCachedNode 511 130916 Adaptive146Third141Node171 = false := by
  decide +kernel

#print axioms adaptive146Third141Proof171

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third141Proof202 : runCachedNode 511 130916 Adaptive146Third141Node202 = false := by
  decide +kernel

#print axioms adaptive146Third141Proof202

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third141Proof217 : runCachedNode 511 130916 Adaptive146Third141Node217 = false := by
  decide +kernel

#print axioms adaptive146Third141Proof217

end NineSeparatedSubsetSums
