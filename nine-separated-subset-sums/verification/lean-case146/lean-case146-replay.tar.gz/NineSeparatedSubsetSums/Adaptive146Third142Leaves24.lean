import NineSeparatedSubsetSums.Adaptive146Third142State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third142Proof364 : runCachedNode 511 131054 Adaptive146Third142Node364 = false := by
  decide +kernel

#print axioms adaptive146Third142Proof364

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third142Proof396 : runCachedNode 511 131054 Adaptive146Third142Node396 = false := by
  decide +kernel

#print axioms adaptive146Third142Proof396

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third142Proof14 : runCachedNode 511 131054 Adaptive146Third142Node14 = false := by
  decide +kernel

#print axioms adaptive146Third142Proof14

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third142Proof442 : runCachedNode 511 131054 Adaptive146Third142Node442 = false := by
  decide +kernel

#print axioms adaptive146Third142Proof442

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third142Proof110 : runCachedNode 511 131054 Adaptive146Third142Node110 = false := by
  decide +kernel

#print axioms adaptive146Third142Proof110

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third142Proof137 : runCachedNode 511 131054 Adaptive146Third142Node137 = false := by
  decide +kernel

#print axioms adaptive146Third142Proof137

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third142Proof3 : runCachedNode 511 131054 Adaptive146Third142Node3 = false := by
  decide +kernel

#print axioms adaptive146Third142Proof3

end NineSeparatedSubsetSums
