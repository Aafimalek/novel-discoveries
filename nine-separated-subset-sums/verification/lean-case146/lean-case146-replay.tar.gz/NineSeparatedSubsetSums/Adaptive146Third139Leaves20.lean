import NineSeparatedSubsetSums.Adaptive146Third139State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third139Proof237 : runCachedNode 511 130638 Adaptive146Third139Node237 = false := by
  decide +kernel

#print axioms adaptive146Third139Proof237

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third139Proof88 : runCachedNode 511 130638 Adaptive146Third139Node88 = false := by
  decide +kernel

#print axioms adaptive146Third139Proof88

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third139Proof119 : runCachedNode 511 130638 Adaptive146Third139Node119 = false := by
  decide +kernel

#print axioms adaptive146Third139Proof119

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third139Proof66 : runCachedNode 511 130638 Adaptive146Third139Node66 = false := by
  decide +kernel

#print axioms adaptive146Third139Proof66

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third139Proof63 : runCachedNode 511 130638 Adaptive146Third139Node63 = false := by
  decide +kernel

#print axioms adaptive146Third139Proof63

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third139Proof116 : runCachedNode 511 130638 Adaptive146Third139Node116 = false := by
  decide +kernel

#print axioms adaptive146Third139Proof116

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third139Proof145 : runCachedNode 511 130638 Adaptive146Third139Node145 = false := by
  decide +kernel

#print axioms adaptive146Third139Proof145

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third139Proof35 : runCachedNode 511 130638 Adaptive146Third139Node35 = false := by
  decide +kernel

#print axioms adaptive146Third139Proof35

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third139Proof85 : runCachedNode 511 130638 Adaptive146Third139Node85 = false := by
  decide +kernel

#print axioms adaptive146Third139Proof85

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third139Proof142 : runCachedNode 511 130638 Adaptive146Third139Node142 = false := by
  decide +kernel

#print axioms adaptive146Third139Proof142

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third139Proof205 : runCachedNode 511 130638 Adaptive146Third139Node205 = false := by
  decide +kernel

#print axioms adaptive146Third139Proof205

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third139Proof86 : runCachedNode 511 130638 Adaptive146Third139Node86 = false := by
  decide +kernel

#print axioms adaptive146Third139Proof86

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third139Proof36 : runCachedNode 511 130638 Adaptive146Third139Node36 = false := by
  decide +kernel

#print axioms adaptive146Third139Proof36

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third139Proof235 : runCachedNode 511 130638 Adaptive146Third139Node235 = false := by
  decide +kernel

#print axioms adaptive146Third139Proof235

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third139Proof34 : runCachedNode 511 130638 Adaptive146Third139Node34 = false := by
  decide +kernel

#print axioms adaptive146Third139Proof34

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third139Proof114 : runCachedNode 511 130638 Adaptive146Third139Node114 = false := by
  decide +kernel

#print axioms adaptive146Third139Proof114

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third139Proof143 : runCachedNode 511 130638 Adaptive146Third139Node143 = false := by
  decide +kernel

#print axioms adaptive146Third139Proof143

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third139Proof208 : runCachedNode 511 130638 Adaptive146Third139Node208 = false := by
  decide +kernel

#print axioms adaptive146Third139Proof208

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third139Proof171 : runCachedNode 511 130638 Adaptive146Third139Node171 = false := by
  decide +kernel

#print axioms adaptive146Third139Proof171

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third139Proof8 : runCachedNode 511 130638 Adaptive146Third139Node8 = false := by
  decide +kernel

#print axioms adaptive146Third139Proof8

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third139Proof113 : runCachedNode 511 130638 Adaptive146Third139Node113 = false := by
  decide +kernel

#print axioms adaptive146Third139Proof113

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third139Proof47 : runCachedNode 511 130638 Adaptive146Third139Node47 = false := by
  decide +kernel

#print axioms adaptive146Third139Proof47

end NineSeparatedSubsetSums
