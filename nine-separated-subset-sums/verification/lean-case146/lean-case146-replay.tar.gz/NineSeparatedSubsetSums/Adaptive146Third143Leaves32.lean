import NineSeparatedSubsetSums.Adaptive146Third143State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third143Proof255 : runCachedNode 511 131193 Adaptive146Third143Node255 = false := by
  decide +kernel

#print axioms adaptive146Third143Proof255

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third143Proof668 : runCachedNode 511 131193 Adaptive146Third143Node668 = false := by
  decide +kernel

#print axioms adaptive146Third143Proof668

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third143Proof572 : runCachedNode 511 131193 Adaptive146Third143Node572 = false := by
  decide +kernel

#print axioms adaptive146Third143Proof572

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third143Proof72 : runCachedNode 511 131193 Adaptive146Third143Node72 = false := by
  decide +kernel

#print axioms adaptive146Third143Proof72

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third143Proof542 : runCachedNode 511 131193 Adaptive146Third143Node542 = false := by
  decide +kernel

#print axioms adaptive146Third143Proof542

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third143Proof13 : runCachedNode 511 131193 Adaptive146Third143Node13 = false := by
  decide +kernel

#print axioms adaptive146Third143Proof13

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive146Third143Proof562 : runCachedNode 511 131193 Adaptive146Third143Node562 = false := by
  decide +kernel

#print axioms adaptive146Third143Proof562

end NineSeparatedSubsetSums
