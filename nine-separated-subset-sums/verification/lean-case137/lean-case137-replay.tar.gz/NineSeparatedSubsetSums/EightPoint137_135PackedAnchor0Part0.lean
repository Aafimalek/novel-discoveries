import NineSeparatedSubsetSums.EightPoint137_135PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint137_135PackedAnchor0Part0 :
    ∀ j : Fin 120, 2445232 ≤ FourPointNumeric.octPackedCharge 137 135 20 packedOct137_135_0
      (2*((j.val : Int)+0)+0) := by decide +kernel

end NineSeparatedSubsetSums
