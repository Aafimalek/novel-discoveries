import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive137Third119Node0 : CachedSearchNode :=
  ⟨4, 118, computeCenteredMask [148,137,119], 404, 54834⟩

end NineSeparatedSubsetSums
