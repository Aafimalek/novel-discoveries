import NineSeparatedSubsetSums.EightPoint137_125PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint137_125PackedAnchor1Part2 :
    ∀ j : Fin 1, 2309643 ≤ FourPointNumeric.octPackedCharge 137 125 20 packedOct137_125_1
      (2*((j.val : Int)+240)+1) := by decide +kernel

end NineSeparatedSubsetSums
