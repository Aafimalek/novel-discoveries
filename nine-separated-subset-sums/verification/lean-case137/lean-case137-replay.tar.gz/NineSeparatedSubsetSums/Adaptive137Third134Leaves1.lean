import NineSeparatedSubsetSums.Adaptive137Third134State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third134Proof15 : runCachedNode 511 128023 Adaptive137Third134Node15 = false := by
  decide +kernel

#print axioms adaptive137Third134Proof15

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third134Proof18 : runCachedNode 511 128023 Adaptive137Third134Node18 = false := by
  decide +kernel

#print axioms adaptive137Third134Proof18

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third134Proof93 : runCachedNode 511 128023 Adaptive137Third134Node93 = false := by
  decide +kernel

#print axioms adaptive137Third134Proof93

end NineSeparatedSubsetSums
