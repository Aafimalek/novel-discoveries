import NineSeparatedSubsetSums.Adaptive137Third133State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third133Proof20 : runCachedNode 511 127870 Adaptive137Third133Node20 = false := by
  decide +kernel

#print axioms adaptive137Third133Proof20

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third133Proof14 : runCachedNode 511 127870 Adaptive137Third133Node14 = false := by
  decide +kernel

#print axioms adaptive137Third133Proof14

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third133Proof8 : runCachedNode 511 127870 Adaptive137Third133Node8 = false := by
  decide +kernel

#print axioms adaptive137Third133Proof8

end NineSeparatedSubsetSums
