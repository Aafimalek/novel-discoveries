import NineSeparatedSubsetSums.Adaptive137Third136State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third136Proof101 : runCachedNode 511 128437 Adaptive137Third136Node101 = false := by
  decide +kernel

#print axioms adaptive137Third136Proof101

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third136Proof18 : runCachedNode 511 128437 Adaptive137Third136Node18 = false := by
  decide +kernel

#print axioms adaptive137Third136Proof18

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third136Proof97 : runCachedNode 511 128437 Adaptive137Third136Node97 = false := by
  decide +kernel

#print axioms adaptive137Third136Proof97

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third136Proof9 : runCachedNode 511 128437 Adaptive137Third136Node9 = false := by
  decide +kernel

#print axioms adaptive137Third136Proof9

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third136Proof24 : runCachedNode 511 128437 Adaptive137Third136Node24 = false := by
  decide +kernel

#print axioms adaptive137Third136Proof24

end NineSeparatedSubsetSums
