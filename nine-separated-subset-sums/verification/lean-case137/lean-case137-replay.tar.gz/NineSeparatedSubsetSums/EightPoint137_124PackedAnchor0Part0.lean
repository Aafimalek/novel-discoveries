import NineSeparatedSubsetSums.EightPoint137_124PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint137_124PackedAnchor0Part0 :
    ∀ j : Fin 120, 2301319 ≤ FourPointNumeric.octPackedCharge 137 124 20 packedOct137_124_0
      (2*((j.val : Int)+0)+1) := by decide +kernel

end NineSeparatedSubsetSums
