import NineSeparatedSubsetSums.Adaptive137Third135State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third135Proof13 : runCachedNode 511 128257 Adaptive137Third135Node13 = false := by
  decide +kernel

#print axioms adaptive137Third135Proof13

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third135Proof68 : runCachedNode 511 128257 Adaptive137Third135Node68 = false := by
  decide +kernel

#print axioms adaptive137Third135Proof68

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third135Proof71 : runCachedNode 511 128257 Adaptive137Third135Node71 = false := by
  decide +kernel

#print axioms adaptive137Third135Proof71

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third135Proof11 : runCachedNode 511 128257 Adaptive137Third135Node11 = false := by
  decide +kernel

#print axioms adaptive137Third135Proof11

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third135Proof39 : runCachedNode 511 128257 Adaptive137Third135Node39 = false := by
  decide +kernel

#print axioms adaptive137Third135Proof39

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third135Proof41 : runCachedNode 511 128257 Adaptive137Third135Node41 = false := by
  decide +kernel

#print axioms adaptive137Third135Proof41

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third135Proof70 : runCachedNode 511 128257 Adaptive137Third135Node70 = false := by
  decide +kernel

#print axioms adaptive137Third135Proof70

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third135Proof9 : runCachedNode 511 128257 Adaptive137Third135Node9 = false := by
  decide +kernel

#print axioms adaptive137Third135Proof9

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third135Proof37 : runCachedNode 511 128257 Adaptive137Third135Node37 = false := by
  decide +kernel

#print axioms adaptive137Third135Proof37

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third135Proof8 : runCachedNode 511 128257 Adaptive137Third135Node8 = false := by
  decide +kernel

#print axioms adaptive137Third135Proof8

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third135Proof38 : runCachedNode 511 128257 Adaptive137Third135Node38 = false := by
  decide +kernel

#print axioms adaptive137Third135Proof38

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third135Proof65 : runCachedNode 511 128257 Adaptive137Third135Node65 = false := by
  decide +kernel

#print axioms adaptive137Third135Proof65

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third135Proof7 : runCachedNode 511 128257 Adaptive137Third135Node7 = false := by
  decide +kernel

#print axioms adaptive137Third135Proof7

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third135Proof6 : runCachedNode 511 128257 Adaptive137Third135Node6 = false := by
  decide +kernel

#print axioms adaptive137Third135Proof6

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third135Proof35 : runCachedNode 511 128257 Adaptive137Third135Node35 = false := by
  decide +kernel

#print axioms adaptive137Third135Proof35

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third135Proof36 : runCachedNode 511 128257 Adaptive137Third135Node36 = false := by
  decide +kernel

#print axioms adaptive137Third135Proof36

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third135Proof64 : runCachedNode 511 128257 Adaptive137Third135Node64 = false := by
  decide +kernel

#print axioms adaptive137Third135Proof64

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third135Proof63 : runCachedNode 511 128257 Adaptive137Third135Node63 = false := by
  decide +kernel

#print axioms adaptive137Third135Proof63

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third135Proof5 : runCachedNode 511 128257 Adaptive137Third135Node5 = false := by
  decide +kernel

#print axioms adaptive137Third135Proof5

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third135Proof34 : runCachedNode 511 128257 Adaptive137Third135Node34 = false := by
  decide +kernel

#print axioms adaptive137Third135Proof34

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third135Proof31 : runCachedNode 511 128257 Adaptive137Third135Node31 = false := by
  decide +kernel

#print axioms adaptive137Third135Proof31

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third135Proof32 : runCachedNode 511 128257 Adaptive137Third135Node32 = false := by
  decide +kernel

#print axioms adaptive137Third135Proof32

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third135Proof24 : runCachedNode 511 128257 Adaptive137Third135Node24 = false := by
  decide +kernel

#print axioms adaptive137Third135Proof24

end NineSeparatedSubsetSums
