import NineSeparatedSubsetSums.EightPoint137_130PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct137_130_0_budget :
    FourPointNumeric.packedBudget 20 packedOct137_130_0 451 = 88485503 := by decide +kernel

#print axioms packedOct137_130_0_budget

end NineSeparatedSubsetSums
