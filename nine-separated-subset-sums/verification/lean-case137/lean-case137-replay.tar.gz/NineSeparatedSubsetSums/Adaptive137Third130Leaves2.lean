import NineSeparatedSubsetSums.Adaptive137Third130State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third130Proof13 : runCachedNode 511 127329 Adaptive137Third130Node13 = false := by
  decide +kernel

#print axioms adaptive137Third130Proof13

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third130Proof12 : runCachedNode 511 127329 Adaptive137Third130Node12 = false := by
  decide +kernel

#print axioms adaptive137Third130Proof12

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third130Proof10 : runCachedNode 511 127329 Adaptive137Third130Node10 = false := by
  decide +kernel

#print axioms adaptive137Third130Proof10

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third130Proof8 : runCachedNode 511 127329 Adaptive137Third130Node8 = false := by
  decide +kernel

#print axioms adaptive137Third130Proof8

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third130Proof7 : runCachedNode 511 127329 Adaptive137Third130Node7 = false := by
  decide +kernel

#print axioms adaptive137Third130Proof7

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third130Proof6 : runCachedNode 511 127329 Adaptive137Third130Node6 = false := by
  decide +kernel

#print axioms adaptive137Third130Proof6

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third130Proof4 : runCachedNode 511 127329 Adaptive137Third130Node4 = false := by
  decide +kernel

#print axioms adaptive137Third130Proof4

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third130Proof3 : runCachedNode 511 127329 Adaptive137Third130Node3 = false := by
  decide +kernel

#print axioms adaptive137Third130Proof3

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third130Proof1 : runCachedNode 511 127329 Adaptive137Third130Node1 = false := by
  decide +kernel

#print axioms adaptive137Third130Proof1

end NineSeparatedSubsetSums
