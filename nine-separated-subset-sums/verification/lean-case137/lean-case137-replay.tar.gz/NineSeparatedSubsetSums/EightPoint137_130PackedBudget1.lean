import NineSeparatedSubsetSums.EightPoint137_130PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct137_130_1_budget :
    FourPointNumeric.packedBudget 20 packedOct137_130_1 450 = 88460880 := by decide +kernel

#print axioms packedOct137_130_1_budget

end NineSeparatedSubsetSums
