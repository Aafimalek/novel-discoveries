import NineSeparatedSubsetSums.Adaptive137Third136State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third136Proof116 : runCachedNode 511 128437 Adaptive137Third136Node116 = false := by
  decide +kernel

#print axioms adaptive137Third136Proof116

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third136Proof2 : runCachedNode 511 128437 Adaptive137Third136Node2 = false := by
  decide +kernel

#print axioms adaptive137Third136Proof2

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third136Proof25 : runCachedNode 511 128437 Adaptive137Third136Node25 = false := by
  decide +kernel

#print axioms adaptive137Third136Proof25

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third136Proof26 : runCachedNode 511 128437 Adaptive137Third136Node26 = false := by
  decide +kernel

#print axioms adaptive137Third136Proof26

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third136Proof52 : runCachedNode 511 128437 Adaptive137Third136Node52 = false := by
  decide +kernel

#print axioms adaptive137Third136Proof52

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third136Proof78 : runCachedNode 511 128437 Adaptive137Third136Node78 = false := by
  decide +kernel

#print axioms adaptive137Third136Proof78

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third136Proof108 : runCachedNode 511 128437 Adaptive137Third136Node108 = false := by
  decide +kernel

#print axioms adaptive137Third136Proof108

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third136Proof51 : runCachedNode 511 128437 Adaptive137Third136Node51 = false := by
  decide +kernel

#print axioms adaptive137Third136Proof51

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third136Proof77 : runCachedNode 511 128437 Adaptive137Third136Node77 = false := by
  decide +kernel

#print axioms adaptive137Third136Proof77

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third136Proof104 : runCachedNode 511 128437 Adaptive137Third136Node104 = false := by
  decide +kernel

#print axioms adaptive137Third136Proof104

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third136Proof105 : runCachedNode 511 128437 Adaptive137Third136Node105 = false := by
  decide +kernel

#print axioms adaptive137Third136Proof105

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third136Proof106 : runCachedNode 511 128437 Adaptive137Third136Node106 = false := by
  decide +kernel

#print axioms adaptive137Third136Proof106

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third136Proof107 : runCachedNode 511 128437 Adaptive137Third136Node107 = false := by
  decide +kernel

#print axioms adaptive137Third136Proof107

end NineSeparatedSubsetSums
