import NineSeparatedSubsetSums.Adaptive137Third117State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third117Proof0 : runCachedNode 511 124504 Adaptive137Third117Node0 = false := by
  decide +kernel

#print axioms adaptive137Third117Proof0

end NineSeparatedSubsetSums
