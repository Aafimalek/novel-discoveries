import NineSeparatedSubsetSums.Adaptive137Third135State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third135Proof74 : runCachedNode 511 128257 Adaptive137Third135Node74 = false := by
  decide +kernel

#print axioms adaptive137Third135Proof74

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third135Proof40 : runCachedNode 511 128257 Adaptive137Third135Node40 = false := by
  decide +kernel

#print axioms adaptive137Third135Proof40

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third135Proof3 : runCachedNode 511 128257 Adaptive137Third135Node3 = false := by
  decide +kernel

#print axioms adaptive137Third135Proof3

end NineSeparatedSubsetSums
