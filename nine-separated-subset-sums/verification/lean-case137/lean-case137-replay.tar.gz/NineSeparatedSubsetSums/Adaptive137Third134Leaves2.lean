import NineSeparatedSubsetSums.Adaptive137Third134State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third134Proof67 : runCachedNode 511 128023 Adaptive137Third134Node67 = false := by
  decide +kernel

#print axioms adaptive137Third134Proof67

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third134Proof16 : runCachedNode 511 128023 Adaptive137Third134Node16 = false := by
  decide +kernel

#print axioms adaptive137Third134Proof16

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third134Proof92 : runCachedNode 511 128023 Adaptive137Third134Node92 = false := by
  decide +kernel

#print axioms adaptive137Third134Proof92

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third134Proof88 : runCachedNode 511 128023 Adaptive137Third134Node88 = false := by
  decide +kernel

#print axioms adaptive137Third134Proof88

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third134Proof1 : runCachedNode 511 128023 Adaptive137Third134Node1 = false := by
  decide +kernel

#print axioms adaptive137Third134Proof1

end NineSeparatedSubsetSums
