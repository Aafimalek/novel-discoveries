import NineSeparatedSubsetSums.EightPointPackedGeometry
import NineSeparatedSubsetSums.EightPoint137_132PackedBudget0
import NineSeparatedSubsetSums.EightPoint137_132PackedAnchor0Part0
import NineSeparatedSubsetSums.EightPoint137_132PackedAnchor0Part1
import NineSeparatedSubsetSums.EightPoint137_132PackedAnchor0Part2
import NineSeparatedSubsetSums.EightPoint137_132PackedBudget1
import NineSeparatedSubsetSums.EightPoint137_132PackedAnchor1Part0
import NineSeparatedSubsetSums.EightPoint137_132PackedAnchor1Part1
import NineSeparatedSubsetSums.EightPoint137_132PackedAnchor1Part2

namespace NineSeparatedSubsetSums

private theorem packedOct137_132Anchor0 :
  ∀ j : Fin 495, ((j.val : Int)+137+132)%2=0 →
    2418222 ≤ FourPointNumeric.octPackedCharge 137 132 20 packedOct137_132_0 (j.val : Int) := by
  intro j hj
  let k := (j.val-1)/2
  have hk : k < 247 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+1 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint137_132PackedAnchor0Part0 z
    rwa [he,hrep] at ht
  by_cases h1 : k < 240
  · let z : Fin 120 := ⟨k-120, by omega⟩
    have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
    have ht := eightPoint137_132PackedAnchor0Part1 z
    rwa [he,hrep] at ht
  let z : Fin 7 := ⟨k-240, by omega⟩
  have he : (z.val : Int)+240 = k := by dsimp [z] <;> omega
  have ht := eightPoint137_132PackedAnchor0Part2 z
  rwa [he,hrep] at ht

private theorem packedOct137_132Anchor1 :
  ∀ j : Fin 495, ((j.val : Int)+137+132)%2=1 →
    2418902 ≤ FourPointNumeric.octPackedCharge 137 132 20 packedOct137_132_1 (j.val : Int) := by
  intro j hj
  let k := (j.val-0)/2
  have hk : k < 248 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+0 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint137_132PackedAnchor1Part0 z
    rwa [he,hrep] at ht
  by_cases h1 : k < 240
  · let z : Fin 120 := ⟨k-120, by omega⟩
    have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
    have ht := eightPoint137_132PackedAnchor1Part1 z
    rwa [he,hrep] at ht
  let z : Fin 8 := ⟨k-240, by omega⟩
  have he : (z.val : Int)+240 = k := by dsimp [z] <;> omega
  have ht := eightPoint137_132PackedAnchor1Part2 z
  rwa [he,hrep] at ht

def packedOctCertificate137_132_0 : EightPointCertificate 137 132 0 127744 :=
  eightPointCertificateOfPacked 137 132 0 127744 2418222 20 packedOct137_132_0 273 495
    (by decide +kernel) (by decide) packedOct137_132Anchor0
    (by rw [packedOct137_132_0_budget]; decide)

def packedOctCertificate137_132_1 : EightPointCertificate 137 132 1 127744 :=
  eightPointCertificateOfPacked 137 132 1 127744 2418902 20 packedOct137_132_1 274 495
    (by decide +kernel) (by decide) packedOct137_132Anchor1
    (by rw [packedOct137_132_1_budget]; decide)

theorem max148_second137_third132_eightPoint_moment_bound (tail : List ℕ) (len : tail.length=6)
    (distinct : (natSubsetSums (148::137::132::tail)).Nodup) :
    127744 ≤ ((148::137::132::tail).map (· ^ 2)).sum := by
  apply eightPointNatMomentLower 137 132 127744 tail len distinct
  intro p hp
  by_cases h : p=0
  · subst p
    exact packedOctCertificate137_132_0
  · have he : p=1 := hp.resolve_left h
    subst p
    exact packedOctCertificate137_132_1

#print axioms max148_second137_third132_eightPoint_moment_bound

end NineSeparatedSubsetSums
