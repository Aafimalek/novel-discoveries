import NineSeparatedSubsetSums.Adaptive137Third129State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third129Proof15 : runCachedNode 511 127136 Adaptive137Third129Node15 = false := by
  decide +kernel

#print axioms adaptive137Third129Proof15

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third129Proof17 : runCachedNode 511 127136 Adaptive137Third129Node17 = false := by
  decide +kernel

#print axioms adaptive137Third129Proof17

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third129Proof14 : runCachedNode 511 127136 Adaptive137Third129Node14 = false := by
  decide +kernel

#print axioms adaptive137Third129Proof14

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third129Proof7 : runCachedNode 511 127136 Adaptive137Third129Node7 = false := by
  decide +kernel

#print axioms adaptive137Third129Proof7

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third129Proof1 : runCachedNode 511 127136 Adaptive137Third129Node1 = false := by
  decide +kernel

#print axioms adaptive137Third129Proof1

end NineSeparatedSubsetSums
