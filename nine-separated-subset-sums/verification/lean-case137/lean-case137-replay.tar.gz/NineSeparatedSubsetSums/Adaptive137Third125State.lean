import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive137Third125Node0 : CachedSearchNode :=
  ⟨4, 124, computeCenteredMask [148,137,125], 410, 56298⟩

end NineSeparatedSubsetSums
