import NineSeparatedSubsetSums.Adaptive137Third126State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third126Proof9 : runCachedNode 511 126757 Adaptive137Third126Node9 = false := by
  decide +kernel

#print axioms adaptive137Third126Proof9

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third126Proof8 : runCachedNode 511 126757 Adaptive137Third126Node8 = false := by
  decide +kernel

#print axioms adaptive137Third126Proof8

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third126Proof7 : runCachedNode 511 126757 Adaptive137Third126Node7 = false := by
  decide +kernel

#print axioms adaptive137Third126Proof7

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third126Proof6 : runCachedNode 511 126757 Adaptive137Third126Node6 = false := by
  decide +kernel

#print axioms adaptive137Third126Proof6

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third126Proof5 : runCachedNode 511 126757 Adaptive137Third126Node5 = false := by
  decide +kernel

#print axioms adaptive137Third126Proof5

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third126Proof3 : runCachedNode 511 126757 Adaptive137Third126Node3 = false := by
  decide +kernel

#print axioms adaptive137Third126Proof3

end NineSeparatedSubsetSums
