import NineSeparatedSubsetSums.Adaptive137Third133State
import NineSeparatedSubsetSums.Adaptive137Third133Leaves0
import NineSeparatedSubsetSums.Adaptive137Third133Leaves2
import NineSeparatedSubsetSums.Adaptive137Third133Leaves4
import NineSeparatedSubsetSums.Adaptive137Third133Leaves1
import NineSeparatedSubsetSums.Adaptive137Third133Leaves3

namespace NineSeparatedSubsetSums

theorem adaptive137Third133Proof0 : runCachedNode 511 127870 Adaptive137Third133Node0 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 127870 Adaptive137Third133Node0 = [111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 123, 124, 125, 126, 127, 128, 129, 130, 131, 132] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive137Third133Proof1
  · exact adaptive137Third133Proof2
  · exact adaptive137Third133Proof3
  · exact adaptive137Third133Proof4
  · exact adaptive137Third133Proof5
  · exact adaptive137Third133Proof6
  · exact adaptive137Third133Proof7
  · exact adaptive137Third133Proof8
  · exact adaptive137Third133Proof9
  · exact adaptive137Third133Proof10
  · exact adaptive137Third133Proof11
  · exact adaptive137Third133Proof12
  · exact adaptive137Third133Proof13
  · exact adaptive137Third133Proof14
  · exact adaptive137Third133Proof15
  · exact adaptive137Third133Proof16
  · exact adaptive137Third133Proof17
  · exact adaptive137Third133Proof18
  · exact adaptive137Third133Proof19
  · exact adaptive137Third133Proof20
  · exact adaptive137Third133Proof21

#print axioms adaptive137Third133Proof0

end NineSeparatedSubsetSums
