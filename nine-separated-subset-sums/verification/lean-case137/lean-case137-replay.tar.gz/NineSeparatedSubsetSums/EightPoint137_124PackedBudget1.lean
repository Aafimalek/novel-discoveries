import NineSeparatedSubsetSums.EightPoint137_124PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct137_124_1_budget :
    FourPointNumeric.packedBudget 20 packedOct137_124_1 254 = 82755938 := by decide +kernel

#print axioms packedOct137_124_1_budget

end NineSeparatedSubsetSums
