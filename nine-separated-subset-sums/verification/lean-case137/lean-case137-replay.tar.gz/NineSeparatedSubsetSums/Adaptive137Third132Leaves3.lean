import NineSeparatedSubsetSums.Adaptive137Third132State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third132Proof14 : runCachedNode 511 127744 Adaptive137Third132Node14 = false := by
  decide +kernel

#print axioms adaptive137Third132Proof14

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third132Proof13 : runCachedNode 511 127744 Adaptive137Third132Node13 = false := by
  decide +kernel

#print axioms adaptive137Third132Proof13

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third132Proof12 : runCachedNode 511 127744 Adaptive137Third132Node12 = false := by
  decide +kernel

#print axioms adaptive137Third132Proof12

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third132Proof11 : runCachedNode 511 127744 Adaptive137Third132Node11 = false := by
  decide +kernel

#print axioms adaptive137Third132Proof11

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third132Proof10 : runCachedNode 511 127744 Adaptive137Third132Node10 = false := by
  decide +kernel

#print axioms adaptive137Third132Proof10

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third132Proof8 : runCachedNode 511 127744 Adaptive137Third132Node8 = false := by
  decide +kernel

#print axioms adaptive137Third132Proof8

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third132Proof6 : runCachedNode 511 127744 Adaptive137Third132Node6 = false := by
  decide +kernel

#print axioms adaptive137Third132Proof6

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third132Proof7 : runCachedNode 511 127744 Adaptive137Third132Node7 = false := by
  decide +kernel

#print axioms adaptive137Third132Proof7

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third132Proof5 : runCachedNode 511 127744 Adaptive137Third132Node5 = false := by
  decide +kernel

#print axioms adaptive137Third132Proof5

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third132Proof4 : runCachedNode 511 127744 Adaptive137Third132Node4 = false := by
  decide +kernel

#print axioms adaptive137Third132Proof4

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third132Proof2 : runCachedNode 511 127744 Adaptive137Third132Node2 = false := by
  decide +kernel

#print axioms adaptive137Third132Proof2

end NineSeparatedSubsetSums
