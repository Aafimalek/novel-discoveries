import NineSeparatedSubsetSums.Adaptive137Third136State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third136Proof102 : runCachedNode 511 128437 Adaptive137Third136Node102 = false := by
  decide +kernel

#print axioms adaptive137Third136Proof102

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third136Proof19 : runCachedNode 511 128437 Adaptive137Third136Node19 = false := by
  decide +kernel

#print axioms adaptive137Third136Proof19

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third136Proof8 : runCachedNode 511 128437 Adaptive137Third136Node8 = false := by
  decide +kernel

#print axioms adaptive137Third136Proof8

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third136Proof53 : runCachedNode 511 128437 Adaptive137Third136Node53 = false := by
  decide +kernel

#print axioms adaptive137Third136Proof53

end NineSeparatedSubsetSums
