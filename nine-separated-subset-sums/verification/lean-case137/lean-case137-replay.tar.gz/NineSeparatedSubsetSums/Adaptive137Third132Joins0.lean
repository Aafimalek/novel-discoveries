import NineSeparatedSubsetSums.Adaptive137Third132State
import NineSeparatedSubsetSums.Adaptive137Third132Leaves0
import NineSeparatedSubsetSums.Adaptive137Third132Leaves3
import NineSeparatedSubsetSums.Adaptive137Third132Leaves1
import NineSeparatedSubsetSums.Adaptive137Third132Leaves2

namespace NineSeparatedSubsetSums

theorem adaptive137Third132Proof0 : runCachedNode 511 127744 Adaptive137Third132Node0 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 127744 Adaptive137Third132Node0 = [111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive137Third132Proof1
  · exact adaptive137Third132Proof2
  · exact adaptive137Third132Proof3
  · exact adaptive137Third132Proof4
  · exact adaptive137Third132Proof5
  · exact adaptive137Third132Proof6
  · exact adaptive137Third132Proof7
  · exact adaptive137Third132Proof8
  · exact adaptive137Third132Proof9
  · exact adaptive137Third132Proof10
  · exact adaptive137Third132Proof11
  · exact adaptive137Third132Proof12
  · exact adaptive137Third132Proof13
  · exact adaptive137Third132Proof14
  · exact adaptive137Third132Proof15
  · exact adaptive137Third132Proof16
  · exact adaptive137Third132Proof17
  · exact adaptive137Third132Proof18
  · exact adaptive137Third132Proof19
  · exact adaptive137Third132Proof20

#print axioms adaptive137Third132Proof0

end NineSeparatedSubsetSums
