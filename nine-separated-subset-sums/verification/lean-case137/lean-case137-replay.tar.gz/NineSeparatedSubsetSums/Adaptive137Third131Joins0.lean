import NineSeparatedSubsetSums.Adaptive137Third131State
import NineSeparatedSubsetSums.Adaptive137Third131Leaves0
import NineSeparatedSubsetSums.Adaptive137Third131Leaves2
import NineSeparatedSubsetSums.Adaptive137Third131Leaves1

namespace NineSeparatedSubsetSums

theorem adaptive137Third131Proof0 : runCachedNode 511 127537 Adaptive137Third131Node0 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 127537 Adaptive137Third131Node0 = [111, 112, 113, 114, 115, 116, 117, 118, 119, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive137Third131Proof1
  · exact adaptive137Third131Proof2
  · exact adaptive137Third131Proof3
  · exact adaptive137Third131Proof4
  · exact adaptive137Third131Proof5
  · exact adaptive137Third131Proof6
  · exact adaptive137Third131Proof7
  · exact adaptive137Third131Proof8
  · exact adaptive137Third131Proof9
  · exact adaptive137Third131Proof10
  · exact adaptive137Third131Proof11
  · exact adaptive137Third131Proof12
  · exact adaptive137Third131Proof13
  · exact adaptive137Third131Proof14
  · exact adaptive137Third131Proof15
  · exact adaptive137Third131Proof16
  · exact adaptive137Third131Proof17
  · exact adaptive137Third131Proof18
  · exact adaptive137Third131Proof19

#print axioms adaptive137Third131Proof0

end NineSeparatedSubsetSums
