import NineSeparatedSubsetSums.EightPoint137_120PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint137_120PackedAnchor1Part1 :
    ∀ j : Fin 120, 2337521 ≤ FourPointNumeric.octPackedCharge 137 120 20 packedOct137_120_1
      (2*((j.val : Int)+120)+0) := by decide +kernel

end NineSeparatedSubsetSums
