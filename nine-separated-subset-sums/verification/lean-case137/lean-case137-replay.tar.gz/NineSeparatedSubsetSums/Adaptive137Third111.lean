import NineSeparatedSubsetSums.Adaptive137Third111Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint137Checked

namespace NineSeparatedSubsetSums


theorem adaptive137Third111 : NoDescendingTailAfterThird 137 111 :=
  noDescendingThirdTail_of_cached 137 111 111041 (fun t ht nd => max148_second137_fourPoint_moment_bound (111::t) (by simp [ht]) nd) adaptive137Third111Proof0

#print axioms adaptive137Third111

end NineSeparatedSubsetSums
