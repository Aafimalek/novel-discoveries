import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive137Third108Node0 : CachedSearchNode :=
  ⟨4, 107, computeCenteredMask [148,137,108], 393, 52337⟩

end NineSeparatedSubsetSums
