import NineSeparatedSubsetSums.EightPoint137_121PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint137_121PackedAnchor0Part1 :
    ∀ j : Fin 120, 2333641 ≤ FourPointNumeric.octPackedCharge 137 121 20 packedOct137_121_0
      (2*((j.val : Int)+120)+0) := by decide +kernel

end NineSeparatedSubsetSums
