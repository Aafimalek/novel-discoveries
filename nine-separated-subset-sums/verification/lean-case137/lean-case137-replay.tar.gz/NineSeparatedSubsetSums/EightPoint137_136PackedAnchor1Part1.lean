import NineSeparatedSubsetSums.EightPoint137_136PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint137_136PackedAnchor1Part1 :
    ∀ j : Fin 120, 2447411 ≤ FourPointNumeric.octPackedCharge 137 136 20 packedOct137_136_1
      (2*((j.val : Int)+120)+0) := by decide +kernel

end NineSeparatedSubsetSums
