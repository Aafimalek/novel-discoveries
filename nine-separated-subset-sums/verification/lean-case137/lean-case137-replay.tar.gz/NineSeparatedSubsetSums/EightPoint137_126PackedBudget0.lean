import NineSeparatedSubsetSums.EightPoint137_126PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct137_126_0_budget :
    FourPointNumeric.packedBudget 20 packedOct137_126_0 407 = 85208591 := by decide +kernel

#print axioms packedOct137_126_0_budget

end NineSeparatedSubsetSums
