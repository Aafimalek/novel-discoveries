import NineSeparatedSubsetSums.Adaptive137Third115State
import NineSeparatedSubsetSums.Adaptive137Third115Leaves1
import NineSeparatedSubsetSums.Adaptive137Third115Leaves0

namespace NineSeparatedSubsetSums

theorem adaptive137Third115Proof0 : runCachedNode 511 111041 Adaptive137Third115Node0 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 111041 Adaptive137Third115Node0 = [101, 102, 103, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive137Third115Proof1
  · exact adaptive137Third115Proof2
  · exact adaptive137Third115Proof3
  · exact adaptive137Third115Proof4
  · exact adaptive137Third115Proof5
  · exact adaptive137Third115Proof6
  · exact adaptive137Third115Proof7
  · exact adaptive137Third115Proof8
  · exact adaptive137Third115Proof9
  · exact adaptive137Third115Proof10
  · exact adaptive137Third115Proof11
  · exact adaptive137Third115Proof12
  · exact adaptive137Third115Proof13

#print axioms adaptive137Third115Proof0

end NineSeparatedSubsetSums
