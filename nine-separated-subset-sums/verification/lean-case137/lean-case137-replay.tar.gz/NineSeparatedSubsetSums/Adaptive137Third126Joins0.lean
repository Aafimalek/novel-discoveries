import NineSeparatedSubsetSums.Adaptive137Third126State
import NineSeparatedSubsetSums.Adaptive137Third126Leaves0
import NineSeparatedSubsetSums.Adaptive137Third126Leaves1

namespace NineSeparatedSubsetSums

theorem adaptive137Third126Proof0 : runCachedNode 511 126757 Adaptive137Third126Node0 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 126757 Adaptive137Third126Node0 = [111, 112, 113, 114, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive137Third126Proof1
  · exact adaptive137Third126Proof2
  · exact adaptive137Third126Proof3
  · exact adaptive137Third126Proof4
  · exact adaptive137Third126Proof5
  · exact adaptive137Third126Proof6
  · exact adaptive137Third126Proof7
  · exact adaptive137Third126Proof8
  · exact adaptive137Third126Proof9
  · exact adaptive137Third126Proof10
  · exact adaptive137Third126Proof11
  · exact adaptive137Third126Proof12
  · exact adaptive137Third126Proof13
  · exact adaptive137Third126Proof14

#print axioms adaptive137Third126Proof0

end NineSeparatedSubsetSums
