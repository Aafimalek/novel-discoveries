import NineSeparatedSubsetSums.EightPoint137_133PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct137_133_0_budget :
    FourPointNumeric.packedBudget 20 packedOct137_133_0 277 = 88777204 := by decide +kernel

#print axioms packedOct137_133_0_budget

end NineSeparatedSubsetSums
