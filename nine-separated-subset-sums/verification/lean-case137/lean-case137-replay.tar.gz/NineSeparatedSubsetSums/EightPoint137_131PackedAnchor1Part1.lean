import NineSeparatedSubsetSums.EightPoint137_131PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint137_131PackedAnchor1Part1 :
    ∀ j : Fin 120, 2420837 ≤ FourPointNumeric.octPackedCharge 137 131 20 packedOct137_131_1
      (2*((j.val : Int)+120)+1) := by decide +kernel

end NineSeparatedSubsetSums
