import NineSeparatedSubsetSums.EightPoint137_132PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct137_132_1_budget :
    FourPointNumeric.packedBudget 20 packedOct137_132_1 274 = 89404938 := by decide +kernel

#print axioms packedOct137_132_1_budget

end NineSeparatedSubsetSums
