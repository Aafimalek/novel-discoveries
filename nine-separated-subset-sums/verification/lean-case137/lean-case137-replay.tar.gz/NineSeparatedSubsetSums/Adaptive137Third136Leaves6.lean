import NineSeparatedSubsetSums.Adaptive137Third136State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third136Proof133 : runCachedNode 511 128437 Adaptive137Third136Node133 = false := by
  decide +kernel

#print axioms adaptive137Third136Proof133

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third136Proof74 : runCachedNode 511 128437 Adaptive137Third136Node74 = false := by
  decide +kernel

#print axioms adaptive137Third136Proof74

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third136Proof48 : runCachedNode 511 128437 Adaptive137Third136Node48 = false := by
  decide +kernel

#print axioms adaptive137Third136Proof48

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third136Proof98 : runCachedNode 511 128437 Adaptive137Third136Node98 = false := by
  decide +kernel

#print axioms adaptive137Third136Proof98

end NineSeparatedSubsetSums
