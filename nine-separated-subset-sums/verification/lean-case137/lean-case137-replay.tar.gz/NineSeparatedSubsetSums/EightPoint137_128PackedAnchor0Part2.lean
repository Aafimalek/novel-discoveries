import NineSeparatedSubsetSums.EightPoint137_128PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint137_128PackedAnchor0Part2 :
    ∀ j : Fin 3, 2344577 ≤ FourPointNumeric.octPackedCharge 137 128 20 packedOct137_128_0
      (2*((j.val : Int)+240)+1) := by decide +kernel

end NineSeparatedSubsetSums
