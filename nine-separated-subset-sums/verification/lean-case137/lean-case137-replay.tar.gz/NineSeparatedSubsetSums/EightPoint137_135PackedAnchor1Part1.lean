import NineSeparatedSubsetSums.EightPoint137_135PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint137_135PackedAnchor1Part1 :
    ∀ j : Fin 120, 2444092 ≤ FourPointNumeric.octPackedCharge 137 135 20 packedOct137_135_1
      (2*((j.val : Int)+120)+1) := by decide +kernel

end NineSeparatedSubsetSums
