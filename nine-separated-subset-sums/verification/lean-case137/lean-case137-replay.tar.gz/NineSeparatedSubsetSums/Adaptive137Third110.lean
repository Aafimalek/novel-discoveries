import NineSeparatedSubsetSums.Adaptive137Third110Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint137Checked

namespace NineSeparatedSubsetSums


theorem adaptive137Third110 : NoDescendingTailAfterThird 137 110 :=
  noDescendingThirdTail_of_cached 137 110 111041 (fun t ht nd => max148_second137_fourPoint_moment_bound (110::t) (by simp [ht]) nd) adaptive137Third110Proof0

#print axioms adaptive137Third110

end NineSeparatedSubsetSums
