import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive137Third107Node0 : CachedSearchNode :=
  ⟨4, 106, computeCenteredMask [148,137,107], 392, 52122⟩

end NineSeparatedSubsetSums
