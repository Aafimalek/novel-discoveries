import NineSeparatedSubsetSums.EightPoint137_118PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct137_118_1_budget :
    FourPointNumeric.packedBudget 20 packedOct137_118_1 490 = 82179166 := by decide +kernel

#print axioms packedOct137_118_1_budget

end NineSeparatedSubsetSums
