import NineSeparatedSubsetSums.FourPoint137PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedWeight137_1_budget :
    FourPointNumeric.packedBudget 20 packedWeight137_1 368 = 84687040 := by decide +kernel

#print axioms packedWeight137_1_budget

end NineSeparatedSubsetSums
