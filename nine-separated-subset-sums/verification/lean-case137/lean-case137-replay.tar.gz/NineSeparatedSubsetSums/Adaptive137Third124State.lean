import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive137Third124Node0 : CachedSearchNode :=
  ⟨4, 123, computeCenteredMask [148,137,124], 409, 56049⟩

end NineSeparatedSubsetSums
