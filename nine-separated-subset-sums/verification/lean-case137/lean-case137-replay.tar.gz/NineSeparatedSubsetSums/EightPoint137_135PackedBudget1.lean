import NineSeparatedSubsetSums.EightPoint137_135PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct137_135_1_budget :
    FourPointNumeric.packedBudget 20 packedOct137_135_1 368 = 90754786 := by decide +kernel

#print axioms packedOct137_135_1_budget

end NineSeparatedSubsetSums
