import NineSeparatedSubsetSums.Adaptive137Third108Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint137Checked

namespace NineSeparatedSubsetSums


theorem adaptive137Third108 : NoDescendingTailAfterThird 137 108 :=
  noDescendingThirdTail_of_cached 137 108 111041 (fun t ht nd => max148_second137_fourPoint_moment_bound (108::t) (by simp [ht]) nd) adaptive137Third108Proof0

#print axioms adaptive137Third108

end NineSeparatedSubsetSums
