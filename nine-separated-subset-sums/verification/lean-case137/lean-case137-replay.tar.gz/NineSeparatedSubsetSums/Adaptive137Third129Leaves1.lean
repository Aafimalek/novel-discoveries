import NineSeparatedSubsetSums.Adaptive137Third129State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third129Proof16 : runCachedNode 511 127136 Adaptive137Third129Node16 = false := by
  decide +kernel

#print axioms adaptive137Third129Proof16

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third129Proof13 : runCachedNode 511 127136 Adaptive137Third129Node13 = false := by
  decide +kernel

#print axioms adaptive137Third129Proof13

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third129Proof12 : runCachedNode 511 127136 Adaptive137Third129Node12 = false := by
  decide +kernel

#print axioms adaptive137Third129Proof12

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third129Proof11 : runCachedNode 511 127136 Adaptive137Third129Node11 = false := by
  decide +kernel

#print axioms adaptive137Third129Proof11

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third129Proof10 : runCachedNode 511 127136 Adaptive137Third129Node10 = false := by
  decide +kernel

#print axioms adaptive137Third129Proof10

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third129Proof9 : runCachedNode 511 127136 Adaptive137Third129Node9 = false := by
  decide +kernel

#print axioms adaptive137Third129Proof9

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third129Proof8 : runCachedNode 511 127136 Adaptive137Third129Node8 = false := by
  decide +kernel

#print axioms adaptive137Third129Proof8

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third129Proof6 : runCachedNode 511 127136 Adaptive137Third129Node6 = false := by
  decide +kernel

#print axioms adaptive137Third129Proof6

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third129Proof4 : runCachedNode 511 127136 Adaptive137Third129Node4 = false := by
  decide +kernel

#print axioms adaptive137Third129Proof4

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third129Proof5 : runCachedNode 511 127136 Adaptive137Third129Node5 = false := by
  decide +kernel

#print axioms adaptive137Third129Proof5

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third129Proof3 : runCachedNode 511 127136 Adaptive137Third129Node3 = false := by
  decide +kernel

#print axioms adaptive137Third129Proof3

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third129Proof2 : runCachedNode 511 127136 Adaptive137Third129Node2 = false := by
  decide +kernel

#print axioms adaptive137Third129Proof2

end NineSeparatedSubsetSums
