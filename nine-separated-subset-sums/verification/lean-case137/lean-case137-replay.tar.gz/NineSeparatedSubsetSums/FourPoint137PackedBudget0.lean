import NineSeparatedSubsetSums.FourPoint137PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedWeight137_0_budget :
    FourPointNumeric.packedBudget 20 packedWeight137_0 365 = 84687040 := by decide +kernel

#print axioms packedWeight137_0_budget

end NineSeparatedSubsetSums
