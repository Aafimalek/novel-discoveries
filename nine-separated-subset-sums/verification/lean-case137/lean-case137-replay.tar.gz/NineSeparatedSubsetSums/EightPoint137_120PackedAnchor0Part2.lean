import NineSeparatedSubsetSums.EightPoint137_120PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint137_120PackedAnchor0Part2 :
    ∀ j : Fin 3, 2337234 ≤ FourPointNumeric.octPackedCharge 137 120 20 packedOct137_120_0
      (2*((j.val : Int)+240)+1) := by decide +kernel

end NineSeparatedSubsetSums
