import NineSeparatedSubsetSums.Adaptive137Third136State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third136Proof20 : runCachedNode 511 128437 Adaptive137Third136Node20 = false := by
  decide +kernel

#print axioms adaptive137Third136Proof20

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third136Proof16 : runCachedNode 511 128437 Adaptive137Third136Node16 = false := by
  decide +kernel

#print axioms adaptive137Third136Proof16

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third136Proof54 : runCachedNode 511 128437 Adaptive137Third136Node54 = false := by
  decide +kernel

#print axioms adaptive137Third136Proof54

end NineSeparatedSubsetSums
