import NineSeparatedSubsetSums.Adaptive137Third136State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third136Proof21 : runCachedNode 511 128437 Adaptive137Third136Node21 = false := by
  decide +kernel

#print axioms adaptive137Third136Proof21

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third136Proof17 : runCachedNode 511 128437 Adaptive137Third136Node17 = false := by
  decide +kernel

#print axioms adaptive137Third136Proof17

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third136Proof31 : runCachedNode 511 128437 Adaptive137Third136Node31 = false := by
  decide +kernel

#print axioms adaptive137Third136Proof31

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third136Proof1 : runCachedNode 511 128437 Adaptive137Third136Node1 = false := by
  decide +kernel

#print axioms adaptive137Third136Proof1

end NineSeparatedSubsetSums
