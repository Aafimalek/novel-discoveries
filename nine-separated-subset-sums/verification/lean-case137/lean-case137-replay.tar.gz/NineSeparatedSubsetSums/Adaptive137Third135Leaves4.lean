import NineSeparatedSubsetSums.Adaptive137Third135State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third135Proof47 : runCachedNode 511 128257 Adaptive137Third135Node47 = false := by
  decide +kernel

#print axioms adaptive137Third135Proof47

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third135Proof15 : runCachedNode 511 128257 Adaptive137Third135Node15 = false := by
  decide +kernel

#print axioms adaptive137Third135Proof15

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third135Proof43 : runCachedNode 511 128257 Adaptive137Third135Node43 = false := by
  decide +kernel

#print axioms adaptive137Third135Proof43

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third135Proof33 : runCachedNode 511 128257 Adaptive137Third135Node33 = false := by
  decide +kernel

#print axioms adaptive137Third135Proof33

end NineSeparatedSubsetSums
