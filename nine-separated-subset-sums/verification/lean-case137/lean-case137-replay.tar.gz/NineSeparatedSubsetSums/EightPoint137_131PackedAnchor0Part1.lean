import NineSeparatedSubsetSums.EightPoint137_131PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint137_131PackedAnchor0Part1 :
    ∀ j : Fin 120, 2420812 ≤ FourPointNumeric.octPackedCharge 137 131 20 packedOct137_131_0
      (2*((j.val : Int)+120)+0) := by decide +kernel

end NineSeparatedSubsetSums
