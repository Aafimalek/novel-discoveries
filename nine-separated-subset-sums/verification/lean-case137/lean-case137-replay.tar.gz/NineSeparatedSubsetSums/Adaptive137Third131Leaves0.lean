import NineSeparatedSubsetSums.Adaptive137Third131State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third131Proof19 : runCachedNode 511 127537 Adaptive137Third131Node19 = false := by
  decide +kernel

#print axioms adaptive137Third131Proof19

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third131Proof15 : runCachedNode 511 127537 Adaptive137Third131Node15 = false := by
  decide +kernel

#print axioms adaptive137Third131Proof15

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third131Proof1 : runCachedNode 511 127537 Adaptive137Third131Node1 = false := by
  decide +kernel

#print axioms adaptive137Third131Proof1

end NineSeparatedSubsetSums
