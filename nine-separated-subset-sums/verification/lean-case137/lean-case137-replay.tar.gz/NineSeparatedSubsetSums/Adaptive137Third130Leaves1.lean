import NineSeparatedSubsetSums.Adaptive137Third130State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third130Proof17 : runCachedNode 511 127329 Adaptive137Third130Node17 = false := by
  decide +kernel

#print axioms adaptive137Third130Proof17

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third130Proof16 : runCachedNode 511 127329 Adaptive137Third130Node16 = false := by
  decide +kernel

#print axioms adaptive137Third130Proof16

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third130Proof14 : runCachedNode 511 127329 Adaptive137Third130Node14 = false := by
  decide +kernel

#print axioms adaptive137Third130Proof14

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third130Proof11 : runCachedNode 511 127329 Adaptive137Third130Node11 = false := by
  decide +kernel

#print axioms adaptive137Third130Proof11

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third130Proof5 : runCachedNode 511 127329 Adaptive137Third130Node5 = false := by
  decide +kernel

#print axioms adaptive137Third130Proof5

end NineSeparatedSubsetSums
