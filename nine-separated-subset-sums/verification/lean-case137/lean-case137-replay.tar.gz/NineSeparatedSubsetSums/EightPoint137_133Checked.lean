import NineSeparatedSubsetSums.EightPointPackedGeometry
import NineSeparatedSubsetSums.EightPoint137_133PackedBudget0
import NineSeparatedSubsetSums.EightPoint137_133PackedAnchor0Part0
import NineSeparatedSubsetSums.EightPoint137_133PackedAnchor0Part1
import NineSeparatedSubsetSums.EightPoint137_133PackedAnchor0Part2
import NineSeparatedSubsetSums.EightPoint137_133PackedBudget1
import NineSeparatedSubsetSums.EightPoint137_133PackedAnchor1Part0
import NineSeparatedSubsetSums.EightPoint137_133PackedAnchor1Part1
import NineSeparatedSubsetSums.EightPoint137_133PackedAnchor1Part2

namespace NineSeparatedSubsetSums

private theorem packedOct137_133Anchor0 :
  ∀ j : Fin 493, ((j.val : Int)+137+133)%2=0 →
    2410102 ≤ FourPointNumeric.octPackedCharge 137 133 20 packedOct137_133_0 (j.val : Int) := by
  intro j hj
  let k := (j.val-0)/2
  have hk : k < 247 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+0 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint137_133PackedAnchor0Part0 z
    rwa [he,hrep] at ht
  by_cases h1 : k < 240
  · let z : Fin 120 := ⟨k-120, by omega⟩
    have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
    have ht := eightPoint137_133PackedAnchor0Part1 z
    rwa [he,hrep] at ht
  let z : Fin 7 := ⟨k-240, by omega⟩
  have he : (z.val : Int)+240 = k := by dsimp [z] <;> omega
  have ht := eightPoint137_133PackedAnchor0Part2 z
  rwa [he,hrep] at ht

private theorem packedOct137_133Anchor1 :
  ∀ j : Fin 493, ((j.val : Int)+137+133)%2=1 →
    2410374 ≤ FourPointNumeric.octPackedCharge 137 133 20 packedOct137_133_1 (j.val : Int) := by
  intro j hj
  let k := (j.val-1)/2
  have hk : k < 246 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+1 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint137_133PackedAnchor1Part0 z
    rwa [he,hrep] at ht
  by_cases h1 : k < 240
  · let z : Fin 120 := ⟨k-120, by omega⟩
    have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
    have ht := eightPoint137_133PackedAnchor1Part1 z
    rwa [he,hrep] at ht
  let z : Fin 6 := ⟨k-240, by omega⟩
  have he : (z.val : Int)+240 = k := by dsimp [z] <;> omega
  have ht := eightPoint137_133PackedAnchor1Part2 z
  rwa [he,hrep] at ht

def packedOctCertificate137_133_0 : EightPointCertificate 137 133 0 127870 :=
  eightPointCertificateOfPacked 137 133 0 127870 2410102 20 packedOct137_133_0 277 493
    (by decide +kernel) (by decide) packedOct137_133Anchor0
    (by rw [packedOct137_133_0_budget]; decide)

def packedOctCertificate137_133_1 : EightPointCertificate 137 133 1 127870 :=
  eightPointCertificateOfPacked 137 133 1 127870 2410374 20 packedOct137_133_1 474 493
    (by decide +kernel) (by decide) packedOct137_133Anchor1
    (by rw [packedOct137_133_1_budget]; decide)

theorem max148_second137_third133_eightPoint_moment_bound (tail : List ℕ) (len : tail.length=6)
    (distinct : (natSubsetSums (148::137::133::tail)).Nodup) :
    127870 ≤ ((148::137::133::tail).map (· ^ 2)).sum := by
  apply eightPointNatMomentLower 137 133 127870 tail len distinct
  intro p hp
  by_cases h : p=0
  · subst p
    exact packedOctCertificate137_133_0
  · have he : p=1 := hp.resolve_left h
    subst p
    exact packedOctCertificate137_133_1

#print axioms max148_second137_third133_eightPoint_moment_bound

end NineSeparatedSubsetSums
