import NineSeparatedSubsetSums.Adaptive137Third114State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third114Proof0 : runCachedNode 511 111041 Adaptive137Third114Node0 = false := by
  decide +kernel

#print axioms adaptive137Third114Proof0

end NineSeparatedSubsetSums
