import NineSeparatedSubsetSums.Adaptive137Third136State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third136Proof131 : runCachedNode 511 128437 Adaptive137Third136Node131 = false := by
  decide +kernel

#print axioms adaptive137Third136Proof131

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third136Proof99 : runCachedNode 511 128437 Adaptive137Third136Node99 = false := by
  decide +kernel

#print axioms adaptive137Third136Proof99

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third136Proof73 : runCachedNode 511 128437 Adaptive137Third136Node73 = false := by
  decide +kernel

#print axioms adaptive137Third136Proof73

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third136Proof95 : runCachedNode 511 128437 Adaptive137Third136Node95 = false := by
  decide +kernel

#print axioms adaptive137Third136Proof95

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third136Proof71 : runCachedNode 511 128437 Adaptive137Third136Node71 = false := by
  decide +kernel

#print axioms adaptive137Third136Proof71

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third136Proof45 : runCachedNode 511 128437 Adaptive137Third136Node45 = false := by
  decide +kernel

#print axioms adaptive137Third136Proof45

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third136Proof94 : runCachedNode 511 128437 Adaptive137Third136Node94 = false := by
  decide +kernel

#print axioms adaptive137Third136Proof94

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third136Proof50 : runCachedNode 511 128437 Adaptive137Third136Node50 = false := by
  decide +kernel

#print axioms adaptive137Third136Proof50

end NineSeparatedSubsetSums
