import NineSeparatedSubsetSums.EightPoint137_122PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint137_122PackedAnchor1Part1 :
    ∀ j : Fin 120, 2274514 ≤ FourPointNumeric.octPackedCharge 137 122 20 packedOct137_122_1
      (2*((j.val : Int)+120)+0) := by decide +kernel

end NineSeparatedSubsetSums
