import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive137Third131Node0 : CachedSearchNode :=
  ⟨4, 130, computeCenteredMask [148,137,131], 416, 57834⟩
def Adaptive137Third131Node1 : CachedSearchNode := cachedChild Adaptive137Third131Node0 111
def Adaptive137Third131Node2 : CachedSearchNode := cachedChild Adaptive137Third131Node0 112
def Adaptive137Third131Node3 : CachedSearchNode := cachedChild Adaptive137Third131Node0 113
def Adaptive137Third131Node4 : CachedSearchNode := cachedChild Adaptive137Third131Node0 114
def Adaptive137Third131Node5 : CachedSearchNode := cachedChild Adaptive137Third131Node0 115
def Adaptive137Third131Node6 : CachedSearchNode := cachedChild Adaptive137Third131Node0 116
def Adaptive137Third131Node7 : CachedSearchNode := cachedChild Adaptive137Third131Node0 117
def Adaptive137Third131Node8 : CachedSearchNode := cachedChild Adaptive137Third131Node0 118
def Adaptive137Third131Node9 : CachedSearchNode := cachedChild Adaptive137Third131Node0 119
def Adaptive137Third131Node10 : CachedSearchNode := cachedChild Adaptive137Third131Node0 121
def Adaptive137Third131Node11 : CachedSearchNode := cachedChild Adaptive137Third131Node0 122
def Adaptive137Third131Node12 : CachedSearchNode := cachedChild Adaptive137Third131Node0 123
def Adaptive137Third131Node13 : CachedSearchNode := cachedChild Adaptive137Third131Node0 124
def Adaptive137Third131Node14 : CachedSearchNode := cachedChild Adaptive137Third131Node0 125
def Adaptive137Third131Node15 : CachedSearchNode := cachedChild Adaptive137Third131Node0 126
def Adaptive137Third131Node16 : CachedSearchNode := cachedChild Adaptive137Third131Node0 127
def Adaptive137Third131Node17 : CachedSearchNode := cachedChild Adaptive137Third131Node0 128
def Adaptive137Third131Node18 : CachedSearchNode := cachedChild Adaptive137Third131Node0 129
def Adaptive137Third131Node19 : CachedSearchNode := cachedChild Adaptive137Third131Node0 130

end NineSeparatedSubsetSums
