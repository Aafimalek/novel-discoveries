import NineSeparatedSubsetSums.Adaptive137Third107Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint137Checked

namespace NineSeparatedSubsetSums


theorem adaptive137Third107 : NoDescendingTailAfterThird 137 107 :=
  noDescendingThirdTail_of_cached 137 107 111041 (fun t ht nd => max148_second137_fourPoint_moment_bound (107::t) (by simp [ht]) nd) adaptive137Third107Proof0

#print axioms adaptive137Third107

end NineSeparatedSubsetSums
