import NineSeparatedSubsetSums.Adaptive137Third116State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third116Proof14 : runCachedNode 511 111041 Adaptive137Third116Node14 = false := by
  decide +kernel

#print axioms adaptive137Third116Proof14

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third116Proof15 : runCachedNode 511 111041 Adaptive137Third116Node15 = false := by
  decide +kernel

#print axioms adaptive137Third116Proof15

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third116Proof13 : runCachedNode 511 111041 Adaptive137Third116Node13 = false := by
  decide +kernel

#print axioms adaptive137Third116Proof13

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third116Proof11 : runCachedNode 511 111041 Adaptive137Third116Node11 = false := by
  decide +kernel

#print axioms adaptive137Third116Proof11

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third116Proof1 : runCachedNode 511 111041 Adaptive137Third116Node1 = false := by
  decide +kernel

#print axioms adaptive137Third116Proof1

end NineSeparatedSubsetSums
