import NineSeparatedSubsetSums.Adaptive137Third135State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third135Proof20 : runCachedNode 511 128257 Adaptive137Third135Node20 = false := by
  decide +kernel

#print axioms adaptive137Third135Proof20

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third135Proof16 : runCachedNode 511 128257 Adaptive137Third135Node16 = false := by
  decide +kernel

#print axioms adaptive137Third135Proof16

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third135Proof10 : runCachedNode 511 128257 Adaptive137Third135Node10 = false := by
  decide +kernel

#print axioms adaptive137Third135Proof10

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third135Proof23 : runCachedNode 511 128257 Adaptive137Third135Node23 = false := by
  decide +kernel

#print axioms adaptive137Third135Proof23

end NineSeparatedSubsetSums
