import NineSeparatedSubsetSums.EightPointPackedGeometry
import NineSeparatedSubsetSums.EightPoint137_123PackedBudget0
import NineSeparatedSubsetSums.EightPoint137_123PackedAnchor0Part0
import NineSeparatedSubsetSums.EightPoint137_123PackedAnchor0Part1
import NineSeparatedSubsetSums.EightPoint137_123PackedBudget1
import NineSeparatedSubsetSums.EightPoint137_123PackedAnchor1Part0
import NineSeparatedSubsetSums.EightPoint137_123PackedAnchor1Part1

namespace NineSeparatedSubsetSums

private theorem packedOct137_123Anchor0 :
  ∀ j : Fin 479, ((j.val : Int)+137+123)%2=0 →
    2275324 ≤ FourPointNumeric.octPackedCharge 137 123 20 packedOct137_123_0 (j.val : Int) := by
  intro j hj
  let k := (j.val-0)/2
  have hk : k < 240 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+0 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint137_123PackedAnchor0Part0 z
    rwa [he,hrep] at ht
  let z : Fin 120 := ⟨k-120, by omega⟩
  have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
  have ht := eightPoint137_123PackedAnchor0Part1 z
  rwa [he,hrep] at ht

private theorem packedOct137_123Anchor1 :
  ∀ j : Fin 479, ((j.val : Int)+137+123)%2=1 →
    2275720 ≤ FourPointNumeric.octPackedCharge 137 123 20 packedOct137_123_1 (j.val : Int) := by
  intro j hj
  let k := (j.val-1)/2
  have hk : k < 239 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+1 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint137_123PackedAnchor1Part0 z
    rwa [he,hrep] at ht
  let z : Fin 119 := ⟨k-120, by omega⟩
  have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
  have ht := eightPoint137_123PackedAnchor1Part1 z
  rwa [he,hrep] at ht

def packedOctCertificate137_123_0 : EightPointCertificate 137 123 0 125617 :=
  eightPointCertificateOfPacked 137 123 0 125617 2275324 20 packedOct137_123_0 471 479
    (by decide +kernel) (by decide) packedOct137_123Anchor0
    (by rw [packedOct137_123_0_budget]; decide)

def packedOctCertificate137_123_1 : EightPointCertificate 137 123 1 125617 :=
  eightPointCertificateOfPacked 137 123 1 125617 2275720 20 packedOct137_123_1 470 479
    (by decide +kernel) (by decide) packedOct137_123Anchor1
    (by rw [packedOct137_123_1_budget]; decide)

theorem max148_second137_third123_eightPoint_moment_bound (tail : List ℕ) (len : tail.length=6)
    (distinct : (natSubsetSums (148::137::123::tail)).Nodup) :
    125617 ≤ ((148::137::123::tail).map (· ^ 2)).sum := by
  apply eightPointNatMomentLower 137 123 125617 tail len distinct
  intro p hp
  by_cases h : p=0
  · subst p
    exact packedOctCertificate137_123_0
  · have he : p=1 := hp.resolve_left h
    subst p
    exact packedOctCertificate137_123_1

#print axioms max148_second137_third123_eightPoint_moment_bound

end NineSeparatedSubsetSums
