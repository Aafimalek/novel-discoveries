import NineSeparatedSubsetSums.EightPoint137_128PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct137_128_0_budget :
    FourPointNumeric.packedBudget 20 packedOct137_128_0 441 = 85082250 := by decide +kernel

#print axioms packedOct137_128_0_budget

end NineSeparatedSubsetSums
