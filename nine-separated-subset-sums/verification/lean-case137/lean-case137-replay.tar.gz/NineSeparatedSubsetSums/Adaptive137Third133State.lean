import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive137Third133Node0 : CachedSearchNode :=
  ⟨4, 132, computeCenteredMask [148,137,133], 418, 58362⟩
def Adaptive137Third133Node1 : CachedSearchNode := cachedChild Adaptive137Third133Node0 111
def Adaptive137Third133Node2 : CachedSearchNode := cachedChild Adaptive137Third133Node0 112
def Adaptive137Third133Node3 : CachedSearchNode := cachedChild Adaptive137Third133Node0 113
def Adaptive137Third133Node4 : CachedSearchNode := cachedChild Adaptive137Third133Node0 114
def Adaptive137Third133Node5 : CachedSearchNode := cachedChild Adaptive137Third133Node0 115
def Adaptive137Third133Node6 : CachedSearchNode := cachedChild Adaptive137Third133Node0 116
def Adaptive137Third133Node7 : CachedSearchNode := cachedChild Adaptive137Third133Node0 117
def Adaptive137Third133Node8 : CachedSearchNode := cachedChild Adaptive137Third133Node0 118
def Adaptive137Third133Node9 : CachedSearchNode := cachedChild Adaptive137Third133Node0 119
def Adaptive137Third133Node10 : CachedSearchNode := cachedChild Adaptive137Third133Node0 120
def Adaptive137Third133Node11 : CachedSearchNode := cachedChild Adaptive137Third133Node0 121
def Adaptive137Third133Node12 : CachedSearchNode := cachedChild Adaptive137Third133Node0 123
def Adaptive137Third133Node13 : CachedSearchNode := cachedChild Adaptive137Third133Node0 124
def Adaptive137Third133Node14 : CachedSearchNode := cachedChild Adaptive137Third133Node0 125
def Adaptive137Third133Node15 : CachedSearchNode := cachedChild Adaptive137Third133Node0 126
def Adaptive137Third133Node16 : CachedSearchNode := cachedChild Adaptive137Third133Node0 127
def Adaptive137Third133Node17 : CachedSearchNode := cachedChild Adaptive137Third133Node0 128
def Adaptive137Third133Node18 : CachedSearchNode := cachedChild Adaptive137Third133Node0 129
def Adaptive137Third133Node19 : CachedSearchNode := cachedChild Adaptive137Third133Node0 130
def Adaptive137Third133Node20 : CachedSearchNode := cachedChild Adaptive137Third133Node0 131
def Adaptive137Third133Node21 : CachedSearchNode := cachedChild Adaptive137Third133Node0 132

end NineSeparatedSubsetSums
