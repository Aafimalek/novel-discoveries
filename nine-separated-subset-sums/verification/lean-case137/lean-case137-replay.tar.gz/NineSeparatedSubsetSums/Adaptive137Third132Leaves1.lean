import NineSeparatedSubsetSums.Adaptive137Third132State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third132Proof20 : runCachedNode 511 127744 Adaptive137Third132Node20 = false := by
  decide +kernel

#print axioms adaptive137Third132Proof20

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third132Proof17 : runCachedNode 511 127744 Adaptive137Third132Node17 = false := by
  decide +kernel

#print axioms adaptive137Third132Proof17

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third132Proof3 : runCachedNode 511 127744 Adaptive137Third132Node3 = false := by
  decide +kernel

#print axioms adaptive137Third132Proof3

end NineSeparatedSubsetSums
