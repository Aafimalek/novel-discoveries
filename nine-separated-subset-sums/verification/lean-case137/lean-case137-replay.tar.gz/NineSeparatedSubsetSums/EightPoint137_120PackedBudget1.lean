import NineSeparatedSubsetSums.EightPoint137_120PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct137_120_1_budget :
    FourPointNumeric.packedBudget 20 packedOct137_120_1 370 = 85518880 := by decide +kernel

#print axioms packedOct137_120_1_budget

end NineSeparatedSubsetSums
