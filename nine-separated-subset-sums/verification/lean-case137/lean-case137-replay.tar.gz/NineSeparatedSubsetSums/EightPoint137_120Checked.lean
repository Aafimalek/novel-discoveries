import NineSeparatedSubsetSums.EightPointPackedGeometry
import NineSeparatedSubsetSums.EightPoint137_120PackedBudget0
import NineSeparatedSubsetSums.EightPoint137_120PackedAnchor0Part0
import NineSeparatedSubsetSums.EightPoint137_120PackedAnchor0Part1
import NineSeparatedSubsetSums.EightPoint137_120PackedAnchor0Part2
import NineSeparatedSubsetSums.EightPoint137_120PackedBudget1
import NineSeparatedSubsetSums.EightPoint137_120PackedAnchor1Part0
import NineSeparatedSubsetSums.EightPoint137_120PackedAnchor1Part1
import NineSeparatedSubsetSums.EightPoint137_120PackedAnchor1Part2

namespace NineSeparatedSubsetSums

private theorem packedOct137_120Anchor0 :
  ∀ j : Fin 487, ((j.val : Int)+137+120)%2=0 →
    2337234 ≤ FourPointNumeric.octPackedCharge 137 120 20 packedOct137_120_0 (j.val : Int) := by
  intro j hj
  let k := (j.val-1)/2
  have hk : k < 243 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+1 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint137_120PackedAnchor0Part0 z
    rwa [he,hrep] at ht
  by_cases h1 : k < 240
  · let z : Fin 120 := ⟨k-120, by omega⟩
    have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
    have ht := eightPoint137_120PackedAnchor0Part1 z
    rwa [he,hrep] at ht
  let z : Fin 3 := ⟨k-240, by omega⟩
  have he : (z.val : Int)+240 = k := by dsimp [z] <;> omega
  have ht := eightPoint137_120PackedAnchor0Part2 z
  rwa [he,hrep] at ht

private theorem packedOct137_120Anchor1 :
  ∀ j : Fin 487, ((j.val : Int)+137+120)%2=1 →
    2337521 ≤ FourPointNumeric.octPackedCharge 137 120 20 packedOct137_120_1 (j.val : Int) := by
  intro j hj
  let k := (j.val-0)/2
  have hk : k < 244 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+0 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint137_120PackedAnchor1Part0 z
    rwa [he,hrep] at ht
  by_cases h1 : k < 240
  · let z : Fin 120 := ⟨k-120, by omega⟩
    have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
    have ht := eightPoint137_120PackedAnchor1Part1 z
    rwa [he,hrep] at ht
  let z : Fin 4 := ⟨k-240, by omega⟩
  have he : (z.val : Int)+240 = k := by dsimp [z] <;> omega
  have ht := eightPoint137_120PackedAnchor1Part2 z
  rwa [he,hrep] at ht

def packedOctCertificate137_120_0 : EightPointCertificate 137 120 0 125162 :=
  eightPointCertificateOfPacked 137 120 0 125162 2337234 20 packedOct137_120_0 281 487
    (by decide +kernel) (by decide) packedOct137_120Anchor0
    (by rw [packedOct137_120_0_budget]; decide)

def packedOctCertificate137_120_1 : EightPointCertificate 137 120 1 125162 :=
  eightPointCertificateOfPacked 137 120 1 125162 2337521 20 packedOct137_120_1 370 487
    (by decide +kernel) (by decide) packedOct137_120Anchor1
    (by rw [packedOct137_120_1_budget]; decide)

theorem max148_second137_third120_eightPoint_moment_bound (tail : List ℕ) (len : tail.length=6)
    (distinct : (natSubsetSums (148::137::120::tail)).Nodup) :
    125162 ≤ ((148::137::120::tail).map (· ^ 2)).sum := by
  apply eightPointNatMomentLower 137 120 125162 tail len distinct
  intro p hp
  by_cases h : p=0
  · subst p
    exact packedOctCertificate137_120_0
  · have he : p=1 := hp.resolve_left h
    subst p
    exact packedOctCertificate137_120_1

#print axioms max148_second137_third120_eightPoint_moment_bound

end NineSeparatedSubsetSums
