import NineSeparatedSubsetSums.EightPoint137_125PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct137_125_0_budget :
    FourPointNumeric.packedBudget 20 packedOct137_125_0 491 = 83093292 := by decide +kernel

#print axioms packedOct137_125_0_budget

end NineSeparatedSubsetSums
