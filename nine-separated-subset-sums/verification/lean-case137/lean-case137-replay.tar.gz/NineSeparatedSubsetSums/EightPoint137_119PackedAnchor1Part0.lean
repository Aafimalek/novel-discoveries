import NineSeparatedSubsetSums.EightPoint137_119PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint137_119PackedAnchor1Part0 :
    ∀ j : Fin 120, 2300495 ≤ FourPointNumeric.octPackedCharge 137 119 20 packedOct137_119_1
      (2*((j.val : Int)+0)+1) := by decide +kernel

end NineSeparatedSubsetSums
