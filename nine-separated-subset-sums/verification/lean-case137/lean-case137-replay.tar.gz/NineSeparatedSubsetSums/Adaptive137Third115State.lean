import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive137Third115Node0 : CachedSearchNode :=
  ⟨4, 114, computeCenteredMask [148,137,115], 400, 53898⟩
def Adaptive137Third115Node1 : CachedSearchNode := cachedChild Adaptive137Third115Node0 101
def Adaptive137Third115Node2 : CachedSearchNode := cachedChild Adaptive137Third115Node0 102
def Adaptive137Third115Node3 : CachedSearchNode := cachedChild Adaptive137Third115Node0 103
def Adaptive137Third115Node4 : CachedSearchNode := cachedChild Adaptive137Third115Node0 105
def Adaptive137Third115Node5 : CachedSearchNode := cachedChild Adaptive137Third115Node0 106
def Adaptive137Third115Node6 : CachedSearchNode := cachedChild Adaptive137Third115Node0 107
def Adaptive137Third115Node7 : CachedSearchNode := cachedChild Adaptive137Third115Node0 108
def Adaptive137Third115Node8 : CachedSearchNode := cachedChild Adaptive137Third115Node0 109
def Adaptive137Third115Node9 : CachedSearchNode := cachedChild Adaptive137Third115Node0 110
def Adaptive137Third115Node10 : CachedSearchNode := cachedChild Adaptive137Third115Node0 111
def Adaptive137Third115Node11 : CachedSearchNode := cachedChild Adaptive137Third115Node0 112
def Adaptive137Third115Node12 : CachedSearchNode := cachedChild Adaptive137Third115Node0 113
def Adaptive137Third115Node13 : CachedSearchNode := cachedChild Adaptive137Third115Node0 114

end NineSeparatedSubsetSums
