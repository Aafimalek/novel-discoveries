import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive137Third110Node0 : CachedSearchNode :=
  ⟨4, 109, computeCenteredMask [148,137,110], 395, 52773⟩

end NineSeparatedSubsetSums
