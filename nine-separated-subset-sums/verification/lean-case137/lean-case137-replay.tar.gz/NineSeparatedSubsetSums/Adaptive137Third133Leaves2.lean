import NineSeparatedSubsetSums.Adaptive137Third133State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third133Proof18 : runCachedNode 511 127870 Adaptive137Third133Node18 = false := by
  decide +kernel

#print axioms adaptive137Third133Proof18

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third133Proof16 : runCachedNode 511 127870 Adaptive137Third133Node16 = false := by
  decide +kernel

#print axioms adaptive137Third133Proof16

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third133Proof11 : runCachedNode 511 127870 Adaptive137Third133Node11 = false := by
  decide +kernel

#print axioms adaptive137Third133Proof11

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third133Proof5 : runCachedNode 511 127870 Adaptive137Third133Node5 = false := by
  decide +kernel

#print axioms adaptive137Third133Proof5

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third133Proof2 : runCachedNode 511 127870 Adaptive137Third133Node2 = false := by
  decide +kernel

#print axioms adaptive137Third133Proof2

end NineSeparatedSubsetSums
