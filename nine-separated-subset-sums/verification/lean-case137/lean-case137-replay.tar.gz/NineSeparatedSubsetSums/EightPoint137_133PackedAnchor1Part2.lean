import NineSeparatedSubsetSums.EightPoint137_133PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint137_133PackedAnchor1Part2 :
    ∀ j : Fin 6, 2410374 ≤ FourPointNumeric.octPackedCharge 137 133 20 packedOct137_133_1
      (2*((j.val : Int)+240)+1) := by decide +kernel

end NineSeparatedSubsetSums
