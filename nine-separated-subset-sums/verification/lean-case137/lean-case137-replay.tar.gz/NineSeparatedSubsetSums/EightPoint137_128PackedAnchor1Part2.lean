import NineSeparatedSubsetSums.EightPoint137_128PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint137_128PackedAnchor1Part2 :
    ∀ j : Fin 3, 2344110 ≤ FourPointNumeric.octPackedCharge 137 128 20 packedOct137_128_1
      (2*((j.val : Int)+240)+0) := by decide +kernel

end NineSeparatedSubsetSums
