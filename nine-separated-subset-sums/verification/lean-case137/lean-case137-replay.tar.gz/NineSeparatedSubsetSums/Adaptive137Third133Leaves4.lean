import NineSeparatedSubsetSums.Adaptive137Third133State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third133Proof17 : runCachedNode 511 127870 Adaptive137Third133Node17 = false := by
  decide +kernel

#print axioms adaptive137Third133Proof17

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third133Proof13 : runCachedNode 511 127870 Adaptive137Third133Node13 = false := by
  decide +kernel

#print axioms adaptive137Third133Proof13

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third133Proof12 : runCachedNode 511 127870 Adaptive137Third133Node12 = false := by
  decide +kernel

#print axioms adaptive137Third133Proof12

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third133Proof10 : runCachedNode 511 127870 Adaptive137Third133Node10 = false := by
  decide +kernel

#print axioms adaptive137Third133Proof10

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third133Proof7 : runCachedNode 511 127870 Adaptive137Third133Node7 = false := by
  decide +kernel

#print axioms adaptive137Third133Proof7

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third133Proof6 : runCachedNode 511 127870 Adaptive137Third133Node6 = false := by
  decide +kernel

#print axioms adaptive137Third133Proof6

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third133Proof3 : runCachedNode 511 127870 Adaptive137Third133Node3 = false := by
  decide +kernel

#print axioms adaptive137Third133Proof3

end NineSeparatedSubsetSums
