import NineSeparatedSubsetSums.EightPoint137_132PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint137_132PackedAnchor1Part2 :
    ∀ j : Fin 8, 2418902 ≤ FourPointNumeric.octPackedCharge 137 132 20 packedOct137_132_1
      (2*((j.val : Int)+240)+0) := by decide +kernel

end NineSeparatedSubsetSums
