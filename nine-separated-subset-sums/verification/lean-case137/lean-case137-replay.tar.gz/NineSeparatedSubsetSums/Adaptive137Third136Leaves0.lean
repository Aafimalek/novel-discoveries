import NineSeparatedSubsetSums.Adaptive137Third136State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third136Proof22 : runCachedNode 511 128437 Adaptive137Third136Node22 = false := by
  decide +kernel

#print axioms adaptive137Third136Proof22

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third136Proof34 : runCachedNode 511 128437 Adaptive137Third136Node34 = false := by
  decide +kernel

#print axioms adaptive137Third136Proof34

end NineSeparatedSubsetSums
