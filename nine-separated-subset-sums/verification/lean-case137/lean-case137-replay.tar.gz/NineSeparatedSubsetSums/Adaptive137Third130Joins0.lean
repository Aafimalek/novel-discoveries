import NineSeparatedSubsetSums.Adaptive137Third130State
import NineSeparatedSubsetSums.Adaptive137Third130Leaves2
import NineSeparatedSubsetSums.Adaptive137Third130Leaves0
import NineSeparatedSubsetSums.Adaptive137Third130Leaves1

namespace NineSeparatedSubsetSums

theorem adaptive137Third130Proof0 : runCachedNode 511 127329 Adaptive137Third130Node0 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 127329 Adaptive137Third130Node0 = [111, 112, 113, 114, 115, 116, 117, 118, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive137Third130Proof1
  · exact adaptive137Third130Proof2
  · exact adaptive137Third130Proof3
  · exact adaptive137Third130Proof4
  · exact adaptive137Third130Proof5
  · exact adaptive137Third130Proof6
  · exact adaptive137Third130Proof7
  · exact adaptive137Third130Proof8
  · exact adaptive137Third130Proof9
  · exact adaptive137Third130Proof10
  · exact adaptive137Third130Proof11
  · exact adaptive137Third130Proof12
  · exact adaptive137Third130Proof13
  · exact adaptive137Third130Proof14
  · exact adaptive137Third130Proof15
  · exact adaptive137Third130Proof16
  · exact adaptive137Third130Proof17
  · exact adaptive137Third130Proof18

#print axioms adaptive137Third130Proof0

end NineSeparatedSubsetSums
