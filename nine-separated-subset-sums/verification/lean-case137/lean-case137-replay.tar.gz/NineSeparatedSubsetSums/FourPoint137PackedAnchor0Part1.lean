import NineSeparatedSubsetSums.FourPoint137PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem fourPoint137PackedAnchor0Part1 :
    ∀ j : Fin 120, 1105784 ≤ FourPointNumeric.packedCharge 137 20 packedWeight137_0
      (2*((j.val : Int)+120)+1) := by decide +kernel

end NineSeparatedSubsetSums
