import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive137Third128Node0 : CachedSearchNode :=
  ⟨4, 127, computeCenteredMask [148,137,128], 413, 57057⟩
def Adaptive137Third128Node1 : CachedSearchNode := cachedChild Adaptive137Third128Node0 111
def Adaptive137Third128Node2 : CachedSearchNode := cachedChild Adaptive137Third128Node0 112
def Adaptive137Third128Node3 : CachedSearchNode := cachedChild Adaptive137Third128Node0 113
def Adaptive137Third128Node4 : CachedSearchNode := cachedChild Adaptive137Third128Node0 114
def Adaptive137Third128Node5 : CachedSearchNode := cachedChild Adaptive137Third128Node0 115
def Adaptive137Third128Node6 : CachedSearchNode := cachedChild Adaptive137Third128Node0 116
def Adaptive137Third128Node7 : CachedSearchNode := cachedChild Adaptive137Third128Node0 118
def Adaptive137Third128Node8 : CachedSearchNode := cachedChild Adaptive137Third128Node0 119
def Adaptive137Third128Node9 : CachedSearchNode := cachedChild Adaptive137Third128Node0 120
def Adaptive137Third128Node10 : CachedSearchNode := cachedChild Adaptive137Third128Node0 121
def Adaptive137Third128Node11 : CachedSearchNode := cachedChild Adaptive137Third128Node0 122
def Adaptive137Third128Node12 : CachedSearchNode := cachedChild Adaptive137Third128Node0 123
def Adaptive137Third128Node13 : CachedSearchNode := cachedChild Adaptive137Third128Node0 124
def Adaptive137Third128Node14 : CachedSearchNode := cachedChild Adaptive137Third128Node0 125
def Adaptive137Third128Node15 : CachedSearchNode := cachedChild Adaptive137Third128Node0 126
def Adaptive137Third128Node16 : CachedSearchNode := cachedChild Adaptive137Third128Node0 127

end NineSeparatedSubsetSums
