import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive137Third114Node0 : CachedSearchNode :=
  ⟨4, 113, computeCenteredMask [148,137,114], 399, 53669⟩

end NineSeparatedSubsetSums
