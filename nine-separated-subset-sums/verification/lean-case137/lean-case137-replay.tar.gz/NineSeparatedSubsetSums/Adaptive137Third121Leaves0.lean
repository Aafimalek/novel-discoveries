import NineSeparatedSubsetSums.Adaptive137Third121State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third121Proof0 : runCachedNode 511 125162 Adaptive137Third121Node0 = false := by
  decide +kernel

#print axioms adaptive137Third121Proof0

end NineSeparatedSubsetSums
