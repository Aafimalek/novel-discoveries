import NineSeparatedSubsetSums.EightPointPackedGeometry
import NineSeparatedSubsetSums.EightPoint137_125PackedBudget0
import NineSeparatedSubsetSums.EightPoint137_125PackedAnchor0Part0
import NineSeparatedSubsetSums.EightPoint137_125PackedAnchor0Part1
import NineSeparatedSubsetSums.EightPoint137_125PackedAnchor0Part2
import NineSeparatedSubsetSums.EightPoint137_125PackedBudget1
import NineSeparatedSubsetSums.EightPoint137_125PackedAnchor1Part0
import NineSeparatedSubsetSums.EightPoint137_125PackedAnchor1Part1
import NineSeparatedSubsetSums.EightPoint137_125PackedAnchor1Part2

namespace NineSeparatedSubsetSums

private theorem packedOct137_125Anchor0 :
  ∀ j : Fin 483, ((j.val : Int)+137+125)%2=0 →
    2309728 ≤ FourPointNumeric.octPackedCharge 137 125 20 packedOct137_125_0 (j.val : Int) := by
  intro j hj
  let k := (j.val-0)/2
  have hk : k < 242 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+0 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint137_125PackedAnchor0Part0 z
    rwa [he,hrep] at ht
  by_cases h1 : k < 240
  · let z : Fin 120 := ⟨k-120, by omega⟩
    have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
    have ht := eightPoint137_125PackedAnchor0Part1 z
    rwa [he,hrep] at ht
  let z : Fin 2 := ⟨k-240, by omega⟩
  have he : (z.val : Int)+240 = k := by dsimp [z] <;> omega
  have ht := eightPoint137_125PackedAnchor0Part2 z
  rwa [he,hrep] at ht

private theorem packedOct137_125Anchor1 :
  ∀ j : Fin 483, ((j.val : Int)+137+125)%2=1 →
    2309643 ≤ FourPointNumeric.octPackedCharge 137 125 20 packedOct137_125_1 (j.val : Int) := by
  intro j hj
  let k := (j.val-1)/2
  have hk : k < 241 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+1 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint137_125PackedAnchor1Part0 z
    rwa [he,hrep] at ht
  by_cases h1 : k < 240
  · let z : Fin 120 := ⟨k-120, by omega⟩
    have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
    have ht := eightPoint137_125PackedAnchor1Part1 z
    rwa [he,hrep] at ht
  let z : Fin 1 := ⟨k-240, by omega⟩
  have he : (z.val : Int)+240 = k := by dsimp [z] <;> omega
  have ht := eightPoint137_125PackedAnchor1Part2 z
  rwa [he,hrep] at ht

def packedOctCertificate137_125_0 : EightPointCertificate 137 125 0 126425 :=
  eightPointCertificateOfPacked 137 125 0 126425 2309728 20 packedOct137_125_0 491 483
    (by decide +kernel) (by decide) packedOct137_125Anchor0
    (by rw [packedOct137_125_0_budget]; decide)

def packedOctCertificate137_125_1 : EightPointCertificate 137 125 1 126425 :=
  eightPointCertificateOfPacked 137 125 1 126425 2309643 20 packedOct137_125_1 490 483
    (by decide +kernel) (by decide) packedOct137_125Anchor1
    (by rw [packedOct137_125_1_budget]; decide)

theorem max148_second137_third125_eightPoint_moment_bound (tail : List ℕ) (len : tail.length=6)
    (distinct : (natSubsetSums (148::137::125::tail)).Nodup) :
    126425 ≤ ((148::137::125::tail).map (· ^ 2)).sum := by
  apply eightPointNatMomentLower 137 125 126425 tail len distinct
  intro p hp
  by_cases h : p=0
  · subst p
    exact packedOctCertificate137_125_0
  · have he : p=1 := hp.resolve_left h
    subst p
    exact packedOctCertificate137_125_1

#print axioms max148_second137_third125_eightPoint_moment_bound

end NineSeparatedSubsetSums
