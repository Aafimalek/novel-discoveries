import NineSeparatedSubsetSums.Adaptive137Third133State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third133Proof21 : runCachedNode 511 127870 Adaptive137Third133Node21 = false := by
  decide +kernel

#print axioms adaptive137Third133Proof21

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third133Proof4 : runCachedNode 511 127870 Adaptive137Third133Node4 = false := by
  decide +kernel

#print axioms adaptive137Third133Proof4

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third133Proof1 : runCachedNode 511 127870 Adaptive137Third133Node1 = false := by
  decide +kernel

#print axioms adaptive137Third133Proof1

end NineSeparatedSubsetSums
