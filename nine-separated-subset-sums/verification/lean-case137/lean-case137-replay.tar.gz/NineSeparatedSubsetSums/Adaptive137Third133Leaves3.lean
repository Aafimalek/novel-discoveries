import NineSeparatedSubsetSums.Adaptive137Third133State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third133Proof19 : runCachedNode 511 127870 Adaptive137Third133Node19 = false := by
  decide +kernel

#print axioms adaptive137Third133Proof19

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third133Proof15 : runCachedNode 511 127870 Adaptive137Third133Node15 = false := by
  decide +kernel

#print axioms adaptive137Third133Proof15

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third133Proof9 : runCachedNode 511 127870 Adaptive137Third133Node9 = false := by
  decide +kernel

#print axioms adaptive137Third133Proof9

end NineSeparatedSubsetSums
