import NineSeparatedSubsetSums.EightPoint137_126PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct137_126_1_budget :
    FourPointNumeric.packedBudget 20 packedOct137_126_1 412 = 85302490 := by decide +kernel

#print axioms packedOct137_126_1_budget

end NineSeparatedSubsetSums
