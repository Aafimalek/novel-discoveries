import NineSeparatedSubsetSums.Adaptive137Third136State
import NineSeparatedSubsetSums.Adaptive137Third136Leaves4
import NineSeparatedSubsetSums.Adaptive137Third136Leaves12
import NineSeparatedSubsetSums.Adaptive137Third136Leaves11
import NineSeparatedSubsetSums.Adaptive137Third136Leaves1
import NineSeparatedSubsetSums.Adaptive137Third136Leaves0
import NineSeparatedSubsetSums.Adaptive137Third136Leaves10
import NineSeparatedSubsetSums.Adaptive137Third136Leaves9
import NineSeparatedSubsetSums.Adaptive137Third136Leaves8
import NineSeparatedSubsetSums.Adaptive137Third136Leaves7
import NineSeparatedSubsetSums.Adaptive137Third136Leaves6
import NineSeparatedSubsetSums.Adaptive137Third136Leaves3
import NineSeparatedSubsetSums.Adaptive137Third136Leaves2
import NineSeparatedSubsetSums.Adaptive137Third136Leaves5

namespace NineSeparatedSubsetSums

theorem adaptive137Third136Proof23 : runCachedNode 511 128437 Adaptive137Third136Node23 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 128437 Adaptive137Third136Node23 = [104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 123, 124, 126, 127, 128, 129, 130, 131] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive137Third136Proof24
  · exact adaptive137Third136Proof25
  · exact adaptive137Third136Proof26
  · exact adaptive137Third136Proof27
  · exact adaptive137Third136Proof28
  · exact adaptive137Third136Proof29
  · exact adaptive137Third136Proof30
  · exact adaptive137Third136Proof31
  · exact adaptive137Third136Proof32
  · exact adaptive137Third136Proof33
  · exact adaptive137Third136Proof34
  · exact adaptive137Third136Proof35
  · exact adaptive137Third136Proof36
  · exact adaptive137Third136Proof37
  · exact adaptive137Third136Proof38
  · exact adaptive137Third136Proof39
  · exact adaptive137Third136Proof40
  · exact adaptive137Third136Proof41
  · exact adaptive137Third136Proof42
  · exact adaptive137Third136Proof43
  · exact adaptive137Third136Proof44
  · exact adaptive137Third136Proof45
  · exact adaptive137Third136Proof46
  · exact adaptive137Third136Proof47
  · exact adaptive137Third136Proof48

#print axioms adaptive137Third136Proof23

theorem adaptive137Third136Proof49 : runCachedNode 511 128437 Adaptive137Third136Node49 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 128437 Adaptive137Third136Node49 = [104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 124, 126, 127, 128, 129, 130, 131, 132] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive137Third136Proof50
  · exact adaptive137Third136Proof51
  · exact adaptive137Third136Proof52
  · exact adaptive137Third136Proof53
  · exact adaptive137Third136Proof54
  · exact adaptive137Third136Proof55
  · exact adaptive137Third136Proof56
  · exact adaptive137Third136Proof57
  · exact adaptive137Third136Proof58
  · exact adaptive137Third136Proof59
  · exact adaptive137Third136Proof60
  · exact adaptive137Third136Proof61
  · exact adaptive137Third136Proof62
  · exact adaptive137Third136Proof63
  · exact adaptive137Third136Proof64
  · exact adaptive137Third136Proof65
  · exact adaptive137Third136Proof66
  · exact adaptive137Third136Proof67
  · exact adaptive137Third136Proof68
  · exact adaptive137Third136Proof69
  · exact adaptive137Third136Proof70
  · exact adaptive137Third136Proof71
  · exact adaptive137Third136Proof72
  · exact adaptive137Third136Proof73
  · exact adaptive137Third136Proof74
  · exact adaptive137Third136Proof75

#print axioms adaptive137Third136Proof49

theorem adaptive137Third136Proof103 : runCachedNode 511 128437 Adaptive137Third136Node103 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 128437 Adaptive137Third136Node103 = [93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 126, 128, 129, 130] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive137Third136Proof104
  · exact adaptive137Third136Proof105
  · exact adaptive137Third136Proof106
  · exact adaptive137Third136Proof107
  · exact adaptive137Third136Proof108
  · exact adaptive137Third136Proof109
  · exact adaptive137Third136Proof110
  · exact adaptive137Third136Proof111
  · exact adaptive137Third136Proof112
  · exact adaptive137Third136Proof113
  · exact adaptive137Third136Proof114
  · exact adaptive137Third136Proof115
  · exact adaptive137Third136Proof116
  · exact adaptive137Third136Proof117
  · exact adaptive137Third136Proof118
  · exact adaptive137Third136Proof119
  · exact adaptive137Third136Proof120
  · exact adaptive137Third136Proof121
  · exact adaptive137Third136Proof122
  · exact adaptive137Third136Proof123
  · exact adaptive137Third136Proof124
  · exact adaptive137Third136Proof125
  · exact adaptive137Third136Proof126
  · exact adaptive137Third136Proof127
  · exact adaptive137Third136Proof128
  · exact adaptive137Third136Proof129
  · exact adaptive137Third136Proof130
  · exact adaptive137Third136Proof131
  · exact adaptive137Third136Proof132
  · exact adaptive137Third136Proof133

#print axioms adaptive137Third136Proof103

theorem adaptive137Third136Proof76 : runCachedNode 511 128437 Adaptive137Third136Node76 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 128437 Adaptive137Third136Node76 = [104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 126, 127, 128, 129, 130, 131, 132, 133] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive137Third136Proof77
  · exact adaptive137Third136Proof78
  · exact adaptive137Third136Proof79
  · exact adaptive137Third136Proof80
  · exact adaptive137Third136Proof81
  · exact adaptive137Third136Proof82
  · exact adaptive137Third136Proof83
  · exact adaptive137Third136Proof84
  · exact adaptive137Third136Proof85
  · exact adaptive137Third136Proof86
  · exact adaptive137Third136Proof87
  · exact adaptive137Third136Proof88
  · exact adaptive137Third136Proof89
  · exact adaptive137Third136Proof90
  · exact adaptive137Third136Proof91
  · exact adaptive137Third136Proof92
  · exact adaptive137Third136Proof93
  · exact adaptive137Third136Proof94
  · exact adaptive137Third136Proof95
  · exact adaptive137Third136Proof96
  · exact adaptive137Third136Proof97
  · exact adaptive137Third136Proof98
  · exact adaptive137Third136Proof99
  · exact adaptive137Third136Proof100
  · exact adaptive137Third136Proof101
  · exact adaptive137Third136Proof102
  · exact adaptive137Third136Proof103

#print axioms adaptive137Third136Proof76

theorem adaptive137Third136Proof0 : runCachedNode 511 128437 Adaptive137Third136Node0 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 128437 Adaptive137Third136Node0 = [110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 126, 127, 128, 129, 130, 131, 132, 133, 134, 135] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive137Third136Proof1
  · exact adaptive137Third136Proof2
  · exact adaptive137Third136Proof3
  · exact adaptive137Third136Proof4
  · exact adaptive137Third136Proof5
  · exact adaptive137Third136Proof6
  · exact adaptive137Third136Proof7
  · exact adaptive137Third136Proof8
  · exact adaptive137Third136Proof9
  · exact adaptive137Third136Proof10
  · exact adaptive137Third136Proof11
  · exact adaptive137Third136Proof12
  · exact adaptive137Third136Proof13
  · exact adaptive137Third136Proof14
  · exact adaptive137Third136Proof15
  · exact adaptive137Third136Proof16
  · exact adaptive137Third136Proof17
  · exact adaptive137Third136Proof18
  · exact adaptive137Third136Proof19
  · exact adaptive137Third136Proof20
  · exact adaptive137Third136Proof21
  · exact adaptive137Third136Proof22
  · exact adaptive137Third136Proof23
  · exact adaptive137Third136Proof49
  · exact adaptive137Third136Proof76

#print axioms adaptive137Third136Proof0

end NineSeparatedSubsetSums
