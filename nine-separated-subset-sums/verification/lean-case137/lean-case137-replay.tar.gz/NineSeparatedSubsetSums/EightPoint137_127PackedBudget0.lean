import NineSeparatedSubsetSums.EightPoint137_127PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct137_127_0_budget :
    FourPointNumeric.packedBudget 20 packedOct137_127_0 453 = 85332999 := by decide +kernel

#print axioms packedOct137_127_0_budget

end NineSeparatedSubsetSums
