import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive137Third122Node0 : CachedSearchNode :=
  ⟨4, 121, computeCenteredMask [148,137,122], 407, 55557⟩

end NineSeparatedSubsetSums
