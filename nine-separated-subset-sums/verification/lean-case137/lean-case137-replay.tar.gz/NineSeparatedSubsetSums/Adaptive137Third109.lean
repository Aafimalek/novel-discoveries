import NineSeparatedSubsetSums.Adaptive137Third109Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint137Checked

namespace NineSeparatedSubsetSums


theorem adaptive137Third109 : NoDescendingTailAfterThird 137 109 :=
  noDescendingThirdTail_of_cached 137 109 111041 (fun t ht nd => max148_second137_fourPoint_moment_bound (109::t) (by simp [ht]) nd) adaptive137Third109Proof0

#print axioms adaptive137Third109

end NineSeparatedSubsetSums
