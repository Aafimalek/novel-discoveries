import NineSeparatedSubsetSums.Adaptive137Third131State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third131Proof16 : runCachedNode 511 127537 Adaptive137Third131Node16 = false := by
  decide +kernel

#print axioms adaptive137Third131Proof16

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third131Proof14 : runCachedNode 511 127537 Adaptive137Third131Node14 = false := by
  decide +kernel

#print axioms adaptive137Third131Proof14

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third131Proof12 : runCachedNode 511 127537 Adaptive137Third131Node12 = false := by
  decide +kernel

#print axioms adaptive137Third131Proof12

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third131Proof11 : runCachedNode 511 127537 Adaptive137Third131Node11 = false := by
  decide +kernel

#print axioms adaptive137Third131Proof11

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third131Proof10 : runCachedNode 511 127537 Adaptive137Third131Node10 = false := by
  decide +kernel

#print axioms adaptive137Third131Proof10

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third131Proof9 : runCachedNode 511 127537 Adaptive137Third131Node9 = false := by
  decide +kernel

#print axioms adaptive137Third131Proof9

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third131Proof8 : runCachedNode 511 127537 Adaptive137Third131Node8 = false := by
  decide +kernel

#print axioms adaptive137Third131Proof8

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third131Proof7 : runCachedNode 511 127537 Adaptive137Third131Node7 = false := by
  decide +kernel

#print axioms adaptive137Third131Proof7

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third131Proof6 : runCachedNode 511 127537 Adaptive137Third131Node6 = false := by
  decide +kernel

#print axioms adaptive137Third131Proof6

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third131Proof4 : runCachedNode 511 127537 Adaptive137Third131Node4 = false := by
  decide +kernel

#print axioms adaptive137Third131Proof4

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third131Proof3 : runCachedNode 511 127537 Adaptive137Third131Node3 = false := by
  decide +kernel

#print axioms adaptive137Third131Proof3

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third131Proof2 : runCachedNode 511 127537 Adaptive137Third131Node2 = false := by
  decide +kernel

#print axioms adaptive137Third131Proof2

end NineSeparatedSubsetSums
