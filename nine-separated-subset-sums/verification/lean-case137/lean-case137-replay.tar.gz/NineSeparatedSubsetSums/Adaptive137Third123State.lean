import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive137Third123Node0 : CachedSearchNode :=
  ⟨4, 122, computeCenteredMask [148,137,123], 408, 55802⟩

end NineSeparatedSubsetSums
