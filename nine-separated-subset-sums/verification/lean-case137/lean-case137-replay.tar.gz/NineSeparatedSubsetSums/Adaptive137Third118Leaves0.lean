import NineSeparatedSubsetSums.Adaptive137Third118State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third118Proof0 : runCachedNode 511 124691 Adaptive137Third118Node0 = false := by
  decide +kernel

#print axioms adaptive137Third118Proof0

end NineSeparatedSubsetSums
