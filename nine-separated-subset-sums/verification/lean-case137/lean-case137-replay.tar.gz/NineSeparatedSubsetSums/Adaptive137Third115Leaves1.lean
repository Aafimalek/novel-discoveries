import NineSeparatedSubsetSums.Adaptive137Third115State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third115Proof6 : runCachedNode 511 111041 Adaptive137Third115Node6 = false := by
  decide +kernel

#print axioms adaptive137Third115Proof6

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third115Proof5 : runCachedNode 511 111041 Adaptive137Third115Node5 = false := by
  decide +kernel

#print axioms adaptive137Third115Proof5

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third115Proof4 : runCachedNode 511 111041 Adaptive137Third115Node4 = false := by
  decide +kernel

#print axioms adaptive137Third115Proof4

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third115Proof2 : runCachedNode 511 111041 Adaptive137Third115Node2 = false := by
  decide +kernel

#print axioms adaptive137Third115Proof2

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third115Proof1 : runCachedNode 511 111041 Adaptive137Third115Node1 = false := by
  decide +kernel

#print axioms adaptive137Third115Proof1

end NineSeparatedSubsetSums
