import NineSeparatedSubsetSums.EightPoint137_121PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct137_121_1_budget :
    FourPointNumeric.packedBudget 20 packedOct137_121_1 394 = 85250932 := by decide +kernel

#print axioms packedOct137_121_1_budget

end NineSeparatedSubsetSums
