import NineSeparatedSubsetSums.Adaptive137Third127State
import NineSeparatedSubsetSums.Adaptive137Third127Leaves1
import NineSeparatedSubsetSums.Adaptive137Third127Leaves0

namespace NineSeparatedSubsetSums

theorem adaptive137Third127Proof0 : runCachedNode 511 126780 Adaptive137Third127Node0 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 126780 Adaptive137Third127Node0 = [111, 112, 113, 114, 115, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive137Third127Proof1
  · exact adaptive137Third127Proof2
  · exact adaptive137Third127Proof3
  · exact adaptive137Third127Proof4
  · exact adaptive137Third127Proof5
  · exact adaptive137Third127Proof6
  · exact adaptive137Third127Proof7
  · exact adaptive137Third127Proof8
  · exact adaptive137Third127Proof9
  · exact adaptive137Third127Proof10
  · exact adaptive137Third127Proof11
  · exact adaptive137Third127Proof12
  · exact adaptive137Third127Proof13
  · exact adaptive137Third127Proof14
  · exact adaptive137Third127Proof15

#print axioms adaptive137Third127Proof0

end NineSeparatedSubsetSums
