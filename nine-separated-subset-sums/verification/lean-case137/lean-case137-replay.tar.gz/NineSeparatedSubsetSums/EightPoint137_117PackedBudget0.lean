import NineSeparatedSubsetSums.EightPoint137_117PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct137_117_0_budget :
    FourPointNumeric.packedBudget 20 packedOct137_117_0 267 = 81641905 := by decide +kernel

#print axioms packedOct137_117_0_budget

end NineSeparatedSubsetSums
