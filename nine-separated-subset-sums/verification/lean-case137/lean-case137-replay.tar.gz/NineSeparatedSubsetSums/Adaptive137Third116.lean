import NineSeparatedSubsetSums.Adaptive137Third116Joins0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint137Checked

namespace NineSeparatedSubsetSums


theorem adaptive137Third116 : NoDescendingTailAfterThird 137 116 :=
  noDescendingThirdTail_of_cached 137 116 111041 (fun t ht nd => max148_second137_fourPoint_moment_bound (116::t) (by simp [ht]) nd) adaptive137Third116Proof0

#print axioms adaptive137Third116

end NineSeparatedSubsetSums
