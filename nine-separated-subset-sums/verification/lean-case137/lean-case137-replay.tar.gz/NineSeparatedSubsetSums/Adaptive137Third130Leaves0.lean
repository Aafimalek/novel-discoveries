import NineSeparatedSubsetSums.Adaptive137Third130State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third130Proof18 : runCachedNode 511 127329 Adaptive137Third130Node18 = false := by
  decide +kernel

#print axioms adaptive137Third130Proof18

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third130Proof15 : runCachedNode 511 127329 Adaptive137Third130Node15 = false := by
  decide +kernel

#print axioms adaptive137Third130Proof15

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third130Proof9 : runCachedNode 511 127329 Adaptive137Third130Node9 = false := by
  decide +kernel

#print axioms adaptive137Third130Proof9

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third130Proof2 : runCachedNode 511 127329 Adaptive137Third130Node2 = false := by
  decide +kernel

#print axioms adaptive137Third130Proof2

end NineSeparatedSubsetSums
