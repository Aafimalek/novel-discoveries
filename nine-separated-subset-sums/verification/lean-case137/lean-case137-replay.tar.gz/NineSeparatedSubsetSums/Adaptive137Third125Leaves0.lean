import NineSeparatedSubsetSums.Adaptive137Third125State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third125Proof0 : runCachedNode 511 126425 Adaptive137Third125Node0 = false := by
  decide +kernel

#print axioms adaptive137Third125Proof0

end NineSeparatedSubsetSums
