import NineSeparatedSubsetSums.Adaptive137Third105Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint137Checked

namespace NineSeparatedSubsetSums


theorem adaptive137Third105 : NoDescendingTailAfterThird 137 105 :=
  noDescendingThirdTail_of_cached 137 105 111041 (fun t ht nd => max148_second137_fourPoint_moment_bound (105::t) (by simp [ht]) nd) adaptive137Third105Proof0

#print axioms adaptive137Third105

end NineSeparatedSubsetSums
