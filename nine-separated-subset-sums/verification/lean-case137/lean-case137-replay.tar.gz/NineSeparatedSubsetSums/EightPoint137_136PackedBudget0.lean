import NineSeparatedSubsetSums.EightPoint137_136PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct137_136_0_budget :
    FourPointNumeric.packedBudget 20 packedOct137_136_0 271 = 90866403 := by decide +kernel

#print axioms packedOct137_136_0_budget

end NineSeparatedSubsetSums
