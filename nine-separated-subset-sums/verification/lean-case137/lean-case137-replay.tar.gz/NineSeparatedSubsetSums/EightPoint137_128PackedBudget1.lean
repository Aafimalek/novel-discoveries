import NineSeparatedSubsetSums.EightPoint137_128PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct137_128_1_budget :
    FourPointNumeric.packedBudget 20 packedOct137_128_1 366 = 85052302 := by decide +kernel

#print axioms packedOct137_128_1_budget

end NineSeparatedSubsetSums
