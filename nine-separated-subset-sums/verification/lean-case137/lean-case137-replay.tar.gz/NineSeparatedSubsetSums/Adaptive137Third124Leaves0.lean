import NineSeparatedSubsetSums.Adaptive137Third124State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third124Proof0 : runCachedNode 511 125990 Adaptive137Third124Node0 = false := by
  decide +kernel

#print axioms adaptive137Third124Proof0

end NineSeparatedSubsetSums
