import NineSeparatedSubsetSums.EightPoint137_117PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint137_117PackedAnchor0Part1 :
    ∀ j : Fin 120, 2271685 ≤ FourPointNumeric.octPackedCharge 137 117 20 packedOct137_117_0
      (2*((j.val : Int)+120)+0) := by decide +kernel

end NineSeparatedSubsetSums
