import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive137Third104Node0 : CachedSearchNode :=
  ⟨4, 103, computeCenteredMask [148,137,104], 389, 51489⟩

end NineSeparatedSubsetSums
