import NineSeparatedSubsetSums.Adaptive137Third104Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint137Checked

namespace NineSeparatedSubsetSums


theorem adaptive137Third104 : NoDescendingTailAfterThird 137 104 :=
  noDescendingThirdTail_of_cached 137 104 111041 (fun t ht nd => max148_second137_fourPoint_moment_bound (104::t) (by simp [ht]) nd) adaptive137Third104Proof0

#print axioms adaptive137Third104

end NineSeparatedSubsetSums
