import NineSeparatedSubsetSums.Adaptive137Third135State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third135Proof21 : runCachedNode 511 128257 Adaptive137Third135Node21 = false := by
  decide +kernel

#print axioms adaptive137Third135Proof21

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third135Proof66 : runCachedNode 511 128257 Adaptive137Third135Node66 = false := by
  decide +kernel

#print axioms adaptive137Third135Proof66

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third135Proof1 : runCachedNode 511 128257 Adaptive137Third135Node1 = false := by
  decide +kernel

#print axioms adaptive137Third135Proof1

end NineSeparatedSubsetSums
