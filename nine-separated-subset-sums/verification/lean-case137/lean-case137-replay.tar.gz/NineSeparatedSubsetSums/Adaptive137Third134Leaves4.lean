import NineSeparatedSubsetSums.Adaptive137Third134State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third134Proof13 : runCachedNode 511 128023 Adaptive137Third134Node13 = false := by
  decide +kernel

#print axioms adaptive137Third134Proof13

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third134Proof40 : runCachedNode 511 128023 Adaptive137Third134Node40 = false := by
  decide +kernel

#print axioms adaptive137Third134Proof40

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third134Proof63 : runCachedNode 511 128023 Adaptive137Third134Node63 = false := by
  decide +kernel

#print axioms adaptive137Third134Proof63

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third134Proof12 : runCachedNode 511 128023 Adaptive137Third134Node12 = false := by
  decide +kernel

#print axioms adaptive137Third134Proof12

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third134Proof38 : runCachedNode 511 128023 Adaptive137Third134Node38 = false := by
  decide +kernel

#print axioms adaptive137Third134Proof38

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third134Proof91 : runCachedNode 511 128023 Adaptive137Third134Node91 = false := by
  decide +kernel

#print axioms adaptive137Third134Proof91

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third134Proof10 : runCachedNode 511 128023 Adaptive137Third134Node10 = false := by
  decide +kernel

#print axioms adaptive137Third134Proof10

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third134Proof64 : runCachedNode 511 128023 Adaptive137Third134Node64 = false := by
  decide +kernel

#print axioms adaptive137Third134Proof64

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third134Proof90 : runCachedNode 511 128023 Adaptive137Third134Node90 = false := by
  decide +kernel

#print axioms adaptive137Third134Proof90

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third134Proof21 : runCachedNode 511 128023 Adaptive137Third134Node21 = false := by
  decide +kernel

#print axioms adaptive137Third134Proof21

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third134Proof69 : runCachedNode 511 128023 Adaptive137Third134Node69 = false := by
  decide +kernel

#print axioms adaptive137Third134Proof69

end NineSeparatedSubsetSums
