import NineSeparatedSubsetSums.Adaptive137Third112Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint137Checked

namespace NineSeparatedSubsetSums


theorem adaptive137Third112 : NoDescendingTailAfterThird 137 112 :=
  noDescendingThirdTail_of_cached 137 112 111041 (fun t ht nd => max148_second137_fourPoint_moment_bound (112::t) (by simp [ht]) nd) adaptive137Third112Proof0

#print axioms adaptive137Third112

end NineSeparatedSubsetSums
