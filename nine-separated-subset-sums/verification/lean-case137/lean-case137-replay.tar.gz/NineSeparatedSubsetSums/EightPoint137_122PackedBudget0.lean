import NineSeparatedSubsetSums.EightPoint137_122PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct137_122_0_budget :
    FourPointNumeric.packedBudget 20 packedOct137_122_0 465 = 81442832 := by decide +kernel

#print axioms packedOct137_122_0_budget

end NineSeparatedSubsetSums
