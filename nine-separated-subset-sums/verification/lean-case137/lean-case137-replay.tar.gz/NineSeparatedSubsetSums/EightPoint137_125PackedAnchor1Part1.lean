import NineSeparatedSubsetSums.EightPoint137_125PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint137_125PackedAnchor1Part1 :
    ∀ j : Fin 120, 2309643 ≤ FourPointNumeric.octPackedCharge 137 125 20 packedOct137_125_1
      (2*((j.val : Int)+120)+1) := by decide +kernel

end NineSeparatedSubsetSums
