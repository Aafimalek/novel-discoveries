import NineSeparatedSubsetSums.FourPoint137PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem fourPoint137PackedAnchor0Part2 :
    ∀ j : Fin 3, 1105784 ≤ FourPointNumeric.packedCharge 137 20 packedWeight137_0
      (2*((j.val : Int)+240)+1) := by decide +kernel

end NineSeparatedSubsetSums
