import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive137Third105Node0 : CachedSearchNode :=
  ⟨4, 104, computeCenteredMask [148,137,105], 390, 51698⟩

end NineSeparatedSubsetSums
