import NineSeparatedSubsetSums.EightPoint137_123PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct137_123_0_budget :
    FourPointNumeric.packedBudget 20 packedOct137_123_0 471 = 81304837 := by decide +kernel

#print axioms packedOct137_123_0_budget

end NineSeparatedSubsetSums
