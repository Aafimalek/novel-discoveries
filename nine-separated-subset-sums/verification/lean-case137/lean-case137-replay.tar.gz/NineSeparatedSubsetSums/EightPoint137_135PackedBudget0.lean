import NineSeparatedSubsetSums.EightPoint137_135PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct137_135_0_budget :
    FourPointNumeric.packedBudget 20 packedOct137_135_0 271 = 90827636 := by decide +kernel

#print axioms packedOct137_135_0_budget

end NineSeparatedSubsetSums
