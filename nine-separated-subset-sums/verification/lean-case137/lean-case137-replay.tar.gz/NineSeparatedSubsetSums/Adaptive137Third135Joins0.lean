import NineSeparatedSubsetSums.Adaptive137Third135State
import NineSeparatedSubsetSums.Adaptive137Third135Leaves2
import NineSeparatedSubsetSums.Adaptive137Third135Leaves7
import NineSeparatedSubsetSums.Adaptive137Third135Leaves8
import NineSeparatedSubsetSums.Adaptive137Third135Leaves4
import NineSeparatedSubsetSums.Adaptive137Third135Leaves0
import NineSeparatedSubsetSums.Adaptive137Third135Leaves6
import NineSeparatedSubsetSums.Adaptive137Third135Leaves5
import NineSeparatedSubsetSums.Adaptive137Third135Leaves3
import NineSeparatedSubsetSums.Adaptive137Third135Leaves1

namespace NineSeparatedSubsetSums

theorem adaptive137Third135Proof22 : runCachedNode 511 128257 Adaptive137Third135Node22 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 128257 Adaptive137Third135Node22 = [104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 121, 123, 125, 126, 127, 128, 129, 130, 132] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive137Third135Proof23
  · exact adaptive137Third135Proof24
  · exact adaptive137Third135Proof25
  · exact adaptive137Third135Proof26
  · exact adaptive137Third135Proof27
  · exact adaptive137Third135Proof28
  · exact adaptive137Third135Proof29
  · exact adaptive137Third135Proof30
  · exact adaptive137Third135Proof31
  · exact adaptive137Third135Proof32
  · exact adaptive137Third135Proof33
  · exact adaptive137Third135Proof34
  · exact adaptive137Third135Proof35
  · exact adaptive137Third135Proof36
  · exact adaptive137Third135Proof37
  · exact adaptive137Third135Proof38
  · exact adaptive137Third135Proof39
  · exact adaptive137Third135Proof40
  · exact adaptive137Third135Proof41
  · exact adaptive137Third135Proof42
  · exact adaptive137Third135Proof43
  · exact adaptive137Third135Proof44
  · exact adaptive137Third135Proof45
  · exact adaptive137Third135Proof46
  · exact adaptive137Third135Proof47

#print axioms adaptive137Third135Proof22

theorem adaptive137Third135Proof48 : runCachedNode 511 128257 Adaptive137Third135Node48 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 128257 Adaptive137Third135Node48 = [104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 122, 125, 126, 127, 128, 129, 130, 131, 133] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive137Third135Proof49
  · exact adaptive137Third135Proof50
  · exact adaptive137Third135Proof51
  · exact adaptive137Third135Proof52
  · exact adaptive137Third135Proof53
  · exact adaptive137Third135Proof54
  · exact adaptive137Third135Proof55
  · exact adaptive137Third135Proof56
  · exact adaptive137Third135Proof57
  · exact adaptive137Third135Proof58
  · exact adaptive137Third135Proof59
  · exact adaptive137Third135Proof60
  · exact adaptive137Third135Proof61
  · exact adaptive137Third135Proof62
  · exact adaptive137Third135Proof63
  · exact adaptive137Third135Proof64
  · exact adaptive137Third135Proof65
  · exact adaptive137Third135Proof66
  · exact adaptive137Third135Proof67
  · exact adaptive137Third135Proof68
  · exact adaptive137Third135Proof69
  · exact adaptive137Third135Proof70
  · exact adaptive137Third135Proof71
  · exact adaptive137Third135Proof72
  · exact adaptive137Third135Proof73
  · exact adaptive137Third135Proof74

#print axioms adaptive137Third135Proof48

theorem adaptive137Third135Proof0 : runCachedNode 511 128257 Adaptive137Third135Node0 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 128257 Adaptive137Third135Node0 = [111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 125, 126, 127, 128, 129, 130, 131, 132, 133, 134] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive137Third135Proof1
  · exact adaptive137Third135Proof2
  · exact adaptive137Third135Proof3
  · exact adaptive137Third135Proof4
  · exact adaptive137Third135Proof5
  · exact adaptive137Third135Proof6
  · exact adaptive137Third135Proof7
  · exact adaptive137Third135Proof8
  · exact adaptive137Third135Proof9
  · exact adaptive137Third135Proof10
  · exact adaptive137Third135Proof11
  · exact adaptive137Third135Proof12
  · exact adaptive137Third135Proof13
  · exact adaptive137Third135Proof14
  · exact adaptive137Third135Proof15
  · exact adaptive137Third135Proof16
  · exact adaptive137Third135Proof17
  · exact adaptive137Third135Proof18
  · exact adaptive137Third135Proof19
  · exact adaptive137Third135Proof20
  · exact adaptive137Third135Proof21
  · exact adaptive137Third135Proof22
  · exact adaptive137Third135Proof48

#print axioms adaptive137Third135Proof0

end NineSeparatedSubsetSums
