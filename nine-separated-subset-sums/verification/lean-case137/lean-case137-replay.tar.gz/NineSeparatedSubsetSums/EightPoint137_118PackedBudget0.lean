import NineSeparatedSubsetSums.EightPoint137_118PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct137_118_0_budget :
    FourPointNumeric.packedBudget 20 packedOct137_118_0 489 = 82257718 := by decide +kernel

#print axioms packedOct137_118_0_budget

end NineSeparatedSubsetSums
