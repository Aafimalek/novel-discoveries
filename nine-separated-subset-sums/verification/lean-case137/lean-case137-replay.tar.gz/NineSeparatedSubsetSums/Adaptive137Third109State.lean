import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive137Third109Node0 : CachedSearchNode :=
  ⟨4, 108, computeCenteredMask [148,137,109], 394, 52554⟩

end NineSeparatedSubsetSums
