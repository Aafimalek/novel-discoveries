import NineSeparatedSubsetSums.EightPointPackedGeometry
import NineSeparatedSubsetSums.EightPoint137_136PackedBudget0
import NineSeparatedSubsetSums.EightPoint137_136PackedAnchor0Part0
import NineSeparatedSubsetSums.EightPoint137_136PackedAnchor0Part1
import NineSeparatedSubsetSums.EightPoint137_136PackedAnchor0Part2
import NineSeparatedSubsetSums.EightPoint137_136PackedBudget1
import NineSeparatedSubsetSums.EightPoint137_136PackedAnchor1Part0
import NineSeparatedSubsetSums.EightPoint137_136PackedAnchor1Part1
import NineSeparatedSubsetSums.EightPoint137_136PackedAnchor1Part2

namespace NineSeparatedSubsetSums

private theorem packedOct137_136Anchor0 :
  ∀ j : Fin 497, ((j.val : Int)+137+136)%2=0 →
    2447284 ≤ FourPointNumeric.octPackedCharge 137 136 20 packedOct137_136_0 (j.val : Int) := by
  intro j hj
  let k := (j.val-1)/2
  have hk : k < 248 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+1 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint137_136PackedAnchor0Part0 z
    rwa [he,hrep] at ht
  by_cases h1 : k < 240
  · let z : Fin 120 := ⟨k-120, by omega⟩
    have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
    have ht := eightPoint137_136PackedAnchor0Part1 z
    rwa [he,hrep] at ht
  let z : Fin 8 := ⟨k-240, by omega⟩
  have he : (z.val : Int)+240 = k := by dsimp [z] <;> omega
  have ht := eightPoint137_136PackedAnchor0Part2 z
  rwa [he,hrep] at ht

private theorem packedOct137_136Anchor1 :
  ∀ j : Fin 497, ((j.val : Int)+137+136)%2=1 →
    2447411 ≤ FourPointNumeric.octPackedCharge 137 136 20 packedOct137_136_1 (j.val : Int) := by
  intro j hj
  let k := (j.val-0)/2
  have hk : k < 249 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+0 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint137_136PackedAnchor1Part0 z
    rwa [he,hrep] at ht
  by_cases h1 : k < 240
  · let z : Fin 120 := ⟨k-120, by omega⟩
    have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
    have ht := eightPoint137_136PackedAnchor1Part1 z
    rwa [he,hrep] at ht
  let z : Fin 9 := ⟨k-240, by omega⟩
  have he : (z.val : Int)+240 = k := by dsimp [z] <;> omega
  have ht := eightPoint137_136PackedAnchor1Part2 z
  rwa [he,hrep] at ht

def packedOctCertificate137_136_0 : EightPointCertificate 137 136 0 128437 :=
  eightPointCertificateOfPacked 137 136 0 128437 2447284 20 packedOct137_136_0 271 497
    (by decide +kernel) (by decide) packedOct137_136Anchor0
    (by rw [packedOct137_136_0_budget]; decide)

def packedOctCertificate137_136_1 : EightPointCertificate 137 136 1 128437 :=
  eightPointCertificateOfPacked 137 136 1 128437 2447411 20 packedOct137_136_1 272 497
    (by decide +kernel) (by decide) packedOct137_136Anchor1
    (by rw [packedOct137_136_1_budget]; decide)

theorem max148_second137_third136_eightPoint_moment_bound (tail : List ℕ) (len : tail.length=6)
    (distinct : (natSubsetSums (148::137::136::tail)).Nodup) :
    128437 ≤ ((148::137::136::tail).map (· ^ 2)).sum := by
  apply eightPointNatMomentLower 137 136 128437 tail len distinct
  intro p hp
  by_cases h : p=0
  · subst p
    exact packedOctCertificate137_136_0
  · have he : p=1 := hp.resolve_left h
    subst p
    exact packedOctCertificate137_136_1

#print axioms max148_second137_third136_eightPoint_moment_bound

end NineSeparatedSubsetSums
