import NineSeparatedSubsetSums.EightPoint137_132PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint137_132PackedAnchor0Part2 :
    ∀ j : Fin 7, 2418222 ≤ FourPointNumeric.octPackedCharge 137 132 20 packedOct137_132_0
      (2*((j.val : Int)+240)+1) := by decide +kernel

end NineSeparatedSubsetSums
