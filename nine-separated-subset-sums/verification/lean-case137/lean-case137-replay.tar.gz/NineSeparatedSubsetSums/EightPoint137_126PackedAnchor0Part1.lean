import NineSeparatedSubsetSums.EightPoint137_126PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint137_126PackedAnchor0Part1 :
    ∀ j : Fin 120, 2345437 ≤ FourPointNumeric.octPackedCharge 137 126 20 packedOct137_126_0
      (2*((j.val : Int)+120)+1) := by decide +kernel

end NineSeparatedSubsetSums
