import NineSeparatedSubsetSums.Adaptive137Third136State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third136Proof14 : runCachedNode 511 128437 Adaptive137Third136Node14 = false := by
  decide +kernel

#print axioms adaptive137Third136Proof14

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third136Proof68 : runCachedNode 511 128437 Adaptive137Third136Node68 = false := by
  decide +kernel

#print axioms adaptive137Third136Proof68

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third136Proof47 : runCachedNode 511 128437 Adaptive137Third136Node47 = false := by
  decide +kernel

#print axioms adaptive137Third136Proof47

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third136Proof13 : runCachedNode 511 128437 Adaptive137Third136Node13 = false := by
  decide +kernel

#print axioms adaptive137Third136Proof13

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third136Proof43 : runCachedNode 511 128437 Adaptive137Third136Node43 = false := by
  decide +kernel

#print axioms adaptive137Third136Proof43

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third136Proof69 : runCachedNode 511 128437 Adaptive137Third136Node69 = false := by
  decide +kernel

#print axioms adaptive137Third136Proof69

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third136Proof12 : runCachedNode 511 128437 Adaptive137Third136Node12 = false := by
  decide +kernel

#print axioms adaptive137Third136Proof12

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third136Proof42 : runCachedNode 511 128437 Adaptive137Third136Node42 = false := by
  decide +kernel

#print axioms adaptive137Third136Proof42

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third136Proof70 : runCachedNode 511 128437 Adaptive137Third136Node70 = false := by
  decide +kernel

#print axioms adaptive137Third136Proof70

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third136Proof72 : runCachedNode 511 128437 Adaptive137Third136Node72 = false := by
  decide +kernel

#print axioms adaptive137Third136Proof72

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third136Proof67 : runCachedNode 511 128437 Adaptive137Third136Node67 = false := by
  decide +kernel

#print axioms adaptive137Third136Proof67

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third136Proof93 : runCachedNode 511 128437 Adaptive137Third136Node93 = false := by
  decide +kernel

#print axioms adaptive137Third136Proof93

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third136Proof65 : runCachedNode 511 128437 Adaptive137Third136Node65 = false := by
  decide +kernel

#print axioms adaptive137Third136Proof65

end NineSeparatedSubsetSums
