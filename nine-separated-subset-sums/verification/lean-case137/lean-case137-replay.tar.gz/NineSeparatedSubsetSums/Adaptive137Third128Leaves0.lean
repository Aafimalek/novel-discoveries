import NineSeparatedSubsetSums.Adaptive137Third128State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third128Proof15 : runCachedNode 511 126896 Adaptive137Third128Node15 = false := by
  decide +kernel

#print axioms adaptive137Third128Proof15

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third128Proof16 : runCachedNode 511 126896 Adaptive137Third128Node16 = false := by
  decide +kernel

#print axioms adaptive137Third128Proof16

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third128Proof14 : runCachedNode 511 126896 Adaptive137Third128Node14 = false := by
  decide +kernel

#print axioms adaptive137Third128Proof14

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third128Proof11 : runCachedNode 511 126896 Adaptive137Third128Node11 = false := by
  decide +kernel

#print axioms adaptive137Third128Proof11

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third128Proof3 : runCachedNode 511 126896 Adaptive137Third128Node3 = false := by
  decide +kernel

#print axioms adaptive137Third128Proof3

end NineSeparatedSubsetSums
