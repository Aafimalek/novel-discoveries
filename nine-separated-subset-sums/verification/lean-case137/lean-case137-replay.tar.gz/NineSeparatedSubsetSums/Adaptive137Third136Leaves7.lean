import NineSeparatedSubsetSums.Adaptive137Third136State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third136Proof46 : runCachedNode 511 128437 Adaptive137Third136Node46 = false := by
  decide +kernel

#print axioms adaptive137Third136Proof46

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third136Proof15 : runCachedNode 511 128437 Adaptive137Third136Node15 = false := by
  decide +kernel

#print axioms adaptive137Third136Proof15

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third136Proof132 : runCachedNode 511 128437 Adaptive137Third136Node132 = false := by
  decide +kernel

#print axioms adaptive137Third136Proof132

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third136Proof130 : runCachedNode 511 128437 Adaptive137Third136Node130 = false := by
  decide +kernel

#print axioms adaptive137Third136Proof130

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third136Proof11 : runCachedNode 511 128437 Adaptive137Third136Node11 = false := by
  decide +kernel

#print axioms adaptive137Third136Proof11

end NineSeparatedSubsetSums
