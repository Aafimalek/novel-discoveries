import NineSeparatedSubsetSums.EightPoint137_131PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct137_131_0_budget :
    FourPointNumeric.packedBudget 20 packedOct137_131_0 361 = 89633320 := by decide +kernel

#print axioms packedOct137_131_0_budget

end NineSeparatedSubsetSums
