import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive137Third121Node0 : CachedSearchNode :=
  ⟨4, 120, computeCenteredMask [148,137,121], 406, 55314⟩

end NineSeparatedSubsetSums
