import NineSeparatedSubsetSums.FourPoint137PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem fourPoint137PackedAnchor1Part1 :
    ∀ j : Fin 120, 1105780 ≤ FourPointNumeric.packedCharge 137 20 packedWeight137_1
      (2*((j.val : Int)+120)+0) := by decide +kernel

end NineSeparatedSubsetSums
