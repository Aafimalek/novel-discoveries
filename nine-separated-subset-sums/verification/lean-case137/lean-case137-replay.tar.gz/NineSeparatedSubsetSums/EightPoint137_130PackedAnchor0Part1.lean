import NineSeparatedSubsetSums.EightPoint137_130PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint137_130PackedAnchor0Part1 :
    ∀ j : Fin 120, 2401216 ≤ FourPointNumeric.octPackedCharge 137 130 20 packedOct137_130_0
      (2*((j.val : Int)+120)+1) := by decide +kernel

end NineSeparatedSubsetSums
