import NineSeparatedSubsetSums.Adaptive137Third131State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third131Proof18 : runCachedNode 511 127537 Adaptive137Third131Node18 = false := by
  decide +kernel

#print axioms adaptive137Third131Proof18

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third131Proof17 : runCachedNode 511 127537 Adaptive137Third131Node17 = false := by
  decide +kernel

#print axioms adaptive137Third131Proof17

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third131Proof13 : runCachedNode 511 127537 Adaptive137Third131Node13 = false := by
  decide +kernel

#print axioms adaptive137Third131Proof13

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third131Proof5 : runCachedNode 511 127537 Adaptive137Third131Node5 = false := by
  decide +kernel

#print axioms adaptive137Third131Proof5

end NineSeparatedSubsetSums
