import NineSeparatedSubsetSums.EightPoint137_123PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint137_123PackedAnchor0Part0 :
    ∀ j : Fin 120, 2275324 ≤ FourPointNumeric.octPackedCharge 137 123 20 packedOct137_123_0
      (2*((j.val : Int)+0)+0) := by decide +kernel

end NineSeparatedSubsetSums
