import NineSeparatedSubsetSums.Adaptive137Third135State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third135Proof18 : runCachedNode 511 128257 Adaptive137Third135Node18 = false := by
  decide +kernel

#print axioms adaptive137Third135Proof18

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third135Proof45 : runCachedNode 511 128257 Adaptive137Third135Node45 = false := by
  decide +kernel

#print axioms adaptive137Third135Proof45

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third135Proof46 : runCachedNode 511 128257 Adaptive137Third135Node46 = false := by
  decide +kernel

#print axioms adaptive137Third135Proof46

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third135Proof69 : runCachedNode 511 128257 Adaptive137Third135Node69 = false := by
  decide +kernel

#print axioms adaptive137Third135Proof69

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third135Proof4 : runCachedNode 511 128257 Adaptive137Third135Node4 = false := by
  decide +kernel

#print axioms adaptive137Third135Proof4

end NineSeparatedSubsetSums
