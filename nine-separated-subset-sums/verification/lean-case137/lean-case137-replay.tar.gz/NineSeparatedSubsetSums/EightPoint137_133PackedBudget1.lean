import NineSeparatedSubsetSums.EightPoint137_133PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct137_133_1_budget :
    FourPointNumeric.packedBudget 20 packedOct137_133_1 474 = 88794326 := by decide +kernel

#print axioms packedOct137_133_1_budget

end NineSeparatedSubsetSums
