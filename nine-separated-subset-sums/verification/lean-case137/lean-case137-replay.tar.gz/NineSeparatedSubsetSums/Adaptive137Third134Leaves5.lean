import NineSeparatedSubsetSums.Adaptive137Third134State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third134Proof89 : runCachedNode 511 128023 Adaptive137Third134Node89 = false := by
  decide +kernel

#print axioms adaptive137Third134Proof89

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third134Proof11 : runCachedNode 511 128023 Adaptive137Third134Node11 = false := by
  decide +kernel

#print axioms adaptive137Third134Proof11

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third134Proof65 : runCachedNode 511 128023 Adaptive137Third134Node65 = false := by
  decide +kernel

#print axioms adaptive137Third134Proof65

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third134Proof37 : runCachedNode 511 128023 Adaptive137Third134Node37 = false := by
  decide +kernel

#print axioms adaptive137Third134Proof37

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third134Proof62 : runCachedNode 511 128023 Adaptive137Third134Node62 = false := by
  decide +kernel

#print axioms adaptive137Third134Proof62

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third134Proof61 : runCachedNode 511 128023 Adaptive137Third134Node61 = false := by
  decide +kernel

#print axioms adaptive137Third134Proof61

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third134Proof9 : runCachedNode 511 128023 Adaptive137Third134Node9 = false := by
  decide +kernel

#print axioms adaptive137Third134Proof9

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third134Proof86 : runCachedNode 511 128023 Adaptive137Third134Node86 = false := by
  decide +kernel

#print axioms adaptive137Third134Proof86

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third134Proof84 : runCachedNode 511 128023 Adaptive137Third134Node84 = false := by
  decide +kernel

#print axioms adaptive137Third134Proof84

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third134Proof59 : runCachedNode 511 128023 Adaptive137Third134Node59 = false := by
  decide +kernel

#print axioms adaptive137Third134Proof59

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third134Proof87 : runCachedNode 511 128023 Adaptive137Third134Node87 = false := by
  decide +kernel

#print axioms adaptive137Third134Proof87

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third134Proof8 : runCachedNode 511 128023 Adaptive137Third134Node8 = false := by
  decide +kernel

#print axioms adaptive137Third134Proof8

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third134Proof36 : runCachedNode 511 128023 Adaptive137Third134Node36 = false := by
  decide +kernel

#print axioms adaptive137Third134Proof36

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third134Proof35 : runCachedNode 511 128023 Adaptive137Third134Node35 = false := by
  decide +kernel

#print axioms adaptive137Third134Proof35

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third134Proof7 : runCachedNode 511 128023 Adaptive137Third134Node7 = false := by
  decide +kernel

#print axioms adaptive137Third134Proof7

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third134Proof83 : runCachedNode 511 128023 Adaptive137Third134Node83 = false := by
  decide +kernel

#print axioms adaptive137Third134Proof83

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third134Proof6 : runCachedNode 511 128023 Adaptive137Third134Node6 = false := by
  decide +kernel

#print axioms adaptive137Third134Proof6

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third134Proof34 : runCachedNode 511 128023 Adaptive137Third134Node34 = false := by
  decide +kernel

#print axioms adaptive137Third134Proof34

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third134Proof60 : runCachedNode 511 128023 Adaptive137Third134Node60 = false := by
  decide +kernel

#print axioms adaptive137Third134Proof60

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third134Proof32 : runCachedNode 511 128023 Adaptive137Third134Node32 = false := by
  decide +kernel

#print axioms adaptive137Third134Proof32

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third134Proof30 : runCachedNode 511 128023 Adaptive137Third134Node30 = false := by
  decide +kernel

#print axioms adaptive137Third134Proof30

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third134Proof82 : runCachedNode 511 128023 Adaptive137Third134Node82 = false := by
  decide +kernel

#print axioms adaptive137Third134Proof82

end NineSeparatedSubsetSums
