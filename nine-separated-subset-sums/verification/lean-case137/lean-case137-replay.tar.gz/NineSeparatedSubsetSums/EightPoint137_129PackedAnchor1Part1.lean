import NineSeparatedSubsetSums.EightPoint137_129PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint137_129PackedAnchor1Part1 :
    ∀ j : Fin 120, 2372737 ≤ FourPointNumeric.octPackedCharge 137 129 20 packedOct137_129_1
      (2*((j.val : Int)+120)+1) := by decide +kernel

end NineSeparatedSubsetSums
