import NineSeparatedSubsetSums.EightPoint137_118PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint137_118PackedAnchor0Part1 :
    ∀ j : Fin 120, 2282807 ≤ FourPointNumeric.octPackedCharge 137 118 20 packedOct137_118_0
      (2*((j.val : Int)+120)+1) := by decide +kernel

end NineSeparatedSubsetSums
