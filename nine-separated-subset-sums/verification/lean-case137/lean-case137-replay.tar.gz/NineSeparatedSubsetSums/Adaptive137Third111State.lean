import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive137Third111Node0 : CachedSearchNode :=
  ⟨4, 110, computeCenteredMask [148,137,111], 396, 52994⟩

end NineSeparatedSubsetSums
