import NineSeparatedSubsetSums.Adaptive137Third126State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third126Proof14 : runCachedNode 511 126757 Adaptive137Third126Node14 = false := by
  decide +kernel

#print axioms adaptive137Third126Proof14

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third126Proof13 : runCachedNode 511 126757 Adaptive137Third126Node13 = false := by
  decide +kernel

#print axioms adaptive137Third126Proof13

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third126Proof12 : runCachedNode 511 126757 Adaptive137Third126Node12 = false := by
  decide +kernel

#print axioms adaptive137Third126Proof12

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third126Proof11 : runCachedNode 511 126757 Adaptive137Third126Node11 = false := by
  decide +kernel

#print axioms adaptive137Third126Proof11

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third126Proof10 : runCachedNode 511 126757 Adaptive137Third126Node10 = false := by
  decide +kernel

#print axioms adaptive137Third126Proof10

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third126Proof4 : runCachedNode 511 126757 Adaptive137Third126Node4 = false := by
  decide +kernel

#print axioms adaptive137Third126Proof4

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third126Proof2 : runCachedNode 511 126757 Adaptive137Third126Node2 = false := by
  decide +kernel

#print axioms adaptive137Third126Proof2

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third126Proof1 : runCachedNode 511 126757 Adaptive137Third126Node1 = false := by
  decide +kernel

#print axioms adaptive137Third126Proof1

end NineSeparatedSubsetSums
