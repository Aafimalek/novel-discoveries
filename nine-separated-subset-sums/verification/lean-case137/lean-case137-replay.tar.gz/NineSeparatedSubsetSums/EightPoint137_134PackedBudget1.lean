import NineSeparatedSubsetSums.EightPoint137_134PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct137_134_1_budget :
    FourPointNumeric.packedBudget 20 packedOct137_134_1 474 = 89485538 := by decide +kernel

#print axioms packedOct137_134_1_budget

end NineSeparatedSubsetSums
