import NineSeparatedSubsetSums.Adaptive137Third127State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third127Proof9 : runCachedNode 511 126780 Adaptive137Third127Node9 = false := by
  decide +kernel

#print axioms adaptive137Third127Proof9

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third127Proof8 : runCachedNode 511 126780 Adaptive137Third127Node8 = false := by
  decide +kernel

#print axioms adaptive137Third127Proof8

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third127Proof7 : runCachedNode 511 126780 Adaptive137Third127Node7 = false := by
  decide +kernel

#print axioms adaptive137Third127Proof7

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third127Proof5 : runCachedNode 511 126780 Adaptive137Third127Node5 = false := by
  decide +kernel

#print axioms adaptive137Third127Proof5

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third127Proof4 : runCachedNode 511 126780 Adaptive137Third127Node4 = false := by
  decide +kernel

#print axioms adaptive137Third127Proof4

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third127Proof3 : runCachedNode 511 126780 Adaptive137Third127Node3 = false := by
  decide +kernel

#print axioms adaptive137Third127Proof3

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third127Proof1 : runCachedNode 511 126780 Adaptive137Third127Node1 = false := by
  decide +kernel

#print axioms adaptive137Third127Proof1

end NineSeparatedSubsetSums
