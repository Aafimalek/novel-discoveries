import NineSeparatedSubsetSums.EightPoint137_127PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint137_127PackedAnchor0Part0 :
    ∀ j : Fin 120, 2347565 ≤ FourPointNumeric.octPackedCharge 137 127 20 packedOct137_127_0
      (2*((j.val : Int)+0)+0) := by decide +kernel

end NineSeparatedSubsetSums
