import NineSeparatedSubsetSums.EightPointPackedGeometry
import NineSeparatedSubsetSums.EightPoint137_131PackedBudget0
import NineSeparatedSubsetSums.EightPoint137_131PackedAnchor0Part0
import NineSeparatedSubsetSums.EightPoint137_131PackedAnchor0Part1
import NineSeparatedSubsetSums.EightPoint137_131PackedAnchor0Part2
import NineSeparatedSubsetSums.EightPoint137_131PackedBudget1
import NineSeparatedSubsetSums.EightPoint137_131PackedAnchor1Part0
import NineSeparatedSubsetSums.EightPoint137_131PackedAnchor1Part1
import NineSeparatedSubsetSums.EightPoint137_131PackedAnchor1Part2

namespace NineSeparatedSubsetSums

private theorem packedOct137_131Anchor0 :
  ∀ j : Fin 495, ((j.val : Int)+137+131)%2=0 →
    2420812 ≤ FourPointNumeric.octPackedCharge 137 131 20 packedOct137_131_0 (j.val : Int) := by
  intro j hj
  let k := (j.val-0)/2
  have hk : k < 248 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+0 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint137_131PackedAnchor0Part0 z
    rwa [he,hrep] at ht
  by_cases h1 : k < 240
  · let z : Fin 120 := ⟨k-120, by omega⟩
    have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
    have ht := eightPoint137_131PackedAnchor0Part1 z
    rwa [he,hrep] at ht
  let z : Fin 8 := ⟨k-240, by omega⟩
  have he : (z.val : Int)+240 = k := by dsimp [z] <;> omega
  have ht := eightPoint137_131PackedAnchor0Part2 z
  rwa [he,hrep] at ht

private theorem packedOct137_131Anchor1 :
  ∀ j : Fin 495, ((j.val : Int)+137+131)%2=1 →
    2420837 ≤ FourPointNumeric.octPackedCharge 137 131 20 packedOct137_131_1 (j.val : Int) := by
  intro j hj
  let k := (j.val-1)/2
  have hk : k < 247 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+1 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint137_131PackedAnchor1Part0 z
    rwa [he,hrep] at ht
  by_cases h1 : k < 240
  · let z : Fin 120 := ⟨k-120, by omega⟩
    have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
    have ht := eightPoint137_131PackedAnchor1Part1 z
    rwa [he,hrep] at ht
  let z : Fin 7 := ⟨k-240, by omega⟩
  have he : (z.val : Int)+240 = k := by dsimp [z] <;> omega
  have ht := eightPoint137_131PackedAnchor1Part2 z
  rwa [he,hrep] at ht

def packedOctCertificate137_131_0 : EightPointCertificate 137 131 0 127537 :=
  eightPointCertificateOfPacked 137 131 0 127537 2420812 20 packedOct137_131_0 361 495
    (by decide +kernel) (by decide) packedOct137_131Anchor0
    (by rw [packedOct137_131_0_budget]; decide)

def packedOctCertificate137_131_1 : EightPointCertificate 137 131 1 127537 :=
  eightPointCertificateOfPacked 137 131 1 127537 2420837 20 packedOct137_131_1 360 495
    (by decide +kernel) (by decide) packedOct137_131Anchor1
    (by rw [packedOct137_131_1_budget]; decide)

theorem max148_second137_third131_eightPoint_moment_bound (tail : List ℕ) (len : tail.length=6)
    (distinct : (natSubsetSums (148::137::131::tail)).Nodup) :
    127537 ≤ ((148::137::131::tail).map (· ^ 2)).sum := by
  apply eightPointNatMomentLower 137 131 127537 tail len distinct
  intro p hp
  by_cases h : p=0
  · subst p
    exact packedOctCertificate137_131_0
  · have he : p=1 := hp.resolve_left h
    subst p
    exact packedOctCertificate137_131_1

#print axioms max148_second137_third131_eightPoint_moment_bound

end NineSeparatedSubsetSums
