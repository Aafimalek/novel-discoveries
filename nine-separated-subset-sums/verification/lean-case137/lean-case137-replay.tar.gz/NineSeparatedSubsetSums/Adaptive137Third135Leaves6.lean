import NineSeparatedSubsetSums.Adaptive137Third135State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third135Proof42 : runCachedNode 511 128257 Adaptive137Third135Node42 = false := by
  decide +kernel

#print axioms adaptive137Third135Proof42

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third135Proof73 : runCachedNode 511 128257 Adaptive137Third135Node73 = false := by
  decide +kernel

#print axioms adaptive137Third135Proof73

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third135Proof44 : runCachedNode 511 128257 Adaptive137Third135Node44 = false := by
  decide +kernel

#print axioms adaptive137Third135Proof44

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third135Proof12 : runCachedNode 511 128257 Adaptive137Third135Node12 = false := by
  decide +kernel

#print axioms adaptive137Third135Proof12

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third135Proof14 : runCachedNode 511 128257 Adaptive137Third135Node14 = false := by
  decide +kernel

#print axioms adaptive137Third135Proof14

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third135Proof67 : runCachedNode 511 128257 Adaptive137Third135Node67 = false := by
  decide +kernel

#print axioms adaptive137Third135Proof67

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third135Proof2 : runCachedNode 511 128257 Adaptive137Third135Node2 = false := by
  decide +kernel

#print axioms adaptive137Third135Proof2

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third135Proof50 : runCachedNode 511 128257 Adaptive137Third135Node50 = false := by
  decide +kernel

#print axioms adaptive137Third135Proof50

end NineSeparatedSubsetSums
