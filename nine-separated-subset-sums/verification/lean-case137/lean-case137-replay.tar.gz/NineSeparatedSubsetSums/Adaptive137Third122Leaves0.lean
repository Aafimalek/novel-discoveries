import NineSeparatedSubsetSums.Adaptive137Third122State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third122Proof0 : runCachedNode 511 125414 Adaptive137Third122Node0 = false := by
  decide +kernel

#print axioms adaptive137Third122Proof0

end NineSeparatedSubsetSums
