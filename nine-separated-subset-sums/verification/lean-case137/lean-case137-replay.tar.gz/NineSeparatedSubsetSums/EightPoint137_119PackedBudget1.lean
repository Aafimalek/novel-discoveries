import NineSeparatedSubsetSums.EightPoint137_119PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct137_119_1_budget :
    FourPointNumeric.packedBudget 20 packedOct137_119_1 490 = 83269474 := by decide +kernel

#print axioms packedOct137_119_1_budget

end NineSeparatedSubsetSums
