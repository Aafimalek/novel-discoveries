import NineSeparatedSubsetSums.EightPoint137_126PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint137_126PackedAnchor1Part2 :
    ∀ j : Fin 4, 2346905 ≤ FourPointNumeric.octPackedCharge 137 126 20 packedOct137_126_1
      (2*((j.val : Int)+240)+0) := by decide +kernel

end NineSeparatedSubsetSums
