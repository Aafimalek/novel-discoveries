import NineSeparatedSubsetSums.Adaptive137Third132State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third132Proof18 : runCachedNode 511 127744 Adaptive137Third132Node18 = false := by
  decide +kernel

#print axioms adaptive137Third132Proof18

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third132Proof16 : runCachedNode 511 127744 Adaptive137Third132Node16 = false := by
  decide +kernel

#print axioms adaptive137Third132Proof16

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third132Proof9 : runCachedNode 511 127744 Adaptive137Third132Node9 = false := by
  decide +kernel

#print axioms adaptive137Third132Proof9

end NineSeparatedSubsetSums
