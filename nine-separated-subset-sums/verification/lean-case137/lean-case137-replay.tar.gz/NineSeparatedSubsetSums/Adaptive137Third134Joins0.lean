import NineSeparatedSubsetSums.Adaptive137Third134State
import NineSeparatedSubsetSums.Adaptive137Third134Leaves4
import NineSeparatedSubsetSums.Adaptive137Third134Leaves7
import NineSeparatedSubsetSums.Adaptive137Third134Leaves6
import NineSeparatedSubsetSums.Adaptive137Third134Leaves5
import NineSeparatedSubsetSums.Adaptive137Third134Leaves3
import NineSeparatedSubsetSums.Adaptive137Third134Leaves0
import NineSeparatedSubsetSums.Adaptive137Third134Leaves2
import NineSeparatedSubsetSums.Adaptive137Third134Leaves1

namespace NineSeparatedSubsetSums

theorem adaptive137Third134Proof20 : runCachedNode 511 128023 Adaptive137Third134Node20 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 128023 Adaptive137Third134Node20 = [105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 118, 119, 121, 122, 124, 125, 126, 127, 129, 130] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive137Third134Proof21
  · exact adaptive137Third134Proof22
  · exact adaptive137Third134Proof23
  · exact adaptive137Third134Proof24
  · exact adaptive137Third134Proof25
  · exact adaptive137Third134Proof26
  · exact adaptive137Third134Proof27
  · exact adaptive137Third134Proof28
  · exact adaptive137Third134Proof29
  · exact adaptive137Third134Proof30
  · exact adaptive137Third134Proof31
  · exact adaptive137Third134Proof32
  · exact adaptive137Third134Proof33
  · exact adaptive137Third134Proof34
  · exact adaptive137Third134Proof35
  · exact adaptive137Third134Proof36
  · exact adaptive137Third134Proof37
  · exact adaptive137Third134Proof38
  · exact adaptive137Third134Proof39
  · exact adaptive137Third134Proof40
  · exact adaptive137Third134Proof41
  · exact adaptive137Third134Proof42

#print axioms adaptive137Third134Proof20

theorem adaptive137Third134Proof43 : runCachedNode 511 128023 Adaptive137Third134Node43 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 128023 Adaptive137Third134Node43 = [104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 119, 120, 122, 124, 125, 126, 127, 128, 130, 131] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive137Third134Proof44
  · exact adaptive137Third134Proof45
  · exact adaptive137Third134Proof46
  · exact adaptive137Third134Proof47
  · exact adaptive137Third134Proof48
  · exact adaptive137Third134Proof49
  · exact adaptive137Third134Proof50
  · exact adaptive137Third134Proof51
  · exact adaptive137Third134Proof52
  · exact adaptive137Third134Proof53
  · exact adaptive137Third134Proof54
  · exact adaptive137Third134Proof55
  · exact adaptive137Third134Proof56
  · exact adaptive137Third134Proof57
  · exact adaptive137Third134Proof58
  · exact adaptive137Third134Proof59
  · exact adaptive137Third134Proof60
  · exact adaptive137Third134Proof61
  · exact adaptive137Third134Proof62
  · exact adaptive137Third134Proof63
  · exact adaptive137Third134Proof64
  · exact adaptive137Third134Proof65
  · exact adaptive137Third134Proof66
  · exact adaptive137Third134Proof67

#print axioms adaptive137Third134Proof43

theorem adaptive137Third134Proof68 : runCachedNode 511 128023 Adaptive137Third134Node68 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 128023 Adaptive137Third134Node68 = [104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 120, 121, 124, 125, 126, 127, 128, 129, 131, 132] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive137Third134Proof69
  · exact adaptive137Third134Proof70
  · exact adaptive137Third134Proof71
  · exact adaptive137Third134Proof72
  · exact adaptive137Third134Proof73
  · exact adaptive137Third134Proof74
  · exact adaptive137Third134Proof75
  · exact adaptive137Third134Proof76
  · exact adaptive137Third134Proof77
  · exact adaptive137Third134Proof78
  · exact adaptive137Third134Proof79
  · exact adaptive137Third134Proof80
  · exact adaptive137Third134Proof81
  · exact adaptive137Third134Proof82
  · exact adaptive137Third134Proof83
  · exact adaptive137Third134Proof84
  · exact adaptive137Third134Proof85
  · exact adaptive137Third134Proof86
  · exact adaptive137Third134Proof87
  · exact adaptive137Third134Proof88
  · exact adaptive137Third134Proof89
  · exact adaptive137Third134Proof90
  · exact adaptive137Third134Proof91
  · exact adaptive137Third134Proof92
  · exact adaptive137Third134Proof93

#print axioms adaptive137Third134Proof68

theorem adaptive137Third134Proof0 : runCachedNode 511 128023 Adaptive137Third134Node0 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 128023 Adaptive137Third134Node0 = [111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 124, 125, 126, 127, 128, 129, 130, 131, 132, 133] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive137Third134Proof1
  · exact adaptive137Third134Proof2
  · exact adaptive137Third134Proof3
  · exact adaptive137Third134Proof4
  · exact adaptive137Third134Proof5
  · exact adaptive137Third134Proof6
  · exact adaptive137Third134Proof7
  · exact adaptive137Third134Proof8
  · exact adaptive137Third134Proof9
  · exact adaptive137Third134Proof10
  · exact adaptive137Third134Proof11
  · exact adaptive137Third134Proof12
  · exact adaptive137Third134Proof13
  · exact adaptive137Third134Proof14
  · exact adaptive137Third134Proof15
  · exact adaptive137Third134Proof16
  · exact adaptive137Third134Proof17
  · exact adaptive137Third134Proof18
  · exact adaptive137Third134Proof19
  · exact adaptive137Third134Proof20
  · exact adaptive137Third134Proof43
  · exact adaptive137Third134Proof68

#print axioms adaptive137Third134Proof0

end NineSeparatedSubsetSums
