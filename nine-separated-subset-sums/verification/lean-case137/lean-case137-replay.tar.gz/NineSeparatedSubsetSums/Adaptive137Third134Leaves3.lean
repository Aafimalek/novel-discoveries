import NineSeparatedSubsetSums.Adaptive137Third134State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third134Proof42 : runCachedNode 511 128023 Adaptive137Third134Node42 = false := by
  decide +kernel

#print axioms adaptive137Third134Proof42

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third134Proof39 : runCachedNode 511 128023 Adaptive137Third134Node39 = false := by
  decide +kernel

#print axioms adaptive137Third134Proof39

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third134Proof66 : runCachedNode 511 128023 Adaptive137Third134Node66 = false := by
  decide +kernel

#print axioms adaptive137Third134Proof66

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third134Proof14 : runCachedNode 511 128023 Adaptive137Third134Node14 = false := by
  decide +kernel

#print axioms adaptive137Third134Proof14

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third134Proof41 : runCachedNode 511 128023 Adaptive137Third134Node41 = false := by
  decide +kernel

#print axioms adaptive137Third134Proof41

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third134Proof85 : runCachedNode 511 128023 Adaptive137Third134Node85 = false := by
  decide +kernel

#print axioms adaptive137Third134Proof85

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third134Proof45 : runCachedNode 511 128023 Adaptive137Third134Node45 = false := by
  decide +kernel

#print axioms adaptive137Third134Proof45

end NineSeparatedSubsetSums
