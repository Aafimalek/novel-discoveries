import NineSeparatedSubsetSums.EightPoint137_133PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint137_133PackedAnchor0Part0 :
    ∀ j : Fin 120, 2410102 ≤ FourPointNumeric.octPackedCharge 137 133 20 packedOct137_133_0
      (2*((j.val : Int)+0)+0) := by decide +kernel

end NineSeparatedSubsetSums
