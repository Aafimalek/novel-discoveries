import NineSeparatedSubsetSums.EightPoint137_130PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint137_130PackedAnchor1Part1 :
    ∀ j : Fin 120, 2400832 ≤ FourPointNumeric.octPackedCharge 137 130 20 packedOct137_130_1
      (2*((j.val : Int)+120)+0) := by decide +kernel

end NineSeparatedSubsetSums
