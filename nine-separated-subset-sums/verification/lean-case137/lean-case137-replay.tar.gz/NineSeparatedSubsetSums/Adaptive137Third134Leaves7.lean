import NineSeparatedSubsetSums.Adaptive137Third134State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third134Proof22 : runCachedNode 511 128023 Adaptive137Third134Node22 = false := by
  decide +kernel

#print axioms adaptive137Third134Proof22

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third134Proof47 : runCachedNode 511 128023 Adaptive137Third134Node47 = false := by
  decide +kernel

#print axioms adaptive137Third134Proof47

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third134Proof72 : runCachedNode 511 128023 Adaptive137Third134Node72 = false := by
  decide +kernel

#print axioms adaptive137Third134Proof72

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third134Proof46 : runCachedNode 511 128023 Adaptive137Third134Node46 = false := by
  decide +kernel

#print axioms adaptive137Third134Proof46

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third134Proof70 : runCachedNode 511 128023 Adaptive137Third134Node70 = false := by
  decide +kernel

#print axioms adaptive137Third134Proof70

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third134Proof71 : runCachedNode 511 128023 Adaptive137Third134Node71 = false := by
  decide +kernel

#print axioms adaptive137Third134Proof71

end NineSeparatedSubsetSums
