import NineSeparatedSubsetSums.EightPointPackedGeometry
import NineSeparatedSubsetSums.EightPoint137_135PackedBudget0
import NineSeparatedSubsetSums.EightPoint137_135PackedAnchor0Part0
import NineSeparatedSubsetSums.EightPoint137_135PackedAnchor0Part1
import NineSeparatedSubsetSums.EightPoint137_135PackedAnchor0Part2
import NineSeparatedSubsetSums.EightPoint137_135PackedBudget1
import NineSeparatedSubsetSums.EightPoint137_135PackedAnchor1Part0
import NineSeparatedSubsetSums.EightPoint137_135PackedAnchor1Part1
import NineSeparatedSubsetSums.EightPoint137_135PackedAnchor1Part2

namespace NineSeparatedSubsetSums

private theorem packedOct137_135Anchor0 :
  ∀ j : Fin 497, ((j.val : Int)+137+135)%2=0 →
    2445232 ≤ FourPointNumeric.octPackedCharge 137 135 20 packedOct137_135_0 (j.val : Int) := by
  intro j hj
  let k := (j.val-0)/2
  have hk : k < 249 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+0 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint137_135PackedAnchor0Part0 z
    rwa [he,hrep] at ht
  by_cases h1 : k < 240
  · let z : Fin 120 := ⟨k-120, by omega⟩
    have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
    have ht := eightPoint137_135PackedAnchor0Part1 z
    rwa [he,hrep] at ht
  let z : Fin 9 := ⟨k-240, by omega⟩
  have he : (z.val : Int)+240 = k := by dsimp [z] <;> omega
  have ht := eightPoint137_135PackedAnchor0Part2 z
  rwa [he,hrep] at ht

private theorem packedOct137_135Anchor1 :
  ∀ j : Fin 497, ((j.val : Int)+137+135)%2=1 →
    2444092 ≤ FourPointNumeric.octPackedCharge 137 135 20 packedOct137_135_1 (j.val : Int) := by
  intro j hj
  let k := (j.val-1)/2
  have hk : k < 248 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+1 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint137_135PackedAnchor1Part0 z
    rwa [he,hrep] at ht
  by_cases h1 : k < 240
  · let z : Fin 120 := ⟨k-120, by omega⟩
    have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
    have ht := eightPoint137_135PackedAnchor1Part1 z
    rwa [he,hrep] at ht
  let z : Fin 8 := ⟨k-240, by omega⟩
  have he : (z.val : Int)+240 = k := by dsimp [z] <;> omega
  have ht := eightPoint137_135PackedAnchor1Part2 z
  rwa [he,hrep] at ht

def packedOctCertificate137_135_0 : EightPointCertificate 137 135 0 128257 :=
  eightPointCertificateOfPacked 137 135 0 128257 2445232 20 packedOct137_135_0 271 497
    (by decide +kernel) (by decide) packedOct137_135Anchor0
    (by rw [packedOct137_135_0_budget]; decide)

def packedOctCertificate137_135_1 : EightPointCertificate 137 135 1 128257 :=
  eightPointCertificateOfPacked 137 135 1 128257 2444092 20 packedOct137_135_1 368 497
    (by decide +kernel) (by decide) packedOct137_135Anchor1
    (by rw [packedOct137_135_1_budget]; decide)

theorem max148_second137_third135_eightPoint_moment_bound (tail : List ℕ) (len : tail.length=6)
    (distinct : (natSubsetSums (148::137::135::tail)).Nodup) :
    128257 ≤ ((148::137::135::tail).map (· ^ 2)).sum := by
  apply eightPointNatMomentLower 137 135 128257 tail len distinct
  intro p hp
  by_cases h : p=0
  · subst p
    exact packedOctCertificate137_135_0
  · have he : p=1 := hp.resolve_left h
    subst p
    exact packedOctCertificate137_135_1

#print axioms max148_second137_third135_eightPoint_moment_bound

end NineSeparatedSubsetSums
