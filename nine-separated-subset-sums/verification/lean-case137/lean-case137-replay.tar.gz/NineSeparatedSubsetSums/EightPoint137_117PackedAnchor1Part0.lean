import NineSeparatedSubsetSums.EightPoint137_117PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint137_117PackedAnchor1Part0 :
    ∀ j : Fin 120, 2269882 ≤ FourPointNumeric.octPackedCharge 137 117 20 packedOct137_117_1
      (2*((j.val : Int)+0)+1) := by decide +kernel

end NineSeparatedSubsetSums
