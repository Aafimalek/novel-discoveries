import NineSeparatedSubsetSums.EightPoint137_134PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint137_134PackedAnchor1Part2 :
    ∀ j : Fin 8, 2422394 ≤ FourPointNumeric.octPackedCharge 137 134 20 packedOct137_134_1
      (2*((j.val : Int)+240)+0) := by decide +kernel

end NineSeparatedSubsetSums
