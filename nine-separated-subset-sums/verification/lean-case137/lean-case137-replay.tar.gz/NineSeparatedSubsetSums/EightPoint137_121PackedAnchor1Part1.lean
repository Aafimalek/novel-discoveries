import NineSeparatedSubsetSums.EightPoint137_121PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint137_121PackedAnchor1Part1 :
    ∀ j : Fin 120, 2333338 ≤ FourPointNumeric.octPackedCharge 137 121 20 packedOct137_121_1
      (2*((j.val : Int)+120)+1) := by decide +kernel

end NineSeparatedSubsetSums
