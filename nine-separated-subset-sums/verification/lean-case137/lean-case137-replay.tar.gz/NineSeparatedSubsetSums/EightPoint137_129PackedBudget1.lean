import NineSeparatedSubsetSums.EightPoint137_129PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct137_129_1_budget :
    FourPointNumeric.packedBudget 20 packedOct137_129_1 428 = 86761712 := by decide +kernel

#print axioms packedOct137_129_1_budget

end NineSeparatedSubsetSums
