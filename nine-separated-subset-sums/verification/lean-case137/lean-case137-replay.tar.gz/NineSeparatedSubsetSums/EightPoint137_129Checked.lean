import NineSeparatedSubsetSums.EightPointPackedGeometry
import NineSeparatedSubsetSums.EightPoint137_129PackedBudget0
import NineSeparatedSubsetSums.EightPoint137_129PackedAnchor0Part0
import NineSeparatedSubsetSums.EightPoint137_129PackedAnchor0Part1
import NineSeparatedSubsetSums.EightPoint137_129PackedAnchor0Part2
import NineSeparatedSubsetSums.EightPoint137_129PackedBudget1
import NineSeparatedSubsetSums.EightPoint137_129PackedAnchor1Part0
import NineSeparatedSubsetSums.EightPoint137_129PackedAnchor1Part1
import NineSeparatedSubsetSums.EightPoint137_129PackedAnchor1Part2

namespace NineSeparatedSubsetSums

private theorem packedOct137_129Anchor0 :
  ∀ j : Fin 490, ((j.val : Int)+137+129)%2=0 →
    2373044 ≤ FourPointNumeric.octPackedCharge 137 129 20 packedOct137_129_0 (j.val : Int) := by
  intro j hj
  let k := (j.val-0)/2
  have hk : k < 245 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+0 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint137_129PackedAnchor0Part0 z
    rwa [he,hrep] at ht
  by_cases h1 : k < 240
  · let z : Fin 120 := ⟨k-120, by omega⟩
    have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
    have ht := eightPoint137_129PackedAnchor0Part1 z
    rwa [he,hrep] at ht
  let z : Fin 5 := ⟨k-240, by omega⟩
  have he : (z.val : Int)+240 = k := by dsimp [z] <;> omega
  have ht := eightPoint137_129PackedAnchor0Part2 z
  rwa [he,hrep] at ht

private theorem packedOct137_129Anchor1 :
  ∀ j : Fin 490, ((j.val : Int)+137+129)%2=1 →
    2372737 ≤ FourPointNumeric.octPackedCharge 137 129 20 packedOct137_129_1 (j.val : Int) := by
  intro j hj
  let k := (j.val-1)/2
  have hk : k < 245 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+1 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint137_129PackedAnchor1Part0 z
    rwa [he,hrep] at ht
  by_cases h1 : k < 240
  · let z : Fin 120 := ⟨k-120, by omega⟩
    have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
    have ht := eightPoint137_129PackedAnchor1Part1 z
    rwa [he,hrep] at ht
  let z : Fin 5 := ⟨k-240, by omega⟩
  have he : (z.val : Int)+240 = k := by dsimp [z] <;> omega
  have ht := eightPoint137_129PackedAnchor1Part2 z
  rwa [he,hrep] at ht

def packedOctCertificate137_129_0 : EightPointCertificate 137 129 0 127136 :=
  eightPointCertificateOfPacked 137 129 0 127136 2373044 20 packedOct137_129_0 429 490
    (by decide +kernel) (by decide) packedOct137_129Anchor0
    (by rw [packedOct137_129_0_budget]; decide)

def packedOctCertificate137_129_1 : EightPointCertificate 137 129 1 127136 :=
  eightPointCertificateOfPacked 137 129 1 127136 2372737 20 packedOct137_129_1 428 490
    (by decide +kernel) (by decide) packedOct137_129Anchor1
    (by rw [packedOct137_129_1_budget]; decide)

theorem max148_second137_third129_eightPoint_moment_bound (tail : List ℕ) (len : tail.length=6)
    (distinct : (natSubsetSums (148::137::129::tail)).Nodup) :
    127136 ≤ ((148::137::129::tail).map (· ^ 2)).sum := by
  apply eightPointNatMomentLower 137 129 127136 tail len distinct
  intro p hp
  by_cases h : p=0
  · subst p
    exact packedOctCertificate137_129_0
  · have he : p=1 := hp.resolve_left h
    subst p
    exact packedOctCertificate137_129_1

#print axioms max148_second137_third129_eightPoint_moment_bound

end NineSeparatedSubsetSums
