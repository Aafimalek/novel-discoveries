import NineSeparatedSubsetSums.EightPoint137_122PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint137_122PackedAnchor0Part0 :
    ∀ j : Fin 120, 2275852 ≤ FourPointNumeric.octPackedCharge 137 122 20 packedOct137_122_0
      (2*((j.val : Int)+0)+1) := by decide +kernel

end NineSeparatedSubsetSums
