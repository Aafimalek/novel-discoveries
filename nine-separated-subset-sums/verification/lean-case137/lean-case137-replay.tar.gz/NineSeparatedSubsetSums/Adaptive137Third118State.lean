import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive137Third118Node0 : CachedSearchNode :=
  ⟨4, 117, computeCenteredMask [148,137,118], 403, 54597⟩

end NineSeparatedSubsetSums
