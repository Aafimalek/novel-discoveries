import NineSeparatedSubsetSums.Adaptive137Third135State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third135Proof30 : runCachedNode 511 128257 Adaptive137Third135Node30 = false := by
  decide +kernel

#print axioms adaptive137Third135Proof30

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third135Proof61 : runCachedNode 511 128257 Adaptive137Third135Node61 = false := by
  decide +kernel

#print axioms adaptive137Third135Proof61

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third135Proof29 : runCachedNode 511 128257 Adaptive137Third135Node29 = false := by
  decide +kernel

#print axioms adaptive137Third135Proof29

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third135Proof28 : runCachedNode 511 128257 Adaptive137Third135Node28 = false := by
  decide +kernel

#print axioms adaptive137Third135Proof28

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third135Proof59 : runCachedNode 511 128257 Adaptive137Third135Node59 = false := by
  decide +kernel

#print axioms adaptive137Third135Proof59

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third135Proof60 : runCachedNode 511 128257 Adaptive137Third135Node60 = false := by
  decide +kernel

#print axioms adaptive137Third135Proof60

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third135Proof27 : runCachedNode 511 128257 Adaptive137Third135Node27 = false := by
  decide +kernel

#print axioms adaptive137Third135Proof27

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third135Proof58 : runCachedNode 511 128257 Adaptive137Third135Node58 = false := by
  decide +kernel

#print axioms adaptive137Third135Proof58

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third135Proof55 : runCachedNode 511 128257 Adaptive137Third135Node55 = false := by
  decide +kernel

#print axioms adaptive137Third135Proof55

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third135Proof56 : runCachedNode 511 128257 Adaptive137Third135Node56 = false := by
  decide +kernel

#print axioms adaptive137Third135Proof56

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third135Proof57 : runCachedNode 511 128257 Adaptive137Third135Node57 = false := by
  decide +kernel

#print axioms adaptive137Third135Proof57

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third135Proof54 : runCachedNode 511 128257 Adaptive137Third135Node54 = false := by
  decide +kernel

#print axioms adaptive137Third135Proof54

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third135Proof26 : runCachedNode 511 128257 Adaptive137Third135Node26 = false := by
  decide +kernel

#print axioms adaptive137Third135Proof26

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third135Proof53 : runCachedNode 511 128257 Adaptive137Third135Node53 = false := by
  decide +kernel

#print axioms adaptive137Third135Proof53

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third135Proof25 : runCachedNode 511 128257 Adaptive137Third135Node25 = false := by
  decide +kernel

#print axioms adaptive137Third135Proof25

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third135Proof52 : runCachedNode 511 128257 Adaptive137Third135Node52 = false := by
  decide +kernel

#print axioms adaptive137Third135Proof52

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third135Proof51 : runCachedNode 511 128257 Adaptive137Third135Node51 = false := by
  decide +kernel

#print axioms adaptive137Third135Proof51

end NineSeparatedSubsetSums
