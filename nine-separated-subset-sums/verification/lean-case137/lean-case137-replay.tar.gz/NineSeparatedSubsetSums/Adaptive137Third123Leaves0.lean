import NineSeparatedSubsetSums.Adaptive137Third123State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third123Proof0 : runCachedNode 511 125617 Adaptive137Third123Node0 = false := by
  decide +kernel

#print axioms adaptive137Third123Proof0

end NineSeparatedSubsetSums
