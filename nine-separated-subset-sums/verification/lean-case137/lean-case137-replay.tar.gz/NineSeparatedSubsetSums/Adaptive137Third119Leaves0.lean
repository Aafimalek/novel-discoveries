import NineSeparatedSubsetSums.Adaptive137Third119State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third119Proof0 : runCachedNode 511 124926 Adaptive137Third119Node0 = false := by
  decide +kernel

#print axioms adaptive137Third119Proof0

end NineSeparatedSubsetSums
