import NineSeparatedSubsetSums.Adaptive137Third132State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third132Proof19 : runCachedNode 511 127744 Adaptive137Third132Node19 = false := by
  decide +kernel

#print axioms adaptive137Third132Proof19

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third132Proof15 : runCachedNode 511 127744 Adaptive137Third132Node15 = false := by
  decide +kernel

#print axioms adaptive137Third132Proof15

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third132Proof1 : runCachedNode 511 127744 Adaptive137Third132Node1 = false := by
  decide +kernel

#print axioms adaptive137Third132Proof1

end NineSeparatedSubsetSums
