import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive137Third126Node0 : CachedSearchNode :=
  ⟨4, 125, computeCenteredMask [148,137,126], 411, 56549⟩
def Adaptive137Third126Node1 : CachedSearchNode := cachedChild Adaptive137Third126Node0 111
def Adaptive137Third126Node2 : CachedSearchNode := cachedChild Adaptive137Third126Node0 112
def Adaptive137Third126Node3 : CachedSearchNode := cachedChild Adaptive137Third126Node0 113
def Adaptive137Third126Node4 : CachedSearchNode := cachedChild Adaptive137Third126Node0 114
def Adaptive137Third126Node5 : CachedSearchNode := cachedChild Adaptive137Third126Node0 116
def Adaptive137Third126Node6 : CachedSearchNode := cachedChild Adaptive137Third126Node0 117
def Adaptive137Third126Node7 : CachedSearchNode := cachedChild Adaptive137Third126Node0 118
def Adaptive137Third126Node8 : CachedSearchNode := cachedChild Adaptive137Third126Node0 119
def Adaptive137Third126Node9 : CachedSearchNode := cachedChild Adaptive137Third126Node0 120
def Adaptive137Third126Node10 : CachedSearchNode := cachedChild Adaptive137Third126Node0 121
def Adaptive137Third126Node11 : CachedSearchNode := cachedChild Adaptive137Third126Node0 122
def Adaptive137Third126Node12 : CachedSearchNode := cachedChild Adaptive137Third126Node0 123
def Adaptive137Third126Node13 : CachedSearchNode := cachedChild Adaptive137Third126Node0 124
def Adaptive137Third126Node14 : CachedSearchNode := cachedChild Adaptive137Third126Node0 125

end NineSeparatedSubsetSums
