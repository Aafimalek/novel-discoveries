import NineSeparatedSubsetSums.EightPoint137_131PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct137_131_1_budget :
    FourPointNumeric.packedBudget 20 packedOct137_131_1 360 = 89634622 := by decide +kernel

#print axioms packedOct137_131_1_budget

end NineSeparatedSubsetSums
