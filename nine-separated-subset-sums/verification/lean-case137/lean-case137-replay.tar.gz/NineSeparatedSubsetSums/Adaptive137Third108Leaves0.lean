import NineSeparatedSubsetSums.Adaptive137Third108State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third108Proof0 : runCachedNode 511 111041 Adaptive137Third108Node0 = false := by
  decide +kernel

#print axioms adaptive137Third108Proof0

end NineSeparatedSubsetSums
