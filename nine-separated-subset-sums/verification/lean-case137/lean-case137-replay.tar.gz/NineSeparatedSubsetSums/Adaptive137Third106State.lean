import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive137Third106Node0 : CachedSearchNode :=
  ⟨4, 105, computeCenteredMask [148,137,106], 391, 51909⟩

end NineSeparatedSubsetSums
