import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive137Third129Node0 : CachedSearchNode :=
  ⟨4, 128, computeCenteredMask [148,137,129], 414, 57314⟩
def Adaptive137Third129Node1 : CachedSearchNode := cachedChild Adaptive137Third129Node0 111
def Adaptive137Third129Node2 : CachedSearchNode := cachedChild Adaptive137Third129Node0 112
def Adaptive137Third129Node3 : CachedSearchNode := cachedChild Adaptive137Third129Node0 113
def Adaptive137Third129Node4 : CachedSearchNode := cachedChild Adaptive137Third129Node0 114
def Adaptive137Third129Node5 : CachedSearchNode := cachedChild Adaptive137Third129Node0 115
def Adaptive137Third129Node6 : CachedSearchNode := cachedChild Adaptive137Third129Node0 116
def Adaptive137Third129Node7 : CachedSearchNode := cachedChild Adaptive137Third129Node0 117
def Adaptive137Third129Node8 : CachedSearchNode := cachedChild Adaptive137Third129Node0 119
def Adaptive137Third129Node9 : CachedSearchNode := cachedChild Adaptive137Third129Node0 120
def Adaptive137Third129Node10 : CachedSearchNode := cachedChild Adaptive137Third129Node0 121
def Adaptive137Third129Node11 : CachedSearchNode := cachedChild Adaptive137Third129Node0 122
def Adaptive137Third129Node12 : CachedSearchNode := cachedChild Adaptive137Third129Node0 123
def Adaptive137Third129Node13 : CachedSearchNode := cachedChild Adaptive137Third129Node0 124
def Adaptive137Third129Node14 : CachedSearchNode := cachedChild Adaptive137Third129Node0 125
def Adaptive137Third129Node15 : CachedSearchNode := cachedChild Adaptive137Third129Node0 126
def Adaptive137Third129Node16 : CachedSearchNode := cachedChild Adaptive137Third129Node0 127
def Adaptive137Third129Node17 : CachedSearchNode := cachedChild Adaptive137Third129Node0 128

end NineSeparatedSubsetSums
