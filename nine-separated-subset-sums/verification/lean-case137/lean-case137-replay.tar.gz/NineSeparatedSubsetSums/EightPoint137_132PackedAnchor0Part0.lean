import NineSeparatedSubsetSums.EightPoint137_132PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint137_132PackedAnchor0Part0 :
    ∀ j : Fin 120, 2418222 ≤ FourPointNumeric.octPackedCharge 137 132 20 packedOct137_132_0
      (2*((j.val : Int)+0)+1) := by decide +kernel

end NineSeparatedSubsetSums
