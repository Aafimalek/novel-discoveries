import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive137Third117Node0 : CachedSearchNode :=
  ⟨4, 116, computeCenteredMask [148,137,117], 402, 54362⟩

end NineSeparatedSubsetSums
