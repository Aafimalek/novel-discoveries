import NineSeparatedSubsetSums.EightPoint137_129PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct137_129_0_budget :
    FourPointNumeric.packedBudget 20 packedOct137_129_0 429 = 86781435 := by decide +kernel

#print axioms packedOct137_129_0_budget

end NineSeparatedSubsetSums
