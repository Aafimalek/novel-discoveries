import NineSeparatedSubsetSums.Adaptive137Third128State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third128Proof13 : runCachedNode 511 126896 Adaptive137Third128Node13 = false := by
  decide +kernel

#print axioms adaptive137Third128Proof13

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third128Proof12 : runCachedNode 511 126896 Adaptive137Third128Node12 = false := by
  decide +kernel

#print axioms adaptive137Third128Proof12

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third128Proof10 : runCachedNode 511 126896 Adaptive137Third128Node10 = false := by
  decide +kernel

#print axioms adaptive137Third128Proof10

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third128Proof9 : runCachedNode 511 126896 Adaptive137Third128Node9 = false := by
  decide +kernel

#print axioms adaptive137Third128Proof9

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third128Proof8 : runCachedNode 511 126896 Adaptive137Third128Node8 = false := by
  decide +kernel

#print axioms adaptive137Third128Proof8

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third128Proof7 : runCachedNode 511 126896 Adaptive137Third128Node7 = false := by
  decide +kernel

#print axioms adaptive137Third128Proof7

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third128Proof6 : runCachedNode 511 126896 Adaptive137Third128Node6 = false := by
  decide +kernel

#print axioms adaptive137Third128Proof6

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third128Proof5 : runCachedNode 511 126896 Adaptive137Third128Node5 = false := by
  decide +kernel

#print axioms adaptive137Third128Proof5

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third128Proof4 : runCachedNode 511 126896 Adaptive137Third128Node4 = false := by
  decide +kernel

#print axioms adaptive137Third128Proof4

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third128Proof2 : runCachedNode 511 126896 Adaptive137Third128Node2 = false := by
  decide +kernel

#print axioms adaptive137Third128Proof2

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third128Proof1 : runCachedNode 511 126896 Adaptive137Third128Node1 = false := by
  decide +kernel

#print axioms adaptive137Third128Proof1

end NineSeparatedSubsetSums
