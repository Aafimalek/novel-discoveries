import NineSeparatedSubsetSums.Adaptive137Third135State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third135Proof19 : runCachedNode 511 128257 Adaptive137Third135Node19 = false := by
  decide +kernel

#print axioms adaptive137Third135Proof19

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third135Proof17 : runCachedNode 511 128257 Adaptive137Third135Node17 = false := by
  decide +kernel

#print axioms adaptive137Third135Proof17

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third135Proof72 : runCachedNode 511 128257 Adaptive137Third135Node72 = false := by
  decide +kernel

#print axioms adaptive137Third135Proof72

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third135Proof62 : runCachedNode 511 128257 Adaptive137Third135Node62 = false := by
  decide +kernel

#print axioms adaptive137Third135Proof62

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third135Proof49 : runCachedNode 511 128257 Adaptive137Third135Node49 = false := by
  decide +kernel

#print axioms adaptive137Third135Proof49

end NineSeparatedSubsetSums
