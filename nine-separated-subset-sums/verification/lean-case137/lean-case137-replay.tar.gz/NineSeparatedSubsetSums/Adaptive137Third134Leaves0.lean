import NineSeparatedSubsetSums.Adaptive137Third134State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third134Proof19 : runCachedNode 511 128023 Adaptive137Third134Node19 = false := by
  decide +kernel

#print axioms adaptive137Third134Proof19

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third134Proof17 : runCachedNode 511 128023 Adaptive137Third134Node17 = false := by
  decide +kernel

#print axioms adaptive137Third134Proof17

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third134Proof5 : runCachedNode 511 128023 Adaptive137Third134Node5 = false := by
  decide +kernel

#print axioms adaptive137Third134Proof5

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third134Proof44 : runCachedNode 511 128023 Adaptive137Third134Node44 = false := by
  decide +kernel

#print axioms adaptive137Third134Proof44

end NineSeparatedSubsetSums
