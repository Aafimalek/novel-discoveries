import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive137Third113Node0 : CachedSearchNode :=
  ⟨4, 112, computeCenteredMask [148,137,113], 398, 53442⟩

end NineSeparatedSubsetSums
