import NineSeparatedSubsetSums.EightPoint137_125PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint137_125PackedAnchor0Part1 :
    ∀ j : Fin 120, 2309728 ≤ FourPointNumeric.octPackedCharge 137 125 20 packedOct137_125_0
      (2*((j.val : Int)+120)+0) := by decide +kernel

end NineSeparatedSubsetSums
