import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive137Third120Node0 : CachedSearchNode :=
  ⟨4, 119, computeCenteredMask [148,137,120], 405, 55073⟩

end NineSeparatedSubsetSums
