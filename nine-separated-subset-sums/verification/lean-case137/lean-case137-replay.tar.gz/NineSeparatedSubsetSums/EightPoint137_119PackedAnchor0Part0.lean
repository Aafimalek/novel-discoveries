import NineSeparatedSubsetSums.EightPoint137_119PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint137_119PackedAnchor0Part0 :
    ∀ j : Fin 120, 2301389 ≤ FourPointNumeric.octPackedCharge 137 119 20 packedOct137_119_0
      (2*((j.val : Int)+0)+0) := by decide +kernel

end NineSeparatedSubsetSums
