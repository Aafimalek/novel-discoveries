import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive137Third112Node0 : CachedSearchNode :=
  ⟨4, 111, computeCenteredMask [148,137,112], 397, 53217⟩

end NineSeparatedSubsetSums
