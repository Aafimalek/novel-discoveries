import NineSeparatedSubsetSums.Adaptive137Third136State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third136Proof75 : runCachedNode 511 128437 Adaptive137Third136Node75 = false := by
  decide +kernel

#print axioms adaptive137Third136Proof75

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third136Proof100 : runCachedNode 511 128437 Adaptive137Third136Node100 = false := by
  decide +kernel

#print axioms adaptive137Third136Proof100

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third136Proof96 : runCachedNode 511 128437 Adaptive137Third136Node96 = false := by
  decide +kernel

#print axioms adaptive137Third136Proof96

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive137Third136Proof5 : runCachedNode 511 128437 Adaptive137Third136Node5 = false := by
  decide +kernel

#print axioms adaptive137Third136Proof5

end NineSeparatedSubsetSums
