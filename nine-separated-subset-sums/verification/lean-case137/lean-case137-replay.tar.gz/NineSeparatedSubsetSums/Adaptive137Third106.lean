import NineSeparatedSubsetSums.Adaptive137Third106Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint137Checked

namespace NineSeparatedSubsetSums


theorem adaptive137Third106 : NoDescendingTailAfterThird 137 106 :=
  noDescendingThirdTail_of_cached 137 106 111041 (fun t ht nd => max148_second137_fourPoint_moment_bound (106::t) (by simp [ht]) nd) adaptive137Third106Proof0

#print axioms adaptive137Third106

end NineSeparatedSubsetSums
