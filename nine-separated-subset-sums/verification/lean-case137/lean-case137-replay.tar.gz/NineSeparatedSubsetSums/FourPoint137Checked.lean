import NineSeparatedSubsetSums.FourPointPackedGeometry
import NineSeparatedSubsetSums.FourPoint137PackedBudget0
import NineSeparatedSubsetSums.FourPoint137PackedAnchor0Part0
import NineSeparatedSubsetSums.FourPoint137PackedAnchor0Part1
import NineSeparatedSubsetSums.FourPoint137PackedAnchor0Part2
import NineSeparatedSubsetSums.FourPoint137PackedBudget1
import NineSeparatedSubsetSums.FourPoint137PackedAnchor1Part0
import NineSeparatedSubsetSums.FourPoint137PackedAnchor1Part1
import NineSeparatedSubsetSums.FourPoint137PackedAnchor1Part2

namespace NineSeparatedSubsetSums

private theorem packed137Anchor0 :
  ∀ j : Fin 486, ((j.val : Int)+137)%2=0 →
    1105784 ≤ FourPointNumeric.packedCharge 137 20 packedWeight137_0 (j.val : Int) := by
  intro j hj
  let k := (j.val-1)/2
  have hk : k < 243 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+1 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := fourPoint137PackedAnchor0Part0 z
    rwa [he,hrep] at ht
  by_cases h1 : k < 240
  · let z : Fin 120 := ⟨k-120, by omega⟩
    have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
    have ht := fourPoint137PackedAnchor0Part1 z
    rwa [he,hrep] at ht
  let z : Fin 3 := ⟨k-240, by omega⟩
  have he : (z.val : Int)+240 = k := by dsimp [z] <;> omega
  have ht := fourPoint137PackedAnchor0Part2 z
  rwa [he,hrep] at ht

private theorem packed137Anchor1 :
  ∀ j : Fin 486, ((j.val : Int)+137)%2=1 →
    1105780 ≤ FourPointNumeric.packedCharge 137 20 packedWeight137_1 (j.val : Int) := by
  intro j hj
  let k := (j.val-0)/2
  have hk : k < 243 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+0 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := fourPoint137PackedAnchor1Part0 z
    rwa [he,hrep] at ht
  by_cases h1 : k < 240
  · let z : Fin 120 := ⟨k-120, by omega⟩
    have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
    have ht := fourPoint137PackedAnchor1Part1 z
    rwa [he,hrep] at ht
  let z : Fin 3 := ⟨k-240, by omega⟩
  have he : (z.val : Int)+240 = k := by dsimp [z] <;> omega
  have ht := fourPoint137PackedAnchor1Part2 z
  rwa [he,hrep] at ht

def packedCertificate137_0 : FourPointCertificate 137 0 111041 :=
  fourPointCertificateOfPacked 137 0 111041 1105784 20 packedWeight137_0 365 486
    (by decide +kernel) (by decide) (by decide) packed137Anchor0
    (by rw [packedWeight137_0_budget]; decide)

def packedCertificate137_1 : FourPointCertificate 137 1 111041 :=
  fourPointCertificateOfPacked 137 1 111041 1105780 20 packedWeight137_1 368 486
    (by decide +kernel) (by decide) (by decide) packed137Anchor1
    (by rw [packedWeight137_1_budget]; decide)

theorem max148_second137_fourPoint_moment_bound (tail : List ℕ) (len : tail.length=7)
    (distinct : (natSubsetSums (148::137::tail)).Nodup) :
    111041 ≤ ((148::137::tail).map (· ^ 2)).sum := by
  apply fourPointNatMomentLower 137 111041 tail len distinct
  intro p hp
  by_cases h : p=0
  · subst p
    exact packedCertificate137_0
  · have he : p=1 := hp.resolve_left h
    subst p
    exact packedCertificate137_1

#print axioms max148_second137_fourPoint_moment_bound

end NineSeparatedSubsetSums
