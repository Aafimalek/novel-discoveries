import NineSeparatedSubsetSums.EightPoint137_127PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct137_127_1_budget :
    FourPointNumeric.packedBudget 20 packedOct137_127_1 454 = 85407034 := by decide +kernel

#print axioms packedOct137_127_1_budget

end NineSeparatedSubsetSums
