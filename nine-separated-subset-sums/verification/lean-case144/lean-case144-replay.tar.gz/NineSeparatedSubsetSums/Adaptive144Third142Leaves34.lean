import NineSeparatedSubsetSums.Adaptive144Third142State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third142Proof332 : runCachedNode 511 130737 Adaptive144Third142Node332 = false := by
  decide +kernel

#print axioms adaptive144Third142Proof332

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third142Proof76 : runCachedNode 511 130737 Adaptive144Third142Node76 = false := by
  decide +kernel

#print axioms adaptive144Third142Proof76

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third142Proof402 : runCachedNode 511 130737 Adaptive144Third142Node402 = false := by
  decide +kernel

#print axioms adaptive144Third142Proof402

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third142Proof292 : runCachedNode 511 130737 Adaptive144Third142Node292 = false := by
  decide +kernel

#print axioms adaptive144Third142Proof292

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third142Proof13 : runCachedNode 511 130737 Adaptive144Third142Node13 = false := by
  decide +kernel

#print axioms adaptive144Third142Proof13

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third142Proof257 : runCachedNode 511 130737 Adaptive144Third142Node257 = false := by
  decide +kernel

#print axioms adaptive144Third142Proof257

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third142Proof331 : runCachedNode 511 130737 Adaptive144Third142Node331 = false := by
  decide +kernel

#print axioms adaptive144Third142Proof331

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third142Proof105 : runCachedNode 511 130737 Adaptive144Third142Node105 = false := by
  decide +kernel

#print axioms adaptive144Third142Proof105

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third142Proof7 : runCachedNode 511 130737 Adaptive144Third142Node7 = false := by
  decide +kernel

#print axioms adaptive144Third142Proof7

end NineSeparatedSubsetSums
