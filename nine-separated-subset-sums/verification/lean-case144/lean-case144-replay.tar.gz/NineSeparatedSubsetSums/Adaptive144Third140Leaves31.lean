import NineSeparatedSubsetSums.Adaptive144Third140State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof198 : runCachedNode 511 130381 Adaptive144Third140Node198 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof198

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof531 : runCachedNode 511 130381 Adaptive144Third140Node531 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof531

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof603 : runCachedNode 511 130381 Adaptive144Third140Node603 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof603

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof11 : runCachedNode 511 130381 Adaptive144Third140Node11 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof11

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof77 : runCachedNode 511 130381 Adaptive144Third140Node77 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof77

end NineSeparatedSubsetSums
