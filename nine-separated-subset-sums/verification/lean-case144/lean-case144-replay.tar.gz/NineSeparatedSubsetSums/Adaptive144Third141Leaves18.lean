import NineSeparatedSubsetSums.Adaptive144Third141State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third141Proof199 : runCachedNode 511 130584 Adaptive144Third141Node199 = false := by
  decide +kernel

#print axioms adaptive144Third141Proof199

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third141Proof279 : runCachedNode 511 130584 Adaptive144Third141Node279 = false := by
  decide +kernel

#print axioms adaptive144Third141Proof279

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third141Proof17 : runCachedNode 511 130584 Adaptive144Third141Node17 = false := by
  decide +kernel

#print axioms adaptive144Third141Proof17

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third141Proof68 : runCachedNode 511 130584 Adaptive144Third141Node68 = false := by
  decide +kernel

#print axioms adaptive144Third141Proof68

end NineSeparatedSubsetSums
