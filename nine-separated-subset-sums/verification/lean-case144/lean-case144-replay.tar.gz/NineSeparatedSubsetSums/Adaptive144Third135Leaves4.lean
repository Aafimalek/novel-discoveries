import NineSeparatedSubsetSums.Adaptive144Third135State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third135Proof17 : runCachedNode 511 129692 Adaptive144Third135Node17 = false := by
  decide +kernel

#print axioms adaptive144Third135Proof17

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third135Proof71 : runCachedNode 511 129692 Adaptive144Third135Node71 = false := by
  decide +kernel

#print axioms adaptive144Third135Proof71

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third135Proof13 : runCachedNode 511 129692 Adaptive144Third135Node13 = false := by
  decide +kernel

#print axioms adaptive144Third135Proof13

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third135Proof97 : runCachedNode 511 129692 Adaptive144Third135Node97 = false := by
  decide +kernel

#print axioms adaptive144Third135Proof97

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third135Proof81 : runCachedNode 511 129692 Adaptive144Third135Node81 = false := by
  decide +kernel

#print axioms adaptive144Third135Proof81

end NineSeparatedSubsetSums
