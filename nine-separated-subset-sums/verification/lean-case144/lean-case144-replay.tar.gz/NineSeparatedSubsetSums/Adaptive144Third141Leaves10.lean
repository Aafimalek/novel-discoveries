import NineSeparatedSubsetSums.Adaptive144Third141State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third141Proof309 : runCachedNode 511 130584 Adaptive144Third141Node309 = false := by
  decide +kernel

#print axioms adaptive144Third141Proof309

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third141Proof78 : runCachedNode 511 130584 Adaptive144Third141Node78 = false := by
  decide +kernel

#print axioms adaptive144Third141Proof78

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third141Proof273 : runCachedNode 511 130584 Adaptive144Third141Node273 = false := by
  decide +kernel

#print axioms adaptive144Third141Proof273

end NineSeparatedSubsetSums
