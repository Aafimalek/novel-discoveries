import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive144Third109Node0 : CachedSearchNode :=
  ⟨4, 108, computeCenteredMask [148,144,109], 401, 54521⟩

end NineSeparatedSubsetSums
