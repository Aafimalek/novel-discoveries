import NineSeparatedSubsetSums.EightPoint144_118PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct144_118_0_budget :
    FourPointNumeric.packedBudget 20 packedOct144_118_0 455 = 89809841 := by decide +kernel

#print axioms packedOct144_118_0_budget

end NineSeparatedSubsetSums
