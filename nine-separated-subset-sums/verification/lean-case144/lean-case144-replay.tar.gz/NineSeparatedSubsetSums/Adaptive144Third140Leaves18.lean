import NineSeparatedSubsetSums.Adaptive144Third140State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof362 : runCachedNode 511 130381 Adaptive144Third140Node362 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof362

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof15 : runCachedNode 511 130381 Adaptive144Third140Node15 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof15

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof162 : runCachedNode 511 130381 Adaptive144Third140Node162 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof162

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof395 : runCachedNode 511 130381 Adaptive144Third140Node395 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof395

end NineSeparatedSubsetSums
