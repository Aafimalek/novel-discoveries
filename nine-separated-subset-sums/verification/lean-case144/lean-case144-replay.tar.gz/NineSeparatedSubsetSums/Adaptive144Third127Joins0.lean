import NineSeparatedSubsetSums.Adaptive144Third127State
import NineSeparatedSubsetSums.Adaptive144Third127Leaves0
import NineSeparatedSubsetSums.Adaptive144Third127Leaves1

namespace NineSeparatedSubsetSums

theorem adaptive144Third127Proof0 : runCachedNode 511 128058 Adaptive144Third127Node0 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 128058 Adaptive144Third127Node0 = [110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 124, 125, 126] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive144Third127Proof1
  · exact adaptive144Third127Proof2
  · exact adaptive144Third127Proof3
  · exact adaptive144Third127Proof4
  · exact adaptive144Third127Proof5
  · exact adaptive144Third127Proof6
  · exact adaptive144Third127Proof7
  · exact adaptive144Third127Proof8
  · exact adaptive144Third127Proof9
  · exact adaptive144Third127Proof10
  · exact adaptive144Third127Proof11
  · exact adaptive144Third127Proof12
  · exact adaptive144Third127Proof13
  · exact adaptive144Third127Proof14
  · exact adaptive144Third127Proof15
  · exact adaptive144Third127Proof16

#print axioms adaptive144Third127Proof0

end NineSeparatedSubsetSums
