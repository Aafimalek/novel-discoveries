import NineSeparatedSubsetSums.Adaptive144Third138State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third138Proof20 : runCachedNode 511 130126 Adaptive144Third138Node20 = false := by
  decide +kernel

#print axioms adaptive144Third138Proof20

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third138Proof69 : runCachedNode 511 130126 Adaptive144Third138Node69 = false := by
  decide +kernel

#print axioms adaptive144Third138Proof69

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third138Proof137 : runCachedNode 511 130126 Adaptive144Third138Node137 = false := by
  decide +kernel

#print axioms adaptive144Third138Proof137

end NineSeparatedSubsetSums
