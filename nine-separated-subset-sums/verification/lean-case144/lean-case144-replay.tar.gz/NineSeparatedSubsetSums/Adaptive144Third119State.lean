import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive144Third119Node0 : CachedSearchNode :=
  ⟨4, 118, computeCenteredMask [148,144,119], 411, 56801⟩

end NineSeparatedSubsetSums
