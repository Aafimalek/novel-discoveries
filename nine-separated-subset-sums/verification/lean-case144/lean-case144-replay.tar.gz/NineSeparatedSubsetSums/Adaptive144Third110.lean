import NineSeparatedSubsetSums.Adaptive144Third110Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint144Checked

namespace NineSeparatedSubsetSums


theorem adaptive144Third110 : NoDescendingTailAfterThird 144 110 :=
  noDescendingThirdTail_of_cached 144 110 112221 (fun t ht nd => max148_second144_fourPoint_moment_bound (110::t) (by simp [ht]) nd) adaptive144Third110Proof0

#print axioms adaptive144Third110

end NineSeparatedSubsetSums
