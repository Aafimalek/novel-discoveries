import NineSeparatedSubsetSums.Adaptive144Third136State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third136Proof3 : runCachedNode 511 129800 Adaptive144Third136Node3 = false := by
  decide +kernel

#print axioms adaptive144Third136Proof3

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third136Proof33 : runCachedNode 511 129800 Adaptive144Third136Node33 = false := by
  decide +kernel

#print axioms adaptive144Third136Proof33

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third136Proof32 : runCachedNode 511 129800 Adaptive144Third136Node32 = false := by
  decide +kernel

#print axioms adaptive144Third136Proof32

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third136Proof87 : runCachedNode 511 129800 Adaptive144Third136Node87 = false := by
  decide +kernel

#print axioms adaptive144Third136Proof87

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third136Proof2 : runCachedNode 511 129800 Adaptive144Third136Node2 = false := by
  decide +kernel

#print axioms adaptive144Third136Proof2

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third136Proof31 : runCachedNode 511 129800 Adaptive144Third136Node31 = false := by
  decide +kernel

#print axioms adaptive144Third136Proof31

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third136Proof58 : runCachedNode 511 129800 Adaptive144Third136Node58 = false := by
  decide +kernel

#print axioms adaptive144Third136Proof58

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third136Proof56 : runCachedNode 511 129800 Adaptive144Third136Node56 = false := by
  decide +kernel

#print axioms adaptive144Third136Proof56

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third136Proof57 : runCachedNode 511 129800 Adaptive144Third136Node57 = false := by
  decide +kernel

#print axioms adaptive144Third136Proof57

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third136Proof86 : runCachedNode 511 129800 Adaptive144Third136Node86 = false := by
  decide +kernel

#print axioms adaptive144Third136Proof86

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third136Proof28 : runCachedNode 511 129800 Adaptive144Third136Node28 = false := by
  decide +kernel

#print axioms adaptive144Third136Proof28

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third136Proof29 : runCachedNode 511 129800 Adaptive144Third136Node29 = false := by
  decide +kernel

#print axioms adaptive144Third136Proof29

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third136Proof54 : runCachedNode 511 129800 Adaptive144Third136Node54 = false := by
  decide +kernel

#print axioms adaptive144Third136Proof54

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third136Proof55 : runCachedNode 511 129800 Adaptive144Third136Node55 = false := by
  decide +kernel

#print axioms adaptive144Third136Proof55

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third136Proof84 : runCachedNode 511 129800 Adaptive144Third136Node84 = false := by
  decide +kernel

#print axioms adaptive144Third136Proof84

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third136Proof85 : runCachedNode 511 129800 Adaptive144Third136Node85 = false := by
  decide +kernel

#print axioms adaptive144Third136Proof85

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third136Proof1 : runCachedNode 511 129800 Adaptive144Third136Node1 = false := by
  decide +kernel

#print axioms adaptive144Third136Proof1

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third136Proof53 : runCachedNode 511 129800 Adaptive144Third136Node53 = false := by
  decide +kernel

#print axioms adaptive144Third136Proof53

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third136Proof83 : runCachedNode 511 129800 Adaptive144Third136Node83 = false := by
  decide +kernel

#print axioms adaptive144Third136Proof83

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third136Proof27 : runCachedNode 511 129800 Adaptive144Third136Node27 = false := by
  decide +kernel

#print axioms adaptive144Third136Proof27

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third136Proof51 : runCachedNode 511 129800 Adaptive144Third136Node51 = false := by
  decide +kernel

#print axioms adaptive144Third136Proof51

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third136Proof52 : runCachedNode 511 129800 Adaptive144Third136Node52 = false := by
  decide +kernel

#print axioms adaptive144Third136Proof52

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third136Proof80 : runCachedNode 511 129800 Adaptive144Third136Node80 = false := by
  decide +kernel

#print axioms adaptive144Third136Proof80

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third136Proof81 : runCachedNode 511 129800 Adaptive144Third136Node81 = false := by
  decide +kernel

#print axioms adaptive144Third136Proof81

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third136Proof82 : runCachedNode 511 129800 Adaptive144Third136Node82 = false := by
  decide +kernel

#print axioms adaptive144Third136Proof82

end NineSeparatedSubsetSums
