import NineSeparatedSubsetSums.Adaptive144Third137State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third137Proof17 : runCachedNode 511 129993 Adaptive144Third137Node17 = false := by
  decide +kernel

#print axioms adaptive144Third137Proof17

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third137Proof152 : runCachedNode 511 129993 Adaptive144Third137Node152 = false := by
  decide +kernel

#print axioms adaptive144Third137Proof152

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third137Proof39 : runCachedNode 511 129993 Adaptive144Third137Node39 = false := by
  decide +kernel

#print axioms adaptive144Third137Proof39

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third137Proof26 : runCachedNode 511 129993 Adaptive144Third137Node26 = false := by
  decide +kernel

#print axioms adaptive144Third137Proof26

end NineSeparatedSubsetSums
