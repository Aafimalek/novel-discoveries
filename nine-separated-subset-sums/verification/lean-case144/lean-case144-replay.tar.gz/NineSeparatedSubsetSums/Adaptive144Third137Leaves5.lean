import NineSeparatedSubsetSums.Adaptive144Third137State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third137Proof151 : runCachedNode 511 129993 Adaptive144Third137Node151 = false := by
  decide +kernel

#print axioms adaptive144Third137Proof151

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third137Proof179 : runCachedNode 511 129993 Adaptive144Third137Node179 = false := by
  decide +kernel

#print axioms adaptive144Third137Proof179

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third137Proof94 : runCachedNode 511 129993 Adaptive144Third137Node94 = false := by
  decide +kernel

#print axioms adaptive144Third137Proof94

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third137Proof65 : runCachedNode 511 129993 Adaptive144Third137Node65 = false := by
  decide +kernel

#print axioms adaptive144Third137Proof65

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third137Proof1 : runCachedNode 511 129993 Adaptive144Third137Node1 = false := by
  decide +kernel

#print axioms adaptive144Third137Proof1

end NineSeparatedSubsetSums
