import NineSeparatedSubsetSums.Adaptive144Third133State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third133Proof20 : runCachedNode 511 129309 Adaptive144Third133Node20 = false := by
  decide +kernel

#print axioms adaptive144Third133Proof20

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third133Proof18 : runCachedNode 511 129309 Adaptive144Third133Node18 = false := by
  decide +kernel

#print axioms adaptive144Third133Proof18

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third133Proof40 : runCachedNode 511 129309 Adaptive144Third133Node40 = false := by
  decide +kernel

#print axioms adaptive144Third133Proof40

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third133Proof3 : runCachedNode 511 129309 Adaptive144Third133Node3 = false := by
  decide +kernel

#print axioms adaptive144Third133Proof3

end NineSeparatedSubsetSums
