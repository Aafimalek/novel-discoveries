import NineSeparatedSubsetSums.EightPoint144_118PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint144_118PackedAnchor0Part1 :
    ∀ j : Fin 120, 2410228 ≤ FourPointNumeric.octPackedCharge 144 118 20 packedOct144_118_0
      (2*((j.val : Int)+120)+0) := by decide +kernel

end NineSeparatedSubsetSums
