import NineSeparatedSubsetSums.Adaptive144Third141State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third141Proof200 : runCachedNode 511 130584 Adaptive144Third141Node200 = false := by
  decide +kernel

#print axioms adaptive144Third141Proof200

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third141Proof169 : runCachedNode 511 130584 Adaptive144Third141Node169 = false := by
  decide +kernel

#print axioms adaptive144Third141Proof169

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third141Proof52 : runCachedNode 511 130584 Adaptive144Third141Node52 = false := by
  decide +kernel

#print axioms adaptive144Third141Proof52

end NineSeparatedSubsetSums
