import NineSeparatedSubsetSums.Adaptive144Third128State
import NineSeparatedSubsetSums.Adaptive144Third128Leaves0
import NineSeparatedSubsetSums.Adaptive144Third128Leaves1

namespace NineSeparatedSubsetSums

theorem adaptive144Third128Proof0 : runCachedNode 511 128276 Adaptive144Third128Node0 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 128276 Adaptive144Third128Node0 = [110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 125, 126, 127] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive144Third128Proof1
  · exact adaptive144Third128Proof2
  · exact adaptive144Third128Proof3
  · exact adaptive144Third128Proof4
  · exact adaptive144Third128Proof5
  · exact adaptive144Third128Proof6
  · exact adaptive144Third128Proof7
  · exact adaptive144Third128Proof8
  · exact adaptive144Third128Proof9
  · exact adaptive144Third128Proof10
  · exact adaptive144Third128Proof11
  · exact adaptive144Third128Proof12
  · exact adaptive144Third128Proof13
  · exact adaptive144Third128Proof14
  · exact adaptive144Third128Proof15
  · exact adaptive144Third128Proof16
  · exact adaptive144Third128Proof17

#print axioms adaptive144Third128Proof0

end NineSeparatedSubsetSums
