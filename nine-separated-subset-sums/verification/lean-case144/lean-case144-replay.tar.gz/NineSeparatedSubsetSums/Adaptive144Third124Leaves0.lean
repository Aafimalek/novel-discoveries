import NineSeparatedSubsetSums.Adaptive144Third124State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third124Proof0 : runCachedNode 511 127162 Adaptive144Third124Node0 = false := by
  decide +kernel

#print axioms adaptive144Third124Proof0

end NineSeparatedSubsetSums
