import NineSeparatedSubsetSums.Adaptive144Third140State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof600 : runCachedNode 511 130381 Adaptive144Third140Node600 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof600

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof464 : runCachedNode 511 130381 Adaptive144Third140Node464 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof464

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof388 : runCachedNode 511 130381 Adaptive144Third140Node388 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof388

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof85 : runCachedNode 511 130381 Adaptive144Third140Node85 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof85

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof43 : runCachedNode 511 130381 Adaptive144Third140Node43 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof43

end NineSeparatedSubsetSums
