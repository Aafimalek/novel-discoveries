import NineSeparatedSubsetSums.Adaptive144Third143State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third143Proof158 : runCachedNode 511 130885 Adaptive144Third143Node158 = false := by
  decide +kernel

#print axioms adaptive144Third143Proof158

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third143Proof486 : runCachedNode 511 130885 Adaptive144Third143Node486 = false := by
  decide +kernel

#print axioms adaptive144Third143Proof486

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third143Proof410 : runCachedNode 511 130885 Adaptive144Third143Node410 = false := by
  decide +kernel

#print axioms adaptive144Third143Proof410

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third143Proof487 : runCachedNode 511 130885 Adaptive144Third143Node487 = false := by
  decide +kernel

#print axioms adaptive144Third143Proof487

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third143Proof253 : runCachedNode 511 130885 Adaptive144Third143Node253 = false := by
  decide +kernel

#print axioms adaptive144Third143Proof253

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third143Proof563 : runCachedNode 511 130885 Adaptive144Third143Node563 = false := by
  decide +kernel

#print axioms adaptive144Third143Proof563

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third143Proof476 : runCachedNode 511 130885 Adaptive144Third143Node476 = false := by
  decide +kernel

#print axioms adaptive144Third143Proof476

end NineSeparatedSubsetSums
