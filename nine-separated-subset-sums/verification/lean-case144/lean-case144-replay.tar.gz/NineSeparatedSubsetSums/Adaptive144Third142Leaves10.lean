import NineSeparatedSubsetSums.Adaptive144Third142State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third142Proof662 : runCachedNode 511 130737 Adaptive144Third142Node662 = false := by
  decide +kernel

#print axioms adaptive144Third142Proof662

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third142Proof264 : runCachedNode 511 130737 Adaptive144Third142Node264 = false := by
  decide +kernel

#print axioms adaptive144Third142Proof264

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third142Proof440 : runCachedNode 511 130737 Adaptive144Third142Node440 = false := by
  decide +kernel

#print axioms adaptive144Third142Proof440

end NineSeparatedSubsetSums
