import NineSeparatedSubsetSums.Adaptive144Third139State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third139Proof16 : runCachedNode 511 130274 Adaptive144Third139Node16 = false := by
  decide +kernel

#print axioms adaptive144Third139Proof16

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third139Proof183 : runCachedNode 511 130274 Adaptive144Third139Node183 = false := by
  decide +kernel

#print axioms adaptive144Third139Proof183

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third139Proof210 : runCachedNode 511 130274 Adaptive144Third139Node210 = false := by
  decide +kernel

#print axioms adaptive144Third139Proof210

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third139Proof15 : runCachedNode 511 130274 Adaptive144Third139Node15 = false := by
  decide +kernel

#print axioms adaptive144Third139Proof15

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third139Proof52 : runCachedNode 511 130274 Adaptive144Third139Node52 = false := by
  decide +kernel

#print axioms adaptive144Third139Proof52

end NineSeparatedSubsetSums
