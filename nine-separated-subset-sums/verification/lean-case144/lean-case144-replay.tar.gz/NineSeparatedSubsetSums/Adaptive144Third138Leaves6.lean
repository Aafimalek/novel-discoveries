import NineSeparatedSubsetSums.Adaptive144Third138State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third138Proof213 : runCachedNode 511 130126 Adaptive144Third138Node213 = false := by
  decide +kernel

#print axioms adaptive144Third138Proof213

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third138Proof183 : runCachedNode 511 130126 Adaptive144Third138Node183 = false := by
  decide +kernel

#print axioms adaptive144Third138Proof183

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third138Proof30 : runCachedNode 511 130126 Adaptive144Third138Node30 = false := by
  decide +kernel

#print axioms adaptive144Third138Proof30

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third138Proof97 : runCachedNode 511 130126 Adaptive144Third138Node97 = false := by
  decide +kernel

#print axioms adaptive144Third138Proof97

end NineSeparatedSubsetSums
