import NineSeparatedSubsetSums.Adaptive144Third140State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof17 : runCachedNode 511 130381 Adaptive144Third140Node17 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof17

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof114 : runCachedNode 511 130381 Adaptive144Third140Node114 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof114

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof67 : runCachedNode 511 130381 Adaptive144Third140Node67 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof67

end NineSeparatedSubsetSums
