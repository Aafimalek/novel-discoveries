import NineSeparatedSubsetSums.Adaptive144Third143State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third143Proof568 : runCachedNode 511 130885 Adaptive144Third143Node568 = false := by
  decide +kernel

#print axioms adaptive144Third143Proof568

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third143Proof128 : runCachedNode 511 130885 Adaptive144Third143Node128 = false := by
  decide +kernel

#print axioms adaptive144Third143Proof128

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third143Proof489 : runCachedNode 511 130885 Adaptive144Third143Node489 = false := by
  decide +kernel

#print axioms adaptive144Third143Proof489

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third143Proof658 : runCachedNode 511 130885 Adaptive144Third143Node658 = false := by
  decide +kernel

#print axioms adaptive144Third143Proof658

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third143Proof183 : runCachedNode 511 130885 Adaptive144Third143Node183 = false := by
  decide +kernel

#print axioms adaptive144Third143Proof183

end NineSeparatedSubsetSums
