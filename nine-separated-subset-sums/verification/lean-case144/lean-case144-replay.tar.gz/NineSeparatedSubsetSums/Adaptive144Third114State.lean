import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive144Third114Node0 : CachedSearchNode :=
  ⟨4, 113, computeCenteredMask [148,144,114], 406, 55636⟩

end NineSeparatedSubsetSums
