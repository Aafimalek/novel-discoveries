import NineSeparatedSubsetSums.Adaptive144Third127State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third127Proof16 : runCachedNode 511 128058 Adaptive144Third127Node16 = false := by
  decide +kernel

#print axioms adaptive144Third127Proof16

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third127Proof15 : runCachedNode 511 128058 Adaptive144Third127Node15 = false := by
  decide +kernel

#print axioms adaptive144Third127Proof15

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third127Proof14 : runCachedNode 511 128058 Adaptive144Third127Node14 = false := by
  decide +kernel

#print axioms adaptive144Third127Proof14

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third127Proof13 : runCachedNode 511 128058 Adaptive144Third127Node13 = false := by
  decide +kernel

#print axioms adaptive144Third127Proof13

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third127Proof10 : runCachedNode 511 128058 Adaptive144Third127Node10 = false := by
  decide +kernel

#print axioms adaptive144Third127Proof10

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third127Proof12 : runCachedNode 511 128058 Adaptive144Third127Node12 = false := by
  decide +kernel

#print axioms adaptive144Third127Proof12

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third127Proof6 : runCachedNode 511 128058 Adaptive144Third127Node6 = false := by
  decide +kernel

#print axioms adaptive144Third127Proof6

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third127Proof3 : runCachedNode 511 128058 Adaptive144Third127Node3 = false := by
  decide +kernel

#print axioms adaptive144Third127Proof3

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third127Proof1 : runCachedNode 511 128058 Adaptive144Third127Node1 = false := by
  decide +kernel

#print axioms adaptive144Third127Proof1

end NineSeparatedSubsetSums
