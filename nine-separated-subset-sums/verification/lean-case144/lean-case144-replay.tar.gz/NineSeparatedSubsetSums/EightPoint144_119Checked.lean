import NineSeparatedSubsetSums.EightPointPackedGeometry
import NineSeparatedSubsetSums.EightPoint144_119PackedBudget0
import NineSeparatedSubsetSums.EightPoint144_119PackedAnchor0Part0
import NineSeparatedSubsetSums.EightPoint144_119PackedAnchor0Part1
import NineSeparatedSubsetSums.EightPoint144_119PackedAnchor0Part2
import NineSeparatedSubsetSums.EightPoint144_119PackedBudget1
import NineSeparatedSubsetSums.EightPoint144_119PackedAnchor1Part0
import NineSeparatedSubsetSums.EightPoint144_119PackedAnchor1Part1
import NineSeparatedSubsetSums.EightPoint144_119PackedAnchor1Part2

namespace NineSeparatedSubsetSums

private theorem packedOct144_119Anchor0 :
  ∀ j : Fin 498, ((j.val : Int)+144+119)%2=0 →
    2430188 ≤ FourPointNumeric.octPackedCharge 144 119 20 packedOct144_119_0 (j.val : Int) := by
  intro j hj
  let k := (j.val-1)/2
  have hk : k < 249 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+1 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint144_119PackedAnchor0Part0 z
    rwa [he,hrep] at ht
  by_cases h1 : k < 240
  · let z : Fin 120 := ⟨k-120, by omega⟩
    have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
    have ht := eightPoint144_119PackedAnchor0Part1 z
    rwa [he,hrep] at ht
  let z : Fin 9 := ⟨k-240, by omega⟩
  have he : (z.val : Int)+240 = k := by dsimp [z] <;> omega
  have ht := eightPoint144_119PackedAnchor0Part2 z
  rwa [he,hrep] at ht

private theorem packedOct144_119Anchor1 :
  ∀ j : Fin 498, ((j.val : Int)+144+119)%2=1 →
    2431080 ≤ FourPointNumeric.octPackedCharge 144 119 20 packedOct144_119_1 (j.val : Int) := by
  intro j hj
  let k := (j.val-0)/2
  have hk : k < 249 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+0 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint144_119PackedAnchor1Part0 z
    rwa [he,hrep] at ht
  by_cases h1 : k < 240
  · let z : Fin 120 := ⟨k-120, by omega⟩
    have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
    have ht := eightPoint144_119PackedAnchor1Part1 z
    rwa [he,hrep] at ht
  let z : Fin 9 := ⟨k-240, by omega⟩
  have he : (z.val : Int)+240 = k := by dsimp [z] <;> omega
  have ht := eightPoint144_119PackedAnchor1Part2 z
  rwa [he,hrep] at ht

def packedOctCertificate144_119_0 : EightPointCertificate 144 119 0 126028 :=
  eightPointCertificateOfPacked 144 119 0 126028 2430188 20 packedOct144_119_0 457 498
    (by decide +kernel) (by decide) packedOct144_119Anchor0
    (by rw [packedOct144_119_0_budget]; decide)

def packedOctCertificate144_119_1 : EightPointCertificate 144 119 1 126028 :=
  eightPointCertificateOfPacked 144 119 1 126028 2431080 20 packedOct144_119_1 464 498
    (by decide +kernel) (by decide) packedOct144_119Anchor1
    (by rw [packedOct144_119_1_budget]; decide)

theorem max148_second144_third119_eightPoint_moment_bound (tail : List ℕ) (len : tail.length=6)
    (distinct : (natSubsetSums (148::144::119::tail)).Nodup) :
    126028 ≤ ((148::144::119::tail).map (· ^ 2)).sum := by
  apply eightPointNatMomentLower 144 119 126028 tail len distinct
  intro p hp
  by_cases h : p=0
  · subst p
    exact packedOctCertificate144_119_0
  · have he : p=1 := hp.resolve_left h
    subst p
    exact packedOctCertificate144_119_1

#print axioms max148_second144_third119_eightPoint_moment_bound

end NineSeparatedSubsetSums
