import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive144Third129Node0 : CachedSearchNode :=
  ⟨4, 128, computeCenteredMask [148,144,129], 421, 59281⟩
def Adaptive144Third129Node1 : CachedSearchNode := cachedChild Adaptive144Third129Node0 110
def Adaptive144Third129Node2 : CachedSearchNode := cachedChild Adaptive144Third129Node0 111
def Adaptive144Third129Node3 : CachedSearchNode := cachedChild Adaptive144Third129Node0 112
def Adaptive144Third129Node4 : CachedSearchNode := cachedChild Adaptive144Third129Node0 113
def Adaptive144Third129Node5 : CachedSearchNode := cachedChild Adaptive144Third129Node0 114
def Adaptive144Third129Node6 : CachedSearchNode := cachedChild Adaptive144Third129Node0 115
def Adaptive144Third129Node7 : CachedSearchNode := cachedChild Adaptive144Third129Node0 116
def Adaptive144Third129Node8 : CachedSearchNode := cachedChild Adaptive144Third129Node0 117
def Adaptive144Third129Node9 : CachedSearchNode := cachedChild Adaptive144Third129Node0 118
def Adaptive144Third129Node10 : CachedSearchNode := cachedChild Adaptive144Third129Node0 119
def Adaptive144Third129Node11 : CachedSearchNode := cachedChild Adaptive144Third129Node0 120
def Adaptive144Third129Node12 : CachedSearchNode := cachedChild Adaptive144Third129Node0 121
def Adaptive144Third129Node13 : CachedSearchNode := cachedChild Adaptive144Third129Node0 122
def Adaptive144Third129Node14 : CachedSearchNode := cachedChild Adaptive144Third129Node0 123
def Adaptive144Third129Node15 : CachedSearchNode := cachedChild Adaptive144Third129Node0 124
def Adaptive144Third129Node16 : CachedSearchNode := cachedChild Adaptive144Third129Node0 126
def Adaptive144Third129Node17 : CachedSearchNode := cachedChild Adaptive144Third129Node0 127
def Adaptive144Third129Node18 : CachedSearchNode := cachedChild Adaptive144Third129Node0 128

end NineSeparatedSubsetSums
