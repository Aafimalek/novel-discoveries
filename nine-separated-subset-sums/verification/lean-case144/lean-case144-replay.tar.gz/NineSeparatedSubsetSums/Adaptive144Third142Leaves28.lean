import NineSeparatedSubsetSums.Adaptive144Third142State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third142Proof489 : runCachedNode 511 130737 Adaptive144Third142Node489 = false := by
  decide +kernel

#print axioms adaptive144Third142Proof489

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third142Proof611 : runCachedNode 511 130737 Adaptive144Third142Node611 = false := by
  decide +kernel

#print axioms adaptive144Third142Proof611

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third142Proof258 : runCachedNode 511 130737 Adaptive144Third142Node258 = false := by
  decide +kernel

#print axioms adaptive144Third142Proof258

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third142Proof235 : runCachedNode 511 130737 Adaptive144Third142Node235 = false := by
  decide +kernel

#print axioms adaptive144Third142Proof235

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third142Proof399 : runCachedNode 511 130737 Adaptive144Third142Node399 = false := by
  decide +kernel

#print axioms adaptive144Third142Proof399

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third142Proof325 : runCachedNode 511 130737 Adaptive144Third142Node325 = false := by
  decide +kernel

#print axioms adaptive144Third142Proof325

end NineSeparatedSubsetSums
