import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive144Third113Node0 : CachedSearchNode :=
  ⟨4, 112, computeCenteredMask [148,144,113], 405, 55409⟩

end NineSeparatedSubsetSums
