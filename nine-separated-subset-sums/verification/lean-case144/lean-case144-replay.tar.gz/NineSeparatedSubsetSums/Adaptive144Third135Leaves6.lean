import NineSeparatedSubsetSums.Adaptive144Third135State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third135Proof45 : runCachedNode 511 129692 Adaptive144Third135Node45 = false := by
  decide +kernel

#print axioms adaptive144Third135Proof45

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third135Proof72 : runCachedNode 511 129692 Adaptive144Third135Node72 = false := by
  decide +kernel

#print axioms adaptive144Third135Proof72

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third135Proof70 : runCachedNode 511 129692 Adaptive144Third135Node70 = false := by
  decide +kernel

#print axioms adaptive144Third135Proof70

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third135Proof69 : runCachedNode 511 129692 Adaptive144Third135Node69 = false := by
  decide +kernel

#print axioms adaptive144Third135Proof69

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third135Proof44 : runCachedNode 511 129692 Adaptive144Third135Node44 = false := by
  decide +kernel

#print axioms adaptive144Third135Proof44

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third135Proof43 : runCachedNode 511 129692 Adaptive144Third135Node43 = false := by
  decide +kernel

#print axioms adaptive144Third135Proof43

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third135Proof10 : runCachedNode 511 129692 Adaptive144Third135Node10 = false := by
  decide +kernel

#print axioms adaptive144Third135Proof10

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third135Proof74 : runCachedNode 511 129692 Adaptive144Third135Node74 = false := by
  decide +kernel

#print axioms adaptive144Third135Proof74

end NineSeparatedSubsetSums
