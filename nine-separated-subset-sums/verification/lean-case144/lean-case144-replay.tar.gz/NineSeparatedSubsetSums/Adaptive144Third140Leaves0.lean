import NineSeparatedSubsetSums.Adaptive144Third140State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof533 : runCachedNode 511 130381 Adaptive144Third140Node533 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof533

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof631 : runCachedNode 511 130381 Adaptive144Third140Node631 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof631

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof204 : runCachedNode 511 130381 Adaptive144Third140Node204 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof204

end NineSeparatedSubsetSums
