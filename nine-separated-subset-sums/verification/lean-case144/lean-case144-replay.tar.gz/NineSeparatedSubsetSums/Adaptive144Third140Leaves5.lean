import NineSeparatedSubsetSums.Adaptive144Third140State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof532 : runCachedNode 511 130381 Adaptive144Third140Node532 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof532

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof390 : runCachedNode 511 130381 Adaptive144Third140Node390 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof390

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof145 : runCachedNode 511 130381 Adaptive144Third140Node145 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof145

end NineSeparatedSubsetSums
