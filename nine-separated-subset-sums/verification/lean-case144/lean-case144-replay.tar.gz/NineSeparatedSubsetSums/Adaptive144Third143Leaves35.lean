import NineSeparatedSubsetSums.Adaptive144Third143State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third143Proof533 : runCachedNode 511 130885 Adaptive144Third143Node533 = false := by
  decide +kernel

#print axioms adaptive144Third143Proof533

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third143Proof224 : runCachedNode 511 130885 Adaptive144Third143Node224 = false := by
  decide +kernel

#print axioms adaptive144Third143Proof224

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third143Proof452 : runCachedNode 511 130885 Adaptive144Third143Node452 = false := by
  decide +kernel

#print axioms adaptive144Third143Proof452

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third143Proof48 : runCachedNode 511 130885 Adaptive144Third143Node48 = false := by
  decide +kernel

#print axioms adaptive144Third143Proof48

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third143Proof155 : runCachedNode 511 130885 Adaptive144Third143Node155 = false := by
  decide +kernel

#print axioms adaptive144Third143Proof155

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third143Proof562 : runCachedNode 511 130885 Adaptive144Third143Node562 = false := by
  decide +kernel

#print axioms adaptive144Third143Proof562

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third143Proof363 : runCachedNode 511 130885 Adaptive144Third143Node363 = false := by
  decide +kernel

#print axioms adaptive144Third143Proof363

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third143Proof221 : runCachedNode 511 130885 Adaptive144Third143Node221 = false := by
  decide +kernel

#print axioms adaptive144Third143Proof221

end NineSeparatedSubsetSums
