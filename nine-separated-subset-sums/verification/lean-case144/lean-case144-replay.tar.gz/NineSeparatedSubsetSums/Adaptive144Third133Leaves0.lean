import NineSeparatedSubsetSums.Adaptive144Third133State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third133Proof21 : runCachedNode 511 129309 Adaptive144Third133Node21 = false := by
  decide +kernel

#print axioms adaptive144Third133Proof21

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third133Proof44 : runCachedNode 511 129309 Adaptive144Third133Node44 = false := by
  decide +kernel

#print axioms adaptive144Third133Proof44

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third133Proof5 : runCachedNode 511 129309 Adaptive144Third133Node5 = false := by
  decide +kernel

#print axioms adaptive144Third133Proof5

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third133Proof1 : runCachedNode 511 129309 Adaptive144Third133Node1 = false := by
  decide +kernel

#print axioms adaptive144Third133Proof1

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third133Proof23 : runCachedNode 511 129309 Adaptive144Third133Node23 = false := by
  decide +kernel

#print axioms adaptive144Third133Proof23

end NineSeparatedSubsetSums
