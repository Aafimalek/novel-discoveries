import NineSeparatedSubsetSums.Adaptive144Third141State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third141Proof348 : runCachedNode 511 130584 Adaptive144Third141Node348 = false := by
  decide +kernel

#print axioms adaptive144Third141Proof348

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third141Proof124 : runCachedNode 511 130584 Adaptive144Third141Node124 = false := by
  decide +kernel

#print axioms adaptive144Third141Proof124

end NineSeparatedSubsetSums
