import NineSeparatedSubsetSums.Adaptive144Third105Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint144Checked

namespace NineSeparatedSubsetSums


theorem adaptive144Third105 : NoDescendingTailAfterThird 144 105 :=
  noDescendingThirdTail_of_cached 144 105 112221 (fun t ht nd => max148_second144_fourPoint_moment_bound (105::t) (by simp [ht]) nd) adaptive144Third105Proof0

#print axioms adaptive144Third105

end NineSeparatedSubsetSums
