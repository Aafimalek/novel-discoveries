import NineSeparatedSubsetSums.Adaptive144Third143State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third143Proof22 : runCachedNode 511 130885 Adaptive144Third143Node22 = false := by
  decide +kernel

#print axioms adaptive144Third143Proof22

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third143Proof129 : runCachedNode 511 130885 Adaptive144Third143Node129 = false := by
  decide +kernel

#print axioms adaptive144Third143Proof129

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third143Proof5 : runCachedNode 511 130885 Adaptive144Third143Node5 = false := by
  decide +kernel

#print axioms adaptive144Third143Proof5

end NineSeparatedSubsetSums
