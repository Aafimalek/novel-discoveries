import NineSeparatedSubsetSums.Adaptive144Third136State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third136Proof20 : runCachedNode 511 129800 Adaptive144Third136Node20 = false := by
  decide +kernel

#print axioms adaptive144Third136Proof20

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third136Proof17 : runCachedNode 511 129800 Adaptive144Third136Node17 = false := by
  decide +kernel

#print axioms adaptive144Third136Proof17

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third136Proof70 : runCachedNode 511 129800 Adaptive144Third136Node70 = false := by
  decide +kernel

#print axioms adaptive144Third136Proof70

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third136Proof59 : runCachedNode 511 129800 Adaptive144Third136Node59 = false := by
  decide +kernel

#print axioms adaptive144Third136Proof59

end NineSeparatedSubsetSums
