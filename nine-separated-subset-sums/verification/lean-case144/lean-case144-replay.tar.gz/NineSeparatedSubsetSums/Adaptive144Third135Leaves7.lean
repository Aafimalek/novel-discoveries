import NineSeparatedSubsetSums.Adaptive144Third135State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third135Proof12 : runCachedNode 511 129692 Adaptive144Third135Node12 = false := by
  decide +kernel

#print axioms adaptive144Third135Proof12

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third135Proof94 : runCachedNode 511 129692 Adaptive144Third135Node94 = false := by
  decide +kernel

#print axioms adaptive144Third135Proof94

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third135Proof41 : runCachedNode 511 129692 Adaptive144Third135Node41 = false := by
  decide +kernel

#print axioms adaptive144Third135Proof41

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third135Proof11 : runCachedNode 511 129692 Adaptive144Third135Node11 = false := by
  decide +kernel

#print axioms adaptive144Third135Proof11

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third135Proof66 : runCachedNode 511 129692 Adaptive144Third135Node66 = false := by
  decide +kernel

#print axioms adaptive144Third135Proof66

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third135Proof42 : runCachedNode 511 129692 Adaptive144Third135Node42 = false := by
  decide +kernel

#print axioms adaptive144Third135Proof42

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third135Proof9 : runCachedNode 511 129692 Adaptive144Third135Node9 = false := by
  decide +kernel

#print axioms adaptive144Third135Proof9

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third135Proof38 : runCachedNode 511 129692 Adaptive144Third135Node38 = false := by
  decide +kernel

#print axioms adaptive144Third135Proof38

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third135Proof62 : runCachedNode 511 129692 Adaptive144Third135Node62 = false := by
  decide +kernel

#print axioms adaptive144Third135Proof62

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third135Proof96 : runCachedNode 511 129692 Adaptive144Third135Node96 = false := by
  decide +kernel

#print axioms adaptive144Third135Proof96

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third135Proof91 : runCachedNode 511 129692 Adaptive144Third135Node91 = false := by
  decide +kernel

#print axioms adaptive144Third135Proof91

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third135Proof64 : runCachedNode 511 129692 Adaptive144Third135Node64 = false := by
  decide +kernel

#print axioms adaptive144Third135Proof64

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third135Proof8 : runCachedNode 511 129692 Adaptive144Third135Node8 = false := by
  decide +kernel

#print axioms adaptive144Third135Proof8

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third135Proof63 : runCachedNode 511 129692 Adaptive144Third135Node63 = false := by
  decide +kernel

#print axioms adaptive144Third135Proof63

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third135Proof39 : runCachedNode 511 129692 Adaptive144Third135Node39 = false := by
  decide +kernel

#print axioms adaptive144Third135Proof39

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third135Proof93 : runCachedNode 511 129692 Adaptive144Third135Node93 = false := by
  decide +kernel

#print axioms adaptive144Third135Proof93

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third135Proof60 : runCachedNode 511 129692 Adaptive144Third135Node60 = false := by
  decide +kernel

#print axioms adaptive144Third135Proof60

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third135Proof7 : runCachedNode 511 129692 Adaptive144Third135Node7 = false := by
  decide +kernel

#print axioms adaptive144Third135Proof7

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third135Proof37 : runCachedNode 511 129692 Adaptive144Third135Node37 = false := by
  decide +kernel

#print axioms adaptive144Third135Proof37

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third135Proof80 : runCachedNode 511 129692 Adaptive144Third135Node80 = false := by
  decide +kernel

#print axioms adaptive144Third135Proof80

end NineSeparatedSubsetSums
