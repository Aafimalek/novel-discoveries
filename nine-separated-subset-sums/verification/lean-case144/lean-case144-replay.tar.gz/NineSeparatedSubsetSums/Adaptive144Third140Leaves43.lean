import NineSeparatedSubsetSums.Adaptive144Third140State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof293 : runCachedNode 511 130381 Adaptive144Third140Node293 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof293

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof360 : runCachedNode 511 130381 Adaptive144Third140Node360 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof360

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof61 : runCachedNode 511 130381 Adaptive144Third140Node61 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof61

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof254 : runCachedNode 511 130381 Adaptive144Third140Node254 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof254

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof172 : runCachedNode 511 130381 Adaptive144Third140Node172 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof172

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof197 : runCachedNode 511 130381 Adaptive144Third140Node197 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof197

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof634 : runCachedNode 511 130381 Adaptive144Third140Node634 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof634

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof257 : runCachedNode 511 130381 Adaptive144Third140Node257 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof257

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof715 : runCachedNode 511 130381 Adaptive144Third140Node715 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof715

end NineSeparatedSubsetSums
