import NineSeparatedSubsetSums.Adaptive144Third143State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third143Proof331 : runCachedNode 511 130885 Adaptive144Third143Node331 = false := by
  decide +kernel

#print axioms adaptive144Third143Proof331

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third143Proof193 : runCachedNode 511 130885 Adaptive144Third143Node193 = false := by
  decide +kernel

#print axioms adaptive144Third143Proof193

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third143Proof32 : runCachedNode 511 130885 Adaptive144Third143Node32 = false := by
  decide +kernel

#print axioms adaptive144Third143Proof32

end NineSeparatedSubsetSums
