import NineSeparatedSubsetSums.Adaptive144Third143State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third143Proof160 : runCachedNode 511 130885 Adaptive144Third143Node160 = false := by
  decide +kernel

#print axioms adaptive144Third143Proof160

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third143Proof536 : runCachedNode 511 130885 Adaptive144Third143Node536 = false := by
  decide +kernel

#print axioms adaptive144Third143Proof536

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third143Proof659 : runCachedNode 511 130885 Adaptive144Third143Node659 = false := by
  decide +kernel

#print axioms adaptive144Third143Proof659

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third143Proof226 : runCachedNode 511 130885 Adaptive144Third143Node226 = false := by
  decide +kernel

#print axioms adaptive144Third143Proof226

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third143Proof27 : runCachedNode 511 130885 Adaptive144Third143Node27 = false := by
  decide +kernel

#print axioms adaptive144Third143Proof27

end NineSeparatedSubsetSums
