import NineSeparatedSubsetSums.Adaptive144Third141State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third141Proof227 : runCachedNode 511 130584 Adaptive144Third141Node227 = false := by
  decide +kernel

#print axioms adaptive144Third141Proof227

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third141Proof276 : runCachedNode 511 130584 Adaptive144Third141Node276 = false := by
  decide +kernel

#print axioms adaptive144Third141Proof276

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third141Proof388 : runCachedNode 511 130584 Adaptive144Third141Node388 = false := by
  decide +kernel

#print axioms adaptive144Third141Proof388

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third141Proof192 : runCachedNode 511 130584 Adaptive144Third141Node192 = false := by
  decide +kernel

#print axioms adaptive144Third141Proof192

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third141Proof45 : runCachedNode 511 130584 Adaptive144Third141Node45 = false := by
  decide +kernel

#print axioms adaptive144Third141Proof45

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third141Proof228 : runCachedNode 511 130584 Adaptive144Third141Node228 = false := by
  decide +kernel

#print axioms adaptive144Third141Proof228

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third141Proof12 : runCachedNode 511 130584 Adaptive144Third141Node12 = false := by
  decide +kernel

#print axioms adaptive144Third141Proof12

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third141Proof134 : runCachedNode 511 130584 Adaptive144Third141Node134 = false := by
  decide +kernel

#print axioms adaptive144Third141Proof134

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third141Proof301 : runCachedNode 511 130584 Adaptive144Third141Node301 = false := by
  decide +kernel

#print axioms adaptive144Third141Proof301

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third141Proof275 : runCachedNode 511 130584 Adaptive144Third141Node275 = false := by
  decide +kernel

#print axioms adaptive144Third141Proof275

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third141Proof2 : runCachedNode 511 130584 Adaptive144Third141Node2 = false := by
  decide +kernel

#print axioms adaptive144Third141Proof2

end NineSeparatedSubsetSums
