import NineSeparatedSubsetSums.Adaptive144Third122State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third122Proof0 : runCachedNode 511 126638 Adaptive144Third122Node0 = false := by
  decide +kernel

#print axioms adaptive144Third122Proof0

end NineSeparatedSubsetSums
