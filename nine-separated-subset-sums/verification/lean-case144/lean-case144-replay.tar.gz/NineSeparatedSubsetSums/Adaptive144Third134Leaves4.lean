import NineSeparatedSubsetSums.Adaptive144Third134State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third134Proof72 : runCachedNode 511 129525 Adaptive144Third134Node72 = false := by
  decide +kernel

#print axioms adaptive144Third134Proof72

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third134Proof41 : runCachedNode 511 129525 Adaptive144Third134Node41 = false := by
  decide +kernel

#print axioms adaptive144Third134Proof41

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third134Proof70 : runCachedNode 511 129525 Adaptive144Third134Node70 = false := by
  decide +kernel

#print axioms adaptive144Third134Proof70

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third134Proof46 : runCachedNode 511 129525 Adaptive144Third134Node46 = false := by
  decide +kernel

#print axioms adaptive144Third134Proof46

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third134Proof71 : runCachedNode 511 129525 Adaptive144Third134Node71 = false := by
  decide +kernel

#print axioms adaptive144Third134Proof71

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third134Proof62 : runCachedNode 511 129525 Adaptive144Third134Node62 = false := by
  decide +kernel

#print axioms adaptive144Third134Proof62

end NineSeparatedSubsetSums
