import NineSeparatedSubsetSums.Adaptive144Third116State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third116Proof14 : runCachedNode 511 112221 Adaptive144Third116Node14 = false := by
  decide +kernel

#print axioms adaptive144Third116Proof14

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third116Proof15 : runCachedNode 511 112221 Adaptive144Third116Node15 = false := by
  decide +kernel

#print axioms adaptive144Third116Proof15

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third116Proof12 : runCachedNode 511 112221 Adaptive144Third116Node12 = false := by
  decide +kernel

#print axioms adaptive144Third116Proof12

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third116Proof3 : runCachedNode 511 112221 Adaptive144Third116Node3 = false := by
  decide +kernel

#print axioms adaptive144Third116Proof3

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third116Proof2 : runCachedNode 511 112221 Adaptive144Third116Node2 = false := by
  decide +kernel

#print axioms adaptive144Third116Proof2

end NineSeparatedSubsetSums
