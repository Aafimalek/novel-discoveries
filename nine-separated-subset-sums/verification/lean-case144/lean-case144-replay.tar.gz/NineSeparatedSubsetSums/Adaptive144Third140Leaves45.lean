import NineSeparatedSubsetSums.Adaptive144Third140State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof594 : runCachedNode 511 130381 Adaptive144Third140Node594 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof594

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof171 : runCachedNode 511 130381 Adaptive144Third140Node171 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof171

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof461 : runCachedNode 511 130381 Adaptive144Third140Node461 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof461

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof571 : runCachedNode 511 130381 Adaptive144Third140Node571 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof571

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof229 : runCachedNode 511 130381 Adaptive144Third140Node229 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof229

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof427 : runCachedNode 511 130381 Adaptive144Third140Node427 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof427

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof462 : runCachedNode 511 130381 Adaptive144Third140Node462 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof462

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof112 : runCachedNode 511 130381 Adaptive144Third140Node112 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof112

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof383 : runCachedNode 511 130381 Adaptive144Third140Node383 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof383

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof484 : runCachedNode 511 130381 Adaptive144Third140Node484 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof484

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof160 : runCachedNode 511 130381 Adaptive144Third140Node160 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof160

end NineSeparatedSubsetSums
