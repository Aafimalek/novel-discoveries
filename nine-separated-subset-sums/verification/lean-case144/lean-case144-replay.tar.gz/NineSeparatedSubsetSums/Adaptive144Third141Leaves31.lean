import NineSeparatedSubsetSums.Adaptive144Third141State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third141Proof164 : runCachedNode 511 130584 Adaptive144Third141Node164 = false := by
  decide +kernel

#print axioms adaptive144Third141Proof164

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third141Proof387 : runCachedNode 511 130584 Adaptive144Third141Node387 = false := by
  decide +kernel

#print axioms adaptive144Third141Proof387

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third141Proof344 : runCachedNode 511 130584 Adaptive144Third141Node344 = false := by
  decide +kernel

#print axioms adaptive144Third141Proof344

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third141Proof431 : runCachedNode 511 130584 Adaptive144Third141Node431 = false := by
  decide +kernel

#print axioms adaptive144Third141Proof431

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third141Proof299 : runCachedNode 511 130584 Adaptive144Third141Node299 = false := by
  decide +kernel

#print axioms adaptive144Third141Proof299

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third141Proof44 : runCachedNode 511 130584 Adaptive144Third141Node44 = false := by
  decide +kernel

#print axioms adaptive144Third141Proof44

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third141Proof129 : runCachedNode 511 130584 Adaptive144Third141Node129 = false := by
  decide +kernel

#print axioms adaptive144Third141Proof129

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third141Proof430 : runCachedNode 511 130584 Adaptive144Third141Node430 = false := by
  decide +kernel

#print axioms adaptive144Third141Proof430

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third141Proof298 : runCachedNode 511 130584 Adaptive144Third141Node298 = false := by
  decide +kernel

#print axioms adaptive144Third141Proof298

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third141Proof70 : runCachedNode 511 130584 Adaptive144Third141Node70 = false := by
  decide +kernel

#print axioms adaptive144Third141Proof70

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third141Proof190 : runCachedNode 511 130584 Adaptive144Third141Node190 = false := by
  decide +kernel

#print axioms adaptive144Third141Proof190

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third141Proof224 : runCachedNode 511 130584 Adaptive144Third141Node224 = false := by
  decide +kernel

#print axioms adaptive144Third141Proof224

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third141Proof123 : runCachedNode 511 130584 Adaptive144Third141Node123 = false := by
  decide +kernel

#print axioms adaptive144Third141Proof123

end NineSeparatedSubsetSums
