import NineSeparatedSubsetSums.Adaptive144Third133State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third133Proof14 : runCachedNode 511 129309 Adaptive144Third133Node14 = false := by
  decide +kernel

#print axioms adaptive144Third133Proof14

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third133Proof13 : runCachedNode 511 129309 Adaptive144Third133Node13 = false := by
  decide +kernel

#print axioms adaptive144Third133Proof13

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third133Proof42 : runCachedNode 511 129309 Adaptive144Third133Node42 = false := by
  decide +kernel

#print axioms adaptive144Third133Proof42

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third133Proof11 : runCachedNode 511 129309 Adaptive144Third133Node11 = false := by
  decide +kernel

#print axioms adaptive144Third133Proof11

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third133Proof43 : runCachedNode 511 129309 Adaptive144Third133Node43 = false := by
  decide +kernel

#print axioms adaptive144Third133Proof43

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third133Proof41 : runCachedNode 511 129309 Adaptive144Third133Node41 = false := by
  decide +kernel

#print axioms adaptive144Third133Proof41

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third133Proof10 : runCachedNode 511 129309 Adaptive144Third133Node10 = false := by
  decide +kernel

#print axioms adaptive144Third133Proof10

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third133Proof9 : runCachedNode 511 129309 Adaptive144Third133Node9 = false := by
  decide +kernel

#print axioms adaptive144Third133Proof9

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third133Proof39 : runCachedNode 511 129309 Adaptive144Third133Node39 = false := by
  decide +kernel

#print axioms adaptive144Third133Proof39

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third133Proof38 : runCachedNode 511 129309 Adaptive144Third133Node38 = false := by
  decide +kernel

#print axioms adaptive144Third133Proof38

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third133Proof8 : runCachedNode 511 129309 Adaptive144Third133Node8 = false := by
  decide +kernel

#print axioms adaptive144Third133Proof8

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third133Proof31 : runCachedNode 511 129309 Adaptive144Third133Node31 = false := by
  decide +kernel

#print axioms adaptive144Third133Proof31

end NineSeparatedSubsetSums
