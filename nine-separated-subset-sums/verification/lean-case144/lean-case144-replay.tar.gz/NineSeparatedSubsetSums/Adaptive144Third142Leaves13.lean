import NineSeparatedSubsetSums.Adaptive144Third142State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third142Proof265 : runCachedNode 511 130737 Adaptive144Third142Node265 = false := by
  decide +kernel

#print axioms adaptive144Third142Proof265

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third142Proof534 : runCachedNode 511 130737 Adaptive144Third142Node534 = false := by
  decide +kernel

#print axioms adaptive144Third142Proof534

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third142Proof333 : runCachedNode 511 130737 Adaptive144Third142Node333 = false := by
  decide +kernel

#print axioms adaptive144Third142Proof333

end NineSeparatedSubsetSums
