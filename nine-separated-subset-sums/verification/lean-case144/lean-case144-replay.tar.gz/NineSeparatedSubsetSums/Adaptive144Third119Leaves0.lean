import NineSeparatedSubsetSums.Adaptive144Third119State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third119Proof0 : runCachedNode 511 126028 Adaptive144Third119Node0 = false := by
  decide +kernel

#print axioms adaptive144Third119Proof0

end NineSeparatedSubsetSums
