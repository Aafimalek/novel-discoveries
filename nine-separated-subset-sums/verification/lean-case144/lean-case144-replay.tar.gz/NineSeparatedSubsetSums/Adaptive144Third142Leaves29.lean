import NineSeparatedSubsetSums.Adaptive144Third142State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third142Proof406 : runCachedNode 511 130737 Adaptive144Third142Node406 = false := by
  decide +kernel

#print axioms adaptive144Third142Proof406

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third142Proof137 : runCachedNode 511 130737 Adaptive144Third142Node137 = false := by
  decide +kernel

#print axioms adaptive144Third142Proof137

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third142Proof336 : runCachedNode 511 130737 Adaptive144Third142Node336 = false := by
  decide +kernel

#print axioms adaptive144Third142Proof336

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third142Proof656 : runCachedNode 511 130737 Adaptive144Third142Node656 = false := by
  decide +kernel

#print axioms adaptive144Third142Proof656

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third142Proof199 : runCachedNode 511 130737 Adaptive144Third142Node199 = false := by
  decide +kernel

#print axioms adaptive144Third142Proof199

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third142Proof44 : runCachedNode 511 130737 Adaptive144Third142Node44 = false := by
  decide +kernel

#print axioms adaptive144Third142Proof44

end NineSeparatedSubsetSums
