import NineSeparatedSubsetSums.Adaptive144Third139State
import NineSeparatedSubsetSums.Adaptive144Third139Leaves1
import NineSeparatedSubsetSums.Adaptive144Third139Leaves8
import NineSeparatedSubsetSums.Adaptive144Third139Leaves14
import NineSeparatedSubsetSums.Adaptive144Third139Leaves20
import NineSeparatedSubsetSums.Adaptive144Third139Leaves22
import NineSeparatedSubsetSums.Adaptive144Third139Leaves21
import NineSeparatedSubsetSums.Adaptive144Third139Leaves19
import NineSeparatedSubsetSums.Adaptive144Third139Leaves18
import NineSeparatedSubsetSums.Adaptive144Third139Leaves17
import NineSeparatedSubsetSums.Adaptive144Third139Leaves16
import NineSeparatedSubsetSums.Adaptive144Third139Leaves15
import NineSeparatedSubsetSums.Adaptive144Third139Leaves12
import NineSeparatedSubsetSums.Adaptive144Third139Leaves6
import NineSeparatedSubsetSums.Adaptive144Third139Leaves7
import NineSeparatedSubsetSums.Adaptive144Third139Leaves5
import NineSeparatedSubsetSums.Adaptive144Third139Joins0

namespace NineSeparatedSubsetSums

theorem adaptive144Third139Proof0 : runCachedNode 511 130274 Adaptive144Third139Node0 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130274 Adaptive144Third139Node0 = [110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 132, 133, 134, 136, 137, 138] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive144Third139Proof1
  · exact adaptive144Third139Proof2
  · exact adaptive144Third139Proof3
  · exact adaptive144Third139Proof4
  · exact adaptive144Third139Proof5
  · exact adaptive144Third139Proof6
  · exact adaptive144Third139Proof7
  · exact adaptive144Third139Proof8
  · exact adaptive144Third139Proof9
  · exact adaptive144Third139Proof10
  · exact adaptive144Third139Proof11
  · exact adaptive144Third139Proof12
  · exact adaptive144Third139Proof13
  · exact adaptive144Third139Proof14
  · exact adaptive144Third139Proof15
  · exact adaptive144Third139Proof16
  · exact adaptive144Third139Proof17
  · exact adaptive144Third139Proof18
  · exact adaptive144Third139Proof19
  · exact adaptive144Third139Proof20
  · exact adaptive144Third139Proof21
  · exact adaptive144Third139Proof45
  · exact adaptive144Third139Proof70
  · exact adaptive144Third139Proof97
  · exact adaptive144Third139Proof125
  · exact adaptive144Third139Proof154
  · exact adaptive144Third139Proof185
  · exact adaptive144Third139Proof217

#print axioms adaptive144Third139Proof0

end NineSeparatedSubsetSums
