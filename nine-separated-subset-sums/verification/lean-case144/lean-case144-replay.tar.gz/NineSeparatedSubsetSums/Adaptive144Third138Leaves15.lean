import NineSeparatedSubsetSums.Adaptive144Third138State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third138Proof11 : runCachedNode 511 130126 Adaptive144Third138Node11 = false := by
  decide +kernel

#print axioms adaptive144Third138Proof11

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third138Proof42 : runCachedNode 511 130126 Adaptive144Third138Node42 = false := by
  decide +kernel

#print axioms adaptive144Third138Proof42

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third138Proof117 : runCachedNode 511 130126 Adaptive144Third138Node117 = false := by
  decide +kernel

#print axioms adaptive144Third138Proof117

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third138Proof175 : runCachedNode 511 130126 Adaptive144Third138Node175 = false := by
  decide +kernel

#print axioms adaptive144Third138Proof175

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third138Proof211 : runCachedNode 511 130126 Adaptive144Third138Node211 = false := by
  decide +kernel

#print axioms adaptive144Third138Proof211

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third138Proof207 : runCachedNode 511 130126 Adaptive144Third138Node207 = false := by
  decide +kernel

#print axioms adaptive144Third138Proof207

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third138Proof89 : runCachedNode 511 130126 Adaptive144Third138Node89 = false := by
  decide +kernel

#print axioms adaptive144Third138Proof89

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third138Proof10 : runCachedNode 511 130126 Adaptive144Third138Node10 = false := by
  decide +kernel

#print axioms adaptive144Third138Proof10

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third138Proof119 : runCachedNode 511 130126 Adaptive144Third138Node119 = false := by
  decide +kernel

#print axioms adaptive144Third138Proof119

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third138Proof88 : runCachedNode 511 130126 Adaptive144Third138Node88 = false := by
  decide +kernel

#print axioms adaptive144Third138Proof88

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third138Proof146 : runCachedNode 511 130126 Adaptive144Third138Node146 = false := by
  decide +kernel

#print axioms adaptive144Third138Proof146

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third138Proof66 : runCachedNode 511 130126 Adaptive144Third138Node66 = false := by
  decide +kernel

#print axioms adaptive144Third138Proof66

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third138Proof47 : runCachedNode 511 130126 Adaptive144Third138Node47 = false := by
  decide +kernel

#print axioms adaptive144Third138Proof47

end NineSeparatedSubsetSums
