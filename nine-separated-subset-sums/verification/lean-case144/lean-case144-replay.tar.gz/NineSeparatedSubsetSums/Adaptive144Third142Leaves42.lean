import NineSeparatedSubsetSums.Adaptive144Third142State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third142Proof640 : runCachedNode 511 130737 Adaptive144Third142Node640 = false := by
  decide +kernel

#print axioms adaptive144Third142Proof640

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third142Proof565 : runCachedNode 511 130737 Adaptive144Third142Node565 = false := by
  decide +kernel

#print axioms adaptive144Third142Proof565

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third142Proof445 : runCachedNode 511 130737 Adaptive144Third142Node445 = false := by
  decide +kernel

#print axioms adaptive144Third142Proof445

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third142Proof485 : runCachedNode 511 130737 Adaptive144Third142Node485 = false := by
  decide +kernel

#print axioms adaptive144Third142Proof485

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third142Proof525 : runCachedNode 511 130737 Adaptive144Third142Node525 = false := by
  decide +kernel

#print axioms adaptive144Third142Proof525

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third142Proof11 : runCachedNode 511 130737 Adaptive144Third142Node11 = false := by
  decide +kernel

#print axioms adaptive144Third142Proof11

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third142Proof253 : runCachedNode 511 130737 Adaptive144Third142Node253 = false := by
  decide +kernel

#print axioms adaptive144Third142Proof253

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third142Proof643 : runCachedNode 511 130737 Adaptive144Third142Node643 = false := by
  decide +kernel

#print axioms adaptive144Third142Proof643

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third142Proof369 : runCachedNode 511 130737 Adaptive144Third142Node369 = false := by
  decide +kernel

#print axioms adaptive144Third142Proof369

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third142Proof523 : runCachedNode 511 130737 Adaptive144Third142Node523 = false := by
  decide +kernel

#print axioms adaptive144Third142Proof523

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third142Proof641 : runCachedNode 511 130737 Adaptive144Third142Node641 = false := by
  decide +kernel

#print axioms adaptive144Third142Proof641

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third142Proof320 : runCachedNode 511 130737 Adaptive144Third142Node320 = false := by
  decide +kernel

#print axioms adaptive144Third142Proof320

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third142Proof486 : runCachedNode 511 130737 Adaptive144Third142Node486 = false := by
  decide +kernel

#print axioms adaptive144Third142Proof486

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third142Proof158 : runCachedNode 511 130737 Adaptive144Third142Node158 = false := by
  decide +kernel

#print axioms adaptive144Third142Proof158

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third142Proof483 : runCachedNode 511 130737 Adaptive144Third142Node483 = false := by
  decide +kernel

#print axioms adaptive144Third142Proof483

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third142Proof599 : runCachedNode 511 130737 Adaptive144Third142Node599 = false := by
  decide +kernel

#print axioms adaptive144Third142Proof599

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third142Proof366 : runCachedNode 511 130737 Adaptive144Third142Node366 = false := by
  decide +kernel

#print axioms adaptive144Third142Proof366

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third142Proof186 : runCachedNode 511 130737 Adaptive144Third142Node186 = false := by
  decide +kernel

#print axioms adaptive144Third142Proof186

end NineSeparatedSubsetSums
