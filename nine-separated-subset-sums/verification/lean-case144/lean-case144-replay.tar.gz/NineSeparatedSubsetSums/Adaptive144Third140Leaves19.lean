import NineSeparatedSubsetSums.Adaptive144Third140State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof491 : runCachedNode 511 130381 Adaptive144Third140Node491 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof491

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof494 : runCachedNode 511 130381 Adaptive144Third140Node494 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof494

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof316 : runCachedNode 511 130381 Adaptive144Third140Node316 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof316

end NineSeparatedSubsetSums
