import NineSeparatedSubsetSums.Adaptive144Third137State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third137Proof122 : runCachedNode 511 129993 Adaptive144Third137Node122 = false := by
  decide +kernel

#print axioms adaptive144Third137Proof122

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third137Proof18 : runCachedNode 511 129993 Adaptive144Third137Node18 = false := by
  decide +kernel

#print axioms adaptive144Third137Proof18

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third137Proof118 : runCachedNode 511 129993 Adaptive144Third137Node118 = false := by
  decide +kernel

#print axioms adaptive144Third137Proof118

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third137Proof97 : runCachedNode 511 129993 Adaptive144Third137Node97 = false := by
  decide +kernel

#print axioms adaptive144Third137Proof97

end NineSeparatedSubsetSums
