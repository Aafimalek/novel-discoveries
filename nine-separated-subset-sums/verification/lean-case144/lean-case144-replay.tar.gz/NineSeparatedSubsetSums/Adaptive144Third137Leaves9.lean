import NineSeparatedSubsetSums.Adaptive144Third137State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third137Proof13 : runCachedNode 511 129993 Adaptive144Third137Node13 = false := by
  decide +kernel

#print axioms adaptive144Third137Proof13

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third137Proof120 : runCachedNode 511 129993 Adaptive144Third137Node120 = false := by
  decide +kernel

#print axioms adaptive144Third137Proof120

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third137Proof66 : runCachedNode 511 129993 Adaptive144Third137Node66 = false := by
  decide +kernel

#print axioms adaptive144Third137Proof66

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third137Proof91 : runCachedNode 511 129993 Adaptive144Third137Node91 = false := by
  decide +kernel

#print axioms adaptive144Third137Proof91

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third137Proof148 : runCachedNode 511 129993 Adaptive144Third137Node148 = false := by
  decide +kernel

#print axioms adaptive144Third137Proof148

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third137Proof176 : runCachedNode 511 129993 Adaptive144Third137Node176 = false := by
  decide +kernel

#print axioms adaptive144Third137Proof176

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third137Proof90 : runCachedNode 511 129993 Adaptive144Third137Node90 = false := by
  decide +kernel

#print axioms adaptive144Third137Proof90

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third137Proof47 : runCachedNode 511 129993 Adaptive144Third137Node47 = false := by
  decide +kernel

#print axioms adaptive144Third137Proof47

end NineSeparatedSubsetSums
