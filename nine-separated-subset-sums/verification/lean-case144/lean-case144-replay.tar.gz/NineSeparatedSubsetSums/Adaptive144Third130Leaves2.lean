import NineSeparatedSubsetSums.Adaptive144Third130State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third130Proof14 : runCachedNode 511 128721 Adaptive144Third130Node14 = false := by
  decide +kernel

#print axioms adaptive144Third130Proof14

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third130Proof12 : runCachedNode 511 128721 Adaptive144Third130Node12 = false := by
  decide +kernel

#print axioms adaptive144Third130Proof12

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third130Proof11 : runCachedNode 511 128721 Adaptive144Third130Node11 = false := by
  decide +kernel

#print axioms adaptive144Third130Proof11

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third130Proof9 : runCachedNode 511 128721 Adaptive144Third130Node9 = false := by
  decide +kernel

#print axioms adaptive144Third130Proof9

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third130Proof8 : runCachedNode 511 128721 Adaptive144Third130Node8 = false := by
  decide +kernel

#print axioms adaptive144Third130Proof8

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third130Proof7 : runCachedNode 511 128721 Adaptive144Third130Node7 = false := by
  decide +kernel

#print axioms adaptive144Third130Proof7

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third130Proof6 : runCachedNode 511 128721 Adaptive144Third130Node6 = false := by
  decide +kernel

#print axioms adaptive144Third130Proof6

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third130Proof5 : runCachedNode 511 128721 Adaptive144Third130Node5 = false := by
  decide +kernel

#print axioms adaptive144Third130Proof5

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third130Proof4 : runCachedNode 511 128721 Adaptive144Third130Node4 = false := by
  decide +kernel

#print axioms adaptive144Third130Proof4

end NineSeparatedSubsetSums
