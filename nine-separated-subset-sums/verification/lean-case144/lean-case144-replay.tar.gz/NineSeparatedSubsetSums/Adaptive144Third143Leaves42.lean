import NineSeparatedSubsetSums.Adaptive144Third143State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third143Proof482 : runCachedNode 511 130885 Adaptive144Third143Node482 = false := by
  decide +kernel

#print axioms adaptive144Third143Proof482

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third143Proof96 : runCachedNode 511 130885 Adaptive144Third143Node96 = false := by
  decide +kernel

#print axioms adaptive144Third143Proof96

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third143Proof68 : runCachedNode 511 130885 Adaptive144Third143Node68 = false := by
  decide +kernel

#print axioms adaptive144Third143Proof68

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third143Proof11 : runCachedNode 511 130885 Adaptive144Third143Node11 = false := by
  decide +kernel

#print axioms adaptive144Third143Proof11

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third143Proof293 : runCachedNode 511 130885 Adaptive144Third143Node293 = false := by
  decide +kernel

#print axioms adaptive144Third143Proof293

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third143Proof359 : runCachedNode 511 130885 Adaptive144Third143Node359 = false := by
  decide +kernel

#print axioms adaptive144Third143Proof359

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third143Proof317 : runCachedNode 511 130885 Adaptive144Third143Node317 = false := by
  decide +kernel

#print axioms adaptive144Third143Proof317

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third143Proof187 : runCachedNode 511 130885 Adaptive144Third143Node187 = false := by
  decide +kernel

#print axioms adaptive144Third143Proof187

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third143Proof407 : runCachedNode 511 130885 Adaptive144Third143Node407 = false := by
  decide +kernel

#print axioms adaptive144Third143Proof407

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third143Proof643 : runCachedNode 511 130885 Adaptive144Third143Node643 = false := by
  decide +kernel

#print axioms adaptive144Third143Proof643

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third143Proof556 : runCachedNode 511 130885 Adaptive144Third143Node556 = false := by
  decide +kernel

#print axioms adaptive144Third143Proof556

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third143Proof316 : runCachedNode 511 130885 Adaptive144Third143Node316 = false := by
  decide +kernel

#print axioms adaptive144Third143Proof316

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third143Proof642 : runCachedNode 511 130885 Adaptive144Third143Node642 = false := by
  decide +kernel

#print axioms adaptive144Third143Proof642

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third143Proof315 : runCachedNode 511 130885 Adaptive144Third143Node315 = false := by
  decide +kernel

#print axioms adaptive144Third143Proof315

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third143Proof231 : runCachedNode 511 130885 Adaptive144Third143Node231 = false := by
  decide +kernel

#print axioms adaptive144Third143Proof231

end NineSeparatedSubsetSums
