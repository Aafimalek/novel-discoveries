import NineSeparatedSubsetSums.EightPoint144_117PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint144_117PackedAnchor1Part2 :
    ∀ j : Fin 7, 2392629 ≤ FourPointNumeric.octPackedCharge 144 117 20 packedOct144_117_1
      (2*((j.val : Int)+240)+0) := by decide +kernel

end NineSeparatedSubsetSums
