import NineSeparatedSubsetSums.Adaptive144Third143State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third143Proof366 : runCachedNode 511 130885 Adaptive144Third143Node366 = false := by
  decide +kernel

#print axioms adaptive144Third143Proof366

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third143Proof71 : runCachedNode 511 130885 Adaptive144Third143Node71 = false := by
  decide +kernel

#print axioms adaptive144Third143Proof71

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third143Proof409 : runCachedNode 511 130885 Adaptive144Third143Node409 = false := by
  decide +kernel

#print axioms adaptive144Third143Proof409

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third143Proof485 : runCachedNode 511 130885 Adaptive144Third143Node485 = false := by
  decide +kernel

#print axioms adaptive144Third143Proof485

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third143Proof320 : runCachedNode 511 130885 Adaptive144Third143Node320 = false := by
  decide +kernel

#print axioms adaptive144Third143Proof320

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third143Proof614 : runCachedNode 511 130885 Adaptive144Third143Node614 = false := by
  decide +kernel

#print axioms adaptive144Third143Proof614

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third143Proof188 : runCachedNode 511 130885 Adaptive144Third143Node188 = false := by
  decide +kernel

#print axioms adaptive144Third143Proof188

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third143Proof295 : runCachedNode 511 130885 Adaptive144Third143Node295 = false := by
  decide +kernel

#print axioms adaptive144Third143Proof295

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third143Proof515 : runCachedNode 511 130885 Adaptive144Third143Node515 = false := by
  decide +kernel

#print axioms adaptive144Third143Proof515

end NineSeparatedSubsetSums
