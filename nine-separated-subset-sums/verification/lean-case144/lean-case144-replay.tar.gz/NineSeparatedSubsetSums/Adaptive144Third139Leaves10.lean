import NineSeparatedSubsetSums.Adaptive144Third139State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third139Proof95 : runCachedNode 511 130274 Adaptive144Third139Node95 = false := by
  decide +kernel

#print axioms adaptive144Third139Proof95

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third139Proof151 : runCachedNode 511 130274 Adaptive144Third139Node151 = false := by
  decide +kernel

#print axioms adaptive144Third139Proof151

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third139Proof124 : runCachedNode 511 130274 Adaptive144Third139Node124 = false := by
  decide +kernel

#print axioms adaptive144Third139Proof124

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third139Proof48 : runCachedNode 511 130274 Adaptive144Third139Node48 = false := by
  decide +kernel

#print axioms adaptive144Third139Proof48

end NineSeparatedSubsetSums
