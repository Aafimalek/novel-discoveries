import NineSeparatedSubsetSums.Adaptive144Third141State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third141Proof391 : runCachedNode 511 130584 Adaptive144Third141Node391 = false := by
  decide +kernel

#print axioms adaptive144Third141Proof391

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third141Proof233 : runCachedNode 511 130584 Adaptive144Third141Node233 = false := by
  decide +kernel

#print axioms adaptive144Third141Proof233

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third141Proof167 : runCachedNode 511 130584 Adaptive144Third141Node167 = false := by
  decide +kernel

#print axioms adaptive144Third141Proof167

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third141Proof168 : runCachedNode 511 130584 Adaptive144Third141Node168 = false := by
  decide +kernel

#print axioms adaptive144Third141Proof168

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third141Proof29 : runCachedNode 511 130584 Adaptive144Third141Node29 = false := by
  decide +kernel

#print axioms adaptive144Third141Proof29

end NineSeparatedSubsetSums
