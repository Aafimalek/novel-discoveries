import NineSeparatedSubsetSums.Adaptive144Third107Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint144Checked

namespace NineSeparatedSubsetSums


theorem adaptive144Third107 : NoDescendingTailAfterThird 144 107 :=
  noDescendingThirdTail_of_cached 144 107 112221 (fun t ht nd => max148_second144_fourPoint_moment_bound (107::t) (by simp [ht]) nd) adaptive144Third107Proof0

#print axioms adaptive144Third107

end NineSeparatedSubsetSums
