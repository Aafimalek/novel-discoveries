import NineSeparatedSubsetSums.Adaptive144Third143State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third143Proof257 : runCachedNode 511 130885 Adaptive144Third143Node257 = false := by
  decide +kernel

#print axioms adaptive144Third143Proof257

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third143Proof131 : runCachedNode 511 130885 Adaptive144Third143Node131 = false := by
  decide +kernel

#print axioms adaptive144Third143Proof131

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third143Proof162 : runCachedNode 511 130885 Adaptive144Third143Node162 = false := by
  decide +kernel

#print axioms adaptive144Third143Proof162

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third143Proof124 : runCachedNode 511 130885 Adaptive144Third143Node124 = false := by
  decide +kernel

#print axioms adaptive144Third143Proof124

end NineSeparatedSubsetSums
