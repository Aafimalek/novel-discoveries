import NineSeparatedSubsetSums.Adaptive144Third139State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third139Proof44 : runCachedNode 511 130274 Adaptive144Third139Node44 = false := by
  decide +kernel

#print axioms adaptive144Third139Proof44

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third139Proof244 : runCachedNode 511 130274 Adaptive144Third139Node244 = false := by
  decide +kernel

#print axioms adaptive144Third139Proof244

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third139Proof123 : runCachedNode 511 130274 Adaptive144Third139Node123 = false := by
  decide +kernel

#print axioms adaptive144Third139Proof123

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third139Proof145 : runCachedNode 511 130274 Adaptive144Third139Node145 = false := by
  decide +kernel

#print axioms adaptive144Third139Proof145

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third139Proof99 : runCachedNode 511 130274 Adaptive144Third139Node99 = false := by
  decide +kernel

#print axioms adaptive144Third139Proof99

end NineSeparatedSubsetSums
