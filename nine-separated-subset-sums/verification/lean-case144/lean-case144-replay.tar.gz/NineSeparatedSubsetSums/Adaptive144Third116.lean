import NineSeparatedSubsetSums.Adaptive144Third116Joins0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint144Checked

namespace NineSeparatedSubsetSums


theorem adaptive144Third116 : NoDescendingTailAfterThird 144 116 :=
  noDescendingThirdTail_of_cached 144 116 112221 (fun t ht nd => max148_second144_fourPoint_moment_bound (116::t) (by simp [ht]) nd) adaptive144Third116Proof0

#print axioms adaptive144Third116

end NineSeparatedSubsetSums
