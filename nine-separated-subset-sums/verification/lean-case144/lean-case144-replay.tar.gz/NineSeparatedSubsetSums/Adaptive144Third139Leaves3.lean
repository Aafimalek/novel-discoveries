import NineSeparatedSubsetSums.Adaptive144Third139State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third139Proof213 : runCachedNode 511 130274 Adaptive144Third139Node213 = false := by
  decide +kernel

#print axioms adaptive144Third139Proof213

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third139Proof96 : runCachedNode 511 130274 Adaptive144Third139Node96 = false := by
  decide +kernel

#print axioms adaptive144Third139Proof96

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third139Proof155 : runCachedNode 511 130274 Adaptive144Third139Node155 = false := by
  decide +kernel

#print axioms adaptive144Third139Proof155

end NineSeparatedSubsetSums
