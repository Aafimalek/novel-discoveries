import NineSeparatedSubsetSums.Adaptive144Third136State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third136Proof16 : runCachedNode 511 129800 Adaptive144Third136Node16 = false := by
  decide +kernel

#print axioms adaptive144Third136Proof16

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third136Proof102 : runCachedNode 511 129800 Adaptive144Third136Node102 = false := by
  decide +kernel

#print axioms adaptive144Third136Proof102

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third136Proof76 : runCachedNode 511 129800 Adaptive144Third136Node76 = false := by
  decide +kernel

#print axioms adaptive144Third136Proof76

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third136Proof104 : runCachedNode 511 129800 Adaptive144Third136Node104 = false := by
  decide +kernel

#print axioms adaptive144Third136Proof104

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third136Proof46 : runCachedNode 511 129800 Adaptive144Third136Node46 = false := by
  decide +kernel

#print axioms adaptive144Third136Proof46

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third136Proof26 : runCachedNode 511 129800 Adaptive144Third136Node26 = false := by
  decide +kernel

#print axioms adaptive144Third136Proof26

end NineSeparatedSubsetSums
