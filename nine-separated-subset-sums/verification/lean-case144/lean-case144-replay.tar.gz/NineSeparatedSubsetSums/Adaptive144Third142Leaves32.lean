import NineSeparatedSubsetSums.Adaptive144Third142State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third142Proof609 : runCachedNode 511 130737 Adaptive144Third142Node609 = false := by
  decide +kernel

#print axioms adaptive144Third142Proof609

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third142Proof134 : runCachedNode 511 130737 Adaptive144Third142Node134 = false := by
  decide +kernel

#print axioms adaptive144Third142Proof134

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third142Proof74 : runCachedNode 511 130737 Adaptive144Third142Node74 = false := by
  decide +kernel

#print axioms adaptive144Third142Proof74

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third142Proof106 : runCachedNode 511 130737 Adaptive144Third142Node106 = false := by
  decide +kernel

#print axioms adaptive144Third142Proof106

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third142Proof397 : runCachedNode 511 130737 Adaptive144Third142Node397 = false := by
  decide +kernel

#print axioms adaptive144Third142Proof397

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third142Proof372 : runCachedNode 511 130737 Adaptive144Third142Node372 = false := by
  decide +kernel

#print axioms adaptive144Third142Proof372

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third142Proof102 : runCachedNode 511 130737 Adaptive144Third142Node102 = false := by
  decide +kernel

#print axioms adaptive144Third142Proof102

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third142Proof207 : runCachedNode 511 130737 Adaptive144Third142Node207 = false := by
  decide +kernel

#print axioms adaptive144Third142Proof207

end NineSeparatedSubsetSums
