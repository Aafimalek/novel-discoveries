import NineSeparatedSubsetSums.Adaptive144Third139State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third139Proof245 : runCachedNode 511 130274 Adaptive144Third139Node245 = false := by
  decide +kernel

#print axioms adaptive144Third139Proof245

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third139Proof18 : runCachedNode 511 130274 Adaptive144Third139Node18 = false := by
  decide +kernel

#print axioms adaptive144Third139Proof18

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third139Proof118 : runCachedNode 511 130274 Adaptive144Third139Node118 = false := by
  decide +kernel

#print axioms adaptive144Third139Proof118

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third139Proof2 : runCachedNode 511 130274 Adaptive144Third139Node2 = false := by
  decide +kernel

#print axioms adaptive144Third139Proof2

end NineSeparatedSubsetSums
