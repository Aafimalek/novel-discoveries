import NineSeparatedSubsetSums.Adaptive144Third142State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third142Proof579 : runCachedNode 511 130737 Adaptive144Third142Node579 = false := by
  decide +kernel

#print axioms adaptive144Third142Proof579

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third142Proof170 : runCachedNode 511 130737 Adaptive144Third142Node170 = false := by
  decide +kernel

#print axioms adaptive144Third142Proof170

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third142Proof296 : runCachedNode 511 130737 Adaptive144Third142Node296 = false := by
  decide +kernel

#print axioms adaptive144Third142Proof296

end NineSeparatedSubsetSums
