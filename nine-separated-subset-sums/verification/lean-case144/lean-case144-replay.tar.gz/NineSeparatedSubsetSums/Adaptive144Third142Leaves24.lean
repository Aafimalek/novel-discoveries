import NineSeparatedSubsetSums.Adaptive144Third142State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third142Proof409 : runCachedNode 511 130737 Adaptive144Third142Node409 = false := by
  decide +kernel

#print axioms adaptive144Third142Proof409

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third142Proof78 : runCachedNode 511 130737 Adaptive144Third142Node78 = false := by
  decide +kernel

#print axioms adaptive144Third142Proof78

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third142Proof401 : runCachedNode 511 130737 Adaptive144Third142Node401 = false := by
  decide +kernel

#print axioms adaptive144Third142Proof401

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third142Proof104 : runCachedNode 511 130737 Adaptive144Third142Node104 = false := by
  decide +kernel

#print axioms adaptive144Third142Proof104

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third142Proof100 : runCachedNode 511 130737 Adaptive144Third142Node100 = false := by
  decide +kernel

#print axioms adaptive144Third142Proof100

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third142Proof27 : runCachedNode 511 130737 Adaptive144Third142Node27 = false := by
  decide +kernel

#print axioms adaptive144Third142Proof27

end NineSeparatedSubsetSums
