import NineSeparatedSubsetSums.Adaptive144Third135State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third135Proof19 : runCachedNode 511 129692 Adaptive144Third135Node19 = false := by
  decide +kernel

#print axioms adaptive144Third135Proof19

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third135Proof100 : runCachedNode 511 129692 Adaptive144Third135Node100 = false := by
  decide +kernel

#print axioms adaptive144Third135Proof100

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third135Proof67 : runCachedNode 511 129692 Adaptive144Third135Node67 = false := by
  decide +kernel

#print axioms adaptive144Third135Proof67

end NineSeparatedSubsetSums
