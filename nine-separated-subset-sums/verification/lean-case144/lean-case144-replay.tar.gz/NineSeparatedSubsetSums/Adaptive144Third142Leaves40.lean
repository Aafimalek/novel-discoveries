import NineSeparatedSubsetSums.Adaptive144Third142State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third142Proof645 : runCachedNode 511 130737 Adaptive144Third142Node645 = false := by
  decide +kernel

#print axioms adaptive144Third142Proof645

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third142Proof370 : runCachedNode 511 130737 Adaptive144Third142Node370 = false := by
  decide +kernel

#print axioms adaptive144Third142Proof370

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third142Proof649 : runCachedNode 511 130737 Adaptive144Third142Node649 = false := by
  decide +kernel

#print axioms adaptive144Third142Proof649

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third142Proof571 : runCachedNode 511 130737 Adaptive144Third142Node571 = false := by
  decide +kernel

#print axioms adaptive144Third142Proof571

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third142Proof160 : runCachedNode 511 130737 Adaptive144Third142Node160 = false := by
  decide +kernel

#print axioms adaptive144Third142Proof160

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third142Proof232 : runCachedNode 511 130737 Adaptive144Third142Node232 = false := by
  decide +kernel

#print axioms adaptive144Third142Proof232

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third142Proof293 : runCachedNode 511 130737 Adaptive144Third142Node293 = false := by
  decide +kernel

#print axioms adaptive144Third142Proof293

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third142Proof196 : runCachedNode 511 130737 Adaptive144Third142Node196 = false := by
  decide +kernel

#print axioms adaptive144Third142Proof196

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third142Proof368 : runCachedNode 511 130737 Adaptive144Third142Node368 = false := by
  decide +kernel

#print axioms adaptive144Third142Proof368

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third142Proof229 : runCachedNode 511 130737 Adaptive144Third142Node229 = false := by
  decide +kernel

#print axioms adaptive144Third142Proof229

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third142Proof602 : runCachedNode 511 130737 Adaptive144Third142Node602 = false := by
  decide +kernel

#print axioms adaptive144Third142Proof602

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third142Proof650 : runCachedNode 511 130737 Adaptive144Third142Node650 = false := by
  decide +kernel

#print axioms adaptive144Third142Proof650

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third142Proof644 : runCachedNode 511 130737 Adaptive144Third142Node644 = false := by
  decide +kernel

#print axioms adaptive144Third142Proof644

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third142Proof527 : runCachedNode 511 130737 Adaptive144Third142Node527 = false := by
  decide +kernel

#print axioms adaptive144Third142Proof527

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third142Proof185 : runCachedNode 511 130737 Adaptive144Third142Node185 = false := by
  decide +kernel

#print axioms adaptive144Third142Proof185

end NineSeparatedSubsetSums
