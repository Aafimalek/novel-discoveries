import NineSeparatedSubsetSums.Adaptive144Third140State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof357 : runCachedNode 511 130381 Adaptive144Third140Node357 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof357

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof110 : runCachedNode 511 130381 Adaptive144Third140Node110 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof110

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof595 : runCachedNode 511 130381 Adaptive144Third140Node595 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof595

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof636 : runCachedNode 511 130381 Adaptive144Third140Node636 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof636

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof81 : runCachedNode 511 130381 Adaptive144Third140Node81 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof81

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof170 : runCachedNode 511 130381 Adaptive144Third140Node170 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof170

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof255 : runCachedNode 511 130381 Adaptive144Third140Node255 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof255

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof36 : runCachedNode 511 130381 Adaptive144Third140Node36 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof36

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof108 : runCachedNode 511 130381 Adaptive144Third140Node108 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof108

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof481 : runCachedNode 511 130381 Adaptive144Third140Node481 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof481

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof62 : runCachedNode 511 130381 Adaptive144Third140Node62 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof62

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof6 : runCachedNode 511 130381 Adaptive144Third140Node6 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof6

end NineSeparatedSubsetSums
