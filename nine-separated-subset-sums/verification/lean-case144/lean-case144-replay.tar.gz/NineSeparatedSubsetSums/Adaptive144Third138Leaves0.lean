import NineSeparatedSubsetSums.Adaptive144Third138State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third138Proof19 : runCachedNode 511 130126 Adaptive144Third138Node19 = false := by
  decide +kernel

#print axioms adaptive144Third138Proof19

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third138Proof40 : runCachedNode 511 130126 Adaptive144Third138Node40 = false := by
  decide +kernel

#print axioms adaptive144Third138Proof40

end NineSeparatedSubsetSums
