import NineSeparatedSubsetSums.Adaptive144Third134State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third134Proof20 : runCachedNode 511 129525 Adaptive144Third134Node20 = false := by
  decide +kernel

#print axioms adaptive144Third134Proof20

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third134Proof15 : runCachedNode 511 129525 Adaptive144Third134Node15 = false := by
  decide +kernel

#print axioms adaptive144Third134Proof15

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third134Proof9 : runCachedNode 511 129525 Adaptive144Third134Node9 = false := by
  decide +kernel

#print axioms adaptive144Third134Proof9

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third134Proof27 : runCachedNode 511 129525 Adaptive144Third134Node27 = false := by
  decide +kernel

#print axioms adaptive144Third134Proof27

end NineSeparatedSubsetSums
