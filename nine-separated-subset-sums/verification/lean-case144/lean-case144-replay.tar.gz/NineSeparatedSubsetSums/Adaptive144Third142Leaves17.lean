import NineSeparatedSubsetSums.Adaptive144Third142State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third142Proof405 : runCachedNode 511 130737 Adaptive144Third142Node405 = false := by
  decide +kernel

#print axioms adaptive144Third142Proof405

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third142Proof263 : runCachedNode 511 130737 Adaptive144Third142Node263 = false := by
  decide +kernel

#print axioms adaptive144Third142Proof263

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third142Proof203 : runCachedNode 511 130737 Adaptive144Third142Node203 = false := by
  decide +kernel

#print axioms adaptive144Third142Proof203

end NineSeparatedSubsetSums
