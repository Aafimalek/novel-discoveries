import NineSeparatedSubsetSums.Adaptive144Third135State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third135Proof20 : runCachedNode 511 129692 Adaptive144Third135Node20 = false := by
  decide +kernel

#print axioms adaptive144Third135Proof20

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third135Proof16 : runCachedNode 511 129692 Adaptive144Third135Node16 = false := by
  decide +kernel

#print axioms adaptive144Third135Proof16

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third135Proof92 : runCachedNode 511 129692 Adaptive144Third135Node92 = false := by
  decide +kernel

#print axioms adaptive144Third135Proof92

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third135Proof78 : runCachedNode 511 129692 Adaptive144Third135Node78 = false := by
  decide +kernel

#print axioms adaptive144Third135Proof78

end NineSeparatedSubsetSums
