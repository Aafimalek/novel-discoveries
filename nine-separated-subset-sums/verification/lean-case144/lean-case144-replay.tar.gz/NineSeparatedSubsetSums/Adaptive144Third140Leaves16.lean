import NineSeparatedSubsetSums.Adaptive144Third140State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof327 : runCachedNode 511 130381 Adaptive144Third140Node327 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof327

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof136 : runCachedNode 511 130381 Adaptive144Third140Node136 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof136

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof154 : runCachedNode 511 130381 Adaptive144Third140Node154 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof154

end NineSeparatedSubsetSums
