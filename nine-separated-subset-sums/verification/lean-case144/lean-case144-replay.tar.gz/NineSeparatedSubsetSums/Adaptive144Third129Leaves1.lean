import NineSeparatedSubsetSums.Adaptive144Third129State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third129Proof15 : runCachedNode 511 128455 Adaptive144Third129Node15 = false := by
  decide +kernel

#print axioms adaptive144Third129Proof15

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third129Proof14 : runCachedNode 511 128455 Adaptive144Third129Node14 = false := by
  decide +kernel

#print axioms adaptive144Third129Proof14

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third129Proof12 : runCachedNode 511 128455 Adaptive144Third129Node12 = false := by
  decide +kernel

#print axioms adaptive144Third129Proof12

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third129Proof13 : runCachedNode 511 128455 Adaptive144Third129Node13 = false := by
  decide +kernel

#print axioms adaptive144Third129Proof13

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third129Proof11 : runCachedNode 511 128455 Adaptive144Third129Node11 = false := by
  decide +kernel

#print axioms adaptive144Third129Proof11

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third129Proof10 : runCachedNode 511 128455 Adaptive144Third129Node10 = false := by
  decide +kernel

#print axioms adaptive144Third129Proof10

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third129Proof9 : runCachedNode 511 128455 Adaptive144Third129Node9 = false := by
  decide +kernel

#print axioms adaptive144Third129Proof9

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third129Proof8 : runCachedNode 511 128455 Adaptive144Third129Node8 = false := by
  decide +kernel

#print axioms adaptive144Third129Proof8

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third129Proof7 : runCachedNode 511 128455 Adaptive144Third129Node7 = false := by
  decide +kernel

#print axioms adaptive144Third129Proof7

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third129Proof6 : runCachedNode 511 128455 Adaptive144Third129Node6 = false := by
  decide +kernel

#print axioms adaptive144Third129Proof6

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third129Proof3 : runCachedNode 511 128455 Adaptive144Third129Node3 = false := by
  decide +kernel

#print axioms adaptive144Third129Proof3

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third129Proof1 : runCachedNode 511 128455 Adaptive144Third129Node1 = false := by
  decide +kernel

#print axioms adaptive144Third129Proof1

end NineSeparatedSubsetSums
