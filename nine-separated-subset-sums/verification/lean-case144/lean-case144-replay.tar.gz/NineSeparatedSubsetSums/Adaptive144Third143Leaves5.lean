import NineSeparatedSubsetSums.Adaptive144Third143State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third143Proof573 : runCachedNode 511 130885 Adaptive144Third143Node573 = false := by
  decide +kernel

#print axioms adaptive144Third143Proof573

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third143Proof16 : runCachedNode 511 130885 Adaptive144Third143Node16 = false := by
  decide +kernel

#print axioms adaptive144Third143Proof16

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third143Proof28 : runCachedNode 511 130885 Adaptive144Third143Node28 = false := by
  decide +kernel

#print axioms adaptive144Third143Proof28

end NineSeparatedSubsetSums
