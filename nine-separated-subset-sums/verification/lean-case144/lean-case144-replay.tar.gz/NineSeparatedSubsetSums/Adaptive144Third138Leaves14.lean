import NineSeparatedSubsetSums.Adaptive144Third138State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third138Proof209 : runCachedNode 511 130126 Adaptive144Third138Node209 = false := by
  decide +kernel

#print axioms adaptive144Third138Proof209

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third138Proof12 : runCachedNode 511 130126 Adaptive144Third138Node12 = false := by
  decide +kernel

#print axioms adaptive144Third138Proof12

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third138Proof91 : runCachedNode 511 130126 Adaptive144Third138Node91 = false := by
  decide +kernel

#print axioms adaptive144Third138Proof91

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third138Proof178 : runCachedNode 511 130126 Adaptive144Third138Node178 = false := by
  decide +kernel

#print axioms adaptive144Third138Proof178

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third138Proof177 : runCachedNode 511 130126 Adaptive144Third138Node177 = false := by
  decide +kernel

#print axioms adaptive144Third138Proof177

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third138Proof147 : runCachedNode 511 130126 Adaptive144Third138Node147 = false := by
  decide +kernel

#print axioms adaptive144Third138Proof147

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third138Proof174 : runCachedNode 511 130126 Adaptive144Third138Node174 = false := by
  decide +kernel

#print axioms adaptive144Third138Proof174

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third138Proof87 : runCachedNode 511 130126 Adaptive144Third138Node87 = false := by
  decide +kernel

#print axioms adaptive144Third138Proof87

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third138Proof81 : runCachedNode 511 130126 Adaptive144Third138Node81 = false := by
  decide +kernel

#print axioms adaptive144Third138Proof81

end NineSeparatedSubsetSums
