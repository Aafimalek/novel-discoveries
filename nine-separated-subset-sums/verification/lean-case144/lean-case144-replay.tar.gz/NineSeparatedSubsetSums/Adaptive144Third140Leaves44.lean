import NineSeparatedSubsetSums.Adaptive144Third140State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof9 : runCachedNode 511 130381 Adaptive144Third140Node9 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof9

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof524 : runCachedNode 511 130381 Adaptive144Third140Node524 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof524

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof518 : runCachedNode 511 130381 Adaptive144Third140Node518 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof518

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof292 : runCachedNode 511 130381 Adaptive144Third140Node292 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof292

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof384 : runCachedNode 511 130381 Adaptive144Third140Node384 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof384

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof133 : runCachedNode 511 130381 Adaptive144Third140Node133 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof133

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof355 : runCachedNode 511 130381 Adaptive144Third140Node355 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof355

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof523 : runCachedNode 511 130381 Adaptive144Third140Node523 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof523

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof386 : runCachedNode 511 130381 Adaptive144Third140Node386 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof386

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof564 : runCachedNode 511 130381 Adaptive144Third140Node564 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof564

end NineSeparatedSubsetSums
