import NineSeparatedSubsetSums.Adaptive144Third138State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third138Proof214 : runCachedNode 511 130126 Adaptive144Third138Node214 = false := by
  decide +kernel

#print axioms adaptive144Third138Proof214

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third138Proof43 : runCachedNode 511 130126 Adaptive144Third138Node43 = false := by
  decide +kernel

#print axioms adaptive144Third138Proof43

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third138Proof149 : runCachedNode 511 130126 Adaptive144Third138Node149 = false := by
  decide +kernel

#print axioms adaptive144Third138Proof149

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third138Proof204 : runCachedNode 511 130126 Adaptive144Third138Node204 = false := by
  decide +kernel

#print axioms adaptive144Third138Proof204

end NineSeparatedSubsetSums
