import NineSeparatedSubsetSums.Adaptive144Third140State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof16 : runCachedNode 511 130381 Adaptive144Third140Node16 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof16

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof324 : runCachedNode 511 130381 Adaptive144Third140Node324 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof324

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof2 : runCachedNode 511 130381 Adaptive144Third140Node2 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof2

end NineSeparatedSubsetSums
