import NineSeparatedSubsetSums.Adaptive144Third143State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third143Proof664 : runCachedNode 511 130885 Adaptive144Third143Node664 = false := by
  decide +kernel

#print axioms adaptive144Third143Proof664

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third143Proof328 : runCachedNode 511 130885 Adaptive144Third143Node328 = false := by
  decide +kernel

#print axioms adaptive144Third143Proof328

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third143Proof54 : runCachedNode 511 130885 Adaptive144Third143Node54 = false := by
  decide +kernel

#print axioms adaptive144Third143Proof54

end NineSeparatedSubsetSums
