import NineSeparatedSubsetSums.Adaptive144Third142State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third142Proof168 : runCachedNode 511 130737 Adaptive144Third142Node168 = false := by
  decide +kernel

#print axioms adaptive144Third142Proof168

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third142Proof237 : runCachedNode 511 130737 Adaptive144Third142Node237 = false := by
  decide +kernel

#print axioms adaptive144Third142Proof237

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third142Proof533 : runCachedNode 511 130737 Adaptive144Third142Node533 = false := by
  decide +kernel

#print axioms adaptive144Third142Proof533

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third142Proof227 : runCachedNode 511 130737 Adaptive144Third142Node227 = false := by
  decide +kernel

#print axioms adaptive144Third142Proof227

end NineSeparatedSubsetSums
