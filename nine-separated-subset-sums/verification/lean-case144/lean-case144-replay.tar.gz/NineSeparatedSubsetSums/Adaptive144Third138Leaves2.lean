import NineSeparatedSubsetSums.Adaptive144Third138State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third138Proof94 : runCachedNode 511 130126 Adaptive144Third138Node94 = false := by
  decide +kernel

#print axioms adaptive144Third138Proof94

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third138Proof176 : runCachedNode 511 130126 Adaptive144Third138Node176 = false := by
  decide +kernel

#print axioms adaptive144Third138Proof176

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third138Proof23 : runCachedNode 511 130126 Adaptive144Third138Node23 = false := by
  decide +kernel

#print axioms adaptive144Third138Proof23

end NineSeparatedSubsetSums
