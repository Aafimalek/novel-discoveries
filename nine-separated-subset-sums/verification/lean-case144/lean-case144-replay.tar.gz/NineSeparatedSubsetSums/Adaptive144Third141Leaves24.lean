import NineSeparatedSubsetSums.Adaptive144Third141State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third141Proof137 : runCachedNode 511 130584 Adaptive144Third141Node137 = false := by
  decide +kernel

#print axioms adaptive144Third141Proof137

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third141Proof194 : runCachedNode 511 130584 Adaptive144Third141Node194 = false := by
  decide +kernel

#print axioms adaptive144Third141Proof194

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third141Proof50 : runCachedNode 511 130584 Adaptive144Third141Node50 = false := by
  decide +kernel

#print axioms adaptive144Third141Proof50

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third141Proof307 : runCachedNode 511 130584 Adaptive144Third141Node307 = false := by
  decide +kernel

#print axioms adaptive144Third141Proof307

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third141Proof14 : runCachedNode 511 130584 Adaptive144Third141Node14 = false := by
  decide +kernel

#print axioms adaptive144Third141Proof14

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third141Proof86 : runCachedNode 511 130584 Adaptive144Third141Node86 = false := by
  decide +kernel

#print axioms adaptive144Third141Proof86

end NineSeparatedSubsetSums
