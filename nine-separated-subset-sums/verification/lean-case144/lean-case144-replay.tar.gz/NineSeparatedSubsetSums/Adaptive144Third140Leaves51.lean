import NineSeparatedSubsetSums.Adaptive144Third140State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof283 : runCachedNode 511 130381 Adaptive144Third140Node283 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof283

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof287 : runCachedNode 511 130381 Adaptive144Third140Node287 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof287

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof480 : runCachedNode 511 130381 Adaptive144Third140Node480 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof480

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof7 : runCachedNode 511 130381 Adaptive144Third140Node7 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof7

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof380 : runCachedNode 511 130381 Adaptive144Third140Node380 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof380

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof458 : runCachedNode 511 130381 Adaptive144Third140Node458 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof458

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof80 : runCachedNode 511 130381 Adaptive144Third140Node80 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof80

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof314 : runCachedNode 511 130381 Adaptive144Third140Node314 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof314

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof479 : runCachedNode 511 130381 Adaptive144Third140Node479 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof479

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof589 : runCachedNode 511 130381 Adaptive144Third140Node589 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof589

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof251 : runCachedNode 511 130381 Adaptive144Third140Node251 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof251

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof517 : runCachedNode 511 130381 Adaptive144Third140Node517 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof517

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof713 : runCachedNode 511 130381 Adaptive144Third140Node713 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof713

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof106 : runCachedNode 511 130381 Adaptive144Third140Node106 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof106

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof190 : runCachedNode 511 130381 Adaptive144Third140Node190 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof190

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof286 : runCachedNode 511 130381 Adaptive144Third140Node286 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof286

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof129 : runCachedNode 511 130381 Adaptive144Third140Node129 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof129

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof166 : runCachedNode 511 130381 Adaptive144Third140Node166 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof166

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof630 : runCachedNode 511 130381 Adaptive144Third140Node630 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof630

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof315 : runCachedNode 511 130381 Adaptive144Third140Node315 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof315

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof105 : runCachedNode 511 130381 Adaptive144Third140Node105 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof105

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof515 : runCachedNode 511 130381 Adaptive144Third140Node515 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof515

end NineSeparatedSubsetSums
