import NineSeparatedSubsetSums.Adaptive144Third139State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third139Proof20 : runCachedNode 511 130274 Adaptive144Third139Node20 = false := by
  decide +kernel

#print axioms adaptive144Third139Proof20

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third139Proof216 : runCachedNode 511 130274 Adaptive144Third139Node216 = false := by
  decide +kernel

#print axioms adaptive144Third139Proof216

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third139Proof46 : runCachedNode 511 130274 Adaptive144Third139Node46 = false := by
  decide +kernel

#print axioms adaptive144Third139Proof46

end NineSeparatedSubsetSums
