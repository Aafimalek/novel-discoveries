import NineSeparatedSubsetSums.Adaptive144Third142State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third142Proof532 : runCachedNode 511 130737 Adaptive144Third142Node532 = false := by
  decide +kernel

#print axioms adaptive144Third142Proof532

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third142Proof260 : runCachedNode 511 130737 Adaptive144Third142Node260 = false := by
  decide +kernel

#print axioms adaptive144Third142Proof260

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third142Proof657 : runCachedNode 511 130737 Adaptive144Third142Node657 = false := by
  decide +kernel

#print axioms adaptive144Third142Proof657

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third142Proof50 : runCachedNode 511 130737 Adaptive144Third142Node50 = false := by
  decide +kernel

#print axioms adaptive144Third142Proof50

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third142Proof48 : runCachedNode 511 130737 Adaptive144Third142Node48 = false := by
  decide +kernel

#print axioms adaptive144Third142Proof48

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third142Proof206 : runCachedNode 511 130737 Adaptive144Third142Node206 = false := by
  decide +kernel

#print axioms adaptive144Third142Proof206

end NineSeparatedSubsetSums
