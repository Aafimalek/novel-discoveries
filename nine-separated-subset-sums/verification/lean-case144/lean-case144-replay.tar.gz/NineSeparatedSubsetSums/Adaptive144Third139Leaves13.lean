import NineSeparatedSubsetSums.Adaptive144Third139State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third139Proof147 : runCachedNode 511 130274 Adaptive144Third139Node147 = false := by
  decide +kernel

#print axioms adaptive144Third139Proof147

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third139Proof150 : runCachedNode 511 130274 Adaptive144Third139Node150 = false := by
  decide +kernel

#print axioms adaptive144Third139Proof150

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third139Proof43 : runCachedNode 511 130274 Adaptive144Third139Node43 = false := by
  decide +kernel

#print axioms adaptive144Third139Proof43

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third139Proof122 : runCachedNode 511 130274 Adaptive144Third139Node122 = false := by
  decide +kernel

#print axioms adaptive144Third139Proof122

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third139Proof208 : runCachedNode 511 130274 Adaptive144Third139Node208 = false := by
  decide +kernel

#print axioms adaptive144Third139Proof208

end NineSeparatedSubsetSums
