import NineSeparatedSubsetSums.Adaptive144Third142State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third142Proof403 : runCachedNode 511 130737 Adaptive144Third142Node403 = false := by
  decide +kernel

#print axioms adaptive144Third142Proof403

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third142Proof490 : runCachedNode 511 130737 Adaptive144Third142Node490 = false := by
  decide +kernel

#print axioms adaptive144Third142Proof490

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third142Proof139 : runCachedNode 511 130737 Adaptive144Third142Node139 = false := by
  decide +kernel

#print axioms adaptive144Third142Proof139

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third142Proof200 : runCachedNode 511 130737 Adaptive144Third142Node200 = false := by
  decide +kernel

#print axioms adaptive144Third142Proof200

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third142Proof84 : runCachedNode 511 130737 Adaptive144Third142Node84 = false := by
  decide +kernel

#print axioms adaptive144Third142Proof84

end NineSeparatedSubsetSums
