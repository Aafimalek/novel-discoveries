import NineSeparatedSubsetSums.Adaptive144Third140State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof721 : runCachedNode 511 130381 Adaptive144Third140Node721 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof721

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof14 : runCachedNode 511 130381 Adaptive144Third140Node14 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof14

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof320 : runCachedNode 511 130381 Adaptive144Third140Node320 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof320

end NineSeparatedSubsetSums
