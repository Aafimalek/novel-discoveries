import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive144Third123Node0 : CachedSearchNode :=
  ⟨4, 122, computeCenteredMask [148,144,123], 415, 57769⟩

end NineSeparatedSubsetSums
