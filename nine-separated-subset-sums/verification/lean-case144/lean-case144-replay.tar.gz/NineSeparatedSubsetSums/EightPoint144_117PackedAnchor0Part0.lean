import NineSeparatedSubsetSums.EightPoint144_117PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint144_117PackedAnchor0Part0 :
    ∀ j : Fin 120, 2399993 ≤ FourPointNumeric.octPackedCharge 144 117 20 packedOct144_117_0
      (2*((j.val : Int)+0)+1) := by decide +kernel

end NineSeparatedSubsetSums
