import NineSeparatedSubsetSums.Adaptive144Third140State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof522 : runCachedNode 511 130381 Adaptive144Third140Node522 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof522

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof63 : runCachedNode 511 130381 Adaptive144Third140Node63 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof63

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof88 : runCachedNode 511 130381 Adaptive144Third140Node88 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof88

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof323 : runCachedNode 511 130381 Adaptive144Third140Node323 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof323

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof296 : runCachedNode 511 130381 Adaptive144Third140Node296 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof296

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof60 : runCachedNode 511 130381 Adaptive144Third140Node60 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof60

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof206 : runCachedNode 511 130381 Adaptive144Third140Node206 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof206

end NineSeparatedSubsetSums
