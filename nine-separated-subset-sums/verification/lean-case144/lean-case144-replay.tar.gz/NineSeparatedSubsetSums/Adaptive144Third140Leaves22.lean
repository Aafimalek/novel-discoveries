import NineSeparatedSubsetSums.Adaptive144Third140State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof601 : runCachedNode 511 130381 Adaptive144Third140Node601 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof601

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof602 : runCachedNode 511 130381 Adaptive144Third140Node602 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof602

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof720 : runCachedNode 511 130381 Adaptive144Third140Node720 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof720

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof180 : runCachedNode 511 130381 Adaptive144Third140Node180 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof180

end NineSeparatedSubsetSums
