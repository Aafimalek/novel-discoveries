import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive144Third125Node0 : CachedSearchNode :=
  ⟨4, 124, computeCenteredMask [148,144,125], 417, 58265⟩

end NineSeparatedSubsetSums
