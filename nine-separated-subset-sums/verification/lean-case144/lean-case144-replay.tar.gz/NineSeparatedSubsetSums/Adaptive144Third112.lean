import NineSeparatedSubsetSums.Adaptive144Third112Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint144Checked

namespace NineSeparatedSubsetSums


theorem adaptive144Third112 : NoDescendingTailAfterThird 144 112 :=
  noDescendingThirdTail_of_cached 144 112 112221 (fun t ht nd => max148_second144_fourPoint_moment_bound (112::t) (by simp [ht]) nd) adaptive144Third112Proof0

#print axioms adaptive144Third112

end NineSeparatedSubsetSums
