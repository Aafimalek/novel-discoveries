import NineSeparatedSubsetSums.Adaptive144Third135State
import NineSeparatedSubsetSums.Adaptive144Third135Leaves0
import NineSeparatedSubsetSums.Adaptive144Third135Leaves9
import NineSeparatedSubsetSums.Adaptive144Third135Leaves8
import NineSeparatedSubsetSums.Adaptive144Third135Leaves5
import NineSeparatedSubsetSums.Adaptive144Third135Leaves7
import NineSeparatedSubsetSums.Adaptive144Third135Leaves6
import NineSeparatedSubsetSums.Adaptive144Third135Leaves2
import NineSeparatedSubsetSums.Adaptive144Third135Leaves4
import NineSeparatedSubsetSums.Adaptive144Third135Leaves1
import NineSeparatedSubsetSums.Adaptive144Third135Leaves3

namespace NineSeparatedSubsetSums

theorem adaptive144Third135Proof22 : runCachedNode 511 129692 Adaptive144Third135Node22 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 129692 Adaptive144Third135Node22 = [104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 120, 121, 122, 124, 125, 126, 127, 129, 130] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive144Third135Proof23
  · exact adaptive144Third135Proof24
  · exact adaptive144Third135Proof25
  · exact adaptive144Third135Proof26
  · exact adaptive144Third135Proof27
  · exact adaptive144Third135Proof28
  · exact adaptive144Third135Proof29
  · exact adaptive144Third135Proof30
  · exact adaptive144Third135Proof31
  · exact adaptive144Third135Proof32
  · exact adaptive144Third135Proof33
  · exact adaptive144Third135Proof34
  · exact adaptive144Third135Proof35
  · exact adaptive144Third135Proof36
  · exact adaptive144Third135Proof37
  · exact adaptive144Third135Proof38
  · exact adaptive144Third135Proof39
  · exact adaptive144Third135Proof40
  · exact adaptive144Third135Proof41
  · exact adaptive144Third135Proof42
  · exact adaptive144Third135Proof43
  · exact adaptive144Third135Proof44
  · exact adaptive144Third135Proof45
  · exact adaptive144Third135Proof46

#print axioms adaptive144Third135Proof22

theorem adaptive144Third135Proof47 : runCachedNode 511 129692 Adaptive144Third135Node47 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 129692 Adaptive144Third135Node47 = [104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 121, 122, 123, 125, 126, 127, 128, 130, 132] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive144Third135Proof48
  · exact adaptive144Third135Proof49
  · exact adaptive144Third135Proof50
  · exact adaptive144Third135Proof51
  · exact adaptive144Third135Proof52
  · exact adaptive144Third135Proof53
  · exact adaptive144Third135Proof54
  · exact adaptive144Third135Proof55
  · exact adaptive144Third135Proof56
  · exact adaptive144Third135Proof57
  · exact adaptive144Third135Proof58
  · exact adaptive144Third135Proof59
  · exact adaptive144Third135Proof60
  · exact adaptive144Third135Proof61
  · exact adaptive144Third135Proof62
  · exact adaptive144Third135Proof63
  · exact adaptive144Third135Proof64
  · exact adaptive144Third135Proof65
  · exact adaptive144Third135Proof66
  · exact adaptive144Third135Proof67
  · exact adaptive144Third135Proof68
  · exact adaptive144Third135Proof69
  · exact adaptive144Third135Proof70
  · exact adaptive144Third135Proof71
  · exact adaptive144Third135Proof72

#print axioms adaptive144Third135Proof47

theorem adaptive144Third135Proof73 : runCachedNode 511 129692 Adaptive144Third135Node73 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 129692 Adaptive144Third135Node73 = [103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 122, 123, 124, 126, 127, 128, 129, 132, 133] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive144Third135Proof74
  · exact adaptive144Third135Proof75
  · exact adaptive144Third135Proof76
  · exact adaptive144Third135Proof77
  · exact adaptive144Third135Proof78
  · exact adaptive144Third135Proof79
  · exact adaptive144Third135Proof80
  · exact adaptive144Third135Proof81
  · exact adaptive144Third135Proof82
  · exact adaptive144Third135Proof83
  · exact adaptive144Third135Proof84
  · exact adaptive144Third135Proof85
  · exact adaptive144Third135Proof86
  · exact adaptive144Third135Proof87
  · exact adaptive144Third135Proof88
  · exact adaptive144Third135Proof89
  · exact adaptive144Third135Proof90
  · exact adaptive144Third135Proof91
  · exact adaptive144Third135Proof92
  · exact adaptive144Third135Proof93
  · exact adaptive144Third135Proof94
  · exact adaptive144Third135Proof95
  · exact adaptive144Third135Proof96
  · exact adaptive144Third135Proof97
  · exact adaptive144Third135Proof98
  · exact adaptive144Third135Proof99
  · exact adaptive144Third135Proof100

#print axioms adaptive144Third135Proof73

theorem adaptive144Third135Proof0 : runCachedNode 511 129692 Adaptive144Third135Node0 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 129692 Adaptive144Third135Node0 = [110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 132, 133, 134] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive144Third135Proof1
  · exact adaptive144Third135Proof2
  · exact adaptive144Third135Proof3
  · exact adaptive144Third135Proof4
  · exact adaptive144Third135Proof5
  · exact adaptive144Third135Proof6
  · exact adaptive144Third135Proof7
  · exact adaptive144Third135Proof8
  · exact adaptive144Third135Proof9
  · exact adaptive144Third135Proof10
  · exact adaptive144Third135Proof11
  · exact adaptive144Third135Proof12
  · exact adaptive144Third135Proof13
  · exact adaptive144Third135Proof14
  · exact adaptive144Third135Proof15
  · exact adaptive144Third135Proof16
  · exact adaptive144Third135Proof17
  · exact adaptive144Third135Proof18
  · exact adaptive144Third135Proof19
  · exact adaptive144Third135Proof20
  · exact adaptive144Third135Proof21
  · exact adaptive144Third135Proof22
  · exact adaptive144Third135Proof47
  · exact adaptive144Third135Proof73

#print axioms adaptive144Third135Proof0

end NineSeparatedSubsetSums
