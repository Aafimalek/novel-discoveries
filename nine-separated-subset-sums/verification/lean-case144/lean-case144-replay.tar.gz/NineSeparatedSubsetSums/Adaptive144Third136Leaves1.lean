import NineSeparatedSubsetSums.Adaptive144Third136State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third136Proof22 : runCachedNode 511 129800 Adaptive144Third136Node22 = false := by
  decide +kernel

#print axioms adaptive144Third136Proof22

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third136Proof11 : runCachedNode 511 129800 Adaptive144Third136Node11 = false := by
  decide +kernel

#print axioms adaptive144Third136Proof11

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third136Proof30 : runCachedNode 511 129800 Adaptive144Third136Node30 = false := by
  decide +kernel

#print axioms adaptive144Third136Proof30

end NineSeparatedSubsetSums
