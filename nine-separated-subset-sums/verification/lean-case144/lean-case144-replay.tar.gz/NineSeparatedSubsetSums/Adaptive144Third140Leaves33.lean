import NineSeparatedSubsetSums.Adaptive144Third140State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof195 : runCachedNode 511 130381 Adaptive144Third140Node195 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof195

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof428 : runCachedNode 511 130381 Adaptive144Third140Node428 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof428

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof530 : runCachedNode 511 130381 Adaptive144Third140Node530 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof530

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof639 : runCachedNode 511 130381 Adaptive144Third140Node639 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof639

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof113 : runCachedNode 511 130381 Adaptive144Third140Node113 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof113

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof432 : runCachedNode 511 130381 Adaptive144Third140Node432 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof432

end NineSeparatedSubsetSums
