import NineSeparatedSubsetSums.Adaptive144Third121State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third121Proof0 : runCachedNode 511 126391 Adaptive144Third121Node0 = false := by
  decide +kernel

#print axioms adaptive144Third121Proof0

end NineSeparatedSubsetSums
