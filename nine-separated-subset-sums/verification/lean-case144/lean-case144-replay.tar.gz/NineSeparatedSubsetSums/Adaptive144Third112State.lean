import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive144Third112Node0 : CachedSearchNode :=
  ⟨4, 111, computeCenteredMask [148,144,112], 404, 55184⟩

end NineSeparatedSubsetSums
