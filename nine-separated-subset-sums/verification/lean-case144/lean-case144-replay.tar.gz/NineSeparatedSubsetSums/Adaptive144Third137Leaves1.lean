import NineSeparatedSubsetSums.Adaptive144Third137State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third137Proof19 : runCachedNode 511 129993 Adaptive144Third137Node19 = false := by
  decide +kernel

#print axioms adaptive144Third137Proof19

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third137Proof150 : runCachedNode 511 129993 Adaptive144Third137Node150 = false := by
  decide +kernel

#print axioms adaptive144Third137Proof150

end NineSeparatedSubsetSums
