import NineSeparatedSubsetSums.Adaptive144Third140State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof326 : runCachedNode 511 130381 Adaptive144Third140Node326 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof326

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof138 : runCachedNode 511 130381 Adaptive144Third140Node138 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof138

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof200 : runCachedNode 511 130381 Adaptive144Third140Node200 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof200

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof20 : runCachedNode 511 130381 Adaptive144Third140Node20 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof20

end NineSeparatedSubsetSums
