import NineSeparatedSubsetSums.Adaptive144Third139State
import NineSeparatedSubsetSums.Adaptive144Third139Leaves22
import NineSeparatedSubsetSums.Adaptive144Third139Leaves16
import NineSeparatedSubsetSums.Adaptive144Third139Leaves21
import NineSeparatedSubsetSums.Adaptive144Third139Leaves20
import NineSeparatedSubsetSums.Adaptive144Third139Leaves18
import NineSeparatedSubsetSums.Adaptive144Third139Leaves19
import NineSeparatedSubsetSums.Adaptive144Third139Leaves14
import NineSeparatedSubsetSums.Adaptive144Third139Leaves17
import NineSeparatedSubsetSums.Adaptive144Third139Leaves13
import NineSeparatedSubsetSums.Adaptive144Third139Leaves11
import NineSeparatedSubsetSums.Adaptive144Third139Leaves5
import NineSeparatedSubsetSums.Adaptive144Third139Leaves10
import NineSeparatedSubsetSums.Adaptive144Third139Leaves9
import NineSeparatedSubsetSums.Adaptive144Third139Leaves12
import NineSeparatedSubsetSums.Adaptive144Third139Leaves15
import NineSeparatedSubsetSums.Adaptive144Third139Leaves4
import NineSeparatedSubsetSums.Adaptive144Third139Leaves0
import NineSeparatedSubsetSums.Adaptive144Third139Leaves23
import NineSeparatedSubsetSums.Adaptive144Third139Leaves3
import NineSeparatedSubsetSums.Adaptive144Third139Leaves6
import NineSeparatedSubsetSums.Adaptive144Third139Leaves2
import NineSeparatedSubsetSums.Adaptive144Third139Leaves8
import NineSeparatedSubsetSums.Adaptive144Third139Leaves1
import NineSeparatedSubsetSums.Adaptive144Third139Leaves7

namespace NineSeparatedSubsetSums

theorem adaptive144Third139Proof21 : runCachedNode 511 130274 Adaptive144Third139Node21 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130274 Adaptive144Third139Node21 = [104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 122, 123, 124, 127, 128, 129] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive144Third139Proof22
  · exact adaptive144Third139Proof23
  · exact adaptive144Third139Proof24
  · exact adaptive144Third139Proof25
  · exact adaptive144Third139Proof26
  · exact adaptive144Third139Proof27
  · exact adaptive144Third139Proof28
  · exact adaptive144Third139Proof29
  · exact adaptive144Third139Proof30
  · exact adaptive144Third139Proof31
  · exact adaptive144Third139Proof32
  · exact adaptive144Third139Proof33
  · exact adaptive144Third139Proof34
  · exact adaptive144Third139Proof35
  · exact adaptive144Third139Proof36
  · exact adaptive144Third139Proof37
  · exact adaptive144Third139Proof38
  · exact adaptive144Third139Proof39
  · exact adaptive144Third139Proof40
  · exact adaptive144Third139Proof41
  · exact adaptive144Third139Proof42
  · exact adaptive144Third139Proof43
  · exact adaptive144Third139Proof44

#print axioms adaptive144Third139Proof21

theorem adaptive144Third139Proof45 : runCachedNode 511 130274 Adaptive144Third139Node45 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130274 Adaptive144Third139Node45 = [104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 123, 124, 125, 128, 129, 130] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive144Third139Proof46
  · exact adaptive144Third139Proof47
  · exact adaptive144Third139Proof48
  · exact adaptive144Third139Proof49
  · exact adaptive144Third139Proof50
  · exact adaptive144Third139Proof51
  · exact adaptive144Third139Proof52
  · exact adaptive144Third139Proof53
  · exact adaptive144Third139Proof54
  · exact adaptive144Third139Proof55
  · exact adaptive144Third139Proof56
  · exact adaptive144Third139Proof57
  · exact adaptive144Third139Proof58
  · exact adaptive144Third139Proof59
  · exact adaptive144Third139Proof60
  · exact adaptive144Third139Proof61
  · exact adaptive144Third139Proof62
  · exact adaptive144Third139Proof63
  · exact adaptive144Third139Proof64
  · exact adaptive144Third139Proof65
  · exact adaptive144Third139Proof66
  · exact adaptive144Third139Proof67
  · exact adaptive144Third139Proof68
  · exact adaptive144Third139Proof69

#print axioms adaptive144Third139Proof45

theorem adaptive144Third139Proof70 : runCachedNode 511 130274 Adaptive144Third139Node70 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130274 Adaptive144Third139Node70 = [103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 124, 125, 126, 129, 130, 131] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive144Third139Proof71
  · exact adaptive144Third139Proof72
  · exact adaptive144Third139Proof73
  · exact adaptive144Third139Proof74
  · exact adaptive144Third139Proof75
  · exact adaptive144Third139Proof76
  · exact adaptive144Third139Proof77
  · exact adaptive144Third139Proof78
  · exact adaptive144Third139Proof79
  · exact adaptive144Third139Proof80
  · exact adaptive144Third139Proof81
  · exact adaptive144Third139Proof82
  · exact adaptive144Third139Proof83
  · exact adaptive144Third139Proof84
  · exact adaptive144Third139Proof85
  · exact adaptive144Third139Proof86
  · exact adaptive144Third139Proof87
  · exact adaptive144Third139Proof88
  · exact adaptive144Third139Proof89
  · exact adaptive144Third139Proof90
  · exact adaptive144Third139Proof91
  · exact adaptive144Third139Proof92
  · exact adaptive144Third139Proof93
  · exact adaptive144Third139Proof94
  · exact adaptive144Third139Proof95
  · exact adaptive144Third139Proof96

#print axioms adaptive144Third139Proof70

theorem adaptive144Third139Proof97 : runCachedNode 511 130274 Adaptive144Third139Node97 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130274 Adaptive144Third139Node97 = [103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 125, 126, 127, 130, 131, 132] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive144Third139Proof98
  · exact adaptive144Third139Proof99
  · exact adaptive144Third139Proof100
  · exact adaptive144Third139Proof101
  · exact adaptive144Third139Proof102
  · exact adaptive144Third139Proof103
  · exact adaptive144Third139Proof104
  · exact adaptive144Third139Proof105
  · exact adaptive144Third139Proof106
  · exact adaptive144Third139Proof107
  · exact adaptive144Third139Proof108
  · exact adaptive144Third139Proof109
  · exact adaptive144Third139Proof110
  · exact adaptive144Third139Proof111
  · exact adaptive144Third139Proof112
  · exact adaptive144Third139Proof113
  · exact adaptive144Third139Proof114
  · exact adaptive144Third139Proof115
  · exact adaptive144Third139Proof116
  · exact adaptive144Third139Proof117
  · exact adaptive144Third139Proof118
  · exact adaptive144Third139Proof119
  · exact adaptive144Third139Proof120
  · exact adaptive144Third139Proof121
  · exact adaptive144Third139Proof122
  · exact adaptive144Third139Proof123
  · exact adaptive144Third139Proof124

#print axioms adaptive144Third139Proof97

theorem adaptive144Third139Proof125 : runCachedNode 511 130274 Adaptive144Third139Node125 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130274 Adaptive144Third139Node125 = [103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 126, 127, 128, 131, 132, 133] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive144Third139Proof126
  · exact adaptive144Third139Proof127
  · exact adaptive144Third139Proof128
  · exact adaptive144Third139Proof129
  · exact adaptive144Third139Proof130
  · exact adaptive144Third139Proof131
  · exact adaptive144Third139Proof132
  · exact adaptive144Third139Proof133
  · exact adaptive144Third139Proof134
  · exact adaptive144Third139Proof135
  · exact adaptive144Third139Proof136
  · exact adaptive144Third139Proof137
  · exact adaptive144Third139Proof138
  · exact adaptive144Third139Proof139
  · exact adaptive144Third139Proof140
  · exact adaptive144Third139Proof141
  · exact adaptive144Third139Proof142
  · exact adaptive144Third139Proof143
  · exact adaptive144Third139Proof144
  · exact adaptive144Third139Proof145
  · exact adaptive144Third139Proof146
  · exact adaptive144Third139Proof147
  · exact adaptive144Third139Proof148
  · exact adaptive144Third139Proof149
  · exact adaptive144Third139Proof150
  · exact adaptive144Third139Proof151
  · exact adaptive144Third139Proof152
  · exact adaptive144Third139Proof153

#print axioms adaptive144Third139Proof125

theorem adaptive144Third139Proof154 : runCachedNode 511 130274 Adaptive144Third139Node154 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130274 Adaptive144Third139Node154 = [102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 128, 129, 130, 133, 134] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive144Third139Proof155
  · exact adaptive144Third139Proof156
  · exact adaptive144Third139Proof157
  · exact adaptive144Third139Proof158
  · exact adaptive144Third139Proof159
  · exact adaptive144Third139Proof160
  · exact adaptive144Third139Proof161
  · exact adaptive144Third139Proof162
  · exact adaptive144Third139Proof163
  · exact adaptive144Third139Proof164
  · exact adaptive144Third139Proof165
  · exact adaptive144Third139Proof166
  · exact adaptive144Third139Proof167
  · exact adaptive144Third139Proof168
  · exact adaptive144Third139Proof169
  · exact adaptive144Third139Proof170
  · exact adaptive144Third139Proof171
  · exact adaptive144Third139Proof172
  · exact adaptive144Third139Proof173
  · exact adaptive144Third139Proof174
  · exact adaptive144Third139Proof175
  · exact adaptive144Third139Proof176
  · exact adaptive144Third139Proof177
  · exact adaptive144Third139Proof178
  · exact adaptive144Third139Proof179
  · exact adaptive144Third139Proof180
  · exact adaptive144Third139Proof181
  · exact adaptive144Third139Proof182
  · exact adaptive144Third139Proof183
  · exact adaptive144Third139Proof184

#print axioms adaptive144Third139Proof154

theorem adaptive144Third139Proof185 : runCachedNode 511 130274 Adaptive144Third139Node185 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130274 Adaptive144Third139Node185 = [102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 129, 130, 131, 134, 136] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive144Third139Proof186
  · exact adaptive144Third139Proof187
  · exact adaptive144Third139Proof188
  · exact adaptive144Third139Proof189
  · exact adaptive144Third139Proof190
  · exact adaptive144Third139Proof191
  · exact adaptive144Third139Proof192
  · exact adaptive144Third139Proof193
  · exact adaptive144Third139Proof194
  · exact adaptive144Third139Proof195
  · exact adaptive144Third139Proof196
  · exact adaptive144Third139Proof197
  · exact adaptive144Third139Proof198
  · exact adaptive144Third139Proof199
  · exact adaptive144Third139Proof200
  · exact adaptive144Third139Proof201
  · exact adaptive144Third139Proof202
  · exact adaptive144Third139Proof203
  · exact adaptive144Third139Proof204
  · exact adaptive144Third139Proof205
  · exact adaptive144Third139Proof206
  · exact adaptive144Third139Proof207
  · exact adaptive144Third139Proof208
  · exact adaptive144Third139Proof209
  · exact adaptive144Third139Proof210
  · exact adaptive144Third139Proof211
  · exact adaptive144Third139Proof212
  · exact adaptive144Third139Proof213
  · exact adaptive144Third139Proof214
  · exact adaptive144Third139Proof215
  · exact adaptive144Third139Proof216

#print axioms adaptive144Third139Proof185

theorem adaptive144Third139Proof217 : runCachedNode 511 130274 Adaptive144Third139Node217 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130274 Adaptive144Third139Node217 = [102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 130, 131, 132, 136, 137] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive144Third139Proof218
  · exact adaptive144Third139Proof219
  · exact adaptive144Third139Proof220
  · exact adaptive144Third139Proof221
  · exact adaptive144Third139Proof222
  · exact adaptive144Third139Proof223
  · exact adaptive144Third139Proof224
  · exact adaptive144Third139Proof225
  · exact adaptive144Third139Proof226
  · exact adaptive144Third139Proof227
  · exact adaptive144Third139Proof228
  · exact adaptive144Third139Proof229
  · exact adaptive144Third139Proof230
  · exact adaptive144Third139Proof231
  · exact adaptive144Third139Proof232
  · exact adaptive144Third139Proof233
  · exact adaptive144Third139Proof234
  · exact adaptive144Third139Proof235
  · exact adaptive144Third139Proof236
  · exact adaptive144Third139Proof237
  · exact adaptive144Third139Proof238
  · exact adaptive144Third139Proof239
  · exact adaptive144Third139Proof240
  · exact adaptive144Third139Proof241
  · exact adaptive144Third139Proof242
  · exact adaptive144Third139Proof243
  · exact adaptive144Third139Proof244
  · exact adaptive144Third139Proof245
  · exact adaptive144Third139Proof246
  · exact adaptive144Third139Proof247
  · exact adaptive144Third139Proof248
  · exact adaptive144Third139Proof249

#print axioms adaptive144Third139Proof217

end NineSeparatedSubsetSums
