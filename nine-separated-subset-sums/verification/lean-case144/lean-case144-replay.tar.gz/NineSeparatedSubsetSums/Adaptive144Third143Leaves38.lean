import NineSeparatedSubsetSums.Adaptive144Third143State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third143Proof12 : runCachedNode 511 130885 Adaptive144Third143Node12 = false := by
  decide +kernel

#print axioms adaptive144Third143Proof12

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third143Proof651 : runCachedNode 511 130885 Adaptive144Third143Node651 = false := by
  decide +kernel

#print axioms adaptive144Third143Proof651

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third143Proof560 : runCachedNode 511 130885 Adaptive144Third143Node560 = false := by
  decide +kernel

#print axioms adaptive144Third143Proof560

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third143Proof652 : runCachedNode 511 130885 Adaptive144Third143Node652 = false := by
  decide +kernel

#print axioms adaptive144Third143Proof652

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third143Proof653 : runCachedNode 511 130885 Adaptive144Third143Node653 = false := by
  decide +kernel

#print axioms adaptive144Third143Proof653

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third143Proof654 : runCachedNode 511 130885 Adaptive144Third143Node654 = false := by
  decide +kernel

#print axioms adaptive144Third143Proof654

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third143Proof646 : runCachedNode 511 130885 Adaptive144Third143Node646 = false := by
  decide +kernel

#print axioms adaptive144Third143Proof646

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third143Proof100 : runCachedNode 511 130885 Adaptive144Third143Node100 = false := by
  decide +kernel

#print axioms adaptive144Third143Proof100

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third143Proof157 : runCachedNode 511 130885 Adaptive144Third143Node157 = false := by
  decide +kernel

#print axioms adaptive144Third143Proof157

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third143Proof125 : runCachedNode 511 130885 Adaptive144Third143Node125 = false := by
  decide +kernel

#print axioms adaptive144Third143Proof125

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third143Proof198 : runCachedNode 511 130885 Adaptive144Third143Node198 = false := by
  decide +kernel

#print axioms adaptive144Third143Proof198

end NineSeparatedSubsetSums
