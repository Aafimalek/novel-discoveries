import NineSeparatedSubsetSums.Adaptive144Third138State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third138Proof95 : runCachedNode 511 130126 Adaptive144Third138Node95 = false := by
  decide +kernel

#print axioms adaptive144Third138Proof95

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third138Proof17 : runCachedNode 511 130126 Adaptive144Third138Node17 = false := by
  decide +kernel

#print axioms adaptive144Third138Proof17

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third138Proof16 : runCachedNode 511 130126 Adaptive144Third138Node16 = false := by
  decide +kernel

#print axioms adaptive144Third138Proof16

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third138Proof6 : runCachedNode 511 130126 Adaptive144Third138Node6 = false := by
  decide +kernel

#print axioms adaptive144Third138Proof6

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third138Proof185 : runCachedNode 511 130126 Adaptive144Third138Node185 = false := by
  decide +kernel

#print axioms adaptive144Third138Proof185

end NineSeparatedSubsetSums
