import NineSeparatedSubsetSums.Adaptive144Third140State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof387 : runCachedNode 511 130381 Adaptive144Third140Node387 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof387

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof294 : runCachedNode 511 130381 Adaptive144Third140Node294 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof294

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof83 : runCachedNode 511 130381 Adaptive144Third140Node83 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof83

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof359 : runCachedNode 511 130381 Adaptive144Third140Node359 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof359

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof426 : runCachedNode 511 130381 Adaptive144Third140Node426 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof426

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof37 : runCachedNode 511 130381 Adaptive144Third140Node37 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof37

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof486 : runCachedNode 511 130381 Adaptive144Third140Node486 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof486

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof425 : runCachedNode 511 130381 Adaptive144Third140Node425 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof425

end NineSeparatedSubsetSums
