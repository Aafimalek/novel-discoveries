import NineSeparatedSubsetSums.Adaptive144Third135State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third135Proof51 : runCachedNode 511 129692 Adaptive144Third135Node51 = false := by
  decide +kernel

#print axioms adaptive144Third135Proof51

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third135Proof26 : runCachedNode 511 129692 Adaptive144Third135Node26 = false := by
  decide +kernel

#print axioms adaptive144Third135Proof26

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third135Proof49 : runCachedNode 511 129692 Adaptive144Third135Node49 = false := by
  decide +kernel

#print axioms adaptive144Third135Proof49

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third135Proof50 : runCachedNode 511 129692 Adaptive144Third135Node50 = false := by
  decide +kernel

#print axioms adaptive144Third135Proof50

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third135Proof24 : runCachedNode 511 129692 Adaptive144Third135Node24 = false := by
  decide +kernel

#print axioms adaptive144Third135Proof24

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third135Proof25 : runCachedNode 511 129692 Adaptive144Third135Node25 = false := by
  decide +kernel

#print axioms adaptive144Third135Proof25

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third135Proof48 : runCachedNode 511 129692 Adaptive144Third135Node48 = false := by
  decide +kernel

#print axioms adaptive144Third135Proof48

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third135Proof75 : runCachedNode 511 129692 Adaptive144Third135Node75 = false := by
  decide +kernel

#print axioms adaptive144Third135Proof75

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third135Proof76 : runCachedNode 511 129692 Adaptive144Third135Node76 = false := by
  decide +kernel

#print axioms adaptive144Third135Proof76

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third135Proof77 : runCachedNode 511 129692 Adaptive144Third135Node77 = false := by
  decide +kernel

#print axioms adaptive144Third135Proof77

end NineSeparatedSubsetSums
