import NineSeparatedSubsetSums.EightPoint144_118PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint144_118PackedAnchor1Part2 :
    ∀ j : Fin 7, 2401228 ≤ FourPointNumeric.octPackedCharge 144 118 20 packedOct144_118_1
      (2*((j.val : Int)+240)+1) := by decide +kernel

end NineSeparatedSubsetSums
