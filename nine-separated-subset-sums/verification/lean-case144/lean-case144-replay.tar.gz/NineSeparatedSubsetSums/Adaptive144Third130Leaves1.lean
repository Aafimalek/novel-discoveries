import NineSeparatedSubsetSums.Adaptive144Third130State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third130Proof17 : runCachedNode 511 128721 Adaptive144Third130Node17 = false := by
  decide +kernel

#print axioms adaptive144Third130Proof17

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third130Proof16 : runCachedNode 511 128721 Adaptive144Third130Node16 = false := by
  decide +kernel

#print axioms adaptive144Third130Proof16

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third130Proof15 : runCachedNode 511 128721 Adaptive144Third130Node15 = false := by
  decide +kernel

#print axioms adaptive144Third130Proof15

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third130Proof13 : runCachedNode 511 128721 Adaptive144Third130Node13 = false := by
  decide +kernel

#print axioms adaptive144Third130Proof13

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third130Proof10 : runCachedNode 511 128721 Adaptive144Third130Node10 = false := by
  decide +kernel

#print axioms adaptive144Third130Proof10

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third130Proof2 : runCachedNode 511 128721 Adaptive144Third130Node2 = false := by
  decide +kernel

#print axioms adaptive144Third130Proof2

end NineSeparatedSubsetSums
