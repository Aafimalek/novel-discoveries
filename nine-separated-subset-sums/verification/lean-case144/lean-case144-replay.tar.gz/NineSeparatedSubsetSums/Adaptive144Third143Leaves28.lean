import NineSeparatedSubsetSums.Adaptive144Third143State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third143Proof454 : runCachedNode 511 130885 Adaptive144Third143Node454 = false := by
  decide +kernel

#print axioms adaptive144Third143Proof454

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third143Proof567 : runCachedNode 511 130885 Adaptive144Third143Node567 = false := by
  decide +kernel

#print axioms adaptive144Third143Proof567

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third143Proof161 : runCachedNode 511 130885 Adaptive144Third143Node161 = false := by
  decide +kernel

#print axioms adaptive144Third143Proof161

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third143Proof74 : runCachedNode 511 130885 Adaptive144Third143Node74 = false := by
  decide +kernel

#print axioms adaptive144Third143Proof74

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third143Proof488 : runCachedNode 511 130885 Adaptive144Third143Node488 = false := by
  decide +kernel

#print axioms adaptive144Third143Proof488

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third143Proof135 : runCachedNode 511 130885 Adaptive144Third143Node135 = false := by
  decide +kernel

#print axioms adaptive144Third143Proof135

end NineSeparatedSubsetSums
