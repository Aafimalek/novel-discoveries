import NineSeparatedSubsetSums.Adaptive144Third139State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third139Proof248 : runCachedNode 511 130274 Adaptive144Third139Node248 = false := by
  decide +kernel

#print axioms adaptive144Third139Proof248

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third139Proof17 : runCachedNode 511 130274 Adaptive144Third139Node17 = false := by
  decide +kernel

#print axioms adaptive144Third139Proof17

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third139Proof98 : runCachedNode 511 130274 Adaptive144Third139Node98 = false := by
  decide +kernel

#print axioms adaptive144Third139Proof98

end NineSeparatedSubsetSums
