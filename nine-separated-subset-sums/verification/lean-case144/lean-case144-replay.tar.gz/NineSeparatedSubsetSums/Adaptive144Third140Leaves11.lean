import NineSeparatedSubsetSums.Adaptive144Third140State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof298 : runCachedNode 511 130381 Adaptive144Third140Node298 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof298

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof391 : runCachedNode 511 130381 Adaptive144Third140Node391 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof391

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof353 : runCachedNode 511 130381 Adaptive144Third140Node353 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof353

end NineSeparatedSubsetSums
