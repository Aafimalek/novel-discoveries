import NineSeparatedSubsetSums.Adaptive144Third140State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof142 : runCachedNode 511 130381 Adaptive144Third140Node142 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof142

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof495 : runCachedNode 511 130381 Adaptive144Third140Node495 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof495

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof28 : runCachedNode 511 130381 Adaptive144Third140Node28 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof28

end NineSeparatedSubsetSums
