import NineSeparatedSubsetSums.Adaptive144Third139State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third139Proof68 : runCachedNode 511 130274 Adaptive144Third139Node68 = false := by
  decide +kernel

#print axioms adaptive144Third139Proof68

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third139Proof13 : runCachedNode 511 130274 Adaptive144Third139Node13 = false := by
  decide +kernel

#print axioms adaptive144Third139Proof13

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third139Proof212 : runCachedNode 511 130274 Adaptive144Third139Node212 = false := by
  decide +kernel

#print axioms adaptive144Third139Proof212

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third139Proof242 : runCachedNode 511 130274 Adaptive144Third139Node242 = false := by
  decide +kernel

#print axioms adaptive144Third139Proof242

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third139Proof241 : runCachedNode 511 130274 Adaptive144Third139Node241 = false := by
  decide +kernel

#print axioms adaptive144Third139Proof241

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third139Proof240 : runCachedNode 511 130274 Adaptive144Third139Node240 = false := by
  decide +kernel

#print axioms adaptive144Third139Proof240

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third139Proof243 : runCachedNode 511 130274 Adaptive144Third139Node243 = false := by
  decide +kernel

#print axioms adaptive144Third139Proof243

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third139Proof85 : runCachedNode 511 130274 Adaptive144Third139Node85 = false := by
  decide +kernel

#print axioms adaptive144Third139Proof85

end NineSeparatedSubsetSums
