import NineSeparatedSubsetSums.Adaptive144Third139State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third139Proof149 : runCachedNode 511 130274 Adaptive144Third139Node149 = false := by
  decide +kernel

#print axioms adaptive144Third139Proof149

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third139Proof14 : runCachedNode 511 130274 Adaptive144Third139Node14 = false := by
  decide +kernel

#print axioms adaptive144Third139Proof14

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third139Proof211 : runCachedNode 511 130274 Adaptive144Third139Node211 = false := by
  decide +kernel

#print axioms adaptive144Third139Proof211

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third139Proof246 : runCachedNode 511 130274 Adaptive144Third139Node246 = false := by
  decide +kernel

#print axioms adaptive144Third139Proof246

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third139Proof121 : runCachedNode 511 130274 Adaptive144Third139Node121 = false := by
  decide +kernel

#print axioms adaptive144Third139Proof121

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third139Proof40 : runCachedNode 511 130274 Adaptive144Third139Node40 = false := by
  decide +kernel

#print axioms adaptive144Third139Proof40

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third139Proof3 : runCachedNode 511 130274 Adaptive144Third139Node3 = false := by
  decide +kernel

#print axioms adaptive144Third139Proof3

end NineSeparatedSubsetSums
