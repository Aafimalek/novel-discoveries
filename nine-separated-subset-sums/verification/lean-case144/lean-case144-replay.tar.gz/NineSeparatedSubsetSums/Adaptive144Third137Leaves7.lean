import NineSeparatedSubsetSums.Adaptive144Third137State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third137Proof44 : runCachedNode 511 129993 Adaptive144Third137Node44 = false := by
  decide +kernel

#print axioms adaptive144Third137Proof44

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third137Proof123 : runCachedNode 511 129993 Adaptive144Third137Node123 = false := by
  decide +kernel

#print axioms adaptive144Third137Proof123

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third137Proof119 : runCachedNode 511 129993 Adaptive144Third137Node119 = false := by
  decide +kernel

#print axioms adaptive144Third137Proof119

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third137Proof15 : runCachedNode 511 129993 Adaptive144Third137Node15 = false := by
  decide +kernel

#print axioms adaptive144Third137Proof15

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third137Proof60 : runCachedNode 511 129993 Adaptive144Third137Node60 = false := by
  decide +kernel

#print axioms adaptive144Third137Proof60

end NineSeparatedSubsetSums
