import NineSeparatedSubsetSums.Adaptive144Third143State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third143Proof21 : runCachedNode 511 130885 Adaptive144Third143Node21 = false := by
  decide +kernel

#print axioms adaptive144Third143Proof21

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third143Proof192 : runCachedNode 511 130885 Adaptive144Third143Node192 = false := by
  decide +kernel

#print axioms adaptive144Third143Proof192

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third143Proof3 : runCachedNode 511 130885 Adaptive144Third143Node3 = false := by
  decide +kernel

#print axioms adaptive144Third143Proof3

end NineSeparatedSubsetSums
