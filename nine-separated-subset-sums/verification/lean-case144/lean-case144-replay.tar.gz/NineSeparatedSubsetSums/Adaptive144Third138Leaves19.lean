import NineSeparatedSubsetSums.Adaptive144Third138State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third138Proof106 : runCachedNode 511 130126 Adaptive144Third138Node106 = false := by
  decide +kernel

#print axioms adaptive144Third138Proof106

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third138Proof4 : runCachedNode 511 130126 Adaptive144Third138Node4 = false := by
  decide +kernel

#print axioms adaptive144Third138Proof4

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third138Proof25 : runCachedNode 511 130126 Adaptive144Third138Node25 = false := by
  decide +kernel

#print axioms adaptive144Third138Proof25

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third138Proof162 : runCachedNode 511 130126 Adaptive144Third138Node162 = false := by
  decide +kernel

#print axioms adaptive144Third138Proof162

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third138Proof52 : runCachedNode 511 130126 Adaptive144Third138Node52 = false := by
  decide +kernel

#print axioms adaptive144Third138Proof52

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third138Proof53 : runCachedNode 511 130126 Adaptive144Third138Node53 = false := by
  decide +kernel

#print axioms adaptive144Third138Proof53

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third138Proof75 : runCachedNode 511 130126 Adaptive144Third138Node75 = false := by
  decide +kernel

#print axioms adaptive144Third138Proof75

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third138Proof3 : runCachedNode 511 130126 Adaptive144Third138Node3 = false := by
  decide +kernel

#print axioms adaptive144Third138Proof3

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third138Proof24 : runCachedNode 511 130126 Adaptive144Third138Node24 = false := by
  decide +kernel

#print axioms adaptive144Third138Proof24

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third138Proof194 : runCachedNode 511 130126 Adaptive144Third138Node194 = false := by
  decide +kernel

#print axioms adaptive144Third138Proof194

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third138Proof51 : runCachedNode 511 130126 Adaptive144Third138Node51 = false := by
  decide +kernel

#print axioms adaptive144Third138Proof51

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third138Proof2 : runCachedNode 511 130126 Adaptive144Third138Node2 = false := by
  decide +kernel

#print axioms adaptive144Third138Proof2

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third138Proof133 : runCachedNode 511 130126 Adaptive144Third138Node133 = false := by
  decide +kernel

#print axioms adaptive144Third138Proof133

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third138Proof161 : runCachedNode 511 130126 Adaptive144Third138Node161 = false := by
  decide +kernel

#print axioms adaptive144Third138Proof161

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third138Proof193 : runCachedNode 511 130126 Adaptive144Third138Node193 = false := by
  decide +kernel

#print axioms adaptive144Third138Proof193

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third138Proof50 : runCachedNode 511 130126 Adaptive144Third138Node50 = false := by
  decide +kernel

#print axioms adaptive144Third138Proof50

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third138Proof74 : runCachedNode 511 130126 Adaptive144Third138Node74 = false := by
  decide +kernel

#print axioms adaptive144Third138Proof74

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third138Proof104 : runCachedNode 511 130126 Adaptive144Third138Node104 = false := by
  decide +kernel

#print axioms adaptive144Third138Proof104

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third138Proof105 : runCachedNode 511 130126 Adaptive144Third138Node105 = false := by
  decide +kernel

#print axioms adaptive144Third138Proof105

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third138Proof49 : runCachedNode 511 130126 Adaptive144Third138Node49 = false := by
  decide +kernel

#print axioms adaptive144Third138Proof49

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third138Proof103 : runCachedNode 511 130126 Adaptive144Third138Node103 = false := by
  decide +kernel

#print axioms adaptive144Third138Proof103

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third138Proof132 : runCachedNode 511 130126 Adaptive144Third138Node132 = false := by
  decide +kernel

#print axioms adaptive144Third138Proof132

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third138Proof159 : runCachedNode 511 130126 Adaptive144Third138Node159 = false := by
  decide +kernel

#print axioms adaptive144Third138Proof159

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third138Proof160 : runCachedNode 511 130126 Adaptive144Third138Node160 = false := by
  decide +kernel

#print axioms adaptive144Third138Proof160

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third138Proof192 : runCachedNode 511 130126 Adaptive144Third138Node192 = false := by
  decide +kernel

#print axioms adaptive144Third138Proof192

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third138Proof48 : runCachedNode 511 130126 Adaptive144Third138Node48 = false := by
  decide +kernel

#print axioms adaptive144Third138Proof48

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third138Proof102 : runCachedNode 511 130126 Adaptive144Third138Node102 = false := by
  decide +kernel

#print axioms adaptive144Third138Proof102

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third138Proof130 : runCachedNode 511 130126 Adaptive144Third138Node130 = false := by
  decide +kernel

#print axioms adaptive144Third138Proof130

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third138Proof131 : runCachedNode 511 130126 Adaptive144Third138Node131 = false := by
  decide +kernel

#print axioms adaptive144Third138Proof131

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third138Proof158 : runCachedNode 511 130126 Adaptive144Third138Node158 = false := by
  decide +kernel

#print axioms adaptive144Third138Proof158

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third138Proof191 : runCachedNode 511 130126 Adaptive144Third138Node191 = false := by
  decide +kernel

#print axioms adaptive144Third138Proof191

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third138Proof46 : runCachedNode 511 130126 Adaptive144Third138Node46 = false := by
  decide +kernel

#print axioms adaptive144Third138Proof46

end NineSeparatedSubsetSums
