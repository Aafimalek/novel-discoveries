import NineSeparatedSubsetSums.Adaptive144Third132State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third132Proof14 : runCachedNode 511 129155 Adaptive144Third132Node14 = false := by
  decide +kernel

#print axioms adaptive144Third132Proof14

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third132Proof12 : runCachedNode 511 129155 Adaptive144Third132Node12 = false := by
  decide +kernel

#print axioms adaptive144Third132Proof12

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third132Proof10 : runCachedNode 511 129155 Adaptive144Third132Node10 = false := by
  decide +kernel

#print axioms adaptive144Third132Proof10

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third132Proof9 : runCachedNode 511 129155 Adaptive144Third132Node9 = false := by
  decide +kernel

#print axioms adaptive144Third132Proof9

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third132Proof7 : runCachedNode 511 129155 Adaptive144Third132Node7 = false := by
  decide +kernel

#print axioms adaptive144Third132Proof7

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third132Proof6 : runCachedNode 511 129155 Adaptive144Third132Node6 = false := by
  decide +kernel

#print axioms adaptive144Third132Proof6

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third132Proof5 : runCachedNode 511 129155 Adaptive144Third132Node5 = false := by
  decide +kernel

#print axioms adaptive144Third132Proof5

end NineSeparatedSubsetSums
