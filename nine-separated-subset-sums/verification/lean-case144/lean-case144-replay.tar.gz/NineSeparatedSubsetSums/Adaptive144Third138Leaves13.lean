import NineSeparatedSubsetSums.Adaptive144Third138State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third138Proof93 : runCachedNode 511 130126 Adaptive144Third138Node93 = false := by
  decide +kernel

#print axioms adaptive144Third138Proof93

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third138Proof14 : runCachedNode 511 130126 Adaptive144Third138Node14 = false := by
  decide +kernel

#print axioms adaptive144Third138Proof14

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third138Proof68 : runCachedNode 511 130126 Adaptive144Third138Node68 = false := by
  decide +kernel

#print axioms adaptive144Third138Proof68

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third138Proof92 : runCachedNode 511 130126 Adaptive144Third138Node92 = false := by
  decide +kernel

#print axioms adaptive144Third138Proof92

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third138Proof13 : runCachedNode 511 130126 Adaptive144Third138Node13 = false := by
  decide +kernel

#print axioms adaptive144Third138Proof13

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third138Proof173 : runCachedNode 511 130126 Adaptive144Third138Node173 = false := by
  decide +kernel

#print axioms adaptive144Third138Proof173

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third138Proof1 : runCachedNode 511 130126 Adaptive144Third138Node1 = false := by
  decide +kernel

#print axioms adaptive144Third138Proof1

end NineSeparatedSubsetSums
