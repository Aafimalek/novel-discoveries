import NineSeparatedSubsetSums.Adaptive144Third140State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof483 : runCachedNode 511 130381 Adaptive144Third140Node483 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof483

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof593 : runCachedNode 511 130381 Adaptive144Third140Node593 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof593

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof58 : runCachedNode 511 130381 Adaptive144Third140Node58 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof58

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof192 : runCachedNode 511 130381 Adaptive144Third140Node192 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof192

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof569 : runCachedNode 511 130381 Adaptive144Third140Node569 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof569

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof358 : runCachedNode 511 130381 Adaptive144Third140Node358 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof358

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof79 : runCachedNode 511 130381 Adaptive144Third140Node79 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof79

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof716 : runCachedNode 511 130381 Adaptive144Third140Node716 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof716

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof672 : runCachedNode 511 130381 Adaptive144Third140Node672 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof672

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof673 : runCachedNode 511 130381 Adaptive144Third140Node673 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof673

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof253 : runCachedNode 511 130381 Adaptive144Third140Node253 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof253

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof382 : runCachedNode 511 130381 Adaptive144Third140Node382 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof382

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof56 : runCachedNode 511 130381 Adaptive144Third140Node56 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof56

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof131 : runCachedNode 511 130381 Adaptive144Third140Node131 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof131

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof519 : runCachedNode 511 130381 Adaptive144Third140Node519 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof519

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof627 : runCachedNode 511 130381 Adaptive144Third140Node627 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof627

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof207 : runCachedNode 511 130381 Adaptive144Third140Node207 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof207

end NineSeparatedSubsetSums
