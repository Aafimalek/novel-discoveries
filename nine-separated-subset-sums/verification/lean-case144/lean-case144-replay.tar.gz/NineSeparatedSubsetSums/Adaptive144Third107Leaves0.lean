import NineSeparatedSubsetSums.Adaptive144Third107State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third107Proof0 : runCachedNode 511 112221 Adaptive144Third107Node0 = false := by
  decide +kernel

#print axioms adaptive144Third107Proof0

end NineSeparatedSubsetSums
