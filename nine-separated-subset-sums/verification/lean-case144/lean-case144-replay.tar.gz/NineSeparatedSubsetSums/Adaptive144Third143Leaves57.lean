import NineSeparatedSubsetSums.Adaptive144Third143State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third143Proof618 : runCachedNode 511 130885 Adaptive144Third143Node618 = false := by
  decide +kernel

#print axioms adaptive144Third143Proof618

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third143Proof619 : runCachedNode 511 130885 Adaptive144Third143Node619 = false := by
  decide +kernel

#print axioms adaptive144Third143Proof619

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third143Proof620 : runCachedNode 511 130885 Adaptive144Third143Node620 = false := by
  decide +kernel

#print axioms adaptive144Third143Proof620

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third143Proof621 : runCachedNode 511 130885 Adaptive144Third143Node621 = false := by
  decide +kernel

#print axioms adaptive144Third143Proof621

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third143Proof622 : runCachedNode 511 130885 Adaptive144Third143Node622 = false := by
  decide +kernel

#print axioms adaptive144Third143Proof622

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third143Proof623 : runCachedNode 511 130885 Adaptive144Third143Node623 = false := by
  decide +kernel

#print axioms adaptive144Third143Proof623

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third143Proof624 : runCachedNode 511 130885 Adaptive144Third143Node624 = false := by
  decide +kernel

#print axioms adaptive144Third143Proof624

end NineSeparatedSubsetSums
