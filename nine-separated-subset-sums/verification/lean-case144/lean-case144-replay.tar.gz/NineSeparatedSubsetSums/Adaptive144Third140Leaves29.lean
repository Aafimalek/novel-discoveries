import NineSeparatedSubsetSums.Adaptive144Third140State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof262 : runCachedNode 511 130381 Adaptive144Third140Node262 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof262

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof489 : runCachedNode 511 130381 Adaptive144Third140Node489 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof489

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof115 : runCachedNode 511 130381 Adaptive144Third140Node115 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof115

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof259 : runCachedNode 511 130381 Adaptive144Third140Node259 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof259

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof430 : runCachedNode 511 130381 Adaptive144Third140Node430 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof430

end NineSeparatedSubsetSums
