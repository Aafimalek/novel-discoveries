import NineSeparatedSubsetSums.Adaptive144Third140State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof65 : runCachedNode 511 130381 Adaptive144Third140Node65 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof65

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof12 : runCachedNode 511 130381 Adaptive144Third140Node12 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof12

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof137 : runCachedNode 511 130381 Adaptive144Third140Node137 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof137

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof321 : runCachedNode 511 130381 Adaptive144Third140Node321 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof321

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof431 : runCachedNode 511 130381 Adaptive144Third140Node431 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof431

end NineSeparatedSubsetSums
