import NineSeparatedSubsetSums.Adaptive144Third137State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third137Proof93 : runCachedNode 511 129993 Adaptive144Third137Node93 = false := by
  decide +kernel

#print axioms adaptive144Third137Proof93

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third137Proof42 : runCachedNode 511 129993 Adaptive144Third137Node42 = false := by
  decide +kernel

#print axioms adaptive144Third137Proof42

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third137Proof68 : runCachedNode 511 129993 Adaptive144Third137Node68 = false := by
  decide +kernel

#print axioms adaptive144Third137Proof68

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third137Proof95 : runCachedNode 511 129993 Adaptive144Third137Node95 = false := by
  decide +kernel

#print axioms adaptive144Third137Proof95

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third137Proof14 : runCachedNode 511 129993 Adaptive144Third137Node14 = false := by
  decide +kernel

#print axioms adaptive144Third137Proof14

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third137Proof79 : runCachedNode 511 129993 Adaptive144Third137Node79 = false := by
  decide +kernel

#print axioms adaptive144Third137Proof79

end NineSeparatedSubsetSums
