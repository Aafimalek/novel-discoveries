import NineSeparatedSubsetSums.Adaptive144Third143State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third143Proof534 : runCachedNode 511 130885 Adaptive144Third143Node534 = false := by
  decide +kernel

#print axioms adaptive144Third143Proof534

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third143Proof47 : runCachedNode 511 130885 Adaptive144Third143Node47 = false := by
  decide +kernel

#print axioms adaptive144Third143Proof47

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third143Proof102 : runCachedNode 511 130885 Adaptive144Third143Node102 = false := by
  decide +kernel

#print axioms adaptive144Third143Proof102

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third143Proof191 : runCachedNode 511 130885 Adaptive144Third143Node191 = false := by
  decide +kernel

#print axioms adaptive144Third143Proof191

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third143Proof453 : runCachedNode 511 130885 Adaptive144Third143Node453 = false := by
  decide +kernel

#print axioms adaptive144Third143Proof453

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third143Proof223 : runCachedNode 511 130885 Adaptive144Third143Node223 = false := by
  decide +kernel

#print axioms adaptive144Third143Proof223

end NineSeparatedSubsetSums
