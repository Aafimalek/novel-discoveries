import NineSeparatedSubsetSums.EightPointPackedGeometry
import NineSeparatedSubsetSums.EightPoint144_117PackedBudget0
import NineSeparatedSubsetSums.EightPoint144_117PackedAnchor0Part0
import NineSeparatedSubsetSums.EightPoint144_117PackedAnchor0Part1
import NineSeparatedSubsetSums.EightPoint144_117PackedAnchor0Part2
import NineSeparatedSubsetSums.EightPoint144_117PackedBudget1
import NineSeparatedSubsetSums.EightPoint144_117PackedAnchor1Part0
import NineSeparatedSubsetSums.EightPoint144_117PackedAnchor1Part1
import NineSeparatedSubsetSums.EightPoint144_117PackedAnchor1Part2

namespace NineSeparatedSubsetSums

private theorem packedOct144_117Anchor0 :
  ∀ j : Fin 494, ((j.val : Int)+144+117)%2=0 →
    2399993 ≤ FourPointNumeric.octPackedCharge 144 117 20 packedOct144_117_0 (j.val : Int) := by
  intro j hj
  let k := (j.val-1)/2
  have hk : k < 247 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+1 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint144_117PackedAnchor0Part0 z
    rwa [he,hrep] at ht
  by_cases h1 : k < 240
  · let z : Fin 120 := ⟨k-120, by omega⟩
    have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
    have ht := eightPoint144_117PackedAnchor0Part1 z
    rwa [he,hrep] at ht
  let z : Fin 7 := ⟨k-240, by omega⟩
  have he : (z.val : Int)+240 = k := by dsimp [z] <;> omega
  have ht := eightPoint144_117PackedAnchor0Part2 z
  rwa [he,hrep] at ht

private theorem packedOct144_117Anchor1 :
  ∀ j : Fin 494, ((j.val : Int)+144+117)%2=1 →
    2392629 ≤ FourPointNumeric.octPackedCharge 144 117 20 packedOct144_117_1 (j.val : Int) := by
  intro j hj
  let k := (j.val-0)/2
  have hk : k < 247 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+0 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint144_117PackedAnchor1Part0 z
    rwa [he,hrep] at ht
  by_cases h1 : k < 240
  · let z : Fin 120 := ⟨k-120, by omega⟩
    have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
    have ht := eightPoint144_117PackedAnchor1Part1 z
    rwa [he,hrep] at ht
  let z : Fin 7 := ⟨k-240, by omega⟩
  have he : (z.val : Int)+240 = k := by dsimp [z] <;> omega
  have ht := eightPoint144_117PackedAnchor1Part2 z
  rwa [he,hrep] at ht

def packedOctCertificate144_117_0 : EightPointCertificate 144 117 0 125665 :=
  eightPointCertificateOfPacked 144 117 0 125665 2399993 20 packedOct144_117_0 457 494
    (by decide +kernel) (by decide) packedOct144_117Anchor0
    (by rw [packedOct144_117_0_budget]; decide)

def packedOctCertificate144_117_1 : EightPointCertificate 144 117 1 125665 :=
  eightPointCertificateOfPacked 144 117 1 125665 2392629 20 packedOct144_117_1 460 494
    (by decide +kernel) (by decide) packedOct144_117Anchor1
    (by rw [packedOct144_117_1_budget]; decide)

theorem max148_second144_third117_eightPoint_moment_bound (tail : List ℕ) (len : tail.length=6)
    (distinct : (natSubsetSums (148::144::117::tail)).Nodup) :
    125665 ≤ ((148::144::117::tail).map (· ^ 2)).sum := by
  apply eightPointNatMomentLower 144 117 125665 tail len distinct
  intro p hp
  by_cases h : p=0
  · subst p
    exact packedOctCertificate144_117_0
  · have he : p=1 := hp.resolve_left h
    subst p
    exact packedOctCertificate144_117_1

#print axioms max148_second144_third117_eightPoint_moment_bound

end NineSeparatedSubsetSums
