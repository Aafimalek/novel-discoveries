import NineSeparatedSubsetSums.Adaptive144Third140State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof297 : runCachedNode 511 130381 Adaptive144Third140Node297 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof297

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof361 : runCachedNode 511 130381 Adaptive144Third140Node361 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof361

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof260 : runCachedNode 511 130381 Adaptive144Third140Node260 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof260

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof168 : runCachedNode 511 130381 Adaptive144Third140Node168 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof168

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof529 : runCachedNode 511 130381 Adaptive144Third140Node529 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof529

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof55 : runCachedNode 511 130381 Adaptive144Third140Node55 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof55

end NineSeparatedSubsetSums
