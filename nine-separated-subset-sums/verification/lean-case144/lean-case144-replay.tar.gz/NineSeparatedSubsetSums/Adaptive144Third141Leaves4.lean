import NineSeparatedSubsetSums.Adaptive144Third141State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third141Proof23 : runCachedNode 511 130584 Adaptive144Third141Node23 = false := by
  decide +kernel

#print axioms adaptive144Third141Proof23

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third141Proof302 : runCachedNode 511 130584 Adaptive144Third141Node302 = false := by
  decide +kernel

#print axioms adaptive144Third141Proof302

end NineSeparatedSubsetSums
