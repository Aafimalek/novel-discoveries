import NineSeparatedSubsetSums.Adaptive144Third140State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof573 : runCachedNode 511 130381 Adaptive144Third140Node573 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof573

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof13 : runCachedNode 511 130381 Adaptive144Third140Node13 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof13

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof199 : runCachedNode 511 130381 Adaptive144Third140Node199 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof199

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof71 : runCachedNode 511 130381 Adaptive144Third140Node71 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof71

end NineSeparatedSubsetSums
