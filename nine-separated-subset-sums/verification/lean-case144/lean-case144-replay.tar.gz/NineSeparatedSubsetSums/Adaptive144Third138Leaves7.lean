import NineSeparatedSubsetSums.Adaptive144Third138State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third138Proof123 : runCachedNode 511 130126 Adaptive144Third138Node123 = false := by
  decide +kernel

#print axioms adaptive144Third138Proof123

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third138Proof18 : runCachedNode 511 130126 Adaptive144Third138Node18 = false := by
  decide +kernel

#print axioms adaptive144Third138Proof18

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third138Proof65 : runCachedNode 511 130126 Adaptive144Third138Node65 = false := by
  decide +kernel

#print axioms adaptive144Third138Proof65

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third138Proof98 : runCachedNode 511 130126 Adaptive144Third138Node98 = false := by
  decide +kernel

#print axioms adaptive144Third138Proof98

end NineSeparatedSubsetSums
