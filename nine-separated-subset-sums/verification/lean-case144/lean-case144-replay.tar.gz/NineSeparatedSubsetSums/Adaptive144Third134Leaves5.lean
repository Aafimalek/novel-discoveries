import NineSeparatedSubsetSums.Adaptive144Third134State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third134Proof43 : runCachedNode 511 129525 Adaptive144Third134Node43 = false := by
  decide +kernel

#print axioms adaptive144Third134Proof43

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third134Proof13 : runCachedNode 511 129525 Adaptive144Third134Node13 = false := by
  decide +kernel

#print axioms adaptive144Third134Proof13

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third134Proof45 : runCachedNode 511 129525 Adaptive144Third134Node45 = false := by
  decide +kernel

#print axioms adaptive144Third134Proof45

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third134Proof68 : runCachedNode 511 129525 Adaptive144Third134Node68 = false := by
  decide +kernel

#print axioms adaptive144Third134Proof68

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third134Proof44 : runCachedNode 511 129525 Adaptive144Third134Node44 = false := by
  decide +kernel

#print axioms adaptive144Third134Proof44

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third134Proof12 : runCachedNode 511 129525 Adaptive144Third134Node12 = false := by
  decide +kernel

#print axioms adaptive144Third134Proof12

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third134Proof66 : runCachedNode 511 129525 Adaptive144Third134Node66 = false := by
  decide +kernel

#print axioms adaptive144Third134Proof66

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third134Proof38 : runCachedNode 511 129525 Adaptive144Third134Node38 = false := by
  decide +kernel

#print axioms adaptive144Third134Proof38

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third134Proof1 : runCachedNode 511 129525 Adaptive144Third134Node1 = false := by
  decide +kernel

#print axioms adaptive144Third134Proof1

end NineSeparatedSubsetSums
