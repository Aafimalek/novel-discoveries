import NineSeparatedSubsetSums.Adaptive144Third141State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third141Proof310 : runCachedNode 511 130584 Adaptive144Third141Node310 = false := by
  decide +kernel

#print axioms adaptive144Third141Proof310

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third141Proof18 : runCachedNode 511 130584 Adaptive144Third141Node18 = false := by
  decide +kernel

#print axioms adaptive144Third141Proof18

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third141Proof191 : runCachedNode 511 130584 Adaptive144Third141Node191 = false := by
  decide +kernel

#print axioms adaptive144Third141Proof191

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third141Proof109 : runCachedNode 511 130584 Adaptive144Third141Node109 = false := by
  decide +kernel

#print axioms adaptive144Third141Proof109

end NineSeparatedSubsetSums
