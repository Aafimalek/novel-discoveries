import NineSeparatedSubsetSums.Adaptive144Third142State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third142Proof612 : runCachedNode 511 130737 Adaptive144Third142Node612 = false := by
  decide +kernel

#print axioms adaptive144Third142Proof612

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third142Proof450 : runCachedNode 511 130737 Adaptive144Third142Node450 = false := by
  decide +kernel

#print axioms adaptive144Third142Proof450

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third142Proof18 : runCachedNode 511 130737 Adaptive144Third142Node18 = false := by
  decide +kernel

#print axioms adaptive144Third142Proof18

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third142Proof4 : runCachedNode 511 130737 Adaptive144Third142Node4 = false := by
  decide +kernel

#print axioms adaptive144Third142Proof4

end NineSeparatedSubsetSums
