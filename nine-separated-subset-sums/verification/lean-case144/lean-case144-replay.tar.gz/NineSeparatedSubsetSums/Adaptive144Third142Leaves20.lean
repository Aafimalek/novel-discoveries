import NineSeparatedSubsetSums.Adaptive144Third142State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third142Proof17 : runCachedNode 511 130737 Adaptive144Third142Node17 = false := by
  decide +kernel

#print axioms adaptive144Third142Proof17

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third142Proof613 : runCachedNode 511 130737 Adaptive144Third142Node613 = false := by
  decide +kernel

#print axioms adaptive144Third142Proof613

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third142Proof411 : runCachedNode 511 130737 Adaptive144Third142Node411 = false := by
  decide +kernel

#print axioms adaptive144Third142Proof411

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third142Proof77 : runCachedNode 511 130737 Adaptive144Third142Node77 = false := by
  decide +kernel

#print axioms adaptive144Third142Proof77

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third142Proof86 : runCachedNode 511 130737 Adaptive144Third142Node86 = false := by
  decide +kernel

#print axioms adaptive144Third142Proof86

end NineSeparatedSubsetSums
