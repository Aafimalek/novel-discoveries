import NineSeparatedSubsetSums.Adaptive144Third140State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof492 : runCachedNode 511 130381 Adaptive144Third140Node492 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof492

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof90 : runCachedNode 511 130381 Adaptive144Third140Node90 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof90

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof525 : runCachedNode 511 130381 Adaptive144Third140Node525 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof525

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof230 : runCachedNode 511 130381 Adaptive144Third140Node230 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof230

end NineSeparatedSubsetSums
