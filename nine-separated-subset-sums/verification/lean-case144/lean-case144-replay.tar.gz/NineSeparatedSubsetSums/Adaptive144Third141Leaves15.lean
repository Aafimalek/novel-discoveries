import NineSeparatedSubsetSums.Adaptive144Third141State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third141Proof234 : runCachedNode 511 130584 Adaptive144Third141Node234 = false := by
  decide +kernel

#print axioms adaptive144Third141Proof234

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third141Proof202 : runCachedNode 511 130584 Adaptive144Third141Node202 = false := by
  decide +kernel

#print axioms adaptive144Third141Proof202

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third141Proof93 : runCachedNode 511 130584 Adaptive144Third141Node93 = false := by
  decide +kernel

#print axioms adaptive144Third141Proof93

end NineSeparatedSubsetSums
