import NineSeparatedSubsetSums.Adaptive144Third141State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third141Proof135 : runCachedNode 511 130584 Adaptive144Third141Node135 = false := by
  decide +kernel

#print axioms adaptive144Third141Proof135

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third141Proof347 : runCachedNode 511 130584 Adaptive144Third141Node347 = false := by
  decide +kernel

#print axioms adaptive144Third141Proof347

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third141Proof102 : runCachedNode 511 130584 Adaptive144Third141Node102 = false := by
  decide +kernel

#print axioms adaptive144Third141Proof102

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third141Proof434 : runCachedNode 511 130584 Adaptive144Third141Node434 = false := by
  decide +kernel

#print axioms adaptive144Third141Proof434

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third141Proof231 : runCachedNode 511 130584 Adaptive144Third141Node231 = false := by
  decide +kernel

#print axioms adaptive144Third141Proof231

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third141Proof156 : runCachedNode 511 130584 Adaptive144Third141Node156 = false := by
  decide +kernel

#print axioms adaptive144Third141Proof156

end NineSeparatedSubsetSums
