import NineSeparatedSubsetSums.Adaptive144Third143State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third143Proof17 : runCachedNode 511 130885 Adaptive144Third143Node17 = false := by
  decide +kernel

#print axioms adaptive144Third143Proof17

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third143Proof133 : runCachedNode 511 130885 Adaptive144Third143Node133 = false := by
  decide +kernel

#print axioms adaptive144Third143Proof133

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third143Proof164 : runCachedNode 511 130885 Adaptive144Third143Node164 = false := by
  decide +kernel

#print axioms adaptive144Third143Proof164

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third143Proof59 : runCachedNode 511 130885 Adaptive144Third143Node59 = false := by
  decide +kernel

#print axioms adaptive144Third143Proof59

end NineSeparatedSubsetSums
