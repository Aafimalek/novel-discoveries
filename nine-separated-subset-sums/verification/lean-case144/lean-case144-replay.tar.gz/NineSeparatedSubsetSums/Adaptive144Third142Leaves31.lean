import NineSeparatedSubsetSums.Adaptive144Third142State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third142Proof14 : runCachedNode 511 130737 Adaptive144Third142Node14 = false := by
  decide +kernel

#print axioms adaptive144Third142Proof14

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third142Proof294 : runCachedNode 511 130737 Adaptive144Third142Node294 = false := by
  decide +kernel

#print axioms adaptive144Third142Proof294

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third142Proof448 : runCachedNode 511 130737 Adaptive144Third142Node448 = false := by
  decide +kernel

#print axioms adaptive144Third142Proof448

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third142Proof335 : runCachedNode 511 130737 Adaptive144Third142Node335 = false := by
  decide +kernel

#print axioms adaptive144Third142Proof335

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third142Proof326 : runCachedNode 511 130737 Adaptive144Third142Node326 = false := by
  decide +kernel

#print axioms adaptive144Third142Proof326

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third142Proof404 : runCachedNode 511 130737 Adaptive144Third142Node404 = false := by
  decide +kernel

#print axioms adaptive144Third142Proof404

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third142Proof225 : runCachedNode 511 130737 Adaptive144Third142Node225 = false := by
  decide +kernel

#print axioms adaptive144Third142Proof225

end NineSeparatedSubsetSums
