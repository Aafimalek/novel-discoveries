import NineSeparatedSubsetSums.Adaptive144Third143State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third143Proof126 : runCachedNode 511 130885 Adaptive144Third143Node126 = false := by
  decide +kernel

#print axioms adaptive144Third143Proof126

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third143Proof319 : runCachedNode 511 130885 Adaptive144Third143Node319 = false := by
  decide +kernel

#print axioms adaptive144Third143Proof319

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third143Proof408 : runCachedNode 511 130885 Adaptive144Third143Node408 = false := by
  decide +kernel

#print axioms adaptive144Third143Proof408

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third143Proof189 : runCachedNode 511 130885 Adaptive144Third143Node189 = false := by
  decide +kernel

#print axioms adaptive144Third143Proof189

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third143Proof559 : runCachedNode 511 130885 Adaptive144Third143Node559 = false := by
  decide +kernel

#print axioms adaptive144Third143Proof559

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third143Proof43 : runCachedNode 511 130885 Adaptive144Third143Node43 = false := by
  decide +kernel

#print axioms adaptive144Third143Proof43

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third143Proof613 : runCachedNode 511 130885 Adaptive144Third143Node613 = false := by
  decide +kernel

#print axioms adaptive144Third143Proof613

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third143Proof645 : runCachedNode 511 130885 Adaptive144Third143Node645 = false := by
  decide +kernel

#print axioms adaptive144Third143Proof645

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third143Proof44 : runCachedNode 511 130885 Adaptive144Third143Node44 = false := by
  decide +kernel

#print axioms adaptive144Third143Proof44

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third143Proof251 : runCachedNode 511 130885 Adaptive144Third143Node251 = false := by
  decide +kernel

#print axioms adaptive144Third143Proof251

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third143Proof249 : runCachedNode 511 130885 Adaptive144Third143Node249 = false := by
  decide +kernel

#print axioms adaptive144Third143Proof249

end NineSeparatedSubsetSums
