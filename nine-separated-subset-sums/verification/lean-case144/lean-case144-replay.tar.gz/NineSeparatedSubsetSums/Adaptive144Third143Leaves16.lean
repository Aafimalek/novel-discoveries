import NineSeparatedSubsetSums.Adaptive144Third143State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third143Proof492 : runCachedNode 511 130885 Adaptive144Third143Node492 = false := by
  decide +kernel

#print axioms adaptive144Third143Proof492

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third143Proof163 : runCachedNode 511 130885 Adaptive144Third143Node163 = false := by
  decide +kernel

#print axioms adaptive144Third143Proof163

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third143Proof647 : runCachedNode 511 130885 Adaptive144Third143Node647 = false := by
  decide +kernel

#print axioms adaptive144Third143Proof647

end NineSeparatedSubsetSums
