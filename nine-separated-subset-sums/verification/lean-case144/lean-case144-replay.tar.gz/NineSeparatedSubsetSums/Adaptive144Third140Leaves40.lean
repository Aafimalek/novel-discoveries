import NineSeparatedSubsetSums.Adaptive144Third140State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof196 : runCachedNode 511 130381 Adaptive144Third140Node196 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof196

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof526 : runCachedNode 511 130381 Adaptive144Third140Node526 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof526

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof134 : runCachedNode 511 130381 Adaptive144Third140Node134 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof134

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof520 : runCachedNode 511 130381 Adaptive144Third140Node520 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof520

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof596 : runCachedNode 511 130381 Adaptive144Third140Node596 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof596

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof288 : runCachedNode 511 130381 Adaptive144Third140Node288 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof288

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof173 : runCachedNode 511 130381 Adaptive144Third140Node173 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof173

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof433 : runCachedNode 511 130381 Adaptive144Third140Node433 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof433

end NineSeparatedSubsetSums
