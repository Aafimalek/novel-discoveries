import NineSeparatedSubsetSums.Adaptive144Third142State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third142Proof233 : runCachedNode 511 130737 Adaptive144Third142Node233 = false := by
  decide +kernel

#print axioms adaptive144Third142Proof233

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third142Proof655 : runCachedNode 511 130737 Adaptive144Third142Node655 = false := by
  decide +kernel

#print axioms adaptive144Third142Proof655

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third142Proof488 : runCachedNode 511 130737 Adaptive144Third142Node488 = false := by
  decide +kernel

#print axioms adaptive144Third142Proof488

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third142Proof197 : runCachedNode 511 130737 Adaptive144Third142Node197 = false := by
  decide +kernel

#print axioms adaptive144Third142Proof197

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third142Proof164 : runCachedNode 511 130737 Adaptive144Third142Node164 = false := by
  decide +kernel

#print axioms adaptive144Third142Proof164

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third142Proof447 : runCachedNode 511 130737 Adaptive144Third142Node447 = false := by
  decide +kernel

#print axioms adaptive144Third142Proof447

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third142Proof574 : runCachedNode 511 130737 Adaptive144Third142Node574 = false := by
  decide +kernel

#print axioms adaptive144Third142Proof574

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third142Proof157 : runCachedNode 511 130737 Adaptive144Third142Node157 = false := by
  decide +kernel

#print axioms adaptive144Third142Proof157

end NineSeparatedSubsetSums
