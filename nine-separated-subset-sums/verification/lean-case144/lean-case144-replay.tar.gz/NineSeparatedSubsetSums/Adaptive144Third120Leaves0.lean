import NineSeparatedSubsetSums.Adaptive144Third120State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third120Proof0 : runCachedNode 511 126045 Adaptive144Third120Node0 = false := by
  decide +kernel

#print axioms adaptive144Third120Proof0

end NineSeparatedSubsetSums
