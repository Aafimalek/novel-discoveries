import NineSeparatedSubsetSums.Adaptive144Third142State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third142Proof266 : runCachedNode 511 130737 Adaptive144Third142Node266 = false := by
  decide +kernel

#print axioms adaptive144Third142Proof266

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third142Proof328 : runCachedNode 511 130737 Adaptive144Third142Node328 = false := by
  decide +kernel

#print axioms adaptive144Third142Proof328

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third142Proof173 : runCachedNode 511 130737 Adaptive144Third142Node173 = false := by
  decide +kernel

#print axioms adaptive144Third142Proof173

end NineSeparatedSubsetSums
