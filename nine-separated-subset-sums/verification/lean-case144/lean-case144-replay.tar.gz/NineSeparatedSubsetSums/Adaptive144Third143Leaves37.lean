import NineSeparatedSubsetSums.Adaptive144Third143State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third143Proof252 : runCachedNode 511 130885 Adaptive144Third143Node252 = false := by
  decide +kernel

#print axioms adaptive144Third143Proof252

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third143Proof451 : runCachedNode 511 130885 Adaptive144Third143Node451 = false := by
  decide +kernel

#print axioms adaptive144Third143Proof451

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third143Proof648 : runCachedNode 511 130885 Adaptive144Third143Node648 = false := by
  decide +kernel

#print axioms adaptive144Third143Proof648

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third143Proof561 : runCachedNode 511 130885 Adaptive144Third143Node561 = false := by
  decide +kernel

#print axioms adaptive144Third143Proof561

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third143Proof649 : runCachedNode 511 130885 Adaptive144Third143Node649 = false := by
  decide +kernel

#print axioms adaptive144Third143Proof649

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third143Proof98 : runCachedNode 511 130885 Adaptive144Third143Node98 = false := by
  decide +kernel

#print axioms adaptive144Third143Proof98

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third143Proof190 : runCachedNode 511 130885 Adaptive144Third143Node190 = false := by
  decide +kernel

#print axioms adaptive144Third143Proof190

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third143Proof650 : runCachedNode 511 130885 Adaptive144Third143Node650 = false := by
  decide +kernel

#print axioms adaptive144Third143Proof650

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third143Proof532 : runCachedNode 511 130885 Adaptive144Third143Node532 = false := by
  decide +kernel

#print axioms adaptive144Third143Proof532

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third143Proof311 : runCachedNode 511 130885 Adaptive144Third143Node311 = false := by
  decide +kernel

#print axioms adaptive144Third143Proof311

end NineSeparatedSubsetSums
