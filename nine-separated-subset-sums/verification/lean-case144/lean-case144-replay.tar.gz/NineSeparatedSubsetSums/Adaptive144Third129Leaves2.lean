import NineSeparatedSubsetSums.Adaptive144Third129State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third129Proof5 : runCachedNode 511 128455 Adaptive144Third129Node5 = false := by
  decide +kernel

#print axioms adaptive144Third129Proof5

end NineSeparatedSubsetSums
