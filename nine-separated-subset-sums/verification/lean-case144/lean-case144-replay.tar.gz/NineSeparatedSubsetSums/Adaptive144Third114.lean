import NineSeparatedSubsetSums.Adaptive144Third114Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint144Checked

namespace NineSeparatedSubsetSums


theorem adaptive144Third114 : NoDescendingTailAfterThird 144 114 :=
  noDescendingThirdTail_of_cached 144 114 112221 (fun t ht nd => max148_second144_fourPoint_moment_bound (114::t) (by simp [ht]) nd) adaptive144Third114Proof0

#print axioms adaptive144Third114

end NineSeparatedSubsetSums
