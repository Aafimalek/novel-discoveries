import NineSeparatedSubsetSums.Adaptive144Third143State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third143Proof261 : runCachedNode 511 130885 Adaptive144Third143Node261 = false := by
  decide +kernel

#print axioms adaptive144Third143Proof261

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third143Proof330 : runCachedNode 511 130885 Adaptive144Third143Node330 = false := by
  decide +kernel

#print axioms adaptive144Third143Proof330

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third143Proof56 : runCachedNode 511 130885 Adaptive144Third143Node56 = false := by
  decide +kernel

#print axioms adaptive144Third143Proof56

end NineSeparatedSubsetSums
