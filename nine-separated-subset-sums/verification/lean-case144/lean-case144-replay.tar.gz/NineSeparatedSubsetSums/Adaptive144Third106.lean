import NineSeparatedSubsetSums.Adaptive144Third106Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint144Checked

namespace NineSeparatedSubsetSums


theorem adaptive144Third106 : NoDescendingTailAfterThird 144 106 :=
  noDescendingThirdTail_of_cached 144 106 112221 (fun t ht nd => max148_second144_fourPoint_moment_bound (106::t) (by simp [ht]) nd) adaptive144Third106Proof0

#print axioms adaptive144Third106

end NineSeparatedSubsetSums
