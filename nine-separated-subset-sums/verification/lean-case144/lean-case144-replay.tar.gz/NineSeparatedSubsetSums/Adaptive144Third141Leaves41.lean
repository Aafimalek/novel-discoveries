import NineSeparatedSubsetSums.Adaptive144Third141State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third141Proof357 : runCachedNode 511 130584 Adaptive144Third141Node357 = false := by
  decide +kernel

#print axioms adaptive144Third141Proof357

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third141Proof358 : runCachedNode 511 130584 Adaptive144Third141Node358 = false := by
  decide +kernel

#print axioms adaptive144Third141Proof358

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third141Proof394 : runCachedNode 511 130584 Adaptive144Third141Node394 = false := by
  decide +kernel

#print axioms adaptive144Third141Proof394

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third141Proof395 : runCachedNode 511 130584 Adaptive144Third141Node395 = false := by
  decide +kernel

#print axioms adaptive144Third141Proof395

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third141Proof396 : runCachedNode 511 130584 Adaptive144Third141Node396 = false := by
  decide +kernel

#print axioms adaptive144Third141Proof396

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third141Proof397 : runCachedNode 511 130584 Adaptive144Third141Node397 = false := by
  decide +kernel

#print axioms adaptive144Third141Proof397

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third141Proof398 : runCachedNode 511 130584 Adaptive144Third141Node398 = false := by
  decide +kernel

#print axioms adaptive144Third141Proof398

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third141Proof399 : runCachedNode 511 130584 Adaptive144Third141Node399 = false := by
  decide +kernel

#print axioms adaptive144Third141Proof399

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third141Proof400 : runCachedNode 511 130584 Adaptive144Third141Node400 = false := by
  decide +kernel

#print axioms adaptive144Third141Proof400

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third141Proof401 : runCachedNode 511 130584 Adaptive144Third141Node401 = false := by
  decide +kernel

#print axioms adaptive144Third141Proof401

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third141Proof402 : runCachedNode 511 130584 Adaptive144Third141Node402 = false := by
  decide +kernel

#print axioms adaptive144Third141Proof402

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third141Proof403 : runCachedNode 511 130584 Adaptive144Third141Node403 = false := by
  decide +kernel

#print axioms adaptive144Third141Proof403

end NineSeparatedSubsetSums
