import NineSeparatedSubsetSums.Adaptive144Third142State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third142Proof529 : runCachedNode 511 130737 Adaptive144Third142Node529 = false := by
  decide +kernel

#print axioms adaptive144Third142Proof529

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third142Proof73 : runCachedNode 511 130737 Adaptive144Third142Node73 = false := by
  decide +kernel

#print axioms adaptive144Third142Proof73

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third142Proof254 : runCachedNode 511 130737 Adaptive144Third142Node254 = false := by
  decide +kernel

#print axioms adaptive144Third142Proof254

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third142Proof133 : runCachedNode 511 130737 Adaptive144Third142Node133 = false := by
  decide +kernel

#print axioms adaptive144Third142Proof133

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third142Proof231 : runCachedNode 511 130737 Adaptive144Third142Node231 = false := by
  decide +kernel

#print axioms adaptive144Third142Proof231

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third142Proof653 : runCachedNode 511 130737 Adaptive144Third142Node653 = false := by
  decide +kernel

#print axioms adaptive144Third142Proof653

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third142Proof162 : runCachedNode 511 130737 Adaptive144Third142Node162 = false := by
  decide +kernel

#print axioms adaptive144Third142Proof162

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third142Proof290 : runCachedNode 511 130737 Adaptive144Third142Node290 = false := by
  decide +kernel

#print axioms adaptive144Third142Proof290

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third142Proof297 : runCachedNode 511 130737 Adaptive144Third142Node297 = false := by
  decide +kernel

#print axioms adaptive144Third142Proof297

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third142Proof255 : runCachedNode 511 130737 Adaptive144Third142Node255 = false := by
  decide +kernel

#print axioms adaptive144Third142Proof255

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third142Proof652 : runCachedNode 511 130737 Adaptive144Third142Node652 = false := by
  decide +kernel

#print axioms adaptive144Third142Proof652

end NineSeparatedSubsetSums
