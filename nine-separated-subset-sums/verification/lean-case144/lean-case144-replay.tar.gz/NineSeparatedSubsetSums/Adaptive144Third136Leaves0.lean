import NineSeparatedSubsetSums.Adaptive144Third136State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third136Proof19 : runCachedNode 511 129800 Adaptive144Third136Node19 = false := by
  decide +kernel

#print axioms adaptive144Third136Proof19

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third136Proof69 : runCachedNode 511 129800 Adaptive144Third136Node69 = false := by
  decide +kernel

#print axioms adaptive144Third136Proof69

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third136Proof24 : runCachedNode 511 129800 Adaptive144Third136Node24 = false := by
  decide +kernel

#print axioms adaptive144Third136Proof24

end NineSeparatedSubsetSums
