import NineSeparatedSubsetSums.Adaptive144Third139State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third139Proof11 : runCachedNode 511 130274 Adaptive144Third139Node11 = false := by
  decide +kernel

#print axioms adaptive144Third139Proof11

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third139Proof65 : runCachedNode 511 130274 Adaptive144Third139Node65 = false := by
  decide +kernel

#print axioms adaptive144Third139Proof65

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third139Proof92 : runCachedNode 511 130274 Adaptive144Third139Node92 = false := by
  decide +kernel

#print axioms adaptive144Third139Proof92

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third139Proof41 : runCachedNode 511 130274 Adaptive144Third139Node41 = false := by
  decide +kernel

#print axioms adaptive144Third139Proof41

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third139Proof143 : runCachedNode 511 130274 Adaptive144Third139Node143 = false := by
  decide +kernel

#print axioms adaptive144Third139Proof143

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third139Proof146 : runCachedNode 511 130274 Adaptive144Third139Node146 = false := by
  decide +kernel

#print axioms adaptive144Third139Proof146

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third139Proof239 : runCachedNode 511 130274 Adaptive144Third139Node239 = false := by
  decide +kernel

#print axioms adaptive144Third139Proof239

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third139Proof64 : runCachedNode 511 130274 Adaptive144Third139Node64 = false := by
  decide +kernel

#print axioms adaptive144Third139Proof64

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third139Proof67 : runCachedNode 511 130274 Adaptive144Third139Node67 = false := by
  decide +kernel

#print axioms adaptive144Third139Proof67

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third139Proof91 : runCachedNode 511 130274 Adaptive144Third139Node91 = false := by
  decide +kernel

#print axioms adaptive144Third139Proof91

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third139Proof178 : runCachedNode 511 130274 Adaptive144Third139Node178 = false := by
  decide +kernel

#print axioms adaptive144Third139Proof178

end NineSeparatedSubsetSums
