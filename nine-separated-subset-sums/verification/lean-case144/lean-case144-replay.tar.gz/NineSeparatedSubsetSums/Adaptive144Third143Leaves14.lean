import NineSeparatedSubsetSums.Adaptive144Third143State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third143Proof228 : runCachedNode 511 130885 Adaptive144Third143Node228 = false := by
  decide +kernel

#print axioms adaptive144Third143Proof228

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third143Proof19 : runCachedNode 511 130885 Adaptive144Third143Node19 = false := by
  decide +kernel

#print axioms adaptive144Third143Proof19

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third143Proof41 : runCachedNode 511 130885 Adaptive144Third143Node41 = false := by
  decide +kernel

#print axioms adaptive144Third143Proof41

end NineSeparatedSubsetSums
