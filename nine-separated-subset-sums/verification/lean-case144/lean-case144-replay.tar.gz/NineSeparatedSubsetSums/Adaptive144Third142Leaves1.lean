import NineSeparatedSubsetSums.Adaptive144Third142State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third142Proof239 : runCachedNode 511 130737 Adaptive144Third142Node239 = false := by
  decide +kernel

#print axioms adaptive144Third142Proof239

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third142Proof256 : runCachedNode 511 130737 Adaptive144Third142Node256 = false := by
  decide +kernel

#print axioms adaptive144Third142Proof256

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third142Proof60 : runCachedNode 511 130737 Adaptive144Third142Node60 = false := by
  decide +kernel

#print axioms adaptive144Third142Proof60

end NineSeparatedSubsetSums
