import NineSeparatedSubsetSums.Adaptive144Third133State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third133Proof36 : runCachedNode 511 129309 Adaptive144Third133Node36 = false := by
  decide +kernel

#print axioms adaptive144Third133Proof36

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third133Proof6 : runCachedNode 511 129309 Adaptive144Third133Node6 = false := by
  decide +kernel

#print axioms adaptive144Third133Proof6

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third133Proof35 : runCachedNode 511 129309 Adaptive144Third133Node35 = false := by
  decide +kernel

#print axioms adaptive144Third133Proof35

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third133Proof37 : runCachedNode 511 129309 Adaptive144Third133Node37 = false := by
  decide +kernel

#print axioms adaptive144Third133Proof37

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third133Proof34 : runCachedNode 511 129309 Adaptive144Third133Node34 = false := by
  decide +kernel

#print axioms adaptive144Third133Proof34

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third133Proof33 : runCachedNode 511 129309 Adaptive144Third133Node33 = false := by
  decide +kernel

#print axioms adaptive144Third133Proof33

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third133Proof32 : runCachedNode 511 129309 Adaptive144Third133Node32 = false := by
  decide +kernel

#print axioms adaptive144Third133Proof32

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third133Proof4 : runCachedNode 511 129309 Adaptive144Third133Node4 = false := by
  decide +kernel

#print axioms adaptive144Third133Proof4

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third133Proof30 : runCachedNode 511 129309 Adaptive144Third133Node30 = false := by
  decide +kernel

#print axioms adaptive144Third133Proof30

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third133Proof29 : runCachedNode 511 129309 Adaptive144Third133Node29 = false := by
  decide +kernel

#print axioms adaptive144Third133Proof29

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third133Proof28 : runCachedNode 511 129309 Adaptive144Third133Node28 = false := by
  decide +kernel

#print axioms adaptive144Third133Proof28

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third133Proof27 : runCachedNode 511 129309 Adaptive144Third133Node27 = false := by
  decide +kernel

#print axioms adaptive144Third133Proof27

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third133Proof26 : runCachedNode 511 129309 Adaptive144Third133Node26 = false := by
  decide +kernel

#print axioms adaptive144Third133Proof26

end NineSeparatedSubsetSums
