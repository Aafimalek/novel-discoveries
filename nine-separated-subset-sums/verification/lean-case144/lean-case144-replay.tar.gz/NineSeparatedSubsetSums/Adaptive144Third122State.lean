import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive144Third122Node0 : CachedSearchNode :=
  ⟨4, 121, computeCenteredMask [148,144,122], 414, 57524⟩

end NineSeparatedSubsetSums
