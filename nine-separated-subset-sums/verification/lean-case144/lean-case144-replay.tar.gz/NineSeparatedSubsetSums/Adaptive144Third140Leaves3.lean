import NineSeparatedSubsetSums.Adaptive144Third140State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof493 : runCachedNode 511 130381 Adaptive144Third140Node493 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof493

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof109 : runCachedNode 511 130381 Adaptive144Third140Node109 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof109

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof365 : runCachedNode 511 130381 Adaptive144Third140Node365 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof365

end NineSeparatedSubsetSums
