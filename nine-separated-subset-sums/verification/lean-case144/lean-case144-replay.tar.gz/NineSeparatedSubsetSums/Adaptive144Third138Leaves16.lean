import NineSeparatedSubsetSums.Adaptive144Third138State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third138Proof148 : runCachedNode 511 130126 Adaptive144Third138Node148 = false := by
  decide +kernel

#print axioms adaptive144Third138Proof148

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third138Proof172 : runCachedNode 511 130126 Adaptive144Third138Node172 = false := by
  decide +kernel

#print axioms adaptive144Third138Proof172

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third138Proof206 : runCachedNode 511 130126 Adaptive144Third138Node206 = false := by
  decide +kernel

#print axioms adaptive144Third138Proof206

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third138Proof118 : runCachedNode 511 130126 Adaptive144Third138Node118 = false := by
  decide +kernel

#print axioms adaptive144Third138Proof118

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third138Proof144 : runCachedNode 511 130126 Adaptive144Third138Node144 = false := by
  decide +kernel

#print axioms adaptive144Third138Proof144

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third138Proof39 : runCachedNode 511 130126 Adaptive144Third138Node39 = false := by
  decide +kernel

#print axioms adaptive144Third138Proof39

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third138Proof208 : runCachedNode 511 130126 Adaptive144Third138Node208 = false := by
  decide +kernel

#print axioms adaptive144Third138Proof208

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third138Proof116 : runCachedNode 511 130126 Adaptive144Third138Node116 = false := by
  decide +kernel

#print axioms adaptive144Third138Proof116

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third138Proof9 : runCachedNode 511 130126 Adaptive144Third138Node9 = false := by
  decide +kernel

#print axioms adaptive144Third138Proof9

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third138Proof36 : runCachedNode 511 130126 Adaptive144Third138Node36 = false := by
  decide +kernel

#print axioms adaptive144Third138Proof36

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third138Proof170 : runCachedNode 511 130126 Adaptive144Third138Node170 = false := by
  decide +kernel

#print axioms adaptive144Third138Proof170

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third138Proof205 : runCachedNode 511 130126 Adaptive144Third138Node205 = false := by
  decide +kernel

#print axioms adaptive144Third138Proof205

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third138Proof38 : runCachedNode 511 130126 Adaptive144Third138Node38 = false := by
  decide +kernel

#print axioms adaptive144Third138Proof38

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third138Proof86 : runCachedNode 511 130126 Adaptive144Third138Node86 = false := by
  decide +kernel

#print axioms adaptive144Third138Proof86

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third138Proof143 : runCachedNode 511 130126 Adaptive144Third138Node143 = false := by
  decide +kernel

#print axioms adaptive144Third138Proof143

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third138Proof171 : runCachedNode 511 130126 Adaptive144Third138Node171 = false := by
  decide +kernel

#print axioms adaptive144Third138Proof171

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third138Proof64 : runCachedNode 511 130126 Adaptive144Third138Node64 = false := by
  decide +kernel

#print axioms adaptive144Third138Proof64

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third138Proof33 : runCachedNode 511 130126 Adaptive144Third138Node33 = false := by
  decide +kernel

#print axioms adaptive144Third138Proof33

end NineSeparatedSubsetSums
