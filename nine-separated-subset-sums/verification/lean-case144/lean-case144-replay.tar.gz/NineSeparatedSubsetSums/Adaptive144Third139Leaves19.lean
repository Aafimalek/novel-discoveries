import NineSeparatedSubsetSums.Adaptive144Third139State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third139Proof37 : runCachedNode 511 130274 Adaptive144Third139Node37 = false := by
  decide +kernel

#print axioms adaptive144Third139Proof37

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third139Proof175 : runCachedNode 511 130274 Adaptive144Third139Node175 = false := by
  decide +kernel

#print axioms adaptive144Third139Proof175

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third139Proof238 : runCachedNode 511 130274 Adaptive144Third139Node238 = false := by
  decide +kernel

#print axioms adaptive144Third139Proof238

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third139Proof35 : runCachedNode 511 130274 Adaptive144Third139Node35 = false := by
  decide +kernel

#print axioms adaptive144Third139Proof35

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third139Proof89 : runCachedNode 511 130274 Adaptive144Third139Node89 = false := by
  decide +kernel

#print axioms adaptive144Third139Proof89

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third139Proof61 : runCachedNode 511 130274 Adaptive144Third139Node61 = false := by
  decide +kernel

#print axioms adaptive144Third139Proof61

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third139Proof90 : runCachedNode 511 130274 Adaptive144Third139Node90 = false := by
  decide +kernel

#print axioms adaptive144Third139Proof90

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third139Proof119 : runCachedNode 511 130274 Adaptive144Third139Node119 = false := by
  decide +kernel

#print axioms adaptive144Third139Proof119

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third139Proof62 : runCachedNode 511 130274 Adaptive144Third139Node62 = false := by
  decide +kernel

#print axioms adaptive144Third139Proof62

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third139Proof142 : runCachedNode 511 130274 Adaptive144Third139Node142 = false := by
  decide +kernel

#print axioms adaptive144Third139Proof142

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third139Proof237 : runCachedNode 511 130274 Adaptive144Third139Node237 = false := by
  decide +kernel

#print axioms adaptive144Third139Proof237

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third139Proof9 : runCachedNode 511 130274 Adaptive144Third139Node9 = false := by
  decide +kernel

#print axioms adaptive144Third139Proof9

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third139Proof235 : runCachedNode 511 130274 Adaptive144Third139Node235 = false := by
  decide +kernel

#print axioms adaptive144Third139Proof235

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third139Proof60 : runCachedNode 511 130274 Adaptive144Third139Node60 = false := by
  decide +kernel

#print axioms adaptive144Third139Proof60

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third139Proof203 : runCachedNode 511 130274 Adaptive144Third139Node203 = false := by
  decide +kernel

#print axioms adaptive144Third139Proof203

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third139Proof36 : runCachedNode 511 130274 Adaptive144Third139Node36 = false := by
  decide +kernel

#print axioms adaptive144Third139Proof36

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third139Proof204 : runCachedNode 511 130274 Adaptive144Third139Node204 = false := by
  decide +kernel

#print axioms adaptive144Third139Proof204

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third139Proof115 : runCachedNode 511 130274 Adaptive144Third139Node115 = false := by
  decide +kernel

#print axioms adaptive144Third139Proof115

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third139Proof136 : runCachedNode 511 130274 Adaptive144Third139Node136 = false := by
  decide +kernel

#print axioms adaptive144Third139Proof136

end NineSeparatedSubsetSums
