import NineSeparatedSubsetSums.Adaptive144Third138State
import NineSeparatedSubsetSums.Adaptive144Third138Leaves1
import NineSeparatedSubsetSums.Adaptive144Third138Leaves2
import NineSeparatedSubsetSums.Adaptive144Third138Leaves19
import NineSeparatedSubsetSums.Adaptive144Third138Leaves12
import NineSeparatedSubsetSums.Adaptive144Third138Leaves18
import NineSeparatedSubsetSums.Adaptive144Third138Leaves6
import NineSeparatedSubsetSums.Adaptive144Third138Leaves17
import NineSeparatedSubsetSums.Adaptive144Third138Leaves16
import NineSeparatedSubsetSums.Adaptive144Third138Leaves0
import NineSeparatedSubsetSums.Adaptive144Third138Leaves15
import NineSeparatedSubsetSums.Adaptive144Third138Leaves10
import NineSeparatedSubsetSums.Adaptive144Third138Leaves11
import NineSeparatedSubsetSums.Adaptive144Third138Leaves5
import NineSeparatedSubsetSums.Adaptive144Third138Leaves7
import NineSeparatedSubsetSums.Adaptive144Third138Leaves13
import NineSeparatedSubsetSums.Adaptive144Third138Leaves3
import NineSeparatedSubsetSums.Adaptive144Third138Leaves4
import NineSeparatedSubsetSums.Adaptive144Third138Leaves20
import NineSeparatedSubsetSums.Adaptive144Third138Leaves14
import NineSeparatedSubsetSums.Adaptive144Third138Leaves8
import NineSeparatedSubsetSums.Adaptive144Third138Leaves9

namespace NineSeparatedSubsetSums

theorem adaptive144Third138Proof21 : runCachedNode 511 130126 Adaptive144Third138Node21 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130126 Adaptive144Third138Node21 = [104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 121, 122, 123, 125, 127, 128, 129] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive144Third138Proof22
  · exact adaptive144Third138Proof23
  · exact adaptive144Third138Proof24
  · exact adaptive144Third138Proof25
  · exact adaptive144Third138Proof26
  · exact adaptive144Third138Proof27
  · exact adaptive144Third138Proof28
  · exact adaptive144Third138Proof29
  · exact adaptive144Third138Proof30
  · exact adaptive144Third138Proof31
  · exact adaptive144Third138Proof32
  · exact adaptive144Third138Proof33
  · exact adaptive144Third138Proof34
  · exact adaptive144Third138Proof35
  · exact adaptive144Third138Proof36
  · exact adaptive144Third138Proof37
  · exact adaptive144Third138Proof38
  · exact adaptive144Third138Proof39
  · exact adaptive144Third138Proof40
  · exact adaptive144Third138Proof41
  · exact adaptive144Third138Proof42
  · exact adaptive144Third138Proof43
  · exact adaptive144Third138Proof44

#print axioms adaptive144Third138Proof21

theorem adaptive144Third138Proof45 : runCachedNode 511 130126 Adaptive144Third138Node45 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130126 Adaptive144Third138Node45 = [104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 122, 123, 124, 126, 128, 129, 130] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive144Third138Proof46
  · exact adaptive144Third138Proof47
  · exact adaptive144Third138Proof48
  · exact adaptive144Third138Proof49
  · exact adaptive144Third138Proof50
  · exact adaptive144Third138Proof51
  · exact adaptive144Third138Proof52
  · exact adaptive144Third138Proof53
  · exact adaptive144Third138Proof54
  · exact adaptive144Third138Proof55
  · exact adaptive144Third138Proof56
  · exact adaptive144Third138Proof57
  · exact adaptive144Third138Proof58
  · exact adaptive144Third138Proof59
  · exact adaptive144Third138Proof60
  · exact adaptive144Third138Proof61
  · exact adaptive144Third138Proof62
  · exact adaptive144Third138Proof63
  · exact adaptive144Third138Proof64
  · exact adaptive144Third138Proof65
  · exact adaptive144Third138Proof66
  · exact adaptive144Third138Proof67
  · exact adaptive144Third138Proof68
  · exact adaptive144Third138Proof69

#print axioms adaptive144Third138Proof45

theorem adaptive144Third138Proof70 : runCachedNode 511 130126 Adaptive144Third138Node70 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130126 Adaptive144Third138Node70 = [104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 123, 124, 125, 127, 129, 130, 131] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive144Third138Proof71
  · exact adaptive144Third138Proof72
  · exact adaptive144Third138Proof73
  · exact adaptive144Third138Proof74
  · exact adaptive144Third138Proof75
  · exact adaptive144Third138Proof76
  · exact adaptive144Third138Proof77
  · exact adaptive144Third138Proof78
  · exact adaptive144Third138Proof79
  · exact adaptive144Third138Proof80
  · exact adaptive144Third138Proof81
  · exact adaptive144Third138Proof82
  · exact adaptive144Third138Proof83
  · exact adaptive144Third138Proof84
  · exact adaptive144Third138Proof85
  · exact adaptive144Third138Proof86
  · exact adaptive144Third138Proof87
  · exact adaptive144Third138Proof88
  · exact adaptive144Third138Proof89
  · exact adaptive144Third138Proof90
  · exact adaptive144Third138Proof91
  · exact adaptive144Third138Proof92
  · exact adaptive144Third138Proof93
  · exact adaptive144Third138Proof94
  · exact adaptive144Third138Proof95

#print axioms adaptive144Third138Proof70

theorem adaptive144Third138Proof96 : runCachedNode 511 130126 Adaptive144Third138Node96 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130126 Adaptive144Third138Node96 = [103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 124, 125, 126, 128, 130, 131, 132] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive144Third138Proof97
  · exact adaptive144Third138Proof98
  · exact adaptive144Third138Proof99
  · exact adaptive144Third138Proof100
  · exact adaptive144Third138Proof101
  · exact adaptive144Third138Proof102
  · exact adaptive144Third138Proof103
  · exact adaptive144Third138Proof104
  · exact adaptive144Third138Proof105
  · exact adaptive144Third138Proof106
  · exact adaptive144Third138Proof107
  · exact adaptive144Third138Proof108
  · exact adaptive144Third138Proof109
  · exact adaptive144Third138Proof110
  · exact adaptive144Third138Proof111
  · exact adaptive144Third138Proof112
  · exact adaptive144Third138Proof113
  · exact adaptive144Third138Proof114
  · exact adaptive144Third138Proof115
  · exact adaptive144Third138Proof116
  · exact adaptive144Third138Proof117
  · exact adaptive144Third138Proof118
  · exact adaptive144Third138Proof119
  · exact adaptive144Third138Proof120
  · exact adaptive144Third138Proof121
  · exact adaptive144Third138Proof122
  · exact adaptive144Third138Proof123

#print axioms adaptive144Third138Proof96

theorem adaptive144Third138Proof124 : runCachedNode 511 130126 Adaptive144Third138Node124 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130126 Adaptive144Third138Node124 = [103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 126, 127, 128, 130, 132, 133] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive144Third138Proof125
  · exact adaptive144Third138Proof126
  · exact adaptive144Third138Proof127
  · exact adaptive144Third138Proof128
  · exact adaptive144Third138Proof129
  · exact adaptive144Third138Proof130
  · exact adaptive144Third138Proof131
  · exact adaptive144Third138Proof132
  · exact adaptive144Third138Proof133
  · exact adaptive144Third138Proof134
  · exact adaptive144Third138Proof135
  · exact adaptive144Third138Proof136
  · exact adaptive144Third138Proof137
  · exact adaptive144Third138Proof138
  · exact adaptive144Third138Proof139
  · exact adaptive144Third138Proof140
  · exact adaptive144Third138Proof141
  · exact adaptive144Third138Proof142
  · exact adaptive144Third138Proof143
  · exact adaptive144Third138Proof144
  · exact adaptive144Third138Proof145
  · exact adaptive144Third138Proof146
  · exact adaptive144Third138Proof147
  · exact adaptive144Third138Proof148
  · exact adaptive144Third138Proof149
  · exact adaptive144Third138Proof150
  · exact adaptive144Third138Proof151
  · exact adaptive144Third138Proof152

#print axioms adaptive144Third138Proof124

theorem adaptive144Third138Proof153 : runCachedNode 511 130126 Adaptive144Third138Node153 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130126 Adaptive144Third138Node153 = [102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 127, 128, 129, 131, 133, 135] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive144Third138Proof154
  · exact adaptive144Third138Proof155
  · exact adaptive144Third138Proof156
  · exact adaptive144Third138Proof157
  · exact adaptive144Third138Proof158
  · exact adaptive144Third138Proof159
  · exact adaptive144Third138Proof160
  · exact adaptive144Third138Proof161
  · exact adaptive144Third138Proof162
  · exact adaptive144Third138Proof163
  · exact adaptive144Third138Proof164
  · exact adaptive144Third138Proof165
  · exact adaptive144Third138Proof166
  · exact adaptive144Third138Proof167
  · exact adaptive144Third138Proof168
  · exact adaptive144Third138Proof169
  · exact adaptive144Third138Proof170
  · exact adaptive144Third138Proof171
  · exact adaptive144Third138Proof172
  · exact adaptive144Third138Proof173
  · exact adaptive144Third138Proof174
  · exact adaptive144Third138Proof175
  · exact adaptive144Third138Proof176
  · exact adaptive144Third138Proof177
  · exact adaptive144Third138Proof178
  · exact adaptive144Third138Proof179
  · exact adaptive144Third138Proof180
  · exact adaptive144Third138Proof181
  · exact adaptive144Third138Proof182
  · exact adaptive144Third138Proof183

#print axioms adaptive144Third138Proof153

theorem adaptive144Third138Proof184 : runCachedNode 511 130126 Adaptive144Third138Node184 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130126 Adaptive144Third138Node184 = [102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 128, 129, 130, 132, 135, 136] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive144Third138Proof185
  · exact adaptive144Third138Proof186
  · exact adaptive144Third138Proof187
  · exact adaptive144Third138Proof188
  · exact adaptive144Third138Proof189
  · exact adaptive144Third138Proof190
  · exact adaptive144Third138Proof191
  · exact adaptive144Third138Proof192
  · exact adaptive144Third138Proof193
  · exact adaptive144Third138Proof194
  · exact adaptive144Third138Proof195
  · exact adaptive144Third138Proof196
  · exact adaptive144Third138Proof197
  · exact adaptive144Third138Proof198
  · exact adaptive144Third138Proof199
  · exact adaptive144Third138Proof200
  · exact adaptive144Third138Proof201
  · exact adaptive144Third138Proof202
  · exact adaptive144Third138Proof203
  · exact adaptive144Third138Proof204
  · exact adaptive144Third138Proof205
  · exact adaptive144Third138Proof206
  · exact adaptive144Third138Proof207
  · exact adaptive144Third138Proof208
  · exact adaptive144Third138Proof209
  · exact adaptive144Third138Proof210
  · exact adaptive144Third138Proof211
  · exact adaptive144Third138Proof212
  · exact adaptive144Third138Proof213
  · exact adaptive144Third138Proof214
  · exact adaptive144Third138Proof215

#print axioms adaptive144Third138Proof184

theorem adaptive144Third138Proof0 : runCachedNode 511 130126 Adaptive144Third138Node0 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130126 Adaptive144Third138Node0 = [110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 132, 133, 135, 136, 137] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive144Third138Proof1
  · exact adaptive144Third138Proof2
  · exact adaptive144Third138Proof3
  · exact adaptive144Third138Proof4
  · exact adaptive144Third138Proof5
  · exact adaptive144Third138Proof6
  · exact adaptive144Third138Proof7
  · exact adaptive144Third138Proof8
  · exact adaptive144Third138Proof9
  · exact adaptive144Third138Proof10
  · exact adaptive144Third138Proof11
  · exact adaptive144Third138Proof12
  · exact adaptive144Third138Proof13
  · exact adaptive144Third138Proof14
  · exact adaptive144Third138Proof15
  · exact adaptive144Third138Proof16
  · exact adaptive144Third138Proof17
  · exact adaptive144Third138Proof18
  · exact adaptive144Third138Proof19
  · exact adaptive144Third138Proof20
  · exact adaptive144Third138Proof21
  · exact adaptive144Third138Proof45
  · exact adaptive144Third138Proof70
  · exact adaptive144Third138Proof96
  · exact adaptive144Third138Proof124
  · exact adaptive144Third138Proof153
  · exact adaptive144Third138Proof184

#print axioms adaptive144Third138Proof0

end NineSeparatedSubsetSums
