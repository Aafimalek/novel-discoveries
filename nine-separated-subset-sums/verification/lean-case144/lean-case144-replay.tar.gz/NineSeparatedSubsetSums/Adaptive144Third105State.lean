import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive144Third105Node0 : CachedSearchNode :=
  ⟨4, 104, computeCenteredMask [148,144,105], 397, 53665⟩

end NineSeparatedSubsetSums
