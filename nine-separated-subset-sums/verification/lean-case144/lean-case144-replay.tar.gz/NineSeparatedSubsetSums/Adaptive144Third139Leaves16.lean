import NineSeparatedSubsetSums.Adaptive144Third139State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third139Proof93 : runCachedNode 511 130274 Adaptive144Third139Node93 = false := by
  decide +kernel

#print axioms adaptive144Third139Proof93

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third139Proof179 : runCachedNode 511 130274 Adaptive144Third139Node179 = false := by
  decide +kernel

#print axioms adaptive144Third139Proof179

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third139Proof120 : runCachedNode 511 130274 Adaptive144Third139Node120 = false := by
  decide +kernel

#print axioms adaptive144Third139Proof120

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third139Proof12 : runCachedNode 511 130274 Adaptive144Third139Node12 = false := by
  decide +kernel

#print axioms adaptive144Third139Proof12

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third139Proof181 : runCachedNode 511 130274 Adaptive144Third139Node181 = false := by
  decide +kernel

#print axioms adaptive144Third139Proof181

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third139Proof177 : runCachedNode 511 130274 Adaptive144Third139Node177 = false := by
  decide +kernel

#print axioms adaptive144Third139Proof177

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third139Proof42 : runCachedNode 511 130274 Adaptive144Third139Node42 = false := by
  decide +kernel

#print axioms adaptive144Third139Proof42

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third139Proof209 : runCachedNode 511 130274 Adaptive144Third139Node209 = false := by
  decide +kernel

#print axioms adaptive144Third139Proof209

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third139Proof144 : runCachedNode 511 130274 Adaptive144Third139Node144 = false := by
  decide +kernel

#print axioms adaptive144Third139Proof144

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third139Proof27 : runCachedNode 511 130274 Adaptive144Third139Node27 = false := by
  decide +kernel

#print axioms adaptive144Third139Proof27

end NineSeparatedSubsetSums
