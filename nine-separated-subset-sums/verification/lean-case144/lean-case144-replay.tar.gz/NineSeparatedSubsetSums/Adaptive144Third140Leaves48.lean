import NineSeparatedSubsetSums.Adaptive144Third140State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof35 : runCachedNode 511 130381 Adaptive144Third140Node35 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof35

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof290 : runCachedNode 511 130381 Adaptive144Third140Node290 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof290

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof191 : runCachedNode 511 130381 Adaptive144Third140Node191 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof191

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof381 : runCachedNode 511 130381 Adaptive144Third140Node381 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof381

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof570 : runCachedNode 511 130381 Adaptive144Third140Node570 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof570

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof34 : runCachedNode 511 130381 Adaptive144Third140Node34 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof34

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof169 : runCachedNode 511 130381 Adaptive144Third140Node169 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof169

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof82 : runCachedNode 511 130381 Adaptive144Third140Node82 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof82

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof8 : runCachedNode 511 130381 Adaptive144Third140Node8 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof8

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof285 : runCachedNode 511 130381 Adaptive144Third140Node285 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof285

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof482 : runCachedNode 511 130381 Adaptive144Third140Node482 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof482

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof289 : runCachedNode 511 130381 Adaptive144Third140Node289 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof289

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof317 : runCachedNode 511 130381 Adaptive144Third140Node317 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof317

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof351 : runCachedNode 511 130381 Adaptive144Third140Node351 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof351

end NineSeparatedSubsetSums
