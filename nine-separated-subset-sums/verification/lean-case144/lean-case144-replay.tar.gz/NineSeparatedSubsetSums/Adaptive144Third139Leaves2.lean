import NineSeparatedSubsetSums.Adaptive144Third139State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third139Proof215 : runCachedNode 511 130274 Adaptive144Third139Node215 = false := by
  decide +kernel

#print axioms adaptive144Third139Proof215

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third139Proof148 : runCachedNode 511 130274 Adaptive144Third139Node148 = false := by
  decide +kernel

#print axioms adaptive144Third139Proof148

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third139Proof111 : runCachedNode 511 130274 Adaptive144Third139Node111 = false := by
  decide +kernel

#print axioms adaptive144Third139Proof111

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third139Proof126 : runCachedNode 511 130274 Adaptive144Third139Node126 = false := by
  decide +kernel

#print axioms adaptive144Third139Proof126

end NineSeparatedSubsetSums
