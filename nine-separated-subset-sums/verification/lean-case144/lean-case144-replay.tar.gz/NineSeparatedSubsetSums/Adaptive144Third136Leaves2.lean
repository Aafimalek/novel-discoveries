import NineSeparatedSubsetSums.Adaptive144Third136State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third136Proof21 : runCachedNode 511 129800 Adaptive144Third136Node21 = false := by
  decide +kernel

#print axioms adaptive144Third136Proof21

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third136Proof14 : runCachedNode 511 129800 Adaptive144Third136Node14 = false := by
  decide +kernel

#print axioms adaptive144Third136Proof14

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third136Proof79 : runCachedNode 511 129800 Adaptive144Third136Node79 = false := by
  decide +kernel

#print axioms adaptive144Third136Proof79

end NineSeparatedSubsetSums
