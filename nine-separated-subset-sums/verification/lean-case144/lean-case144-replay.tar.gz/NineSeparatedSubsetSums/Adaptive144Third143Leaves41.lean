import NineSeparatedSubsetSums.Adaptive144Third143State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third143Proof154 : runCachedNode 511 130885 Adaptive144Third143Node154 = false := by
  decide +kernel

#print axioms adaptive144Third143Proof154

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third143Proof483 : runCachedNode 511 130885 Adaptive144Third143Node483 = false := by
  decide +kernel

#print axioms adaptive144Third143Proof483

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third143Proof638 : runCachedNode 511 130885 Adaptive144Third143Node638 = false := by
  decide +kernel

#print axioms adaptive144Third143Proof638

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third143Proof640 : runCachedNode 511 130885 Adaptive144Third143Node640 = false := by
  decide +kernel

#print axioms adaptive144Third143Proof640

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third143Proof250 : runCachedNode 511 130885 Adaptive144Third143Node250 = false := by
  decide +kernel

#print axioms adaptive144Third143Proof250

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third143Proof69 : runCachedNode 511 130885 Adaptive144Third143Node69 = false := by
  decide +kernel

#print axioms adaptive144Third143Proof69

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third143Proof612 : runCachedNode 511 130885 Adaptive144Third143Node612 = false := by
  decide +kernel

#print axioms adaptive144Third143Proof612

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third143Proof557 : runCachedNode 511 130885 Adaptive144Third143Node557 = false := by
  decide +kernel

#print axioms adaptive144Third143Proof557

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third143Proof531 : runCachedNode 511 130885 Adaptive144Third143Node531 = false := by
  decide +kernel

#print axioms adaptive144Third143Proof531

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third143Proof644 : runCachedNode 511 130885 Adaptive144Third143Node644 = false := by
  decide +kernel

#print axioms adaptive144Third143Proof644

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third143Proof637 : runCachedNode 511 130885 Adaptive144Third143Node637 = false := by
  decide +kernel

#print axioms adaptive144Third143Proof637

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third143Proof641 : runCachedNode 511 130885 Adaptive144Third143Node641 = false := by
  decide +kernel

#print axioms adaptive144Third143Proof641

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third143Proof351 : runCachedNode 511 130885 Adaptive144Third143Node351 = false := by
  decide +kernel

#print axioms adaptive144Third143Proof351

end NineSeparatedSubsetSums
