import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive144Third121Node0 : CachedSearchNode :=
  ⟨4, 120, computeCenteredMask [148,144,121], 413, 57281⟩

end NineSeparatedSubsetSums
