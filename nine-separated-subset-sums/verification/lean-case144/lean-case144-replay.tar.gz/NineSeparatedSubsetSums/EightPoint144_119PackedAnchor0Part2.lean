import NineSeparatedSubsetSums.EightPoint144_119PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint144_119PackedAnchor0Part2 :
    ∀ j : Fin 9, 2430188 ≤ FourPointNumeric.octPackedCharge 144 119 20 packedOct144_119_0
      (2*((j.val : Int)+240)+1) := by decide +kernel

end NineSeparatedSubsetSums
