import NineSeparatedSubsetSums.Adaptive144Third142State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third142Proof236 : runCachedNode 511 130737 Adaptive144Third142Node236 = false := by
  decide +kernel

#print axioms adaptive144Third142Proof236

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third142Proof107 : runCachedNode 511 130737 Adaptive144Third142Node107 = false := by
  decide +kernel

#print axioms adaptive144Third142Proof107

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third142Proof49 : runCachedNode 511 130737 Adaptive144Third142Node49 = false := by
  decide +kernel

#print axioms adaptive144Third142Proof49

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third142Proof259 : runCachedNode 511 130737 Adaptive144Third142Node259 = false := by
  decide +kernel

#print axioms adaptive144Third142Proof259

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third142Proof608 : runCachedNode 511 130737 Adaptive144Third142Node608 = false := by
  decide +kernel

#print axioms adaptive144Third142Proof608

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third142Proof334 : runCachedNode 511 130737 Adaptive144Third142Node334 = false := by
  decide +kernel

#print axioms adaptive144Third142Proof334

end NineSeparatedSubsetSums
