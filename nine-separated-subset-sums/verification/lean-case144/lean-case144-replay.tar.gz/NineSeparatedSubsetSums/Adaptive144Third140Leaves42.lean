import NineSeparatedSubsetSums.Adaptive144Third140State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof638 : runCachedNode 511 130381 Adaptive144Third140Node638 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof638

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof232 : runCachedNode 511 130381 Adaptive144Third140Node232 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof232

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof322 : runCachedNode 511 130381 Adaptive144Third140Node322 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof322

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof718 : runCachedNode 511 130381 Adaptive144Third140Node718 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof718

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof256 : runCachedNode 511 130381 Adaptive144Third140Node256 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof256

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof194 : runCachedNode 511 130381 Adaptive144Third140Node194 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof194

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof38 : runCachedNode 511 130381 Adaptive144Third140Node38 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof38

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof423 : runCachedNode 511 130381 Adaptive144Third140Node423 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof423

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof92 : runCachedNode 511 130381 Adaptive144Third140Node92 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof92

end NineSeparatedSubsetSums
