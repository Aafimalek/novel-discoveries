import NineSeparatedSubsetSums.Adaptive144Third131State
import NineSeparatedSubsetSums.Adaptive144Third131Leaves1
import NineSeparatedSubsetSums.Adaptive144Third131Leaves0
import NineSeparatedSubsetSums.Adaptive144Third131Leaves3
import NineSeparatedSubsetSums.Adaptive144Third131Leaves2

namespace NineSeparatedSubsetSums

theorem adaptive144Third131Proof0 : runCachedNode 511 129000 Adaptive144Third131Node0 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 129000 Adaptive144Third131Node0 = [110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 128, 129, 130] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive144Third131Proof1
  · exact adaptive144Third131Proof2
  · exact adaptive144Third131Proof3
  · exact adaptive144Third131Proof4
  · exact adaptive144Third131Proof5
  · exact adaptive144Third131Proof6
  · exact adaptive144Third131Proof7
  · exact adaptive144Third131Proof8
  · exact adaptive144Third131Proof9
  · exact adaptive144Third131Proof10
  · exact adaptive144Third131Proof11
  · exact adaptive144Third131Proof12
  · exact adaptive144Third131Proof13
  · exact adaptive144Third131Proof14
  · exact adaptive144Third131Proof15
  · exact adaptive144Third131Proof16
  · exact adaptive144Third131Proof17
  · exact adaptive144Third131Proof18
  · exact adaptive144Third131Proof19
  · exact adaptive144Third131Proof20

#print axioms adaptive144Third131Proof0

end NineSeparatedSubsetSums
