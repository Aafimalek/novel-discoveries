import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive144Third111Node0 : CachedSearchNode :=
  ⟨4, 110, computeCenteredMask [148,144,111], 403, 54961⟩

end NineSeparatedSubsetSums
