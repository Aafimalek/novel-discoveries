import NineSeparatedSubsetSums.Adaptive144Third133State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third133Proof19 : runCachedNode 511 129309 Adaptive144Third133Node19 = false := by
  decide +kernel

#print axioms adaptive144Third133Proof19

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third133Proof17 : runCachedNode 511 129309 Adaptive144Third133Node17 = false := by
  decide +kernel

#print axioms adaptive144Third133Proof17

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third133Proof12 : runCachedNode 511 129309 Adaptive144Third133Node12 = false := by
  decide +kernel

#print axioms adaptive144Third133Proof12

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third133Proof7 : runCachedNode 511 129309 Adaptive144Third133Node7 = false := by
  decide +kernel

#print axioms adaptive144Third133Proof7

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third133Proof24 : runCachedNode 511 129309 Adaptive144Third133Node24 = false := by
  decide +kernel

#print axioms adaptive144Third133Proof24

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third133Proof25 : runCachedNode 511 129309 Adaptive144Third133Node25 = false := by
  decide +kernel

#print axioms adaptive144Third133Proof25

end NineSeparatedSubsetSums
