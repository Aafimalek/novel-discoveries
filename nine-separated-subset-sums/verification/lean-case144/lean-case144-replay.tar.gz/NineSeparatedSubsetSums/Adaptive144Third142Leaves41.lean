import NineSeparatedSubsetSums.Adaptive144Third142State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third142Proof603 : runCachedNode 511 130737 Adaptive144Third142Node603 = false := by
  decide +kernel

#print axioms adaptive144Third142Proof603

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third142Proof288 : runCachedNode 511 130737 Adaptive144Third142Node288 = false := by
  decide +kernel

#print axioms adaptive144Third142Proof288

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third142Proof569 : runCachedNode 511 130737 Adaptive144Third142Node569 = false := by
  decide +kernel

#print axioms adaptive144Third142Proof569

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third142Proof639 : runCachedNode 511 130737 Adaptive144Third142Node639 = false := by
  decide +kernel

#print axioms adaptive144Third142Proof639

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third142Proof567 : runCachedNode 511 130737 Adaptive144Third142Node567 = false := by
  decide +kernel

#print axioms adaptive144Third142Proof567

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third142Proof601 : runCachedNode 511 130737 Adaptive144Third142Node601 = false := by
  decide +kernel

#print axioms adaptive144Third142Proof601

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third142Proof43 : runCachedNode 511 130737 Adaptive144Third142Node43 = false := by
  decide +kernel

#print axioms adaptive144Third142Proof43

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third142Proof528 : runCachedNode 511 130737 Adaptive144Third142Node528 = false := by
  decide +kernel

#print axioms adaptive144Third142Proof528

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third142Proof638 : runCachedNode 511 130737 Adaptive144Third142Node638 = false := by
  decide +kernel

#print axioms adaptive144Third142Proof638

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third142Proof98 : runCachedNode 511 130737 Adaptive144Third142Node98 = false := by
  decide +kernel

#print axioms adaptive144Third142Proof98

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third142Proof101 : runCachedNode 511 130737 Adaptive144Third142Node101 = false := by
  decide +kernel

#print axioms adaptive144Third142Proof101

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third142Proof131 : runCachedNode 511 130737 Adaptive144Third142Node131 = false := by
  decide +kernel

#print axioms adaptive144Third142Proof131

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third142Proof193 : runCachedNode 511 130737 Adaptive144Third142Node193 = false := by
  decide +kernel

#print axioms adaptive144Third142Proof193

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third142Proof396 : runCachedNode 511 130737 Adaptive144Third142Node396 = false := by
  decide +kernel

#print axioms adaptive144Third142Proof396

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third142Proof600 : runCachedNode 511 130737 Adaptive144Third142Node600 = false := by
  decide +kernel

#print axioms adaptive144Third142Proof600

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third142Proof637 : runCachedNode 511 130737 Adaptive144Third142Node637 = false := by
  decide +kernel

#print axioms adaptive144Third142Proof637

end NineSeparatedSubsetSums
