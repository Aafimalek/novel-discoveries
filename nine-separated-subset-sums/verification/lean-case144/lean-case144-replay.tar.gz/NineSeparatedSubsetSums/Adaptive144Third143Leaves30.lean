import NineSeparatedSubsetSums.Adaptive144Third143State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third143Proof616 : runCachedNode 511 130885 Adaptive144Third143Node616 = false := by
  decide +kernel

#print axioms adaptive144Third143Proof616

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third143Proof254 : runCachedNode 511 130885 Adaptive144Third143Node254 = false := by
  decide +kernel

#print axioms adaptive144Third143Proof254

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third143Proof564 : runCachedNode 511 130885 Adaptive144Third143Node564 = false := by
  decide +kernel

#print axioms adaptive144Third143Proof564

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third143Proof657 : runCachedNode 511 130885 Adaptive144Third143Node657 = false := by
  decide +kernel

#print axioms adaptive144Third143Proof657

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third143Proof73 : runCachedNode 511 130885 Adaptive144Third143Node73 = false := by
  decide +kernel

#print axioms adaptive144Third143Proof73

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third143Proof248 : runCachedNode 511 130885 Adaptive144Third143Node248 = false := by
  decide +kernel

#print axioms adaptive144Third143Proof248

end NineSeparatedSubsetSums
