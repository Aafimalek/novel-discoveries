import NineSeparatedSubsetSums.Adaptive144Third132State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third132Proof19 : runCachedNode 511 129155 Adaptive144Third132Node19 = false := by
  decide +kernel

#print axioms adaptive144Third132Proof19

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third132Proof18 : runCachedNode 511 129155 Adaptive144Third132Node18 = false := by
  decide +kernel

#print axioms adaptive144Third132Proof18

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third132Proof8 : runCachedNode 511 129155 Adaptive144Third132Node8 = false := by
  decide +kernel

#print axioms adaptive144Third132Proof8

end NineSeparatedSubsetSums
