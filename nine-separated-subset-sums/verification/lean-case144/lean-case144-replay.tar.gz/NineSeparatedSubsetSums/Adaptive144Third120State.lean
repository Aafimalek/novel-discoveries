import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive144Third120Node0 : CachedSearchNode :=
  ⟨4, 119, computeCenteredMask [148,144,120], 412, 57040⟩

end NineSeparatedSubsetSums
