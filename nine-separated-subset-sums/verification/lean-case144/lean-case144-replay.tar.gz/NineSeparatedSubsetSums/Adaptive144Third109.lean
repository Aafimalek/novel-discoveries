import NineSeparatedSubsetSums.Adaptive144Third109Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint144Checked

namespace NineSeparatedSubsetSums


theorem adaptive144Third109 : NoDescendingTailAfterThird 144 109 :=
  noDescendingThirdTail_of_cached 144 109 112221 (fun t ht nd => max148_second144_fourPoint_moment_bound (109::t) (by simp [ht]) nd) adaptive144Third109Proof0

#print axioms adaptive144Third109

end NineSeparatedSubsetSums
