import NineSeparatedSubsetSums.Adaptive144Third131State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third131Proof16 : runCachedNode 511 129000 Adaptive144Third131Node16 = false := by
  decide +kernel

#print axioms adaptive144Third131Proof16

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third131Proof15 : runCachedNode 511 129000 Adaptive144Third131Node15 = false := by
  decide +kernel

#print axioms adaptive144Third131Proof15

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third131Proof14 : runCachedNode 511 129000 Adaptive144Third131Node14 = false := by
  decide +kernel

#print axioms adaptive144Third131Proof14

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third131Proof13 : runCachedNode 511 129000 Adaptive144Third131Node13 = false := by
  decide +kernel

#print axioms adaptive144Third131Proof13

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third131Proof12 : runCachedNode 511 129000 Adaptive144Third131Node12 = false := by
  decide +kernel

#print axioms adaptive144Third131Proof12

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third131Proof8 : runCachedNode 511 129000 Adaptive144Third131Node8 = false := by
  decide +kernel

#print axioms adaptive144Third131Proof8

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third131Proof6 : runCachedNode 511 129000 Adaptive144Third131Node6 = false := by
  decide +kernel

#print axioms adaptive144Third131Proof6

end NineSeparatedSubsetSums
