import NineSeparatedSubsetSums.Adaptive144Third138State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third138Proof120 : runCachedNode 511 130126 Adaptive144Third138Node120 = false := by
  decide +kernel

#print axioms adaptive144Third138Proof120

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third138Proof212 : runCachedNode 511 130126 Adaptive144Third138Node212 = false := by
  decide +kernel

#print axioms adaptive144Third138Proof212

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third138Proof180 : runCachedNode 511 130126 Adaptive144Third138Node180 = false := by
  decide +kernel

#print axioms adaptive144Third138Proof180

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third138Proof82 : runCachedNode 511 130126 Adaptive144Third138Node82 = false := by
  decide +kernel

#print axioms adaptive144Third138Proof82

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third138Proof125 : runCachedNode 511 130126 Adaptive144Third138Node125 = false := by
  decide +kernel

#print axioms adaptive144Third138Proof125

end NineSeparatedSubsetSums
