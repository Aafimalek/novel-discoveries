import NineSeparatedSubsetSums.Adaptive144Third132State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third132Proof20 : runCachedNode 511 129155 Adaptive144Third132Node20 = false := by
  decide +kernel

#print axioms adaptive144Third132Proof20

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third132Proof13 : runCachedNode 511 129155 Adaptive144Third132Node13 = false := by
  decide +kernel

#print axioms adaptive144Third132Proof13

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third132Proof2 : runCachedNode 511 129155 Adaptive144Third132Node2 = false := by
  decide +kernel

#print axioms adaptive144Third132Proof2

end NineSeparatedSubsetSums
