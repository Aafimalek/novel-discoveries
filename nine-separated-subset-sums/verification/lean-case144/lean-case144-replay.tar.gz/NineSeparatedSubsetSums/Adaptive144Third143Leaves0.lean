import NineSeparatedSubsetSums.Adaptive144Third143State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third143Proof369 : runCachedNode 511 130885 Adaptive144Third143Node369 = false := by
  decide +kernel

#print axioms adaptive144Third143Proof369

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third143Proof156 : runCachedNode 511 130885 Adaptive144Third143Node156 = false := by
  decide +kernel

#print axioms adaptive144Third143Proof156

end NineSeparatedSubsetSums
