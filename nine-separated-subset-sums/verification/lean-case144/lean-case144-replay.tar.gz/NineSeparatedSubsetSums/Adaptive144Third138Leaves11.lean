import NineSeparatedSubsetSums.Adaptive144Third138State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third138Proof15 : runCachedNode 511 130126 Adaptive144Third138Node15 = false := by
  decide +kernel

#print axioms adaptive144Third138Proof15

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third138Proof152 : runCachedNode 511 130126 Adaptive144Third138Node152 = false := by
  decide +kernel

#print axioms adaptive144Third138Proof152

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third138Proof122 : runCachedNode 511 130126 Adaptive144Third138Node122 = false := by
  decide +kernel

#print axioms adaptive144Third138Proof122

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third138Proof67 : runCachedNode 511 130126 Adaptive144Third138Node67 = false := by
  decide +kernel

#print axioms adaptive144Third138Proof67

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third138Proof54 : runCachedNode 511 130126 Adaptive144Third138Node54 = false := by
  decide +kernel

#print axioms adaptive144Third138Proof54

end NineSeparatedSubsetSums
