import NineSeparatedSubsetSums.Adaptive144Third142State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third142Proof238 : runCachedNode 511 130737 Adaptive144Third142Node238 = false := by
  decide +kernel

#print axioms adaptive144Third142Proof238

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third142Proof165 : runCachedNode 511 130737 Adaptive144Third142Node165 = false := by
  decide +kernel

#print axioms adaptive144Third142Proof165

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third142Proof201 : runCachedNode 511 130737 Adaptive144Third142Node201 = false := by
  decide +kernel

#print axioms adaptive144Third142Proof201

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third142Proof29 : runCachedNode 511 130737 Adaptive144Third142Node29 = false := by
  decide +kernel

#print axioms adaptive144Third142Proof29

end NineSeparatedSubsetSums
