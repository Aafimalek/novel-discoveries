import NineSeparatedSubsetSums.Adaptive144Third140State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof202 : runCachedNode 511 130381 Adaptive144Third140Node202 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof202

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof89 : runCachedNode 511 130381 Adaptive144Third140Node89 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof89

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof637 : runCachedNode 511 130381 Adaptive144Third140Node637 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof637

end NineSeparatedSubsetSums
