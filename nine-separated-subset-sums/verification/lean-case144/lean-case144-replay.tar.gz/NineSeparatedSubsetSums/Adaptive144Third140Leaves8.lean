import NineSeparatedSubsetSums.Adaptive144Third140State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof363 : runCachedNode 511 130381 Adaptive144Third140Node363 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof363

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof291 : runCachedNode 511 130381 Adaptive144Third140Node291 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof291

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof4 : runCachedNode 511 130381 Adaptive144Third140Node4 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof4

end NineSeparatedSubsetSums
