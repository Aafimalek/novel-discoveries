import NineSeparatedSubsetSums.Adaptive144Third137State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third137Proof16 : runCachedNode 511 129993 Adaptive144Third137Node16 = false := by
  decide +kernel

#print axioms adaptive144Third137Proof16

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third137Proof147 : runCachedNode 511 129993 Adaptive144Third137Node147 = false := by
  decide +kernel

#print axioms adaptive144Third137Proof147

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third137Proof178 : runCachedNode 511 129993 Adaptive144Third137Node178 = false := by
  decide +kernel

#print axioms adaptive144Third137Proof178

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third137Proof43 : runCachedNode 511 129993 Adaptive144Third137Node43 = false := by
  decide +kernel

#print axioms adaptive144Third137Proof43

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third137Proof22 : runCachedNode 511 129993 Adaptive144Third137Node22 = false := by
  decide +kernel

#print axioms adaptive144Third137Proof22

end NineSeparatedSubsetSums
