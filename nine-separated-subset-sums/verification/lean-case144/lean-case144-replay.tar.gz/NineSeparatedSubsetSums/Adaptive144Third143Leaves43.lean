import NineSeparatedSubsetSums.Adaptive144Third143State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third143Proof45 : runCachedNode 511 130885 Adaptive144Third143Node45 = false := by
  decide +kernel

#print axioms adaptive144Third143Proof45

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third143Proof481 : runCachedNode 511 130885 Adaptive144Third143Node481 = false := by
  decide +kernel

#print axioms adaptive144Third143Proof481

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third143Proof67 : runCachedNode 511 130885 Adaptive144Third143Node67 = false := by
  decide +kernel

#print axioms adaptive144Third143Proof67

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third143Proof636 : runCachedNode 511 130885 Adaptive144Third143Node636 = false := by
  decide +kernel

#print axioms adaptive144Third143Proof636

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third143Proof480 : runCachedNode 511 130885 Adaptive144Third143Node480 = false := by
  decide +kernel

#print axioms adaptive144Third143Proof480

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third143Proof478 : runCachedNode 511 130885 Adaptive144Third143Node478 = false := by
  decide +kernel

#print axioms adaptive144Third143Proof478

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third143Proof479 : runCachedNode 511 130885 Adaptive144Third143Node479 = false := by
  decide +kernel

#print axioms adaptive144Third143Proof479

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third143Proof247 : runCachedNode 511 130885 Adaptive144Third143Node247 = false := by
  decide +kernel

#print axioms adaptive144Third143Proof247

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third143Proof555 : runCachedNode 511 130885 Adaptive144Third143Node555 = false := by
  decide +kernel

#print axioms adaptive144Third143Proof555

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third143Proof153 : runCachedNode 511 130885 Adaptive144Third143Node153 = false := by
  decide +kernel

#print axioms adaptive144Third143Proof153

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third143Proof362 : runCachedNode 511 130885 Adaptive144Third143Node362 = false := by
  decide +kernel

#print axioms adaptive144Third143Proof362

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third143Proof477 : runCachedNode 511 130885 Adaptive144Third143Node477 = false := by
  decide +kernel

#print axioms adaptive144Third143Proof477

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third143Proof290 : runCachedNode 511 130885 Adaptive144Third143Node290 = false := by
  decide +kernel

#print axioms adaptive144Third143Proof290

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third143Proof218 : runCachedNode 511 130885 Adaptive144Third143Node218 = false := by
  decide +kernel

#print axioms adaptive144Third143Proof218

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third143Proof361 : runCachedNode 511 130885 Adaptive144Third143Node361 = false := by
  decide +kernel

#print axioms adaptive144Third143Proof361

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third143Proof220 : runCachedNode 511 130885 Adaptive144Third143Node220 = false := by
  decide +kernel

#print axioms adaptive144Third143Proof220

end NineSeparatedSubsetSums
