import NineSeparatedSubsetSums.Adaptive144Third141State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third141Proof15 : runCachedNode 511 130584 Adaptive144Third141Node15 = false := by
  decide +kernel

#print axioms adaptive144Third141Proof15

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third141Proof100 : runCachedNode 511 130584 Adaptive144Third141Node100 = false := by
  decide +kernel

#print axioms adaptive144Third141Proof100

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third141Proof195 : runCachedNode 511 130584 Adaptive144Third141Node195 = false := by
  decide +kernel

#print axioms adaptive144Third141Proof195

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third141Proof232 : runCachedNode 511 130584 Adaptive144Third141Node232 = false := by
  decide +kernel

#print axioms adaptive144Third141Proof232

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third141Proof133 : runCachedNode 511 130584 Adaptive144Third141Node133 = false := by
  decide +kernel

#print axioms adaptive144Third141Proof133

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third141Proof31 : runCachedNode 511 130584 Adaptive144Third141Node31 = false := by
  decide +kernel

#print axioms adaptive144Third141Proof31

end NineSeparatedSubsetSums
