import NineSeparatedSubsetSums.Adaptive144Third141State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third141Proof170 : runCachedNode 511 130584 Adaptive144Third141Node170 = false := by
  decide +kernel

#print axioms adaptive144Third141Proof170

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third141Proof236 : runCachedNode 511 130584 Adaptive144Third141Node236 = false := by
  decide +kernel

#print axioms adaptive144Third141Proof236

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third141Proof105 : runCachedNode 511 130584 Adaptive144Third141Node105 = false := by
  decide +kernel

#print axioms adaptive144Third141Proof105

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third141Proof32 : runCachedNode 511 130584 Adaptive144Third141Node32 = false := by
  decide +kernel

#print axioms adaptive144Third141Proof32

end NineSeparatedSubsetSums
