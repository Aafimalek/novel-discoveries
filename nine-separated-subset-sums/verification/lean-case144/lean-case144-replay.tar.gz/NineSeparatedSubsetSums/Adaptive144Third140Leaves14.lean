import NineSeparatedSubsetSums.Adaptive144Third140State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof465 : runCachedNode 511 130381 Adaptive144Third140Node465 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof465

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof117 : runCachedNode 511 130381 Adaptive144Third140Node117 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof117

end NineSeparatedSubsetSums
