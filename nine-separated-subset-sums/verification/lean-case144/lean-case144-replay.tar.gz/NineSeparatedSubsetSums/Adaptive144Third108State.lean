import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive144Third108Node0 : CachedSearchNode :=
  ⟨4, 107, computeCenteredMask [148,144,108], 400, 54304⟩

end NineSeparatedSubsetSums
