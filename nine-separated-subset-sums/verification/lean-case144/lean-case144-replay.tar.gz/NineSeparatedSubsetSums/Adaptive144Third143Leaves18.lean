import NineSeparatedSubsetSums.Adaptive144Third143State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third143Proof196 : runCachedNode 511 130885 Adaptive144Third143Node196 = false := by
  decide +kernel

#print axioms adaptive144Third143Proof196

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third143Proof18 : runCachedNode 511 130885 Adaptive144Third143Node18 = false := by
  decide +kernel

#print axioms adaptive144Third143Proof18

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third143Proof565 : runCachedNode 511 130885 Adaptive144Third143Node565 = false := by
  decide +kernel

#print axioms adaptive144Third143Proof565

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third143Proof24 : runCachedNode 511 130885 Adaptive144Third143Node24 = false := by
  decide +kernel

#print axioms adaptive144Third143Proof24

end NineSeparatedSubsetSums
