import NineSeparatedSubsetSums.Adaptive144Third134State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third134Proof25 : runCachedNode 511 129525 Adaptive144Third134Node25 = false := by
  decide +kernel

#print axioms adaptive144Third134Proof25

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third134Proof51 : runCachedNode 511 129525 Adaptive144Third134Node51 = false := by
  decide +kernel

#print axioms adaptive144Third134Proof51

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third134Proof23 : runCachedNode 511 129525 Adaptive144Third134Node23 = false := by
  decide +kernel

#print axioms adaptive144Third134Proof23

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third134Proof24 : runCachedNode 511 129525 Adaptive144Third134Node24 = false := by
  decide +kernel

#print axioms adaptive144Third134Proof24

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third134Proof49 : runCachedNode 511 129525 Adaptive144Third134Node49 = false := by
  decide +kernel

#print axioms adaptive144Third134Proof49

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third134Proof50 : runCachedNode 511 129525 Adaptive144Third134Node50 = false := by
  decide +kernel

#print axioms adaptive144Third134Proof50

end NineSeparatedSubsetSums
