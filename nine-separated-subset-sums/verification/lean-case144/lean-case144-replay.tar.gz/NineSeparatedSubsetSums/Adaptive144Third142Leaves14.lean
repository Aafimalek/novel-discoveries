import NineSeparatedSubsetSums.Adaptive144Third142State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third142Proof202 : runCachedNode 511 130737 Adaptive144Third142Node202 = false := by
  decide +kernel

#print axioms adaptive144Third142Proof202

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third142Proof19 : runCachedNode 511 130737 Adaptive144Third142Node19 = false := by
  decide +kernel

#print axioms adaptive144Third142Proof19

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third142Proof575 : runCachedNode 511 130737 Adaptive144Third142Node575 = false := by
  decide +kernel

#print axioms adaptive144Third142Proof575

end NineSeparatedSubsetSums
