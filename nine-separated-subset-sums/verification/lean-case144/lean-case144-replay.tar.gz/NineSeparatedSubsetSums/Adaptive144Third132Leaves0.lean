import NineSeparatedSubsetSums.Adaptive144Third132State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third132Proof21 : runCachedNode 511 129155 Adaptive144Third132Node21 = false := by
  decide +kernel

#print axioms adaptive144Third132Proof21

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third132Proof11 : runCachedNode 511 129155 Adaptive144Third132Node11 = false := by
  decide +kernel

#print axioms adaptive144Third132Proof11

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third132Proof3 : runCachedNode 511 129155 Adaptive144Third132Node3 = false := by
  decide +kernel

#print axioms adaptive144Third132Proof3

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third132Proof1 : runCachedNode 511 129155 Adaptive144Third132Node1 = false := by
  decide +kernel

#print axioms adaptive144Third132Proof1

end NineSeparatedSubsetSums
