import NineSeparatedSubsetSums.Adaptive144Third141State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third141Proof103 : runCachedNode 511 130584 Adaptive144Third141Node103 = false := by
  decide +kernel

#print axioms adaptive144Third141Proof103

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third141Proof305 : runCachedNode 511 130584 Adaptive144Third141Node305 = false := by
  decide +kernel

#print axioms adaptive144Third141Proof305

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third141Proof136 : runCachedNode 511 130584 Adaptive144Third141Node136 = false := by
  decide +kernel

#print axioms adaptive144Third141Proof136

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third141Proof390 : runCachedNode 511 130584 Adaptive144Third141Node390 = false := by
  decide +kernel

#print axioms adaptive144Third141Proof390

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third141Proof296 : runCachedNode 511 130584 Adaptive144Third141Node296 = false := by
  decide +kernel

#print axioms adaptive144Third141Proof296

end NineSeparatedSubsetSums
