import NineSeparatedSubsetSums.EightPoint144_117PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct144_117_1_budget :
    FourPointNumeric.packedBudget 20 packedOct144_117_1 460 = 88787820 := by decide +kernel

#print axioms packedOct144_117_1_budget

end NineSeparatedSubsetSums
