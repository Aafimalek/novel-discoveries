import NineSeparatedSubsetSums.Adaptive144Third142State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third142Proof136 : runCachedNode 511 130737 Adaptive144Third142Node136 = false := by
  decide +kernel

#print axioms adaptive144Third142Proof136

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third142Proof408 : runCachedNode 511 130737 Adaptive144Third142Node408 = false := by
  decide +kernel

#print axioms adaptive144Third142Proof408

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third142Proof108 : runCachedNode 511 130737 Adaptive144Third142Node108 = false := by
  decide +kernel

#print axioms adaptive144Third142Proof108

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third142Proof166 : runCachedNode 511 130737 Adaptive144Third142Node166 = false := by
  decide +kernel

#print axioms adaptive144Third142Proof166

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third142Proof135 : runCachedNode 511 130737 Adaptive144Third142Node135 = false := by
  decide +kernel

#print axioms adaptive144Third142Proof135

end NineSeparatedSubsetSums
