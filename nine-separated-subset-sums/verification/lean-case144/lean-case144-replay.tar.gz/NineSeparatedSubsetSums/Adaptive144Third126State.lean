import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive144Third126Node0 : CachedSearchNode :=
  ⟨4, 125, computeCenteredMask [148,144,126], 418, 58516⟩
def Adaptive144Third126Node1 : CachedSearchNode := cachedChild Adaptive144Third126Node0 110
def Adaptive144Third126Node2 : CachedSearchNode := cachedChild Adaptive144Third126Node0 111
def Adaptive144Third126Node3 : CachedSearchNode := cachedChild Adaptive144Third126Node0 112
def Adaptive144Third126Node4 : CachedSearchNode := cachedChild Adaptive144Third126Node0 113
def Adaptive144Third126Node5 : CachedSearchNode := cachedChild Adaptive144Third126Node0 114
def Adaptive144Third126Node6 : CachedSearchNode := cachedChild Adaptive144Third126Node0 115
def Adaptive144Third126Node7 : CachedSearchNode := cachedChild Adaptive144Third126Node0 116
def Adaptive144Third126Node8 : CachedSearchNode := cachedChild Adaptive144Third126Node0 117
def Adaptive144Third126Node9 : CachedSearchNode := cachedChild Adaptive144Third126Node0 118
def Adaptive144Third126Node10 : CachedSearchNode := cachedChild Adaptive144Third126Node0 119
def Adaptive144Third126Node11 : CachedSearchNode := cachedChild Adaptive144Third126Node0 120
def Adaptive144Third126Node12 : CachedSearchNode := cachedChild Adaptive144Third126Node0 121
def Adaptive144Third126Node13 : CachedSearchNode := cachedChild Adaptive144Third126Node0 123
def Adaptive144Third126Node14 : CachedSearchNode := cachedChild Adaptive144Third126Node0 124
def Adaptive144Third126Node15 : CachedSearchNode := cachedChild Adaptive144Third126Node0 125

end NineSeparatedSubsetSums
