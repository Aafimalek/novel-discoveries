import NineSeparatedSubsetSums.Adaptive144Third143State
import NineSeparatedSubsetSums.Adaptive144Third143Leaves42
import NineSeparatedSubsetSums.Adaptive144Third143Leaves54
import NineSeparatedSubsetSums.Adaptive144Third143Leaves53
import NineSeparatedSubsetSums.Adaptive144Third143Leaves52
import NineSeparatedSubsetSums.Adaptive144Third143Leaves51
import NineSeparatedSubsetSums.Adaptive144Third143Leaves50
import NineSeparatedSubsetSums.Adaptive144Third143Leaves49
import NineSeparatedSubsetSums.Adaptive144Third143Leaves48
import NineSeparatedSubsetSums.Adaptive144Third143Leaves47
import NineSeparatedSubsetSums.Adaptive144Third143Leaves45
import NineSeparatedSubsetSums.Adaptive144Third143Leaves44
import NineSeparatedSubsetSums.Adaptive144Third143Leaves43
import NineSeparatedSubsetSums.Adaptive144Third143Leaves30
import NineSeparatedSubsetSums.Adaptive144Third143Leaves39
import NineSeparatedSubsetSums.Adaptive144Third143Leaves41
import NineSeparatedSubsetSums.Adaptive144Third143Leaves37
import NineSeparatedSubsetSums.Adaptive144Third143Leaves33
import NineSeparatedSubsetSums.Adaptive144Third143Leaves31
import NineSeparatedSubsetSums.Adaptive144Third143Leaves27
import NineSeparatedSubsetSums.Adaptive144Third143Leaves23
import NineSeparatedSubsetSums.Adaptive144Third143Leaves8
import NineSeparatedSubsetSums.Adaptive144Third143Leaves11
import NineSeparatedSubsetSums.Adaptive144Third143Leaves15
import NineSeparatedSubsetSums.Adaptive144Third143Leaves12
import NineSeparatedSubsetSums.Adaptive144Third143Joins0
import NineSeparatedSubsetSums.Adaptive144Third143Leaves1
import NineSeparatedSubsetSums.Adaptive144Third143Leaves2
import NineSeparatedSubsetSums.Adaptive144Third143Leaves55
import NineSeparatedSubsetSums.Adaptive144Third143Leaves46
import NineSeparatedSubsetSums.Adaptive144Third143Leaves35
import NineSeparatedSubsetSums.Adaptive144Third143Leaves40
import NineSeparatedSubsetSums.Adaptive144Third143Leaves36
import NineSeparatedSubsetSums.Adaptive144Third143Leaves29
import NineSeparatedSubsetSums.Adaptive144Third143Leaves20
import NineSeparatedSubsetSums.Adaptive144Third143Leaves32
import NineSeparatedSubsetSums.Adaptive144Third143Leaves28
import NineSeparatedSubsetSums.Adaptive144Third143Leaves9
import NineSeparatedSubsetSums.Adaptive144Third143Leaves34
import NineSeparatedSubsetSums.Adaptive144Third143Leaves24
import NineSeparatedSubsetSums.Adaptive144Third143Leaves19
import NineSeparatedSubsetSums.Adaptive144Third143Leaves10
import NineSeparatedSubsetSums.Adaptive144Third143Leaves21
import NineSeparatedSubsetSums.Adaptive144Third143Leaves4
import NineSeparatedSubsetSums.Adaptive144Third143Leaves7
import NineSeparatedSubsetSums.Adaptive144Third143Leaves0
import NineSeparatedSubsetSums.Adaptive144Third143Leaves56
import NineSeparatedSubsetSums.Adaptive144Third143Leaves25
import NineSeparatedSubsetSums.Adaptive144Third143Leaves26
import NineSeparatedSubsetSums.Adaptive144Third143Leaves16

namespace NineSeparatedSubsetSums

theorem adaptive144Third143Proof230 : runCachedNode 511 130885 Adaptive144Third143Node230 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130885 Adaptive144Third143Node230 = [101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 132, 135, 136] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive144Third143Proof231
  · exact adaptive144Third143Proof232
  · exact adaptive144Third143Proof233
  · exact adaptive144Third143Proof234
  · exact adaptive144Third143Proof235
  · exact adaptive144Third143Proof236
  · exact adaptive144Third143Proof237
  · exact adaptive144Third143Proof238
  · exact adaptive144Third143Proof239
  · exact adaptive144Third143Proof240
  · exact adaptive144Third143Proof241
  · exact adaptive144Third143Proof242
  · exact adaptive144Third143Proof243
  · exact adaptive144Third143Proof244
  · exact adaptive144Third143Proof245
  · exact adaptive144Third143Proof246
  · exact adaptive144Third143Proof247
  · exact adaptive144Third143Proof248
  · exact adaptive144Third143Proof249
  · exact adaptive144Third143Proof250
  · exact adaptive144Third143Proof251
  · exact adaptive144Third143Proof252
  · exact adaptive144Third143Proof253
  · exact adaptive144Third143Proof254
  · exact adaptive144Third143Proof255
  · exact adaptive144Third143Proof256
  · exact adaptive144Third143Proof257
  · exact adaptive144Third143Proof258
  · exact adaptive144Third143Proof259
  · exact adaptive144Third143Proof260
  · exact adaptive144Third143Proof261
  · exact adaptive144Third143Proof262
  · exact adaptive144Third143Proof298
  · exact adaptive144Third143Proof299

#print axioms adaptive144Third143Proof230

theorem adaptive144Third143Proof332 : runCachedNode 511 130885 Adaptive144Third143Node332 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130885 Adaptive144Third143Node332 = [90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 126, 130] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive144Third143Proof333
  · exact adaptive144Third143Proof334
  · exact adaptive144Third143Proof335
  · exact adaptive144Third143Proof336
  · exact adaptive144Third143Proof337
  · exact adaptive144Third143Proof338
  · exact adaptive144Third143Proof339
  · exact adaptive144Third143Proof340
  · exact adaptive144Third143Proof341
  · exact adaptive144Third143Proof342
  · exact adaptive144Third143Proof343
  · exact adaptive144Third143Proof344
  · exact adaptive144Third143Proof345
  · exact adaptive144Third143Proof346
  · exact adaptive144Third143Proof347
  · exact adaptive144Third143Proof348
  · exact adaptive144Third143Proof349
  · exact adaptive144Third143Proof350
  · exact adaptive144Third143Proof351
  · exact adaptive144Third143Proof352
  · exact adaptive144Third143Proof353
  · exact adaptive144Third143Proof354
  · exact adaptive144Third143Proof355
  · exact adaptive144Third143Proof356
  · exact adaptive144Third143Proof357
  · exact adaptive144Third143Proof358
  · exact adaptive144Third143Proof359
  · exact adaptive144Third143Proof360
  · exact adaptive144Third143Proof361
  · exact adaptive144Third143Proof362
  · exact adaptive144Third143Proof363
  · exact adaptive144Third143Proof364
  · exact adaptive144Third143Proof365
  · exact adaptive144Third143Proof366
  · exact adaptive144Third143Proof367

#print axioms adaptive144Third143Proof332

theorem adaptive144Third143Proof370 : runCachedNode 511 130885 Adaptive144Third143Node370 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130885 Adaptive144Third143Node370 = [88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 131] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive144Third143Proof371
  · exact adaptive144Third143Proof372
  · exact adaptive144Third143Proof373
  · exact adaptive144Third143Proof374
  · exact adaptive144Third143Proof375
  · exact adaptive144Third143Proof376
  · exact adaptive144Third143Proof377
  · exact adaptive144Third143Proof378
  · exact adaptive144Third143Proof379
  · exact adaptive144Third143Proof380
  · exact adaptive144Third143Proof381
  · exact adaptive144Third143Proof382
  · exact adaptive144Third143Proof383
  · exact adaptive144Third143Proof384
  · exact adaptive144Third143Proof385
  · exact adaptive144Third143Proof386
  · exact adaptive144Third143Proof387
  · exact adaptive144Third143Proof388
  · exact adaptive144Third143Proof389
  · exact adaptive144Third143Proof390
  · exact adaptive144Third143Proof391
  · exact adaptive144Third143Proof392
  · exact adaptive144Third143Proof393
  · exact adaptive144Third143Proof394
  · exact adaptive144Third143Proof395
  · exact adaptive144Third143Proof396
  · exact adaptive144Third143Proof397
  · exact adaptive144Third143Proof398
  · exact adaptive144Third143Proof399
  · exact adaptive144Third143Proof400
  · exact adaptive144Third143Proof401
  · exact adaptive144Third143Proof402
  · exact adaptive144Third143Proof403
  · exact adaptive144Third143Proof404
  · exact adaptive144Third143Proof405
  · exact adaptive144Third143Proof406
  · exact adaptive144Third143Proof407
  · exact adaptive144Third143Proof408
  · exact adaptive144Third143Proof409
  · exact adaptive144Third143Proof410
  · exact adaptive144Third143Proof411

#print axioms adaptive144Third143Proof370

theorem adaptive144Third143Proof412 : runCachedNode 511 130885 Adaptive144Third143Node412 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130885 Adaptive144Third143Node412 = [87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 132] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive144Third143Proof413
  · exact adaptive144Third143Proof414
  · exact adaptive144Third143Proof415
  · exact adaptive144Third143Proof416
  · exact adaptive144Third143Proof417
  · exact adaptive144Third143Proof418
  · exact adaptive144Third143Proof419
  · exact adaptive144Third143Proof420
  · exact adaptive144Third143Proof421
  · exact adaptive144Third143Proof422
  · exact adaptive144Third143Proof423
  · exact adaptive144Third143Proof424
  · exact adaptive144Third143Proof425
  · exact adaptive144Third143Proof426
  · exact adaptive144Third143Proof427
  · exact adaptive144Third143Proof428
  · exact adaptive144Third143Proof429
  · exact adaptive144Third143Proof430
  · exact adaptive144Third143Proof431
  · exact adaptive144Third143Proof432
  · exact adaptive144Third143Proof433
  · exact adaptive144Third143Proof434
  · exact adaptive144Third143Proof435
  · exact adaptive144Third143Proof436
  · exact adaptive144Third143Proof437
  · exact adaptive144Third143Proof438
  · exact adaptive144Third143Proof439
  · exact adaptive144Third143Proof440
  · exact adaptive144Third143Proof441
  · exact adaptive144Third143Proof442
  · exact adaptive144Third143Proof443
  · exact adaptive144Third143Proof444
  · exact adaptive144Third143Proof445
  · exact adaptive144Third143Proof446
  · exact adaptive144Third143Proof447
  · exact adaptive144Third143Proof448
  · exact adaptive144Third143Proof449
  · exact adaptive144Third143Proof450
  · exact adaptive144Third143Proof451
  · exact adaptive144Third143Proof452
  · exact adaptive144Third143Proof453
  · exact adaptive144Third143Proof454
  · exact adaptive144Third143Proof455

#print axioms adaptive144Third143Proof412

theorem adaptive144Third143Proof300 : runCachedNode 511 130885 Adaptive144Third143Node300 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130885 Adaptive144Third143Node300 = [101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 132, 133, 134, 137, 138] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive144Third143Proof301
  · exact adaptive144Third143Proof302
  · exact adaptive144Third143Proof303
  · exact adaptive144Third143Proof304
  · exact adaptive144Third143Proof305
  · exact adaptive144Third143Proof306
  · exact adaptive144Third143Proof307
  · exact adaptive144Third143Proof308
  · exact adaptive144Third143Proof309
  · exact adaptive144Third143Proof310
  · exact adaptive144Third143Proof311
  · exact adaptive144Third143Proof312
  · exact adaptive144Third143Proof313
  · exact adaptive144Third143Proof314
  · exact adaptive144Third143Proof315
  · exact adaptive144Third143Proof316
  · exact adaptive144Third143Proof317
  · exact adaptive144Third143Proof318
  · exact adaptive144Third143Proof319
  · exact adaptive144Third143Proof320
  · exact adaptive144Third143Proof321
  · exact adaptive144Third143Proof322
  · exact adaptive144Third143Proof323
  · exact adaptive144Third143Proof324
  · exact adaptive144Third143Proof325
  · exact adaptive144Third143Proof326
  · exact adaptive144Third143Proof327
  · exact adaptive144Third143Proof328
  · exact adaptive144Third143Proof329
  · exact adaptive144Third143Proof330
  · exact adaptive144Third143Proof331
  · exact adaptive144Third143Proof332
  · exact adaptive144Third143Proof368
  · exact adaptive144Third143Proof369
  · exact adaptive144Third143Proof370
  · exact adaptive144Third143Proof412

#print axioms adaptive144Third143Proof300

theorem adaptive144Third143Proof493 : runCachedNode 511 130885 Adaptive144Third143Node493 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130885 Adaptive144Third143Node493 = [87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive144Third143Proof494
  · exact adaptive144Third143Proof495
  · exact adaptive144Third143Proof496
  · exact adaptive144Third143Proof497
  · exact adaptive144Third143Proof498
  · exact adaptive144Third143Proof499
  · exact adaptive144Third143Proof500
  · exact adaptive144Third143Proof501
  · exact adaptive144Third143Proof502
  · exact adaptive144Third143Proof503
  · exact adaptive144Third143Proof504
  · exact adaptive144Third143Proof505
  · exact adaptive144Third143Proof506
  · exact adaptive144Third143Proof507
  · exact adaptive144Third143Proof508
  · exact adaptive144Third143Proof509
  · exact adaptive144Third143Proof510
  · exact adaptive144Third143Proof511
  · exact adaptive144Third143Proof512
  · exact adaptive144Third143Proof513
  · exact adaptive144Third143Proof514
  · exact adaptive144Third143Proof515
  · exact adaptive144Third143Proof516
  · exact adaptive144Third143Proof517
  · exact adaptive144Third143Proof518
  · exact adaptive144Third143Proof519
  · exact adaptive144Third143Proof520
  · exact adaptive144Third143Proof521
  · exact adaptive144Third143Proof522
  · exact adaptive144Third143Proof523
  · exact adaptive144Third143Proof524
  · exact adaptive144Third143Proof525
  · exact adaptive144Third143Proof526
  · exact adaptive144Third143Proof527
  · exact adaptive144Third143Proof528
  · exact adaptive144Third143Proof529
  · exact adaptive144Third143Proof530
  · exact adaptive144Third143Proof531
  · exact adaptive144Third143Proof532
  · exact adaptive144Third143Proof533
  · exact adaptive144Third143Proof534
  · exact adaptive144Third143Proof535
  · exact adaptive144Third143Proof536

#print axioms adaptive144Third143Proof493

theorem adaptive144Third143Proof456 : runCachedNode 511 130885 Adaptive144Third143Node456 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130885 Adaptive144Third143Node456 = [100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 132, 133, 134, 135, 138] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive144Third143Proof457
  · exact adaptive144Third143Proof458
  · exact adaptive144Third143Proof459
  · exact adaptive144Third143Proof460
  · exact adaptive144Third143Proof461
  · exact adaptive144Third143Proof462
  · exact adaptive144Third143Proof463
  · exact adaptive144Third143Proof464
  · exact adaptive144Third143Proof465
  · exact adaptive144Third143Proof466
  · exact adaptive144Third143Proof467
  · exact adaptive144Third143Proof468
  · exact adaptive144Third143Proof469
  · exact adaptive144Third143Proof470
  · exact adaptive144Third143Proof471
  · exact adaptive144Third143Proof472
  · exact adaptive144Third143Proof473
  · exact adaptive144Third143Proof474
  · exact adaptive144Third143Proof475
  · exact adaptive144Third143Proof476
  · exact adaptive144Third143Proof477
  · exact adaptive144Third143Proof478
  · exact adaptive144Third143Proof479
  · exact adaptive144Third143Proof480
  · exact adaptive144Third143Proof481
  · exact adaptive144Third143Proof482
  · exact adaptive144Third143Proof483
  · exact adaptive144Third143Proof484
  · exact adaptive144Third143Proof485
  · exact adaptive144Third143Proof486
  · exact adaptive144Third143Proof487
  · exact adaptive144Third143Proof488
  · exact adaptive144Third143Proof489
  · exact adaptive144Third143Proof490
  · exact adaptive144Third143Proof491
  · exact adaptive144Third143Proof492
  · exact adaptive144Third143Proof493

#print axioms adaptive144Third143Proof456

theorem adaptive144Third143Proof574 : runCachedNode 511 130885 Adaptive144Third143Node574 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130885 Adaptive144Third143Node574 = [87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive144Third143Proof575
  · exact adaptive144Third143Proof576
  · exact adaptive144Third143Proof577
  · exact adaptive144Third143Proof578
  · exact adaptive144Third143Proof579
  · exact adaptive144Third143Proof580
  · exact adaptive144Third143Proof581
  · exact adaptive144Third143Proof582
  · exact adaptive144Third143Proof583
  · exact adaptive144Third143Proof584
  · exact adaptive144Third143Proof585
  · exact adaptive144Third143Proof586
  · exact adaptive144Third143Proof587
  · exact adaptive144Third143Proof588
  · exact adaptive144Third143Proof589
  · exact adaptive144Third143Proof590
  · exact adaptive144Third143Proof591
  · exact adaptive144Third143Proof592
  · exact adaptive144Third143Proof593
  · exact adaptive144Third143Proof594
  · exact adaptive144Third143Proof595
  · exact adaptive144Third143Proof596
  · exact adaptive144Third143Proof597
  · exact adaptive144Third143Proof598
  · exact adaptive144Third143Proof599
  · exact adaptive144Third143Proof600
  · exact adaptive144Third143Proof601
  · exact adaptive144Third143Proof602
  · exact adaptive144Third143Proof603
  · exact adaptive144Third143Proof604
  · exact adaptive144Third143Proof605
  · exact adaptive144Third143Proof606
  · exact adaptive144Third143Proof607
  · exact adaptive144Third143Proof608
  · exact adaptive144Third143Proof609
  · exact adaptive144Third143Proof610
  · exact adaptive144Third143Proof611
  · exact adaptive144Third143Proof612
  · exact adaptive144Third143Proof613
  · exact adaptive144Third143Proof614
  · exact adaptive144Third143Proof615
  · exact adaptive144Third143Proof616

#print axioms adaptive144Third143Proof574

end NineSeparatedSubsetSums
