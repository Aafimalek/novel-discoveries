import NineSeparatedSubsetSums.Adaptive144Third126State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third126Proof7 : runCachedNode 511 127754 Adaptive144Third126Node7 = false := by
  decide +kernel

#print axioms adaptive144Third126Proof7

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third126Proof5 : runCachedNode 511 127754 Adaptive144Third126Node5 = false := by
  decide +kernel

#print axioms adaptive144Third126Proof5

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third126Proof4 : runCachedNode 511 127754 Adaptive144Third126Node4 = false := by
  decide +kernel

#print axioms adaptive144Third126Proof4

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third126Proof1 : runCachedNode 511 127754 Adaptive144Third126Node1 = false := by
  decide +kernel

#print axioms adaptive144Third126Proof1

end NineSeparatedSubsetSums
