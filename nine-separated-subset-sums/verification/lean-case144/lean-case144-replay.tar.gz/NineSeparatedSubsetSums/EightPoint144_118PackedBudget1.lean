import NineSeparatedSubsetSums.EightPoint144_118PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct144_118_1_budget :
    FourPointNumeric.packedBudget 20 packedOct144_118_1 456 = 89234332 := by decide +kernel

#print axioms packedOct144_118_1_budget

end NineSeparatedSubsetSums
