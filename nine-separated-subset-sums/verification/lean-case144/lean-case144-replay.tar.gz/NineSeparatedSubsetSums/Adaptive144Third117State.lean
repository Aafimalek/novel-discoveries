import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive144Third117Node0 : CachedSearchNode :=
  ⟨4, 116, computeCenteredMask [148,144,117], 409, 56329⟩

end NineSeparatedSubsetSums
