import NineSeparatedSubsetSums.Adaptive144Third123State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third123Proof0 : runCachedNode 511 126857 Adaptive144Third123Node0 = false := by
  decide +kernel

#print axioms adaptive144Third123Proof0

end NineSeparatedSubsetSums
