import NineSeparatedSubsetSums.Adaptive144Third128State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third128Proof11 : runCachedNode 511 128276 Adaptive144Third128Node11 = false := by
  decide +kernel

#print axioms adaptive144Third128Proof11

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third128Proof13 : runCachedNode 511 128276 Adaptive144Third128Node13 = false := by
  decide +kernel

#print axioms adaptive144Third128Proof13

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third128Proof12 : runCachedNode 511 128276 Adaptive144Third128Node12 = false := by
  decide +kernel

#print axioms adaptive144Third128Proof12

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third128Proof10 : runCachedNode 511 128276 Adaptive144Third128Node10 = false := by
  decide +kernel

#print axioms adaptive144Third128Proof10

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third128Proof9 : runCachedNode 511 128276 Adaptive144Third128Node9 = false := by
  decide +kernel

#print axioms adaptive144Third128Proof9

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third128Proof8 : runCachedNode 511 128276 Adaptive144Third128Node8 = false := by
  decide +kernel

#print axioms adaptive144Third128Proof8

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third128Proof6 : runCachedNode 511 128276 Adaptive144Third128Node6 = false := by
  decide +kernel

#print axioms adaptive144Third128Proof6

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third128Proof5 : runCachedNode 511 128276 Adaptive144Third128Node5 = false := by
  decide +kernel

#print axioms adaptive144Third128Proof5

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third128Proof3 : runCachedNode 511 128276 Adaptive144Third128Node3 = false := by
  decide +kernel

#print axioms adaptive144Third128Proof3

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third128Proof2 : runCachedNode 511 128276 Adaptive144Third128Node2 = false := by
  decide +kernel

#print axioms adaptive144Third128Proof2

end NineSeparatedSubsetSums
