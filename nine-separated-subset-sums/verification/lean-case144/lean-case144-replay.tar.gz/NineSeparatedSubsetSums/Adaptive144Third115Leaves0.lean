import NineSeparatedSubsetSums.Adaptive144Third115State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third115Proof14 : runCachedNode 511 112221 Adaptive144Third115Node14 = false := by
  decide +kernel

#print axioms adaptive144Third115Proof14

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third115Proof13 : runCachedNode 511 112221 Adaptive144Third115Node13 = false := by
  decide +kernel

#print axioms adaptive144Third115Proof13

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third115Proof12 : runCachedNode 511 112221 Adaptive144Third115Node12 = false := by
  decide +kernel

#print axioms adaptive144Third115Proof12

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third115Proof11 : runCachedNode 511 112221 Adaptive144Third115Node11 = false := by
  decide +kernel

#print axioms adaptive144Third115Proof11

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third115Proof8 : runCachedNode 511 112221 Adaptive144Third115Node8 = false := by
  decide +kernel

#print axioms adaptive144Third115Proof8

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third115Proof2 : runCachedNode 511 112221 Adaptive144Third115Node2 = false := by
  decide +kernel

#print axioms adaptive144Third115Proof2

end NineSeparatedSubsetSums
