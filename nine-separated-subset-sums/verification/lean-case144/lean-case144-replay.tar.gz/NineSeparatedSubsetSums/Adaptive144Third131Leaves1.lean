import NineSeparatedSubsetSums.Adaptive144Third131State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third131Proof19 : runCachedNode 511 129000 Adaptive144Third131Node19 = false := by
  decide +kernel

#print axioms adaptive144Third131Proof19

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third131Proof18 : runCachedNode 511 129000 Adaptive144Third131Node18 = false := by
  decide +kernel

#print axioms adaptive144Third131Proof18

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third131Proof10 : runCachedNode 511 129000 Adaptive144Third131Node10 = false := by
  decide +kernel

#print axioms adaptive144Third131Proof10

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third131Proof2 : runCachedNode 511 129000 Adaptive144Third131Node2 = false := by
  decide +kernel

#print axioms adaptive144Third131Proof2

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third131Proof1 : runCachedNode 511 129000 Adaptive144Third131Node1 = false := by
  decide +kernel

#print axioms adaptive144Third131Proof1

end NineSeparatedSubsetSums
