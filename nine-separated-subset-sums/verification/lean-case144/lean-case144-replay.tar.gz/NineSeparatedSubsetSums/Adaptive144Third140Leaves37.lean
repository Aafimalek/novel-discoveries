import NineSeparatedSubsetSums.Adaptive144Third140State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof10 : runCachedNode 511 130381 Adaptive144Third140Node10 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof10

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof87 : runCachedNode 511 130381 Adaptive144Third140Node87 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof87

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof719 : runCachedNode 511 130381 Adaptive144Third140Node719 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof719

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof235 : runCachedNode 511 130381 Adaptive144Third140Node235 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof235

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof676 : runCachedNode 511 130381 Adaptive144Third140Node676 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof676

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof463 : runCachedNode 511 130381 Adaptive144Third140Node463 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof463

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof249 : runCachedNode 511 130381 Adaptive144Third140Node249 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof249

end NineSeparatedSubsetSums
