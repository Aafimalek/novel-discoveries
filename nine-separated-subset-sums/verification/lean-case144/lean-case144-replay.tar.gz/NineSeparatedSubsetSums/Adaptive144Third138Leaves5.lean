import NineSeparatedSubsetSums.Adaptive144Third138State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third138Proof215 : runCachedNode 511 130126 Adaptive144Third138Node215 = false := by
  decide +kernel

#print axioms adaptive144Third138Proof215

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third138Proof182 : runCachedNode 511 130126 Adaptive144Third138Node182 = false := by
  decide +kernel

#print axioms adaptive144Third138Proof182

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third138Proof60 : runCachedNode 511 130126 Adaptive144Third138Node60 = false := by
  decide +kernel

#print axioms adaptive144Third138Proof60

end NineSeparatedSubsetSums
