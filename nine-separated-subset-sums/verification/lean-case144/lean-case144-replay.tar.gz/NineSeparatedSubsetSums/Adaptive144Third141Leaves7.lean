import NineSeparatedSubsetSums.Adaptive144Third141State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third141Proof107 : runCachedNode 511 130584 Adaptive144Third141Node107 = false := by
  decide +kernel

#print axioms adaptive144Third141Proof107

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third141Proof106 : runCachedNode 511 130584 Adaptive144Third141Node106 = false := by
  decide +kernel

#print axioms adaptive144Third141Proof106

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third141Proof1 : runCachedNode 511 130584 Adaptive144Third141Node1 = false := by
  decide +kernel

#print axioms adaptive144Third141Proof1

end NineSeparatedSubsetSums
