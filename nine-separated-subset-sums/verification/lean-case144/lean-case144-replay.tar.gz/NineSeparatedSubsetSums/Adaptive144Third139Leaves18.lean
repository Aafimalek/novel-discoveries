import NineSeparatedSubsetSums.Adaptive144Third139State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third139Proof207 : runCachedNode 511 130274 Adaptive144Third139Node207 = false := by
  decide +kernel

#print axioms adaptive144Third139Proof207

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third139Proof176 : runCachedNode 511 130274 Adaptive144Third139Node176 = false := by
  decide +kernel

#print axioms adaptive144Third139Proof176

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third139Proof39 : runCachedNode 511 130274 Adaptive144Third139Node39 = false := by
  decide +kernel

#print axioms adaptive144Third139Proof39

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third139Proof206 : runCachedNode 511 130274 Adaptive144Third139Node206 = false := by
  decide +kernel

#print axioms adaptive144Third139Proof206

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third139Proof38 : runCachedNode 511 130274 Adaptive144Third139Node38 = false := by
  decide +kernel

#print axioms adaptive144Third139Proof38

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third139Proof94 : runCachedNode 511 130274 Adaptive144Third139Node94 = false := by
  decide +kernel

#print axioms adaptive144Third139Proof94

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third139Proof10 : runCachedNode 511 130274 Adaptive144Third139Node10 = false := by
  decide +kernel

#print axioms adaptive144Third139Proof10

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third139Proof205 : runCachedNode 511 130274 Adaptive144Third139Node205 = false := by
  decide +kernel

#print axioms adaptive144Third139Proof205

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third139Proof88 : runCachedNode 511 130274 Adaptive144Third139Node88 = false := by
  decide +kernel

#print axioms adaptive144Third139Proof88

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third139Proof66 : runCachedNode 511 130274 Adaptive144Third139Node66 = false := by
  decide +kernel

#print axioms adaptive144Third139Proof66

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third139Proof117 : runCachedNode 511 130274 Adaptive144Third139Node117 = false := by
  decide +kernel

#print axioms adaptive144Third139Proof117

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third139Proof63 : runCachedNode 511 130274 Adaptive144Third139Node63 = false := by
  decide +kernel

#print axioms adaptive144Third139Proof63

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third139Proof236 : runCachedNode 511 130274 Adaptive144Third139Node236 = false := by
  decide +kernel

#print axioms adaptive144Third139Proof236

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third139Proof34 : runCachedNode 511 130274 Adaptive144Third139Node34 = false := by
  decide +kernel

#print axioms adaptive144Third139Proof34

end NineSeparatedSubsetSums
