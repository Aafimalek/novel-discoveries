import NineSeparatedSubsetSums.Adaptive144Third141State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third141Proof131 : runCachedNode 511 130584 Adaptive144Third141Node131 = false := by
  decide +kernel

#print axioms adaptive144Third141Proof131

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third141Proof11 : runCachedNode 511 130584 Adaptive144Third141Node11 = false := by
  decide +kernel

#print axioms adaptive144Third141Proof11

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third141Proof274 : runCachedNode 511 130584 Adaptive144Third141Node274 = false := by
  decide +kernel

#print axioms adaptive144Third141Proof274

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third141Proof297 : runCachedNode 511 130584 Adaptive144Third141Node297 = false := by
  decide +kernel

#print axioms adaptive144Third141Proof297

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third141Proof339 : runCachedNode 511 130584 Adaptive144Third141Node339 = false := by
  decide +kernel

#print axioms adaptive144Third141Proof339

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third141Proof96 : runCachedNode 511 130584 Adaptive144Third141Node96 = false := by
  decide +kernel

#print axioms adaptive144Third141Proof96

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third141Proof189 : runCachedNode 511 130584 Adaptive144Third141Node189 = false := by
  decide +kernel

#print axioms adaptive144Third141Proof189

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third141Proof386 : runCachedNode 511 130584 Adaptive144Third141Node386 = false := by
  decide +kernel

#print axioms adaptive144Third141Proof386

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third141Proof188 : runCachedNode 511 130584 Adaptive144Third141Node188 = false := by
  decide +kernel

#print axioms adaptive144Third141Proof188

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third141Proof226 : runCachedNode 511 130584 Adaptive144Third141Node226 = false := by
  decide +kernel

#print axioms adaptive144Third141Proof226

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third141Proof225 : runCachedNode 511 130584 Adaptive144Third141Node225 = false := by
  decide +kernel

#print axioms adaptive144Third141Proof225

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third141Proof42 : runCachedNode 511 130584 Adaptive144Third141Node42 = false := by
  decide +kernel

#print axioms adaptive144Third141Proof42

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third141Proof130 : runCachedNode 511 130584 Adaptive144Third141Node130 = false := by
  decide +kernel

#print axioms adaptive144Third141Proof130

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third141Proof342 : runCachedNode 511 130584 Adaptive144Third141Node342 = false := by
  decide +kernel

#print axioms adaptive144Third141Proof342

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third141Proof159 : runCachedNode 511 130584 Adaptive144Third141Node159 = false := by
  decide +kernel

#print axioms adaptive144Third141Proof159

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third141Proof110 : runCachedNode 511 130584 Adaptive144Third141Node110 = false := by
  decide +kernel

#print axioms adaptive144Third141Proof110

end NineSeparatedSubsetSums
