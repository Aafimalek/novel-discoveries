import NineSeparatedSubsetSums.Adaptive144Third140State
import NineSeparatedSubsetSums.Adaptive144Third140Leaves63
import NineSeparatedSubsetSums.Adaptive144Third140Leaves62
import NineSeparatedSubsetSums.Adaptive144Third140Leaves61
import NineSeparatedSubsetSums.Adaptive144Third140Leaves60
import NineSeparatedSubsetSums.Adaptive144Third140Leaves58
import NineSeparatedSubsetSums.Adaptive144Third140Leaves57
import NineSeparatedSubsetSums.Adaptive144Third140Leaves55
import NineSeparatedSubsetSums.Adaptive144Third140Leaves56
import NineSeparatedSubsetSums.Adaptive144Third140Leaves54
import NineSeparatedSubsetSums.Adaptive144Third140Leaves53
import NineSeparatedSubsetSums.Adaptive144Third140Leaves44
import NineSeparatedSubsetSums.Adaptive144Third140Leaves52
import NineSeparatedSubsetSums.Adaptive144Third140Leaves49
import NineSeparatedSubsetSums.Adaptive144Third140Leaves48
import NineSeparatedSubsetSums.Adaptive144Third140Leaves45
import NineSeparatedSubsetSums.Adaptive144Third140Leaves36
import NineSeparatedSubsetSums.Adaptive144Third140Leaves23
import NineSeparatedSubsetSums.Adaptive144Third140Leaves51
import NineSeparatedSubsetSums.Adaptive144Third140Leaves46
import NineSeparatedSubsetSums.Adaptive144Third140Leaves38
import NineSeparatedSubsetSums.Adaptive144Third140Leaves41
import NineSeparatedSubsetSums.Adaptive144Third140Leaves39
import NineSeparatedSubsetSums.Adaptive144Third140Leaves29
import NineSeparatedSubsetSums.Adaptive144Third140Leaves32
import NineSeparatedSubsetSums.Adaptive144Third140Leaves19
import NineSeparatedSubsetSums.Adaptive144Third140Leaves27
import NineSeparatedSubsetSums.Adaptive144Third140Leaves3
import NineSeparatedSubsetSums.Adaptive144Third140Leaves17
import NineSeparatedSubsetSums.Adaptive144Third140Joins1
import NineSeparatedSubsetSums.Adaptive144Third140Leaves5
import NineSeparatedSubsetSums.Adaptive144Third140Leaves0
import NineSeparatedSubsetSums.Adaptive144Third140Leaves50
import NineSeparatedSubsetSums.Adaptive144Third140Leaves43
import NineSeparatedSubsetSums.Adaptive144Third140Leaves20
import NineSeparatedSubsetSums.Adaptive144Third140Leaves42
import NineSeparatedSubsetSums.Adaptive144Third140Leaves33
import NineSeparatedSubsetSums.Adaptive144Third140Leaves47
import NineSeparatedSubsetSums.Adaptive144Third140Leaves37
import NineSeparatedSubsetSums.Adaptive144Third140Leaves26
import NineSeparatedSubsetSums.Adaptive144Third140Leaves64
import NineSeparatedSubsetSums.Adaptive144Third140Leaves59
import NineSeparatedSubsetSums.Adaptive144Third140Leaves22
import NineSeparatedSubsetSums.Adaptive144Third140Leaves21
import NineSeparatedSubsetSums.Adaptive144Third140Leaves40
import NineSeparatedSubsetSums.Adaptive144Third140Leaves28
import NineSeparatedSubsetSums.Adaptive144Third140Leaves31
import NineSeparatedSubsetSums.Adaptive144Third140Leaves9
import NineSeparatedSubsetSums.Adaptive144Third140Leaves10
import NineSeparatedSubsetSums.Adaptive144Third140Leaves2
import NineSeparatedSubsetSums.Adaptive144Third140Leaves15
import NineSeparatedSubsetSums.Adaptive144Third140Leaves8
import NineSeparatedSubsetSums.Adaptive144Third140Leaves30
import NineSeparatedSubsetSums.Adaptive144Third140Leaves18
import NineSeparatedSubsetSums.Adaptive144Third140Leaves6
import NineSeparatedSubsetSums.Adaptive144Third140Leaves1
import NineSeparatedSubsetSums.Adaptive144Third140Joins0

namespace NineSeparatedSubsetSums

theorem adaptive144Third140Proof534 : runCachedNode 511 130381 Adaptive144Third140Node534 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130381 Adaptive144Third140Node534 = [89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 124, 125, 126, 128, 132] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive144Third140Proof535
  · exact adaptive144Third140Proof536
  · exact adaptive144Third140Proof537
  · exact adaptive144Third140Proof538
  · exact adaptive144Third140Proof539
  · exact adaptive144Third140Proof540
  · exact adaptive144Third140Proof541
  · exact adaptive144Third140Proof542
  · exact adaptive144Third140Proof543
  · exact adaptive144Third140Proof544
  · exact adaptive144Third140Proof545
  · exact adaptive144Third140Proof546
  · exact adaptive144Third140Proof547
  · exact adaptive144Third140Proof548
  · exact adaptive144Third140Proof549
  · exact adaptive144Third140Proof550
  · exact adaptive144Third140Proof551
  · exact adaptive144Third140Proof552
  · exact adaptive144Third140Proof553
  · exact adaptive144Third140Proof554
  · exact adaptive144Third140Proof555
  · exact adaptive144Third140Proof556
  · exact adaptive144Third140Proof557
  · exact adaptive144Third140Proof558
  · exact adaptive144Third140Proof559
  · exact adaptive144Third140Proof560
  · exact adaptive144Third140Proof561
  · exact adaptive144Third140Proof562
  · exact adaptive144Third140Proof563
  · exact adaptive144Third140Proof564
  · exact adaptive144Third140Proof565
  · exact adaptive144Third140Proof566
  · exact adaptive144Third140Proof567
  · exact adaptive144Third140Proof568
  · exact adaptive144Third140Proof569
  · exact adaptive144Third140Proof570
  · exact adaptive144Third140Proof571
  · exact adaptive144Third140Proof572
  · exact adaptive144Third140Proof573

#print axioms adaptive144Third140Proof534

theorem adaptive144Third140Proof466 : runCachedNode 511 130381 Adaptive144Third140Node466 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130381 Adaptive144Third140Node466 = [102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 131, 132, 133, 135, 137] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive144Third140Proof467
  · exact adaptive144Third140Proof468
  · exact adaptive144Third140Proof469
  · exact adaptive144Third140Proof470
  · exact adaptive144Third140Proof471
  · exact adaptive144Third140Proof472
  · exact adaptive144Third140Proof473
  · exact adaptive144Third140Proof474
  · exact adaptive144Third140Proof475
  · exact adaptive144Third140Proof476
  · exact adaptive144Third140Proof477
  · exact adaptive144Third140Proof478
  · exact adaptive144Third140Proof479
  · exact adaptive144Third140Proof480
  · exact adaptive144Third140Proof481
  · exact adaptive144Third140Proof482
  · exact adaptive144Third140Proof483
  · exact adaptive144Third140Proof484
  · exact adaptive144Third140Proof485
  · exact adaptive144Third140Proof486
  · exact adaptive144Third140Proof487
  · exact adaptive144Third140Proof488
  · exact adaptive144Third140Proof489
  · exact adaptive144Third140Proof490
  · exact adaptive144Third140Proof491
  · exact adaptive144Third140Proof492
  · exact adaptive144Third140Proof493
  · exact adaptive144Third140Proof494
  · exact adaptive144Third140Proof495
  · exact adaptive144Third140Proof496
  · exact adaptive144Third140Proof532
  · exact adaptive144Third140Proof533
  · exact adaptive144Third140Proof534

#print axioms adaptive144Third140Proof466

theorem adaptive144Third140Proof605 : runCachedNode 511 130381 Adaptive144Third140Node605 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130381 Adaptive144Third140Node605 = [91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 120, 121, 122, 125, 126, 130] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive144Third140Proof606
  · exact adaptive144Third140Proof607
  · exact adaptive144Third140Proof608
  · exact adaptive144Third140Proof609
  · exact adaptive144Third140Proof610
  · exact adaptive144Third140Proof611
  · exact adaptive144Third140Proof612
  · exact adaptive144Third140Proof613
  · exact adaptive144Third140Proof614
  · exact adaptive144Third140Proof615
  · exact adaptive144Third140Proof616
  · exact adaptive144Third140Proof617
  · exact adaptive144Third140Proof618
  · exact adaptive144Third140Proof619
  · exact adaptive144Third140Proof620
  · exact adaptive144Third140Proof621
  · exact adaptive144Third140Proof622
  · exact adaptive144Third140Proof623
  · exact adaptive144Third140Proof624
  · exact adaptive144Third140Proof625
  · exact adaptive144Third140Proof626
  · exact adaptive144Third140Proof627
  · exact adaptive144Third140Proof628
  · exact adaptive144Third140Proof629
  · exact adaptive144Third140Proof630
  · exact adaptive144Third140Proof631
  · exact adaptive144Third140Proof632
  · exact adaptive144Third140Proof633
  · exact adaptive144Third140Proof634
  · exact adaptive144Third140Proof635
  · exact adaptive144Third140Proof636
  · exact adaptive144Third140Proof637
  · exact adaptive144Third140Proof638
  · exact adaptive144Third140Proof639

#print axioms adaptive144Third140Proof605

theorem adaptive144Third140Proof641 : runCachedNode 511 130381 Adaptive144Third140Node641 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130381 Adaptive144Third140Node641 = [90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 122, 123, 124, 127, 128, 132] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive144Third140Proof642
  · exact adaptive144Third140Proof643
  · exact adaptive144Third140Proof644
  · exact adaptive144Third140Proof645
  · exact adaptive144Third140Proof646
  · exact adaptive144Third140Proof647
  · exact adaptive144Third140Proof648
  · exact adaptive144Third140Proof649
  · exact adaptive144Third140Proof650
  · exact adaptive144Third140Proof651
  · exact adaptive144Third140Proof652
  · exact adaptive144Third140Proof653
  · exact adaptive144Third140Proof654
  · exact adaptive144Third140Proof655
  · exact adaptive144Third140Proof656
  · exact adaptive144Third140Proof657
  · exact adaptive144Third140Proof658
  · exact adaptive144Third140Proof659
  · exact adaptive144Third140Proof660
  · exact adaptive144Third140Proof661
  · exact adaptive144Third140Proof662
  · exact adaptive144Third140Proof663
  · exact adaptive144Third140Proof664
  · exact adaptive144Third140Proof665
  · exact adaptive144Third140Proof666
  · exact adaptive144Third140Proof667
  · exact adaptive144Third140Proof668
  · exact adaptive144Third140Proof669
  · exact adaptive144Third140Proof670
  · exact adaptive144Third140Proof671
  · exact adaptive144Third140Proof672
  · exact adaptive144Third140Proof673
  · exact adaptive144Third140Proof674
  · exact adaptive144Third140Proof675
  · exact adaptive144Third140Proof676
  · exact adaptive144Third140Proof677
  · exact adaptive144Third140Proof678

#print axioms adaptive144Third140Proof641

theorem adaptive144Third140Proof680 : runCachedNode 511 130381 Adaptive144Third140Node680 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130381 Adaptive144Third140Node680 = [88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 126, 127, 128, 132] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive144Third140Proof681
  · exact adaptive144Third140Proof682
  · exact adaptive144Third140Proof683
  · exact adaptive144Third140Proof684
  · exact adaptive144Third140Proof685
  · exact adaptive144Third140Proof686
  · exact adaptive144Third140Proof687
  · exact adaptive144Third140Proof688
  · exact adaptive144Third140Proof689
  · exact adaptive144Third140Proof690
  · exact adaptive144Third140Proof691
  · exact adaptive144Third140Proof692
  · exact adaptive144Third140Proof693
  · exact adaptive144Third140Proof694
  · exact adaptive144Third140Proof695
  · exact adaptive144Third140Proof696
  · exact adaptive144Third140Proof697
  · exact adaptive144Third140Proof698
  · exact adaptive144Third140Proof699
  · exact adaptive144Third140Proof700
  · exact adaptive144Third140Proof701
  · exact adaptive144Third140Proof702
  · exact adaptive144Third140Proof703
  · exact adaptive144Third140Proof704
  · exact adaptive144Third140Proof705
  · exact adaptive144Third140Proof706
  · exact adaptive144Third140Proof707
  · exact adaptive144Third140Proof708
  · exact adaptive144Third140Proof709
  · exact adaptive144Third140Proof710
  · exact adaptive144Third140Proof711
  · exact adaptive144Third140Proof712
  · exact adaptive144Third140Proof713
  · exact adaptive144Third140Proof714
  · exact adaptive144Third140Proof715
  · exact adaptive144Third140Proof716
  · exact adaptive144Third140Proof717
  · exact adaptive144Third140Proof718
  · exact adaptive144Third140Proof719
  · exact adaptive144Third140Proof720
  · exact adaptive144Third140Proof721

#print axioms adaptive144Third140Proof680

theorem adaptive144Third140Proof574 : runCachedNode 511 130381 Adaptive144Third140Node574 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130381 Adaptive144Third140Node574 = [101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 132, 133, 134, 137, 138] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive144Third140Proof575
  · exact adaptive144Third140Proof576
  · exact adaptive144Third140Proof577
  · exact adaptive144Third140Proof578
  · exact adaptive144Third140Proof579
  · exact adaptive144Third140Proof580
  · exact adaptive144Third140Proof581
  · exact adaptive144Third140Proof582
  · exact adaptive144Third140Proof583
  · exact adaptive144Third140Proof584
  · exact adaptive144Third140Proof585
  · exact adaptive144Third140Proof586
  · exact adaptive144Third140Proof587
  · exact adaptive144Third140Proof588
  · exact adaptive144Third140Proof589
  · exact adaptive144Third140Proof590
  · exact adaptive144Third140Proof591
  · exact adaptive144Third140Proof592
  · exact adaptive144Third140Proof593
  · exact adaptive144Third140Proof594
  · exact adaptive144Third140Proof595
  · exact adaptive144Third140Proof596
  · exact adaptive144Third140Proof597
  · exact adaptive144Third140Proof598
  · exact adaptive144Third140Proof599
  · exact adaptive144Third140Proof600
  · exact adaptive144Third140Proof601
  · exact adaptive144Third140Proof602
  · exact adaptive144Third140Proof603
  · exact adaptive144Third140Proof604
  · exact adaptive144Third140Proof605
  · exact adaptive144Third140Proof640
  · exact adaptive144Third140Proof641
  · exact adaptive144Third140Proof679
  · exact adaptive144Third140Proof680

#print axioms adaptive144Third140Proof574

theorem adaptive144Third140Proof0 : runCachedNode 511 130381 Adaptive144Third140Node0 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130381 Adaptive144Third140Node0 = [110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 132, 133, 134, 135, 137, 138, 139] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive144Third140Proof1
  · exact adaptive144Third140Proof2
  · exact adaptive144Third140Proof3
  · exact adaptive144Third140Proof4
  · exact adaptive144Third140Proof5
  · exact adaptive144Third140Proof6
  · exact adaptive144Third140Proof7
  · exact adaptive144Third140Proof8
  · exact adaptive144Third140Proof9
  · exact adaptive144Third140Proof10
  · exact adaptive144Third140Proof11
  · exact adaptive144Third140Proof12
  · exact adaptive144Third140Proof13
  · exact adaptive144Third140Proof14
  · exact adaptive144Third140Proof15
  · exact adaptive144Third140Proof16
  · exact adaptive144Third140Proof17
  · exact adaptive144Third140Proof18
  · exact adaptive144Third140Proof19
  · exact adaptive144Third140Proof42
  · exact adaptive144Third140Proof66
  · exact adaptive144Third140Proof91
  · exact adaptive144Third140Proof118
  · exact adaptive144Third140Proof175
  · exact adaptive144Third140Proof236
  · exact adaptive144Third140Proof299
  · exact adaptive144Third140Proof364
  · exact adaptive144Third140Proof466
  · exact adaptive144Third140Proof574

#print axioms adaptive144Third140Proof0

end NineSeparatedSubsetSums
