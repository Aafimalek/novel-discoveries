import NineSeparatedSubsetSums.Adaptive144Third140State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof528 : runCachedNode 511 130381 Adaptive144Third140Node528 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof528

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof488 : runCachedNode 511 130381 Adaptive144Third140Node488 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof488

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof677 : runCachedNode 511 130381 Adaptive144Third140Node677 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof677

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof572 : runCachedNode 511 130381 Adaptive144Third140Node572 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof572

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof111 : runCachedNode 511 130381 Adaptive144Third140Node111 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof111

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof234 : runCachedNode 511 130381 Adaptive144Third140Node234 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof234

end NineSeparatedSubsetSums
