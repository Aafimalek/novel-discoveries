import NineSeparatedSubsetSums.Adaptive144Third141State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third141Proof349 : runCachedNode 511 130584 Adaptive144Third141Node349 = false := by
  decide +kernel

#print axioms adaptive144Third141Proof349

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third141Proof19 : runCachedNode 511 130584 Adaptive144Third141Node19 = false := by
  decide +kernel

#print axioms adaptive144Third141Proof19

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third141Proof5 : runCachedNode 511 130584 Adaptive144Third141Node5 = false := by
  decide +kernel

#print axioms adaptive144Third141Proof5

end NineSeparatedSubsetSums
