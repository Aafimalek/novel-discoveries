import NineSeparatedSubsetSums.Adaptive144Third117State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third117Proof0 : runCachedNode 511 125665 Adaptive144Third117Node0 = false := by
  decide +kernel

#print axioms adaptive144Third117Proof0

end NineSeparatedSubsetSums
