import NineSeparatedSubsetSums.Adaptive144Third137State
import NineSeparatedSubsetSums.Adaptive144Third137Leaves6
import NineSeparatedSubsetSums.Adaptive144Third137Leaves10
import NineSeparatedSubsetSums.Adaptive144Third137Leaves14
import NineSeparatedSubsetSums.Adaptive144Third137Leaves3
import NineSeparatedSubsetSums.Adaptive144Third137Leaves13
import NineSeparatedSubsetSums.Adaptive144Third137Leaves12
import NineSeparatedSubsetSums.Adaptive144Third137Leaves11
import NineSeparatedSubsetSums.Adaptive144Third137Leaves8
import NineSeparatedSubsetSums.Adaptive144Third137Leaves7
import NineSeparatedSubsetSums.Adaptive144Third137Leaves15
import NineSeparatedSubsetSums.Adaptive144Third137Leaves9
import NineSeparatedSubsetSums.Adaptive144Third137Leaves5
import NineSeparatedSubsetSums.Adaptive144Third137Leaves4
import NineSeparatedSubsetSums.Adaptive144Third137Leaves2
import NineSeparatedSubsetSums.Adaptive144Third137Leaves0
import NineSeparatedSubsetSums.Adaptive144Third137Leaves1

namespace NineSeparatedSubsetSums

theorem adaptive144Third137Proof21 : runCachedNode 511 129993 Adaptive144Third137Node21 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 129993 Adaptive144Third137Node21 = [104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 120, 121, 122, 124, 125, 127, 128, 129] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive144Third137Proof22
  · exact adaptive144Third137Proof23
  · exact adaptive144Third137Proof24
  · exact adaptive144Third137Proof25
  · exact adaptive144Third137Proof26
  · exact adaptive144Third137Proof27
  · exact adaptive144Third137Proof28
  · exact adaptive144Third137Proof29
  · exact adaptive144Third137Proof30
  · exact adaptive144Third137Proof31
  · exact adaptive144Third137Proof32
  · exact adaptive144Third137Proof33
  · exact adaptive144Third137Proof34
  · exact adaptive144Third137Proof35
  · exact adaptive144Third137Proof36
  · exact adaptive144Third137Proof37
  · exact adaptive144Third137Proof38
  · exact adaptive144Third137Proof39
  · exact adaptive144Third137Proof40
  · exact adaptive144Third137Proof41
  · exact adaptive144Third137Proof42
  · exact adaptive144Third137Proof43
  · exact adaptive144Third137Proof44

#print axioms adaptive144Third137Proof21

theorem adaptive144Third137Proof45 : runCachedNode 511 129993 Adaptive144Third137Node45 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 129993 Adaptive144Third137Node45 = [104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 121, 122, 123, 125, 126, 128, 129, 130] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive144Third137Proof46
  · exact adaptive144Third137Proof47
  · exact adaptive144Third137Proof48
  · exact adaptive144Third137Proof49
  · exact adaptive144Third137Proof50
  · exact adaptive144Third137Proof51
  · exact adaptive144Third137Proof52
  · exact adaptive144Third137Proof53
  · exact adaptive144Third137Proof54
  · exact adaptive144Third137Proof55
  · exact adaptive144Third137Proof56
  · exact adaptive144Third137Proof57
  · exact adaptive144Third137Proof58
  · exact adaptive144Third137Proof59
  · exact adaptive144Third137Proof60
  · exact adaptive144Third137Proof61
  · exact adaptive144Third137Proof62
  · exact adaptive144Third137Proof63
  · exact adaptive144Third137Proof64
  · exact adaptive144Third137Proof65
  · exact adaptive144Third137Proof66
  · exact adaptive144Third137Proof67
  · exact adaptive144Third137Proof68
  · exact adaptive144Third137Proof69

#print axioms adaptive144Third137Proof45

theorem adaptive144Third137Proof70 : runCachedNode 511 129993 Adaptive144Third137Node70 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 129993 Adaptive144Third137Node70 = [104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 122, 123, 124, 126, 127, 129, 130, 131] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive144Third137Proof71
  · exact adaptive144Third137Proof72
  · exact adaptive144Third137Proof73
  · exact adaptive144Third137Proof74
  · exact adaptive144Third137Proof75
  · exact adaptive144Third137Proof76
  · exact adaptive144Third137Proof77
  · exact adaptive144Third137Proof78
  · exact adaptive144Third137Proof79
  · exact adaptive144Third137Proof80
  · exact adaptive144Third137Proof81
  · exact adaptive144Third137Proof82
  · exact adaptive144Third137Proof83
  · exact adaptive144Third137Proof84
  · exact adaptive144Third137Proof85
  · exact adaptive144Third137Proof86
  · exact adaptive144Third137Proof87
  · exact adaptive144Third137Proof88
  · exact adaptive144Third137Proof89
  · exact adaptive144Third137Proof90
  · exact adaptive144Third137Proof91
  · exact adaptive144Third137Proof92
  · exact adaptive144Third137Proof93
  · exact adaptive144Third137Proof94
  · exact adaptive144Third137Proof95

#print axioms adaptive144Third137Proof70

theorem adaptive144Third137Proof96 : runCachedNode 511 129993 Adaptive144Third137Node96 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 129993 Adaptive144Third137Node96 = [103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 124, 125, 126, 128, 129, 131, 132] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive144Third137Proof97
  · exact adaptive144Third137Proof98
  · exact adaptive144Third137Proof99
  · exact adaptive144Third137Proof100
  · exact adaptive144Third137Proof101
  · exact adaptive144Third137Proof102
  · exact adaptive144Third137Proof103
  · exact adaptive144Third137Proof104
  · exact adaptive144Third137Proof105
  · exact adaptive144Third137Proof106
  · exact adaptive144Third137Proof107
  · exact adaptive144Third137Proof108
  · exact adaptive144Third137Proof109
  · exact adaptive144Third137Proof110
  · exact adaptive144Third137Proof111
  · exact adaptive144Third137Proof112
  · exact adaptive144Third137Proof113
  · exact adaptive144Third137Proof114
  · exact adaptive144Third137Proof115
  · exact adaptive144Third137Proof116
  · exact adaptive144Third137Proof117
  · exact adaptive144Third137Proof118
  · exact adaptive144Third137Proof119
  · exact adaptive144Third137Proof120
  · exact adaptive144Third137Proof121
  · exact adaptive144Third137Proof122
  · exact adaptive144Third137Proof123

#print axioms adaptive144Third137Proof96

theorem adaptive144Third137Proof124 : runCachedNode 511 129993 Adaptive144Third137Node124 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 129993 Adaptive144Third137Node124 = [103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 125, 126, 127, 129, 130, 132, 134] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive144Third137Proof125
  · exact adaptive144Third137Proof126
  · exact adaptive144Third137Proof127
  · exact adaptive144Third137Proof128
  · exact adaptive144Third137Proof129
  · exact adaptive144Third137Proof130
  · exact adaptive144Third137Proof131
  · exact adaptive144Third137Proof132
  · exact adaptive144Third137Proof133
  · exact adaptive144Third137Proof134
  · exact adaptive144Third137Proof135
  · exact adaptive144Third137Proof136
  · exact adaptive144Third137Proof137
  · exact adaptive144Third137Proof138
  · exact adaptive144Third137Proof139
  · exact adaptive144Third137Proof140
  · exact adaptive144Third137Proof141
  · exact adaptive144Third137Proof142
  · exact adaptive144Third137Proof143
  · exact adaptive144Third137Proof144
  · exact adaptive144Third137Proof145
  · exact adaptive144Third137Proof146
  · exact adaptive144Third137Proof147
  · exact adaptive144Third137Proof148
  · exact adaptive144Third137Proof149
  · exact adaptive144Third137Proof150
  · exact adaptive144Third137Proof151
  · exact adaptive144Third137Proof152

#print axioms adaptive144Third137Proof124

theorem adaptive144Third137Proof153 : runCachedNode 511 129993 Adaptive144Third137Node153 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 129993 Adaptive144Third137Node153 = [103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 126, 127, 128, 130, 131, 134, 135] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive144Third137Proof154
  · exact adaptive144Third137Proof155
  · exact adaptive144Third137Proof156
  · exact adaptive144Third137Proof157
  · exact adaptive144Third137Proof158
  · exact adaptive144Third137Proof159
  · exact adaptive144Third137Proof160
  · exact adaptive144Third137Proof161
  · exact adaptive144Third137Proof162
  · exact adaptive144Third137Proof163
  · exact adaptive144Third137Proof164
  · exact adaptive144Third137Proof165
  · exact adaptive144Third137Proof166
  · exact adaptive144Third137Proof167
  · exact adaptive144Third137Proof168
  · exact adaptive144Third137Proof169
  · exact adaptive144Third137Proof170
  · exact adaptive144Third137Proof171
  · exact adaptive144Third137Proof172
  · exact adaptive144Third137Proof173
  · exact adaptive144Third137Proof174
  · exact adaptive144Third137Proof175
  · exact adaptive144Third137Proof176
  · exact adaptive144Third137Proof177
  · exact adaptive144Third137Proof178
  · exact adaptive144Third137Proof179
  · exact adaptive144Third137Proof180
  · exact adaptive144Third137Proof181
  · exact adaptive144Third137Proof182

#print axioms adaptive144Third137Proof153

theorem adaptive144Third137Proof0 : runCachedNode 511 129993 Adaptive144Third137Node0 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 129993 Adaptive144Third137Node0 = [110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 132, 134, 135, 136] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive144Third137Proof1
  · exact adaptive144Third137Proof2
  · exact adaptive144Third137Proof3
  · exact adaptive144Third137Proof4
  · exact adaptive144Third137Proof5
  · exact adaptive144Third137Proof6
  · exact adaptive144Third137Proof7
  · exact adaptive144Third137Proof8
  · exact adaptive144Third137Proof9
  · exact adaptive144Third137Proof10
  · exact adaptive144Third137Proof11
  · exact adaptive144Third137Proof12
  · exact adaptive144Third137Proof13
  · exact adaptive144Third137Proof14
  · exact adaptive144Third137Proof15
  · exact adaptive144Third137Proof16
  · exact adaptive144Third137Proof17
  · exact adaptive144Third137Proof18
  · exact adaptive144Third137Proof19
  · exact adaptive144Third137Proof20
  · exact adaptive144Third137Proof21
  · exact adaptive144Third137Proof45
  · exact adaptive144Third137Proof70
  · exact adaptive144Third137Proof96
  · exact adaptive144Third137Proof124
  · exact adaptive144Third137Proof153

#print axioms adaptive144Third137Proof0

end NineSeparatedSubsetSums
