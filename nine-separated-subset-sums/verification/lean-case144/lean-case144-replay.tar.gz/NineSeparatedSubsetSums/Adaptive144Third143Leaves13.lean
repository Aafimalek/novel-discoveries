import NineSeparatedSubsetSums.Adaptive144Third143State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third143Proof572 : runCachedNode 511 130885 Adaptive144Third143Node572 = false := by
  decide +kernel

#print axioms adaptive144Third143Proof572

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third143Proof663 : runCachedNode 511 130885 Adaptive144Third143Node663 = false := by
  decide +kernel

#print axioms adaptive144Third143Proof663

end NineSeparatedSubsetSums
