import NineSeparatedSubsetSums.Adaptive144Third143State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third143Proof297 : runCachedNode 511 130885 Adaptive144Third143Node297 = false := by
  decide +kernel

#print axioms adaptive144Third143Proof297

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third143Proof75 : runCachedNode 511 130885 Adaptive144Third143Node75 = false := by
  decide +kernel

#print axioms adaptive144Third143Proof75

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third143Proof103 : runCachedNode 511 130885 Adaptive144Third143Node103 = false := by
  decide +kernel

#print axioms adaptive144Third143Proof103

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third143Proof14 : runCachedNode 511 130885 Adaptive144Third143Node14 = false := by
  decide +kernel

#print axioms adaptive144Third143Proof14

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third143Proof367 : runCachedNode 511 130885 Adaptive144Third143Node367 = false := by
  decide +kernel

#print axioms adaptive144Third143Proof367

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third143Proof291 : runCachedNode 511 130885 Adaptive144Third143Node291 = false := by
  decide +kernel

#print axioms adaptive144Third143Proof291

end NineSeparatedSubsetSums
