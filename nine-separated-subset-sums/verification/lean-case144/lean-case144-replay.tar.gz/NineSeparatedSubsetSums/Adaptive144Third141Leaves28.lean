import NineSeparatedSubsetSums.Adaptive144Third141State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third141Proof97 : runCachedNode 511 130584 Adaptive144Third141Node97 = false := by
  decide +kernel

#print axioms adaptive144Third141Proof97

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third141Proof132 : runCachedNode 511 130584 Adaptive144Third141Node132 = false := by
  decide +kernel

#print axioms adaptive144Third141Proof132

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third141Proof346 : runCachedNode 511 130584 Adaptive144Third141Node346 = false := by
  decide +kernel

#print axioms adaptive144Third141Proof346

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third141Proof343 : runCachedNode 511 130584 Adaptive144Third141Node343 = false := by
  decide +kernel

#print axioms adaptive144Third141Proof343

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third141Proof98 : runCachedNode 511 130584 Adaptive144Third141Node98 = false := by
  decide +kernel

#print axioms adaptive144Third141Proof98

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third141Proof99 : runCachedNode 511 130584 Adaptive144Third141Node99 = false := by
  decide +kernel

#print axioms adaptive144Third141Proof99

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third141Proof46 : runCachedNode 511 130584 Adaptive144Third141Node46 = false := by
  decide +kernel

#print axioms adaptive144Third141Proof46

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third141Proof193 : runCachedNode 511 130584 Adaptive144Third141Node193 = false := by
  decide +kernel

#print axioms adaptive144Third141Proof193

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third141Proof185 : runCachedNode 511 130584 Adaptive144Third141Node185 = false := by
  decide +kernel

#print axioms adaptive144Third141Proof185

end NineSeparatedSubsetSums
