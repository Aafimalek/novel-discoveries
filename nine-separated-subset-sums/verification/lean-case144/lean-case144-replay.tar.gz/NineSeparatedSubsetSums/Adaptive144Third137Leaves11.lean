import NineSeparatedSubsetSums.Adaptive144Third137State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third137Proof146 : runCachedNode 511 129993 Adaptive144Third137Node146 = false := by
  decide +kernel

#print axioms adaptive144Third137Proof146

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third137Proof11 : runCachedNode 511 129993 Adaptive144Third137Node11 = false := by
  decide +kernel

#print axioms adaptive144Third137Proof11

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third137Proof116 : runCachedNode 511 129993 Adaptive144Third137Node116 = false := by
  decide +kernel

#print axioms adaptive144Third137Proof116

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third137Proof40 : runCachedNode 511 129993 Adaptive144Third137Node40 = false := by
  decide +kernel

#print axioms adaptive144Third137Proof40

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third137Proof114 : runCachedNode 511 129993 Adaptive144Third137Node114 = false := by
  decide +kernel

#print axioms adaptive144Third137Proof114

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third137Proof10 : runCachedNode 511 129993 Adaptive144Third137Node10 = false := by
  decide +kernel

#print axioms adaptive144Third137Proof10

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third137Proof145 : runCachedNode 511 129993 Adaptive144Third137Node145 = false := by
  decide +kernel

#print axioms adaptive144Third137Proof145

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third137Proof63 : runCachedNode 511 129993 Adaptive144Third137Node63 = false := by
  decide +kernel

#print axioms adaptive144Third137Proof63

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third137Proof38 : runCachedNode 511 129993 Adaptive144Third137Node38 = false := by
  decide +kernel

#print axioms adaptive144Third137Proof38

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third137Proof89 : runCachedNode 511 129993 Adaptive144Third137Node89 = false := by
  decide +kernel

#print axioms adaptive144Third137Proof89

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third137Proof173 : runCachedNode 511 129993 Adaptive144Third137Node173 = false := by
  decide +kernel

#print axioms adaptive144Third137Proof173

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third137Proof143 : runCachedNode 511 129993 Adaptive144Third137Node143 = false := by
  decide +kernel

#print axioms adaptive144Third137Proof143

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third137Proof177 : runCachedNode 511 129993 Adaptive144Third137Node177 = false := by
  decide +kernel

#print axioms adaptive144Third137Proof177

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third137Proof142 : runCachedNode 511 129993 Adaptive144Third137Node142 = false := by
  decide +kernel

#print axioms adaptive144Third137Proof142

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third137Proof172 : runCachedNode 511 129993 Adaptive144Third137Node172 = false := by
  decide +kernel

#print axioms adaptive144Third137Proof172

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third137Proof59 : runCachedNode 511 129993 Adaptive144Third137Node59 = false := by
  decide +kernel

#print axioms adaptive144Third137Proof59

end NineSeparatedSubsetSums
