import NineSeparatedSubsetSums.Adaptive144Third140State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof389 : runCachedNode 511 130381 Adaptive144Third140Node389 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof389

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof325 : runCachedNode 511 130381 Adaptive144Third140Node325 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof325

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof393 : runCachedNode 511 130381 Adaptive144Third140Node393 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof393

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof72 : runCachedNode 511 130381 Adaptive144Third140Node72 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof72

end NineSeparatedSubsetSums
