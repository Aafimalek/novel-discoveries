import NineSeparatedSubsetSums.Adaptive144Third139State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third139Proof153 : runCachedNode 511 130274 Adaptive144Third139Node153 = false := by
  decide +kernel

#print axioms adaptive144Third139Proof153

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third139Proof182 : runCachedNode 511 130274 Adaptive144Third139Node182 = false := by
  decide +kernel

#print axioms adaptive144Third139Proof182

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third139Proof1 : runCachedNode 511 130274 Adaptive144Third139Node1 = false := by
  decide +kernel

#print axioms adaptive144Third139Proof1

end NineSeparatedSubsetSums
