import NineSeparatedSubsetSums.Adaptive144Third143State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third143Proof368 : runCachedNode 511 130885 Adaptive144Third143Node368 = false := by
  decide +kernel

#print axioms adaptive144Third143Proof368

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third143Proof491 : runCachedNode 511 130885 Adaptive144Third143Node491 = false := by
  decide +kernel

#print axioms adaptive144Third143Proof491

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third143Proof6 : runCachedNode 511 130885 Adaptive144Third143Node6 = false := by
  decide +kernel

#print axioms adaptive144Third143Proof6

end NineSeparatedSubsetSums
