import NineSeparatedSubsetSums.Adaptive144Third143State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third143Proof662 : runCachedNode 511 130885 Adaptive144Third143Node662 = false := by
  decide +kernel

#print axioms adaptive144Third143Proof662

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third143Proof229 : runCachedNode 511 130885 Adaptive144Third143Node229 = false := by
  decide +kernel

#print axioms adaptive144Third143Proof229

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third143Proof13 : runCachedNode 511 130885 Adaptive144Third143Node13 = false := by
  decide +kernel

#print axioms adaptive144Third143Proof13

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third143Proof4 : runCachedNode 511 130885 Adaptive144Third143Node4 = false := by
  decide +kernel

#print axioms adaptive144Third143Proof4

end NineSeparatedSubsetSums
