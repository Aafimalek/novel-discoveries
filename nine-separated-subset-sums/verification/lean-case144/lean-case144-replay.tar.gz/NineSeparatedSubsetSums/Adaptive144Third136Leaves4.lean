import NineSeparatedSubsetSums.Adaptive144Third136State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third136Proof74 : runCachedNode 511 129800 Adaptive144Third136Node74 = false := by
  decide +kernel

#print axioms adaptive144Third136Proof74

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third136Proof106 : runCachedNode 511 129800 Adaptive144Third136Node106 = false := by
  decide +kernel

#print axioms adaptive144Third136Proof106

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third136Proof12 : runCachedNode 511 129800 Adaptive144Third136Node12 = false := by
  decide +kernel

#print axioms adaptive144Third136Proof12

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third136Proof5 : runCachedNode 511 129800 Adaptive144Third136Node5 = false := by
  decide +kernel

#print axioms adaptive144Third136Proof5

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third136Proof25 : runCachedNode 511 129800 Adaptive144Third136Node25 = false := by
  decide +kernel

#print axioms adaptive144Third136Proof25

end NineSeparatedSubsetSums
