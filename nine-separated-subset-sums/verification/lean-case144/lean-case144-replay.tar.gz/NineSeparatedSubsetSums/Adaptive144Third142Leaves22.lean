import NineSeparatedSubsetSums.Adaptive144Third142State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third142Proof410 : runCachedNode 511 130737 Adaptive144Third142Node410 = false := by
  decide +kernel

#print axioms adaptive144Third142Proof410

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third142Proof16 : runCachedNode 511 130737 Adaptive144Third142Node16 = false := by
  decide +kernel

#print axioms adaptive144Third142Proof16

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third142Proof261 : runCachedNode 511 130737 Adaptive144Third142Node261 = false := by
  decide +kernel

#print axioms adaptive144Third142Proof261

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third142Proof262 : runCachedNode 511 130737 Adaptive144Third142Node262 = false := by
  decide +kernel

#print axioms adaptive144Third142Proof262

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third142Proof116 : runCachedNode 511 130737 Adaptive144Third142Node116 = false := by
  decide +kernel

#print axioms adaptive144Third142Proof116

end NineSeparatedSubsetSums
