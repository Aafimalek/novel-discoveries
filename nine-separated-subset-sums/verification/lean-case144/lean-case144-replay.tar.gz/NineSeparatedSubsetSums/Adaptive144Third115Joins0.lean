import NineSeparatedSubsetSums.Adaptive144Third115State
import NineSeparatedSubsetSums.Adaptive144Third115Leaves1
import NineSeparatedSubsetSums.Adaptive144Third115Leaves0

namespace NineSeparatedSubsetSums

theorem adaptive144Third115Proof0 : runCachedNode 511 112221 Adaptive144Third115Node0 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 112221 Adaptive144Third115Node0 = [100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 112, 113, 114] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive144Third115Proof1
  · exact adaptive144Third115Proof2
  · exact adaptive144Third115Proof3
  · exact adaptive144Third115Proof4
  · exact adaptive144Third115Proof5
  · exact adaptive144Third115Proof6
  · exact adaptive144Third115Proof7
  · exact adaptive144Third115Proof8
  · exact adaptive144Third115Proof9
  · exact adaptive144Third115Proof10
  · exact adaptive144Third115Proof11
  · exact adaptive144Third115Proof12
  · exact adaptive144Third115Proof13
  · exact adaptive144Third115Proof14

#print axioms adaptive144Third115Proof0

end NineSeparatedSubsetSums
