import NineSeparatedSubsetSums.Adaptive144Third140State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof392 : runCachedNode 511 130381 Adaptive144Third140Node392 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof392

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof40 : runCachedNode 511 130381 Adaptive144Third140Node40 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof40

end NineSeparatedSubsetSums
