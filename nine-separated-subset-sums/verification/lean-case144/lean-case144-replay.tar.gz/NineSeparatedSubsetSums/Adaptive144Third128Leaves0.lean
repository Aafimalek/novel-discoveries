import NineSeparatedSubsetSums.Adaptive144Third128State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third128Proof17 : runCachedNode 511 128276 Adaptive144Third128Node17 = false := by
  decide +kernel

#print axioms adaptive144Third128Proof17

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third128Proof16 : runCachedNode 511 128276 Adaptive144Third128Node16 = false := by
  decide +kernel

#print axioms adaptive144Third128Proof16

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third128Proof15 : runCachedNode 511 128276 Adaptive144Third128Node15 = false := by
  decide +kernel

#print axioms adaptive144Third128Proof15

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third128Proof14 : runCachedNode 511 128276 Adaptive144Third128Node14 = false := by
  decide +kernel

#print axioms adaptive144Third128Proof14

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third128Proof7 : runCachedNode 511 128276 Adaptive144Third128Node7 = false := by
  decide +kernel

#print axioms adaptive144Third128Proof7

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third128Proof4 : runCachedNode 511 128276 Adaptive144Third128Node4 = false := by
  decide +kernel

#print axioms adaptive144Third128Proof4

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third128Proof1 : runCachedNode 511 128276 Adaptive144Third128Node1 = false := by
  decide +kernel

#print axioms adaptive144Third128Proof1

end NineSeparatedSubsetSums
