import NineSeparatedSubsetSums.Adaptive144Third134State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third134Proof19 : runCachedNode 511 129525 Adaptive144Third134Node19 = false := by
  decide +kernel

#print axioms adaptive144Third134Proof19

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third134Proof16 : runCachedNode 511 129525 Adaptive144Third134Node16 = false := by
  decide +kernel

#print axioms adaptive144Third134Proof16

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third134Proof11 : runCachedNode 511 129525 Adaptive144Third134Node11 = false := by
  decide +kernel

#print axioms adaptive144Third134Proof11

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third134Proof52 : runCachedNode 511 129525 Adaptive144Third134Node52 = false := by
  decide +kernel

#print axioms adaptive144Third134Proof52

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third134Proof48 : runCachedNode 511 129525 Adaptive144Third134Node48 = false := by
  decide +kernel

#print axioms adaptive144Third134Proof48

end NineSeparatedSubsetSums
