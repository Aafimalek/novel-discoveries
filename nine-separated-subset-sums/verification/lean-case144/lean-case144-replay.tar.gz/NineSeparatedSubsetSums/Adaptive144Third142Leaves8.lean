import NineSeparatedSubsetSums.Adaptive144Third142State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third142Proof21 : runCachedNode 511 130737 Adaptive144Third142Node21 = false := by
  decide +kernel

#print axioms adaptive144Third142Proof21

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third142Proof661 : runCachedNode 511 130737 Adaptive144Third142Node661 = false := by
  decide +kernel

#print axioms adaptive144Third142Proof661

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third142Proof6 : runCachedNode 511 130737 Adaptive144Third142Node6 = false := by
  decide +kernel

#print axioms adaptive144Third142Proof6

end NineSeparatedSubsetSums
