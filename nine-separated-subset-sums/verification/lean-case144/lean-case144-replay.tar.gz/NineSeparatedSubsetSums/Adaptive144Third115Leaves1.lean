import NineSeparatedSubsetSums.Adaptive144Third115State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third115Proof10 : runCachedNode 511 112221 Adaptive144Third115Node10 = false := by
  decide +kernel

#print axioms adaptive144Third115Proof10

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third115Proof9 : runCachedNode 511 112221 Adaptive144Third115Node9 = false := by
  decide +kernel

#print axioms adaptive144Third115Proof9

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third115Proof7 : runCachedNode 511 112221 Adaptive144Third115Node7 = false := by
  decide +kernel

#print axioms adaptive144Third115Proof7

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third115Proof6 : runCachedNode 511 112221 Adaptive144Third115Node6 = false := by
  decide +kernel

#print axioms adaptive144Third115Proof6

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third115Proof5 : runCachedNode 511 112221 Adaptive144Third115Node5 = false := by
  decide +kernel

#print axioms adaptive144Third115Proof5

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third115Proof4 : runCachedNode 511 112221 Adaptive144Third115Node4 = false := by
  decide +kernel

#print axioms adaptive144Third115Proof4

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third115Proof3 : runCachedNode 511 112221 Adaptive144Third115Node3 = false := by
  decide +kernel

#print axioms adaptive144Third115Proof3

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third115Proof1 : runCachedNode 511 112221 Adaptive144Third115Node1 = false := by
  decide +kernel

#print axioms adaptive144Third115Proof1

end NineSeparatedSubsetSums
