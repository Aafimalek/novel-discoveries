import NineSeparatedSubsetSums.Adaptive144Third140State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof143 : runCachedNode 511 130381 Adaptive144Third140Node143 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof143

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof640 : runCachedNode 511 130381 Adaptive144Third140Node640 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof640

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof70 : runCachedNode 511 130381 Adaptive144Third140Node70 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof70

end NineSeparatedSubsetSums
