import NineSeparatedSubsetSums.Adaptive144Third142State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third142Proof171 : runCachedNode 511 130737 Adaptive144Third142Node171 = false := by
  decide +kernel

#print axioms adaptive144Third142Proof171

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third142Proof20 : runCachedNode 511 130737 Adaptive144Third142Node20 = false := by
  decide +kernel

#print axioms adaptive144Third142Proof20

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third142Proof85 : runCachedNode 511 130737 Adaptive144Third142Node85 = false := by
  decide +kernel

#print axioms adaptive144Third142Proof85

end NineSeparatedSubsetSums
