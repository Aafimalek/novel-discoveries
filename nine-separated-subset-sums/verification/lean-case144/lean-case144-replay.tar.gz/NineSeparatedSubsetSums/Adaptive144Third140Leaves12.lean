import NineSeparatedSubsetSums.Adaptive144Third140State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof261 : runCachedNode 511 130381 Adaptive144Third140Node261 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof261

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof140 : runCachedNode 511 130381 Adaptive144Third140Node140 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof140

end NineSeparatedSubsetSums
