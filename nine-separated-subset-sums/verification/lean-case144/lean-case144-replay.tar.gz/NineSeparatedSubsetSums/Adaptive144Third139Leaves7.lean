import NineSeparatedSubsetSums.Adaptive144Third139State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third139Proof19 : runCachedNode 511 130274 Adaptive144Third139Node19 = false := by
  decide +kernel

#print axioms adaptive144Third139Proof19

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third139Proof184 : runCachedNode 511 130274 Adaptive144Third139Node184 = false := by
  decide +kernel

#print axioms adaptive144Third139Proof184

end NineSeparatedSubsetSums
