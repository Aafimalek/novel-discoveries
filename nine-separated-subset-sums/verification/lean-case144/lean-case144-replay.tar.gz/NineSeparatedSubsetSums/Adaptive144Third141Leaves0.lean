import NineSeparatedSubsetSums.Adaptive144Third141State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third141Proof22 : runCachedNode 511 130584 Adaptive144Third141Node22 = false := by
  decide +kernel

#print axioms adaptive144Third141Proof22

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third141Proof36 : runCachedNode 511 130584 Adaptive144Third141Node36 = false := by
  decide +kernel

#print axioms adaptive144Third141Proof36

end NineSeparatedSubsetSums
