import NineSeparatedSubsetSums.Adaptive144Third143State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third143Proof260 : runCachedNode 511 130885 Adaptive144Third143Node260 = false := by
  decide +kernel

#print axioms adaptive144Third143Proof260

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third143Proof570 : runCachedNode 511 130885 Adaptive144Third143Node570 = false := by
  decide +kernel

#print axioms adaptive144Third143Proof570

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third143Proof70 : runCachedNode 511 130885 Adaptive144Third143Node70 = false := by
  decide +kernel

#print axioms adaptive144Third143Proof70

end NineSeparatedSubsetSums
