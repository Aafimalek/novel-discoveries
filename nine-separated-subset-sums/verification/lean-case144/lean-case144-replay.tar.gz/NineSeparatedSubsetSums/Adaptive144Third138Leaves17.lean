import NineSeparatedSubsetSums.Adaptive144Third138State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third138Proof85 : runCachedNode 511 130126 Adaptive144Third138Node85 = false := by
  decide +kernel

#print axioms adaptive144Third138Proof85

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third138Proof83 : runCachedNode 511 130126 Adaptive144Third138Node83 = false := by
  decide +kernel

#print axioms adaptive144Third138Proof83

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third138Proof145 : runCachedNode 511 130126 Adaptive144Third138Node145 = false := by
  decide +kernel

#print axioms adaptive144Third138Proof145

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third138Proof203 : runCachedNode 511 130126 Adaptive144Third138Node203 = false := by
  decide +kernel

#print axioms adaptive144Third138Proof203

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third138Proof34 : runCachedNode 511 130126 Adaptive144Third138Node34 = false := by
  decide +kernel

#print axioms adaptive144Third138Proof34

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third138Proof37 : runCachedNode 511 130126 Adaptive144Third138Node37 = false := by
  decide +kernel

#print axioms adaptive144Third138Proof37

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third138Proof8 : runCachedNode 511 130126 Adaptive144Third138Node8 = false := by
  decide +kernel

#print axioms adaptive144Third138Proof8

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third138Proof84 : runCachedNode 511 130126 Adaptive144Third138Node84 = false := by
  decide +kernel

#print axioms adaptive144Third138Proof84

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third138Proof169 : runCachedNode 511 130126 Adaptive144Third138Node169 = false := by
  decide +kernel

#print axioms adaptive144Third138Proof169

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third138Proof62 : runCachedNode 511 130126 Adaptive144Third138Node62 = false := by
  decide +kernel

#print axioms adaptive144Third138Proof62

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third138Proof115 : runCachedNode 511 130126 Adaptive144Third138Node115 = false := by
  decide +kernel

#print axioms adaptive144Third138Proof115

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third138Proof142 : runCachedNode 511 130126 Adaptive144Third138Node142 = false := by
  decide +kernel

#print axioms adaptive144Third138Proof142

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third138Proof168 : runCachedNode 511 130126 Adaptive144Third138Node168 = false := by
  decide +kernel

#print axioms adaptive144Third138Proof168

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third138Proof63 : runCachedNode 511 130126 Adaptive144Third138Node63 = false := by
  decide +kernel

#print axioms adaptive144Third138Proof63

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third138Proof113 : runCachedNode 511 130126 Adaptive144Third138Node113 = false := by
  decide +kernel

#print axioms adaptive144Third138Proof113

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third138Proof61 : runCachedNode 511 130126 Adaptive144Third138Node61 = false := by
  decide +kernel

#print axioms adaptive144Third138Proof61

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third138Proof112 : runCachedNode 511 130126 Adaptive144Third138Node112 = false := by
  decide +kernel

#print axioms adaptive144Third138Proof112

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third138Proof141 : runCachedNode 511 130126 Adaptive144Third138Node141 = false := by
  decide +kernel

#print axioms adaptive144Third138Proof141

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third138Proof35 : runCachedNode 511 130126 Adaptive144Third138Node35 = false := by
  decide +kernel

#print axioms adaptive144Third138Proof35

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third138Proof140 : runCachedNode 511 130126 Adaptive144Third138Node140 = false := by
  decide +kernel

#print axioms adaptive144Third138Proof140

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third138Proof114 : runCachedNode 511 130126 Adaptive144Third138Node114 = false := by
  decide +kernel

#print axioms adaptive144Third138Proof114

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third138Proof202 : runCachedNode 511 130126 Adaptive144Third138Node202 = false := by
  decide +kernel

#print axioms adaptive144Third138Proof202

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third138Proof201 : runCachedNode 511 130126 Adaptive144Third138Node201 = false := by
  decide +kernel

#print axioms adaptive144Third138Proof201

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third138Proof167 : runCachedNode 511 130126 Adaptive144Third138Node167 = false := by
  decide +kernel

#print axioms adaptive144Third138Proof167

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third138Proof199 : runCachedNode 511 130126 Adaptive144Third138Node199 = false := by
  decide +kernel

#print axioms adaptive144Third138Proof199

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third138Proof200 : runCachedNode 511 130126 Adaptive144Third138Node200 = false := by
  decide +kernel

#print axioms adaptive144Third138Proof200

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third138Proof166 : runCachedNode 511 130126 Adaptive144Third138Node166 = false := by
  decide +kernel

#print axioms adaptive144Third138Proof166

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third138Proof7 : runCachedNode 511 130126 Adaptive144Third138Node7 = false := by
  decide +kernel

#print axioms adaptive144Third138Proof7

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third138Proof32 : runCachedNode 511 130126 Adaptive144Third138Node32 = false := by
  decide +kernel

#print axioms adaptive144Third138Proof32

end NineSeparatedSubsetSums
