import NineSeparatedSubsetSums.Adaptive144Third143State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third143Proof258 : runCachedNode 511 130885 Adaptive144Third143Node258 = false := by
  decide +kernel

#print axioms adaptive144Third143Proof258

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third143Proof571 : runCachedNode 511 130885 Adaptive144Third143Node571 = false := by
  decide +kernel

#print axioms adaptive144Third143Proof571

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third143Proof146 : runCachedNode 511 130885 Adaptive144Third143Node146 = false := by
  decide +kernel

#print axioms adaptive144Third143Proof146

end NineSeparatedSubsetSums
