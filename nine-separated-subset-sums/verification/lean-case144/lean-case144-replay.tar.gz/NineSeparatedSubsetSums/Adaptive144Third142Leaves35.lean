import NineSeparatedSubsetSums.Adaptive144Third142State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third142Proof324 : runCachedNode 511 130737 Adaptive144Third142Node324 = false := by
  decide +kernel

#print axioms adaptive144Third142Proof324

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third142Proof47 : runCachedNode 511 130737 Adaptive144Third142Node47 = false := by
  decide +kernel

#print axioms adaptive144Third142Proof47

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third142Proof371 : runCachedNode 511 130737 Adaptive144Third142Node371 = false := by
  decide +kernel

#print axioms adaptive144Third142Proof371

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third142Proof161 : runCachedNode 511 130737 Adaptive144Third142Node161 = false := by
  decide +kernel

#print axioms adaptive144Third142Proof161

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third142Proof300 : runCachedNode 511 130737 Adaptive144Third142Node300 = false := by
  decide +kernel

#print axioms adaptive144Third142Proof300

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third142Proof606 : runCachedNode 511 130737 Adaptive144Third142Node606 = false := by
  decide +kernel

#print axioms adaptive144Third142Proof606

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third142Proof573 : runCachedNode 511 130737 Adaptive144Third142Node573 = false := by
  decide +kernel

#print axioms adaptive144Third142Proof573

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third142Proof530 : runCachedNode 511 130737 Adaptive144Third142Node530 = false := by
  decide +kernel

#print axioms adaptive144Third142Proof530

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third142Proof132 : runCachedNode 511 130737 Adaptive144Third142Node132 = false := by
  decide +kernel

#print axioms adaptive144Third142Proof132

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third142Proof57 : runCachedNode 511 130737 Adaptive144Third142Node57 = false := by
  decide +kernel

#print axioms adaptive144Third142Proof57

end NineSeparatedSubsetSums
