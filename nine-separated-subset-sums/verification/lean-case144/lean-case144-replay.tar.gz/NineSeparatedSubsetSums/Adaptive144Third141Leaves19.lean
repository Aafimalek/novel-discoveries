import NineSeparatedSubsetSums.Adaptive144Third141State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third141Proof104 : runCachedNode 511 130584 Adaptive144Third141Node104 = false := by
  decide +kernel

#print axioms adaptive144Third141Proof104

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third141Proof306 : runCachedNode 511 130584 Adaptive144Third141Node306 = false := by
  decide +kernel

#print axioms adaptive144Third141Proof306

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third141Proof101 : runCachedNode 511 130584 Adaptive144Third141Node101 = false := by
  decide +kernel

#print axioms adaptive144Third141Proof101

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third141Proof72 : runCachedNode 511 130584 Adaptive144Third141Node72 = false := by
  decide +kernel

#print axioms adaptive144Third141Proof72

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third141Proof4 : runCachedNode 511 130584 Adaptive144Third141Node4 = false := by
  decide +kernel

#print axioms adaptive144Third141Proof4

end NineSeparatedSubsetSums
