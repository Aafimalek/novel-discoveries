import NineSeparatedSubsetSums.Adaptive144Third143State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third143Proof299 : runCachedNode 511 130885 Adaptive144Third143Node299 = false := by
  decide +kernel

#print axioms adaptive144Third143Proof299

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third143Proof222 : runCachedNode 511 130885 Adaptive144Third143Node222 = false := by
  decide +kernel

#print axioms adaptive144Third143Proof222

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third143Proof1 : runCachedNode 511 130885 Adaptive144Third143Node1 = false := by
  decide +kernel

#print axioms adaptive144Third143Proof1

end NineSeparatedSubsetSums
