import NineSeparatedSubsetSums.Adaptive144Third136State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third136Proof71 : runCachedNode 511 129800 Adaptive144Third136Node71 = false := by
  decide +kernel

#print axioms adaptive144Third136Proof71

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third136Proof13 : runCachedNode 511 129800 Adaptive144Third136Node13 = false := by
  decide +kernel

#print axioms adaptive144Third136Proof13

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third136Proof49 : runCachedNode 511 129800 Adaptive144Third136Node49 = false := by
  decide +kernel

#print axioms adaptive144Third136Proof49

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third136Proof45 : runCachedNode 511 129800 Adaptive144Third136Node45 = false := by
  decide +kernel

#print axioms adaptive144Third136Proof45

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third136Proof99 : runCachedNode 511 129800 Adaptive144Third136Node99 = false := by
  decide +kernel

#print axioms adaptive144Third136Proof99

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third136Proof73 : runCachedNode 511 129800 Adaptive144Third136Node73 = false := by
  decide +kernel

#print axioms adaptive144Third136Proof73

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third136Proof44 : runCachedNode 511 129800 Adaptive144Third136Node44 = false := by
  decide +kernel

#print axioms adaptive144Third136Proof44

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third136Proof72 : runCachedNode 511 129800 Adaptive144Third136Node72 = false := by
  decide +kernel

#print axioms adaptive144Third136Proof72

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third136Proof42 : runCachedNode 511 129800 Adaptive144Third136Node42 = false := by
  decide +kernel

#print axioms adaptive144Third136Proof42

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third136Proof98 : runCachedNode 511 129800 Adaptive144Third136Node98 = false := by
  decide +kernel

#print axioms adaptive144Third136Proof98

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third136Proof10 : runCachedNode 511 129800 Adaptive144Third136Node10 = false := by
  decide +kernel

#print axioms adaptive144Third136Proof10

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third136Proof34 : runCachedNode 511 129800 Adaptive144Third136Node34 = false := by
  decide +kernel

#print axioms adaptive144Third136Proof34

end NineSeparatedSubsetSums
