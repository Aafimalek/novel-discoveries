import NineSeparatedSubsetSums.Adaptive144Third129State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third129Proof18 : runCachedNode 511 128455 Adaptive144Third129Node18 = false := by
  decide +kernel

#print axioms adaptive144Third129Proof18

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third129Proof17 : runCachedNode 511 128455 Adaptive144Third129Node17 = false := by
  decide +kernel

#print axioms adaptive144Third129Proof17

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third129Proof16 : runCachedNode 511 128455 Adaptive144Third129Node16 = false := by
  decide +kernel

#print axioms adaptive144Third129Proof16

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third129Proof4 : runCachedNode 511 128455 Adaptive144Third129Node4 = false := by
  decide +kernel

#print axioms adaptive144Third129Proof4

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third129Proof2 : runCachedNode 511 128455 Adaptive144Third129Node2 = false := by
  decide +kernel

#print axioms adaptive144Third129Proof2

end NineSeparatedSubsetSums
