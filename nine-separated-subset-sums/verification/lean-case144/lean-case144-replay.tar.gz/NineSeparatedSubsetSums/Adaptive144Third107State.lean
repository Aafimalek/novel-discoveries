import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive144Third107Node0 : CachedSearchNode :=
  ⟨4, 106, computeCenteredMask [148,144,107], 399, 54089⟩

end NineSeparatedSubsetSums
