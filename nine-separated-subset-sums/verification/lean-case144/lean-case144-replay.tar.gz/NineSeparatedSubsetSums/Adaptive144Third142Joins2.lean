import NineSeparatedSubsetSums.Adaptive144Third142State
import NineSeparatedSubsetSums.Adaptive144Third142Leaves55
import NineSeparatedSubsetSums.Adaptive144Third142Leaves54
import NineSeparatedSubsetSums.Adaptive144Third142Leaves52
import NineSeparatedSubsetSums.Adaptive144Third142Leaves51
import NineSeparatedSubsetSums.Adaptive144Third142Leaves50
import NineSeparatedSubsetSums.Adaptive144Third142Leaves49
import NineSeparatedSubsetSums.Adaptive144Third142Leaves48
import NineSeparatedSubsetSums.Adaptive144Third142Leaves47
import NineSeparatedSubsetSums.Adaptive144Third142Leaves45
import NineSeparatedSubsetSums.Adaptive144Third142Leaves44
import NineSeparatedSubsetSums.Adaptive144Third142Leaves43
import NineSeparatedSubsetSums.Adaptive144Third142Leaves41
import NineSeparatedSubsetSums.Adaptive144Third142Leaves42
import NineSeparatedSubsetSums.Adaptive144Third142Leaves40
import NineSeparatedSubsetSums.Adaptive144Third142Leaves39
import NineSeparatedSubsetSums.Adaptive144Third142Leaves38
import NineSeparatedSubsetSums.Adaptive144Third142Leaves36
import NineSeparatedSubsetSums.Adaptive144Third142Leaves37
import NineSeparatedSubsetSums.Adaptive144Third142Leaves33
import NineSeparatedSubsetSums.Adaptive144Third142Leaves29
import NineSeparatedSubsetSums.Adaptive144Third142Leaves25
import NineSeparatedSubsetSums.Adaptive144Third142Leaves23
import NineSeparatedSubsetSums.Adaptive144Third142Leaves16
import NineSeparatedSubsetSums.Adaptive144Third142Leaves8
import NineSeparatedSubsetSums.Adaptive144Third142Leaves10
import NineSeparatedSubsetSums.Adaptive144Third142Leaves53
import NineSeparatedSubsetSums.Adaptive144Third142Leaves46
import NineSeparatedSubsetSums.Adaptive144Third142Leaves35
import NineSeparatedSubsetSums.Adaptive144Third142Leaves30
import NineSeparatedSubsetSums.Adaptive144Third142Leaves32
import NineSeparatedSubsetSums.Adaptive144Third142Leaves27
import NineSeparatedSubsetSums.Adaptive144Third142Leaves28
import NineSeparatedSubsetSums.Adaptive144Third142Leaves18
import NineSeparatedSubsetSums.Adaptive144Third142Leaves20
import NineSeparatedSubsetSums.Adaptive144Third142Leaves9
import NineSeparatedSubsetSums.Adaptive144Third142Leaves2
import NineSeparatedSubsetSums.Adaptive144Third142Leaves6
import NineSeparatedSubsetSums.Adaptive144Third142Leaves34
import NineSeparatedSubsetSums.Adaptive144Third142Leaves31
import NineSeparatedSubsetSums.Adaptive144Third142Leaves4
import NineSeparatedSubsetSums.Adaptive144Third142Leaves22
import NineSeparatedSubsetSums.Adaptive144Third142Leaves14
import NineSeparatedSubsetSums.Adaptive144Third142Leaves11
import NineSeparatedSubsetSums.Adaptive144Third142Leaves0
import NineSeparatedSubsetSums.Adaptive144Third142Joins0
import NineSeparatedSubsetSums.Adaptive144Third142Joins1

namespace NineSeparatedSubsetSums

theorem adaptive144Third142Proof616 : runCachedNode 511 130737 Adaptive144Third142Node616 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130737 Adaptive144Third142Node616 = [86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 132] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive144Third142Proof617
  · exact adaptive144Third142Proof618
  · exact adaptive144Third142Proof619
  · exact adaptive144Third142Proof620
  · exact adaptive144Third142Proof621
  · exact adaptive144Third142Proof622
  · exact adaptive144Third142Proof623
  · exact adaptive144Third142Proof624
  · exact adaptive144Third142Proof625
  · exact adaptive144Third142Proof626
  · exact adaptive144Third142Proof627
  · exact adaptive144Third142Proof628
  · exact adaptive144Third142Proof629
  · exact adaptive144Third142Proof630
  · exact adaptive144Third142Proof631
  · exact adaptive144Third142Proof632
  · exact adaptive144Third142Proof633
  · exact adaptive144Third142Proof634
  · exact adaptive144Third142Proof635
  · exact adaptive144Third142Proof636
  · exact adaptive144Third142Proof637
  · exact adaptive144Third142Proof638
  · exact adaptive144Third142Proof639
  · exact adaptive144Third142Proof640
  · exact adaptive144Third142Proof641
  · exact adaptive144Third142Proof642
  · exact adaptive144Third142Proof643
  · exact adaptive144Third142Proof644
  · exact adaptive144Third142Proof645
  · exact adaptive144Third142Proof646
  · exact adaptive144Third142Proof647
  · exact adaptive144Third142Proof648
  · exact adaptive144Third142Proof649
  · exact adaptive144Third142Proof650
  · exact adaptive144Third142Proof651
  · exact adaptive144Third142Proof652
  · exact adaptive144Third142Proof653
  · exact adaptive144Third142Proof654
  · exact adaptive144Third142Proof655
  · exact adaptive144Third142Proof656
  · exact adaptive144Third142Proof657
  · exact adaptive144Third142Proof658
  · exact adaptive144Third142Proof659
  · exact adaptive144Third142Proof660
  · exact adaptive144Third142Proof661
  · exact adaptive144Third142Proof662

#print axioms adaptive144Third142Proof616

theorem adaptive144Third142Proof580 : runCachedNode 511 130737 Adaptive144Third142Node580 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130737 Adaptive144Third142Node580 = [101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 132, 133, 134, 136, 140] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive144Third142Proof581
  · exact adaptive144Third142Proof582
  · exact adaptive144Third142Proof583
  · exact adaptive144Third142Proof584
  · exact adaptive144Third142Proof585
  · exact adaptive144Third142Proof586
  · exact adaptive144Third142Proof587
  · exact adaptive144Third142Proof588
  · exact adaptive144Third142Proof589
  · exact adaptive144Third142Proof590
  · exact adaptive144Third142Proof591
  · exact adaptive144Third142Proof592
  · exact adaptive144Third142Proof593
  · exact adaptive144Third142Proof594
  · exact adaptive144Third142Proof595
  · exact adaptive144Third142Proof596
  · exact adaptive144Third142Proof597
  · exact adaptive144Third142Proof598
  · exact adaptive144Third142Proof599
  · exact adaptive144Third142Proof600
  · exact adaptive144Third142Proof601
  · exact adaptive144Third142Proof602
  · exact adaptive144Third142Proof603
  · exact adaptive144Third142Proof604
  · exact adaptive144Third142Proof605
  · exact adaptive144Third142Proof606
  · exact adaptive144Third142Proof607
  · exact adaptive144Third142Proof608
  · exact adaptive144Third142Proof609
  · exact adaptive144Third142Proof610
  · exact adaptive144Third142Proof611
  · exact adaptive144Third142Proof612
  · exact adaptive144Third142Proof613
  · exact adaptive144Third142Proof614
  · exact adaptive144Third142Proof615
  · exact adaptive144Third142Proof616

#print axioms adaptive144Third142Proof580

theorem adaptive144Third142Proof0 : runCachedNode 511 130737 Adaptive144Third142Node0 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130737 Adaptive144Third142Node0 = [109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 132, 133, 134, 135, 136, 137, 139, 140, 141] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive144Third142Proof1
  · exact adaptive144Third142Proof2
  · exact adaptive144Third142Proof3
  · exact adaptive144Third142Proof4
  · exact adaptive144Third142Proof5
  · exact adaptive144Third142Proof6
  · exact adaptive144Third142Proof7
  · exact adaptive144Third142Proof8
  · exact adaptive144Third142Proof9
  · exact adaptive144Third142Proof10
  · exact adaptive144Third142Proof11
  · exact adaptive144Third142Proof12
  · exact adaptive144Third142Proof13
  · exact adaptive144Third142Proof14
  · exact adaptive144Third142Proof15
  · exact adaptive144Third142Proof16
  · exact adaptive144Third142Proof17
  · exact adaptive144Third142Proof18
  · exact adaptive144Third142Proof19
  · exact adaptive144Third142Proof20
  · exact adaptive144Third142Proof21
  · exact adaptive144Third142Proof22
  · exact adaptive144Third142Proof23
  · exact adaptive144Third142Proof24
  · exact adaptive144Third142Proof51
  · exact adaptive144Third142Proof79
  · exact adaptive144Third142Proof109
  · exact adaptive144Third142Proof140
  · exact adaptive144Third142Proof172
  · exact adaptive144Third142Proof205
  · exact adaptive144Third142Proof240
  · exact adaptive144Third142Proof580

#print axioms adaptive144Third142Proof0

end NineSeparatedSubsetSums
