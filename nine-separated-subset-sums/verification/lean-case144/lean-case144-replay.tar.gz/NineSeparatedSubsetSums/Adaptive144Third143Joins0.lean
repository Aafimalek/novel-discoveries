import NineSeparatedSubsetSums.Adaptive144Third143State
import NineSeparatedSubsetSums.Adaptive144Third143Leaves18
import NineSeparatedSubsetSums.Adaptive144Third143Leaves54
import NineSeparatedSubsetSums.Adaptive144Third143Leaves21
import NineSeparatedSubsetSums.Adaptive144Third143Leaves25
import NineSeparatedSubsetSums.Adaptive144Third143Leaves5
import NineSeparatedSubsetSums.Adaptive144Third143Leaves51
import NineSeparatedSubsetSums.Adaptive144Third143Leaves50
import NineSeparatedSubsetSums.Adaptive144Third143Leaves4
import NineSeparatedSubsetSums.Adaptive144Third143Leaves49
import NineSeparatedSubsetSums.Adaptive144Third143Leaves48
import NineSeparatedSubsetSums.Adaptive144Third143Leaves46
import NineSeparatedSubsetSums.Adaptive144Third143Leaves44
import NineSeparatedSubsetSums.Adaptive144Third143Leaves14
import NineSeparatedSubsetSums.Adaptive144Third143Leaves39
import NineSeparatedSubsetSums.Adaptive144Third143Leaves43
import NineSeparatedSubsetSums.Adaptive144Third143Leaves27
import NineSeparatedSubsetSums.Adaptive144Third143Leaves32
import NineSeparatedSubsetSums.Adaptive144Third143Leaves35
import NineSeparatedSubsetSums.Adaptive144Third143Leaves20
import NineSeparatedSubsetSums.Adaptive144Third143Leaves53
import NineSeparatedSubsetSums.Adaptive144Third143Leaves10
import NineSeparatedSubsetSums.Adaptive144Third143Leaves12
import NineSeparatedSubsetSums.Adaptive144Third143Leaves22
import NineSeparatedSubsetSums.Adaptive144Third143Leaves45
import NineSeparatedSubsetSums.Adaptive144Third143Leaves42
import NineSeparatedSubsetSums.Adaptive144Third143Leaves41
import NineSeparatedSubsetSums.Adaptive144Third143Leaves15
import NineSeparatedSubsetSums.Adaptive144Third143Leaves36
import NineSeparatedSubsetSums.Adaptive144Third143Leaves40
import NineSeparatedSubsetSums.Adaptive144Third143Leaves30
import NineSeparatedSubsetSums.Adaptive144Third143Leaves28
import NineSeparatedSubsetSums.Adaptive144Third143Leaves29
import NineSeparatedSubsetSums.Adaptive144Third143Leaves52
import NineSeparatedSubsetSums.Adaptive144Third143Leaves11
import NineSeparatedSubsetSums.Adaptive144Third143Leaves19
import NineSeparatedSubsetSums.Adaptive144Third143Leaves47
import NineSeparatedSubsetSums.Adaptive144Third143Leaves31
import NineSeparatedSubsetSums.Adaptive144Third143Leaves37
import NineSeparatedSubsetSums.Adaptive144Third143Leaves38
import NineSeparatedSubsetSums.Adaptive144Third143Leaves9
import NineSeparatedSubsetSums.Adaptive144Third143Leaves23
import NineSeparatedSubsetSums.Adaptive144Third143Leaves26
import NineSeparatedSubsetSums.Adaptive144Third143Leaves3
import NineSeparatedSubsetSums.Adaptive144Third143Leaves34
import NineSeparatedSubsetSums.Adaptive144Third143Leaves8
import NineSeparatedSubsetSums.Adaptive144Third143Leaves0
import NineSeparatedSubsetSums.Adaptive144Third143Leaves33
import NineSeparatedSubsetSums.Adaptive144Third143Leaves16
import NineSeparatedSubsetSums.Adaptive144Third143Leaves6
import NineSeparatedSubsetSums.Adaptive144Third143Leaves24
import NineSeparatedSubsetSums.Adaptive144Third143Leaves2
import NineSeparatedSubsetSums.Adaptive144Third143Leaves17
import NineSeparatedSubsetSums.Adaptive144Third143Leaves55

namespace NineSeparatedSubsetSums

theorem adaptive144Third143Proof23 : runCachedNode 511 130885 Adaptive144Third143Node23 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130885 Adaptive144Third143Node23 = [103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 128, 129] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive144Third143Proof24
  · exact adaptive144Third143Proof25
  · exact adaptive144Third143Proof26
  · exact adaptive144Third143Proof27
  · exact adaptive144Third143Proof28
  · exact adaptive144Third143Proof29
  · exact adaptive144Third143Proof30
  · exact adaptive144Third143Proof31
  · exact adaptive144Third143Proof32
  · exact adaptive144Third143Proof33
  · exact adaptive144Third143Proof34
  · exact adaptive144Third143Proof35
  · exact adaptive144Third143Proof36
  · exact adaptive144Third143Proof37
  · exact adaptive144Third143Proof38
  · exact adaptive144Third143Proof39
  · exact adaptive144Third143Proof40
  · exact adaptive144Third143Proof41
  · exact adaptive144Third143Proof42
  · exact adaptive144Third143Proof43
  · exact adaptive144Third143Proof44
  · exact adaptive144Third143Proof45
  · exact adaptive144Third143Proof46
  · exact adaptive144Third143Proof47
  · exact adaptive144Third143Proof48

#print axioms adaptive144Third143Proof23

theorem adaptive144Third143Proof49 : runCachedNode 511 130885 Adaptive144Third143Node49 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130885 Adaptive144Third143Node49 = [103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 129, 130] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive144Third143Proof50
  · exact adaptive144Third143Proof51
  · exact adaptive144Third143Proof52
  · exact adaptive144Third143Proof53
  · exact adaptive144Third143Proof54
  · exact adaptive144Third143Proof55
  · exact adaptive144Third143Proof56
  · exact adaptive144Third143Proof57
  · exact adaptive144Third143Proof58
  · exact adaptive144Third143Proof59
  · exact adaptive144Third143Proof60
  · exact adaptive144Third143Proof61
  · exact adaptive144Third143Proof62
  · exact adaptive144Third143Proof63
  · exact adaptive144Third143Proof64
  · exact adaptive144Third143Proof65
  · exact adaptive144Third143Proof66
  · exact adaptive144Third143Proof67
  · exact adaptive144Third143Proof68
  · exact adaptive144Third143Proof69
  · exact adaptive144Third143Proof70
  · exact adaptive144Third143Proof71
  · exact adaptive144Third143Proof72
  · exact adaptive144Third143Proof73
  · exact adaptive144Third143Proof74
  · exact adaptive144Third143Proof75

#print axioms adaptive144Third143Proof49

theorem adaptive144Third143Proof76 : runCachedNode 511 130885 Adaptive144Third143Node76 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130885 Adaptive144Third143Node76 = [103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 130, 131] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive144Third143Proof77
  · exact adaptive144Third143Proof78
  · exact adaptive144Third143Proof79
  · exact adaptive144Third143Proof80
  · exact adaptive144Third143Proof81
  · exact adaptive144Third143Proof82
  · exact adaptive144Third143Proof83
  · exact adaptive144Third143Proof84
  · exact adaptive144Third143Proof85
  · exact adaptive144Third143Proof86
  · exact adaptive144Third143Proof87
  · exact adaptive144Third143Proof88
  · exact adaptive144Third143Proof89
  · exact adaptive144Third143Proof90
  · exact adaptive144Third143Proof91
  · exact adaptive144Third143Proof92
  · exact adaptive144Third143Proof93
  · exact adaptive144Third143Proof94
  · exact adaptive144Third143Proof95
  · exact adaptive144Third143Proof96
  · exact adaptive144Third143Proof97
  · exact adaptive144Third143Proof98
  · exact adaptive144Third143Proof99
  · exact adaptive144Third143Proof100
  · exact adaptive144Third143Proof101
  · exact adaptive144Third143Proof102
  · exact adaptive144Third143Proof103

#print axioms adaptive144Third143Proof76

theorem adaptive144Third143Proof104 : runCachedNode 511 130885 Adaptive144Third143Node104 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130885 Adaptive144Third143Node104 = [102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 131, 132] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive144Third143Proof105
  · exact adaptive144Third143Proof106
  · exact adaptive144Third143Proof107
  · exact adaptive144Third143Proof108
  · exact adaptive144Third143Proof109
  · exact adaptive144Third143Proof110
  · exact adaptive144Third143Proof111
  · exact adaptive144Third143Proof112
  · exact adaptive144Third143Proof113
  · exact adaptive144Third143Proof114
  · exact adaptive144Third143Proof115
  · exact adaptive144Third143Proof116
  · exact adaptive144Third143Proof117
  · exact adaptive144Third143Proof118
  · exact adaptive144Third143Proof119
  · exact adaptive144Third143Proof120
  · exact adaptive144Third143Proof121
  · exact adaptive144Third143Proof122
  · exact adaptive144Third143Proof123
  · exact adaptive144Third143Proof124
  · exact adaptive144Third143Proof125
  · exact adaptive144Third143Proof126
  · exact adaptive144Third143Proof127
  · exact adaptive144Third143Proof128
  · exact adaptive144Third143Proof129
  · exact adaptive144Third143Proof130
  · exact adaptive144Third143Proof131
  · exact adaptive144Third143Proof132
  · exact adaptive144Third143Proof133

#print axioms adaptive144Third143Proof104

theorem adaptive144Third143Proof134 : runCachedNode 511 130885 Adaptive144Third143Node134 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130885 Adaptive144Third143Node134 = [102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 132, 133] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive144Third143Proof135
  · exact adaptive144Third143Proof136
  · exact adaptive144Third143Proof137
  · exact adaptive144Third143Proof138
  · exact adaptive144Third143Proof139
  · exact adaptive144Third143Proof140
  · exact adaptive144Third143Proof141
  · exact adaptive144Third143Proof142
  · exact adaptive144Third143Proof143
  · exact adaptive144Third143Proof144
  · exact adaptive144Third143Proof145
  · exact adaptive144Third143Proof146
  · exact adaptive144Third143Proof147
  · exact adaptive144Third143Proof148
  · exact adaptive144Third143Proof149
  · exact adaptive144Third143Proof150
  · exact adaptive144Third143Proof151
  · exact adaptive144Third143Proof152
  · exact adaptive144Third143Proof153
  · exact adaptive144Third143Proof154
  · exact adaptive144Third143Proof155
  · exact adaptive144Third143Proof156
  · exact adaptive144Third143Proof157
  · exact adaptive144Third143Proof158
  · exact adaptive144Third143Proof159
  · exact adaptive144Third143Proof160
  · exact adaptive144Third143Proof161
  · exact adaptive144Third143Proof162
  · exact adaptive144Third143Proof163
  · exact adaptive144Third143Proof164

#print axioms adaptive144Third143Proof134

theorem adaptive144Third143Proof165 : runCachedNode 511 130885 Adaptive144Third143Node165 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130885 Adaptive144Third143Node165 = [102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 133, 134] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive144Third143Proof166
  · exact adaptive144Third143Proof167
  · exact adaptive144Third143Proof168
  · exact adaptive144Third143Proof169
  · exact adaptive144Third143Proof170
  · exact adaptive144Third143Proof171
  · exact adaptive144Third143Proof172
  · exact adaptive144Third143Proof173
  · exact adaptive144Third143Proof174
  · exact adaptive144Third143Proof175
  · exact adaptive144Third143Proof176
  · exact adaptive144Third143Proof177
  · exact adaptive144Third143Proof178
  · exact adaptive144Third143Proof179
  · exact adaptive144Third143Proof180
  · exact adaptive144Third143Proof181
  · exact adaptive144Third143Proof182
  · exact adaptive144Third143Proof183
  · exact adaptive144Third143Proof184
  · exact adaptive144Third143Proof185
  · exact adaptive144Third143Proof186
  · exact adaptive144Third143Proof187
  · exact adaptive144Third143Proof188
  · exact adaptive144Third143Proof189
  · exact adaptive144Third143Proof190
  · exact adaptive144Third143Proof191
  · exact adaptive144Third143Proof192
  · exact adaptive144Third143Proof193
  · exact adaptive144Third143Proof194
  · exact adaptive144Third143Proof195
  · exact adaptive144Third143Proof196

#print axioms adaptive144Third143Proof165

theorem adaptive144Third143Proof197 : runCachedNode 511 130885 Adaptive144Third143Node197 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130885 Adaptive144Third143Node197 = [102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 134, 135] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive144Third143Proof198
  · exact adaptive144Third143Proof199
  · exact adaptive144Third143Proof200
  · exact adaptive144Third143Proof201
  · exact adaptive144Third143Proof202
  · exact adaptive144Third143Proof203
  · exact adaptive144Third143Proof204
  · exact adaptive144Third143Proof205
  · exact adaptive144Third143Proof206
  · exact adaptive144Third143Proof207
  · exact adaptive144Third143Proof208
  · exact adaptive144Third143Proof209
  · exact adaptive144Third143Proof210
  · exact adaptive144Third143Proof211
  · exact adaptive144Third143Proof212
  · exact adaptive144Third143Proof213
  · exact adaptive144Third143Proof214
  · exact adaptive144Third143Proof215
  · exact adaptive144Third143Proof216
  · exact adaptive144Third143Proof217
  · exact adaptive144Third143Proof218
  · exact adaptive144Third143Proof219
  · exact adaptive144Third143Proof220
  · exact adaptive144Third143Proof221
  · exact adaptive144Third143Proof222
  · exact adaptive144Third143Proof223
  · exact adaptive144Third143Proof224
  · exact adaptive144Third143Proof225
  · exact adaptive144Third143Proof226
  · exact adaptive144Third143Proof227
  · exact adaptive144Third143Proof228
  · exact adaptive144Third143Proof229

#print axioms adaptive144Third143Proof197

theorem adaptive144Third143Proof262 : runCachedNode 511 130885 Adaptive144Third143Node262 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130885 Adaptive144Third143Node262 = [90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 124, 125, 129, 130] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive144Third143Proof263
  · exact adaptive144Third143Proof264
  · exact adaptive144Third143Proof265
  · exact adaptive144Third143Proof266
  · exact adaptive144Third143Proof267
  · exact adaptive144Third143Proof268
  · exact adaptive144Third143Proof269
  · exact adaptive144Third143Proof270
  · exact adaptive144Third143Proof271
  · exact adaptive144Third143Proof272
  · exact adaptive144Third143Proof273
  · exact adaptive144Third143Proof274
  · exact adaptive144Third143Proof275
  · exact adaptive144Third143Proof276
  · exact adaptive144Third143Proof277
  · exact adaptive144Third143Proof278
  · exact adaptive144Third143Proof279
  · exact adaptive144Third143Proof280
  · exact adaptive144Third143Proof281
  · exact adaptive144Third143Proof282
  · exact adaptive144Third143Proof283
  · exact adaptive144Third143Proof284
  · exact adaptive144Third143Proof285
  · exact adaptive144Third143Proof286
  · exact adaptive144Third143Proof287
  · exact adaptive144Third143Proof288
  · exact adaptive144Third143Proof289
  · exact adaptive144Third143Proof290
  · exact adaptive144Third143Proof291
  · exact adaptive144Third143Proof292
  · exact adaptive144Third143Proof293
  · exact adaptive144Third143Proof294
  · exact adaptive144Third143Proof295
  · exact adaptive144Third143Proof296
  · exact adaptive144Third143Proof297

#print axioms adaptive144Third143Proof262

end NineSeparatedSubsetSums
