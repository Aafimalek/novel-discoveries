import NineSeparatedSubsetSums.Adaptive144Third143State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third143Proof20 : runCachedNode 511 130885 Adaptive144Third143Node20 = false := by
  decide +kernel

#print axioms adaptive144Third143Proof20

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third143Proof455 : runCachedNode 511 130885 Adaptive144Third143Node455 = false := by
  decide +kernel

#print axioms adaptive144Third143Proof455

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third143Proof109 : runCachedNode 511 130885 Adaptive144Third143Node109 = false := by
  decide +kernel

#print axioms adaptive144Third143Proof109

end NineSeparatedSubsetSums
