import NineSeparatedSubsetSums.Adaptive144Third140State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof679 : runCachedNode 511 130381 Adaptive144Third140Node679 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof679

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof424 : runCachedNode 511 130381 Adaptive144Third140Node424 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof424

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof329 : runCachedNode 511 130381 Adaptive144Third140Node329 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof329

end NineSeparatedSubsetSums
