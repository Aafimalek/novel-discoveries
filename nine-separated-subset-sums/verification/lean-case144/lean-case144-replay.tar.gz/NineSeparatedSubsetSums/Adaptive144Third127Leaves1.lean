import NineSeparatedSubsetSums.Adaptive144Third127State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third127Proof11 : runCachedNode 511 128058 Adaptive144Third127Node11 = false := by
  decide +kernel

#print axioms adaptive144Third127Proof11

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third127Proof9 : runCachedNode 511 128058 Adaptive144Third127Node9 = false := by
  decide +kernel

#print axioms adaptive144Third127Proof9

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third127Proof8 : runCachedNode 511 128058 Adaptive144Third127Node8 = false := by
  decide +kernel

#print axioms adaptive144Third127Proof8

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third127Proof7 : runCachedNode 511 128058 Adaptive144Third127Node7 = false := by
  decide +kernel

#print axioms adaptive144Third127Proof7

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third127Proof5 : runCachedNode 511 128058 Adaptive144Third127Node5 = false := by
  decide +kernel

#print axioms adaptive144Third127Proof5

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third127Proof4 : runCachedNode 511 128058 Adaptive144Third127Node4 = false := by
  decide +kernel

#print axioms adaptive144Third127Proof4

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third127Proof2 : runCachedNode 511 128058 Adaptive144Third127Node2 = false := by
  decide +kernel

#print axioms adaptive144Third127Proof2

end NineSeparatedSubsetSums
