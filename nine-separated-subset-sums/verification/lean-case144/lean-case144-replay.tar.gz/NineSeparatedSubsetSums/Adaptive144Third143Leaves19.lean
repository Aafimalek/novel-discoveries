import NineSeparatedSubsetSums.Adaptive144Third143State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third143Proof661 : runCachedNode 511 130885 Adaptive144Third143Node661 = false := by
  decide +kernel

#print axioms adaptive144Third143Proof661

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third143Proof327 : runCachedNode 511 130885 Adaptive144Third143Node327 = false := by
  decide +kernel

#print axioms adaptive144Third143Proof327

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third143Proof159 : runCachedNode 511 130885 Adaptive144Third143Node159 = false := by
  decide +kernel

#print axioms adaptive144Third143Proof159

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third143Proof84 : runCachedNode 511 130885 Adaptive144Third143Node84 = false := by
  decide +kernel

#print axioms adaptive144Third143Proof84

end NineSeparatedSubsetSums
