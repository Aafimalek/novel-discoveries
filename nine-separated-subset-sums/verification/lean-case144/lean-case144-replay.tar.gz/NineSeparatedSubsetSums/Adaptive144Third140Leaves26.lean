import NineSeparatedSubsetSums.Adaptive144Third140State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof139 : runCachedNode 511 130381 Adaptive144Third140Node139 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof139

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof263 : runCachedNode 511 130381 Adaptive144Third140Node263 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof263

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof678 : runCachedNode 511 130381 Adaptive144Third140Node678 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof678

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof101 : runCachedNode 511 130381 Adaptive144Third140Node101 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof101

end NineSeparatedSubsetSums
