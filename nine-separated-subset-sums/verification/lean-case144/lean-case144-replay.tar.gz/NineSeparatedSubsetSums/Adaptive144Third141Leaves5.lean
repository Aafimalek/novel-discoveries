import NineSeparatedSubsetSums.Adaptive144Third141State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third141Proof203 : runCachedNode 511 130584 Adaptive144Third141Node203 = false := by
  decide +kernel

#print axioms adaptive144Third141Proof203

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third141Proof433 : runCachedNode 511 130584 Adaptive144Third141Node433 = false := by
  decide +kernel

#print axioms adaptive144Third141Proof433

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third141Proof60 : runCachedNode 511 130584 Adaptive144Third141Node60 = false := by
  decide +kernel

#print axioms adaptive144Third141Proof60

end NineSeparatedSubsetSums
