import NineSeparatedSubsetSums.Adaptive144Third125State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third125Proof0 : runCachedNode 511 127462 Adaptive144Third125Node0 = false := by
  decide +kernel

#print axioms adaptive144Third125Proof0

end NineSeparatedSubsetSums
