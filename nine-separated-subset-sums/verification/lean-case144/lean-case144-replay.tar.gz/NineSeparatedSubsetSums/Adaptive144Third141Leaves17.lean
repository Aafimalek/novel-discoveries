import NineSeparatedSubsetSums.Adaptive144Third141State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third141Proof436 : runCachedNode 511 130584 Adaptive144Third141Node436 = false := by
  decide +kernel

#print axioms adaptive144Third141Proof436

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third141Proof311 : runCachedNode 511 130584 Adaptive144Third141Node311 = false := by
  decide +kernel

#print axioms adaptive144Third141Proof311

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third141Proof235 : runCachedNode 511 130584 Adaptive144Third141Node235 = false := by
  decide +kernel

#print axioms adaptive144Third141Proof235

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third141Proof55 : runCachedNode 511 130584 Adaptive144Third141Node55 = false := by
  decide +kernel

#print axioms adaptive144Third141Proof55

end NineSeparatedSubsetSums
