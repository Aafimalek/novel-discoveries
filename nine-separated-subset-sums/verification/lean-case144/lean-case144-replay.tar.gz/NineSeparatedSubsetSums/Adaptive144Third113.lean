import NineSeparatedSubsetSums.Adaptive144Third113Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint144Checked

namespace NineSeparatedSubsetSums


theorem adaptive144Third113 : NoDescendingTailAfterThird 144 113 :=
  noDescendingThirdTail_of_cached 144 113 112221 (fun t ht nd => max148_second144_fourPoint_moment_bound (113::t) (by simp [ht]) nd) adaptive144Third113Proof0

#print axioms adaptive144Third113

end NineSeparatedSubsetSums
