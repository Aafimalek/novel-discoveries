import NineSeparatedSubsetSums.Adaptive144Third142State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third142Proof204 : runCachedNode 511 130737 Adaptive144Third142Node204 = false := by
  decide +kernel

#print axioms adaptive144Third142Proof204

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third142Proof491 : runCachedNode 511 130737 Adaptive144Third142Node491 = false := by
  decide +kernel

#print axioms adaptive144Third142Proof491

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third142Proof33 : runCachedNode 511 130737 Adaptive144Third142Node33 = false := by
  decide +kernel

#print axioms adaptive144Third142Proof33

end NineSeparatedSubsetSums
