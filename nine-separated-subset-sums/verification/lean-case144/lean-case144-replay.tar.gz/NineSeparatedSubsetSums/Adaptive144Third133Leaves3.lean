import NineSeparatedSubsetSums.Adaptive144Third133State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third133Proof16 : runCachedNode 511 129309 Adaptive144Third133Node16 = false := by
  decide +kernel

#print axioms adaptive144Third133Proof16

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third133Proof46 : runCachedNode 511 129309 Adaptive144Third133Node46 = false := by
  decide +kernel

#print axioms adaptive144Third133Proof46

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third133Proof15 : runCachedNode 511 129309 Adaptive144Third133Node15 = false := by
  decide +kernel

#print axioms adaptive144Third133Proof15

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third133Proof45 : runCachedNode 511 129309 Adaptive144Third133Node45 = false := by
  decide +kernel

#print axioms adaptive144Third133Proof45

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third133Proof2 : runCachedNode 511 129309 Adaptive144Third133Node2 = false := by
  decide +kernel

#print axioms adaptive144Third133Proof2

end NineSeparatedSubsetSums
