import NineSeparatedSubsetSums.Adaptive144Third138State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third138Proof90 : runCachedNode 511 130126 Adaptive144Third138Node90 = false := by
  decide +kernel

#print axioms adaptive144Third138Proof90

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third138Proof150 : runCachedNode 511 130126 Adaptive144Third138Node150 = false := by
  decide +kernel

#print axioms adaptive144Third138Proof150

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third138Proof210 : runCachedNode 511 130126 Adaptive144Third138Node210 = false := by
  decide +kernel

#print axioms adaptive144Third138Proof210

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third138Proof121 : runCachedNode 511 130126 Adaptive144Third138Node121 = false := by
  decide +kernel

#print axioms adaptive144Third138Proof121

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third138Proof41 : runCachedNode 511 130126 Adaptive144Third138Node41 = false := by
  decide +kernel

#print axioms adaptive144Third138Proof41

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third138Proof26 : runCachedNode 511 130126 Adaptive144Third138Node26 = false := by
  decide +kernel

#print axioms adaptive144Third138Proof26

end NineSeparatedSubsetSums
