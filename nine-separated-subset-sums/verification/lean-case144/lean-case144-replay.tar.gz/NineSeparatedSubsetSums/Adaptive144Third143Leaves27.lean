import NineSeparatedSubsetSums.Adaptive144Third143State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third143Proof15 : runCachedNode 511 130885 Adaptive144Third143Node15 = false := by
  decide +kernel

#print axioms adaptive144Third143Proof15

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third143Proof256 : runCachedNode 511 130885 Adaptive144Third143Node256 = false := by
  decide +kernel

#print axioms adaptive144Third143Proof256

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third143Proof566 : runCachedNode 511 130885 Adaptive144Third143Node566 = false := by
  decide +kernel

#print axioms adaptive144Third143Proof566

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third143Proof535 : runCachedNode 511 130885 Adaptive144Third143Node535 = false := by
  decide +kernel

#print axioms adaptive144Third143Proof535

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third143Proof46 : runCachedNode 511 130885 Adaptive144Third143Node46 = false := by
  decide +kernel

#print axioms adaptive144Third143Proof46

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third143Proof105 : runCachedNode 511 130885 Adaptive144Third143Node105 = false := by
  decide +kernel

#print axioms adaptive144Third143Proof105

end NineSeparatedSubsetSums
