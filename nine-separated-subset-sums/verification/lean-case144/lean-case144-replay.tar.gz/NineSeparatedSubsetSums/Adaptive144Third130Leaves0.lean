import NineSeparatedSubsetSums.Adaptive144Third130State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third130Proof19 : runCachedNode 511 128721 Adaptive144Third130Node19 = false := by
  decide +kernel

#print axioms adaptive144Third130Proof19

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third130Proof18 : runCachedNode 511 128721 Adaptive144Third130Node18 = false := by
  decide +kernel

#print axioms adaptive144Third130Proof18

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third130Proof3 : runCachedNode 511 128721 Adaptive144Third130Node3 = false := by
  decide +kernel

#print axioms adaptive144Third130Proof3

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third130Proof1 : runCachedNode 511 128721 Adaptive144Third130Node1 = false := by
  decide +kernel

#print axioms adaptive144Third130Proof1

end NineSeparatedSubsetSums
