import NineSeparatedSubsetSums.Adaptive144Third131State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third131Proof11 : runCachedNode 511 129000 Adaptive144Third131Node11 = false := by
  decide +kernel

#print axioms adaptive144Third131Proof11

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third131Proof7 : runCachedNode 511 129000 Adaptive144Third131Node7 = false := by
  decide +kernel

#print axioms adaptive144Third131Proof7

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third131Proof5 : runCachedNode 511 129000 Adaptive144Third131Node5 = false := by
  decide +kernel

#print axioms adaptive144Third131Proof5

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third131Proof4 : runCachedNode 511 129000 Adaptive144Third131Node4 = false := by
  decide +kernel

#print axioms adaptive144Third131Proof4

end NineSeparatedSubsetSums
