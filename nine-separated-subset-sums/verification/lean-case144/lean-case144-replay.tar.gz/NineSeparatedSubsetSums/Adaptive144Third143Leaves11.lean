import NineSeparatedSubsetSums.Adaptive144Third143State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third143Proof259 : runCachedNode 511 130885 Adaptive144Third143Node259 = false := by
  decide +kernel

#print axioms adaptive144Third143Proof259

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third143Proof227 : runCachedNode 511 130885 Adaptive144Third143Node227 = false := by
  decide +kernel

#print axioms adaptive144Third143Proof227

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third143Proof83 : runCachedNode 511 130885 Adaptive144Third143Node83 = false := by
  decide +kernel

#print axioms adaptive144Third143Proof83

end NineSeparatedSubsetSums
