import NineSeparatedSubsetSums.Adaptive144Third142State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third142Proof577 : runCachedNode 511 130737 Adaptive144Third142Node577 = false := by
  decide +kernel

#print axioms adaptive144Third142Proof577

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third142Proof658 : runCachedNode 511 130737 Adaptive144Third142Node658 = false := by
  decide +kernel

#print axioms adaptive144Third142Proof658

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third142Proof330 : runCachedNode 511 130737 Adaptive144Third142Node330 = false := by
  decide +kernel

#print axioms adaptive144Third142Proof330

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third142Proof449 : runCachedNode 511 130737 Adaptive144Third142Node449 = false := by
  decide +kernel

#print axioms adaptive144Third142Proof449

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third142Proof389 : runCachedNode 511 130737 Adaptive144Third142Node389 = false := by
  decide +kernel

#print axioms adaptive144Third142Proof389

end NineSeparatedSubsetSums
