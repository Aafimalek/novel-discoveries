import NineSeparatedSubsetSums.Adaptive144Third142State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third142Proof267 : runCachedNode 511 130737 Adaptive144Third142Node267 = false := by
  decide +kernel

#print axioms adaptive144Third142Proof267

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third142Proof614 : runCachedNode 511 130737 Adaptive144Third142Node614 = false := by
  decide +kernel

#print axioms adaptive144Third142Proof614

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third142Proof124 : runCachedNode 511 130737 Adaptive144Third142Node124 = false := by
  decide +kernel

#print axioms adaptive144Third142Proof124

end NineSeparatedSubsetSums
