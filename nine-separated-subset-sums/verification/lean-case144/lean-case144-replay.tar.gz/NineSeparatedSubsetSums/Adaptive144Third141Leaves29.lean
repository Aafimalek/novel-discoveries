import NineSeparatedSubsetSums.Adaptive144Third141State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third141Proof432 : runCachedNode 511 130584 Adaptive144Third141Node432 = false := by
  decide +kernel

#print axioms adaptive144Third141Proof432

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third141Proof165 : runCachedNode 511 130584 Adaptive144Third141Node165 = false := by
  decide +kernel

#print axioms adaptive144Third141Proof165

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third141Proof163 : runCachedNode 511 130584 Adaptive144Third141Node163 = false := by
  decide +kernel

#print axioms adaptive144Third141Proof163

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third141Proof73 : runCachedNode 511 130584 Adaptive144Third141Node73 = false := by
  decide +kernel

#print axioms adaptive144Third141Proof73

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third141Proof162 : runCachedNode 511 130584 Adaptive144Third141Node162 = false := by
  decide +kernel

#print axioms adaptive144Third141Proof162

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third141Proof48 : runCachedNode 511 130584 Adaptive144Third141Node48 = false := by
  decide +kernel

#print axioms adaptive144Third141Proof48

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third141Proof47 : runCachedNode 511 130584 Adaptive144Third141Node47 = false := by
  decide +kernel

#print axioms adaptive144Third141Proof47

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third141Proof300 : runCachedNode 511 130584 Adaptive144Third141Node300 = false := by
  decide +kernel

#print axioms adaptive144Third141Proof300

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third141Proof345 : runCachedNode 511 130584 Adaptive144Third141Node345 = false := by
  decide +kernel

#print axioms adaptive144Third141Proof345

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third141Proof113 : runCachedNode 511 130584 Adaptive144Third141Node113 = false := by
  decide +kernel

#print axioms adaptive144Third141Proof113

end NineSeparatedSubsetSums
