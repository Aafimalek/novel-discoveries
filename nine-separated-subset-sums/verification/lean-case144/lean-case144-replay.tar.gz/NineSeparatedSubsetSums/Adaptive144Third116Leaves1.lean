import NineSeparatedSubsetSums.Adaptive144Third116State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third116Proof13 : runCachedNode 511 112221 Adaptive144Third116Node13 = false := by
  decide +kernel

#print axioms adaptive144Third116Proof13

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third116Proof11 : runCachedNode 511 112221 Adaptive144Third116Node11 = false := by
  decide +kernel

#print axioms adaptive144Third116Proof11

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third116Proof9 : runCachedNode 511 112221 Adaptive144Third116Node9 = false := by
  decide +kernel

#print axioms adaptive144Third116Proof9

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third116Proof10 : runCachedNode 511 112221 Adaptive144Third116Node10 = false := by
  decide +kernel

#print axioms adaptive144Third116Proof10

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third116Proof8 : runCachedNode 511 112221 Adaptive144Third116Node8 = false := by
  decide +kernel

#print axioms adaptive144Third116Proof8

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third116Proof7 : runCachedNode 511 112221 Adaptive144Third116Node7 = false := by
  decide +kernel

#print axioms adaptive144Third116Proof7

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third116Proof6 : runCachedNode 511 112221 Adaptive144Third116Node6 = false := by
  decide +kernel

#print axioms adaptive144Third116Proof6

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third116Proof5 : runCachedNode 511 112221 Adaptive144Third116Node5 = false := by
  decide +kernel

#print axioms adaptive144Third116Proof5

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third116Proof4 : runCachedNode 511 112221 Adaptive144Third116Node4 = false := by
  decide +kernel

#print axioms adaptive144Third116Proof4

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third116Proof1 : runCachedNode 511 112221 Adaptive144Third116Node1 = false := by
  decide +kernel

#print axioms adaptive144Third116Proof1

end NineSeparatedSubsetSums
