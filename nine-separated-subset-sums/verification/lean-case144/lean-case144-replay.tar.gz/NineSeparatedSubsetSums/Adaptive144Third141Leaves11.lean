import NineSeparatedSubsetSums.Adaptive144Third141State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third141Proof198 : runCachedNode 511 130584 Adaptive144Third141Node198 = false := by
  decide +kernel

#print axioms adaptive144Third141Proof198

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third141Proof392 : runCachedNode 511 130584 Adaptive144Third141Node392 = false := by
  decide +kernel

#print axioms adaptive144Third141Proof392

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third141Proof122 : runCachedNode 511 130584 Adaptive144Third141Node122 = false := by
  decide +kernel

#print axioms adaptive144Third141Proof122

end NineSeparatedSubsetSums
