import NineSeparatedSubsetSums.Adaptive144Third111Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint144Checked

namespace NineSeparatedSubsetSums


theorem adaptive144Third111 : NoDescendingTailAfterThird 144 111 :=
  noDescendingThirdTail_of_cached 144 111 112221 (fun t ht nd => max148_second144_fourPoint_moment_bound (111::t) (by simp [ht]) nd) adaptive144Third111Proof0

#print axioms adaptive144Third111

end NineSeparatedSubsetSums
