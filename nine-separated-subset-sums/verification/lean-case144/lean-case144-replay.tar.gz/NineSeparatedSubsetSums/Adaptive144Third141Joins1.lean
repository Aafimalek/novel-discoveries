import NineSeparatedSubsetSums.Adaptive144Third141State
import NineSeparatedSubsetSums.Adaptive144Third141Leaves40
import NineSeparatedSubsetSums.Adaptive144Third141Leaves39
import NineSeparatedSubsetSums.Adaptive144Third141Leaves38
import NineSeparatedSubsetSums.Adaptive144Third141Leaves37
import NineSeparatedSubsetSums.Adaptive144Third141Leaves36
import NineSeparatedSubsetSums.Adaptive144Third141Leaves35
import NineSeparatedSubsetSums.Adaptive144Third141Leaves34
import NineSeparatedSubsetSums.Adaptive144Third141Leaves32
import NineSeparatedSubsetSums.Adaptive144Third141Leaves33
import NineSeparatedSubsetSums.Adaptive144Third141Leaves28
import NineSeparatedSubsetSums.Adaptive144Third141Leaves31
import NineSeparatedSubsetSums.Adaptive144Third141Leaves29
import NineSeparatedSubsetSums.Adaptive144Third141Leaves25
import NineSeparatedSubsetSums.Adaptive144Third141Leaves41
import NineSeparatedSubsetSums.Adaptive144Third141Leaves30
import NineSeparatedSubsetSums.Adaptive144Third141Leaves27
import NineSeparatedSubsetSums.Adaptive144Third141Leaves22
import NineSeparatedSubsetSums.Adaptive144Third141Leaves21
import NineSeparatedSubsetSums.Adaptive144Third141Leaves11
import NineSeparatedSubsetSums.Adaptive144Third141Leaves5
import NineSeparatedSubsetSums.Adaptive144Third141Leaves20
import NineSeparatedSubsetSums.Adaptive144Third141Leaves17
import NineSeparatedSubsetSums.Adaptive144Third141Leaves4
import NineSeparatedSubsetSums.Adaptive144Third141Leaves19
import NineSeparatedSubsetSums.Adaptive144Third141Leaves24
import NineSeparatedSubsetSums.Adaptive144Third141Leaves12
import NineSeparatedSubsetSums.Adaptive144Third141Leaves10
import NineSeparatedSubsetSums.Adaptive144Third141Leaves13
import NineSeparatedSubsetSums.Adaptive144Third141Leaves1
import NineSeparatedSubsetSums.Adaptive144Third141Leaves9
import NineSeparatedSubsetSums.Adaptive144Third141Leaves7
import NineSeparatedSubsetSums.Adaptive144Third141Leaves23
import NineSeparatedSubsetSums.Adaptive144Third141Leaves18
import NineSeparatedSubsetSums.Adaptive144Third141Leaves8
import NineSeparatedSubsetSums.Adaptive144Third141Leaves0
import NineSeparatedSubsetSums.Adaptive144Third141Joins0

namespace NineSeparatedSubsetSums

theorem adaptive144Third141Proof312 : runCachedNode 511 130584 Adaptive144Third141Node312 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130584 Adaptive144Third141Node312 = [90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 122, 123, 126, 130] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive144Third141Proof313
  · exact adaptive144Third141Proof314
  · exact adaptive144Third141Proof315
  · exact adaptive144Third141Proof316
  · exact adaptive144Third141Proof317
  · exact adaptive144Third141Proof318
  · exact adaptive144Third141Proof319
  · exact adaptive144Third141Proof320
  · exact adaptive144Third141Proof321
  · exact adaptive144Third141Proof322
  · exact adaptive144Third141Proof323
  · exact adaptive144Third141Proof324
  · exact adaptive144Third141Proof325
  · exact adaptive144Third141Proof326
  · exact adaptive144Third141Proof327
  · exact adaptive144Third141Proof328
  · exact adaptive144Third141Proof329
  · exact adaptive144Third141Proof330
  · exact adaptive144Third141Proof331
  · exact adaptive144Third141Proof332
  · exact adaptive144Third141Proof333
  · exact adaptive144Third141Proof334
  · exact adaptive144Third141Proof335
  · exact adaptive144Third141Proof336
  · exact adaptive144Third141Proof337
  · exact adaptive144Third141Proof338
  · exact adaptive144Third141Proof339
  · exact adaptive144Third141Proof340
  · exact adaptive144Third141Proof341
  · exact adaptive144Third141Proof342
  · exact adaptive144Third141Proof343
  · exact adaptive144Third141Proof344
  · exact adaptive144Third141Proof345
  · exact adaptive144Third141Proof346
  · exact adaptive144Third141Proof347

#print axioms adaptive144Third141Proof312

theorem adaptive144Third141Proof350 : runCachedNode 511 130584 Adaptive144Third141Node350 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130584 Adaptive144Third141Node350 = [88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 128, 129, 132] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive144Third141Proof351
  · exact adaptive144Third141Proof352
  · exact adaptive144Third141Proof353
  · exact adaptive144Third141Proof354
  · exact adaptive144Third141Proof355
  · exact adaptive144Third141Proof356
  · exact adaptive144Third141Proof357
  · exact adaptive144Third141Proof358
  · exact adaptive144Third141Proof359
  · exact adaptive144Third141Proof360
  · exact adaptive144Third141Proof361
  · exact adaptive144Third141Proof362
  · exact adaptive144Third141Proof363
  · exact adaptive144Third141Proof364
  · exact adaptive144Third141Proof365
  · exact adaptive144Third141Proof366
  · exact adaptive144Third141Proof367
  · exact adaptive144Third141Proof368
  · exact adaptive144Third141Proof369
  · exact adaptive144Third141Proof370
  · exact adaptive144Third141Proof371
  · exact adaptive144Third141Proof372
  · exact adaptive144Third141Proof373
  · exact adaptive144Third141Proof374
  · exact adaptive144Third141Proof375
  · exact adaptive144Third141Proof376
  · exact adaptive144Third141Proof377
  · exact adaptive144Third141Proof378
  · exact adaptive144Third141Proof379
  · exact adaptive144Third141Proof380
  · exact adaptive144Third141Proof381
  · exact adaptive144Third141Proof382
  · exact adaptive144Third141Proof383
  · exact adaptive144Third141Proof384
  · exact adaptive144Third141Proof385
  · exact adaptive144Third141Proof386
  · exact adaptive144Third141Proof387
  · exact adaptive144Third141Proof388
  · exact adaptive144Third141Proof389
  · exact adaptive144Third141Proof390
  · exact adaptive144Third141Proof391
  · exact adaptive144Third141Proof392

#print axioms adaptive144Third141Proof350

theorem adaptive144Third141Proof393 : runCachedNode 511 130584 Adaptive144Third141Node393 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130584 Adaptive144Third141Node393 = [87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 129, 130] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive144Third141Proof394
  · exact adaptive144Third141Proof395
  · exact adaptive144Third141Proof396
  · exact adaptive144Third141Proof397
  · exact adaptive144Third141Proof398
  · exact adaptive144Third141Proof399
  · exact adaptive144Third141Proof400
  · exact adaptive144Third141Proof401
  · exact adaptive144Third141Proof402
  · exact adaptive144Third141Proof403
  · exact adaptive144Third141Proof404
  · exact adaptive144Third141Proof405
  · exact adaptive144Third141Proof406
  · exact adaptive144Third141Proof407
  · exact adaptive144Third141Proof408
  · exact adaptive144Third141Proof409
  · exact adaptive144Third141Proof410
  · exact adaptive144Third141Proof411
  · exact adaptive144Third141Proof412
  · exact adaptive144Third141Proof413
  · exact adaptive144Third141Proof414
  · exact adaptive144Third141Proof415
  · exact adaptive144Third141Proof416
  · exact adaptive144Third141Proof417
  · exact adaptive144Third141Proof418
  · exact adaptive144Third141Proof419
  · exact adaptive144Third141Proof420
  · exact adaptive144Third141Proof421
  · exact adaptive144Third141Proof422
  · exact adaptive144Third141Proof423
  · exact adaptive144Third141Proof424
  · exact adaptive144Third141Proof425
  · exact adaptive144Third141Proof426
  · exact adaptive144Third141Proof427
  · exact adaptive144Third141Proof428
  · exact adaptive144Third141Proof429
  · exact adaptive144Third141Proof430
  · exact adaptive144Third141Proof431
  · exact adaptive144Third141Proof432
  · exact adaptive144Third141Proof433
  · exact adaptive144Third141Proof434
  · exact adaptive144Third141Proof435
  · exact adaptive144Third141Proof436

#print axioms adaptive144Third141Proof393

theorem adaptive144Third141Proof280 : runCachedNode 511 130584 Adaptive144Third141Node280 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130584 Adaptive144Third141Node280 = [101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 132, 134, 135, 138, 139] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive144Third141Proof281
  · exact adaptive144Third141Proof282
  · exact adaptive144Third141Proof283
  · exact adaptive144Third141Proof284
  · exact adaptive144Third141Proof285
  · exact adaptive144Third141Proof286
  · exact adaptive144Third141Proof287
  · exact adaptive144Third141Proof288
  · exact adaptive144Third141Proof289
  · exact adaptive144Third141Proof290
  · exact adaptive144Third141Proof291
  · exact adaptive144Third141Proof292
  · exact adaptive144Third141Proof293
  · exact adaptive144Third141Proof294
  · exact adaptive144Third141Proof295
  · exact adaptive144Third141Proof296
  · exact adaptive144Third141Proof297
  · exact adaptive144Third141Proof298
  · exact adaptive144Third141Proof299
  · exact adaptive144Third141Proof300
  · exact adaptive144Third141Proof301
  · exact adaptive144Third141Proof302
  · exact adaptive144Third141Proof303
  · exact adaptive144Third141Proof304
  · exact adaptive144Third141Proof305
  · exact adaptive144Third141Proof306
  · exact adaptive144Third141Proof307
  · exact adaptive144Third141Proof308
  · exact adaptive144Third141Proof309
  · exact adaptive144Third141Proof310
  · exact adaptive144Third141Proof311
  · exact adaptive144Third141Proof312
  · exact adaptive144Third141Proof348
  · exact adaptive144Third141Proof349
  · exact adaptive144Third141Proof350
  · exact adaptive144Third141Proof393

#print axioms adaptive144Third141Proof280

theorem adaptive144Third141Proof0 : runCachedNode 511 130584 Adaptive144Third141Node0 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130584 Adaptive144Third141Node0 = [109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 132, 133, 134, 135, 136, 138, 139, 140] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive144Third141Proof1
  · exact adaptive144Third141Proof2
  · exact adaptive144Third141Proof3
  · exact adaptive144Third141Proof4
  · exact adaptive144Third141Proof5
  · exact adaptive144Third141Proof6
  · exact adaptive144Third141Proof7
  · exact adaptive144Third141Proof8
  · exact adaptive144Third141Proof9
  · exact adaptive144Third141Proof10
  · exact adaptive144Third141Proof11
  · exact adaptive144Third141Proof12
  · exact adaptive144Third141Proof13
  · exact adaptive144Third141Proof14
  · exact adaptive144Third141Proof15
  · exact adaptive144Third141Proof16
  · exact adaptive144Third141Proof17
  · exact adaptive144Third141Proof18
  · exact adaptive144Third141Proof19
  · exact adaptive144Third141Proof20
  · exact adaptive144Third141Proof21
  · exact adaptive144Third141Proof22
  · exact adaptive144Third141Proof23
  · exact adaptive144Third141Proof24
  · exact adaptive144Third141Proof51
  · exact adaptive144Third141Proof79
  · exact adaptive144Third141Proof108
  · exact adaptive144Third141Proof139
  · exact adaptive144Third141Proof171
  · exact adaptive144Third141Proof204
  · exact adaptive144Third141Proof280

#print axioms adaptive144Third141Proof0

end NineSeparatedSubsetSums
