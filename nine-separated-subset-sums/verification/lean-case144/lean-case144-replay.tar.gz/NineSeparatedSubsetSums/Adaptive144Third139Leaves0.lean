import NineSeparatedSubsetSums.Adaptive144Third139State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third139Proof249 : runCachedNode 511 130274 Adaptive144Third139Node249 = false := by
  decide +kernel

#print axioms adaptive144Third139Proof249

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third139Proof139 : runCachedNode 511 130274 Adaptive144Third139Node139 = false := by
  decide +kernel

#print axioms adaptive144Third139Proof139

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third139Proof71 : runCachedNode 511 130274 Adaptive144Third139Node71 = false := by
  decide +kernel

#print axioms adaptive144Third139Proof71

end NineSeparatedSubsetSums
