import NineSeparatedSubsetSums.Adaptive144Third142State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third142Proof103 : runCachedNode 511 130737 Adaptive144Third142Node103 = false := by
  decide +kernel

#print axioms adaptive144Third142Proof103

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third142Proof42 : runCachedNode 511 130737 Adaptive144Third142Node42 = false := by
  decide +kernel

#print axioms adaptive144Third142Proof42

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third142Proof398 : runCachedNode 511 130737 Adaptive144Third142Node398 = false := by
  decide +kernel

#print axioms adaptive144Third142Proof398

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third142Proof646 : runCachedNode 511 130737 Adaptive144Third142Node646 = false := by
  decide +kernel

#print axioms adaptive144Third142Proof646

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third142Proof72 : runCachedNode 511 130737 Adaptive144Third142Node72 = false := by
  decide +kernel

#print axioms adaptive144Third142Proof72

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third142Proof130 : runCachedNode 511 130737 Adaptive144Third142Node130 = false := by
  decide +kernel

#print axioms adaptive144Third142Proof130

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third142Proof648 : runCachedNode 511 130737 Adaptive144Third142Node648 = false := by
  decide +kernel

#print axioms adaptive144Third142Proof648

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third142Proof71 : runCachedNode 511 130737 Adaptive144Third142Node71 = false := by
  decide +kernel

#print axioms adaptive144Third142Proof71

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third142Proof605 : runCachedNode 511 130737 Adaptive144Third142Node605 = false := by
  decide +kernel

#print axioms adaptive144Third142Proof605

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third142Proof159 : runCachedNode 511 130737 Adaptive144Third142Node159 = false := by
  decide +kernel

#print axioms adaptive144Third142Proof159

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third142Proof604 : runCachedNode 511 130737 Adaptive144Third142Node604 = false := by
  decide +kernel

#print axioms adaptive144Third142Proof604

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third142Proof393 : runCachedNode 511 130737 Adaptive144Third142Node393 = false := by
  decide +kernel

#print axioms adaptive144Third142Proof393

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third142Proof99 : runCachedNode 511 130737 Adaptive144Third142Node99 = false := by
  decide +kernel

#print axioms adaptive144Third142Proof99

end NineSeparatedSubsetSums
