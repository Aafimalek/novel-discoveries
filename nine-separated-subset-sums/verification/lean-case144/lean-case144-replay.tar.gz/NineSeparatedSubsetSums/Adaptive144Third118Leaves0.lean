import NineSeparatedSubsetSums.Adaptive144Third118State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third118Proof0 : runCachedNode 511 125868 Adaptive144Third118Node0 = false := by
  decide +kernel

#print axioms adaptive144Third118Proof0

end NineSeparatedSubsetSums
