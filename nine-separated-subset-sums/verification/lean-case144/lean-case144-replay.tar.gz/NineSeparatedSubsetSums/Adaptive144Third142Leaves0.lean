import NineSeparatedSubsetSums.Adaptive144Third142State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third142Proof23 : runCachedNode 511 130737 Adaptive144Third142Node23 = false := by
  decide +kernel

#print axioms adaptive144Third142Proof23

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third142Proof531 : runCachedNode 511 130737 Adaptive144Third142Node531 = false := by
  decide +kernel

#print axioms adaptive144Third142Proof531

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third142Proof58 : runCachedNode 511 130737 Adaptive144Third142Node58 = false := by
  decide +kernel

#print axioms adaptive144Third142Proof58

end NineSeparatedSubsetSums
