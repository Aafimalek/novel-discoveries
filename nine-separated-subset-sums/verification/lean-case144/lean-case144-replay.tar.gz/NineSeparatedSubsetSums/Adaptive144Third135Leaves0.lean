import NineSeparatedSubsetSums.Adaptive144Third135State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third135Proof21 : runCachedNode 511 129692 Adaptive144Third135Node21 = false := by
  decide +kernel

#print axioms adaptive144Third135Proof21

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third135Proof65 : runCachedNode 511 129692 Adaptive144Third135Node65 = false := by
  decide +kernel

#print axioms adaptive144Third135Proof65

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third135Proof3 : runCachedNode 511 129692 Adaptive144Third135Node3 = false := by
  decide +kernel

#print axioms adaptive144Third135Proof3

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third135Proof23 : runCachedNode 511 129692 Adaptive144Third135Node23 = false := by
  decide +kernel

#print axioms adaptive144Third135Proof23

end NineSeparatedSubsetSums
