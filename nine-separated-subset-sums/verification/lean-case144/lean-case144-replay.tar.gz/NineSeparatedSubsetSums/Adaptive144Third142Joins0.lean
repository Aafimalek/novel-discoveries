import NineSeparatedSubsetSums.Adaptive144Third142State
import NineSeparatedSubsetSums.Adaptive144Third142Leaves52
import NineSeparatedSubsetSums.Adaptive144Third142Leaves24
import NineSeparatedSubsetSums.Adaptive144Third142Leaves4
import NineSeparatedSubsetSums.Adaptive144Third142Leaves15
import NineSeparatedSubsetSums.Adaptive144Third142Leaves45
import NineSeparatedSubsetSums.Adaptive144Third142Leaves48
import NineSeparatedSubsetSums.Adaptive144Third142Leaves7
import NineSeparatedSubsetSums.Adaptive144Third142Leaves47
import NineSeparatedSubsetSums.Adaptive144Third142Leaves43
import NineSeparatedSubsetSums.Adaptive144Third142Leaves44
import NineSeparatedSubsetSums.Adaptive144Third142Leaves39
import NineSeparatedSubsetSums.Adaptive144Third142Leaves41
import NineSeparatedSubsetSums.Adaptive144Third142Leaves29
import NineSeparatedSubsetSums.Adaptive144Third142Leaves38
import NineSeparatedSubsetSums.Adaptive144Third142Leaves2
import NineSeparatedSubsetSums.Adaptive144Third142Leaves35
import NineSeparatedSubsetSums.Adaptive144Third142Leaves25
import NineSeparatedSubsetSums.Adaptive144Third142Leaves30
import NineSeparatedSubsetSums.Adaptive144Third142Leaves53
import NineSeparatedSubsetSums.Adaptive144Third142Leaves5
import NineSeparatedSubsetSums.Adaptive144Third142Leaves50
import NineSeparatedSubsetSums.Adaptive144Third142Leaves0
import NineSeparatedSubsetSums.Adaptive144Third142Leaves49
import NineSeparatedSubsetSums.Adaptive144Third142Leaves1
import NineSeparatedSubsetSums.Adaptive144Third142Leaves46
import NineSeparatedSubsetSums.Adaptive144Third142Leaves37
import NineSeparatedSubsetSums.Adaptive144Third142Leaves32
import NineSeparatedSubsetSums.Adaptive144Third142Leaves36
import NineSeparatedSubsetSums.Adaptive144Third142Leaves34
import NineSeparatedSubsetSums.Adaptive144Third142Leaves20
import NineSeparatedSubsetSums.Adaptive144Third142Leaves21
import NineSeparatedSubsetSums.Adaptive144Third142Leaves11
import NineSeparatedSubsetSums.Adaptive144Third142Leaves26
import NineSeparatedSubsetSums.Adaptive144Third142Leaves22
import NineSeparatedSubsetSums.Adaptive144Third142Leaves9
import NineSeparatedSubsetSums.Adaptive144Third142Leaves51
import NineSeparatedSubsetSums.Adaptive144Third142Leaves27
import NineSeparatedSubsetSums.Adaptive144Third142Leaves33
import NineSeparatedSubsetSums.Adaptive144Third142Leaves42
import NineSeparatedSubsetSums.Adaptive144Third142Leaves40
import NineSeparatedSubsetSums.Adaptive144Third142Leaves19
import NineSeparatedSubsetSums.Adaptive144Third142Leaves6
import NineSeparatedSubsetSums.Adaptive144Third142Leaves12
import NineSeparatedSubsetSums.Adaptive144Third142Leaves3
import NineSeparatedSubsetSums.Adaptive144Third142Leaves14
import NineSeparatedSubsetSums.Adaptive144Third142Leaves17
import NineSeparatedSubsetSums.Adaptive144Third142Leaves54
import NineSeparatedSubsetSums.Adaptive144Third142Leaves31
import NineSeparatedSubsetSums.Adaptive144Third142Leaves28

namespace NineSeparatedSubsetSums

theorem adaptive144Third142Proof24 : runCachedNode 511 130737 Adaptive144Third142Node24 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130737 Adaptive144Third142Node24 = [103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 127, 129, 131] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive144Third142Proof25
  · exact adaptive144Third142Proof26
  · exact adaptive144Third142Proof27
  · exact adaptive144Third142Proof28
  · exact adaptive144Third142Proof29
  · exact adaptive144Third142Proof30
  · exact adaptive144Third142Proof31
  · exact adaptive144Third142Proof32
  · exact adaptive144Third142Proof33
  · exact adaptive144Third142Proof34
  · exact adaptive144Third142Proof35
  · exact adaptive144Third142Proof36
  · exact adaptive144Third142Proof37
  · exact adaptive144Third142Proof38
  · exact adaptive144Third142Proof39
  · exact adaptive144Third142Proof40
  · exact adaptive144Third142Proof41
  · exact adaptive144Third142Proof42
  · exact adaptive144Third142Proof43
  · exact adaptive144Third142Proof44
  · exact adaptive144Third142Proof45
  · exact adaptive144Third142Proof46
  · exact adaptive144Third142Proof47
  · exact adaptive144Third142Proof48
  · exact adaptive144Third142Proof49
  · exact adaptive144Third142Proof50

#print axioms adaptive144Third142Proof24

theorem adaptive144Third142Proof51 : runCachedNode 511 130737 Adaptive144Third142Node51 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130737 Adaptive144Third142Node51 = [103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 128, 130, 132] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive144Third142Proof52
  · exact adaptive144Third142Proof53
  · exact adaptive144Third142Proof54
  · exact adaptive144Third142Proof55
  · exact adaptive144Third142Proof56
  · exact adaptive144Third142Proof57
  · exact adaptive144Third142Proof58
  · exact adaptive144Third142Proof59
  · exact adaptive144Third142Proof60
  · exact adaptive144Third142Proof61
  · exact adaptive144Third142Proof62
  · exact adaptive144Third142Proof63
  · exact adaptive144Third142Proof64
  · exact adaptive144Third142Proof65
  · exact adaptive144Third142Proof66
  · exact adaptive144Third142Proof67
  · exact adaptive144Third142Proof68
  · exact adaptive144Third142Proof69
  · exact adaptive144Third142Proof70
  · exact adaptive144Third142Proof71
  · exact adaptive144Third142Proof72
  · exact adaptive144Third142Proof73
  · exact adaptive144Third142Proof74
  · exact adaptive144Third142Proof75
  · exact adaptive144Third142Proof76
  · exact adaptive144Third142Proof77
  · exact adaptive144Third142Proof78

#print axioms adaptive144Third142Proof51

theorem adaptive144Third142Proof79 : runCachedNode 511 130737 Adaptive144Third142Node79 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130737 Adaptive144Third142Node79 = [102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 129, 131, 133] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive144Third142Proof80
  · exact adaptive144Third142Proof81
  · exact adaptive144Third142Proof82
  · exact adaptive144Third142Proof83
  · exact adaptive144Third142Proof84
  · exact adaptive144Third142Proof85
  · exact adaptive144Third142Proof86
  · exact adaptive144Third142Proof87
  · exact adaptive144Third142Proof88
  · exact adaptive144Third142Proof89
  · exact adaptive144Third142Proof90
  · exact adaptive144Third142Proof91
  · exact adaptive144Third142Proof92
  · exact adaptive144Third142Proof93
  · exact adaptive144Third142Proof94
  · exact adaptive144Third142Proof95
  · exact adaptive144Third142Proof96
  · exact adaptive144Third142Proof97
  · exact adaptive144Third142Proof98
  · exact adaptive144Third142Proof99
  · exact adaptive144Third142Proof100
  · exact adaptive144Third142Proof101
  · exact adaptive144Third142Proof102
  · exact adaptive144Third142Proof103
  · exact adaptive144Third142Proof104
  · exact adaptive144Third142Proof105
  · exact adaptive144Third142Proof106
  · exact adaptive144Third142Proof107
  · exact adaptive144Third142Proof108

#print axioms adaptive144Third142Proof79

theorem adaptive144Third142Proof109 : runCachedNode 511 130737 Adaptive144Third142Node109 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130737 Adaptive144Third142Node109 = [102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 130, 132, 134] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive144Third142Proof110
  · exact adaptive144Third142Proof111
  · exact adaptive144Third142Proof112
  · exact adaptive144Third142Proof113
  · exact adaptive144Third142Proof114
  · exact adaptive144Third142Proof115
  · exact adaptive144Third142Proof116
  · exact adaptive144Third142Proof117
  · exact adaptive144Third142Proof118
  · exact adaptive144Third142Proof119
  · exact adaptive144Third142Proof120
  · exact adaptive144Third142Proof121
  · exact adaptive144Third142Proof122
  · exact adaptive144Third142Proof123
  · exact adaptive144Third142Proof124
  · exact adaptive144Third142Proof125
  · exact adaptive144Third142Proof126
  · exact adaptive144Third142Proof127
  · exact adaptive144Third142Proof128
  · exact adaptive144Third142Proof129
  · exact adaptive144Third142Proof130
  · exact adaptive144Third142Proof131
  · exact adaptive144Third142Proof132
  · exact adaptive144Third142Proof133
  · exact adaptive144Third142Proof134
  · exact adaptive144Third142Proof135
  · exact adaptive144Third142Proof136
  · exact adaptive144Third142Proof137
  · exact adaptive144Third142Proof138
  · exact adaptive144Third142Proof139

#print axioms adaptive144Third142Proof109

theorem adaptive144Third142Proof140 : runCachedNode 511 130737 Adaptive144Third142Node140 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130737 Adaptive144Third142Node140 = [102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 131, 133, 135] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive144Third142Proof141
  · exact adaptive144Third142Proof142
  · exact adaptive144Third142Proof143
  · exact adaptive144Third142Proof144
  · exact adaptive144Third142Proof145
  · exact adaptive144Third142Proof146
  · exact adaptive144Third142Proof147
  · exact adaptive144Third142Proof148
  · exact adaptive144Third142Proof149
  · exact adaptive144Third142Proof150
  · exact adaptive144Third142Proof151
  · exact adaptive144Third142Proof152
  · exact adaptive144Third142Proof153
  · exact adaptive144Third142Proof154
  · exact adaptive144Third142Proof155
  · exact adaptive144Third142Proof156
  · exact adaptive144Third142Proof157
  · exact adaptive144Third142Proof158
  · exact adaptive144Third142Proof159
  · exact adaptive144Third142Proof160
  · exact adaptive144Third142Proof161
  · exact adaptive144Third142Proof162
  · exact adaptive144Third142Proof163
  · exact adaptive144Third142Proof164
  · exact adaptive144Third142Proof165
  · exact adaptive144Third142Proof166
  · exact adaptive144Third142Proof167
  · exact adaptive144Third142Proof168
  · exact adaptive144Third142Proof169
  · exact adaptive144Third142Proof170
  · exact adaptive144Third142Proof171

#print axioms adaptive144Third142Proof140

theorem adaptive144Third142Proof172 : runCachedNode 511 130737 Adaptive144Third142Node172 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130737 Adaptive144Third142Node172 = [102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 132, 134, 136] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive144Third142Proof173
  · exact adaptive144Third142Proof174
  · exact adaptive144Third142Proof175
  · exact adaptive144Third142Proof176
  · exact adaptive144Third142Proof177
  · exact adaptive144Third142Proof178
  · exact adaptive144Third142Proof179
  · exact adaptive144Third142Proof180
  · exact adaptive144Third142Proof181
  · exact adaptive144Third142Proof182
  · exact adaptive144Third142Proof183
  · exact adaptive144Third142Proof184
  · exact adaptive144Third142Proof185
  · exact adaptive144Third142Proof186
  · exact adaptive144Third142Proof187
  · exact adaptive144Third142Proof188
  · exact adaptive144Third142Proof189
  · exact adaptive144Third142Proof190
  · exact adaptive144Third142Proof191
  · exact adaptive144Third142Proof192
  · exact adaptive144Third142Proof193
  · exact adaptive144Third142Proof194
  · exact adaptive144Third142Proof195
  · exact adaptive144Third142Proof196
  · exact adaptive144Third142Proof197
  · exact adaptive144Third142Proof198
  · exact adaptive144Third142Proof199
  · exact adaptive144Third142Proof200
  · exact adaptive144Third142Proof201
  · exact adaptive144Third142Proof202
  · exact adaptive144Third142Proof203
  · exact adaptive144Third142Proof204

#print axioms adaptive144Third142Proof172

theorem adaptive144Third142Proof205 : runCachedNode 511 130737 Adaptive144Third142Node205 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130737 Adaptive144Third142Node205 = [101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 132, 134, 136] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive144Third142Proof206
  · exact adaptive144Third142Proof207
  · exact adaptive144Third142Proof208
  · exact adaptive144Third142Proof209
  · exact adaptive144Third142Proof210
  · exact adaptive144Third142Proof211
  · exact adaptive144Third142Proof212
  · exact adaptive144Third142Proof213
  · exact adaptive144Third142Proof214
  · exact adaptive144Third142Proof215
  · exact adaptive144Third142Proof216
  · exact adaptive144Third142Proof217
  · exact adaptive144Third142Proof218
  · exact adaptive144Third142Proof219
  · exact adaptive144Third142Proof220
  · exact adaptive144Third142Proof221
  · exact adaptive144Third142Proof222
  · exact adaptive144Third142Proof223
  · exact adaptive144Third142Proof224
  · exact adaptive144Third142Proof225
  · exact adaptive144Third142Proof226
  · exact adaptive144Third142Proof227
  · exact adaptive144Third142Proof228
  · exact adaptive144Third142Proof229
  · exact adaptive144Third142Proof230
  · exact adaptive144Third142Proof231
  · exact adaptive144Third142Proof232
  · exact adaptive144Third142Proof233
  · exact adaptive144Third142Proof234
  · exact adaptive144Third142Proof235
  · exact adaptive144Third142Proof236
  · exact adaptive144Third142Proof237
  · exact adaptive144Third142Proof238
  · exact adaptive144Third142Proof239

#print axioms adaptive144Third142Proof205

theorem adaptive144Third142Proof268 : runCachedNode 511 130737 Adaptive144Third142Node268 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130737 Adaptive144Third142Node268 = [91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 119, 121, 123, 125, 127] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive144Third142Proof269
  · exact adaptive144Third142Proof270
  · exact adaptive144Third142Proof271
  · exact adaptive144Third142Proof272
  · exact adaptive144Third142Proof273
  · exact adaptive144Third142Proof274
  · exact adaptive144Third142Proof275
  · exact adaptive144Third142Proof276
  · exact adaptive144Third142Proof277
  · exact adaptive144Third142Proof278
  · exact adaptive144Third142Proof279
  · exact adaptive144Third142Proof280
  · exact adaptive144Third142Proof281
  · exact adaptive144Third142Proof282
  · exact adaptive144Third142Proof283
  · exact adaptive144Third142Proof284
  · exact adaptive144Third142Proof285
  · exact adaptive144Third142Proof286
  · exact adaptive144Third142Proof287
  · exact adaptive144Third142Proof288
  · exact adaptive144Third142Proof289
  · exact adaptive144Third142Proof290
  · exact adaptive144Third142Proof291
  · exact adaptive144Third142Proof292
  · exact adaptive144Third142Proof293
  · exact adaptive144Third142Proof294
  · exact adaptive144Third142Proof295
  · exact adaptive144Third142Proof296
  · exact adaptive144Third142Proof297
  · exact adaptive144Third142Proof298
  · exact adaptive144Third142Proof299
  · exact adaptive144Third142Proof300

#print axioms adaptive144Third142Proof268

end NineSeparatedSubsetSums
