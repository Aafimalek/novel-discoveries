import NineSeparatedSubsetSums.Adaptive144Third104Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint144Checked

namespace NineSeparatedSubsetSums


theorem adaptive144Third104 : NoDescendingTailAfterThird 144 104 :=
  noDescendingThirdTail_of_cached 144 104 112221 (fun t ht nd => max148_second144_fourPoint_moment_bound (104::t) (by simp [ht]) nd) adaptive144Third104Proof0

#print axioms adaptive144Third104

end NineSeparatedSubsetSums
