import NineSeparatedSubsetSums.Adaptive144Third141State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third141Proof201 : runCachedNode 511 130584 Adaptive144Third141Node201 = false := by
  decide +kernel

#print axioms adaptive144Third141Proof201

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third141Proof270 : runCachedNode 511 130584 Adaptive144Third141Node270 = false := by
  decide +kernel

#print axioms adaptive144Third141Proof270

end NineSeparatedSubsetSums
