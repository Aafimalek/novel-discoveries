import NineSeparatedSubsetSums.Adaptive144Third134State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third134Proof21 : runCachedNode 511 129525 Adaptive144Third134Node21 = false := by
  decide +kernel

#print axioms adaptive144Third134Proof21

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third134Proof14 : runCachedNode 511 129525 Adaptive144Third134Node14 = false := by
  decide +kernel

#print axioms adaptive144Third134Proof14

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third134Proof5 : runCachedNode 511 129525 Adaptive144Third134Node5 = false := by
  decide +kernel

#print axioms adaptive144Third134Proof5

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third134Proof26 : runCachedNode 511 129525 Adaptive144Third134Node26 = false := by
  decide +kernel

#print axioms adaptive144Third134Proof26

end NineSeparatedSubsetSums
