import NineSeparatedSubsetSums.Adaptive144Third135State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third135Proof98 : runCachedNode 511 129692 Adaptive144Third135Node98 = false := by
  decide +kernel

#print axioms adaptive144Third135Proof98

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third135Proof95 : runCachedNode 511 129692 Adaptive144Third135Node95 = false := by
  decide +kernel

#print axioms adaptive144Third135Proof95

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third135Proof68 : runCachedNode 511 129692 Adaptive144Third135Node68 = false := by
  decide +kernel

#print axioms adaptive144Third135Proof68

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third135Proof14 : runCachedNode 511 129692 Adaptive144Third135Node14 = false := by
  decide +kernel

#print axioms adaptive144Third135Proof14

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third135Proof46 : runCachedNode 511 129692 Adaptive144Third135Node46 = false := by
  decide +kernel

#print axioms adaptive144Third135Proof46

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third135Proof40 : runCachedNode 511 129692 Adaptive144Third135Node40 = false := by
  decide +kernel

#print axioms adaptive144Third135Proof40

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third135Proof28 : runCachedNode 511 129692 Adaptive144Third135Node28 = false := by
  decide +kernel

#print axioms adaptive144Third135Proof28

end NineSeparatedSubsetSums
