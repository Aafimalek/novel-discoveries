import NineSeparatedSubsetSums.Adaptive144Third139State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third139Proof152 : runCachedNode 511 130274 Adaptive144Third139Node152 = false := by
  decide +kernel

#print axioms adaptive144Third139Proof152

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third139Proof214 : runCachedNode 511 130274 Adaptive144Third139Node214 = false := by
  decide +kernel

#print axioms adaptive144Third139Proof214

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third139Proof180 : runCachedNode 511 130274 Adaptive144Third139Node180 = false := by
  decide +kernel

#print axioms adaptive144Third139Proof180

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third139Proof50 : runCachedNode 511 130274 Adaptive144Third139Node50 = false := by
  decide +kernel

#print axioms adaptive144Third139Proof50

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third139Proof218 : runCachedNode 511 130274 Adaptive144Third139Node218 = false := by
  decide +kernel

#print axioms adaptive144Third139Proof218

end NineSeparatedSubsetSums
