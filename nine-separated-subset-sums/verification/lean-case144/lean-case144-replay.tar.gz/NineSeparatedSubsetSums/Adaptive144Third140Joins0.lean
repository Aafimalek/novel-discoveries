import NineSeparatedSubsetSums.Adaptive144Third140State
import NineSeparatedSubsetSums.Adaptive144Third140Leaves25
import NineSeparatedSubsetSums.Adaptive144Third140Leaves59
import NineSeparatedSubsetSums.Adaptive144Third140Leaves58
import NineSeparatedSubsetSums.Adaptive144Third140Leaves57
import NineSeparatedSubsetSums.Adaptive144Third140Leaves56
import NineSeparatedSubsetSums.Adaptive144Third140Leaves55
import NineSeparatedSubsetSums.Adaptive144Third140Leaves54
import NineSeparatedSubsetSums.Adaptive144Third140Leaves50
import NineSeparatedSubsetSums.Adaptive144Third140Leaves17
import NineSeparatedSubsetSums.Adaptive144Third140Leaves53
import NineSeparatedSubsetSums.Adaptive144Third140Leaves52
import NineSeparatedSubsetSums.Adaptive144Third140Leaves47
import NineSeparatedSubsetSums.Adaptive144Third140Leaves38
import NineSeparatedSubsetSums.Adaptive144Third140Leaves48
import NineSeparatedSubsetSums.Adaptive144Third140Leaves46
import NineSeparatedSubsetSums.Adaptive144Third140Leaves41
import NineSeparatedSubsetSums.Adaptive144Third140Leaves42
import NineSeparatedSubsetSums.Adaptive144Third140Leaves39
import NineSeparatedSubsetSums.Adaptive144Third140Leaves7
import NineSeparatedSubsetSums.Adaptive144Third140Leaves32
import NineSeparatedSubsetSums.Adaptive144Third140Leaves28
import NineSeparatedSubsetSums.Adaptive144Third140Leaves34
import NineSeparatedSubsetSums.Adaptive144Third140Leaves49
import NineSeparatedSubsetSums.Adaptive144Third140Leaves1
import NineSeparatedSubsetSums.Adaptive144Third140Leaves35
import NineSeparatedSubsetSums.Adaptive144Third140Leaves43
import NineSeparatedSubsetSums.Adaptive144Third140Leaves30
import NineSeparatedSubsetSums.Adaptive144Third140Leaves6
import NineSeparatedSubsetSums.Adaptive144Third140Leaves10
import NineSeparatedSubsetSums.Adaptive144Third140Leaves23
import NineSeparatedSubsetSums.Adaptive144Third140Leaves24
import NineSeparatedSubsetSums.Adaptive144Third140Leaves31
import NineSeparatedSubsetSums.Adaptive144Third140Leaves51
import NineSeparatedSubsetSums.Adaptive144Third140Leaves37
import NineSeparatedSubsetSums.Adaptive144Third140Leaves20
import NineSeparatedSubsetSums.Adaptive144Third140Leaves27
import NineSeparatedSubsetSums.Adaptive144Third140Leaves26
import NineSeparatedSubsetSums.Adaptive144Third140Leaves3
import NineSeparatedSubsetSums.Adaptive144Third140Leaves36
import NineSeparatedSubsetSums.Adaptive144Third140Leaves45
import NineSeparatedSubsetSums.Adaptive144Third140Leaves33
import NineSeparatedSubsetSums.Adaptive144Third140Leaves29
import NineSeparatedSubsetSums.Adaptive144Third140Leaves9
import NineSeparatedSubsetSums.Adaptive144Third140Leaves14
import NineSeparatedSubsetSums.Adaptive144Third140Leaves5
import NineSeparatedSubsetSums.Adaptive144Third140Leaves61
import NineSeparatedSubsetSums.Adaptive144Third140Leaves60
import NineSeparatedSubsetSums.Adaptive144Third140Leaves16
import NineSeparatedSubsetSums.Adaptive144Third140Leaves18
import NineSeparatedSubsetSums.Adaptive144Third140Leaves4
import NineSeparatedSubsetSums.Adaptive144Third140Leaves40
import NineSeparatedSubsetSums.Adaptive144Third140Leaves44
import NineSeparatedSubsetSums.Adaptive144Third140Leaves12
import NineSeparatedSubsetSums.Adaptive144Third140Leaves13
import NineSeparatedSubsetSums.Adaptive144Third140Leaves0
import NineSeparatedSubsetSums.Adaptive144Third140Leaves22

namespace NineSeparatedSubsetSums

theorem adaptive144Third140Proof19 : runCachedNode 511 130381 Adaptive144Third140Node19 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130381 Adaptive144Third140Node19 = [104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 121, 122, 123, 125, 126, 127] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive144Third140Proof20
  · exact adaptive144Third140Proof21
  · exact adaptive144Third140Proof22
  · exact adaptive144Third140Proof23
  · exact adaptive144Third140Proof24
  · exact adaptive144Third140Proof25
  · exact adaptive144Third140Proof26
  · exact adaptive144Third140Proof27
  · exact adaptive144Third140Proof28
  · exact adaptive144Third140Proof29
  · exact adaptive144Third140Proof30
  · exact adaptive144Third140Proof31
  · exact adaptive144Third140Proof32
  · exact adaptive144Third140Proof33
  · exact adaptive144Third140Proof34
  · exact adaptive144Third140Proof35
  · exact adaptive144Third140Proof36
  · exact adaptive144Third140Proof37
  · exact adaptive144Third140Proof38
  · exact adaptive144Third140Proof39
  · exact adaptive144Third140Proof40
  · exact adaptive144Third140Proof41

#print axioms adaptive144Third140Proof19

theorem adaptive144Third140Proof42 : runCachedNode 511 130381 Adaptive144Third140Node42 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130381 Adaptive144Third140Node42 = [104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 122, 123, 124, 126, 127, 128] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive144Third140Proof43
  · exact adaptive144Third140Proof44
  · exact adaptive144Third140Proof45
  · exact adaptive144Third140Proof46
  · exact adaptive144Third140Proof47
  · exact adaptive144Third140Proof48
  · exact adaptive144Third140Proof49
  · exact adaptive144Third140Proof50
  · exact adaptive144Third140Proof51
  · exact adaptive144Third140Proof52
  · exact adaptive144Third140Proof53
  · exact adaptive144Third140Proof54
  · exact adaptive144Third140Proof55
  · exact adaptive144Third140Proof56
  · exact adaptive144Third140Proof57
  · exact adaptive144Third140Proof58
  · exact adaptive144Third140Proof59
  · exact adaptive144Third140Proof60
  · exact adaptive144Third140Proof61
  · exact adaptive144Third140Proof62
  · exact adaptive144Third140Proof63
  · exact adaptive144Third140Proof64
  · exact adaptive144Third140Proof65

#print axioms adaptive144Third140Proof42

theorem adaptive144Third140Proof66 : runCachedNode 511 130381 Adaptive144Third140Node66 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130381 Adaptive144Third140Node66 = [104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 123, 124, 125, 127, 128, 129] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive144Third140Proof67
  · exact adaptive144Third140Proof68
  · exact adaptive144Third140Proof69
  · exact adaptive144Third140Proof70
  · exact adaptive144Third140Proof71
  · exact adaptive144Third140Proof72
  · exact adaptive144Third140Proof73
  · exact adaptive144Third140Proof74
  · exact adaptive144Third140Proof75
  · exact adaptive144Third140Proof76
  · exact adaptive144Third140Proof77
  · exact adaptive144Third140Proof78
  · exact adaptive144Third140Proof79
  · exact adaptive144Third140Proof80
  · exact adaptive144Third140Proof81
  · exact adaptive144Third140Proof82
  · exact adaptive144Third140Proof83
  · exact adaptive144Third140Proof84
  · exact adaptive144Third140Proof85
  · exact adaptive144Third140Proof86
  · exact adaptive144Third140Proof87
  · exact adaptive144Third140Proof88
  · exact adaptive144Third140Proof89
  · exact adaptive144Third140Proof90

#print axioms adaptive144Third140Proof66

theorem adaptive144Third140Proof91 : runCachedNode 511 130381 Adaptive144Third140Node91 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130381 Adaptive144Third140Node91 = [103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 124, 125, 126, 128, 129, 130] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive144Third140Proof92
  · exact adaptive144Third140Proof93
  · exact adaptive144Third140Proof94
  · exact adaptive144Third140Proof95
  · exact adaptive144Third140Proof96
  · exact adaptive144Third140Proof97
  · exact adaptive144Third140Proof98
  · exact adaptive144Third140Proof99
  · exact adaptive144Third140Proof100
  · exact adaptive144Third140Proof101
  · exact adaptive144Third140Proof102
  · exact adaptive144Third140Proof103
  · exact adaptive144Third140Proof104
  · exact adaptive144Third140Proof105
  · exact adaptive144Third140Proof106
  · exact adaptive144Third140Proof107
  · exact adaptive144Third140Proof108
  · exact adaptive144Third140Proof109
  · exact adaptive144Third140Proof110
  · exact adaptive144Third140Proof111
  · exact adaptive144Third140Proof112
  · exact adaptive144Third140Proof113
  · exact adaptive144Third140Proof114
  · exact adaptive144Third140Proof115
  · exact adaptive144Third140Proof116
  · exact adaptive144Third140Proof117

#print axioms adaptive144Third140Proof91

theorem adaptive144Third140Proof144 : runCachedNode 511 130381 Adaptive144Third140Node144 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130381 Adaptive144Third140Node144 = [94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 111, 112, 113, 115, 116, 117, 119, 120, 121, 123, 125, 127, 129] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive144Third140Proof145
  · exact adaptive144Third140Proof146
  · exact adaptive144Third140Proof147
  · exact adaptive144Third140Proof148
  · exact adaptive144Third140Proof149
  · exact adaptive144Third140Proof150
  · exact adaptive144Third140Proof151
  · exact adaptive144Third140Proof152
  · exact adaptive144Third140Proof153
  · exact adaptive144Third140Proof154
  · exact adaptive144Third140Proof155
  · exact adaptive144Third140Proof156
  · exact adaptive144Third140Proof157
  · exact adaptive144Third140Proof158
  · exact adaptive144Third140Proof159
  · exact adaptive144Third140Proof160
  · exact adaptive144Third140Proof161
  · exact adaptive144Third140Proof162
  · exact adaptive144Third140Proof163
  · exact adaptive144Third140Proof164
  · exact adaptive144Third140Proof165
  · exact adaptive144Third140Proof166
  · exact adaptive144Third140Proof167
  · exact adaptive144Third140Proof168
  · exact adaptive144Third140Proof169
  · exact adaptive144Third140Proof170
  · exact adaptive144Third140Proof171
  · exact adaptive144Third140Proof172
  · exact adaptive144Third140Proof173

#print axioms adaptive144Third140Proof144

theorem adaptive144Third140Proof118 : runCachedNode 511 130381 Adaptive144Third140Node118 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130381 Adaptive144Third140Node118 = [103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 125, 126, 127, 129, 130, 131] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive144Third140Proof119
  · exact adaptive144Third140Proof120
  · exact adaptive144Third140Proof121
  · exact adaptive144Third140Proof122
  · exact adaptive144Third140Proof123
  · exact adaptive144Third140Proof124
  · exact adaptive144Third140Proof125
  · exact adaptive144Third140Proof126
  · exact adaptive144Third140Proof127
  · exact adaptive144Third140Proof128
  · exact adaptive144Third140Proof129
  · exact adaptive144Third140Proof130
  · exact adaptive144Third140Proof131
  · exact adaptive144Third140Proof132
  · exact adaptive144Third140Proof133
  · exact adaptive144Third140Proof134
  · exact adaptive144Third140Proof135
  · exact adaptive144Third140Proof136
  · exact adaptive144Third140Proof137
  · exact adaptive144Third140Proof138
  · exact adaptive144Third140Proof139
  · exact adaptive144Third140Proof140
  · exact adaptive144Third140Proof141
  · exact adaptive144Third140Proof142
  · exact adaptive144Third140Proof143
  · exact adaptive144Third140Proof144
  · exact adaptive144Third140Proof174

#print axioms adaptive144Third140Proof118

theorem adaptive144Third140Proof203 : runCachedNode 511 130381 Adaptive144Third140Node203 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130381 Adaptive144Third140Node203 = [93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 114, 115, 116, 118, 119, 120, 122, 123, 126, 127, 130, 131] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive144Third140Proof204
  · exact adaptive144Third140Proof205
  · exact adaptive144Third140Proof206
  · exact adaptive144Third140Proof207
  · exact adaptive144Third140Proof208
  · exact adaptive144Third140Proof209
  · exact adaptive144Third140Proof210
  · exact adaptive144Third140Proof211
  · exact adaptive144Third140Proof212
  · exact adaptive144Third140Proof213
  · exact adaptive144Third140Proof214
  · exact adaptive144Third140Proof215
  · exact adaptive144Third140Proof216
  · exact adaptive144Third140Proof217
  · exact adaptive144Third140Proof218
  · exact adaptive144Third140Proof219
  · exact adaptive144Third140Proof220
  · exact adaptive144Third140Proof221
  · exact adaptive144Third140Proof222
  · exact adaptive144Third140Proof223
  · exact adaptive144Third140Proof224
  · exact adaptive144Third140Proof225
  · exact adaptive144Third140Proof226
  · exact adaptive144Third140Proof227
  · exact adaptive144Third140Proof228
  · exact adaptive144Third140Proof229
  · exact adaptive144Third140Proof230
  · exact adaptive144Third140Proof231
  · exact adaptive144Third140Proof232
  · exact adaptive144Third140Proof233
  · exact adaptive144Third140Proof234
  · exact adaptive144Third140Proof235

#print axioms adaptive144Third140Proof203

theorem adaptive144Third140Proof175 : runCachedNode 511 130381 Adaptive144Third140Node175 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130381 Adaptive144Third140Node175 = [103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 126, 127, 128, 130, 131, 132] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive144Third140Proof176
  · exact adaptive144Third140Proof177
  · exact adaptive144Third140Proof178
  · exact adaptive144Third140Proof179
  · exact adaptive144Third140Proof180
  · exact adaptive144Third140Proof181
  · exact adaptive144Third140Proof182
  · exact adaptive144Third140Proof183
  · exact adaptive144Third140Proof184
  · exact adaptive144Third140Proof185
  · exact adaptive144Third140Proof186
  · exact adaptive144Third140Proof187
  · exact adaptive144Third140Proof188
  · exact adaptive144Third140Proof189
  · exact adaptive144Third140Proof190
  · exact adaptive144Third140Proof191
  · exact adaptive144Third140Proof192
  · exact adaptive144Third140Proof193
  · exact adaptive144Third140Proof194
  · exact adaptive144Third140Proof195
  · exact adaptive144Third140Proof196
  · exact adaptive144Third140Proof197
  · exact adaptive144Third140Proof198
  · exact adaptive144Third140Proof199
  · exact adaptive144Third140Proof200
  · exact adaptive144Third140Proof201
  · exact adaptive144Third140Proof202
  · exact adaptive144Third140Proof203

#print axioms adaptive144Third140Proof175

end NineSeparatedSubsetSums
