import NineSeparatedSubsetSums.Adaptive144Third141State
import NineSeparatedSubsetSums.Adaptive144Third141Leaves12
import NineSeparatedSubsetSums.Adaptive144Third141Leaves39
import NineSeparatedSubsetSums.Adaptive144Third141Leaves21
import NineSeparatedSubsetSums.Adaptive144Third141Leaves6
import NineSeparatedSubsetSums.Adaptive144Third141Leaves23
import NineSeparatedSubsetSums.Adaptive144Third141Leaves16
import NineSeparatedSubsetSums.Adaptive144Third141Leaves8
import NineSeparatedSubsetSums.Adaptive144Third141Leaves37
import NineSeparatedSubsetSums.Adaptive144Third141Leaves0
import NineSeparatedSubsetSums.Adaptive144Third141Leaves36
import NineSeparatedSubsetSums.Adaptive144Third141Leaves35
import NineSeparatedSubsetSums.Adaptive144Third141Leaves34
import NineSeparatedSubsetSums.Adaptive144Third141Leaves32
import NineSeparatedSubsetSums.Adaptive144Third141Leaves3
import NineSeparatedSubsetSums.Adaptive144Third141Leaves31
import NineSeparatedSubsetSums.Adaptive144Third141Leaves30
import NineSeparatedSubsetSums.Adaptive144Third141Leaves28
import NineSeparatedSubsetSums.Adaptive144Third141Leaves29
import NineSeparatedSubsetSums.Adaptive144Third141Leaves26
import NineSeparatedSubsetSums.Adaptive144Third141Leaves24
import NineSeparatedSubsetSums.Adaptive144Third141Leaves14
import NineSeparatedSubsetSums.Adaptive144Third141Leaves38
import NineSeparatedSubsetSums.Adaptive144Third141Leaves17
import NineSeparatedSubsetSums.Adaptive144Third141Leaves20
import NineSeparatedSubsetSums.Adaptive144Third141Leaves5
import NineSeparatedSubsetSums.Adaptive144Third141Leaves33
import NineSeparatedSubsetSums.Adaptive144Third141Leaves18
import NineSeparatedSubsetSums.Adaptive144Third141Leaves27
import NineSeparatedSubsetSums.Adaptive144Third141Leaves19
import NineSeparatedSubsetSums.Adaptive144Third141Leaves10
import NineSeparatedSubsetSums.Adaptive144Third141Leaves15
import NineSeparatedSubsetSums.Adaptive144Third141Leaves25
import NineSeparatedSubsetSums.Adaptive144Third141Leaves22
import NineSeparatedSubsetSums.Adaptive144Third141Leaves7
import NineSeparatedSubsetSums.Adaptive144Third141Leaves13
import NineSeparatedSubsetSums.Adaptive144Third141Leaves11
import NineSeparatedSubsetSums.Adaptive144Third141Leaves1
import NineSeparatedSubsetSums.Adaptive144Third141Leaves40
import NineSeparatedSubsetSums.Adaptive144Third141Leaves2

namespace NineSeparatedSubsetSums

theorem adaptive144Third141Proof24 : runCachedNode 511 130584 Adaptive144Third141Node24 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130584 Adaptive144Third141Node24 = [103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 126, 127, 130, 131] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive144Third141Proof25
  · exact adaptive144Third141Proof26
  · exact adaptive144Third141Proof27
  · exact adaptive144Third141Proof28
  · exact adaptive144Third141Proof29
  · exact adaptive144Third141Proof30
  · exact adaptive144Third141Proof31
  · exact adaptive144Third141Proof32
  · exact adaptive144Third141Proof33
  · exact adaptive144Third141Proof34
  · exact adaptive144Third141Proof35
  · exact adaptive144Third141Proof36
  · exact adaptive144Third141Proof37
  · exact adaptive144Third141Proof38
  · exact adaptive144Third141Proof39
  · exact adaptive144Third141Proof40
  · exact adaptive144Third141Proof41
  · exact adaptive144Third141Proof42
  · exact adaptive144Third141Proof43
  · exact adaptive144Third141Proof44
  · exact adaptive144Third141Proof45
  · exact adaptive144Third141Proof46
  · exact adaptive144Third141Proof47
  · exact adaptive144Third141Proof48
  · exact adaptive144Third141Proof49
  · exact adaptive144Third141Proof50

#print axioms adaptive144Third141Proof24

theorem adaptive144Third141Proof51 : runCachedNode 511 130584 Adaptive144Third141Node51 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130584 Adaptive144Third141Node51 = [103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 127, 128, 131, 132] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive144Third141Proof52
  · exact adaptive144Third141Proof53
  · exact adaptive144Third141Proof54
  · exact adaptive144Third141Proof55
  · exact adaptive144Third141Proof56
  · exact adaptive144Third141Proof57
  · exact adaptive144Third141Proof58
  · exact adaptive144Third141Proof59
  · exact adaptive144Third141Proof60
  · exact adaptive144Third141Proof61
  · exact adaptive144Third141Proof62
  · exact adaptive144Third141Proof63
  · exact adaptive144Third141Proof64
  · exact adaptive144Third141Proof65
  · exact adaptive144Third141Proof66
  · exact adaptive144Third141Proof67
  · exact adaptive144Third141Proof68
  · exact adaptive144Third141Proof69
  · exact adaptive144Third141Proof70
  · exact adaptive144Third141Proof71
  · exact adaptive144Third141Proof72
  · exact adaptive144Third141Proof73
  · exact adaptive144Third141Proof74
  · exact adaptive144Third141Proof75
  · exact adaptive144Third141Proof76
  · exact adaptive144Third141Proof77
  · exact adaptive144Third141Proof78

#print axioms adaptive144Third141Proof51

theorem adaptive144Third141Proof79 : runCachedNode 511 130584 Adaptive144Third141Node79 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130584 Adaptive144Third141Node79 = [103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 128, 129, 132, 133] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive144Third141Proof80
  · exact adaptive144Third141Proof81
  · exact adaptive144Third141Proof82
  · exact adaptive144Third141Proof83
  · exact adaptive144Third141Proof84
  · exact adaptive144Third141Proof85
  · exact adaptive144Third141Proof86
  · exact adaptive144Third141Proof87
  · exact adaptive144Third141Proof88
  · exact adaptive144Third141Proof89
  · exact adaptive144Third141Proof90
  · exact adaptive144Third141Proof91
  · exact adaptive144Third141Proof92
  · exact adaptive144Third141Proof93
  · exact adaptive144Third141Proof94
  · exact adaptive144Third141Proof95
  · exact adaptive144Third141Proof96
  · exact adaptive144Third141Proof97
  · exact adaptive144Third141Proof98
  · exact adaptive144Third141Proof99
  · exact adaptive144Third141Proof100
  · exact adaptive144Third141Proof101
  · exact adaptive144Third141Proof102
  · exact adaptive144Third141Proof103
  · exact adaptive144Third141Proof104
  · exact adaptive144Third141Proof105
  · exact adaptive144Third141Proof106
  · exact adaptive144Third141Proof107

#print axioms adaptive144Third141Proof79

theorem adaptive144Third141Proof108 : runCachedNode 511 130584 Adaptive144Third141Node108 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130584 Adaptive144Third141Node108 = [102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 129, 130, 133, 134] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive144Third141Proof109
  · exact adaptive144Third141Proof110
  · exact adaptive144Third141Proof111
  · exact adaptive144Third141Proof112
  · exact adaptive144Third141Proof113
  · exact adaptive144Third141Proof114
  · exact adaptive144Third141Proof115
  · exact adaptive144Third141Proof116
  · exact adaptive144Third141Proof117
  · exact adaptive144Third141Proof118
  · exact adaptive144Third141Proof119
  · exact adaptive144Third141Proof120
  · exact adaptive144Third141Proof121
  · exact adaptive144Third141Proof122
  · exact adaptive144Third141Proof123
  · exact adaptive144Third141Proof124
  · exact adaptive144Third141Proof125
  · exact adaptive144Third141Proof126
  · exact adaptive144Third141Proof127
  · exact adaptive144Third141Proof128
  · exact adaptive144Third141Proof129
  · exact adaptive144Third141Proof130
  · exact adaptive144Third141Proof131
  · exact adaptive144Third141Proof132
  · exact adaptive144Third141Proof133
  · exact adaptive144Third141Proof134
  · exact adaptive144Third141Proof135
  · exact adaptive144Third141Proof136
  · exact adaptive144Third141Proof137
  · exact adaptive144Third141Proof138

#print axioms adaptive144Third141Proof108

theorem adaptive144Third141Proof139 : runCachedNode 511 130584 Adaptive144Third141Node139 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130584 Adaptive144Third141Node139 = [102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 130, 131, 134, 135] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive144Third141Proof140
  · exact adaptive144Third141Proof141
  · exact adaptive144Third141Proof142
  · exact adaptive144Third141Proof143
  · exact adaptive144Third141Proof144
  · exact adaptive144Third141Proof145
  · exact adaptive144Third141Proof146
  · exact adaptive144Third141Proof147
  · exact adaptive144Third141Proof148
  · exact adaptive144Third141Proof149
  · exact adaptive144Third141Proof150
  · exact adaptive144Third141Proof151
  · exact adaptive144Third141Proof152
  · exact adaptive144Third141Proof153
  · exact adaptive144Third141Proof154
  · exact adaptive144Third141Proof155
  · exact adaptive144Third141Proof156
  · exact adaptive144Third141Proof157
  · exact adaptive144Third141Proof158
  · exact adaptive144Third141Proof159
  · exact adaptive144Third141Proof160
  · exact adaptive144Third141Proof161
  · exact adaptive144Third141Proof162
  · exact adaptive144Third141Proof163
  · exact adaptive144Third141Proof164
  · exact adaptive144Third141Proof165
  · exact adaptive144Third141Proof166
  · exact adaptive144Third141Proof167
  · exact adaptive144Third141Proof168
  · exact adaptive144Third141Proof169
  · exact adaptive144Third141Proof170

#print axioms adaptive144Third141Proof139

theorem adaptive144Third141Proof171 : runCachedNode 511 130584 Adaptive144Third141Node171 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130584 Adaptive144Third141Node171 = [102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 132, 133, 136] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive144Third141Proof172
  · exact adaptive144Third141Proof173
  · exact adaptive144Third141Proof174
  · exact adaptive144Third141Proof175
  · exact adaptive144Third141Proof176
  · exact adaptive144Third141Proof177
  · exact adaptive144Third141Proof178
  · exact adaptive144Third141Proof179
  · exact adaptive144Third141Proof180
  · exact adaptive144Third141Proof181
  · exact adaptive144Third141Proof182
  · exact adaptive144Third141Proof183
  · exact adaptive144Third141Proof184
  · exact adaptive144Third141Proof185
  · exact adaptive144Third141Proof186
  · exact adaptive144Third141Proof187
  · exact adaptive144Third141Proof188
  · exact adaptive144Third141Proof189
  · exact adaptive144Third141Proof190
  · exact adaptive144Third141Proof191
  · exact adaptive144Third141Proof192
  · exact adaptive144Third141Proof193
  · exact adaptive144Third141Proof194
  · exact adaptive144Third141Proof195
  · exact adaptive144Third141Proof196
  · exact adaptive144Third141Proof197
  · exact adaptive144Third141Proof198
  · exact adaptive144Third141Proof199
  · exact adaptive144Third141Proof200
  · exact adaptive144Third141Proof201
  · exact adaptive144Third141Proof202
  · exact adaptive144Third141Proof203

#print axioms adaptive144Third141Proof171

theorem adaptive144Third141Proof238 : runCachedNode 511 130584 Adaptive144Third141Node238 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130584 Adaptive144Third141Node238 = [88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 127, 128, 130] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive144Third141Proof239
  · exact adaptive144Third141Proof240
  · exact adaptive144Third141Proof241
  · exact adaptive144Third141Proof242
  · exact adaptive144Third141Proof243
  · exact adaptive144Third141Proof244
  · exact adaptive144Third141Proof245
  · exact adaptive144Third141Proof246
  · exact adaptive144Third141Proof247
  · exact adaptive144Third141Proof248
  · exact adaptive144Third141Proof249
  · exact adaptive144Third141Proof250
  · exact adaptive144Third141Proof251
  · exact adaptive144Third141Proof252
  · exact adaptive144Third141Proof253
  · exact adaptive144Third141Proof254
  · exact adaptive144Third141Proof255
  · exact adaptive144Third141Proof256
  · exact adaptive144Third141Proof257
  · exact adaptive144Third141Proof258
  · exact adaptive144Third141Proof259
  · exact adaptive144Third141Proof260
  · exact adaptive144Third141Proof261
  · exact adaptive144Third141Proof262
  · exact adaptive144Third141Proof263
  · exact adaptive144Third141Proof264
  · exact adaptive144Third141Proof265
  · exact adaptive144Third141Proof266
  · exact adaptive144Third141Proof267
  · exact adaptive144Third141Proof268
  · exact adaptive144Third141Proof269
  · exact adaptive144Third141Proof270
  · exact adaptive144Third141Proof271
  · exact adaptive144Third141Proof272
  · exact adaptive144Third141Proof273
  · exact adaptive144Third141Proof274
  · exact adaptive144Third141Proof275
  · exact adaptive144Third141Proof276
  · exact adaptive144Third141Proof277
  · exact adaptive144Third141Proof278
  · exact adaptive144Third141Proof279

#print axioms adaptive144Third141Proof238

theorem adaptive144Third141Proof204 : runCachedNode 511 130584 Adaptive144Third141Node204 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130584 Adaptive144Third141Node204 = [101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 133, 134, 138] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive144Third141Proof205
  · exact adaptive144Third141Proof206
  · exact adaptive144Third141Proof207
  · exact adaptive144Third141Proof208
  · exact adaptive144Third141Proof209
  · exact adaptive144Third141Proof210
  · exact adaptive144Third141Proof211
  · exact adaptive144Third141Proof212
  · exact adaptive144Third141Proof213
  · exact adaptive144Third141Proof214
  · exact adaptive144Third141Proof215
  · exact adaptive144Third141Proof216
  · exact adaptive144Third141Proof217
  · exact adaptive144Third141Proof218
  · exact adaptive144Third141Proof219
  · exact adaptive144Third141Proof220
  · exact adaptive144Third141Proof221
  · exact adaptive144Third141Proof222
  · exact adaptive144Third141Proof223
  · exact adaptive144Third141Proof224
  · exact adaptive144Third141Proof225
  · exact adaptive144Third141Proof226
  · exact adaptive144Third141Proof227
  · exact adaptive144Third141Proof228
  · exact adaptive144Third141Proof229
  · exact adaptive144Third141Proof230
  · exact adaptive144Third141Proof231
  · exact adaptive144Third141Proof232
  · exact adaptive144Third141Proof233
  · exact adaptive144Third141Proof234
  · exact adaptive144Third141Proof235
  · exact adaptive144Third141Proof236
  · exact adaptive144Third141Proof237
  · exact adaptive144Third141Proof238

#print axioms adaptive144Third141Proof204

end NineSeparatedSubsetSums
