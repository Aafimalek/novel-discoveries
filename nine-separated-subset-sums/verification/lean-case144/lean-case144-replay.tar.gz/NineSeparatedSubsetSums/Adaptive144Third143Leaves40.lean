import NineSeparatedSubsetSums.Adaptive144Third143State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third143Proof484 : runCachedNode 511 130885 Adaptive144Third143Node484 = false := by
  decide +kernel

#print axioms adaptive144Third143Proof484

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third143Proof294 : runCachedNode 511 130885 Adaptive144Third143Node294 = false := by
  decide +kernel

#print axioms adaptive144Third143Proof294

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third143Proof558 : runCachedNode 511 130885 Adaptive144Third143Node558 = false := by
  decide +kernel

#print axioms adaptive144Third143Proof558

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third143Proof639 : runCachedNode 511 130885 Adaptive144Third143Node639 = false := by
  decide +kernel

#print axioms adaptive144Third143Proof639

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third143Proof99 : runCachedNode 511 130885 Adaptive144Third143Node99 = false := by
  decide +kernel

#print axioms adaptive144Third143Proof99

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third143Proof364 : runCachedNode 511 130885 Adaptive144Third143Node364 = false := by
  decide +kernel

#print axioms adaptive144Third143Proof364

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third143Proof365 : runCachedNode 511 130885 Adaptive144Third143Node365 = false := by
  decide +kernel

#print axioms adaptive144Third143Proof365

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third143Proof72 : runCachedNode 511 130885 Adaptive144Third143Node72 = false := by
  decide +kernel

#print axioms adaptive144Third143Proof72

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third143Proof318 : runCachedNode 511 130885 Adaptive144Third143Node318 = false := by
  decide +kernel

#print axioms adaptive144Third143Proof318

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third143Proof450 : runCachedNode 511 130885 Adaptive144Third143Node450 = false := by
  decide +kernel

#print axioms adaptive144Third143Proof450

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third143Proof123 : runCachedNode 511 130885 Adaptive144Third143Node123 = false := by
  decide +kernel

#print axioms adaptive144Third143Proof123

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third143Proof121 : runCachedNode 511 130885 Adaptive144Third143Node121 = false := by
  decide +kernel

#print axioms adaptive144Third143Proof121

end NineSeparatedSubsetSums
