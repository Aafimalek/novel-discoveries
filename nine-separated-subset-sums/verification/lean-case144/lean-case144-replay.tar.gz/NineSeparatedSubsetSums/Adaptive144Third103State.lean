import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive144Third103Node0 : CachedSearchNode :=
  ⟨4, 102, computeCenteredMask [148,144,103], 395, 53249⟩

end NineSeparatedSubsetSums
