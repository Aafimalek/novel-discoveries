import NineSeparatedSubsetSums.Adaptive144Third143State
import NineSeparatedSubsetSums.Adaptive144Third143Leaves57
import NineSeparatedSubsetSums.Adaptive144Third143Leaves55
import NineSeparatedSubsetSums.Adaptive144Third143Leaves53
import NineSeparatedSubsetSums.Adaptive144Third143Leaves52
import NineSeparatedSubsetSums.Adaptive144Third143Leaves51
import NineSeparatedSubsetSums.Adaptive144Third143Leaves50
import NineSeparatedSubsetSums.Adaptive144Third143Leaves49
import NineSeparatedSubsetSums.Adaptive144Third143Leaves47
import NineSeparatedSubsetSums.Adaptive144Third143Leaves46
import NineSeparatedSubsetSums.Adaptive144Third143Leaves44
import NineSeparatedSubsetSums.Adaptive144Third143Leaves43
import NineSeparatedSubsetSums.Adaptive144Third143Leaves41
import NineSeparatedSubsetSums.Adaptive144Third143Leaves40
import NineSeparatedSubsetSums.Adaptive144Third143Leaves42
import NineSeparatedSubsetSums.Adaptive144Third143Leaves39
import NineSeparatedSubsetSums.Adaptive144Third143Leaves38
import NineSeparatedSubsetSums.Adaptive144Third143Leaves16
import NineSeparatedSubsetSums.Adaptive144Third143Leaves37
import NineSeparatedSubsetSums.Adaptive144Third143Leaves1
import NineSeparatedSubsetSums.Adaptive144Third143Leaves34
import NineSeparatedSubsetSums.Adaptive144Third143Leaves30
import NineSeparatedSubsetSums.Adaptive144Third143Leaves26
import NineSeparatedSubsetSums.Adaptive144Third143Leaves25
import NineSeparatedSubsetSums.Adaptive144Third143Leaves20
import NineSeparatedSubsetSums.Adaptive144Third143Leaves19
import NineSeparatedSubsetSums.Adaptive144Third143Leaves17
import NineSeparatedSubsetSums.Adaptive144Third143Leaves13
import NineSeparatedSubsetSums.Adaptive144Third143Leaves10
import NineSeparatedSubsetSums.Adaptive144Third143Leaves56
import NineSeparatedSubsetSums.Adaptive144Third143Leaves54
import NineSeparatedSubsetSums.Adaptive144Third143Leaves48
import NineSeparatedSubsetSums.Adaptive144Third143Leaves45
import NineSeparatedSubsetSums.Adaptive144Third143Leaves35
import NineSeparatedSubsetSums.Adaptive144Third143Leaves33
import NineSeparatedSubsetSums.Adaptive144Third143Leaves18
import NineSeparatedSubsetSums.Adaptive144Third143Leaves27
import NineSeparatedSubsetSums.Adaptive144Third143Leaves28
import NineSeparatedSubsetSums.Adaptive144Third143Leaves21
import NineSeparatedSubsetSums.Adaptive144Third143Leaves15
import NineSeparatedSubsetSums.Adaptive144Third143Leaves8
import NineSeparatedSubsetSums.Adaptive144Third143Leaves5
import NineSeparatedSubsetSums.Adaptive144Third143Joins1
import NineSeparatedSubsetSums.Adaptive144Third143Leaves2
import NineSeparatedSubsetSums.Adaptive144Third143Leaves6
import NineSeparatedSubsetSums.Adaptive144Third143Leaves3
import NineSeparatedSubsetSums.Adaptive144Third143Leaves7
import NineSeparatedSubsetSums.Adaptive144Third143Leaves29
import NineSeparatedSubsetSums.Adaptive144Third143Leaves22
import NineSeparatedSubsetSums.Adaptive144Third143Leaves14
import NineSeparatedSubsetSums.Adaptive144Third143Leaves9
import NineSeparatedSubsetSums.Adaptive144Third143Joins0

namespace NineSeparatedSubsetSums

theorem adaptive144Third143Proof617 : runCachedNode 511 130885 Adaptive144Third143Node617 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130885 Adaptive144Third143Node617 = [86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 132] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive144Third143Proof618
  · exact adaptive144Third143Proof619
  · exact adaptive144Third143Proof620
  · exact adaptive144Third143Proof621
  · exact adaptive144Third143Proof622
  · exact adaptive144Third143Proof623
  · exact adaptive144Third143Proof624
  · exact adaptive144Third143Proof625
  · exact adaptive144Third143Proof626
  · exact adaptive144Third143Proof627
  · exact adaptive144Third143Proof628
  · exact adaptive144Third143Proof629
  · exact adaptive144Third143Proof630
  · exact adaptive144Third143Proof631
  · exact adaptive144Third143Proof632
  · exact adaptive144Third143Proof633
  · exact adaptive144Third143Proof634
  · exact adaptive144Third143Proof635
  · exact adaptive144Third143Proof636
  · exact adaptive144Third143Proof637
  · exact adaptive144Third143Proof638
  · exact adaptive144Third143Proof639
  · exact adaptive144Third143Proof640
  · exact adaptive144Third143Proof641
  · exact adaptive144Third143Proof642
  · exact adaptive144Third143Proof643
  · exact adaptive144Third143Proof644
  · exact adaptive144Third143Proof645
  · exact adaptive144Third143Proof646
  · exact adaptive144Third143Proof647
  · exact adaptive144Third143Proof648
  · exact adaptive144Third143Proof649
  · exact adaptive144Third143Proof650
  · exact adaptive144Third143Proof651
  · exact adaptive144Third143Proof652
  · exact adaptive144Third143Proof653
  · exact adaptive144Third143Proof654
  · exact adaptive144Third143Proof655
  · exact adaptive144Third143Proof656
  · exact adaptive144Third143Proof657
  · exact adaptive144Third143Proof658
  · exact adaptive144Third143Proof659
  · exact adaptive144Third143Proof660
  · exact adaptive144Third143Proof661
  · exact adaptive144Third143Proof662
  · exact adaptive144Third143Proof663
  · exact adaptive144Third143Proof664

#print axioms adaptive144Third143Proof617

theorem adaptive144Third143Proof537 : runCachedNode 511 130885 Adaptive144Third143Node537 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130885 Adaptive144Third143Node537 = [100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 132, 133, 134, 135, 136, 140] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive144Third143Proof538
  · exact adaptive144Third143Proof539
  · exact adaptive144Third143Proof540
  · exact adaptive144Third143Proof541
  · exact adaptive144Third143Proof542
  · exact adaptive144Third143Proof543
  · exact adaptive144Third143Proof544
  · exact adaptive144Third143Proof545
  · exact adaptive144Third143Proof546
  · exact adaptive144Third143Proof547
  · exact adaptive144Third143Proof548
  · exact adaptive144Third143Proof549
  · exact adaptive144Third143Proof550
  · exact adaptive144Third143Proof551
  · exact adaptive144Third143Proof552
  · exact adaptive144Third143Proof553
  · exact adaptive144Third143Proof554
  · exact adaptive144Third143Proof555
  · exact adaptive144Third143Proof556
  · exact adaptive144Third143Proof557
  · exact adaptive144Third143Proof558
  · exact adaptive144Third143Proof559
  · exact adaptive144Third143Proof560
  · exact adaptive144Third143Proof561
  · exact adaptive144Third143Proof562
  · exact adaptive144Third143Proof563
  · exact adaptive144Third143Proof564
  · exact adaptive144Third143Proof565
  · exact adaptive144Third143Proof566
  · exact adaptive144Third143Proof567
  · exact adaptive144Third143Proof568
  · exact adaptive144Third143Proof569
  · exact adaptive144Third143Proof570
  · exact adaptive144Third143Proof571
  · exact adaptive144Third143Proof572
  · exact adaptive144Third143Proof573
  · exact adaptive144Third143Proof574
  · exact adaptive144Third143Proof617

#print axioms adaptive144Third143Proof537

theorem adaptive144Third143Proof0 : runCachedNode 511 130885 Adaptive144Third143Node0 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130885 Adaptive144Third143Node0 = [109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 132, 133, 134, 135, 136, 137, 138, 140, 141, 142] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive144Third143Proof1
  · exact adaptive144Third143Proof2
  · exact adaptive144Third143Proof3
  · exact adaptive144Third143Proof4
  · exact adaptive144Third143Proof5
  · exact adaptive144Third143Proof6
  · exact adaptive144Third143Proof7
  · exact adaptive144Third143Proof8
  · exact adaptive144Third143Proof9
  · exact adaptive144Third143Proof10
  · exact adaptive144Third143Proof11
  · exact adaptive144Third143Proof12
  · exact adaptive144Third143Proof13
  · exact adaptive144Third143Proof14
  · exact adaptive144Third143Proof15
  · exact adaptive144Third143Proof16
  · exact adaptive144Third143Proof17
  · exact adaptive144Third143Proof18
  · exact adaptive144Third143Proof19
  · exact adaptive144Third143Proof20
  · exact adaptive144Third143Proof21
  · exact adaptive144Third143Proof22
  · exact adaptive144Third143Proof23
  · exact adaptive144Third143Proof49
  · exact adaptive144Third143Proof76
  · exact adaptive144Third143Proof104
  · exact adaptive144Third143Proof134
  · exact adaptive144Third143Proof165
  · exact adaptive144Third143Proof197
  · exact adaptive144Third143Proof230
  · exact adaptive144Third143Proof300
  · exact adaptive144Third143Proof456
  · exact adaptive144Third143Proof537

#print axioms adaptive144Third143Proof0

end NineSeparatedSubsetSums
