import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive144Third124Node0 : CachedSearchNode :=
  ⟨4, 123, computeCenteredMask [148,144,124], 416, 58016⟩

end NineSeparatedSubsetSums
