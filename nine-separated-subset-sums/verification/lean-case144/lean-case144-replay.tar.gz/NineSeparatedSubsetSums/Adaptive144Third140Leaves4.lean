import NineSeparatedSubsetSums.Adaptive144Third140State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof174 : runCachedNode 511 130381 Adaptive144Third140Node174 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof174

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof165 : runCachedNode 511 130381 Adaptive144Third140Node165 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof165

end NineSeparatedSubsetSums
