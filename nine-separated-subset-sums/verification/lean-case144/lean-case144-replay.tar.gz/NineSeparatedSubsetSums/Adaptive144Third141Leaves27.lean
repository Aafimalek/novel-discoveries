import NineSeparatedSubsetSums.Adaptive144Third141State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third141Proof75 : runCachedNode 511 130584 Adaptive144Third141Node75 = false := by
  decide +kernel

#print axioms adaptive144Third141Proof75

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third141Proof303 : runCachedNode 511 130584 Adaptive144Third141Node303 = false := by
  decide +kernel

#print axioms adaptive144Third141Proof303

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third141Proof71 : runCachedNode 511 130584 Adaptive144Third141Node71 = false := by
  decide +kernel

#print axioms adaptive144Third141Proof71

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third141Proof77 : runCachedNode 511 130584 Adaptive144Third141Node77 = false := by
  decide +kernel

#print axioms adaptive144Third141Proof77

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third141Proof389 : runCachedNode 511 130584 Adaptive144Third141Node389 = false := by
  decide +kernel

#print axioms adaptive144Third141Proof389

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third141Proof230 : runCachedNode 511 130584 Adaptive144Third141Node230 = false := by
  decide +kernel

#print axioms adaptive144Third141Proof230

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third141Proof13 : runCachedNode 511 130584 Adaptive144Third141Node13 = false := by
  decide +kernel

#print axioms adaptive144Third141Proof13

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third141Proof428 : runCachedNode 511 130584 Adaptive144Third141Node428 = false := by
  decide +kernel

#print axioms adaptive144Third141Proof428

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third141Proof140 : runCachedNode 511 130584 Adaptive144Third141Node140 = false := by
  decide +kernel

#print axioms adaptive144Third141Proof140

end NineSeparatedSubsetSums
