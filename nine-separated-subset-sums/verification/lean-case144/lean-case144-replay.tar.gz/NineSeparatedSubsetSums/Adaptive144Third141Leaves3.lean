import NineSeparatedSubsetSums.Adaptive144Third141State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third141Proof237 : runCachedNode 511 130584 Adaptive144Third141Node237 = false := by
  decide +kernel

#print axioms adaptive144Third141Proof237

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third141Proof43 : runCachedNode 511 130584 Adaptive144Third141Node43 = false := by
  decide +kernel

#print axioms adaptive144Third141Proof43

end NineSeparatedSubsetSums
