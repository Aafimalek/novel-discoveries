import NineSeparatedSubsetSums.Adaptive144Third140State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof318 : runCachedNode 511 130381 Adaptive144Third140Node318 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof318

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof233 : runCachedNode 511 130381 Adaptive144Third140Node233 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof233

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof717 : runCachedNode 511 130381 Adaptive144Third140Node717 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof717

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof193 : runCachedNode 511 130381 Adaptive144Third140Node193 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof193

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof521 : runCachedNode 511 130381 Adaptive144Third140Node521 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof521

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof107 : runCachedNode 511 130381 Adaptive144Third140Node107 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof107

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof59 : runCachedNode 511 130381 Adaptive144Third140Node59 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof59

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof32 : runCachedNode 511 130381 Adaptive144Third140Node32 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof32

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof319 : runCachedNode 511 130381 Adaptive144Third140Node319 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof319

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof516 : runCachedNode 511 130381 Adaptive144Third140Node516 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof516

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof592 : runCachedNode 511 130381 Adaptive144Third140Node592 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof592

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof674 : runCachedNode 511 130381 Adaptive144Third140Node674 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof674

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof705 : runCachedNode 511 130381 Adaptive144Third140Node705 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof705

end NineSeparatedSubsetSums
