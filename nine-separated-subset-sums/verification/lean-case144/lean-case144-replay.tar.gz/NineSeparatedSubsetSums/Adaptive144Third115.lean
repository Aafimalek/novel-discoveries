import NineSeparatedSubsetSums.Adaptive144Third115Joins0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint144Checked

namespace NineSeparatedSubsetSums


theorem adaptive144Third115 : NoDescendingTailAfterThird 144 115 :=
  noDescendingThirdTail_of_cached 144 115 112221 (fun t ht nd => max148_second144_fourPoint_moment_bound (115::t) (by simp [ht]) nd) adaptive144Third115Proof0

#print axioms adaptive144Third115

end NineSeparatedSubsetSums
