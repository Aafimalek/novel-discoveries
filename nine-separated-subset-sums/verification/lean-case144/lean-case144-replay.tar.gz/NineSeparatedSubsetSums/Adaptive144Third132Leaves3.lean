import NineSeparatedSubsetSums.Adaptive144Third132State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third132Proof17 : runCachedNode 511 129155 Adaptive144Third132Node17 = false := by
  decide +kernel

#print axioms adaptive144Third132Proof17

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third132Proof15 : runCachedNode 511 129155 Adaptive144Third132Node15 = false := by
  decide +kernel

#print axioms adaptive144Third132Proof15

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third132Proof16 : runCachedNode 511 129155 Adaptive144Third132Node16 = false := by
  decide +kernel

#print axioms adaptive144Third132Proof16

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third132Proof4 : runCachedNode 511 129155 Adaptive144Third132Node4 = false := by
  decide +kernel

#print axioms adaptive144Third132Proof4

end NineSeparatedSubsetSums
