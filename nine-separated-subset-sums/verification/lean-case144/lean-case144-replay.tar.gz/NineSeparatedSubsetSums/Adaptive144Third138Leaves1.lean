import NineSeparatedSubsetSums.Adaptive144Third138State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third138Proof151 : runCachedNode 511 130126 Adaptive144Third138Node151 = false := by
  decide +kernel

#print axioms adaptive144Third138Proof151

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third138Proof44 : runCachedNode 511 130126 Adaptive144Third138Node44 = false := by
  decide +kernel

#print axioms adaptive144Third138Proof44

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third138Proof22 : runCachedNode 511 130126 Adaptive144Third138Node22 = false := by
  decide +kernel

#print axioms adaptive144Third138Proof22

end NineSeparatedSubsetSums
