import NineSeparatedSubsetSums.Adaptive144Third140State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof681 : runCachedNode 511 130381 Adaptive144Third140Node681 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof681

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof682 : runCachedNode 511 130381 Adaptive144Third140Node682 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof682

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof683 : runCachedNode 511 130381 Adaptive144Third140Node683 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof683

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof684 : runCachedNode 511 130381 Adaptive144Third140Node684 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof684

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof685 : runCachedNode 511 130381 Adaptive144Third140Node685 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof685

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof686 : runCachedNode 511 130381 Adaptive144Third140Node686 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof686

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof687 : runCachedNode 511 130381 Adaptive144Third140Node687 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof687

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof688 : runCachedNode 511 130381 Adaptive144Third140Node688 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof688

end NineSeparatedSubsetSums
