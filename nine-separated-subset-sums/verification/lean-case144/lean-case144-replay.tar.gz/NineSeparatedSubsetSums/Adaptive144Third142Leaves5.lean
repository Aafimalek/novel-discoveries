import NineSeparatedSubsetSums.Adaptive144Third142State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third142Proof167 : runCachedNode 511 130737 Adaptive144Third142Node167 = false := by
  decide +kernel

#print axioms adaptive144Third142Proof167

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third142Proof138 : runCachedNode 511 130737 Adaptive144Third142Node138 = false := by
  decide +kernel

#print axioms adaptive144Third142Proof138

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third142Proof55 : runCachedNode 511 130737 Adaptive144Third142Node55 = false := by
  decide +kernel

#print axioms adaptive144Third142Proof55

end NineSeparatedSubsetSums
