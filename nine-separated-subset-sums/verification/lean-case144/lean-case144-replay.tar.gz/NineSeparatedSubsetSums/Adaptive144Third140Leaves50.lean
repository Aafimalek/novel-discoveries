import NineSeparatedSubsetSums.Adaptive144Third140State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof420 : runCachedNode 511 130381 Adaptive144Third140Node420 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof420

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof591 : runCachedNode 511 130381 Adaptive144Third140Node591 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof591

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof352 : runCachedNode 511 130381 Adaptive144Third140Node352 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof352

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof590 : runCachedNode 511 130381 Adaptive144Third140Node590 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof590

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof633 : runCachedNode 511 130381 Adaptive144Third140Node633 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof633

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof635 : runCachedNode 511 130381 Adaptive144Third140Node635 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof635

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof421 : runCachedNode 511 130381 Adaptive144Third140Node421 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof421

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof514 : runCachedNode 511 130381 Adaptive144Third140Node514 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof514

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof379 : runCachedNode 511 130381 Adaptive144Third140Node379 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof379

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof460 : runCachedNode 511 130381 Adaptive144Third140Node460 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof460

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof250 : runCachedNode 511 130381 Adaptive144Third140Node250 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof250

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof130 : runCachedNode 511 130381 Adaptive144Third140Node130 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof130

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof167 : runCachedNode 511 130381 Adaptive144Third140Node167 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof167

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof226 : runCachedNode 511 130381 Adaptive144Third140Node226 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof226

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof252 : runCachedNode 511 130381 Adaptive144Third140Node252 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof252

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof227 : runCachedNode 511 130381 Adaptive144Third140Node227 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof227

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof354 : runCachedNode 511 130381 Adaptive144Third140Node354 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof354

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof459 : runCachedNode 511 130381 Adaptive144Third140Node459 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof459

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof27 : runCachedNode 511 130381 Adaptive144Third140Node27 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof27

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof434 : runCachedNode 511 130381 Adaptive144Third140Node434 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof434

end NineSeparatedSubsetSums
