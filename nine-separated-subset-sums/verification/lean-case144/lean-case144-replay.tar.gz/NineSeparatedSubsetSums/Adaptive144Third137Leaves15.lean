import NineSeparatedSubsetSums.Adaptive144Third137State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third137Proof126 : runCachedNode 511 129993 Adaptive144Third137Node126 = false := by
  decide +kernel

#print axioms adaptive144Third137Proof126

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third137Proof127 : runCachedNode 511 129993 Adaptive144Third137Node127 = false := by
  decide +kernel

#print axioms adaptive144Third137Proof127

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third137Proof158 : runCachedNode 511 129993 Adaptive144Third137Node158 = false := by
  decide +kernel

#print axioms adaptive144Third137Proof158

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third137Proof159 : runCachedNode 511 129993 Adaptive144Third137Node159 = false := by
  decide +kernel

#print axioms adaptive144Third137Proof159

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third137Proof46 : runCachedNode 511 129993 Adaptive144Third137Node46 = false := by
  decide +kernel

#print axioms adaptive144Third137Proof46

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third137Proof71 : runCachedNode 511 129993 Adaptive144Third137Node71 = false := by
  decide +kernel

#print axioms adaptive144Third137Proof71

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third137Proof98 : runCachedNode 511 129993 Adaptive144Third137Node98 = false := by
  decide +kernel

#print axioms adaptive144Third137Proof98

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third137Proof99 : runCachedNode 511 129993 Adaptive144Third137Node99 = false := by
  decide +kernel

#print axioms adaptive144Third137Proof99

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third137Proof125 : runCachedNode 511 129993 Adaptive144Third137Node125 = false := by
  decide +kernel

#print axioms adaptive144Third137Proof125

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third137Proof154 : runCachedNode 511 129993 Adaptive144Third137Node154 = false := by
  decide +kernel

#print axioms adaptive144Third137Proof154

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third137Proof155 : runCachedNode 511 129993 Adaptive144Third137Node155 = false := by
  decide +kernel

#print axioms adaptive144Third137Proof155

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third137Proof156 : runCachedNode 511 129993 Adaptive144Third137Node156 = false := by
  decide +kernel

#print axioms adaptive144Third137Proof156

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third137Proof157 : runCachedNode 511 129993 Adaptive144Third137Node157 = false := by
  decide +kernel

#print axioms adaptive144Third137Proof157

end NineSeparatedSubsetSums
