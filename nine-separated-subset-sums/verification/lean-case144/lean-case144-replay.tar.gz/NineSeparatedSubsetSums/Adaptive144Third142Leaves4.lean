import NineSeparatedSubsetSums.Adaptive144Third142State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third142Proof301 : runCachedNode 511 130737 Adaptive144Third142Node301 = false := by
  decide +kernel

#print axioms adaptive144Third142Proof301

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third142Proof15 : runCachedNode 511 130737 Adaptive144Third142Node15 = false := by
  decide +kernel

#print axioms adaptive144Third142Proof15

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third142Proof28 : runCachedNode 511 130737 Adaptive144Third142Node28 = false := by
  decide +kernel

#print axioms adaptive144Third142Proof28

end NineSeparatedSubsetSums
