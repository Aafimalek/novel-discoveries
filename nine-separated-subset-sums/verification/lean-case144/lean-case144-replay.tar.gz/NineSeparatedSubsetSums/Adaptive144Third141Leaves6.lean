import NineSeparatedSubsetSums.Adaptive144Third141State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third141Proof138 : runCachedNode 511 130584 Adaptive144Third141Node138 = false := by
  decide +kernel

#print axioms adaptive144Third141Proof138

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third141Proof278 : runCachedNode 511 130584 Adaptive144Third141Node278 = false := by
  decide +kernel

#print axioms adaptive144Third141Proof278

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third141Proof30 : runCachedNode 511 130584 Adaptive144Third141Node30 = false := by
  decide +kernel

#print axioms adaptive144Third141Proof30

end NineSeparatedSubsetSums
