import NineSeparatedSubsetSums.Adaptive144Third136State
import NineSeparatedSubsetSums.Adaptive144Third136Leaves0
import NineSeparatedSubsetSums.Adaptive144Third136Leaves4
import NineSeparatedSubsetSums.Adaptive144Third136Leaves6
import NineSeparatedSubsetSums.Adaptive144Third136Leaves10
import NineSeparatedSubsetSums.Adaptive144Third136Leaves1
import NineSeparatedSubsetSums.Adaptive144Third136Leaves8
import NineSeparatedSubsetSums.Adaptive144Third136Leaves9
import NineSeparatedSubsetSums.Adaptive144Third136Leaves7
import NineSeparatedSubsetSums.Adaptive144Third136Leaves3
import NineSeparatedSubsetSums.Adaptive144Third136Leaves5
import NineSeparatedSubsetSums.Adaptive144Third136Leaves2

namespace NineSeparatedSubsetSums

theorem adaptive144Third136Proof23 : runCachedNode 511 129800 Adaptive144Third136Node23 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 129800 Adaptive144Third136Node23 = [103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 122, 123, 124, 126, 127, 128, 130, 131] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive144Third136Proof24
  · exact adaptive144Third136Proof25
  · exact adaptive144Third136Proof26
  · exact adaptive144Third136Proof27
  · exact adaptive144Third136Proof28
  · exact adaptive144Third136Proof29
  · exact adaptive144Third136Proof30
  · exact adaptive144Third136Proof31
  · exact adaptive144Third136Proof32
  · exact adaptive144Third136Proof33
  · exact adaptive144Third136Proof34
  · exact adaptive144Third136Proof35
  · exact adaptive144Third136Proof36
  · exact adaptive144Third136Proof37
  · exact adaptive144Third136Proof38
  · exact adaptive144Third136Proof39
  · exact adaptive144Third136Proof40
  · exact adaptive144Third136Proof41
  · exact adaptive144Third136Proof42
  · exact adaptive144Third136Proof43
  · exact adaptive144Third136Proof44
  · exact adaptive144Third136Proof45
  · exact adaptive144Third136Proof46
  · exact adaptive144Third136Proof47
  · exact adaptive144Third136Proof48
  · exact adaptive144Third136Proof49

#print axioms adaptive144Third136Proof23

theorem adaptive144Third136Proof50 : runCachedNode 511 129800 Adaptive144Third136Node50 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 129800 Adaptive144Third136Node50 = [103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 123, 124, 125, 127, 128, 129, 131, 133] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive144Third136Proof51
  · exact adaptive144Third136Proof52
  · exact adaptive144Third136Proof53
  · exact adaptive144Third136Proof54
  · exact adaptive144Third136Proof55
  · exact adaptive144Third136Proof56
  · exact adaptive144Third136Proof57
  · exact adaptive144Third136Proof58
  · exact adaptive144Third136Proof59
  · exact adaptive144Third136Proof60
  · exact adaptive144Third136Proof61
  · exact adaptive144Third136Proof62
  · exact adaptive144Third136Proof63
  · exact adaptive144Third136Proof64
  · exact adaptive144Third136Proof65
  · exact adaptive144Third136Proof66
  · exact adaptive144Third136Proof67
  · exact adaptive144Third136Proof68
  · exact adaptive144Third136Proof69
  · exact adaptive144Third136Proof70
  · exact adaptive144Third136Proof71
  · exact adaptive144Third136Proof72
  · exact adaptive144Third136Proof73
  · exact adaptive144Third136Proof74
  · exact adaptive144Third136Proof75
  · exact adaptive144Third136Proof76
  · exact adaptive144Third136Proof77

#print axioms adaptive144Third136Proof50

theorem adaptive144Third136Proof78 : runCachedNode 511 129800 Adaptive144Third136Node78 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 129800 Adaptive144Third136Node78 = [103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 124, 125, 126, 128, 129, 130, 133, 134] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive144Third136Proof79
  · exact adaptive144Third136Proof80
  · exact adaptive144Third136Proof81
  · exact adaptive144Third136Proof82
  · exact adaptive144Third136Proof83
  · exact adaptive144Third136Proof84
  · exact adaptive144Third136Proof85
  · exact adaptive144Third136Proof86
  · exact adaptive144Third136Proof87
  · exact adaptive144Third136Proof88
  · exact adaptive144Third136Proof89
  · exact adaptive144Third136Proof90
  · exact adaptive144Third136Proof91
  · exact adaptive144Third136Proof92
  · exact adaptive144Third136Proof93
  · exact adaptive144Third136Proof94
  · exact adaptive144Third136Proof95
  · exact adaptive144Third136Proof96
  · exact adaptive144Third136Proof97
  · exact adaptive144Third136Proof98
  · exact adaptive144Third136Proof99
  · exact adaptive144Third136Proof100
  · exact adaptive144Third136Proof101
  · exact adaptive144Third136Proof102
  · exact adaptive144Third136Proof103
  · exact adaptive144Third136Proof104
  · exact adaptive144Third136Proof105
  · exact adaptive144Third136Proof106

#print axioms adaptive144Third136Proof78

theorem adaptive144Third136Proof0 : runCachedNode 511 129800 Adaptive144Third136Node0 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 129800 Adaptive144Third136Node0 = [110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 133, 134, 135] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive144Third136Proof1
  · exact adaptive144Third136Proof2
  · exact adaptive144Third136Proof3
  · exact adaptive144Third136Proof4
  · exact adaptive144Third136Proof5
  · exact adaptive144Third136Proof6
  · exact adaptive144Third136Proof7
  · exact adaptive144Third136Proof8
  · exact adaptive144Third136Proof9
  · exact adaptive144Third136Proof10
  · exact adaptive144Third136Proof11
  · exact adaptive144Third136Proof12
  · exact adaptive144Third136Proof13
  · exact adaptive144Third136Proof14
  · exact adaptive144Third136Proof15
  · exact adaptive144Third136Proof16
  · exact adaptive144Third136Proof17
  · exact adaptive144Third136Proof18
  · exact adaptive144Third136Proof19
  · exact adaptive144Third136Proof20
  · exact adaptive144Third136Proof21
  · exact adaptive144Third136Proof22
  · exact adaptive144Third136Proof23
  · exact adaptive144Third136Proof50
  · exact adaptive144Third136Proof78

#print axioms adaptive144Third136Proof0

end NineSeparatedSubsetSums
