import NineSeparatedSubsetSums.Adaptive144Third141State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third141Proof21 : runCachedNode 511 130584 Adaptive144Third141Node21 = false := by
  decide +kernel

#print axioms adaptive144Third141Proof21

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third141Proof197 : runCachedNode 511 130584 Adaptive144Third141Node197 = false := by
  decide +kernel

#print axioms adaptive144Third141Proof197

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third141Proof33 : runCachedNode 511 130584 Adaptive144Third141Node33 = false := by
  decide +kernel

#print axioms adaptive144Third141Proof33

end NineSeparatedSubsetSums
