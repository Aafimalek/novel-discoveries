import NineSeparatedSubsetSums.Adaptive144Third139State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third139Proof247 : runCachedNode 511 130274 Adaptive144Third139Node247 = false := by
  decide +kernel

#print axioms adaptive144Third139Proof247

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third139Proof69 : runCachedNode 511 130274 Adaptive144Third139Node69 = false := by
  decide +kernel

#print axioms adaptive144Third139Proof69

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third139Proof107 : runCachedNode 511 130274 Adaptive144Third139Node107 = false := by
  decide +kernel

#print axioms adaptive144Third139Proof107

end NineSeparatedSubsetSums
