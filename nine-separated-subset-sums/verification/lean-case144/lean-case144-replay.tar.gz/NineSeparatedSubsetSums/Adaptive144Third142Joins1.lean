import NineSeparatedSubsetSums.Adaptive144Third142State
import NineSeparatedSubsetSums.Adaptive144Third142Leaves53
import NineSeparatedSubsetSums.Adaptive144Third142Leaves52
import NineSeparatedSubsetSums.Adaptive144Third142Leaves51
import NineSeparatedSubsetSums.Adaptive144Third142Leaves50
import NineSeparatedSubsetSums.Adaptive144Third142Leaves49
import NineSeparatedSubsetSums.Adaptive144Third142Leaves48
import NineSeparatedSubsetSums.Adaptive144Third142Leaves47
import NineSeparatedSubsetSums.Adaptive144Third142Leaves45
import NineSeparatedSubsetSums.Adaptive144Third142Leaves46
import NineSeparatedSubsetSums.Adaptive144Third142Leaves42
import NineSeparatedSubsetSums.Adaptive144Third142Leaves38
import NineSeparatedSubsetSums.Adaptive144Third142Leaves43
import NineSeparatedSubsetSums.Adaptive144Third142Leaves35
import NineSeparatedSubsetSums.Adaptive144Third142Leaves28
import NineSeparatedSubsetSums.Adaptive144Third142Leaves31
import NineSeparatedSubsetSums.Adaptive144Third142Leaves3
import NineSeparatedSubsetSums.Adaptive144Third142Leaves36
import NineSeparatedSubsetSums.Adaptive144Third142Leaves23
import NineSeparatedSubsetSums.Adaptive144Third142Leaves34
import NineSeparatedSubsetSums.Adaptive144Third142Leaves13
import NineSeparatedSubsetSums.Adaptive144Third142Leaves30
import NineSeparatedSubsetSums.Adaptive144Third142Leaves29
import NineSeparatedSubsetSums.Adaptive144Third142Leaves40
import NineSeparatedSubsetSums.Adaptive144Third142Leaves32
import NineSeparatedSubsetSums.Adaptive144Third142Leaves27
import NineSeparatedSubsetSums.Adaptive144Third142Leaves39
import NineSeparatedSubsetSums.Adaptive144Third142Leaves41
import NineSeparatedSubsetSums.Adaptive144Third142Leaves24
import NineSeparatedSubsetSums.Adaptive144Third142Leaves21
import NineSeparatedSubsetSums.Adaptive144Third142Leaves17
import NineSeparatedSubsetSums.Adaptive144Third142Leaves26
import NineSeparatedSubsetSums.Adaptive144Third142Leaves22
import NineSeparatedSubsetSums.Adaptive144Third142Leaves20
import NineSeparatedSubsetSums.Adaptive144Third142Leaves54
import NineSeparatedSubsetSums.Adaptive144Third142Leaves10
import NineSeparatedSubsetSums.Adaptive144Third142Leaves33
import NineSeparatedSubsetSums.Adaptive144Third142Leaves18
import NineSeparatedSubsetSums.Adaptive144Third142Leaves44
import NineSeparatedSubsetSums.Adaptive144Third142Leaves7
import NineSeparatedSubsetSums.Adaptive144Third142Leaves37
import NineSeparatedSubsetSums.Adaptive144Third142Leaves0
import NineSeparatedSubsetSums.Adaptive144Third142Leaves25
import NineSeparatedSubsetSums.Adaptive144Third142Leaves19
import NineSeparatedSubsetSums.Adaptive144Third142Leaves55
import NineSeparatedSubsetSums.Adaptive144Third142Leaves14
import NineSeparatedSubsetSums.Adaptive144Third142Leaves16
import NineSeparatedSubsetSums.Adaptive144Third142Leaves12
import NineSeparatedSubsetSums.Adaptive144Third142Leaves1
import NineSeparatedSubsetSums.Adaptive144Third142Leaves9
import NineSeparatedSubsetSums.Adaptive144Third142Joins0
import NineSeparatedSubsetSums.Adaptive144Third142Leaves4

namespace NineSeparatedSubsetSums

theorem adaptive144Third142Proof302 : runCachedNode 511 130737 Adaptive144Third142Node302 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130737 Adaptive144Third142Node302 = [91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 121, 123, 125, 127, 129] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive144Third142Proof303
  · exact adaptive144Third142Proof304
  · exact adaptive144Third142Proof305
  · exact adaptive144Third142Proof306
  · exact adaptive144Third142Proof307
  · exact adaptive144Third142Proof308
  · exact adaptive144Third142Proof309
  · exact adaptive144Third142Proof310
  · exact adaptive144Third142Proof311
  · exact adaptive144Third142Proof312
  · exact adaptive144Third142Proof313
  · exact adaptive144Third142Proof314
  · exact adaptive144Third142Proof315
  · exact adaptive144Third142Proof316
  · exact adaptive144Third142Proof317
  · exact adaptive144Third142Proof318
  · exact adaptive144Third142Proof319
  · exact adaptive144Third142Proof320
  · exact adaptive144Third142Proof321
  · exact adaptive144Third142Proof322
  · exact adaptive144Third142Proof323
  · exact adaptive144Third142Proof324
  · exact adaptive144Third142Proof325
  · exact adaptive144Third142Proof326
  · exact adaptive144Third142Proof327
  · exact adaptive144Third142Proof328
  · exact adaptive144Third142Proof329
  · exact adaptive144Third142Proof330
  · exact adaptive144Third142Proof331
  · exact adaptive144Third142Proof332
  · exact adaptive144Third142Proof333
  · exact adaptive144Third142Proof334
  · exact adaptive144Third142Proof335
  · exact adaptive144Third142Proof336

#print axioms adaptive144Third142Proof302

theorem adaptive144Third142Proof337 : runCachedNode 511 130737 Adaptive144Third142Node337 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130737 Adaptive144Third142Node337 = [90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 122, 124, 126, 128, 130] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive144Third142Proof338
  · exact adaptive144Third142Proof339
  · exact adaptive144Third142Proof340
  · exact adaptive144Third142Proof341
  · exact adaptive144Third142Proof342
  · exact adaptive144Third142Proof343
  · exact adaptive144Third142Proof344
  · exact adaptive144Third142Proof345
  · exact adaptive144Third142Proof346
  · exact adaptive144Third142Proof347
  · exact adaptive144Third142Proof348
  · exact adaptive144Third142Proof349
  · exact adaptive144Third142Proof350
  · exact adaptive144Third142Proof351
  · exact adaptive144Third142Proof352
  · exact adaptive144Third142Proof353
  · exact adaptive144Third142Proof354
  · exact adaptive144Third142Proof355
  · exact adaptive144Third142Proof356
  · exact adaptive144Third142Proof357
  · exact adaptive144Third142Proof358
  · exact adaptive144Third142Proof359
  · exact adaptive144Third142Proof360
  · exact adaptive144Third142Proof361
  · exact adaptive144Third142Proof362
  · exact adaptive144Third142Proof363
  · exact adaptive144Third142Proof364
  · exact adaptive144Third142Proof365
  · exact adaptive144Third142Proof366
  · exact adaptive144Third142Proof367
  · exact adaptive144Third142Proof368
  · exact adaptive144Third142Proof369
  · exact adaptive144Third142Proof370
  · exact adaptive144Third142Proof371
  · exact adaptive144Third142Proof372
  · exact adaptive144Third142Proof373

#print axioms adaptive144Third142Proof337

theorem adaptive144Third142Proof374 : runCachedNode 511 130737 Adaptive144Third142Node374 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130737 Adaptive144Third142Node374 = [90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 123, 125, 127, 129, 131] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive144Third142Proof375
  · exact adaptive144Third142Proof376
  · exact adaptive144Third142Proof377
  · exact adaptive144Third142Proof378
  · exact adaptive144Third142Proof379
  · exact adaptive144Third142Proof380
  · exact adaptive144Third142Proof381
  · exact adaptive144Third142Proof382
  · exact adaptive144Third142Proof383
  · exact adaptive144Third142Proof384
  · exact adaptive144Third142Proof385
  · exact adaptive144Third142Proof386
  · exact adaptive144Third142Proof387
  · exact adaptive144Third142Proof388
  · exact adaptive144Third142Proof389
  · exact adaptive144Third142Proof390
  · exact adaptive144Third142Proof391
  · exact adaptive144Third142Proof392
  · exact adaptive144Third142Proof393
  · exact adaptive144Third142Proof394
  · exact adaptive144Third142Proof395
  · exact adaptive144Third142Proof396
  · exact adaptive144Third142Proof397
  · exact adaptive144Third142Proof398
  · exact adaptive144Third142Proof399
  · exact adaptive144Third142Proof400
  · exact adaptive144Third142Proof401
  · exact adaptive144Third142Proof402
  · exact adaptive144Third142Proof403
  · exact adaptive144Third142Proof404
  · exact adaptive144Third142Proof405
  · exact adaptive144Third142Proof406
  · exact adaptive144Third142Proof407
  · exact adaptive144Third142Proof408
  · exact adaptive144Third142Proof409
  · exact adaptive144Third142Proof410
  · exact adaptive144Third142Proof411

#print axioms adaptive144Third142Proof374

theorem adaptive144Third142Proof412 : runCachedNode 511 130737 Adaptive144Third142Node412 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130737 Adaptive144Third142Node412 = [90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 124, 126, 128, 130, 132] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive144Third142Proof413
  · exact adaptive144Third142Proof414
  · exact adaptive144Third142Proof415
  · exact adaptive144Third142Proof416
  · exact adaptive144Third142Proof417
  · exact adaptive144Third142Proof418
  · exact adaptive144Third142Proof419
  · exact adaptive144Third142Proof420
  · exact adaptive144Third142Proof421
  · exact adaptive144Third142Proof422
  · exact adaptive144Third142Proof423
  · exact adaptive144Third142Proof424
  · exact adaptive144Third142Proof425
  · exact adaptive144Third142Proof426
  · exact adaptive144Third142Proof427
  · exact adaptive144Third142Proof428
  · exact adaptive144Third142Proof429
  · exact adaptive144Third142Proof430
  · exact adaptive144Third142Proof431
  · exact adaptive144Third142Proof432
  · exact adaptive144Third142Proof433
  · exact adaptive144Third142Proof434
  · exact adaptive144Third142Proof435
  · exact adaptive144Third142Proof436
  · exact adaptive144Third142Proof437
  · exact adaptive144Third142Proof438
  · exact adaptive144Third142Proof439
  · exact adaptive144Third142Proof440
  · exact adaptive144Third142Proof441
  · exact adaptive144Third142Proof442
  · exact adaptive144Third142Proof443
  · exact adaptive144Third142Proof444
  · exact adaptive144Third142Proof445
  · exact adaptive144Third142Proof446
  · exact adaptive144Third142Proof447
  · exact adaptive144Third142Proof448
  · exact adaptive144Third142Proof449
  · exact adaptive144Third142Proof450

#print axioms adaptive144Third142Proof412

theorem adaptive144Third142Proof451 : runCachedNode 511 130737 Adaptive144Third142Node451 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130737 Adaptive144Third142Node451 = [89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 126, 128, 130, 132] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive144Third142Proof452
  · exact adaptive144Third142Proof453
  · exact adaptive144Third142Proof454
  · exact adaptive144Third142Proof455
  · exact adaptive144Third142Proof456
  · exact adaptive144Third142Proof457
  · exact adaptive144Third142Proof458
  · exact adaptive144Third142Proof459
  · exact adaptive144Third142Proof460
  · exact adaptive144Third142Proof461
  · exact adaptive144Third142Proof462
  · exact adaptive144Third142Proof463
  · exact adaptive144Third142Proof464
  · exact adaptive144Third142Proof465
  · exact adaptive144Third142Proof466
  · exact adaptive144Third142Proof467
  · exact adaptive144Third142Proof468
  · exact adaptive144Third142Proof469
  · exact adaptive144Third142Proof470
  · exact adaptive144Third142Proof471
  · exact adaptive144Third142Proof472
  · exact adaptive144Third142Proof473
  · exact adaptive144Third142Proof474
  · exact adaptive144Third142Proof475
  · exact adaptive144Third142Proof476
  · exact adaptive144Third142Proof477
  · exact adaptive144Third142Proof478
  · exact adaptive144Third142Proof479
  · exact adaptive144Third142Proof480
  · exact adaptive144Third142Proof481
  · exact adaptive144Third142Proof482
  · exact adaptive144Third142Proof483
  · exact adaptive144Third142Proof484
  · exact adaptive144Third142Proof485
  · exact adaptive144Third142Proof486
  · exact adaptive144Third142Proof487
  · exact adaptive144Third142Proof488
  · exact adaptive144Third142Proof489
  · exact adaptive144Third142Proof490
  · exact adaptive144Third142Proof491

#print axioms adaptive144Third142Proof451

theorem adaptive144Third142Proof492 : runCachedNode 511 130737 Adaptive144Third142Node492 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130737 Adaptive144Third142Node492 = [88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 128, 130, 132] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive144Third142Proof493
  · exact adaptive144Third142Proof494
  · exact adaptive144Third142Proof495
  · exact adaptive144Third142Proof496
  · exact adaptive144Third142Proof497
  · exact adaptive144Third142Proof498
  · exact adaptive144Third142Proof499
  · exact adaptive144Third142Proof500
  · exact adaptive144Third142Proof501
  · exact adaptive144Third142Proof502
  · exact adaptive144Third142Proof503
  · exact adaptive144Third142Proof504
  · exact adaptive144Third142Proof505
  · exact adaptive144Third142Proof506
  · exact adaptive144Third142Proof507
  · exact adaptive144Third142Proof508
  · exact adaptive144Third142Proof509
  · exact adaptive144Third142Proof510
  · exact adaptive144Third142Proof511
  · exact adaptive144Third142Proof512
  · exact adaptive144Third142Proof513
  · exact adaptive144Third142Proof514
  · exact adaptive144Third142Proof515
  · exact adaptive144Third142Proof516
  · exact adaptive144Third142Proof517
  · exact adaptive144Third142Proof518
  · exact adaptive144Third142Proof519
  · exact adaptive144Third142Proof520
  · exact adaptive144Third142Proof521
  · exact adaptive144Third142Proof522
  · exact adaptive144Third142Proof523
  · exact adaptive144Third142Proof524
  · exact adaptive144Third142Proof525
  · exact adaptive144Third142Proof526
  · exact adaptive144Third142Proof527
  · exact adaptive144Third142Proof528
  · exact adaptive144Third142Proof529
  · exact adaptive144Third142Proof530
  · exact adaptive144Third142Proof531
  · exact adaptive144Third142Proof532
  · exact adaptive144Third142Proof533
  · exact adaptive144Third142Proof534

#print axioms adaptive144Third142Proof492

theorem adaptive144Third142Proof535 : runCachedNode 511 130737 Adaptive144Third142Node535 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130737 Adaptive144Third142Node535 = [87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 130, 132] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive144Third142Proof536
  · exact adaptive144Third142Proof537
  · exact adaptive144Third142Proof538
  · exact adaptive144Third142Proof539
  · exact adaptive144Third142Proof540
  · exact adaptive144Third142Proof541
  · exact adaptive144Third142Proof542
  · exact adaptive144Third142Proof543
  · exact adaptive144Third142Proof544
  · exact adaptive144Third142Proof545
  · exact adaptive144Third142Proof546
  · exact adaptive144Third142Proof547
  · exact adaptive144Third142Proof548
  · exact adaptive144Third142Proof549
  · exact adaptive144Third142Proof550
  · exact adaptive144Third142Proof551
  · exact adaptive144Third142Proof552
  · exact adaptive144Third142Proof553
  · exact adaptive144Third142Proof554
  · exact adaptive144Third142Proof555
  · exact adaptive144Third142Proof556
  · exact adaptive144Third142Proof557
  · exact adaptive144Third142Proof558
  · exact adaptive144Third142Proof559
  · exact adaptive144Third142Proof560
  · exact adaptive144Third142Proof561
  · exact adaptive144Third142Proof562
  · exact adaptive144Third142Proof563
  · exact adaptive144Third142Proof564
  · exact adaptive144Third142Proof565
  · exact adaptive144Third142Proof566
  · exact adaptive144Third142Proof567
  · exact adaptive144Third142Proof568
  · exact adaptive144Third142Proof569
  · exact adaptive144Third142Proof570
  · exact adaptive144Third142Proof571
  · exact adaptive144Third142Proof572
  · exact adaptive144Third142Proof573
  · exact adaptive144Third142Proof574
  · exact adaptive144Third142Proof575
  · exact adaptive144Third142Proof576
  · exact adaptive144Third142Proof577
  · exact adaptive144Third142Proof578
  · exact adaptive144Third142Proof579

#print axioms adaptive144Third142Proof535

theorem adaptive144Third142Proof240 : runCachedNode 511 130737 Adaptive144Third142Node240 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130737 Adaptive144Third142Node240 = [101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 132, 133, 135, 137, 139] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive144Third142Proof241
  · exact adaptive144Third142Proof242
  · exact adaptive144Third142Proof243
  · exact adaptive144Third142Proof244
  · exact adaptive144Third142Proof245
  · exact adaptive144Third142Proof246
  · exact adaptive144Third142Proof247
  · exact adaptive144Third142Proof248
  · exact adaptive144Third142Proof249
  · exact adaptive144Third142Proof250
  · exact adaptive144Third142Proof251
  · exact adaptive144Third142Proof252
  · exact adaptive144Third142Proof253
  · exact adaptive144Third142Proof254
  · exact adaptive144Third142Proof255
  · exact adaptive144Third142Proof256
  · exact adaptive144Third142Proof257
  · exact adaptive144Third142Proof258
  · exact adaptive144Third142Proof259
  · exact adaptive144Third142Proof260
  · exact adaptive144Third142Proof261
  · exact adaptive144Third142Proof262
  · exact adaptive144Third142Proof263
  · exact adaptive144Third142Proof264
  · exact adaptive144Third142Proof265
  · exact adaptive144Third142Proof266
  · exact adaptive144Third142Proof267
  · exact adaptive144Third142Proof268
  · exact adaptive144Third142Proof301
  · exact adaptive144Third142Proof302
  · exact adaptive144Third142Proof337
  · exact adaptive144Third142Proof374
  · exact adaptive144Third142Proof412
  · exact adaptive144Third142Proof451
  · exact adaptive144Third142Proof492
  · exact adaptive144Third142Proof535

#print axioms adaptive144Third142Proof240

end NineSeparatedSubsetSums
