import NineSeparatedSubsetSums.Adaptive144Third137State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third137Proof117 : runCachedNode 511 129993 Adaptive144Third137Node117 = false := by
  decide +kernel

#print axioms adaptive144Third137Proof117

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third137Proof180 : runCachedNode 511 129993 Adaptive144Third137Node180 = false := by
  decide +kernel

#print axioms adaptive144Third137Proof180

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third137Proof67 : runCachedNode 511 129993 Adaptive144Third137Node67 = false := by
  decide +kernel

#print axioms adaptive144Third137Proof67

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third137Proof144 : runCachedNode 511 129993 Adaptive144Third137Node144 = false := by
  decide +kernel

#print axioms adaptive144Third137Proof144

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third137Proof121 : runCachedNode 511 129993 Adaptive144Third137Node121 = false := by
  decide +kernel

#print axioms adaptive144Third137Proof121

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third137Proof12 : runCachedNode 511 129993 Adaptive144Third137Node12 = false := by
  decide +kernel

#print axioms adaptive144Third137Proof12

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third137Proof92 : runCachedNode 511 129993 Adaptive144Third137Node92 = false := by
  decide +kernel

#print axioms adaptive144Third137Proof92

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third137Proof175 : runCachedNode 511 129993 Adaptive144Third137Node175 = false := by
  decide +kernel

#print axioms adaptive144Third137Proof175

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third137Proof41 : runCachedNode 511 129993 Adaptive144Third137Node41 = false := by
  decide +kernel

#print axioms adaptive144Third137Proof41

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third137Proof23 : runCachedNode 511 129993 Adaptive144Third137Node23 = false := by
  decide +kernel

#print axioms adaptive144Third137Proof23

end NineSeparatedSubsetSums
