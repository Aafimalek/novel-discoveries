import NineSeparatedSubsetSums.Adaptive144Third138State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third138Proof72 : runCachedNode 511 130126 Adaptive144Third138Node72 = false := by
  decide +kernel

#print axioms adaptive144Third138Proof72

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third138Proof73 : runCachedNode 511 130126 Adaptive144Third138Node73 = false := by
  decide +kernel

#print axioms adaptive144Third138Proof73

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third138Proof99 : runCachedNode 511 130126 Adaptive144Third138Node99 = false := by
  decide +kernel

#print axioms adaptive144Third138Proof99

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third138Proof100 : runCachedNode 511 130126 Adaptive144Third138Node100 = false := by
  decide +kernel

#print axioms adaptive144Third138Proof100

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third138Proof101 : runCachedNode 511 130126 Adaptive144Third138Node101 = false := by
  decide +kernel

#print axioms adaptive144Third138Proof101

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third138Proof128 : runCachedNode 511 130126 Adaptive144Third138Node128 = false := by
  decide +kernel

#print axioms adaptive144Third138Proof128

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third138Proof129 : runCachedNode 511 130126 Adaptive144Third138Node129 = false := by
  decide +kernel

#print axioms adaptive144Third138Proof129

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third138Proof156 : runCachedNode 511 130126 Adaptive144Third138Node156 = false := by
  decide +kernel

#print axioms adaptive144Third138Proof156

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third138Proof157 : runCachedNode 511 130126 Adaptive144Third138Node157 = false := by
  decide +kernel

#print axioms adaptive144Third138Proof157

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third138Proof126 : runCachedNode 511 130126 Adaptive144Third138Node126 = false := by
  decide +kernel

#print axioms adaptive144Third138Proof126

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third138Proof127 : runCachedNode 511 130126 Adaptive144Third138Node127 = false := by
  decide +kernel

#print axioms adaptive144Third138Proof127

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third138Proof154 : runCachedNode 511 130126 Adaptive144Third138Node154 = false := by
  decide +kernel

#print axioms adaptive144Third138Proof154

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third138Proof155 : runCachedNode 511 130126 Adaptive144Third138Node155 = false := by
  decide +kernel

#print axioms adaptive144Third138Proof155

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third138Proof186 : runCachedNode 511 130126 Adaptive144Third138Node186 = false := by
  decide +kernel

#print axioms adaptive144Third138Proof186

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third138Proof187 : runCachedNode 511 130126 Adaptive144Third138Node187 = false := by
  decide +kernel

#print axioms adaptive144Third138Proof187

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third138Proof188 : runCachedNode 511 130126 Adaptive144Third138Node188 = false := by
  decide +kernel

#print axioms adaptive144Third138Proof188

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third138Proof189 : runCachedNode 511 130126 Adaptive144Third138Node189 = false := by
  decide +kernel

#print axioms adaptive144Third138Proof189

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third138Proof190 : runCachedNode 511 130126 Adaptive144Third138Node190 = false := by
  decide +kernel

#print axioms adaptive144Third138Proof190

end NineSeparatedSubsetSums
