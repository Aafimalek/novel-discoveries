import NineSeparatedSubsetSums.Adaptive144Third140State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof135 : runCachedNode 511 130381 Adaptive144Third140Node135 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof135

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof597 : runCachedNode 511 130381 Adaptive144Third140Node597 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof597

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof527 : runCachedNode 511 130381 Adaptive144Third140Node527 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof527

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof485 : runCachedNode 511 130381 Adaptive144Third140Node485 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof485

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof385 : runCachedNode 511 130381 Adaptive144Third140Node385 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof385

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof598 : runCachedNode 511 130381 Adaptive144Third140Node598 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof598

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof33 : runCachedNode 511 130381 Adaptive144Third140Node33 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof33

end NineSeparatedSubsetSums
