import NineSeparatedSubsetSums.EightPointPackedGeometry
import NineSeparatedSubsetSums.EightPoint144_118PackedBudget0
import NineSeparatedSubsetSums.EightPoint144_118PackedAnchor0Part0
import NineSeparatedSubsetSums.EightPoint144_118PackedAnchor0Part1
import NineSeparatedSubsetSums.EightPoint144_118PackedAnchor0Part2
import NineSeparatedSubsetSums.EightPoint144_118PackedBudget1
import NineSeparatedSubsetSums.EightPoint144_118PackedAnchor1Part0
import NineSeparatedSubsetSums.EightPoint144_118PackedAnchor1Part1
import NineSeparatedSubsetSums.EightPoint144_118PackedAnchor1Part2

namespace NineSeparatedSubsetSums

private theorem packedOct144_118Anchor0 :
  ∀ j : Fin 495, ((j.val : Int)+144+118)%2=0 →
    2410228 ≤ FourPointNumeric.octPackedCharge 144 118 20 packedOct144_118_0 (j.val : Int) := by
  intro j hj
  let k := (j.val-0)/2
  have hk : k < 248 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+0 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint144_118PackedAnchor0Part0 z
    rwa [he,hrep] at ht
  by_cases h1 : k < 240
  · let z : Fin 120 := ⟨k-120, by omega⟩
    have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
    have ht := eightPoint144_118PackedAnchor0Part1 z
    rwa [he,hrep] at ht
  let z : Fin 8 := ⟨k-240, by omega⟩
  have he : (z.val : Int)+240 = k := by dsimp [z] <;> omega
  have ht := eightPoint144_118PackedAnchor0Part2 z
  rwa [he,hrep] at ht

private theorem packedOct144_118Anchor1 :
  ∀ j : Fin 495, ((j.val : Int)+144+118)%2=1 →
    2401228 ≤ FourPointNumeric.octPackedCharge 144 118 20 packedOct144_118_1 (j.val : Int) := by
  intro j hj
  let k := (j.val-1)/2
  have hk : k < 247 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+1 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint144_118PackedAnchor1Part0 z
    rwa [he,hrep] at ht
  by_cases h1 : k < 240
  · let z : Fin 120 := ⟨k-120, by omega⟩
    have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
    have ht := eightPoint144_118PackedAnchor1Part1 z
    rwa [he,hrep] at ht
  let z : Fin 7 := ⟨k-240, by omega⟩
  have he : (z.val : Int)+240 = k := by dsimp [z] <;> omega
  have ht := eightPoint144_118PackedAnchor1Part2 z
  rwa [he,hrep] at ht

def packedOctCertificate144_118_0 : EightPointCertificate 144 118 0 125868 :=
  eightPointCertificateOfPacked 144 118 0 125868 2410228 20 packedOct144_118_0 455 495
    (by decide +kernel) (by decide) packedOct144_118Anchor0
    (by rw [packedOct144_118_0_budget]; decide)

def packedOctCertificate144_118_1 : EightPointCertificate 144 118 1 125868 :=
  eightPointCertificateOfPacked 144 118 1 125868 2401228 20 packedOct144_118_1 456 495
    (by decide +kernel) (by decide) packedOct144_118Anchor1
    (by rw [packedOct144_118_1_budget]; decide)

theorem max148_second144_third118_eightPoint_moment_bound (tail : List ℕ) (len : tail.length=6)
    (distinct : (natSubsetSums (148::144::118::tail)).Nodup) :
    125868 ≤ ((148::144::118::tail).map (· ^ 2)).sum := by
  apply eightPointNatMomentLower 144 118 125868 tail len distinct
  intro p hp
  by_cases h : p=0
  · subst p
    exact packedOctCertificate144_118_0
  · have he : p=1 := hp.resolve_left h
    subst p
    exact packedOctCertificate144_118_1

#print axioms max148_second144_third118_eightPoint_moment_bound

end NineSeparatedSubsetSums
