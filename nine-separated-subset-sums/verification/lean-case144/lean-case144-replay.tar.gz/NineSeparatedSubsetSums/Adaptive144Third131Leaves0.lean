import NineSeparatedSubsetSums.Adaptive144Third131State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third131Proof20 : runCachedNode 511 129000 Adaptive144Third131Node20 = false := by
  decide +kernel

#print axioms adaptive144Third131Proof20

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third131Proof17 : runCachedNode 511 129000 Adaptive144Third131Node17 = false := by
  decide +kernel

#print axioms adaptive144Third131Proof17

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third131Proof9 : runCachedNode 511 129000 Adaptive144Third131Node9 = false := by
  decide +kernel

#print axioms adaptive144Third131Proof9

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third131Proof3 : runCachedNode 511 129000 Adaptive144Third131Node3 = false := by
  decide +kernel

#print axioms adaptive144Third131Proof3

end NineSeparatedSubsetSums
