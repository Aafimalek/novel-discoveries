import NineSeparatedSubsetSums.Adaptive144Third141State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third141Proof20 : runCachedNode 511 130584 Adaptive144Third141Node20 = false := by
  decide +kernel

#print axioms adaptive144Third141Proof20

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third141Proof308 : runCachedNode 511 130584 Adaptive144Third141Node308 = false := by
  decide +kernel

#print axioms adaptive144Third141Proof308

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third141Proof41 : runCachedNode 511 130584 Adaptive144Third141Node41 = false := by
  decide +kernel

#print axioms adaptive144Third141Proof41

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third141Proof25 : runCachedNode 511 130584 Adaptive144Third141Node25 = false := by
  decide +kernel

#print axioms adaptive144Third141Proof25

end NineSeparatedSubsetSums
