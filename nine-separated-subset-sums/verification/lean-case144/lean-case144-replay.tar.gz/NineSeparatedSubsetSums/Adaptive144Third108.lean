import NineSeparatedSubsetSums.Adaptive144Third108Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint144Checked

namespace NineSeparatedSubsetSums


theorem adaptive144Third108 : NoDescendingTailAfterThird 144 108 :=
  noDescendingThirdTail_of_cached 144 108 112221 (fun t ht nd => max148_second144_fourPoint_moment_bound (108::t) (by simp [ht]) nd) adaptive144Third108Proof0

#print axioms adaptive144Third108

end NineSeparatedSubsetSums
