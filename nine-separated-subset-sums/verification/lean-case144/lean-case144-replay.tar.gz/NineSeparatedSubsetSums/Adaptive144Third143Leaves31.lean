import NineSeparatedSubsetSums.Adaptive144Third143State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third143Proof325 : runCachedNode 511 130885 Adaptive144Third143Node325 = false := by
  decide +kernel

#print axioms adaptive144Third143Proof325

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third143Proof255 : runCachedNode 511 130885 Adaptive144Third143Node255 = false := by
  decide +kernel

#print axioms adaptive144Third143Proof255

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third143Proof101 : runCachedNode 511 130885 Adaptive144Third143Node101 = false := by
  decide +kernel

#print axioms adaptive144Third143Proof101

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third143Proof127 : runCachedNode 511 130885 Adaptive144Third143Node127 = false := by
  decide +kernel

#print axioms adaptive144Third143Proof127

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third143Proof324 : runCachedNode 511 130885 Adaptive144Third143Node324 = false := by
  decide +kernel

#print axioms adaptive144Third143Proof324

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third143Proof97 : runCachedNode 511 130885 Adaptive144Third143Node97 = false := by
  decide +kernel

#print axioms adaptive144Third143Proof97

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third143Proof166 : runCachedNode 511 130885 Adaptive144Third143Node166 = false := by
  decide +kernel

#print axioms adaptive144Third143Proof166

end NineSeparatedSubsetSums
