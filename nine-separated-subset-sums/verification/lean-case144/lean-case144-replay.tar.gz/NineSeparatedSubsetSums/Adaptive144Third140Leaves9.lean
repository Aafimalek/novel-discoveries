import NineSeparatedSubsetSums.Adaptive144Third140State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof604 : runCachedNode 511 130381 Adaptive144Third140Node604 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof604

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof116 : runCachedNode 511 130381 Adaptive144Third140Node116 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof116

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof3 : runCachedNode 511 130381 Adaptive144Third140Node3 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof3

end NineSeparatedSubsetSums
