import NineSeparatedSubsetSums.Adaptive144Third142State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third142Proof22 : runCachedNode 511 130737 Adaptive144Third142Node22 = false := by
  decide +kernel

#print axioms adaptive144Third142Proof22

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third142Proof169 : runCachedNode 511 130737 Adaptive144Third142Node169 = false := by
  decide +kernel

#print axioms adaptive144Third142Proof169

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third142Proof5 : runCachedNode 511 130737 Adaptive144Third142Node5 = false := by
  decide +kernel

#print axioms adaptive144Third142Proof5

end NineSeparatedSubsetSums
