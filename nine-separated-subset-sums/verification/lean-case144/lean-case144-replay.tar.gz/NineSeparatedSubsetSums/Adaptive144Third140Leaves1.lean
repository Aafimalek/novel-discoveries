import NineSeparatedSubsetSums.Adaptive144Third140State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof18 : runCachedNode 511 130381 Adaptive144Third140Node18 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof18

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof57 : runCachedNode 511 130381 Adaptive144Third140Node57 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof57

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof300 : runCachedNode 511 130381 Adaptive144Third140Node300 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof300

end NineSeparatedSubsetSums
