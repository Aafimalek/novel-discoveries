import NineSeparatedSubsetSums.Adaptive144Third142State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third142Proof578 : runCachedNode 511 130737 Adaptive144Third142Node578 = false := by
  decide +kernel

#print axioms adaptive144Third142Proof578

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third142Proof660 : runCachedNode 511 130737 Adaptive144Third142Node660 = false := by
  decide +kernel

#print axioms adaptive144Third142Proof660

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third142Proof659 : runCachedNode 511 130737 Adaptive144Third142Node659 = false := by
  decide +kernel

#print axioms adaptive144Third142Proof659

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third142Proof3 : runCachedNode 511 130737 Adaptive144Third142Node3 = false := by
  decide +kernel

#print axioms adaptive144Third142Proof3

end NineSeparatedSubsetSums
