import NineSeparatedSubsetSums.Adaptive144Third143State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third143Proof490 : runCachedNode 511 130885 Adaptive144Third143Node490 = false := by
  decide +kernel

#print axioms adaptive144Third143Proof490

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third143Proof326 : runCachedNode 511 130885 Adaptive144Third143Node326 = false := by
  decide +kernel

#print axioms adaptive144Third143Proof326

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third143Proof194 : runCachedNode 511 130885 Adaptive144Third143Node194 = false := by
  decide +kernel

#print axioms adaptive144Third143Proof194

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third143Proof296 : runCachedNode 511 130885 Adaptive144Third143Node296 = false := by
  decide +kernel

#print axioms adaptive144Third143Proof296

end NineSeparatedSubsetSums
