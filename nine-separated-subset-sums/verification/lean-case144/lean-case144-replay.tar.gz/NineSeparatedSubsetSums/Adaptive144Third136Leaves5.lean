import NineSeparatedSubsetSums.Adaptive144Third136State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third136Proof18 : runCachedNode 511 129800 Adaptive144Third136Node18 = false := by
  decide +kernel

#print axioms adaptive144Third136Proof18

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third136Proof15 : runCachedNode 511 129800 Adaptive144Third136Node15 = false := by
  decide +kernel

#print axioms adaptive144Third136Proof15

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third136Proof77 : runCachedNode 511 129800 Adaptive144Third136Node77 = false := by
  decide +kernel

#print axioms adaptive144Third136Proof77

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third136Proof103 : runCachedNode 511 129800 Adaptive144Third136Node103 = false := by
  decide +kernel

#print axioms adaptive144Third136Proof103

end NineSeparatedSubsetSums
