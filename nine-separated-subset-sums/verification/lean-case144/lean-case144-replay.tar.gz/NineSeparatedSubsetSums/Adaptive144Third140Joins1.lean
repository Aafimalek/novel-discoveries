import NineSeparatedSubsetSums.Adaptive144Third140State
import NineSeparatedSubsetSums.Adaptive144Third140Leaves62
import NineSeparatedSubsetSums.Adaptive144Third140Leaves61
import NineSeparatedSubsetSums.Adaptive144Third140Leaves60
import NineSeparatedSubsetSums.Adaptive144Third140Leaves59
import NineSeparatedSubsetSums.Adaptive144Third140Leaves58
import NineSeparatedSubsetSums.Adaptive144Third140Leaves57
import NineSeparatedSubsetSums.Adaptive144Third140Leaves55
import NineSeparatedSubsetSums.Adaptive144Third140Leaves56
import NineSeparatedSubsetSums.Adaptive144Third140Leaves53
import NineSeparatedSubsetSums.Adaptive144Third140Leaves54
import NineSeparatedSubsetSums.Adaptive144Third140Leaves51
import NineSeparatedSubsetSums.Adaptive144Third140Leaves48
import NineSeparatedSubsetSums.Adaptive144Third140Leaves40
import NineSeparatedSubsetSums.Adaptive144Third140Leaves8
import NineSeparatedSubsetSums.Adaptive144Third140Leaves44
import NineSeparatedSubsetSums.Adaptive144Third140Leaves43
import NineSeparatedSubsetSums.Adaptive144Third140Leaves41
import NineSeparatedSubsetSums.Adaptive144Third140Leaves39
import NineSeparatedSubsetSums.Adaptive144Third140Leaves35
import NineSeparatedSubsetSums.Adaptive144Third140Leaves34
import NineSeparatedSubsetSums.Adaptive144Third140Leaves37
import NineSeparatedSubsetSums.Adaptive144Third140Leaves50
import NineSeparatedSubsetSums.Adaptive144Third140Leaves49
import NineSeparatedSubsetSums.Adaptive144Third140Leaves46
import NineSeparatedSubsetSums.Adaptive144Third140Leaves42
import NineSeparatedSubsetSums.Adaptive144Third140Leaves32
import NineSeparatedSubsetSums.Adaptive144Third140Leaves29
import NineSeparatedSubsetSums.Adaptive144Third140Leaves12
import NineSeparatedSubsetSums.Adaptive144Third140Leaves26
import NineSeparatedSubsetSums.Adaptive144Third140Leaves11
import NineSeparatedSubsetSums.Adaptive144Third140Leaves2
import NineSeparatedSubsetSums.Adaptive144Third140Leaves52
import NineSeparatedSubsetSums.Adaptive144Third140Leaves1
import NineSeparatedSubsetSums.Adaptive144Third140Leaves19
import NineSeparatedSubsetSums.Adaptive144Third140Leaves47
import NineSeparatedSubsetSums.Adaptive144Third140Leaves21
import NineSeparatedSubsetSums.Adaptive144Third140Leaves30
import NineSeparatedSubsetSums.Adaptive144Third140Leaves15
import NineSeparatedSubsetSums.Adaptive144Third140Leaves24
import NineSeparatedSubsetSums.Adaptive144Third140Leaves25
import NineSeparatedSubsetSums.Adaptive144Third140Leaves16
import NineSeparatedSubsetSums.Adaptive144Third140Leaves18
import NineSeparatedSubsetSums.Adaptive144Third140Leaves45
import NineSeparatedSubsetSums.Adaptive144Third140Leaves33
import NineSeparatedSubsetSums.Adaptive144Third140Leaves63
import NineSeparatedSubsetSums.Adaptive144Third140Leaves28
import NineSeparatedSubsetSums.Adaptive144Third140Leaves3
import NineSeparatedSubsetSums.Adaptive144Third140Leaves38
import NineSeparatedSubsetSums.Adaptive144Third140Leaves5
import NineSeparatedSubsetSums.Adaptive144Third140Leaves7
import NineSeparatedSubsetSums.Adaptive144Third140Leaves14
import NineSeparatedSubsetSums.Adaptive144Third140Leaves27
import NineSeparatedSubsetSums.Adaptive144Third140Leaves36
import NineSeparatedSubsetSums.Adaptive144Third140Leaves31

namespace NineSeparatedSubsetSums

theorem adaptive144Third140Proof264 : runCachedNode 511 130381 Adaptive144Third140Node264 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130381 Adaptive144Third140Node264 = [92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 115, 116, 117, 119, 120, 121, 123, 125, 127, 129, 131] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive144Third140Proof265
  · exact adaptive144Third140Proof266
  · exact adaptive144Third140Proof267
  · exact adaptive144Third140Proof268
  · exact adaptive144Third140Proof269
  · exact adaptive144Third140Proof270
  · exact adaptive144Third140Proof271
  · exact adaptive144Third140Proof272
  · exact adaptive144Third140Proof273
  · exact adaptive144Third140Proof274
  · exact adaptive144Third140Proof275
  · exact adaptive144Third140Proof276
  · exact adaptive144Third140Proof277
  · exact adaptive144Third140Proof278
  · exact adaptive144Third140Proof279
  · exact adaptive144Third140Proof280
  · exact adaptive144Third140Proof281
  · exact adaptive144Third140Proof282
  · exact adaptive144Third140Proof283
  · exact adaptive144Third140Proof284
  · exact adaptive144Third140Proof285
  · exact adaptive144Third140Proof286
  · exact adaptive144Third140Proof287
  · exact adaptive144Third140Proof288
  · exact adaptive144Third140Proof289
  · exact adaptive144Third140Proof290
  · exact adaptive144Third140Proof291
  · exact adaptive144Third140Proof292
  · exact adaptive144Third140Proof293
  · exact adaptive144Third140Proof294
  · exact adaptive144Third140Proof295
  · exact adaptive144Third140Proof296
  · exact adaptive144Third140Proof297

#print axioms adaptive144Third140Proof264

theorem adaptive144Third140Proof236 : runCachedNode 511 130381 Adaptive144Third140Node236 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130381 Adaptive144Third140Node236 = [103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 127, 128, 129, 131, 132, 133] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive144Third140Proof237
  · exact adaptive144Third140Proof238
  · exact adaptive144Third140Proof239
  · exact adaptive144Third140Proof240
  · exact adaptive144Third140Proof241
  · exact adaptive144Third140Proof242
  · exact adaptive144Third140Proof243
  · exact adaptive144Third140Proof244
  · exact adaptive144Third140Proof245
  · exact adaptive144Third140Proof246
  · exact adaptive144Third140Proof247
  · exact adaptive144Third140Proof248
  · exact adaptive144Third140Proof249
  · exact adaptive144Third140Proof250
  · exact adaptive144Third140Proof251
  · exact adaptive144Third140Proof252
  · exact adaptive144Third140Proof253
  · exact adaptive144Third140Proof254
  · exact adaptive144Third140Proof255
  · exact adaptive144Third140Proof256
  · exact adaptive144Third140Proof257
  · exact adaptive144Third140Proof258
  · exact adaptive144Third140Proof259
  · exact adaptive144Third140Proof260
  · exact adaptive144Third140Proof261
  · exact adaptive144Third140Proof262
  · exact adaptive144Third140Proof263
  · exact adaptive144Third140Proof264
  · exact adaptive144Third140Proof298

#print axioms adaptive144Third140Proof236

theorem adaptive144Third140Proof328 : runCachedNode 511 130381 Adaptive144Third140Node328 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130381 Adaptive144Third140Node328 = [92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 116, 117, 118, 120, 121, 122, 125, 126, 129, 130] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive144Third140Proof329
  · exact adaptive144Third140Proof330
  · exact adaptive144Third140Proof331
  · exact adaptive144Third140Proof332
  · exact adaptive144Third140Proof333
  · exact adaptive144Third140Proof334
  · exact adaptive144Third140Proof335
  · exact adaptive144Third140Proof336
  · exact adaptive144Third140Proof337
  · exact adaptive144Third140Proof338
  · exact adaptive144Third140Proof339
  · exact adaptive144Third140Proof340
  · exact adaptive144Third140Proof341
  · exact adaptive144Third140Proof342
  · exact adaptive144Third140Proof343
  · exact adaptive144Third140Proof344
  · exact adaptive144Third140Proof345
  · exact adaptive144Third140Proof346
  · exact adaptive144Third140Proof347
  · exact adaptive144Third140Proof348
  · exact adaptive144Third140Proof349
  · exact adaptive144Third140Proof350
  · exact adaptive144Third140Proof351
  · exact adaptive144Third140Proof352
  · exact adaptive144Third140Proof353
  · exact adaptive144Third140Proof354
  · exact adaptive144Third140Proof355
  · exact adaptive144Third140Proof356
  · exact adaptive144Third140Proof357
  · exact adaptive144Third140Proof358
  · exact adaptive144Third140Proof359
  · exact adaptive144Third140Proof360
  · exact adaptive144Third140Proof361

#print axioms adaptive144Third140Proof328

theorem adaptive144Third140Proof299 : runCachedNode 511 130381 Adaptive144Third140Node299 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130381 Adaptive144Third140Node299 = [102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 128, 129, 130, 132, 133, 134] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive144Third140Proof300
  · exact adaptive144Third140Proof301
  · exact adaptive144Third140Proof302
  · exact adaptive144Third140Proof303
  · exact adaptive144Third140Proof304
  · exact adaptive144Third140Proof305
  · exact adaptive144Third140Proof306
  · exact adaptive144Third140Proof307
  · exact adaptive144Third140Proof308
  · exact adaptive144Third140Proof309
  · exact adaptive144Third140Proof310
  · exact adaptive144Third140Proof311
  · exact adaptive144Third140Proof312
  · exact adaptive144Third140Proof313
  · exact adaptive144Third140Proof314
  · exact adaptive144Third140Proof315
  · exact adaptive144Third140Proof316
  · exact adaptive144Third140Proof317
  · exact adaptive144Third140Proof318
  · exact adaptive144Third140Proof319
  · exact adaptive144Third140Proof320
  · exact adaptive144Third140Proof321
  · exact adaptive144Third140Proof322
  · exact adaptive144Third140Proof323
  · exact adaptive144Third140Proof324
  · exact adaptive144Third140Proof325
  · exact adaptive144Third140Proof326
  · exact adaptive144Third140Proof327
  · exact adaptive144Third140Proof328
  · exact adaptive144Third140Proof362
  · exact adaptive144Third140Proof363

#print axioms adaptive144Third140Proof299

theorem adaptive144Third140Proof394 : runCachedNode 511 130381 Adaptive144Third140Node394 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130381 Adaptive144Third140Node394 = [91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 118, 119, 120, 122, 123, 126, 127, 130] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive144Third140Proof395
  · exact adaptive144Third140Proof396
  · exact adaptive144Third140Proof397
  · exact adaptive144Third140Proof398
  · exact adaptive144Third140Proof399
  · exact adaptive144Third140Proof400
  · exact adaptive144Third140Proof401
  · exact adaptive144Third140Proof402
  · exact adaptive144Third140Proof403
  · exact adaptive144Third140Proof404
  · exact adaptive144Third140Proof405
  · exact adaptive144Third140Proof406
  · exact adaptive144Third140Proof407
  · exact adaptive144Third140Proof408
  · exact adaptive144Third140Proof409
  · exact adaptive144Third140Proof410
  · exact adaptive144Third140Proof411
  · exact adaptive144Third140Proof412
  · exact adaptive144Third140Proof413
  · exact adaptive144Third140Proof414
  · exact adaptive144Third140Proof415
  · exact adaptive144Third140Proof416
  · exact adaptive144Third140Proof417
  · exact adaptive144Third140Proof418
  · exact adaptive144Third140Proof419
  · exact adaptive144Third140Proof420
  · exact adaptive144Third140Proof421
  · exact adaptive144Third140Proof422
  · exact adaptive144Third140Proof423
  · exact adaptive144Third140Proof424
  · exact adaptive144Third140Proof425
  · exact adaptive144Third140Proof426
  · exact adaptive144Third140Proof427
  · exact adaptive144Third140Proof428

#print axioms adaptive144Third140Proof394

theorem adaptive144Third140Proof429 : runCachedNode 511 130381 Adaptive144Third140Node429 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130381 Adaptive144Third140Node429 = [91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 120, 121, 122, 124, 125, 128, 132] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive144Third140Proof430
  · exact adaptive144Third140Proof431
  · exact adaptive144Third140Proof432
  · exact adaptive144Third140Proof433
  · exact adaptive144Third140Proof434
  · exact adaptive144Third140Proof435
  · exact adaptive144Third140Proof436
  · exact adaptive144Third140Proof437
  · exact adaptive144Third140Proof438
  · exact adaptive144Third140Proof439
  · exact adaptive144Third140Proof440
  · exact adaptive144Third140Proof441
  · exact adaptive144Third140Proof442
  · exact adaptive144Third140Proof443
  · exact adaptive144Third140Proof444
  · exact adaptive144Third140Proof445
  · exact adaptive144Third140Proof446
  · exact adaptive144Third140Proof447
  · exact adaptive144Third140Proof448
  · exact adaptive144Third140Proof449
  · exact adaptive144Third140Proof450
  · exact adaptive144Third140Proof451
  · exact adaptive144Third140Proof452
  · exact adaptive144Third140Proof453
  · exact adaptive144Third140Proof454
  · exact adaptive144Third140Proof455
  · exact adaptive144Third140Proof456
  · exact adaptive144Third140Proof457
  · exact adaptive144Third140Proof458
  · exact adaptive144Third140Proof459
  · exact adaptive144Third140Proof460
  · exact adaptive144Third140Proof461
  · exact adaptive144Third140Proof462
  · exact adaptive144Third140Proof463
  · exact adaptive144Third140Proof464

#print axioms adaptive144Third140Proof429

theorem adaptive144Third140Proof364 : runCachedNode 511 130381 Adaptive144Third140Node364 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130381 Adaptive144Third140Node364 = [102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 130, 131, 132, 134, 135] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive144Third140Proof365
  · exact adaptive144Third140Proof366
  · exact adaptive144Third140Proof367
  · exact adaptive144Third140Proof368
  · exact adaptive144Third140Proof369
  · exact adaptive144Third140Proof370
  · exact adaptive144Third140Proof371
  · exact adaptive144Third140Proof372
  · exact adaptive144Third140Proof373
  · exact adaptive144Third140Proof374
  · exact adaptive144Third140Proof375
  · exact adaptive144Third140Proof376
  · exact adaptive144Third140Proof377
  · exact adaptive144Third140Proof378
  · exact adaptive144Third140Proof379
  · exact adaptive144Third140Proof380
  · exact adaptive144Third140Proof381
  · exact adaptive144Third140Proof382
  · exact adaptive144Third140Proof383
  · exact adaptive144Third140Proof384
  · exact adaptive144Third140Proof385
  · exact adaptive144Third140Proof386
  · exact adaptive144Third140Proof387
  · exact adaptive144Third140Proof388
  · exact adaptive144Third140Proof389
  · exact adaptive144Third140Proof390
  · exact adaptive144Third140Proof391
  · exact adaptive144Third140Proof392
  · exact adaptive144Third140Proof393
  · exact adaptive144Third140Proof394
  · exact adaptive144Third140Proof429
  · exact adaptive144Third140Proof465

#print axioms adaptive144Third140Proof364

theorem adaptive144Third140Proof496 : runCachedNode 511 130381 Adaptive144Third140Node496 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130381 Adaptive144Third140Node496 = [91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 119, 120, 121, 123, 125, 127, 129, 131] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive144Third140Proof497
  · exact adaptive144Third140Proof498
  · exact adaptive144Third140Proof499
  · exact adaptive144Third140Proof500
  · exact adaptive144Third140Proof501
  · exact adaptive144Third140Proof502
  · exact adaptive144Third140Proof503
  · exact adaptive144Third140Proof504
  · exact adaptive144Third140Proof505
  · exact adaptive144Third140Proof506
  · exact adaptive144Third140Proof507
  · exact adaptive144Third140Proof508
  · exact adaptive144Third140Proof509
  · exact adaptive144Third140Proof510
  · exact adaptive144Third140Proof511
  · exact adaptive144Third140Proof512
  · exact adaptive144Third140Proof513
  · exact adaptive144Third140Proof514
  · exact adaptive144Third140Proof515
  · exact adaptive144Third140Proof516
  · exact adaptive144Third140Proof517
  · exact adaptive144Third140Proof518
  · exact adaptive144Third140Proof519
  · exact adaptive144Third140Proof520
  · exact adaptive144Third140Proof521
  · exact adaptive144Third140Proof522
  · exact adaptive144Third140Proof523
  · exact adaptive144Third140Proof524
  · exact adaptive144Third140Proof525
  · exact adaptive144Third140Proof526
  · exact adaptive144Third140Proof527
  · exact adaptive144Third140Proof528
  · exact adaptive144Third140Proof529
  · exact adaptive144Third140Proof530
  · exact adaptive144Third140Proof531

#print axioms adaptive144Third140Proof496

end NineSeparatedSubsetSums
