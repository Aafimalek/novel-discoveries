import NineSeparatedSubsetSums.Adaptive144Third103Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint144Checked

namespace NineSeparatedSubsetSums


theorem adaptive144Third103 : NoDescendingTailAfterThird 144 103 :=
  noDescendingThirdTail_of_cached 144 103 112221 (fun t ht nd => max148_second144_fourPoint_moment_bound (103::t) (by simp [ht]) nd) adaptive144Third103Proof0

#print axioms adaptive144Third103

end NineSeparatedSubsetSums
