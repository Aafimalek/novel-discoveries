import NineSeparatedSubsetSums.Adaptive144Third134State
import NineSeparatedSubsetSums.Adaptive144Third134Leaves7
import NineSeparatedSubsetSums.Adaptive144Third134Leaves0
import NineSeparatedSubsetSums.Adaptive144Third134Leaves1
import NineSeparatedSubsetSums.Adaptive144Third134Leaves6
import NineSeparatedSubsetSums.Adaptive144Third134Leaves3
import NineSeparatedSubsetSums.Adaptive144Third134Leaves5
import NineSeparatedSubsetSums.Adaptive144Third134Leaves4
import NineSeparatedSubsetSums.Adaptive144Third134Leaves2

namespace NineSeparatedSubsetSums

theorem adaptive144Third134Proof22 : runCachedNode 511 129525 Adaptive144Third134Node22 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 129525 Adaptive144Third134Node22 = [104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 119, 120, 121, 123, 124, 125, 126, 127, 129, 131] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive144Third134Proof23
  · exact adaptive144Third134Proof24
  · exact adaptive144Third134Proof25
  · exact adaptive144Third134Proof26
  · exact adaptive144Third134Proof27
  · exact adaptive144Third134Proof28
  · exact adaptive144Third134Proof29
  · exact adaptive144Third134Proof30
  · exact adaptive144Third134Proof31
  · exact adaptive144Third134Proof32
  · exact adaptive144Third134Proof33
  · exact adaptive144Third134Proof34
  · exact adaptive144Third134Proof35
  · exact adaptive144Third134Proof36
  · exact adaptive144Third134Proof37
  · exact adaptive144Third134Proof38
  · exact adaptive144Third134Proof39
  · exact adaptive144Third134Proof40
  · exact adaptive144Third134Proof41
  · exact adaptive144Third134Proof42
  · exact adaptive144Third134Proof43
  · exact adaptive144Third134Proof44
  · exact adaptive144Third134Proof45
  · exact adaptive144Third134Proof46

#print axioms adaptive144Third134Proof22

theorem adaptive144Third134Proof47 : runCachedNode 511 129525 Adaptive144Third134Node47 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 129525 Adaptive144Third134Node47 = [104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 120, 121, 122, 124, 125, 126, 127, 128, 131, 132] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive144Third134Proof48
  · exact adaptive144Third134Proof49
  · exact adaptive144Third134Proof50
  · exact adaptive144Third134Proof51
  · exact adaptive144Third134Proof52
  · exact adaptive144Third134Proof53
  · exact adaptive144Third134Proof54
  · exact adaptive144Third134Proof55
  · exact adaptive144Third134Proof56
  · exact adaptive144Third134Proof57
  · exact adaptive144Third134Proof58
  · exact adaptive144Third134Proof59
  · exact adaptive144Third134Proof60
  · exact adaptive144Third134Proof61
  · exact adaptive144Third134Proof62
  · exact adaptive144Third134Proof63
  · exact adaptive144Third134Proof64
  · exact adaptive144Third134Proof65
  · exact adaptive144Third134Proof66
  · exact adaptive144Third134Proof67
  · exact adaptive144Third134Proof68
  · exact adaptive144Third134Proof69
  · exact adaptive144Third134Proof70
  · exact adaptive144Third134Proof71
  · exact adaptive144Third134Proof72

#print axioms adaptive144Third134Proof47

theorem adaptive144Third134Proof0 : runCachedNode 511 129525 Adaptive144Third134Node0 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 129525 Adaptive144Third134Node0 = [110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 131, 132, 133] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive144Third134Proof1
  · exact adaptive144Third134Proof2
  · exact adaptive144Third134Proof3
  · exact adaptive144Third134Proof4
  · exact adaptive144Third134Proof5
  · exact adaptive144Third134Proof6
  · exact adaptive144Third134Proof7
  · exact adaptive144Third134Proof8
  · exact adaptive144Third134Proof9
  · exact adaptive144Third134Proof10
  · exact adaptive144Third134Proof11
  · exact adaptive144Third134Proof12
  · exact adaptive144Third134Proof13
  · exact adaptive144Third134Proof14
  · exact adaptive144Third134Proof15
  · exact adaptive144Third134Proof16
  · exact adaptive144Third134Proof17
  · exact adaptive144Third134Proof18
  · exact adaptive144Third134Proof19
  · exact adaptive144Third134Proof20
  · exact adaptive144Third134Proof21
  · exact adaptive144Third134Proof22
  · exact adaptive144Third134Proof47

#print axioms adaptive144Third134Proof0

end NineSeparatedSubsetSums
