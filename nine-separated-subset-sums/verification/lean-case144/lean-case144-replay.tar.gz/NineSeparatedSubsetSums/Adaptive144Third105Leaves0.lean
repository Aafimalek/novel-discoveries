import NineSeparatedSubsetSums.Adaptive144Third105State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third105Proof0 : runCachedNode 511 112221 Adaptive144Third105Node0 = false := by
  decide +kernel

#print axioms adaptive144Third105Proof0

end NineSeparatedSubsetSums
