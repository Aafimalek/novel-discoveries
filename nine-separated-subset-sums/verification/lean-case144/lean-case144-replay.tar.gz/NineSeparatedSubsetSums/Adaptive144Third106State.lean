import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive144Third106Node0 : CachedSearchNode :=
  ⟨4, 105, computeCenteredMask [148,144,106], 398, 53876⟩

end NineSeparatedSubsetSums
