import NineSeparatedSubsetSums.Adaptive144Third137State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third137Proof182 : runCachedNode 511 129993 Adaptive144Third137Node182 = false := by
  decide +kernel

#print axioms adaptive144Third137Proof182

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third137Proof181 : runCachedNode 511 129993 Adaptive144Third137Node181 = false := by
  decide +kernel

#print axioms adaptive144Third137Proof181

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third137Proof69 : runCachedNode 511 129993 Adaptive144Third137Node69 = false := by
  decide +kernel

#print axioms adaptive144Third137Proof69

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third137Proof104 : runCachedNode 511 129993 Adaptive144Third137Node104 = false := by
  decide +kernel

#print axioms adaptive144Third137Proof104

end NineSeparatedSubsetSums
