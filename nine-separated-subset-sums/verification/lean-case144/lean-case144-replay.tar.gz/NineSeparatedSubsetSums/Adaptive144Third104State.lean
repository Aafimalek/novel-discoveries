import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive144Third104Node0 : CachedSearchNode :=
  ⟨4, 103, computeCenteredMask [148,144,104], 396, 53456⟩

end NineSeparatedSubsetSums
