import NineSeparatedSubsetSums.Adaptive144Third142State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third142Proof576 : runCachedNode 511 130737 Adaptive144Third142Node576 = false := by
  decide +kernel

#print axioms adaptive144Third142Proof576

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third142Proof373 : runCachedNode 511 130737 Adaptive144Third142Node373 = false := by
  decide +kernel

#print axioms adaptive144Third142Proof373

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third142Proof610 : runCachedNode 511 130737 Adaptive144Third142Node610 = false := by
  decide +kernel

#print axioms adaptive144Third142Proof610

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third142Proof163 : runCachedNode 511 130737 Adaptive144Third142Node163 = false := by
  decide +kernel

#print axioms adaptive144Third142Proof163

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third142Proof407 : runCachedNode 511 130737 Adaptive144Third142Node407 = false := by
  decide +kernel

#print axioms adaptive144Third142Proof407

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third142Proof146 : runCachedNode 511 130737 Adaptive144Third142Node146 = false := by
  decide +kernel

#print axioms adaptive144Third142Proof146

end NineSeparatedSubsetSums
