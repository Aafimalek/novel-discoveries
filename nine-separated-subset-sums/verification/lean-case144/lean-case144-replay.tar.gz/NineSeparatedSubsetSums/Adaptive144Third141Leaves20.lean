import NineSeparatedSubsetSums.Adaptive144Third141State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third141Proof166 : runCachedNode 511 130584 Adaptive144Third141Node166 = false := by
  decide +kernel

#print axioms adaptive144Third141Proof166

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third141Proof435 : runCachedNode 511 130584 Adaptive144Third141Node435 = false := by
  decide +kernel

#print axioms adaptive144Third141Proof435

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third141Proof16 : runCachedNode 511 130584 Adaptive144Third141Node16 = false := by
  decide +kernel

#print axioms adaptive144Third141Proof16

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third141Proof304 : runCachedNode 511 130584 Adaptive144Third141Node304 = false := by
  decide +kernel

#print axioms adaptive144Third141Proof304

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third141Proof56 : runCachedNode 511 130584 Adaptive144Third141Node56 = false := by
  decide +kernel

#print axioms adaptive144Third141Proof56

end NineSeparatedSubsetSums
