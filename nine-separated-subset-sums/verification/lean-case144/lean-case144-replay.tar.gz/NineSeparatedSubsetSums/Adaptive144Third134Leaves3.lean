import NineSeparatedSubsetSums.Adaptive144Third134State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third134Proof17 : runCachedNode 511 129525 Adaptive144Third134Node17 = false := by
  decide +kernel

#print axioms adaptive144Third134Proof17

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third134Proof18 : runCachedNode 511 129525 Adaptive144Third134Node18 = false := by
  decide +kernel

#print axioms adaptive144Third134Proof18

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third134Proof35 : runCachedNode 511 129525 Adaptive144Third134Node35 = false := by
  decide +kernel

#print axioms adaptive144Third134Proof35

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third134Proof2 : runCachedNode 511 129525 Adaptive144Third134Node2 = false := by
  decide +kernel

#print axioms adaptive144Third134Proof2

end NineSeparatedSubsetSums
