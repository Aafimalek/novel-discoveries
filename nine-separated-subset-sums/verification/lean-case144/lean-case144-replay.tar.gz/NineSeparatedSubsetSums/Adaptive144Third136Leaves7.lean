import NineSeparatedSubsetSums.Adaptive144Third136State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third136Proof48 : runCachedNode 511 129800 Adaptive144Third136Node48 = false := by
  decide +kernel

#print axioms adaptive144Third136Proof48

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third136Proof47 : runCachedNode 511 129800 Adaptive144Third136Node47 = false := by
  decide +kernel

#print axioms adaptive144Third136Proof47

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third136Proof105 : runCachedNode 511 129800 Adaptive144Third136Node105 = false := by
  decide +kernel

#print axioms adaptive144Third136Proof105

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third136Proof75 : runCachedNode 511 129800 Adaptive144Third136Node75 = false := by
  decide +kernel

#print axioms adaptive144Third136Proof75

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third136Proof101 : runCachedNode 511 129800 Adaptive144Third136Node101 = false := by
  decide +kernel

#print axioms adaptive144Third136Proof101

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third136Proof62 : runCachedNode 511 129800 Adaptive144Third136Node62 = false := by
  decide +kernel

#print axioms adaptive144Third136Proof62

end NineSeparatedSubsetSums
