import NineSeparatedSubsetSums.Adaptive144Third142State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third142Proof654 : runCachedNode 511 130737 Adaptive144Third142Node654 = false := by
  decide +kernel

#print axioms adaptive144Third142Proof654

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third142Proof395 : runCachedNode 511 130737 Adaptive144Third142Node395 = false := by
  decide +kernel

#print axioms adaptive144Third142Proof395

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third142Proof75 : runCachedNode 511 130737 Adaptive144Third142Node75 = false := by
  decide +kernel

#print axioms adaptive144Third142Proof75

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third142Proof400 : runCachedNode 511 130737 Adaptive144Third142Node400 = false := by
  decide +kernel

#print axioms adaptive144Third142Proof400

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third142Proof299 : runCachedNode 511 130737 Adaptive144Third142Node299 = false := by
  decide +kernel

#print axioms adaptive144Third142Proof299

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third142Proof329 : runCachedNode 511 130737 Adaptive144Third142Node329 = false := by
  decide +kernel

#print axioms adaptive144Third142Proof329

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third142Proof198 : runCachedNode 511 130737 Adaptive144Third142Node198 = false := by
  decide +kernel

#print axioms adaptive144Third142Proof198

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third142Proof234 : runCachedNode 511 130737 Adaptive144Third142Node234 = false := by
  decide +kernel

#print axioms adaptive144Third142Proof234

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third142Proof298 : runCachedNode 511 130737 Adaptive144Third142Node298 = false := by
  decide +kernel

#print axioms adaptive144Third142Proof298

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third142Proof651 : runCachedNode 511 130737 Adaptive144Third142Node651 = false := by
  decide +kernel

#print axioms adaptive144Third142Proof651

end NineSeparatedSubsetSums
