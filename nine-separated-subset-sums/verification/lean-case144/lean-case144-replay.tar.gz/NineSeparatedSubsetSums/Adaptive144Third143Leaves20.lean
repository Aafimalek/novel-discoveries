import NineSeparatedSubsetSums.Adaptive144Third143State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third143Proof195 : runCachedNode 511 130885 Adaptive144Third143Node195 = false := by
  decide +kernel

#print axioms adaptive144Third143Proof195

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third143Proof411 : runCachedNode 511 130885 Adaptive144Third143Node411 = false := by
  decide +kernel

#print axioms adaptive144Third143Proof411

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third143Proof660 : runCachedNode 511 130885 Adaptive144Third143Node660 = false := by
  decide +kernel

#print axioms adaptive144Third143Proof660

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third143Proof50 : runCachedNode 511 130885 Adaptive144Third143Node50 = false := by
  decide +kernel

#print axioms adaptive144Third143Proof50

end NineSeparatedSubsetSums
