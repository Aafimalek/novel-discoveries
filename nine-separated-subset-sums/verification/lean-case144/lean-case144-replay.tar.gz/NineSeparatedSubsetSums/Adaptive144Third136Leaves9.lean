import NineSeparatedSubsetSums.Adaptive144Third136State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third136Proof68 : runCachedNode 511 129800 Adaptive144Third136Node68 = false := by
  decide +kernel

#print axioms adaptive144Third136Proof68

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third136Proof100 : runCachedNode 511 129800 Adaptive144Third136Node100 = false := by
  decide +kernel

#print axioms adaptive144Third136Proof100

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third136Proof9 : runCachedNode 511 129800 Adaptive144Third136Node9 = false := by
  decide +kernel

#print axioms adaptive144Third136Proof9

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third136Proof66 : runCachedNode 511 129800 Adaptive144Third136Node66 = false := by
  decide +kernel

#print axioms adaptive144Third136Proof66

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third136Proof95 : runCachedNode 511 129800 Adaptive144Third136Node95 = false := by
  decide +kernel

#print axioms adaptive144Third136Proof95

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third136Proof43 : runCachedNode 511 129800 Adaptive144Third136Node43 = false := by
  decide +kernel

#print axioms adaptive144Third136Proof43

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third136Proof96 : runCachedNode 511 129800 Adaptive144Third136Node96 = false := by
  decide +kernel

#print axioms adaptive144Third136Proof96

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third136Proof41 : runCachedNode 511 129800 Adaptive144Third136Node41 = false := by
  decide +kernel

#print axioms adaptive144Third136Proof41

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third136Proof67 : runCachedNode 511 129800 Adaptive144Third136Node67 = false := by
  decide +kernel

#print axioms adaptive144Third136Proof67

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third136Proof39 : runCachedNode 511 129800 Adaptive144Third136Node39 = false := by
  decide +kernel

#print axioms adaptive144Third136Proof39

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third136Proof94 : runCachedNode 511 129800 Adaptive144Third136Node94 = false := by
  decide +kernel

#print axioms adaptive144Third136Proof94

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third136Proof97 : runCachedNode 511 129800 Adaptive144Third136Node97 = false := by
  decide +kernel

#print axioms adaptive144Third136Proof97

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third136Proof8 : runCachedNode 511 129800 Adaptive144Third136Node8 = false := by
  decide +kernel

#print axioms adaptive144Third136Proof8

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third136Proof64 : runCachedNode 511 129800 Adaptive144Third136Node64 = false := by
  decide +kernel

#print axioms adaptive144Third136Proof64

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third136Proof38 : runCachedNode 511 129800 Adaptive144Third136Node38 = false := by
  decide +kernel

#print axioms adaptive144Third136Proof38

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third136Proof65 : runCachedNode 511 129800 Adaptive144Third136Node65 = false := by
  decide +kernel

#print axioms adaptive144Third136Proof65

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third136Proof40 : runCachedNode 511 129800 Adaptive144Third136Node40 = false := by
  decide +kernel

#print axioms adaptive144Third136Proof40

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third136Proof93 : runCachedNode 511 129800 Adaptive144Third136Node93 = false := by
  decide +kernel

#print axioms adaptive144Third136Proof93

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third136Proof7 : runCachedNode 511 129800 Adaptive144Third136Node7 = false := by
  decide +kernel

#print axioms adaptive144Third136Proof7

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third136Proof63 : runCachedNode 511 129800 Adaptive144Third136Node63 = false := by
  decide +kernel

#print axioms adaptive144Third136Proof63

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third136Proof91 : runCachedNode 511 129800 Adaptive144Third136Node91 = false := by
  decide +kernel

#print axioms adaptive144Third136Proof91

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third136Proof92 : runCachedNode 511 129800 Adaptive144Third136Node92 = false := by
  decide +kernel

#print axioms adaptive144Third136Proof92

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third136Proof6 : runCachedNode 511 129800 Adaptive144Third136Node6 = false := by
  decide +kernel

#print axioms adaptive144Third136Proof6

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third136Proof37 : runCachedNode 511 129800 Adaptive144Third136Node37 = false := by
  decide +kernel

#print axioms adaptive144Third136Proof37

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third136Proof90 : runCachedNode 511 129800 Adaptive144Third136Node90 = false := by
  decide +kernel

#print axioms adaptive144Third136Proof90

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third136Proof36 : runCachedNode 511 129800 Adaptive144Third136Node36 = false := by
  decide +kernel

#print axioms adaptive144Third136Proof36

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third136Proof35 : runCachedNode 511 129800 Adaptive144Third136Node35 = false := by
  decide +kernel

#print axioms adaptive144Third136Proof35

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third136Proof61 : runCachedNode 511 129800 Adaptive144Third136Node61 = false := by
  decide +kernel

#print axioms adaptive144Third136Proof61

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third136Proof4 : runCachedNode 511 129800 Adaptive144Third136Node4 = false := by
  decide +kernel

#print axioms adaptive144Third136Proof4

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third136Proof89 : runCachedNode 511 129800 Adaptive144Third136Node89 = false := by
  decide +kernel

#print axioms adaptive144Third136Proof89

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third136Proof60 : runCachedNode 511 129800 Adaptive144Third136Node60 = false := by
  decide +kernel

#print axioms adaptive144Third136Proof60

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third136Proof88 : runCachedNode 511 129800 Adaptive144Third136Node88 = false := by
  decide +kernel

#print axioms adaptive144Third136Proof88

end NineSeparatedSubsetSums
