import NineSeparatedSubsetSums.Adaptive144Third143State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third143Proof569 : runCachedNode 511 130885 Adaptive144Third143Node569 = false := by
  decide +kernel

#print axioms adaptive144Third143Proof569

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third143Proof132 : runCachedNode 511 130885 Adaptive144Third143Node132 = false := by
  decide +kernel

#print axioms adaptive144Third143Proof132

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third143Proof329 : runCachedNode 511 130885 Adaptive144Third143Node329 = false := by
  decide +kernel

#print axioms adaptive144Third143Proof329

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third143Proof26 : runCachedNode 511 130885 Adaptive144Third143Node26 = false := by
  decide +kernel

#print axioms adaptive144Third143Proof26

end NineSeparatedSubsetSums
