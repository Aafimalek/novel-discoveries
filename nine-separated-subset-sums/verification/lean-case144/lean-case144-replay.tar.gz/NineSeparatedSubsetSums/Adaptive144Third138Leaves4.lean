import NineSeparatedSubsetSums.Adaptive144Third138State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third138Proof179 : runCachedNode 511 130126 Adaptive144Third138Node179 = false := by
  decide +kernel

#print axioms adaptive144Third138Proof179

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third138Proof181 : runCachedNode 511 130126 Adaptive144Third138Node181 = false := by
  decide +kernel

#print axioms adaptive144Third138Proof181

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third138Proof71 : runCachedNode 511 130126 Adaptive144Third138Node71 = false := by
  decide +kernel

#print axioms adaptive144Third138Proof71

end NineSeparatedSubsetSums
