import NineSeparatedSubsetSums.Adaptive144Third142State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third142Proof12 : runCachedNode 511 130737 Adaptive144Third142Node12 = false := by
  decide +kernel

#print axioms adaptive144Third142Proof12

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third142Proof195 : runCachedNode 511 130737 Adaptive144Third142Node195 = false := by
  decide +kernel

#print axioms adaptive144Third142Proof195

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third142Proof446 : runCachedNode 511 130737 Adaptive144Third142Node446 = false := by
  decide +kernel

#print axioms adaptive144Third142Proof446

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third142Proof607 : runCachedNode 511 130737 Adaptive144Third142Node607 = false := by
  decide +kernel

#print axioms adaptive144Third142Proof607

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third142Proof295 : runCachedNode 511 130737 Adaptive144Third142Node295 = false := by
  decide +kernel

#print axioms adaptive144Third142Proof295

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third142Proof327 : runCachedNode 511 130737 Adaptive144Third142Node327 = false := by
  decide +kernel

#print axioms adaptive144Third142Proof327

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third142Proof45 : runCachedNode 511 130737 Adaptive144Third142Node45 = false := by
  decide +kernel

#print axioms adaptive144Third142Proof45

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third142Proof487 : runCachedNode 511 130737 Adaptive144Third142Node487 = false := by
  decide +kernel

#print axioms adaptive144Third142Proof487

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third142Proof572 : runCachedNode 511 130737 Adaptive144Third142Node572 = false := by
  decide +kernel

#print axioms adaptive144Third142Proof572

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third142Proof322 : runCachedNode 511 130737 Adaptive144Third142Node322 = false := by
  decide +kernel

#print axioms adaptive144Third142Proof322

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third142Proof647 : runCachedNode 511 130737 Adaptive144Third142Node647 = false := by
  decide +kernel

#print axioms adaptive144Third142Proof647

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third142Proof291 : runCachedNode 511 130737 Adaptive144Third142Node291 = false := by
  decide +kernel

#print axioms adaptive144Third142Proof291

end NineSeparatedSubsetSums
