import NineSeparatedSubsetSums.Adaptive144Third140State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof487 : runCachedNode 511 130381 Adaptive144Third140Node487 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof487

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof295 : runCachedNode 511 130381 Adaptive144Third140Node295 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof295

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof599 : runCachedNode 511 130381 Adaptive144Third140Node599 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof599

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof132 : runCachedNode 511 130381 Adaptive144Third140Node132 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof132

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof86 : runCachedNode 511 130381 Adaptive144Third140Node86 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof86

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof39 : runCachedNode 511 130381 Adaptive144Third140Node39 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof39

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof84 : runCachedNode 511 130381 Adaptive144Third140Node84 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof84

end NineSeparatedSubsetSums
