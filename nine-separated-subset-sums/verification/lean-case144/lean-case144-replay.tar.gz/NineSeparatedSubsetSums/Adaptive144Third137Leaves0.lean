import NineSeparatedSubsetSums.Adaptive144Third137State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third137Proof20 : runCachedNode 511 129993 Adaptive144Third137Node20 = false := by
  decide +kernel

#print axioms adaptive144Third137Proof20

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third137Proof149 : runCachedNode 511 129993 Adaptive144Third137Node149 = false := by
  decide +kernel

#print axioms adaptive144Third137Proof149

end NineSeparatedSubsetSums
