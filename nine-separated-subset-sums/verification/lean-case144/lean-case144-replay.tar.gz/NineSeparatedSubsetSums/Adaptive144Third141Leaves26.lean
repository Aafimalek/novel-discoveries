import NineSeparatedSubsetSums.Adaptive144Third141State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third141Proof76 : runCachedNode 511 130584 Adaptive144Third141Node76 = false := by
  decide +kernel

#print axioms adaptive144Third141Proof76

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third141Proof74 : runCachedNode 511 130584 Adaptive144Third141Node74 = false := by
  decide +kernel

#print axioms adaptive144Third141Proof74

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third141Proof49 : runCachedNode 511 130584 Adaptive144Third141Node49 = false := by
  decide +kernel

#print axioms adaptive144Third141Proof49

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third141Proof277 : runCachedNode 511 130584 Adaptive144Third141Node277 = false := by
  decide +kernel

#print axioms adaptive144Third141Proof277

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third141Proof196 : runCachedNode 511 130584 Adaptive144Third141Node196 = false := by
  decide +kernel

#print axioms adaptive144Third141Proof196

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third141Proof229 : runCachedNode 511 130584 Adaptive144Third141Node229 = false := by
  decide +kernel

#print axioms adaptive144Third141Proof229

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third141Proof112 : runCachedNode 511 130584 Adaptive144Third141Node112 = false := by
  decide +kernel

#print axioms adaptive144Third141Proof112

end NineSeparatedSubsetSums
