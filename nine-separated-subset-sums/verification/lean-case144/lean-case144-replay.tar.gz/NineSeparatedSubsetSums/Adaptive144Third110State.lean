import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive144Third110Node0 : CachedSearchNode :=
  ⟨4, 109, computeCenteredMask [148,144,110], 402, 54740⟩

end NineSeparatedSubsetSums
