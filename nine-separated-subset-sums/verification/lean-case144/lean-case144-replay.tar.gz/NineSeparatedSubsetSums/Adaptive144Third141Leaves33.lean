import NineSeparatedSubsetSums.Adaptive144Third141State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third141Proof341 : runCachedNode 511 130584 Adaptive144Third141Node341 = false := by
  decide +kernel

#print axioms adaptive144Third141Proof341

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third141Proof67 : runCachedNode 511 130584 Adaptive144Third141Node67 = false := by
  decide +kernel

#print axioms adaptive144Third141Proof67

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third141Proof223 : runCachedNode 511 130584 Adaptive144Third141Node223 = false := by
  decide +kernel

#print axioms adaptive144Third141Proof223

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third141Proof69 : runCachedNode 511 130584 Adaptive144Third141Node69 = false := by
  decide +kernel

#print axioms adaptive144Third141Proof69

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third141Proof95 : runCachedNode 511 130584 Adaptive144Third141Node95 = false := by
  decide +kernel

#print axioms adaptive144Third141Proof95

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third141Proof429 : runCachedNode 511 130584 Adaptive144Third141Node429 = false := by
  decide +kernel

#print axioms adaptive144Third141Proof429

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third141Proof94 : runCachedNode 511 130584 Adaptive144Third141Node94 = false := by
  decide +kernel

#print axioms adaptive144Third141Proof94

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third141Proof340 : runCachedNode 511 130584 Adaptive144Third141Node340 = false := by
  decide +kernel

#print axioms adaptive144Third141Proof340

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third141Proof160 : runCachedNode 511 130584 Adaptive144Third141Node160 = false := by
  decide +kernel

#print axioms adaptive144Third141Proof160

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third141Proof161 : runCachedNode 511 130584 Adaptive144Third141Node161 = false := by
  decide +kernel

#print axioms adaptive144Third141Proof161

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third141Proof385 : runCachedNode 511 130584 Adaptive144Third141Node385 = false := by
  decide +kernel

#print axioms adaptive144Third141Proof385

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third141Proof187 : runCachedNode 511 130584 Adaptive144Third141Node187 = false := by
  decide +kernel

#print axioms adaptive144Third141Proof187

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third141Proof186 : runCachedNode 511 130584 Adaptive144Third141Node186 = false := by
  decide +kernel

#print axioms adaptive144Third141Proof186

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third141Proof222 : runCachedNode 511 130584 Adaptive144Third141Node222 = false := by
  decide +kernel

#print axioms adaptive144Third141Proof222

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third141Proof128 : runCachedNode 511 130584 Adaptive144Third141Node128 = false := by
  decide +kernel

#print axioms adaptive144Third141Proof128

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third141Proof10 : runCachedNode 511 130584 Adaptive144Third141Node10 = false := by
  decide +kernel

#print axioms adaptive144Third141Proof10

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third141Proof383 : runCachedNode 511 130584 Adaptive144Third141Node383 = false := by
  decide +kernel

#print axioms adaptive144Third141Proof383

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third141Proof295 : runCachedNode 511 130584 Adaptive144Third141Node295 = false := by
  decide +kernel

#print axioms adaptive144Third141Proof295

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third141Proof158 : runCachedNode 511 130584 Adaptive144Third141Node158 = false := by
  decide +kernel

#print axioms adaptive144Third141Proof158

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third141Proof180 : runCachedNode 511 130584 Adaptive144Third141Node180 = false := by
  decide +kernel

#print axioms adaptive144Third141Proof180

end NineSeparatedSubsetSums
