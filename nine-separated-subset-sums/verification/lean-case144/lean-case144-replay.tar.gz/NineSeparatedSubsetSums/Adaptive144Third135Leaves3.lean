import NineSeparatedSubsetSums.Adaptive144Third135State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third135Proof18 : runCachedNode 511 129692 Adaptive144Third135Node18 = false := by
  decide +kernel

#print axioms adaptive144Third135Proof18

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third135Proof15 : runCachedNode 511 129692 Adaptive144Third135Node15 = false := by
  decide +kernel

#print axioms adaptive144Third135Proof15

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third135Proof99 : runCachedNode 511 129692 Adaptive144Third135Node99 = false := by
  decide +kernel

#print axioms adaptive144Third135Proof99

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third135Proof1 : runCachedNode 511 129692 Adaptive144Third135Node1 = false := by
  decide +kernel

#print axioms adaptive144Third135Proof1

end NineSeparatedSubsetSums
