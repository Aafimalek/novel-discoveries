import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive144Third118Node0 : CachedSearchNode :=
  ⟨4, 117, computeCenteredMask [148,144,118], 410, 56564⟩

end NineSeparatedSubsetSums
