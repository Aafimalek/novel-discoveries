import NineSeparatedSubsetSums.Adaptive144Third140State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof258 : runCachedNode 511 130381 Adaptive144Third140Node258 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof258

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof490 : runCachedNode 511 130381 Adaptive144Third140Node490 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof490

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof64 : runCachedNode 511 130381 Adaptive144Third140Node64 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof64

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof41 : runCachedNode 511 130381 Adaptive144Third140Node41 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof41

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof675 : runCachedNode 511 130381 Adaptive144Third140Node675 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof675

end NineSeparatedSubsetSums
