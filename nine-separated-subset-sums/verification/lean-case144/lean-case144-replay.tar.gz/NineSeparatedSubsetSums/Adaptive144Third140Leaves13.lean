import NineSeparatedSubsetSums.Adaptive144Third140State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof141 : runCachedNode 511 130381 Adaptive144Third140Node141 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof141

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof201 : runCachedNode 511 130381 Adaptive144Third140Node201 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof201

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third140Proof205 : runCachedNode 511 130381 Adaptive144Third140Node205 = false := by
  decide +kernel

#print axioms adaptive144Third140Proof205

end NineSeparatedSubsetSums
