import NineSeparatedSubsetSums.Adaptive144Third143State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third143Proof225 : runCachedNode 511 130885 Adaptive144Third143Node225 = false := by
  decide +kernel

#print axioms adaptive144Third143Proof225

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third143Proof615 : runCachedNode 511 130885 Adaptive144Third143Node615 = false := by
  decide +kernel

#print axioms adaptive144Third143Proof615

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third143Proof322 : runCachedNode 511 130885 Adaptive144Third143Node322 = false := by
  decide +kernel

#print axioms adaptive144Third143Proof322

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third143Proof656 : runCachedNode 511 130885 Adaptive144Third143Node656 = false := by
  decide +kernel

#print axioms adaptive144Third143Proof656

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third143Proof323 : runCachedNode 511 130885 Adaptive144Third143Node323 = false := by
  decide +kernel

#print axioms adaptive144Third143Proof323

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third143Proof321 : runCachedNode 511 130885 Adaptive144Third143Node321 = false := by
  decide +kernel

#print axioms adaptive144Third143Proof321

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive144Third143Proof130 : runCachedNode 511 130885 Adaptive144Third143Node130 = false := by
  decide +kernel

#print axioms adaptive144Third143Proof130

end NineSeparatedSubsetSums
