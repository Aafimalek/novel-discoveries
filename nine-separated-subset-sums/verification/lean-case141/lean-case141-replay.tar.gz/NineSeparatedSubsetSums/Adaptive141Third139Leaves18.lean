import NineSeparatedSubsetSums.Adaptive141Third139State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third139Proof156 : runCachedNode 511 129747 Adaptive141Third139Node156 = false := by
  decide +kernel

#print axioms adaptive141Third139Proof156

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third139Proof250 : runCachedNode 511 129747 Adaptive141Third139Node250 = false := by
  decide +kernel

#print axioms adaptive141Third139Proof250

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third139Proof180 : runCachedNode 511 129747 Adaptive141Third139Node180 = false := by
  decide +kernel

#print axioms adaptive141Third139Proof180

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third139Proof38 : runCachedNode 511 129747 Adaptive141Third139Node38 = false := by
  decide +kernel

#print axioms adaptive141Third139Proof38

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third139Proof125 : runCachedNode 511 129747 Adaptive141Third139Node125 = false := by
  decide +kernel

#print axioms adaptive141Third139Proof125

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third139Proof67 : runCachedNode 511 129747 Adaptive141Third139Node67 = false := by
  decide +kernel

#print axioms adaptive141Third139Proof67

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third139Proof89 : runCachedNode 511 129747 Adaptive141Third139Node89 = false := by
  decide +kernel

#print axioms adaptive141Third139Proof89

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third139Proof122 : runCachedNode 511 129747 Adaptive141Third139Node122 = false := by
  decide +kernel

#print axioms adaptive141Third139Proof122

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third139Proof249 : runCachedNode 511 129747 Adaptive141Third139Node249 = false := by
  decide +kernel

#print axioms adaptive141Third139Proof249

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third139Proof151 : runCachedNode 511 129747 Adaptive141Third139Node151 = false := by
  decide +kernel

#print axioms adaptive141Third139Proof151

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third139Proof126 : runCachedNode 511 129747 Adaptive141Third139Node126 = false := by
  decide +kernel

#print axioms adaptive141Third139Proof126

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third139Proof252 : runCachedNode 511 129747 Adaptive141Third139Node252 = false := by
  decide +kernel

#print axioms adaptive141Third139Proof252

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third139Proof90 : runCachedNode 511 129747 Adaptive141Third139Node90 = false := by
  decide +kernel

#print axioms adaptive141Third139Proof90

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third139Proof66 : runCachedNode 511 129747 Adaptive141Third139Node66 = false := by
  decide +kernel

#print axioms adaptive141Third139Proof66

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third139Proof178 : runCachedNode 511 129747 Adaptive141Third139Node178 = false := by
  decide +kernel

#print axioms adaptive141Third139Proof178

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third139Proof222 : runCachedNode 511 129747 Adaptive141Third139Node222 = false := by
  decide +kernel

#print axioms adaptive141Third139Proof222

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third139Proof87 : runCachedNode 511 129747 Adaptive141Third139Node87 = false := by
  decide +kernel

#print axioms adaptive141Third139Proof87

end NineSeparatedSubsetSums
