import NineSeparatedSubsetSums.Adaptive141Third140State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third140Proof274 : runCachedNode 511 129930 Adaptive141Third140Node274 = false := by
  decide +kernel

#print axioms adaptive141Third140Proof274

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third140Proof168 : runCachedNode 511 129930 Adaptive141Third140Node168 = false := by
  decide +kernel

#print axioms adaptive141Third140Proof168

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third140Proof90 : runCachedNode 511 129930 Adaptive141Third140Node90 = false := by
  decide +kernel

#print axioms adaptive141Third140Proof90

end NineSeparatedSubsetSums
