import NineSeparatedSubsetSums.Adaptive141Third108Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint141Checked

namespace NineSeparatedSubsetSums


theorem adaptive141Third108 : NoDescendingTailAfterThird 141 108 :=
  noDescendingThirdTail_of_cached 141 108 111653 (fun t ht nd => max148_second141_fourPoint_moment_bound (108::t) (by simp [ht]) nd) adaptive141Third108Proof0

#print axioms adaptive141Third108

end NineSeparatedSubsetSums
