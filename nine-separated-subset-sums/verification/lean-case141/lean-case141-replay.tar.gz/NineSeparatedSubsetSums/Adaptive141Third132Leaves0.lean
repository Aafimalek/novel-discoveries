import NineSeparatedSubsetSums.Adaptive141Third132State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third132Proof21 : runCachedNode 511 128536 Adaptive141Third132Node21 = false := by
  decide +kernel

#print axioms adaptive141Third132Proof21

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third132Proof17 : runCachedNode 511 128536 Adaptive141Third132Node17 = false := by
  decide +kernel

#print axioms adaptive141Third132Proof17

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third132Proof2 : runCachedNode 511 128536 Adaptive141Third132Node2 = false := by
  decide +kernel

#print axioms adaptive141Third132Proof2

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third132Proof1 : runCachedNode 511 128536 Adaptive141Third132Node1 = false := by
  decide +kernel

#print axioms adaptive141Third132Proof1

end NineSeparatedSubsetSums
