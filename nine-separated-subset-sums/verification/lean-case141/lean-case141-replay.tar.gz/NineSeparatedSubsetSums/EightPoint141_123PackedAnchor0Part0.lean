import NineSeparatedSubsetSums.EightPoint141_123PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint141_123PackedAnchor0Part0 :
    ∀ j : Fin 120, 2302596 ≤ FourPointNumeric.octPackedCharge 141 123 20 packedOct141_123_0
      (2*((j.val : Int)+0)+0) := by decide +kernel

end NineSeparatedSubsetSums
