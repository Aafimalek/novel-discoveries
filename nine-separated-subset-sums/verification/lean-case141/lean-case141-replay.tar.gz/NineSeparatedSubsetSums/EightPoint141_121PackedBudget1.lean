import NineSeparatedSubsetSums.EightPoint141_121PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct141_121_1_budget :
    FourPointNumeric.packedBudget 20 packedOct141_121_1 264 = 82746070 := by decide +kernel

#print axioms packedOct141_121_1_budget

end NineSeparatedSubsetSums
