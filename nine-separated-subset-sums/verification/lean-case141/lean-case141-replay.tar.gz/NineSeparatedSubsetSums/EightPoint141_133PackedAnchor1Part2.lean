import NineSeparatedSubsetSums.EightPoint141_133PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint141_133PackedAnchor1Part2 :
    ∀ j : Fin 9, 2455404 ≤ FourPointNumeric.octPackedCharge 141 133 20 packedOct141_133_1
      (2*((j.val : Int)+240)+1) := by decide +kernel

end NineSeparatedSubsetSums
