import NineSeparatedSubsetSums.Adaptive141Third137State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third137Proof105 : runCachedNode 511 129418 Adaptive141Third137Node105 = false := by
  decide +kernel

#print axioms adaptive141Third137Proof105

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third137Proof17 : runCachedNode 511 129418 Adaptive141Third137Node17 = false := by
  decide +kernel

#print axioms adaptive141Third137Proof17

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third137Proof57 : runCachedNode 511 129418 Adaptive141Third137Node57 = false := by
  decide +kernel

#print axioms adaptive141Third137Proof57

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third137Proof80 : runCachedNode 511 129418 Adaptive141Third137Node80 = false := by
  decide +kernel

#print axioms adaptive141Third137Proof80

end NineSeparatedSubsetSums
