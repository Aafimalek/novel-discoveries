import NineSeparatedSubsetSums.Adaptive141Third139State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third139Proof124 : runCachedNode 511 129747 Adaptive141Third139Node124 = false := by
  decide +kernel

#print axioms adaptive141Third139Proof124

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third139Proof155 : runCachedNode 511 129747 Adaptive141Third139Node155 = false := by
  decide +kernel

#print axioms adaptive141Third139Proof155

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third139Proof11 : runCachedNode 511 129747 Adaptive141Third139Node11 = false := by
  decide +kernel

#print axioms adaptive141Third139Proof11

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third139Proof39 : runCachedNode 511 129747 Adaptive141Third139Node39 = false := by
  decide +kernel

#print axioms adaptive141Third139Proof39

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third139Proof254 : runCachedNode 511 129747 Adaptive141Third139Node254 = false := by
  decide +kernel

#print axioms adaptive141Third139Proof254

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third139Proof223 : runCachedNode 511 129747 Adaptive141Third139Node223 = false := by
  decide +kernel

#print axioms adaptive141Third139Proof223

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third139Proof92 : runCachedNode 511 129747 Adaptive141Third139Node92 = false := by
  decide +kernel

#print axioms adaptive141Third139Proof92

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third139Proof153 : runCachedNode 511 129747 Adaptive141Third139Node153 = false := by
  decide +kernel

#print axioms adaptive141Third139Proof153

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third139Proof179 : runCachedNode 511 129747 Adaptive141Third139Node179 = false := by
  decide +kernel

#print axioms adaptive141Third139Proof179

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third139Proof40 : runCachedNode 511 129747 Adaptive141Third139Node40 = false := by
  decide +kernel

#print axioms adaptive141Third139Proof40

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third139Proof37 : runCachedNode 511 129747 Adaptive141Third139Node37 = false := by
  decide +kernel

#print axioms adaptive141Third139Proof37

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third139Proof10 : runCachedNode 511 129747 Adaptive141Third139Node10 = false := by
  decide +kernel

#print axioms adaptive141Third139Proof10

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third139Proof147 : runCachedNode 511 129747 Adaptive141Third139Node147 = false := by
  decide +kernel

#print axioms adaptive141Third139Proof147

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third139Proof1 : runCachedNode 511 129747 Adaptive141Third139Node1 = false := by
  decide +kernel

#print axioms adaptive141Third139Proof1

end NineSeparatedSubsetSums
