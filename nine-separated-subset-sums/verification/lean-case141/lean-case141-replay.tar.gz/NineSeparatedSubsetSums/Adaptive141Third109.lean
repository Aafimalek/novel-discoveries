import NineSeparatedSubsetSums.Adaptive141Third109Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint141Checked

namespace NineSeparatedSubsetSums


theorem adaptive141Third109 : NoDescendingTailAfterThird 141 109 :=
  noDescendingThirdTail_of_cached 141 109 111653 (fun t ht nd => max148_second141_fourPoint_moment_bound (109::t) (by simp [ht]) nd) adaptive141Third109Proof0

#print axioms adaptive141Third109

end NineSeparatedSubsetSums
