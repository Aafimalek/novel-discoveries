import NineSeparatedSubsetSums.EightPoint141_126PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint141_126PackedAnchor1Part0 :
    ∀ j : Fin 120, 2351518 ≤ FourPointNumeric.octPackedCharge 141 126 20 packedOct141_126_1
      (2*((j.val : Int)+0)+0) := by decide +kernel

end NineSeparatedSubsetSums
