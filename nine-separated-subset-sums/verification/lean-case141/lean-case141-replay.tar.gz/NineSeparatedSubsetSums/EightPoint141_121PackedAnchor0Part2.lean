import NineSeparatedSubsetSums.EightPoint141_121PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint141_121PackedAnchor0Part2 :
    ∀ j : Fin 1, 2303982 ≤ FourPointNumeric.octPackedCharge 141 121 20 packedOct141_121_0
      (2*((j.val : Int)+240)+0) := by decide +kernel

end NineSeparatedSubsetSums
