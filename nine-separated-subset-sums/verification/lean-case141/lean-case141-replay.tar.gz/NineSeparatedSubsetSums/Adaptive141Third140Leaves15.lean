import NineSeparatedSubsetSums.Adaptive141Third140State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third140Proof17 : runCachedNode 511 129930 Adaptive141Third140Node17 = false := by
  decide +kernel

#print axioms adaptive141Third140Proof17

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third140Proof166 : runCachedNode 511 129930 Adaptive141Third140Node166 = false := by
  decide +kernel

#print axioms adaptive141Third140Proof166

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third140Proof226 : runCachedNode 511 129930 Adaptive141Third140Node226 = false := by
  decide +kernel

#print axioms adaptive141Third140Proof226

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third140Proof34 : runCachedNode 511 129930 Adaptive141Third140Node34 = false := by
  decide +kernel

#print axioms adaptive141Third140Proof34

end NineSeparatedSubsetSums
