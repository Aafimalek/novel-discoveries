import NineSeparatedSubsetSums.Adaptive141Third132State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third132Proof19 : runCachedNode 511 128536 Adaptive141Third132Node19 = false := by
  decide +kernel

#print axioms adaptive141Third132Proof19

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third132Proof18 : runCachedNode 511 128536 Adaptive141Third132Node18 = false := by
  decide +kernel

#print axioms adaptive141Third132Proof18

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third132Proof13 : runCachedNode 511 128536 Adaptive141Third132Node13 = false := by
  decide +kernel

#print axioms adaptive141Third132Proof13

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third132Proof10 : runCachedNode 511 128536 Adaptive141Third132Node10 = false := by
  decide +kernel

#print axioms adaptive141Third132Proof10

end NineSeparatedSubsetSums
