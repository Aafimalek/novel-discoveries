import NineSeparatedSubsetSums.Adaptive141Third134State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third134Proof19 : runCachedNode 511 128866 Adaptive141Third134Node19 = false := by
  decide +kernel

#print axioms adaptive141Third134Proof19

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third134Proof37 : runCachedNode 511 128866 Adaptive141Third134Node37 = false := by
  decide +kernel

#print axioms adaptive141Third134Proof37

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third134Proof23 : runCachedNode 511 128866 Adaptive141Third134Node23 = false := by
  decide +kernel

#print axioms adaptive141Third134Proof23

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third134Proof95 : runCachedNode 511 128866 Adaptive141Third134Node95 = false := by
  decide +kernel

#print axioms adaptive141Third134Proof95

end NineSeparatedSubsetSums
