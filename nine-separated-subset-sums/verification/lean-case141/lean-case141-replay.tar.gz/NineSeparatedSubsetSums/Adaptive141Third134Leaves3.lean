import NineSeparatedSubsetSums.Adaptive141Third134State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third134Proof17 : runCachedNode 511 128866 Adaptive141Third134Node17 = false := by
  decide +kernel

#print axioms adaptive141Third134Proof17

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third134Proof92 : runCachedNode 511 128866 Adaptive141Third134Node92 = false := by
  decide +kernel

#print axioms adaptive141Third134Proof92

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third134Proof34 : runCachedNode 511 128866 Adaptive141Third134Node34 = false := by
  decide +kernel

#print axioms adaptive141Third134Proof34

end NineSeparatedSubsetSums
