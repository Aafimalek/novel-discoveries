import NineSeparatedSubsetSums.Adaptive141Third140State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third140Proof136 : runCachedNode 511 129930 Adaptive141Third140Node136 = false := by
  decide +kernel

#print axioms adaptive141Third140Proof136

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third140Proof73 : runCachedNode 511 129930 Adaptive141Third140Node73 = false := by
  decide +kernel

#print axioms adaptive141Third140Proof73

end NineSeparatedSubsetSums
