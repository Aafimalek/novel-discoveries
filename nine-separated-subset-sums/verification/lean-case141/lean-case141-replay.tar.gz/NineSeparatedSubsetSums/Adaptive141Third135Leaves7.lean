import NineSeparatedSubsetSums.Adaptive141Third135State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third135Proof14 : runCachedNode 511 129079 Adaptive141Third135Node14 = false := by
  decide +kernel

#print axioms adaptive141Third135Proof14

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third135Proof95 : runCachedNode 511 129079 Adaptive141Third135Node95 = false := by
  decide +kernel

#print axioms adaptive141Third135Proof95

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third135Proof97 : runCachedNode 511 129079 Adaptive141Third135Node97 = false := by
  decide +kernel

#print axioms adaptive141Third135Proof97

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third135Proof93 : runCachedNode 511 129079 Adaptive141Third135Node93 = false := by
  decide +kernel

#print axioms adaptive141Third135Proof93

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third135Proof12 : runCachedNode 511 129079 Adaptive141Third135Node12 = false := by
  decide +kernel

#print axioms adaptive141Third135Proof12

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third135Proof69 : runCachedNode 511 129079 Adaptive141Third135Node69 = false := by
  decide +kernel

#print axioms adaptive141Third135Proof69

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third135Proof94 : runCachedNode 511 129079 Adaptive141Third135Node94 = false := by
  decide +kernel

#print axioms adaptive141Third135Proof94

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third135Proof38 : runCachedNode 511 129079 Adaptive141Third135Node38 = false := by
  decide +kernel

#print axioms adaptive141Third135Proof38

end NineSeparatedSubsetSums
