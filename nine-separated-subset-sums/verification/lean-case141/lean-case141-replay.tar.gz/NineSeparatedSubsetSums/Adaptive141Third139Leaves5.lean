import NineSeparatedSubsetSums.Adaptive141Third139State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third139Proof259 : runCachedNode 511 129747 Adaptive141Third139Node259 = false := by
  decide +kernel

#print axioms adaptive141Third139Proof259

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third139Proof226 : runCachedNode 511 129747 Adaptive141Third139Node226 = false := by
  decide +kernel

#print axioms adaptive141Third139Proof226

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third139Proof173 : runCachedNode 511 129747 Adaptive141Third139Node173 = false := by
  decide +kernel

#print axioms adaptive141Third139Proof173

end NineSeparatedSubsetSums
