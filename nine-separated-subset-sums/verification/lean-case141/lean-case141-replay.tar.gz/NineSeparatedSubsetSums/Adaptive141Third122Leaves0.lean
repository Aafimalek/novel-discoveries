import NineSeparatedSubsetSums.Adaptive141Third122State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third122Proof0 : runCachedNode 511 126125 Adaptive141Third122Node0 = false := by
  decide +kernel

#print axioms adaptive141Third122Proof0

end NineSeparatedSubsetSums
