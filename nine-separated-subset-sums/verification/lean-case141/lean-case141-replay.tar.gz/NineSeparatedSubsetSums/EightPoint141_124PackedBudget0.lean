import NineSeparatedSubsetSums.EightPoint141_124PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct141_124_0_budget :
    FourPointNumeric.packedBudget 20 packedOct141_124_0 479 = 84152267 := by decide +kernel

#print axioms packedOct141_124_0_budget

end NineSeparatedSubsetSums
