import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive141Third105Node0 : CachedSearchNode :=
  ⟨4, 104, computeCenteredMask [148,141,105], 394, 52810⟩

end NineSeparatedSubsetSums
