import NineSeparatedSubsetSums.Adaptive141Third128State
import NineSeparatedSubsetSums.Adaptive141Third128Leaves1
import NineSeparatedSubsetSums.Adaptive141Third128Leaves0

namespace NineSeparatedSubsetSums

theorem adaptive141Third128Proof0 : runCachedNode 511 127705 Adaptive141Third128Node0 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 127705 Adaptive141Third128Node0 = [111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 122, 123, 124, 125, 126, 127] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive141Third128Proof1
  · exact adaptive141Third128Proof2
  · exact adaptive141Third128Proof3
  · exact adaptive141Third128Proof4
  · exact adaptive141Third128Proof5
  · exact adaptive141Third128Proof6
  · exact adaptive141Third128Proof7
  · exact adaptive141Third128Proof8
  · exact adaptive141Third128Proof9
  · exact adaptive141Third128Proof10
  · exact adaptive141Third128Proof11
  · exact adaptive141Third128Proof12
  · exact adaptive141Third128Proof13
  · exact adaptive141Third128Proof14
  · exact adaptive141Third128Proof15
  · exact adaptive141Third128Proof16

#print axioms adaptive141Third128Proof0

end NineSeparatedSubsetSums
