import NineSeparatedSubsetSums.EightPoint141_139PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct141_139_1_budget :
    FourPointNumeric.packedBudget 20 packedOct141_139_1 272 = 93800612 := by decide +kernel

#print axioms packedOct141_139_1_budget

end NineSeparatedSubsetSums
