import NineSeparatedSubsetSums.EightPoint141_139PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct141_139_0_budget :
    FourPointNumeric.packedBudget 20 packedOct141_139_0 271 = 93911004 := by decide +kernel

#print axioms packedOct141_139_0_budget

end NineSeparatedSubsetSums
