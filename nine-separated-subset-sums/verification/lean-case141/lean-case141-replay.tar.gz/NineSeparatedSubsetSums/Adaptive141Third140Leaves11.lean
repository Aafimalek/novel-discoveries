import NineSeparatedSubsetSums.Adaptive141Third140State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third140Proof20 : runCachedNode 511 129930 Adaptive141Third140Node20 = false := by
  decide +kernel

#print axioms adaptive141Third140Proof20

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third140Proof48 : runCachedNode 511 129930 Adaptive141Third140Node48 = false := by
  decide +kernel

#print axioms adaptive141Third140Proof48

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third140Proof63 : runCachedNode 511 129930 Adaptive141Third140Node63 = false := by
  decide +kernel

#print axioms adaptive141Third140Proof63

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third140Proof108 : runCachedNode 511 129930 Adaptive141Third140Node108 = false := by
  decide +kernel

#print axioms adaptive141Third140Proof108

end NineSeparatedSubsetSums
