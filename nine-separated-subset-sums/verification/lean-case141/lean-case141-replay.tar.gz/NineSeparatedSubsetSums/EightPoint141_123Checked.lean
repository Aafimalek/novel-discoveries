import NineSeparatedSubsetSums.EightPointPackedGeometry
import NineSeparatedSubsetSums.EightPoint141_123PackedBudget0
import NineSeparatedSubsetSums.EightPoint141_123PackedAnchor0Part0
import NineSeparatedSubsetSums.EightPoint141_123PackedAnchor0Part1
import NineSeparatedSubsetSums.EightPoint141_123PackedAnchor0Part2
import NineSeparatedSubsetSums.EightPoint141_123PackedBudget1
import NineSeparatedSubsetSums.EightPoint141_123PackedAnchor1Part0
import NineSeparatedSubsetSums.EightPoint141_123PackedAnchor1Part1

namespace NineSeparatedSubsetSums

private theorem packedOct141_123Anchor0 :
  ∀ j : Fin 481, ((j.val : Int)+141+123)%2=0 →
    2302596 ≤ FourPointNumeric.octPackedCharge 141 123 20 packedOct141_123_0 (j.val : Int) := by
  intro j hj
  let k := (j.val-0)/2
  have hk : k < 241 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+0 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint141_123PackedAnchor0Part0 z
    rwa [he,hrep] at ht
  by_cases h1 : k < 240
  · let z : Fin 120 := ⟨k-120, by omega⟩
    have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
    have ht := eightPoint141_123PackedAnchor0Part1 z
    rwa [he,hrep] at ht
  let z : Fin 1 := ⟨k-240, by omega⟩
  have he : (z.val : Int)+240 = k := by dsimp [z] <;> omega
  have ht := eightPoint141_123PackedAnchor0Part2 z
  rwa [he,hrep] at ht

private theorem packedOct141_123Anchor1 :
  ∀ j : Fin 481, ((j.val : Int)+141+123)%2=1 →
    2303533 ≤ FourPointNumeric.octPackedCharge 141 123 20 packedOct141_123_1 (j.val : Int) := by
  intro j hj
  let k := (j.val-1)/2
  have hk : k < 240 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+1 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint141_123PackedAnchor1Part0 z
    rwa [he,hrep] at ht
  let z : Fin 120 := ⟨k-120, by omega⟩
  have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
  have ht := eightPoint141_123PackedAnchor1Part1 z
  rwa [he,hrep] at ht

def packedOctCertificate141_123_0 : EightPointCertificate 141 123 0 126322 :=
  eightPointCertificateOfPacked 141 123 0 126322 2302596 20 packedOct141_123_0 391 481
    (by decide +kernel) (by decide) packedOct141_123Anchor0
    (by rw [packedOct141_123_0_budget]; decide)

def packedOctCertificate141_123_1 : EightPointCertificate 141 123 1 126322 :=
  eightPointCertificateOfPacked 141 123 1 126322 2303533 20 packedOct141_123_1 280 481
    (by decide +kernel) (by decide) packedOct141_123Anchor1
    (by rw [packedOct141_123_1_budget]; decide)

theorem max148_second141_third123_eightPoint_moment_bound (tail : List ℕ) (len : tail.length=6)
    (distinct : (natSubsetSums (148::141::123::tail)).Nodup) :
    126322 ≤ ((148::141::123::tail).map (· ^ 2)).sum := by
  apply eightPointNatMomentLower 141 123 126322 tail len distinct
  intro p hp
  by_cases h : p=0
  · subst p
    exact packedOctCertificate141_123_0
  · have he : p=1 := hp.resolve_left h
    subst p
    exact packedOctCertificate141_123_1

#print axioms max148_second141_third123_eightPoint_moment_bound

end NineSeparatedSubsetSums
