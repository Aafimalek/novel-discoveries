import NineSeparatedSubsetSums.Adaptive141Third138State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third138Proof46 : runCachedNode 511 129566 Adaptive141Third138Node46 = false := by
  decide +kernel

#print axioms adaptive141Third138Proof46

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third138Proof73 : runCachedNode 511 129566 Adaptive141Third138Node73 = false := by
  decide +kernel

#print axioms adaptive141Third138Proof73

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third138Proof201 : runCachedNode 511 129566 Adaptive141Third138Node201 = false := by
  decide +kernel

#print axioms adaptive141Third138Proof201

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third138Proof129 : runCachedNode 511 129566 Adaptive141Third138Node129 = false := by
  decide +kernel

#print axioms adaptive141Third138Proof129

end NineSeparatedSubsetSums
