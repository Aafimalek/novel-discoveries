import NineSeparatedSubsetSums.Adaptive141Third136State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third136Proof43 : runCachedNode 511 129226 Adaptive141Third136Node43 = false := by
  decide +kernel

#print axioms adaptive141Third136Proof43

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third136Proof93 : runCachedNode 511 129226 Adaptive141Third136Node93 = false := by
  decide +kernel

#print axioms adaptive141Third136Proof93

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third136Proof13 : runCachedNode 511 129226 Adaptive141Third136Node13 = false := by
  decide +kernel

#print axioms adaptive141Third136Proof13

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third136Proof94 : runCachedNode 511 129226 Adaptive141Third136Node94 = false := by
  decide +kernel

#print axioms adaptive141Third136Proof94

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third136Proof122 : runCachedNode 511 129226 Adaptive141Third136Node122 = false := by
  decide +kernel

#print axioms adaptive141Third136Proof122

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third136Proof125 : runCachedNode 511 129226 Adaptive141Third136Node125 = false := by
  decide +kernel

#print axioms adaptive141Third136Proof125

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third136Proof60 : runCachedNode 511 129226 Adaptive141Third136Node60 = false := by
  decide +kernel

#print axioms adaptive141Third136Proof60

end NineSeparatedSubsetSums
