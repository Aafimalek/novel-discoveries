import NineSeparatedSubsetSums.Adaptive141Third140State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third140Proof201 : runCachedNode 511 129930 Adaptive141Third140Node201 = false := by
  decide +kernel

#print axioms adaptive141Third140Proof201

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third140Proof223 : runCachedNode 511 129930 Adaptive141Third140Node223 = false := by
  decide +kernel

#print axioms adaptive141Third140Proof223

end NineSeparatedSubsetSums
