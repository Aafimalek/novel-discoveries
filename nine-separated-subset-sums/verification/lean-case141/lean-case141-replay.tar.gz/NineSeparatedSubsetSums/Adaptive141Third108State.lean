import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive141Third108Node0 : CachedSearchNode :=
  ⟨4, 107, computeCenteredMask [148,141,108], 397, 53449⟩

end NineSeparatedSubsetSums
