import NineSeparatedSubsetSums.EightPoint141_138PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint141_138PackedAnchor0Part1 :
    ∀ j : Fin 120, 2495833 ≤ FourPointNumeric.octPackedCharge 141 138 20 packedOct141_138_0
      (2*((j.val : Int)+120)+1) := by decide +kernel

end NineSeparatedSubsetSums
