import NineSeparatedSubsetSums.Adaptive141Third103Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint141Checked

namespace NineSeparatedSubsetSums


theorem adaptive141Third103 : NoDescendingTailAfterThird 141 103 :=
  noDescendingThirdTail_of_cached 141 103 111653 (fun t ht nd => max148_second141_fourPoint_moment_bound (103::t) (by simp [ht]) nd) adaptive141Third103Proof0

#print axioms adaptive141Third103

end NineSeparatedSubsetSums
