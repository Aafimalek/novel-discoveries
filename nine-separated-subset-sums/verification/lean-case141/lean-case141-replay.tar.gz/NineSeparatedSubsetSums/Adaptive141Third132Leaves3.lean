import NineSeparatedSubsetSums.Adaptive141Third132State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third132Proof15 : runCachedNode 511 128536 Adaptive141Third132Node15 = false := by
  decide +kernel

#print axioms adaptive141Third132Proof15

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third132Proof14 : runCachedNode 511 128536 Adaptive141Third132Node14 = false := by
  decide +kernel

#print axioms adaptive141Third132Proof14

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third132Proof12 : runCachedNode 511 128536 Adaptive141Third132Node12 = false := by
  decide +kernel

#print axioms adaptive141Third132Proof12

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third132Proof9 : runCachedNode 511 128536 Adaptive141Third132Node9 = false := by
  decide +kernel

#print axioms adaptive141Third132Proof9

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third132Proof8 : runCachedNode 511 128536 Adaptive141Third132Node8 = false := by
  decide +kernel

#print axioms adaptive141Third132Proof8

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third132Proof7 : runCachedNode 511 128536 Adaptive141Third132Node7 = false := by
  decide +kernel

#print axioms adaptive141Third132Proof7

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third132Proof6 : runCachedNode 511 128536 Adaptive141Third132Node6 = false := by
  decide +kernel

#print axioms adaptive141Third132Proof6

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third132Proof5 : runCachedNode 511 128536 Adaptive141Third132Node5 = false := by
  decide +kernel

#print axioms adaptive141Third132Proof5

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third132Proof4 : runCachedNode 511 128536 Adaptive141Third132Node4 = false := by
  decide +kernel

#print axioms adaptive141Third132Proof4

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third132Proof3 : runCachedNode 511 128536 Adaptive141Third132Node3 = false := by
  decide +kernel

#print axioms adaptive141Third132Proof3

end NineSeparatedSubsetSums
