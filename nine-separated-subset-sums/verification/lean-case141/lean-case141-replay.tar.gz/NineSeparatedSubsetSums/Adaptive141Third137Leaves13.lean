import NineSeparatedSubsetSums.Adaptive141Third137State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third137Proof68 : runCachedNode 511 129418 Adaptive141Third137Node68 = false := by
  decide +kernel

#print axioms adaptive141Third137Proof68

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third137Proof11 : runCachedNode 511 129418 Adaptive141Third137Node11 = false := by
  decide +kernel

#print axioms adaptive141Third137Proof11

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third137Proof42 : runCachedNode 511 129418 Adaptive141Third137Node42 = false := by
  decide +kernel

#print axioms adaptive141Third137Proof42

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third137Proof102 : runCachedNode 511 129418 Adaptive141Third137Node102 = false := by
  decide +kernel

#print axioms adaptive141Third137Proof102

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third137Proof69 : runCachedNode 511 129418 Adaptive141Third137Node69 = false := by
  decide +kernel

#print axioms adaptive141Third137Proof69

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third137Proof10 : runCachedNode 511 129418 Adaptive141Third137Node10 = false := by
  decide +kernel

#print axioms adaptive141Third137Proof10

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third137Proof39 : runCachedNode 511 129418 Adaptive141Third137Node39 = false := by
  decide +kernel

#print axioms adaptive141Third137Proof39

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third137Proof66 : runCachedNode 511 129418 Adaptive141Third137Node66 = false := by
  decide +kernel

#print axioms adaptive141Third137Proof66

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third137Proof40 : runCachedNode 511 129418 Adaptive141Third137Node40 = false := by
  decide +kernel

#print axioms adaptive141Third137Proof40

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third137Proof41 : runCachedNode 511 129418 Adaptive141Third137Node41 = false := by
  decide +kernel

#print axioms adaptive141Third137Proof41

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third137Proof98 : runCachedNode 511 129418 Adaptive141Third137Node98 = false := by
  decide +kernel

#print axioms adaptive141Third137Proof98

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third137Proof100 : runCachedNode 511 129418 Adaptive141Third137Node100 = false := by
  decide +kernel

#print axioms adaptive141Third137Proof100

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third137Proof128 : runCachedNode 511 129418 Adaptive141Third137Node128 = false := by
  decide +kernel

#print axioms adaptive141Third137Proof128

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third137Proof126 : runCachedNode 511 129418 Adaptive141Third137Node126 = false := by
  decide +kernel

#print axioms adaptive141Third137Proof126

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third137Proof65 : runCachedNode 511 129418 Adaptive141Third137Node65 = false := by
  decide +kernel

#print axioms adaptive141Third137Proof65

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third137Proof29 : runCachedNode 511 129418 Adaptive141Third137Node29 = false := by
  decide +kernel

#print axioms adaptive141Third137Proof29

end NineSeparatedSubsetSums
