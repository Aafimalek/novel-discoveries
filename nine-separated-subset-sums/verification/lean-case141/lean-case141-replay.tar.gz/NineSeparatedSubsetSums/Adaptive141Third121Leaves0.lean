import NineSeparatedSubsetSums.Adaptive141Third121State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third121Proof0 : runCachedNode 511 125914 Adaptive141Third121Node0 = false := by
  decide +kernel

#print axioms adaptive141Third121Proof0

end NineSeparatedSubsetSums
