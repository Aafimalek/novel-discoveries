import NineSeparatedSubsetSums.Adaptive141Third136State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third136Proof17 : runCachedNode 511 129226 Adaptive141Third136Node17 = false := by
  decide +kernel

#print axioms adaptive141Third136Proof17

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third136Proof18 : runCachedNode 511 129226 Adaptive141Third136Node18 = false := by
  decide +kernel

#print axioms adaptive141Third136Proof18

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third136Proof15 : runCachedNode 511 129226 Adaptive141Third136Node15 = false := by
  decide +kernel

#print axioms adaptive141Third136Proof15

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third136Proof10 : runCachedNode 511 129226 Adaptive141Third136Node10 = false := by
  decide +kernel

#print axioms adaptive141Third136Proof10

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third136Proof130 : runCachedNode 511 129226 Adaptive141Third136Node130 = false := by
  decide +kernel

#print axioms adaptive141Third136Proof130

end NineSeparatedSubsetSums
