import NineSeparatedSubsetSums.Adaptive141Third115Joins0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint141Checked

namespace NineSeparatedSubsetSums


theorem adaptive141Third115 : NoDescendingTailAfterThird 141 115 :=
  noDescendingThirdTail_of_cached 141 115 111653 (fun t ht nd => max148_second141_fourPoint_moment_bound (115::t) (by simp [ht]) nd) adaptive141Third115Proof0

#print axioms adaptive141Third115

end NineSeparatedSubsetSums
