import NineSeparatedSubsetSums.EightPoint141_120PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct141_120_1_budget :
    FourPointNumeric.packedBudget 20 packedOct141_120_1 268 = 85289030 := by decide +kernel

#print axioms packedOct141_120_1_budget

end NineSeparatedSubsetSums
