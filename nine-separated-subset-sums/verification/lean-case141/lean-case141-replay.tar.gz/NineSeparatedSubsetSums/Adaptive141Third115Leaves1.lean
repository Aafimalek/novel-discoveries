import NineSeparatedSubsetSums.Adaptive141Third115State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third115Proof9 : runCachedNode 511 111653 Adaptive141Third115Node9 = false := by
  decide +kernel

#print axioms adaptive141Third115Proof9

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third115Proof8 : runCachedNode 511 111653 Adaptive141Third115Node8 = false := by
  decide +kernel

#print axioms adaptive141Third115Proof8

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third115Proof7 : runCachedNode 511 111653 Adaptive141Third115Node7 = false := by
  decide +kernel

#print axioms adaptive141Third115Proof7

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third115Proof5 : runCachedNode 511 111653 Adaptive141Third115Node5 = false := by
  decide +kernel

#print axioms adaptive141Third115Proof5

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third115Proof4 : runCachedNode 511 111653 Adaptive141Third115Node4 = false := by
  decide +kernel

#print axioms adaptive141Third115Proof4

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third115Proof3 : runCachedNode 511 111653 Adaptive141Third115Node3 = false := by
  decide +kernel

#print axioms adaptive141Third115Proof3

end NineSeparatedSubsetSums
