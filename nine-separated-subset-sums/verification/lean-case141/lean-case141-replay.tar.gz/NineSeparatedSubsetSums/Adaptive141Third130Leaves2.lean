import NineSeparatedSubsetSums.Adaptive141Third130State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third130Proof9 : runCachedNode 511 128244 Adaptive141Third130Node9 = false := by
  decide +kernel

#print axioms adaptive141Third130Proof9

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third130Proof7 : runCachedNode 511 128244 Adaptive141Third130Node7 = false := by
  decide +kernel

#print axioms adaptive141Third130Proof7

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third130Proof6 : runCachedNode 511 128244 Adaptive141Third130Node6 = false := by
  decide +kernel

#print axioms adaptive141Third130Proof6

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third130Proof4 : runCachedNode 511 128244 Adaptive141Third130Node4 = false := by
  decide +kernel

#print axioms adaptive141Third130Proof4

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third130Proof3 : runCachedNode 511 128244 Adaptive141Third130Node3 = false := by
  decide +kernel

#print axioms adaptive141Third130Proof3

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third130Proof2 : runCachedNode 511 128244 Adaptive141Third130Node2 = false := by
  decide +kernel

#print axioms adaptive141Third130Proof2

end NineSeparatedSubsetSums
