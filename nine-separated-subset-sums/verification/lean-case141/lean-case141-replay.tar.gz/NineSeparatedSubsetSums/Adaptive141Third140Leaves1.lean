import NineSeparatedSubsetSums.Adaptive141Third140State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third140Proof167 : runCachedNode 511 129930 Adaptive141Third140Node167 = false := by
  decide +kernel

#print axioms adaptive141Third140Proof167

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third140Proof66 : runCachedNode 511 129930 Adaptive141Third140Node66 = false := by
  decide +kernel

#print axioms adaptive141Third140Proof66

end NineSeparatedSubsetSums
