import NineSeparatedSubsetSums.EightPointPackedGeometry
import NineSeparatedSubsetSums.EightPoint141_133PackedBudget0
import NineSeparatedSubsetSums.EightPoint141_133PackedAnchor0Part0
import NineSeparatedSubsetSums.EightPoint141_133PackedAnchor0Part1
import NineSeparatedSubsetSums.EightPoint141_133PackedAnchor0Part2
import NineSeparatedSubsetSums.EightPoint141_133PackedBudget1
import NineSeparatedSubsetSums.EightPoint141_133PackedAnchor1Part0
import NineSeparatedSubsetSums.EightPoint141_133PackedAnchor1Part1
import NineSeparatedSubsetSums.EightPoint141_133PackedAnchor1Part2

namespace NineSeparatedSubsetSums

private theorem packedOct141_133Anchor0 :
  ∀ j : Fin 498, ((j.val : Int)+141+133)%2=0 →
    2454911 ≤ FourPointNumeric.octPackedCharge 141 133 20 packedOct141_133_0 (j.val : Int) := by
  intro j hj
  let k := (j.val-0)/2
  have hk : k < 249 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+0 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint141_133PackedAnchor0Part0 z
    rwa [he,hrep] at ht
  by_cases h1 : k < 240
  · let z : Fin 120 := ⟨k-120, by omega⟩
    have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
    have ht := eightPoint141_133PackedAnchor0Part1 z
    rwa [he,hrep] at ht
  let z : Fin 9 := ⟨k-240, by omega⟩
  have he : (z.val : Int)+240 = k := by dsimp [z] <;> omega
  have ht := eightPoint141_133PackedAnchor0Part2 z
  rwa [he,hrep] at ht

private theorem packedOct141_133Anchor1 :
  ∀ j : Fin 498, ((j.val : Int)+141+133)%2=1 →
    2455404 ≤ FourPointNumeric.octPackedCharge 141 133 20 packedOct141_133_1 (j.val : Int) := by
  intro j hj
  let k := (j.val-1)/2
  have hk : k < 249 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+1 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint141_133PackedAnchor1Part0 z
    rwa [he,hrep] at ht
  by_cases h1 : k < 240
  · let z : Fin 120 := ⟨k-120, by omega⟩
    have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
    have ht := eightPoint141_133PackedAnchor1Part1 z
    rwa [he,hrep] at ht
  let z : Fin 9 := ⟨k-240, by omega⟩
  have he : (z.val : Int)+240 = k := by dsimp [z] <;> omega
  have ht := eightPoint141_133PackedAnchor1Part2 z
  rwa [he,hrep] at ht

def packedOctCertificate141_133_0 : EightPointCertificate 141 133 0 128708 :=
  eightPointCertificateOfPacked 141 133 0 128708 2454911 20 packedOct141_133_0 457 498
    (by decide +kernel) (by decide) packedOct141_133Anchor0
    (by rw [packedOct141_133_0_budget]; decide)

def packedOctCertificate141_133_1 : EightPointCertificate 141 133 1 128708 :=
  eightPointCertificateOfPacked 141 133 1 128708 2455404 20 packedOct141_133_1 456 498
    (by decide +kernel) (by decide) packedOct141_133Anchor1
    (by rw [packedOct141_133_1_budget]; decide)

theorem max148_second141_third133_eightPoint_moment_bound (tail : List ℕ) (len : tail.length=6)
    (distinct : (natSubsetSums (148::141::133::tail)).Nodup) :
    128708 ≤ ((148::141::133::tail).map (· ^ 2)).sum := by
  apply eightPointNatMomentLower 141 133 128708 tail len distinct
  intro p hp
  by_cases h : p=0
  · subst p
    exact packedOctCertificate141_133_0
  · have he : p=1 := hp.resolve_left h
    subst p
    exact packedOctCertificate141_133_1

#print axioms max148_second141_third133_eightPoint_moment_bound

end NineSeparatedSubsetSums
