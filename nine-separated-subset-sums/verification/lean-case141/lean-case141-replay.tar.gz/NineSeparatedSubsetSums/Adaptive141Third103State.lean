import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive141Third103Node0 : CachedSearchNode :=
  ⟨4, 102, computeCenteredMask [148,141,103], 392, 52394⟩

end NineSeparatedSubsetSums
