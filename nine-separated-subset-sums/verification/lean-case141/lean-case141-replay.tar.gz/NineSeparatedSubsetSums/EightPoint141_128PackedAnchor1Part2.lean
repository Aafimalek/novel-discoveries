import NineSeparatedSubsetSums.EightPoint141_128PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint141_128PackedAnchor1Part2 :
    ∀ j : Fin 5, 2375433 ≤ FourPointNumeric.octPackedCharge 141 128 20 packedOct141_128_1
      (2*((j.val : Int)+240)+0) := by decide +kernel

end NineSeparatedSubsetSums
