import NineSeparatedSubsetSums.EightPoint141_131PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint141_131PackedAnchor0Part1 :
    ∀ j : Fin 120, 2425695 ≤ FourPointNumeric.octPackedCharge 141 131 20 packedOct141_131_0
      (2*((j.val : Int)+120)+0) := by decide +kernel

end NineSeparatedSubsetSums
