import NineSeparatedSubsetSums.Adaptive141Third137State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third137Proof46 : runCachedNode 511 129418 Adaptive141Third137Node46 = false := by
  decide +kernel

#print axioms adaptive141Third137Proof46

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third137Proof132 : runCachedNode 511 129418 Adaptive141Third137Node132 = false := by
  decide +kernel

#print axioms adaptive141Third137Proof132

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third137Proof13 : runCachedNode 511 129418 Adaptive141Third137Node13 = false := by
  decide +kernel

#print axioms adaptive141Third137Proof13

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third137Proof70 : runCachedNode 511 129418 Adaptive141Third137Node70 = false := by
  decide +kernel

#print axioms adaptive141Third137Proof70

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third137Proof130 : runCachedNode 511 129418 Adaptive141Third137Node130 = false := by
  decide +kernel

#print axioms adaptive141Third137Proof130

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third137Proof67 : runCachedNode 511 129418 Adaptive141Third137Node67 = false := by
  decide +kernel

#print axioms adaptive141Third137Proof67

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third137Proof12 : runCachedNode 511 129418 Adaptive141Third137Node12 = false := by
  decide +kernel

#print axioms adaptive141Third137Proof12

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third137Proof129 : runCachedNode 511 129418 Adaptive141Third137Node129 = false := by
  decide +kernel

#print axioms adaptive141Third137Proof129

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third137Proof38 : runCachedNode 511 129418 Adaptive141Third137Node38 = false := by
  decide +kernel

#print axioms adaptive141Third137Proof38

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third137Proof2 : runCachedNode 511 129418 Adaptive141Third137Node2 = false := by
  decide +kernel

#print axioms adaptive141Third137Proof2

end NineSeparatedSubsetSums
