import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive141Third122Node0 : CachedSearchNode :=
  ⟨4, 121, computeCenteredMask [148,141,122], 411, 56669⟩

end NineSeparatedSubsetSums
