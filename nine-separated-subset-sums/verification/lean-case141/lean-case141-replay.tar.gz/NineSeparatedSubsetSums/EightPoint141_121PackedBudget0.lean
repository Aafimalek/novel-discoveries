import NineSeparatedSubsetSums.EightPoint141_121PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct141_121_0_budget :
    FourPointNumeric.packedBudget 20 packedOct141_121_0 263 = 82987118 := by decide +kernel

#print axioms packedOct141_121_0_budget

end NineSeparatedSubsetSums
