import NineSeparatedSubsetSums.Adaptive141Third138State
import NineSeparatedSubsetSums.Adaptive141Third138Leaves11
import NineSeparatedSubsetSums.Adaptive141Third138Leaves12
import NineSeparatedSubsetSums.Adaptive141Third138Leaves19
import NineSeparatedSubsetSums.Adaptive141Third138Leaves18
import NineSeparatedSubsetSums.Adaptive141Third138Leaves4
import NineSeparatedSubsetSums.Adaptive141Third138Leaves3
import NineSeparatedSubsetSums.Adaptive141Third138Leaves17
import NineSeparatedSubsetSums.Adaptive141Third138Leaves2
import NineSeparatedSubsetSums.Adaptive141Third138Leaves16
import NineSeparatedSubsetSums.Adaptive141Third138Leaves10
import NineSeparatedSubsetSums.Adaptive141Third138Leaves9
import NineSeparatedSubsetSums.Adaptive141Third138Leaves15
import NineSeparatedSubsetSums.Adaptive141Third138Leaves14
import NineSeparatedSubsetSums.Adaptive141Third138Leaves7
import NineSeparatedSubsetSums.Adaptive141Third138Leaves1
import NineSeparatedSubsetSums.Adaptive141Third138Leaves13
import NineSeparatedSubsetSums.Adaptive141Third138Leaves5
import NineSeparatedSubsetSums.Adaptive141Third138Leaves6
import NineSeparatedSubsetSums.Adaptive141Third138Leaves8
import NineSeparatedSubsetSums.Adaptive141Third138Leaves0

namespace NineSeparatedSubsetSums

theorem adaptive141Third138Proof23 : runCachedNode 511 129566 Adaptive141Third138Node23 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 129566 Adaptive141Third138Node23 = [104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 124, 125, 127, 128, 129, 132] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive141Third138Proof24
  · exact adaptive141Third138Proof25
  · exact adaptive141Third138Proof26
  · exact adaptive141Third138Proof27
  · exact adaptive141Third138Proof28
  · exact adaptive141Third138Proof29
  · exact adaptive141Third138Proof30
  · exact adaptive141Third138Proof31
  · exact adaptive141Third138Proof32
  · exact adaptive141Third138Proof33
  · exact adaptive141Third138Proof34
  · exact adaptive141Third138Proof35
  · exact adaptive141Third138Proof36
  · exact adaptive141Third138Proof37
  · exact adaptive141Third138Proof38
  · exact adaptive141Third138Proof39
  · exact adaptive141Third138Proof40
  · exact adaptive141Third138Proof41
  · exact adaptive141Third138Proof42
  · exact adaptive141Third138Proof43
  · exact adaptive141Third138Proof44
  · exact adaptive141Third138Proof45
  · exact adaptive141Third138Proof46
  · exact adaptive141Third138Proof47
  · exact adaptive141Third138Proof48

#print axioms adaptive141Third138Proof23

theorem adaptive141Third138Proof49 : runCachedNode 511 129566 Adaptive141Third138Node49 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 129566 Adaptive141Third138Node49 = [103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 125, 126, 128, 129, 130, 132, 133] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive141Third138Proof50
  · exact adaptive141Third138Proof51
  · exact adaptive141Third138Proof52
  · exact adaptive141Third138Proof53
  · exact adaptive141Third138Proof54
  · exact adaptive141Third138Proof55
  · exact adaptive141Third138Proof56
  · exact adaptive141Third138Proof57
  · exact adaptive141Third138Proof58
  · exact adaptive141Third138Proof59
  · exact adaptive141Third138Proof60
  · exact adaptive141Third138Proof61
  · exact adaptive141Third138Proof62
  · exact adaptive141Third138Proof63
  · exact adaptive141Third138Proof64
  · exact adaptive141Third138Proof65
  · exact adaptive141Third138Proof66
  · exact adaptive141Third138Proof67
  · exact adaptive141Third138Proof68
  · exact adaptive141Third138Proof69
  · exact adaptive141Third138Proof70
  · exact adaptive141Third138Proof71
  · exact adaptive141Third138Proof72
  · exact adaptive141Third138Proof73
  · exact adaptive141Third138Proof74
  · exact adaptive141Third138Proof75
  · exact adaptive141Third138Proof76
  · exact adaptive141Third138Proof77

#print axioms adaptive141Third138Proof49

theorem adaptive141Third138Proof106 : runCachedNode 511 129566 Adaptive141Third138Node106 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 129566 Adaptive141Third138Node106 = [92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 119, 120, 122, 123, 126, 129, 133] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive141Third138Proof107
  · exact adaptive141Third138Proof108
  · exact adaptive141Third138Proof109
  · exact adaptive141Third138Proof110
  · exact adaptive141Third138Proof111
  · exact adaptive141Third138Proof112
  · exact adaptive141Third138Proof113
  · exact adaptive141Third138Proof114
  · exact adaptive141Third138Proof115
  · exact adaptive141Third138Proof116
  · exact adaptive141Third138Proof117
  · exact adaptive141Third138Proof118
  · exact adaptive141Third138Proof119
  · exact adaptive141Third138Proof120
  · exact adaptive141Third138Proof121
  · exact adaptive141Third138Proof122
  · exact adaptive141Third138Proof123
  · exact adaptive141Third138Proof124
  · exact adaptive141Third138Proof125
  · exact adaptive141Third138Proof126
  · exact adaptive141Third138Proof127
  · exact adaptive141Third138Proof128
  · exact adaptive141Third138Proof129
  · exact adaptive141Third138Proof130
  · exact adaptive141Third138Proof131
  · exact adaptive141Third138Proof132
  · exact adaptive141Third138Proof133
  · exact adaptive141Third138Proof134
  · exact adaptive141Third138Proof135
  · exact adaptive141Third138Proof136
  · exact adaptive141Third138Proof137
  · exact adaptive141Third138Proof138
  · exact adaptive141Third138Proof139

#print axioms adaptive141Third138Proof106

theorem adaptive141Third138Proof78 : runCachedNode 511 129566 Adaptive141Third138Node78 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 129566 Adaptive141Third138Node78 = [103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 126, 127, 129, 130, 133, 134] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive141Third138Proof79
  · exact adaptive141Third138Proof80
  · exact adaptive141Third138Proof81
  · exact adaptive141Third138Proof82
  · exact adaptive141Third138Proof83
  · exact adaptive141Third138Proof84
  · exact adaptive141Third138Proof85
  · exact adaptive141Third138Proof86
  · exact adaptive141Third138Proof87
  · exact adaptive141Third138Proof88
  · exact adaptive141Third138Proof89
  · exact adaptive141Third138Proof90
  · exact adaptive141Third138Proof91
  · exact adaptive141Third138Proof92
  · exact adaptive141Third138Proof93
  · exact adaptive141Third138Proof94
  · exact adaptive141Third138Proof95
  · exact adaptive141Third138Proof96
  · exact adaptive141Third138Proof97
  · exact adaptive141Third138Proof98
  · exact adaptive141Third138Proof99
  · exact adaptive141Third138Proof100
  · exact adaptive141Third138Proof101
  · exact adaptive141Third138Proof102
  · exact adaptive141Third138Proof103
  · exact adaptive141Third138Proof104
  · exact adaptive141Third138Proof105
  · exact adaptive141Third138Proof106

#print axioms adaptive141Third138Proof78

theorem adaptive141Third138Proof140 : runCachedNode 511 129566 Adaptive141Third138Node140 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 129566 Adaptive141Third138Node140 = [103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 127, 128, 130, 132, 134, 135] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive141Third138Proof141
  · exact adaptive141Third138Proof142
  · exact adaptive141Third138Proof143
  · exact adaptive141Third138Proof144
  · exact adaptive141Third138Proof145
  · exact adaptive141Third138Proof146
  · exact adaptive141Third138Proof147
  · exact adaptive141Third138Proof148
  · exact adaptive141Third138Proof149
  · exact adaptive141Third138Proof150
  · exact adaptive141Third138Proof151
  · exact adaptive141Third138Proof152
  · exact adaptive141Third138Proof153
  · exact adaptive141Third138Proof154
  · exact adaptive141Third138Proof155
  · exact adaptive141Third138Proof156
  · exact adaptive141Third138Proof157
  · exact adaptive141Third138Proof158
  · exact adaptive141Third138Proof159
  · exact adaptive141Third138Proof160
  · exact adaptive141Third138Proof161
  · exact adaptive141Third138Proof162
  · exact adaptive141Third138Proof163
  · exact adaptive141Third138Proof164
  · exact adaptive141Third138Proof165
  · exact adaptive141Third138Proof166
  · exact adaptive141Third138Proof167
  · exact adaptive141Third138Proof168
  · exact adaptive141Third138Proof169

#print axioms adaptive141Third138Proof140

theorem adaptive141Third138Proof170 : runCachedNode 511 129566 Adaptive141Third138Node170 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 129566 Adaptive141Third138Node170 = [102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 128, 129, 132, 133, 135, 136] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive141Third138Proof171
  · exact adaptive141Third138Proof172
  · exact adaptive141Third138Proof173
  · exact adaptive141Third138Proof174
  · exact adaptive141Third138Proof175
  · exact adaptive141Third138Proof176
  · exact adaptive141Third138Proof177
  · exact adaptive141Third138Proof178
  · exact adaptive141Third138Proof179
  · exact adaptive141Third138Proof180
  · exact adaptive141Third138Proof181
  · exact adaptive141Third138Proof182
  · exact adaptive141Third138Proof183
  · exact adaptive141Third138Proof184
  · exact adaptive141Third138Proof185
  · exact adaptive141Third138Proof186
  · exact adaptive141Third138Proof187
  · exact adaptive141Third138Proof188
  · exact adaptive141Third138Proof189
  · exact adaptive141Third138Proof190
  · exact adaptive141Third138Proof191
  · exact adaptive141Third138Proof192
  · exact adaptive141Third138Proof193
  · exact adaptive141Third138Proof194
  · exact adaptive141Third138Proof195
  · exact adaptive141Third138Proof196
  · exact adaptive141Third138Proof197
  · exact adaptive141Third138Proof198
  · exact adaptive141Third138Proof199
  · exact adaptive141Third138Proof200
  · exact adaptive141Third138Proof201

#print axioms adaptive141Third138Proof170

theorem adaptive141Third138Proof0 : runCachedNode 511 129566 Adaptive141Third138Node0 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 129566 Adaptive141Third138Node0 = [110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 132, 133, 134, 135, 136, 137] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive141Third138Proof1
  · exact adaptive141Third138Proof2
  · exact adaptive141Third138Proof3
  · exact adaptive141Third138Proof4
  · exact adaptive141Third138Proof5
  · exact adaptive141Third138Proof6
  · exact adaptive141Third138Proof7
  · exact adaptive141Third138Proof8
  · exact adaptive141Third138Proof9
  · exact adaptive141Third138Proof10
  · exact adaptive141Third138Proof11
  · exact adaptive141Third138Proof12
  · exact adaptive141Third138Proof13
  · exact adaptive141Third138Proof14
  · exact adaptive141Third138Proof15
  · exact adaptive141Third138Proof16
  · exact adaptive141Third138Proof17
  · exact adaptive141Third138Proof18
  · exact adaptive141Third138Proof19
  · exact adaptive141Third138Proof20
  · exact adaptive141Third138Proof21
  · exact adaptive141Third138Proof22
  · exact adaptive141Third138Proof23
  · exact adaptive141Third138Proof49
  · exact adaptive141Third138Proof78
  · exact adaptive141Third138Proof140
  · exact adaptive141Third138Proof170

#print axioms adaptive141Third138Proof0

end NineSeparatedSubsetSums
