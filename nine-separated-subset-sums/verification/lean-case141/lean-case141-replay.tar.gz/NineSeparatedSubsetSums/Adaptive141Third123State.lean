import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive141Third123Node0 : CachedSearchNode :=
  ⟨4, 122, computeCenteredMask [148,141,123], 412, 56914⟩

end NineSeparatedSubsetSums
