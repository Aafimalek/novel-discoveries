import NineSeparatedSubsetSums.EightPoint141_120PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint141_120PackedAnchor0Part2 :
    ∀ j : Fin 3, 2339286 ≤ FourPointNumeric.octPackedCharge 141 120 20 packedOct141_120_0
      (2*((j.val : Int)+240)+1) := by decide +kernel

end NineSeparatedSubsetSums
