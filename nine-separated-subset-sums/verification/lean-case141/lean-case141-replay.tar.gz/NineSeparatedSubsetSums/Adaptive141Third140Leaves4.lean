import NineSeparatedSubsetSums.Adaptive141Third140State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third140Proof77 : runCachedNode 511 129930 Adaptive141Third140Node77 = false := by
  decide +kernel

#print axioms adaptive141Third140Proof77

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third140Proof229 : runCachedNode 511 129930 Adaptive141Third140Node229 = false := by
  decide +kernel

#print axioms adaptive141Third140Proof229

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third140Proof25 : runCachedNode 511 129930 Adaptive141Third140Node25 = false := by
  decide +kernel

#print axioms adaptive141Third140Proof25

end NineSeparatedSubsetSums
