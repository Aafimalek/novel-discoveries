import NineSeparatedSubsetSums.Adaptive141Third140State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third140Proof133 : runCachedNode 511 129930 Adaptive141Third140Node133 = false := by
  decide +kernel

#print axioms adaptive141Third140Proof133

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third140Proof225 : runCachedNode 511 129930 Adaptive141Third140Node225 = false := by
  decide +kernel

#print axioms adaptive141Third140Proof225

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third140Proof14 : runCachedNode 511 129930 Adaptive141Third140Node14 = false := by
  decide +kernel

#print axioms adaptive141Third140Proof14

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third140Proof163 : runCachedNode 511 129930 Adaptive141Third140Node163 = false := by
  decide +kernel

#print axioms adaptive141Third140Proof163

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third140Proof272 : runCachedNode 511 129930 Adaptive141Third140Node272 = false := by
  decide +kernel

#print axioms adaptive141Third140Proof272

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third140Proof13 : runCachedNode 511 129930 Adaptive141Third140Node13 = false := by
  decide +kernel

#print axioms adaptive141Third140Proof13

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third140Proof85 : runCachedNode 511 129930 Adaptive141Third140Node85 = false := by
  decide +kernel

#print axioms adaptive141Third140Proof85

end NineSeparatedSubsetSums
