import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive141Third126Node0 : CachedSearchNode :=
  ⟨4, 125, computeCenteredMask [148,141,126], 415, 57661⟩

end NineSeparatedSubsetSums
