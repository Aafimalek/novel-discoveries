import NineSeparatedSubsetSums.Adaptive141Third140State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third140Proof234 : runCachedNode 511 129930 Adaptive141Third140Node234 = false := by
  decide +kernel

#print axioms adaptive141Third140Proof234

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third140Proof75 : runCachedNode 511 129930 Adaptive141Third140Node75 = false := by
  decide +kernel

#print axioms adaptive141Third140Proof75

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third140Proof101 : runCachedNode 511 129930 Adaptive141Third140Node101 = false := by
  decide +kernel

#print axioms adaptive141Third140Proof101

end NineSeparatedSubsetSums
