import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive141Third106Node0 : CachedSearchNode :=
  ⟨4, 105, computeCenteredMask [148,141,106], 395, 53021⟩

end NineSeparatedSubsetSums
