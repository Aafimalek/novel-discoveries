import NineSeparatedSubsetSums.Adaptive141Third133State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third133Proof21 : runCachedNode 511 128708 Adaptive141Third133Node21 = false := by
  decide +kernel

#print axioms adaptive141Third133Proof21

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third133Proof17 : runCachedNode 511 128708 Adaptive141Third133Node17 = false := by
  decide +kernel

#print axioms adaptive141Third133Proof17

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third133Proof1 : runCachedNode 511 128708 Adaptive141Third133Node1 = false := by
  decide +kernel

#print axioms adaptive141Third133Proof1

end NineSeparatedSubsetSums
