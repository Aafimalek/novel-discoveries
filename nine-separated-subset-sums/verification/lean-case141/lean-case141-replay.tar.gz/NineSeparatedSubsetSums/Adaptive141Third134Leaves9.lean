import NineSeparatedSubsetSums.Adaptive141Third134State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third134Proof60 : runCachedNode 511 128866 Adaptive141Third134Node60 = false := by
  decide +kernel

#print axioms adaptive141Third134Proof60

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third134Proof39 : runCachedNode 511 128866 Adaptive141Third134Node39 = false := by
  decide +kernel

#print axioms adaptive141Third134Proof39

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third134Proof10 : runCachedNode 511 128866 Adaptive141Third134Node10 = false := by
  decide +kernel

#print axioms adaptive141Third134Proof10

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third134Proof88 : runCachedNode 511 128866 Adaptive141Third134Node88 = false := by
  decide +kernel

#print axioms adaptive141Third134Proof88

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third134Proof35 : runCachedNode 511 128866 Adaptive141Third134Node35 = false := by
  decide +kernel

#print axioms adaptive141Third134Proof35

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third134Proof84 : runCachedNode 511 128866 Adaptive141Third134Node84 = false := by
  decide +kernel

#print axioms adaptive141Third134Proof84

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third134Proof9 : runCachedNode 511 128866 Adaptive141Third134Node9 = false := by
  decide +kernel

#print axioms adaptive141Third134Proof9

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third134Proof61 : runCachedNode 511 128866 Adaptive141Third134Node61 = false := by
  decide +kernel

#print axioms adaptive141Third134Proof61

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third134Proof59 : runCachedNode 511 128866 Adaptive141Third134Node59 = false := by
  decide +kernel

#print axioms adaptive141Third134Proof59

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third134Proof63 : runCachedNode 511 128866 Adaptive141Third134Node63 = false := by
  decide +kernel

#print axioms adaptive141Third134Proof63

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third134Proof83 : runCachedNode 511 128866 Adaptive141Third134Node83 = false := by
  decide +kernel

#print axioms adaptive141Third134Proof83

end NineSeparatedSubsetSums
