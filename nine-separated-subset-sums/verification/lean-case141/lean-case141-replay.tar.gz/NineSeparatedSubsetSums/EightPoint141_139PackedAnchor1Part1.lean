import NineSeparatedSubsetSums.EightPoint141_139PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint141_139PackedAnchor1Part1 :
    ∀ j : Fin 120, 2503610 ≤ FourPointNumeric.octPackedCharge 141 139 20 packedOct141_139_1
      (2*((j.val : Int)+120)+1) := by decide +kernel

end NineSeparatedSubsetSums
