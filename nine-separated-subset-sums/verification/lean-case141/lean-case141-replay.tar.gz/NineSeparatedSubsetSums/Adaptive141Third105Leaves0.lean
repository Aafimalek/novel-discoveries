import NineSeparatedSubsetSums.Adaptive141Third105State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third105Proof0 : runCachedNode 511 111653 Adaptive141Third105Node0 = false := by
  decide +kernel

#print axioms adaptive141Third105Proof0

end NineSeparatedSubsetSums
