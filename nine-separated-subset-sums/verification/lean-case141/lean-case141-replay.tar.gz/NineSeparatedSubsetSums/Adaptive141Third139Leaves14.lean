import NineSeparatedSubsetSums.Adaptive141Third139State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third139Proof185 : runCachedNode 511 129747 Adaptive141Third139Node185 = false := by
  decide +kernel

#print axioms adaptive141Third139Proof185

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third139Proof127 : runCachedNode 511 129747 Adaptive141Third139Node127 = false := by
  decide +kernel

#print axioms adaptive141Third139Proof127

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third139Proof94 : runCachedNode 511 129747 Adaptive141Third139Node94 = false := by
  decide +kernel

#print axioms adaptive141Third139Proof94

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third139Proof255 : runCachedNode 511 129747 Adaptive141Third139Node255 = false := by
  decide +kernel

#print axioms adaptive141Third139Proof255

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third139Proof42 : runCachedNode 511 129747 Adaptive141Third139Node42 = false := by
  decide +kernel

#print axioms adaptive141Third139Proof42

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third139Proof41 : runCachedNode 511 129747 Adaptive141Third139Node41 = false := by
  decide +kernel

#print axioms adaptive141Third139Proof41

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third139Proof56 : runCachedNode 511 129747 Adaptive141Third139Node56 = false := by
  decide +kernel

#print axioms adaptive141Third139Proof56

end NineSeparatedSubsetSums
