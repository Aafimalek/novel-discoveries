import NineSeparatedSubsetSums.Adaptive141Third138State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third138Proof139 : runCachedNode 511 129566 Adaptive141Third138Node139 = false := by
  decide +kernel

#print axioms adaptive141Third138Proof139

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third138Proof167 : runCachedNode 511 129566 Adaptive141Third138Node167 = false := by
  decide +kernel

#print axioms adaptive141Third138Proof167

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third138Proof18 : runCachedNode 511 129566 Adaptive141Third138Node18 = false := by
  decide +kernel

#print axioms adaptive141Third138Proof18

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third138Proof53 : runCachedNode 511 129566 Adaptive141Third138Node53 = false := by
  decide +kernel

#print axioms adaptive141Third138Proof53

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third138Proof108 : runCachedNode 511 129566 Adaptive141Third138Node108 = false := by
  decide +kernel

#print axioms adaptive141Third138Proof108

end NineSeparatedSubsetSums
