import NineSeparatedSubsetSums.Adaptive141Third140State
import NineSeparatedSubsetSums.Adaptive141Third140Leaves2
import NineSeparatedSubsetSums.Adaptive141Third140Leaves28
import NineSeparatedSubsetSums.Adaptive141Third140Leaves13
import NineSeparatedSubsetSums.Adaptive141Third140Leaves27
import NineSeparatedSubsetSums.Adaptive141Third140Leaves26
import NineSeparatedSubsetSums.Adaptive141Third140Leaves25
import NineSeparatedSubsetSums.Adaptive141Third140Leaves24
import NineSeparatedSubsetSums.Adaptive141Third140Leaves23
import NineSeparatedSubsetSums.Adaptive141Third140Leaves22
import NineSeparatedSubsetSums.Adaptive141Third140Leaves21
import NineSeparatedSubsetSums.Adaptive141Third140Leaves20
import NineSeparatedSubsetSums.Adaptive141Third140Leaves8
import NineSeparatedSubsetSums.Adaptive141Third140Leaves15
import NineSeparatedSubsetSums.Adaptive141Third140Leaves17
import NineSeparatedSubsetSums.Adaptive141Third140Leaves14
import NineSeparatedSubsetSums.Adaptive141Third140Leaves11
import NineSeparatedSubsetSums.Adaptive141Third140Leaves5
import NineSeparatedSubsetSums.Adaptive141Third140Leaves7
import NineSeparatedSubsetSums.Adaptive141Third140Joins0

namespace NineSeparatedSubsetSums

theorem adaptive141Third140Proof0 : runCachedNode 511 129930 Adaptive141Third140Node0 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 129930 Adaptive141Third140Node0 = [110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 132, 134, 135, 136, 137, 138, 139] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive141Third140Proof1
  · exact adaptive141Third140Proof2
  · exact adaptive141Third140Proof3
  · exact adaptive141Third140Proof4
  · exact adaptive141Third140Proof5
  · exact adaptive141Third140Proof6
  · exact adaptive141Third140Proof7
  · exact adaptive141Third140Proof8
  · exact adaptive141Third140Proof9
  · exact adaptive141Third140Proof10
  · exact adaptive141Third140Proof11
  · exact adaptive141Third140Proof12
  · exact adaptive141Third140Proof13
  · exact adaptive141Third140Proof14
  · exact adaptive141Third140Proof15
  · exact adaptive141Third140Proof16
  · exact adaptive141Third140Proof17
  · exact adaptive141Third140Proof18
  · exact adaptive141Third140Proof19
  · exact adaptive141Third140Proof20
  · exact adaptive141Third140Proof21
  · exact adaptive141Third140Proof22
  · exact adaptive141Third140Proof23
  · exact adaptive141Third140Proof49
  · exact adaptive141Third140Proof78
  · exact adaptive141Third140Proof107
  · exact adaptive141Third140Proof137
  · exact adaptive141Third140Proof169
  · exact adaptive141Third140Proof202

#print axioms adaptive141Third140Proof0

end NineSeparatedSubsetSums
