import NineSeparatedSubsetSums.Adaptive141Third135State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third135Proof19 : runCachedNode 511 129079 Adaptive141Third135Node19 = false := by
  decide +kernel

#print axioms adaptive141Third135Proof19

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third135Proof44 : runCachedNode 511 129079 Adaptive141Third135Node44 = false := by
  decide +kernel

#print axioms adaptive141Third135Proof44

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third135Proof11 : runCachedNode 511 129079 Adaptive141Third135Node11 = false := by
  decide +kernel

#print axioms adaptive141Third135Proof11

end NineSeparatedSubsetSums
