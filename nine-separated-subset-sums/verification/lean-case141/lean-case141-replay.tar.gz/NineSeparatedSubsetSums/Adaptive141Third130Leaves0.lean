import NineSeparatedSubsetSums.Adaptive141Third130State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third130Proof18 : runCachedNode 511 128244 Adaptive141Third130Node18 = false := by
  decide +kernel

#print axioms adaptive141Third130Proof18

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third130Proof17 : runCachedNode 511 128244 Adaptive141Third130Node17 = false := by
  decide +kernel

#print axioms adaptive141Third130Proof17

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third130Proof14 : runCachedNode 511 128244 Adaptive141Third130Node14 = false := by
  decide +kernel

#print axioms adaptive141Third130Proof14

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third130Proof5 : runCachedNode 511 128244 Adaptive141Third130Node5 = false := by
  decide +kernel

#print axioms adaptive141Third130Proof5

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third130Proof1 : runCachedNode 511 128244 Adaptive141Third130Node1 = false := by
  decide +kernel

#print axioms adaptive141Third130Proof1

end NineSeparatedSubsetSums
