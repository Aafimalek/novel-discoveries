import NineSeparatedSubsetSums.Adaptive141Third131State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third131Proof18 : runCachedNode 511 128468 Adaptive141Third131Node18 = false := by
  decide +kernel

#print axioms adaptive141Third131Proof18

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third131Proof15 : runCachedNode 511 128468 Adaptive141Third131Node15 = false := by
  decide +kernel

#print axioms adaptive141Third131Proof15

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third131Proof16 : runCachedNode 511 128468 Adaptive141Third131Node16 = false := by
  decide +kernel

#print axioms adaptive141Third131Proof16

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third131Proof13 : runCachedNode 511 128468 Adaptive141Third131Node13 = false := by
  decide +kernel

#print axioms adaptive141Third131Proof13

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third131Proof2 : runCachedNode 511 128468 Adaptive141Third131Node2 = false := by
  decide +kernel

#print axioms adaptive141Third131Proof2

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third131Proof1 : runCachedNode 511 128468 Adaptive141Third131Node1 = false := by
  decide +kernel

#print axioms adaptive141Third131Proof1

end NineSeparatedSubsetSums
