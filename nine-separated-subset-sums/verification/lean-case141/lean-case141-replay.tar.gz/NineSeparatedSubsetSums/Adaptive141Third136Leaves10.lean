import NineSeparatedSubsetSums.Adaptive141Third136State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third136Proof38 : runCachedNode 511 129226 Adaptive141Third136Node38 = false := by
  decide +kernel

#print axioms adaptive141Third136Proof38

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third136Proof92 : runCachedNode 511 129226 Adaptive141Third136Node92 = false := by
  decide +kernel

#print axioms adaptive141Third136Proof92

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third136Proof66 : runCachedNode 511 129226 Adaptive141Third136Node66 = false := by
  decide +kernel

#print axioms adaptive141Third136Proof66

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third136Proof91 : runCachedNode 511 129226 Adaptive141Third136Node91 = false := by
  decide +kernel

#print axioms adaptive141Third136Proof91

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third136Proof158 : runCachedNode 511 129226 Adaptive141Third136Node158 = false := by
  decide +kernel

#print axioms adaptive141Third136Proof158

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third136Proof124 : runCachedNode 511 129226 Adaptive141Third136Node124 = false := by
  decide +kernel

#print axioms adaptive141Third136Proof124

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third136Proof11 : runCachedNode 511 129226 Adaptive141Third136Node11 = false := by
  decide +kernel

#print axioms adaptive141Third136Proof11

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third136Proof39 : runCachedNode 511 129226 Adaptive141Third136Node39 = false := by
  decide +kernel

#print axioms adaptive141Third136Proof39

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third136Proof123 : runCachedNode 511 129226 Adaptive141Third136Node123 = false := by
  decide +kernel

#print axioms adaptive141Third136Proof123

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third136Proof68 : runCachedNode 511 129226 Adaptive141Third136Node68 = false := by
  decide +kernel

#print axioms adaptive141Third136Proof68

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third136Proof119 : runCachedNode 511 129226 Adaptive141Third136Node119 = false := by
  decide +kernel

#print axioms adaptive141Third136Proof119

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third136Proof120 : runCachedNode 511 129226 Adaptive141Third136Node120 = false := by
  decide +kernel

#print axioms adaptive141Third136Proof120

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third136Proof65 : runCachedNode 511 129226 Adaptive141Third136Node65 = false := by
  decide +kernel

#print axioms adaptive141Third136Proof65

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third136Proof88 : runCachedNode 511 129226 Adaptive141Third136Node88 = false := by
  decide +kernel

#print axioms adaptive141Third136Proof88

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third136Proof36 : runCachedNode 511 129226 Adaptive141Third136Node36 = false := by
  decide +kernel

#print axioms adaptive141Third136Proof36

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third136Proof22 : runCachedNode 511 129226 Adaptive141Third136Node22 = false := by
  decide +kernel

#print axioms adaptive141Third136Proof22

end NineSeparatedSubsetSums
