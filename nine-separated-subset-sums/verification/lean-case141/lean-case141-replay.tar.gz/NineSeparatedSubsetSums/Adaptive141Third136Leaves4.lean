import NineSeparatedSubsetSums.Adaptive141Third136State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third136Proof19 : runCachedNode 511 129226 Adaptive141Third136Node19 = false := by
  decide +kernel

#print axioms adaptive141Third136Proof19

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third136Proof70 : runCachedNode 511 129226 Adaptive141Third136Node70 = false := by
  decide +kernel

#print axioms adaptive141Third136Proof70

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third136Proof62 : runCachedNode 511 129226 Adaptive141Third136Node62 = false := by
  decide +kernel

#print axioms adaptive141Third136Proof62

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third136Proof102 : runCachedNode 511 129226 Adaptive141Third136Node102 = false := by
  decide +kernel

#print axioms adaptive141Third136Proof102

end NineSeparatedSubsetSums
