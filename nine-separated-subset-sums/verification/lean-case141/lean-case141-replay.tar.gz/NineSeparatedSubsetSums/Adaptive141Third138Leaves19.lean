import NineSeparatedSubsetSums.Adaptive141Third138State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third138Proof118 : runCachedNode 511 129566 Adaptive141Third138Node118 = false := by
  decide +kernel

#print axioms adaptive141Third138Proof118

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third138Proof178 : runCachedNode 511 129566 Adaptive141Third138Node178 = false := by
  decide +kernel

#print axioms adaptive141Third138Proof178

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third138Proof26 : runCachedNode 511 129566 Adaptive141Third138Node26 = false := by
  decide +kernel

#print axioms adaptive141Third138Proof26

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third138Proof50 : runCachedNode 511 129566 Adaptive141Third138Node50 = false := by
  decide +kernel

#print axioms adaptive141Third138Proof50

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third138Proof79 : runCachedNode 511 129566 Adaptive141Third138Node79 = false := by
  decide +kernel

#print axioms adaptive141Third138Proof79

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third138Proof115 : runCachedNode 511 129566 Adaptive141Third138Node115 = false := by
  decide +kernel

#print axioms adaptive141Third138Proof115

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third138Proof116 : runCachedNode 511 129566 Adaptive141Third138Node116 = false := by
  decide +kernel

#print axioms adaptive141Third138Proof116

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third138Proof143 : runCachedNode 511 129566 Adaptive141Third138Node143 = false := by
  decide +kernel

#print axioms adaptive141Third138Proof143

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third138Proof144 : runCachedNode 511 129566 Adaptive141Third138Node144 = false := by
  decide +kernel

#print axioms adaptive141Third138Proof144

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third138Proof175 : runCachedNode 511 129566 Adaptive141Third138Node175 = false := by
  decide +kernel

#print axioms adaptive141Third138Proof175

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third138Proof176 : runCachedNode 511 129566 Adaptive141Third138Node176 = false := by
  decide +kernel

#print axioms adaptive141Third138Proof176

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third138Proof177 : runCachedNode 511 129566 Adaptive141Third138Node177 = false := by
  decide +kernel

#print axioms adaptive141Third138Proof177

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third138Proof110 : runCachedNode 511 129566 Adaptive141Third138Node110 = false := by
  decide +kernel

#print axioms adaptive141Third138Proof110

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third138Proof111 : runCachedNode 511 129566 Adaptive141Third138Node111 = false := by
  decide +kernel

#print axioms adaptive141Third138Proof111

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third138Proof112 : runCachedNode 511 129566 Adaptive141Third138Node112 = false := by
  decide +kernel

#print axioms adaptive141Third138Proof112

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third138Proof113 : runCachedNode 511 129566 Adaptive141Third138Node113 = false := by
  decide +kernel

#print axioms adaptive141Third138Proof113

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third138Proof114 : runCachedNode 511 129566 Adaptive141Third138Node114 = false := by
  decide +kernel

#print axioms adaptive141Third138Proof114

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third138Proof141 : runCachedNode 511 129566 Adaptive141Third138Node141 = false := by
  decide +kernel

#print axioms adaptive141Third138Proof141

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third138Proof142 : runCachedNode 511 129566 Adaptive141Third138Node142 = false := by
  decide +kernel

#print axioms adaptive141Third138Proof142

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third138Proof172 : runCachedNode 511 129566 Adaptive141Third138Node172 = false := by
  decide +kernel

#print axioms adaptive141Third138Proof172

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third138Proof173 : runCachedNode 511 129566 Adaptive141Third138Node173 = false := by
  decide +kernel

#print axioms adaptive141Third138Proof173

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third138Proof174 : runCachedNode 511 129566 Adaptive141Third138Node174 = false := by
  decide +kernel

#print axioms adaptive141Third138Proof174

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third138Proof109 : runCachedNode 511 129566 Adaptive141Third138Node109 = false := by
  decide +kernel

#print axioms adaptive141Third138Proof109

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third138Proof171 : runCachedNode 511 129566 Adaptive141Third138Node171 = false := by
  decide +kernel

#print axioms adaptive141Third138Proof171

end NineSeparatedSubsetSums
