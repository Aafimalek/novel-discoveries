import NineSeparatedSubsetSums.EightPointPackedGeometry
import NineSeparatedSubsetSums.EightPoint141_122PackedBudget0
import NineSeparatedSubsetSums.EightPoint141_122PackedAnchor0Part0
import NineSeparatedSubsetSums.EightPoint141_122PackedAnchor0Part1
import NineSeparatedSubsetSums.EightPoint141_122PackedAnchor0Part2
import NineSeparatedSubsetSums.EightPoint141_122PackedBudget1
import NineSeparatedSubsetSums.EightPoint141_122PackedAnchor1Part0
import NineSeparatedSubsetSums.EightPoint141_122PackedAnchor1Part1
import NineSeparatedSubsetSums.EightPoint141_122PackedAnchor1Part2

namespace NineSeparatedSubsetSums

private theorem packedOct141_122Anchor0 :
  ∀ j : Fin 482, ((j.val : Int)+141+122)%2=0 →
    2307472 ≤ FourPointNumeric.octPackedCharge 141 122 20 packedOct141_122_0 (j.val : Int) := by
  intro j hj
  let k := (j.val-1)/2
  have hk : k < 241 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+1 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint141_122PackedAnchor0Part0 z
    rwa [he,hrep] at ht
  by_cases h1 : k < 240
  · let z : Fin 120 := ⟨k-120, by omega⟩
    have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
    have ht := eightPoint141_122PackedAnchor0Part1 z
    rwa [he,hrep] at ht
  let z : Fin 1 := ⟨k-240, by omega⟩
  have he : (z.val : Int)+240 = k := by dsimp [z] <;> omega
  have ht := eightPoint141_122PackedAnchor0Part2 z
  rwa [he,hrep] at ht

private theorem packedOct141_122Anchor1 :
  ∀ j : Fin 482, ((j.val : Int)+141+122)%2=1 →
    2307631 ≤ FourPointNumeric.octPackedCharge 141 122 20 packedOct141_122_1 (j.val : Int) := by
  intro j hj
  let k := (j.val-0)/2
  have hk : k < 241 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+0 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint141_122PackedAnchor1Part0 z
    rwa [he,hrep] at ht
  by_cases h1 : k < 240
  · let z : Fin 120 := ⟨k-120, by omega⟩
    have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
    have ht := eightPoint141_122PackedAnchor1Part1 z
    rwa [he,hrep] at ht
  let z : Fin 1 := ⟨k-240, by omega⟩
  have he : (z.val : Int)+240 = k := by dsimp [z] <;> omega
  have ht := eightPoint141_122PackedAnchor1Part2 z
  rwa [he,hrep] at ht

def packedOctCertificate141_122_0 : EightPointCertificate 141 122 0 126125 :=
  eightPointCertificateOfPacked 141 122 0 126125 2307472 20 packedOct141_122_0 279 482
    (by decide +kernel) (by decide) packedOct141_122Anchor0
    (by rw [packedOct141_122_0_budget]; decide)

def packedOctCertificate141_122_1 : EightPointCertificate 141 122 1 126125 :=
  eightPointCertificateOfPacked 141 122 1 126125 2307631 20 packedOct141_122_1 278 482
    (by decide +kernel) (by decide) packedOct141_122Anchor1
    (by rw [packedOct141_122_1_budget]; decide)

theorem max148_second141_third122_eightPoint_moment_bound (tail : List ℕ) (len : tail.length=6)
    (distinct : (natSubsetSums (148::141::122::tail)).Nodup) :
    126125 ≤ ((148::141::122::tail).map (· ^ 2)).sum := by
  apply eightPointNatMomentLower 141 122 126125 tail len distinct
  intro p hp
  by_cases h : p=0
  · subst p
    exact packedOctCertificate141_122_0
  · have he : p=1 := hp.resolve_left h
    subst p
    exact packedOctCertificate141_122_1

#print axioms max148_second141_third122_eightPoint_moment_bound

end NineSeparatedSubsetSums
