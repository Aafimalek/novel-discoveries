import NineSeparatedSubsetSums.Adaptive141Third125State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third125Proof0 : runCachedNode 511 127095 Adaptive141Third125Node0 = false := by
  decide +kernel

#print axioms adaptive141Third125Proof0

end NineSeparatedSubsetSums
