import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive141Third113Node0 : CachedSearchNode :=
  ⟨4, 112, computeCenteredMask [148,141,113], 402, 54554⟩

end NineSeparatedSubsetSums
