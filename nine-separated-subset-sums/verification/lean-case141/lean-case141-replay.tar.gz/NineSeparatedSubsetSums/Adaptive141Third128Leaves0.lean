import NineSeparatedSubsetSums.Adaptive141Third128State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third128Proof16 : runCachedNode 511 127705 Adaptive141Third128Node16 = false := by
  decide +kernel

#print axioms adaptive141Third128Proof16

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third128Proof15 : runCachedNode 511 127705 Adaptive141Third128Node15 = false := by
  decide +kernel

#print axioms adaptive141Third128Proof15

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third128Proof14 : runCachedNode 511 127705 Adaptive141Third128Node14 = false := by
  decide +kernel

#print axioms adaptive141Third128Proof14

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third128Proof13 : runCachedNode 511 127705 Adaptive141Third128Node13 = false := by
  decide +kernel

#print axioms adaptive141Third128Proof13

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third128Proof12 : runCachedNode 511 127705 Adaptive141Third128Node12 = false := by
  decide +kernel

#print axioms adaptive141Third128Proof12

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third128Proof10 : runCachedNode 511 127705 Adaptive141Third128Node10 = false := by
  decide +kernel

#print axioms adaptive141Third128Proof10

end NineSeparatedSubsetSums
