import NineSeparatedSubsetSums.EightPoint141_134PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct141_134_1_budget :
    FourPointNumeric.packedBudget 20 packedOct141_134_1 410 = 93335558 := by decide +kernel

#print axioms packedOct141_134_1_budget

end NineSeparatedSubsetSums
