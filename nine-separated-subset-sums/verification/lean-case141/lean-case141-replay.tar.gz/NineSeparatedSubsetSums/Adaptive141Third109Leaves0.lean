import NineSeparatedSubsetSums.Adaptive141Third109State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third109Proof0 : runCachedNode 511 111653 Adaptive141Third109Node0 = false := by
  decide +kernel

#print axioms adaptive141Third109Proof0

end NineSeparatedSubsetSums
