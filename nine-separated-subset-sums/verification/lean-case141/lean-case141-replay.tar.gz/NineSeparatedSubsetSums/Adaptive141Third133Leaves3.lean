import NineSeparatedSubsetSums.Adaptive141Third133State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third133Proof16 : runCachedNode 511 128708 Adaptive141Third133Node16 = false := by
  decide +kernel

#print axioms adaptive141Third133Proof16

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third133Proof15 : runCachedNode 511 128708 Adaptive141Third133Node15 = false := by
  decide +kernel

#print axioms adaptive141Third133Proof15

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third133Proof13 : runCachedNode 511 128708 Adaptive141Third133Node13 = false := by
  decide +kernel

#print axioms adaptive141Third133Proof13

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third133Proof45 : runCachedNode 511 128708 Adaptive141Third133Node45 = false := by
  decide +kernel

#print axioms adaptive141Third133Proof45

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third133Proof44 : runCachedNode 511 128708 Adaptive141Third133Node44 = false := by
  decide +kernel

#print axioms adaptive141Third133Proof44

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third133Proof12 : runCachedNode 511 128708 Adaptive141Third133Node12 = false := by
  decide +kernel

#print axioms adaptive141Third133Proof12

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third133Proof7 : runCachedNode 511 128708 Adaptive141Third133Node7 = false := by
  decide +kernel

#print axioms adaptive141Third133Proof7

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third133Proof23 : runCachedNode 511 128708 Adaptive141Third133Node23 = false := by
  decide +kernel

#print axioms adaptive141Third133Proof23

end NineSeparatedSubsetSums
