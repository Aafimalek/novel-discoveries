import NineSeparatedSubsetSums.Adaptive141Third140State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third140Proof21 : runCachedNode 511 129930 Adaptive141Third140Node21 = false := by
  decide +kernel

#print axioms adaptive141Third140Proof21

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third140Proof46 : runCachedNode 511 129930 Adaptive141Third140Node46 = false := by
  decide +kernel

#print axioms adaptive141Third140Proof46

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third140Proof24 : runCachedNode 511 129930 Adaptive141Third140Node24 = false := by
  decide +kernel

#print axioms adaptive141Third140Proof24

end NineSeparatedSubsetSums
