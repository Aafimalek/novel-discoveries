import NineSeparatedSubsetSums.EightPoint141_137PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint141_137PackedAnchor0Part1 :
    ∀ j : Fin 120, 2485076 ≤ FourPointNumeric.octPackedCharge 141 137 20 packedOct141_137_0
      (2*((j.val : Int)+120)+0) := by decide +kernel

end NineSeparatedSubsetSums
