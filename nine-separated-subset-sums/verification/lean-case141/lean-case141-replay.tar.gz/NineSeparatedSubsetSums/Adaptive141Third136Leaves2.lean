import NineSeparatedSubsetSums.Adaptive141Third136State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third136Proof99 : runCachedNode 511 129226 Adaptive141Third136Node99 = false := by
  decide +kernel

#print axioms adaptive141Third136Proof99

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third136Proof71 : runCachedNode 511 129226 Adaptive141Third136Node71 = false := by
  decide +kernel

#print axioms adaptive141Third136Proof71

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third136Proof52 : runCachedNode 511 129226 Adaptive141Third136Node52 = false := by
  decide +kernel

#print axioms adaptive141Third136Proof52

end NineSeparatedSubsetSums
