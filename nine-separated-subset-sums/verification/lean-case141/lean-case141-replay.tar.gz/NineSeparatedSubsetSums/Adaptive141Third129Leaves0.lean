import NineSeparatedSubsetSums.Adaptive141Third129State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third129Proof17 : runCachedNode 511 127896 Adaptive141Third129Node17 = false := by
  decide +kernel

#print axioms adaptive141Third129Proof17

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third129Proof15 : runCachedNode 511 127896 Adaptive141Third129Node15 = false := by
  decide +kernel

#print axioms adaptive141Third129Proof15

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third129Proof16 : runCachedNode 511 127896 Adaptive141Third129Node16 = false := by
  decide +kernel

#print axioms adaptive141Third129Proof16

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third129Proof14 : runCachedNode 511 127896 Adaptive141Third129Node14 = false := by
  decide +kernel

#print axioms adaptive141Third129Proof14

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third129Proof4 : runCachedNode 511 127896 Adaptive141Third129Node4 = false := by
  decide +kernel

#print axioms adaptive141Third129Proof4

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third129Proof1 : runCachedNode 511 127896 Adaptive141Third129Node1 = false := by
  decide +kernel

#print axioms adaptive141Third129Proof1

end NineSeparatedSubsetSums
