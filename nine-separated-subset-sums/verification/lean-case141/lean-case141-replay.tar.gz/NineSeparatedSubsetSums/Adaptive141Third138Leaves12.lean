import NineSeparatedSubsetSums.Adaptive141Third138State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third138Proof16 : runCachedNode 511 129566 Adaptive141Third138Node16 = false := by
  decide +kernel

#print axioms adaptive141Third138Proof16

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third138Proof47 : runCachedNode 511 129566 Adaptive141Third138Node47 = false := by
  decide +kernel

#print axioms adaptive141Third138Proof47

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third138Proof14 : runCachedNode 511 129566 Adaptive141Third138Node14 = false := by
  decide +kernel

#print axioms adaptive141Third138Proof14

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third138Proof102 : runCachedNode 511 129566 Adaptive141Third138Node102 = false := by
  decide +kernel

#print axioms adaptive141Third138Proof102

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third138Proof196 : runCachedNode 511 129566 Adaptive141Third138Node196 = false := by
  decide +kernel

#print axioms adaptive141Third138Proof196

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third138Proof161 : runCachedNode 511 129566 Adaptive141Third138Node161 = false := by
  decide +kernel

#print axioms adaptive141Third138Proof161

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third138Proof120 : runCachedNode 511 129566 Adaptive141Third138Node120 = false := by
  decide +kernel

#print axioms adaptive141Third138Proof120

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third138Proof25 : runCachedNode 511 129566 Adaptive141Third138Node25 = false := by
  decide +kernel

#print axioms adaptive141Third138Proof25

end NineSeparatedSubsetSums
