import NineSeparatedSubsetSums.EightPoint141_129PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint141_129PackedAnchor1Part2 :
    ∀ j : Fin 5, 2384650 ≤ FourPointNumeric.octPackedCharge 141 129 20 packedOct141_129_1
      (2*((j.val : Int)+240)+1) := by decide +kernel

end NineSeparatedSubsetSums
