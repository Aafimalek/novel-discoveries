import NineSeparatedSubsetSums.EightPoint141_124PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct141_124_1_budget :
    FourPointNumeric.packedBudget 20 packedOct141_124_1 478 = 84023290 := by decide +kernel

#print axioms packedOct141_124_1_budget

end NineSeparatedSubsetSums
