import NineSeparatedSubsetSums.Adaptive141Third139State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third139Proof129 : runCachedNode 511 129747 Adaptive141Third139Node129 = false := by
  decide +kernel

#print axioms adaptive141Third139Proof129

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third139Proof130 : runCachedNode 511 129747 Adaptive141Third139Node130 = false := by
  decide +kernel

#print axioms adaptive141Third139Proof130

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third139Proof159 : runCachedNode 511 129747 Adaptive141Third139Node159 = false := by
  decide +kernel

#print axioms adaptive141Third139Proof159

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third139Proof152 : runCachedNode 511 129747 Adaptive141Third139Node152 = false := by
  decide +kernel

#print axioms adaptive141Third139Proof152

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third139Proof76 : runCachedNode 511 129747 Adaptive141Third139Node76 = false := by
  decide +kernel

#print axioms adaptive141Third139Proof76

end NineSeparatedSubsetSums
