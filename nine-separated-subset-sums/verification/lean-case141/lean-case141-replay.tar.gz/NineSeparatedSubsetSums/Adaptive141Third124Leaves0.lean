import NineSeparatedSubsetSums.Adaptive141Third124State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third124Proof0 : runCachedNode 511 126631 Adaptive141Third124Node0 = false := by
  decide +kernel

#print axioms adaptive141Third124Proof0

end NineSeparatedSubsetSums
