import NineSeparatedSubsetSums.Adaptive141Third139State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third139Proof16 : runCachedNode 511 129747 Adaptive141Third139Node16 = false := by
  decide +kernel

#print axioms adaptive141Third139Proof16

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third139Proof160 : runCachedNode 511 129747 Adaptive141Third139Node160 = false := by
  decide +kernel

#print axioms adaptive141Third139Proof160

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third139Proof187 : runCachedNode 511 129747 Adaptive141Third139Node187 = false := by
  decide +kernel

#print axioms adaptive141Third139Proof187

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third139Proof14 : runCachedNode 511 129747 Adaptive141Third139Node14 = false := by
  decide +kernel

#print axioms adaptive141Third139Proof14

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third139Proof64 : runCachedNode 511 129747 Adaptive141Third139Node64 = false := by
  decide +kernel

#print axioms adaptive141Third139Proof64

end NineSeparatedSubsetSums
