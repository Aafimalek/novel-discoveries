import NineSeparatedSubsetSums.Adaptive141Third135State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third135Proof21 : runCachedNode 511 129079 Adaptive141Third135Node21 = false := by
  decide +kernel

#print axioms adaptive141Third135Proof21

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third135Proof99 : runCachedNode 511 129079 Adaptive141Third135Node99 = false := by
  decide +kernel

#print axioms adaptive141Third135Proof99

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third135Proof87 : runCachedNode 511 129079 Adaptive141Third135Node87 = false := by
  decide +kernel

#print axioms adaptive141Third135Proof87

end NineSeparatedSubsetSums
