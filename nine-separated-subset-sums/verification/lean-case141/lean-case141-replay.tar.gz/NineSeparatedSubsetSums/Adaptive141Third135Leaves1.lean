import NineSeparatedSubsetSums.Adaptive141Third135State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third135Proof20 : runCachedNode 511 129079 Adaptive141Third135Node20 = false := by
  decide +kernel

#print axioms adaptive141Third135Proof20

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third135Proof18 : runCachedNode 511 129079 Adaptive141Third135Node18 = false := by
  decide +kernel

#print axioms adaptive141Third135Proof18

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third135Proof31 : runCachedNode 511 129079 Adaptive141Third135Node31 = false := by
  decide +kernel

#print axioms adaptive141Third135Proof31

end NineSeparatedSubsetSums
