import NineSeparatedSubsetSums.EightPoint141_137PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint141_137PackedAnchor1Part0 :
    ∀ j : Fin 120, 2485069 ≤ FourPointNumeric.octPackedCharge 141 137 20 packedOct141_137_1
      (2*((j.val : Int)+0)+1) := by decide +kernel

end NineSeparatedSubsetSums
