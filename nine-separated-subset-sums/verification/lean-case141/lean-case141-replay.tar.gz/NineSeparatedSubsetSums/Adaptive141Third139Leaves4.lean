import NineSeparatedSubsetSums.Adaptive141Third139State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third139Proof20 : runCachedNode 511 129747 Adaptive141Third139Node20 = false := by
  decide +kernel

#print axioms adaptive141Third139Proof20

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third139Proof258 : runCachedNode 511 129747 Adaptive141Third139Node258 = false := by
  decide +kernel

#print axioms adaptive141Third139Proof258

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third139Proof55 : runCachedNode 511 129747 Adaptive141Third139Node55 = false := by
  decide +kernel

#print axioms adaptive141Third139Proof55

end NineSeparatedSubsetSums
