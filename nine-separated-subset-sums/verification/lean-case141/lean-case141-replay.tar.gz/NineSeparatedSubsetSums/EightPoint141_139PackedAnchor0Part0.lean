import NineSeparatedSubsetSums.EightPoint141_139PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint141_139PackedAnchor0Part0 :
    ∀ j : Fin 120, 2505339 ≤ FourPointNumeric.octPackedCharge 141 139 20 packedOct141_139_0
      (2*((j.val : Int)+0)+0) := by decide +kernel

end NineSeparatedSubsetSums
