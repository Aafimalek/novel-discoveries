import NineSeparatedSubsetSums.EightPointPackedGeometry
import NineSeparatedSubsetSums.EightPoint141_130PackedBudget0
import NineSeparatedSubsetSums.EightPoint141_130PackedAnchor0Part0
import NineSeparatedSubsetSums.EightPoint141_130PackedAnchor0Part1
import NineSeparatedSubsetSums.EightPoint141_130PackedAnchor0Part2
import NineSeparatedSubsetSums.EightPoint141_130PackedBudget1
import NineSeparatedSubsetSums.EightPoint141_130PackedAnchor1Part0
import NineSeparatedSubsetSums.EightPoint141_130PackedAnchor1Part1
import NineSeparatedSubsetSums.EightPoint141_130PackedAnchor1Part2

namespace NineSeparatedSubsetSums

private theorem packedOct141_130Anchor0 :
  ∀ j : Fin 492, ((j.val : Int)+141+130)%2=0 →
    2404567 ≤ FourPointNumeric.octPackedCharge 141 130 20 packedOct141_130_0 (j.val : Int) := by
  intro j hj
  let k := (j.val-1)/2
  have hk : k < 246 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+1 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint141_130PackedAnchor0Part0 z
    rwa [he,hrep] at ht
  by_cases h1 : k < 240
  · let z : Fin 120 := ⟨k-120, by omega⟩
    have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
    have ht := eightPoint141_130PackedAnchor0Part1 z
    rwa [he,hrep] at ht
  let z : Fin 6 := ⟨k-240, by omega⟩
  have he : (z.val : Int)+240 = k := by dsimp [z] <;> omega
  have ht := eightPoint141_130PackedAnchor0Part2 z
  rwa [he,hrep] at ht

private theorem packedOct141_130Anchor1 :
  ∀ j : Fin 492, ((j.val : Int)+141+130)%2=1 →
    2404464 ≤ FourPointNumeric.octPackedCharge 141 130 20 packedOct141_130_1 (j.val : Int) := by
  intro j hj
  let k := (j.val-0)/2
  have hk : k < 246 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+0 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint141_130PackedAnchor1Part0 z
    rwa [he,hrep] at ht
  by_cases h1 : k < 240
  · let z : Fin 120 := ⟨k-120, by omega⟩
    have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
    have ht := eightPoint141_130PackedAnchor1Part1 z
    rwa [he,hrep] at ht
  let z : Fin 6 := ⟨k-240, by omega⟩
  have he : (z.val : Int)+240 = k := by dsimp [z] <;> omega
  have ht := eightPoint141_130PackedAnchor1Part2 z
  rwa [he,hrep] at ht

def packedOctCertificate141_130_0 : EightPointCertificate 141 130 0 128244 :=
  eightPointCertificateOfPacked 141 130 0 128244 2404567 20 packedOct141_130_0 507 492
    (by decide +kernel) (by decide) packedOct141_130Anchor0
    (by rw [packedOct141_130_0_budget]; decide)

def packedOctCertificate141_130_1 : EightPointCertificate 141 130 1 128244 :=
  eightPointCertificateOfPacked 141 130 1 128244 2404464 20 packedOct141_130_1 508 492
    (by decide +kernel) (by decide) packedOct141_130Anchor1
    (by rw [packedOct141_130_1_budget]; decide)

theorem max148_second141_third130_eightPoint_moment_bound (tail : List ℕ) (len : tail.length=6)
    (distinct : (natSubsetSums (148::141::130::tail)).Nodup) :
    128244 ≤ ((148::141::130::tail).map (· ^ 2)).sum := by
  apply eightPointNatMomentLower 141 130 128244 tail len distinct
  intro p hp
  by_cases h : p=0
  · subst p
    exact packedOctCertificate141_130_0
  · have he : p=1 := hp.resolve_left h
    subst p
    exact packedOctCertificate141_130_1

#print axioms max148_second141_third130_eightPoint_moment_bound

end NineSeparatedSubsetSums
