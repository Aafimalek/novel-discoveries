import NineSeparatedSubsetSums.Adaptive141Third138State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third138Proof69 : runCachedNode 511 129566 Adaptive141Third138Node69 = false := by
  decide +kernel

#print axioms adaptive141Third138Proof69

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third138Proof97 : runCachedNode 511 129566 Adaptive141Third138Node97 = false := by
  decide +kernel

#print axioms adaptive141Third138Proof97

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third138Proof197 : runCachedNode 511 129566 Adaptive141Third138Node197 = false := by
  decide +kernel

#print axioms adaptive141Third138Proof197

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third138Proof193 : runCachedNode 511 129566 Adaptive141Third138Node193 = false := by
  decide +kernel

#print axioms adaptive141Third138Proof193

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third138Proof11 : runCachedNode 511 129566 Adaptive141Third138Node11 = false := by
  decide +kernel

#print axioms adaptive141Third138Proof11

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third138Proof192 : runCachedNode 511 129566 Adaptive141Third138Node192 = false := by
  decide +kernel

#print axioms adaptive141Third138Proof192

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third138Proof159 : runCachedNode 511 129566 Adaptive141Third138Node159 = false := by
  decide +kernel

#print axioms adaptive141Third138Proof159

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third138Proof95 : runCachedNode 511 129566 Adaptive141Third138Node95 = false := by
  decide +kernel

#print axioms adaptive141Third138Proof95

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third138Proof163 : runCachedNode 511 129566 Adaptive141Third138Node163 = false := by
  decide +kernel

#print axioms adaptive141Third138Proof163

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third138Proof96 : runCachedNode 511 129566 Adaptive141Third138Node96 = false := by
  decide +kernel

#print axioms adaptive141Third138Proof96

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third138Proof135 : runCachedNode 511 129566 Adaptive141Third138Node135 = false := by
  decide +kernel

#print axioms adaptive141Third138Proof135

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third138Proof160 : runCachedNode 511 129566 Adaptive141Third138Node160 = false := by
  decide +kernel

#print axioms adaptive141Third138Proof160

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third138Proof66 : runCachedNode 511 129566 Adaptive141Third138Node66 = false := by
  decide +kernel

#print axioms adaptive141Third138Proof66

end NineSeparatedSubsetSums
