import NineSeparatedSubsetSums.Adaptive141Third134State
import NineSeparatedSubsetSums.Adaptive141Third134Leaves12
import NineSeparatedSubsetSums.Adaptive141Third134Leaves0
import NineSeparatedSubsetSums.Adaptive141Third134Leaves11
import NineSeparatedSubsetSums.Adaptive141Third134Leaves1
import NineSeparatedSubsetSums.Adaptive141Third134Leaves10
import NineSeparatedSubsetSums.Adaptive141Third134Leaves3
import NineSeparatedSubsetSums.Adaptive141Third134Leaves9
import NineSeparatedSubsetSums.Adaptive141Third134Leaves6
import NineSeparatedSubsetSums.Adaptive141Third134Leaves8
import NineSeparatedSubsetSums.Adaptive141Third134Leaves5
import NineSeparatedSubsetSums.Adaptive141Third134Leaves4
import NineSeparatedSubsetSums.Adaptive141Third134Leaves7
import NineSeparatedSubsetSums.Adaptive141Third134Leaves2

namespace NineSeparatedSubsetSums

theorem adaptive141Third134Proof20 : runCachedNode 511 128866 Adaptive141Third134Node20 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 128866 Adaptive141Third134Node20 = [105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 117, 118, 119, 120, 121, 122, 124, 125, 126, 128, 129] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive141Third134Proof21
  · exact adaptive141Third134Proof22
  · exact adaptive141Third134Proof23
  · exact adaptive141Third134Proof24
  · exact adaptive141Third134Proof25
  · exact adaptive141Third134Proof26
  · exact adaptive141Third134Proof27
  · exact adaptive141Third134Proof28
  · exact adaptive141Third134Proof29
  · exact adaptive141Third134Proof30
  · exact adaptive141Third134Proof31
  · exact adaptive141Third134Proof32
  · exact adaptive141Third134Proof33
  · exact adaptive141Third134Proof34
  · exact adaptive141Third134Proof35
  · exact adaptive141Third134Proof36
  · exact adaptive141Third134Proof37
  · exact adaptive141Third134Proof38
  · exact adaptive141Third134Proof39
  · exact adaptive141Third134Proof40
  · exact adaptive141Third134Proof41
  · exact adaptive141Third134Proof42

#print axioms adaptive141Third134Proof20

theorem adaptive141Third134Proof43 : runCachedNode 511 128866 Adaptive141Third134Node43 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 128866 Adaptive141Third134Node43 = [104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 118, 119, 120, 121, 122, 123, 125, 126, 128, 129, 130] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive141Third134Proof44
  · exact adaptive141Third134Proof45
  · exact adaptive141Third134Proof46
  · exact adaptive141Third134Proof47
  · exact adaptive141Third134Proof48
  · exact adaptive141Third134Proof49
  · exact adaptive141Third134Proof50
  · exact adaptive141Third134Proof51
  · exact adaptive141Third134Proof52
  · exact adaptive141Third134Proof53
  · exact adaptive141Third134Proof54
  · exact adaptive141Third134Proof55
  · exact adaptive141Third134Proof56
  · exact adaptive141Third134Proof57
  · exact adaptive141Third134Proof58
  · exact adaptive141Third134Proof59
  · exact adaptive141Third134Proof60
  · exact adaptive141Third134Proof61
  · exact adaptive141Third134Proof62
  · exact adaptive141Third134Proof63
  · exact adaptive141Third134Proof64
  · exact adaptive141Third134Proof65
  · exact adaptive141Third134Proof66
  · exact adaptive141Third134Proof67

#print axioms adaptive141Third134Proof43

theorem adaptive141Third134Proof68 : runCachedNode 511 128866 Adaptive141Third134Node68 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 128866 Adaptive141Third134Node68 = [104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 119, 120, 121, 122, 123, 124, 126, 128, 129, 130, 131] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive141Third134Proof69
  · exact adaptive141Third134Proof70
  · exact adaptive141Third134Proof71
  · exact adaptive141Third134Proof72
  · exact adaptive141Third134Proof73
  · exact adaptive141Third134Proof74
  · exact adaptive141Third134Proof75
  · exact adaptive141Third134Proof76
  · exact adaptive141Third134Proof77
  · exact adaptive141Third134Proof78
  · exact adaptive141Third134Proof79
  · exact adaptive141Third134Proof80
  · exact adaptive141Third134Proof81
  · exact adaptive141Third134Proof82
  · exact adaptive141Third134Proof83
  · exact adaptive141Third134Proof84
  · exact adaptive141Third134Proof85
  · exact adaptive141Third134Proof86
  · exact adaptive141Third134Proof87
  · exact adaptive141Third134Proof88
  · exact adaptive141Third134Proof89
  · exact adaptive141Third134Proof90
  · exact adaptive141Third134Proof91
  · exact adaptive141Third134Proof92
  · exact adaptive141Third134Proof93

#print axioms adaptive141Third134Proof68

theorem adaptive141Third134Proof94 : runCachedNode 511 128866 Adaptive141Third134Node94 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 128866 Adaptive141Third134Node94 = [104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 120, 121, 122, 123, 124, 125, 128, 129, 130, 131, 132] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive141Third134Proof95
  · exact adaptive141Third134Proof96
  · exact adaptive141Third134Proof97
  · exact adaptive141Third134Proof98
  · exact adaptive141Third134Proof99
  · exact adaptive141Third134Proof100
  · exact adaptive141Third134Proof101
  · exact adaptive141Third134Proof102
  · exact adaptive141Third134Proof103
  · exact adaptive141Third134Proof104
  · exact adaptive141Third134Proof105
  · exact adaptive141Third134Proof106
  · exact adaptive141Third134Proof107
  · exact adaptive141Third134Proof108
  · exact adaptive141Third134Proof109
  · exact adaptive141Third134Proof110
  · exact adaptive141Third134Proof111
  · exact adaptive141Third134Proof112
  · exact adaptive141Third134Proof113
  · exact adaptive141Third134Proof114
  · exact adaptive141Third134Proof115
  · exact adaptive141Third134Proof116
  · exact adaptive141Third134Proof117
  · exact adaptive141Third134Proof118
  · exact adaptive141Third134Proof119
  · exact adaptive141Third134Proof120

#print axioms adaptive141Third134Proof94

theorem adaptive141Third134Proof0 : runCachedNode 511 128866 Adaptive141Third134Node0 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 128866 Adaptive141Third134Node0 = [110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 128, 129, 130, 131, 132, 133] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive141Third134Proof1
  · exact adaptive141Third134Proof2
  · exact adaptive141Third134Proof3
  · exact adaptive141Third134Proof4
  · exact adaptive141Third134Proof5
  · exact adaptive141Third134Proof6
  · exact adaptive141Third134Proof7
  · exact adaptive141Third134Proof8
  · exact adaptive141Third134Proof9
  · exact adaptive141Third134Proof10
  · exact adaptive141Third134Proof11
  · exact adaptive141Third134Proof12
  · exact adaptive141Third134Proof13
  · exact adaptive141Third134Proof14
  · exact adaptive141Third134Proof15
  · exact adaptive141Third134Proof16
  · exact adaptive141Third134Proof17
  · exact adaptive141Third134Proof18
  · exact adaptive141Third134Proof19
  · exact adaptive141Third134Proof20
  · exact adaptive141Third134Proof43
  · exact adaptive141Third134Proof68
  · exact adaptive141Third134Proof94

#print axioms adaptive141Third134Proof0

end NineSeparatedSubsetSums
