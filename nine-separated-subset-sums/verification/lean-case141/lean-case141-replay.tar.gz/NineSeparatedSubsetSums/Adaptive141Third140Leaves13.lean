import NineSeparatedSubsetSums.Adaptive141Third140State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third140Proof200 : runCachedNode 511 129930 Adaptive141Third140Node200 = false := by
  decide +kernel

#print axioms adaptive141Third140Proof200

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third140Proof198 : runCachedNode 511 129930 Adaptive141Third140Node198 = false := by
  decide +kernel

#print axioms adaptive141Third140Proof198

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third140Proof3 : runCachedNode 511 129930 Adaptive141Third140Node3 = false := by
  decide +kernel

#print axioms adaptive141Third140Proof3

end NineSeparatedSubsetSums
