import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive141Third121Node0 : CachedSearchNode :=
  ⟨4, 120, computeCenteredMask [148,141,121], 410, 56426⟩

end NineSeparatedSubsetSums
