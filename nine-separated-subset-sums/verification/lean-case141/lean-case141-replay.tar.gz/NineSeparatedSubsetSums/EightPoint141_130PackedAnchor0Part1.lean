import NineSeparatedSubsetSums.EightPoint141_130PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint141_130PackedAnchor0Part1 :
    ∀ j : Fin 120, 2404567 ≤ FourPointNumeric.octPackedCharge 141 130 20 packedOct141_130_0
      (2*((j.val : Int)+120)+1) := by decide +kernel

end NineSeparatedSubsetSums
