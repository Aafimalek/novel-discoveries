import NineSeparatedSubsetSums.Adaptive141Third131State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third131Proof19 : runCachedNode 511 128468 Adaptive141Third131Node19 = false := by
  decide +kernel

#print axioms adaptive141Third131Proof19

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third131Proof17 : runCachedNode 511 128468 Adaptive141Third131Node17 = false := by
  decide +kernel

#print axioms adaptive141Third131Proof17

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third131Proof6 : runCachedNode 511 128468 Adaptive141Third131Node6 = false := by
  decide +kernel

#print axioms adaptive141Third131Proof6

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third131Proof3 : runCachedNode 511 128468 Adaptive141Third131Node3 = false := by
  decide +kernel

#print axioms adaptive141Third131Proof3

end NineSeparatedSubsetSums
