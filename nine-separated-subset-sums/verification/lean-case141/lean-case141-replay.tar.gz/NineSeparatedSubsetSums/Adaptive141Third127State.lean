import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive141Third127Node0 : CachedSearchNode :=
  ⟨4, 126, computeCenteredMask [148,141,127], 416, 57914⟩

end NineSeparatedSubsetSums
