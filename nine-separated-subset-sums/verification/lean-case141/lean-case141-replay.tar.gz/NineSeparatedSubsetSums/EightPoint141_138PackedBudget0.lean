import NineSeparatedSubsetSums.EightPoint141_138PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct141_138_0_budget :
    FourPointNumeric.packedBudget 20 packedOct141_138_0 277 = 93395848 := by decide +kernel

#print axioms packedOct141_138_0_budget

end NineSeparatedSubsetSums
