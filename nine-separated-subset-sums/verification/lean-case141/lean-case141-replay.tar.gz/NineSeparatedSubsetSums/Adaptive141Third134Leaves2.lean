import NineSeparatedSubsetSums.Adaptive141Third134State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third134Proof120 : runCachedNode 511 128866 Adaptive141Third134Node120 = false := by
  decide +kernel

#print axioms adaptive141Third134Proof120

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third134Proof15 : runCachedNode 511 128866 Adaptive141Third134Node15 = false := by
  decide +kernel

#print axioms adaptive141Third134Proof15

end NineSeparatedSubsetSums
