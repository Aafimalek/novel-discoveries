import NineSeparatedSubsetSums.Adaptive141Third113Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint141Checked

namespace NineSeparatedSubsetSums


theorem adaptive141Third113 : NoDescendingTailAfterThird 141 113 :=
  noDescendingThirdTail_of_cached 141 113 111653 (fun t ht nd => max148_second141_fourPoint_moment_bound (113::t) (by simp [ht]) nd) adaptive141Third113Proof0

#print axioms adaptive141Third113

end NineSeparatedSubsetSums
