import NineSeparatedSubsetSums.Adaptive141Third139State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third139Proof260 : runCachedNode 511 129747 Adaptive141Third139Node260 = false := by
  decide +kernel

#print axioms adaptive141Third139Proof260

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third139Proof225 : runCachedNode 511 129747 Adaptive141Third139Node225 = false := by
  decide +kernel

#print axioms adaptive141Third139Proof225

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third139Proof32 : runCachedNode 511 129747 Adaptive141Third139Node32 = false := by
  decide +kernel

#print axioms adaptive141Third139Proof32

end NineSeparatedSubsetSums
