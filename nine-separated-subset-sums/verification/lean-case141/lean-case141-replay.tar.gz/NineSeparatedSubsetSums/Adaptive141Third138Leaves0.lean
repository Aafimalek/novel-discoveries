import NineSeparatedSubsetSums.Adaptive141Third138State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third138Proof22 : runCachedNode 511 129566 Adaptive141Third138Node22 = false := by
  decide +kernel

#print axioms adaptive141Third138Proof22

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third138Proof9 : runCachedNode 511 129566 Adaptive141Third138Node9 = false := by
  decide +kernel

#print axioms adaptive141Third138Proof9

end NineSeparatedSubsetSums
