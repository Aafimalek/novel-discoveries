import NineSeparatedSubsetSums.EightPoint141_117PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct141_117_1_budget :
    FourPointNumeric.packedBudget 20 packedOct141_117_1 268 = 86840020 := by decide +kernel

#print axioms packedOct141_117_1_budget

end NineSeparatedSubsetSums
