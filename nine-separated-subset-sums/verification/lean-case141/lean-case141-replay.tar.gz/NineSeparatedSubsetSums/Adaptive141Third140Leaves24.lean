import NineSeparatedSubsetSums.Adaptive141Third140State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third140Proof191 : runCachedNode 511 129930 Adaptive141Third140Node191 = false := by
  decide +kernel

#print axioms adaptive141Third140Proof191

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third140Proof158 : runCachedNode 511 129930 Adaptive141Third140Node158 = false := by
  decide +kernel

#print axioms adaptive141Third140Proof158

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third140Proof160 : runCachedNode 511 129930 Adaptive141Third140Node160 = false := by
  decide +kernel

#print axioms adaptive141Third140Proof160

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third140Proof269 : runCachedNode 511 129930 Adaptive141Third140Node269 = false := by
  decide +kernel

#print axioms adaptive141Third140Proof269

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third140Proof10 : runCachedNode 511 129930 Adaptive141Third140Node10 = false := by
  decide +kernel

#print axioms adaptive141Third140Proof10

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third140Proof190 : runCachedNode 511 129930 Adaptive141Third140Node190 = false := by
  decide +kernel

#print axioms adaptive141Third140Proof190

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third140Proof192 : runCachedNode 511 129930 Adaptive141Third140Node192 = false := by
  decide +kernel

#print axioms adaptive141Third140Proof192

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third140Proof221 : runCachedNode 511 129930 Adaptive141Third140Node221 = false := by
  decide +kernel

#print axioms adaptive141Third140Proof221

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third140Proof128 : runCachedNode 511 129930 Adaptive141Third140Node128 = false := by
  decide +kernel

#print axioms adaptive141Third140Proof128

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third140Proof193 : runCachedNode 511 129930 Adaptive141Third140Node193 = false := by
  decide +kernel

#print axioms adaptive141Third140Proof193

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third140Proof157 : runCachedNode 511 129930 Adaptive141Third140Node157 = false := by
  decide +kernel

#print axioms adaptive141Third140Proof157

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third140Proof39 : runCachedNode 511 129930 Adaptive141Third140Node39 = false := by
  decide +kernel

#print axioms adaptive141Third140Proof39

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third140Proof98 : runCachedNode 511 129930 Adaptive141Third140Node98 = false := by
  decide +kernel

#print axioms adaptive141Third140Proof98

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third140Proof38 : runCachedNode 511 129930 Adaptive141Third140Node38 = false := by
  decide +kernel

#print axioms adaptive141Third140Proof38

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third140Proof219 : runCachedNode 511 129930 Adaptive141Third140Node219 = false := by
  decide +kernel

#print axioms adaptive141Third140Proof219

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third140Proof65 : runCachedNode 511 129930 Adaptive141Third140Node65 = false := by
  decide +kernel

#print axioms adaptive141Third140Proof65

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third140Proof117 : runCachedNode 511 129930 Adaptive141Third140Node117 = false := by
  decide +kernel

#print axioms adaptive141Third140Proof117

end NineSeparatedSubsetSums
