import NineSeparatedSubsetSums.Adaptive141Third116State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third116Proof12 : runCachedNode 511 111653 Adaptive141Third116Node12 = false := by
  decide +kernel

#print axioms adaptive141Third116Proof12

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third116Proof11 : runCachedNode 511 111653 Adaptive141Third116Node11 = false := by
  decide +kernel

#print axioms adaptive141Third116Proof11

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third116Proof10 : runCachedNode 511 111653 Adaptive141Third116Node10 = false := by
  decide +kernel

#print axioms adaptive141Third116Proof10

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third116Proof9 : runCachedNode 511 111653 Adaptive141Third116Node9 = false := by
  decide +kernel

#print axioms adaptive141Third116Proof9

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third116Proof8 : runCachedNode 511 111653 Adaptive141Third116Node8 = false := by
  decide +kernel

#print axioms adaptive141Third116Proof8

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third116Proof7 : runCachedNode 511 111653 Adaptive141Third116Node7 = false := by
  decide +kernel

#print axioms adaptive141Third116Proof7

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third116Proof5 : runCachedNode 511 111653 Adaptive141Third116Node5 = false := by
  decide +kernel

#print axioms adaptive141Third116Proof5

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third116Proof4 : runCachedNode 511 111653 Adaptive141Third116Node4 = false := by
  decide +kernel

#print axioms adaptive141Third116Proof4

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third116Proof3 : runCachedNode 511 111653 Adaptive141Third116Node3 = false := by
  decide +kernel

#print axioms adaptive141Third116Proof3

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third116Proof2 : runCachedNode 511 111653 Adaptive141Third116Node2 = false := by
  decide +kernel

#print axioms adaptive141Third116Proof2

end NineSeparatedSubsetSums
