import NineSeparatedSubsetSums.Adaptive141Third135State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third135Proof17 : runCachedNode 511 129079 Adaptive141Third135Node17 = false := by
  decide +kernel

#print axioms adaptive141Third135Proof17

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third135Proof72 : runCachedNode 511 129079 Adaptive141Third135Node72 = false := by
  decide +kernel

#print axioms adaptive141Third135Proof72

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third135Proof16 : runCachedNode 511 129079 Adaptive141Third135Node16 = false := by
  decide +kernel

#print axioms adaptive141Third135Proof16

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third135Proof13 : runCachedNode 511 129079 Adaptive141Third135Node13 = false := by
  decide +kernel

#print axioms adaptive141Third135Proof13

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third135Proof2 : runCachedNode 511 129079 Adaptive141Third135Node2 = false := by
  decide +kernel

#print axioms adaptive141Third135Proof2

end NineSeparatedSubsetSums
