import NineSeparatedSubsetSums.Adaptive141Third135State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third135Proof46 : runCachedNode 511 129079 Adaptive141Third135Node46 = false := by
  decide +kernel

#print axioms adaptive141Third135Proof46

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third135Proof15 : runCachedNode 511 129079 Adaptive141Third135Node15 = false := by
  decide +kernel

#print axioms adaptive141Third135Proof15

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third135Proof70 : runCachedNode 511 129079 Adaptive141Third135Node70 = false := by
  decide +kernel

#print axioms adaptive141Third135Proof70

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third135Proof45 : runCachedNode 511 129079 Adaptive141Third135Node45 = false := by
  decide +kernel

#print axioms adaptive141Third135Proof45

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third135Proof91 : runCachedNode 511 129079 Adaptive141Third135Node91 = false := by
  decide +kernel

#print axioms adaptive141Third135Proof91

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third135Proof24 : runCachedNode 511 129079 Adaptive141Third135Node24 = false := by
  decide +kernel

#print axioms adaptive141Third135Proof24

end NineSeparatedSubsetSums
