import NineSeparatedSubsetSums.EightPoint141_136PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct141_136_0_budget :
    FourPointNumeric.packedBudget 20 packedOct141_136_0 437 = 92451374 := by decide +kernel

#print axioms packedOct141_136_0_budget

end NineSeparatedSubsetSums
