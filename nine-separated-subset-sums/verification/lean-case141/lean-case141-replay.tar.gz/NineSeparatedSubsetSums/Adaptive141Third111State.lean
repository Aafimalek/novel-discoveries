import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive141Third111Node0 : CachedSearchNode :=
  ⟨4, 110, computeCenteredMask [148,141,111], 400, 54106⟩

end NineSeparatedSubsetSums
