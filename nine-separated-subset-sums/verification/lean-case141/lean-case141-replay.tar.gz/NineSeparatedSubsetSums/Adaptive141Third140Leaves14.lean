import NineSeparatedSubsetSums.Adaptive141Third140State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third140Proof19 : runCachedNode 511 129930 Adaptive141Third140Node19 = false := by
  decide +kernel

#print axioms adaptive141Third140Proof19

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third140Proof230 : runCachedNode 511 129930 Adaptive141Third140Node230 = false := by
  decide +kernel

#print axioms adaptive141Third140Proof230

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third140Proof67 : runCachedNode 511 129930 Adaptive141Third140Node67 = false := by
  decide +kernel

#print axioms adaptive141Third140Proof67

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third140Proof79 : runCachedNode 511 129930 Adaptive141Third140Node79 = false := by
  decide +kernel

#print axioms adaptive141Third140Proof79

end NineSeparatedSubsetSums
