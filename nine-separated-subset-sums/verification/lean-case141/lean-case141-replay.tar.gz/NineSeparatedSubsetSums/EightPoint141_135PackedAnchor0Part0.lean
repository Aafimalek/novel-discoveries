import NineSeparatedSubsetSums.EightPoint141_135PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint141_135PackedAnchor0Part0 :
    ∀ j : Fin 120, 2472049 ≤ FourPointNumeric.octPackedCharge 141 135 20 packedOct141_135_0
      (2*((j.val : Int)+0)+0) := by decide +kernel

end NineSeparatedSubsetSums
