import NineSeparatedSubsetSums.Adaptive141Third128State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third128Proof11 : runCachedNode 511 127705 Adaptive141Third128Node11 = false := by
  decide +kernel

#print axioms adaptive141Third128Proof11

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third128Proof9 : runCachedNode 511 127705 Adaptive141Third128Node9 = false := by
  decide +kernel

#print axioms adaptive141Third128Proof9

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third128Proof8 : runCachedNode 511 127705 Adaptive141Third128Node8 = false := by
  decide +kernel

#print axioms adaptive141Third128Proof8

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third128Proof7 : runCachedNode 511 127705 Adaptive141Third128Node7 = false := by
  decide +kernel

#print axioms adaptive141Third128Proof7

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third128Proof6 : runCachedNode 511 127705 Adaptive141Third128Node6 = false := by
  decide +kernel

#print axioms adaptive141Third128Proof6

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third128Proof5 : runCachedNode 511 127705 Adaptive141Third128Node5 = false := by
  decide +kernel

#print axioms adaptive141Third128Proof5

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third128Proof4 : runCachedNode 511 127705 Adaptive141Third128Node4 = false := by
  decide +kernel

#print axioms adaptive141Third128Proof4

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third128Proof3 : runCachedNode 511 127705 Adaptive141Third128Node3 = false := by
  decide +kernel

#print axioms adaptive141Third128Proof3

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third128Proof2 : runCachedNode 511 127705 Adaptive141Third128Node2 = false := by
  decide +kernel

#print axioms adaptive141Third128Proof2

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third128Proof1 : runCachedNode 511 127705 Adaptive141Third128Node1 = false := by
  decide +kernel

#print axioms adaptive141Third128Proof1

end NineSeparatedSubsetSums
