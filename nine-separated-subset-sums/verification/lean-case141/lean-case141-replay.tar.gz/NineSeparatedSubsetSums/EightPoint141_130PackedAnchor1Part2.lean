import NineSeparatedSubsetSums.EightPoint141_130PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint141_130PackedAnchor1Part2 :
    ∀ j : Fin 6, 2404464 ≤ FourPointNumeric.octPackedCharge 141 130 20 packedOct141_130_1
      (2*((j.val : Int)+240)+0) := by decide +kernel

end NineSeparatedSubsetSums
