import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive141Third125Node0 : CachedSearchNode :=
  ⟨4, 124, computeCenteredMask [148,141,125], 414, 57410⟩

end NineSeparatedSubsetSums
