import NineSeparatedSubsetSums.EightPoint141_122PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct141_122_1_budget :
    FourPointNumeric.packedBudget 20 packedOct141_122_1 278 = 83112818 := by decide +kernel

#print axioms packedOct141_122_1_budget

end NineSeparatedSubsetSums
