import NineSeparatedSubsetSums.EightPoint141_135PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct141_135_1_budget :
    FourPointNumeric.packedBudget 20 packedOct141_135_1 470 = 92120498 := by decide +kernel

#print axioms packedOct141_135_1_budget

end NineSeparatedSubsetSums
