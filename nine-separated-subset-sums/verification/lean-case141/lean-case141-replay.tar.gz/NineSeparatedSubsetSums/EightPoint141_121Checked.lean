import NineSeparatedSubsetSums.EightPointPackedGeometry
import NineSeparatedSubsetSums.EightPoint141_121PackedBudget0
import NineSeparatedSubsetSums.EightPoint141_121PackedAnchor0Part0
import NineSeparatedSubsetSums.EightPoint141_121PackedAnchor0Part1
import NineSeparatedSubsetSums.EightPoint141_121PackedAnchor0Part2
import NineSeparatedSubsetSums.EightPoint141_121PackedBudget1
import NineSeparatedSubsetSums.EightPoint141_121PackedAnchor1Part0
import NineSeparatedSubsetSums.EightPoint141_121PackedAnchor1Part1
import NineSeparatedSubsetSums.EightPoint141_121PackedAnchor1Part2

namespace NineSeparatedSubsetSums

private theorem packedOct141_121Anchor0 :
  ∀ j : Fin 482, ((j.val : Int)+141+121)%2=0 →
    2303982 ≤ FourPointNumeric.octPackedCharge 141 121 20 packedOct141_121_0 (j.val : Int) := by
  intro j hj
  let k := (j.val-0)/2
  have hk : k < 241 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+0 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint141_121PackedAnchor0Part0 z
    rwa [he,hrep] at ht
  by_cases h1 : k < 240
  · let z : Fin 120 := ⟨k-120, by omega⟩
    have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
    have ht := eightPoint141_121PackedAnchor0Part1 z
    rwa [he,hrep] at ht
  let z : Fin 1 := ⟨k-240, by omega⟩
  have he : (z.val : Int)+240 = k := by dsimp [z] <;> omega
  have ht := eightPoint141_121PackedAnchor0Part2 z
  rwa [he,hrep] at ht

private theorem packedOct141_121Anchor1 :
  ∀ j : Fin 482, ((j.val : Int)+141+121)%2=1 →
    2300215 ≤ FourPointNumeric.octPackedCharge 141 121 20 packedOct141_121_1 (j.val : Int) := by
  intro j hj
  let k := (j.val-1)/2
  have hk : k < 241 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+1 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint141_121PackedAnchor1Part0 z
    rwa [he,hrep] at ht
  by_cases h1 : k < 240
  · let z : Fin 120 := ⟨k-120, by omega⟩
    have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
    have ht := eightPoint141_121PackedAnchor1Part1 z
    rwa [he,hrep] at ht
  let z : Fin 1 := ⟨k-240, by omega⟩
  have he : (z.val : Int)+240 = k := by dsimp [z] <;> omega
  have ht := eightPoint141_121PackedAnchor1Part2 z
  rwa [he,hrep] at ht

def packedOctCertificate141_121_0 : EightPointCertificate 141 121 0 125914 :=
  eightPointCertificateOfPacked 141 121 0 125914 2303982 20 packedOct141_121_0 263 482
    (by decide +kernel) (by decide) packedOct141_121Anchor0
    (by rw [packedOct141_121_0_budget]; decide)

def packedOctCertificate141_121_1 : EightPointCertificate 141 121 1 125914 :=
  eightPointCertificateOfPacked 141 121 1 125914 2300215 20 packedOct141_121_1 264 482
    (by decide +kernel) (by decide) packedOct141_121Anchor1
    (by rw [packedOct141_121_1_budget]; decide)

theorem max148_second141_third121_eightPoint_moment_bound (tail : List ℕ) (len : tail.length=6)
    (distinct : (natSubsetSums (148::141::121::tail)).Nodup) :
    125914 ≤ ((148::141::121::tail).map (· ^ 2)).sum := by
  apply eightPointNatMomentLower 141 121 125914 tail len distinct
  intro p hp
  by_cases h : p=0
  · subst p
    exact packedOctCertificate141_121_0
  · have he : p=1 := hp.resolve_left h
    subst p
    exact packedOctCertificate141_121_1

#print axioms max148_second141_third121_eightPoint_moment_bound

end NineSeparatedSubsetSums
