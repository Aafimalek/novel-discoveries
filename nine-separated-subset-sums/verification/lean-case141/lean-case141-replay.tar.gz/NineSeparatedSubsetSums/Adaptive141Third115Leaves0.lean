import NineSeparatedSubsetSums.Adaptive141Third115State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third115Proof14 : runCachedNode 511 111653 Adaptive141Third115Node14 = false := by
  decide +kernel

#print axioms adaptive141Third115Proof14

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third115Proof13 : runCachedNode 511 111653 Adaptive141Third115Node13 = false := by
  decide +kernel

#print axioms adaptive141Third115Proof13

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third115Proof12 : runCachedNode 511 111653 Adaptive141Third115Node12 = false := by
  decide +kernel

#print axioms adaptive141Third115Proof12

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third115Proof11 : runCachedNode 511 111653 Adaptive141Third115Node11 = false := by
  decide +kernel

#print axioms adaptive141Third115Proof11

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third115Proof10 : runCachedNode 511 111653 Adaptive141Third115Node10 = false := by
  decide +kernel

#print axioms adaptive141Third115Proof10

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third115Proof6 : runCachedNode 511 111653 Adaptive141Third115Node6 = false := by
  decide +kernel

#print axioms adaptive141Third115Proof6

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third115Proof2 : runCachedNode 511 111653 Adaptive141Third115Node2 = false := by
  decide +kernel

#print axioms adaptive141Third115Proof2

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third115Proof1 : runCachedNode 511 111653 Adaptive141Third115Node1 = false := by
  decide +kernel

#print axioms adaptive141Third115Proof1

end NineSeparatedSubsetSums
