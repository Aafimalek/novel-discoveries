import NineSeparatedSubsetSums.Adaptive141Third138State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third138Proof21 : runCachedNode 511 129566 Adaptive141Third138Node21 = false := by
  decide +kernel

#print axioms adaptive141Third138Proof21

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third138Proof105 : runCachedNode 511 129566 Adaptive141Third138Node105 = false := by
  decide +kernel

#print axioms adaptive141Third138Proof105

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third138Proof31 : runCachedNode 511 129566 Adaptive141Third138Node31 = false := by
  decide +kernel

#print axioms adaptive141Third138Proof31

end NineSeparatedSubsetSums
