import NineSeparatedSubsetSums.Adaptive141Third127State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third127Proof0 : runCachedNode 511 127543 Adaptive141Third127Node0 = false := by
  decide +kernel

#print axioms adaptive141Third127Proof0

end NineSeparatedSubsetSums
