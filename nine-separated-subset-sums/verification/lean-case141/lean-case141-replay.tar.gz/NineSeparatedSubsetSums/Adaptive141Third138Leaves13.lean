import NineSeparatedSubsetSums.Adaptive141Third138State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third138Proof166 : runCachedNode 511 129566 Adaptive141Third138Node166 = false := by
  decide +kernel

#print axioms adaptive141Third138Proof166

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third138Proof98 : runCachedNode 511 129566 Adaptive141Third138Node98 = false := by
  decide +kernel

#print axioms adaptive141Third138Proof98

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third138Proof162 : runCachedNode 511 129566 Adaptive141Third138Node162 = false := by
  decide +kernel

#print axioms adaptive141Third138Proof162

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third138Proof72 : runCachedNode 511 129566 Adaptive141Third138Node72 = false := by
  decide +kernel

#print axioms adaptive141Third138Proof72

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third138Proof13 : runCachedNode 511 129566 Adaptive141Third138Node13 = false := by
  decide +kernel

#print axioms adaptive141Third138Proof13

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third138Proof198 : runCachedNode 511 129566 Adaptive141Third138Node198 = false := by
  decide +kernel

#print axioms adaptive141Third138Proof198

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third138Proof99 : runCachedNode 511 129566 Adaptive141Third138Node99 = false := by
  decide +kernel

#print axioms adaptive141Third138Proof99

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third138Proof121 : runCachedNode 511 129566 Adaptive141Third138Node121 = false := by
  decide +kernel

#print axioms adaptive141Third138Proof121

end NineSeparatedSubsetSums
