import NineSeparatedSubsetSums.Adaptive141Third117State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third117Proof0 : runCachedNode 511 125131 Adaptive141Third117Node0 = false := by
  decide +kernel

#print axioms adaptive141Third117Proof0

end NineSeparatedSubsetSums
