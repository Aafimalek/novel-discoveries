import NineSeparatedSubsetSums.Adaptive141Third110Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint141Checked

namespace NineSeparatedSubsetSums


theorem adaptive141Third110 : NoDescendingTailAfterThird 141 110 :=
  noDescendingThirdTail_of_cached 141 110 111653 (fun t ht nd => max148_second141_fourPoint_moment_bound (110::t) (by simp [ht]) nd) adaptive141Third110Proof0

#print axioms adaptive141Third110

end NineSeparatedSubsetSums
