import NineSeparatedSubsetSums.Adaptive141Third140State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third140Proof196 : runCachedNode 511 129930 Adaptive141Third140Node196 = false := by
  decide +kernel

#print axioms adaptive141Third140Proof196

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third140Proof72 : runCachedNode 511 129930 Adaptive141Third140Node72 = false := by
  decide +kernel

#print axioms adaptive141Third140Proof72

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third140Proof197 : runCachedNode 511 129930 Adaptive141Third140Node197 = false := by
  decide +kernel

#print axioms adaptive141Third140Proof197

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third140Proof104 : runCachedNode 511 129930 Adaptive141Third140Node104 = false := by
  decide +kernel

#print axioms adaptive141Third140Proof104

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third140Proof224 : runCachedNode 511 129930 Adaptive141Third140Node224 = false := by
  decide +kernel

#print axioms adaptive141Third140Proof224

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third140Proof170 : runCachedNode 511 129930 Adaptive141Third140Node170 = false := by
  decide +kernel

#print axioms adaptive141Third140Proof170

end NineSeparatedSubsetSums
