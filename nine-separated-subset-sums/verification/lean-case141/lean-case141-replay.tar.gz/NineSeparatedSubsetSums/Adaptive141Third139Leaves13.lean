import NineSeparatedSubsetSums.Adaptive141Third139State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third139Proof15 : runCachedNode 511 129747 Adaptive141Third139Node15 = false := by
  decide +kernel

#print axioms adaptive141Third139Proof15

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third139Proof72 : runCachedNode 511 129747 Adaptive141Third139Node72 = false := by
  decide +kernel

#print axioms adaptive141Third139Proof72

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third139Proof96 : runCachedNode 511 129747 Adaptive141Third139Node96 = false := by
  decide +kernel

#print axioms adaptive141Third139Proof96

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third139Proof188 : runCachedNode 511 129747 Adaptive141Third139Node188 = false := by
  decide +kernel

#print axioms adaptive141Third139Proof188

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third139Proof184 : runCachedNode 511 129747 Adaptive141Third139Node184 = false := by
  decide +kernel

#print axioms adaptive141Third139Proof184

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third139Proof35 : runCachedNode 511 129747 Adaptive141Third139Node35 = false := by
  decide +kernel

#print axioms adaptive141Third139Proof35

end NineSeparatedSubsetSums
