import NineSeparatedSubsetSums.Adaptive141Third134State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third134Proof18 : runCachedNode 511 128866 Adaptive141Third134Node18 = false := by
  decide +kernel

#print axioms adaptive141Third134Proof18

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third134Proof66 : runCachedNode 511 128866 Adaptive141Third134Node66 = false := by
  decide +kernel

#print axioms adaptive141Third134Proof66

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third134Proof28 : runCachedNode 511 128866 Adaptive141Third134Node28 = false := by
  decide +kernel

#print axioms adaptive141Third134Proof28

end NineSeparatedSubsetSums
