import NineSeparatedSubsetSums.Adaptive141Third137State
import NineSeparatedSubsetSums.Adaptive141Third137Leaves1
import NineSeparatedSubsetSums.Adaptive141Third137Leaves15
import NineSeparatedSubsetSums.Adaptive141Third137Leaves0
import NineSeparatedSubsetSums.Adaptive141Third137Leaves13
import NineSeparatedSubsetSums.Adaptive141Third137Leaves2
import NineSeparatedSubsetSums.Adaptive141Third137Leaves14
import NineSeparatedSubsetSums.Adaptive141Third137Leaves12
import NineSeparatedSubsetSums.Adaptive141Third137Leaves10
import NineSeparatedSubsetSums.Adaptive141Third137Leaves11
import NineSeparatedSubsetSums.Adaptive141Third137Leaves7
import NineSeparatedSubsetSums.Adaptive141Third137Leaves9
import NineSeparatedSubsetSums.Adaptive141Third137Leaves8
import NineSeparatedSubsetSums.Adaptive141Third137Leaves5
import NineSeparatedSubsetSums.Adaptive141Third137Leaves4
import NineSeparatedSubsetSums.Adaptive141Third137Leaves3
import NineSeparatedSubsetSums.Adaptive141Third137Leaves6

namespace NineSeparatedSubsetSums

theorem adaptive141Third137Proof23 : runCachedNode 511 129418 Adaptive141Third137Node23 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 129418 Adaptive141Third137Node23 = [104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 123, 124, 125, 127, 128, 131, 132] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive141Third137Proof24
  · exact adaptive141Third137Proof25
  · exact adaptive141Third137Proof26
  · exact adaptive141Third137Proof27
  · exact adaptive141Third137Proof28
  · exact adaptive141Third137Proof29
  · exact adaptive141Third137Proof30
  · exact adaptive141Third137Proof31
  · exact adaptive141Third137Proof32
  · exact adaptive141Third137Proof33
  · exact adaptive141Third137Proof34
  · exact adaptive141Third137Proof35
  · exact adaptive141Third137Proof36
  · exact adaptive141Third137Proof37
  · exact adaptive141Third137Proof38
  · exact adaptive141Third137Proof39
  · exact adaptive141Third137Proof40
  · exact adaptive141Third137Proof41
  · exact adaptive141Third137Proof42
  · exact adaptive141Third137Proof43
  · exact adaptive141Third137Proof44
  · exact adaptive141Third137Proof45
  · exact adaptive141Third137Proof46
  · exact adaptive141Third137Proof47
  · exact adaptive141Third137Proof48

#print axioms adaptive141Third137Proof23

theorem adaptive141Third137Proof49 : runCachedNode 511 129418 Adaptive141Third137Node49 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 129418 Adaptive141Third137Node49 = [103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 124, 125, 126, 128, 129, 131, 132, 133] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive141Third137Proof50
  · exact adaptive141Third137Proof51
  · exact adaptive141Third137Proof52
  · exact adaptive141Third137Proof53
  · exact adaptive141Third137Proof54
  · exact adaptive141Third137Proof55
  · exact adaptive141Third137Proof56
  · exact adaptive141Third137Proof57
  · exact adaptive141Third137Proof58
  · exact adaptive141Third137Proof59
  · exact adaptive141Third137Proof60
  · exact adaptive141Third137Proof61
  · exact adaptive141Third137Proof62
  · exact adaptive141Third137Proof63
  · exact adaptive141Third137Proof64
  · exact adaptive141Third137Proof65
  · exact adaptive141Third137Proof66
  · exact adaptive141Third137Proof67
  · exact adaptive141Third137Proof68
  · exact adaptive141Third137Proof69
  · exact adaptive141Third137Proof70
  · exact adaptive141Third137Proof71
  · exact adaptive141Third137Proof72
  · exact adaptive141Third137Proof73
  · exact adaptive141Third137Proof74
  · exact adaptive141Third137Proof75
  · exact adaptive141Third137Proof76
  · exact adaptive141Third137Proof77

#print axioms adaptive141Third137Proof49

theorem adaptive141Third137Proof78 : runCachedNode 511 129418 Adaptive141Third137Node78 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 129418 Adaptive141Third137Node78 = [103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 125, 126, 127, 129, 132, 133, 134] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive141Third137Proof79
  · exact adaptive141Third137Proof80
  · exact adaptive141Third137Proof81
  · exact adaptive141Third137Proof82
  · exact adaptive141Third137Proof83
  · exact adaptive141Third137Proof84
  · exact adaptive141Third137Proof85
  · exact adaptive141Third137Proof86
  · exact adaptive141Third137Proof87
  · exact adaptive141Third137Proof88
  · exact adaptive141Third137Proof89
  · exact adaptive141Third137Proof90
  · exact adaptive141Third137Proof91
  · exact adaptive141Third137Proof92
  · exact adaptive141Third137Proof93
  · exact adaptive141Third137Proof94
  · exact adaptive141Third137Proof95
  · exact adaptive141Third137Proof96
  · exact adaptive141Third137Proof97
  · exact adaptive141Third137Proof98
  · exact adaptive141Third137Proof99
  · exact adaptive141Third137Proof100
  · exact adaptive141Third137Proof101
  · exact adaptive141Third137Proof102
  · exact adaptive141Third137Proof103
  · exact adaptive141Third137Proof104
  · exact adaptive141Third137Proof105
  · exact adaptive141Third137Proof106

#print axioms adaptive141Third137Proof78

theorem adaptive141Third137Proof107 : runCachedNode 511 129418 Adaptive141Third137Node107 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 129418 Adaptive141Third137Node107 = [103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 126, 127, 128, 131, 133, 134, 135] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive141Third137Proof108
  · exact adaptive141Third137Proof109
  · exact adaptive141Third137Proof110
  · exact adaptive141Third137Proof111
  · exact adaptive141Third137Proof112
  · exact adaptive141Third137Proof113
  · exact adaptive141Third137Proof114
  · exact adaptive141Third137Proof115
  · exact adaptive141Third137Proof116
  · exact adaptive141Third137Proof117
  · exact adaptive141Third137Proof118
  · exact adaptive141Third137Proof119
  · exact adaptive141Third137Proof120
  · exact adaptive141Third137Proof121
  · exact adaptive141Third137Proof122
  · exact adaptive141Third137Proof123
  · exact adaptive141Third137Proof124
  · exact adaptive141Third137Proof125
  · exact adaptive141Third137Proof126
  · exact adaptive141Third137Proof127
  · exact adaptive141Third137Proof128
  · exact adaptive141Third137Proof129
  · exact adaptive141Third137Proof130
  · exact adaptive141Third137Proof131
  · exact adaptive141Third137Proof132
  · exact adaptive141Third137Proof133
  · exact adaptive141Third137Proof134
  · exact adaptive141Third137Proof135
  · exact adaptive141Third137Proof136

#print axioms adaptive141Third137Proof107

theorem adaptive141Third137Proof0 : runCachedNode 511 129418 Adaptive141Third137Node0 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 129418 Adaptive141Third137Node0 = [110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 131, 132, 133, 134, 135, 136] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive141Third137Proof1
  · exact adaptive141Third137Proof2
  · exact adaptive141Third137Proof3
  · exact adaptive141Third137Proof4
  · exact adaptive141Third137Proof5
  · exact adaptive141Third137Proof6
  · exact adaptive141Third137Proof7
  · exact adaptive141Third137Proof8
  · exact adaptive141Third137Proof9
  · exact adaptive141Third137Proof10
  · exact adaptive141Third137Proof11
  · exact adaptive141Third137Proof12
  · exact adaptive141Third137Proof13
  · exact adaptive141Third137Proof14
  · exact adaptive141Third137Proof15
  · exact adaptive141Third137Proof16
  · exact adaptive141Third137Proof17
  · exact adaptive141Third137Proof18
  · exact adaptive141Third137Proof19
  · exact adaptive141Third137Proof20
  · exact adaptive141Third137Proof21
  · exact adaptive141Third137Proof22
  · exact adaptive141Third137Proof23
  · exact adaptive141Third137Proof49
  · exact adaptive141Third137Proof78
  · exact adaptive141Third137Proof107

#print axioms adaptive141Third137Proof0

end NineSeparatedSubsetSums
