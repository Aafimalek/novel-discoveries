import NineSeparatedSubsetSums.Adaptive141Third137State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third137Proof19 : runCachedNode 511 129418 Adaptive141Third137Node19 = false := by
  decide +kernel

#print axioms adaptive141Third137Proof19

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third137Proof16 : runCachedNode 511 129418 Adaptive141Third137Node16 = false := by
  decide +kernel

#print axioms adaptive141Third137Proof16

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third137Proof44 : runCachedNode 511 129418 Adaptive141Third137Node44 = false := by
  decide +kernel

#print axioms adaptive141Third137Proof44

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third137Proof131 : runCachedNode 511 129418 Adaptive141Third137Node131 = false := by
  decide +kernel

#print axioms adaptive141Third137Proof131

end NineSeparatedSubsetSums
