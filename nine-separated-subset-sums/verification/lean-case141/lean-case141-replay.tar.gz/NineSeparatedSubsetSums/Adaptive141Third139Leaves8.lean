import NineSeparatedSubsetSums.Adaptive141Third139State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third139Proof227 : runCachedNode 511 129747 Adaptive141Third139Node227 = false := by
  decide +kernel

#print axioms adaptive141Third139Proof227

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third139Proof19 : runCachedNode 511 129747 Adaptive141Third139Node19 = false := by
  decide +kernel

#print axioms adaptive141Third139Proof19

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third139Proof13 : runCachedNode 511 129747 Adaptive141Third139Node13 = false := by
  decide +kernel

#print axioms adaptive141Third139Proof13

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third139Proof54 : runCachedNode 511 129747 Adaptive141Third139Node54 = false := by
  decide +kernel

#print axioms adaptive141Third139Proof54

end NineSeparatedSubsetSums
