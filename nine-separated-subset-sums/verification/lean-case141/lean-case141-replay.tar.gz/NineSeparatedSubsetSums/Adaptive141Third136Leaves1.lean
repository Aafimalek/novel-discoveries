import NineSeparatedSubsetSums.Adaptive141Third136State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third136Proof98 : runCachedNode 511 129226 Adaptive141Third136Node98 = false := by
  decide +kernel

#print axioms adaptive141Third136Proof98

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third136Proof160 : runCachedNode 511 129226 Adaptive141Third136Node160 = false := by
  decide +kernel

#print axioms adaptive141Third136Proof160

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third136Proof3 : runCachedNode 511 129226 Adaptive141Third136Node3 = false := by
  decide +kernel

#print axioms adaptive141Third136Proof3

end NineSeparatedSubsetSums
