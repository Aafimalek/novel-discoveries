import NineSeparatedSubsetSums.Adaptive141Third133State
import NineSeparatedSubsetSums.Adaptive141Third133Leaves3
import NineSeparatedSubsetSums.Adaptive141Third133Leaves1
import NineSeparatedSubsetSums.Adaptive141Third133Leaves2
import NineSeparatedSubsetSums.Adaptive141Third133Leaves4
import NineSeparatedSubsetSums.Adaptive141Third133Leaves0

namespace NineSeparatedSubsetSums

theorem adaptive141Third133Proof22 : runCachedNode 511 128708 Adaptive141Third133Node22 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 128708 Adaptive141Third133Node22 = [104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 118, 119, 120, 121, 122, 123, 127, 128, 129, 130, 131] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive141Third133Proof23
  · exact adaptive141Third133Proof24
  · exact adaptive141Third133Proof25
  · exact adaptive141Third133Proof26
  · exact adaptive141Third133Proof27
  · exact adaptive141Third133Proof28
  · exact adaptive141Third133Proof29
  · exact adaptive141Third133Proof30
  · exact adaptive141Third133Proof31
  · exact adaptive141Third133Proof32
  · exact adaptive141Third133Proof33
  · exact adaptive141Third133Proof34
  · exact adaptive141Third133Proof35
  · exact adaptive141Third133Proof36
  · exact adaptive141Third133Proof37
  · exact adaptive141Third133Proof38
  · exact adaptive141Third133Proof39
  · exact adaptive141Third133Proof40
  · exact adaptive141Third133Proof41
  · exact adaptive141Third133Proof42
  · exact adaptive141Third133Proof43
  · exact adaptive141Third133Proof44
  · exact adaptive141Third133Proof45
  · exact adaptive141Third133Proof46

#print axioms adaptive141Third133Proof22

theorem adaptive141Third133Proof0 : runCachedNode 511 128708 Adaptive141Third133Node0 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 128708 Adaptive141Third133Node0 = [110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 127, 128, 129, 130, 131, 132] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive141Third133Proof1
  · exact adaptive141Third133Proof2
  · exact adaptive141Third133Proof3
  · exact adaptive141Third133Proof4
  · exact adaptive141Third133Proof5
  · exact adaptive141Third133Proof6
  · exact adaptive141Third133Proof7
  · exact adaptive141Third133Proof8
  · exact adaptive141Third133Proof9
  · exact adaptive141Third133Proof10
  · exact adaptive141Third133Proof11
  · exact adaptive141Third133Proof12
  · exact adaptive141Third133Proof13
  · exact adaptive141Third133Proof14
  · exact adaptive141Third133Proof15
  · exact adaptive141Third133Proof16
  · exact adaptive141Third133Proof17
  · exact adaptive141Third133Proof18
  · exact adaptive141Third133Proof19
  · exact adaptive141Third133Proof20
  · exact adaptive141Third133Proof21
  · exact adaptive141Third133Proof22

#print axioms adaptive141Third133Proof0

end NineSeparatedSubsetSums
