import NineSeparatedSubsetSums.Adaptive141Third138State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third138Proof169 : runCachedNode 511 129566 Adaptive141Third138Node169 = false := by
  decide +kernel

#print axioms adaptive141Third138Proof169

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third138Proof71 : runCachedNode 511 129566 Adaptive141Third138Node71 = false := by
  decide +kernel

#print axioms adaptive141Third138Proof71

end NineSeparatedSubsetSums
