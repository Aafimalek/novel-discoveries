import NineSeparatedSubsetSums.Adaptive141Third112Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint141Checked

namespace NineSeparatedSubsetSums


theorem adaptive141Third112 : NoDescendingTailAfterThird 141 112 :=
  noDescendingThirdTail_of_cached 141 112 111653 (fun t ht nd => max148_second141_fourPoint_moment_bound (112::t) (by simp [ht]) nd) adaptive141Third112Proof0

#print axioms adaptive141Third112

end NineSeparatedSubsetSums
