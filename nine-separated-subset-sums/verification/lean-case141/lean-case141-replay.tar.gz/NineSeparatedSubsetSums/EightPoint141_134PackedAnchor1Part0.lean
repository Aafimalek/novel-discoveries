import NineSeparatedSubsetSums.EightPoint141_134PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint141_134PackedAnchor1Part0 :
    ∀ j : Fin 120, 2489290 ≤ FourPointNumeric.octPackedCharge 141 134 20 packedOct141_134_1
      (2*((j.val : Int)+0)+0) := by decide +kernel

end NineSeparatedSubsetSums
