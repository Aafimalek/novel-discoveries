import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive141Third119Node0 : CachedSearchNode :=
  ⟨4, 118, computeCenteredMask [148,141,119], 408, 55946⟩

end NineSeparatedSubsetSums
