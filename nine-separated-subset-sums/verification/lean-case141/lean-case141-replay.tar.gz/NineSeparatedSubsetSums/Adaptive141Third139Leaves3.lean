import NineSeparatedSubsetSums.Adaptive141Third139State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third139Proof101 : runCachedNode 511 129747 Adaptive141Third139Node101 = false := by
  decide +kernel

#print axioms adaptive141Third139Proof101

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third139Proof18 : runCachedNode 511 129747 Adaptive141Third139Node18 = false := by
  decide +kernel

#print axioms adaptive141Third139Proof18

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third139Proof51 : runCachedNode 511 129747 Adaptive141Third139Node51 = false := by
  decide +kernel

#print axioms adaptive141Third139Proof51

end NineSeparatedSubsetSums
