import NineSeparatedSubsetSums.Adaptive141Third132State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third132Proof20 : runCachedNode 511 128536 Adaptive141Third132Node20 = false := by
  decide +kernel

#print axioms adaptive141Third132Proof20

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third132Proof16 : runCachedNode 511 128536 Adaptive141Third132Node16 = false := by
  decide +kernel

#print axioms adaptive141Third132Proof16

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third132Proof11 : runCachedNode 511 128536 Adaptive141Third132Node11 = false := by
  decide +kernel

#print axioms adaptive141Third132Proof11

end NineSeparatedSubsetSums
