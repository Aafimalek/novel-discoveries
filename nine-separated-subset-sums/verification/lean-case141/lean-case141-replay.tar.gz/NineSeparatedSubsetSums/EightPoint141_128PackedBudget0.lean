import NineSeparatedSubsetSums.EightPoint141_128PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct141_128_0_budget :
    FourPointNumeric.packedBudget 20 packedOct141_128_0 267 = 86608236 := by decide +kernel

#print axioms packedOct141_128_0_budget

end NineSeparatedSubsetSums
