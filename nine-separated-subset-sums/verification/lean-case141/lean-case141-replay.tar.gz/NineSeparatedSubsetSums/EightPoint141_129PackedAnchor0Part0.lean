import NineSeparatedSubsetSums.EightPoint141_129PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint141_129PackedAnchor0Part0 :
    ∀ j : Fin 120, 2383970 ≤ FourPointNumeric.octPackedCharge 141 129 20 packedOct141_129_0
      (2*((j.val : Int)+0)+0) := by decide +kernel

end NineSeparatedSubsetSums
