import NineSeparatedSubsetSums.Adaptive141Third138State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third138Proof103 : runCachedNode 511 129566 Adaptive141Third138Node103 = false := by
  decide +kernel

#print axioms adaptive141Third138Proof103

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third138Proof199 : runCachedNode 511 129566 Adaptive141Third138Node199 = false := by
  decide +kernel

#print axioms adaptive141Third138Proof199

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third138Proof70 : runCachedNode 511 129566 Adaptive141Third138Node70 = false := by
  decide +kernel

#print axioms adaptive141Third138Proof70

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third138Proof122 : runCachedNode 511 129566 Adaptive141Third138Node122 = false := by
  decide +kernel

#print axioms adaptive141Third138Proof122

end NineSeparatedSubsetSums
