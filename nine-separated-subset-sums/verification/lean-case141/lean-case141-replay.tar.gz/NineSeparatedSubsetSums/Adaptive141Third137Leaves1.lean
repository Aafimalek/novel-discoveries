import NineSeparatedSubsetSums.Adaptive141Third137State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third137Proof22 : runCachedNode 511 129418 Adaptive141Third137Node22 = false := by
  decide +kernel

#print axioms adaptive141Third137Proof22

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third137Proof15 : runCachedNode 511 129418 Adaptive141Third137Node15 = false := by
  decide +kernel

#print axioms adaptive141Third137Proof15

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third137Proof24 : runCachedNode 511 129418 Adaptive141Third137Node24 = false := by
  decide +kernel

#print axioms adaptive141Third137Proof24

end NineSeparatedSubsetSums
