import NineSeparatedSubsetSums.Adaptive141Third134State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third134Proof112 : runCachedNode 511 128866 Adaptive141Third134Node112 = false := by
  decide +kernel

#print axioms adaptive141Third134Proof112

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third134Proof114 : runCachedNode 511 128866 Adaptive141Third134Node114 = false := by
  decide +kernel

#print axioms adaptive141Third134Proof114

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third134Proof62 : runCachedNode 511 128866 Adaptive141Third134Node62 = false := by
  decide +kernel

#print axioms adaptive141Third134Proof62

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third134Proof8 : runCachedNode 511 128866 Adaptive141Third134Node8 = false := by
  decide +kernel

#print axioms adaptive141Third134Proof8

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third134Proof38 : runCachedNode 511 128866 Adaptive141Third134Node38 = false := by
  decide +kernel

#print axioms adaptive141Third134Proof38

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third134Proof36 : runCachedNode 511 128866 Adaptive141Third134Node36 = false := by
  decide +kernel

#print axioms adaptive141Third134Proof36

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third134Proof86 : runCachedNode 511 128866 Adaptive141Third134Node86 = false := by
  decide +kernel

#print axioms adaptive141Third134Proof86

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third134Proof111 : runCachedNode 511 128866 Adaptive141Third134Node111 = false := by
  decide +kernel

#print axioms adaptive141Third134Proof111

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third134Proof109 : runCachedNode 511 128866 Adaptive141Third134Node109 = false := by
  decide +kernel

#print axioms adaptive141Third134Proof109

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third134Proof7 : runCachedNode 511 128866 Adaptive141Third134Node7 = false := by
  decide +kernel

#print axioms adaptive141Third134Proof7

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third134Proof85 : runCachedNode 511 128866 Adaptive141Third134Node85 = false := by
  decide +kernel

#print axioms adaptive141Third134Proof85

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third134Proof6 : runCachedNode 511 128866 Adaptive141Third134Node6 = false := by
  decide +kernel

#print axioms adaptive141Third134Proof6

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third134Proof58 : runCachedNode 511 128866 Adaptive141Third134Node58 = false := by
  decide +kernel

#print axioms adaptive141Third134Proof58

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third134Proof81 : runCachedNode 511 128866 Adaptive141Third134Node81 = false := by
  decide +kernel

#print axioms adaptive141Third134Proof81

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third134Proof82 : runCachedNode 511 128866 Adaptive141Third134Node82 = false := by
  decide +kernel

#print axioms adaptive141Third134Proof82

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third134Proof107 : runCachedNode 511 128866 Adaptive141Third134Node107 = false := by
  decide +kernel

#print axioms adaptive141Third134Proof107

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third134Proof108 : runCachedNode 511 128866 Adaptive141Third134Node108 = false := by
  decide +kernel

#print axioms adaptive141Third134Proof108

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third134Proof33 : runCachedNode 511 128866 Adaptive141Third134Node33 = false := by
  decide +kernel

#print axioms adaptive141Third134Proof33

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third134Proof56 : runCachedNode 511 128866 Adaptive141Third134Node56 = false := by
  decide +kernel

#print axioms adaptive141Third134Proof56

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third134Proof57 : runCachedNode 511 128866 Adaptive141Third134Node57 = false := by
  decide +kernel

#print axioms adaptive141Third134Proof57

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third134Proof104 : runCachedNode 511 128866 Adaptive141Third134Node104 = false := by
  decide +kernel

#print axioms adaptive141Third134Proof104

end NineSeparatedSubsetSums
