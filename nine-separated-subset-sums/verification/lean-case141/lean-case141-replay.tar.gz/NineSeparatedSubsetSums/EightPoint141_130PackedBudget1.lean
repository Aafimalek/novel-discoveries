import NineSeparatedSubsetSums.EightPoint141_130PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct141_130_1_budget :
    FourPointNumeric.packedBudget 20 packedOct141_130_1 508 = 88224786 := by decide +kernel

#print axioms packedOct141_130_1_budget

end NineSeparatedSubsetSums
