import NineSeparatedSubsetSums.EightPoint141_119PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint141_119PackedAnchor0Part2 :
    ∀ j : Fin 6, 2371098 ≤ FourPointNumeric.octPackedCharge 141 119 20 packedOct141_119_0
      (2*((j.val : Int)+240)+0) := by decide +kernel

end NineSeparatedSubsetSums
