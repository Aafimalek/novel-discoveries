import NineSeparatedSubsetSums.EightPoint141_127PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint141_127PackedAnchor0Part2 :
    ∀ j : Fin 5, 2373076 ≤ FourPointNumeric.octPackedCharge 141 127 20 packedOct141_127_0
      (2*((j.val : Int)+240)+0) := by decide +kernel

end NineSeparatedSubsetSums
