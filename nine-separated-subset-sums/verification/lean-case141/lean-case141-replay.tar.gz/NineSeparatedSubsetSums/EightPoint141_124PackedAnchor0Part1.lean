import NineSeparatedSubsetSums.EightPoint141_124PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint141_124PackedAnchor0Part1 :
    ∀ j : Fin 120, 2327927 ≤ FourPointNumeric.octPackedCharge 141 124 20 packedOct141_124_0
      (2*((j.val : Int)+120)+1) := by decide +kernel

end NineSeparatedSubsetSums
