import NineSeparatedSubsetSums.EightPoint141_117PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint141_117PackedAnchor1Part0 :
    ∀ j : Fin 120, 2357921 ≤ FourPointNumeric.octPackedCharge 141 117 20 packedOct141_117_1
      (2*((j.val : Int)+0)+1) := by decide +kernel

end NineSeparatedSubsetSums
