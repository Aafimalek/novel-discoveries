import NineSeparatedSubsetSums.EightPoint141_118PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint141_118PackedAnchor0Part0 :
    ∀ j : Fin 120, 2352582 ≤ FourPointNumeric.octPackedCharge 141 118 20 packedOct141_118_0
      (2*((j.val : Int)+0)+1) := by decide +kernel

end NineSeparatedSubsetSums
