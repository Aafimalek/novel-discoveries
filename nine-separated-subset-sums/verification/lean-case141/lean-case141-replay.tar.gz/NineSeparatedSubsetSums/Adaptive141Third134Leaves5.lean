import NineSeparatedSubsetSums.Adaptive141Third134State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third134Proof14 : runCachedNode 511 128866 Adaptive141Third134Node14 = false := by
  decide +kernel

#print axioms adaptive141Third134Proof14

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third134Proof91 : runCachedNode 511 128866 Adaptive141Third134Node91 = false := by
  decide +kernel

#print axioms adaptive141Third134Proof91

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third134Proof67 : runCachedNode 511 128866 Adaptive141Third134Node67 = false := by
  decide +kernel

#print axioms adaptive141Third134Proof67

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third134Proof42 : runCachedNode 511 128866 Adaptive141Third134Node42 = false := by
  decide +kernel

#print axioms adaptive141Third134Proof42

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third134Proof69 : runCachedNode 511 128866 Adaptive141Third134Node69 = false := by
  decide +kernel

#print axioms adaptive141Third134Proof69

end NineSeparatedSubsetSums
