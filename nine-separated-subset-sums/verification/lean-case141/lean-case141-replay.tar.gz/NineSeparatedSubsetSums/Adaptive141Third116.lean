import NineSeparatedSubsetSums.Adaptive141Third116Joins0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint141Checked

namespace NineSeparatedSubsetSums


theorem adaptive141Third116 : NoDescendingTailAfterThird 141 116 :=
  noDescendingThirdTail_of_cached 141 116 111653 (fun t ht nd => max148_second141_fourPoint_moment_bound (116::t) (by simp [ht]) nd) adaptive141Third116Proof0

#print axioms adaptive141Third116

end NineSeparatedSubsetSums
