import NineSeparatedSubsetSums.Adaptive141Third115State
import NineSeparatedSubsetSums.Adaptive141Third115Leaves0
import NineSeparatedSubsetSums.Adaptive141Third115Leaves1

namespace NineSeparatedSubsetSums

theorem adaptive141Third115Proof0 : runCachedNode 511 111653 Adaptive141Third115Node0 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 111653 Adaptive141Third115Node0 = [100, 101, 102, 103, 104, 105, 106, 107, 109, 110, 111, 112, 113, 114] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive141Third115Proof1
  · exact adaptive141Third115Proof2
  · exact adaptive141Third115Proof3
  · exact adaptive141Third115Proof4
  · exact adaptive141Third115Proof5
  · exact adaptive141Third115Proof6
  · exact adaptive141Third115Proof7
  · exact adaptive141Third115Proof8
  · exact adaptive141Third115Proof9
  · exact adaptive141Third115Proof10
  · exact adaptive141Third115Proof11
  · exact adaptive141Third115Proof12
  · exact adaptive141Third115Proof13
  · exact adaptive141Third115Proof14

#print axioms adaptive141Third115Proof0

end NineSeparatedSubsetSums
