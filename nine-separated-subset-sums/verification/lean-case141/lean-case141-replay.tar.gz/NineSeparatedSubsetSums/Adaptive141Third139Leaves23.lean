import NineSeparatedSubsetSums.Adaptive141Third139State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third139Proof163 : runCachedNode 511 129747 Adaptive141Third139Node163 = false := by
  decide +kernel

#print axioms adaptive141Third139Proof163

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third139Proof197 : runCachedNode 511 129747 Adaptive141Third139Node197 = false := by
  decide +kernel

#print axioms adaptive141Third139Proof197

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third139Proof198 : runCachedNode 511 129747 Adaptive141Third139Node198 = false := by
  decide +kernel

#print axioms adaptive141Third139Proof198

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third139Proof199 : runCachedNode 511 129747 Adaptive141Third139Node199 = false := by
  decide +kernel

#print axioms adaptive141Third139Proof199

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third139Proof200 : runCachedNode 511 129747 Adaptive141Third139Node200 = false := by
  decide +kernel

#print axioms adaptive141Third139Proof200

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third139Proof201 : runCachedNode 511 129747 Adaptive141Third139Node201 = false := by
  decide +kernel

#print axioms adaptive141Third139Proof201

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third139Proof202 : runCachedNode 511 129747 Adaptive141Third139Node202 = false := by
  decide +kernel

#print axioms adaptive141Third139Proof202

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third139Proof231 : runCachedNode 511 129747 Adaptive141Third139Node231 = false := by
  decide +kernel

#print axioms adaptive141Third139Proof231

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third139Proof47 : runCachedNode 511 129747 Adaptive141Third139Node47 = false := by
  decide +kernel

#print axioms adaptive141Third139Proof47

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third139Proof48 : runCachedNode 511 129747 Adaptive141Third139Node48 = false := by
  decide +kernel

#print axioms adaptive141Third139Proof48

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third139Proof192 : runCachedNode 511 129747 Adaptive141Third139Node192 = false := by
  decide +kernel

#print axioms adaptive141Third139Proof192

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third139Proof193 : runCachedNode 511 129747 Adaptive141Third139Node193 = false := by
  decide +kernel

#print axioms adaptive141Third139Proof193

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third139Proof194 : runCachedNode 511 129747 Adaptive141Third139Node194 = false := by
  decide +kernel

#print axioms adaptive141Third139Proof194

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third139Proof195 : runCachedNode 511 129747 Adaptive141Third139Node195 = false := by
  decide +kernel

#print axioms adaptive141Third139Proof195

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third139Proof196 : runCachedNode 511 129747 Adaptive141Third139Node196 = false := by
  decide +kernel

#print axioms adaptive141Third139Proof196

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third139Proof229 : runCachedNode 511 129747 Adaptive141Third139Node229 = false := by
  decide +kernel

#print axioms adaptive141Third139Proof229

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third139Proof230 : runCachedNode 511 129747 Adaptive141Third139Node230 = false := by
  decide +kernel

#print axioms adaptive141Third139Proof230

end NineSeparatedSubsetSums
