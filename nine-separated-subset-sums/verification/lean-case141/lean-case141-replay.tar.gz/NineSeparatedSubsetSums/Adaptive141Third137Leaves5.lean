import NineSeparatedSubsetSums.Adaptive141Third137State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third137Proof75 : runCachedNode 511 129418 Adaptive141Third137Node75 = false := by
  decide +kernel

#print axioms adaptive141Third137Proof75

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third137Proof18 : runCachedNode 511 129418 Adaptive141Third137Node18 = false := by
  decide +kernel

#print axioms adaptive141Third137Proof18

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third137Proof62 : runCachedNode 511 129418 Adaptive141Third137Node62 = false := by
  decide +kernel

#print axioms adaptive141Third137Proof62

end NineSeparatedSubsetSums
