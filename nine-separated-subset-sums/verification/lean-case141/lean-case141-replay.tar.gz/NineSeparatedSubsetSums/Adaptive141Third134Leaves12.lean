import NineSeparatedSubsetSums.Adaptive141Third134State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third134Proof98 : runCachedNode 511 128866 Adaptive141Third134Node98 = false := by
  decide +kernel

#print axioms adaptive141Third134Proof98

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third134Proof99 : runCachedNode 511 128866 Adaptive141Third134Node99 = false := by
  decide +kernel

#print axioms adaptive141Third134Proof99

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third134Proof72 : runCachedNode 511 128866 Adaptive141Third134Node72 = false := by
  decide +kernel

#print axioms adaptive141Third134Proof72

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third134Proof97 : runCachedNode 511 128866 Adaptive141Third134Node97 = false := by
  decide +kernel

#print axioms adaptive141Third134Proof97

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third134Proof71 : runCachedNode 511 128866 Adaptive141Third134Node71 = false := by
  decide +kernel

#print axioms adaptive141Third134Proof71

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third134Proof21 : runCachedNode 511 128866 Adaptive141Third134Node21 = false := by
  decide +kernel

#print axioms adaptive141Third134Proof21

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third134Proof22 : runCachedNode 511 128866 Adaptive141Third134Node22 = false := by
  decide +kernel

#print axioms adaptive141Third134Proof22

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third134Proof45 : runCachedNode 511 128866 Adaptive141Third134Node45 = false := by
  decide +kernel

#print axioms adaptive141Third134Proof45

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third134Proof46 : runCachedNode 511 128866 Adaptive141Third134Node46 = false := by
  decide +kernel

#print axioms adaptive141Third134Proof46

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third134Proof1 : runCachedNode 511 128866 Adaptive141Third134Node1 = false := by
  decide +kernel

#print axioms adaptive141Third134Proof1

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third134Proof44 : runCachedNode 511 128866 Adaptive141Third134Node44 = false := by
  decide +kernel

#print axioms adaptive141Third134Proof44

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third134Proof70 : runCachedNode 511 128866 Adaptive141Third134Node70 = false := by
  decide +kernel

#print axioms adaptive141Third134Proof70

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third134Proof96 : runCachedNode 511 128866 Adaptive141Third134Node96 = false := by
  decide +kernel

#print axioms adaptive141Third134Proof96

end NineSeparatedSubsetSums
