import NineSeparatedSubsetSums.Adaptive141Third104Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint141Checked

namespace NineSeparatedSubsetSums


theorem adaptive141Third104 : NoDescendingTailAfterThird 141 104 :=
  noDescendingThirdTail_of_cached 141 104 111653 (fun t ht nd => max148_second141_fourPoint_moment_bound (104::t) (by simp [ht]) nd) adaptive141Third104Proof0

#print axioms adaptive141Third104

end NineSeparatedSubsetSums
