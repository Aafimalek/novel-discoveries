import NineSeparatedSubsetSums.Adaptive141Third136State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third136Proof16 : runCachedNode 511 129226 Adaptive141Third136Node16 = false := by
  decide +kernel

#print axioms adaptive141Third136Proof16

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third136Proof44 : runCachedNode 511 129226 Adaptive141Third136Node44 = false := by
  decide +kernel

#print axioms adaptive141Third136Proof44

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third136Proof97 : runCachedNode 511 129226 Adaptive141Third136Node97 = false := by
  decide +kernel

#print axioms adaptive141Third136Proof97

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third136Proof128 : runCachedNode 511 129226 Adaptive141Third136Node128 = false := by
  decide +kernel

#print axioms adaptive141Third136Proof128

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third136Proof67 : runCachedNode 511 129226 Adaptive141Third136Node67 = false := by
  decide +kernel

#print axioms adaptive141Third136Proof67

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third136Proof108 : runCachedNode 511 129226 Adaptive141Third136Node108 = false := by
  decide +kernel

#print axioms adaptive141Third136Proof108

end NineSeparatedSubsetSums
