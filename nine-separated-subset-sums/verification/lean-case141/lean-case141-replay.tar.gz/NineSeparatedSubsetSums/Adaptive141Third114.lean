import NineSeparatedSubsetSums.Adaptive141Third114Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint141Checked

namespace NineSeparatedSubsetSums


theorem adaptive141Third114 : NoDescendingTailAfterThird 141 114 :=
  noDescendingThirdTail_of_cached 141 114 111653 (fun t ht nd => max148_second141_fourPoint_moment_bound (114::t) (by simp [ht]) nd) adaptive141Third114Proof0

#print axioms adaptive141Third114

end NineSeparatedSubsetSums
