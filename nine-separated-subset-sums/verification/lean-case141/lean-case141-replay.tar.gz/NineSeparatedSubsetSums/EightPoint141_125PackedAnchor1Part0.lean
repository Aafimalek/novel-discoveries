import NineSeparatedSubsetSums.EightPoint141_125PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint141_125PackedAnchor1Part0 :
    ∀ j : Fin 120, 2359824 ≤ FourPointNumeric.octPackedCharge 141 125 20 packedOct141_125_1
      (2*((j.val : Int)+0)+1) := by decide +kernel

end NineSeparatedSubsetSums
