import NineSeparatedSubsetSums.Adaptive141Third133State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third133Proof19 : runCachedNode 511 128708 Adaptive141Third133Node19 = false := by
  decide +kernel

#print axioms adaptive141Third133Proof19

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third133Proof46 : runCachedNode 511 128708 Adaptive141Third133Node46 = false := by
  decide +kernel

#print axioms adaptive141Third133Proof46

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third133Proof14 : runCachedNode 511 128708 Adaptive141Third133Node14 = false := by
  decide +kernel

#print axioms adaptive141Third133Proof14

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third133Proof6 : runCachedNode 511 128708 Adaptive141Third133Node6 = false := by
  decide +kernel

#print axioms adaptive141Third133Proof6

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third133Proof25 : runCachedNode 511 128708 Adaptive141Third133Node25 = false := by
  decide +kernel

#print axioms adaptive141Third133Proof25

end NineSeparatedSubsetSums
