import NineSeparatedSubsetSums.EightPointPackedGeometry
import NineSeparatedSubsetSums.EightPoint141_135PackedBudget0
import NineSeparatedSubsetSums.EightPoint141_135PackedAnchor0Part0
import NineSeparatedSubsetSums.EightPoint141_135PackedAnchor0Part1
import NineSeparatedSubsetSums.EightPoint141_135PackedAnchor0Part2
import NineSeparatedSubsetSums.EightPoint141_135PackedBudget1
import NineSeparatedSubsetSums.EightPoint141_135PackedAnchor1Part0
import NineSeparatedSubsetSums.EightPoint141_135PackedAnchor1Part1
import NineSeparatedSubsetSums.EightPoint141_135PackedAnchor1Part2

namespace NineSeparatedSubsetSums

private theorem packedOct141_135Anchor0 :
  ∀ j : Fin 499, ((j.val : Int)+141+135)%2=0 →
    2472049 ≤ FourPointNumeric.octPackedCharge 141 135 20 packedOct141_135_0 (j.val : Int) := by
  intro j hj
  let k := (j.val-0)/2
  have hk : k < 250 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+0 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint141_135PackedAnchor0Part0 z
    rwa [he,hrep] at ht
  by_cases h1 : k < 240
  · let z : Fin 120 := ⟨k-120, by omega⟩
    have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
    have ht := eightPoint141_135PackedAnchor0Part1 z
    rwa [he,hrep] at ht
  let z : Fin 10 := ⟨k-240, by omega⟩
  have he : (z.val : Int)+240 = k := by dsimp [z] <;> omega
  have ht := eightPoint141_135PackedAnchor0Part2 z
  rwa [he,hrep] at ht

private theorem packedOct141_135Anchor1 :
  ∀ j : Fin 499, ((j.val : Int)+141+135)%2=1 →
    2472017 ≤ FourPointNumeric.octPackedCharge 141 135 20 packedOct141_135_1 (j.val : Int) := by
  intro j hj
  let k := (j.val-1)/2
  have hk : k < 249 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+1 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint141_135PackedAnchor1Part0 z
    rwa [he,hrep] at ht
  by_cases h1 : k < 240
  · let z : Fin 120 := ⟨k-120, by omega⟩
    have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
    have ht := eightPoint141_135PackedAnchor1Part1 z
    rwa [he,hrep] at ht
  let z : Fin 9 := ⟨k-240, by omega⟩
  have he : (z.val : Int)+240 = k := by dsimp [z] <;> omega
  have ht := eightPoint141_135PackedAnchor1Part2 z
  rwa [he,hrep] at ht

def packedOctCertificate141_135_0 : EightPointCertificate 141 135 0 129079 :=
  eightPointCertificateOfPacked 141 135 0 129079 2472049 20 packedOct141_135_0 471 499
    (by decide +kernel) (by decide) packedOct141_135Anchor0
    (by rw [packedOct141_135_0_budget]; decide)

def packedOctCertificate141_135_1 : EightPointCertificate 141 135 1 129079 :=
  eightPointCertificateOfPacked 141 135 1 129079 2472017 20 packedOct141_135_1 470 499
    (by decide +kernel) (by decide) packedOct141_135Anchor1
    (by rw [packedOct141_135_1_budget]; decide)

theorem max148_second141_third135_eightPoint_moment_bound (tail : List ℕ) (len : tail.length=6)
    (distinct : (natSubsetSums (148::141::135::tail)).Nodup) :
    129079 ≤ ((148::141::135::tail).map (· ^ 2)).sum := by
  apply eightPointNatMomentLower 141 135 129079 tail len distinct
  intro p hp
  by_cases h : p=0
  · subst p
    exact packedOctCertificate141_135_0
  · have he : p=1 := hp.resolve_left h
    subst p
    exact packedOctCertificate141_135_1

#print axioms max148_second141_third135_eightPoint_moment_bound

end NineSeparatedSubsetSums
