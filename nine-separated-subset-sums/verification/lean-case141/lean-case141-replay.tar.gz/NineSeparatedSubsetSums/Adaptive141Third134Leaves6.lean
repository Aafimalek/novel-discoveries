import NineSeparatedSubsetSums.Adaptive141Third134State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third134Proof65 : runCachedNode 511 128866 Adaptive141Third134Node65 = false := by
  decide +kernel

#print axioms adaptive141Third134Proof65

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third134Proof115 : runCachedNode 511 128866 Adaptive141Third134Node115 = false := by
  decide +kernel

#print axioms adaptive141Third134Proof115

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third134Proof13 : runCachedNode 511 128866 Adaptive141Third134Node13 = false := by
  decide +kernel

#print axioms adaptive141Third134Proof13

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third134Proof40 : runCachedNode 511 128866 Adaptive141Third134Node40 = false := by
  decide +kernel

#print axioms adaptive141Third134Proof40

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third134Proof74 : runCachedNode 511 128866 Adaptive141Third134Node74 = false := by
  decide +kernel

#print axioms adaptive141Third134Proof74

end NineSeparatedSubsetSums
