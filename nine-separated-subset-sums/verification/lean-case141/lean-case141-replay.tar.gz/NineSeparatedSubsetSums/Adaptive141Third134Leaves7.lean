import NineSeparatedSubsetSums.Adaptive141Third134State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third134Proof93 : runCachedNode 511 128866 Adaptive141Third134Node93 = false := by
  decide +kernel

#print axioms adaptive141Third134Proof93

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third134Proof116 : runCachedNode 511 128866 Adaptive141Third134Node116 = false := by
  decide +kernel

#print axioms adaptive141Third134Proof116

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third134Proof11 : runCachedNode 511 128866 Adaptive141Third134Node11 = false := by
  decide +kernel

#print axioms adaptive141Third134Proof11

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third134Proof12 : runCachedNode 511 128866 Adaptive141Third134Node12 = false := by
  decide +kernel

#print axioms adaptive141Third134Proof12

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third134Proof113 : runCachedNode 511 128866 Adaptive141Third134Node113 = false := by
  decide +kernel

#print axioms adaptive141Third134Proof113

end NineSeparatedSubsetSums
