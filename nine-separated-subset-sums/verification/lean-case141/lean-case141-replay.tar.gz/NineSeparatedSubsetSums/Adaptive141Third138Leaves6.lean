import NineSeparatedSubsetSums.Adaptive141Third138State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third138Proof20 : runCachedNode 511 129566 Adaptive141Third138Node20 = false := by
  decide +kernel

#print axioms adaptive141Third138Proof20

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third138Proof76 : runCachedNode 511 129566 Adaptive141Third138Node76 = false := by
  decide +kernel

#print axioms adaptive141Third138Proof76

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third138Proof194 : runCachedNode 511 129566 Adaptive141Third138Node194 = false := by
  decide +kernel

#print axioms adaptive141Third138Proof194

end NineSeparatedSubsetSums
