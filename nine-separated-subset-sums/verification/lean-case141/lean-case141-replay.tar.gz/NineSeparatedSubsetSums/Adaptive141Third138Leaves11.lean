import NineSeparatedSubsetSums.Adaptive141Third138State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third138Proof74 : runCachedNode 511 129566 Adaptive141Third138Node74 = false := by
  decide +kernel

#print axioms adaptive141Third138Proof74

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third138Proof165 : runCachedNode 511 129566 Adaptive141Third138Node165 = false := by
  decide +kernel

#print axioms adaptive141Third138Proof165

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third138Proof17 : runCachedNode 511 129566 Adaptive141Third138Node17 = false := by
  decide +kernel

#print axioms adaptive141Third138Proof17

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third138Proof44 : runCachedNode 511 129566 Adaptive141Third138Node44 = false := by
  decide +kernel

#print axioms adaptive141Third138Proof44

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third138Proof84 : runCachedNode 511 129566 Adaptive141Third138Node84 = false := by
  decide +kernel

#print axioms adaptive141Third138Proof84

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third138Proof24 : runCachedNode 511 129566 Adaptive141Third138Node24 = false := by
  decide +kernel

#print axioms adaptive141Third138Proof24

end NineSeparatedSubsetSums
