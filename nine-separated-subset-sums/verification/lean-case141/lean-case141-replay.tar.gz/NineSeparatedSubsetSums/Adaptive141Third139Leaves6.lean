import NineSeparatedSubsetSums.Adaptive141Third139State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third139Proof99 : runCachedNode 511 129747 Adaptive141Third139Node99 = false := by
  decide +kernel

#print axioms adaptive141Third139Proof99

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third139Proof100 : runCachedNode 511 129747 Adaptive141Third139Node100 = false := by
  decide +kernel

#print axioms adaptive141Third139Proof100

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third139Proof149 : runCachedNode 511 129747 Adaptive141Third139Node149 = false := by
  decide +kernel

#print axioms adaptive141Third139Proof149

end NineSeparatedSubsetSums
