import NineSeparatedSubsetSums.EightPointPackedGeometry
import NineSeparatedSubsetSums.EightPoint141_127PackedBudget0
import NineSeparatedSubsetSums.EightPoint141_127PackedAnchor0Part0
import NineSeparatedSubsetSums.EightPoint141_127PackedAnchor0Part1
import NineSeparatedSubsetSums.EightPoint141_127PackedAnchor0Part2
import NineSeparatedSubsetSums.EightPoint141_127PackedBudget1
import NineSeparatedSubsetSums.EightPoint141_127PackedAnchor1Part0
import NineSeparatedSubsetSums.EightPoint141_127PackedAnchor1Part1
import NineSeparatedSubsetSums.EightPoint141_127PackedAnchor1Part2

namespace NineSeparatedSubsetSums

private theorem packedOct141_127Anchor0 :
  ∀ j : Fin 489, ((j.val : Int)+141+127)%2=0 →
    2373076 ≤ FourPointNumeric.octPackedCharge 141 127 20 packedOct141_127_0 (j.val : Int) := by
  intro j hj
  let k := (j.val-0)/2
  have hk : k < 245 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+0 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint141_127PackedAnchor0Part0 z
    rwa [he,hrep] at ht
  by_cases h1 : k < 240
  · let z : Fin 120 := ⟨k-120, by omega⟩
    have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
    have ht := eightPoint141_127PackedAnchor0Part1 z
    rwa [he,hrep] at ht
  let z : Fin 5 := ⟨k-240, by omega⟩
  have he : (z.val : Int)+240 = k := by dsimp [z] <;> omega
  have ht := eightPoint141_127PackedAnchor0Part2 z
  rwa [he,hrep] at ht

private theorem packedOct141_127Anchor1 :
  ∀ j : Fin 489, ((j.val : Int)+141+127)%2=1 →
    2372246 ≤ FourPointNumeric.octPackedCharge 141 127 20 packedOct141_127_1 (j.val : Int) := by
  intro j hj
  let k := (j.val-1)/2
  have hk : k < 244 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+1 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint141_127PackedAnchor1Part0 z
    rwa [he,hrep] at ht
  by_cases h1 : k < 240
  · let z : Fin 120 := ⟨k-120, by omega⟩
    have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
    have ht := eightPoint141_127PackedAnchor1Part1 z
    rwa [he,hrep] at ht
  let z : Fin 4 := ⟨k-240, by omega⟩
  have he : (z.val : Int)+240 = k := by dsimp [z] <;> omega
  have ht := eightPoint141_127PackedAnchor1Part2 z
  rwa [he,hrep] at ht

def packedOctCertificate141_127_0 : EightPointCertificate 141 127 0 127543 :=
  eightPointCertificateOfPacked 141 127 0 127543 2373076 20 packedOct141_127_0 435 489
    (by decide +kernel) (by decide) packedOct141_127Anchor0
    (by rw [packedOct141_127_0_budget]; decide)

def packedOctCertificate141_127_1 : EightPointCertificate 141 127 1 127543 :=
  eightPointCertificateOfPacked 141 127 1 127543 2372246 20 packedOct141_127_1 434 489
    (by decide +kernel) (by decide) packedOct141_127Anchor1
    (by rw [packedOct141_127_1_budget]; decide)

theorem max148_second141_third127_eightPoint_moment_bound (tail : List ℕ) (len : tail.length=6)
    (distinct : (natSubsetSums (148::141::127::tail)).Nodup) :
    127543 ≤ ((148::141::127::tail).map (· ^ 2)).sum := by
  apply eightPointNatMomentLower 141 127 127543 tail len distinct
  intro p hp
  by_cases h : p=0
  · subst p
    exact packedOctCertificate141_127_0
  · have he : p=1 := hp.resolve_left h
    subst p
    exact packedOctCertificate141_127_1

#print axioms max148_second141_third127_eightPoint_moment_bound

end NineSeparatedSubsetSums
