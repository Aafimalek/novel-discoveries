import NineSeparatedSubsetSums.Adaptive141Third135State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third135Proof52 : runCachedNode 511 129079 Adaptive141Third135Node52 = false := by
  decide +kernel

#print axioms adaptive141Third135Proof52

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third135Proof26 : runCachedNode 511 129079 Adaptive141Third135Node26 = false := by
  decide +kernel

#print axioms adaptive141Third135Proof26

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third135Proof27 : runCachedNode 511 129079 Adaptive141Third135Node27 = false := by
  decide +kernel

#print axioms adaptive141Third135Proof27

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third135Proof28 : runCachedNode 511 129079 Adaptive141Third135Node28 = false := by
  decide +kernel

#print axioms adaptive141Third135Proof28

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third135Proof49 : runCachedNode 511 129079 Adaptive141Third135Node49 = false := by
  decide +kernel

#print axioms adaptive141Third135Proof49

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third135Proof25 : runCachedNode 511 129079 Adaptive141Third135Node25 = false := by
  decide +kernel

#print axioms adaptive141Third135Proof25

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third135Proof75 : runCachedNode 511 129079 Adaptive141Third135Node75 = false := by
  decide +kernel

#print axioms adaptive141Third135Proof75

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third135Proof23 : runCachedNode 511 129079 Adaptive141Third135Node23 = false := by
  decide +kernel

#print axioms adaptive141Third135Proof23

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third135Proof48 : runCachedNode 511 129079 Adaptive141Third135Node48 = false := by
  decide +kernel

#print axioms adaptive141Third135Proof48

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third135Proof74 : runCachedNode 511 129079 Adaptive141Third135Node74 = false := by
  decide +kernel

#print axioms adaptive141Third135Proof74

end NineSeparatedSubsetSums
