import NineSeparatedSubsetSums.Adaptive141Third139State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third139Proof183 : runCachedNode 511 129747 Adaptive141Third139Node183 = false := by
  decide +kernel

#print axioms adaptive141Third139Proof183

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third139Proof224 : runCachedNode 511 129747 Adaptive141Third139Node224 = false := by
  decide +kernel

#print axioms adaptive141Third139Proof224

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third139Proof157 : runCachedNode 511 129747 Adaptive141Third139Node157 = false := by
  decide +kernel

#print axioms adaptive141Third139Proof157

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third139Proof68 : runCachedNode 511 129747 Adaptive141Third139Node68 = false := by
  decide +kernel

#print axioms adaptive141Third139Proof68

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third139Proof95 : runCachedNode 511 129747 Adaptive141Third139Node95 = false := by
  decide +kernel

#print axioms adaptive141Third139Proof95

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third139Proof43 : runCachedNode 511 129747 Adaptive141Third139Node43 = false := by
  decide +kernel

#print axioms adaptive141Third139Proof43

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third139Proof71 : runCachedNode 511 129747 Adaptive141Third139Node71 = false := by
  decide +kernel

#print axioms adaptive141Third139Proof71

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third139Proof182 : runCachedNode 511 129747 Adaptive141Third139Node182 = false := by
  decide +kernel

#print axioms adaptive141Third139Proof182

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third139Proof108 : runCachedNode 511 129747 Adaptive141Third139Node108 = false := by
  decide +kernel

#print axioms adaptive141Third139Proof108

end NineSeparatedSubsetSums
