import NineSeparatedSubsetSums.Adaptive141Third140State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third140Proof130 : runCachedNode 511 129930 Adaptive141Third140Node130 = false := by
  decide +kernel

#print axioms adaptive141Third140Proof130

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third140Proof42 : runCachedNode 511 129930 Adaptive141Third140Node42 = false := by
  decide +kernel

#print axioms adaptive141Third140Proof42

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third140Proof129 : runCachedNode 511 129930 Adaptive141Third140Node129 = false := by
  decide +kernel

#print axioms adaptive141Third140Proof129

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third140Proof270 : runCachedNode 511 129930 Adaptive141Third140Node270 = false := by
  decide +kernel

#print axioms adaptive141Third140Proof270

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third140Proof194 : runCachedNode 511 129930 Adaptive141Third140Node194 = false := by
  decide +kernel

#print axioms adaptive141Third140Proof194

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third140Proof11 : runCachedNode 511 129930 Adaptive141Third140Node11 = false := by
  decide +kernel

#print axioms adaptive141Third140Proof11

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third140Proof131 : runCachedNode 511 129930 Adaptive141Third140Node131 = false := by
  decide +kernel

#print axioms adaptive141Third140Proof131

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third140Proof195 : runCachedNode 511 129930 Adaptive141Third140Node195 = false := by
  decide +kernel

#print axioms adaptive141Third140Proof195

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third140Proof222 : runCachedNode 511 129930 Adaptive141Third140Node222 = false := by
  decide +kernel

#print axioms adaptive141Third140Proof222

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third140Proof159 : runCachedNode 511 129930 Adaptive141Third140Node159 = false := by
  decide +kernel

#print axioms adaptive141Third140Proof159

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third140Proof40 : runCachedNode 511 129930 Adaptive141Third140Node40 = false := by
  decide +kernel

#print axioms adaptive141Third140Proof40

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third140Proof95 : runCachedNode 511 129930 Adaptive141Third140Node95 = false := by
  decide +kernel

#print axioms adaptive141Third140Proof95

end NineSeparatedSubsetSums
