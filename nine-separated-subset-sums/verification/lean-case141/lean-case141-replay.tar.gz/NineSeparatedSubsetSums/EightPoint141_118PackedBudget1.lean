import NineSeparatedSubsetSums.EightPoint141_118PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct141_118_1_budget :
    FourPointNumeric.packedBudget 20 packedOct141_118_1 272 = 86299116 := by decide +kernel

#print axioms packedOct141_118_1_budget

end NineSeparatedSubsetSums
