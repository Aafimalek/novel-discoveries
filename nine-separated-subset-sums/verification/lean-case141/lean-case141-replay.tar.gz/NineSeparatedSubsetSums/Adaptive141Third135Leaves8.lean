import NineSeparatedSubsetSums.Adaptive141Third135State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third135Proof68 : runCachedNode 511 129079 Adaptive141Third135Node68 = false := by
  decide +kernel

#print axioms adaptive141Third135Proof68

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third135Proof90 : runCachedNode 511 129079 Adaptive141Third135Node90 = false := by
  decide +kernel

#print axioms adaptive141Third135Proof90

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third135Proof65 : runCachedNode 511 129079 Adaptive141Third135Node65 = false := by
  decide +kernel

#print axioms adaptive141Third135Proof65

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third135Proof40 : runCachedNode 511 129079 Adaptive141Third135Node40 = false := by
  decide +kernel

#print axioms adaptive141Third135Proof40

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third135Proof92 : runCachedNode 511 129079 Adaptive141Third135Node92 = false := by
  decide +kernel

#print axioms adaptive141Third135Proof92

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third135Proof67 : runCachedNode 511 129079 Adaptive141Third135Node67 = false := by
  decide +kernel

#print axioms adaptive141Third135Proof67

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third135Proof10 : runCachedNode 511 129079 Adaptive141Third135Node10 = false := by
  decide +kernel

#print axioms adaptive141Third135Proof10

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third135Proof89 : runCachedNode 511 129079 Adaptive141Third135Node89 = false := by
  decide +kernel

#print axioms adaptive141Third135Proof89

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third135Proof9 : runCachedNode 511 129079 Adaptive141Third135Node9 = false := by
  decide +kernel

#print axioms adaptive141Third135Proof9

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third135Proof66 : runCachedNode 511 129079 Adaptive141Third135Node66 = false := by
  decide +kernel

#print axioms adaptive141Third135Proof66

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third135Proof42 : runCachedNode 511 129079 Adaptive141Third135Node42 = false := by
  decide +kernel

#print axioms adaptive141Third135Proof42

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third135Proof88 : runCachedNode 511 129079 Adaptive141Third135Node88 = false := by
  decide +kernel

#print axioms adaptive141Third135Proof88

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third135Proof43 : runCachedNode 511 129079 Adaptive141Third135Node43 = false := by
  decide +kernel

#print axioms adaptive141Third135Proof43

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third135Proof63 : runCachedNode 511 129079 Adaptive141Third135Node63 = false := by
  decide +kernel

#print axioms adaptive141Third135Proof63

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third135Proof64 : runCachedNode 511 129079 Adaptive141Third135Node64 = false := by
  decide +kernel

#print axioms adaptive141Third135Proof64

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third135Proof8 : runCachedNode 511 129079 Adaptive141Third135Node8 = false := by
  decide +kernel

#print axioms adaptive141Third135Proof8

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third135Proof62 : runCachedNode 511 129079 Adaptive141Third135Node62 = false := by
  decide +kernel

#print axioms adaptive141Third135Proof62

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third135Proof85 : runCachedNode 511 129079 Adaptive141Third135Node85 = false := by
  decide +kernel

#print axioms adaptive141Third135Proof85

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third135Proof86 : runCachedNode 511 129079 Adaptive141Third135Node86 = false := by
  decide +kernel

#print axioms adaptive141Third135Proof86

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third135Proof37 : runCachedNode 511 129079 Adaptive141Third135Node37 = false := by
  decide +kernel

#print axioms adaptive141Third135Proof37

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third135Proof1 : runCachedNode 511 129079 Adaptive141Third135Node1 = false := by
  decide +kernel

#print axioms adaptive141Third135Proof1

end NineSeparatedSubsetSums
