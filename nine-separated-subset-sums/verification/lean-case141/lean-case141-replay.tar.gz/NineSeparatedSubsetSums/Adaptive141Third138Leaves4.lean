import NineSeparatedSubsetSums.Adaptive141Third138State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third138Proof19 : runCachedNode 511 129566 Adaptive141Third138Node19 = false := by
  decide +kernel

#print axioms adaptive141Third138Proof19

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third138Proof15 : runCachedNode 511 129566 Adaptive141Third138Node15 = false := by
  decide +kernel

#print axioms adaptive141Third138Proof15

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third138Proof30 : runCachedNode 511 129566 Adaptive141Third138Node30 = false := by
  decide +kernel

#print axioms adaptive141Third138Proof30

end NineSeparatedSubsetSums
