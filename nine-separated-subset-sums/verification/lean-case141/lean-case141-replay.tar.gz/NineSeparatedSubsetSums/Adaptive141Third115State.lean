import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive141Third115Node0 : CachedSearchNode :=
  ⟨4, 114, computeCenteredMask [148,141,115], 404, 55010⟩
def Adaptive141Third115Node1 : CachedSearchNode := cachedChild Adaptive141Third115Node0 100
def Adaptive141Third115Node2 : CachedSearchNode := cachedChild Adaptive141Third115Node0 101
def Adaptive141Third115Node3 : CachedSearchNode := cachedChild Adaptive141Third115Node0 102
def Adaptive141Third115Node4 : CachedSearchNode := cachedChild Adaptive141Third115Node0 103
def Adaptive141Third115Node5 : CachedSearchNode := cachedChild Adaptive141Third115Node0 104
def Adaptive141Third115Node6 : CachedSearchNode := cachedChild Adaptive141Third115Node0 105
def Adaptive141Third115Node7 : CachedSearchNode := cachedChild Adaptive141Third115Node0 106
def Adaptive141Third115Node8 : CachedSearchNode := cachedChild Adaptive141Third115Node0 107
def Adaptive141Third115Node9 : CachedSearchNode := cachedChild Adaptive141Third115Node0 109
def Adaptive141Third115Node10 : CachedSearchNode := cachedChild Adaptive141Third115Node0 110
def Adaptive141Third115Node11 : CachedSearchNode := cachedChild Adaptive141Third115Node0 111
def Adaptive141Third115Node12 : CachedSearchNode := cachedChild Adaptive141Third115Node0 112
def Adaptive141Third115Node13 : CachedSearchNode := cachedChild Adaptive141Third115Node0 113
def Adaptive141Third115Node14 : CachedSearchNode := cachedChild Adaptive141Third115Node0 114

end NineSeparatedSubsetSums
