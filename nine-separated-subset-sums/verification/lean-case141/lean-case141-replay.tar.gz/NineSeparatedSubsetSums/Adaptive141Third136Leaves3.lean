import NineSeparatedSubsetSums.Adaptive141Third136State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third136Proof20 : runCachedNode 511 129226 Adaptive141Third136Node20 = false := by
  decide +kernel

#print axioms adaptive141Third136Proof20

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third136Proof100 : runCachedNode 511 129226 Adaptive141Third136Node100 = false := by
  decide +kernel

#print axioms adaptive141Third136Proof100

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third136Proof23 : runCachedNode 511 129226 Adaptive141Third136Node23 = false := by
  decide +kernel

#print axioms adaptive141Third136Proof23

end NineSeparatedSubsetSums
