import NineSeparatedSubsetSums.Adaptive141Third139State
import NineSeparatedSubsetSums.Adaptive141Third139Leaves22
import NineSeparatedSubsetSums.Adaptive141Third139Leaves21
import NineSeparatedSubsetSums.Adaptive141Third139Leaves20
import NineSeparatedSubsetSums.Adaptive141Third139Leaves19
import NineSeparatedSubsetSums.Adaptive141Third139Leaves2
import NineSeparatedSubsetSums.Adaptive141Third139Leaves13
import NineSeparatedSubsetSums.Adaptive141Third139Leaves17
import NineSeparatedSubsetSums.Adaptive141Third139Leaves18
import NineSeparatedSubsetSums.Adaptive141Third139Leaves14
import NineSeparatedSubsetSums.Adaptive141Third139Leaves15
import NineSeparatedSubsetSums.Adaptive141Third139Leaves9
import NineSeparatedSubsetSums.Adaptive141Third139Leaves23
import NineSeparatedSubsetSums.Adaptive141Third139Leaves3
import NineSeparatedSubsetSums.Adaptive141Third139Leaves0
import NineSeparatedSubsetSums.Adaptive141Third139Leaves8
import NineSeparatedSubsetSums.Adaptive141Third139Leaves4
import NineSeparatedSubsetSums.Adaptive141Third139Leaves12
import NineSeparatedSubsetSums.Adaptive141Third139Leaves16
import NineSeparatedSubsetSums.Adaptive141Third139Leaves11
import NineSeparatedSubsetSums.Adaptive141Third139Leaves7
import NineSeparatedSubsetSums.Adaptive141Third139Leaves6
import NineSeparatedSubsetSums.Adaptive141Third139Leaves5
import NineSeparatedSubsetSums.Adaptive141Third139Leaves10
import NineSeparatedSubsetSums.Adaptive141Third139Leaves1

namespace NineSeparatedSubsetSums

theorem adaptive141Third139Proof21 : runCachedNode 511 129747 Adaptive141Third139Node21 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 129747 Adaptive141Third139Node21 = [104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 122, 124, 125, 126, 127, 129] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive141Third139Proof22
  · exact adaptive141Third139Proof23
  · exact adaptive141Third139Proof24
  · exact adaptive141Third139Proof25
  · exact adaptive141Third139Proof26
  · exact adaptive141Third139Proof27
  · exact adaptive141Third139Proof28
  · exact adaptive141Third139Proof29
  · exact adaptive141Third139Proof30
  · exact adaptive141Third139Proof31
  · exact adaptive141Third139Proof32
  · exact adaptive141Third139Proof33
  · exact adaptive141Third139Proof34
  · exact adaptive141Third139Proof35
  · exact adaptive141Third139Proof36
  · exact adaptive141Third139Proof37
  · exact adaptive141Third139Proof38
  · exact adaptive141Third139Proof39
  · exact adaptive141Third139Proof40
  · exact adaptive141Third139Proof41
  · exact adaptive141Third139Proof42
  · exact adaptive141Third139Proof43
  · exact adaptive141Third139Proof44

#print axioms adaptive141Third139Proof21

theorem adaptive141Third139Proof46 : runCachedNode 511 129747 Adaptive141Third139Node46 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 129747 Adaptive141Third139Node46 = [103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 125, 127, 128, 129, 130] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive141Third139Proof47
  · exact adaptive141Third139Proof48
  · exact adaptive141Third139Proof49
  · exact adaptive141Third139Proof50
  · exact adaptive141Third139Proof51
  · exact adaptive141Third139Proof52
  · exact adaptive141Third139Proof53
  · exact adaptive141Third139Proof54
  · exact adaptive141Third139Proof55
  · exact adaptive141Third139Proof56
  · exact adaptive141Third139Proof57
  · exact adaptive141Third139Proof58
  · exact adaptive141Third139Proof59
  · exact adaptive141Third139Proof60
  · exact adaptive141Third139Proof61
  · exact adaptive141Third139Proof62
  · exact adaptive141Third139Proof63
  · exact adaptive141Third139Proof64
  · exact adaptive141Third139Proof65
  · exact adaptive141Third139Proof66
  · exact adaptive141Third139Proof67
  · exact adaptive141Third139Proof68
  · exact adaptive141Third139Proof69
  · exact adaptive141Third139Proof70
  · exact adaptive141Third139Proof71
  · exact adaptive141Third139Proof72

#print axioms adaptive141Third139Proof46

theorem adaptive141Third139Proof73 : runCachedNode 511 129747 Adaptive141Third139Node73 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 129747 Adaptive141Third139Node73 = [103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 126, 128, 129, 130, 131, 133] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive141Third139Proof74
  · exact adaptive141Third139Proof75
  · exact adaptive141Third139Proof76
  · exact adaptive141Third139Proof77
  · exact adaptive141Third139Proof78
  · exact adaptive141Third139Proof79
  · exact adaptive141Third139Proof80
  · exact adaptive141Third139Proof81
  · exact adaptive141Third139Proof82
  · exact adaptive141Third139Proof83
  · exact adaptive141Third139Proof84
  · exact adaptive141Third139Proof85
  · exact adaptive141Third139Proof86
  · exact adaptive141Third139Proof87
  · exact adaptive141Third139Proof88
  · exact adaptive141Third139Proof89
  · exact adaptive141Third139Proof90
  · exact adaptive141Third139Proof91
  · exact adaptive141Third139Proof92
  · exact adaptive141Third139Proof93
  · exact adaptive141Third139Proof94
  · exact adaptive141Third139Proof95
  · exact adaptive141Third139Proof96
  · exact adaptive141Third139Proof97
  · exact adaptive141Third139Proof98
  · exact adaptive141Third139Proof99
  · exact adaptive141Third139Proof100
  · exact adaptive141Third139Proof101

#print axioms adaptive141Third139Proof73

theorem adaptive141Third139Proof102 : runCachedNode 511 129747 Adaptive141Third139Node102 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 129747 Adaptive141Third139Node102 = [103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 127, 129, 130, 131, 134] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive141Third139Proof103
  · exact adaptive141Third139Proof104
  · exact adaptive141Third139Proof105
  · exact adaptive141Third139Proof106
  · exact adaptive141Third139Proof107
  · exact adaptive141Third139Proof108
  · exact adaptive141Third139Proof109
  · exact adaptive141Third139Proof110
  · exact adaptive141Third139Proof111
  · exact adaptive141Third139Proof112
  · exact adaptive141Third139Proof113
  · exact adaptive141Third139Proof114
  · exact adaptive141Third139Proof115
  · exact adaptive141Third139Proof116
  · exact adaptive141Third139Proof117
  · exact adaptive141Third139Proof118
  · exact adaptive141Third139Proof119
  · exact adaptive141Third139Proof120
  · exact adaptive141Third139Proof121
  · exact adaptive141Third139Proof122
  · exact adaptive141Third139Proof123
  · exact adaptive141Third139Proof124
  · exact adaptive141Third139Proof125
  · exact adaptive141Third139Proof126
  · exact adaptive141Third139Proof127
  · exact adaptive141Third139Proof128
  · exact adaptive141Third139Proof129
  · exact adaptive141Third139Proof130

#print axioms adaptive141Third139Proof102

theorem adaptive141Third139Proof131 : runCachedNode 511 129747 Adaptive141Third139Node131 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 129747 Adaptive141Third139Node131 = [103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 128, 130, 131, 133, 135] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive141Third139Proof132
  · exact adaptive141Third139Proof133
  · exact adaptive141Third139Proof134
  · exact adaptive141Third139Proof135
  · exact adaptive141Third139Proof136
  · exact adaptive141Third139Proof137
  · exact adaptive141Third139Proof138
  · exact adaptive141Third139Proof139
  · exact adaptive141Third139Proof140
  · exact adaptive141Third139Proof141
  · exact adaptive141Third139Proof142
  · exact adaptive141Third139Proof143
  · exact adaptive141Third139Proof144
  · exact adaptive141Third139Proof145
  · exact adaptive141Third139Proof146
  · exact adaptive141Third139Proof147
  · exact adaptive141Third139Proof148
  · exact adaptive141Third139Proof149
  · exact adaptive141Third139Proof150
  · exact adaptive141Third139Proof151
  · exact adaptive141Third139Proof152
  · exact adaptive141Third139Proof153
  · exact adaptive141Third139Proof154
  · exact adaptive141Third139Proof155
  · exact adaptive141Third139Proof156
  · exact adaptive141Third139Proof157
  · exact adaptive141Third139Proof158
  · exact adaptive141Third139Proof159
  · exact adaptive141Third139Proof160

#print axioms adaptive141Third139Proof131

theorem adaptive141Third139Proof191 : runCachedNode 511 129747 Adaptive141Third139Node191 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 129747 Adaptive141Third139Node191 = [91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 122, 124, 126, 131, 133] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive141Third139Proof192
  · exact adaptive141Third139Proof193
  · exact adaptive141Third139Proof194
  · exact adaptive141Third139Proof195
  · exact adaptive141Third139Proof196
  · exact adaptive141Third139Proof197
  · exact adaptive141Third139Proof198
  · exact adaptive141Third139Proof199
  · exact adaptive141Third139Proof200
  · exact adaptive141Third139Proof201
  · exact adaptive141Third139Proof202
  · exact adaptive141Third139Proof203
  · exact adaptive141Third139Proof204
  · exact adaptive141Third139Proof205
  · exact adaptive141Third139Proof206
  · exact adaptive141Third139Proof207
  · exact adaptive141Third139Proof208
  · exact adaptive141Third139Proof209
  · exact adaptive141Third139Proof210
  · exact adaptive141Third139Proof211
  · exact adaptive141Third139Proof212
  · exact adaptive141Third139Proof213
  · exact adaptive141Third139Proof214
  · exact adaptive141Third139Proof215
  · exact adaptive141Third139Proof216
  · exact adaptive141Third139Proof217
  · exact adaptive141Third139Proof218
  · exact adaptive141Third139Proof219
  · exact adaptive141Third139Proof220
  · exact adaptive141Third139Proof221
  · exact adaptive141Third139Proof222
  · exact adaptive141Third139Proof223
  · exact adaptive141Third139Proof224
  · exact adaptive141Third139Proof225
  · exact adaptive141Third139Proof226

#print axioms adaptive141Third139Proof191

theorem adaptive141Third139Proof161 : runCachedNode 511 129747 Adaptive141Third139Node161 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 129747 Adaptive141Third139Node161 = [102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 129, 131, 133, 134, 136] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive141Third139Proof162
  · exact adaptive141Third139Proof163
  · exact adaptive141Third139Proof164
  · exact adaptive141Third139Proof165
  · exact adaptive141Third139Proof166
  · exact adaptive141Third139Proof167
  · exact adaptive141Third139Proof168
  · exact adaptive141Third139Proof169
  · exact adaptive141Third139Proof170
  · exact adaptive141Third139Proof171
  · exact adaptive141Third139Proof172
  · exact adaptive141Third139Proof173
  · exact adaptive141Third139Proof174
  · exact adaptive141Third139Proof175
  · exact adaptive141Third139Proof176
  · exact adaptive141Third139Proof177
  · exact adaptive141Third139Proof178
  · exact adaptive141Third139Proof179
  · exact adaptive141Third139Proof180
  · exact adaptive141Third139Proof181
  · exact adaptive141Third139Proof182
  · exact adaptive141Third139Proof183
  · exact adaptive141Third139Proof184
  · exact adaptive141Third139Proof185
  · exact adaptive141Third139Proof186
  · exact adaptive141Third139Proof187
  · exact adaptive141Third139Proof188
  · exact adaptive141Third139Proof189
  · exact adaptive141Third139Proof190
  · exact adaptive141Third139Proof191
  · exact adaptive141Third139Proof227

#print axioms adaptive141Third139Proof161

theorem adaptive141Third139Proof228 : runCachedNode 511 129747 Adaptive141Third139Node228 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 129747 Adaptive141Third139Node228 = [102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 130, 133, 134, 135, 137] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive141Third139Proof229
  · exact adaptive141Third139Proof230
  · exact adaptive141Third139Proof231
  · exact adaptive141Third139Proof232
  · exact adaptive141Third139Proof233
  · exact adaptive141Third139Proof234
  · exact adaptive141Third139Proof235
  · exact adaptive141Third139Proof236
  · exact adaptive141Third139Proof237
  · exact adaptive141Third139Proof238
  · exact adaptive141Third139Proof239
  · exact adaptive141Third139Proof240
  · exact adaptive141Third139Proof241
  · exact adaptive141Third139Proof242
  · exact adaptive141Third139Proof243
  · exact adaptive141Third139Proof244
  · exact adaptive141Third139Proof245
  · exact adaptive141Third139Proof246
  · exact adaptive141Third139Proof247
  · exact adaptive141Third139Proof248
  · exact adaptive141Third139Proof249
  · exact adaptive141Third139Proof250
  · exact adaptive141Third139Proof251
  · exact adaptive141Third139Proof252
  · exact adaptive141Third139Proof253
  · exact adaptive141Third139Proof254
  · exact adaptive141Third139Proof255
  · exact adaptive141Third139Proof256
  · exact adaptive141Third139Proof257
  · exact adaptive141Third139Proof258
  · exact adaptive141Third139Proof259
  · exact adaptive141Third139Proof260

#print axioms adaptive141Third139Proof228

end NineSeparatedSubsetSums
