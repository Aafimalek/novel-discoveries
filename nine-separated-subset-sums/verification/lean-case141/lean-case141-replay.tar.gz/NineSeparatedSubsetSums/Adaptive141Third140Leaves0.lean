import NineSeparatedSubsetSums.Adaptive141Third140State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third140Proof232 : runCachedNode 511 129930 Adaptive141Third140Node232 = false := by
  decide +kernel

#print axioms adaptive141Third140Proof232

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third140Proof97 : runCachedNode 511 129930 Adaptive141Third140Node97 = false := by
  decide +kernel

#print axioms adaptive141Third140Proof97

end NineSeparatedSubsetSums
