import NineSeparatedSubsetSums.Adaptive141Third135State
import NineSeparatedSubsetSums.Adaptive141Third135Leaves10
import NineSeparatedSubsetSums.Adaptive141Third135Leaves6
import NineSeparatedSubsetSums.Adaptive141Third135Leaves9
import NineSeparatedSubsetSums.Adaptive141Third135Leaves1
import NineSeparatedSubsetSums.Adaptive141Third135Leaves8
import NineSeparatedSubsetSums.Adaptive141Third135Leaves7
import NineSeparatedSubsetSums.Adaptive141Third135Leaves0
import NineSeparatedSubsetSums.Adaptive141Third135Leaves4
import NineSeparatedSubsetSums.Adaptive141Third135Leaves3
import NineSeparatedSubsetSums.Adaptive141Third135Leaves5
import NineSeparatedSubsetSums.Adaptive141Third135Leaves2

namespace NineSeparatedSubsetSums

theorem adaptive141Third135Proof22 : runCachedNode 511 129079 Adaptive141Third135Node22 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 129079 Adaptive141Third135Node22 = [104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 120, 121, 122, 123, 124, 127, 129, 130, 131] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive141Third135Proof23
  · exact adaptive141Third135Proof24
  · exact adaptive141Third135Proof25
  · exact adaptive141Third135Proof26
  · exact adaptive141Third135Proof27
  · exact adaptive141Third135Proof28
  · exact adaptive141Third135Proof29
  · exact adaptive141Third135Proof30
  · exact adaptive141Third135Proof31
  · exact adaptive141Third135Proof32
  · exact adaptive141Third135Proof33
  · exact adaptive141Third135Proof34
  · exact adaptive141Third135Proof35
  · exact adaptive141Third135Proof36
  · exact adaptive141Third135Proof37
  · exact adaptive141Third135Proof38
  · exact adaptive141Third135Proof39
  · exact adaptive141Third135Proof40
  · exact adaptive141Third135Proof41
  · exact adaptive141Third135Proof42
  · exact adaptive141Third135Proof43
  · exact adaptive141Third135Proof44
  · exact adaptive141Third135Proof45
  · exact adaptive141Third135Proof46

#print axioms adaptive141Third135Proof22

theorem adaptive141Third135Proof47 : runCachedNode 511 129079 Adaptive141Third135Node47 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 129079 Adaptive141Third135Node47 = [104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 121, 122, 123, 124, 125, 129, 130, 131, 132] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive141Third135Proof48
  · exact adaptive141Third135Proof49
  · exact adaptive141Third135Proof50
  · exact adaptive141Third135Proof51
  · exact adaptive141Third135Proof52
  · exact adaptive141Third135Proof53
  · exact adaptive141Third135Proof54
  · exact adaptive141Third135Proof55
  · exact adaptive141Third135Proof56
  · exact adaptive141Third135Proof57
  · exact adaptive141Third135Proof58
  · exact adaptive141Third135Proof59
  · exact adaptive141Third135Proof60
  · exact adaptive141Third135Proof61
  · exact adaptive141Third135Proof62
  · exact adaptive141Third135Proof63
  · exact adaptive141Third135Proof64
  · exact adaptive141Third135Proof65
  · exact adaptive141Third135Proof66
  · exact adaptive141Third135Proof67
  · exact adaptive141Third135Proof68
  · exact adaptive141Third135Proof69
  · exact adaptive141Third135Proof70
  · exact adaptive141Third135Proof71
  · exact adaptive141Third135Proof72

#print axioms adaptive141Third135Proof47

theorem adaptive141Third135Proof73 : runCachedNode 511 129079 Adaptive141Third135Node73 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 129079 Adaptive141Third135Node73 = [104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 122, 123, 124, 125, 126, 129, 130, 131, 132, 133] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive141Third135Proof74
  · exact adaptive141Third135Proof75
  · exact adaptive141Third135Proof76
  · exact adaptive141Third135Proof77
  · exact adaptive141Third135Proof78
  · exact adaptive141Third135Proof79
  · exact adaptive141Third135Proof80
  · exact adaptive141Third135Proof81
  · exact adaptive141Third135Proof82
  · exact adaptive141Third135Proof83
  · exact adaptive141Third135Proof84
  · exact adaptive141Third135Proof85
  · exact adaptive141Third135Proof86
  · exact adaptive141Third135Proof87
  · exact adaptive141Third135Proof88
  · exact adaptive141Third135Proof89
  · exact adaptive141Third135Proof90
  · exact adaptive141Third135Proof91
  · exact adaptive141Third135Proof92
  · exact adaptive141Third135Proof93
  · exact adaptive141Third135Proof94
  · exact adaptive141Third135Proof95
  · exact adaptive141Third135Proof96
  · exact adaptive141Third135Proof97
  · exact adaptive141Third135Proof98
  · exact adaptive141Third135Proof99
  · exact adaptive141Third135Proof100

#print axioms adaptive141Third135Proof73

theorem adaptive141Third135Proof0 : runCachedNode 511 129079 Adaptive141Third135Node0 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 129079 Adaptive141Third135Node0 = [110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 129, 130, 131, 132, 133, 134] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive141Third135Proof1
  · exact adaptive141Third135Proof2
  · exact adaptive141Third135Proof3
  · exact adaptive141Third135Proof4
  · exact adaptive141Third135Proof5
  · exact adaptive141Third135Proof6
  · exact adaptive141Third135Proof7
  · exact adaptive141Third135Proof8
  · exact adaptive141Third135Proof9
  · exact adaptive141Third135Proof10
  · exact adaptive141Third135Proof11
  · exact adaptive141Third135Proof12
  · exact adaptive141Third135Proof13
  · exact adaptive141Third135Proof14
  · exact adaptive141Third135Proof15
  · exact adaptive141Third135Proof16
  · exact adaptive141Third135Proof17
  · exact adaptive141Third135Proof18
  · exact adaptive141Third135Proof19
  · exact adaptive141Third135Proof20
  · exact adaptive141Third135Proof21
  · exact adaptive141Third135Proof22
  · exact adaptive141Third135Proof47
  · exact adaptive141Third135Proof73

#print axioms adaptive141Third135Proof0

end NineSeparatedSubsetSums
