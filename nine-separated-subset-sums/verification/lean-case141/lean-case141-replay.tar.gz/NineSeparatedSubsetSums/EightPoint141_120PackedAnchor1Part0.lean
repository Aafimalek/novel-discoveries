import NineSeparatedSubsetSums.EightPoint141_120PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint141_120PackedAnchor1Part0 :
    ∀ j : Fin 120, 2338671 ≤ FourPointNumeric.octPackedCharge 141 120 20 packedOct141_120_1
      (2*((j.val : Int)+0)+0) := by decide +kernel

end NineSeparatedSubsetSums
