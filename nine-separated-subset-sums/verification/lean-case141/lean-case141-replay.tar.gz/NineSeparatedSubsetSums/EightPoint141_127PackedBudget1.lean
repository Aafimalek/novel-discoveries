import NineSeparatedSubsetSums.EightPoint141_127PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct141_127_1_budget :
    FourPointNumeric.packedBudget 20 packedOct141_127_1 434 = 86522048 := by decide +kernel

#print axioms packedOct141_127_1_budget

end NineSeparatedSubsetSums
