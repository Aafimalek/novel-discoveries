import NineSeparatedSubsetSums.EightPoint141_133PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct141_133_0_budget :
    FourPointNumeric.packedBudget 20 packedOct141_133_0 457 = 91216086 := by decide +kernel

#print axioms packedOct141_133_0_budget

end NineSeparatedSubsetSums
