import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive141Third118Node0 : CachedSearchNode :=
  ⟨4, 117, computeCenteredMask [148,141,118], 407, 55709⟩

end NineSeparatedSubsetSums
