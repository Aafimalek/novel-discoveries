import NineSeparatedSubsetSums.EightPointPackedGeometry
import NineSeparatedSubsetSums.EightPoint141_138PackedBudget0
import NineSeparatedSubsetSums.EightPoint141_138PackedAnchor0Part0
import NineSeparatedSubsetSums.EightPoint141_138PackedAnchor0Part1
import NineSeparatedSubsetSums.EightPoint141_138PackedAnchor0Part2
import NineSeparatedSubsetSums.EightPoint141_138PackedBudget1
import NineSeparatedSubsetSums.EightPoint141_138PackedAnchor1Part0
import NineSeparatedSubsetSums.EightPoint141_138PackedAnchor1Part1
import NineSeparatedSubsetSums.EightPoint141_138PackedAnchor1Part2

namespace NineSeparatedSubsetSums

private theorem packedOct141_138Anchor0 :
  ∀ j : Fin 502, ((j.val : Int)+141+138)%2=0 →
    2495833 ≤ FourPointNumeric.octPackedCharge 141 138 20 packedOct141_138_0 (j.val : Int) := by
  intro j hj
  let k := (j.val-1)/2
  have hk : k < 251 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+1 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint141_138PackedAnchor0Part0 z
    rwa [he,hrep] at ht
  by_cases h1 : k < 240
  · let z : Fin 120 := ⟨k-120, by omega⟩
    have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
    have ht := eightPoint141_138PackedAnchor0Part1 z
    rwa [he,hrep] at ht
  let z : Fin 11 := ⟨k-240, by omega⟩
  have he : (z.val : Int)+240 = k := by dsimp [z] <;> omega
  have ht := eightPoint141_138PackedAnchor0Part2 z
  rwa [he,hrep] at ht

private theorem packedOct141_138Anchor1 :
  ∀ j : Fin 502, ((j.val : Int)+141+138)%2=1 →
    2495700 ≤ FourPointNumeric.octPackedCharge 141 138 20 packedOct141_138_1 (j.val : Int) := by
  intro j hj
  let k := (j.val-0)/2
  have hk : k < 251 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+0 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint141_138PackedAnchor1Part0 z
    rwa [he,hrep] at ht
  by_cases h1 : k < 240
  · let z : Fin 120 := ⟨k-120, by omega⟩
    have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
    have ht := eightPoint141_138PackedAnchor1Part1 z
    rwa [he,hrep] at ht
  let z : Fin 11 := ⟨k-240, by omega⟩
  have he : (z.val : Int)+240 = k := by dsimp [z] <;> omega
  have ht := eightPoint141_138PackedAnchor1Part2 z
  rwa [he,hrep] at ht

def packedOctCertificate141_138_0 : EightPointCertificate 141 138 0 129566 :=
  eightPointCertificateOfPacked 141 138 0 129566 2495833 20 packedOct141_138_0 277 502
    (by decide +kernel) (by decide) packedOct141_138Anchor0
    (by rw [packedOct141_138_0_budget]; decide)

def packedOctCertificate141_138_1 : EightPointCertificate 141 138 1 129566 :=
  eightPointCertificateOfPacked 141 138 1 129566 2495700 20 packedOct141_138_1 422 502
    (by decide +kernel) (by decide) packedOct141_138Anchor1
    (by rw [packedOct141_138_1_budget]; decide)

theorem max148_second141_third138_eightPoint_moment_bound (tail : List ℕ) (len : tail.length=6)
    (distinct : (natSubsetSums (148::141::138::tail)).Nodup) :
    129566 ≤ ((148::141::138::tail).map (· ^ 2)).sum := by
  apply eightPointNatMomentLower 141 138 129566 tail len distinct
  intro p hp
  by_cases h : p=0
  · subst p
    exact packedOctCertificate141_138_0
  · have he : p=1 := hp.resolve_left h
    subst p
    exact packedOctCertificate141_138_1

#print axioms max148_second141_third138_eightPoint_moment_bound

end NineSeparatedSubsetSums
