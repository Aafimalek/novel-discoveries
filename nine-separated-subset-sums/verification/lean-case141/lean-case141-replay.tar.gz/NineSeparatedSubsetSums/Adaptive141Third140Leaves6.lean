import NineSeparatedSubsetSums.Adaptive141Third140State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third140Proof231 : runCachedNode 511 129930 Adaptive141Third140Node231 = false := by
  decide +kernel

#print axioms adaptive141Third140Proof231

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third140Proof162 : runCachedNode 511 129930 Adaptive141Third140Node162 = false := by
  decide +kernel

#print axioms adaptive141Third140Proof162

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third140Proof125 : runCachedNode 511 129930 Adaptive141Third140Node125 = false := by
  decide +kernel

#print axioms adaptive141Third140Proof125

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third140Proof80 : runCachedNode 511 129930 Adaptive141Third140Node80 = false := by
  decide +kernel

#print axioms adaptive141Third140Proof80

end NineSeparatedSubsetSums
