import NineSeparatedSubsetSums.Adaptive141Third134State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third134Proof119 : runCachedNode 511 128866 Adaptive141Third134Node119 = false := by
  decide +kernel

#print axioms adaptive141Third134Proof119

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third134Proof89 : runCachedNode 511 128866 Adaptive141Third134Node89 = false := by
  decide +kernel

#print axioms adaptive141Third134Proof89

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third134Proof117 : runCachedNode 511 128866 Adaptive141Third134Node117 = false := by
  decide +kernel

#print axioms adaptive141Third134Proof117

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third134Proof41 : runCachedNode 511 128866 Adaptive141Third134Node41 = false := by
  decide +kernel

#print axioms adaptive141Third134Proof41

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third134Proof90 : runCachedNode 511 128866 Adaptive141Third134Node90 = false := by
  decide +kernel

#print axioms adaptive141Third134Proof90

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third134Proof64 : runCachedNode 511 128866 Adaptive141Third134Node64 = false := by
  decide +kernel

#print axioms adaptive141Third134Proof64

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third134Proof110 : runCachedNode 511 128866 Adaptive141Third134Node110 = false := by
  decide +kernel

#print axioms adaptive141Third134Proof110

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third134Proof47 : runCachedNode 511 128866 Adaptive141Third134Node47 = false := by
  decide +kernel

#print axioms adaptive141Third134Proof47

end NineSeparatedSubsetSums
