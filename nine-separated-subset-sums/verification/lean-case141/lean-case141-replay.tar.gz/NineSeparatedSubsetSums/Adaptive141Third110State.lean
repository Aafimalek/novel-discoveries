import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive141Third110Node0 : CachedSearchNode :=
  ⟨4, 109, computeCenteredMask [148,141,110], 399, 53885⟩

end NineSeparatedSubsetSums
