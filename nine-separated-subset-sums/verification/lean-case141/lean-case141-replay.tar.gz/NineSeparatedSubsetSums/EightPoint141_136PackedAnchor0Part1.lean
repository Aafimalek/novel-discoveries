import NineSeparatedSubsetSums.EightPoint141_136PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint141_136PackedAnchor0Part1 :
    ∀ j : Fin 120, 2478358 ≤ FourPointNumeric.octPackedCharge 141 136 20 packedOct141_136_0
      (2*((j.val : Int)+120)+1) := by decide +kernel

end NineSeparatedSubsetSums
