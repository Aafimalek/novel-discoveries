import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive141Third107Node0 : CachedSearchNode :=
  ⟨4, 106, computeCenteredMask [148,141,107], 396, 53234⟩

end NineSeparatedSubsetSums
