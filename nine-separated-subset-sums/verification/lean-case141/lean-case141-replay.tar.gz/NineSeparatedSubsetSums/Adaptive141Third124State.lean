import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive141Third124Node0 : CachedSearchNode :=
  ⟨4, 123, computeCenteredMask [148,141,124], 413, 57161⟩

end NineSeparatedSubsetSums
