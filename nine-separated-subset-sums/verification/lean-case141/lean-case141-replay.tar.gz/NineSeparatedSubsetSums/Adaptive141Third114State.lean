import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive141Third114Node0 : CachedSearchNode :=
  ⟨4, 113, computeCenteredMask [148,141,114], 403, 54781⟩

end NineSeparatedSubsetSums
