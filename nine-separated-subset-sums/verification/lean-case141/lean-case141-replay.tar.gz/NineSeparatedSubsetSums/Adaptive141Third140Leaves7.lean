import NineSeparatedSubsetSums.Adaptive141Third140State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third140Proof22 : runCachedNode 511 129930 Adaptive141Third140Node22 = false := by
  decide +kernel

#print axioms adaptive141Third140Proof22

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third140Proof165 : runCachedNode 511 129930 Adaptive141Third140Node165 = false := by
  decide +kernel

#print axioms adaptive141Third140Proof165

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third140Proof220 : runCachedNode 511 129930 Adaptive141Third140Node220 = false := by
  decide +kernel

#print axioms adaptive141Third140Proof220

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third140Proof50 : runCachedNode 511 129930 Adaptive141Third140Node50 = false := by
  decide +kernel

#print axioms adaptive141Third140Proof50

end NineSeparatedSubsetSums
