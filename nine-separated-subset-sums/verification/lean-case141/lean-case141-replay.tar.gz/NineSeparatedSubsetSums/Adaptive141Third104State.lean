import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive141Third104Node0 : CachedSearchNode :=
  ⟨4, 103, computeCenteredMask [148,141,104], 393, 52601⟩

end NineSeparatedSubsetSums
