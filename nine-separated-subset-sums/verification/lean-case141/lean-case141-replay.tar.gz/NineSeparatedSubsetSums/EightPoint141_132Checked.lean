import NineSeparatedSubsetSums.EightPointPackedGeometry
import NineSeparatedSubsetSums.EightPoint141_132PackedBudget0
import NineSeparatedSubsetSums.EightPoint141_132PackedAnchor0Part0
import NineSeparatedSubsetSums.EightPoint141_132PackedAnchor0Part1
import NineSeparatedSubsetSums.EightPoint141_132PackedAnchor0Part2
import NineSeparatedSubsetSums.EightPoint141_132PackedBudget1
import NineSeparatedSubsetSums.EightPoint141_132PackedAnchor1Part0
import NineSeparatedSubsetSums.EightPoint141_132PackedAnchor1Part1
import NineSeparatedSubsetSums.EightPoint141_132PackedAnchor1Part2

namespace NineSeparatedSubsetSums

private theorem packedOct141_132Anchor0 :
  ∀ j : Fin 496, ((j.val : Int)+141+132)%2=0 →
    2438400 ≤ FourPointNumeric.octPackedCharge 141 132 20 packedOct141_132_0 (j.val : Int) := by
  intro j hj
  let k := (j.val-1)/2
  have hk : k < 248 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+1 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint141_132PackedAnchor0Part0 z
    rwa [he,hrep] at ht
  by_cases h1 : k < 240
  · let z : Fin 120 := ⟨k-120, by omega⟩
    have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
    have ht := eightPoint141_132PackedAnchor0Part1 z
    rwa [he,hrep] at ht
  let z : Fin 8 := ⟨k-240, by omega⟩
  have he : (z.val : Int)+240 = k := by dsimp [z] <;> omega
  have ht := eightPoint141_132PackedAnchor0Part2 z
  rwa [he,hrep] at ht

private theorem packedOct141_132Anchor1 :
  ∀ j : Fin 496, ((j.val : Int)+141+132)%2=1 →
    2439744 ≤ FourPointNumeric.octPackedCharge 141 132 20 packedOct141_132_1 (j.val : Int) := by
  intro j hj
  let k := (j.val-0)/2
  have hk : k < 248 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+0 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint141_132PackedAnchor1Part0 z
    rwa [he,hrep] at ht
  by_cases h1 : k < 240
  · let z : Fin 120 := ⟨k-120, by omega⟩
    have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
    have ht := eightPoint141_132PackedAnchor1Part1 z
    rwa [he,hrep] at ht
  let z : Fin 8 := ⟨k-240, by omega⟩
  have he : (z.val : Int)+240 = k := by dsimp [z] <;> omega
  have ht := eightPoint141_132PackedAnchor1Part2 z
  rwa [he,hrep] at ht

def packedOctCertificate141_132_0 : EightPointCertificate 141 132 0 128536 :=
  eightPointCertificateOfPacked 141 132 0 128536 2438400 20 packedOct141_132_0 411 496
    (by decide +kernel) (by decide) packedOct141_132Anchor0
    (by rw [packedOct141_132_0_budget]; decide)

def packedOctCertificate141_132_1 : EightPointCertificate 141 132 1 128536 :=
  eightPointCertificateOfPacked 141 132 1 128536 2439744 20 packedOct141_132_1 470 496
    (by decide +kernel) (by decide) packedOct141_132Anchor1
    (by rw [packedOct141_132_1_budget]; decide)

theorem max148_second141_third132_eightPoint_moment_bound (tail : List ℕ) (len : tail.length=6)
    (distinct : (natSubsetSums (148::141::132::tail)).Nodup) :
    128536 ≤ ((148::141::132::tail).map (· ^ 2)).sum := by
  apply eightPointNatMomentLower 141 132 128536 tail len distinct
  intro p hp
  by_cases h : p=0
  · subst p
    exact packedOctCertificate141_132_0
  · have he : p=1 := hp.resolve_left h
    subst p
    exact packedOctCertificate141_132_1

#print axioms max148_second141_third132_eightPoint_moment_bound

end NineSeparatedSubsetSums
