import NineSeparatedSubsetSums.Adaptive141Third137State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third137Proof106 : runCachedNode 511 129418 Adaptive141Third137Node106 = false := by
  decide +kernel

#print axioms adaptive141Third137Proof106

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third137Proof133 : runCachedNode 511 129418 Adaptive141Third137Node133 = false := by
  decide +kernel

#print axioms adaptive141Third137Proof133

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third137Proof5 : runCachedNode 511 129418 Adaptive141Third137Node5 = false := by
  decide +kernel

#print axioms adaptive141Third137Proof5

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third137Proof108 : runCachedNode 511 129418 Adaptive141Third137Node108 = false := by
  decide +kernel

#print axioms adaptive141Third137Proof108

end NineSeparatedSubsetSums
