import NineSeparatedSubsetSums.Adaptive141Third140State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third140Proof161 : runCachedNode 511 129930 Adaptive141Third140Node161 = false := by
  decide +kernel

#print axioms adaptive141Third140Proof161

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third140Proof69 : runCachedNode 511 129930 Adaptive141Third140Node69 = false := by
  decide +kernel

#print axioms adaptive141Third140Proof69

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third140Proof12 : runCachedNode 511 129930 Adaptive141Third140Node12 = false := by
  decide +kernel

#print axioms adaptive141Third140Proof12

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third140Proof71 : runCachedNode 511 129930 Adaptive141Third140Node71 = false := by
  decide +kernel

#print axioms adaptive141Third140Proof71

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third140Proof68 : runCachedNode 511 129930 Adaptive141Third140Node68 = false := by
  decide +kernel

#print axioms adaptive141Third140Proof68

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third140Proof45 : runCachedNode 511 129930 Adaptive141Third140Node45 = false := by
  decide +kernel

#print axioms adaptive141Third140Proof45

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third140Proof105 : runCachedNode 511 129930 Adaptive141Third140Node105 = false := by
  decide +kernel

#print axioms adaptive141Third140Proof105

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third140Proof102 : runCachedNode 511 129930 Adaptive141Third140Node102 = false := by
  decide +kernel

#print axioms adaptive141Third140Proof102

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third140Proof41 : runCachedNode 511 129930 Adaptive141Third140Node41 = false := by
  decide +kernel

#print axioms adaptive141Third140Proof41

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third140Proof115 : runCachedNode 511 129930 Adaptive141Third140Node115 = false := by
  decide +kernel

#print axioms adaptive141Third140Proof115

end NineSeparatedSubsetSums
