import NineSeparatedSubsetSums.Adaptive141Third140State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third140Proof47 : runCachedNode 511 129930 Adaptive141Third140Node47 = false := by
  decide +kernel

#print axioms adaptive141Third140Proof47

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third140Proof74 : runCachedNode 511 129930 Adaptive141Third140Node74 = false := by
  decide +kernel

#print axioms adaptive141Third140Proof74

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third140Proof164 : runCachedNode 511 129930 Adaptive141Third140Node164 = false := by
  decide +kernel

#print axioms adaptive141Third140Proof164

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third140Proof44 : runCachedNode 511 129930 Adaptive141Third140Node44 = false := by
  decide +kernel

#print axioms adaptive141Third140Proof44

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third140Proof271 : runCachedNode 511 129930 Adaptive141Third140Node271 = false := by
  decide +kernel

#print axioms adaptive141Third140Proof271

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third140Proof181 : runCachedNode 511 129930 Adaptive141Third140Node181 = false := by
  decide +kernel

#print axioms adaptive141Third140Proof181

end NineSeparatedSubsetSums
