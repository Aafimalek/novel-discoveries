import NineSeparatedSubsetSums.Adaptive141Third138State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third138Proof200 : runCachedNode 511 129566 Adaptive141Third138Node200 = false := by
  decide +kernel

#print axioms adaptive141Third138Proof200

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third138Proof77 : runCachedNode 511 129566 Adaptive141Third138Node77 = false := by
  decide +kernel

#print axioms adaptive141Third138Proof77

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third138Proof138 : runCachedNode 511 129566 Adaptive141Third138Node138 = false := by
  decide +kernel

#print axioms adaptive141Third138Proof138

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third138Proof10 : runCachedNode 511 129566 Adaptive141Third138Node10 = false := by
  decide +kernel

#print axioms adaptive141Third138Proof10

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third138Proof1 : runCachedNode 511 129566 Adaptive141Third138Node1 = false := by
  decide +kernel

#print axioms adaptive141Third138Proof1

end NineSeparatedSubsetSums
