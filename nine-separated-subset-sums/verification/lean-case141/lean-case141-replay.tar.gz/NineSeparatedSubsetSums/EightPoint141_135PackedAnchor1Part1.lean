import NineSeparatedSubsetSums.EightPoint141_135PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint141_135PackedAnchor1Part1 :
    ∀ j : Fin 120, 2472017 ≤ FourPointNumeric.octPackedCharge 141 135 20 packedOct141_135_1
      (2*((j.val : Int)+120)+1) := by decide +kernel

end NineSeparatedSubsetSums
