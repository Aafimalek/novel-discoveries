import NineSeparatedSubsetSums.Adaptive141Third140State
import NineSeparatedSubsetSums.Adaptive141Third140Leaves5
import NineSeparatedSubsetSums.Adaptive141Third140Leaves4
import NineSeparatedSubsetSums.Adaptive141Third140Leaves27
import NineSeparatedSubsetSums.Adaptive141Third140Leaves26
import NineSeparatedSubsetSums.Adaptive141Third140Leaves15
import NineSeparatedSubsetSums.Adaptive141Third140Leaves25
import NineSeparatedSubsetSums.Adaptive141Third140Leaves24
import NineSeparatedSubsetSums.Adaptive141Third140Leaves23
import NineSeparatedSubsetSums.Adaptive141Third140Leaves22
import NineSeparatedSubsetSums.Adaptive141Third140Leaves20
import NineSeparatedSubsetSums.Adaptive141Third140Leaves18
import NineSeparatedSubsetSums.Adaptive141Third140Leaves11
import NineSeparatedSubsetSums.Adaptive141Third140Leaves7
import NineSeparatedSubsetSums.Adaptive141Third140Leaves28
import NineSeparatedSubsetSums.Adaptive141Third140Leaves17
import NineSeparatedSubsetSums.Adaptive141Third140Leaves1
import NineSeparatedSubsetSums.Adaptive141Third140Leaves14
import NineSeparatedSubsetSums.Adaptive141Third140Leaves19
import NineSeparatedSubsetSums.Adaptive141Third140Leaves10
import NineSeparatedSubsetSums.Adaptive141Third140Leaves12
import NineSeparatedSubsetSums.Adaptive141Third140Leaves16
import NineSeparatedSubsetSums.Adaptive141Third140Leaves6
import NineSeparatedSubsetSums.Adaptive141Third140Leaves21
import NineSeparatedSubsetSums.Adaptive141Third140Leaves2
import NineSeparatedSubsetSums.Adaptive141Third140Leaves9
import NineSeparatedSubsetSums.Adaptive141Third140Leaves0
import NineSeparatedSubsetSums.Adaptive141Third140Leaves29
import NineSeparatedSubsetSums.Adaptive141Third140Leaves8
import NineSeparatedSubsetSums.Adaptive141Third140Leaves13
import NineSeparatedSubsetSums.Adaptive141Third140Leaves3

namespace NineSeparatedSubsetSums

theorem adaptive141Third140Proof23 : runCachedNode 511 129930 Adaptive141Third140Node23 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 129930 Adaptive141Third140Node23 = [104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 126, 127, 128, 129, 130] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive141Third140Proof24
  · exact adaptive141Third140Proof25
  · exact adaptive141Third140Proof26
  · exact adaptive141Third140Proof27
  · exact adaptive141Third140Proof28
  · exact adaptive141Third140Proof29
  · exact adaptive141Third140Proof30
  · exact adaptive141Third140Proof31
  · exact adaptive141Third140Proof32
  · exact adaptive141Third140Proof33
  · exact adaptive141Third140Proof34
  · exact adaptive141Third140Proof35
  · exact adaptive141Third140Proof36
  · exact adaptive141Third140Proof37
  · exact adaptive141Third140Proof38
  · exact adaptive141Third140Proof39
  · exact adaptive141Third140Proof40
  · exact adaptive141Third140Proof41
  · exact adaptive141Third140Proof42
  · exact adaptive141Third140Proof43
  · exact adaptive141Third140Proof44
  · exact adaptive141Third140Proof45
  · exact adaptive141Third140Proof46
  · exact adaptive141Third140Proof47
  · exact adaptive141Third140Proof48

#print axioms adaptive141Third140Proof23

theorem adaptive141Third140Proof49 : runCachedNode 511 129930 Adaptive141Third140Node49 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 129930 Adaptive141Third140Node49 = [103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 128, 129, 130, 131, 132] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive141Third140Proof50
  · exact adaptive141Third140Proof51
  · exact adaptive141Third140Proof52
  · exact adaptive141Third140Proof53
  · exact adaptive141Third140Proof54
  · exact adaptive141Third140Proof55
  · exact adaptive141Third140Proof56
  · exact adaptive141Third140Proof57
  · exact adaptive141Third140Proof58
  · exact adaptive141Third140Proof59
  · exact adaptive141Third140Proof60
  · exact adaptive141Third140Proof61
  · exact adaptive141Third140Proof62
  · exact adaptive141Third140Proof63
  · exact adaptive141Third140Proof64
  · exact adaptive141Third140Proof65
  · exact adaptive141Third140Proof66
  · exact adaptive141Third140Proof67
  · exact adaptive141Third140Proof68
  · exact adaptive141Third140Proof69
  · exact adaptive141Third140Proof70
  · exact adaptive141Third140Proof71
  · exact adaptive141Third140Proof72
  · exact adaptive141Third140Proof73
  · exact adaptive141Third140Proof74
  · exact adaptive141Third140Proof75
  · exact adaptive141Third140Proof76
  · exact adaptive141Third140Proof77

#print axioms adaptive141Third140Proof49

theorem adaptive141Third140Proof78 : runCachedNode 511 129930 Adaptive141Third140Node78 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 129930 Adaptive141Third140Node78 = [103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 129, 130, 131, 132] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive141Third140Proof79
  · exact adaptive141Third140Proof80
  · exact adaptive141Third140Proof81
  · exact adaptive141Third140Proof82
  · exact adaptive141Third140Proof83
  · exact adaptive141Third140Proof84
  · exact adaptive141Third140Proof85
  · exact adaptive141Third140Proof86
  · exact adaptive141Third140Proof87
  · exact adaptive141Third140Proof88
  · exact adaptive141Third140Proof89
  · exact adaptive141Third140Proof90
  · exact adaptive141Third140Proof91
  · exact adaptive141Third140Proof92
  · exact adaptive141Third140Proof93
  · exact adaptive141Third140Proof94
  · exact adaptive141Third140Proof95
  · exact adaptive141Third140Proof96
  · exact adaptive141Third140Proof97
  · exact adaptive141Third140Proof98
  · exact adaptive141Third140Proof99
  · exact adaptive141Third140Proof100
  · exact adaptive141Third140Proof101
  · exact adaptive141Third140Proof102
  · exact adaptive141Third140Proof103
  · exact adaptive141Third140Proof104
  · exact adaptive141Third140Proof105
  · exact adaptive141Third140Proof106

#print axioms adaptive141Third140Proof78

theorem adaptive141Third140Proof107 : runCachedNode 511 129930 Adaptive141Third140Node107 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 129930 Adaptive141Third140Node107 = [103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 130, 131, 132, 134] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive141Third140Proof108
  · exact adaptive141Third140Proof109
  · exact adaptive141Third140Proof110
  · exact adaptive141Third140Proof111
  · exact adaptive141Third140Proof112
  · exact adaptive141Third140Proof113
  · exact adaptive141Third140Proof114
  · exact adaptive141Third140Proof115
  · exact adaptive141Third140Proof116
  · exact adaptive141Third140Proof117
  · exact adaptive141Third140Proof118
  · exact adaptive141Third140Proof119
  · exact adaptive141Third140Proof120
  · exact adaptive141Third140Proof121
  · exact adaptive141Third140Proof122
  · exact adaptive141Third140Proof123
  · exact adaptive141Third140Proof124
  · exact adaptive141Third140Proof125
  · exact adaptive141Third140Proof126
  · exact adaptive141Third140Proof127
  · exact adaptive141Third140Proof128
  · exact adaptive141Third140Proof129
  · exact adaptive141Third140Proof130
  · exact adaptive141Third140Proof131
  · exact adaptive141Third140Proof132
  · exact adaptive141Third140Proof133
  · exact adaptive141Third140Proof134
  · exact adaptive141Third140Proof135
  · exact adaptive141Third140Proof136

#print axioms adaptive141Third140Proof107

theorem adaptive141Third140Proof137 : runCachedNode 511 129930 Adaptive141Third140Node137 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 129930 Adaptive141Third140Node137 = [102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 131, 132, 134, 135] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive141Third140Proof138
  · exact adaptive141Third140Proof139
  · exact adaptive141Third140Proof140
  · exact adaptive141Third140Proof141
  · exact adaptive141Third140Proof142
  · exact adaptive141Third140Proof143
  · exact adaptive141Third140Proof144
  · exact adaptive141Third140Proof145
  · exact adaptive141Third140Proof146
  · exact adaptive141Third140Proof147
  · exact adaptive141Third140Proof148
  · exact adaptive141Third140Proof149
  · exact adaptive141Third140Proof150
  · exact adaptive141Third140Proof151
  · exact adaptive141Third140Proof152
  · exact adaptive141Third140Proof153
  · exact adaptive141Third140Proof154
  · exact adaptive141Third140Proof155
  · exact adaptive141Third140Proof156
  · exact adaptive141Third140Proof157
  · exact adaptive141Third140Proof158
  · exact adaptive141Third140Proof159
  · exact adaptive141Third140Proof160
  · exact adaptive141Third140Proof161
  · exact adaptive141Third140Proof162
  · exact adaptive141Third140Proof163
  · exact adaptive141Third140Proof164
  · exact adaptive141Third140Proof165
  · exact adaptive141Third140Proof166
  · exact adaptive141Third140Proof167
  · exact adaptive141Third140Proof168

#print axioms adaptive141Third140Proof137

theorem adaptive141Third140Proof169 : runCachedNode 511 129930 Adaptive141Third140Node169 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 129930 Adaptive141Third140Node169 = [102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 132, 134, 135, 136] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive141Third140Proof170
  · exact adaptive141Third140Proof171
  · exact adaptive141Third140Proof172
  · exact adaptive141Third140Proof173
  · exact adaptive141Third140Proof174
  · exact adaptive141Third140Proof175
  · exact adaptive141Third140Proof176
  · exact adaptive141Third140Proof177
  · exact adaptive141Third140Proof178
  · exact adaptive141Third140Proof179
  · exact adaptive141Third140Proof180
  · exact adaptive141Third140Proof181
  · exact adaptive141Third140Proof182
  · exact adaptive141Third140Proof183
  · exact adaptive141Third140Proof184
  · exact adaptive141Third140Proof185
  · exact adaptive141Third140Proof186
  · exact adaptive141Third140Proof187
  · exact adaptive141Third140Proof188
  · exact adaptive141Third140Proof189
  · exact adaptive141Third140Proof190
  · exact adaptive141Third140Proof191
  · exact adaptive141Third140Proof192
  · exact adaptive141Third140Proof193
  · exact adaptive141Third140Proof194
  · exact adaptive141Third140Proof195
  · exact adaptive141Third140Proof196
  · exact adaptive141Third140Proof197
  · exact adaptive141Third140Proof198
  · exact adaptive141Third140Proof199
  · exact adaptive141Third140Proof200
  · exact adaptive141Third140Proof201

#print axioms adaptive141Third140Proof169

theorem adaptive141Third140Proof235 : runCachedNode 511 129930 Adaptive141Third140Node235 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 129930 Adaptive141Third140Node235 = [89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 134] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive141Third140Proof236
  · exact adaptive141Third140Proof237
  · exact adaptive141Third140Proof238
  · exact adaptive141Third140Proof239
  · exact adaptive141Third140Proof240
  · exact adaptive141Third140Proof241
  · exact adaptive141Third140Proof242
  · exact adaptive141Third140Proof243
  · exact adaptive141Third140Proof244
  · exact adaptive141Third140Proof245
  · exact adaptive141Third140Proof246
  · exact adaptive141Third140Proof247
  · exact adaptive141Third140Proof248
  · exact adaptive141Third140Proof249
  · exact adaptive141Third140Proof250
  · exact adaptive141Third140Proof251
  · exact adaptive141Third140Proof252
  · exact adaptive141Third140Proof253
  · exact adaptive141Third140Proof254
  · exact adaptive141Third140Proof255
  · exact adaptive141Third140Proof256
  · exact adaptive141Third140Proof257
  · exact adaptive141Third140Proof258
  · exact adaptive141Third140Proof259
  · exact adaptive141Third140Proof260
  · exact adaptive141Third140Proof261
  · exact adaptive141Third140Proof262
  · exact adaptive141Third140Proof263
  · exact adaptive141Third140Proof264
  · exact adaptive141Third140Proof265
  · exact adaptive141Third140Proof266
  · exact adaptive141Third140Proof267
  · exact adaptive141Third140Proof268
  · exact adaptive141Third140Proof269
  · exact adaptive141Third140Proof270
  · exact adaptive141Third140Proof271
  · exact adaptive141Third140Proof272
  · exact adaptive141Third140Proof273
  · exact adaptive141Third140Proof274

#print axioms adaptive141Third140Proof235

theorem adaptive141Third140Proof202 : runCachedNode 511 129930 Adaptive141Third140Node202 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 129930 Adaptive141Third140Node202 = [102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 134, 135, 136, 137] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive141Third140Proof203
  · exact adaptive141Third140Proof204
  · exact adaptive141Third140Proof205
  · exact adaptive141Third140Proof206
  · exact adaptive141Third140Proof207
  · exact adaptive141Third140Proof208
  · exact adaptive141Third140Proof209
  · exact adaptive141Third140Proof210
  · exact adaptive141Third140Proof211
  · exact adaptive141Third140Proof212
  · exact adaptive141Third140Proof213
  · exact adaptive141Third140Proof214
  · exact adaptive141Third140Proof215
  · exact adaptive141Third140Proof216
  · exact adaptive141Third140Proof217
  · exact adaptive141Third140Proof218
  · exact adaptive141Third140Proof219
  · exact adaptive141Third140Proof220
  · exact adaptive141Third140Proof221
  · exact adaptive141Third140Proof222
  · exact adaptive141Third140Proof223
  · exact adaptive141Third140Proof224
  · exact adaptive141Third140Proof225
  · exact adaptive141Third140Proof226
  · exact adaptive141Third140Proof227
  · exact adaptive141Third140Proof228
  · exact adaptive141Third140Proof229
  · exact adaptive141Third140Proof230
  · exact adaptive141Third140Proof231
  · exact adaptive141Third140Proof232
  · exact adaptive141Third140Proof233
  · exact adaptive141Third140Proof234
  · exact adaptive141Third140Proof235

#print axioms adaptive141Third140Proof202

end NineSeparatedSubsetSums
