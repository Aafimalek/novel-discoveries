import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive141Third117Node0 : CachedSearchNode :=
  ⟨4, 116, computeCenteredMask [148,141,117], 406, 55474⟩

end NineSeparatedSubsetSums
