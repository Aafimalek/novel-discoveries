import NineSeparatedSubsetSums.Adaptive141Third140State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third140Proof18 : runCachedNode 511 129930 Adaptive141Third140Node18 = false := by
  decide +kernel

#print axioms adaptive141Third140Proof18

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third140Proof106 : runCachedNode 511 129930 Adaptive141Third140Node106 = false := by
  decide +kernel

#print axioms adaptive141Third140Proof106

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third140Proof227 : runCachedNode 511 129930 Adaptive141Third140Node227 = false := by
  decide +kernel

#print axioms adaptive141Third140Proof227

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third140Proof70 : runCachedNode 511 129930 Adaptive141Third140Node70 = false := by
  decide +kernel

#print axioms adaptive141Third140Proof70

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third140Proof55 : runCachedNode 511 129930 Adaptive141Third140Node55 = false := by
  decide +kernel

#print axioms adaptive141Third140Proof55

end NineSeparatedSubsetSums
