import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive141Third109Node0 : CachedSearchNode :=
  ⟨4, 108, computeCenteredMask [148,141,109], 398, 53666⟩

end NineSeparatedSubsetSums
