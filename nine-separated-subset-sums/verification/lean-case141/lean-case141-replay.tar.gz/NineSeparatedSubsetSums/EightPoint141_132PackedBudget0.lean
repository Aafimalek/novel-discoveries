import NineSeparatedSubsetSums.EightPoint141_132PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct141_132_0_budget :
    FourPointNumeric.packedBudget 20 packedOct141_132_0 411 = 90247045 := by decide +kernel

#print axioms packedOct141_132_0_budget

end NineSeparatedSubsetSums
