import NineSeparatedSubsetSums.EightPoint141_132PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct141_132_1_budget :
    FourPointNumeric.packedBudget 20 packedOct141_132_1 470 = 90333202 := by decide +kernel

#print axioms packedOct141_132_1_budget

end NineSeparatedSubsetSums
