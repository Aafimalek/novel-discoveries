import NineSeparatedSubsetSums.Adaptive141Third140State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third140Proof76 : runCachedNode 511 129930 Adaptive141Third140Node76 = false := by
  decide +kernel

#print axioms adaptive141Third140Proof76

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third140Proof199 : runCachedNode 511 129930 Adaptive141Third140Node199 = false := by
  decide +kernel

#print axioms adaptive141Third140Proof199

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third140Proof103 : runCachedNode 511 129930 Adaptive141Third140Node103 = false := by
  decide +kernel

#print axioms adaptive141Third140Proof103

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third140Proof138 : runCachedNode 511 129930 Adaptive141Third140Node138 = false := by
  decide +kernel

#print axioms adaptive141Third140Proof138

end NineSeparatedSubsetSums
