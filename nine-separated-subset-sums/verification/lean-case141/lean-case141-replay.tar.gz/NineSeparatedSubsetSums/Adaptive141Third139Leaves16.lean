import NineSeparatedSubsetSums.Adaptive141Third139State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third139Proof93 : runCachedNode 511 129747 Adaptive141Third139Node93 = false := by
  decide +kernel

#print axioms adaptive141Third139Proof93

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third139Proof97 : runCachedNode 511 129747 Adaptive141Third139Node97 = false := by
  decide +kernel

#print axioms adaptive141Third139Proof97

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third139Proof69 : runCachedNode 511 129747 Adaptive141Third139Node69 = false := by
  decide +kernel

#print axioms adaptive141Third139Proof69

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third139Proof253 : runCachedNode 511 129747 Adaptive141Third139Node253 = false := by
  decide +kernel

#print axioms adaptive141Third139Proof253

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third139Proof91 : runCachedNode 511 129747 Adaptive141Third139Node91 = false := by
  decide +kernel

#print axioms adaptive141Third139Proof91

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third139Proof70 : runCachedNode 511 129747 Adaptive141Third139Node70 = false := by
  decide +kernel

#print axioms adaptive141Third139Proof70

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third139Proof12 : runCachedNode 511 129747 Adaptive141Third139Node12 = false := by
  decide +kernel

#print axioms adaptive141Third139Proof12

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third139Proof181 : runCachedNode 511 129747 Adaptive141Third139Node181 = false := by
  decide +kernel

#print axioms adaptive141Third139Proof181

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third139Proof154 : runCachedNode 511 129747 Adaptive141Third139Node154 = false := by
  decide +kernel

#print axioms adaptive141Third139Proof154

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third139Proof86 : runCachedNode 511 129747 Adaptive141Third139Node86 = false := by
  decide +kernel

#print axioms adaptive141Third139Proof86

end NineSeparatedSubsetSums
