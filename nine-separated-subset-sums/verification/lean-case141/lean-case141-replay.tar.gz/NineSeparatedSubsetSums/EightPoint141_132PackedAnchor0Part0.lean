import NineSeparatedSubsetSums.EightPoint141_132PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint141_132PackedAnchor0Part0 :
    ∀ j : Fin 120, 2438400 ≤ FourPointNumeric.octPackedCharge 141 132 20 packedOct141_132_0
      (2*((j.val : Int)+0)+1) := by decide +kernel

end NineSeparatedSubsetSums
