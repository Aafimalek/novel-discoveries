import NineSeparatedSubsetSums.Adaptive141Third137State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third137Proof76 : runCachedNode 511 129418 Adaptive141Third137Node76 = false := by
  decide +kernel

#print axioms adaptive141Third137Proof76

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third137Proof48 : runCachedNode 511 129418 Adaptive141Third137Node48 = false := by
  decide +kernel

#print axioms adaptive141Third137Proof48

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third137Proof71 : runCachedNode 511 129418 Adaptive141Third137Node71 = false := by
  decide +kernel

#print axioms adaptive141Third137Proof71

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third137Proof55 : runCachedNode 511 129418 Adaptive141Third137Node55 = false := by
  decide +kernel

#print axioms adaptive141Third137Proof55

end NineSeparatedSubsetSums
