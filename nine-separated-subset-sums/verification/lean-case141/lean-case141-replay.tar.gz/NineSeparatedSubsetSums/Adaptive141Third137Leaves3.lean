import NineSeparatedSubsetSums.Adaptive141Third137State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third137Proof136 : runCachedNode 511 129418 Adaptive141Third137Node136 = false := by
  decide +kernel

#print axioms adaptive141Third137Proof136

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third137Proof104 : runCachedNode 511 129418 Adaptive141Third137Node104 = false := by
  decide +kernel

#print axioms adaptive141Third137Proof104

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third137Proof119 : runCachedNode 511 129418 Adaptive141Third137Node119 = false := by
  decide +kernel

#print axioms adaptive141Third137Proof119

end NineSeparatedSubsetSums
