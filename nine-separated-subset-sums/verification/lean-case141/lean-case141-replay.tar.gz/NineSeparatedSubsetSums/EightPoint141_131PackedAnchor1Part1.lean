import NineSeparatedSubsetSums.EightPoint141_131PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint141_131PackedAnchor1Part1 :
    ∀ j : Fin 120, 2426386 ≤ FourPointNumeric.octPackedCharge 141 131 20 packedOct141_131_1
      (2*((j.val : Int)+120)+1) := by decide +kernel

end NineSeparatedSubsetSums
