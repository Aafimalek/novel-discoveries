import NineSeparatedSubsetSums.EightPoint141_124PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint141_124PackedAnchor1Part2 :
    ∀ j : Fin 2, 2325912 ≤ FourPointNumeric.octPackedCharge 141 124 20 packedOct141_124_1
      (2*((j.val : Int)+240)+0) := by decide +kernel

end NineSeparatedSubsetSums
