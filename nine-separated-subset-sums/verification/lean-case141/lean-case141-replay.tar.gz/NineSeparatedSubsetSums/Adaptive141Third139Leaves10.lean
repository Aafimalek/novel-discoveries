import NineSeparatedSubsetSums.Adaptive141Third139State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third139Proof186 : runCachedNode 511 129747 Adaptive141Third139Node186 = false := by
  decide +kernel

#print axioms adaptive141Third139Proof186

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third139Proof257 : runCachedNode 511 129747 Adaptive141Third139Node257 = false := by
  decide +kernel

#print axioms adaptive141Third139Proof257

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third139Proof189 : runCachedNode 511 129747 Adaptive141Third139Node189 = false := by
  decide +kernel

#print axioms adaptive141Third139Proof189

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third139Proof5 : runCachedNode 511 129747 Adaptive141Third139Node5 = false := by
  decide +kernel

#print axioms adaptive141Third139Proof5

end NineSeparatedSubsetSums
