import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive141Third120Node0 : CachedSearchNode :=
  ⟨4, 119, computeCenteredMask [148,141,120], 409, 56185⟩

end NineSeparatedSubsetSums
