import NineSeparatedSubsetSums.Adaptive141Third123State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third123Proof0 : runCachedNode 511 126322 Adaptive141Third123Node0 = false := by
  decide +kernel

#print axioms adaptive141Third123Proof0

end NineSeparatedSubsetSums
