import NineSeparatedSubsetSums.Adaptive141Third133State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third133Proof11 : runCachedNode 511 128708 Adaptive141Third133Node11 = false := by
  decide +kernel

#print axioms adaptive141Third133Proof11

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third133Proof10 : runCachedNode 511 128708 Adaptive141Third133Node10 = false := by
  decide +kernel

#print axioms adaptive141Third133Proof10

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third133Proof41 : runCachedNode 511 128708 Adaptive141Third133Node41 = false := by
  decide +kernel

#print axioms adaptive141Third133Proof41

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third133Proof42 : runCachedNode 511 128708 Adaptive141Third133Node42 = false := by
  decide +kernel

#print axioms adaptive141Third133Proof42

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third133Proof43 : runCachedNode 511 128708 Adaptive141Third133Node43 = false := by
  decide +kernel

#print axioms adaptive141Third133Proof43

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third133Proof9 : runCachedNode 511 128708 Adaptive141Third133Node9 = false := by
  decide +kernel

#print axioms adaptive141Third133Proof9

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third133Proof39 : runCachedNode 511 128708 Adaptive141Third133Node39 = false := by
  decide +kernel

#print axioms adaptive141Third133Proof39

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third133Proof38 : runCachedNode 511 128708 Adaptive141Third133Node38 = false := by
  decide +kernel

#print axioms adaptive141Third133Proof38

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third133Proof8 : runCachedNode 511 128708 Adaptive141Third133Node8 = false := by
  decide +kernel

#print axioms adaptive141Third133Proof8

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third133Proof40 : runCachedNode 511 128708 Adaptive141Third133Node40 = false := by
  decide +kernel

#print axioms adaptive141Third133Proof40

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third133Proof37 : runCachedNode 511 128708 Adaptive141Third133Node37 = false := by
  decide +kernel

#print axioms adaptive141Third133Proof37

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third133Proof35 : runCachedNode 511 128708 Adaptive141Third133Node35 = false := by
  decide +kernel

#print axioms adaptive141Third133Proof35

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third133Proof5 : runCachedNode 511 128708 Adaptive141Third133Node5 = false := by
  decide +kernel

#print axioms adaptive141Third133Proof5

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third133Proof34 : runCachedNode 511 128708 Adaptive141Third133Node34 = false := by
  decide +kernel

#print axioms adaptive141Third133Proof34

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third133Proof4 : runCachedNode 511 128708 Adaptive141Third133Node4 = false := by
  decide +kernel

#print axioms adaptive141Third133Proof4

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third133Proof33 : runCachedNode 511 128708 Adaptive141Third133Node33 = false := by
  decide +kernel

#print axioms adaptive141Third133Proof33

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third133Proof3 : runCachedNode 511 128708 Adaptive141Third133Node3 = false := by
  decide +kernel

#print axioms adaptive141Third133Proof3

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third133Proof31 : runCachedNode 511 128708 Adaptive141Third133Node31 = false := by
  decide +kernel

#print axioms adaptive141Third133Proof31

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third133Proof30 : runCachedNode 511 128708 Adaptive141Third133Node30 = false := by
  decide +kernel

#print axioms adaptive141Third133Proof30

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third133Proof29 : runCachedNode 511 128708 Adaptive141Third133Node29 = false := by
  decide +kernel

#print axioms adaptive141Third133Proof29

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third133Proof2 : runCachedNode 511 128708 Adaptive141Third133Node2 = false := by
  decide +kernel

#print axioms adaptive141Third133Proof2

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third133Proof26 : runCachedNode 511 128708 Adaptive141Third133Node26 = false := by
  decide +kernel

#print axioms adaptive141Third133Proof26

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third133Proof27 : runCachedNode 511 128708 Adaptive141Third133Node27 = false := by
  decide +kernel

#print axioms adaptive141Third133Proof27

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third133Proof28 : runCachedNode 511 128708 Adaptive141Third133Node28 = false := by
  decide +kernel

#print axioms adaptive141Third133Proof28

end NineSeparatedSubsetSums
