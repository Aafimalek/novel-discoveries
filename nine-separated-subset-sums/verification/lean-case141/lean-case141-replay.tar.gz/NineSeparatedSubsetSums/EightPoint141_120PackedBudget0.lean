import NineSeparatedSubsetSums.EightPoint141_120PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct141_120_0_budget :
    FourPointNumeric.packedBudget 20 packedOct141_120_0 361 = 85328722 := by decide +kernel

#print axioms packedOct141_120_0_budget

end NineSeparatedSubsetSums
