import NineSeparatedSubsetSums.EightPoint141_132PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint141_132PackedAnchor1Part2 :
    ∀ j : Fin 8, 2439744 ≤ FourPointNumeric.octPackedCharge 141 132 20 packedOct141_132_1
      (2*((j.val : Int)+240)+0) := by decide +kernel

end NineSeparatedSubsetSums
