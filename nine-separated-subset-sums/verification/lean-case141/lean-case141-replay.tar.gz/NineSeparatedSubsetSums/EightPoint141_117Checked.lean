import NineSeparatedSubsetSums.EightPointPackedGeometry
import NineSeparatedSubsetSums.EightPoint141_117PackedBudget0
import NineSeparatedSubsetSums.EightPoint141_117PackedAnchor0Part0
import NineSeparatedSubsetSums.EightPoint141_117PackedAnchor0Part1
import NineSeparatedSubsetSums.EightPoint141_117PackedAnchor0Part2
import NineSeparatedSubsetSums.EightPoint141_117PackedBudget1
import NineSeparatedSubsetSums.EightPoint141_117PackedAnchor1Part0
import NineSeparatedSubsetSums.EightPoint141_117PackedAnchor1Part1
import NineSeparatedSubsetSums.EightPoint141_117PackedAnchor1Part2

namespace NineSeparatedSubsetSums

private theorem packedOct141_117Anchor0 :
  ∀ j : Fin 490, ((j.val : Int)+141+117)%2=0 →
    2360914 ≤ FourPointNumeric.octPackedCharge 141 117 20 packedOct141_117_0 (j.val : Int) := by
  intro j hj
  let k := (j.val-0)/2
  have hk : k < 245 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+0 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint141_117PackedAnchor0Part0 z
    rwa [he,hrep] at ht
  by_cases h1 : k < 240
  · let z : Fin 120 := ⟨k-120, by omega⟩
    have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
    have ht := eightPoint141_117PackedAnchor0Part1 z
    rwa [he,hrep] at ht
  let z : Fin 5 := ⟨k-240, by omega⟩
  have he : (z.val : Int)+240 = k := by dsimp [z] <;> omega
  have ht := eightPoint141_117PackedAnchor0Part2 z
  rwa [he,hrep] at ht

private theorem packedOct141_117Anchor1 :
  ∀ j : Fin 490, ((j.val : Int)+141+117)%2=1 →
    2357921 ≤ FourPointNumeric.octPackedCharge 141 117 20 packedOct141_117_1 (j.val : Int) := by
  intro j hj
  let k := (j.val-1)/2
  have hk : k < 245 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+1 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint141_117PackedAnchor1Part0 z
    rwa [he,hrep] at ht
  by_cases h1 : k < 240
  · let z : Fin 120 := ⟨k-120, by omega⟩
    have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
    have ht := eightPoint141_117PackedAnchor1Part1 z
    rwa [he,hrep] at ht
  let z : Fin 5 := ⟨k-240, by omega⟩
  have he : (z.val : Int)+240 = k := by dsimp [z] <;> omega
  have ht := eightPoint141_117PackedAnchor1Part2 z
  rwa [he,hrep] at ht

def packedOctCertificate141_117_0 : EightPointCertificate 141 117 0 125131 :=
  eightPointCertificateOfPacked 141 117 0 125131 2360914 20 packedOct141_117_0 267 490
    (by decide +kernel) (by decide) packedOct141_117Anchor0
    (by rw [packedOct141_117_0_budget]; decide)

def packedOctCertificate141_117_1 : EightPointCertificate 141 117 1 125131 :=
  eightPointCertificateOfPacked 141 117 1 125131 2357921 20 packedOct141_117_1 268 490
    (by decide +kernel) (by decide) packedOct141_117Anchor1
    (by rw [packedOct141_117_1_budget]; decide)

theorem max148_second141_third117_eightPoint_moment_bound (tail : List ℕ) (len : tail.length=6)
    (distinct : (natSubsetSums (148::141::117::tail)).Nodup) :
    125131 ≤ ((148::141::117::tail).map (· ^ 2)).sum := by
  apply eightPointNatMomentLower 141 117 125131 tail len distinct
  intro p hp
  by_cases h : p=0
  · subst p
    exact packedOctCertificate141_117_0
  · have he : p=1 := hp.resolve_left h
    subst p
    exact packedOctCertificate141_117_1

#print axioms max148_second141_third117_eightPoint_moment_bound

end NineSeparatedSubsetSums
