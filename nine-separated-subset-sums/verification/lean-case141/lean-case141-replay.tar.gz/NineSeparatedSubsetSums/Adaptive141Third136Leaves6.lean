import NineSeparatedSubsetSums.Adaptive141Third136State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third136Proof161 : runCachedNode 511 129226 Adaptive141Third136Node161 = false := by
  decide +kernel

#print axioms adaptive141Third136Proof161

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third136Proof126 : runCachedNode 511 129226 Adaptive141Third136Node126 = false := by
  decide +kernel

#print axioms adaptive141Third136Proof126

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third136Proof96 : runCachedNode 511 129226 Adaptive141Third136Node96 = false := by
  decide +kernel

#print axioms adaptive141Third136Proof96

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third136Proof14 : runCachedNode 511 129226 Adaptive141Third136Node14 = false := by
  decide +kernel

#print axioms adaptive141Third136Proof14

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third136Proof7 : runCachedNode 511 129226 Adaptive141Third136Node7 = false := by
  decide +kernel

#print axioms adaptive141Third136Proof7

end NineSeparatedSubsetSums
