import NineSeparatedSubsetSums.EightPoint141_131PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct141_131_1_budget :
    FourPointNumeric.packedBudget 20 packedOct141_131_1 472 = 89513562 := by decide +kernel

#print axioms packedOct141_131_1_budget

end NineSeparatedSubsetSums
