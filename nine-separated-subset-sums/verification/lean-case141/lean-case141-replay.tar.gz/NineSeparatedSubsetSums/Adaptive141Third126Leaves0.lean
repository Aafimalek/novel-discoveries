import NineSeparatedSubsetSums.Adaptive141Third126State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third126Proof0 : runCachedNode 511 127399 Adaptive141Third126Node0 = false := by
  decide +kernel

#print axioms adaptive141Third126Proof0

end NineSeparatedSubsetSums
