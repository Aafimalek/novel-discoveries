import NineSeparatedSubsetSums.EightPoint141_135PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct141_135_0_budget :
    FourPointNumeric.packedBudget 20 packedOct141_135_0 471 = 92122844 := by decide +kernel

#print axioms packedOct141_135_0_budget

end NineSeparatedSubsetSums
