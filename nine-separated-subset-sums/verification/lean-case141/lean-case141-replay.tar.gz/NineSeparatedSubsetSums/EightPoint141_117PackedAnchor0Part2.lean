import NineSeparatedSubsetSums.EightPoint141_117PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint141_117PackedAnchor0Part2 :
    ∀ j : Fin 5, 2360914 ≤ FourPointNumeric.octPackedCharge 141 117 20 packedOct141_117_0
      (2*((j.val : Int)+240)+0) := by decide +kernel

end NineSeparatedSubsetSums
