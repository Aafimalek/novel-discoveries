import NineSeparatedSubsetSums.Adaptive141Third119State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third119Proof0 : runCachedNode 511 125564 Adaptive141Third119Node0 = false := by
  decide +kernel

#print axioms adaptive141Third119Proof0

end NineSeparatedSubsetSums
