import NineSeparatedSubsetSums.EightPoint141_123PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct141_123_1_budget :
    FourPointNumeric.packedBudget 20 packedOct141_123_1 280 = 82749660 := by decide +kernel

#print axioms packedOct141_123_1_budget

end NineSeparatedSubsetSums
