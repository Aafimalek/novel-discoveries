import NineSeparatedSubsetSums.Adaptive141Third116State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third116Proof15 : runCachedNode 511 111653 Adaptive141Third116Node15 = false := by
  decide +kernel

#print axioms adaptive141Third116Proof15

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third116Proof14 : runCachedNode 511 111653 Adaptive141Third116Node14 = false := by
  decide +kernel

#print axioms adaptive141Third116Proof14

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third116Proof13 : runCachedNode 511 111653 Adaptive141Third116Node13 = false := by
  decide +kernel

#print axioms adaptive141Third116Proof13

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third116Proof6 : runCachedNode 511 111653 Adaptive141Third116Node6 = false := by
  decide +kernel

#print axioms adaptive141Third116Proof6

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third116Proof1 : runCachedNode 511 111653 Adaptive141Third116Node1 = false := by
  decide +kernel

#print axioms adaptive141Third116Proof1

end NineSeparatedSubsetSums
