import NineSeparatedSubsetSums.EightPoint141_123PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint141_123PackedAnchor1Part1 :
    ∀ j : Fin 120, 2303533 ≤ FourPointNumeric.octPackedCharge 141 123 20 packedOct141_123_1
      (2*((j.val : Int)+120)+1) := by decide +kernel

end NineSeparatedSubsetSums
