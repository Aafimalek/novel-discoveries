import NineSeparatedSubsetSums.Adaptive141Third136State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third136Proof45 : runCachedNode 511 129226 Adaptive141Third136Node45 = false := by
  decide +kernel

#print axioms adaptive141Third136Proof45

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third136Proof89 : runCachedNode 511 129226 Adaptive141Third136Node89 = false := by
  decide +kernel

#print axioms adaptive141Third136Proof89

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third136Proof1 : runCachedNode 511 129226 Adaptive141Third136Node1 = false := by
  decide +kernel

#print axioms adaptive141Third136Proof1

end NineSeparatedSubsetSums
