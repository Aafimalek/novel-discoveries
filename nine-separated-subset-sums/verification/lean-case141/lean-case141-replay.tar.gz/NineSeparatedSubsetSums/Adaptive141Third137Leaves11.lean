import NineSeparatedSubsetSums.Adaptive141Third137State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third137Proof14 : runCachedNode 511 129418 Adaptive141Third137Node14 = false := by
  decide +kernel

#print axioms adaptive141Third137Proof14

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third137Proof74 : runCachedNode 511 129418 Adaptive141Third137Node74 = false := by
  decide +kernel

#print axioms adaptive141Third137Proof74

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third137Proof103 : runCachedNode 511 129418 Adaptive141Third137Node103 = false := by
  decide +kernel

#print axioms adaptive141Third137Proof103

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third137Proof73 : runCachedNode 511 129418 Adaptive141Third137Node73 = false := by
  decide +kernel

#print axioms adaptive141Third137Proof73

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third137Proof101 : runCachedNode 511 129418 Adaptive141Third137Node101 = false := by
  decide +kernel

#print axioms adaptive141Third137Proof101

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third137Proof45 : runCachedNode 511 129418 Adaptive141Third137Node45 = false := by
  decide +kernel

#print axioms adaptive141Third137Proof45

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third137Proof117 : runCachedNode 511 129418 Adaptive141Third137Node117 = false := by
  decide +kernel

#print axioms adaptive141Third137Proof117

end NineSeparatedSubsetSums
