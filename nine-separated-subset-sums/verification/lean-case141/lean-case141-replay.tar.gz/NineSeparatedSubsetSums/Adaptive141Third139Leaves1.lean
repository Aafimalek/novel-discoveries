import NineSeparatedSubsetSums.Adaptive141Third139State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third139Proof190 : runCachedNode 511 129747 Adaptive141Third139Node190 = false := by
  decide +kernel

#print axioms adaptive141Third139Proof190

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third139Proof17 : runCachedNode 511 129747 Adaptive141Third139Node17 = false := by
  decide +kernel

#print axioms adaptive141Third139Proof17

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third139Proof6 : runCachedNode 511 129747 Adaptive141Third139Node6 = false := by
  decide +kernel

#print axioms adaptive141Third139Proof6

end NineSeparatedSubsetSums
