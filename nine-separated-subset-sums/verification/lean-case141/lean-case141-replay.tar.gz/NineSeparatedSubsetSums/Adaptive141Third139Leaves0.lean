import NineSeparatedSubsetSums.Adaptive141Third139State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third139Proof45 : runCachedNode 511 129747 Adaptive141Third139Node45 = false := by
  decide +kernel

#print axioms adaptive141Third139Proof45

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third139Proof251 : runCachedNode 511 129747 Adaptive141Third139Node251 = false := by
  decide +kernel

#print axioms adaptive141Third139Proof251

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third139Proof53 : runCachedNode 511 129747 Adaptive141Third139Node53 = false := by
  decide +kernel

#print axioms adaptive141Third139Proof53

end NineSeparatedSubsetSums
