import NineSeparatedSubsetSums.Adaptive141Third110State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third110Proof0 : runCachedNode 511 111653 Adaptive141Third110Node0 = false := by
  decide +kernel

#print axioms adaptive141Third110Proof0

end NineSeparatedSubsetSums
