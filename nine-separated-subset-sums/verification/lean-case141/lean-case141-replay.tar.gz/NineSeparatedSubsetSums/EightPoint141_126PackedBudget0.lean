import NineSeparatedSubsetSums.EightPoint141_126PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct141_126_0_budget :
    FourPointNumeric.packedBudget 20 packedOct141_126_0 379 = 85278858 := by decide +kernel

#print axioms packedOct141_126_0_budget

end NineSeparatedSubsetSums
