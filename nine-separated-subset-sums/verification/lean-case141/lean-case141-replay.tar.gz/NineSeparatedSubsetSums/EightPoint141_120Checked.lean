import NineSeparatedSubsetSums.EightPointPackedGeometry
import NineSeparatedSubsetSums.EightPoint141_120PackedBudget0
import NineSeparatedSubsetSums.EightPoint141_120PackedAnchor0Part0
import NineSeparatedSubsetSums.EightPoint141_120PackedAnchor0Part1
import NineSeparatedSubsetSums.EightPoint141_120PackedAnchor0Part2
import NineSeparatedSubsetSums.EightPoint141_120PackedBudget1
import NineSeparatedSubsetSums.EightPoint141_120PackedAnchor1Part0
import NineSeparatedSubsetSums.EightPoint141_120PackedAnchor1Part1
import NineSeparatedSubsetSums.EightPoint141_120PackedAnchor1Part2

namespace NineSeparatedSubsetSums

private theorem packedOct141_120Anchor0 :
  ∀ j : Fin 487, ((j.val : Int)+141+120)%2=0 →
    2339286 ≤ FourPointNumeric.octPackedCharge 141 120 20 packedOct141_120_0 (j.val : Int) := by
  intro j hj
  let k := (j.val-1)/2
  have hk : k < 243 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+1 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint141_120PackedAnchor0Part0 z
    rwa [he,hrep] at ht
  by_cases h1 : k < 240
  · let z : Fin 120 := ⟨k-120, by omega⟩
    have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
    have ht := eightPoint141_120PackedAnchor0Part1 z
    rwa [he,hrep] at ht
  let z : Fin 3 := ⟨k-240, by omega⟩
  have he : (z.val : Int)+240 = k := by dsimp [z] <;> omega
  have ht := eightPoint141_120PackedAnchor0Part2 z
  rwa [he,hrep] at ht

private theorem packedOct141_120Anchor1 :
  ∀ j : Fin 487, ((j.val : Int)+141+120)%2=1 →
    2338671 ≤ FourPointNumeric.octPackedCharge 141 120 20 packedOct141_120_1 (j.val : Int) := by
  intro j hj
  let k := (j.val-0)/2
  have hk : k < 244 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+0 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint141_120PackedAnchor1Part0 z
    rwa [he,hrep] at ht
  by_cases h1 : k < 240
  · let z : Fin 120 := ⟨k-120, by omega⟩
    have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
    have ht := eightPoint141_120PackedAnchor1Part1 z
    rwa [he,hrep] at ht
  let z : Fin 4 := ⟨k-240, by omega⟩
  have he : (z.val : Int)+240 = k := by dsimp [z] <;> omega
  have ht := eightPoint141_120PackedAnchor1Part2 z
  rwa [he,hrep] at ht

def packedOctCertificate141_120_0 : EightPointCertificate 141 120 0 125754 :=
  eightPointCertificateOfPacked 141 120 0 125754 2339286 20 packedOct141_120_0 361 487
    (by decide +kernel) (by decide) packedOct141_120Anchor0
    (by rw [packedOct141_120_0_budget]; decide)

def packedOctCertificate141_120_1 : EightPointCertificate 141 120 1 125754 :=
  eightPointCertificateOfPacked 141 120 1 125754 2338671 20 packedOct141_120_1 268 487
    (by decide +kernel) (by decide) packedOct141_120Anchor1
    (by rw [packedOct141_120_1_budget]; decide)

theorem max148_second141_third120_eightPoint_moment_bound (tail : List ℕ) (len : tail.length=6)
    (distinct : (natSubsetSums (148::141::120::tail)).Nodup) :
    125754 ≤ ((148::141::120::tail).map (· ^ 2)).sum := by
  apply eightPointNatMomentLower 141 120 125754 tail len distinct
  intro p hp
  by_cases h : p=0
  · subst p
    exact packedOctCertificate141_120_0
  · have he : p=1 := hp.resolve_left h
    subst p
    exact packedOctCertificate141_120_1

#print axioms max148_second141_third120_eightPoint_moment_bound

end NineSeparatedSubsetSums
