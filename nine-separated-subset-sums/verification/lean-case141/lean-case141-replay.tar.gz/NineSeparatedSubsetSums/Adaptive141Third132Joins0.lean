import NineSeparatedSubsetSums.Adaptive141Third132State
import NineSeparatedSubsetSums.Adaptive141Third132Leaves0
import NineSeparatedSubsetSums.Adaptive141Third132Leaves3
import NineSeparatedSubsetSums.Adaptive141Third132Leaves2
import NineSeparatedSubsetSums.Adaptive141Third132Leaves1

namespace NineSeparatedSubsetSums

theorem adaptive141Third132Proof0 : runCachedNode 511 128536 Adaptive141Third132Node0 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 128536 Adaptive141Third132Node0 = [110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 126, 127, 128, 129, 130, 131] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive141Third132Proof1
  · exact adaptive141Third132Proof2
  · exact adaptive141Third132Proof3
  · exact adaptive141Third132Proof4
  · exact adaptive141Third132Proof5
  · exact adaptive141Third132Proof6
  · exact adaptive141Third132Proof7
  · exact adaptive141Third132Proof8
  · exact adaptive141Third132Proof9
  · exact adaptive141Third132Proof10
  · exact adaptive141Third132Proof11
  · exact adaptive141Third132Proof12
  · exact adaptive141Third132Proof13
  · exact adaptive141Third132Proof14
  · exact adaptive141Third132Proof15
  · exact adaptive141Third132Proof16
  · exact adaptive141Third132Proof17
  · exact adaptive141Third132Proof18
  · exact adaptive141Third132Proof19
  · exact adaptive141Third132Proof20
  · exact adaptive141Third132Proof21

#print axioms adaptive141Third132Proof0

end NineSeparatedSubsetSums
