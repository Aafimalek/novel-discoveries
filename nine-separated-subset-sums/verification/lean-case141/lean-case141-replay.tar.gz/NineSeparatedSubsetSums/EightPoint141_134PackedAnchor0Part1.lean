import NineSeparatedSubsetSums.EightPoint141_134PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint141_134PackedAnchor0Part1 :
    ∀ j : Fin 120, 2490789 ≤ FourPointNumeric.octPackedCharge 141 134 20 packedOct141_134_0
      (2*((j.val : Int)+120)+1) := by decide +kernel

end NineSeparatedSubsetSums
