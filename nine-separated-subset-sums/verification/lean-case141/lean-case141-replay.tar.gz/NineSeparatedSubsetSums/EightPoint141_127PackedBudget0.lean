import NineSeparatedSubsetSums.EightPoint141_127PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct141_127_0_budget :
    FourPointNumeric.packedBudget 20 packedOct141_127_0 435 = 86575248 := by decide +kernel

#print axioms packedOct141_127_0_budget

end NineSeparatedSubsetSums
