import NineSeparatedSubsetSums.Adaptive141Third140State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third140Proof228 : runCachedNode 511 129930 Adaptive141Third140Node228 = false := by
  decide +kernel

#print axioms adaptive141Third140Proof228

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third140Proof134 : runCachedNode 511 129930 Adaptive141Third140Node134 = false := by
  decide +kernel

#print axioms adaptive141Third140Proof134

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third140Proof273 : runCachedNode 511 129930 Adaptive141Third140Node273 = false := by
  decide +kernel

#print axioms adaptive141Third140Proof273

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third140Proof43 : runCachedNode 511 129930 Adaptive141Third140Node43 = false := by
  decide +kernel

#print axioms adaptive141Third140Proof43

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third140Proof15 : runCachedNode 511 129930 Adaptive141Third140Node15 = false := by
  decide +kernel

#print axioms adaptive141Third140Proof15

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third140Proof64 : runCachedNode 511 129930 Adaptive141Third140Node64 = false := by
  decide +kernel

#print axioms adaptive141Third140Proof64

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third140Proof109 : runCachedNode 511 129930 Adaptive141Third140Node109 = false := by
  decide +kernel

#print axioms adaptive141Third140Proof109

end NineSeparatedSubsetSums
