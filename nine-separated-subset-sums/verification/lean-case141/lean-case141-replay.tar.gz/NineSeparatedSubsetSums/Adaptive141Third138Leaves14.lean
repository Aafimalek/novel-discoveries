import NineSeparatedSubsetSums.Adaptive141Third138State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third138Proof100 : runCachedNode 511 129566 Adaptive141Third138Node100 = false := by
  decide +kernel

#print axioms adaptive141Third138Proof100

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third138Proof164 : runCachedNode 511 129566 Adaptive141Third138Node164 = false := by
  decide +kernel

#print axioms adaptive141Third138Proof164

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third138Proof12 : runCachedNode 511 129566 Adaptive141Third138Node12 = false := by
  decide +kernel

#print axioms adaptive141Third138Proof12

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third138Proof101 : runCachedNode 511 129566 Adaptive141Third138Node101 = false := by
  decide +kernel

#print axioms adaptive141Third138Proof101

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third138Proof195 : runCachedNode 511 129566 Adaptive141Third138Node195 = false := by
  decide +kernel

#print axioms adaptive141Third138Proof195

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third138Proof137 : runCachedNode 511 129566 Adaptive141Third138Node137 = false := by
  decide +kernel

#print axioms adaptive141Third138Proof137

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third138Proof68 : runCachedNode 511 129566 Adaptive141Third138Node68 = false := by
  decide +kernel

#print axioms adaptive141Third138Proof68

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third138Proof67 : runCachedNode 511 129566 Adaptive141Third138Node67 = false := by
  decide +kernel

#print axioms adaptive141Third138Proof67

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third138Proof6 : runCachedNode 511 129566 Adaptive141Third138Node6 = false := by
  decide +kernel

#print axioms adaptive141Third138Proof6

end NineSeparatedSubsetSums
