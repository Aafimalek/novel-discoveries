import NineSeparatedSubsetSums.EightPointPackedGeometry
import NineSeparatedSubsetSums.EightPoint141_140PackedBudget0
import NineSeparatedSubsetSums.EightPoint141_140PackedAnchor0Part0
import NineSeparatedSubsetSums.EightPoint141_140PackedAnchor0Part1
import NineSeparatedSubsetSums.EightPoint141_140PackedAnchor0Part2
import NineSeparatedSubsetSums.EightPoint141_140PackedBudget1
import NineSeparatedSubsetSums.EightPoint141_140PackedAnchor1Part0
import NineSeparatedSubsetSums.EightPoint141_140PackedAnchor1Part1
import NineSeparatedSubsetSums.EightPoint141_140PackedAnchor1Part2

namespace NineSeparatedSubsetSums

private theorem packedOct141_140Anchor0 :
  ∀ j : Fin 504, ((j.val : Int)+141+140)%2=0 →
    2519921 ≤ FourPointNumeric.octPackedCharge 141 140 20 packedOct141_140_0 (j.val : Int) := by
  intro j hj
  let k := (j.val-1)/2
  have hk : k < 252 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+1 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint141_140PackedAnchor0Part0 z
    rwa [he,hrep] at ht
  by_cases h1 : k < 240
  · let z : Fin 120 := ⟨k-120, by omega⟩
    have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
    have ht := eightPoint141_140PackedAnchor0Part1 z
    rwa [he,hrep] at ht
  let z : Fin 12 := ⟨k-240, by omega⟩
  have he : (z.val : Int)+240 = k := by dsimp [z] <;> omega
  have ht := eightPoint141_140PackedAnchor0Part2 z
  rwa [he,hrep] at ht

private theorem packedOct141_140Anchor1 :
  ∀ j : Fin 504, ((j.val : Int)+141+140)%2=1 →
    2520690 ≤ FourPointNumeric.octPackedCharge 141 140 20 packedOct141_140_1 (j.val : Int) := by
  intro j hj
  let k := (j.val-0)/2
  have hk : k < 252 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+0 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint141_140PackedAnchor1Part0 z
    rwa [he,hrep] at ht
  by_cases h1 : k < 240
  · let z : Fin 120 := ⟨k-120, by omega⟩
    have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
    have ht := eightPoint141_140PackedAnchor1Part1 z
    rwa [he,hrep] at ht
  let z : Fin 12 := ⟨k-240, by omega⟩
  have he : (z.val : Int)+240 = k := by dsimp [z] <;> omega
  have ht := eightPoint141_140PackedAnchor1Part2 z
  rwa [he,hrep] at ht

def packedOctCertificate141_140_0 : EightPointCertificate 141 140 0 129930 :=
  eightPointCertificateOfPacked 141 140 0 129930 2519921 20 packedOct141_140_0 271 504
    (by decide +kernel) (by decide) packedOct141_140Anchor0
    (by rw [packedOct141_140_0_budget]; decide)

def packedOctCertificate141_140_1 : EightPointCertificate 141 140 1 129930 :=
  eightPointCertificateOfPacked 141 140 1 129930 2520690 20 packedOct141_140_1 278 504
    (by decide +kernel) (by decide) packedOct141_140Anchor1
    (by rw [packedOct141_140_1_budget]; decide)

theorem max148_second141_third140_eightPoint_moment_bound (tail : List ℕ) (len : tail.length=6)
    (distinct : (natSubsetSums (148::141::140::tail)).Nodup) :
    129930 ≤ ((148::141::140::tail).map (· ^ 2)).sum := by
  apply eightPointNatMomentLower 141 140 129930 tail len distinct
  intro p hp
  by_cases h : p=0
  · subst p
    exact packedOctCertificate141_140_0
  · have he : p=1 := hp.resolve_left h
    subst p
    exact packedOctCertificate141_140_1

#print axioms max148_second141_third140_eightPoint_moment_bound

end NineSeparatedSubsetSums
