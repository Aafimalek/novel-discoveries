import NineSeparatedSubsetSums.Adaptive141Third134State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third134Proof16 : runCachedNode 511 128866 Adaptive141Third134Node16 = false := by
  decide +kernel

#print axioms adaptive141Third134Proof16

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third134Proof118 : runCachedNode 511 128866 Adaptive141Third134Node118 = false := by
  decide +kernel

#print axioms adaptive141Third134Proof118

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third134Proof87 : runCachedNode 511 128866 Adaptive141Third134Node87 = false := by
  decide +kernel

#print axioms adaptive141Third134Proof87

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third134Proof102 : runCachedNode 511 128866 Adaptive141Third134Node102 = false := by
  decide +kernel

#print axioms adaptive141Third134Proof102

end NineSeparatedSubsetSums
