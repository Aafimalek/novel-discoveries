import NineSeparatedSubsetSums.Adaptive141Third118State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third118Proof0 : runCachedNode 511 125354 Adaptive141Third118Node0 = false := by
  decide +kernel

#print axioms adaptive141Third118Proof0

end NineSeparatedSubsetSums
