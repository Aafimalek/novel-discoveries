import NineSeparatedSubsetSums.EightPoint141_139PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint141_139PackedAnchor1Part2 :
    ∀ j : Fin 11, 2503610 ≤ FourPointNumeric.octPackedCharge 141 139 20 packedOct141_139_1
      (2*((j.val : Int)+240)+1) := by decide +kernel

end NineSeparatedSubsetSums
