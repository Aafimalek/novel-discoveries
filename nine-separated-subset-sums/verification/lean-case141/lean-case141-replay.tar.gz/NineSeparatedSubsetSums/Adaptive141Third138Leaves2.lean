import NineSeparatedSubsetSums.Adaptive141Third138State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third138Proof168 : runCachedNode 511 129566 Adaptive141Third138Node168 = false := by
  decide +kernel

#print axioms adaptive141Third138Proof168

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third138Proof48 : runCachedNode 511 129566 Adaptive141Third138Node48 = false := by
  decide +kernel

#print axioms adaptive141Third138Proof48

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third138Proof35 : runCachedNode 511 129566 Adaptive141Third138Node35 = false := by
  decide +kernel

#print axioms adaptive141Third138Proof35

end NineSeparatedSubsetSums
