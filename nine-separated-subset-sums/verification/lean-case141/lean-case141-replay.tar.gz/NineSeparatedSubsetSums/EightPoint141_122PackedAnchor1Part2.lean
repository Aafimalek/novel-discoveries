import NineSeparatedSubsetSums.EightPoint141_122PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint141_122PackedAnchor1Part2 :
    ∀ j : Fin 1, 2307631 ≤ FourPointNumeric.octPackedCharge 141 122 20 packedOct141_122_1
      (2*((j.val : Int)+240)+0) := by decide +kernel

end NineSeparatedSubsetSums
