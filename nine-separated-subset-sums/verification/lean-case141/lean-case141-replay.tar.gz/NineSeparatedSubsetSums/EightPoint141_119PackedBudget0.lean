import NineSeparatedSubsetSums.EightPoint141_119PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct141_119_0_budget :
    FourPointNumeric.packedBudget 20 packedOct141_119_0 273 = 87461535 := by decide +kernel

#print axioms packedOct141_119_0_budget

end NineSeparatedSubsetSums
