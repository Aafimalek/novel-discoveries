import NineSeparatedSubsetSums.EightPoint141_127PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint141_127PackedAnchor1Part1 :
    ∀ j : Fin 120, 2372246 ≤ FourPointNumeric.octPackedCharge 141 127 20 packedOct141_127_1
      (2*((j.val : Int)+120)+1) := by decide +kernel

end NineSeparatedSubsetSums
