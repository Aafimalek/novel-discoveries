import NineSeparatedSubsetSums.Adaptive141Third137State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third137Proof21 : runCachedNode 511 129418 Adaptive141Third137Node21 = false := by
  decide +kernel

#print axioms adaptive141Third137Proof21

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third137Proof47 : runCachedNode 511 129418 Adaptive141Third137Node47 = false := by
  decide +kernel

#print axioms adaptive141Third137Proof47

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third137Proof31 : runCachedNode 511 129418 Adaptive141Third137Node31 = false := by
  decide +kernel

#print axioms adaptive141Third137Proof31

end NineSeparatedSubsetSums
