import NineSeparatedSubsetSums.EightPoint141_140PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint141_140PackedAnchor0Part0 :
    ∀ j : Fin 120, 2519921 ≤ FourPointNumeric.octPackedCharge 141 140 20 packedOct141_140_0
      (2*((j.val : Int)+0)+1) := by decide +kernel

end NineSeparatedSubsetSums
