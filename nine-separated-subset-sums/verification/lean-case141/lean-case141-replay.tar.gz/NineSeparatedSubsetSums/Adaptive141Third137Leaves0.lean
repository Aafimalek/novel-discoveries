import NineSeparatedSubsetSums.Adaptive141Third137State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third137Proof77 : runCachedNode 511 129418 Adaptive141Third137Node77 = false := by
  decide +kernel

#print axioms adaptive141Third137Proof77

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third137Proof43 : runCachedNode 511 129418 Adaptive141Third137Node43 = false := by
  decide +kernel

#print axioms adaptive141Third137Proof43

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third137Proof27 : runCachedNode 511 129418 Adaptive141Third137Node27 = false := by
  decide +kernel

#print axioms adaptive141Third137Proof27

end NineSeparatedSubsetSums
