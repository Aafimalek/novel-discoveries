import NineSeparatedSubsetSums.Adaptive141Third139State
import NineSeparatedSubsetSums.Adaptive141Third139Leaves17
import NineSeparatedSubsetSums.Adaptive141Third139Leaves22
import NineSeparatedSubsetSums.Adaptive141Third139Leaves21
import NineSeparatedSubsetSums.Adaptive141Third139Leaves10
import NineSeparatedSubsetSums.Adaptive141Third139Leaves1
import NineSeparatedSubsetSums.Adaptive141Third139Leaves20
import NineSeparatedSubsetSums.Adaptive141Third139Leaves19
import NineSeparatedSubsetSums.Adaptive141Third139Leaves16
import NineSeparatedSubsetSums.Adaptive141Third139Leaves8
import NineSeparatedSubsetSums.Adaptive141Third139Leaves12
import NineSeparatedSubsetSums.Adaptive141Third139Leaves13
import NineSeparatedSubsetSums.Adaptive141Third139Leaves3
import NineSeparatedSubsetSums.Adaptive141Third139Leaves4
import NineSeparatedSubsetSums.Adaptive141Third139Joins0
import NineSeparatedSubsetSums.Adaptive141Third139Leaves0

namespace NineSeparatedSubsetSums

theorem adaptive141Third139Proof0 : runCachedNode 511 129747 Adaptive141Third139Node0 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 129747 Adaptive141Third139Node0 = [110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 133, 134, 135, 136, 137, 138] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive141Third139Proof1
  · exact adaptive141Third139Proof2
  · exact adaptive141Third139Proof3
  · exact adaptive141Third139Proof4
  · exact adaptive141Third139Proof5
  · exact adaptive141Third139Proof6
  · exact adaptive141Third139Proof7
  · exact adaptive141Third139Proof8
  · exact adaptive141Third139Proof9
  · exact adaptive141Third139Proof10
  · exact adaptive141Third139Proof11
  · exact adaptive141Third139Proof12
  · exact adaptive141Third139Proof13
  · exact adaptive141Third139Proof14
  · exact adaptive141Third139Proof15
  · exact adaptive141Third139Proof16
  · exact adaptive141Third139Proof17
  · exact adaptive141Third139Proof18
  · exact adaptive141Third139Proof19
  · exact adaptive141Third139Proof20
  · exact adaptive141Third139Proof21
  · exact adaptive141Third139Proof45
  · exact adaptive141Third139Proof46
  · exact adaptive141Third139Proof73
  · exact adaptive141Third139Proof102
  · exact adaptive141Third139Proof131
  · exact adaptive141Third139Proof161
  · exact adaptive141Third139Proof228

#print axioms adaptive141Third139Proof0

end NineSeparatedSubsetSums
