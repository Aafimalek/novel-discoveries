import NineSeparatedSubsetSums.Adaptive141Third138State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third138Proof75 : runCachedNode 511 129566 Adaptive141Third138Node75 = false := by
  decide +kernel

#print axioms adaptive141Third138Proof75

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third138Proof104 : runCachedNode 511 129566 Adaptive141Third138Node104 = false := by
  decide +kernel

#print axioms adaptive141Third138Proof104

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third138Proof4 : runCachedNode 511 129566 Adaptive141Third138Node4 = false := by
  decide +kernel

#print axioms adaptive141Third138Proof4

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third138Proof107 : runCachedNode 511 129566 Adaptive141Third138Node107 = false := by
  decide +kernel

#print axioms adaptive141Third138Proof107

end NineSeparatedSubsetSums
