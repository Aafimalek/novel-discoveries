import NineSeparatedSubsetSums.Adaptive141Third111Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint141Checked

namespace NineSeparatedSubsetSums


theorem adaptive141Third111 : NoDescendingTailAfterThird 141 111 :=
  noDescendingThirdTail_of_cached 141 111 111653 (fun t ht nd => max148_second141_fourPoint_moment_bound (111::t) (by simp [ht]) nd) adaptive141Third111Proof0

#print axioms adaptive141Third111

end NineSeparatedSubsetSums
