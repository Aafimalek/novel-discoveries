import NineSeparatedSubsetSums.EightPoint141_121PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint141_121PackedAnchor1Part1 :
    ∀ j : Fin 120, 2300215 ≤ FourPointNumeric.octPackedCharge 141 121 20 packedOct141_121_1
      (2*((j.val : Int)+120)+1) := by decide +kernel

end NineSeparatedSubsetSums
