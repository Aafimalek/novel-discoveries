import NineSeparatedSubsetSums.Adaptive141Third136State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third136Proof127 : runCachedNode 511 129226 Adaptive141Third136Node127 = false := by
  decide +kernel

#print axioms adaptive141Third136Proof127

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third136Proof41 : runCachedNode 511 129226 Adaptive141Third136Node41 = false := by
  decide +kernel

#print axioms adaptive141Third136Proof41

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third136Proof69 : runCachedNode 511 129226 Adaptive141Third136Node69 = false := by
  decide +kernel

#print axioms adaptive141Third136Proof69

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third136Proof95 : runCachedNode 511 129226 Adaptive141Third136Node95 = false := by
  decide +kernel

#print axioms adaptive141Third136Proof95

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third136Proof12 : runCachedNode 511 129226 Adaptive141Third136Node12 = false := by
  decide +kernel

#print axioms adaptive141Third136Proof12

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third136Proof121 : runCachedNode 511 129226 Adaptive141Third136Node121 = false := by
  decide +kernel

#print axioms adaptive141Third136Proof121

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third136Proof90 : runCachedNode 511 129226 Adaptive141Third136Node90 = false := by
  decide +kernel

#print axioms adaptive141Third136Proof90

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third136Proof159 : runCachedNode 511 129226 Adaptive141Third136Node159 = false := by
  decide +kernel

#print axioms adaptive141Third136Proof159

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third136Proof42 : runCachedNode 511 129226 Adaptive141Third136Node42 = false := by
  decide +kernel

#print axioms adaptive141Third136Proof42

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third136Proof40 : runCachedNode 511 129226 Adaptive141Third136Node40 = false := by
  decide +kernel

#print axioms adaptive141Third136Proof40

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third136Proof26 : runCachedNode 511 129226 Adaptive141Third136Node26 = false := by
  decide +kernel

#print axioms adaptive141Third136Proof26

end NineSeparatedSubsetSums
