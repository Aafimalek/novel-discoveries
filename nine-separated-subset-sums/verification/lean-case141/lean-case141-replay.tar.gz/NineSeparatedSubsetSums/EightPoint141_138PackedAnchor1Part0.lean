import NineSeparatedSubsetSums.EightPoint141_138PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint141_138PackedAnchor1Part0 :
    ∀ j : Fin 120, 2495700 ≤ FourPointNumeric.octPackedCharge 141 138 20 packedOct141_138_1
      (2*((j.val : Int)+0)+0) := by decide +kernel

end NineSeparatedSubsetSums
