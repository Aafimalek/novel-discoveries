import NineSeparatedSubsetSums.Adaptive141Third111State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third111Proof0 : runCachedNode 511 111653 Adaptive141Third111Node0 = false := by
  decide +kernel

#print axioms adaptive141Third111Proof0

end NineSeparatedSubsetSums
