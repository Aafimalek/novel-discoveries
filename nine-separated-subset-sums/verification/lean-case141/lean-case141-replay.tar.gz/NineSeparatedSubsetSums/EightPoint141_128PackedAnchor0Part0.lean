import NineSeparatedSubsetSums.EightPoint141_128PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint141_128PackedAnchor0Part0 :
    ∀ j : Fin 120, 2374890 ≤ FourPointNumeric.octPackedCharge 141 128 20 packedOct141_128_0
      (2*((j.val : Int)+0)+1) := by decide +kernel

end NineSeparatedSubsetSums
