import NineSeparatedSubsetSums.Adaptive141Third130State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third130Proof16 : runCachedNode 511 128244 Adaptive141Third130Node16 = false := by
  decide +kernel

#print axioms adaptive141Third130Proof16

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third130Proof15 : runCachedNode 511 128244 Adaptive141Third130Node15 = false := by
  decide +kernel

#print axioms adaptive141Third130Proof15

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third130Proof13 : runCachedNode 511 128244 Adaptive141Third130Node13 = false := by
  decide +kernel

#print axioms adaptive141Third130Proof13

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third130Proof12 : runCachedNode 511 128244 Adaptive141Third130Node12 = false := by
  decide +kernel

#print axioms adaptive141Third130Proof12

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third130Proof11 : runCachedNode 511 128244 Adaptive141Third130Node11 = false := by
  decide +kernel

#print axioms adaptive141Third130Proof11

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third130Proof10 : runCachedNode 511 128244 Adaptive141Third130Node10 = false := by
  decide +kernel

#print axioms adaptive141Third130Proof10

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third130Proof8 : runCachedNode 511 128244 Adaptive141Third130Node8 = false := by
  decide +kernel

#print axioms adaptive141Third130Proof8

end NineSeparatedSubsetSums
