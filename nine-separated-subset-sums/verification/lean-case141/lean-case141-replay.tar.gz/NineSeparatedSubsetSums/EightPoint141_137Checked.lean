import NineSeparatedSubsetSums.EightPointPackedGeometry
import NineSeparatedSubsetSums.EightPoint141_137PackedBudget0
import NineSeparatedSubsetSums.EightPoint141_137PackedAnchor0Part0
import NineSeparatedSubsetSums.EightPoint141_137PackedAnchor0Part1
import NineSeparatedSubsetSums.EightPoint141_137PackedAnchor0Part2
import NineSeparatedSubsetSums.EightPoint141_137PackedBudget1
import NineSeparatedSubsetSums.EightPoint141_137PackedAnchor1Part0
import NineSeparatedSubsetSums.EightPoint141_137PackedAnchor1Part1
import NineSeparatedSubsetSums.EightPoint141_137PackedAnchor1Part2

namespace NineSeparatedSubsetSums

private theorem packedOct141_137Anchor0 :
  ∀ j : Fin 501, ((j.val : Int)+141+137)%2=0 →
    2485076 ≤ FourPointNumeric.octPackedCharge 141 137 20 packedOct141_137_0 (j.val : Int) := by
  intro j hj
  let k := (j.val-0)/2
  have hk : k < 251 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+0 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint141_137PackedAnchor0Part0 z
    rwa [he,hrep] at ht
  by_cases h1 : k < 240
  · let z : Fin 120 := ⟨k-120, by omega⟩
    have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
    have ht := eightPoint141_137PackedAnchor0Part1 z
    rwa [he,hrep] at ht
  let z : Fin 11 := ⟨k-240, by omega⟩
  have he : (z.val : Int)+240 = k := by dsimp [z] <;> omega
  have ht := eightPoint141_137PackedAnchor0Part2 z
  rwa [he,hrep] at ht

private theorem packedOct141_137Anchor1 :
  ∀ j : Fin 501, ((j.val : Int)+141+137)%2=1 →
    2485069 ≤ FourPointNumeric.octPackedCharge 141 137 20 packedOct141_137_1 (j.val : Int) := by
  intro j hj
  let k := (j.val-1)/2
  have hk : k < 250 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+1 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint141_137PackedAnchor1Part0 z
    rwa [he,hrep] at ht
  by_cases h1 : k < 240
  · let z : Fin 120 := ⟨k-120, by omega⟩
    have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
    have ht := eightPoint141_137PackedAnchor1Part1 z
    rwa [he,hrep] at ht
  let z : Fin 10 := ⟨k-240, by omega⟩
  have he : (z.val : Int)+240 = k := by dsimp [z] <;> omega
  have ht := eightPoint141_137PackedAnchor1Part2 z
  rwa [he,hrep] at ht

def packedOctCertificate141_137_0 : EightPointCertificate 141 137 0 129418 :=
  eightPointCertificateOfPacked 141 137 0 129418 2485076 20 packedOct141_137_0 397 501
    (by decide +kernel) (by decide) packedOct141_137Anchor0
    (by rw [packedOct141_137_0_budget]; decide)

def packedOctCertificate141_137_1 : EightPointCertificate 141 137 1 129418 :=
  eightPointCertificateOfPacked 141 137 1 129418 2485069 20 packedOct141_137_1 396 501
    (by decide +kernel) (by decide) packedOct141_137Anchor1
    (by rw [packedOct141_137_1_budget]; decide)

theorem max148_second141_third137_eightPoint_moment_bound (tail : List ℕ) (len : tail.length=6)
    (distinct : (natSubsetSums (148::141::137::tail)).Nodup) :
    129418 ≤ ((148::141::137::tail).map (· ^ 2)).sum := by
  apply eightPointNatMomentLower 141 137 129418 tail len distinct
  intro p hp
  by_cases h : p=0
  · subst p
    exact packedOctCertificate141_137_0
  · have he : p=1 := hp.resolve_left h
    subst p
    exact packedOctCertificate141_137_1

#print axioms max148_second141_third137_eightPoint_moment_bound

end NineSeparatedSubsetSums
