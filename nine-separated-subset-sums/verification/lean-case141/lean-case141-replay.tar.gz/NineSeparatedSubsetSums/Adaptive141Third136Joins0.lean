import NineSeparatedSubsetSums.Adaptive141Third136State
import NineSeparatedSubsetSums.Adaptive141Third136Leaves10
import NineSeparatedSubsetSums.Adaptive141Third136Leaves3
import NineSeparatedSubsetSums.Adaptive141Third136Leaves12
import NineSeparatedSubsetSums.Adaptive141Third136Leaves9
import NineSeparatedSubsetSums.Adaptive141Third136Leaves11
import NineSeparatedSubsetSums.Adaptive141Third136Leaves8
import NineSeparatedSubsetSums.Adaptive141Third136Leaves7
import NineSeparatedSubsetSums.Adaptive141Third136Leaves13
import NineSeparatedSubsetSums.Adaptive141Third136Leaves2
import NineSeparatedSubsetSums.Adaptive141Third136Leaves4
import NineSeparatedSubsetSums.Adaptive141Third136Leaves0
import NineSeparatedSubsetSums.Adaptive141Third136Leaves6
import NineSeparatedSubsetSums.Adaptive141Third136Leaves1
import NineSeparatedSubsetSums.Adaptive141Third136Leaves5

namespace NineSeparatedSubsetSums

theorem adaptive141Third136Proof21 : runCachedNode 511 129226 Adaptive141Third136Node21 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 129226 Adaptive141Third136Node21 = [104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 120, 121, 122, 123, 125, 127, 128, 130] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive141Third136Proof22
  · exact adaptive141Third136Proof23
  · exact adaptive141Third136Proof24
  · exact adaptive141Third136Proof25
  · exact adaptive141Third136Proof26
  · exact adaptive141Third136Proof27
  · exact adaptive141Third136Proof28
  · exact adaptive141Third136Proof29
  · exact adaptive141Third136Proof30
  · exact adaptive141Third136Proof31
  · exact adaptive141Third136Proof32
  · exact adaptive141Third136Proof33
  · exact adaptive141Third136Proof34
  · exact adaptive141Third136Proof35
  · exact adaptive141Third136Proof36
  · exact adaptive141Third136Proof37
  · exact adaptive141Third136Proof38
  · exact adaptive141Third136Proof39
  · exact adaptive141Third136Proof40
  · exact adaptive141Third136Proof41
  · exact adaptive141Third136Proof42
  · exact adaptive141Third136Proof43
  · exact adaptive141Third136Proof44

#print axioms adaptive141Third136Proof21

theorem adaptive141Third136Proof46 : runCachedNode 511 129226 Adaptive141Third136Node46 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 129226 Adaptive141Third136Node46 = [104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 122, 123, 124, 125, 127, 130, 131, 132] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive141Third136Proof47
  · exact adaptive141Third136Proof48
  · exact adaptive141Third136Proof49
  · exact adaptive141Third136Proof50
  · exact adaptive141Third136Proof51
  · exact adaptive141Third136Proof52
  · exact adaptive141Third136Proof53
  · exact adaptive141Third136Proof54
  · exact adaptive141Third136Proof55
  · exact adaptive141Third136Proof56
  · exact adaptive141Third136Proof57
  · exact adaptive141Third136Proof58
  · exact adaptive141Third136Proof59
  · exact adaptive141Third136Proof60
  · exact adaptive141Third136Proof61
  · exact adaptive141Third136Proof62
  · exact adaptive141Third136Proof63
  · exact adaptive141Third136Proof64
  · exact adaptive141Third136Proof65
  · exact adaptive141Third136Proof66
  · exact adaptive141Third136Proof67
  · exact adaptive141Third136Proof68
  · exact adaptive141Third136Proof69
  · exact adaptive141Third136Proof70
  · exact adaptive141Third136Proof71

#print axioms adaptive141Third136Proof46

theorem adaptive141Third136Proof72 : runCachedNode 511 129226 Adaptive141Third136Node72 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 129226 Adaptive141Third136Node72 = [103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 123, 124, 125, 126, 128, 130, 131, 132, 133] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive141Third136Proof73
  · exact adaptive141Third136Proof74
  · exact adaptive141Third136Proof75
  · exact adaptive141Third136Proof76
  · exact adaptive141Third136Proof77
  · exact adaptive141Third136Proof78
  · exact adaptive141Third136Proof79
  · exact adaptive141Third136Proof80
  · exact adaptive141Third136Proof81
  · exact adaptive141Third136Proof82
  · exact adaptive141Third136Proof83
  · exact adaptive141Third136Proof84
  · exact adaptive141Third136Proof85
  · exact adaptive141Third136Proof86
  · exact adaptive141Third136Proof87
  · exact adaptive141Third136Proof88
  · exact adaptive141Third136Proof89
  · exact adaptive141Third136Proof90
  · exact adaptive141Third136Proof91
  · exact adaptive141Third136Proof92
  · exact adaptive141Third136Proof93
  · exact adaptive141Third136Proof94
  · exact adaptive141Third136Proof95
  · exact adaptive141Third136Proof96
  · exact adaptive141Third136Proof97
  · exact adaptive141Third136Proof98
  · exact adaptive141Third136Proof99
  · exact adaptive141Third136Proof100

#print axioms adaptive141Third136Proof72

theorem adaptive141Third136Proof129 : runCachedNode 511 129226 Adaptive141Third136Node129 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 129226 Adaptive141Third136Node129 = [92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 117, 118, 119, 120, 124, 125, 131, 132] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive141Third136Proof130
  · exact adaptive141Third136Proof131
  · exact adaptive141Third136Proof132
  · exact adaptive141Third136Proof133
  · exact adaptive141Third136Proof134
  · exact adaptive141Third136Proof135
  · exact adaptive141Third136Proof136
  · exact adaptive141Third136Proof137
  · exact adaptive141Third136Proof138
  · exact adaptive141Third136Proof139
  · exact adaptive141Third136Proof140
  · exact adaptive141Third136Proof141
  · exact adaptive141Third136Proof142
  · exact adaptive141Third136Proof143
  · exact adaptive141Third136Proof144
  · exact adaptive141Third136Proof145
  · exact adaptive141Third136Proof146
  · exact adaptive141Third136Proof147
  · exact adaptive141Third136Proof148
  · exact adaptive141Third136Proof149
  · exact adaptive141Third136Proof150
  · exact adaptive141Third136Proof151
  · exact adaptive141Third136Proof152
  · exact adaptive141Third136Proof153
  · exact adaptive141Third136Proof154
  · exact adaptive141Third136Proof155
  · exact adaptive141Third136Proof156
  · exact adaptive141Third136Proof157
  · exact adaptive141Third136Proof158
  · exact adaptive141Third136Proof159
  · exact adaptive141Third136Proof160
  · exact adaptive141Third136Proof161

#print axioms adaptive141Third136Proof129

theorem adaptive141Third136Proof101 : runCachedNode 511 129226 Adaptive141Third136Node101 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 129226 Adaptive141Third136Node101 = [103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 124, 125, 126, 127, 131, 132, 133, 134] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive141Third136Proof102
  · exact adaptive141Third136Proof103
  · exact adaptive141Third136Proof104
  · exact adaptive141Third136Proof105
  · exact adaptive141Third136Proof106
  · exact adaptive141Third136Proof107
  · exact adaptive141Third136Proof108
  · exact adaptive141Third136Proof109
  · exact adaptive141Third136Proof110
  · exact adaptive141Third136Proof111
  · exact adaptive141Third136Proof112
  · exact adaptive141Third136Proof113
  · exact adaptive141Third136Proof114
  · exact adaptive141Third136Proof115
  · exact adaptive141Third136Proof116
  · exact adaptive141Third136Proof117
  · exact adaptive141Third136Proof118
  · exact adaptive141Third136Proof119
  · exact adaptive141Third136Proof120
  · exact adaptive141Third136Proof121
  · exact adaptive141Third136Proof122
  · exact adaptive141Third136Proof123
  · exact adaptive141Third136Proof124
  · exact adaptive141Third136Proof125
  · exact adaptive141Third136Proof126
  · exact adaptive141Third136Proof127
  · exact adaptive141Third136Proof128
  · exact adaptive141Third136Proof129

#print axioms adaptive141Third136Proof101

theorem adaptive141Third136Proof0 : runCachedNode 511 129226 Adaptive141Third136Node0 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 129226 Adaptive141Third136Node0 = [110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 130, 131, 132, 133, 134, 135] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive141Third136Proof1
  · exact adaptive141Third136Proof2
  · exact adaptive141Third136Proof3
  · exact adaptive141Third136Proof4
  · exact adaptive141Third136Proof5
  · exact adaptive141Third136Proof6
  · exact adaptive141Third136Proof7
  · exact adaptive141Third136Proof8
  · exact adaptive141Third136Proof9
  · exact adaptive141Third136Proof10
  · exact adaptive141Third136Proof11
  · exact adaptive141Third136Proof12
  · exact adaptive141Third136Proof13
  · exact adaptive141Third136Proof14
  · exact adaptive141Third136Proof15
  · exact adaptive141Third136Proof16
  · exact adaptive141Third136Proof17
  · exact adaptive141Third136Proof18
  · exact adaptive141Third136Proof19
  · exact adaptive141Third136Proof20
  · exact adaptive141Third136Proof21
  · exact adaptive141Third136Proof45
  · exact adaptive141Third136Proof46
  · exact adaptive141Third136Proof72
  · exact adaptive141Third136Proof101

#print axioms adaptive141Third136Proof0

end NineSeparatedSubsetSums
