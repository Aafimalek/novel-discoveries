import NineSeparatedSubsetSums.Adaptive141Third139State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third139Proof158 : runCachedNode 511 129747 Adaptive141Third139Node158 = false := by
  decide +kernel

#print axioms adaptive141Third139Proof158

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third139Proof98 : runCachedNode 511 129747 Adaptive141Third139Node98 = false := by
  decide +kernel

#print axioms adaptive141Third139Proof98

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third139Proof80 : runCachedNode 511 129747 Adaptive141Third139Node80 = false := by
  decide +kernel

#print axioms adaptive141Third139Proof80

end NineSeparatedSubsetSums
