import NineSeparatedSubsetSums.EightPoint141_122PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct141_122_0_budget :
    FourPointNumeric.packedBudget 20 packedOct141_122_0 279 = 83102519 := by decide +kernel

#print axioms packedOct141_122_0_budget

end NineSeparatedSubsetSums
