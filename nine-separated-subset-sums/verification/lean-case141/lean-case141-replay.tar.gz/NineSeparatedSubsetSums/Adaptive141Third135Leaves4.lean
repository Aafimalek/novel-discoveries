import NineSeparatedSubsetSums.Adaptive141Third135State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third135Proof96 : runCachedNode 511 129079 Adaptive141Third135Node96 = false := by
  decide +kernel

#print axioms adaptive141Third135Proof96

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third135Proof98 : runCachedNode 511 129079 Adaptive141Third135Node98 = false := by
  decide +kernel

#print axioms adaptive141Third135Proof98

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third135Proof41 : runCachedNode 511 129079 Adaptive141Third135Node41 = false := by
  decide +kernel

#print axioms adaptive141Third135Proof41

end NineSeparatedSubsetSums
