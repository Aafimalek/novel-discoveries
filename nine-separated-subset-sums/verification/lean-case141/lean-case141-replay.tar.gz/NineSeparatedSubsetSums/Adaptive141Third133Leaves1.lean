import NineSeparatedSubsetSums.Adaptive141Third133State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third133Proof20 : runCachedNode 511 128708 Adaptive141Third133Node20 = false := by
  decide +kernel

#print axioms adaptive141Third133Proof20

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third133Proof18 : runCachedNode 511 128708 Adaptive141Third133Node18 = false := by
  decide +kernel

#print axioms adaptive141Third133Proof18

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third133Proof36 : runCachedNode 511 128708 Adaptive141Third133Node36 = false := by
  decide +kernel

#print axioms adaptive141Third133Proof36

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third133Proof32 : runCachedNode 511 128708 Adaptive141Third133Node32 = false := by
  decide +kernel

#print axioms adaptive141Third133Proof32

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third133Proof24 : runCachedNode 511 128708 Adaptive141Third133Node24 = false := by
  decide +kernel

#print axioms adaptive141Third133Proof24

end NineSeparatedSubsetSums
