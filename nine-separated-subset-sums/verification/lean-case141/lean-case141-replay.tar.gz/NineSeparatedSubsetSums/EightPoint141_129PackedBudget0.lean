import NineSeparatedSubsetSums.EightPoint141_129PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct141_129_0_budget :
    FourPointNumeric.packedBudget 20 packedOct141_129_0 269 = 87091559 := by decide +kernel

#print axioms packedOct141_129_0_budget

end NineSeparatedSubsetSums
