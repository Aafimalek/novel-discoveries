import NineSeparatedSubsetSums.Adaptive141Third107Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint141Checked

namespace NineSeparatedSubsetSums


theorem adaptive141Third107 : NoDescendingTailAfterThird 141 107 :=
  noDescendingThirdTail_of_cached 141 107 111653 (fun t ht nd => max148_second141_fourPoint_moment_bound (107::t) (by simp [ht]) nd) adaptive141Third107Proof0

#print axioms adaptive141Third107

end NineSeparatedSubsetSums
