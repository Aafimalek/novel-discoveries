import NineSeparatedSubsetSums.EightPointPackedGeometry
import NineSeparatedSubsetSums.EightPoint141_136PackedBudget0
import NineSeparatedSubsetSums.EightPoint141_136PackedAnchor0Part0
import NineSeparatedSubsetSums.EightPoint141_136PackedAnchor0Part1
import NineSeparatedSubsetSums.EightPoint141_136PackedAnchor0Part2
import NineSeparatedSubsetSums.EightPoint141_136PackedBudget1
import NineSeparatedSubsetSums.EightPoint141_136PackedAnchor1Part0
import NineSeparatedSubsetSums.EightPoint141_136PackedAnchor1Part1
import NineSeparatedSubsetSums.EightPoint141_136PackedAnchor1Part2

namespace NineSeparatedSubsetSums

private theorem packedOct141_136Anchor0 :
  ∀ j : Fin 500, ((j.val : Int)+141+136)%2=0 →
    2478358 ≤ FourPointNumeric.octPackedCharge 141 136 20 packedOct141_136_0 (j.val : Int) := by
  intro j hj
  let k := (j.val-1)/2
  have hk : k < 250 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+1 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint141_136PackedAnchor0Part0 z
    rwa [he,hrep] at ht
  by_cases h1 : k < 240
  · let z : Fin 120 := ⟨k-120, by omega⟩
    have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
    have ht := eightPoint141_136PackedAnchor0Part1 z
    rwa [he,hrep] at ht
  let z : Fin 10 := ⟨k-240, by omega⟩
  have he : (z.val : Int)+240 = k := by dsimp [z] <;> omega
  have ht := eightPoint141_136PackedAnchor0Part2 z
  rwa [he,hrep] at ht

private theorem packedOct141_136Anchor1 :
  ∀ j : Fin 500, ((j.val : Int)+141+136)%2=1 →
    2478224 ≤ FourPointNumeric.octPackedCharge 141 136 20 packedOct141_136_1 (j.val : Int) := by
  intro j hj
  let k := (j.val-0)/2
  have hk : k < 250 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+0 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint141_136PackedAnchor1Part0 z
    rwa [he,hrep] at ht
  by_cases h1 : k < 240
  · let z : Fin 120 := ⟨k-120, by omega⟩
    have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
    have ht := eightPoint141_136PackedAnchor1Part1 z
    rwa [he,hrep] at ht
  let z : Fin 10 := ⟨k-240, by omega⟩
  have he : (z.val : Int)+240 = k := by dsimp [z] <;> omega
  have ht := eightPoint141_136PackedAnchor1Part2 z
  rwa [he,hrep] at ht

def packedOctCertificate141_136_0 : EightPointCertificate 141 136 0 129226 :=
  eightPointCertificateOfPacked 141 136 0 129226 2478358 20 packedOct141_136_0 437 500
    (by decide +kernel) (by decide) packedOct141_136Anchor0
    (by rw [packedOct141_136_0_budget]; decide)

def packedOctCertificate141_136_1 : EightPointCertificate 141 136 1 129226 :=
  eightPointCertificateOfPacked 141 136 1 129226 2478224 20 packedOct141_136_1 434 500
    (by decide +kernel) (by decide) packedOct141_136Anchor1
    (by rw [packedOct141_136_1_budget]; decide)

theorem max148_second141_third136_eightPoint_moment_bound (tail : List ℕ) (len : tail.length=6)
    (distinct : (natSubsetSums (148::141::136::tail)).Nodup) :
    129226 ≤ ((148::141::136::tail).map (· ^ 2)).sum := by
  apply eightPointNatMomentLower 141 136 129226 tail len distinct
  intro p hp
  by_cases h : p=0
  · subst p
    exact packedOctCertificate141_136_0
  · have he : p=1 := hp.resolve_left h
    subst p
    exact packedOctCertificate141_136_1

#print axioms max148_second141_third136_eightPoint_moment_bound

end NineSeparatedSubsetSums
