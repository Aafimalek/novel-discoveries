import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive141Third112Node0 : CachedSearchNode :=
  ⟨4, 111, computeCenteredMask [148,141,112], 401, 54329⟩

end NineSeparatedSubsetSums
