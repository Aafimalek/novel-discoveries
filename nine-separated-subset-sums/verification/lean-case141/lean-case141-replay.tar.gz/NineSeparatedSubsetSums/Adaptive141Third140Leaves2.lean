import NineSeparatedSubsetSums.Adaptive141Third140State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third140Proof135 : runCachedNode 511 129930 Adaptive141Third140Node135 = false := by
  decide +kernel

#print axioms adaptive141Third140Proof135

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third140Proof132 : runCachedNode 511 129930 Adaptive141Third140Node132 = false := by
  decide +kernel

#print axioms adaptive141Third140Proof132

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third140Proof86 : runCachedNode 511 129930 Adaptive141Third140Node86 = false := by
  decide +kernel

#print axioms adaptive141Third140Proof86

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third140Proof1 : runCachedNode 511 129930 Adaptive141Third140Node1 = false := by
  decide +kernel

#print axioms adaptive141Third140Proof1

end NineSeparatedSubsetSums
