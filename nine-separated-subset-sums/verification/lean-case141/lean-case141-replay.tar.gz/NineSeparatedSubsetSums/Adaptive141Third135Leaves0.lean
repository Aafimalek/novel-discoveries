import NineSeparatedSubsetSums.Adaptive141Third135State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third135Proof100 : runCachedNode 511 129079 Adaptive141Third135Node100 = false := by
  decide +kernel

#print axioms adaptive141Third135Proof100

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third135Proof71 : runCachedNode 511 129079 Adaptive141Third135Node71 = false := by
  decide +kernel

#print axioms adaptive141Third135Proof71

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third135Proof39 : runCachedNode 511 129079 Adaptive141Third135Node39 = false := by
  decide +kernel

#print axioms adaptive141Third135Proof39

end NineSeparatedSubsetSums
