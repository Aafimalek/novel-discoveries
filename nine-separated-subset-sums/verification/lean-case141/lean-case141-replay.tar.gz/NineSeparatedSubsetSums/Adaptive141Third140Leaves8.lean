import NineSeparatedSubsetSums.Adaptive141Third140State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third140Proof233 : runCachedNode 511 129930 Adaptive141Third140Node233 = false := by
  decide +kernel

#print axioms adaptive141Third140Proof233

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third140Proof16 : runCachedNode 511 129930 Adaptive141Third140Node16 = false := by
  decide +kernel

#print axioms adaptive141Third140Proof16

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third140Proof124 : runCachedNode 511 129930 Adaptive141Third140Node124 = false := by
  decide +kernel

#print axioms adaptive141Third140Proof124

end NineSeparatedSubsetSums
