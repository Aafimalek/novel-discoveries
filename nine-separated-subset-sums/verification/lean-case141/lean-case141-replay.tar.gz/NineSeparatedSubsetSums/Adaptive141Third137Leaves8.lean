import NineSeparatedSubsetSums.Adaptive141Third137State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third137Proof20 : runCachedNode 511 129418 Adaptive141Third137Node20 = false := by
  decide +kernel

#print axioms adaptive141Third137Proof20

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third137Proof135 : runCachedNode 511 129418 Adaptive141Third137Node135 = false := by
  decide +kernel

#print axioms adaptive141Third137Proof135

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third137Proof61 : runCachedNode 511 129418 Adaptive141Third137Node61 = false := by
  decide +kernel

#print axioms adaptive141Third137Proof61

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third137Proof1 : runCachedNode 511 129418 Adaptive141Third137Node1 = false := by
  decide +kernel

#print axioms adaptive141Third137Proof1

end NineSeparatedSubsetSums
