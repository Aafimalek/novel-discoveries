import NineSeparatedSubsetSums.Adaptive141Third105Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint141Checked

namespace NineSeparatedSubsetSums


theorem adaptive141Third105 : NoDescendingTailAfterThird 141 105 :=
  noDescendingThirdTail_of_cached 141 105 111653 (fun t ht nd => max148_second141_fourPoint_moment_bound (105::t) (by simp [ht]) nd) adaptive141Third105Proof0

#print axioms adaptive141Third105

end NineSeparatedSubsetSums
