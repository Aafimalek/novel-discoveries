import NineSeparatedSubsetSums.Adaptive141Third106Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint141Checked

namespace NineSeparatedSubsetSums


theorem adaptive141Third106 : NoDescendingTailAfterThird 141 106 :=
  noDescendingThirdTail_of_cached 141 106 111653 (fun t ht nd => max148_second141_fourPoint_moment_bound (106::t) (by simp [ht]) nd) adaptive141Third106Proof0

#print axioms adaptive141Third106

end NineSeparatedSubsetSums
