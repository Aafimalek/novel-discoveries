import NineSeparatedSubsetSums.Adaptive141Third139State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third139Proof128 : runCachedNode 511 129747 Adaptive141Third139Node128 = false := by
  decide +kernel

#print axioms adaptive141Third139Proof128

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third139Proof256 : runCachedNode 511 129747 Adaptive141Third139Node256 = false := by
  decide +kernel

#print axioms adaptive141Third139Proof256

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third139Proof44 : runCachedNode 511 129747 Adaptive141Third139Node44 = false := by
  decide +kernel

#print axioms adaptive141Third139Proof44

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third139Proof52 : runCachedNode 511 129747 Adaptive141Third139Node52 = false := by
  decide +kernel

#print axioms adaptive141Third139Proof52

end NineSeparatedSubsetSums
