import NineSeparatedSubsetSums.Adaptive141Third137State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third137Proof134 : runCachedNode 511 129418 Adaptive141Third137Node134 = false := by
  decide +kernel

#print axioms adaptive141Third137Proof134

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third137Proof72 : runCachedNode 511 129418 Adaptive141Third137Node72 = false := by
  decide +kernel

#print axioms adaptive141Third137Proof72

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third137Proof123 : runCachedNode 511 129418 Adaptive141Third137Node123 = false := by
  decide +kernel

#print axioms adaptive141Third137Proof123

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive141Third137Proof79 : runCachedNode 511 129418 Adaptive141Third137Node79 = false := by
  decide +kernel

#print axioms adaptive141Third137Proof79

end NineSeparatedSubsetSums
