import NineSeparatedSubsetSums.Adaptive126Third115Joins0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint126Checked

namespace NineSeparatedSubsetSums


theorem adaptive126Third115 : NoDescendingTailAfterThird 126 115 :=
  noDescendingThirdTail_of_cached 126 115 109252 (fun t ht nd => max148_second126_fourPoint_moment_bound (115::t) (by simp [ht]) nd) adaptive126Third115Proof0

#print axioms adaptive126Third115

end NineSeparatedSubsetSums
