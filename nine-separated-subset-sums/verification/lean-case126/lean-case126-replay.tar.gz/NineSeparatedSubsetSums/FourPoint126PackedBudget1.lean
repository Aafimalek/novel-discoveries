import NineSeparatedSubsetSums.FourPoint126PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedWeight126_1_budget :
    FourPointNumeric.packedBudget 20 packedWeight126_1 354 = 86311680 := by decide +kernel

#print axioms packedWeight126_1_budget

end NineSeparatedSubsetSums
