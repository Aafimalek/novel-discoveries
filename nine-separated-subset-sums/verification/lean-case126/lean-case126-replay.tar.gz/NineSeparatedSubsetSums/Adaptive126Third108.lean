import NineSeparatedSubsetSums.Adaptive126Third108Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint126Checked

namespace NineSeparatedSubsetSums


theorem adaptive126Third108 : NoDescendingTailAfterThird 126 108 :=
  noDescendingThirdTail_of_cached 126 108 109252 (fun t ht nd => max148_second126_fourPoint_moment_bound (108::t) (by simp [ht]) nd) adaptive126Third108Proof0

#print axioms adaptive126Third108

end NineSeparatedSubsetSums
