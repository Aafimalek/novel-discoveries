import NineSeparatedSubsetSums.Adaptive126Third113Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint126Checked

namespace NineSeparatedSubsetSums


theorem adaptive126Third113 : NoDescendingTailAfterThird 126 113 :=
  noDescendingThirdTail_of_cached 126 113 109252 (fun t ht nd => max148_second126_fourPoint_moment_bound (113::t) (by simp [ht]) nd) adaptive126Third113Proof0

#print axioms adaptive126Third113

end NineSeparatedSubsetSums
