import NineSeparatedSubsetSums.EightPointPackedGeometry
import NineSeparatedSubsetSums.EightPoint126_119PackedBudget0
import NineSeparatedSubsetSums.EightPoint126_119PackedAnchor0Part0
import NineSeparatedSubsetSums.EightPoint126_119PackedAnchor0Part1
import NineSeparatedSubsetSums.EightPoint126_119PackedBudget1
import NineSeparatedSubsetSums.EightPoint126_119PackedAnchor1Part0
import NineSeparatedSubsetSums.EightPoint126_119PackedAnchor1Part1

namespace NineSeparatedSubsetSums

private theorem packedOct126_119Anchor0 :
  ∀ j : Fin 470, ((j.val : Int)+126+119)%2=0 →
    2182083 ≤ FourPointNumeric.octPackedCharge 126 119 20 packedOct126_119_0 (j.val : Int) := by
  intro j hj
  let k := (j.val-1)/2
  have hk : k < 235 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+1 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint126_119PackedAnchor0Part0 z
    rwa [he,hrep] at ht
  let z : Fin 115 := ⟨k-120, by omega⟩
  have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
  have ht := eightPoint126_119PackedAnchor0Part1 z
  rwa [he,hrep] at ht

private theorem packedOct126_119Anchor1 :
  ∀ j : Fin 470, ((j.val : Int)+126+119)%2=1 →
    2181205 ≤ FourPointNumeric.octPackedCharge 126 119 20 packedOct126_119_1 (j.val : Int) := by
  intro j hj
  let k := (j.val-0)/2
  have hk : k < 235 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+0 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint126_119PackedAnchor1Part0 z
    rwa [he,hrep] at ht
  let z : Fin 115 := ⟨k-120, by omega⟩
  have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
  have ht := eightPoint126_119PackedAnchor1Part1 z
  rwa [he,hrep] at ht

def packedOctCertificate126_119_0 : EightPointCertificate 126 119 0 122676 :=
  eightPointCertificateOfPacked 126 119 0 122676 2182083 20 packedOct126_119_0 271 470
    (by decide +kernel) (by decide) packedOct126_119Anchor0
    (by rw [packedOct126_119_0_budget]; decide)

def packedOctCertificate126_119_1 : EightPointCertificate 126 119 1 122676 :=
  eightPointCertificateOfPacked 126 119 1 122676 2181205 20 packedOct126_119_1 270 470
    (by decide +kernel) (by decide) packedOct126_119Anchor1
    (by rw [packedOct126_119_1_budget]; decide)

theorem max148_second126_third119_eightPoint_moment_bound (tail : List ℕ) (len : tail.length=6)
    (distinct : (natSubsetSums (148::126::119::tail)).Nodup) :
    122676 ≤ ((148::126::119::tail).map (· ^ 2)).sum := by
  apply eightPointNatMomentLower 126 119 122676 tail len distinct
  intro p hp
  by_cases h : p=0
  · subst p
    exact packedOctCertificate126_119_0
  · have he : p=1 := hp.resolve_left h
    subst p
    exact packedOctCertificate126_119_1

#print axioms max148_second126_third119_eightPoint_moment_bound

end NineSeparatedSubsetSums
