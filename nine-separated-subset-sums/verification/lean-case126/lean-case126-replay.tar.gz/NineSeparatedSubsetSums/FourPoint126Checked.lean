import NineSeparatedSubsetSums.FourPointPackedGeometry
import NineSeparatedSubsetSums.FourPoint126PackedBudget0
import NineSeparatedSubsetSums.FourPoint126PackedAnchor0Part0
import NineSeparatedSubsetSums.FourPoint126PackedAnchor0Part1
import NineSeparatedSubsetSums.FourPoint126PackedAnchor0Part2
import NineSeparatedSubsetSums.FourPoint126PackedBudget1
import NineSeparatedSubsetSums.FourPoint126PackedAnchor1Part0
import NineSeparatedSubsetSums.FourPoint126PackedAnchor1Part1
import NineSeparatedSubsetSums.FourPoint126PackedAnchor1Part2

namespace NineSeparatedSubsetSums

private theorem packed126Anchor0 :
  ∀ j : Fin 491, ((j.val : Int)+126)%2=0 →
    1111568 ≤ FourPointNumeric.packedCharge 126 20 packedWeight126_0 (j.val : Int) := by
  intro j hj
  let k := (j.val-0)/2
  have hk : k < 246 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+0 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := fourPoint126PackedAnchor0Part0 z
    rwa [he,hrep] at ht
  by_cases h1 : k < 240
  · let z : Fin 120 := ⟨k-120, by omega⟩
    have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
    have ht := fourPoint126PackedAnchor0Part1 z
    rwa [he,hrep] at ht
  let z : Fin 6 := ⟨k-240, by omega⟩
  have he : (z.val : Int)+240 = k := by dsimp [z] <;> omega
  have ht := fourPoint126PackedAnchor0Part2 z
  rwa [he,hrep] at ht

private theorem packed126Anchor1 :
  ∀ j : Fin 491, ((j.val : Int)+126)%2=1 →
    1111316 ≤ FourPointNumeric.packedCharge 126 20 packedWeight126_1 (j.val : Int) := by
  intro j hj
  let k := (j.val-1)/2
  have hk : k < 245 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+1 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := fourPoint126PackedAnchor1Part0 z
    rwa [he,hrep] at ht
  by_cases h1 : k < 240
  · let z : Fin 120 := ⟨k-120, by omega⟩
    have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
    have ht := fourPoint126PackedAnchor1Part1 z
    rwa [he,hrep] at ht
  let z : Fin 5 := ⟨k-240, by omega⟩
  have he : (z.val : Int)+240 = k := by dsimp [z] <;> omega
  have ht := fourPoint126PackedAnchor1Part2 z
  rwa [he,hrep] at ht

def packedCertificate126_0 : FourPointCertificate 126 0 109252 :=
  fourPointCertificateOfPacked 126 0 109252 1111568 20 packedWeight126_0 645 491
    (by decide +kernel) (by decide) (by decide) packed126Anchor0
    (by rw [packedWeight126_0_budget]; decide)

def packedCertificate126_1 : FourPointCertificate 126 1 109252 :=
  fourPointCertificateOfPacked 126 1 109252 1111316 20 packedWeight126_1 354 491
    (by decide +kernel) (by decide) (by decide) packed126Anchor1
    (by rw [packedWeight126_1_budget]; decide)

theorem max148_second126_fourPoint_moment_bound (tail : List ℕ) (len : tail.length=7)
    (distinct : (natSubsetSums (148::126::tail)).Nodup) :
    109252 ≤ ((148::126::tail).map (· ^ 2)).sum := by
  apply fourPointNatMomentLower 126 109252 tail len distinct
  intro p hp
  by_cases h : p=0
  · subst p
    exact packedCertificate126_0
  · have he : p=1 := hp.resolve_left h
    subst p
    exact packedCertificate126_1

#print axioms max148_second126_fourPoint_moment_bound

end NineSeparatedSubsetSums
