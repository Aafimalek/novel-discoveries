import NineSeparatedSubsetSums.EightPoint126_123PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct126_123_1_budget :
    FourPointNumeric.packedBudget 20 packedOct126_123_1 378 = 84961622 := by decide +kernel

#print axioms packedOct126_123_1_budget

end NineSeparatedSubsetSums
