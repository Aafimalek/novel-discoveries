import NineSeparatedSubsetSums.Adaptive126Third120State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive126Third120Proof0 : runCachedNode 511 122890 Adaptive126Third120Node0 = false := by
  decide +kernel

#print axioms adaptive126Third120Proof0

end NineSeparatedSubsetSums
