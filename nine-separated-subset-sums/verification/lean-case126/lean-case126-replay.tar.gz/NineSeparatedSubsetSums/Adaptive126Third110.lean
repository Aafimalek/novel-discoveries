import NineSeparatedSubsetSums.Adaptive126Third110Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint126Checked

namespace NineSeparatedSubsetSums


theorem adaptive126Third110 : NoDescendingTailAfterThird 126 110 :=
  noDescendingThirdTail_of_cached 126 110 109252 (fun t ht nd => max148_second126_fourPoint_moment_bound (110::t) (by simp [ht]) nd) adaptive126Third110Proof0

#print axioms adaptive126Third110

end NineSeparatedSubsetSums
