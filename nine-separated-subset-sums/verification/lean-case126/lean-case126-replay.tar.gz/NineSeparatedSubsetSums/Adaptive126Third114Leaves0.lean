import NineSeparatedSubsetSums.Adaptive126Third114State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive126Third114Proof12 : runCachedNode 511 109252 Adaptive126Third114Node12 = false := by
  decide +kernel

#print axioms adaptive126Third114Proof12

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive126Third114Proof11 : runCachedNode 511 109252 Adaptive126Third114Node11 = false := by
  decide +kernel

#print axioms adaptive126Third114Proof11

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive126Third114Proof10 : runCachedNode 511 109252 Adaptive126Third114Node10 = false := by
  decide +kernel

#print axioms adaptive126Third114Proof10

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive126Third114Proof9 : runCachedNode 511 109252 Adaptive126Third114Node9 = false := by
  decide +kernel

#print axioms adaptive126Third114Proof9

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive126Third114Proof8 : runCachedNode 511 109252 Adaptive126Third114Node8 = false := by
  decide +kernel

#print axioms adaptive126Third114Proof8

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive126Third114Proof7 : runCachedNode 511 109252 Adaptive126Third114Node7 = false := by
  decide +kernel

#print axioms adaptive126Third114Proof7

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive126Third114Proof6 : runCachedNode 511 109252 Adaptive126Third114Node6 = false := by
  decide +kernel

#print axioms adaptive126Third114Proof6

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive126Third114Proof1 : runCachedNode 511 109252 Adaptive126Third114Node1 = false := by
  decide +kernel

#print axioms adaptive126Third114Proof1

end NineSeparatedSubsetSums
