import NineSeparatedSubsetSums.Adaptive126Third116State
import NineSeparatedSubsetSums.Adaptive126Third116Leaves0
import NineSeparatedSubsetSums.Adaptive126Third116Leaves1

namespace NineSeparatedSubsetSums

theorem adaptive126Third116Proof0 : runCachedNode 511 109252 Adaptive126Third116Node0 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 109252 Adaptive126Third116Node0 = [101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive126Third116Proof1
  · exact adaptive126Third116Proof2
  · exact adaptive126Third116Proof3
  · exact adaptive126Third116Proof4
  · exact adaptive126Third116Proof5
  · exact adaptive126Third116Proof6
  · exact adaptive126Third116Proof7
  · exact adaptive126Third116Proof8
  · exact adaptive126Third116Proof9
  · exact adaptive126Third116Proof10
  · exact adaptive126Third116Proof11
  · exact adaptive126Third116Proof12
  · exact adaptive126Third116Proof13
  · exact adaptive126Third116Proof14
  · exact adaptive126Third116Proof15

#print axioms adaptive126Third116Proof0

end NineSeparatedSubsetSums
