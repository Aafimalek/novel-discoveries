import NineSeparatedSubsetSums.EightPointPackedGeometry
import NineSeparatedSubsetSums.EightPoint126_122PackedBudget0
import NineSeparatedSubsetSums.EightPoint126_122PackedAnchor0Part0
import NineSeparatedSubsetSums.EightPoint126_122PackedAnchor0Part1
import NineSeparatedSubsetSums.EightPoint126_122PackedAnchor0Part2
import NineSeparatedSubsetSums.EightPoint126_122PackedBudget1
import NineSeparatedSubsetSums.EightPoint126_122PackedAnchor1Part0
import NineSeparatedSubsetSums.EightPoint126_122PackedAnchor1Part1
import NineSeparatedSubsetSums.EightPoint126_122PackedAnchor1Part2

namespace NineSeparatedSubsetSums

private theorem packedOct126_122Anchor0 :
  ∀ j : Fin 488, ((j.val : Int)+126+122)%2=0 →
    2323280 ≤ FourPointNumeric.octPackedCharge 126 122 20 packedOct126_122_0 (j.val : Int) := by
  intro j hj
  let k := (j.val-0)/2
  have hk : k < 244 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+0 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint126_122PackedAnchor0Part0 z
    rwa [he,hrep] at ht
  by_cases h1 : k < 240
  · let z : Fin 120 := ⟨k-120, by omega⟩
    have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
    have ht := eightPoint126_122PackedAnchor0Part1 z
    rwa [he,hrep] at ht
  let z : Fin 4 := ⟨k-240, by omega⟩
  have he : (z.val : Int)+240 = k := by dsimp [z] <;> omega
  have ht := eightPoint126_122PackedAnchor0Part2 z
  rwa [he,hrep] at ht

private theorem packedOct126_122Anchor1 :
  ∀ j : Fin 488, ((j.val : Int)+126+122)%2=1 →
    2324031 ≤ FourPointNumeric.octPackedCharge 126 122 20 packedOct126_122_1 (j.val : Int) := by
  intro j hj
  let k := (j.val-1)/2
  have hk : k < 244 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+1 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint126_122PackedAnchor1Part0 z
    rwa [he,hrep] at ht
  by_cases h1 : k < 240
  · let z : Fin 120 := ⟨k-120, by omega⟩
    have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
    have ht := eightPoint126_122PackedAnchor1Part1 z
    rwa [he,hrep] at ht
  let z : Fin 4 := ⟨k-240, by omega⟩
  have he : (z.val : Int)+240 = k := by dsimp [z] <;> omega
  have ht := eightPoint126_122PackedAnchor1Part2 z
  rwa [he,hrep] at ht

def packedOctCertificate126_122_0 : EightPointCertificate 126 122 0 123464 :=
  eightPointCertificateOfPacked 126 122 0 123464 2323280 20 packedOct126_122_0 389 488
    (by decide +kernel) (by decide) packedOct126_122Anchor0
    (by rw [packedOct126_122_0_budget]; decide)

def packedOctCertificate126_122_1 : EightPointCertificate 126 122 1 123464 :=
  eightPointCertificateOfPacked 126 122 1 123464 2324031 20 packedOct126_122_1 386 488
    (by decide +kernel) (by decide) packedOct126_122Anchor1
    (by rw [packedOct126_122_1_budget]; decide)

theorem max148_second126_third122_eightPoint_moment_bound (tail : List ℕ) (len : tail.length=6)
    (distinct : (natSubsetSums (148::126::122::tail)).Nodup) :
    123464 ≤ ((148::126::122::tail).map (· ^ 2)).sum := by
  apply eightPointNatMomentLower 126 122 123464 tail len distinct
  intro p hp
  by_cases h : p=0
  · subst p
    exact packedOctCertificate126_122_0
  · have he : p=1 := hp.resolve_left h
    subst p
    exact packedOctCertificate126_122_1

#print axioms max148_second126_third122_eightPoint_moment_bound

end NineSeparatedSubsetSums
