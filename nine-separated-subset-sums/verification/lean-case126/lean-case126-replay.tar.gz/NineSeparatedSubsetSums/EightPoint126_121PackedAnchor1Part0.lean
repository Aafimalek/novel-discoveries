import NineSeparatedSubsetSums.EightPoint126_121PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint126_121PackedAnchor1Part0 :
    ∀ j : Fin 120, 2309377 ≤ FourPointNumeric.octPackedCharge 126 121 20 packedOct126_121_1
      (2*((j.val : Int)+0)+0) := by decide +kernel

end NineSeparatedSubsetSums
