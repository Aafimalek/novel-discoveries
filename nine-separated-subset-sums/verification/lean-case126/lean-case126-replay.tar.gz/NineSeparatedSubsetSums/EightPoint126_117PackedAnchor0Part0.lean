import NineSeparatedSubsetSums.EightPoint126_117PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint126_117PackedAnchor0Part0 :
    ∀ j : Fin 120, 2207925 ≤ FourPointNumeric.octPackedCharge 126 117 20 packedOct126_117_0
      (2*((j.val : Int)+0)+1) := by decide +kernel

end NineSeparatedSubsetSums
