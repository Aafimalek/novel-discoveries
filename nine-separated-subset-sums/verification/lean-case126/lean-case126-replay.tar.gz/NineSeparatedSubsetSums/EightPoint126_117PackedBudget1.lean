import NineSeparatedSubsetSums.EightPoint126_117PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct126_117_1_budget :
    FourPointNumeric.packedBudget 20 packedOct126_117_1 264 = 78759636 := by decide +kernel

#print axioms packedOct126_117_1_budget

end NineSeparatedSubsetSums
