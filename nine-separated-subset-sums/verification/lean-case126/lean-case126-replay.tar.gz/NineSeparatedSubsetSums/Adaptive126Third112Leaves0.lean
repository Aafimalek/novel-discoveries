import NineSeparatedSubsetSums.Adaptive126Third112State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive126Third112Proof0 : runCachedNode 511 109252 Adaptive126Third112Node0 = false := by
  decide +kernel

#print axioms adaptive126Third112Proof0

end NineSeparatedSubsetSums
