import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive126Third114Node0 : CachedSearchNode :=
  ⟨4, 113, computeCenteredMask [148,126,114], 388, 50776⟩
def Adaptive126Third114Node1 : CachedSearchNode := cachedChild Adaptive126Third114Node0 102
def Adaptive126Third114Node2 : CachedSearchNode := cachedChild Adaptive126Third114Node0 103
def Adaptive126Third114Node3 : CachedSearchNode := cachedChild Adaptive126Third114Node0 104
def Adaptive126Third114Node4 : CachedSearchNode := cachedChild Adaptive126Third114Node0 105
def Adaptive126Third114Node5 : CachedSearchNode := cachedChild Adaptive126Third114Node0 106
def Adaptive126Third114Node6 : CachedSearchNode := cachedChild Adaptive126Third114Node0 107
def Adaptive126Third114Node7 : CachedSearchNode := cachedChild Adaptive126Third114Node0 108
def Adaptive126Third114Node8 : CachedSearchNode := cachedChild Adaptive126Third114Node0 109
def Adaptive126Third114Node9 : CachedSearchNode := cachedChild Adaptive126Third114Node0 110
def Adaptive126Third114Node10 : CachedSearchNode := cachedChild Adaptive126Third114Node0 111
def Adaptive126Third114Node11 : CachedSearchNode := cachedChild Adaptive126Third114Node0 112
def Adaptive126Third114Node12 : CachedSearchNode := cachedChild Adaptive126Third114Node0 113

end NineSeparatedSubsetSums
