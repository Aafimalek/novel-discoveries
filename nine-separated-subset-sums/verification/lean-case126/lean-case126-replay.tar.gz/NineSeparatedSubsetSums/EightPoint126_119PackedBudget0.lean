import NineSeparatedSubsetSums.EightPoint126_119PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct126_119_0_budget :
    FourPointNumeric.packedBudget 20 packedOct126_119_0 271 = 76843271 := by decide +kernel

#print axioms packedOct126_119_0_budget

end NineSeparatedSubsetSums
