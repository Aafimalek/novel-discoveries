import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive126Third119Node0 : CachedSearchNode :=
  ⟨4, 118, computeCenteredMask [148,126,119], 393, 51941⟩

end NineSeparatedSubsetSums
