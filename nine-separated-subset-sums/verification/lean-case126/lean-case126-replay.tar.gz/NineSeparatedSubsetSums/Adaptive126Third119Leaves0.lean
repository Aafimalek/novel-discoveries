import NineSeparatedSubsetSums.Adaptive126Third119State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive126Third119Proof0 : runCachedNode 511 122676 Adaptive126Third119Node0 = false := by
  decide +kernel

#print axioms adaptive126Third119Proof0

end NineSeparatedSubsetSums
