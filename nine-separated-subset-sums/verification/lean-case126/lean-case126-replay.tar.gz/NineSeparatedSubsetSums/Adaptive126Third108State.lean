import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive126Third108Node0 : CachedSearchNode :=
  ⟨4, 107, computeCenteredMask [148,126,108], 382, 49444⟩

end NineSeparatedSubsetSums
