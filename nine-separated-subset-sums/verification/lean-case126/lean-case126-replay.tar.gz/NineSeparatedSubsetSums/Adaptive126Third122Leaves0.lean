import NineSeparatedSubsetSums.Adaptive126Third122State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive126Third122Proof0 : runCachedNode 511 123464 Adaptive126Third122Node0 = false := by
  decide +kernel

#print axioms adaptive126Third122Proof0

end NineSeparatedSubsetSums
