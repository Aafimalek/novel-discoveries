import NineSeparatedSubsetSums.EightPoint126_122PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint126_122PackedAnchor1Part1 :
    ∀ j : Fin 120, 2324031 ≤ FourPointNumeric.octPackedCharge 126 122 20 packedOct126_122_1
      (2*((j.val : Int)+120)+1) := by decide +kernel

end NineSeparatedSubsetSums
