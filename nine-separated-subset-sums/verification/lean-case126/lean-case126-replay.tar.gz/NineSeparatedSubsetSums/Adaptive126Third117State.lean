import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive126Third117Node0 : CachedSearchNode :=
  ⟨4, 116, computeCenteredMask [148,126,117], 391, 51469⟩

end NineSeparatedSubsetSums
