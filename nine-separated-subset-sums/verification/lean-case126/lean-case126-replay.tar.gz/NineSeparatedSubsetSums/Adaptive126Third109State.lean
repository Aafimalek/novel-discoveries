import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive126Third109Node0 : CachedSearchNode :=
  ⟨4, 108, computeCenteredMask [148,126,109], 383, 49661⟩

end NineSeparatedSubsetSums
