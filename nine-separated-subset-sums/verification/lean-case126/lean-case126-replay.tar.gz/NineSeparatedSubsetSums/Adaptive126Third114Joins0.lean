import NineSeparatedSubsetSums.Adaptive126Third114State
import NineSeparatedSubsetSums.Adaptive126Third114Leaves0
import NineSeparatedSubsetSums.Adaptive126Third114Leaves1

namespace NineSeparatedSubsetSums

theorem adaptive126Third114Proof0 : runCachedNode 511 109252 Adaptive126Third114Node0 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 109252 Adaptive126Third114Node0 = [102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive126Third114Proof1
  · exact adaptive126Third114Proof2
  · exact adaptive126Third114Proof3
  · exact adaptive126Third114Proof4
  · exact adaptive126Third114Proof5
  · exact adaptive126Third114Proof6
  · exact adaptive126Third114Proof7
  · exact adaptive126Third114Proof8
  · exact adaptive126Third114Proof9
  · exact adaptive126Third114Proof10
  · exact adaptive126Third114Proof11
  · exact adaptive126Third114Proof12

#print axioms adaptive126Third114Proof0

end NineSeparatedSubsetSums
