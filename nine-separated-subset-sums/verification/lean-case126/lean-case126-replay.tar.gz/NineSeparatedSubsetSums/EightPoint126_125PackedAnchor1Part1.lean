import NineSeparatedSubsetSums.EightPoint126_125PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint126_125PackedAnchor1Part1 :
    ∀ j : Fin 120, 2333409 ≤ FourPointNumeric.octPackedCharge 126 125 20 packedOct126_125_1
      (2*((j.val : Int)+120)+0) := by decide +kernel

end NineSeparatedSubsetSums
