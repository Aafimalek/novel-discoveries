import NineSeparatedSubsetSums.EightPoint126_117PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct126_117_0_budget :
    FourPointNumeric.packedBudget 20 packedOct126_117_0 259 = 78688153 := by decide +kernel

#print axioms packedOct126_117_0_budget

end NineSeparatedSubsetSums
