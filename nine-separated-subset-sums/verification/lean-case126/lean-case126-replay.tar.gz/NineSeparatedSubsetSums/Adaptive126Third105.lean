import NineSeparatedSubsetSums.Adaptive126Third105Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint126Checked

namespace NineSeparatedSubsetSums


theorem adaptive126Third105 : NoDescendingTailAfterThird 126 105 :=
  noDescendingThirdTail_of_cached 126 105 109252 (fun t ht nd => max148_second126_fourPoint_moment_bound (105::t) (by simp [ht]) nd) adaptive126Third105Proof0

#print axioms adaptive126Third105

end NineSeparatedSubsetSums
