import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive126Third124Node0 : CachedSearchNode :=
  ⟨4, 123, computeCenteredMask [148,126,124], 398, 53156⟩

end NineSeparatedSubsetSums
