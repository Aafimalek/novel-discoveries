import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive126Third105Node0 : CachedSearchNode :=
  ⟨4, 104, computeCenteredMask [148,126,105], 379, 48805⟩

end NineSeparatedSubsetSums
