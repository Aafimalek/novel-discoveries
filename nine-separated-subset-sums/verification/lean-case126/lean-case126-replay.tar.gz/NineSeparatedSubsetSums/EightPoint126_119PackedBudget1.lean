import NineSeparatedSubsetSums.EightPoint126_119PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct126_119_1_budget :
    FourPointNumeric.packedBudget 20 packedOct126_119_1 270 = 76786888 := by decide +kernel

#print axioms packedOct126_119_1_budget

end NineSeparatedSubsetSums
