import NineSeparatedSubsetSums.FourPoint126PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedWeight126_0_budget :
    FourPointNumeric.packedBudget 20 packedWeight126_0 645 = 86343424 := by decide +kernel

#print axioms packedWeight126_0_budget

end NineSeparatedSubsetSums
