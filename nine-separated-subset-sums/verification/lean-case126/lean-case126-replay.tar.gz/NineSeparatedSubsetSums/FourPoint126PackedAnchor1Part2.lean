import NineSeparatedSubsetSums.FourPoint126PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem fourPoint126PackedAnchor1Part2 :
    ∀ j : Fin 5, 1111316 ≤ FourPointNumeric.packedCharge 126 20 packedWeight126_1
      (2*((j.val : Int)+240)+1) := by decide +kernel

end NineSeparatedSubsetSums
