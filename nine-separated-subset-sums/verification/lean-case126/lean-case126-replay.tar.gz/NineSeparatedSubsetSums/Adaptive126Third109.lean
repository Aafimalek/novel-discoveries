import NineSeparatedSubsetSums.Adaptive126Third109Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint126Checked

namespace NineSeparatedSubsetSums


theorem adaptive126Third109 : NoDescendingTailAfterThird 126 109 :=
  noDescendingThirdTail_of_cached 126 109 109252 (fun t ht nd => max148_second126_fourPoint_moment_bound (109::t) (by simp [ht]) nd) adaptive126Third109Proof0

#print axioms adaptive126Third109

end NineSeparatedSubsetSums
