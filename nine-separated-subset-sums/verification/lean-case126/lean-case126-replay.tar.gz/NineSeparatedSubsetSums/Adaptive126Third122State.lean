import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive126Third122Node0 : CachedSearchNode :=
  ⟨4, 121, computeCenteredMask [148,126,122], 396, 52664⟩

end NineSeparatedSubsetSums
