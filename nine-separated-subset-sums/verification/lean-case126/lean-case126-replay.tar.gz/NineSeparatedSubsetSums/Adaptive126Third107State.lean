import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive126Third107Node0 : CachedSearchNode :=
  ⟨4, 106, computeCenteredMask [148,126,107], 381, 49229⟩

end NineSeparatedSubsetSums
