import NineSeparatedSubsetSums.Adaptive126Third123State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive126Third123Proof0 : runCachedNode 511 123685 Adaptive126Third123Node0 = false := by
  decide +kernel

#print axioms adaptive126Third123Proof0

end NineSeparatedSubsetSums
