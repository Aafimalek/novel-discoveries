import NineSeparatedSubsetSums.EightPoint126_124PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint126_124PackedAnchor1Part2 :
    ∀ j : Fin 5, 2348399 ≤ FourPointNumeric.octPackedCharge 126 124 20 packedOct126_124_1
      (2*((j.val : Int)+240)+1) := by decide +kernel

end NineSeparatedSubsetSums
