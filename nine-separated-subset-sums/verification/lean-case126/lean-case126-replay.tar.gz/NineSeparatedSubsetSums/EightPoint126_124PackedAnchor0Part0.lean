import NineSeparatedSubsetSums.EightPoint126_124PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint126_124PackedAnchor0Part0 :
    ∀ j : Fin 120, 2349143 ≤ FourPointNumeric.octPackedCharge 126 124 20 packedOct126_124_0
      (2*((j.val : Int)+0)+0) := by decide +kernel

end NineSeparatedSubsetSums
