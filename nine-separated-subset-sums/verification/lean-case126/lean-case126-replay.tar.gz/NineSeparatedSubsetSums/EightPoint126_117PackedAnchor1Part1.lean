import NineSeparatedSubsetSums.EightPoint126_117PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint126_117PackedAnchor1Part1 :
    ∀ j : Fin 117, 2209042 ≤ FourPointNumeric.octPackedCharge 126 117 20 packedOct126_117_1
      (2*((j.val : Int)+120)+0) := by decide +kernel

end NineSeparatedSubsetSums
