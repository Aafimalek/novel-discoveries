import NineSeparatedSubsetSums.EightPoint126_124PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct126_124_0_budget :
    FourPointNumeric.packedBudget 20 packedOct126_124_0 387 = 86901852 := by decide +kernel

#print axioms packedOct126_124_0_budget

end NineSeparatedSubsetSums
