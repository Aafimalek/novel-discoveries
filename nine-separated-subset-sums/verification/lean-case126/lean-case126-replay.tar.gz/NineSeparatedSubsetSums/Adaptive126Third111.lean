import NineSeparatedSubsetSums.Adaptive126Third111Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint126Checked

namespace NineSeparatedSubsetSums


theorem adaptive126Third111 : NoDescendingTailAfterThird 126 111 :=
  noDescendingThirdTail_of_cached 126 111 109252 (fun t ht nd => max148_second126_fourPoint_moment_bound (111::t) (by simp [ht]) nd) adaptive126Third111Proof0

#print axioms adaptive126Third111

end NineSeparatedSubsetSums
