import NineSeparatedSubsetSums.EightPoint126_122PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct126_122_1_budget :
    FourPointNumeric.packedBudget 20 packedOct126_122_1 386 = 85524766 := by decide +kernel

#print axioms packedOct126_122_1_budget

end NineSeparatedSubsetSums
