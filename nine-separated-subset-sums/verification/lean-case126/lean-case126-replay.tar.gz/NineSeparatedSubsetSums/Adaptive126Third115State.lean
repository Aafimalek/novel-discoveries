import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive126Third115Node0 : CachedSearchNode :=
  ⟨4, 114, computeCenteredMask [148,126,115], 389, 51005⟩
def Adaptive126Third115Node1 : CachedSearchNode := cachedChild Adaptive126Third115Node0 102
def Adaptive126Third115Node2 : CachedSearchNode := cachedChild Adaptive126Third115Node0 103
def Adaptive126Third115Node3 : CachedSearchNode := cachedChild Adaptive126Third115Node0 104
def Adaptive126Third115Node4 : CachedSearchNode := cachedChild Adaptive126Third115Node0 105
def Adaptive126Third115Node5 : CachedSearchNode := cachedChild Adaptive126Third115Node0 106
def Adaptive126Third115Node6 : CachedSearchNode := cachedChild Adaptive126Third115Node0 107
def Adaptive126Third115Node7 : CachedSearchNode := cachedChild Adaptive126Third115Node0 108
def Adaptive126Third115Node8 : CachedSearchNode := cachedChild Adaptive126Third115Node0 109
def Adaptive126Third115Node9 : CachedSearchNode := cachedChild Adaptive126Third115Node0 110
def Adaptive126Third115Node10 : CachedSearchNode := cachedChild Adaptive126Third115Node0 111
def Adaptive126Third115Node11 : CachedSearchNode := cachedChild Adaptive126Third115Node0 112
def Adaptive126Third115Node12 : CachedSearchNode := cachedChild Adaptive126Third115Node0 113
def Adaptive126Third115Node13 : CachedSearchNode := cachedChild Adaptive126Third115Node0 114

end NineSeparatedSubsetSums
