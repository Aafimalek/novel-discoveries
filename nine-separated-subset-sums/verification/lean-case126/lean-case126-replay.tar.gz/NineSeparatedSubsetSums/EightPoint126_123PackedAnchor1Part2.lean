import NineSeparatedSubsetSums.EightPoint126_123PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint126_123PackedAnchor1Part2 :
    ∀ j : Fin 4, 2317005 ≤ FourPointNumeric.octPackedCharge 126 123 20 packedOct126_123_1
      (2*((j.val : Int)+240)+0) := by decide +kernel

end NineSeparatedSubsetSums
