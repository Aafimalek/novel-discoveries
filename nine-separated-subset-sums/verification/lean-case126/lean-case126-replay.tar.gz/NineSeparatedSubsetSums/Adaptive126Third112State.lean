import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive126Third112Node0 : CachedSearchNode :=
  ⟨4, 111, computeCenteredMask [148,126,112], 386, 50324⟩

end NineSeparatedSubsetSums
