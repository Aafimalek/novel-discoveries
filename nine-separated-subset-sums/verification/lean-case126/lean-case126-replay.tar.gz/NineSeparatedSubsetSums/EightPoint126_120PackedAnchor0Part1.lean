import NineSeparatedSubsetSums.EightPoint126_120PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint126_120PackedAnchor0Part1 :
    ∀ j : Fin 119, 2234409 ≤ FourPointNumeric.octPackedCharge 126 120 20 packedOct126_120_0
      (2*((j.val : Int)+120)+0) := by decide +kernel

end NineSeparatedSubsetSums
