import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive126Third110Node0 : CachedSearchNode :=
  ⟨4, 109, computeCenteredMask [148,126,110], 384, 49880⟩

end NineSeparatedSubsetSums
