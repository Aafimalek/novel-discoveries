import NineSeparatedSubsetSums.Adaptive126Third124State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive126Third124Proof0 : runCachedNode 511 123913 Adaptive126Third124Node0 = false := by
  decide +kernel

#print axioms adaptive126Third124Proof0

end NineSeparatedSubsetSums
