import NineSeparatedSubsetSums.FourPoint126PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem fourPoint126PackedAnchor0Part2 :
    ∀ j : Fin 6, 1111568 ≤ FourPointNumeric.packedCharge 126 20 packedWeight126_0
      (2*((j.val : Int)+240)+0) := by decide +kernel

end NineSeparatedSubsetSums
