import NineSeparatedSubsetSums.Adaptive126Third118State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive126Third118Proof0 : runCachedNode 511 122478 Adaptive126Third118Node0 = false := by
  decide +kernel

#print axioms adaptive126Third118Proof0

end NineSeparatedSubsetSums
