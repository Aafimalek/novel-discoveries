import NineSeparatedSubsetSums.Adaptive126Third121State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive126Third121Proof0 : runCachedNode 511 123176 Adaptive126Third121Node0 = false := by
  decide +kernel

#print axioms adaptive126Third121Proof0

end NineSeparatedSubsetSums
