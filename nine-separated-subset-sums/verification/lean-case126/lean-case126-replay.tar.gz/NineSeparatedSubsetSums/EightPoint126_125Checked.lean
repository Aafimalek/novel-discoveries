import NineSeparatedSubsetSums.EightPointPackedGeometry
import NineSeparatedSubsetSums.EightPoint126_125PackedBudget0
import NineSeparatedSubsetSums.EightPoint126_125PackedAnchor0Part0
import NineSeparatedSubsetSums.EightPoint126_125PackedAnchor0Part1
import NineSeparatedSubsetSums.EightPoint126_125PackedAnchor0Part2
import NineSeparatedSubsetSums.EightPoint126_125PackedBudget1
import NineSeparatedSubsetSums.EightPoint126_125PackedAnchor1Part0
import NineSeparatedSubsetSums.EightPoint126_125PackedAnchor1Part1
import NineSeparatedSubsetSums.EightPoint126_125PackedAnchor1Part2

namespace NineSeparatedSubsetSums

private theorem packedOct126_125Anchor0 :
  ∀ j : Fin 489, ((j.val : Int)+126+125)%2=0 →
    2332502 ≤ FourPointNumeric.octPackedCharge 126 125 20 packedOct126_125_0 (j.val : Int) := by
  intro j hj
  let k := (j.val-1)/2
  have hk : k < 244 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+1 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint126_125PackedAnchor0Part0 z
    rwa [he,hrep] at ht
  by_cases h1 : k < 240
  · let z : Fin 120 := ⟨k-120, by omega⟩
    have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
    have ht := eightPoint126_125PackedAnchor0Part1 z
    rwa [he,hrep] at ht
  let z : Fin 4 := ⟨k-240, by omega⟩
  have he : (z.val : Int)+240 = k := by dsimp [z] <;> omega
  have ht := eightPoint126_125PackedAnchor0Part2 z
  rwa [he,hrep] at ht

private theorem packedOct126_125Anchor1 :
  ∀ j : Fin 489, ((j.val : Int)+126+125)%2=1 →
    2333409 ≤ FourPointNumeric.octPackedCharge 126 125 20 packedOct126_125_1 (j.val : Int) := by
  intro j hj
  let k := (j.val-0)/2
  have hk : k < 245 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+0 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint126_125PackedAnchor1Part0 z
    rwa [he,hrep] at ht
  by_cases h1 : k < 240
  · let z : Fin 120 := ⟨k-120, by omega⟩
    have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
    have ht := eightPoint126_125PackedAnchor1Part1 z
    rwa [he,hrep] at ht
  let z : Fin 5 := ⟨k-240, by omega⟩
  have he : (z.val : Int)+240 = k := by dsimp [z] <;> omega
  have ht := eightPoint126_125PackedAnchor1Part2 z
  rwa [he,hrep] at ht

def packedOctCertificate126_125_0 : EightPointCertificate 126 125 0 124134 :=
  eightPointCertificateOfPacked 126 125 0 124134 2332502 20 packedOct126_125_0 393 489
    (by decide +kernel) (by decide) packedOct126_125Anchor0
    (by rw [packedOct126_125_0_budget]; decide)

def packedOctCertificate126_125_1 : EightPointCertificate 126 125 1 124134 :=
  eightPointCertificateOfPacked 126 125 1 124134 2333409 20 packedOct126_125_1 392 489
    (by decide +kernel) (by decide) packedOct126_125Anchor1
    (by rw [packedOct126_125_1_budget]; decide)

theorem max148_second126_third125_eightPoint_moment_bound (tail : List ℕ) (len : tail.length=6)
    (distinct : (natSubsetSums (148::126::125::tail)).Nodup) :
    124134 ≤ ((148::126::125::tail).map (· ^ 2)).sum := by
  apply eightPointNatMomentLower 126 125 124134 tail len distinct
  intro p hp
  by_cases h : p=0
  · subst p
    exact packedOctCertificate126_125_0
  · have he : p=1 := hp.resolve_left h
    subst p
    exact packedOctCertificate126_125_1

#print axioms max148_second126_third125_eightPoint_moment_bound

end NineSeparatedSubsetSums
