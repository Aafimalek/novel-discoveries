import NineSeparatedSubsetSums.Adaptive126Third106Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint126Checked

namespace NineSeparatedSubsetSums


theorem adaptive126Third106 : NoDescendingTailAfterThird 126 106 :=
  noDescendingThirdTail_of_cached 126 106 109252 (fun t ht nd => max148_second126_fourPoint_moment_bound (106::t) (by simp [ht]) nd) adaptive126Third106Proof0

#print axioms adaptive126Third106

end NineSeparatedSubsetSums
