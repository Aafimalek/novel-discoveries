import NineSeparatedSubsetSums.EightPoint126_118PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint126_118PackedAnchor1Part1 :
    ∀ j : Fin 115, 2178176 ≤ FourPointNumeric.octPackedCharge 126 118 20 packedOct126_118_1
      (2*((j.val : Int)+120)+1) := by decide +kernel

end NineSeparatedSubsetSums
