import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive126Third121Node0 : CachedSearchNode :=
  ⟨4, 120, computeCenteredMask [148,126,121], 395, 52421⟩

end NineSeparatedSubsetSums
