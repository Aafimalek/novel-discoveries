import NineSeparatedSubsetSums.EightPointPackedGeometry
import NineSeparatedSubsetSums.EightPoint126_118PackedBudget0
import NineSeparatedSubsetSums.EightPoint126_118PackedAnchor0Part0
import NineSeparatedSubsetSums.EightPoint126_118PackedAnchor0Part1
import NineSeparatedSubsetSums.EightPoint126_118PackedBudget1
import NineSeparatedSubsetSums.EightPoint126_118PackedAnchor1Part0
import NineSeparatedSubsetSums.EightPoint126_118PackedAnchor1Part1

namespace NineSeparatedSubsetSums

private theorem packedOct126_118Anchor0 :
  ∀ j : Fin 470, ((j.val : Int)+126+118)%2=0 →
    2180365 ≤ FourPointNumeric.octPackedCharge 126 118 20 packedOct126_118_0 (j.val : Int) := by
  intro j hj
  let k := (j.val-0)/2
  have hk : k < 235 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+0 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint126_118PackedAnchor0Part0 z
    rwa [he,hrep] at ht
  let z : Fin 115 := ⟨k-120, by omega⟩
  have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
  have ht := eightPoint126_118PackedAnchor0Part1 z
  rwa [he,hrep] at ht

private theorem packedOct126_118Anchor1 :
  ∀ j : Fin 470, ((j.val : Int)+126+118)%2=1 →
    2178176 ≤ FourPointNumeric.octPackedCharge 126 118 20 packedOct126_118_1 (j.val : Int) := by
  intro j hj
  let k := (j.val-1)/2
  have hk : k < 235 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+1 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint126_118PackedAnchor1Part0 z
    rwa [he,hrep] at ht
  let z : Fin 115 := ⟨k-120, by omega⟩
  have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
  have ht := eightPoint126_118PackedAnchor1Part1 z
  rwa [he,hrep] at ht

def packedOctCertificate126_118_0 : EightPointCertificate 126 118 0 122478 :=
  eightPointCertificateOfPacked 126 118 0 122478 2180365 20 packedOct126_118_0 259 470
    (by decide +kernel) (by decide) packedOct126_118Anchor0
    (by rw [packedOct126_118_0_budget]; decide)

def packedOctCertificate126_118_1 : EightPointCertificate 126 118 1 122478 :=
  eightPointCertificateOfPacked 126 118 1 122478 2178176 20 packedOct126_118_1 262 470
    (by decide +kernel) (by decide) packedOct126_118Anchor1
    (by rw [packedOct126_118_1_budget]; decide)

theorem max148_second126_third118_eightPoint_moment_bound (tail : List ℕ) (len : tail.length=6)
    (distinct : (natSubsetSums (148::126::118::tail)).Nodup) :
    122478 ≤ ((148::126::118::tail).map (· ^ 2)).sum := by
  apply eightPointNatMomentLower 126 118 122478 tail len distinct
  intro p hp
  by_cases h : p=0
  · subst p
    exact packedOctCertificate126_118_0
  · have he : p=1 := hp.resolve_left h
    subst p
    exact packedOctCertificate126_118_1

#print axioms max148_second126_third118_eightPoint_moment_bound

end NineSeparatedSubsetSums
