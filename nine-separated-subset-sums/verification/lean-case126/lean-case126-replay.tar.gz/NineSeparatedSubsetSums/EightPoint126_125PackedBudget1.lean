import NineSeparatedSubsetSums.EightPoint126_125PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct126_125_1_budget :
    FourPointNumeric.packedBudget 20 packedOct126_125_1 392 = 85781456 := by decide +kernel

#print axioms packedOct126_125_1_budget

end NineSeparatedSubsetSums
