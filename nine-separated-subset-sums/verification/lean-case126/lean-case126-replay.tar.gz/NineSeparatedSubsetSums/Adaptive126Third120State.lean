import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive126Third120Node0 : CachedSearchNode :=
  ⟨4, 119, computeCenteredMask [148,126,120], 394, 52180⟩

end NineSeparatedSubsetSums
