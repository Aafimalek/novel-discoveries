import NineSeparatedSubsetSums.FourPoint126PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem fourPoint126PackedAnchor1Part1 :
    ∀ j : Fin 120, 1111316 ≤ FourPointNumeric.packedCharge 126 20 packedWeight126_1
      (2*((j.val : Int)+120)+1) := by decide +kernel

end NineSeparatedSubsetSums
