import NineSeparatedSubsetSums.Adaptive126Third117State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive126Third117Proof0 : runCachedNode 511 122303 Adaptive126Third117Node0 = false := by
  decide +kernel

#print axioms adaptive126Third117Proof0

end NineSeparatedSubsetSums
