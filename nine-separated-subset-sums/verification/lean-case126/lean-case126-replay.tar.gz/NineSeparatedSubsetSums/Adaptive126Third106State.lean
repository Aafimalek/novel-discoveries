import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive126Third106Node0 : CachedSearchNode :=
  ⟨4, 105, computeCenteredMask [148,126,106], 380, 49016⟩

end NineSeparatedSubsetSums
