import NineSeparatedSubsetSums.EightPoint126_125PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint126_125PackedAnchor0Part0 :
    ∀ j : Fin 120, 2332502 ≤ FourPointNumeric.octPackedCharge 126 125 20 packedOct126_125_0
      (2*((j.val : Int)+0)+1) := by decide +kernel

end NineSeparatedSubsetSums
