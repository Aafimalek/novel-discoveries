import NineSeparatedSubsetSums.Adaptive126Third125State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive126Third125Proof0 : runCachedNode 511 124134 Adaptive126Third125Node0 = false := by
  decide +kernel

#print axioms adaptive126Third125Proof0

end NineSeparatedSubsetSums
