import NineSeparatedSubsetSums.EightPoint126_125PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct126_125_0_budget :
    FourPointNumeric.packedBudget 20 packedOct126_125_0 393 = 85723554 := by decide +kernel

#print axioms packedOct126_125_0_budget

end NineSeparatedSubsetSums
