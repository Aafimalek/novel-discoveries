import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive126Third123Node0 : CachedSearchNode :=
  ⟨4, 122, computeCenteredMask [148,126,123], 397, 52909⟩

end NineSeparatedSubsetSums
