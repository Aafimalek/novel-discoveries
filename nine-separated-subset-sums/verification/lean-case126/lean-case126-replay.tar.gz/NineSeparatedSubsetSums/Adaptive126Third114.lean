import NineSeparatedSubsetSums.Adaptive126Third114Joins0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint126Checked

namespace NineSeparatedSubsetSums


theorem adaptive126Third114 : NoDescendingTailAfterThird 126 114 :=
  noDescendingThirdTail_of_cached 126 114 109252 (fun t ht nd => max148_second126_fourPoint_moment_bound (114::t) (by simp [ht]) nd) adaptive126Third114Proof0

#print axioms adaptive126Third114

end NineSeparatedSubsetSums
