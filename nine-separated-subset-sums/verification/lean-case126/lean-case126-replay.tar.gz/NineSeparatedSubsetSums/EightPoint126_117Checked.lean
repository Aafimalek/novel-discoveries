import NineSeparatedSubsetSums.EightPointPackedGeometry
import NineSeparatedSubsetSums.EightPoint126_117PackedBudget0
import NineSeparatedSubsetSums.EightPoint126_117PackedAnchor0Part0
import NineSeparatedSubsetSums.EightPoint126_117PackedAnchor0Part1
import NineSeparatedSubsetSums.EightPoint126_117PackedBudget1
import NineSeparatedSubsetSums.EightPoint126_117PackedAnchor1Part0
import NineSeparatedSubsetSums.EightPoint126_117PackedAnchor1Part1

namespace NineSeparatedSubsetSums

private theorem packedOct126_117Anchor0 :
  ∀ j : Fin 474, ((j.val : Int)+126+117)%2=0 →
    2207925 ≤ FourPointNumeric.octPackedCharge 126 117 20 packedOct126_117_0 (j.val : Int) := by
  intro j hj
  let k := (j.val-1)/2
  have hk : k < 237 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+1 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint126_117PackedAnchor0Part0 z
    rwa [he,hrep] at ht
  let z : Fin 117 := ⟨k-120, by omega⟩
  have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
  have ht := eightPoint126_117PackedAnchor0Part1 z
  rwa [he,hrep] at ht

private theorem packedOct126_117Anchor1 :
  ∀ j : Fin 474, ((j.val : Int)+126+117)%2=1 →
    2209042 ≤ FourPointNumeric.octPackedCharge 126 117 20 packedOct126_117_1 (j.val : Int) := by
  intro j hj
  let k := (j.val-0)/2
  have hk : k < 237 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+0 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint126_117PackedAnchor1Part0 z
    rwa [he,hrep] at ht
  let z : Fin 117 := ⟨k-120, by omega⟩
  have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
  have ht := eightPoint126_117PackedAnchor1Part1 z
  rwa [he,hrep] at ht

def packedOctCertificate126_117_0 : EightPointCertificate 126 117 0 122303 :=
  eightPointCertificateOfPacked 126 117 0 122303 2207925 20 packedOct126_117_0 259 474
    (by decide +kernel) (by decide) packedOct126_117Anchor0
    (by rw [packedOct126_117_0_budget]; decide)

def packedOctCertificate126_117_1 : EightPointCertificate 126 117 1 122303 :=
  eightPointCertificateOfPacked 126 117 1 122303 2209042 20 packedOct126_117_1 264 474
    (by decide +kernel) (by decide) packedOct126_117Anchor1
    (by rw [packedOct126_117_1_budget]; decide)

theorem max148_second126_third117_eightPoint_moment_bound (tail : List ℕ) (len : tail.length=6)
    (distinct : (natSubsetSums (148::126::117::tail)).Nodup) :
    122303 ≤ ((148::126::117::tail).map (· ^ 2)).sum := by
  apply eightPointNatMomentLower 126 117 122303 tail len distinct
  intro p hp
  by_cases h : p=0
  · subst p
    exact packedOctCertificate126_117_0
  · have he : p=1 := hp.resolve_left h
    subst p
    exact packedOctCertificate126_117_1

#print axioms max148_second126_third117_eightPoint_moment_bound

end NineSeparatedSubsetSums
