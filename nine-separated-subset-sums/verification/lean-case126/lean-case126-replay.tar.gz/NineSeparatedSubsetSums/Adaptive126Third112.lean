import NineSeparatedSubsetSums.Adaptive126Third112Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint126Checked

namespace NineSeparatedSubsetSums


theorem adaptive126Third112 : NoDescendingTailAfterThird 126 112 :=
  noDescendingThirdTail_of_cached 126 112 109252 (fun t ht nd => max148_second126_fourPoint_moment_bound (112::t) (by simp [ht]) nd) adaptive126Third112Proof0

#print axioms adaptive126Third112

end NineSeparatedSubsetSums
