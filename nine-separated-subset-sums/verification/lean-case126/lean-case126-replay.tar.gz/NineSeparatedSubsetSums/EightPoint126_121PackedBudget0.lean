import NineSeparatedSubsetSums.EightPoint126_121PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct126_121_0_budget :
    FourPointNumeric.packedBudget 20 packedOct126_121_0 403 = 84369771 := by decide +kernel

#print axioms packedOct126_121_0_budget

end NineSeparatedSubsetSums
