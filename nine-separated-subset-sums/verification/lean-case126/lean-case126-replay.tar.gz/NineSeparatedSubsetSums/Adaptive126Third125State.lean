import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive126Third125Node0 : CachedSearchNode :=
  ⟨4, 124, computeCenteredMask [148,126,125], 399, 53405⟩

end NineSeparatedSubsetSums
