import NineSeparatedSubsetSums.EightPoint126_120PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct126_120_1_budget :
    FourPointNumeric.packedBudget 20 packedOct126_120_1 388 = 80020334 := by decide +kernel

#print axioms packedOct126_120_1_budget

end NineSeparatedSubsetSums
