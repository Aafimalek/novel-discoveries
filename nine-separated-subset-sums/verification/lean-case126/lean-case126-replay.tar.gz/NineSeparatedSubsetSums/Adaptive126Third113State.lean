import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive126Third113Node0 : CachedSearchNode :=
  ⟨4, 112, computeCenteredMask [148,126,113], 387, 50549⟩

end NineSeparatedSubsetSums
