import NineSeparatedSubsetSums.Adaptive126Third116State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive126Third116Proof15 : runCachedNode 511 109252 Adaptive126Third116Node15 = false := by
  decide +kernel

#print axioms adaptive126Third116Proof15

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive126Third116Proof14 : runCachedNode 511 109252 Adaptive126Third116Node14 = false := by
  decide +kernel

#print axioms adaptive126Third116Proof14

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive126Third116Proof13 : runCachedNode 511 109252 Adaptive126Third116Node13 = false := by
  decide +kernel

#print axioms adaptive126Third116Proof13

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive126Third116Proof11 : runCachedNode 511 109252 Adaptive126Third116Node11 = false := by
  decide +kernel

#print axioms adaptive126Third116Proof11

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive126Third116Proof5 : runCachedNode 511 109252 Adaptive126Third116Node5 = false := by
  decide +kernel

#print axioms adaptive126Third116Proof5

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive126Third116Proof3 : runCachedNode 511 109252 Adaptive126Third116Node3 = false := by
  decide +kernel

#print axioms adaptive126Third116Proof3

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive126Third116Proof1 : runCachedNode 511 109252 Adaptive126Third116Node1 = false := by
  decide +kernel

#print axioms adaptive126Third116Proof1

end NineSeparatedSubsetSums
