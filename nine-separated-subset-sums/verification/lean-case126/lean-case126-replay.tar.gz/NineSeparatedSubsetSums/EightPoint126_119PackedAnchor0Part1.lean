import NineSeparatedSubsetSums.EightPoint126_119PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint126_119PackedAnchor0Part1 :
    ∀ j : Fin 115, 2182083 ≤ FourPointNumeric.octPackedCharge 126 119 20 packedOct126_119_0
      (2*((j.val : Int)+120)+1) := by decide +kernel

end NineSeparatedSubsetSums
