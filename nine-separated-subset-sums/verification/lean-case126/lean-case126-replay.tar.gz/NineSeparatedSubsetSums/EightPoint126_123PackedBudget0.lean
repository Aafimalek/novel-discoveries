import NineSeparatedSubsetSums.EightPoint126_123PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct126_123_0_budget :
    FourPointNumeric.packedBudget 20 packedOct126_123_0 379 = 84967905 := by decide +kernel

#print axioms packedOct126_123_0_budget

end NineSeparatedSubsetSums
