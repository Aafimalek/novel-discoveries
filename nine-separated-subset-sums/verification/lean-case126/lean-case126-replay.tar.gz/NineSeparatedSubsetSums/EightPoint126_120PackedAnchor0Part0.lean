import NineSeparatedSubsetSums.EightPoint126_120PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint126_120PackedAnchor0Part0 :
    ∀ j : Fin 120, 2234409 ≤ FourPointNumeric.octPackedCharge 126 120 20 packedOct126_120_0
      (2*((j.val : Int)+0)+0) := by decide +kernel

end NineSeparatedSubsetSums
