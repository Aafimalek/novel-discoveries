import NineSeparatedSubsetSums.Adaptive126Third107Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint126Checked

namespace NineSeparatedSubsetSums


theorem adaptive126Third107 : NoDescendingTailAfterThird 126 107 :=
  noDescendingThirdTail_of_cached 126 107 109252 (fun t ht nd => max148_second126_fourPoint_moment_bound (107::t) (by simp [ht]) nd) adaptive126Third107Proof0

#print axioms adaptive126Third107

end NineSeparatedSubsetSums
