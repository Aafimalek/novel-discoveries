import NineSeparatedSubsetSums.EightPoint126_118PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint126_118PackedAnchor0Part1 :
    ∀ j : Fin 115, 2180365 ≤ FourPointNumeric.octPackedCharge 126 118 20 packedOct126_118_0
      (2*((j.val : Int)+120)+0) := by decide +kernel

end NineSeparatedSubsetSums
