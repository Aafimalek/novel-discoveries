import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive126Third118Node0 : CachedSearchNode :=
  ⟨4, 117, computeCenteredMask [148,126,118], 392, 51704⟩

end NineSeparatedSubsetSums
