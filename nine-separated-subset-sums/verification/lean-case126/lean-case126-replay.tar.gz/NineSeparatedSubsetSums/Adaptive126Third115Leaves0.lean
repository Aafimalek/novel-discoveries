import NineSeparatedSubsetSums.Adaptive126Third115State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive126Third115Proof13 : runCachedNode 511 109252 Adaptive126Third115Node13 = false := by
  decide +kernel

#print axioms adaptive126Third115Proof13

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive126Third115Proof12 : runCachedNode 511 109252 Adaptive126Third115Node12 = false := by
  decide +kernel

#print axioms adaptive126Third115Proof12

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive126Third115Proof11 : runCachedNode 511 109252 Adaptive126Third115Node11 = false := by
  decide +kernel

#print axioms adaptive126Third115Proof11

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive126Third115Proof10 : runCachedNode 511 109252 Adaptive126Third115Node10 = false := by
  decide +kernel

#print axioms adaptive126Third115Proof10

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive126Third115Proof9 : runCachedNode 511 109252 Adaptive126Third115Node9 = false := by
  decide +kernel

#print axioms adaptive126Third115Proof9

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive126Third115Proof5 : runCachedNode 511 109252 Adaptive126Third115Node5 = false := by
  decide +kernel

#print axioms adaptive126Third115Proof5

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive126Third115Proof1 : runCachedNode 511 109252 Adaptive126Third115Node1 = false := by
  decide +kernel

#print axioms adaptive126Third115Proof1

end NineSeparatedSubsetSums
