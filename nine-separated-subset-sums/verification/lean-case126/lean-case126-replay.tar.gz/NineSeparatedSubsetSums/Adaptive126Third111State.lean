import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive126Third111Node0 : CachedSearchNode :=
  ⟨4, 110, computeCenteredMask [148,126,111], 385, 50101⟩

end NineSeparatedSubsetSums
