import NineSeparatedSubsetSums.Adaptive126Third116Joins0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint126Checked

namespace NineSeparatedSubsetSums


theorem adaptive126Third116 : NoDescendingTailAfterThird 126 116 :=
  noDescendingThirdTail_of_cached 126 116 109252 (fun t ht nd => max148_second126_fourPoint_moment_bound (116::t) (by simp [ht]) nd) adaptive126Third116Proof0

#print axioms adaptive126Third116

end NineSeparatedSubsetSums
