import NineSeparatedSubsetSums.EightPoint126_120PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct126_120_0_budget :
    FourPointNumeric.packedBudget 20 packedOct126_120_0 387 = 80082189 := by decide +kernel

#print axioms packedOct126_120_0_budget

end NineSeparatedSubsetSums
