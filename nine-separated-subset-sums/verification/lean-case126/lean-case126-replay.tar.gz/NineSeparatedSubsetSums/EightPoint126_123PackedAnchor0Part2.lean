import NineSeparatedSubsetSums.EightPoint126_123PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint126_123PackedAnchor0Part2 :
    ∀ j : Fin 3, 2317102 ≤ FourPointNumeric.octPackedCharge 126 123 20 packedOct126_123_0
      (2*((j.val : Int)+240)+1) := by decide +kernel

end NineSeparatedSubsetSums
