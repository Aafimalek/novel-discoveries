import NineSeparatedSubsetSums.Adaptive126Third114State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive126Third114Proof5 : runCachedNode 511 109252 Adaptive126Third114Node5 = false := by
  decide +kernel

#print axioms adaptive126Third114Proof5

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive126Third114Proof4 : runCachedNode 511 109252 Adaptive126Third114Node4 = false := by
  decide +kernel

#print axioms adaptive126Third114Proof4

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive126Third114Proof3 : runCachedNode 511 109252 Adaptive126Third114Node3 = false := by
  decide +kernel

#print axioms adaptive126Third114Proof3

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive126Third114Proof2 : runCachedNode 511 109252 Adaptive126Third114Node2 = false := by
  decide +kernel

#print axioms adaptive126Third114Proof2

end NineSeparatedSubsetSums
