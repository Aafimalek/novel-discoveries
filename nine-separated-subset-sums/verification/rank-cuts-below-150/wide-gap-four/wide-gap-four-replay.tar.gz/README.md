# Normalized wide e>=4 single-row root test

Full mathematical derivation: written/README.md. No q-slot or multi-band
expansion is tested here. The exact model retains the old wide e>=3
case, and appends exactly one row, \(x_7-x_8\le-4\), in each of the
122 duties. Final replay independently checks the complete previous
wide layer and exact unchanged inherited row arrays for every case.

    sha256sum -c SHA256SUMS
    python3 wide_e4.py verify --require-complete certificates/wide-e4-*.json

A numerical survivor is not an actual nine-weight configuration.
This test concerns the wide branch, not a new unrestricted lower
bound and not a full chamber enumeration. No new close branch is
tested. Numerical generation was limited to one guarded process at
a time, at most 8 s per shard, 130000 KiB measured RSS, 480000 KiB
virtual limit, one BLAS/OMP thread.
