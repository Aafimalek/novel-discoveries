#!/usr/bin/env bash
set -euo pipefail
if (( $# != 2 )) || [[ ! $2 =~ ^([0-9]|1[0-5])$ ]]; then
 echo 'usage: run-wide-shard.sh PROGRESS SHARD (0..15)' >&2; exit 2
fi
here="$(cd -- "$(dirname -- "$0")" && pwd -P)"
mkdir -p -- "$1"; p="$(cd -- "$1" && pwd -P)"; shard=$2
printf -v name 'wide-e4-%02d' "$shard"
out="$p/$name.json"
if [[ -e $out ]]; then
 python3 "$here/wide_e4.py" verify --quick "$out"; exit
fi
exec 9>"$p/.wide-e4.lock"
flock -n 9 || { echo 'another wide worker is running in this directory' >&2; exit 3; }
tmp="$(mktemp -d "$p/.$name.try-XXXXXX")"
export OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 MKL_NUM_THREADS=1
(
 ulimit -v 480000
 exec python3 "$here/prior-wide/prior-close/two-way-root/normalized-root/measure-child.py" "$tmp/time.log" \
    python3 "$here/wide_e4.py" generate "$shard" "$tmp/result.json"
) >"$tmp/stdout.log" 2>"$tmp/stderr.log"
python3 "$here/wide_e4.py" verify --quick "$tmp/result.json" >"$tmp/replay.log"
ln -- "$tmp/result.json" "$out"
