import argparse,json,sys
from pathlib import Path
HERE=Path(__file__).resolve().parent
OLD=HERE/'prior-wide'
sys.path.insert(0,str(OLD))
from wide_e3 import rows as prior_rows, shortlist, verify as old_verify
from central_branch import exact
from floor148_root import oracle
SCHEMA='nine149-normalized-wide-e4-v1'
ADD=[0]*6+[1,-1,0]

def old():
    s=OLD/'certificates';fs=tuple(s/f'wide-e3-{j:02d}.json' for j in range(16))
    assert set(fs)==set(s.glob('*.json'))
    seen,closed,whole=old_verify(fs,complete=True)
    assert len(seen)==122 and not closed and not whole

def rows(z):
    A,b=prior_rows(z)
    return A+[ADD],b+[-4]

def generate(j):
    ss=shortlist(); assert 0<=j<16
    start=8*j;count=min(8,len(ss)-start);out={}
    for s in ss[start:start+count]:
        A,b=rows(s);status,proof=oracle(A,b)
        out[s]=dict(status=status,proof=proof)
    return dict(schema=SCHEMA,shard=j,start=start,count=count,records=out)

def verify(files,quick=False,complete=False):
    assert not (quick and complete)
    if not quick:old()
    ss=shortlist();assert len(ss)==122
    seen=set();rejects=set();stats={}
    for f in files:
        z=json.loads(f.read_text())
        assert set(z)=={'schema','shard','start','count','records'} and z['schema']==SCHEMA
        j,i,n=(z[k] for k in ('shard','start','count'))
        assert type(j)==type(i)==type(n)==int and 0<=j<16 and i==8*j and n==min(8,len(ss)-i)
        assert set(z['records'])==set(ss[i:i+n])
        for s,r in z['records'].items():
            assert s not in seen and set(r)=={'status','proof'}
            seen.add(s);label,proof=r['status'],r['proof']
            A,b=rows(s);U,v=prior_rows(s)
            assert A[:-1]==U and b[:-1]==v and A[-1]==[0]*6+[1,-1,0] and b[-1]==-4
            if label=='exact-reject':
                assert isinstance(proof,dict) and exact(A,b,proof); rejects.add(s)
            else:
                assert label in ('numeric-survivor','unknown') and proof is None
            stats[label]=stats.get(label,0)+1
    if complete:assert seen==set(ss)
    print(f'New e>=4 wide duties checked: {len(seen)}/122; {stats}')
    print('Exact wide rejections:',len(rejects),', all other rows byte-identical to e>=3 construction.')
    return seen,rejects

def main():
    p=argparse.ArgumentParser(); c=p.add_subparsers(dest='cmd',required=True)
    g=c.add_parser('generate');g.add_argument('shard',type=int);g.add_argument('out',type=Path)
    v=c.add_parser('verify');v.add_argument('--quick',action='store_true');v.add_argument('--require-complete',action='store_true');v.add_argument('files',type=Path,nargs='+')
    a=p.parse_args()
    if a.cmd=='verify':verify(a.files,a.quick,a.require_complete)
    else:
        z=generate(a.shard)
        with a.out.open('x') as f:json.dump(z,f,sort_keys=True,separators=(',',':'));f.write('\n')
        verify([a.out],quick=True)
if __name__=='__main__':main()
