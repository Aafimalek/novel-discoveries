#!/usr/bin/env python3
"""Exact normalized wide duties with the written lower row e>=3."""
import argparse,json,sys
from pathlib import Path
HERE=Path(__file__).resolve().parent
OLD=HERE/'prior-close'
sys.path.insert(0,str(OLD))
from close_total_root import prior_files, verify as verify_close
from two_way_root import rows as two_rows, shortlist, verify as verify_two
from central_branch import exact
from floor148_root import oracle
SCHEMA='nine149-normalized-wide-e3-v1'

def audit_old():
    fs=tuple(OLD/'certificates'/f'close-total-{j:02d}.json' for j in range(9))
    assert set(fs)==set((OLD/'certificates').glob('*.json'))
    seen,closed=verify_close(fs,complete=True)
    assert len(seen)==69 and len(closed)==20
    seen2,old,both=verify_two(prior_files(),quick=True)
    assert len(seen2)==244 and not old['pair-wide'] and len(old['triple-close'])==53 and not both
    assert not old['triple-close']&closed
    return old['triple-close']|closed

def rows(sign):
    A,b=two_rows('pair-wide',sign)
    return A+[[0]*6+[1,-1,0]],b+[-3]

def run(j):
    ss=shortlist(); assert len(ss)==122 and 0<=j<16
    start=8*j; count=min(8,len(ss)-start)
    d={}
    for s in ss[start:start+count]:
        A,b=rows(s); label,proof=oracle(A,b)
        d[s]=dict(status=label,proof=proof)
    return dict(schema=SCHEMA,shard=j,start=start,count=count,records=d)

def verify(fs,quick=False,complete=False):
    assert not (quick and complete)
    prev_close=set() if quick else audit_old()
    ss=shortlist(); assert len(ss)==122
    seen=set(); closed=set(); stats={}
    for f in fs:
        d=json.loads(f.read_text())
        assert set(d)=={'schema','shard','start','count','records'} and d['schema']==SCHEMA
        j,a,n=(d[k] for k in ('shard','start','count'))
        assert type(j)==type(a)==type(n)==int and 0<=j<16 and a==8*j and n==min(8,len(ss)-a)
        assert set(d['records'])==set(ss[a:a+n])
        for s,r in d['records'].items():
            assert s not in seen and set(r)=={'status','proof'}
            seen.add(s); label,proof=r['status'],r['proof']
            if label=='exact-reject':
                A,b=rows(s); assert isinstance(proof,dict) and exact(A,b,proof)
                closed.add(s)
            else:
                assert label in ('numeric-survivor','unknown') and proof is None
            stats[label]=stats.get(label,0)+1
    if complete: assert seen==set(ss)
    print(f'Wide duties checked: {len(seen)}/122; statuses: {stats}')
    if not quick:
        whole=closed&prev_close
        print('New exact wide-duty exclusions:',len(closed))
        print('Already certified close-duty exclusions on these orientations:',len(whole))
        print('Whole orientation exclusions therefore added:',len(whole))
        print('Unresolved wide/close/whole:',122-len(closed),49,122-len(whole))
        if whole: print('Exact whole words:',','.join(sorted(whole)))
    return seen,closed,closed&prev_close

def main():
    p=argparse.ArgumentParser(); c=p.add_subparsers(dest='cmd',required=True)
    g=c.add_parser('generate'); g.add_argument('shard',type=int);g.add_argument('out',type=Path)
    v=c.add_parser('verify');v.add_argument('--quick',action='store_true');v.add_argument('--require-complete',action='store_true');v.add_argument('files',type=Path,nargs='+')
    a=p.parse_args()
    if a.cmd=='verify':
        verify(a.files,a.quick,a.require_complete)
    else:
        d=run(a.shard)
        with a.out.open('x') as f:
            json.dump(d,f,sort_keys=True,separators=(',',':'));f.write('\n')
        verify([a.out],quick=True)

if __name__=='__main__': main()
