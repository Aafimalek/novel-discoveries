"""Exact all-122 coverage and the empty wide-exclusion result."""
import json
from pathlib import Path
from wide_e3 import rows,shortlist,verify
HERE=Path(__file__).resolve().parent
p=HERE/'certificates'
fs=[p/f'wide-e3-{j:02d}.json' for j in range(16)]
assert len(fs)==16 and set(fs)==set(p.glob('*.json'))
seen,wide,whole=verify(fs,complete=True)
assert len(seen)==122 and not wide and not whole
for j,f in enumerate(fs):
    d=json.loads(f.read_text())
    assert d['shard']==j
    assert all(z['status']=='numeric-survivor' for z in d['records'].values())
for s in shortlist():
    A,b=rows(s)
    assert A[-1]==[0]*6+[1,-1,0] and b[-1]==-3
print('All 16 fixed shards covered; no wide or whole exact rejections.')
