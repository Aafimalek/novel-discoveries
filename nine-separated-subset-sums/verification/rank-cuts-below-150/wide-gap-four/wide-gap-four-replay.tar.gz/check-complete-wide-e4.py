from pathlib import Path
import json,re
from wide_e4 import verify
here=Path(__file__).resolve().parent
p=here/'certificates'
fs=[p/f'wide-e4-{i:02d}.json' for i in range(16)]
assert set(fs)==set(p.glob('*.json'))
seen,closed=verify(fs,complete=True)
assert len(seen)==122 and not closed
for i,f in enumerate(fs):
 q=json.loads(f.read_text())
 assert q['shard']==i and all(r['status']=='numeric-survivor' for r in q['records'].values())
t=[dict(re.findall(r'(\w+)=([\d.]+)',f.read_text())) for f in (here/'timing').glob('*.log')]
assert len(t)==16 and all(q['guard_status']=='0' for q in t)
print('All 16 guard receipts replayed: summed seconds / max seconds / max KiB:',
      round(sum(float(q['elapsed']) for q in t),2),max(float(q['elapsed']) for q in t),max(int(q['max_child_rss_kib']) for q in t))
print('No change to 122 wide, 49 close, or 122 whole residual duties.')
