#!/usr/bin/env bash
set -euo pipefail
cd -- "$(dirname -- "$0")"
for id in $(python3 -c 'import json,sys; lo,hi=map(int,sys.argv[1:]); print(*(s["id"] for s in json.load(open("checkpoint/manifest.json"))["shards"] if lo<=s["a"]<=hi))' "$1" "$2"); do
    test "$(awk '/MemAvailable/{print $2}' /proc/meminfo)" -ge 1250000 || { echo 'STOP memory reserve'; exit 74; }
    test "$(df -Pm /tmp | awk 'NR==2{print $4}')" -ge 420 || { echo 'STOP disk reserve'; exit 74; }
    out="$(./run-shard.sh "$id" --max-depth 4)"
    printf '%s\n' "$out"
    if grep -q '^STILL OPEN ' <<<"$out"; then
        printf 'STOP genuine residual at %s\n' "$id"
        exit 3
    fi
done
