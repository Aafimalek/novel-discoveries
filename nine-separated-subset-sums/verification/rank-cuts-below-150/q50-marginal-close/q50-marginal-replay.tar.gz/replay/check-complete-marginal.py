"""Replay the prerequisite branch coverage and independent exact final arithmetic."""
import runpy
import subprocess
import sys
from pathlib import Path
HERE=Path(__file__).resolve().parent
P=HERE/'prior-q53'
subprocess.run([sys.executable,str(P/'check-complete-triple53.py')],check=True,cwd=P)
runpy.run_path(str(HERE/'check-linear-arithmetic.py'))
print('With the written geometric lemmas, q50 sign +----++ is excluded for central -----+++-.')
print('No whole central orientation is excluded by this marginal result.')
