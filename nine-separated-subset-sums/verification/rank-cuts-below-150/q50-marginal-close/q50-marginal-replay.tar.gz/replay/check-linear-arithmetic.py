"""Exact row-combination replay for the written sole-survivor contradiction.

Rows encode lhs <= rhs; an attached True means strict lhs < rhs.
The geometry establishing these premises is in README.md.
"""
from fractions import Fraction as F
from collections import namedtuple
Row=namedtuple('Row','a b strict')
NAMES=('a','t','s','x4','x5','x6','X','g')
a,t,s,x4,x5,x6,X,g=NAMES

def row(b, strict=False, **a):
    assert set(a)<=set(NAMES)
    return Row(tuple(F(a.get(k,0)) for k in NAMES),F(b),strict)

def mix(*ls):
    assert all(k>=0 for k,r in ls)
    return Row(tuple(sum(k*r.a[i] for k,r in ls) for i in range(len(NAMES))),
               sum(k*r.b for k,r in ls), any(k>0 and r.strict for k,r in ls))

def contradiction(r):
    assert not any(r.a) and (r.b<0 or r.b==0 and r.strict)

# x6 = 3a+2t+s+x4+x5-X+g+2 (a=x1, t=x2-x1, s=x3-x2).
center=row(-2,a=3,t=2,s=1,x4=1,x5=1,x6=-1,X=-1,g=1)
amin=row(-F(95,2),True,a=-1)
amax=row(49,True,a=1)
tmin=row(-3,t=-1)
smin=row(-3,s=-1)
Xmax=row(149,True,X=1)
gmin=row(-1,g=-1)
gmax=row(2,True,g=1)
vt=row(-97,a=-2,g=-1)

# If x5<72, pairing virtual X and x6 implies x6<=X-72.
# The first five consecutive singleton gaps are >=3.
elim_small5=mix((1,center),(1,row(-3,a=1,t=1,s=1,x4=-1)),
                (1,row(-6,a=1,t=1,s=1,x5=-1)),
                (1,row(-72,x6=1,X=-1)),(5,amin),(4,tmin),(3,smin),
                (2,Xmax),(1,gmin))
contradiction(elim_small5)
print('x5<72 alternative contradicted:',elim_small5.b)

# For both remaining cases x5>=72 and x4-x3>=t+3.
common=mix((1,center),(1,row(-3,a=1,t=2,s=1,x4=-1)),
           (1,row(-72,x5=-1)))
assert common==row(-77,a=4,t=4,s=2,x6=-1,X=-1,g=1)

# If s>=6, use X-x6>=t+3.
large_s=mix((1,common),(1,row(-3,t=1,x6=1,X=-1)),(2,row(-6,s=-1)))
assert large_s==row(-92,a=4,t=5,X=-2,g=1)
elim_large_s=mix((1,large_s),(2,vt),(5,tmin),(2,Xmax),(1,gmax))
contradiction(elim_large_s)
print('s>=6 alternative contradicted:',elim_large_s.b)

# In the short-triple alternative, X-x6>=t+s+3.
small_s=mix((1,common),(1,row(-3,t=1,s=1,x6=1,X=-1)))
assert small_s==row(-80,a=4,t=5,s=3,X=-2,g=1)
# D = x6+x1-(x3+x4+x5) = 3a+t-X+g+2.
upper=mix((F(1,2),small_s),(1,amax),(F(3,2),tmin),(F(3,2),smin),(F(1,2),gmax))
assert upper==row(1,True,a=3,t=1,X=-1,g=1)  # D<3
lower=mix((3,amin),(1,tmin),(1,Xmax),(1,gmin))
assert lower==row(F(5,2),True,a=-3,t=-1,X=1,g=-1)  # D>-1/2
contradiction(mix((1,upper),(1,row(-1,a=-3,t=-1,X=1,g=-1)))) # D>=3
contradiction(mix((1,lower),(1,row(-5,a=3,t=1,X=-1,g=1))))   # D<=-3
print('Checked: -1/2 < D < 3; neither signed 3-separation alternative survives.')
