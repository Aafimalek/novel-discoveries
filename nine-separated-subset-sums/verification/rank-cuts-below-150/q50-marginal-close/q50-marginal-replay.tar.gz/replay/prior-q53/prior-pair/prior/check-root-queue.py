#!/usr/bin/env python3
"""Require exact root shard coverage, then replay using only pure Python."""
from argparse import ArgumentParser
import json
from pathlib import Path
from floor148_root import replay

def check(path, shards):
    paths=[]
    for i in shards:
        start=8*i
        f=path/f'root-{start:03d}.json'
        d=json.loads(f.read_text())
        assert (d['kind'],d['sign'],d['q'],d['start'],d['count'])==('root',None,None,start,8), f
        paths.append(f)
    roots,slots,covered=replay(paths)
    assert not slots and not covered
    print(f'Shard coverage: {len(shards)} of 64 | oriented branches attempted: {8*len(shards)}')
    if len(shards)==64:
        print(f'Unresolved by this exact screen: {512-len(roots)} of 512')

if __name__=='__main__':
    p=ArgumentParser()
    p.add_argument('progress',type=Path)
    p.add_argument('--shard',type=int,choices=range(64))
    a=p.parse_args()
    check(a.progress,tuple(range(64)) if a.shard is None else (a.shard,))
