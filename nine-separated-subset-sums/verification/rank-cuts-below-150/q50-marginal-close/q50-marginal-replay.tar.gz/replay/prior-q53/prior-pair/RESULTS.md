# Exact paired q50/q51 pilot

For the one central orientation with sign word shown below, all 164
guarded shards completed and independently replayed:

    -----+++-

The prior 87 exact q50 first-sign exclusions reduce the new paired
scope to 41 × 128 = 5,248 leaves. The exact whole-scope outcome:

| Type | Leaves |
|---|---:|
| Rejected by recomputed signed-support structural checks | 3,867 |
| Rejected by verified rational Farkas certificates | 628 |
| Not excluded (numerical survivors of the relaxation) | 753 |

No whole orientation was excluded. None of the 753 numeric survivors
is certified feasible for a true discrete sign chamber or for the
subset-sum problem. No other central orientation was searched.

Combining exact prior and paired coverage, the remaining leaves project
to 40 q50 first-sign alternatives and 37 q51 second-sign alternatives.
Exactly one of the prior 41 q50 alternatives is now independently
excluded after full coverage of all 128 second signs: it is --+-++-.
The 91 excluded second-sign alternatives are marginal conclusions on
this same one orientation, not new complete orientation exclusions.
The residual word pairs can be read from remaining-pairs.tsv.

All 164 successful guarded batches are recorded in timing/.
The elapsed times sum to 101.37 s; the longest was 1.05 s, and
maximum audited child RSS was 61,492 KiB. These were serial runs
using the 130,000 KiB RSS stop, 480,000 KiB virtual cap, 8 s elapsed
per shard, and one BLAS/OMP thread.

Portable, pure-Python exact replay:

    sha256sum -c SHA256SUMS
    python3 check-complete-pair.py

The checker requires the exact 164-file partition, verifies the prior
root and q50 certificates, checks every combinatorial exclusion and
rational vector again, and cross-checks the marginal summary and TSV.
The optional written mirrored outer-run cut is not encoded by this
middle-center computation.
