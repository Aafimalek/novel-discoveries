# Paired 50/51 slot follow-up (verified pilot)

This is an exact certificate package and guarded command runner for just
one final-floor central orientation, `-----+++-`. On this orientation
the previous pilot exactly rejected 87 of 128 possible first witnesses
at slot 50. Those files and their exact verifiers are copied, unmodified,
under prior/. The aggregate paired replay first checks all 64 baseline
root shards and the 16 original q50 certificate shards. It verifies that
the complement of their exact exclusions is precisely the 41 ordered
first-sign options used by this follow-up. The second sign ranges over
all 128 seven-sign words at q51, yielding 41 × 128 = 5,248 exactly
specified pairs, with no solver work assigned to the 87 × 128 old
exclusions. This scope does not include any of the other 123 unresolved
central orientations.

## Rows

Let X=x8, M=x9, d=M−X, ε=d−1, and ℓ=1+d. The two positive
seven-coordinate full signed forms are v (slot 50) and w (slot 51);
D50=v+d, D51=X+M−w. Use all prior scaled and central-defect rows,
the sharpened D49=v−d≥97, and the exact coupled inequality

    38ε + (g−1) + (2X−v−w−2) ≤ X−147.

The underlying adjacent gap is g158=X−(v+w)/2 in [1,2). The term
2g158−2 charges that mixed gap and its distinct reflected translated
copy. The central gap and both mixed gaps are separate from all 38
packed swap/triple tokens for the tested middle-middle orientation.
The complete derivation is preserved in prior/README.md.

We also add the direct gap bounds 2X−4≤v+w≤2X−2, the signed
spacing w−v≥2ℓ (distinct full first-seven absolute forms), and
the positivity minimum ℓ for the half-signed support forms
below. Although spacing is redundant under the high and low
window boxes, it is retained as an explicit correct row.

## Exact combinatorial prefilter

Before SciPy, reject coinciding full sign words up to a total sign
flip: the underlying abs forms are distinct by their disjoint rank
windows. Write a=g+d for the positive signed seven-weight form
with word equal to the first seven signs of the tested central
orientation. Since d<41/39 and g<2, a∈[2,119/39].
Closed outward rank windows give v∈[98,100] and w∈[195,198].

The half-combinations (v+w)/2, (w−v)/2, (v+a)/2, (v−a)/2,
(w+a)/2, (w−a)/2 have coefficients in {−1,0,+1}, all strictly
positive in the outward intervals used, hence each is on a nonempty
support and is at least ℓ. This follows from the separation theorem
for the first seven (every signed form with nonzero support is
a difference of two distinct base subset sums). The exact rational
outward intervals are computed from the boxes above, with (v+w)/2≤148
also using g158≥1 and X<149. None of the prefilters assumes any
of these outward interval endpoints is attained.

To bound these signed support forms without LP, relax xi using
yi=xi−2i (1-based indices) into

    0≤y1≤...≤y7≤134, y6≥36, y7≥74.

Indeed the first-seven singleton spacings are at least ℓ≥2,
x6≥24ℓ≥48, x7≥44ℓ≥88, and x7≤X−1<148. Every such y lies
in the convex hull of the nondecreasing y vectors on the grid
{0,36,74,134} satisfying the same bounds: apply a single shared
uniform threshold on each open grid interval to round each y
in that interval to its two bounding endpoints with expectation
equal to y. Within each interval this rounding rule is monotone,
and fixed grid bounds remain preserved. Averaging the finite
resulting rounding vectors gives y. Therefore evaluating any
fixed linear form over the finitely many feasible grid vectors
gives a sound signed-support outer envelope. Disjointness of its
range from the required outward window certifies a structural
rejection; equality does not certify anything. The verifier
independently reconstructs every structural reason with exact
integer/rational arithmetic.

## Shards and final replay

Only after clearance, run one batch at a time, starting from shard 0.
Each contains exactly 32 contiguous pairs; IDs 0..163 partition the
specified product. Run any pilot budget with an explicit overall stop;
the complete 164-shard run is not presumed cheap and the runner
itself intentionally launches just one shard. It reuses the prior
8 s / 130000 KiB RSS audit+kill / 480000 KiB VSZ process guard and
one BLAS/OMP thread. Any limit crossing or import/solver error leaves
no completed shard, and no exclusion can be inferred. Continue to
treat unrecognized or numerically surviving outcomes as unresolved.

    sha256sum -c SHA256SUMS
    ./run-pair-shard.sh progress 0
    python3 pair50.py verify progress/pair50-*.json
    # Require exact full structural/LP coverage only when all 164 shards exist:
    python3 pair50.py verify --require-complete progress/pair50-*.json

Replay imports no SciPy. It accepts only recomputed exact combinatorial
rejections or checked rational Farkas vectors. It counts an orientation
as excluded if and only if all 5,248 residual leaves are certified
rejected, in addition to the validated earlier 87 first-sign exclusions.
See RESULTS.md for the exact verification outcome of the full run.
