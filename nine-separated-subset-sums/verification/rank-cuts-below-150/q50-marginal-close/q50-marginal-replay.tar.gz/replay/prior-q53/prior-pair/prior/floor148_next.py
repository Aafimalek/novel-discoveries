#!/usr/bin/env python3
"""Staged exact replay for scaled subdimensions, central defect, and slot 50."""
import argparse
from itertools import product
import json
from pathlib import Path

from central_branch import exact
from central_matching import parse
from central_root_lp import unit
from floor148_root import KEYS, WITNESSES, constraints, mul, oracle, replay, sum_rows

HERE=Path(__file__).resolve().parent
SCHEMA="nine149-floor148-scaled-and-slot50-v1"
PASSES=("scaled","defect","slot50","pair50")

def residuals():
    vals=tuple((HERE/'residual-signs.txt').read_text().splitlines())
    assert len(vals)==124 and vals==tuple(k for k in KEYS if k in set(vals))
    return vals

def audited_residuals():
    certs=[]
    for start in range(0,512,8):
        p=HERE/'baseline-certificates'/f'root-{start:03d}.json'
        d=json.loads(p.read_text())
        assert (d['kind'],d['sign'],d['q'],d['start'],d['count'])==('root',None,None,start,8)
        certs.append(p)
    roots,slots,covered=replay(certs)
    assert len(roots)==388 and not slots and not covered
    vals=residuals()
    assert vals==tuple(k for k in KEYS if k not in roots)
    return vals

def rows(passno,sign,word=None,word2=None):
    assert passno in PASSES
    assert (passno in ('slot50','pair50'))==(word in WITNESSES)
    assert (passno=='pair50')==(word2 in WITNESSES)
    X,M=unit(7),unit(8)
    d=sum_rows(M,mul(-1,X))
    g=list(parse(sign))
    # x6 >= f_R(6)*(1+d), x7 >= f_R(7)*(1+d).
    extra=[(sum_rows(mul(k,d),mul(-1,unit(i))),-k) for i,k in ((5,24),(6,44))]
    if passno!='scaled':
        # Account for g_256-1; preserve all 38 tokens only when g is 01->10.
        n=38 if sign.endswith("+-") else 37
        assert sign[-2:] in ('+-','--','++')
        extra.append((sum_rows(mul(n,d),mul(-1,X),g),n-146))
    A,b=constraints(sign,50,word) if passno in ('slot50','pair50') else constraints(sign)
    if passno in ('slot50','pair50'):
        v=list(parse(word))+[0,0]
        # D50=v+d is the right member of the adjacent pair, so D49=v-d>=97.
        extra.append((sum_rows(d,mul(-1,v)),-97))
    if passno=='pair50':
        from floor148_root import slot_rows
        extra+=slot_rows(51,word2)
        v=list(parse(word))+[0,0]; w=list(parse(word2))+[0,0]
        # n*(d-1)+(g-1)+(2X-v-w-2)<=X-147.
        extra.append((sum_rows(mul(n,d),g,X,mul(-1,v),mul(-1,w)),n-144))
    return A+[a for a,_ in extra],b+[z for _,z in extra]

def keys(passno,rs):
    if passno in ('scaled','defect'): return rs
    if passno=='slot50': return WITNESSES
    return tuple(j+':'+k for j,k in product(WITNESSES,repeat=2))

def params(passno,k,sign):
    if passno in ('scaled','defect'): return k,None,None
    if passno=='slot50': return sign,k,None
    a,b=k.split(':')
    return sign,a,b

def generate(passno,sign,start,count):
    rs=residuals()
    ks=keys(passno,rs)
    if passno in ('scaled','defect'): assert sign is None
    else: assert sign in rs
    assert 0<=start<len(ks) and 1<=count<=len(ks)-start
    records={}
    for k in ks[start:start+count]:
        A,b=rows(passno,*params(passno,k,sign))
        label,proof=oracle(A,b)
        records[k]={"status":label,"proof":proof}
    return dict(schema=SCHEMA,passno=passno,sign=sign,start=start,count=count,records=records)

def verify(files,rs,required=()):
    totals={passno:set() for passno in PASSES}
    attempts=set()
    for f in files:
        d=json.loads(f.read_text())
        assert set(d)=={'schema','passno','sign','start','count','records'}
        assert d['schema']==SCHEMA and d['passno'] in PASSES
        passno,sign,start,count=(d[k] for k in ('passno','sign','start','count'))
        assert type(start)==int and type(count)==int
        if passno in ('scaled','defect'): assert sign is None
        else: assert sign in rs
        ks=keys(passno,rs)
        assert 0<=start<len(ks) and 1<=count<=len(ks)-start
        assert set(d['records'])==set(ks[start:start+count])
        for k,r in d['records'].items():
            job=(passno,sign,k)
            assert job not in attempts
            attempts.add(job)
            assert set(r)=={'status','proof'}
            if r['status']=='exact-reject':
                A,b=rows(passno,*params(passno,k,sign))
                assert isinstance(r['proof'],dict) and exact(A,b,r['proof']),job
                totals[passno].add((sign,k))
            else:
                assert r['status'] in ('numeric-survivor','unknown') and r['proof'] is None
    for p in required:
        assert p in ('scaled','defect')
        assert all((p,None,k) in attempts for k in rs),('missing root cases',p)
    closed=set()
    for p in PASSES:
        n=sum(job[0]==p for job in attempts)
        if p in ('scaled','defect'):
            s={k for _,k in totals[p]}
        else:
            nopt=128 if p=='slot50' else 128**2
            s={sign for sign in rs if sum(u==sign for u,_ in totals[p])==nopt}
        closed.update(s)
        print(f'{p}: {n} tried, {len(totals[p])} exact option rejections, {len(s)} whole orientations')
    print(f'Distinct new whole rejections: {len(closed)}; unresolved after exact union: {len(rs)-len(closed)}')

def main():
    p=argparse.ArgumentParser()
    sub=p.add_subparsers(dest='cmd',required=True)
    gen=sub.add_parser('generate')
    gen.add_argument('passno',choices=PASSES)
    gen.add_argument('start',type=int)
    gen.add_argument('count',type=int)
    gen.add_argument('out',type=Path)
    gen.add_argument('sign',nargs='?')
    ver=sub.add_parser('verify')
    ver.add_argument('--quick',action='store_true',help="per-shard check; final replay must omit")
    ver.add_argument('--require-root-pass',choices=('scaled','defect'),action='append',default=[])
    ver.add_argument('files',type=Path,nargs='+')
    args=p.parse_args()
    if args.cmd=='verify':
        verify(args.files,residuals() if args.quick else audited_residuals(),args.require_root_pass)
        return
    d=generate(args.passno,args.sign,args.start,args.count)
    with args.out.open('x') as f:
        json.dump(d,f,sort_keys=True,separators=(',',':'))
        f.write('\n')
    verify([args.out],residuals())

if __name__=='__main__':
    main()
