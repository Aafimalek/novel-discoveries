#!/usr/bin/env bash
# One of 164 deterministic 32-leaf residual shards, then exit.
set -euo pipefail
if (( $# != 2 )) || [[ ! $2 =~ ^([0-9]|[1-9][0-9]|1[0-5][0-9]|16[0-3])$ ]]; then
  echo 'usage: run-pair-shard.sh PROGRESS SHARD (0..163)' >&2
  exit 2
fi
here="$(cd -- "$(dirname -- "$0")" && pwd -P)"
mkdir -p -- "$1"
p="$(cd -- "$1" && pwd -P)"
start=$((32*$2))
printf -v name 'pair50-%04d' "$start"
out="$p/$name.json"
if [[ -e $out ]]; then
  python3 "$here/pair50.py" verify --quick "$out"
  exit
fi
exec 9>"$p/.pair.lock"
flock -n 9 || { echo 'another pair worker is running for this directory' >&2; exit 3; }
tmp="$(mktemp -d "$p/.$name.try-XXXXXX")"
export OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 MKL_NUM_THREADS=1
(
  ulimit -v 480000
  exec python3 "$here/prior/measure-child.py" "$tmp/time.log" \
    python3 "$here/pair50.py" generate "$start" 32 "$tmp/result.json"
) >"$tmp/stdout.log" 2>"$tmp/stderr.log"
python3 "$here/pair50.py" verify --quick "$tmp/result.json" >"$tmp/replay.log"
ln -- "$tmp/result.json" "$out"
