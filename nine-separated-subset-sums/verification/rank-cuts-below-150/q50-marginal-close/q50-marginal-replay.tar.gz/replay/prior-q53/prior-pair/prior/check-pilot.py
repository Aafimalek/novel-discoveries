"""Verify the fixed 124+124+128 branch scope and every rational certificate."""
from pathlib import Path
import json
from floor148_next import audited_residuals, verify

p=Path(__file__).resolve().parent/'certificates'
fixed='-----+++-'; fs=[]
for kind,sign,n in (('scaled',None,124),('defect',None,124),('slot50',fixed,128)):
    tag=kind if sign is None else f'{kind}-{sign}'
    for start in range(0,n,8):
        f=p/f'{tag}-{start:03d}.json'
        d=json.loads(f.read_text())
        assert (d['passno'],d['sign'],d['start'],d['count'])==(kind,sign,start,min(8,n-start))
        fs.append(f)
assert len(fs)==48 and set(fs)==set(p.glob('*.json'))
verify(fs,audited_residuals(),('scaled','defect'))
print(f'Complete fixed pilot coverage: 124+124 root tests and 128 slot-50 options for {fixed}')
