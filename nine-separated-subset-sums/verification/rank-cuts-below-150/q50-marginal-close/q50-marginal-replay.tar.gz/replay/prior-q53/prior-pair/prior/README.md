# Follow-up final-floor root and slot-50 screen (verified pilot)

This extension recorded two complete exact root screens and one complete
slot-50 pilot; see RESULTS.md for the verified scope. It includes the 64
previously verified root shards and replays them before deriving the
exact ordered shortlist of 124 remaining full central orientations.

## Separate passes

- **scaled:** the prior floor-148 constraints plus two affine rows
  \(x_6\ge24(1+d)\) and \(x_7\ge44(1+d)\), with \(d=M-X\).
  This uses Notik's exact real claims \(f_{\mathbb R}(6)=24\) and
  \(f_{\mathbb R}(7)=44\) in [arXiv:2611.17360](https://arxiv.org/abs/2611.17360).
  It is applicable because every positive first-seven subset difference
  is at least \(1+d\), including all differences of just the first six
  weights; rescale by dividing by \(1+d\) and apply the respective
  smaller-dimensional real lower bound. No lattice or flank assumption
  is used by this pass.
- **defect:** the scaled pass plus the strengthened central-gap excess
  row below. Kept distinct, to attribute any additional exclusions.
- **slot50:** the defect pass plus the exact necessary \(D_{50}=v+d\)
  slot inequalities for one oriented, full-support seven-sign witness.
  It adds \(v\ge97+d\), since the immediate previous full absolute
  magnitude is \(D_{49}=v-d\ge97\). This relies on the published
  consecutive pair \(v-d,v+d\) (spacing of different full absolute
  magnitudes is at least 2 and \(2d<4\)). All 128 seven-sign words are
  covered explicitly for a selected central orientation; if any word
  is unresolved, the slot as a whole has not been excluded.
- **pair50:** staged stronger hybrid, not in the default guarded queue.
  It uses both 50 and 51 slots with the coupled budget below and needs
  all \(128^2\) oriented word pairs to prove a whole orientation by
  exhaustive independent testing. A practical later search would
  first certify elimination of individual slot signs (partial
  branches), then recursively apply the coupled budget only to the
  surviving Cartesian product. In the current verifier, by design,
  one does not get credit for such implicit branch pruning; all
  pairs must be explicitly certified to count a whole orientation.

Although this package replays the 388 previously certified exclusions,
its new row passes only test their exact complement (124 distinct
orientations). The only new proof status is a checked exact rational
Farkas certificate. No numerical feasibility status proves existence.

## Central-gap budget and mixed-gap coupling

Write \(\epsilon=d-1\), let \(s_r\) be ascending ranks, and write
\(g_r=s_{r+1}-s_r\), with \(g=g_{256}\). The existing packed-defect proof
on ranks \([158,305]\) uses at least 38 disjoint gap sets, each with
excess at least \(\epsilon\). Its tokens are only (i) a middle
\(10\to01\) adjacent swap of one first-seven subset and (ii) two
outer-only consecutive gaps in a triple. The slab total excess is
\(X-147\).

For central last signs \(\mathord{+}\mathord{-}\), the middle labels
ascend instead as \(01\to10\) at ranks 256 to 257, so their gap is
disjoint from every token gap. For \(\mathord{+}\mathord{+}\) or
\(\mathord{-}\mathord{-}\), at most one of the disjoint tokens uses the
central gap, and drop it. There are no remaining
\(\mathord{-}\mathord{+}\) orientations in the prior screen.
With \(n=38\) in the first case, \(n=37\) in the other two cases,
the independent central row is
\[
n\epsilon+(g-1)\le X-147.
\]

For each \(k\in\{158,161,168,171\}\), the gap at \(k\) is outer
\(00\to10\) middle from the forced consecutive starts. Translating
along coordinate 9 gives \(g_{k+148}=g_k\) at the upper pair, and
complement gives \(g_{364-k}=g_k\). All eight gap indices
\(158,161,168,171,206,203,196,193\) are distinct in the slab and avoid
rank 256. Every gap is mixed outer/middle, hence unusable by any
token. Thus the joint necessary budget is
\[
n\epsilon+(g-1)+2\sum_{k\in\{158,161,168,171\}}(g_k-1)\le X-147.
\]
For \(q=k-108\), its two slot forms are \(D_q=d+v\) and
\(D_{q+1}=X+M-w\) with positive oriented first-seven forms \(v,w\).
By rank reflection \(D_q=2s_{k+148}-\sum_i x_i\); therefore
\(D_{q+1}-D_q=2g_k\) and \(2g_k=2X-v-w\). The present **pair50**
pass applies the valid one-pair version
\[
 n\epsilon+(g-1)+(2X-v-w-2)\le X-147.
\]
All other mixed contributions are nonnegative, so dropping them is safe.
No selected token or new gap is counted twice. This is not purely two
independent slot filters: two admissible witnesses must also fit within
the same remaining rank-excess budget.

## One worker, only after resource clearance

Use a fresh progress directory and run one small shard at a time; stop
at the first import error, timeout, memory cap, or other failure. Scaled
and defect offsets \(8j,\ldots,8j+7\) for \(j=0,\ldots,14\) and four
entries at \(j=15\) partition all 124 old survivors. All 16 eight-case
slot shards for one chosen survivor cover its 128 witnesses. Start with
scaled; run just one targeted orientation's slot at a time after
reviewing the outcome (slot 50 has the preceding \(D_{49}\) constraint
and the strong two-slot follow-up outlined above). No full 124×128
slot queue is authorized by these examples.

    sha256sum -c SHA256SUMS
    ./run-next-shard.sh progress scaled 0
    # ... only when cleared, continue through scaled shard 15.
    python3 floor148_next.py verify --require-root-pass scaled progress/scaled-*.json
    # Example argument format; actually select an unresolved central sign.
    ./run-next-shard.sh progress slot50 0 '-----+++-'
    python3 floor148_next.py verify progress/*.json

The example central sign is illustrative, not a claimed survivor. The
generator refuses a sign not on the audited shortlist. The guard uses
the previously successful process-group watchdog (130000 KiB RSS kill
threshold with 5 ms polls/high-water audit, 480000 KiB VAS, 8 s cap) and
one BLAS/OMP thread. The packaged run timings and scope are in RESULTS.md. Exact replay does
not import NumPy or SciPy. Do not use optimized Python: the checkers rely on assertions.
