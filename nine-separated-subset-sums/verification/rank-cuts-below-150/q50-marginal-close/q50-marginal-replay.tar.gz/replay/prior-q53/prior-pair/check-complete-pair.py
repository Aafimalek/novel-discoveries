"""Require all fixed paired shards, verify them, and check exact marginal projection."""
import json
from pathlib import Path
from pair50 import verify, WITNESSES

HERE=Path(__file__).resolve().parent
d=HERE/'certificates'; files=[]; left=set(); surviving=[]
for start in range(0,5248,32):
    p=d/f'pair50-{start:04d}.json'
    r=json.loads(p.read_text())
    assert (r['start'],r['count'])==(start,32),p
    files.append(p)
    for case in r['records']:
        left.add(case['left'])
        if case['status'] not in ('exact-structural','exact-reject'):
            surviving.append((case['left'],case['right']))
assert len(files)==164 and set(files)==set(d.glob('pair50-*.json'))
seen,counts=verify(files,complete=True)
assert len(left)==41 and len(seen)==5248
assert counts=={'exact-structural':3867,'exact-reject':628,'numeric-survivor':753}
lhs={u for u,v in surviving}
rhs={v for u,v in surviving}
assert len(lhs)==40 and len(rhs)==37
assert left-lhs=={'--+-++-'}
print('Newly excluded q50 first-sign option within the old 41:', ','.join(sorted(left-lhs)))
print('Marginal q50 options not yet excluded:',len(lhs),'of 128')
print('Marginal q51 options not yet excluded:',len(rhs),'of',len(WITNESSES))
table='left-q50\tright-q51\n'+''.join(x+'\t'+y+'\n' for x,y in surviving)
p=HERE/'remaining-pairs.tsv'
assert p.read_text()==table
