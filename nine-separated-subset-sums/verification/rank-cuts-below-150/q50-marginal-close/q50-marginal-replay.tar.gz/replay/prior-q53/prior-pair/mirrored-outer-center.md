# Extra mirrored outer-run budget (written, no solver)

For a hypothetical floor-148 solution let ε=d−1 and h=g256−1.
If the central top signs are both plus or both minus, both middle-rank
vertices 256 and 257 are outer. Their maximal outer run is invariant
under complement reflection. Rank 305 is a known middle vertex (the
first prescribed upper triple), as is its complement at rank 208,
so the central outer run lies entirely in [209,304], within the
38-token slab [158,305]. It has even length 2m, with center gap h
and equal mirrored flank excesses e1,...,e_(m−1). All these numbers
are nonnegative. Consecutive outer vertices have opposite top types,
since the entire slab has consecutive gaps <2 and those of the same
outer type are (2+ε)-separated. Each three consecutive outer vertices
therefore forces the sum of its two gap excesses to be at least ε,
so e_(j−1)+e_j≥ε for j≥1, with e0=h.

If m is odd, use the disjoint pairs (e1,e2), (e3,e4), ... on one
side and reflect: the total run excess is at least (m−1)ε+h.
If m is even, use e1≥max(0,ε−h), and the pairs (e2,e3),
(e4,e5), ... after it. The run excess is at least

    h + (m−2)ε + 2 max(0,ε−h)
      = (m−1)ε + |h−ε|.

The original run had exactly floor((2m−1)/2)=m−1 triple tokens,
all of which can be replaced by these run bounds. It uses no gap
outside that run and hence no middle-pair token or mixed prescribed gap.
Adding the contributions of the other slab pieces yields the unconditional
outer-center inequality

    38ε + min(h,|h−ε|) + 2 Σ_k(g_k−1) ≤ X−147

with k=158,161,168,171. In the parity-banded version replace the minimum
by h when m odd or |h−ε| when m even. In the latter case this gives
both former 37ε+h and the new affine row 39ε−h (before adding the
mixed terms). This is a strict improvement over the earlier combination
of 38ε and 37ε+h in the strip 0<h<ε. At h≥ε it gives the former
bound, and it does not exclude the full slice. The paired computation here
is a middle-center orientation, so this outer-center inequality is not
encoded in the paired certificate format.
