#!/usr/bin/env bash
# One small batch only. No pair50 launch here.
set -euo pipefail
if (( $# < 3 || $# > 4 )) || [[ ! $3 =~ ^([0-9]|1[0-5])$ ]]; then
    echo 'usage: run-next-shard.sh PROGRESS scaled|defect|slot50 SHARD0..15 [CENTRAL-SIGN]' >&2
    exit 2
fi
here="$(cd -- "$(dirname -- "$0")" && pwd -P)"
mkdir -p -- "$1"
p="$(cd -- "$1" && pwd -P)"; pass=$2; shard=$3; start=$((8*shard)); count=8
case $pass in
    scaled|defect)
        (( $# == 3 )) || exit 2
        (( shard != 15 )) || count=4
        args=(); tag="$pass"
        ;;
    slot50)
        (( $# == 4 )) && [[ $4 =~ ^[-+]{9}$ ]] || exit 2
        args=(-- "$4"); tag="$pass-$4"
        ;;
    *) exit 2;;
esac
printf -v base '%s-%03d' "$tag" "$start"
out="$p/$base.json"
if [[ -e $out ]]; then
    python3 "$here/floor148_next.py" verify --quick "$out"
    exit
fi
exec 9>"$p/.next-shards.lock"
flock -n 9 || { echo 'a shard is running in this directory' >&2; exit 3; }
tmp="$(mktemp -d "$p/.$base.try-XXXXXX")"
export OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 MKL_NUM_THREADS=1
(
    ulimit -v 480000
    exec python3 "$here/measure-child.py" "$tmp/time.log" \
        python3 "$here/floor148_next.py" generate "$pass" "$start" "$count" "$tmp/result.json" "${args[@]}"
) >"$tmp/stdout.log" 2>"$tmp/stderr.log"
python3 "$here/floor148_next.py" verify --quick "$tmp/result.json" >"$tmp/replay.log"
ln -- "$tmp/result.json" "$out"
