# Exact floor-148 refinement pilot

The prior exact baseline excluded 388 of 512 oriented central signs.
The following follow-up computations cover its 124 exact residual cases:

| Screen | Exact branch rejections | Further complete orientations excluded |
|---|---:|---:|
| Scaled real-six/real-seven affine bounds | 0 of 124 | 0 |
| Those bounds plus the strengthened central-gap budget | 0 of 124 | 0 |
| Independent slot 50 on central sign `-----+++-` | 87 of 128 | 0 |

The pilot target was the lexicographically first residual sign ending in
the middle-middle orientation `+-` (using the same order as the
published baseline). Its 41 unexcluded seven-sign witnesses and the
unexcluded root tests all had numerical feasible-relaxation status.
That is not an exact feasibility result or a subset-sum construction.
The total number of unresolved central orientations remains 124.

In particular we did not broaden the independent slot search or run the
paired-slot hybrid. The joint mixed-gap inequality documented in
README.md remains a possible next test; this negative pilot does not
measure it.

All 48 serial guarded batches completed. Their child elapsed times sum
to 29.66 s, with slowest 1.18 s and largest audited child peak RSS
60,944 KiB. They used the 130,000 KiB RSS threshold, 480,000 KiB virtual
limit, one BLAS/OMP thread and 8 s elapsed cap per batch. The replay uses
only standard Python:

    sha256sum -c SHA256SUMS
    python3 check-pilot.py
