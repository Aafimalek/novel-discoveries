#!/usr/bin/env python3
"""Exact-verifier-guided 41 x 128 pair runner; no other central class is tested."""
import argparse
from fractions import Fraction as F
from functools import lru_cache
from itertools import combinations_with_replacement, product
import json
from pathlib import Path
import sys
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE/'prior'))
from central_branch import exact
from central_matching import parse
from central_root_lp import unit
from floor148_next import audited_residuals, rows as pair_rows, verify as prior_verify
from floor148_root import WITNESSES, mul, oracle, sum_rows

SCOPE="nine149-pair50-41x128-v1"
CENTRAL='-----+++-'
PRIOR=HERE/'prior'/'certificates'

def pilot_and_left(verify_prior):
    fs=[PRIOR/f'slot50-{CENTRAL}-{i:03d}.json' for i in range(0,128,8)]
    rej=set()
    for i,f in enumerate(fs):
        r=json.loads(f.read_text())
        assert (r['passno'],r['sign'],r['start'],r['count'])==('slot50',CENTRAL,8*i,8)
        assert set(r['records'])==set(WITNESSES[8*i:8*i+8])
        rej.update(k for k,z in r['records'].items() if z['status']=='exact-reject')
    assert len(rej)==87
    if verify_prior:
        rs=audited_residuals()
        assert CENTRAL in rs
        prior_verify(fs,rs)
    left=tuple(s for s in WITNESSES if s not in rej)
    assert len(left)==41
    return left

def indices(verify_prior):
    return tuple(product(pilot_and_left(verify_prior),WITNESSES))

@lru_cache(maxsize=1)
def vertices():
    grid=(0,36,74,134)
    return tuple(tuple(2*(i+1)+z for i,z in enumerate(ys))
                 for ys in combinations_with_replacement(grid,7)
                 if ys[5]>=36 and ys[6]>=74)

@lru_cache(maxsize=None)
def hull_range(coeff):
    vals=[sum(a*x for a,x in zip(coeff,v)) for v in vertices()]
    return min(vals),max(vals)

def combine7(v,w,delta):
    vals=tuple(a+delta*b for a,b in zip(v,w))
    assert all(n%2==0 for n in vals)
    return tuple(n//2 for n in vals)

def support_forms(left,right):
    v,w,a=parse(left),parse(right),parse(CENTRAL[:7])
    # All are positive: v∈[98,100], w∈[195,198], a=g+d∈[2,119/39].
    # Use closed, outward interval endpoints for exact impossibility tests.
    return (
        ('v',v,98,100), ('w',w,195,198),
        ('half-sum',combine7(v,w,+1),F(293,2),148),
        ('half-diff',combine7(w,v,-1),F(95,2),50),
        ('v-center-sum',combine7(v,a,+1),50,F(4019,78)),
        ('v-center-diff',combine7(v,a,-1),F(3703,78),49),
        ('w-center-sum',combine7(w,a,+1),F(197,2),F(7841,78)),
        ('w-center-diff',combine7(w,a,-1),F(7486,78),98),
    )

def structural(left,right):
    if left==right or all(a!=b for a,b in zip(left,right)):
        return 'same-absolute-form'
    for name,coef,lo,hi in support_forms(left,right):
        if not any(coef):
            return f'zero-support:{name}'
        mn,mx=hull_range(coef)
        if mx<lo or hi<mn:
            return f'monotone-support:{name}'
    return None

def constraints(left,right):
    A,b=pair_rows('pair50',CENTRAL,left,right)
    X,M=unit(7),unit(8)
    d=sum_rows(M,mul(-1,X))
    v,w=list(parse(left))+[0,0],list(parse(right))+[0,0]
    # The shared gap is g_158=X-(v+w)/2∈[1,2). Close 2 outward.
    extra=[(sum_rows(v,w,mul(-2,X)),-2),
           (sum_rows(mul(-1,v),mul(-1,w),mul(2,X)),4),
           # w-v>=2(1+d) is spacing of distinct full seven magnitudes.
           (sum_rows(v,mul(-1,w),mul(2,d)),-2)]
    # Each indicated coefficient is a +/-1 signed sum on a nonempty
    # support with positive real value; all such sums are >=1+d.
    for _,coef,_,_ in support_forms(left,right):
        if not any(coef):
            raise ValueError('structurally excluded support should not reach LP')
        extra.append((sum_rows(d,mul(-1,list(coef)+[0,0])),-1))
    return A+[a for a,_ in extra],b+[z for _,z in extra]

def run(start,count):
    leaves=indices(False)
    assert 0<=start<len(leaves) and 1<=count<=len(leaves)-start
    results=[]
    for left,right in leaves[start:start+count]:
        reason=structural(left,right)
        if reason:
            label,proof='exact-structural',reason
        else:
            A,b=constraints(left,right)
            label,proof=oracle(A,b)
        results.append(dict(left=left,right=right,status=label,proof=proof))
    return dict(schema=SCOPE,start=start,count=count,records=results)

def verify(files,quick=False,complete=False):
    assert not (quick and complete)
    ls=indices(not quick)
    seen=set(); totals={}
    for file in files:
        r=json.loads(file.read_text())
        assert set(r)=={'schema','start','count','records'}
        assert r['schema']==SCOPE
        start,count=r['start'],r['count']
        assert type(start)==int and type(count)==int
        assert 0<=start<len(ls) and 1<=count<=len(ls)-start
        assert len(r['records'])==count
        for idx,x in enumerate(r['records'],start):
            assert idx not in seen and set(x)=={'left','right','status','proof'}
            seen.add(idx)
            left,right=ls[idx]
            assert (x['left'],x['right'])==(left,right)
            status,proof=x['status'],x['proof']
            reason=structural(left,right)
            if status=='exact-structural':
                assert proof is not None and reason==proof
            elif status=='exact-reject':
                assert reason is None
                A,b=constraints(left,right)
                assert isinstance(proof,dict) and exact(A,b,proof)
            else:
                assert reason is None
                assert status in ('numeric-survivor','unknown') and proof is None
            totals[status]=totals.get(status,0)+1
    if complete: assert seen==set(range(len(ls))), ('incomplete residual product',len(seen))
    exact_count=totals.get('exact-structural',0)+totals.get('exact-reject',0)
    print(f'Specified residual leaves verified: {len(seen)}/{len(ls)}; statuses: {totals}')
    if not quick:
        print('Whole orientation excluded:',exact_count==len(ls) and len(seen)==len(ls))
    return seen,totals

def main():
    p=argparse.ArgumentParser()
    sub=p.add_subparsers(dest='cmd',required=True)
    g=sub.add_parser('generate')
    g.add_argument('start',type=int)
    g.add_argument('count',type=int)
    g.add_argument('out',type=Path)
    v=sub.add_parser('verify')
    v.add_argument('--quick',action='store_true')
    v.add_argument('--require-complete',action='store_true')
    v.add_argument('files',type=Path,nargs='+')
    a=p.parse_args()
    if a.cmd=='verify':
        verify(a.files,a.quick,a.require_complete)
        return
    result=run(a.start,a.count)
    with a.out.open('x') as f:
        json.dump(result,f,sort_keys=True,separators=(',',':'))
        f.write('\n')
    verify([a.out],quick=True)

if __name__=='__main__':
    main()
