# Targeted slot-53 follow-up, verified pilot

The paired q50/q51 package leaves 753 option pairs for one particular
central orientation. A complete additional q53 scan would multiply
this by 128 possibilities (96,384 leaves), before trying q54 or
other sign branches. This package instead records a sharply scoped
pilot of 256 deterministic leaves: the two still-open q50/q51
pairings of the q50 sign word

    +----++

have q51 words

    -++++-+
    ++---++

respectively; each is tested against all 128 ways to orient q53.
If both pairs were fully certified rejected, the old audited pairs
would imply one new marginal exclusion at q50. Merely excluding
some q53 options or one selected q50/q51 pair is not a marginal
exclusion. Even clearing the whole pilot would not dispose of the
whole central orientation. The standalone exact replay audits the
old 5,248-leaf table, the earlier 87 old q50 exclusions, and all
388 root records before accepting this coverage deduction.
It imports no SciPy, and RESULTS.md records the completed scope.

## Pinned normalized model

This run model additionally imposes \(d=M-X=1\) and \(x_6\ge66\).
The earlier two-weight normalization moves only \(X,M\) toward
their fixed midpoint; it preserves every labeled subset comparison.
The first seven therefore stay fixed, all requested rank labels persist,
and the positive first-seven full-sign words \(v,w,z\) themselves do
not change. Every would-be witness to any old live pair has a
normalized representative in the same word branch; the older
pair exclusions remain valid because they were derived over a
larger relaxation. The \(x_6\) inequality is the previously proved
real-seven midpoint-pairing consequence. No branch is additionally
assumed to have \(X-x_7=1\); the separate close-case deductions
below are the original inequalities, not a new imposed compression.
This model does not search any other q50/q51 pair.

## Additional signed rank relations

Let the q50 and q51 candidates be \(v,w>0\) and the new q53 candidate
be \(z>0\), oriented all-seven signed forms. Put \(X=x_8\),
\(M=x_9\), \(d=M-X\), \(\epsilon=d-1\), and \(a=g+d\), the small
central first-seven form for the fixed middle-center orientation.
Here \(2\le a<119/39\). The forced types give

\[
D_{49}=v-d,\quad D_{50}=v+d,\quad D_{51}=X+M-w,\quad
D_{52}=z-d,\quad D_{53}=z+d.
\]
The consecutive signed-pair property puts the left companions
immediately before their right forms. The available prior slot boxes
are \(98\le v<100\), \(195\le w<198\).
In the same central rank interval, \(D_{52}\ge103\) and
\(D_{53}\le106+M-149\). Therefore \(103+d\le z\le X-43\),
and in particular \(104\le z<106\). Moreover
\(z-v=D_{53}-D_{50}\ge4+2d\): two distinct inter-slot gaps
are at least 2 and the third is exactly \(2d\).
Thus \((z-v)/2\in[3,4)\), a notably narrow positive support box.

The crossing \(D_{51}\to D_{52}\) corresponds to the lower reflected
gap \(g_{205}=s_{206}-s_{205}\), since the lower ranks for slots
51 and 52 are 206 and 205. Exactly \(1\le g_{205}<2\), and

\[
2g_{205}=D_{52}-D_{51}=z+w-2M.
\]
Ranks 205 and 206 are the complements of 308 and 307. The earlier
forced triples give top types 10 at 308 and 11 at 307, so the crossing
is \(01\to00\). This is a mixed gap distinct from the eight charged
\(00\to10\) gaps and all packed swap and outer-triple gaps. The
joint one-pair budget thus gains one further nonnegative excess:

\[
38\epsilon+(g-1)+(2X-v-w-2)+(z+w-2M-2)/2\le X-147.
\]
Its simplified integer-coefficient form is
\(74d+2g-2v-w+z\le-210\). This holds on the chosen middle-center
orientation since the central \(01\to10\) gap is also disjoint from
all packed tokens. No q54 choice is needed merely to derive it.

## Signed-support and adjacency filter

The half forms \((z-v)/2,(z+v)/2,(w-z)/2,(w+z)/2,(z-a)/2,
(z+a)/2\) are signed sums with coefficients in \(\{-1,0,1\}\).
The boxes above and crossing give the explicit outward ranges checked
in the program. For example \((w+z)/2\in[150,152)\) and
\((w-z)/2\in[89/2,47)\).
Each listed range is positive, so the support must be nonzero
and its value at least \(1+d\). The exact convex-hull
support calculation may reject a branch before SciPy when the
hull range and its required interval are disjoint. The upper
endpoints of these boxes are strict; equality against such an
upper endpoint also rejects.

The two chosen pairs also admit a tighter hull than the generic
previous stage. The selected word for \(v\) differs from the central
seven-sign word only at coordinate 1; hence
\(x_1=(v-a)/2\in[3703/78,49)\).
For the first \(w\) word, agreement with \(v\) occurs only at
coordinate 7 and both signs there are positive, hence
\(x_7=(v+w)/2\in[293/2,148)\).
For the second \(w\) word, only coordinate 2 changes, from minus to
plus, hence \(x_2=(w-v)/2\in[95/2,50)\).
The second partner uses \(y_i=x_i-2i\), the closed
bounds \(3547/78\le y_1\le47\), \(y_2\le46\), \(y_6\ge36\),
and \(74\le y_7\le134\). The first partner additionally gives
first-six spacing at least 3 through the next subsection.
Use offsets \((3,6,9,12,15,18,20)\) so that \(y_i\) is again
increasing, with closed bounds \(3469/78\le y_1\le46\),
\(y_6\ge54\) and \(1393/11\le y_7\le128\).
As before put all interval endpoints on the grid and use the
same shared-threshold interpolation to verify the hull.
All adjacency sign checks use the hull appropriate to \(w\).

In fact \(v,z\) are adjacent in the ordered seven-sign absolute
magnitudes. Their consecutive original pairs occupy full ranks
49–50 and 52–53. Any intermediate positive seven-form would
bring two consecutive full magnitudes between the paired blocks;
only slot 51 sits there, so that is impossible.
For any different oriented word \(k\) representing the full form
\(u\) (ignore the two extremes and their negatives), let
\(A=(u-v)/2\), \(B=(z-u)/2\). These are again signed forms on
nonempty supports. A branch cannot have both \(A>0\) and \(B>0\).
Since a nonempty support always has absolute value at least
\(1+d\ge2\), a strict hull lower bound greater than \(-2\) forces
its sign positive, and a strict hull upper bound below \(2\)
forces negative. The first partner uses the stronger cutoff 3
when the sign form is supported entirely among the first six. Thus a forced-positive form rules out the pair
if the other is forced positive too; otherwise the other must
be \(\le-(1+d)\), which supplies a new exact LP row if not already
forced negative. A form forced both ways is itself impossible.
Unresolved signs are relaxed, never guessed or used for exclusion.

## Global close-top-three branch and its use for the first partner

Write \(Y=x_7\) and \(e=X-Y\). For any admissible final-floor
configuration with \(e<2\), we have \(1\le d,e<2\).
A positive first-six subset sum difference \(h\) obeys
\(|h-c|\ge1\) for every positive signed difference \(c\) of the
top three weights: compare suitably shifted subsets on the
disjoint coordinate groups. The three low centers \(d,e,d+e\)
have their open radius-one windows overlapping successively;
the union contains 1 and reaches \(1+d+e\).
Hence all first-six positive differences have spacing
\(\ell_6=1+d+e=1+M-Y\).
The five high centers \(Y-d,Y,X,M,M+e\) are also all top-three
signed differences, with consecutive distances \(d,e,d,e<2\).
Their forbidden intervals join to \((X-\ell_6,X+\ell_6)\).
Thus appending \(X\) to the first six produces seven positive
weights separated by at least \(\ell_6\). Their largest weight is
\(X\). Notik's exact real-seven bound gives \(44\ell_6\le X\).
In particular the final slice has the disjunctive constraint
\[
   e\ge2\quad\hbox{or}\quad 44(1+M-Y)\le X.
\]
In the second alternative coming from \(e<2\),
\(e\le X/44-2<61/44\). No assumption on any signed pair is
needed for this global disjunction.

For the specific first \(w\) word in this pilot \(Y=(v+w)/2\),
so \(e=X-Y=g_{158}<2\) automatically. Incorporate the affine
seven-weight bound, all first-six singleton gaps at least
\(\ell_6\), and the lower bounds
\(x_i\ge f_{\mathbb R}(i)\ell_6\), \(i\le6\), from the real
small-dimension theorem (values \(1,2,4,7,13,24\)).
In particular \(x_6\ge72\); the new bound on \(e\) also gives
\(Y\ge (43/44)X+2\ge1613/11\), as used in the local hull.

Finally \(p=(z+w)/2=M+g_{205}\in[M+1,M+2)\) is strictly
inside \((X-\ell_6,X+\ell_6)\), because
\(X+\ell_6=M+e+1\ge M+2\).
The \(w\) word has a plus in coordinate 7; if the \(z\) word
has a minus there, \(p\) is a positive difference supported
in the first six, impossible. This direct no-LP filter applies
only to the first \(w\) partner. The second partner uses neither
this branch assumption nor the enhanced first-six rows.

## Resource-controlled commands, only after direction

Eight disjoint 32-leaf shards cover these two chosen pairs only.
Run one at a time, stop on guard or any failure, and do not scale
up to the other 751 pairs unless independently authorized after a
useful result from this pilot.

    sha256sum -c SHA256SUMS
    ./run-triple-shard.sh progress 0
    # After all eight shards, 0 through 7:
    python3 triple53.py verify --require-complete progress/triple53-*.json

The standard prior numerical worker guard uses 130000 KiB audited
RSS, 480000 KiB virtual mapping cap, 8 s per shard, and one numerical
thread. The verifier independently reconstructs all exact structural
certificates and all rational Farkas vectors. The completed outcome is in RESULTS.md.
