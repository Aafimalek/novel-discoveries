# Exact slot-53 pilot on two selected slot-50/51 pairs

All eight deterministic guarded shards finished, and exact standard-library
replay covered all 256 specified third-sign alternatives. The test is
within one previously selected central orientation (-----+++-), for the
two remaining paired witnesses with the fixed q50 sign +----++:

| q51 sign | Exact structural q53 exclusions | Remaining q53 alternatives |
|---|---:|---:|
| -++++-+ | 127 | 1 |
| ++---++ | 128 | 0 |

The remaining q53 sign for the first partner is -+---++.
It is a numerical survivor of the relaxation only, not a valid
configuration or a certified feasible full chamber.

Thus precisely one old q50/q51 pairing is closed in this pilot. Neither
the q50 marginal sign +----++ nor the central orientation is excluded:
the whole-orientation count is unchanged (122 still unresolved after
the separate most recent root screen). The other 751 old pairs, and
all other central orientations, were outside this pilot.

All 255 exclusions were exact structural checks (185 signed-support
convex hull disjointness, 64 first-six forbidden-window signs, six
coincident absolute forms). No Farkas certificates were needed in
this pilot; the surviving LP case included the pinned d=1 and
x6≥66 rows. The inherited paired replay validates the prior sign
coverage used to select the two cases. Scope of its older baseline
summary (124 central orientations still open at its stage) does not
overwrite the newer 122-root count.

All eight 8 s / 130000 KiB RSS / 480000 KiB virtual guards passed.
Child times sum to 2.75 s; the maximum was 1.65 s and maximum
post-exit child RSS 61,148 KiB. No broader batches were run.

Exact standard-library replay:

    sha256sum -c SHA256SUMS
    python3 check-complete-triple53.py
