#!/usr/bin/env bash
# One of eight deterministic 32-leaf guarded shards, then exit.
set -euo pipefail
if (( $# != 2 )) || [[ ! $2 =~ ^[0-7]$ ]]; then
 echo 'usage: run-triple-shard.sh PROGRESS SHARD (0..7)' >&2
 exit 2
fi
here="$(cd -- "$(dirname -- "$0")" && pwd -P)"
mkdir -p -- "$1"
p="$(cd -- "$1" && pwd -P)"; start=$((32*$2))
printf -v name 'triple53-%03d' "$start"
out="$p/$name.json"
if [[ -e $out ]]; then
 python3 "$here/triple53.py" verify --quick "$out"; exit
fi
exec 9>"$p/.triple53.lock"
flock -n 9 || { echo 'another q53 worker is running in this directory' >&2; exit 3; }
tmp="$(mktemp -d "$p/.$name.try-XXXXXX")"
export OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 MKL_NUM_THREADS=1
(
 ulimit -v 480000
 exec python3 "$here/prior-pair/prior/measure-child.py" "$tmp/time.log" \
    python3 "$here/triple53.py" generate "$start" 32 "$tmp/result.json"
) >"$tmp/stdout.log" 2>"$tmp/stderr.log"
python3 "$here/triple53.py" verify --quick "$tmp/result.json" >"$tmp/replay.log"
ln -- "$tmp/result.json" "$out"
