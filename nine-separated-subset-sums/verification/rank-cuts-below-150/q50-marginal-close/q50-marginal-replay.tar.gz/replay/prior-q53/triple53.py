#!/usr/bin/env python3
"""A fixed two-pair q53 pilot with exact crossing and adjacency checks."""
import argparse
from fractions import Fraction as F
from functools import lru_cache
from itertools import combinations_with_replacement, product
import json
from pathlib import Path
import sys

HERE=Path(__file__).resolve().parent
OLD=HERE/'prior-pair'
sys.path.insert(0,str(OLD))
import pair50 as p
from central_branch import exact
from central_root_lp import unit
from floor148_root import WITNESSES, mul, oracle, sum_rows
from central_matching import parse

SCHEMA='nine149-q53-two-pairs-d1-pilot-v1'
# Select a residual q50 word with exactly two unexcluded q51 options.
FIRST='+----++'
SELECTED=((FIRST,'-++++-+'),(FIRST,'++---++'))
TOTAL=len(SELECTED)*len(WITNESSES)
KEYS=tuple((a,b,c) for (a,b),c in product(SELECTED,WITNESSES))

def audit_prior():
    seen,counts=p.verify(sorted((OLD/'certificates').glob('pair50-*.json')),complete=True)
    assert len(seen)==5248 and counts=={'exact-structural':3867,'exact-reject':628,'numeric-survivor':753}
    surviving=tuple((r['left'],r['right'])
                    for f in sorted((OLD/'certificates').glob('pair50-*.json'))
                    for r in json.loads(f.read_text())['records'] if r['status']=='numeric-survivor')
    live=set(surviving)
    assert len(live)==753
    assert tuple(q for q in surviving if q[0]==FIRST)==SELECTED
    assert {(a,b) for a,b in live if a==FIRST}==set(SELECTED)

def negword(s):
    return s.translate(str.maketrans('-+','+-'))

def ternary_forms(v,w,z):
    v,w,z,a=map(parse,(v,w,z,p.CENTRAL[:7]))
    # (name, coefficient, lower, upper, strict-upper)
    # Relative support windows are derived in README; lower endpoints outward/closed.
    return (
       ('z',z,104,106,True),
       ('z-v',p.combine7(z,v,-1),3,4,True),
       ('z+v',p.combine7(z,v,+1),101,103,True),
       ('w-z',p.combine7(w,z,-1),F(89,2),47,True),
       ('w+z',p.combine7(w,z,+1),150,152,True),
       ('z-a',p.combine7(z,a,-1),F(3937,78),52,True),
       ('z+a',p.combine7(z,a,+1),53,F(4253,78),True),
    )

@lru_cache(maxsize=2)
def local_vertices(w):
    assert w in {z for _,z in SELECTED}
    if w==SELECTED[0][1]:
        # First-six separation >=3, then one final singleton gap >=2.
        base=(3,6,9,12,15,18,20)
        lo1,hi1=F(3469,78),F(46)
        # x6>=24*3 and x7>=X-(X/44-2)>=1613/11.
        lo6,lo7,hi7=F(54),F(1393,11),F(128)
        grid=(lo1,hi1,lo6,lo7,hi7)
        keep=lambda ys: lo1<=ys[0]<=hi1 and ys[5]>=lo6 and ys[6]>=lo7
    else:
        base=(2,4,6,8,10,12,14)
        lo1,hi1=F(3547,78),F(47)
        grid=tuple(sorted({F(36),F(74),F(134),lo1,hi1,F(46)}))
        keep=lambda ys: lo1<=ys[0]<=hi1 and ys[5]>=36 and ys[6]>=74 and ys[1]<=46
    return tuple(tuple(y+b for y,b in zip(ys,base))
                 for ys in combinations_with_replacement(grid,7) if keep(ys))

@lru_cache(maxsize=None)
def local_range(w,coef):
    vals=[sum(c*x for c,x in zip(coef,vertex)) for vertex in local_vertices(w)]
    return min(vals),max(vals)

def forced_sign(w,coef):
    """Use |form|>=2, or >=3 in the first-six close-top branch."""
    assert any(coef)
    lo,hi=local_range(w,coef)
    gap=3 if w==SELECTED[0][1] and coef[-1]==0 else 2
    pos=lo>-gap
    neg=hi<gap
    return pos,neg

@lru_cache(maxsize=None)
def adjacency(v,w,z):
    """Derive rows if an alternative signed form cannot lie strictly between v,z."""
    V,Z=parse(v),parse(z)
    assert v!=z and v!=negword(z)
    rows=set()
    for k in WITNESSES:
        if k in (v,z,negword(v),negword(z)):
            continue
        K=parse(k)
        a=p.combine7(K,V,-1); b=p.combine7(Z,K,-1)
        ap,an=forced_sign(w,a); bp,bn=forced_sign(w,b)
        if (ap and an) or (bp and bn):
            return ('impossible-small-support:'+k,())
        if ap and bp:
            return ('mandatory-intervening-word:'+k,())
        if ap and not bn:
            rows.add(b)
        if bp and not an:
            rows.add(a)
    # Each recorded form is strictly negative, so is at most -(1+d).
    return None,tuple(sorted(rows))

def structural(v,w,z):
    if w==SELECTED[0][1] and z[-1]=='-':
        return 'first-six-forbidden-window'
    if z in (v,w,negword(v),negword(w)):
        return 'same-absolute-form'
    for name,coef,lo,hi,strict in ternary_forms(v,w,z):
        if not any(coef):
            return 'zero-support:'+name
        a,b=local_range(w,coef)
        if b<lo or (a>=hi if strict else a>hi):
            return 'hull-disjoint:'+name
    reason,_=adjacency(v,w,z)
    return reason

def row_set(v,w,z):
    A,b=p.constraints(v,w)
    X,M=unit(7),unit(8)
    d=sum_rows(M,mul(-1,X)); g=list(parse(p.CENTRAL))
    V,W,Z=(list(parse(k))+[0,0] for k in (v,w,z))
    extra=[
      # Normalize only X,M, preserving all labels and first-seven signed words.
      (d,1), (mul(-1,d),-1),
      (mul(-1,unit(5)),-66),  # Valid by the prior virtual-seven lemma.
      # D52=z-d>=103; D53=z+d<=106+M-149.
      (sum_rows(d,mul(-1,Z)),-103),
      (sum_rows(Z,mul(-1,X)),-43),
      # z-v=D53-D50>=4+2d; both inter-slot gaps >=2.
      (sum_rows(V,mul(-1,Z),mul(2,d)),-4),
      # D52-D51=z+w-2M within [2,4]; close strict right endpoint.
      (sum_rows(mul(2,M),mul(-1,Z),mul(-1,W)),-2),
      (sum_rows(Z,W,mul(-2,M)),4),
      # Add one crossing gap to the shared pair+center excess budget.
      (sum_rows(mul(74,d),mul(2,g),mul(-2,V),mul(-1,W),Z),-210),
    ]
    close7=w==SELECTED[0][1]
    Y=unit(6)
    big_gap=sum_rows(M,mul(-1,Y))  # ell_6=1+(M-Y).
    if close7:
        extra.append((sum_rows(mul(44,big_gap),mul(-1,X)),-44))
        for i in range(6):
            prev=unit(i-1) if i else [0]*9
            extra.append((sum_rows(big_gap,prev,mul(-1,unit(i))),-1))
        for i,k in enumerate((1,2,4,7,13,24)):
            if i:
                extra.append((sum_rows(mul(k,big_gap),mul(-1,unit(i))),-k))
    for _,coef,_,_,_ in ternary_forms(v,w,z):
        assert any(coef)
        gap=big_gap if close7 and coef[-1]==0 else d
        extra.append((sum_rows(gap,mul(-1,list(coef)+[0,0])),-1))
    reason,signrows=adjacency(v,w,z)
    assert reason is None
    for coef in signrows:
        gap=big_gap if close7 and coef[-1]==0 else d
        extra.append((sum_rows(gap,list(coef)+[0,0]),-1))
    return A+[a for a,_ in extra],b+[y for _,y in extra]

def run(start,count):
    assert 0<=start<TOTAL and 1<=count<=TOTAL-start
    rec=[]
    for key in KEYS[start:start+count]:
        why=structural(*key)
        if why is not None:
            status,proof='exact-structural',why
        else:
            A,b=row_set(*key)
            status,proof=oracle(A,b)
        rec.append(dict(signs=key,status=status,proof=proof))
    return dict(schema=SCHEMA,start=start,count=count,records=rec)

def verify(files,quick=False,complete=False):
    assert not (quick and complete)
    if not quick:
        audit_prior()
    seen=set()
    stats={key:{} for key in SELECTED}
    excluded=set()
    for f in files:
        dat=json.loads(f.read_text())
        assert set(dat)=={'schema','start','count','records'} and dat['schema']==SCHEMA
        start,count=dat['start'],dat['count']
        assert type(start)==type(count)==int and 0<=start<TOTAL and 1<=count<=TOTAL-start
        assert len(dat['records'])==count
        for idx,r in enumerate(dat['records'],start):
            assert idx not in seen and set(r)=={'signs','status','proof'}
            seen.add(idx); key=KEYS[idx]
            assert r['signs']==list(key)
            label=r['status']; proof=r['proof']
            why=structural(*key)
            if label=='exact-structural':
                assert why is not None and proof==why
                excluded.add(key)
            elif label=='exact-reject':
                assert why is None and isinstance(proof,dict)
                A,b=row_set(*key)
                assert exact(A,b,proof)
                excluded.add(key)
            else:
                assert why is None and label in ('numeric-survivor','unknown') and proof is None
            d=stats[key[:2]]
            d[label]=d.get(label,0)+1
    if complete: assert seen==set(range(TOTAL))
    for key in SELECTED:
        print(key,stats[key], 'pair excluded:',all(key+(z,) in excluded for z in WITNESSES))
    # Only in an audited replay can coverage of these two pairs eliminate q50 FIRST.
    marginal=not quick and all(key in excluded for key in KEYS)
    print(f'New q50 marginal exclusion: {marginal}; audited theoretical scope only {TOTAL} leaves, not all 753 pairs.')
    return marginal

def main():
    cp=argparse.ArgumentParser()
    sub=cp.add_subparsers(dest='cmd',required=True)
    g=sub.add_parser('generate'); g.add_argument('start',type=int); g.add_argument('count',type=int); g.add_argument('out',type=Path)
    c=sub.add_parser('verify'); c.add_argument('--quick',action='store_true'); c.add_argument('--require-complete',action='store_true'); c.add_argument('files',nargs='+',type=Path)
    a=cp.parse_args()
    if a.cmd=='verify':
        verify(a.files,a.quick,a.require_complete)
    else:
        out=run(a.start,a.count)
        with a.out.open('x') as f:
            json.dump(out,f,sort_keys=True,separators=(',',':'))
            f.write('\n')
        verify([a.out],quick=True)
if __name__=='__main__':
    main()
