"""Rerun the exact archive and cross-check the fixed pilot's sole survivor."""
import json
from pathlib import Path
from collections import Counter
from triple53 import verify

p=Path(__file__).resolve().parent/'certificates'
fs=[p/f'triple53-{32*j:03d}.json' for j in range(8)]
assert set(fs)==set(p.glob('*.json'))
assert not verify(fs,complete=True)
allr=[]
for j,f in enumerate(fs):
    d=json.loads(f.read_text())
    assert (d['start'],d['count'])==(32*j,32)
    allr+=d['records']
assert Counter(r['status'] for r in allr)=={'exact-structural':255,'numeric-survivor':1}
assert [r['signs'] for r in allr if r['status']=='numeric-survivor']==[['+----++','-++++-+','-+---++']]
assert Counter(r['proof'].split(':')[0] for r in allr if r['status']=='exact-structural')=={
    'hull-disjoint':185,'first-six-forbidden-window':64,'same-absolute-form':6}
print('Verified fixed 256-leaf pilot; sole unresolved triple: +----++, -++++-+, -+---++.')
