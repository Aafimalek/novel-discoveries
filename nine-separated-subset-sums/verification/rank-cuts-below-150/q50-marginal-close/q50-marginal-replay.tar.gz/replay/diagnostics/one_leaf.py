import json
import sys
from pathlib import Path
ROOT=Path(__file__).resolve().parent.parent/'prior-q53'
sys.path.insert(0,str(ROOT))
from triple53 import row_set, SELECTED
from floor148_root import sum_rows,mul,oracle
from central_root_lp import unit
from central_branch import exact
KEY=('+----++','-++++-+','-+---++')
def model():
    A,b=row_set(*KEY)
    X,Y=unit(7),unit(6)
    e=sum_rows(X,mul(-1,Y))
    extra=[(e,1),(mul(-1,e),-1),(mul(-1,unit(5)),-72)]
    for i in range(6):
        prev=unit(i-1) if i else [0]*9
        extra.append((sum_rows(prev,mul(-1,unit(i))),-3))
    return A+[a for a,_ in extra],b+[u for _,u in extra]
def main():
    path=Path(sys.argv[-1])
    A,b=model()
    if sys.argv[1]=='generate':
        status,proof=oracle(A,b)
        with path.open('x') as f:
            json.dump(dict(status=status,proof=proof),f,sort_keys=True,separators=(',',':'));f.write('\n')
    r=json.loads(path.read_text())
    if r['status']=='exact-reject':
        assert exact(A,b,r['proof'])
    else:
        assert r['status'] in ('numeric-survivor','unknown') and r['proof'] is None
    print(r)
if __name__=='__main__': main()
