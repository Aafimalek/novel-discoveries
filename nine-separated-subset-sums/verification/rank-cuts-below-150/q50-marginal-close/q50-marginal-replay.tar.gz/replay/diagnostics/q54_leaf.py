"""Single q54 fiber after exact reflection, with independently justified rows."""
from one_leaf import model, KEY, ROOT
import json
from pathlib import Path
import sys
from triple53 import adjacency, SELECTED, p
from floor148_root import slot_rows, sum_rows, mul, oracle
from central_root_lp import unit
from central_branch import exact
from central_matching import parse

W='+-+++-+'
def enhanced():
    A,b=model()
    X=unit(7); t=sum_rows(unit(1),mul(-1,unit(0))); g=list(parse(p.CENTRAL))
    e=slot_rows(54,W)
    # Disjoint close differences in the 3-separated virtual first-six + X.
    for j,k in ((2,3),(3,4),(4,5),(5,7)):
        e.append((sum_rows(t,unit(j),mul(-1,unit(k))),-3))
    # First-six + X permits pairing x6,X; x6 from the central equation >77.
    e.append((mul(-1,unit(4)),-72))
    # First-three sum exceeds X, so their virtual subset gap is >=3.
    e.append((sum_rows(X,mul(-1,unit(0)),mul(-1,unit(1)),mul(-1,unit(2))),-3))
    # Central sign transition at x5,x6 for the virtual 3-separated seven.
    e.append((sum_rows(g,unit(4),mul(-1,unit(5))),-5))
    # q54 and q51 are adjacent in the seven-sign list: ranks 52,53 are a pair.
    why,srows=adjacency(W,SELECTED[0][1],KEY[1])
    if why is not None:
        return None,None,why
    for coef in srows:
        e.append((list(coef)+[0,0],-3 if coef[-1]==0 else -2))
    return A+[a for a,_ in e],b+[r for _,r in e],None
def main():
    path=Path(sys.argv[-1]); A,b,reason=enhanced()
    if sys.argv[1]=='generate':
        status,proof=('exact-structural',reason) if reason else oracle(A,b)
        with path.open('x') as f:
            json.dump(dict(status=status,proof=proof,word=W),f,sort_keys=True,separators=(',',':'));f.write('\n')
    r=json.loads(path.read_text())
    assert r['word']==W
    if r['status']=='exact-reject':
        assert reason is None and exact(A,b,r['proof'])
    elif r['status']=='exact-structural':
        assert reason is not None and r['proof']==reason
    else:
        assert r['status'] in ('numeric-survivor','unknown') and r['proof'] is None and reason is None
    print(r)
if __name__=='__main__': main()
