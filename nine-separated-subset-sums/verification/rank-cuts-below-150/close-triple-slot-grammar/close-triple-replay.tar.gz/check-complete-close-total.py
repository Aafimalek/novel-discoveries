"""Complete exact coverage of 69 close duties and audit all 20 new rational vectors."""
from collections import Counter
from fractions import Fraction as F
from pathlib import Path
import json
from close_total_root import verify, model
from central_branch import STRICT

HERE=Path(__file__).resolve().parent
p=HERE/'certificates'
fs=[p/f'close-total-{j:02d}.json' for j in range(9)]
assert len(fs)==9 and set(fs)==set(p.glob('*.json'))
seen,closed=verify(fs,complete=True)
assert len(seen)==69 and len(closed)==20 and '-----+++-' in closed
assert Counter(s[-3:] for s in closed)=={'+--':10,'++-':8,'+++':1,'---':1}
for j,f in enumerate(fs):
    d=json.loads(f.read_text())
    assert d['shard']==j
    for s,z in d['records'].items():
        if s not in closed:
            assert z['status']=='numeric-survivor'
            continue
        A,b=model(s)
        h={int(i):F(x) for i,x in z['proof'].items()}
        assert A[-1]==[-1]*6+[0,3,0] and b[-1]==-109
        assert h[len(b)-1]>0 and sum(b[i]*q for i,q in h.items())==-1
        if s=='-----+++-':
            assert h[len(b)-1]==F(1,118) and all(not h.get(i,0) for i in STRICT)
print('All 20 exact certificates use the new total row; all have weighted RHS -1.')
print('122 wide duties and 49 close duties remain unresolved; 122 whole signs remain.')
