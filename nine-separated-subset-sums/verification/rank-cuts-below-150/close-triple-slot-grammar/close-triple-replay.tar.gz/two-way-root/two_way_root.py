#!/usr/bin/env python3
"""A staged exact two-way check of the 122 remaining central orientations."""
import argparse
import json
from pathlib import Path
import sys

HERE=Path(__file__).resolve().parent
PRE=HERE/'normalized-root'
sys.path.insert(0,str(PRE))
from normalized_root import rows as normalized_rows, shortlist as earlier_shortlist, verify as normalized_verify
from central_branch import exact
from central_root_lp import unit
from floor148_root import mul, oracle, sum_rows

SCHEMA='nine149-global-block-two-way-v1'
BRANCHES=('pair-wide','triple-close')

def prior_files():
    fs=tuple(PRE/'certificates'/f'normalized-{j:02d}.json' for j in range(16))
    assert set(fs)==set((PRE/'certificates').glob('*.json'))
    return fs

def shortlist():
    exact_keys=set()
    for j,f in enumerate(prior_files()):
        d=json.loads(f.read_text())
        assert d['shard']==j
        exact_keys.update(s for s,r in d['records'].items() if r['status']=='exact-reject')
    assert exact_keys=={'-+----++-','+-++++-+-'}
    ss=tuple(s for s in earlier_shortlist() if s not in exact_keys)
    assert len(ss)==len(set(ss))==122
    return ss

def audit_prior():
    seen,rejected=normalized_verify(prior_files(),full=True)
    assert len(seen)==124 and len(rejected)==2
    assert set(shortlist())==seen-rejected

def rows(branch,sign):
    assert branch in BRANCHES
    A,b=normalized_rows(sign)
    X,Y=unit(7),unit(6)
    e=sum_rows(X,mul(-1,Y))
    if branch=='pair-wide':
        extra=[(mul(-1,e),-2)]
    else:
        extra=[(e,1),(mul(-1,e),-1)]
        # Separation of all first-six subset differences implies these
        # subset/singleton gap instances. The stronger full condition is
        # not independently branched on in this root screen.
        for i in range(6):
            prev=unit(i-1) if i else [0]*9
            extra.append((sum_rows(prev,mul(-1,unit(i))),-3))
        # Virtual separation at scale 3; redundant because X>=148.
        extra.append((mul(-1,X),-132))
    return A+[a for a,_ in extra],b+[r for _,r in extra]

def run(branch,shard):
    assert branch in BRANCHES and 0<=shard<16
    ss=shortlist()
    start=8*shard; count=min(8,len(ss)-start)
    rec={}
    for s in ss[start:start+count]:
        A,b=rows(branch,s)
        status,proof=oracle(A,b)
        rec[s]=dict(status=status,proof=proof)
    return dict(schema=SCHEMA,branch=branch,shard=shard,start=start,count=count,records=rec)

def verify(fs,quick=False,complete=False):
    assert not (quick and complete)
    if not quick:
        audit_prior()
    ss=shortlist()
    seen=set()
    rejects={branch:set() for branch in BRANCHES}
    stats={branch:{} for branch in BRANCHES}
    for f in fs:
        r=json.loads(f.read_text())
        assert set(r)=={'schema','branch','shard','start','count','records'}
        assert r['schema']==SCHEMA
        branch,j,start,count=(r[k] for k in ('branch','shard','start','count'))
        assert branch in BRANCHES and type(j)==type(start)==type(count)==int
        assert 0<=j<16 and start==8*j and count==min(8,len(ss)-start)
        assert set(r['records'])==set(ss[start:start+count])
        for s,leaf in r['records'].items():
            assert (branch,s) not in seen and set(leaf)=={'status','proof'}
            seen.add((branch,s))
            label,proof=leaf['status'],leaf['proof']
            if label=='exact-reject':
                A,b=rows(branch,s)
                assert isinstance(proof,dict) and exact(A,b,proof)
                rejects[branch].add(s)
            else:
                assert label in ('numeric-survivor','unknown') and proof is None
            q=stats[branch]
            q[label]=q.get(label,0)+1
    if complete:
        assert seen=={(branch,s) for branch in BRANCHES for s in ss}
    both=rejects[BRANCHES[0]] & rejects[BRANCHES[1]]
    for branch in BRANCHES:
        print(branch,stats[branch])
    print('Unions of branch rejections are not orientation conclusions.')
    if not quick:
        print('New complete orientation exclusions (both branches):',len(both))
        print('Remaining whole orientations:',122-len(both))
    return seen,rejects,both

def main():
    p=argparse.ArgumentParser()
    c=p.add_subparsers(dest='cmd',required=True)
    g=c.add_parser('generate')
    g.add_argument('branch',choices=BRANCHES); g.add_argument('shard',type=int); g.add_argument('out',type=Path)
    v=c.add_parser('verify')
    v.add_argument('--quick',action='store_true'); v.add_argument('--require-complete',action='store_true')
    v.add_argument('files',nargs='+',type=Path)
    a=p.parse_args()
    if a.cmd=='verify':
        verify(a.files,a.quick,a.require_complete)
    else:
        d=run(a.branch,a.shard)
        with a.out.open('x') as f:
            json.dump(d,f,sort_keys=True,separators=(',',':'))
            f.write('\n')
        verify([a.out],quick=True)
if __name__=='__main__':
    main()
