# Global block normalization and verified 122-orientation two-way screen

The self-contained written theorem in global-block-normalization.md
normalizes the unique short adjacent pair or triple in **any**
unit-separated real configuration while preserving every labeled
subset-sum comparison. Its largest weight does not increase.
In the hypothetical nine final slice, this leaves precisely two
branches to consider:

* **pair-wide:** \(M-X=1\) and \(X-x_7\ge2\).
* **triple-close:** \(M-X=1\) and \(X-x_7=1\).

The exact normalized predecessor screen is included, byte-for-byte,
under normalized-root/. Its replay excludes 390 of the 512 central
signs (388 baseline and two further exact rejections). The two further
certificates actually use only \(x_6\ge66\) among added rows, so apply
even before normalization. To reproduce this archived result:
    
    cd normalized-root
    sha256sum -c SHA256SUMS
    python3 check-complete-normalized.py

That is the prior verified result, not a result of the staged
two-way extension. The completed screen leaves the normalized root
constraints as a prefix. The wide branch adds only
\(X-x_7\ge2\). The close branch instead adds
\(X-x_7=1\) (two non-strict rows), \(x_1\ge3\), the five adjacent
singleton gaps among the first six at least 3, and the virtual
real-seven lower bound \(X\ge132\). The last row is redundant
with the inherited \(X\ge148\), and is included to mark the
independent virtual-weight implication. No universal signed
disjunction over the first-six subset differences is encoded
by those singleton rows. No q-slot, contact, or mixed-gap
exploration is included.

The exact verifier reconstructs all 390 prior exclusions
before obtaining the exact 122-element shortlist. It then verifies
both branch duties for each unresolved orientation as separate
disjoint shards. A new orientation counts as excluded only if
**both** its wide and close branches have their own rational
Farkas certificate. No numerical survivor or unknown is a proof.
The combined full coverage requirement is exactly 122 × 2 attempted
duties; it never treats missing shards as checked.

## Commands after resource clearance

Reserve one light worker and run one shard at a time. Each branch
has 16 shards of eight orientations except its last with two.
Use a new progress directory and stop on any guard or process error.
The archived one-process guard limits measured RSS to 130000 KiB,
virtual mapping space to 480000 KiB, and each shard to 8 s, with
one numerical thread. These guard settings were inherited
from the preceding checked run. This package includes receipts.

    sha256sum -c SHA256SUMS
    ./run-two-way-shard.sh progress pair-wide 0
    # ... after clearance, pair-wide 1..15 and triple-close 0..15, serially.
    python3 two_way_root.py verify --require-complete progress/*.json

The exact replay uses standard Python fractions and the recorded
two original strict bounds, with no SciPy import. Only numerical
hint generation imports SciPy. See RESULTS.md for the precise exact scope and outcome. No new Lean result is claimed.
