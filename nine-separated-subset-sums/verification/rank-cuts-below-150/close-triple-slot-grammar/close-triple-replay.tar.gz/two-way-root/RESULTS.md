# Exact terminal-pair/triple root screen

All 32 deterministic serial shards completed, covering both branches for
each of the 122 residual central orientations. The predecessor exact
replay accounts for the other 390 orientations.

| Branch | Exact rejections | Not excluded by this root screen |
|---|---:|---:|
| Terminal pair, \(x_8-x_7\ge2\) | 0 | 122 |
| Terminal triple, \(x_8-x_7=1\) | 53 | 69 |

The intersection is empty, so no additional whole orientation was
excluded. Exactly 122 whole orientations and 191 out of the 244
tested branch obligations remain unresolved by this screen.
The 191 numerical survivors are not certified feasible chambers or
examples of unit-separated weights.

The 53 exclusions have a short independent explanation. They are
exactly the residual central words with \(s_7=-,s_8=+\).
Write \(e=x_8-x_7\) and \(g\) for the positive central gap.
Flipping just coordinates 7 and 8 in the full central word produces
a different complementary signed pair. Its gap has absolute value
\(|g-2e|\ge g+2\). Since \(e\ge1\) and \(g<2\), this gives
\(2e-g\ge g+2\), hence \(e\ge g+1\ge2\).
It excludes the triple branch \(e=1\) but not the wide branch.
All 53 Farkas vectors use only the appended \(e\le1\) row, not any
of the additional close-case spacings or virtual bound. Eliminating
that row from the exact vector gives \(e\ge2\) on every one of
these prior normalized orientations, with no strict row needed.
The checker independently verifies this projected consequence and
the exact sign-position description.

The original process watchdog measured at most 60,968 KiB child RSS
and 1.13 s elapsed in an individual shard; the 32 child times sum to
21.03 s. All guards passed. The package includes the all-dimension
short-block proof; this computation used only the stated two branch
root relaxations, not any slot or boundary exploration.

Exact standard-library replay with full branch coverage:

    sha256sum -c SHA256SUMS
    python3 check-complete-two-way.py
