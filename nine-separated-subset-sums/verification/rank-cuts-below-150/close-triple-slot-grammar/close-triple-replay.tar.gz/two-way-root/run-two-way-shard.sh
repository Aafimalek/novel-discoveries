#!/usr/bin/env bash
set -euo pipefail
if (( $# != 3 )) || [[ ! $2 =~ ^(pair-wide|triple-close)$ ]] || [[ ! $3 =~ ^([0-9]|1[0-5])$ ]]; then
    echo 'usage: run-two-way-shard.sh PROGRESS pair-wide|triple-close SHARD-ID (0..15)' >&2
    exit 2
fi
here="$(cd -- "$(dirname -- "$0")" && pwd -P)"
mkdir -p -- "$1"
p="$(cd -- "$1" && pwd -P)"; branch=$2; shard=$3
printf -v name '%s-%02d' "$branch" "$shard"
out="$p/$name.json"
if [[ -e $out ]]; then
    python3 "$here/two_way_root.py" verify --quick "$out"; exit
fi
exec 9>"$p/.two-way-root.lock"
flock -n 9 || { echo 'another two-way worker is running in this directory' >&2; exit 3; }
tmp="$(mktemp -d "$p/.$name.try-XXXXXX")"
export OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 MKL_NUM_THREADS=1
(
    ulimit -v 480000
    exec python3 "$here/normalized-root/measure-child.py" "$tmp/time.log" \
         python3 "$here/two_way_root.py" generate "$branch" "$shard" "$tmp/result.json"
) >"$tmp/stdout.log" 2>"$tmp/stderr.log"
python3 "$here/two_way_root.py" verify --quick "$tmp/result.json" >"$tmp/replay.log"
ln -- "$tmp/result.json" "$out"
