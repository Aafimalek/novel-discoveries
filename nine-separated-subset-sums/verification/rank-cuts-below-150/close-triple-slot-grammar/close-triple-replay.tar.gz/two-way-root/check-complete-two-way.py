"""Check exact coverage, then audit the simple proof represented by all 53 leaves."""
from fractions import Fraction as F
from pathlib import Path
import json
from two_way_root import BRANCHES, rows, normalized_rows, shortlist, verify
from central_branch import STRICT

d=Path(__file__).resolve().parent/'certificates'
files=[d/f'{br}-{j:02d}.json' for br in BRANCHES for j in range(16)]
assert len(files)==32 and set(files)==set(d.glob('*.json'))
seen,rejects,both=verify(files,complete=True)
assert len(seen)==244 and not both
assert not rejects['pair-wide']
ss=shortlist()
adjacent={s for s in ss if s[6:8]=='-+'}
assert len(adjacent)==53 and rejects['triple-close']==adjacent
for f in files:
    dat=json.loads(f.read_text())
    br,j=dat['branch'],dat['shard']
    assert f.name==f'{br}-{j:02d}.json'
    for s,r in dat['records'].items():
        if s not in rejects[br]:
            assert r['status']=='numeric-survivor'
            continue
        A,b=rows(br,s); n=len(normalized_rows(s)[0])
        y={int(i):F(q) for i,q in r['proof'].items()}
        assert A[n]==[0]*6+[-1,1,0] and b[n]==1
        assert set(y)&set(range(n,len(b)))=={n} and y[n]>0
        assert all(not y.get(i,0) for i in STRICT)
        assert 1-sum(b[i]*q for i,q in y.items())/y[n]==2
print('All 53 exact close-branch proofs project to e>=2 and are the central -+ transition at positions 7–8.')
