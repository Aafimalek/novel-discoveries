#!/usr/bin/env python3
"""Staged full normalized exact root screen on the certified residual 124."""
import argparse
import json
from pathlib import Path
from central_branch import exact
from central_matching import parse
from central_root_lp import unit
from floor148_root import KEYS, constraints, mul, oracle, replay, sum_rows

HERE=Path(__file__).resolve().parent
SCHEMA='nine149-floor148-normalized-d1-v1'

def shortlist():
    ss=tuple((HERE/'residual-signs.txt').read_text().splitlines())
    aset=set(ss)
    assert len(ss)==len(aset)==124
    assert ss==tuple(s for s in KEYS if s in aset)
    assert {s[-2:] for s in ss}=={'+-','--','++'}
    return ss

def audit_baseline():
    fs=[]
    for start in range(0,512,8):
        f=HERE/'baseline-certificates'/f'root-{start:03d}.json'
        r=json.loads(f.read_text())
        assert (r['kind'],r['sign'],r['q'],r['start'],r['count'])==('root',None,None,start,8)
        fs.append(f)
    roots,slots,covered=replay(fs)
    assert len(roots)==388 and not slots and not covered
    assert shortlist()==tuple(s for s in KEYS if s not in roots)

def rows(sign):
    A,b=constraints(sign)
    X,M=unit(7),unit(8); d=sum_rows(M,mul(-1,X))
    g=list(parse(sign))
    # n is number of uncharged packed tokens after freeing the central gap.
    n=38 if sign.endswith('+-') else 37
    extra=[
        (d,1), (mul(-1,d),-1),                 # normalized d=1
        (mul(-1,unit(5)),-66),                 # scaled virtual-seven pairing
        (mul(-1,unit(6)),-88),                 # first-seven whole configuration
        (sum_rows(mul(n,d),mul(-1,X),g),n-146) # central defect
    ]
    return A+[a for a,_ in extra],b+[u for _,u in extra]

def generate(j):
    ss=shortlist()
    assert 0<=j<16
    start=8*j; count=min(8,len(ss)-start)
    data={}
    for s in ss[start:start+count]:
        A,b=rows(s)
        label,proof=oracle(A,b)
        data[s]={'status':label,'proof':proof}
    return dict(schema=SCHEMA,shard=j,start=start,count=count,records=data)

def verify(files,quick=False,full=False):
    assert not (quick and full)
    ss=shortlist()
    if not quick:
        audit_baseline()
    seen=set(); stats={}; rejected=set()
    for f in files:
        d=json.loads(f.read_text())
        assert set(d)=={'schema','shard','start','count','records'}
        assert d['schema']==SCHEMA
        j=d['shard']; start=d['start']; count=d['count']
        assert type(j)==type(start)==type(count)==int
        assert 0<=j<16 and start==8*j and count==min(8,len(ss)-start)
        assert set(d['records'])==set(ss[start:start+count])
        for s,r in d['records'].items():
            assert s not in seen and set(r)=={'status','proof'}
            seen.add(s)
            label,proof=r['status'],r['proof']
            if label=='exact-reject':
                A,b=rows(s)
                assert isinstance(proof,dict) and exact(A,b,proof)
                rejected.add(s)
            else:
                assert label in ('numeric-survivor','unknown') and proof is None
            stats[label]=stats.get(label,0)+1
    if full:
        assert seen==set(ss), ('incomplete normalized coverage',len(seen))
    print(f'Normalized orientations attempted: {len(seen)}/124; checked statuses: {stats}')
    print('New exact normalized orientation rejections:',len(rejected))
    if not quick:
        print('Unexcluded normalized orientations:',124-len(rejected))
    return seen,rejected

def main():
    p=argparse.ArgumentParser()
    sub=p.add_subparsers(dest='cmd',required=True)
    g=sub.add_parser('generate'); g.add_argument('shard',type=int); g.add_argument('out',type=Path)
    v=sub.add_parser('verify'); v.add_argument('--quick',action='store_true'); v.add_argument('--require-complete',action='store_true'); v.add_argument('files',nargs='+',type=Path)
    a=p.parse_args()
    if a.cmd=='verify':
        verify(a.files,a.quick,a.require_complete)
    else:
        d=generate(a.shard)
        with a.out.open('x') as f:
            json.dump(d,f,sort_keys=True,separators=(',',':'))
            f.write('\n')
        verify([a.out],quick=True)

if __name__=='__main__':
    main()
