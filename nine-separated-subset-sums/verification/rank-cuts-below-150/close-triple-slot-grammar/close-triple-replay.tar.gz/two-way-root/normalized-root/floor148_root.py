#!/usr/bin/env python3
"""Deterministic bounded final-floor Farkas generation and Fractions-only replay."""
import argparse
from fractions import Fraction
from itertools import product
import json
from pathlib import Path

from central_branch import STRICT, arrays as central_arrays, exact
from central_matching import parse
from central_root_lp import unit
from moment_central_lp import cuts as moment_cuts, rational_on_support

KEYS = tuple("".join(s) for s in product("-+", repeat=9))
WITNESSES = tuple("".join(s) for s in product("-+", repeat=7))
QS = (50,51,53,54,60,61,63,64)
SCHEMA = "nine149-floor148-farkas-v1"

def sum_rows(*rows):
    return [sum(col) for col in zip(*rows)]

def mul(k, a):
    return [k*x for x in a]

def final_cuts():
    X, M = unit(7), unit(8)
    # x8>=148; 39*(M-X-1)<=M-148.
    yield mul(-1,X), -148
    yield sum_rows(mul(38,M),mul(-39,X)), -109
    # x1>=1+d, x(i+1)-x(i)>=1+d for every i<=6.
    d = sum_rows(M,mul(-1,X))
    for j in range(7):
        weaker = unit(j-1) if j else [0]*9
        yield sum_rows(d,weaker,mul(-1,unit(j))), -1

def slot_rows(q, word):
    v = list(parse(word)) + [0,0]
    X, M = unit(7), unit(8)
    assert q in QS and word in WITNESSES
    if q in QS[::2]:
        # Dq=d+v, 2q-1 <= Dq <= 2q + M-149.
        return [(sum_rows(mul(-1,v),X,mul(-1,M)),1-2*q),
                (sum_rows(v,mul(-1,X)),2*q-149)]
    # Dq=X+M-v and the same Dq envelope.
    return [(sum_rows(mul(-1,v),X),2*q-149),
            (sum_rows(v,mul(-1,X),mul(-1,M)),1-2*q)]

def constraints(sign,q=None,word=None):
    A,b=central_arrays(parse(sign),[])
    extra=list(moment_cuts())+list(final_cuts())
    if q is not None: extra+=slot_rows(q,word)
    return A+[a for a,_ in extra],b+[c for _,c in extra]

def oracle(A,b):
    import numpy as np
    from scipy.optimize import linprog
    factors=np.array([max(1,max(abs(x) for x in a),abs(z)/150) for a,z in zip(A,b)])
    D=np.asarray(A)/factors[:,None]; r=np.asarray(b)/factors
    C=np.array([int(i in STRICT) for i in range(len(b))])/factors
    l=linprog([0]*9+[-1],A_ub=np.column_stack((D,C)),b_ub=r,
              bounds=[(None,None)]*9+[(0,None)],method='highs')
    if l.status==0 and l.x[-1]>1e-8: return "numeric-survivor",None
    if l.status==2:
        q=linprog(np.zeros(len(b)),A_eq=np.vstack((D.T,r)),b_eq=[0]*9+[-1],
                  bounds=[(0,None)]*len(b),method='highs')
        if q.status!=0: return "unknown",None
        w=q.x; strict_case=False
    elif l.status==0:
        w=-l.ineqlin.marginals; strict_case=True
    else:
        return "unknown",None
    for tol in (1e-8,1e-10,1e-13,0.0):
        ids=[i for i,v in enumerate(w) if v>tol]
        proof=rational_on_support(A,b,ids,strict_case)
        if proof is not None:
            assert exact(A,b,proof)
            return "exact-reject",proof
    return "unknown",None

def calculate(kind,sign,q,start,count):
    assert kind in ("root","slot")
    keys=KEYS if kind=="root" else WITNESSES
    assert 0<=start<len(keys) and 1<=count<=len(keys)-start
    if kind=="slot": assert sign in KEYS and q in QS
    else: assert sign is None and q is None
    rec={}
    for k in keys[start:start+count]:
        A,b=constraints(k) if kind=="root" else constraints(sign,q,k)
        label,proof=oracle(A,b)
        rec[k]={"status":label, "proof":proof}
    return dict(schema=SCHEMA,kind=kind,sign=sign,q=q,start=start,count=count,records=rec)

def replay(paths):
    roots=set(); slots={}; attempted=set()
    for path in paths:
        d=json.loads(path.read_text())
        assert set(d)=={"schema","kind","sign","q","start","count","records"}
        assert d['schema']==SCHEMA and d['kind'] in ("root","slot")
        kind,sign,q,start,count=(d[k] for k in ("kind","sign","q","start","count"))
        if kind=="root": assert sign is None and q is None
        else: assert sign in KEYS and q in QS
        keys=KEYS if kind=="root" else WITNESSES
        assert type(start)==int and type(count)==int
        assert 0<=start<len(keys) and 1<=count<=len(keys)-start
        assert set(d['records'])==set(keys[start:start+count])
        for k,r in d['records'].items():
            ident=(kind,sign,q,k)
            assert ident not in attempted,("duplicate attempted entry",ident)
            attempted.add(ident)
            assert set(r)=={"status","proof"}
            if r["status"]=="exact-reject":
                A,b=constraints(k) if kind=="root" else constraints(sign,q,k)
                assert isinstance(r["proof"],dict) and exact(A,b,r["proof"]),ident
                if kind=="root": roots.add(k)
                else: slots.setdefault((sign,q),set()).add(k)
            else:
                assert r["status"] in ("numeric-survivor","unknown") and r["proof"] is None
    covered={(sign,q) for (sign,q),words in slots.items() if words==set(WITNESSES)}
    print("Verified root rejections:",len(roots))
    print("Verified slot-sign option rejections:",sum(map(len,slots.values())))
    print("Verified complete orientation+slot rejections:",len(covered))
    print("Verified distinct whole orientation rejections:",len(roots|{s for s,_ in covered}))
    print("Attempts in provided files:",len(attempted),"(not a global run)")
    return roots,slots,covered

def main():
    ap=argparse.ArgumentParser()
    sub=ap.add_subparsers(dest="cmd",required=True)
    def common(p):
        p.add_argument("--start",type=int,default=0)
        p.add_argument("--count",type=int,default=8)
        p.add_argument("out",type=Path)
    common(sub.add_parser("root"))
    slot=sub.add_parser("slot")
    common(slot)
    slot.add_argument("sign",choices=KEYS)
    slot.add_argument("q",type=int,choices=QS)
    ver=sub.add_parser("verify")
    ver.add_argument("files",type=Path,nargs="+")
    a=ap.parse_args()
    if a.cmd=="verify": replay(a.files); return
    d=calculate(a.cmd,getattr(a,"sign",None),getattr(a,"q",None),a.start,a.count)
    # Exclusive create prevents accidentally replacing a prior shard.
    with a.out.open("x") as f: json.dump(d,f,sort_keys=True,separators=(",",":")); f.write("\n")
    replay([a.out])

if __name__=="__main__":
    main()
