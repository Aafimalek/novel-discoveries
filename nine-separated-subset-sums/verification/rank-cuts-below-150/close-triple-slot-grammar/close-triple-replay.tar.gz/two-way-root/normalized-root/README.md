# Normalized d=1 root screen for the nine-weight floor-148 branch

This is the verified root-screen package (see RESULTS.md). It covers the 124 central
orientations remaining after the exact baseline rejected 388 of 512.
The original 64 integer/Fraction replayable shards are included and
rechecked by the final verifier before it derives their exact
124-element complement. The strengthened root screen is a relaxation,
not full signed-chamber coverage.

Assume a hypothetical unit-separated real nine-weight configuration in
the already established final slice

\[
149\le M=x_9<150,\qquad 148\le X=x_8<149,\qquad
1\le d=M-X<41/39.
\]

## Exact normalization, preserving the labeled order

Take the midpoint \(Y=(X+M)/2\) and replace the last two coordinates
by \(X'=Y-1/2\), \(M'=Y+1/2\). This moves \(X\) weakly upward
and \(M\) weakly downward, preserves \(X+M\), and sets
\(M'-X'=1\). The new weights are still in the same final slice:
\(X'\ge X\ge148\), \(M'\le M<150\), \(M'\ge149\), and
\(X'<149\). Only these two weights move.

Let \(D\) be the finite set of all positive differences of first-seven
subset scores. Any \(e\in D\) is initially at least 1. Comparing
opposite middle shifts gives \(|e-d|\ge1\), and \(d-1<1\), so
\(e\ge1+d\). Comparing the two smaller upper shifts separately gives
\(|e-X|,|e-M|\ge1\). Their forbidden open windows overlap since
\(d<2\), so \(e\) must satisfy
\[
e\le X-1\quad\text{or}\quad e\ge M+1.
\]
In either case \(e\) remains at least 1 away from both \(X'\) and \(M'\)
and stays on the same side of each.

Here is why this covers *all* labeled score comparisons. A full subset
score is a first-seven score plus one of
\(0,X,M,X+M\). The positive gaps between shift labels are \(X\), \(M\),
\(d\), and \(X+M\): the first two change inward inside the old
interval \([X,M]\), the middle difference \(d\) decreases to 1, and the
total shift is fixed. For a positive base difference \(e\), the signs
of comparisons with \(X,M\) and their margins are as above; against
\(d\) one has \(e-d\ge1\) and that margin only grows; against \(X+M\)
nothing changes. Comparisons with matching shift labels are unchanged,
and expressions adding a base gap to a positive shift gap remain
positive with at least unit margin. Equal base labels give only the
shift-gap tests, all still at least 1. The order of the four shift
labels themselves is unchanged. Consequently every labeled comparison
keeps its sign and its distance remains at least 1.

This proves the normalized subspace contains a representative of
every candidate, with exactly the same ordering of all 512 labeled
subsets. In particular the original central orientation and all
forced rank-edge identities persist.

## Extra written root rows

The first-seven configuration is \((1+d)\)-separated, so the exact
\(f_{\mathbb R}(7)=44\) result in
[Notik, arXiv:2611.17360](https://arxiv.org/abs/2611.17360)
already gives \(x_7\ge88\).
Furthermore the midpoint \(Y=(X+M)/2\) of the old top two
satisfies \(Y>x_7\), and the base differences avoid the open
interval centered at \(Y\) with radius \(1+d/2\). Thus first seven
weights together with \(Y\) form an eight-weight configuration
of separation \(1+d/2\). Replace the pair \(x_7,Y\) by its positive
difference. Specifically, translating the reduced subset sums by
\(x_7\) identifies them with full subset sums selecting exactly one
of \(x_7,Y\). Hence the seven weights
\((x_1,\ldots,x_6,Y-x_7)\) retain separation \(1+d/2\).
Here \(Y<149.5\) and \(x_7\ge88\), so the auxiliary weight
\(Y-x_7<61.5<66\). The real-seven lower bound implies their largest
weight is at least \(44(1+d/2)\ge66\), proving \(x_6\ge66\)
(and even \(x_6\ge44(1+d/2)\) before normalization).
The first six weights are unchanged by normalization.

The program uses the inherited rank, matching and moment rows,
then adds the equality \(M-X=1\) as two non-strict inequalities
and the lower bounds \(x_6\ge66,\ x_7\ge88\). It also retains
the central-gap defect row
\[
n_0(d-1)+(g-1)\le X-147,
\]
where \(g\) is the positive central gap, and \(n_0=38\) for top
signs \(+-\), \(n_0=37\) for equal top signs. This is justified by
the earlier packed defect proof (the middle-center gap is not a
swap token, and at most one token must be dropped for an outer
center). At \(d=1\) it is redundant by \(g<2\) and \(X\ge148\),
but keeping it makes the model scope explicit. No optional
slot, boundary, or outer-band split is tested here.

## Active endpoints at fixed first seven

After normalization write \(X=t\), \(M=t+1\). The top additions
are \(0,t,t+1,2t+1\). At fixed first-seven weights the comparisons
are equivalent to the already known base gap \(\ge2\), together with
avoiding two open windows for each \(e\in D\):
\[
e\notin(t-1,t+2),\qquad e\notin(2t,2t+2).
\]
Fix the side of each window determined by the current rank chamber.
If \(e\le t-1\), this contributes \(t\ge e+1\); if \(e\ge t+2\),
it contributes an upper bound, automatically preserved by downward
motion. Similarly \(e\le2t\) contributes \(t\ge e/2\), and
\(e\ge2t+2\) contributes only an upper bound. Therefore at fixed
first-seven weights one may decrease \(t\) to the largest member
of the finite set
\[
\{148\}\cup\{e+1:e\in D,\ e\le t-1\}
       \cup\{e/2:e\in D,\ e\le2t\}.
\]
All inequalities are weak at the selected endpoint and all scores
remain separated by at least 1 with identical labels in order.
The singleton lower bound \(t\ge x_7+1\) is already among the
first type of contact since \(e=x_7\) is a base difference.
Thus some active boundary is \(t=148\), \(e+1\), or \(e/2\) in
a feasible representative, but the staged computation does not
branch on these possibilities. The separately written optional
top-three reduction is in close-top-three-normalization.md;
it too is not enforced in this screen.

## Guard and replay

Run only after resource clearance, one worker at a time. The fixed
16 shards contain eight cases each, except the last has four.
Every completed root rejection is a standard-library exact
nonnegative rational Farkas check (zero weighted coefficients,
with negative weighted RHS or appropriate original strict rows).
Numerical survivor/unknown statuses prove nothing. A guard failure
never counts; final replay checks exact disjoint coverage.

    sha256sum -c SHA256SUMS
    ./run-normalized-shard.sh progress 0
    # Only when cleared, continue serially through shard 15.
    python3 normalized_root.py verify --require-complete progress/normalized-*.json

The inherited runner caps one numerical process group at 8 s and
130000 KiB monitored resident memory (with post-exit high-water
audit), 480000 KiB virtual address space, and one BLAS/OMP thread.
Numerical hints were used for generation only; no Lean result is claimed.
