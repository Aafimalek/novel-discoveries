# Optional close-top-three normalization (written only)

This observation is outside the staged root screen.

Let \(Y=x_7,\ X=x_8,\ M=x_9\) and suppose both adjacent top gaps
\(e=X-Y\) and \(d=M-X\) belong to \([1,2)\). In the final slice
\(X\ge148\), so all positive top-three signed differences are
classified, in increasing magnitude bands, as follows:

- low: \(e,d,d+e\);
- middle: \(Y-d,Y,Y+d,X,M,M+e\), with outermost values
  \(Y-d=X-(d+e)\) and \(M+e=X+(d+e)\);
- high: \(Y+X,Y+M,X+M\), with outermost values \(T-M,T-Y\);
- fixed top value \(T=Y+X+M\).

For any positive first-six subset difference \(b\), comparison with
each positive top signed difference \(c\) gives \(|b-c|\ge1\).
All low radius-one windows connect and contain 1, so
\(b\ge1+d+e\). In the middle band just the centers
\(Y-d,Y,X,M,M+e\) suffice to join the whole radius-one corridor
from \(Y-d-1\) to \(M+e+1\): its center gaps are \(d,e,d,e<2\).
The high centers likewise fill the high corridor from \(T-M-1\)
to \(T-Y+1\).

Put \(C=T/3=X+(d-e)/3\) and replace the three top weights by
\((C-1,C,C+1)\). The new band of low centers is \(\{1,2\}\),
which lies at least 1 below every positive first-six difference
because \(b\ge1+d+e\ge3\); the old low centers likewise lie below.
The new middle centers range from \(C-2\) to \(C+2\).
They are all within the old extrema: \(d+e-2\ge|d-e|\),
so \(|C-X|+2\le d+e\). Every first-six gap is already outside
the old connected forbidden corridor, hence is at distance
at least 1 and on the same side under every such middle comparison.
The new high extrema are also nested: \(C-1\ge Y\) and
\(C+1\le M\) from \(d,e\ge1\), so the high extrema become
\(T-(C+1)\ge T-M\) and \(T-(C-1)\le T-Y\).
The total \(T\) is fixed. The eight top shifts themselves preserve
their order: after zero, the three singleton shifts increase,
then the three pair shifts increase, then the triple, and all
new consecutive shift gaps are at least 1. (Their large-group
separation follows already from \(C>147\).)
This proves every labeled full subset comparison preserves order
and unit separation after the replacement.

In particular after the \(d=1\) normalization, the branch
\(1\le e<2\) may be reduced further to \(e=d=1\), at the new
\(X=C=X-(e-1)/3\). Its maximum \(C+1\) is at most the old \(M\);
the earlier nine-weight bound \(f_{\mathbb R}(9)\ge149\) implies
\(C\ge148\), so the new configuration is still in the final slice.
The other branch \(e\ge2\) is not covered by this triple normalization.

For this further normalized branch the eight top shifts are precisely

    0; X−1,X,X+1; 2X−1,2X,2X+1; 3X.

All the positive labeled differences of these shifts are in the
four bands just described. Consequently admissibility at fixed
first-six weights is exactly base spacing at least 3 together
with avoidance, by each positive first-six difference \(b\), of
\[
(X-3,X+3),\qquad (2X-2,2X+2),\qquad (3X-1,3X+1).
\]
At fixed labels one may lower \(X\) until it contacts \(148\)
or one of the lower sides \(X=b+3\), \(X=(b+2)/2\),
or \(X=(b+1)/3\), as in the two-weight endpoint argument.
These additional contacts are not part of the staged screen.
