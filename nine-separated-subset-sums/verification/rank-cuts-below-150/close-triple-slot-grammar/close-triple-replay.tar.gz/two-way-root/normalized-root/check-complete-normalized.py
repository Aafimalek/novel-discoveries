"""Exact full scope, and audit that the two certificates already hold before d=1."""
from fractions import Fraction as F
from pathlib import Path
import json
from central_branch import exact
from floor148_root import constraints
from normalized_root import rows, shortlist, verify

d=Path(__file__).resolve().parent/'certificates'
files=[d/f'normalized-{j:02d}.json' for j in range(16)]
assert set(files)==set(d.glob('*.json'))
seen,rejects=verify(files,full=True)
assert seen==set(shortlist())
assert rejects=={'-+----++-','+-++++-+-'}
for j,f in enumerate(files):
    dat=json.loads(f.read_text())
    assert dat['shard']==j
    for s,r in dat['records'].items():
        if s not in rejects:
            assert r['status']=='numeric-survivor'
            continue
        A,b=rows(s)
        n=len(constraints(s)[0])
        assert A[n+2]==[0]*5+[-1]+[0]*3 and b[n+2]==-66
        coeff={int(i):F(t) for i,t in r['proof'].items()}
        assert set(coeff)&set(range(n,len(b)))=={n+2}
        assert coeff[n+2]>0
        rhs=sum(b[i]*q for i,q in coeff.items())
        assert rhs==-1
        small={str(i if i<n else n):str(q) for i,q in coeff.items()}
        assert exact(A[:n]+[A[n+2]],b[:n]+[b[n+2]],small)
        print(s,': uses x6>=66 alone among new rows; RHS',rhs)
print('Combined original plus new exact exclusions: 390 of 512; residual 122.')
