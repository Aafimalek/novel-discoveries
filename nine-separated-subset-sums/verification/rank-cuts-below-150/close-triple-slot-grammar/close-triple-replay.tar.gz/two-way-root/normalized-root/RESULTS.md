# Exact normalized floor-148 root screen

All 16 deterministic guarded shards completed, covering all 124
central orientations not already excluded by the 388 verified
baseline certificates. Independent standard-library Fraction replay
proved exactly two additional exclusions:

    -+----++-
    +-++++-+-

The resulting count is 390 of 512 central orientations excluded,
with 122 not excluded by this screen. The 122 were numerical
survivors of the relaxed LP; none is an actual configuration or
a certified feasible chamber.

A useful support check: both rational vectors use the row
\(x_6\ge66\), with respective positive coefficients \(1000/6929\)
and \(1000/1929\), and neither vector uses the new \(d=1\),
\(x_7\ge88\) or extra central-defect rows. Both have weighted RHS
\(-1\). The checker independently discards all new rows except
\(x_6\ge66\) and replays both vectors again. Because the midpoint
argument for that lower bound already applies before normalization,
these two rejections also apply directly to the original
unnormalized final slice.

The numeric hint generator used one process group at a time,
one BLAS/OMP thread, a 130000 KiB resident-space watchdog,
480000 KiB virtual mapping cap and 8 s elapsed cap per shard.
The 16 child elapsed times sum to 12.99 s; the longest was
0.99 s, and maximum audited child RSS was 60732 KiB.
No optional boundary, slot, q53, or close-top-three subproblem
was searched.

Standard-library replay:

    sha256sum -c SHA256SUMS
    python3 check-complete-normalized.py
