# Unique short-block normalization preserving every labeled subset comparison

**Theorem.** Let \(1\le x_1<\cdots<x_n\) be positive real weights
with unit-separated subset sums. An adjacent gap is *short* if
it is below 2. There is either no short gap, one short gap,
or two consecutive short gaps. In the latter two cases the
affected pair or triple can be replaced by equally spaced weights
with adjacent gap exactly 1 and the same sum. This preserves the
entire labeled subset-sum order and unit separation, leaves all
outside weights fixed, does not decrease either adjacent outside
gap, and weakly decreases the largest weight.

In particular every feasible sign chamber has a representative
in which each adjacent gap is exactly 1 or is at least 2, and
at most one consecutive pair or triple can have gaps equal to 1.
The analogous conclusion for separation at least \(\lambda>0\)
follows by scaling all weights by \(1/\lambda\).

## Uniqueness of the short block

Write \(g_i=x_{i+1}-x_i\); every \(g_i\ge1\) by separation of
singletons. If \(i+1<j\) and both \(g_i,g_j<2\), compare the two
original subsets \(\{i+1,j\}\) and \(\{i,j+1\}\). Their signed
difference is \(g_i-g_j\in(-1,1)\), a contradiction.
Thus any two short indices must be consecutive. Three distinct
short indices would have a nonconsecutive pair. This proves the
claimed cases, including the empty case \(n=1\).

## One pair or triple can be treated as a block

All full scores are the sum of an outside score and a labeled
block score. Let \(b>0\) be any positive difference of two outside
scores, and \(c>0\) any positive difference of two block scores.
Since the coordinate groups are disjoint, comparing opposite
differences gives \(|b-c|\ge1\); also \(b\ge1\).
An order-preserving block replacement is therefore sufficient if
each positive labeled block difference stays positive and at least
one, and every \(b\) stays on the same side of its corresponding
block difference with a gap of at least one.
The comparison with equal block labels is unchanged; adding a
positive block gap to \(b\) never causes a sign or separation issue.
If there are no positive outside differences these conditions are
vacuous and only the block's own comparison matters.

### Pair

Let the block be \(Y,X\) with \(d=X-Y\in[1,2)\).
Its positive shifted differences are \(d,Y,X,Y+X\).
The condition \(|b-d|\ge1\), with \(b\ge1>d-1\), yields
\(b\ge1+d\). The unit-radius forbidden windows around \(Y\)
and \(X\) overlap, so every outside \(b\) obeys
\(b\le Y-1\) or \(b\ge X+1\).
Replace the pair by \(C-1/2,C+1/2\), where \(C=(Y+X)/2\).
Both singleton centers stay in \([Y,X]\); accordingly their
comparisons with \(b\) stay on the same side and unit separated.
The difference \(d\) decreases to 1, safely below every \(b\)
as before. The total is fixed. Block-only labels preserve their
strict order, and all their new consecutive gaps are at least one.

### Triple

Let the block be \(Y,X,M\), with \(e=X-Y\in[1,2)\) and
\(d=M-X\in[1,2)\). Because the disjoint subsets consisting of
\(Y,X\) and \(M\) are themselves unit-separated,
\(|Y-d|=|Y+X-M|\ge1\). Since \(Y\ge1\) and \(d<2\) imply
\(Y-d>-1\), it follows that \(Y-d\ge1\).
In particular \(Y\ge2\).

Up to reversing sign the thirteen nonzero-support signed block
forms have the following positive magnitudes:
\[
\begin{array}{ll}
\text{low:}& d,\ e,\ d+e;\\
\text{middle:}& Y-d,\ Y,\ Y+d,\ X,\ M,\ M+e;\\
\text{high:}& Y+X,\ Y+M,\ X+M;\\
\text{total:}& T=Y+X+M.
\end{array}
\]
These are labeled classes; their numerical ranges can overlap for
small blocks. Disjointness is not used.
The low forbidden windows overlap and contain 1; their union
extends to \(1+d+e\). Hence every positive outside difference
satisfies \(b\ge1+d+e\).
The middle centers \(Y-d,Y,X,M,M+e\) are successive distances
\(d,e,d,e\) apart, all below 2, and their windows cover the entire
open corridor \((Y-d-1,M+e+1)\). The other middle form
\(Y+d\) lies between those extrema. Similarly the high centers
span the connected forbidden interval \((T-M-1,T-Y+1)\),
since their consecutive spacings are \(d,e\).

Put \(C=T/3=X+(d-e)/3\), and replace the triple by
\((C-1,C,C+1)\).
The new low magnitudes 1 or 2 stay at least one below every
\(b\), as were the old low magnitudes.
The new middle centers lie between \(C-2\) and \(C+2\).
They stay within the old middle center range
\([X-(d+e),X+d+e]\), because \(d,e\ge1\) give
\[
|C-X|+2=|d-e|/3+2\le d+e.
\]
Similarly \([C-1,C+1]\subseteq[Y,M]\), since
\(C-Y=(2e+d)/3\ge1\) and \(M-C=(e+2d)/3\ge1\).
Thus the new high range \([T-(C+1),T-(C-1)]\) nests inside
the old high range. Every \(b\) avoids each old connected
forbidden interval, so its relative side and unit margin against
the corresponding middle or high form are unchanged.
The total remains fixed.

For the block's own comparisons, the original eight labeled
subset scores occur in the order zero; the three singleton
scores; the three pair sums; the total.
The singleton maximum \(M\) precedes the minimum pair sum
\(Y+X\) by at least one (proved above). The internal orders
of singleton and pair groups follow sorted weights.
For the new triple we have \(C\ge3\). The corresponding
boundary gap between the largest singleton and smallest pair
is \(C-2\ge1\), and all other new consecutive gaps are at least
one. Hence all labeled block comparisons also retain direction
and separation. The rule for full comparisons now proves the
theorem.

## Endpoints and the nine-weight final slice

The normalized block minimum is weakly larger than its old
minimum, and its maximum is weakly smaller. Thus the
outside-to-block gaps, whenever present, cannot shrink.
The unchanged gaps elsewhere were already at least 2.
The maximum decreases strictly if the block ends with the
largest weight and at least one block gap was originally larger
than 1. Also an identified block's outside differences retain
their stronger \((1+d)\)-separation for a pair or
\((1+d+e)\)-separation for a triple, since its outside weights
never move. If desired the interpolation is safe too: every
comparison is affine in the weights, with the same fixed sign
and margin at both ends.

In the nine-weight slice \(149\le M=x_9<150\),
\(148\le X=x_8<149\), the last gap \(d=M-X<2\) is short.
The unique short block must terminate at coordinate 9. There
are just two possibilities:

1. Last pair only: \(e=X-x_7\ge2\); pair normalization gives
   \(d=1\), leaves the first seven weights unchanged and
   makes \(e\) no smaller.
2. Last triple: \(e<2\); triple normalization gives \(e=d=1\).
   The first six weights are unchanged and have gap at least 3
   between any distinct subset sums.
   At the normalized top differences, comparing with the top
   signed middle centers \(X-2,X-1,X,X+1,X+2\) yields the
   open forbidden interval \((X-3,X+3)\) for positive first-six
   differences. Appending the virtual weight \(X\) to the first
   six therefore gives seven 3-separated weights.
   From the exact real-seven lower bound 44 in
   [Notik, arXiv:2611.17360](https://arxiv.org/abs/2611.17360)
   it follows that \(X\ge3\cdot44=132\).
   This last bound happens to be redundant when \(X\ge148\).

Normalization cannot increase the largest weight; if it fell
below 149 this would contradict the separately established
real-nine bound. Thus the normalized representative remains
in the same floor-148 slice. Every labeled rank comparison, so
also its central sign word, is unchanged. Closure of both
branches would be needed to rule out that sign word.
