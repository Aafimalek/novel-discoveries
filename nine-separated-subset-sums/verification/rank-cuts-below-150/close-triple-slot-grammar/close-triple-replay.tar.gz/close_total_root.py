#!/usr/bin/env python3
"""Staged S6>=3X+109 screen on exactly 69 close-branch survivors."""
import argparse
import json
from pathlib import Path
import sys

HERE=Path(__file__).resolve().parent
PRE=HERE/'two-way-root'
sys.path.insert(0,str(PRE))
from two_way_root import BRANCHES, rows as old_rows, shortlist as old_shortlist, verify as prior_verify
from central_branch import exact
from floor148_root import oracle

SCHEMA='nine149-close-triple-slot-grammar-root-v1'
CANONICAL=('+++','++-','+--','---')

def prior_files():
    d=PRE/'certificates'
    fs=tuple(d/f'{br}-{j:02d}.json' for br in BRANCHES for j in range(16))
    assert set(fs)==set(d.glob('*.json'))
    return fs

def shortlist():
    rej=set()
    for f in prior_files():
        r=json.loads(f.read_text())
        if r['branch']=='triple-close':
            rej.update(k for k,z in r['records'].items() if z['status']=='exact-reject')
    ss=tuple(s for s in old_shortlist() if s not in rej)
    assert len(rej)==53 and len(ss)==len(set(ss))==69
    assert all(s[-3:] in CANONICAL for s in ss)
    assert '-----+++-' in ss
    return ss

def audit_prior():
    seen,rejects,both=prior_verify(prior_files(),complete=True)
    assert len(seen)==244 and not both and not rejects['pair-wide'] and len(rejects['triple-close'])==53
    assert set(shortlist())==set(old_shortlist())-rejects['triple-close']

def model(sign):
    assert sign[-3:] in CANONICAL
    A,b=old_rows('triple-close',sign)
    return A+[[-1]*6+[0,3,0]],b+[-109]

def run(shard):
    ss=shortlist()
    assert 0<=shard<9
    start=8*shard; count=min(8,len(ss)-start)
    data={}
    for sign in ss[start:start+count]:
        A,b=model(sign)
        status,proof=oracle(A,b)
        data[sign]=dict(status=status,proof=proof)
    return dict(schema=SCHEMA,shard=shard,start=start,count=count,records=data)

def verify(files,quick=False,complete=False):
    assert not (quick and complete)
    if not quick:
        audit_prior()
    ss=shortlist()
    seen=set(); rejects=set(); stats={}
    for f in files:
        r=json.loads(f.read_text())
        assert set(r)=={'schema','shard','start','count','records'} and r['schema']==SCHEMA
        j,start,count=(r[k] for k in ('shard','start','count'))
        assert type(j)==type(start)==type(count)==int
        assert 0<=j<9 and start==8*j and count==min(8,len(ss)-start)
        assert set(r['records'])==set(ss[start:start+count])
        for sign,case in r['records'].items():
            assert sign not in seen and set(case)=={'status','proof'}
            seen.add(sign); label,proof=case['status'],case['proof']
            if label=='exact-reject':
                A,b=model(sign)
                assert isinstance(proof,dict) and exact(A,b,proof)
                rejects.add(sign)
            else:
                assert label in ('numeric-survivor','unknown') and proof is None
            stats[label]=stats.get(label,0)+1
    if complete:
        assert seen==set(ss), ('incomplete close branch coverage',len(seen))
    print(f'Close branch duties checked: {len(seen)}/69; statuses:',stats)
    print('New complete close-only certificates:',len(rejects))
    if not quick:
        print('Unexcluded close duties by replayed root calculations:',69-len(rejects))
        print('No whole orientation is excluded by a close-only screen; no wide duty tested.')
    return seen,rejects

def main():
    p=argparse.ArgumentParser()
    c=p.add_subparsers(dest='cmd',required=True)
    g=c.add_parser('generate');g.add_argument('shard',type=int);g.add_argument('out',type=Path)
    v=c.add_parser('verify');v.add_argument('--quick',action='store_true');v.add_argument('--require-complete',action='store_true');v.add_argument('files',type=Path,nargs='+')
    a=p.parse_args()
    if a.cmd=='verify':
        verify(a.files,a.quick,a.require_complete)
    else:
        d=run(a.shard)
        with a.out.open('x') as f:
            json.dump(d,f,sort_keys=True,separators=(',',':')); f.write('\n')
        verify([a.out],quick=True)

if __name__=='__main__': main()
