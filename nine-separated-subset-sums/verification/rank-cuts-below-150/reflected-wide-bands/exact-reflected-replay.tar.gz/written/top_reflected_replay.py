"""Finite top-word propagation, not a real LP or a full chamber proof."""
from itertools import product,combinations
Q=(50,53,60,63)
ONE=('+--','-+-','--+')
TWO=('++-','+-+','-++')
CHOICES=tuple(product(tuple(product('+-',repeat=2)),repeat=4))
DIST={}
for fam,kinds in ((ONE,('e','1')),(TWO,('1','e'))):
    for i,x in enumerate(fam):
        DIST[x]=tuple((y,1 if j>i else -1,kinds[min(i,j)] if abs(i-j)==1 else 'e+1')
                      for j,y in enumerate(fam) if i!=j)

def complement(c):return '+' if c=='-' else '-'
def reflected(x):
    assert x[-1]=='+'
    return ''.join(complement(c) for c in x[:2])+'+'

def tight_band(i,j):
    return (i<=64 and j<=64) or (i>=85 and j>=85)

def possible(i,direction,kind,m):
    if kind=='1':
        j=i+direction
        return (j,) if 1<=j<=99 else None
    h=m+int(kind=='e+1')
    far=i+direction*h
    # Upward lifts are positive. Downward lifts have raw value >-1
    # if i-h>=1 and thus must be positive by unit separation/first support.
    if not 1<=far<=99:return None
    near=i+direction*(h-1)
    assert 1<=near<=99
    return (far,) if tight_band(i,near) else (near,far)

def permitted(m,p,use_singletons):
    if use_singletons:
        for (q,(_,w)),(r,(_,z)) in combinations(zip(Q,p),2):
            if w==z=='-' and r-q in (m,m+1):return False
    selected={}
    def put(i,label):
        if i in selected and selected[i]!=label:return False
        selected[i]=label
        return True
    for q,(v,w) in zip(Q,p):
        l=(v+'+-',v+'-+',complement(w)+'++')
        for j,t in zip((q-1,q,q+1),l):
            if not put(j,t):return False
        for j,t in zip((q,q+1),l[1:]):
            if not put(149-j,reflected(t)):return False
    change=True
    while change:
        change=False
        for i,t in tuple(sorted(selected.items())):
            for u,d,k in DIST.get(t,()):
                candidates=possible(i,d,k,m)
                if candidates is None:continue
                choices=tuple(j for j in candidates if selected.get(j,u)==u)
                if not choices:return False
                if len(choices)==1 and choices[0] not in selected:
                    assert put(choices[0],u)
                    change=True
    return True

def encode(p): return ' '.join(''.join(k) for k in p)
def viable(m,gate=False):return tuple(p for p in CHOICES if permitted(m,p,gate))
if __name__=='__main__':
    assert len(CHOICES)==256
    assert not viable(5)
    for m in (9,10):
        assert tuple(map(encode,viable(m)))==('-+ -+ +- +-',)
    assert len(viable(34))==8
    assert tuple(map(encode,viable(35)))==('-+ -+ -+ -+',)
    for m in range(4,61):
        raw=viable(m); ext=viable(m,True)
        print(m,len(raw),len(ext),' / '.join(map(encode,raw)) if len(raw)<=1 else '')
