# Reflected signed-rank band removes \([4.5,6)\) from the wide case

This is a conditional result in the established nine-weight final
slice. Use the order-preserving top-pair normalization \(M=X+1\),
where \(X=x_8\in[148,149)\), \(M=x_9\), \(Y=x_7\), \(e=X-Y\),
and \(\delta=X-148\). The earlier wide analysis gives \(e\ge4\);
the exact first-seven lower bound gives \(Y\ge88\), so \(e<61\).
We prove the necessary disjunction
\[
   4\le e<4.5\quad\hbox{or}\quad 6\le e<61 .
\]
This does not exclude the entire wide or floor-148 slice.

## Reflected forced edges and exact displacement

Order the 512 scores \(s_i\) increasingly, and write \(S\) for
the total weight. Complement sends rank \(i\) to \(513-i\).
For the full positive signed magnitudes \(D_j\), exactly one per
complementary word pair, \(D_j=2s_{256+j}-S\). Their positive
oriented words are unique; every adjacent magnitude gap is at
least 2 by the two reflected rank steps.

The eight established forced rank edges have lower endpoints
\(k=u+108\) and upper endpoints \(k+148=u+256\), where
\[
 u\in\{50,51,53,54,60,61,63,64\}.
\]
Each adds coordinate 9, so \(s_{k+148}-s_k=M\). The complement
of its lower endpoint is rank \(513-k=256+(149-u)\). Hence
\[
     D_u+D_{149-u}=2M.
\]
For their signed words, the upper endpoint and the complement of
the lower endpoint have opposite bits on all first eight
coordinates and both contain coordinate 9. In particular, at the
reflected magnitude the three top signs become
\((s_7,s_8,+)\mapsto(-s_7,-s_8,+)\).

Put \(\theta_j=D_j-2j\), necessarily nondecreasing. The old
central envelope gives \(-1\le\theta_j\le\delta\) for
\(1\le j\le64\). The reflection identity yields
\(\theta_u+\theta_{149-u}=2\delta\).
Using \(u=50,64\), the width in the reflected band is
\[
 \theta_{99}-\theta_{85}=\theta_{64}-\theta_{50}
              \le1+\delta<2.
\]
The full interval \(1\) through \(99\) has width
\(\theta_{99}-\theta_1\le2\delta+2<4\).
Consequently a **positive** signed lift of absolute displacement
\(2h+2f\), with integer \(h\ge1\) and \(0\le f<1\), has rank
displacement exactly \(h\) when both endpoints are within either
small-width band \(1..64\) or \(85..99\). If both ranks are only
known to lie in \(1..99\), the possible displacements are
\(h-1,h\) (ignoring a zero displacement when the magnitude
difference is nonzero). To see this, for increasing indices the
numerical displacement equals twice the rank displacement plus a
nonnegative difference in \(\theta\), which is \(<2\) or \(<4\),
respectively. Before applying an upper bracket, the global step
bound 2 already gives rank displacement at most \(h\).

The same-prefix one-plus top pattern has ordered words
\(\texttt{+--},\texttt{-+-},\texttt{--+}\) with successive
positive raw displacement \(2e,2\). The two-plus words
\(\texttt{++-},\texttt{+-+},\texttt{-++}\) have raw
displacement \(2,2e\). These are just signed sums of
\(Y,X,M=X+1\) at a fixed signed first-six prefix.
We only invoke a step where the new raw value remains positive.

## Exclude \(5\le e<6\)

For \(q=50,53,60,63\) the prescribed lower words at
\(q-1,q,q+1\) have top signs
\[
 (v_7,+,-),\qquad(v_7,-,+),\qquad(-w_7,+,+),
\]
and their positive magnitudes at \(q-1,q\) are \(v_q-1,v_q+1\).
Here \(v_7,w_7\) are the seventh signs in the corresponding two
oriented first-seven forms.

Use the \(w\) at index 54 (the second member for \(q=53\)).
If \(w_7=+\), the top signs at \(D_{54}\) are \(\texttt{-++}\).
Its same-prefix \(\texttt{+-+}\) lift is \(D_{54}-2e>0\)
since \(D_{54}\ge107\) and \(2e<12\). Its rank is 49:
by global step bound it is at most five positions lower
and both ends are in the low band. The exact displacement
inside that band is five. But \(D_{49}\) has last two signs
\(+-\), not the required \(-+\).

If \(w_7=-\), then \(D_{54}\) has top word \(\texttt{+++}\)
and its reflected partner at index \(149-54=95\) has word
\(\texttt{--+}\). The same-prefix \(\texttt{+--}\) lift
is precisely \(D_{95}-2(e+1)>0\).
Positivity follows from \(D_{95}\ge189\) and \(2(e+1)<14\).
By min-step 2 its target is at most six ranks below 95, so
within \(89..94\), all in the reflected small-width band.
That band's exact displacement gives rank 89.
But rank 89 reflects \(D_{60}\), whose prescribed last
two signs are \(-+\). Its reflection has last two signs
\(++\), conflicting with \(\texttt{+--}\).
Both cases contradict sign uniqueness.

## Exclude \(4.5\le e<5\)

Write \(e=4+f\), \(0\le f<1\). Use a lift with
displacement \(2e\) from each of \(q=50,60\).
If \(v_q(7)=+\), the top word at \(D_q\) is
\(\texttt{+-+}\), and its positive \(\texttt{-++}\)
lift is \(D_q+2e\), exactly at \(q+4\) (inside low ranks).
If \(v_q(7)=-\), the predecessor \(D_{q-1}\)
has \(\texttt{-+-}\), and its \(\texttt{+--}\) lift
is \(D_{q-1}-2e>0\), exactly at \(q-5\).
In each case the \(\theta\) increase on the four-rank
interval is \(2f\). At \(q=50\) the two possible intervals
are \([45,49]\) and \([50,54]\); at \(q=60\) they are
\([55,59]\) and \([60,64]\). Whichever signs occur,
the intervals are disjoint and ordered.
Monotonicity and the low band width then give
\[
 4f\le1+\delta<2.
\]
Thus \(f<1/2\), proving the claim. In fact on this branch
\(4e\le X-131\); the prepared root split uses only its
weaker closed relaxation \(e\le4.5\), not this affine
dependency.

## Finite necessary top propagation

The accompanying standard-library integer checker uses the
four pairs' eight initial signs. It seeds the low ranks and
their predetermined reflected high partners and propagates
the two same-prefix families. Exact displacement 2 takes
one rank. For a displacement \(2e\) or \(2(e+1)\),
use \(h=\lfloor e\rfloor\) or \(h=\lfloor e\rfloor+1\),
respectively. Impose the rule only when the farther nominal
rank is in \(1..99\); the other candidate (one step closer)
is then in range as well. A downward lift is positive in
this case: \(D_i\ge2i-1\), \(i-h\ge1\) and \(f<1\) give
its raw value strictly above \(-1\). Unit separation of
this nonzero-support signed word makes it at least 1.
Remove the closer candidate whenever it lies with the
source inside the same small-width band, since that
displacement cannot reach \(2h\). Remove any slot already
assigned an incompatible top word. No remaining target
rejects a seed pattern, and one target permits its assignment.
A two-target ambiguity is retained, never resolved heuristically.

This is a necessary top-label consistency check only; it
does not track equality of the underlying signed first-six
prefixes and does not solve a real chamber. It gives zero
top assignments for \(m=5\); one each for \(m=9,10,35\);
and eight for \(m=34\). The unique surviving sign pairs
in increasing \(q\) order are \((-+,-+,+-,+-)\) at 9 and
10 and \((-+,-+,-+,-+)\) at 35. The optional earlier
negative-\(w\) singleton consistency test is exposed as a
second count; for this propagation table it removes
no additional top assignments. No feasibility conclusion
follows from any nonzero count. No numerical solver or Lean
formalization contributes to this finite replay.
