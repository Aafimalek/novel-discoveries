"""Exact complete coverage and separately audited wide/close intersection."""
import json,re
from pathlib import Path
from reflected_split import BRANCHES, verify, model, e4_rows
from wide_e3 import audit_old as independent_close_audit
here=Path(__file__).resolve().parent
p=here/'certificates'
fs=[p/f'{br}-{j:02d}.json' for br in BRANCHES for j in range(16)]
assert len(fs)==32 and set(fs)==set(p.glob('*.json'))
seen,closed,wide=verify(fs,complete=True)
assert len(seen)==244 and not any(closed.values()) and not wide
for i,f in enumerate(fs):
    x=json.loads(f.read_text())
    br,j=x['branch'],x['shard']
    assert j==i%16 and f.name==f'{br}-{j:02d}.json'
    for s,r in x['records'].items():
        oldA,oldb=e4_rows(s)
        A,b=model(br,s)
        extra=([0]*6+[-2,2,0],9) if br=='low45' else ([0]*6+[1,-1,0],-6)
        assert A==oldA+[extra[0]] and b==oldb+[extra[1]]
        assert r=={'status':'numeric-survivor','proof':None}
close=independent_close_audit()
assert len(close)==73
whole=wide & close
assert not whole
logs=[dict(re.findall(r'(\w+)=([\d.]+)',f.read_text())) for f in (here/'timing').glob('*.log')]
assert len(logs)==32 and all(r['guard_status']=='0' for r in logs)
print('Guard audits: sum/max seconds/peak KiB',
      round(sum(float(r['elapsed']) for r in logs),2),
      max(float(r['elapsed']) for r in logs),max(int(r['max_child_rss_kib']) for r in logs))
print('Exact low/high/wide/full exclusions:',*[len(closed[z]) for z in BRANCHES],len(wide),len(whole))
print('Residual 122 low, 122 high across 122 wide; 49 close, 122 whole.')
