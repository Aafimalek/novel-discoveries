"""Exact two-way wide root screen, prepared only."""
from pathlib import Path
import argparse,json,sys
HERE=Path(__file__).resolve().parent
OLD=HERE/'prior-wide-e4'
sys.path.insert(0,str(OLD))
from wide_e4 import rows as e4_rows,shortlist,verify as old_verify
from central_branch import exact
from floor148_root import oracle
SCHEMA='nine149-wide-reflected-split-v1'
BRANCHES=('low45','high6')
EXTRA={'low45':([0]*6+[-2,2,0],9),'high6':([0]*6+[1,-1,0],-6)}

def audit_old():
    old=OLD/'certificates'
    files=[old/f'wide-e4-{j:02d}.json' for j in range(16)]
    assert set(files)==set(old.glob('*.json'))
    seen,closed=old_verify(files,complete=True)
    assert len(seen)==122 and not closed

def model(branch,sign):
    A,b=e4_rows(sign)
    a,z=EXTRA[branch]
    return A+[a],b+[z]

def generate(branch,j):
    ss=shortlist(); assert len(ss)==122 and 0<=j<16
    start=8*j;count=min(8,len(ss)-start); out={}
    for s in ss[start:start+count]:
        A,b=model(branch,s)
        label,proof=oracle(A,b)
        out[s]=dict(status=label,proof=proof)
    return dict(schema=SCHEMA,branch=branch,shard=j,start=start,count=count,records=out)

def verify(files,quick=False,complete=False):
    assert not (quick and complete)
    if not quick:audit_old()
    ss=shortlist(); assert len(ss)==122
    seen=set(); closed={p:set() for p in BRANCHES}; stats={p:{} for p in BRANCHES}
    for f in files:
        r=json.loads(f.read_text())
        assert set(r)=={'schema','branch','shard','start','count','records'} and r['schema']==SCHEMA
        p,j,a,n=(r[k] for k in ('branch','shard','start','count'))
        assert p in BRANCHES and type(j)==type(a)==type(n)==int and 0<=j<16 and a==8*j and n==min(8,len(ss)-a)
        assert set(r['records'])==set(ss[a:a+n])
        for s,c in r['records'].items():
            assert (p,s) not in seen and set(c)=={'status','proof'}
            seen.add((p,s)); label,proof=c['status'],c['proof']
            A,b=model(p,s); A0,b0=e4_rows(s)
            assert A[:-1]==A0 and b[:-1]==b0
            assert (A[-1],b[-1])==EXTRA[p]
            if label=='exact-reject':
                assert isinstance(proof,dict) and exact(A,b,proof); closed[p].add(s)
            else:
                assert label in ('numeric-survivor','unknown') and proof is None
            stats[p][label]=stats[p].get(label,0)+1
    if complete:assert seen=={(p,s) for p in BRANCHES for s in ss}
    for p in BRANCHES: print(p,stats[p])
    both=closed['low45']&closed['high6']
    if not quick:
        print('Wide orientations newly excluded only after both exact branches:',len(both))
        print('No close branch tested; partial wide exclusions are not whole orientations.')
    return seen,closed,both

def main():
    p=argparse.ArgumentParser(); c=p.add_subparsers(dest='cmd',required=True)
    g=c.add_parser('generate');g.add_argument('branch',choices=BRANCHES); g.add_argument('shard',type=int);g.add_argument('out',type=Path)
    v=c.add_parser('verify');v.add_argument('--quick',action='store_true');v.add_argument('--require-complete',action='store_true');v.add_argument('files',type=Path,nargs='+')
    a=p.parse_args()
    if a.cmd=='verify':verify(a.files,a.quick,a.require_complete)
    else:
        d=generate(a.branch,a.shard)
        with a.out.open('x') as f:json.dump(d,f,sort_keys=True,separators=(',',':'));f.write('\n')
        verify([a.out],quick=True)
if __name__=='__main__':main()
