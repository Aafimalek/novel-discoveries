# Prepared anonymous rank-capacity pilot (no solve)

One deterministic prior duty only: m=9, first of the 122 inherited
central-word orientations, ID 0, '------+++'. The exact input of the
continuous pilot for this duty is copied as source-id000-m9.json and
its SHA-256 is pinned in pilot.py. The copied source is only used for
anchored ranges, signs, and labels; its continuous constraints are not
charged as anonymous integer rows. This new input is a necessary outer
integer relaxation, not an equivalent reformulation.

## Coverage from actual ranks

Normalize M=X+1, Y=X-e, with X in [148,149) and 9<=e<10.
Use the containing closed rectangle X in [148,149], e in [9,10].
Every real solution has 32 distinct positive first-six full-signed
magnitudes at pairwise distance >=4. The copied graph for this
orientation has nine disjoint absolute prefix intervals, including
the anchored central prefix. Treat those nine magnitudes as known
anchors and the other 23 as anonymous. Every anonymous magnitude
a lies in [2,798]: indeed a<=S_6<=6Y-42<=798 by the ordered
first-seven coordinate gaps >=2.

Each positive a generates the eight full nine signed magnitudes
|lambda_i +/- a|, where the four positive shifts are
Y-1, Y+1, X+e+1, 3X+1-e. These eight for each of 32 prefixes
are exactly the complete 256 positive complementary nine-sign
magnitudes in an actual configuration. Thus distinct generated
values are always >=2 apart. This also certifies that no unknown
spawn can equal an anchored threshold.

Use the fixed thresholds D41,D50,D60,D64. They were chosen before
any solver, to sample the bottom edge of the propagated packet and
the three later subblocks; the labels include both dimer imbalance
signs and zero. Use the proven envelope D_j in [2j-1,2j+1] for
j<=64. The first bin is strictly below D41, the final bin begins
at D64, and all other bins include their lower but not upper
threshold. Full bin populations are (40,9,10,4,193).

All 72 anchored spawns have exactly one possible bin, as witnessed
in model.json by the graph rank label or outer interval arithmetic.
For a graph label meeting its threshold, the endpoint is counted
in the later bin. Missing graph labels are distinct from all
thresholds, therefore use strict comparisons. In an interval
[m,M] for a missing spawn, bin k requires M>threshold[k-1].min
and m<threshold[k].max, omitting nonexistent endpoints. These are
only necessary interval tests; allowed bins need not all occur.
They choose a unique bin for every anchored spawn in the pinned
pilot. In particular anchored bin counts are (2,6,6,4,54).
Anonymous bin counts must therefore be exactly (38,3,4,0,139).

The lambda_1/lambda_2 images of one signed prefix are adjacent
dimers: the top centers Y-1,Y,Y+1 prohibit a from (Y-2,Y+2),
so absolute values of these two same-prefix expressions are
always distance exactly 2. For a cut D_j the count below the
cut from lambda_1 minus the count below from lambda_2 is -1
if the top label at j is --+, +1 if it is +-+, and 0 otherwise.
Entirely lower dimers cancel, and only the upper endpoint of
the containing dimer can leave one unmatched lower contribution.
For this pilot the anchored imbalances are exactly (0,-1,1,0),
which already match the cut labels. The four residual
anonymous dimer imbalance equations all have RHS zero.

## Finite endpoint and occupancy proof

model.json contains all rational closed outer spawn boxes, endpoint
cells, rank bins per spawn, and an exact reason for every omitted
cell. Split [2,798] by the step-4 grid and the endpoints of all
computed uniformly forbidden open intervals. Keep all endpoints as
separate singleton cells unless explicitly certified forbidden.
The exact capacity of an open cell of width w is at most ceil(w/4);
a singleton has capacity one. Consecutive retained cells also get
any tightening of the sum of their capacities from a common
closed interval of width w, at most floor(w/4)+1. These latter
constraints do not require cells to touch. Gaps between cells
merely weaken this closed-span estimate.

Two sources of forbidden intervals are |a-a_i|<4 for an anchor
a_i, or |a-c|<1 for any top signed center c. If the moving center
is known in [L,H], the interval (H-r,L+r) is uniformly forbidden
with distance r. A third source is collision of the spawn
|lambda_i+s*a| with an anchored spawn in [b_min,b_max]. For either
absolute-value orientation t, force R=t(lambda_i+s*a) uniformly
positive and between b_max-2 and b_min+2. With
[t*lambda_i]_range=[L,H], the open interval
max(0,b_max-2)-L < t*s*a < b_min+2-H suffices.
Every point in it is uniformly banned irrespective of the actual
rectangle or anchored variables. The model discards an open cell
only if one such open interval contains it (coincident endpoints
are fine for open cells); discarding a singleton requires strict
containment. The code also supports deleting a cell when a spawn
has no possible rank bin, which did not occur in this pilot.

For each kept cell C, the integer mass n_C is the number of
anonymous magnitudes there; sum n_C=23. Each of its eight spawn
types allocates n_C occurrences among its allowed rank bins.
A type with only one possible bin uses n_C directly, without
an allocation variable. Global sums enforce the exact residual
rank and dimer equations above. As optional safe coupling:
if one same-prefix spawn is always <= another on C, cumulative
allocations below every threshold must be at least as large for
the first. This includes |lambda_i-a|<lambda_i+a, the increasing
positive-shift line, and negative-shift ordering when 2a is
certifiably on one side of lambda_i+lambda_j. All capacities,
comparisons and row coefficients are exact integers.

An actual configuration maps directly to these columns by counting
its anonymous magnitudes and their actual ranks. Consequently an
infeasibility certificate excludes this one floor/central duty.
A feasible assignment would not settle anything: internal unknown
spawns can conflict, their individual memberships are relaxed to
cohorts, and anonymous magnitudes need not come from six additive
weights. No whole orientation or floor exclusion is reported.

## Commands and exact proof interface

    sha256sum -c SHA256SUMS
    python3 pilot.py verify
    python3 test_checker.py

The verifier reconstructs the complete covered interval, all omission
and bin receipts, and the exact sparse rows from the pinned input and
compares the bytes of model.json. The synthetic checker test checks
only the proof interface, not feasibility of this pilot. To
reproduce the input from scratch, remove or move model.json and run
`python3 pilot.py prepare` (exclusive output creation).

A later search may supply a JSON proof tree and run

    python3 pilot.py exclude path/to/proof.json

A node {"split":i,"cut":k,"left":...,"right":...} covers the disjoint
integer domains z_i<=k and z_i>=k+1 inside the current bound box.
A leaf {"combine":[[row_index,"positive-rational"],...]} certifies
a nonnegative row combination whose minimum possible left-hand side
in the current box is already strictly larger than its RHS.
Every arithmetic check is exact Fraction arithmetic; both children
are required, duplicate JSON keys and duplicate leaf indices are
rejected. This proof format is complete in principle for bounded
integer infeasibility (one can split to singletons), not a claim
that the resulting trees will be small. Do not run Python with
assertions disabled.

Input frozen: 404 retained cells, 27 omitted cells, 560 columns,
347 rows. No LP, integer solver, Lean, or Git was run. No exclusion.
