from pilot import check_tree

# Synthetic integer z in [0,1] with incompatible half-integral constraints.
# Real z=1/2 survives; exhaustive integer branching must cover both values.
model = {"upper": [1], "rows": [[[[0, -2]], -1, "z>=1/2"],
                               [[[0, 2]], 1, "z<=1/2"]]}
valid={"split":0,"cut":0,"left":{"combine":[[0,"1/2"]]},
                        "right":{"combine":[[1,"3/2"]]}}
assert check_tree(model,valid)==2
bad=(dict(valid,right=valid["left"]),dict(valid,cut=1),{"combine":[[0,1],[1,1]]},
     {"combine":[[0,1],[0,2]]},{"combine":[[0,-1]]})
for proof in bad:
    try:check_tree(model,proof)
    except AssertionError:pass
    else:raise AssertionError("invalid proof accepted")
print("synthetic exact proof-interface tests passed; no pilot feasibility test")
