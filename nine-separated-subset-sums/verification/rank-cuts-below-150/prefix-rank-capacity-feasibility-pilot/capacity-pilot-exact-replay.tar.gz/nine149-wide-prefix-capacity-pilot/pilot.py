#!/usr/bin/env python3
"""Capacity-only outer integer model, m=9 / frozen orientation 0. No solver."""
from bisect import bisect_right
from fractions import Fraction as F
from hashlib import sha256
from itertools import product
from pathlib import Path
import argparse
import json

HERE = Path(__file__).resolve().parent
SOURCE = HERE / "source-id000-m9.json"
SOURCE_SHA = "0579f3860262c7b1a883f54f6760ff09798cb324427aa3d09623e83e8fa23881"
CUTS = (41, 50, 60, 64)
TOP = ("++-", "+-+", "-++", "+++")
SIGNS = (-1, 1)
# Y=X-e, M=X+1. Each lambda tuple is the (X,e,1) coefficient vector.
LAM = ((1,-1,-1), (1,-1,1), (1,1,1), (3,-1,1))
CENTERS = ((0,0,1),(0,1,0),(0,1,1),(1,-1,-1),(1,-1,0),(1,-1,1),
           (1,0,0),(1,0,1),(1,1,1),(2,-1,0),(2,-1,1),(2,0,1),(3,-1,1))
CAP = 6*(149-9)-42

def enc(z):
    return json.dumps(z, sort_keys=True, separators=(",",":"), default=str) + "\n"

def flip(word):
    return "".join("+" if c == "-" else "-" for c in word)

def box_aff(aff):
    a,b,c=aff
    xs=[a*X+b*e+c for X,e in product((148,149),(9,10))]
    return min(xs),max(xs)

def scale(s, a):
    return tuple(sorted(s*x for x in a))

def abs_sum(lam, s, a):
    assert s in SIGNS
    c,d=scale(s,a)
    lo,hi=lam[0]+c,lam[1]+d
    return (0 if lo <= 0 <= hi else min(abs(lo),abs(hi))),max(abs(lo),abs(hi))

def rankbox(j):
    return (2*j-1, 2*j+(1 if j<=64 else 3))

def robust_open(lam, s, b):
    # If b_hi-2 < R < b_lo+2 and R>0 throughout, |R| is uniformly within 2 of b.
    lo,hi=lam
    a0=max(0,b[1]-2)-lo
    a1=b[0]+2-hi
    a0,a1=scale(s,(a0,a1)) if a0<=a1 else (1,0)
    return a0,a1

def possible_bins(box):
    # Used only for a spawn distinct from all the exact thresholds, hence strict comparisons.
    lo,hi=box
    A=[rankbox(j) for j in CUTS]
    return tuple(k for k in range(len(A)+1)
                 if (k==0 or hi>A[k-1][0]) and (k==len(A) or lo<A[k][1]))

def data():
    bs=SOURCE.read_bytes(); assert sha256(bs).hexdigest()==SOURCE_SHA
    base=json.loads(bs)
    ix={int(r):tuple(map(int,b)) for r,b in base["ranges"].items()}
    orient={int(r):int(o) for r,o in base["orient"].items()}
    assert len(ix)==9 and set(ix)==set(orient)
    A={r:scale(orient[r],b) for r,b in sorted(ix.items())}
    assert all(lo>=2 and hi<=CAP for lo,hi in A.values())
    ordered=sorted(A.values())
    assert all(b[0]>a[1] for a,b in zip(ordered,ordered[1:]))
    ranks={}
    for j,z in base["rank_labels"].items():
        r,p=base["prefix_components"][j]; s=p*orient[r]
        if z not in TOP:z=flip(z);s=-s
        tag=(r,TOP.index(z),s)
        assert tag not in ranks
        ranks[tag]=int(j)
    assert sorted(j for j in ranks.values() if j in CUTS)==list(CUTS)
    L=list(map(box_aff,LAM))
    B={}
    for r,a in A.items():
        for i,s in product(range(4),SIGNS):
            tag=(r,i,s)
            lo,hi=abs_sum(L[i],s,a)
            if tag in ranks:
                rl,rh=rankbox(ranks[tag]);lo=max(lo,rl);hi=min(hi,rh)
            assert lo<=hi
            B[tag]=(lo,hi)
    return A,L,B,ranks,base["rank_labels"]

def build():
    A,L,B,ranks,labels=data()
    safe={}
    def ban(lo,hi,why):
        if lo<hi:safe.setdefault((lo,hi),why)
    for r,(a,b) in A.items():ban(b-4,a+4,f"anchor prefix {r}")
    for i,c in enumerate(CENTERS):
        lo,hi=box_aff(c);ban(hi-1,lo+1,f"top center {i}")
    for tag,b in B.items():
        for i,s,t in product(range(4),SIGNS,SIGNS):
            ban(*robust_open(scale(t,L[i]),s*t,b),f"anchor spawn {tag}, lambda {i}, signs {s},{t}")
    # Open forbidden endpoints never delete equality. The full [2,CAP] is partitioned
    # first by all witnesses (for a compact coverage proof) and an exact step-4 grid.
    E={2,CAP}|set(range(2,CAP,4))|{x for w in safe for x in w if 2<=x<=CAP}
    E=sorted(E)
    # Point and open-interval cells. A single witnessing open forbidden interval
    # is enough; any omitted intersection merely leaves a weaker model.
    cells=[];omitted=[]
    for a,b in sorted([(x,x) for x in E]+list(zip(E,E[1:]))):
        witness=next((k for k in sorted(safe) if (k[0]<a<k[1] if a==b
                                          else k[0]<=a and b<=k[1])),None)
        V=[possible_bins(abs_sum(L[i],s,(a,b))) for i,s in product(range(4),SIGNS)]
        if witness is not None:
            omitted.append([a,b,"forbidden",list(witness)])
        elif any(not k for k in V):
            omitted.append([a,b,"no-rank-bin",next(i for i,k in enumerate(V) if not k)])
        else:
            # In (a,b), 4(n-1)<b-a. Since integer endpoints, cap=ceil((b-a)/4).
            cells.append([a,b,1 if a==b else (b-a+3)//4,[list(k) for k in V]])
    # Indexed sparse exact integer constraints A*z<=b, plus column bounds 0<=z<=u.
    names=[];upper=[];rows=[]
    def col(name,u):
        j=len(names);names.append(name);upper.append(u);return j
    def row(co,b,name):
        rows.append([[[i,x] for i,x in sorted(co.items()) if x],b,name])
    def eq(co,b,name):
        row(co,b,name+" +");row({i:-v for i,v in co.items()},-b,name+" -")
    def ad(co,i,a=1):
        co[i]=co.get(i,0)+a
    bins=[{} for _ in range(len(CUTS)+1)]
    balances=[{} for _ in CUTS]
    def cohort(name,u,reps,i,bslots):
        assert bslots
        if len(bslots)==1:shares=[(bslots[0],reps)]
        else:
            shares=[(k,col(f"{name}:bin{k}",u)) for k in bslots]
            C={j:1 for k,j in shares};ad(C,reps,-1);eq(C,0,name+" allocation")
        for k,j in shares:
            ad(bins[k],j)
            for l,C in enumerate(balances):
                if i in (0,1) and k<=l:ad(C,j,1 if i==0 else -1)
        return shares
    ns=[]
    for k,(a,b,u,V) in enumerate(cells):
        n=col(f"cell[{k}] mass",u);ns.append(n)
        sh=[cohort(f"cell[{k}] spawn{t}",u,n,t//2,k0) for t,k0 in enumerate(V)]
        # Same-magnitude rank order implies cumulative cohort count order. These
        # comparisons are independent of assumptions about other cells.
        before={(2*i,2*i+1) for i in range(4)}
        before|={(2*i+1,2*j+1) for i,j in zip(range(3),range(1,4))}
        for i in range(4):
            for j in range(i+1,4):
                l,h=box_aff(tuple(A+B for A,B in zip(LAM[i],LAM[j])))
                if 2*b<=l:before.add((2*i,2*j))
                if 2*a>=h:before.add((2*j,2*i))
        for t,v in sorted(before):
            for l in range(len(CUTS)):
                C={}
                for kk,jj in sh[t]:
                    if kk<=l:ad(C,jj,-1)
                for kk,jj in sh[v]:
                    if kk<=l:ad(C,jj,1)
                if any(C.values()) and any(w>0 for w in C.values()):
                    row(C,0,f"cell[{k}] spawn{t}<=spawn{v} cumulative threshold {l}")
    eq({i:1 for i in ns},32-len(A),"exact anonymous mass")
    anchor_bins=[]
    A0=[0]*len(bins)
    B0=[0]*len(CUTS)
    for tag,bb in sorted(B.items()):
        r,i,s=tag
        V=[bisect_right(CUTS,ranks[tag])] if tag in ranks else list(possible_bins(bb))
        assert len(V)==1, "for this pinned pilot all 72 anchor bins are fixed"
        k=V[0];A0[k]+=1
        for l in range(len(CUTS)):
            if i in (0,1) and k<=l:B0[l]+=(1 if i==0 else -1)
        anchor_bins.append([list(tag),list(bb),ranks.get(tag),V])
    below=[0]+[j-1 for j in CUTS]+[256]
    for k,C in enumerate(bins):eq(C,below[k+1]-below[k]-A0[k],f"exact residual nine rank bin {k}")
    for j,C,b0 in zip(CUTS,balances,B0):
        d={"+-+":1,"--+":-1}.get(labels[str(j)],0)
        eq(C,d-b0,f"exact residual dimer imbalance at D{j}")
    # Add spacing between occupied cells. Closed bounding spans are enough; only
    # adjacent cells in the retained list are considered here.
    for k,(C,D) in enumerate(zip(cells,cells[1:])):
        width=D[1]-C[0]
        cap=width//4+1
        if cap<C[2]+D[2]:row({ns[k]:1,ns[k+1]:1},cap,f"neighbor spacing {k}")
    return dict(source_sha=SOURCE_SHA,orientation="------+++",m=9,thresholds=CUTS,
                forbidden=[[*k,v] for k,v in sorted(safe.items())],
                anchors=anchor_bins,cells=cells,omitted=omitted,variables=names,
                upper=upper,rows=rows)

def unique_pairs(l):
    z={}
    for k,v in l:
        assert k not in z
        z[k]=v
    return z

def check_tree(model, tree):
    """Exact exhaustive 0..u integer box splits; contradiction by rational row sum."""
    rows=model["rows"];n=len(model["upper"])
    lo=[0]*n;hi=model["upper"][:]
    def go(t):
        keys=set(t)
        if keys=={"split","cut","left","right"}:
            j,k=t["split"],t["cut"]
            assert type(j) is int and type(k) is int and 0<=j<n and lo[j]<=k<hi[j]
            a,b=lo[j],hi[j]
            hi[j]=k;L=go(t["left"]);hi[j]=b
            lo[j]=k+1;R=go(t["right"]);lo[j]=a
            return L+R
        assert keys=={"combine"}
        W=unique_pairs(t["combine"])
        assert W
        C={};rhs=F(0)
        for i,y in W.items():
            assert type(i) is int and 0<=i<len(rows) and type(y) in (int,str)
            y=F(y); assert y>0
            co,b,_=rows[i]
            for j,a in co: C[j]=C.get(j,0)+y*a
            rhs+=y*b
        lhs=sum(a*(lo[j] if a>=0 else hi[j]) for j,a in C.items())
        assert lhs>rhs,("not a contradiction",str(lhs),str(rhs))
        return 1
    return go(tree)

def main():
    p=argparse.ArgumentParser()
    p.add_argument("command",choices=("prepare","verify","exclude"))
    p.add_argument("tree",nargs="?",type=Path)
    a=p.parse_args()
    model=build();out=HERE/"model.json"
    if a.command=="prepare":
        with out.open("x") as f:f.write(enc(model))
    else:
        assert out.read_text()==enc(model),"pilot model differs from deterministic rebuild"
    info=[("kept cells",len(model["cells"])),("omitted cells",len(model["omitted"])),
          ("columns",len(model["variables"])),("rows",len(model["rows"]))]
    print("; ".join(f"{n} {x}" for n,x in info))
    if a.command=="exclude":
        assert a.tree is not None
        print("EXCLUDED m=9, frozen central word ------+++, by",check_tree(model,json.loads(a.tree.read_text(),object_pairs_hook=unique_pairs)),"covered leaves")
    else:
        assert a.tree is None
        print("Input coverage regenerated; no feasibility determination.")

if __name__=="__main__":
    main()
