#!/usr/bin/env python3
import json,sys,warnings
from pathlib import Path
from hashlib import sha256

HERE=Path(__file__).resolve().parent
SRC=HERE.parent/'nine149-wide-prefix-capacity-pilot'
MODEL=SRC/'model.json'
EXPECTED='e4beffe53faa7360d742c41eba02569b3712408c0e22bb0c82361ed09765199f'
OUT=HERE/'result.json'

def inputs():
    raw=MODEL.read_bytes()
    assert sha256(raw).hexdigest()==EXPECTED
    m=json.loads(raw)
    assert (m['orientation'],m['m'],len(m['upper']),len(m['rows']))==('------+++',9,560,347)
    return m

def once():
    import numpy as np
    import scipy
    from scipy.optimize import milp,Bounds,LinearConstraint
    from scipy.sparse import coo_matrix
    m=inputs();n=len(m['upper']);r=len(m['rows'])
    ii=[];jj=[];vv=[];b=[]
    for i,(co,rhs,name) in enumerate(m['rows']):
        for j,a in co:
            ii.append(i);jj.append(j);vv.append(a)
        b.append(rhs)
    A=coo_matrix((vv,(ii,jj)),shape=(r,n),dtype=float).tocsc()
    with warnings.catch_warnings(record=True) as w:
        q=milp(np.zeros(n),integrality=np.ones(n),
               bounds=Bounds(np.zeros(n),np.array(m['upper'],dtype=float)),
               constraints=LinearConstraint(A,np.full(r,-np.inf),np.array(b,dtype=float)),
               options=dict(time_limit=10.,threads=1,parallel=False))
    z=q.x
    out=dict(model_sha=EXPECTED,scipy=scipy.__version__,status=int(q.status),message=q.message,
             warnings=[str(a.message) for a in w],integers=None,max_float_rounding_residual=None)
    if z is not None and np.all(np.isfinite(z)):
        v=np.rint(z)
        out['max_float_rounding_residual']=float(np.max(np.abs(z-v)))
        out['integers']=list(map(int,v))
    with OUT.open('x') as f:json.dump(out,f,sort_keys=True,indent=2);f.write('\n')
    print('heuristic status',out['status'],out['message'])

def check():
    m=inputs();out=json.loads(OUT.read_text())
    assert out['model_sha']==EXPECTED
    w=out['integers']
    if w is None:
        print('No integer vector returned; heuristic status only:',out['status'],out['message'])
        return
    assert type(w) is list and len(w)==len(m['upper'])
    assert all(type(x) is int and 0<=x<=u for x,u in zip(w,m['upper']))
    sl=[]
    for co,b,name in m['rows']:
        v=sum(a*w[j] for j,a in co)
        assert v<=b,(v,b,name)
        sl.append(b-v)
    print(f'Exact feasible relaxation only: {len(w)} column bounds and {len(sl)} integer rows checked.')
    print(f'Minimum row slack {min(sl)}; {sl.count(0)} tight rows.')

if __name__=='__main__':
    assert len(sys.argv)==2
    {'once':once,'check':check}[sys.argv[1]]()
