# Single guarded integer feasibility pilot

Scope: m=9, inherited central orientation ID 0, `------+++`.
Input: the previously frozen `../nine149-wide-prefix-capacity-pilot/model.json`,
SHA-256 `e4beffe53faa7360d742c41eba02569b3712408c0e22bb0c82361ed09765199f`.

One zero-objective SciPy/HiGHS integer feasibility call returned a
feasible vector. The complete rounded vector in result.json was
then replayed independently using only Python integer arithmetic:
all 560 column bounds and all 347 sparse rows pass. This proves
**feasibility of this outer integer relaxation only**. It does not
supply anonymous magnitude values, signed-six support assignments,
nine separated weights, or an exclusion.

The guarded worker completed in 0.85 seconds, sampled process-group
peak RSS 62076 KiB and audited child peak RSS 62204 KiB. The guard
was set to 12 seconds and 150000 KiB RSS under 480000 KiB VAS;
BLAS/OMP/MKL and HiGHS were explicitly single-worker.

Independent replay without SciPy or a solver:

    sha256sum -c SHA256SUMS
    python3 ../nine149-wide-prefix-capacity-pilot/pilot.py verify
    python3 one.py check

The one numerical run used:

    (export OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 MKL_NUM_THREADS=1
     ulimit -v 480000
     exec python3 guard12.py time.log python3 one.py once) >solver.log 2>stderr.log

The worker opens the result exclusively; do not overwrite the
frozen result just to replay it. No other orientation or floor
was run; no inequality bound or exclusion count changed.
