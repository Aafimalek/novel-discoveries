"""Run one process group under elapsed-time, VAS and monitored RSS limits."""
import os
from pathlib import Path
import resource
import signal
import subprocess
import sys
import time

RSS_LIM=150000
ELAPSED_LIM=12.0

def group_rss(pgid):
    # /proc/<pid>/stat fields after the final ')' are numbered from 3.
    # Field 5 is process-group ID; field 24 is resident pages.
    size=os.sysconf("SC_PAGESIZE")//1024
    total=0
    for entry in os.scandir("/proc"):
        if not entry.name.isdecimal():
            continue
        try:
            f=(Path(entry.path)/"stat").read_text().rsplit(")",1)[1].split()
            if int(f[2])==pgid: total+=int(f[21])*size
        except (FileNotFoundError, ProcessLookupError, PermissionError):
            pass
    return total

log,*cmd=sys.argv[1:]
start=time.monotonic()
p=subprocess.Popen(cmd,start_new_session=True)
peak=0; killed=None
try:
    while p.poll() is None:
        peak=max(peak,group_rss(p.pid))
        if peak>=RSS_LIM:
            killed="RSS"; break
        if time.monotonic()-start>=ELAPSED_LIM:
            killed="elapsed"; break
        time.sleep(.005)
finally:
    if p.poll() is None:
        try: os.killpg(p.pid,signal.SIGKILL)
        except ProcessLookupError: pass
    code=p.wait()
peak_child=resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss
status=125 if killed=="RSS" or peak_child>=RSS_LIM else 124 if killed else code
Path(log).write_text(f'elapsed={time.monotonic()-start:.2f} max_group_sample_rss_kib={peak} max_child_rss_kib={peak_child} exit={code} guard_status={status} killed={killed}\n')
raise SystemExit(status)
