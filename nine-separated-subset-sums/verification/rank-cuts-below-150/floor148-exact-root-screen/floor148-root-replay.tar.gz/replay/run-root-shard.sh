#!/usr/bin/env bash
# Run at most one of the 64 disjoint eight-orientation root shards.
set -euo pipefail
if (( $# != 2 )) || [[ ! $2 =~ ^([0-9]|[1-5][0-9]|6[0-3])$ ]]; then
    echo 'usage: run-root-shard.sh PROGRESS-DIRECTORY SHARD-ID (0..63)' >&2
    exit 2
fi
here="$(cd -- "$(dirname -- "$0")" && pwd -P)"
mkdir -p -- "$1"
progress="$(cd -- "$1" && pwd -P)"
shard=$2; start=$((8*shard))
printf -v base 'root-%03d' "$start"
out="$progress/$base.json"
if [[ -e $out ]]; then
    python3 "$here/check-root-queue.py" "$progress" --shard "$shard"
    exit
fi
# The lock prevents concurrent jobs that use this progress directory.
exec 9>"$progress/.root-shards.lock"
flock -n 9 || { echo 'another shard is running for this directory' >&2; exit 3; }
tmp="$(mktemp -d "$progress/.$base.try-XXXXXX")"
# Keep unsuccessful attempt logs but never promote interrupted or partial files.
export OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 MKL_NUM_THREADS=1
(
    ulimit -v 480000
    exec python3 "$here/measure-child.py" "$tmp/time.log" \
        python3 "$here/floor148_root.py" root --start "$start" --count 8 "$tmp/result.json"
) >"$tmp/stdout.log" 2>"$tmp/stderr.log"
python3 "$here/floor148_root.py" verify "$tmp/result.json" >"$tmp/replay.log"
ln -- "$tmp/result.json" "$out"
python3 "$here/check-root-queue.py" "$progress" --shard "$shard"
