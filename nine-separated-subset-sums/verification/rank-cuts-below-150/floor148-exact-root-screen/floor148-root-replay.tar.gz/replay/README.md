# Final floor-148 Farkas screen

This optional computation assumes nine positive increasing real weights with
unit-separated subset sums, \(149\le M=x_9<150\), and the previously
proved penultimate restriction \(148\le X=x_8<149\). It is a necessary
root screen, not an exhaustive chamber search and not a result for
the entire final slice. The completed root queue and exact replay are
recorded in [RESULTS.md](RESULTS.md). The optional slot code was not run.

## Exact rows and premises

Each orientation \(s\in\{-1,1\}^9\) is the ordered, positive central
full-sign combination, with \(1\le g=s\cdot x<2\). Reuse the original
central-root rows (range, sorted singleton separation, packing, and
individual central support inequalities), the opposite-sign matching
rows, and the three published rank-moment consequences. These known
premises are the same ones used in the earlier moment packet, except
that this program tests them simultaneously with the new final-slice rows.
The moment arithmetic is separately replayable by
`python3 rank_moment_arithmetic.py`; its printed bounds do not depend on
the new screening results.

New rows in the root:
1. \(X\ge148\).
2. \(38M-39X\le-109\), from \(39(M-X-1)\le M-148\), the
   packed-defect cut on ranks 158–305.
3. If \(d=M-X\), any positive difference \(e\) of first-seven subset
   sums satisfies \(e\ge1+d\): \(e\ge1\) and \(|e-d|\ge1\) by
   using the opposite one-top-coordinate shifts, while \(d-1<1\).
   In particular \(x_1\ge1+d\) and all six consecutive singleton gaps
   among the first seven are at least \(1+d\).

The optional slot search uses the Q slots \(q=50,51,53,54,60,61,63,64\)
from the prescribed rank-length-148 coordinate-9 edges. If \(D_q\) is
the q-th member of the ordered nine-weight absolute full-sign list, the
rank bounds are \(2q-1\le D_q\le2q+M-149\).
For \(q=50,53,60,63\), the local top-bit pattern gives
\(D_q=(M-X)+v\) with positive seven-weight full-sign magnitude \(v\).
For \(q=51,54,61,64\), it gives \(D_q=X+M-v\). These identities are
from the written remaining-floor148 cuts, not a new computational
assertion. Substitute each of the 128 explicitly oriented full-support
seven-sign patterns into the appropriate two inequalities for \(D_q\).
The implied intervals for \(v\) are strictly positive, so evaluating an
oriented form without an absolute value covers every possible witness.
A slot is impossible for that same central orientation only when **all 128**
of its signs have been rejected by exact proofs. There is no compatibility
claim between slot signs at different slots. A whole orientation may be
cleared by a root proof or a fully rejected slot; partial slot counts are
never counted as whole orientations.

The separate `optional-lattice-and-flanks.md` records further necessary
mathematical cuts. The scaled lattice argument there uses
\(f_{\mathbb Z}(8)=84\) and the flank argument specifically assumes the
exact \(f_{\mathbb R}(8)=84\) result of Notik, arXiv:2611.17360.
**Neither of those optional cuts is encoded by this program.**
The prior root rows use the inherited \(x_6\ge44,\ x_7\ge84\) facts
(by retaining the smaller weights and replacing a suitable adjacent
large pair by its positive difference), so their earlier real
lower-bound dependencies still apply.

## Guarded generation commands

Use an unused JSON pathname per deterministic shard, starting from offset 0;
choose smaller counts for tight time budgets. The root order is
lexicographic with '-' before '+' on all 512 length-nine signs. The optional
slot order uses the analogous 128 length-seven signs. Commands for one
root shard and one example slot shard, **not to be run concurrently**:

```sh
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 timeout 8s \
 python3 floor148_root.py root --start 0 --count 8 root-000.json
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 timeout 8s \
 python3 floor148_root.py slot --start 0 --count 8 slot-000.json -- '-++-++---' 50
python3 floor148_root.py verify root-000.json slot-000.json
```

Generation alone imports SciPy/HiGHS. Its floating point output is a hint
for reconstructing a rational nonnegative Farkas vector, checked exactly
before recording. The exact standard-library replay reconstructs every row
from the branch definition; it validates zero weighted coefficient sum and
either a negative RHS sum or a zero RHS sum with positive coefficient
on at least one of the two strict rows \(M<150\), \(g<2\). Use ordinary
Python (not `python -O`, since this checker uses assertions).
Inconsistent JSON is rejected; the checker also rejects overlapping shards
within one invocation. The statuses 'numeric-survivor' and 'unknown' prove
nothing. An externally interrupted or abandoned shard makes no coverage
claim. Passing a subset of completed shard files verifies only those files.

## Complete deterministic root queue

The prepared queue assigns branch indices `8j,...,8j+7` to shard
ID `j=0,...,63`. Run one worker at a time:

```sh
./run-root-shard.sh ./progress 0   # one bounded process, then exits
# Resume the next missing ID explicitly. Existing output is verified and reused.
python3 check-root-queue.py ./progress  # run only when all 64 are present
```

The shell runner gives the process-group watchdog an 8 s elapsed cap,
a 130000 KiB resident-memory kill threshold (5 ms poll and post-exit
child high-water audit), and a 480000 KiB virtual address-space cap
to allow scientific-library shared mappings. It concurrently runs
only one numerical process, with a one-thread numerical-library setting,
and has a per-progress-directory lock. A guard-related failure is not a
proof and leaves only temporary logs; it must be retried or reported
as missing, not silently skipped. For each completed attempt, measured
RSS is recorded in the hidden attempt directory's 'time.log'. The final
portable replay requires the exact filename, start, and eight records for
every shard ID (all 512 disjoint orientations); only checked rational
Farkas leaves count as exclusions, regardless of numerical status or
earlier analytic pruning. See RESULTS.md for the completed root-run status.
