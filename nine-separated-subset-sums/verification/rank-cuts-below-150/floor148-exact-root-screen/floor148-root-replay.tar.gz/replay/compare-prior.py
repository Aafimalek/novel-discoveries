"""Replay earlier root and moment records before measuring overlap."""
import json
from pathlib import Path
from central_root_lp import verify
from moment_central_lp import verify_new
from floor148_root import replay

data=Path(__file__).resolve().parent
old=json.loads((data/'previous'/'central-root-farkas.json').read_text())['True']
assert verify(old,True)==294
old_set=set(old['verified_rejections'])
mom=json.loads((data/'previous'/'moment-farkas.json').read_text())
verify_new(old_set,mom)
mom_set=set(mom['certs'])
assert len(mom_set)==22 and not old_set.intersection(mom_set)
roots,slots,covered=replay(sorted((data/'certificates').glob('root-*.json')))
assert not slots and not covered
prior=old_set|mom_set
print('Exact prior exclusions in this comparison:',len(prior))
print('Prior exact exclusions also certified here:',len(prior&roots))
print('Additional exact exclusions versus prior root+moment:',len(roots-prior))
print('Prior exact exclusions not certified here:',len(prior-roots))
