# Scaled rounding and two forbidden-window flank cuts

These are necessary conditions only. They do not exclude the last candidate
interval for the nine-real-weight problem.

Assume that nine sorted positive weights have unit-separated subset sums and
that the last two are $X=148+\eta$, $M=X+d<150$, $d=1+\epsilon$.
Use the previous floor-148 cuts $1\le d<41/39$. Set
$$
L=X-1,\quad U=M+1,\quad C=(X+M)/2,\quad h=1+d/2.
$$
Thus $(L,U)=(C-h,C+h)$.

Let `D` be the finite set of positive differences of distinct subset scores
of the first seven weights. Every $e\in D$ satisfies $e\ge1+d$:
it is at least 1 and $|e-d|\ge1$ by comparing opposite one-top lifts,
whereas $d-1<1$. Comparing an unshifted score to its translate by
$X$ or $M$ also gives $|e-X|,|e-M|\ge1$. The two open forbidden
intervals overlap since $d<2$, so $D\cap(L,U)=\varnothing$.

## Unscaled parity cut

Round each of the first seven weights to the nearest even integer $u_i$
and write $E=\sum_{i\le7}|x_i-u_i|$. For the even target $A=148$,
the distance to the nearer endpoint of the forbidden window is $1-\eta$.
For $A=150$, it is $\eta+\epsilon$ (use $\eta+\epsilon<1$).
If $E$ is strictly below either margin, the seven rounded weights have
distinct subset sums (their signed differences each move by at most $E$),
and none of their rounded signed differences equals that corresponding $A$.
The rounded weights are positive and at most $A$.
After appending integers $A,A+1$, the two subset-sum parity groups are
$B\cup(B+A)$ and $(B+A+1)\cup(B+2A+1)$, where $B$ is the
rounded-base collection. Both are injective, impossible by the exact
integer optimum 161. Therefore
$$
E\ge\max(1-\eta,\eta+\epsilon)\ge d/2 .
$$

## Scaled integer-eight cuts

For every integer $1\le n\le83$, set $\beta=n/C$, round each
$\beta x_i$ for $i\le7$ to a nearest integer $w_i$, and write
$E_n=\sum_{i\le7}|\beta x_i-w_i|$. Then
$$
 E_n\ge\beta h\qquad
 \text{or equivalently}\qquad
 \sum_{i\le7}\left\|n x_i/C\right\|_{\mathbb Z}\ge nh/C .
$$

Indeed if $E_n<\beta h$, the rounded seven weights still have distinct
subset sums since $\beta h<\beta(1+d)$. They are therefore positive:
rounding nonnegative numbers cannot produce negative values, and a zero
would give a collision. They are at most $n$ since $\beta x_i<n$.
Every base signed difference moves by at most $E_n$ but no actual scaled
base difference belongs to $(n-\beta h,n+\beta h)$. Thus no rounded
signed difference equals $n$. Appending $n$ yields eight positive
sum-distinct integers of maximum at most 83, contradicting the exact
integer optimum 84.

Equivalently the scaled-even formulation takes $A=2n$ and rounds
$A x_i/C$ to nearest even; then the error threshold is $Ah/C$.
The nine-weight parity proof alone supplies $n\le79$, whereas the
eight-integer optimum supplies all $n\le83$.

Integer source: [Borwein–Mossinghoff, Table 5](https://www.cecm.sfu.ca/~pborwein/PAPERS/P170.pdf).

## Real-eight flank witnesses

Using the exact real-eight result $f_{\mathbb R}(8)=84$
[Notik, arXiv:2611.17360](https://arxiv.org/abs/2611.17360), the following
two small intervals must each contain a first-seven positive signed difference:
$$
 D\cap[(83/85)U,L]\ne\varnothing,
 \qquad D\cap[U,(85/83)L]\ne\varnothing .
$$

For any $x_7\le t<84(1+d)$, appending $t$ to the first seven shows
there is $e\in D$ with $|e-t|\le t/84$. Otherwise all augmented
subset sums have pairwise distance strictly more than $t/84$: same-side
differences are at least $1+d>t/84$, same-base opposite sides have
distance $t>t/84$, and other opposite-side differences are at least
$|e-t|$ or $e+t$. Rescaling would yield eight reals with maximum
strictly below 84 and unit-separated subset sums.

To force the lower flank, take $t$ toward $84U/85$ from below.
That limit is strictly above $x_7\le L$ and below $84(1+d)$.
In fact
$84U/85-L=(84(U-L)-L)/85>0$ since $U-L=d+2\ge3$ and $L<148$.
All witnesses then satisfy $e\le L$, for $t+t/84<U$ and the
open forbidden interval has no base differences. Finiteness of $D$
provides one witness along a sequence of such $t$'s, and taking limits
gives $e\ge83U/85$. To force the upper flank, take $t$ toward
$84L/83>L\ge x_7$ from above (that limit is also strictly below
$84(1+d)$). Then $t-t/84>L$ excludes the lower flank, and the
same finite-set argument gives $e\le85L/83$.

Each interval has width less than $0.57$: using $U-L=d+2\ge3$ and
$L<148$, the two widths are at most
$(2L-249)/85<47/85$ and $(2L-249)/83<47/83$, respectively.
Both provide explicit signed-witness branches if the final slice is
searched. None of these cuts in isolation supplies a contradiction.
