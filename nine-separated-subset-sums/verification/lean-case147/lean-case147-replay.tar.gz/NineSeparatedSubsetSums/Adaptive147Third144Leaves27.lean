import NineSeparatedSubsetSums.Adaptive147Third144State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof232 : runCachedNode 511 131483 Adaptive147Third144Node232 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof232

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof265 : runCachedNode 511 131483 Adaptive147Third144Node265 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof265

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof334 : runCachedNode 511 131483 Adaptive147Third144Node334 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof334

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof524 : runCachedNode 511 131483 Adaptive147Third144Node524 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof524

end NineSeparatedSubsetSums
