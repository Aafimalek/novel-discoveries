import NineSeparatedSubsetSums.Adaptive147Third143State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third143Proof506 : runCachedNode 511 131344 Adaptive147Third143Node506 = false := by
  decide +kernel

#print axioms adaptive147Third143Proof506

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third143Proof194 : runCachedNode 511 131344 Adaptive147Third143Node194 = false := by
  decide +kernel

#print axioms adaptive147Third143Proof194

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third143Proof13 : runCachedNode 511 131344 Adaptive147Third143Node13 = false := by
  decide +kernel

#print axioms adaptive147Third143Proof13

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third143Proof293 : runCachedNode 511 131344 Adaptive147Third143Node293 = false := by
  decide +kernel

#print axioms adaptive147Third143Proof293

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third143Proof163 : runCachedNode 511 131344 Adaptive147Third143Node163 = false := by
  decide +kernel

#print axioms adaptive147Third143Proof163

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third143Proof131 : runCachedNode 511 131344 Adaptive147Third143Node131 = false := by
  decide +kernel

#print axioms adaptive147Third143Proof131

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third143Proof68 : runCachedNode 511 131344 Adaptive147Third143Node68 = false := by
  decide +kernel

#print axioms adaptive147Third143Proof68

end NineSeparatedSubsetSums
