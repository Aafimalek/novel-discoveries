import NineSeparatedSubsetSums.Adaptive147Third143State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third143Proof302 : runCachedNode 511 131344 Adaptive147Third143Node302 = false := by
  decide +kernel

#print axioms adaptive147Third143Proof302

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third143Proof165 : runCachedNode 511 131344 Adaptive147Third143Node165 = false := by
  decide +kernel

#print axioms adaptive147Third143Proof165

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third143Proof52 : runCachedNode 511 131344 Adaptive147Third143Node52 = false := by
  decide +kernel

#print axioms adaptive147Third143Proof52

end NineSeparatedSubsetSums
