import NineSeparatedSubsetSums.Adaptive147Third143State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third143Proof22 : runCachedNode 511 131344 Adaptive147Third143Node22 = false := by
  decide +kernel

#print axioms adaptive147Third143Proof22

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third143Proof7 : runCachedNode 511 131344 Adaptive147Third143Node7 = false := by
  decide +kernel

#print axioms adaptive147Third143Proof7

end NineSeparatedSubsetSums
