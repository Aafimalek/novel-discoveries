import NineSeparatedSubsetSums.Adaptive147Third117State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third117Proof0 : runCachedNode 511 126115 Adaptive147Third117Node0 = false := by
  decide +kernel

#print axioms adaptive147Third117Proof0

end NineSeparatedSubsetSums
