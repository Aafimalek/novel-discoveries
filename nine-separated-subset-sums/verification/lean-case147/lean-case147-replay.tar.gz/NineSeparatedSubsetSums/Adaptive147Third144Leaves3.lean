import NineSeparatedSubsetSums.Adaptive147Third144State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof305 : runCachedNode 511 131483 Adaptive147Third144Node305 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof305

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof102 : runCachedNode 511 131483 Adaptive147Third144Node102 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof102

end NineSeparatedSubsetSums
