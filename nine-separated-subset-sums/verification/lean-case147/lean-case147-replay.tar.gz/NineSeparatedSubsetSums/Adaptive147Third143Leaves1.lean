import NineSeparatedSubsetSums.Adaptive147Third143State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third143Proof266 : runCachedNode 511 131344 Adaptive147Third143Node266 = false := by
  decide +kernel

#print axioms adaptive147Third143Proof266

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third143Proof11 : runCachedNode 511 131344 Adaptive147Third143Node11 = false := by
  decide +kernel

#print axioms adaptive147Third143Proof11

end NineSeparatedSubsetSums
