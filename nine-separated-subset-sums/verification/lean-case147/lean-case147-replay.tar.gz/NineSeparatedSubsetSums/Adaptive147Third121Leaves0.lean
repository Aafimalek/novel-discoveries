import NineSeparatedSubsetSums.Adaptive147Third121State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third121Proof0 : runCachedNode 511 126944 Adaptive147Third121Node0 = false := by
  decide +kernel

#print axioms adaptive147Third121Proof0

end NineSeparatedSubsetSums
