import NineSeparatedSubsetSums.Adaptive147Third140State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third140Proof21 : runCachedNode 511 130945 Adaptive147Third140Node21 = false := by
  decide +kernel

#print axioms adaptive147Third140Proof21

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third140Proof131 : runCachedNode 511 130945 Adaptive147Third140Node131 = false := by
  decide +kernel

#print axioms adaptive147Third140Proof131

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third140Proof150 : runCachedNode 511 130945 Adaptive147Third140Node150 = false := by
  decide +kernel

#print axioms adaptive147Third140Proof150

end NineSeparatedSubsetSums
