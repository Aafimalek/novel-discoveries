import NineSeparatedSubsetSums.Adaptive147Third144State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof269 : runCachedNode 511 131483 Adaptive147Third144Node269 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof269

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof532 : runCachedNode 511 131483 Adaptive147Third144Node532 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof532

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof172 : runCachedNode 511 131483 Adaptive147Third144Node172 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof172

end NineSeparatedSubsetSums
