import NineSeparatedSubsetSums.Adaptive147Third143State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third143Proof385 : runCachedNode 511 131344 Adaptive147Third143Node385 = false := by
  decide +kernel

#print axioms adaptive147Third143Proof385

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third143Proof15 : runCachedNode 511 131344 Adaptive147Third143Node15 = false := by
  decide +kernel

#print axioms adaptive147Third143Proof15

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third143Proof540 : runCachedNode 511 131344 Adaptive147Third143Node540 = false := by
  decide +kernel

#print axioms adaptive147Third143Proof540

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third143Proof14 : runCachedNode 511 131344 Adaptive147Third143Node14 = false := by
  decide +kernel

#print axioms adaptive147Third143Proof14

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third143Proof111 : runCachedNode 511 131344 Adaptive147Third143Node111 = false := by
  decide +kernel

#print axioms adaptive147Third143Proof111

end NineSeparatedSubsetSums
