import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive147Third112Node0 : CachedSearchNode :=
  ⟨4, 111, computeCenteredMask [148,147,112], 407, 56057⟩

end NineSeparatedSubsetSums
