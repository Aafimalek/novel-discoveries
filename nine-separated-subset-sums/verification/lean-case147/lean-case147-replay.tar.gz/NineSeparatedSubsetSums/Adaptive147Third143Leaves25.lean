import NineSeparatedSubsetSums.Adaptive147Third143State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third143Proof134 : runCachedNode 511 131344 Adaptive147Third143Node134 = false := by
  decide +kernel

#print axioms adaptive147Third143Proof134

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third143Proof634 : runCachedNode 511 131344 Adaptive147Third143Node634 = false := by
  decide +kernel

#print axioms adaptive147Third143Proof634

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third143Proof226 : runCachedNode 511 131344 Adaptive147Third143Node226 = false := by
  decide +kernel

#print axioms adaptive147Third143Proof226

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third143Proof542 : runCachedNode 511 131344 Adaptive147Third143Node542 = false := by
  decide +kernel

#print axioms adaptive147Third143Proof542

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third143Proof29 : runCachedNode 511 131344 Adaptive147Third143Node29 = false := by
  decide +kernel

#print axioms adaptive147Third143Proof29

end NineSeparatedSubsetSums
