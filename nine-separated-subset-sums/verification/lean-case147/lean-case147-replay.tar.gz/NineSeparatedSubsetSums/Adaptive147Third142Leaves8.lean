import NineSeparatedSubsetSums.Adaptive147Third142State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third142Proof390 : runCachedNode 511 131213 Adaptive147Third142Node390 = false := by
  decide +kernel

#print axioms adaptive147Third142Proof390

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third142Proof202 : runCachedNode 511 131213 Adaptive147Third142Node202 = false := by
  decide +kernel

#print axioms adaptive147Third142Proof202

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third142Proof181 : runCachedNode 511 131213 Adaptive147Third142Node181 = false := by
  decide +kernel

#print axioms adaptive147Third142Proof181

end NineSeparatedSubsetSums
