import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive147Third129Node0 : CachedSearchNode :=
  ⟨4, 128, computeCenteredMask [148,147,129], 424, 60154⟩
def Adaptive147Third129Node1 : CachedSearchNode := cachedChild Adaptive147Third129Node0 110
def Adaptive147Third129Node2 : CachedSearchNode := cachedChild Adaptive147Third129Node0 111
def Adaptive147Third129Node3 : CachedSearchNode := cachedChild Adaptive147Third129Node0 112
def Adaptive147Third129Node4 : CachedSearchNode := cachedChild Adaptive147Third129Node0 113
def Adaptive147Third129Node5 : CachedSearchNode := cachedChild Adaptive147Third129Node0 114
def Adaptive147Third129Node6 : CachedSearchNode := cachedChild Adaptive147Third129Node0 115
def Adaptive147Third129Node7 : CachedSearchNode := cachedChild Adaptive147Third129Node0 116
def Adaptive147Third129Node8 : CachedSearchNode := cachedChild Adaptive147Third129Node0 117
def Adaptive147Third129Node9 : CachedSearchNode := cachedChild Adaptive147Third129Node0 118
def Adaptive147Third129Node10 : CachedSearchNode := cachedChild Adaptive147Third129Node0 119
def Adaptive147Third129Node11 : CachedSearchNode := cachedChild Adaptive147Third129Node0 120
def Adaptive147Third129Node12 : CachedSearchNode := cachedChild Adaptive147Third129Node0 121
def Adaptive147Third129Node13 : CachedSearchNode := cachedChild Adaptive147Third129Node0 122
def Adaptive147Third129Node14 : CachedSearchNode := cachedChild Adaptive147Third129Node0 123
def Adaptive147Third129Node15 : CachedSearchNode := cachedChild Adaptive147Third129Node0 124
def Adaptive147Third129Node16 : CachedSearchNode := cachedChild Adaptive147Third129Node0 125
def Adaptive147Third129Node17 : CachedSearchNode := cachedChild Adaptive147Third129Node0 126
def Adaptive147Third129Node18 : CachedSearchNode := cachedChild Adaptive147Third129Node0 127

end NineSeparatedSubsetSums
