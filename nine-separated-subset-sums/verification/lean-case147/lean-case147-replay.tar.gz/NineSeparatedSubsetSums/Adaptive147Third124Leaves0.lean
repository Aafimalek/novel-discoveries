import NineSeparatedSubsetSums.Adaptive147Third124State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third124Proof0 : runCachedNode 511 127662 Adaptive147Third124Node0 = false := by
  decide +kernel

#print axioms adaptive147Third124Proof0

end NineSeparatedSubsetSums
