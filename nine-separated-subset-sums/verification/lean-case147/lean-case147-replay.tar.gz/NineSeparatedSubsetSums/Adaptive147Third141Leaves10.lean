import NineSeparatedSubsetSums.Adaptive147Third141State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third141Proof335 : runCachedNode 511 131086 Adaptive147Third141Node335 = false := by
  decide +kernel

#print axioms adaptive147Third141Proof335

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third141Proof130 : runCachedNode 511 131086 Adaptive147Third141Node130 = false := by
  decide +kernel

#print axioms adaptive147Third141Proof130

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third141Proof62 : runCachedNode 511 131086 Adaptive147Third141Node62 = false := by
  decide +kernel

#print axioms adaptive147Third141Proof62

end NineSeparatedSubsetSums
