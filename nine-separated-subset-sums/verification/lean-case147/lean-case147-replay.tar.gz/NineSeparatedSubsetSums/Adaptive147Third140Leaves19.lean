import NineSeparatedSubsetSums.Adaptive147Third140State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third140Proof98 : runCachedNode 511 130945 Adaptive147Third140Node98 = false := by
  decide +kernel

#print axioms adaptive147Third140Proof98

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third140Proof257 : runCachedNode 511 130945 Adaptive147Third140Node257 = false := by
  decide +kernel

#print axioms adaptive147Third140Proof257

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third140Proof100 : runCachedNode 511 130945 Adaptive147Third140Node100 = false := by
  decide +kernel

#print axioms adaptive147Third140Proof100

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third140Proof14 : runCachedNode 511 130945 Adaptive147Third140Node14 = false := by
  decide +kernel

#print axioms adaptive147Third140Proof14

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third140Proof223 : runCachedNode 511 130945 Adaptive147Third140Node223 = false := by
  decide +kernel

#print axioms adaptive147Third140Proof223

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third140Proof41 : runCachedNode 511 130945 Adaptive147Third140Node41 = false := by
  decide +kernel

#print axioms adaptive147Third140Proof41

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third140Proof2 : runCachedNode 511 130945 Adaptive147Third140Node2 = false := by
  decide +kernel

#print axioms adaptive147Third140Proof2

end NineSeparatedSubsetSums
