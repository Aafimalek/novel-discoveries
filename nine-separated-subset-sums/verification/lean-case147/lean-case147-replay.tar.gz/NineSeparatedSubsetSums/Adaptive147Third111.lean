import NineSeparatedSubsetSums.Adaptive147Third111Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint147Checked

namespace NineSeparatedSubsetSums


theorem adaptive147Third111 : NoDescendingTailAfterThird 147 111 :=
  noDescendingThirdTail_of_cached 147 111 112835 (fun t ht nd => max148_second147_fourPoint_moment_bound (111::t) (by simp [ht]) nd) adaptive147Third111Proof0

#print axioms adaptive147Third111

end NineSeparatedSubsetSums
