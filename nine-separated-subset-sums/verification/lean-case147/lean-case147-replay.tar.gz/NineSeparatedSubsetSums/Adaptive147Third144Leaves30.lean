import NineSeparatedSubsetSums.Adaptive147Third144State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof335 : runCachedNode 511 131483 Adaptive147Third144Node335 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof335

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof164 : runCachedNode 511 131483 Adaptive147Third144Node164 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof164

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof263 : runCachedNode 511 131483 Adaptive147Third144Node263 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof263

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof132 : runCachedNode 511 131483 Adaptive147Third144Node132 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof132

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof177 : runCachedNode 511 131483 Adaptive147Third144Node177 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof177

end NineSeparatedSubsetSums
