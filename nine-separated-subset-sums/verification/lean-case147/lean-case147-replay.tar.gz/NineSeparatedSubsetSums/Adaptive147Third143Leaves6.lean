import NineSeparatedSubsetSums.Adaptive147Third143State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third143Proof21 : runCachedNode 511 131344 Adaptive147Third143Node21 = false := by
  decide +kernel

#print axioms adaptive147Third143Proof21

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third143Proof75 : runCachedNode 511 131344 Adaptive147Third143Node75 = false := by
  decide +kernel

#print axioms adaptive147Third143Proof75

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third143Proof4 : runCachedNode 511 131344 Adaptive147Third143Node4 = false := by
  decide +kernel

#print axioms adaptive147Third143Proof4

end NineSeparatedSubsetSums
