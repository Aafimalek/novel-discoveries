import NineSeparatedSubsetSums.Adaptive147Third131State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third131Proof20 : runCachedNode 511 129432 Adaptive147Third131Node20 = false := by
  decide +kernel

#print axioms adaptive147Third131Proof20

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third131Proof15 : runCachedNode 511 129432 Adaptive147Third131Node15 = false := by
  decide +kernel

#print axioms adaptive147Third131Proof15

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third131Proof3 : runCachedNode 511 129432 Adaptive147Third131Node3 = false := by
  decide +kernel

#print axioms adaptive147Third131Proof3

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third131Proof2 : runCachedNode 511 129432 Adaptive147Third131Node2 = false := by
  decide +kernel

#print axioms adaptive147Third131Proof2

end NineSeparatedSubsetSums
