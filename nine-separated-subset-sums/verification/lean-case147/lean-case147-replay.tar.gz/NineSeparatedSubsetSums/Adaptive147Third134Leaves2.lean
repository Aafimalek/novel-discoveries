import NineSeparatedSubsetSums.Adaptive147Third134State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third134Proof20 : runCachedNode 511 130034 Adaptive147Third134Node20 = false := by
  decide +kernel

#print axioms adaptive147Third134Proof20

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third134Proof16 : runCachedNode 511 130034 Adaptive147Third134Node16 = false := by
  decide +kernel

#print axioms adaptive147Third134Proof16

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third134Proof37 : runCachedNode 511 130034 Adaptive147Third134Node37 = false := by
  decide +kernel

#print axioms adaptive147Third134Proof37

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third134Proof2 : runCachedNode 511 130034 Adaptive147Third134Node2 = false := by
  decide +kernel

#print axioms adaptive147Third134Proof2

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third134Proof26 : runCachedNode 511 130034 Adaptive147Third134Node26 = false := by
  decide +kernel

#print axioms adaptive147Third134Proof26

end NineSeparatedSubsetSums
