import NineSeparatedSubsetSums.Adaptive147Third143State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third143Proof299 : runCachedNode 511 131344 Adaptive147Third143Node299 = false := by
  decide +kernel

#print axioms adaptive147Third143Proof299

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third143Proof417 : runCachedNode 511 131344 Adaptive147Third143Node417 = false := by
  decide +kernel

#print axioms adaptive147Third143Proof417

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third143Proof25 : runCachedNode 511 131344 Adaptive147Third143Node25 = false := by
  decide +kernel

#print axioms adaptive147Third143Proof25

end NineSeparatedSubsetSums
