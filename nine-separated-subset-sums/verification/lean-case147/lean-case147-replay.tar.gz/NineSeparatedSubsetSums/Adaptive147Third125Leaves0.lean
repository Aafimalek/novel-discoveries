import NineSeparatedSubsetSums.Adaptive147Third125State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third125Proof0 : runCachedNode 511 127929 Adaptive147Third125Node0 = false := by
  decide +kernel

#print axioms adaptive147Third125Proof0

end NineSeparatedSubsetSums
