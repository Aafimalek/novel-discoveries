import NineSeparatedSubsetSums.Adaptive147Third119State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third119Proof0 : runCachedNode 511 126613 Adaptive147Third119Node0 = false := by
  decide +kernel

#print axioms adaptive147Third119Proof0

end NineSeparatedSubsetSums
