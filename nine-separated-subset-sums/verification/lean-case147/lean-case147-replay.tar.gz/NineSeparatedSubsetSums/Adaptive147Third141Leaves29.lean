import NineSeparatedSubsetSums.Adaptive147Third141State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third141Proof186 : runCachedNode 511 131086 Adaptive147Third141Node186 = false := by
  decide +kernel

#print axioms adaptive147Third141Proof186

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third141Proof255 : runCachedNode 511 131086 Adaptive147Third141Node255 = false := by
  decide +kernel

#print axioms adaptive147Third141Proof255

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third141Proof323 : runCachedNode 511 131086 Adaptive147Third141Node323 = false := by
  decide +kernel

#print axioms adaptive147Third141Proof323

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third141Proof184 : runCachedNode 511 131086 Adaptive147Third141Node184 = false := by
  decide +kernel

#print axioms adaptive147Third141Proof184

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third141Proof322 : runCachedNode 511 131086 Adaptive147Third141Node322 = false := by
  decide +kernel

#print axioms adaptive147Third141Proof322

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third141Proof68 : runCachedNode 511 131086 Adaptive147Third141Node68 = false := by
  decide +kernel

#print axioms adaptive147Third141Proof68

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third141Proof152 : runCachedNode 511 131086 Adaptive147Third141Node152 = false := by
  decide +kernel

#print axioms adaptive147Third141Proof152

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third141Proof183 : runCachedNode 511 131086 Adaptive147Third141Node183 = false := by
  decide +kernel

#print axioms adaptive147Third141Proof183

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third141Proof185 : runCachedNode 511 131086 Adaptive147Third141Node185 = false := by
  decide +kernel

#print axioms adaptive147Third141Proof185

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third141Proof218 : runCachedNode 511 131086 Adaptive147Third141Node218 = false := by
  decide +kernel

#print axioms adaptive147Third141Proof218

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third141Proof10 : runCachedNode 511 131086 Adaptive147Third141Node10 = false := by
  decide +kernel

#print axioms adaptive147Third141Proof10

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third141Proof151 : runCachedNode 511 131086 Adaptive147Third141Node151 = false := by
  decide +kernel

#print axioms adaptive147Third141Proof151

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third141Proof297 : runCachedNode 511 131086 Adaptive147Third141Node297 = false := by
  decide +kernel

#print axioms adaptive147Third141Proof297

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third141Proof122 : runCachedNode 511 131086 Adaptive147Third141Node122 = false := by
  decide +kernel

#print axioms adaptive147Third141Proof122

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third141Proof219 : runCachedNode 511 131086 Adaptive147Third141Node219 = false := by
  decide +kernel

#print axioms adaptive147Third141Proof219

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third141Proof296 : runCachedNode 511 131086 Adaptive147Third141Node296 = false := by
  decide +kernel

#print axioms adaptive147Third141Proof296

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third141Proof67 : runCachedNode 511 131086 Adaptive147Third141Node67 = false := by
  decide +kernel

#print axioms adaptive147Third141Proof67

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third141Proof180 : runCachedNode 511 131086 Adaptive147Third141Node180 = false := by
  decide +kernel

#print axioms adaptive147Third141Proof180

end NineSeparatedSubsetSums
