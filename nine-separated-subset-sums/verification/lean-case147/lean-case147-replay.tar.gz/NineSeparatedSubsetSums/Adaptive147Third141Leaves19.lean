import NineSeparatedSubsetSums.Adaptive147Third141State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third141Proof15 : runCachedNode 511 131086 Adaptive147Third141Node15 = false := by
  decide +kernel

#print axioms adaptive147Third141Proof15

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third141Proof262 : runCachedNode 511 131086 Adaptive147Third141Node262 = false := by
  decide +kernel

#print axioms adaptive147Third141Proof262

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third141Proof100 : runCachedNode 511 131086 Adaptive147Third141Node100 = false := by
  decide +kernel

#print axioms adaptive147Third141Proof100

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third141Proof302 : runCachedNode 511 131086 Adaptive147Third141Node302 = false := by
  decide +kernel

#print axioms adaptive147Third141Proof302

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third141Proof324 : runCachedNode 511 131086 Adaptive147Third141Node324 = false := by
  decide +kernel

#print axioms adaptive147Third141Proof324

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third141Proof77 : runCachedNode 511 131086 Adaptive147Third141Node77 = false := by
  decide +kernel

#print axioms adaptive147Third141Proof77

end NineSeparatedSubsetSums
