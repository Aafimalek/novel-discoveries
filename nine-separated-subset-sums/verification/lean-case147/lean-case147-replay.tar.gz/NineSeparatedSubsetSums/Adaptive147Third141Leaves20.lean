import NineSeparatedSubsetSums.Adaptive147Third141State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third141Proof190 : runCachedNode 511 131086 Adaptive147Third141Node190 = false := by
  decide +kernel

#print axioms adaptive147Third141Proof190

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third141Proof158 : runCachedNode 511 131086 Adaptive147Third141Node158 = false := by
  decide +kernel

#print axioms adaptive147Third141Proof158

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third141Proof193 : runCachedNode 511 131086 Adaptive147Third141Node193 = false := by
  decide +kernel

#print axioms adaptive147Third141Proof193

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third141Proof156 : runCachedNode 511 131086 Adaptive147Third141Node156 = false := by
  decide +kernel

#print axioms adaptive147Third141Proof156

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third141Proof227 : runCachedNode 511 131086 Adaptive147Third141Node227 = false := by
  decide +kernel

#print axioms adaptive147Third141Proof227

end NineSeparatedSubsetSums
