import NineSeparatedSubsetSums.Adaptive147Third140State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third140Proof73 : runCachedNode 511 130945 Adaptive147Third140Node73 = false := by
  decide +kernel

#print axioms adaptive147Third140Proof73

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third140Proof17 : runCachedNode 511 130945 Adaptive147Third140Node17 = false := by
  decide +kernel

#print axioms adaptive147Third140Proof17

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third140Proof102 : runCachedNode 511 130945 Adaptive147Third140Node102 = false := by
  decide +kernel

#print axioms adaptive147Third140Proof102

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third140Proof190 : runCachedNode 511 130945 Adaptive147Third140Node190 = false := by
  decide +kernel

#print axioms adaptive147Third140Proof190

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third140Proof138 : runCachedNode 511 130945 Adaptive147Third140Node138 = false := by
  decide +kernel

#print axioms adaptive147Third140Proof138

end NineSeparatedSubsetSums
