import NineSeparatedSubsetSums.Adaptive147Third116State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third116Proof16 : runCachedNode 511 112835 Adaptive147Third116Node16 = false := by
  decide +kernel

#print axioms adaptive147Third116Proof16

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third116Proof15 : runCachedNode 511 112835 Adaptive147Third116Node15 = false := by
  decide +kernel

#print axioms adaptive147Third116Proof15

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third116Proof14 : runCachedNode 511 112835 Adaptive147Third116Node14 = false := by
  decide +kernel

#print axioms adaptive147Third116Proof14

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third116Proof4 : runCachedNode 511 112835 Adaptive147Third116Node4 = false := by
  decide +kernel

#print axioms adaptive147Third116Proof4

end NineSeparatedSubsetSums
