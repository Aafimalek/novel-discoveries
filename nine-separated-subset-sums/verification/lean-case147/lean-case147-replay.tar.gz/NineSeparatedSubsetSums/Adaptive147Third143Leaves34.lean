import NineSeparatedSubsetSums.Adaptive147Third143State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third143Proof462 : runCachedNode 511 131344 Adaptive147Third143Node462 = false := by
  decide +kernel

#print axioms adaptive147Third143Proof462

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third143Proof538 : runCachedNode 511 131344 Adaptive147Third143Node538 = false := by
  decide +kernel

#print axioms adaptive147Third143Proof538

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third143Proof292 : runCachedNode 511 131344 Adaptive147Third143Node292 = false := by
  decide +kernel

#print axioms adaptive147Third143Proof292

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third143Proof101 : runCachedNode 511 131344 Adaptive147Third143Node101 = false := by
  decide +kernel

#print axioms adaptive147Third143Proof101

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third143Proof291 : runCachedNode 511 131344 Adaptive147Third143Node291 = false := by
  decide +kernel

#print axioms adaptive147Third143Proof291

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third143Proof12 : runCachedNode 511 131344 Adaptive147Third143Node12 = false := by
  decide +kernel

#print axioms adaptive147Third143Proof12

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third143Proof99 : runCachedNode 511 131344 Adaptive147Third143Node99 = false := by
  decide +kernel

#print axioms adaptive147Third143Proof99

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third143Proof191 : runCachedNode 511 131344 Adaptive147Third143Node191 = false := by
  decide +kernel

#print axioms adaptive147Third143Proof191

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third143Proof114 : runCachedNode 511 131344 Adaptive147Third143Node114 = false := by
  decide +kernel

#print axioms adaptive147Third143Proof114

end NineSeparatedSubsetSums
