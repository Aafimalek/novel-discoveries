import NineSeparatedSubsetSums.Adaptive147Third141State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third141Proof230 : runCachedNode 511 131086 Adaptive147Third141Node230 = false := by
  decide +kernel

#print axioms adaptive147Third141Proof230

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third141Proof157 : runCachedNode 511 131086 Adaptive147Third141Node157 = false := by
  decide +kernel

#print axioms adaptive147Third141Proof157

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third141Proof27 : runCachedNode 511 131086 Adaptive147Third141Node27 = false := by
  decide +kernel

#print axioms adaptive147Third141Proof27

end NineSeparatedSubsetSums
