import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive147Third125Node0 : CachedSearchNode :=
  ⟨4, 124, computeCenteredMask [148,147,125], 420, 59138⟩

end NineSeparatedSubsetSums
