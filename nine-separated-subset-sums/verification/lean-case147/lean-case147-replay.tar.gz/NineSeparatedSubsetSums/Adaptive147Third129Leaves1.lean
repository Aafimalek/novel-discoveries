import NineSeparatedSubsetSums.Adaptive147Third129State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third129Proof16 : runCachedNode 511 129010 Adaptive147Third129Node16 = false := by
  decide +kernel

#print axioms adaptive147Third129Proof16

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third129Proof14 : runCachedNode 511 129010 Adaptive147Third129Node14 = false := by
  decide +kernel

#print axioms adaptive147Third129Proof14

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third129Proof13 : runCachedNode 511 129010 Adaptive147Third129Node13 = false := by
  decide +kernel

#print axioms adaptive147Third129Proof13

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third129Proof12 : runCachedNode 511 129010 Adaptive147Third129Node12 = false := by
  decide +kernel

#print axioms adaptive147Third129Proof12

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third129Proof11 : runCachedNode 511 129010 Adaptive147Third129Node11 = false := by
  decide +kernel

#print axioms adaptive147Third129Proof11

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third129Proof10 : runCachedNode 511 129010 Adaptive147Third129Node10 = false := by
  decide +kernel

#print axioms adaptive147Third129Proof10

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third129Proof9 : runCachedNode 511 129010 Adaptive147Third129Node9 = false := by
  decide +kernel

#print axioms adaptive147Third129Proof9

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third129Proof7 : runCachedNode 511 129010 Adaptive147Third129Node7 = false := by
  decide +kernel

#print axioms adaptive147Third129Proof7

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third129Proof3 : runCachedNode 511 129010 Adaptive147Third129Node3 = false := by
  decide +kernel

#print axioms adaptive147Third129Proof3

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third129Proof2 : runCachedNode 511 129010 Adaptive147Third129Node2 = false := by
  decide +kernel

#print axioms adaptive147Third129Proof2

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third129Proof1 : runCachedNode 511 129010 Adaptive147Third129Node1 = false := by
  decide +kernel

#print axioms adaptive147Third129Proof1

end NineSeparatedSubsetSums
