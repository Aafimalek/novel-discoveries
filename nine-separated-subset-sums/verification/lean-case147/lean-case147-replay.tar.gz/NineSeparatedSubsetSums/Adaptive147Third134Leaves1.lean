import NineSeparatedSubsetSums.Adaptive147Third134State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third134Proof21 : runCachedNode 511 130034 Adaptive147Third134Node21 = false := by
  decide +kernel

#print axioms adaptive147Third134Proof21

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third134Proof47 : runCachedNode 511 130034 Adaptive147Third134Node47 = false := by
  decide +kernel

#print axioms adaptive147Third134Proof47

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third134Proof35 : runCachedNode 511 130034 Adaptive147Third134Node35 = false := by
  decide +kernel

#print axioms adaptive147Third134Proof35

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third134Proof3 : runCachedNode 511 130034 Adaptive147Third134Node3 = false := by
  decide +kernel

#print axioms adaptive147Third134Proof3

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third134Proof24 : runCachedNode 511 130034 Adaptive147Third134Node24 = false := by
  decide +kernel

#print axioms adaptive147Third134Proof24

end NineSeparatedSubsetSums
