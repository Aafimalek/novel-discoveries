import NineSeparatedSubsetSums.Adaptive147Third143State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third143Proof415 : runCachedNode 511 131344 Adaptive147Third143Node415 = false := by
  decide +kernel

#print axioms adaptive147Third143Proof415

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third143Proof104 : runCachedNode 511 131344 Adaptive147Third143Node104 = false := by
  decide +kernel

#print axioms adaptive147Third143Proof104

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third143Proof162 : runCachedNode 511 131344 Adaptive147Third143Node162 = false := by
  decide +kernel

#print axioms adaptive147Third143Proof162

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third143Proof135 : runCachedNode 511 131344 Adaptive147Third143Node135 = false := by
  decide +kernel

#print axioms adaptive147Third143Proof135

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third143Proof192 : runCachedNode 511 131344 Adaptive147Third143Node192 = false := by
  decide +kernel

#print axioms adaptive147Third143Proof192

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third143Proof54 : runCachedNode 511 131344 Adaptive147Third143Node54 = false := by
  decide +kernel

#print axioms adaptive147Third143Proof54

end NineSeparatedSubsetSums
