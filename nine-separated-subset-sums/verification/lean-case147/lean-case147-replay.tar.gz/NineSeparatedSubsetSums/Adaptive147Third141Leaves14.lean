import NineSeparatedSubsetSums.Adaptive147Third141State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third141Proof303 : runCachedNode 511 131086 Adaptive147Third141Node303 = false := by
  decide +kernel

#print axioms adaptive147Third141Proof303

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third141Proof194 : runCachedNode 511 131086 Adaptive147Third141Node194 = false := by
  decide +kernel

#print axioms adaptive147Third141Proof194

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third141Proof84 : runCachedNode 511 131086 Adaptive147Third141Node84 = false := by
  decide +kernel

#print axioms adaptive147Third141Proof84

end NineSeparatedSubsetSums
