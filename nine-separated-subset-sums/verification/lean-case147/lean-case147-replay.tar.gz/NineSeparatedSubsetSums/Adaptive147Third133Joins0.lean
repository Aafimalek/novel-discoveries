import NineSeparatedSubsetSums.Adaptive147Third133State
import NineSeparatedSubsetSums.Adaptive147Third133Leaves2
import NineSeparatedSubsetSums.Adaptive147Third133Leaves1
import NineSeparatedSubsetSums.Adaptive147Third133Leaves4
import NineSeparatedSubsetSums.Adaptive147Third133Leaves3
import NineSeparatedSubsetSums.Adaptive147Third133Leaves5
import NineSeparatedSubsetSums.Adaptive147Third133Leaves0

namespace NineSeparatedSubsetSums

theorem adaptive147Third133Proof22 : runCachedNode 511 129861 Adaptive147Third133Node22 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 129861 Adaptive147Third133Node22 = [104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive147Third133Proof23
  · exact adaptive147Third133Proof24
  · exact adaptive147Third133Proof25
  · exact adaptive147Third133Proof26
  · exact adaptive147Third133Proof27
  · exact adaptive147Third133Proof28
  · exact adaptive147Third133Proof29
  · exact adaptive147Third133Proof30
  · exact adaptive147Third133Proof31
  · exact adaptive147Third133Proof32
  · exact adaptive147Third133Proof33
  · exact adaptive147Third133Proof34
  · exact adaptive147Third133Proof35
  · exact adaptive147Third133Proof36
  · exact adaptive147Third133Proof37
  · exact adaptive147Third133Proof38
  · exact adaptive147Third133Proof39
  · exact adaptive147Third133Proof40
  · exact adaptive147Third133Proof41
  · exact adaptive147Third133Proof42
  · exact adaptive147Third133Proof43
  · exact adaptive147Third133Proof44
  · exact adaptive147Third133Proof45
  · exact adaptive147Third133Proof46

#print axioms adaptive147Third133Proof22

theorem adaptive147Third133Proof0 : runCachedNode 511 129861 Adaptive147Third133Node0 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 129861 Adaptive147Third133Node0 = [110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive147Third133Proof1
  · exact adaptive147Third133Proof2
  · exact adaptive147Third133Proof3
  · exact adaptive147Third133Proof4
  · exact adaptive147Third133Proof5
  · exact adaptive147Third133Proof6
  · exact adaptive147Third133Proof7
  · exact adaptive147Third133Proof8
  · exact adaptive147Third133Proof9
  · exact adaptive147Third133Proof10
  · exact adaptive147Third133Proof11
  · exact adaptive147Third133Proof12
  · exact adaptive147Third133Proof13
  · exact adaptive147Third133Proof14
  · exact adaptive147Third133Proof15
  · exact adaptive147Third133Proof16
  · exact adaptive147Third133Proof17
  · exact adaptive147Third133Proof18
  · exact adaptive147Third133Proof19
  · exact adaptive147Third133Proof20
  · exact adaptive147Third133Proof21
  · exact adaptive147Third133Proof22

#print axioms adaptive147Third133Proof0

end NineSeparatedSubsetSums
