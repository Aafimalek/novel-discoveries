import NineSeparatedSubsetSums.Adaptive147Third144State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof131 : runCachedNode 511 131483 Adaptive147Third144Node131 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof131

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof228 : runCachedNode 511 131483 Adaptive147Third144Node228 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof228

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof332 : runCachedNode 511 131483 Adaptive147Third144Node332 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof332

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof834 : runCachedNode 511 131483 Adaptive147Third144Node834 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof834

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof704 : runCachedNode 511 131483 Adaptive147Third144Node704 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof704

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof226 : runCachedNode 511 131483 Adaptive147Third144Node226 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof226

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof107 : runCachedNode 511 131483 Adaptive147Third144Node107 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof107

end NineSeparatedSubsetSums
