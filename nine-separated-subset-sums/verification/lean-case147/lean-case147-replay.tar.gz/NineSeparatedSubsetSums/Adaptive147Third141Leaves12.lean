import NineSeparatedSubsetSums.Adaptive147Third141State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third141Proof162 : runCachedNode 511 131086 Adaptive147Third141Node162 = false := by
  decide +kernel

#print axioms adaptive147Third141Proof162

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third141Proof131 : runCachedNode 511 131086 Adaptive147Third141Node131 = false := by
  decide +kernel

#print axioms adaptive147Third141Proof131

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third141Proof253 : runCachedNode 511 131086 Adaptive147Third141Node253 = false := by
  decide +kernel

#print axioms adaptive147Third141Proof253

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third141Proof24 : runCachedNode 511 131086 Adaptive147Third141Node24 = false := by
  decide +kernel

#print axioms adaptive147Third141Proof24

end NineSeparatedSubsetSums
