import NineSeparatedSubsetSums.Adaptive147Third142State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third142Proof205 : runCachedNode 511 131213 Adaptive147Third142Node205 = false := by
  decide +kernel

#print axioms adaptive147Third142Proof205

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third142Proof168 : runCachedNode 511 131213 Adaptive147Third142Node168 = false := by
  decide +kernel

#print axioms adaptive147Third142Proof168

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third142Proof223 : runCachedNode 511 131213 Adaptive147Third142Node223 = false := by
  decide +kernel

#print axioms adaptive147Third142Proof223

end NineSeparatedSubsetSums
