import NineSeparatedSubsetSums.Adaptive147Third144State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof129 : runCachedNode 511 131483 Adaptive147Third144Node129 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof129

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof227 : runCachedNode 511 131483 Adaptive147Third144Node227 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof227

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof101 : runCachedNode 511 131483 Adaptive147Third144Node101 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof101

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof789 : runCachedNode 511 131483 Adaptive147Third144Node789 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof789

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof575 : runCachedNode 511 131483 Adaptive147Third144Node575 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof575

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof193 : runCachedNode 511 131483 Adaptive147Third144Node193 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof193

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof65 : runCachedNode 511 131483 Adaptive147Third144Node65 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof65

end NineSeparatedSubsetSums
