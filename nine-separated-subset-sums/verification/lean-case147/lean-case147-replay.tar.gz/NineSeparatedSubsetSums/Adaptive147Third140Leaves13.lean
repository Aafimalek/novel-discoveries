import NineSeparatedSubsetSums.Adaptive147Third140State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third140Proof196 : runCachedNode 511 130945 Adaptive147Third140Node196 = false := by
  decide +kernel

#print axioms adaptive147Third140Proof196

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third140Proof163 : runCachedNode 511 130945 Adaptive147Third140Node163 = false := by
  decide +kernel

#print axioms adaptive147Third140Proof163

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third140Proof58 : runCachedNode 511 130945 Adaptive147Third140Node58 = false := by
  decide +kernel

#print axioms adaptive147Third140Proof58

end NineSeparatedSubsetSums
