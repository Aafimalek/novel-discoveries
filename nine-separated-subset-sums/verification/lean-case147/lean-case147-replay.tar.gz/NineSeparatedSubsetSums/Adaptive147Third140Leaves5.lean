import NineSeparatedSubsetSums.Adaptive147Third140State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third140Proof260 : runCachedNode 511 130945 Adaptive147Third140Node260 = false := by
  decide +kernel

#print axioms adaptive147Third140Proof260

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third140Proof101 : runCachedNode 511 130945 Adaptive147Third140Node101 = false := by
  decide +kernel

#print axioms adaptive147Third140Proof101

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third140Proof26 : runCachedNode 511 130945 Adaptive147Third140Node26 = false := by
  decide +kernel

#print axioms adaptive147Third140Proof26

end NineSeparatedSubsetSums
