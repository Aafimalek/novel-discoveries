import NineSeparatedSubsetSums.Adaptive147Third144State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof707 : runCachedNode 511 131483 Adaptive147Third144Node707 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof707

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof338 : runCachedNode 511 131483 Adaptive147Third144Node338 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof338

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof176 : runCachedNode 511 131483 Adaptive147Third144Node176 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof176

end NineSeparatedSubsetSums
