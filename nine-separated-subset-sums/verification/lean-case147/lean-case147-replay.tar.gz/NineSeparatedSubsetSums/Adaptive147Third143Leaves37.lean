import NineSeparatedSubsetSums.Adaptive147Third143State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third143Proof412 : runCachedNode 511 131344 Adaptive147Third143Node412 = false := by
  decide +kernel

#print axioms adaptive147Third143Proof412

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third143Proof289 : runCachedNode 511 131344 Adaptive147Third143Node289 = false := by
  decide +kernel

#print axioms adaptive147Third143Proof289

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third143Proof410 : runCachedNode 511 131344 Adaptive147Third143Node410 = false := by
  decide +kernel

#print axioms adaptive147Third143Proof410

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third143Proof70 : runCachedNode 511 131344 Adaptive147Third143Node70 = false := by
  decide +kernel

#print axioms adaptive147Third143Proof70

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third143Proof157 : runCachedNode 511 131344 Adaptive147Third143Node157 = false := by
  decide +kernel

#print axioms adaptive147Third143Proof157

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third143Proof341 : runCachedNode 511 131344 Adaptive147Third143Node341 = false := by
  decide +kernel

#print axioms adaptive147Third143Proof341

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third143Proof102 : runCachedNode 511 131344 Adaptive147Third143Node102 = false := by
  decide +kernel

#print axioms adaptive147Third143Proof102

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third143Proof224 : runCachedNode 511 131344 Adaptive147Third143Node224 = false := by
  decide +kernel

#print axioms adaptive147Third143Proof224

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third143Proof587 : runCachedNode 511 131344 Adaptive147Third143Node587 = false := by
  decide +kernel

#print axioms adaptive147Third143Proof587

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third143Proof159 : runCachedNode 511 131344 Adaptive147Third143Node159 = false := by
  decide +kernel

#print axioms adaptive147Third143Proof159

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third143Proof283 : runCachedNode 511 131344 Adaptive147Third143Node283 = false := by
  decide +kernel

#print axioms adaptive147Third143Proof283

end NineSeparatedSubsetSums
