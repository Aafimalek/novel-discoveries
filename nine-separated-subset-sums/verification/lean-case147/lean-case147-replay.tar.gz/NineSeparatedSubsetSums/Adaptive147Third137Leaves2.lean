import NineSeparatedSubsetSums.Adaptive147Third137State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third137Proof18 : runCachedNode 511 130518 Adaptive147Third137Node18 = false := by
  decide +kernel

#print axioms adaptive147Third137Proof18

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third137Proof93 : runCachedNode 511 130518 Adaptive147Third137Node93 = false := by
  decide +kernel

#print axioms adaptive147Third137Proof93

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third137Proof22 : runCachedNode 511 130518 Adaptive147Third137Node22 = false := by
  decide +kernel

#print axioms adaptive147Third137Proof22

end NineSeparatedSubsetSums
