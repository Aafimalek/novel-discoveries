import NineSeparatedSubsetSums.Adaptive147Third130State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third130Proof17 : runCachedNode 511 129214 Adaptive147Third130Node17 = false := by
  decide +kernel

#print axioms adaptive147Third130Proof17

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third130Proof16 : runCachedNode 511 129214 Adaptive147Third130Node16 = false := by
  decide +kernel

#print axioms adaptive147Third130Proof16

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third130Proof15 : runCachedNode 511 129214 Adaptive147Third130Node15 = false := by
  decide +kernel

#print axioms adaptive147Third130Proof15

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third130Proof14 : runCachedNode 511 129214 Adaptive147Third130Node14 = false := by
  decide +kernel

#print axioms adaptive147Third130Proof14

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third130Proof6 : runCachedNode 511 129214 Adaptive147Third130Node6 = false := by
  decide +kernel

#print axioms adaptive147Third130Proof6

end NineSeparatedSubsetSums
