import NineSeparatedSubsetSums.Adaptive147Third144State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof527 : runCachedNode 511 131483 Adaptive147Third144Node527 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof527

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof835 : runCachedNode 511 131483 Adaptive147Third144Node835 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof835

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof735 : runCachedNode 511 131483 Adaptive147Third144Node735 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof735

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof163 : runCachedNode 511 131483 Adaptive147Third144Node163 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof163

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof413 : runCachedNode 511 131483 Adaptive147Third144Node413 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof413

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof206 : runCachedNode 511 131483 Adaptive147Third144Node206 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof206

end NineSeparatedSubsetSums
