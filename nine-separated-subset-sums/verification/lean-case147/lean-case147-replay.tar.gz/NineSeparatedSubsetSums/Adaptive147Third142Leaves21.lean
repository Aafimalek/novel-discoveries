import NineSeparatedSubsetSums.Adaptive147Third142State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third142Proof164 : runCachedNode 511 131213 Adaptive147Third142Node164 = false := by
  decide +kernel

#print axioms adaptive147Third142Proof164

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third142Proof166 : runCachedNode 511 131213 Adaptive147Third142Node166 = false := by
  decide +kernel

#print axioms adaptive147Third142Proof166

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third142Proof109 : runCachedNode 511 131213 Adaptive147Third142Node109 = false := by
  decide +kernel

#print axioms adaptive147Third142Proof109

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third142Proof259 : runCachedNode 511 131213 Adaptive147Third142Node259 = false := by
  decide +kernel

#print axioms adaptive147Third142Proof259

end NineSeparatedSubsetSums
