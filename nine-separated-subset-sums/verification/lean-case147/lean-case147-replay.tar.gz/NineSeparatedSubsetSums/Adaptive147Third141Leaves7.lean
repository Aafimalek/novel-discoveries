import NineSeparatedSubsetSums.Adaptive147Third141State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third141Proof339 : runCachedNode 511 131086 Adaptive147Third141Node339 = false := by
  decide +kernel

#print axioms adaptive147Third141Proof339

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third141Proof263 : runCachedNode 511 131086 Adaptive147Third141Node263 = false := by
  decide +kernel

#print axioms adaptive147Third141Proof263

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third141Proof3 : runCachedNode 511 131086 Adaptive147Third141Node3 = false := by
  decide +kernel

#print axioms adaptive147Third141Proof3

end NineSeparatedSubsetSums
