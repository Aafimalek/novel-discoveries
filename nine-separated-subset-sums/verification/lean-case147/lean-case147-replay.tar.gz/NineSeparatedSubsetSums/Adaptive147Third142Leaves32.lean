import NineSeparatedSubsetSums.Adaptive147Third142State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third142Proof432 : runCachedNode 511 131213 Adaptive147Third142Node432 = false := by
  decide +kernel

#print axioms adaptive147Third142Proof432

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third142Proof75 : runCachedNode 511 131213 Adaptive147Third142Node75 = false := by
  decide +kernel

#print axioms adaptive147Third142Proof75

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third142Proof230 : runCachedNode 511 131213 Adaptive147Third142Node230 = false := by
  decide +kernel

#print axioms adaptive147Third142Proof230

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third142Proof309 : runCachedNode 511 131213 Adaptive147Third142Node309 = false := by
  decide +kernel

#print axioms adaptive147Third142Proof309

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third142Proof73 : runCachedNode 511 131213 Adaptive147Third142Node73 = false := by
  decide +kernel

#print axioms adaptive147Third142Proof73

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third142Proof12 : runCachedNode 511 131213 Adaptive147Third142Node12 = false := by
  decide +kernel

#print axioms adaptive147Third142Proof12

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third142Proof103 : runCachedNode 511 131213 Adaptive147Third142Node103 = false := by
  decide +kernel

#print axioms adaptive147Third142Proof103

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third142Proof193 : runCachedNode 511 131213 Adaptive147Third142Node193 = false := by
  decide +kernel

#print axioms adaptive147Third142Proof193

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third142Proof224 : runCachedNode 511 131213 Adaptive147Third142Node224 = false := by
  decide +kernel

#print axioms adaptive147Third142Proof224

end NineSeparatedSubsetSums
