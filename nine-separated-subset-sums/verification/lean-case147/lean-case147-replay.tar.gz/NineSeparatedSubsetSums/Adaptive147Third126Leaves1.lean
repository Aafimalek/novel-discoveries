import NineSeparatedSubsetSums.Adaptive147Third126State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third126Proof7 : runCachedNode 511 128211 Adaptive147Third126Node7 = false := by
  decide +kernel

#print axioms adaptive147Third126Proof7

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third126Proof6 : runCachedNode 511 128211 Adaptive147Third126Node6 = false := by
  decide +kernel

#print axioms adaptive147Third126Proof6

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third126Proof4 : runCachedNode 511 128211 Adaptive147Third126Node4 = false := by
  decide +kernel

#print axioms adaptive147Third126Proof4

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third126Proof3 : runCachedNode 511 128211 Adaptive147Third126Node3 = false := by
  decide +kernel

#print axioms adaptive147Third126Proof3

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third126Proof1 : runCachedNode 511 128211 Adaptive147Third126Node1 = false := by
  decide +kernel

#print axioms adaptive147Third126Proof1

end NineSeparatedSubsetSums
