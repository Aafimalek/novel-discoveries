import NineSeparatedSubsetSums.Adaptive147Third144State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof157 : runCachedNode 511 131483 Adaptive147Third144Node157 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof157

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof569 : runCachedNode 511 131483 Adaptive147Third144Node569 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof569

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof825 : runCachedNode 511 131483 Adaptive147Third144Node825 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof825

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof43 : runCachedNode 511 131483 Adaptive147Third144Node43 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof43

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof69 : runCachedNode 511 131483 Adaptive147Third144Node69 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof69

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof95 : runCachedNode 511 131483 Adaptive147Third144Node95 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof95

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof290 : runCachedNode 511 131483 Adaptive147Third144Node290 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof290

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof657 : runCachedNode 511 131483 Adaptive147Third144Node657 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof657

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof612 : runCachedNode 511 131483 Adaptive147Third144Node612 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof612

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof828 : runCachedNode 511 131483 Adaptive147Third144Node828 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof828

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof96 : runCachedNode 511 131483 Adaptive147Third144Node96 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof96

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof42 : runCachedNode 511 131483 Adaptive147Third144Node42 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof42

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof189 : runCachedNode 511 131483 Adaptive147Third144Node189 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof189

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof823 : runCachedNode 511 131483 Adaptive147Third144Node823 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof823

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof173 : runCachedNode 511 131483 Adaptive147Third144Node173 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof173

end NineSeparatedSubsetSums
