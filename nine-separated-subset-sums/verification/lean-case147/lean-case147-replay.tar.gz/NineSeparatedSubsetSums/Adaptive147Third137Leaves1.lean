import NineSeparatedSubsetSums.Adaptive147Third137State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third137Proof19 : runCachedNode 511 130518 Adaptive147Third137Node19 = false := by
  decide +kernel

#print axioms adaptive147Third137Proof19

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third137Proof177 : runCachedNode 511 130518 Adaptive147Third137Node177 = false := by
  decide +kernel

#print axioms adaptive147Third137Proof177

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third137Proof140 : runCachedNode 511 130518 Adaptive147Third137Node140 = false := by
  decide +kernel

#print axioms adaptive147Third137Proof140

end NineSeparatedSubsetSums
