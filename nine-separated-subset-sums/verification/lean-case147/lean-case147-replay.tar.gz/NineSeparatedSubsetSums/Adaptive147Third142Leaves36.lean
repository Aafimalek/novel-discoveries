import NineSeparatedSubsetSums.Adaptive147Third142State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third142Proof276 : runCachedNode 511 131213 Adaptive147Third142Node276 = false := by
  decide +kernel

#print axioms adaptive147Third142Proof276

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third142Proof473 : runCachedNode 511 131213 Adaptive147Third142Node473 = false := by
  decide +kernel

#print axioms adaptive147Third142Proof473

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third142Proof69 : runCachedNode 511 131213 Adaptive147Third142Node69 = false := by
  decide +kernel

#print axioms adaptive147Third142Proof69

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third142Proof349 : runCachedNode 511 131213 Adaptive147Third142Node349 = false := by
  decide +kernel

#print axioms adaptive147Third142Proof349

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third142Proof42 : runCachedNode 511 131213 Adaptive147Third142Node42 = false := by
  decide +kernel

#print axioms adaptive147Third142Proof42

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third142Proof70 : runCachedNode 511 131213 Adaptive147Third142Node70 = false := by
  decide +kernel

#print axioms adaptive147Third142Proof70

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third142Proof157 : runCachedNode 511 131213 Adaptive147Third142Node157 = false := by
  decide +kernel

#print axioms adaptive147Third142Proof157

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third142Proof225 : runCachedNode 511 131213 Adaptive147Third142Node225 = false := by
  decide +kernel

#print axioms adaptive147Third142Proof225

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third142Proof189 : runCachedNode 511 131213 Adaptive147Third142Node189 = false := by
  decide +kernel

#print axioms adaptive147Third142Proof189

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third142Proof190 : runCachedNode 511 131213 Adaptive147Third142Node190 = false := by
  decide +kernel

#print axioms adaptive147Third142Proof190

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third142Proof10 : runCachedNode 511 131213 Adaptive147Third142Node10 = false := by
  decide +kernel

#print axioms adaptive147Third142Proof10

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third142Proof156 : runCachedNode 511 131213 Adaptive147Third142Node156 = false := by
  decide +kernel

#print axioms adaptive147Third142Proof156

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third142Proof226 : runCachedNode 511 131213 Adaptive147Third142Node226 = false := by
  decide +kernel

#print axioms adaptive147Third142Proof226

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third142Proof128 : runCachedNode 511 131213 Adaptive147Third142Node128 = false := by
  decide +kernel

#print axioms adaptive147Third142Proof128

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third142Proof68 : runCachedNode 511 131213 Adaptive147Third142Node68 = false := by
  decide +kernel

#print axioms adaptive147Third142Proof68

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third142Proof374 : runCachedNode 511 131213 Adaptive147Third142Node374 = false := by
  decide +kernel

#print axioms adaptive147Third142Proof374

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third142Proof301 : runCachedNode 511 131213 Adaptive147Third142Node301 = false := by
  decide +kernel

#print axioms adaptive147Third142Proof301

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third142Proof304 : runCachedNode 511 131213 Adaptive147Third142Node304 = false := by
  decide +kernel

#print axioms adaptive147Third142Proof304

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third142Proof95 : runCachedNode 511 131213 Adaptive147Third142Node95 = false := by
  decide +kernel

#print axioms adaptive147Third142Proof95

end NineSeparatedSubsetSums
