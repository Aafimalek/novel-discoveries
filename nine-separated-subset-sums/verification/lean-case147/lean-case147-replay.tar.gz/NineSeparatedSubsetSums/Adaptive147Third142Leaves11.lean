import NineSeparatedSubsetSums.Adaptive147Third142State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third142Proof169 : runCachedNode 511 131213 Adaptive147Third142Node169 = false := by
  decide +kernel

#print axioms adaptive147Third142Proof169

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third142Proof165 : runCachedNode 511 131213 Adaptive147Third142Node165 = false := by
  decide +kernel

#print axioms adaptive147Third142Proof165

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third142Proof81 : runCachedNode 511 131213 Adaptive147Third142Node81 = false := by
  decide +kernel

#print axioms adaptive147Third142Proof81

end NineSeparatedSubsetSums
