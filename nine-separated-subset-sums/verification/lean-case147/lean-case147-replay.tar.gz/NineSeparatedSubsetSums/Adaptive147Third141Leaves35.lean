import NineSeparatedSubsetSums.Adaptive147Third141State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third141Proof271 : runCachedNode 511 131086 Adaptive147Third141Node271 = false := by
  decide +kernel

#print axioms adaptive147Third141Proof271

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third141Proof272 : runCachedNode 511 131086 Adaptive147Third141Node272 = false := by
  decide +kernel

#print axioms adaptive147Third141Proof272

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third141Proof273 : runCachedNode 511 131086 Adaptive147Third141Node273 = false := by
  decide +kernel

#print axioms adaptive147Third141Proof273

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third141Proof307 : runCachedNode 511 131086 Adaptive147Third141Node307 = false := by
  decide +kernel

#print axioms adaptive147Third141Proof307

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third141Proof199 : runCachedNode 511 131086 Adaptive147Third141Node199 = false := by
  decide +kernel

#print axioms adaptive147Third141Proof199

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third141Proof233 : runCachedNode 511 131086 Adaptive147Third141Node233 = false := by
  decide +kernel

#print axioms adaptive147Third141Proof233

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third141Proof234 : runCachedNode 511 131086 Adaptive147Third141Node234 = false := by
  decide +kernel

#print axioms adaptive147Third141Proof234

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third141Proof235 : runCachedNode 511 131086 Adaptive147Third141Node235 = false := by
  decide +kernel

#print axioms adaptive147Third141Proof235

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third141Proof266 : runCachedNode 511 131086 Adaptive147Third141Node266 = false := by
  decide +kernel

#print axioms adaptive147Third141Proof266

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third141Proof267 : runCachedNode 511 131086 Adaptive147Third141Node267 = false := by
  decide +kernel

#print axioms adaptive147Third141Proof267

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third141Proof268 : runCachedNode 511 131086 Adaptive147Third141Node268 = false := by
  decide +kernel

#print axioms adaptive147Third141Proof268

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third141Proof269 : runCachedNode 511 131086 Adaptive147Third141Node269 = false := by
  decide +kernel

#print axioms adaptive147Third141Proof269

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third141Proof270 : runCachedNode 511 131086 Adaptive147Third141Node270 = false := by
  decide +kernel

#print axioms adaptive147Third141Proof270

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third141Proof305 : runCachedNode 511 131086 Adaptive147Third141Node305 = false := by
  decide +kernel

#print axioms adaptive147Third141Proof305

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third141Proof306 : runCachedNode 511 131086 Adaptive147Third141Node306 = false := by
  decide +kernel

#print axioms adaptive147Third141Proof306

end NineSeparatedSubsetSums
