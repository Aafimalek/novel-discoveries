import NineSeparatedSubsetSums.Adaptive147Third140State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third140Proof261 : runCachedNode 511 130945 Adaptive147Third140Node261 = false := by
  decide +kernel

#print axioms adaptive147Third140Proof261

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third140Proof262 : runCachedNode 511 130945 Adaptive147Third140Node262 = false := by
  decide +kernel

#print axioms adaptive147Third140Proof262

end NineSeparatedSubsetSums
