import NineSeparatedSubsetSums.Adaptive147Third140State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third140Proof133 : runCachedNode 511 130945 Adaptive147Third140Node133 = false := by
  decide +kernel

#print axioms adaptive147Third140Proof133

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third140Proof229 : runCachedNode 511 130945 Adaptive147Third140Node229 = false := by
  decide +kernel

#print axioms adaptive147Third140Proof229

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third140Proof137 : runCachedNode 511 130945 Adaptive147Third140Node137 = false := by
  decide +kernel

#print axioms adaptive147Third140Proof137

end NineSeparatedSubsetSums
