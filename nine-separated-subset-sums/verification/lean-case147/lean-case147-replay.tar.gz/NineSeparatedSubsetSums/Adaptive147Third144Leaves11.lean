import NineSeparatedSubsetSums.Adaptive147Third144State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof744 : runCachedNode 511 131483 Adaptive147Third144Node744 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof744

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof337 : runCachedNode 511 131483 Adaptive147Third144Node337 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof337

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof53 : runCachedNode 511 131483 Adaptive147Third144Node53 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof53

end NineSeparatedSubsetSums
