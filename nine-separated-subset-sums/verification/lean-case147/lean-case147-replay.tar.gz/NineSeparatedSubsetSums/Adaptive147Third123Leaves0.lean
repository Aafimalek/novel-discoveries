import NineSeparatedSubsetSums.Adaptive147Third123State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third123Proof0 : runCachedNode 511 127417 Adaptive147Third123Node0 = false := by
  decide +kernel

#print axioms adaptive147Third123Proof0

end NineSeparatedSubsetSums
