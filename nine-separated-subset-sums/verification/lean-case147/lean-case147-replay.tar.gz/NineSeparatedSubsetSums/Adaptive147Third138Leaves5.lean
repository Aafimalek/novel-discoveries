import NineSeparatedSubsetSums.Adaptive147Third138State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third138Proof17 : runCachedNode 511 130657 Adaptive147Third138Node17 = false := by
  decide +kernel

#print axioms adaptive147Third138Proof17

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third138Proof174 : runCachedNode 511 130657 Adaptive147Third138Node174 = false := by
  decide +kernel

#print axioms adaptive147Third138Proof174

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third138Proof118 : runCachedNode 511 130657 Adaptive147Third138Node118 = false := by
  decide +kernel

#print axioms adaptive147Third138Proof118

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third138Proof129 : runCachedNode 511 130657 Adaptive147Third138Node129 = false := by
  decide +kernel

#print axioms adaptive147Third138Proof129

end NineSeparatedSubsetSums
