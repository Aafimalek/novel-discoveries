import NineSeparatedSubsetSums.Adaptive147Third140State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third140Proof158 : runCachedNode 511 130945 Adaptive147Third140Node158 = false := by
  decide +kernel

#print axioms adaptive147Third140Proof158

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third140Proof10 : runCachedNode 511 130945 Adaptive147Third140Node10 = false := by
  decide +kernel

#print axioms adaptive147Third140Proof10

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third140Proof91 : runCachedNode 511 130945 Adaptive147Third140Node91 = false := by
  decide +kernel

#print axioms adaptive147Third140Proof91

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third140Proof215 : runCachedNode 511 130945 Adaptive147Third140Node215 = false := by
  decide +kernel

#print axioms adaptive147Third140Proof215

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third140Proof185 : runCachedNode 511 130945 Adaptive147Third140Node185 = false := by
  decide +kernel

#print axioms adaptive147Third140Proof185

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third140Proof186 : runCachedNode 511 130945 Adaptive147Third140Node186 = false := by
  decide +kernel

#print axioms adaptive147Third140Proof186

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third140Proof217 : runCachedNode 511 130945 Adaptive147Third140Node217 = false := by
  decide +kernel

#print axioms adaptive147Third140Proof217

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third140Proof248 : runCachedNode 511 130945 Adaptive147Third140Node248 = false := by
  decide +kernel

#print axioms adaptive147Third140Proof248

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third140Proof249 : runCachedNode 511 130945 Adaptive147Third140Node249 = false := by
  decide +kernel

#print axioms adaptive147Third140Proof249

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third140Proof40 : runCachedNode 511 130945 Adaptive147Third140Node40 = false := by
  decide +kernel

#print axioms adaptive147Third140Proof40

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third140Proof220 : runCachedNode 511 130945 Adaptive147Third140Node220 = false := by
  decide +kernel

#print axioms adaptive147Third140Proof220

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third140Proof153 : runCachedNode 511 130945 Adaptive147Third140Node153 = false := by
  decide +kernel

#print axioms adaptive147Third140Proof153

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third140Proof216 : runCachedNode 511 130945 Adaptive147Third140Node216 = false := by
  decide +kernel

#print axioms adaptive147Third140Proof216

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third140Proof39 : runCachedNode 511 130945 Adaptive147Third140Node39 = false := by
  decide +kernel

#print axioms adaptive147Third140Proof39

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third140Proof121 : runCachedNode 511 130945 Adaptive147Third140Node121 = false := by
  decide +kernel

#print axioms adaptive147Third140Proof121

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third140Proof247 : runCachedNode 511 130945 Adaptive147Third140Node247 = false := by
  decide +kernel

#print axioms adaptive147Third140Proof247

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third140Proof214 : runCachedNode 511 130945 Adaptive147Third140Node214 = false := by
  decide +kernel

#print axioms adaptive147Third140Proof214

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third140Proof38 : runCachedNode 511 130945 Adaptive147Third140Node38 = false := by
  decide +kernel

#print axioms adaptive147Third140Proof38

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third140Proof152 : runCachedNode 511 130945 Adaptive147Third140Node152 = false := by
  decide +kernel

#print axioms adaptive147Third140Proof152

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third140Proof182 : runCachedNode 511 130945 Adaptive147Third140Node182 = false := by
  decide +kernel

#print axioms adaptive147Third140Proof182

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third140Proof243 : runCachedNode 511 130945 Adaptive147Third140Node243 = false := by
  decide +kernel

#print axioms adaptive147Third140Proof243

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third140Proof24 : runCachedNode 511 130945 Adaptive147Third140Node24 = false := by
  decide +kernel

#print axioms adaptive147Third140Proof24

end NineSeparatedSubsetSums
