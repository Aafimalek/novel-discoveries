import NineSeparatedSubsetSums.Adaptive147Third143State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third143Proof263 : runCachedNode 511 131344 Adaptive147Third143Node263 = false := by
  decide +kernel

#print axioms adaptive147Third143Proof263

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third143Proof543 : runCachedNode 511 131344 Adaptive147Third143Node543 = false := by
  decide +kernel

#print axioms adaptive147Third143Proof543

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third143Proof83 : runCachedNode 511 131344 Adaptive147Third143Node83 = false := by
  decide +kernel

#print axioms adaptive147Third143Proof83

end NineSeparatedSubsetSums
