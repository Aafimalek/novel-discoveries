import NineSeparatedSubsetSums.Adaptive147Third144State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof198 : runCachedNode 511 131483 Adaptive147Third144Node198 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof198

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof197 : runCachedNode 511 131483 Adaptive147Third144Node197 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof197

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof705 : runCachedNode 511 131483 Adaptive147Third144Node705 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof705

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof104 : runCachedNode 511 131483 Adaptive147Third144Node104 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof104

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof78 : runCachedNode 511 131483 Adaptive147Third144Node78 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof78

end NineSeparatedSubsetSums
