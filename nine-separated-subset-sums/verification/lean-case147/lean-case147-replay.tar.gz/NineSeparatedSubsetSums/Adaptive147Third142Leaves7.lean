import NineSeparatedSubsetSums.Adaptive147Third142State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third142Proof172 : runCachedNode 511 131213 Adaptive147Third142Node172 = false := by
  decide +kernel

#print axioms adaptive147Third142Proof172

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third142Proof238 : runCachedNode 511 131213 Adaptive147Third142Node238 = false := by
  decide +kernel

#print axioms adaptive147Third142Proof238

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third142Proof30 : runCachedNode 511 131213 Adaptive147Third142Node30 = false := by
  decide +kernel

#print axioms adaptive147Third142Proof30

end NineSeparatedSubsetSums
