import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive147Third123Node0 : CachedSearchNode :=
  ⟨4, 122, computeCenteredMask [148,147,123], 418, 58642⟩

end NineSeparatedSubsetSums
