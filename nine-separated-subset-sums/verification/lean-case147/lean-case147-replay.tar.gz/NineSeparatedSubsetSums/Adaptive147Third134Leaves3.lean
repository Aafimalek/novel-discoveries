import NineSeparatedSubsetSums.Adaptive147Third134State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third134Proof19 : runCachedNode 511 130034 Adaptive147Third134Node19 = false := by
  decide +kernel

#print axioms adaptive147Third134Proof19

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third134Proof17 : runCachedNode 511 130034 Adaptive147Third134Node17 = false := by
  decide +kernel

#print axioms adaptive147Third134Proof17

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third134Proof38 : runCachedNode 511 130034 Adaptive147Third134Node38 = false := by
  decide +kernel

#print axioms adaptive147Third134Proof38

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third134Proof28 : runCachedNode 511 130034 Adaptive147Third134Node28 = false := by
  decide +kernel

#print axioms adaptive147Third134Proof28

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third134Proof27 : runCachedNode 511 130034 Adaptive147Third134Node27 = false := by
  decide +kernel

#print axioms adaptive147Third134Proof27

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third134Proof25 : runCachedNode 511 130034 Adaptive147Third134Node25 = false := by
  decide +kernel

#print axioms adaptive147Third134Proof25

end NineSeparatedSubsetSums
