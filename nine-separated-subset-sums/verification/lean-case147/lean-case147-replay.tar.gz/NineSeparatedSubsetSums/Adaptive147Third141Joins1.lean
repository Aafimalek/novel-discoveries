import NineSeparatedSubsetSums.Adaptive147Third141State
import NineSeparatedSubsetSums.Adaptive147Third141Leaves35
import NineSeparatedSubsetSums.Adaptive147Third141Leaves34
import NineSeparatedSubsetSums.Adaptive147Third141Leaves33
import NineSeparatedSubsetSums.Adaptive147Third141Leaves32
import NineSeparatedSubsetSums.Adaptive147Third141Leaves31
import NineSeparatedSubsetSums.Adaptive147Third141Leaves22
import NineSeparatedSubsetSums.Adaptive147Third141Leaves30
import NineSeparatedSubsetSums.Adaptive147Third141Leaves12
import NineSeparatedSubsetSums.Adaptive147Third141Leaves28
import NineSeparatedSubsetSums.Adaptive147Third141Leaves29
import NineSeparatedSubsetSums.Adaptive147Third141Leaves27
import NineSeparatedSubsetSums.Adaptive147Third141Leaves24
import NineSeparatedSubsetSums.Adaptive147Third141Leaves21
import NineSeparatedSubsetSums.Adaptive147Third141Leaves19
import NineSeparatedSubsetSums.Adaptive147Third141Leaves7
import NineSeparatedSubsetSums.Adaptive147Third141Leaves11
import NineSeparatedSubsetSums.Adaptive147Third141Joins0
import NineSeparatedSubsetSums.Adaptive147Third141Leaves14
import NineSeparatedSubsetSums.Adaptive147Third141Leaves26
import NineSeparatedSubsetSums.Adaptive147Third141Leaves17
import NineSeparatedSubsetSums.Adaptive147Third141Leaves10
import NineSeparatedSubsetSums.Adaptive147Third141Leaves5
import NineSeparatedSubsetSums.Adaptive147Third141Leaves3
import NineSeparatedSubsetSums.Adaptive147Third141Leaves9
import NineSeparatedSubsetSums.Adaptive147Third141Leaves0
import NineSeparatedSubsetSums.Adaptive147Third141Leaves18
import NineSeparatedSubsetSums.Adaptive147Third141Leaves6
import NineSeparatedSubsetSums.Adaptive147Third141Leaves13
import NineSeparatedSubsetSums.Adaptive147Third141Leaves8

namespace NineSeparatedSubsetSums

theorem adaptive147Third141Proof232 : runCachedNode 511 131086 Adaptive147Third141Node232 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 131086 Adaptive147Third141Node232 = [101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 133, 134, 135, 136] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive147Third141Proof233
  · exact adaptive147Third141Proof234
  · exact adaptive147Third141Proof235
  · exact adaptive147Third141Proof236
  · exact adaptive147Third141Proof237
  · exact adaptive147Third141Proof238
  · exact adaptive147Third141Proof239
  · exact adaptive147Third141Proof240
  · exact adaptive147Third141Proof241
  · exact adaptive147Third141Proof242
  · exact adaptive147Third141Proof243
  · exact adaptive147Third141Proof244
  · exact adaptive147Third141Proof245
  · exact adaptive147Third141Proof246
  · exact adaptive147Third141Proof247
  · exact adaptive147Third141Proof248
  · exact adaptive147Third141Proof249
  · exact adaptive147Third141Proof250
  · exact adaptive147Third141Proof251
  · exact adaptive147Third141Proof252
  · exact adaptive147Third141Proof253
  · exact adaptive147Third141Proof254
  · exact adaptive147Third141Proof255
  · exact adaptive147Third141Proof256
  · exact adaptive147Third141Proof257
  · exact adaptive147Third141Proof258
  · exact adaptive147Third141Proof259
  · exact adaptive147Third141Proof260
  · exact adaptive147Third141Proof261
  · exact adaptive147Third141Proof262
  · exact adaptive147Third141Proof263
  · exact adaptive147Third141Proof264
  · exact adaptive147Third141Proof265
  · exact adaptive147Third141Proof303

#print axioms adaptive147Third141Proof232

theorem adaptive147Third141Proof304 : runCachedNode 511 131086 Adaptive147Third141Node304 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 131086 Adaptive147Third141Node304 = [101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 134, 135, 136, 137] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive147Third141Proof305
  · exact adaptive147Third141Proof306
  · exact adaptive147Third141Proof307
  · exact adaptive147Third141Proof308
  · exact adaptive147Third141Proof309
  · exact adaptive147Third141Proof310
  · exact adaptive147Third141Proof311
  · exact adaptive147Third141Proof312
  · exact adaptive147Third141Proof313
  · exact adaptive147Third141Proof314
  · exact adaptive147Third141Proof315
  · exact adaptive147Third141Proof316
  · exact adaptive147Third141Proof317
  · exact adaptive147Third141Proof318
  · exact adaptive147Third141Proof319
  · exact adaptive147Third141Proof320
  · exact adaptive147Third141Proof321
  · exact adaptive147Third141Proof322
  · exact adaptive147Third141Proof323
  · exact adaptive147Third141Proof324
  · exact adaptive147Third141Proof325
  · exact adaptive147Third141Proof326
  · exact adaptive147Third141Proof327
  · exact adaptive147Third141Proof328
  · exact adaptive147Third141Proof329
  · exact adaptive147Third141Proof330
  · exact adaptive147Third141Proof331
  · exact adaptive147Third141Proof332
  · exact adaptive147Third141Proof333
  · exact adaptive147Third141Proof334
  · exact adaptive147Third141Proof335
  · exact adaptive147Third141Proof336
  · exact adaptive147Third141Proof337
  · exact adaptive147Third141Proof338
  · exact adaptive147Third141Proof339

#print axioms adaptive147Third141Proof304

theorem adaptive147Third141Proof0 : runCachedNode 511 131086 Adaptive147Third141Node0 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 131086 Adaptive147Third141Node0 = [109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 132, 133, 134, 135, 136, 137, 138, 139] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive147Third141Proof1
  · exact adaptive147Third141Proof2
  · exact adaptive147Third141Proof3
  · exact adaptive147Third141Proof4
  · exact adaptive147Third141Proof5
  · exact adaptive147Third141Proof6
  · exact adaptive147Third141Proof7
  · exact adaptive147Third141Proof8
  · exact adaptive147Third141Proof9
  · exact adaptive147Third141Proof10
  · exact adaptive147Third141Proof11
  · exact adaptive147Third141Proof12
  · exact adaptive147Third141Proof13
  · exact adaptive147Third141Proof14
  · exact adaptive147Third141Proof15
  · exact adaptive147Third141Proof16
  · exact adaptive147Third141Proof17
  · exact adaptive147Third141Proof18
  · exact adaptive147Third141Proof19
  · exact adaptive147Third141Proof20
  · exact adaptive147Third141Proof21
  · exact adaptive147Third141Proof22
  · exact adaptive147Third141Proof23
  · exact adaptive147Third141Proof49
  · exact adaptive147Third141Proof76
  · exact adaptive147Third141Proof105
  · exact adaptive147Third141Proof135
  · exact adaptive147Third141Proof166
  · exact adaptive147Third141Proof198
  · exact adaptive147Third141Proof232
  · exact adaptive147Third141Proof304

#print axioms adaptive147Third141Proof0

end NineSeparatedSubsetSums
