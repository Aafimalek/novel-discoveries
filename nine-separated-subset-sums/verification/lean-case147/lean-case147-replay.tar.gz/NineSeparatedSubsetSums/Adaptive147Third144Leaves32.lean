import NineSeparatedSubsetSums.Adaptive147Third144State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof230 : runCachedNode 511 131483 Adaptive147Third144Node230 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof230

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof740 : runCachedNode 511 131483 Adaptive147Third144Node740 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof740

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof134 : runCachedNode 511 131483 Adaptive147Third144Node134 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof134

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof617 : runCachedNode 511 131483 Adaptive147Third144Node617 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof617

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof71 : runCachedNode 511 131483 Adaptive147Third144Node71 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof71

end NineSeparatedSubsetSums
