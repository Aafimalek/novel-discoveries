import NineSeparatedSubsetSums.Adaptive147Third138State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third138Proof234 : runCachedNode 511 130657 Adaptive147Third138Node234 = false := by
  decide +kernel

#print axioms adaptive147Third138Proof234

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third138Proof173 : runCachedNode 511 130657 Adaptive147Third138Node173 = false := by
  decide +kernel

#print axioms adaptive147Third138Proof173

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third138Proof15 : runCachedNode 511 130657 Adaptive147Third138Node15 = false := by
  decide +kernel

#print axioms adaptive147Third138Proof15

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third138Proof3 : runCachedNode 511 130657 Adaptive147Third138Node3 = false := by
  decide +kernel

#print axioms adaptive147Third138Proof3

end NineSeparatedSubsetSums
