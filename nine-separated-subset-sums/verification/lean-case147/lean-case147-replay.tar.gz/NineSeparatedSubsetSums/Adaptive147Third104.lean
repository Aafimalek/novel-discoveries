import NineSeparatedSubsetSums.Adaptive147Third104Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint147Checked

namespace NineSeparatedSubsetSums


theorem adaptive147Third104 : NoDescendingTailAfterThird 147 104 :=
  noDescendingThirdTail_of_cached 147 104 112835 (fun t ht nd => max148_second147_fourPoint_moment_bound (104::t) (by simp [ht]) nd) adaptive147Third104Proof0

#print axioms adaptive147Third104

end NineSeparatedSubsetSums
