import NineSeparatedSubsetSums.Adaptive147Third135State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third135Proof19 : runCachedNode 511 130219 Adaptive147Third135Node19 = false := by
  decide +kernel

#print axioms adaptive147Third135Proof19

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third135Proof76 : runCachedNode 511 130219 Adaptive147Third135Node76 = false := by
  decide +kernel

#print axioms adaptive147Third135Proof76

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third135Proof39 : runCachedNode 511 130219 Adaptive147Third135Node39 = false := by
  decide +kernel

#print axioms adaptive147Third135Proof39

end NineSeparatedSubsetSums
