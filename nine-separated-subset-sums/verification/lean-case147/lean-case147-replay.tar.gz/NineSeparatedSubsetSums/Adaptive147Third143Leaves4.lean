import NineSeparatedSubsetSums.Adaptive147Third143State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third143Proof268 : runCachedNode 511 131344 Adaptive147Third143Node268 = false := by
  decide +kernel

#print axioms adaptive147Third143Proof268

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third143Proof48 : runCachedNode 511 131344 Adaptive147Third143Node48 = false := by
  decide +kernel

#print axioms adaptive147Third143Proof48

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third143Proof3 : runCachedNode 511 131344 Adaptive147Third143Node3 = false := by
  decide +kernel

#print axioms adaptive147Third143Proof3

end NineSeparatedSubsetSums
