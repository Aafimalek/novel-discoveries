import NineSeparatedSubsetSums.Adaptive147Third142State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third142Proof17 : runCachedNode 511 131213 Adaptive147Third142Node17 = false := by
  decide +kernel

#print axioms adaptive147Third142Proof17

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third142Proof280 : runCachedNode 511 131213 Adaptive147Third142Node280 = false := by
  decide +kernel

#print axioms adaptive147Third142Proof280

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third142Proof385 : runCachedNode 511 131213 Adaptive147Third142Node385 = false := by
  decide +kernel

#print axioms adaptive147Third142Proof385

end NineSeparatedSubsetSums
