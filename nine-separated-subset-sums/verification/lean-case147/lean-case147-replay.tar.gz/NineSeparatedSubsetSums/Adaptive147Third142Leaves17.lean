import NineSeparatedSubsetSums.Adaptive147Third142State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third142Proof389 : runCachedNode 511 131213 Adaptive147Third142Node389 = false := by
  decide +kernel

#print axioms adaptive147Third142Proof389

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third142Proof140 : runCachedNode 511 131213 Adaptive147Third142Node140 = false := by
  decide +kernel

#print axioms adaptive147Third142Proof140

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third142Proof378 : runCachedNode 511 131213 Adaptive147Third142Node378 = false := by
  decide +kernel

#print axioms adaptive147Third142Proof378

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third142Proof176 : runCachedNode 511 131213 Adaptive147Third142Node176 = false := by
  decide +kernel

#print axioms adaptive147Third142Proof176

end NineSeparatedSubsetSums
