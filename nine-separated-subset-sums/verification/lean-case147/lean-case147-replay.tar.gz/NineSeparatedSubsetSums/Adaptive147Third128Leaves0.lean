import NineSeparatedSubsetSums.Adaptive147Third128State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third128Proof17 : runCachedNode 511 128781 Adaptive147Third128Node17 = false := by
  decide +kernel

#print axioms adaptive147Third128Proof17

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third128Proof16 : runCachedNode 511 128781 Adaptive147Third128Node16 = false := by
  decide +kernel

#print axioms adaptive147Third128Proof16

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third128Proof15 : runCachedNode 511 128781 Adaptive147Third128Node15 = false := by
  decide +kernel

#print axioms adaptive147Third128Proof15

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third128Proof14 : runCachedNode 511 128781 Adaptive147Third128Node14 = false := by
  decide +kernel

#print axioms adaptive147Third128Proof14

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third128Proof4 : runCachedNode 511 128781 Adaptive147Third128Node4 = false := by
  decide +kernel

#print axioms adaptive147Third128Proof4

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third128Proof3 : runCachedNode 511 128781 Adaptive147Third128Node3 = false := by
  decide +kernel

#print axioms adaptive147Third128Proof3

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third128Proof2 : runCachedNode 511 128781 Adaptive147Third128Node2 = false := by
  decide +kernel

#print axioms adaptive147Third128Proof2

end NineSeparatedSubsetSums
