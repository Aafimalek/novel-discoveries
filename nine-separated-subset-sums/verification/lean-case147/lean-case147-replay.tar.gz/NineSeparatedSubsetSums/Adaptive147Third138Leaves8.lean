import NineSeparatedSubsetSums.Adaptive147Third138State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third138Proof117 : runCachedNode 511 130657 Adaptive147Third138Node117 = false := by
  decide +kernel

#print axioms adaptive147Third138Proof117

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third138Proof147 : runCachedNode 511 130657 Adaptive147Third138Node147 = false := by
  decide +kernel

#print axioms adaptive147Third138Proof147

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third138Proof176 : runCachedNode 511 130657 Adaptive147Third138Node176 = false := by
  decide +kernel

#print axioms adaptive147Third138Proof176

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third138Proof231 : runCachedNode 511 130657 Adaptive147Third138Node231 = false := by
  decide +kernel

#print axioms adaptive147Third138Proof231

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third138Proof98 : runCachedNode 511 130657 Adaptive147Third138Node98 = false := by
  decide +kernel

#print axioms adaptive147Third138Proof98

end NineSeparatedSubsetSums
