import NineSeparatedSubsetSums.Adaptive147Third137State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third137Proof17 : runCachedNode 511 130518 Adaptive147Third137Node17 = false := by
  decide +kernel

#print axioms adaptive147Third137Proof17

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third137Proof182 : runCachedNode 511 130518 Adaptive147Third137Node182 = false := by
  decide +kernel

#print axioms adaptive147Third137Proof182

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third137Proof146 : runCachedNode 511 130518 Adaptive147Third137Node146 = false := by
  decide +kernel

#print axioms adaptive147Third137Proof146

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third137Proof73 : runCachedNode 511 130518 Adaptive147Third137Node73 = false := by
  decide +kernel

#print axioms adaptive147Third137Proof73

end NineSeparatedSubsetSums
