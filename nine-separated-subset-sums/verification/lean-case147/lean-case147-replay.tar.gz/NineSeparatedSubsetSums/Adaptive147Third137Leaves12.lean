import NineSeparatedSubsetSums.Adaptive147Third137State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third137Proof143 : runCachedNode 511 130518 Adaptive147Third137Node143 = false := by
  decide +kernel

#print axioms adaptive147Third137Proof143

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third137Proof62 : runCachedNode 511 130518 Adaptive147Third137Node62 = false := by
  decide +kernel

#print axioms adaptive147Third137Proof62

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third137Proof116 : runCachedNode 511 130518 Adaptive147Third137Node116 = false := by
  decide +kernel

#print axioms adaptive147Third137Proof116

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third137Proof89 : runCachedNode 511 130518 Adaptive147Third137Node89 = false := by
  decide +kernel

#print axioms adaptive147Third137Proof89

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third137Proof37 : runCachedNode 511 130518 Adaptive147Third137Node37 = false := by
  decide +kernel

#print axioms adaptive147Third137Proof37

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third137Proof64 : runCachedNode 511 130518 Adaptive147Third137Node64 = false := by
  decide +kernel

#print axioms adaptive147Third137Proof64

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third137Proof171 : runCachedNode 511 130518 Adaptive147Third137Node171 = false := by
  decide +kernel

#print axioms adaptive147Third137Proof171

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third137Proof172 : runCachedNode 511 130518 Adaptive147Third137Node172 = false := by
  decide +kernel

#print axioms adaptive147Third137Proof172

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third137Proof115 : runCachedNode 511 130518 Adaptive147Third137Node115 = false := by
  decide +kernel

#print axioms adaptive147Third137Proof115

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third137Proof38 : runCachedNode 511 130518 Adaptive147Third137Node38 = false := by
  decide +kernel

#print axioms adaptive147Third137Proof38

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third137Proof88 : runCachedNode 511 130518 Adaptive147Third137Node88 = false := by
  decide +kernel

#print axioms adaptive147Third137Proof88

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third137Proof170 : runCachedNode 511 130518 Adaptive147Third137Node170 = false := by
  decide +kernel

#print axioms adaptive147Third137Proof170

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third137Proof8 : runCachedNode 511 130518 Adaptive147Third137Node8 = false := by
  decide +kernel

#print axioms adaptive147Third137Proof8

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third137Proof142 : runCachedNode 511 130518 Adaptive147Third137Node142 = false := by
  decide +kernel

#print axioms adaptive147Third137Proof142

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third137Proof61 : runCachedNode 511 130518 Adaptive147Third137Node61 = false := by
  decide +kernel

#print axioms adaptive147Third137Proof61

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third137Proof63 : runCachedNode 511 130518 Adaptive147Third137Node63 = false := by
  decide +kernel

#print axioms adaptive147Third137Proof63

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third137Proof36 : runCachedNode 511 130518 Adaptive147Third137Node36 = false := by
  decide +kernel

#print axioms adaptive147Third137Proof36

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third137Proof169 : runCachedNode 511 130518 Adaptive147Third137Node169 = false := by
  decide +kernel

#print axioms adaptive147Third137Proof169

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third137Proof85 : runCachedNode 511 130518 Adaptive147Third137Node85 = false := by
  decide +kernel

#print axioms adaptive147Third137Proof85

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third137Proof86 : runCachedNode 511 130518 Adaptive147Third137Node86 = false := by
  decide +kernel

#print axioms adaptive147Third137Proof86

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third137Proof90 : runCachedNode 511 130518 Adaptive147Third137Node90 = false := by
  decide +kernel

#print axioms adaptive147Third137Proof90

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third137Proof168 : runCachedNode 511 130518 Adaptive147Third137Node168 = false := by
  decide +kernel

#print axioms adaptive147Third137Proof168

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third137Proof112 : runCachedNode 511 130518 Adaptive147Third137Node112 = false := by
  decide +kernel

#print axioms adaptive147Third137Proof112

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third137Proof7 : runCachedNode 511 130518 Adaptive147Third137Node7 = false := by
  decide +kernel

#print axioms adaptive147Third137Proof7

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third137Proof87 : runCachedNode 511 130518 Adaptive147Third137Node87 = false := by
  decide +kernel

#print axioms adaptive147Third137Proof87

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third137Proof107 : runCachedNode 511 130518 Adaptive147Third137Node107 = false := by
  decide +kernel

#print axioms adaptive147Third137Proof107

end NineSeparatedSubsetSums
