import NineSeparatedSubsetSums.Adaptive147Third141State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third141Proof264 : runCachedNode 511 131086 Adaptive147Third141Node264 = false := by
  decide +kernel

#print axioms adaptive147Third141Proof264

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third141Proof18 : runCachedNode 511 131086 Adaptive147Third141Node18 = false := by
  decide +kernel

#print axioms adaptive147Third141Proof18

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third141Proof32 : runCachedNode 511 131086 Adaptive147Third141Node32 = false := by
  decide +kernel

#print axioms adaptive147Third141Proof32

end NineSeparatedSubsetSums
