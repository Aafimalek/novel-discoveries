import NineSeparatedSubsetSums.Adaptive147Third140State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third140Proof48 : runCachedNode 511 130945 Adaptive147Third140Node48 = false := by
  decide +kernel

#print axioms adaptive147Third140Proof48

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third140Proof224 : runCachedNode 511 130945 Adaptive147Third140Node224 = false := by
  decide +kernel

#print axioms adaptive147Third140Proof224

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third140Proof70 : runCachedNode 511 130945 Adaptive147Third140Node70 = false := by
  decide +kernel

#print axioms adaptive147Third140Proof70

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third140Proof193 : runCachedNode 511 130945 Adaptive147Third140Node193 = false := by
  decide +kernel

#print axioms adaptive147Third140Proof193

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third140Proof192 : runCachedNode 511 130945 Adaptive147Third140Node192 = false := by
  decide +kernel

#print axioms adaptive147Third140Proof192

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third140Proof33 : runCachedNode 511 130945 Adaptive147Third140Node33 = false := by
  decide +kernel

#print axioms adaptive147Third140Proof33

end NineSeparatedSubsetSums
