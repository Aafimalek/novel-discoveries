import NineSeparatedSubsetSums.Adaptive147Third139State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third139Proof154 : runCachedNode 511 130807 Adaptive147Third139Node154 = false := by
  decide +kernel

#print axioms adaptive147Third139Proof154

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third139Proof183 : runCachedNode 511 130807 Adaptive147Third139Node183 = false := by
  decide +kernel

#print axioms adaptive147Third139Proof183

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third139Proof43 : runCachedNode 511 130807 Adaptive147Third139Node43 = false := by
  decide +kernel

#print axioms adaptive147Third139Proof43

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third139Proof3 : runCachedNode 511 130807 Adaptive147Third139Node3 = false := by
  decide +kernel

#print axioms adaptive147Third139Proof3

end NineSeparatedSubsetSums
