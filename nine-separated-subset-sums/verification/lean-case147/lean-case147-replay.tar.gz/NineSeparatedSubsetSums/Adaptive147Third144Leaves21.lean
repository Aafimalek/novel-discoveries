import NineSeparatedSubsetSums.Adaptive147Third144State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof17 : runCachedNode 511 131483 Adaptive147Third144Node17 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof17

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof268 : runCachedNode 511 131483 Adaptive147Third144Node268 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof268

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof264 : runCachedNode 511 131483 Adaptive147Third144Node264 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof264

end NineSeparatedSubsetSums
