import NineSeparatedSubsetSums.Adaptive147Third116State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third116Proof13 : runCachedNode 511 112835 Adaptive147Third116Node13 = false := by
  decide +kernel

#print axioms adaptive147Third116Proof13

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third116Proof12 : runCachedNode 511 112835 Adaptive147Third116Node12 = false := by
  decide +kernel

#print axioms adaptive147Third116Proof12

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third116Proof11 : runCachedNode 511 112835 Adaptive147Third116Node11 = false := by
  decide +kernel

#print axioms adaptive147Third116Proof11

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third116Proof10 : runCachedNode 511 112835 Adaptive147Third116Node10 = false := by
  decide +kernel

#print axioms adaptive147Third116Proof10

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third116Proof9 : runCachedNode 511 112835 Adaptive147Third116Node9 = false := by
  decide +kernel

#print axioms adaptive147Third116Proof9

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third116Proof8 : runCachedNode 511 112835 Adaptive147Third116Node8 = false := by
  decide +kernel

#print axioms adaptive147Third116Proof8

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third116Proof7 : runCachedNode 511 112835 Adaptive147Third116Node7 = false := by
  decide +kernel

#print axioms adaptive147Third116Proof7

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third116Proof6 : runCachedNode 511 112835 Adaptive147Third116Node6 = false := by
  decide +kernel

#print axioms adaptive147Third116Proof6

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third116Proof5 : runCachedNode 511 112835 Adaptive147Third116Node5 = false := by
  decide +kernel

#print axioms adaptive147Third116Proof5

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third116Proof3 : runCachedNode 511 112835 Adaptive147Third116Node3 = false := by
  decide +kernel

#print axioms adaptive147Third116Proof3

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third116Proof2 : runCachedNode 511 112835 Adaptive147Third116Node2 = false := by
  decide +kernel

#print axioms adaptive147Third116Proof2

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third116Proof1 : runCachedNode 511 112835 Adaptive147Third116Node1 = false := by
  decide +kernel

#print axioms adaptive147Third116Proof1

end NineSeparatedSubsetSums
