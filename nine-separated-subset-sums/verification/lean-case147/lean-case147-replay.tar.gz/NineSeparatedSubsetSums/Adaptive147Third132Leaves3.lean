import NineSeparatedSubsetSums.Adaptive147Third132State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third132Proof16 : runCachedNode 511 129667 Adaptive147Third132Node16 = false := by
  decide +kernel

#print axioms adaptive147Third132Proof16

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third132Proof15 : runCachedNode 511 129667 Adaptive147Third132Node15 = false := by
  decide +kernel

#print axioms adaptive147Third132Proof15

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third132Proof14 : runCachedNode 511 129667 Adaptive147Third132Node14 = false := by
  decide +kernel

#print axioms adaptive147Third132Proof14

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third132Proof12 : runCachedNode 511 129667 Adaptive147Third132Node12 = false := by
  decide +kernel

#print axioms adaptive147Third132Proof12

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third132Proof11 : runCachedNode 511 129667 Adaptive147Third132Node11 = false := by
  decide +kernel

#print axioms adaptive147Third132Proof11

end NineSeparatedSubsetSums
