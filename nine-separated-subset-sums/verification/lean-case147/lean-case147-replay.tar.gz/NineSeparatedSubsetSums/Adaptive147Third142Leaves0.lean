import NineSeparatedSubsetSums.Adaptive147Third142State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third142Proof355 : runCachedNode 511 131213 Adaptive147Third142Node355 = false := by
  decide +kernel

#print axioms adaptive147Third142Proof355

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third142Proof61 : runCachedNode 511 131213 Adaptive147Third142Node61 = false := by
  decide +kernel

#print axioms adaptive147Third142Proof61

end NineSeparatedSubsetSums
