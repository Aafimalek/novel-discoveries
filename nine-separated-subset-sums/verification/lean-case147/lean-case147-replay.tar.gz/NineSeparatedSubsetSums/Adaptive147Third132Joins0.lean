import NineSeparatedSubsetSums.Adaptive147Third132State
import NineSeparatedSubsetSums.Adaptive147Third132Leaves0
import NineSeparatedSubsetSums.Adaptive147Third132Leaves2
import NineSeparatedSubsetSums.Adaptive147Third132Leaves1
import NineSeparatedSubsetSums.Adaptive147Third132Leaves4
import NineSeparatedSubsetSums.Adaptive147Third132Leaves3

namespace NineSeparatedSubsetSums

theorem adaptive147Third132Proof0 : runCachedNode 511 129667 Adaptive147Third132Node0 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 129667 Adaptive147Third132Node0 = [110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive147Third132Proof1
  · exact adaptive147Third132Proof2
  · exact adaptive147Third132Proof3
  · exact adaptive147Third132Proof4
  · exact adaptive147Third132Proof5
  · exact adaptive147Third132Proof6
  · exact adaptive147Third132Proof7
  · exact adaptive147Third132Proof8
  · exact adaptive147Third132Proof9
  · exact adaptive147Third132Proof10
  · exact adaptive147Third132Proof11
  · exact adaptive147Third132Proof12
  · exact adaptive147Third132Proof13
  · exact adaptive147Third132Proof14
  · exact adaptive147Third132Proof15
  · exact adaptive147Third132Proof16
  · exact adaptive147Third132Proof17
  · exact adaptive147Third132Proof18
  · exact adaptive147Third132Proof19
  · exact adaptive147Third132Proof20
  · exact adaptive147Third132Proof21

#print axioms adaptive147Third132Proof0

end NineSeparatedSubsetSums
