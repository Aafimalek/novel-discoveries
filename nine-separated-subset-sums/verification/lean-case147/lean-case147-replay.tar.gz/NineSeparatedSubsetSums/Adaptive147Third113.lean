import NineSeparatedSubsetSums.Adaptive147Third113Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint147Checked

namespace NineSeparatedSubsetSums


theorem adaptive147Third113 : NoDescendingTailAfterThird 147 113 :=
  noDescendingThirdTail_of_cached 147 113 112835 (fun t ht nd => max148_second147_fourPoint_moment_bound (113::t) (by simp [ht]) nd) adaptive147Third113Proof0

#print axioms adaptive147Third113

end NineSeparatedSubsetSums
