import NineSeparatedSubsetSums.Adaptive147Third144State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof20 : runCachedNode 511 131483 Adaptive147Third144Node20 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof20

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof739 : runCachedNode 511 131483 Adaptive147Third144Node739 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof739

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof4 : runCachedNode 511 131483 Adaptive147Third144Node4 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof4

end NineSeparatedSubsetSums
