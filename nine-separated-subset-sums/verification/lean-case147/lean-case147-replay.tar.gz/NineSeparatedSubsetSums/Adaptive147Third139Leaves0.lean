import NineSeparatedSubsetSums.Adaptive147Third139State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third139Proof21 : runCachedNode 511 130807 Adaptive147Third139Node21 = false := by
  decide +kernel

#print axioms adaptive147Third139Proof21

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third139Proof70 : runCachedNode 511 130807 Adaptive147Third139Node70 = false := by
  decide +kernel

#print axioms adaptive147Third139Proof70

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third139Proof76 : runCachedNode 511 130807 Adaptive147Third139Node76 = false := by
  decide +kernel

#print axioms adaptive147Third139Proof76

end NineSeparatedSubsetSums
