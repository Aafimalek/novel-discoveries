import NineSeparatedSubsetSums.Adaptive147Third143State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third143Proof231 : runCachedNode 511 131344 Adaptive147Third143Node231 = false := by
  decide +kernel

#print axioms adaptive147Third143Proof231

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third143Proof636 : runCachedNode 511 131344 Adaptive147Third143Node636 = false := by
  decide +kernel

#print axioms adaptive147Third143Proof636

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third143Proof53 : runCachedNode 511 131344 Adaptive147Third143Node53 = false := by
  decide +kernel

#print axioms adaptive147Third143Proof53

end NineSeparatedSubsetSums
