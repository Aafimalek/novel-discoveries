import NineSeparatedSubsetSums.Adaptive147Third141State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third141Proof21 : runCachedNode 511 131086 Adaptive147Third141Node21 = false := by
  decide +kernel

#print axioms adaptive147Third141Proof21

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third141Proof163 : runCachedNode 511 131086 Adaptive147Third141Node163 = false := by
  decide +kernel

#print axioms adaptive147Third141Proof163

end NineSeparatedSubsetSums
