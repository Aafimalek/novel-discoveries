import NineSeparatedSubsetSums.Adaptive147Third144State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof728 : runCachedNode 511 131483 Adaptive147Third144Node728 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof728

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof788 : runCachedNode 511 131483 Adaptive147Third144Node788 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof788

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof497 : runCachedNode 511 131483 Adaptive147Third144Node497 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof497

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof831 : runCachedNode 511 131483 Adaptive147Third144Node831 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof831

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof326 : runCachedNode 511 131483 Adaptive147Third144Node326 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof326

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof259 : runCachedNode 511 131483 Adaptive147Third144Node259 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof259

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof373 : runCachedNode 511 131483 Adaptive147Third144Node373 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof373

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof520 : runCachedNode 511 131483 Adaptive147Third144Node520 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof520

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof97 : runCachedNode 511 131483 Adaptive147Third144Node97 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof97

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof410 : runCachedNode 511 131483 Adaptive147Third144Node410 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof410

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof700 : runCachedNode 511 131483 Adaptive147Third144Node700 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof700

end NineSeparatedSubsetSums
