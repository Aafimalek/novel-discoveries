import NineSeparatedSubsetSums.Adaptive147Third140State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third140Proof195 : runCachedNode 511 130945 Adaptive147Third140Node195 = false := by
  decide +kernel

#print axioms adaptive147Third140Proof195

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third140Proof18 : runCachedNode 511 130945 Adaptive147Third140Node18 = false := by
  decide +kernel

#print axioms adaptive147Third140Proof18

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third140Proof79 : runCachedNode 511 130945 Adaptive147Third140Node79 = false := by
  decide +kernel

#print axioms adaptive147Third140Proof79

end NineSeparatedSubsetSums
