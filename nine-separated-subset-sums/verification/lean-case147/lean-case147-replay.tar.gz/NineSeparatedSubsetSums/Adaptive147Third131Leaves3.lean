import NineSeparatedSubsetSums.Adaptive147Third131State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third131Proof11 : runCachedNode 511 129432 Adaptive147Third131Node11 = false := by
  decide +kernel

#print axioms adaptive147Third131Proof11

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third131Proof10 : runCachedNode 511 129432 Adaptive147Third131Node10 = false := by
  decide +kernel

#print axioms adaptive147Third131Proof10

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third131Proof9 : runCachedNode 511 129432 Adaptive147Third131Node9 = false := by
  decide +kernel

#print axioms adaptive147Third131Proof9

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third131Proof7 : runCachedNode 511 129432 Adaptive147Third131Node7 = false := by
  decide +kernel

#print axioms adaptive147Third131Proof7

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third131Proof6 : runCachedNode 511 129432 Adaptive147Third131Node6 = false := by
  decide +kernel

#print axioms adaptive147Third131Proof6

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third131Proof5 : runCachedNode 511 129432 Adaptive147Third131Node5 = false := by
  decide +kernel

#print axioms adaptive147Third131Proof5

end NineSeparatedSubsetSums
