import NineSeparatedSubsetSums.Adaptive147Third145State
import NineSeparatedSubsetSums.Adaptive147Third145Leaves30
import NineSeparatedSubsetSums.Adaptive147Third145Leaves33
import NineSeparatedSubsetSums.Adaptive147Third145Leaves60
import NineSeparatedSubsetSums.Adaptive147Third145Leaves21
import NineSeparatedSubsetSums.Adaptive147Third145Leaves59
import NineSeparatedSubsetSums.Adaptive147Third145Leaves58
import NineSeparatedSubsetSums.Adaptive147Third145Leaves57
import NineSeparatedSubsetSums.Adaptive147Third145Leaves17
import NineSeparatedSubsetSums.Adaptive147Third145Leaves56
import NineSeparatedSubsetSums.Adaptive147Third145Leaves55
import NineSeparatedSubsetSums.Adaptive147Third145Leaves54
import NineSeparatedSubsetSums.Adaptive147Third145Leaves15
import NineSeparatedSubsetSums.Adaptive147Third145Leaves23
import NineSeparatedSubsetSums.Adaptive147Third145Leaves48
import NineSeparatedSubsetSums.Adaptive147Third145Leaves47
import NineSeparatedSubsetSums.Adaptive147Third145Leaves46
import NineSeparatedSubsetSums.Adaptive147Third145Leaves45
import NineSeparatedSubsetSums.Adaptive147Third145Leaves43
import NineSeparatedSubsetSums.Adaptive147Third145Leaves41
import NineSeparatedSubsetSums.Adaptive147Third145Leaves35
import NineSeparatedSubsetSums.Adaptive147Third145Leaves61
import NineSeparatedSubsetSums.Adaptive147Third145Leaves7
import NineSeparatedSubsetSums.Adaptive147Third145Leaves28
import NineSeparatedSubsetSums.Adaptive147Third145Leaves53
import NineSeparatedSubsetSums.Adaptive147Third145Leaves51
import NineSeparatedSubsetSums.Adaptive147Third145Leaves38
import NineSeparatedSubsetSums.Adaptive147Third145Leaves32
import NineSeparatedSubsetSums.Adaptive147Third145Leaves18
import NineSeparatedSubsetSums.Adaptive147Third145Leaves52
import NineSeparatedSubsetSums.Adaptive147Third145Leaves29
import NineSeparatedSubsetSums.Adaptive147Third145Leaves20
import NineSeparatedSubsetSums.Adaptive147Third145Leaves34
import NineSeparatedSubsetSums.Adaptive147Third145Leaves49
import NineSeparatedSubsetSums.Adaptive147Third145Leaves44
import NineSeparatedSubsetSums.Adaptive147Third145Leaves36
import NineSeparatedSubsetSums.Adaptive147Third145Leaves42
import NineSeparatedSubsetSums.Adaptive147Third145Leaves39
import NineSeparatedSubsetSums.Adaptive147Third145Leaves25
import NineSeparatedSubsetSums.Adaptive147Third145Leaves27
import NineSeparatedSubsetSums.Adaptive147Third145Leaves19
import NineSeparatedSubsetSums.Adaptive147Third145Leaves50
import NineSeparatedSubsetSums.Adaptive147Third145Leaves37
import NineSeparatedSubsetSums.Adaptive147Third145Leaves11
import NineSeparatedSubsetSums.Adaptive147Third145Leaves0
import NineSeparatedSubsetSums.Adaptive147Third145Leaves31
import NineSeparatedSubsetSums.Adaptive147Third145Leaves22
import NineSeparatedSubsetSums.Adaptive147Third145Leaves13
import NineSeparatedSubsetSums.Adaptive147Third145Leaves2
import NineSeparatedSubsetSums.Adaptive147Third145Leaves6
import NineSeparatedSubsetSums.Adaptive147Third145Leaves10
import NineSeparatedSubsetSums.Adaptive147Third145Leaves5
import NineSeparatedSubsetSums.Adaptive147Third145Leaves9
import NineSeparatedSubsetSums.Adaptive147Third145Leaves16
import NineSeparatedSubsetSums.Adaptive147Third145Leaves14

namespace NineSeparatedSubsetSums

theorem adaptive147Third145Proof24 : runCachedNode 511 131618 Adaptive147Third145Node24 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 131618 Adaptive147Third145Node24 = [102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive147Third145Proof25
  · exact adaptive147Third145Proof26
  · exact adaptive147Third145Proof27
  · exact adaptive147Third145Proof28
  · exact adaptive147Third145Proof29
  · exact adaptive147Third145Proof30
  · exact adaptive147Third145Proof31
  · exact adaptive147Third145Proof32
  · exact adaptive147Third145Proof33
  · exact adaptive147Third145Proof34
  · exact adaptive147Third145Proof35
  · exact adaptive147Third145Proof36
  · exact adaptive147Third145Proof37
  · exact adaptive147Third145Proof38
  · exact adaptive147Third145Proof39
  · exact adaptive147Third145Proof40
  · exact adaptive147Third145Proof41
  · exact adaptive147Third145Proof42
  · exact adaptive147Third145Proof43
  · exact adaptive147Third145Proof44
  · exact adaptive147Third145Proof45
  · exact adaptive147Third145Proof46
  · exact adaptive147Third145Proof47
  · exact adaptive147Third145Proof48
  · exact adaptive147Third145Proof49
  · exact adaptive147Third145Proof50
  · exact adaptive147Third145Proof51

#print axioms adaptive147Third145Proof24

theorem adaptive147Third145Proof52 : runCachedNode 511 131618 Adaptive147Third145Node52 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 131618 Adaptive147Third145Node52 = [102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive147Third145Proof53
  · exact adaptive147Third145Proof54
  · exact adaptive147Third145Proof55
  · exact adaptive147Third145Proof56
  · exact adaptive147Third145Proof57
  · exact adaptive147Third145Proof58
  · exact adaptive147Third145Proof59
  · exact adaptive147Third145Proof60
  · exact adaptive147Third145Proof61
  · exact adaptive147Third145Proof62
  · exact adaptive147Third145Proof63
  · exact adaptive147Third145Proof64
  · exact adaptive147Third145Proof65
  · exact adaptive147Third145Proof66
  · exact adaptive147Third145Proof67
  · exact adaptive147Third145Proof68
  · exact adaptive147Third145Proof69
  · exact adaptive147Third145Proof70
  · exact adaptive147Third145Proof71
  · exact adaptive147Third145Proof72
  · exact adaptive147Third145Proof73
  · exact adaptive147Third145Proof74
  · exact adaptive147Third145Proof75
  · exact adaptive147Third145Proof76
  · exact adaptive147Third145Proof77
  · exact adaptive147Third145Proof78
  · exact adaptive147Third145Proof79
  · exact adaptive147Third145Proof80

#print axioms adaptive147Third145Proof52

theorem adaptive147Third145Proof81 : runCachedNode 511 131618 Adaptive147Third145Node81 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 131618 Adaptive147Third145Node81 = [102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive147Third145Proof82
  · exact adaptive147Third145Proof83
  · exact adaptive147Third145Proof84
  · exact adaptive147Third145Proof85
  · exact adaptive147Third145Proof86
  · exact adaptive147Third145Proof87
  · exact adaptive147Third145Proof88
  · exact adaptive147Third145Proof89
  · exact adaptive147Third145Proof90
  · exact adaptive147Third145Proof91
  · exact adaptive147Third145Proof92
  · exact adaptive147Third145Proof93
  · exact adaptive147Third145Proof94
  · exact adaptive147Third145Proof95
  · exact adaptive147Third145Proof96
  · exact adaptive147Third145Proof97
  · exact adaptive147Third145Proof98
  · exact adaptive147Third145Proof99
  · exact adaptive147Third145Proof100
  · exact adaptive147Third145Proof101
  · exact adaptive147Third145Proof102
  · exact adaptive147Third145Proof103
  · exact adaptive147Third145Proof104
  · exact adaptive147Third145Proof105
  · exact adaptive147Third145Proof106
  · exact adaptive147Third145Proof107
  · exact adaptive147Third145Proof108
  · exact adaptive147Third145Proof109
  · exact adaptive147Third145Proof110

#print axioms adaptive147Third145Proof81

theorem adaptive147Third145Proof111 : runCachedNode 511 131618 Adaptive147Third145Node111 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 131618 Adaptive147Third145Node111 = [101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive147Third145Proof112
  · exact adaptive147Third145Proof113
  · exact adaptive147Third145Proof114
  · exact adaptive147Third145Proof115
  · exact adaptive147Third145Proof116
  · exact adaptive147Third145Proof117
  · exact adaptive147Third145Proof118
  · exact adaptive147Third145Proof119
  · exact adaptive147Third145Proof120
  · exact adaptive147Third145Proof121
  · exact adaptive147Third145Proof122
  · exact adaptive147Third145Proof123
  · exact adaptive147Third145Proof124
  · exact adaptive147Third145Proof125
  · exact adaptive147Third145Proof126
  · exact adaptive147Third145Proof127
  · exact adaptive147Third145Proof128
  · exact adaptive147Third145Proof129
  · exact adaptive147Third145Proof130
  · exact adaptive147Third145Proof131
  · exact adaptive147Third145Proof132
  · exact adaptive147Third145Proof133
  · exact adaptive147Third145Proof134
  · exact adaptive147Third145Proof135
  · exact adaptive147Third145Proof136
  · exact adaptive147Third145Proof137
  · exact adaptive147Third145Proof138
  · exact adaptive147Third145Proof139
  · exact adaptive147Third145Proof140
  · exact adaptive147Third145Proof141
  · exact adaptive147Third145Proof142

#print axioms adaptive147Third145Proof111

theorem adaptive147Third145Proof143 : runCachedNode 511 131618 Adaptive147Third145Node143 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 131618 Adaptive147Third145Node143 = [101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 132] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive147Third145Proof144
  · exact adaptive147Third145Proof145
  · exact adaptive147Third145Proof146
  · exact adaptive147Third145Proof147
  · exact adaptive147Third145Proof148
  · exact adaptive147Third145Proof149
  · exact adaptive147Third145Proof150
  · exact adaptive147Third145Proof151
  · exact adaptive147Third145Proof152
  · exact adaptive147Third145Proof153
  · exact adaptive147Third145Proof154
  · exact adaptive147Third145Proof155
  · exact adaptive147Third145Proof156
  · exact adaptive147Third145Proof157
  · exact adaptive147Third145Proof158
  · exact adaptive147Third145Proof159
  · exact adaptive147Third145Proof160
  · exact adaptive147Third145Proof161
  · exact adaptive147Third145Proof162
  · exact adaptive147Third145Proof163
  · exact adaptive147Third145Proof164
  · exact adaptive147Third145Proof165
  · exact adaptive147Third145Proof166
  · exact adaptive147Third145Proof167
  · exact adaptive147Third145Proof168
  · exact adaptive147Third145Proof169
  · exact adaptive147Third145Proof170
  · exact adaptive147Third145Proof171
  · exact adaptive147Third145Proof172
  · exact adaptive147Third145Proof173
  · exact adaptive147Third145Proof174
  · exact adaptive147Third145Proof175

#print axioms adaptive147Third145Proof143

theorem adaptive147Third145Proof176 : runCachedNode 511 131618 Adaptive147Third145Node176 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 131618 Adaptive147Third145Node176 = [101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 132, 133] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive147Third145Proof177
  · exact adaptive147Third145Proof178
  · exact adaptive147Third145Proof179
  · exact adaptive147Third145Proof180
  · exact adaptive147Third145Proof181
  · exact adaptive147Third145Proof182
  · exact adaptive147Third145Proof183
  · exact adaptive147Third145Proof184
  · exact adaptive147Third145Proof185
  · exact adaptive147Third145Proof186
  · exact adaptive147Third145Proof187
  · exact adaptive147Third145Proof188
  · exact adaptive147Third145Proof189
  · exact adaptive147Third145Proof190
  · exact adaptive147Third145Proof191
  · exact adaptive147Third145Proof192
  · exact adaptive147Third145Proof193
  · exact adaptive147Third145Proof194
  · exact adaptive147Third145Proof195
  · exact adaptive147Third145Proof196
  · exact adaptive147Third145Proof197
  · exact adaptive147Third145Proof198
  · exact adaptive147Third145Proof199
  · exact adaptive147Third145Proof200
  · exact adaptive147Third145Proof201
  · exact adaptive147Third145Proof202
  · exact adaptive147Third145Proof203
  · exact adaptive147Third145Proof204
  · exact adaptive147Third145Proof205
  · exact adaptive147Third145Proof206
  · exact adaptive147Third145Proof207
  · exact adaptive147Third145Proof208
  · exact adaptive147Third145Proof209

#print axioms adaptive147Third145Proof176

theorem adaptive147Third145Proof210 : runCachedNode 511 131618 Adaptive147Third145Node210 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 131618 Adaptive147Third145Node210 = [101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 132, 133, 134] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive147Third145Proof211
  · exact adaptive147Third145Proof212
  · exact adaptive147Third145Proof213
  · exact adaptive147Third145Proof214
  · exact adaptive147Third145Proof215
  · exact adaptive147Third145Proof216
  · exact adaptive147Third145Proof217
  · exact adaptive147Third145Proof218
  · exact adaptive147Third145Proof219
  · exact adaptive147Third145Proof220
  · exact adaptive147Third145Proof221
  · exact adaptive147Third145Proof222
  · exact adaptive147Third145Proof223
  · exact adaptive147Third145Proof224
  · exact adaptive147Third145Proof225
  · exact adaptive147Third145Proof226
  · exact adaptive147Third145Proof227
  · exact adaptive147Third145Proof228
  · exact adaptive147Third145Proof229
  · exact adaptive147Third145Proof230
  · exact adaptive147Third145Proof231
  · exact adaptive147Third145Proof232
  · exact adaptive147Third145Proof233
  · exact adaptive147Third145Proof234
  · exact adaptive147Third145Proof235
  · exact adaptive147Third145Proof236
  · exact adaptive147Third145Proof237
  · exact adaptive147Third145Proof238
  · exact adaptive147Third145Proof239
  · exact adaptive147Third145Proof240
  · exact adaptive147Third145Proof241
  · exact adaptive147Third145Proof242
  · exact adaptive147Third145Proof243
  · exact adaptive147Third145Proof244

#print axioms adaptive147Third145Proof210

theorem adaptive147Third145Proof245 : runCachedNode 511 131618 Adaptive147Third145Node245 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 131618 Adaptive147Third145Node245 = [100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 132, 133, 134, 135] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive147Third145Proof246
  · exact adaptive147Third145Proof247
  · exact adaptive147Third145Proof248
  · exact adaptive147Third145Proof249
  · exact adaptive147Third145Proof250
  · exact adaptive147Third145Proof251
  · exact adaptive147Third145Proof252
  · exact adaptive147Third145Proof253
  · exact adaptive147Third145Proof254
  · exact adaptive147Third145Proof255
  · exact adaptive147Third145Proof256
  · exact adaptive147Third145Proof257
  · exact adaptive147Third145Proof258
  · exact adaptive147Third145Proof259
  · exact adaptive147Third145Proof260
  · exact adaptive147Third145Proof261
  · exact adaptive147Third145Proof262
  · exact adaptive147Third145Proof263
  · exact adaptive147Third145Proof264
  · exact adaptive147Third145Proof265
  · exact adaptive147Third145Proof266
  · exact adaptive147Third145Proof267
  · exact adaptive147Third145Proof268
  · exact adaptive147Third145Proof269
  · exact adaptive147Third145Proof270
  · exact adaptive147Third145Proof271
  · exact adaptive147Third145Proof272
  · exact adaptive147Third145Proof273
  · exact adaptive147Third145Proof274
  · exact adaptive147Third145Proof275
  · exact adaptive147Third145Proof276
  · exact adaptive147Third145Proof277
  · exact adaptive147Third145Proof278
  · exact adaptive147Third145Proof279
  · exact adaptive147Third145Proof280
  · exact adaptive147Third145Proof281

#print axioms adaptive147Third145Proof245

end NineSeparatedSubsetSums
