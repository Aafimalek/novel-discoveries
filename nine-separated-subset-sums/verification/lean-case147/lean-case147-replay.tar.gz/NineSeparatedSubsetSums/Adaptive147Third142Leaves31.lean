import NineSeparatedSubsetSums.Adaptive147Third142State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third142Proof47 : runCachedNode 511 131213 Adaptive147Third142Node47 = false := by
  decide +kernel

#print axioms adaptive147Third142Proof47

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third142Proof162 : runCachedNode 511 131213 Adaptive147Third142Node162 = false := by
  decide +kernel

#print axioms adaptive147Third142Proof162

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third142Proof353 : runCachedNode 511 131213 Adaptive147Third142Node353 = false := by
  decide +kernel

#print axioms adaptive147Third142Proof353

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third142Proof475 : runCachedNode 511 131213 Adaptive147Third142Node475 = false := by
  decide +kernel

#print axioms adaptive147Third142Proof475

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third142Proof104 : runCachedNode 511 131213 Adaptive147Third142Node104 = false := by
  decide +kernel

#print axioms adaptive147Third142Proof104

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third142Proof49 : runCachedNode 511 131213 Adaptive147Third142Node49 = false := by
  decide +kernel

#print axioms adaptive147Third142Proof49

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third142Proof231 : runCachedNode 511 131213 Adaptive147Third142Node231 = false := by
  decide +kernel

#print axioms adaptive147Third142Proof231

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third142Proof306 : runCachedNode 511 131213 Adaptive147Third142Node306 = false := by
  decide +kernel

#print axioms adaptive147Third142Proof306

end NineSeparatedSubsetSums
