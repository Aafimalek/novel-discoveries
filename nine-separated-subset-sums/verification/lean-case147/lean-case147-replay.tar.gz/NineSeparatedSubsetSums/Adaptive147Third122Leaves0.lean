import NineSeparatedSubsetSums.Adaptive147Third122State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third122Proof0 : runCachedNode 511 127172 Adaptive147Third122Node0 = false := by
  decide +kernel

#print axioms adaptive147Third122Proof0

end NineSeparatedSubsetSums
