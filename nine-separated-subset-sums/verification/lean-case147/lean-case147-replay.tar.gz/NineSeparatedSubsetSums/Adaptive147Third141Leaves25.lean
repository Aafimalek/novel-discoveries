import NineSeparatedSubsetSums.Adaptive147Third141State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third141Proof124 : runCachedNode 511 131086 Adaptive147Third141Node124 = false := by
  decide +kernel

#print axioms adaptive147Third141Proof124

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third141Proof301 : runCachedNode 511 131086 Adaptive147Third141Node301 = false := by
  decide +kernel

#print axioms adaptive147Third141Proof301

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third141Proof47 : runCachedNode 511 131086 Adaptive147Third141Node47 = false := by
  decide +kernel

#print axioms adaptive147Third141Proof47

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third141Proof192 : runCachedNode 511 131086 Adaptive147Third141Node192 = false := by
  decide +kernel

#print axioms adaptive147Third141Proof192

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third141Proof188 : runCachedNode 511 131086 Adaptive147Third141Node188 = false := by
  decide +kernel

#print axioms adaptive147Third141Proof188

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third141Proof99 : runCachedNode 511 131086 Adaptive147Third141Node99 = false := by
  decide +kernel

#print axioms adaptive147Third141Proof99

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third141Proof48 : runCachedNode 511 131086 Adaptive147Third141Node48 = false := by
  decide +kernel

#print axioms adaptive147Third141Proof48

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third141Proof97 : runCachedNode 511 131086 Adaptive147Third141Node97 = false := by
  decide +kernel

#print axioms adaptive147Third141Proof97

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third141Proof169 : runCachedNode 511 131086 Adaptive147Third141Node169 = false := by
  decide +kernel

#print axioms adaptive147Third141Proof169

end NineSeparatedSubsetSums
