import NineSeparatedSubsetSums.Adaptive147Third143State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third143Proof297 : runCachedNode 511 131344 Adaptive147Third143Node297 = false := by
  decide +kernel

#print axioms adaptive147Third143Proof297

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third143Proof343 : runCachedNode 511 131344 Adaptive147Third143Node343 = false := by
  decide +kernel

#print axioms adaptive147Third143Proof343

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third143Proof384 : runCachedNode 511 131344 Adaptive147Third143Node384 = false := by
  decide +kernel

#print axioms adaptive147Third143Proof384

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third143Proof195 : runCachedNode 511 131344 Adaptive147Third143Node195 = false := by
  decide +kernel

#print axioms adaptive147Third143Proof195

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third143Proof72 : runCachedNode 511 131344 Adaptive147Third143Node72 = false := by
  decide +kernel

#print axioms adaptive147Third143Proof72

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third143Proof107 : runCachedNode 511 131344 Adaptive147Third143Node107 = false := by
  decide +kernel

#print axioms adaptive147Third143Proof107

end NineSeparatedSubsetSums
