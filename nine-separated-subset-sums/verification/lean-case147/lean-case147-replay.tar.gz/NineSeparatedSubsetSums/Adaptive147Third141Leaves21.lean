import NineSeparatedSubsetSums.Adaptive147Third141State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third141Proof160 : runCachedNode 511 131086 Adaptive147Third141Node160 = false := by
  decide +kernel

#print axioms adaptive147Third141Proof160

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third141Proof159 : runCachedNode 511 131086 Adaptive147Third141Node159 = false := by
  decide +kernel

#print axioms adaptive147Third141Proof159

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third141Proof261 : runCachedNode 511 131086 Adaptive147Third141Node261 = false := by
  decide +kernel

#print axioms adaptive147Third141Proof261

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third141Proof129 : runCachedNode 511 131086 Adaptive147Third141Node129 = false := by
  decide +kernel

#print axioms adaptive147Third141Proof129

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third141Proof126 : runCachedNode 511 131086 Adaptive147Third141Node126 = false := by
  decide +kernel

#print axioms adaptive147Third141Proof126

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third141Proof140 : runCachedNode 511 131086 Adaptive147Third141Node140 = false := by
  decide +kernel

#print axioms adaptive147Third141Proof140

end NineSeparatedSubsetSums
