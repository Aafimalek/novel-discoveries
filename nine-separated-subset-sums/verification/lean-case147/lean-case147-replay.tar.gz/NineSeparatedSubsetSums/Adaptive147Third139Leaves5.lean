import NineSeparatedSubsetSums.Adaptive147Third139State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third139Proof153 : runCachedNode 511 130807 Adaptive147Third139Node153 = false := by
  decide +kernel

#print axioms adaptive147Third139Proof153

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third139Proof19 : runCachedNode 511 130807 Adaptive147Third139Node19 = false := by
  decide +kernel

#print axioms adaptive147Third139Proof19

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third139Proof179 : runCachedNode 511 130807 Adaptive147Third139Node179 = false := by
  decide +kernel

#print axioms adaptive147Third139Proof179

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third139Proof2 : runCachedNode 511 130807 Adaptive147Third139Node2 = false := by
  decide +kernel

#print axioms adaptive147Third139Proof2

end NineSeparatedSubsetSums
