import NineSeparatedSubsetSums.Adaptive147Third134State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third134Proof18 : runCachedNode 511 130034 Adaptive147Third134Node18 = false := by
  decide +kernel

#print axioms adaptive147Third134Proof18

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third134Proof48 : runCachedNode 511 130034 Adaptive147Third134Node48 = false := by
  decide +kernel

#print axioms adaptive147Third134Proof48

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third134Proof14 : runCachedNode 511 130034 Adaptive147Third134Node14 = false := by
  decide +kernel

#print axioms adaptive147Third134Proof14

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third134Proof5 : runCachedNode 511 130034 Adaptive147Third134Node5 = false := by
  decide +kernel

#print axioms adaptive147Third134Proof5

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third134Proof29 : runCachedNode 511 130034 Adaptive147Third134Node29 = false := by
  decide +kernel

#print axioms adaptive147Third134Proof29

end NineSeparatedSubsetSums
