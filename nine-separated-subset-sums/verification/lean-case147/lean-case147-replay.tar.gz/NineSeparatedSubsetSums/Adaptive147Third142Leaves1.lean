import NineSeparatedSubsetSums.Adaptive147Third142State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third142Proof206 : runCachedNode 511 131213 Adaptive147Third142Node206 = false := by
  decide +kernel

#print axioms adaptive147Third142Proof206

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third142Proof66 : runCachedNode 511 131213 Adaptive147Third142Node66 = false := by
  decide +kernel

#print axioms adaptive147Third142Proof66

end NineSeparatedSubsetSums
