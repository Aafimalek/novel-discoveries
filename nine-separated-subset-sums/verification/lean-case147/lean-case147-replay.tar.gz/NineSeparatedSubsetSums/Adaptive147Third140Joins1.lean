import NineSeparatedSubsetSums.Adaptive147Third140State
import NineSeparatedSubsetSums.Adaptive147Third140Leaves14
import NineSeparatedSubsetSums.Adaptive147Third140Leaves19
import NineSeparatedSubsetSums.Adaptive147Third140Leaves28
import NineSeparatedSubsetSums.Adaptive147Third140Leaves27
import NineSeparatedSubsetSums.Adaptive147Third140Leaves12
import NineSeparatedSubsetSums.Adaptive147Third140Leaves26
import NineSeparatedSubsetSums.Adaptive147Third140Leaves25
import NineSeparatedSubsetSums.Adaptive147Third140Leaves23
import NineSeparatedSubsetSums.Adaptive147Third140Leaves22
import NineSeparatedSubsetSums.Adaptive147Third140Leaves20
import NineSeparatedSubsetSums.Adaptive147Third140Leaves17
import NineSeparatedSubsetSums.Adaptive147Third140Leaves16
import NineSeparatedSubsetSums.Adaptive147Third140Leaves7
import NineSeparatedSubsetSums.Adaptive147Third140Leaves9
import NineSeparatedSubsetSums.Adaptive147Third140Leaves3
import NineSeparatedSubsetSums.Adaptive147Third140Leaves1
import NineSeparatedSubsetSums.Adaptive147Third140Joins0

namespace NineSeparatedSubsetSums

theorem adaptive147Third140Proof0 : runCachedNode 511 130945 Adaptive147Third140Node0 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130945 Adaptive147Third140Node0 = [109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 132, 133, 134, 135, 136, 137, 138] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive147Third140Proof1
  · exact adaptive147Third140Proof2
  · exact adaptive147Third140Proof3
  · exact adaptive147Third140Proof4
  · exact adaptive147Third140Proof5
  · exact adaptive147Third140Proof6
  · exact adaptive147Third140Proof7
  · exact adaptive147Third140Proof8
  · exact adaptive147Third140Proof9
  · exact adaptive147Third140Proof10
  · exact adaptive147Third140Proof11
  · exact adaptive147Third140Proof12
  · exact adaptive147Third140Proof13
  · exact adaptive147Third140Proof14
  · exact adaptive147Third140Proof15
  · exact adaptive147Third140Proof16
  · exact adaptive147Third140Proof17
  · exact adaptive147Third140Proof18
  · exact adaptive147Third140Proof19
  · exact adaptive147Third140Proof20
  · exact adaptive147Third140Proof21
  · exact adaptive147Third140Proof22
  · exact adaptive147Third140Proof23
  · exact adaptive147Third140Proof49
  · exact adaptive147Third140Proof76
  · exact adaptive147Third140Proof104
  · exact adaptive147Third140Proof134
  · exact adaptive147Third140Proof165
  · exact adaptive147Third140Proof197
  · exact adaptive147Third140Proof230

#print axioms adaptive147Third140Proof0

end NineSeparatedSubsetSums
