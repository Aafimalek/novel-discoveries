import NineSeparatedSubsetSums.Adaptive147Third139State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third139Proof121 : runCachedNode 511 130807 Adaptive147Third139Node121 = false := by
  decide +kernel

#print axioms adaptive147Third139Proof121

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third139Proof67 : runCachedNode 511 130807 Adaptive147Third139Node67 = false := by
  decide +kernel

#print axioms adaptive147Third139Proof67

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third139Proof12 : runCachedNode 511 130807 Adaptive147Third139Node12 = false := by
  decide +kernel

#print axioms adaptive147Third139Proof12

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third139Proof39 : runCachedNode 511 130807 Adaptive147Third139Node39 = false := by
  decide +kernel

#print axioms adaptive147Third139Proof39

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third139Proof182 : runCachedNode 511 130807 Adaptive147Third139Node182 = false := by
  decide +kernel

#print axioms adaptive147Third139Proof182

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third139Proof122 : runCachedNode 511 130807 Adaptive147Third139Node122 = false := by
  decide +kernel

#print axioms adaptive147Third139Proof122

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third139Proof94 : runCachedNode 511 130807 Adaptive147Third139Node94 = false := by
  decide +kernel

#print axioms adaptive147Third139Proof94

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third139Proof181 : runCachedNode 511 130807 Adaptive147Third139Node181 = false := by
  decide +kernel

#print axioms adaptive147Third139Proof181

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third139Proof180 : runCachedNode 511 130807 Adaptive147Third139Node180 = false := by
  decide +kernel

#print axioms adaptive147Third139Proof180

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third139Proof62 : runCachedNode 511 130807 Adaptive147Third139Node62 = false := by
  decide +kernel

#print axioms adaptive147Third139Proof62

end NineSeparatedSubsetSums
