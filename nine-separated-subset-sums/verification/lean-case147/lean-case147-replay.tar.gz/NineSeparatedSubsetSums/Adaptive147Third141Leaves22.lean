import NineSeparatedSubsetSums.Adaptive147Third141State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third141Proof333 : runCachedNode 511 131086 Adaptive147Third141Node333 = false := by
  decide +kernel

#print axioms adaptive147Third141Proof333

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third141Proof260 : runCachedNode 511 131086 Adaptive147Third141Node260 = false := by
  decide +kernel

#print axioms adaptive147Third141Proof260

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third141Proof14 : runCachedNode 511 131086 Adaptive147Third141Node14 = false := by
  decide +kernel

#print axioms adaptive147Third141Proof14

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third141Proof330 : runCachedNode 511 131086 Adaptive147Third141Node330 = false := by
  decide +kernel

#print axioms adaptive147Third141Proof330

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third141Proof189 : runCachedNode 511 131086 Adaptive147Third141Node189 = false := by
  decide +kernel

#print axioms adaptive147Third141Proof189

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third141Proof249 : runCachedNode 511 131086 Adaptive147Third141Node249 = false := by
  decide +kernel

#print axioms adaptive147Third141Proof249

end NineSeparatedSubsetSums
