import NineSeparatedSubsetSums.Adaptive147Third120State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third120Proof0 : runCachedNode 511 126807 Adaptive147Third120Node0 = false := by
  decide +kernel

#print axioms adaptive147Third120Proof0

end NineSeparatedSubsetSums
