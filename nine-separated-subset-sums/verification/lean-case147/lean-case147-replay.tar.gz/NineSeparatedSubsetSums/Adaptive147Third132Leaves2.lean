import NineSeparatedSubsetSums.Adaptive147Third132State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third132Proof19 : runCachedNode 511 129667 Adaptive147Third132Node19 = false := by
  decide +kernel

#print axioms adaptive147Third132Proof19

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third132Proof17 : runCachedNode 511 129667 Adaptive147Third132Node17 = false := by
  decide +kernel

#print axioms adaptive147Third132Proof17

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third132Proof13 : runCachedNode 511 129667 Adaptive147Third132Node13 = false := by
  decide +kernel

#print axioms adaptive147Third132Proof13

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third132Proof5 : runCachedNode 511 129667 Adaptive147Third132Node5 = false := by
  decide +kernel

#print axioms adaptive147Third132Proof5

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third132Proof3 : runCachedNode 511 129667 Adaptive147Third132Node3 = false := by
  decide +kernel

#print axioms adaptive147Third132Proof3

end NineSeparatedSubsetSums
