import NineSeparatedSubsetSums.Adaptive147Third142State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third142Proof204 : runCachedNode 511 131213 Adaptive147Third142Node204 = false := by
  decide +kernel

#print axioms adaptive147Third142Proof204

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third142Proof105 : runCachedNode 511 131213 Adaptive147Third142Node105 = false := by
  decide +kernel

#print axioms adaptive147Third142Proof105

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third142Proof32 : runCachedNode 511 131213 Adaptive147Third142Node32 = false := by
  decide +kernel

#print axioms adaptive147Third142Proof32

end NineSeparatedSubsetSums
