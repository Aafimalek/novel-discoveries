import NineSeparatedSubsetSums.Adaptive147Third144State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof839 : runCachedNode 511 131483 Adaptive147Third144Node839 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof839

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof18 : runCachedNode 511 131483 Adaptive147Third144Node18 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof18

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof144 : runCachedNode 511 131483 Adaptive147Third144Node144 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof144

end NineSeparatedSubsetSums
