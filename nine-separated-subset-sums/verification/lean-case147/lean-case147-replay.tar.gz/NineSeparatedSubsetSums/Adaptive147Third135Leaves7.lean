import NineSeparatedSubsetSums.Adaptive147Third135State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third135Proof12 : runCachedNode 511 130219 Adaptive147Third135Node12 = false := by
  decide +kernel

#print axioms adaptive147Third135Proof12

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third135Proof46 : runCachedNode 511 130219 Adaptive147Third135Node46 = false := by
  decide +kernel

#print axioms adaptive147Third135Proof46

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third135Proof67 : runCachedNode 511 130219 Adaptive147Third135Node67 = false := by
  decide +kernel

#print axioms adaptive147Third135Proof67

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third135Proof71 : runCachedNode 511 130219 Adaptive147Third135Node71 = false := by
  decide +kernel

#print axioms adaptive147Third135Proof71

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third135Proof11 : runCachedNode 511 130219 Adaptive147Third135Node11 = false := by
  decide +kernel

#print axioms adaptive147Third135Proof11

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third135Proof69 : runCachedNode 511 130219 Adaptive147Third135Node69 = false := by
  decide +kernel

#print axioms adaptive147Third135Proof69

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third135Proof45 : runCachedNode 511 130219 Adaptive147Third135Node45 = false := by
  decide +kernel

#print axioms adaptive147Third135Proof45

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third135Proof40 : runCachedNode 511 130219 Adaptive147Third135Node40 = false := by
  decide +kernel

#print axioms adaptive147Third135Proof40

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third135Proof66 : runCachedNode 511 130219 Adaptive147Third135Node66 = false := by
  decide +kernel

#print axioms adaptive147Third135Proof66

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third135Proof44 : runCachedNode 511 130219 Adaptive147Third135Node44 = false := by
  decide +kernel

#print axioms adaptive147Third135Proof44

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third135Proof70 : runCachedNode 511 130219 Adaptive147Third135Node70 = false := by
  decide +kernel

#print axioms adaptive147Third135Proof70

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third135Proof43 : runCachedNode 511 130219 Adaptive147Third135Node43 = false := by
  decide +kernel

#print axioms adaptive147Third135Proof43

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third135Proof31 : runCachedNode 511 130219 Adaptive147Third135Node31 = false := by
  decide +kernel

#print axioms adaptive147Third135Proof31

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third135Proof50 : runCachedNode 511 130219 Adaptive147Third135Node50 = false := by
  decide +kernel

#print axioms adaptive147Third135Proof50

end NineSeparatedSubsetSums
