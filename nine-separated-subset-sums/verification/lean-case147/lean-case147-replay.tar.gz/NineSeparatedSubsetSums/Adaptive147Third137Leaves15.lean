import NineSeparatedSubsetSums.Adaptive147Third137State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third137Proof158 : runCachedNode 511 130518 Adaptive147Third137Node158 = false := by
  decide +kernel

#print axioms adaptive147Third137Proof158

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third137Proof75 : runCachedNode 511 130518 Adaptive147Third137Node75 = false := by
  decide +kernel

#print axioms adaptive147Third137Proof75

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third137Proof130 : runCachedNode 511 130518 Adaptive147Third137Node130 = false := by
  decide +kernel

#print axioms adaptive147Third137Proof130

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third137Proof46 : runCachedNode 511 130518 Adaptive147Third137Node46 = false := by
  decide +kernel

#print axioms adaptive147Third137Proof46

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third137Proof72 : runCachedNode 511 130518 Adaptive147Third137Node72 = false := by
  decide +kernel

#print axioms adaptive147Third137Proof72

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third137Proof99 : runCachedNode 511 130518 Adaptive147Third137Node99 = false := by
  decide +kernel

#print axioms adaptive147Third137Proof99

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third137Proof100 : runCachedNode 511 130518 Adaptive147Third137Node100 = false := by
  decide +kernel

#print axioms adaptive147Third137Proof100

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third137Proof101 : runCachedNode 511 130518 Adaptive147Third137Node101 = false := by
  decide +kernel

#print axioms adaptive147Third137Proof101

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third137Proof129 : runCachedNode 511 130518 Adaptive147Third137Node129 = false := by
  decide +kernel

#print axioms adaptive147Third137Proof129

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third137Proof157 : runCachedNode 511 130518 Adaptive147Third137Node157 = false := by
  decide +kernel

#print axioms adaptive147Third137Proof157

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third137Proof127 : runCachedNode 511 130518 Adaptive147Third137Node127 = false := by
  decide +kernel

#print axioms adaptive147Third137Proof127

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third137Proof128 : runCachedNode 511 130518 Adaptive147Third137Node128 = false := by
  decide +kernel

#print axioms adaptive147Third137Proof128

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third137Proof155 : runCachedNode 511 130518 Adaptive147Third137Node155 = false := by
  decide +kernel

#print axioms adaptive147Third137Proof155

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third137Proof156 : runCachedNode 511 130518 Adaptive147Third137Node156 = false := by
  decide +kernel

#print axioms adaptive147Third137Proof156

end NineSeparatedSubsetSums
