import NineSeparatedSubsetSums.Adaptive147Third138State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third138Proof144 : runCachedNode 511 130657 Adaptive147Third138Node144 = false := by
  decide +kernel

#print axioms adaptive147Third138Proof144

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third138Proof233 : runCachedNode 511 130657 Adaptive147Third138Node233 = false := by
  decide +kernel

#print axioms adaptive147Third138Proof233

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third138Proof202 : runCachedNode 511 130657 Adaptive147Third138Node202 = false := by
  decide +kernel

#print axioms adaptive147Third138Proof202

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third138Proof21 : runCachedNode 511 130657 Adaptive147Third138Node21 = false := by
  decide +kernel

#print axioms adaptive147Third138Proof21

end NineSeparatedSubsetSums
