import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive147Third127Node0 : CachedSearchNode :=
  ⟨4, 126, computeCenteredMask [148,147,127], 422, 59642⟩
def Adaptive147Third127Node1 : CachedSearchNode := cachedChild Adaptive147Third127Node0 110
def Adaptive147Third127Node2 : CachedSearchNode := cachedChild Adaptive147Third127Node0 111
def Adaptive147Third127Node3 : CachedSearchNode := cachedChild Adaptive147Third127Node0 112
def Adaptive147Third127Node4 : CachedSearchNode := cachedChild Adaptive147Third127Node0 113
def Adaptive147Third127Node5 : CachedSearchNode := cachedChild Adaptive147Third127Node0 114
def Adaptive147Third127Node6 : CachedSearchNode := cachedChild Adaptive147Third127Node0 115
def Adaptive147Third127Node7 : CachedSearchNode := cachedChild Adaptive147Third127Node0 116
def Adaptive147Third127Node8 : CachedSearchNode := cachedChild Adaptive147Third127Node0 117
def Adaptive147Third127Node9 : CachedSearchNode := cachedChild Adaptive147Third127Node0 118
def Adaptive147Third127Node10 : CachedSearchNode := cachedChild Adaptive147Third127Node0 119
def Adaptive147Third127Node11 : CachedSearchNode := cachedChild Adaptive147Third127Node0 120
def Adaptive147Third127Node12 : CachedSearchNode := cachedChild Adaptive147Third127Node0 121
def Adaptive147Third127Node13 : CachedSearchNode := cachedChild Adaptive147Third127Node0 122
def Adaptive147Third127Node14 : CachedSearchNode := cachedChild Adaptive147Third127Node0 123
def Adaptive147Third127Node15 : CachedSearchNode := cachedChild Adaptive147Third127Node0 124
def Adaptive147Third127Node16 : CachedSearchNode := cachedChild Adaptive147Third127Node0 125

end NineSeparatedSubsetSums
