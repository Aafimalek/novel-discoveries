import NineSeparatedSubsetSums.Adaptive147Third138State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third138Proof41 : runCachedNode 511 130657 Adaptive147Third138Node41 = false := by
  decide +kernel

#print axioms adaptive147Third138Proof41

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third138Proof40 : runCachedNode 511 130657 Adaptive147Third138Node40 = false := by
  decide +kernel

#print axioms adaptive147Third138Proof40

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third138Proof39 : runCachedNode 511 130657 Adaptive147Third138Node39 = false := by
  decide +kernel

#print axioms adaptive147Third138Proof39

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third138Proof200 : runCachedNode 511 130657 Adaptive147Third138Node200 = false := by
  decide +kernel

#print axioms adaptive147Third138Proof200

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third138Proof11 : runCachedNode 511 130657 Adaptive147Third138Node11 = false := by
  decide +kernel

#print axioms adaptive147Third138Proof11

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third138Proof64 : runCachedNode 511 130657 Adaptive147Third138Node64 = false := by
  decide +kernel

#print axioms adaptive147Third138Proof64

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third138Proof199 : runCachedNode 511 130657 Adaptive147Third138Node199 = false := by
  decide +kernel

#print axioms adaptive147Third138Proof199

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third138Proof113 : runCachedNode 511 130657 Adaptive147Third138Node113 = false := by
  decide +kernel

#print axioms adaptive147Third138Proof113

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third138Proof89 : runCachedNode 511 130657 Adaptive147Third138Node89 = false := by
  decide +kernel

#print axioms adaptive147Third138Proof89

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third138Proof229 : runCachedNode 511 130657 Adaptive147Third138Node229 = false := by
  decide +kernel

#print axioms adaptive147Third138Proof229

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third138Proof179 : runCachedNode 511 130657 Adaptive147Third138Node179 = false := by
  decide +kernel

#print axioms adaptive147Third138Proof179

end NineSeparatedSubsetSums
