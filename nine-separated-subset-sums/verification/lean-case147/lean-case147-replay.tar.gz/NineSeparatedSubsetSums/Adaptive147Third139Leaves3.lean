import NineSeparatedSubsetSums.Adaptive147Third139State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third139Proof20 : runCachedNode 511 130807 Adaptive147Third139Node20 = false := by
  decide +kernel

#print axioms adaptive147Third139Proof20

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third139Proof246 : runCachedNode 511 130807 Adaptive147Third139Node246 = false := by
  decide +kernel

#print axioms adaptive147Third139Proof246

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third139Proof4 : runCachedNode 511 130807 Adaptive147Third139Node4 = false := by
  decide +kernel

#print axioms adaptive147Third139Proof4

end NineSeparatedSubsetSums
