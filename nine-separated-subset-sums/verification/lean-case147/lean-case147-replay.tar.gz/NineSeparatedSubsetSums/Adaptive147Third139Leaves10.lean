import NineSeparatedSubsetSums.Adaptive147Third139State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third139Proof185 : runCachedNode 511 130807 Adaptive147Third139Node185 = false := by
  decide +kernel

#print axioms adaptive147Third139Proof185

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third139Proof186 : runCachedNode 511 130807 Adaptive147Third139Node186 = false := by
  decide +kernel

#print axioms adaptive147Third139Proof186

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third139Proof245 : runCachedNode 511 130807 Adaptive147Third139Node245 = false := by
  decide +kernel

#print axioms adaptive147Third139Proof245

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third139Proof85 : runCachedNode 511 130807 Adaptive147Third139Node85 = false := by
  decide +kernel

#print axioms adaptive147Third139Proof85

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third139Proof1 : runCachedNode 511 130807 Adaptive147Third139Node1 = false := by
  decide +kernel

#print axioms adaptive147Third139Proof1

end NineSeparatedSubsetSums
