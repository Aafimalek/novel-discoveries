import NineSeparatedSubsetSums.Adaptive147Third143State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third143Proof416 : runCachedNode 511 131344 Adaptive147Third143Node416 = false := by
  decide +kernel

#print axioms adaptive147Third143Proof416

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third143Proof589 : runCachedNode 511 131344 Adaptive147Third143Node589 = false := by
  decide +kernel

#print axioms adaptive147Third143Proof589

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third143Proof130 : runCachedNode 511 131344 Adaptive147Third143Node130 = false := by
  decide +kernel

#print axioms adaptive147Third143Proof130

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third143Proof76 : runCachedNode 511 131344 Adaptive147Third143Node76 = false := by
  decide +kernel

#print axioms adaptive147Third143Proof76

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third143Proof161 : runCachedNode 511 131344 Adaptive147Third143Node161 = false := by
  decide +kernel

#print axioms adaptive147Third143Proof161

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third143Proof221 : runCachedNode 511 131344 Adaptive147Third143Node221 = false := by
  decide +kernel

#print axioms adaptive147Third143Proof221

end NineSeparatedSubsetSums
