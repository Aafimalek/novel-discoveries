import NineSeparatedSubsetSums.Adaptive147Third144State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof534 : runCachedNode 511 131483 Adaptive147Third144Node534 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof534

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof741 : runCachedNode 511 131483 Adaptive147Third144Node741 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof741

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof734 : runCachedNode 511 131483 Adaptive147Third144Node734 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof734

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof110 : runCachedNode 511 131483 Adaptive147Third144Node110 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof110

end NineSeparatedSubsetSums
