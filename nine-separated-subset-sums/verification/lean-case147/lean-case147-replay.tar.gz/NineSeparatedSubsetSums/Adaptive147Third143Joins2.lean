import NineSeparatedSubsetSums.Adaptive147Third143State
import NineSeparatedSubsetSums.Adaptive147Third143Leaves53
import NineSeparatedSubsetSums.Adaptive147Third143Leaves52
import NineSeparatedSubsetSums.Adaptive147Third143Leaves51
import NineSeparatedSubsetSums.Adaptive147Third143Leaves50
import NineSeparatedSubsetSums.Adaptive147Third143Leaves49
import NineSeparatedSubsetSums.Adaptive147Third143Leaves48
import NineSeparatedSubsetSums.Adaptive147Third143Leaves47
import NineSeparatedSubsetSums.Adaptive147Third143Leaves46
import NineSeparatedSubsetSums.Adaptive147Third143Leaves45
import NineSeparatedSubsetSums.Adaptive147Third143Leaves43
import NineSeparatedSubsetSums.Adaptive147Third143Leaves42
import NineSeparatedSubsetSums.Adaptive147Third143Leaves41
import NineSeparatedSubsetSums.Adaptive147Third143Leaves40
import NineSeparatedSubsetSums.Adaptive147Third143Leaves39
import NineSeparatedSubsetSums.Adaptive147Third143Leaves16
import NineSeparatedSubsetSums.Adaptive147Third143Leaves38
import NineSeparatedSubsetSums.Adaptive147Third143Leaves36
import NineSeparatedSubsetSums.Adaptive147Third143Leaves33
import NineSeparatedSubsetSums.Adaptive147Third143Leaves35
import NineSeparatedSubsetSums.Adaptive147Third143Leaves34
import NineSeparatedSubsetSums.Adaptive147Third143Leaves29
import NineSeparatedSubsetSums.Adaptive147Third143Leaves23
import NineSeparatedSubsetSums.Adaptive147Third143Leaves24
import NineSeparatedSubsetSums.Adaptive147Third143Leaves25
import NineSeparatedSubsetSums.Adaptive147Third143Leaves7
import NineSeparatedSubsetSums.Adaptive147Third143Leaves18
import NineSeparatedSubsetSums.Adaptive147Third143Leaves15
import NineSeparatedSubsetSums.Adaptive147Third143Joins1
import NineSeparatedSubsetSums.Adaptive147Third143Leaves3
import NineSeparatedSubsetSums.Adaptive147Third143Leaves21
import NineSeparatedSubsetSums.Adaptive147Third143Leaves4
import NineSeparatedSubsetSums.Adaptive147Third143Leaves6
import NineSeparatedSubsetSums.Adaptive147Third143Leaves13
import NineSeparatedSubsetSums.Adaptive147Third143Leaves0
import NineSeparatedSubsetSums.Adaptive147Third143Leaves44
import NineSeparatedSubsetSums.Adaptive147Third143Leaves1
import NineSeparatedSubsetSums.Adaptive147Third143Leaves32
import NineSeparatedSubsetSums.Adaptive147Third143Leaves9
import NineSeparatedSubsetSums.Adaptive147Third143Leaves12
import NineSeparatedSubsetSums.Adaptive147Third143Leaves14
import NineSeparatedSubsetSums.Adaptive147Third143Joins0

namespace NineSeparatedSubsetSums

theorem adaptive147Third143Proof509 : runCachedNode 511 131344 Adaptive147Third143Node509 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 131344 Adaptive147Third143Node509 = [100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 132, 133, 134, 135, 138, 139] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive147Third143Proof510
  · exact adaptive147Third143Proof511
  · exact adaptive147Third143Proof512
  · exact adaptive147Third143Proof513
  · exact adaptive147Third143Proof514
  · exact adaptive147Third143Proof515
  · exact adaptive147Third143Proof516
  · exact adaptive147Third143Proof517
  · exact adaptive147Third143Proof518
  · exact adaptive147Third143Proof519
  · exact adaptive147Third143Proof520
  · exact adaptive147Third143Proof521
  · exact adaptive147Third143Proof522
  · exact adaptive147Third143Proof523
  · exact adaptive147Third143Proof524
  · exact adaptive147Third143Proof525
  · exact adaptive147Third143Proof526
  · exact adaptive147Third143Proof527
  · exact adaptive147Third143Proof528
  · exact adaptive147Third143Proof529
  · exact adaptive147Third143Proof530
  · exact adaptive147Third143Proof531
  · exact adaptive147Third143Proof532
  · exact adaptive147Third143Proof533
  · exact adaptive147Third143Proof534
  · exact adaptive147Third143Proof535
  · exact adaptive147Third143Proof536
  · exact adaptive147Third143Proof537
  · exact adaptive147Third143Proof538
  · exact adaptive147Third143Proof539
  · exact adaptive147Third143Proof540
  · exact adaptive147Third143Proof541
  · exact adaptive147Third143Proof542
  · exact adaptive147Third143Proof543
  · exact adaptive147Third143Proof544
  · exact adaptive147Third143Proof545
  · exact adaptive147Third143Proof546
  · exact adaptive147Third143Proof591

#print axioms adaptive147Third143Proof509

theorem adaptive147Third143Proof0 : runCachedNode 511 131344 Adaptive147Third143Node0 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 131344 Adaptive147Third143Node0 = [109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 132, 133, 134, 135, 136, 137, 138, 139, 140, 141] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive147Third143Proof1
  · exact adaptive147Third143Proof2
  · exact adaptive147Third143Proof3
  · exact adaptive147Third143Proof4
  · exact adaptive147Third143Proof5
  · exact adaptive147Third143Proof6
  · exact adaptive147Third143Proof7
  · exact adaptive147Third143Proof8
  · exact adaptive147Third143Proof9
  · exact adaptive147Third143Proof10
  · exact adaptive147Third143Proof11
  · exact adaptive147Third143Proof12
  · exact adaptive147Third143Proof13
  · exact adaptive147Third143Proof14
  · exact adaptive147Third143Proof15
  · exact adaptive147Third143Proof16
  · exact adaptive147Third143Proof17
  · exact adaptive147Third143Proof18
  · exact adaptive147Third143Proof19
  · exact adaptive147Third143Proof20
  · exact adaptive147Third143Proof21
  · exact adaptive147Third143Proof22
  · exact adaptive147Third143Proof23
  · exact adaptive147Third143Proof49
  · exact adaptive147Third143Proof77
  · exact adaptive147Third143Proof106
  · exact adaptive147Third143Proof136
  · exact adaptive147Third143Proof167
  · exact adaptive147Third143Proof200
  · exact adaptive147Third143Proof234
  · exact adaptive147Third143Proof269
  · exact adaptive147Third143Proof386
  · exact adaptive147Third143Proof509

#print axioms adaptive147Third143Proof0

end NineSeparatedSubsetSums
