import NineSeparatedSubsetSums.Adaptive147Third138State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third138Proof175 : runCachedNode 511 130657 Adaptive147Third138Node175 = false := by
  decide +kernel

#print axioms adaptive147Third138Proof175

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third138Proof203 : runCachedNode 511 130657 Adaptive147Third138Node203 = false := by
  decide +kernel

#print axioms adaptive147Third138Proof203

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third138Proof172 : runCachedNode 511 130657 Adaptive147Third138Node172 = false := by
  decide +kernel

#print axioms adaptive147Third138Proof172

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third138Proof232 : runCachedNode 511 130657 Adaptive147Third138Node232 = false := by
  decide +kernel

#print axioms adaptive147Third138Proof232

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third138Proof167 : runCachedNode 511 130657 Adaptive147Third138Node167 = false := by
  decide +kernel

#print axioms adaptive147Third138Proof167

end NineSeparatedSubsetSums
