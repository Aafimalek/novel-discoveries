import NineSeparatedSubsetSums.Adaptive147Third144State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof836 : runCachedNode 511 131483 Adaptive147Third144Node836 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof836

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof531 : runCachedNode 511 131483 Adaptive147Third144Node531 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof531

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof15 : runCachedNode 511 131483 Adaptive147Third144Node15 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof15

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof298 : runCachedNode 511 131483 Adaptive147Third144Node298 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof298

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof205 : runCachedNode 511 131483 Adaptive147Third144Node205 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof205

end NineSeparatedSubsetSums
