import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive147Third109Node0 : CachedSearchNode :=
  ⟨4, 108, computeCenteredMask [148,147,109], 404, 55394⟩

end NineSeparatedSubsetSums
