import NineSeparatedSubsetSums.Adaptive147Third134State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third134Proof43 : runCachedNode 511 130034 Adaptive147Third134Node43 = false := by
  decide +kernel

#print axioms adaptive147Third134Proof43

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third134Proof45 : runCachedNode 511 130034 Adaptive147Third134Node45 = false := by
  decide +kernel

#print axioms adaptive147Third134Proof45

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third134Proof10 : runCachedNode 511 130034 Adaptive147Third134Node10 = false := by
  decide +kernel

#print axioms adaptive147Third134Proof10

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third134Proof9 : runCachedNode 511 130034 Adaptive147Third134Node9 = false := by
  decide +kernel

#print axioms adaptive147Third134Proof9

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third134Proof40 : runCachedNode 511 130034 Adaptive147Third134Node40 = false := by
  decide +kernel

#print axioms adaptive147Third134Proof40

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third134Proof42 : runCachedNode 511 130034 Adaptive147Third134Node42 = false := by
  decide +kernel

#print axioms adaptive147Third134Proof42

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third134Proof8 : runCachedNode 511 130034 Adaptive147Third134Node8 = false := by
  decide +kernel

#print axioms adaptive147Third134Proof8

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third134Proof41 : runCachedNode 511 130034 Adaptive147Third134Node41 = false := by
  decide +kernel

#print axioms adaptive147Third134Proof41

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third134Proof7 : runCachedNode 511 130034 Adaptive147Third134Node7 = false := by
  decide +kernel

#print axioms adaptive147Third134Proof7

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third134Proof36 : runCachedNode 511 130034 Adaptive147Third134Node36 = false := by
  decide +kernel

#print axioms adaptive147Third134Proof36

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third134Proof34 : runCachedNode 511 130034 Adaptive147Third134Node34 = false := by
  decide +kernel

#print axioms adaptive147Third134Proof34

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third134Proof31 : runCachedNode 511 130034 Adaptive147Third134Node31 = false := by
  decide +kernel

#print axioms adaptive147Third134Proof31

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third134Proof32 : runCachedNode 511 130034 Adaptive147Third134Node32 = false := by
  decide +kernel

#print axioms adaptive147Third134Proof32

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third134Proof33 : runCachedNode 511 130034 Adaptive147Third134Node33 = false := by
  decide +kernel

#print axioms adaptive147Third134Proof33

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third134Proof30 : runCachedNode 511 130034 Adaptive147Third134Node30 = false := by
  decide +kernel

#print axioms adaptive147Third134Proof30

end NineSeparatedSubsetSums
