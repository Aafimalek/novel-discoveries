import NineSeparatedSubsetSums.Adaptive147Third143State
import NineSeparatedSubsetSums.Adaptive147Third143Leaves52
import NineSeparatedSubsetSums.Adaptive147Third143Leaves51
import NineSeparatedSubsetSums.Adaptive147Third143Leaves50
import NineSeparatedSubsetSums.Adaptive147Third143Leaves49
import NineSeparatedSubsetSums.Adaptive147Third143Leaves48
import NineSeparatedSubsetSums.Adaptive147Third143Leaves47
import NineSeparatedSubsetSums.Adaptive147Third143Leaves45
import NineSeparatedSubsetSums.Adaptive147Third143Leaves46
import NineSeparatedSubsetSums.Adaptive147Third143Leaves44
import NineSeparatedSubsetSums.Adaptive147Third143Leaves20
import NineSeparatedSubsetSums.Adaptive147Third143Leaves38
import NineSeparatedSubsetSums.Adaptive147Third143Leaves41
import NineSeparatedSubsetSums.Adaptive147Third143Leaves36
import NineSeparatedSubsetSums.Adaptive147Third143Leaves39
import NineSeparatedSubsetSums.Adaptive147Third143Leaves37
import NineSeparatedSubsetSums.Adaptive147Third143Leaves29
import NineSeparatedSubsetSums.Adaptive147Third143Leaves27
import NineSeparatedSubsetSums.Adaptive147Third143Leaves43
import NineSeparatedSubsetSums.Adaptive147Third143Leaves42
import NineSeparatedSubsetSums.Adaptive147Third143Leaves40
import NineSeparatedSubsetSums.Adaptive147Third143Leaves35
import NineSeparatedSubsetSums.Adaptive147Third143Leaves23
import NineSeparatedSubsetSums.Adaptive147Third143Leaves34
import NineSeparatedSubsetSums.Adaptive147Third143Leaves32
import NineSeparatedSubsetSums.Adaptive147Third143Leaves26
import NineSeparatedSubsetSums.Adaptive147Third143Leaves19
import NineSeparatedSubsetSums.Adaptive147Third143Leaves24
import NineSeparatedSubsetSums.Adaptive147Third143Leaves15
import NineSeparatedSubsetSums.Adaptive147Third143Leaves5
import NineSeparatedSubsetSums.Adaptive147Third143Leaves3
import NineSeparatedSubsetSums.Adaptive147Third143Leaves13
import NineSeparatedSubsetSums.Adaptive147Third143Leaves8
import NineSeparatedSubsetSums.Adaptive147Third143Leaves53
import NineSeparatedSubsetSums.Adaptive147Third143Leaves33
import NineSeparatedSubsetSums.Adaptive147Third143Leaves22
import NineSeparatedSubsetSums.Adaptive147Third143Leaves11
import NineSeparatedSubsetSums.Adaptive147Third143Leaves31
import NineSeparatedSubsetSums.Adaptive147Third143Leaves28
import NineSeparatedSubsetSums.Adaptive147Third143Leaves30
import NineSeparatedSubsetSums.Adaptive147Third143Leaves14
import NineSeparatedSubsetSums.Adaptive147Third143Leaves16
import NineSeparatedSubsetSums.Adaptive147Third143Leaves17
import NineSeparatedSubsetSums.Adaptive147Third143Leaves54
import NineSeparatedSubsetSums.Adaptive147Third143Leaves25
import NineSeparatedSubsetSums.Adaptive147Third143Leaves21
import NineSeparatedSubsetSums.Adaptive147Third143Leaves10

namespace NineSeparatedSubsetSums

theorem adaptive147Third143Proof303 : runCachedNode 511 131344 Adaptive147Third143Node303 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 131344 Adaptive147Third143Node303 = [88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 124, 125, 126, 129, 130] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive147Third143Proof304
  · exact adaptive147Third143Proof305
  · exact adaptive147Third143Proof306
  · exact adaptive147Third143Proof307
  · exact adaptive147Third143Proof308
  · exact adaptive147Third143Proof309
  · exact adaptive147Third143Proof310
  · exact adaptive147Third143Proof311
  · exact adaptive147Third143Proof312
  · exact adaptive147Third143Proof313
  · exact adaptive147Third143Proof314
  · exact adaptive147Third143Proof315
  · exact adaptive147Third143Proof316
  · exact adaptive147Third143Proof317
  · exact adaptive147Third143Proof318
  · exact adaptive147Third143Proof319
  · exact adaptive147Third143Proof320
  · exact adaptive147Third143Proof321
  · exact adaptive147Third143Proof322
  · exact adaptive147Third143Proof323
  · exact adaptive147Third143Proof324
  · exact adaptive147Third143Proof325
  · exact adaptive147Third143Proof326
  · exact adaptive147Third143Proof327
  · exact adaptive147Third143Proof328
  · exact adaptive147Third143Proof329
  · exact adaptive147Third143Proof330
  · exact adaptive147Third143Proof331
  · exact adaptive147Third143Proof332
  · exact adaptive147Third143Proof333
  · exact adaptive147Third143Proof334
  · exact adaptive147Third143Proof335
  · exact adaptive147Third143Proof336
  · exact adaptive147Third143Proof337
  · exact adaptive147Third143Proof338
  · exact adaptive147Third143Proof339
  · exact adaptive147Third143Proof340
  · exact adaptive147Third143Proof341
  · exact adaptive147Third143Proof342
  · exact adaptive147Third143Proof343

#print axioms adaptive147Third143Proof303

theorem adaptive147Third143Proof344 : runCachedNode 511 131344 Adaptive147Third143Node344 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 131344 Adaptive147Third143Node344 = [88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 125, 126, 127, 130, 131] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive147Third143Proof345
  · exact adaptive147Third143Proof346
  · exact adaptive147Third143Proof347
  · exact adaptive147Third143Proof348
  · exact adaptive147Third143Proof349
  · exact adaptive147Third143Proof350
  · exact adaptive147Third143Proof351
  · exact adaptive147Third143Proof352
  · exact adaptive147Third143Proof353
  · exact adaptive147Third143Proof354
  · exact adaptive147Third143Proof355
  · exact adaptive147Third143Proof356
  · exact adaptive147Third143Proof357
  · exact adaptive147Third143Proof358
  · exact adaptive147Third143Proof359
  · exact adaptive147Third143Proof360
  · exact adaptive147Third143Proof361
  · exact adaptive147Third143Proof362
  · exact adaptive147Third143Proof363
  · exact adaptive147Third143Proof364
  · exact adaptive147Third143Proof365
  · exact adaptive147Third143Proof366
  · exact adaptive147Third143Proof367
  · exact adaptive147Third143Proof368
  · exact adaptive147Third143Proof369
  · exact adaptive147Third143Proof370
  · exact adaptive147Third143Proof371
  · exact adaptive147Third143Proof372
  · exact adaptive147Third143Proof373
  · exact adaptive147Third143Proof374
  · exact adaptive147Third143Proof375
  · exact adaptive147Third143Proof376
  · exact adaptive147Third143Proof377
  · exact adaptive147Third143Proof378
  · exact adaptive147Third143Proof379
  · exact adaptive147Third143Proof380
  · exact adaptive147Third143Proof381
  · exact adaptive147Third143Proof382
  · exact adaptive147Third143Proof383
  · exact adaptive147Third143Proof384
  · exact adaptive147Third143Proof385

#print axioms adaptive147Third143Proof344

theorem adaptive147Third143Proof269 : runCachedNode 511 131344 Adaptive147Third143Node269 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 131344 Adaptive147Third143Node269 = [101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 132, 133, 136, 137] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive147Third143Proof270
  · exact adaptive147Third143Proof271
  · exact adaptive147Third143Proof272
  · exact adaptive147Third143Proof273
  · exact adaptive147Third143Proof274
  · exact adaptive147Third143Proof275
  · exact adaptive147Third143Proof276
  · exact adaptive147Third143Proof277
  · exact adaptive147Third143Proof278
  · exact adaptive147Third143Proof279
  · exact adaptive147Third143Proof280
  · exact adaptive147Third143Proof281
  · exact adaptive147Third143Proof282
  · exact adaptive147Third143Proof283
  · exact adaptive147Third143Proof284
  · exact adaptive147Third143Proof285
  · exact adaptive147Third143Proof286
  · exact adaptive147Third143Proof287
  · exact adaptive147Third143Proof288
  · exact adaptive147Third143Proof289
  · exact adaptive147Third143Proof290
  · exact adaptive147Third143Proof291
  · exact adaptive147Third143Proof292
  · exact adaptive147Third143Proof293
  · exact adaptive147Third143Proof294
  · exact adaptive147Third143Proof295
  · exact adaptive147Third143Proof296
  · exact adaptive147Third143Proof297
  · exact adaptive147Third143Proof298
  · exact adaptive147Third143Proof299
  · exact adaptive147Third143Proof300
  · exact adaptive147Third143Proof301
  · exact adaptive147Third143Proof302
  · exact adaptive147Third143Proof303
  · exact adaptive147Third143Proof344

#print axioms adaptive147Third143Proof269

theorem adaptive147Third143Proof422 : runCachedNode 511 131344 Adaptive147Third143Node422 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 131344 Adaptive147Third143Node422 = [87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 126, 127, 128, 131] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive147Third143Proof423
  · exact adaptive147Third143Proof424
  · exact adaptive147Third143Proof425
  · exact adaptive147Third143Proof426
  · exact adaptive147Third143Proof427
  · exact adaptive147Third143Proof428
  · exact adaptive147Third143Proof429
  · exact adaptive147Third143Proof430
  · exact adaptive147Third143Proof431
  · exact adaptive147Third143Proof432
  · exact adaptive147Third143Proof433
  · exact adaptive147Third143Proof434
  · exact adaptive147Third143Proof435
  · exact adaptive147Third143Proof436
  · exact adaptive147Third143Proof437
  · exact adaptive147Third143Proof438
  · exact adaptive147Third143Proof439
  · exact adaptive147Third143Proof440
  · exact adaptive147Third143Proof441
  · exact adaptive147Third143Proof442
  · exact adaptive147Third143Proof443
  · exact adaptive147Third143Proof444
  · exact adaptive147Third143Proof445
  · exact adaptive147Third143Proof446
  · exact adaptive147Third143Proof447
  · exact adaptive147Third143Proof448
  · exact adaptive147Third143Proof449
  · exact adaptive147Third143Proof450
  · exact adaptive147Third143Proof451
  · exact adaptive147Third143Proof452
  · exact adaptive147Third143Proof453
  · exact adaptive147Third143Proof454
  · exact adaptive147Third143Proof455
  · exact adaptive147Third143Proof456
  · exact adaptive147Third143Proof457
  · exact adaptive147Third143Proof458
  · exact adaptive147Third143Proof459
  · exact adaptive147Third143Proof460
  · exact adaptive147Third143Proof461
  · exact adaptive147Third143Proof462
  · exact adaptive147Third143Proof463
  · exact adaptive147Third143Proof464

#print axioms adaptive147Third143Proof422

theorem adaptive147Third143Proof465 : runCachedNode 511 131344 Adaptive147Third143Node465 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 131344 Adaptive147Third143Node465 = [87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 127, 128, 129, 132] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive147Third143Proof466
  · exact adaptive147Third143Proof467
  · exact adaptive147Third143Proof468
  · exact adaptive147Third143Proof469
  · exact adaptive147Third143Proof470
  · exact adaptive147Third143Proof471
  · exact adaptive147Third143Proof472
  · exact adaptive147Third143Proof473
  · exact adaptive147Third143Proof474
  · exact adaptive147Third143Proof475
  · exact adaptive147Third143Proof476
  · exact adaptive147Third143Proof477
  · exact adaptive147Third143Proof478
  · exact adaptive147Third143Proof479
  · exact adaptive147Third143Proof480
  · exact adaptive147Third143Proof481
  · exact adaptive147Third143Proof482
  · exact adaptive147Third143Proof483
  · exact adaptive147Third143Proof484
  · exact adaptive147Third143Proof485
  · exact adaptive147Third143Proof486
  · exact adaptive147Third143Proof487
  · exact adaptive147Third143Proof488
  · exact adaptive147Third143Proof489
  · exact adaptive147Third143Proof490
  · exact adaptive147Third143Proof491
  · exact adaptive147Third143Proof492
  · exact adaptive147Third143Proof493
  · exact adaptive147Third143Proof494
  · exact adaptive147Third143Proof495
  · exact adaptive147Third143Proof496
  · exact adaptive147Third143Proof497
  · exact adaptive147Third143Proof498
  · exact adaptive147Third143Proof499
  · exact adaptive147Third143Proof500
  · exact adaptive147Third143Proof501
  · exact adaptive147Third143Proof502
  · exact adaptive147Third143Proof503
  · exact adaptive147Third143Proof504
  · exact adaptive147Third143Proof505
  · exact adaptive147Third143Proof506
  · exact adaptive147Third143Proof507
  · exact adaptive147Third143Proof508

#print axioms adaptive147Third143Proof465

theorem adaptive147Third143Proof386 : runCachedNode 511 131344 Adaptive147Third143Node386 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 131344 Adaptive147Third143Node386 = [100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 132, 133, 134, 137, 138] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive147Third143Proof387
  · exact adaptive147Third143Proof388
  · exact adaptive147Third143Proof389
  · exact adaptive147Third143Proof390
  · exact adaptive147Third143Proof391
  · exact adaptive147Third143Proof392
  · exact adaptive147Third143Proof393
  · exact adaptive147Third143Proof394
  · exact adaptive147Third143Proof395
  · exact adaptive147Third143Proof396
  · exact adaptive147Third143Proof397
  · exact adaptive147Third143Proof398
  · exact adaptive147Third143Proof399
  · exact adaptive147Third143Proof400
  · exact adaptive147Third143Proof401
  · exact adaptive147Third143Proof402
  · exact adaptive147Third143Proof403
  · exact adaptive147Third143Proof404
  · exact adaptive147Third143Proof405
  · exact adaptive147Third143Proof406
  · exact adaptive147Third143Proof407
  · exact adaptive147Third143Proof408
  · exact adaptive147Third143Proof409
  · exact adaptive147Third143Proof410
  · exact adaptive147Third143Proof411
  · exact adaptive147Third143Proof412
  · exact adaptive147Third143Proof413
  · exact adaptive147Third143Proof414
  · exact adaptive147Third143Proof415
  · exact adaptive147Third143Proof416
  · exact adaptive147Third143Proof417
  · exact adaptive147Third143Proof418
  · exact adaptive147Third143Proof419
  · exact adaptive147Third143Proof420
  · exact adaptive147Third143Proof421
  · exact adaptive147Third143Proof422
  · exact adaptive147Third143Proof465

#print axioms adaptive147Third143Proof386

theorem adaptive147Third143Proof546 : runCachedNode 511 131344 Adaptive147Third143Node546 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 131344 Adaptive147Third143Node546 = [86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 128, 129, 130] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive147Third143Proof547
  · exact adaptive147Third143Proof548
  · exact adaptive147Third143Proof549
  · exact adaptive147Third143Proof550
  · exact adaptive147Third143Proof551
  · exact adaptive147Third143Proof552
  · exact adaptive147Third143Proof553
  · exact adaptive147Third143Proof554
  · exact adaptive147Third143Proof555
  · exact adaptive147Third143Proof556
  · exact adaptive147Third143Proof557
  · exact adaptive147Third143Proof558
  · exact adaptive147Third143Proof559
  · exact adaptive147Third143Proof560
  · exact adaptive147Third143Proof561
  · exact adaptive147Third143Proof562
  · exact adaptive147Third143Proof563
  · exact adaptive147Third143Proof564
  · exact adaptive147Third143Proof565
  · exact adaptive147Third143Proof566
  · exact adaptive147Third143Proof567
  · exact adaptive147Third143Proof568
  · exact adaptive147Third143Proof569
  · exact adaptive147Third143Proof570
  · exact adaptive147Third143Proof571
  · exact adaptive147Third143Proof572
  · exact adaptive147Third143Proof573
  · exact adaptive147Third143Proof574
  · exact adaptive147Third143Proof575
  · exact adaptive147Third143Proof576
  · exact adaptive147Third143Proof577
  · exact adaptive147Third143Proof578
  · exact adaptive147Third143Proof579
  · exact adaptive147Third143Proof580
  · exact adaptive147Third143Proof581
  · exact adaptive147Third143Proof582
  · exact adaptive147Third143Proof583
  · exact adaptive147Third143Proof584
  · exact adaptive147Third143Proof585
  · exact adaptive147Third143Proof586
  · exact adaptive147Third143Proof587
  · exact adaptive147Third143Proof588
  · exact adaptive147Third143Proof589
  · exact adaptive147Third143Proof590

#print axioms adaptive147Third143Proof546

theorem adaptive147Third143Proof591 : runCachedNode 511 131344 Adaptive147Third143Node591 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 131344 Adaptive147Third143Node591 = [86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 129, 130, 131] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive147Third143Proof592
  · exact adaptive147Third143Proof593
  · exact adaptive147Third143Proof594
  · exact adaptive147Third143Proof595
  · exact adaptive147Third143Proof596
  · exact adaptive147Third143Proof597
  · exact adaptive147Third143Proof598
  · exact adaptive147Third143Proof599
  · exact adaptive147Third143Proof600
  · exact adaptive147Third143Proof601
  · exact adaptive147Third143Proof602
  · exact adaptive147Third143Proof603
  · exact adaptive147Third143Proof604
  · exact adaptive147Third143Proof605
  · exact adaptive147Third143Proof606
  · exact adaptive147Third143Proof607
  · exact adaptive147Third143Proof608
  · exact adaptive147Third143Proof609
  · exact adaptive147Third143Proof610
  · exact adaptive147Third143Proof611
  · exact adaptive147Third143Proof612
  · exact adaptive147Third143Proof613
  · exact adaptive147Third143Proof614
  · exact adaptive147Third143Proof615
  · exact adaptive147Third143Proof616
  · exact adaptive147Third143Proof617
  · exact adaptive147Third143Proof618
  · exact adaptive147Third143Proof619
  · exact adaptive147Third143Proof620
  · exact adaptive147Third143Proof621
  · exact adaptive147Third143Proof622
  · exact adaptive147Third143Proof623
  · exact adaptive147Third143Proof624
  · exact adaptive147Third143Proof625
  · exact adaptive147Third143Proof626
  · exact adaptive147Third143Proof627
  · exact adaptive147Third143Proof628
  · exact adaptive147Third143Proof629
  · exact adaptive147Third143Proof630
  · exact adaptive147Third143Proof631
  · exact adaptive147Third143Proof632
  · exact adaptive147Third143Proof633
  · exact adaptive147Third143Proof634
  · exact adaptive147Third143Proof635
  · exact adaptive147Third143Proof636

#print axioms adaptive147Third143Proof591

end NineSeparatedSubsetSums
