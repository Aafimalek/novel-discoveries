import NineSeparatedSubsetSums.Adaptive147Third135State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third135Proof16 : runCachedNode 511 130219 Adaptive147Third135Node16 = false := by
  decide +kernel

#print axioms adaptive147Third135Proof16

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third135Proof15 : runCachedNode 511 130219 Adaptive147Third135Node15 = false := by
  decide +kernel

#print axioms adaptive147Third135Proof15

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third135Proof75 : runCachedNode 511 130219 Adaptive147Third135Node75 = false := by
  decide +kernel

#print axioms adaptive147Third135Proof75

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third135Proof68 : runCachedNode 511 130219 Adaptive147Third135Node68 = false := by
  decide +kernel

#print axioms adaptive147Third135Proof68

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third135Proof29 : runCachedNode 511 130219 Adaptive147Third135Node29 = false := by
  decide +kernel

#print axioms adaptive147Third135Proof29

end NineSeparatedSubsetSums
