import NineSeparatedSubsetSums.Adaptive147Third137State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third137Proof92 : runCachedNode 511 130518 Adaptive147Third137Node92 = false := by
  decide +kernel

#print axioms adaptive147Third137Proof92

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third137Proof148 : runCachedNode 511 130518 Adaptive147Third137Node148 = false := by
  decide +kernel

#print axioms adaptive147Third137Proof148

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third137Proof94 : runCachedNode 511 130518 Adaptive147Third137Node94 = false := by
  decide +kernel

#print axioms adaptive147Third137Proof94

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third137Proof42 : runCachedNode 511 130518 Adaptive147Third137Node42 = false := by
  decide +kernel

#print axioms adaptive147Third137Proof42

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third137Proof44 : runCachedNode 511 130518 Adaptive147Third137Node44 = false := by
  decide +kernel

#print axioms adaptive147Third137Proof44

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third137Proof13 : runCachedNode 511 130518 Adaptive147Third137Node13 = false := by
  decide +kernel

#print axioms adaptive147Third137Proof13

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third137Proof79 : runCachedNode 511 130518 Adaptive147Third137Node79 = false := by
  decide +kernel

#print axioms adaptive147Third137Proof79

end NineSeparatedSubsetSums
