import NineSeparatedSubsetSums.Adaptive147Third143State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third143Proof227 : runCachedNode 511 131344 Adaptive147Third143Node227 = false := by
  decide +kernel

#print axioms adaptive147Third143Proof227

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third143Proof228 : runCachedNode 511 131344 Adaptive147Third143Node228 = false := by
  decide +kernel

#print axioms adaptive147Third143Proof228

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third143Proof464 : runCachedNode 511 131344 Adaptive147Third143Node464 = false := by
  decide +kernel

#print axioms adaptive147Third143Proof464

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third143Proof74 : runCachedNode 511 131344 Adaptive147Third143Node74 = false := by
  decide +kernel

#print axioms adaptive147Third143Proof74

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third143Proof51 : runCachedNode 511 131344 Adaptive147Third143Node51 = false := by
  decide +kernel

#print axioms adaptive147Third143Proof51

end NineSeparatedSubsetSums
