import NineSeparatedSubsetSums.Adaptive147Third105Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint147Checked

namespace NineSeparatedSubsetSums


theorem adaptive147Third105 : NoDescendingTailAfterThird 147 105 :=
  noDescendingThirdTail_of_cached 147 105 112835 (fun t ht nd => max148_second147_fourPoint_moment_bound (105::t) (by simp [ht]) nd) adaptive147Third105Proof0

#print axioms adaptive147Third105

end NineSeparatedSubsetSums
