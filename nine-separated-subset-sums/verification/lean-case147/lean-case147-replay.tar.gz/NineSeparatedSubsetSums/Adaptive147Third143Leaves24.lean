import NineSeparatedSubsetSums.Adaptive147Third143State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third143Proof229 : runCachedNode 511 131344 Adaptive147Third143Node229 = false := by
  decide +kernel

#print axioms adaptive147Third143Proof229

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third143Proof541 : runCachedNode 511 131344 Adaptive147Third143Node541 = false := by
  decide +kernel

#print axioms adaptive147Third143Proof541

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third143Proof296 : runCachedNode 511 131344 Adaptive147Third143Node296 = false := by
  decide +kernel

#print axioms adaptive147Third143Proof296

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third143Proof590 : runCachedNode 511 131344 Adaptive147Third143Node590 = false := by
  decide +kernel

#print axioms adaptive147Third143Proof590

end NineSeparatedSubsetSums
