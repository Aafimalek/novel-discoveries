import NineSeparatedSubsetSums.Adaptive147Third140State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third140Proof264 : runCachedNode 511 130945 Adaptive147Third140Node264 = false := by
  decide +kernel

#print axioms adaptive147Third140Proof264

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third140Proof225 : runCachedNode 511 130945 Adaptive147Third140Node225 = false := by
  decide +kernel

#print axioms adaptive147Third140Proof225

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third140Proof81 : runCachedNode 511 130945 Adaptive147Third140Node81 = false := by
  decide +kernel

#print axioms adaptive147Third140Proof81

end NineSeparatedSubsetSums
