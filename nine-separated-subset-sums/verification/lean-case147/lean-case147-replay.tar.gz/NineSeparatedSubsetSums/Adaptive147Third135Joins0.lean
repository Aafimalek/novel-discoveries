import NineSeparatedSubsetSums.Adaptive147Third135State
import NineSeparatedSubsetSums.Adaptive147Third135Leaves2
import NineSeparatedSubsetSums.Adaptive147Third135Leaves4
import NineSeparatedSubsetSums.Adaptive147Third135Leaves6
import NineSeparatedSubsetSums.Adaptive147Third135Leaves8
import NineSeparatedSubsetSums.Adaptive147Third135Leaves5
import NineSeparatedSubsetSums.Adaptive147Third135Leaves7
import NineSeparatedSubsetSums.Adaptive147Third135Leaves3
import NineSeparatedSubsetSums.Adaptive147Third135Leaves1
import NineSeparatedSubsetSums.Adaptive147Third135Leaves0

namespace NineSeparatedSubsetSums

theorem adaptive147Third135Proof23 : runCachedNode 511 130219 Adaptive147Third135Node23 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130219 Adaptive147Third135Node23 = [104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive147Third135Proof24
  · exact adaptive147Third135Proof25
  · exact adaptive147Third135Proof26
  · exact adaptive147Third135Proof27
  · exact adaptive147Third135Proof28
  · exact adaptive147Third135Proof29
  · exact adaptive147Third135Proof30
  · exact adaptive147Third135Proof31
  · exact adaptive147Third135Proof32
  · exact adaptive147Third135Proof33
  · exact adaptive147Third135Proof34
  · exact adaptive147Third135Proof35
  · exact adaptive147Third135Proof36
  · exact adaptive147Third135Proof37
  · exact adaptive147Third135Proof38
  · exact adaptive147Third135Proof39
  · exact adaptive147Third135Proof40
  · exact adaptive147Third135Proof41
  · exact adaptive147Third135Proof42
  · exact adaptive147Third135Proof43
  · exact adaptive147Third135Proof44
  · exact adaptive147Third135Proof45
  · exact adaptive147Third135Proof46
  · exact adaptive147Third135Proof47
  · exact adaptive147Third135Proof48

#print axioms adaptive147Third135Proof23

theorem adaptive147Third135Proof49 : runCachedNode 511 130219 Adaptive147Third135Node49 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130219 Adaptive147Third135Node49 = [103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive147Third135Proof50
  · exact adaptive147Third135Proof51
  · exact adaptive147Third135Proof52
  · exact adaptive147Third135Proof53
  · exact adaptive147Third135Proof54
  · exact adaptive147Third135Proof55
  · exact adaptive147Third135Proof56
  · exact adaptive147Third135Proof57
  · exact adaptive147Third135Proof58
  · exact adaptive147Third135Proof59
  · exact adaptive147Third135Proof60
  · exact adaptive147Third135Proof61
  · exact adaptive147Third135Proof62
  · exact adaptive147Third135Proof63
  · exact adaptive147Third135Proof64
  · exact adaptive147Third135Proof65
  · exact adaptive147Third135Proof66
  · exact adaptive147Third135Proof67
  · exact adaptive147Third135Proof68
  · exact adaptive147Third135Proof69
  · exact adaptive147Third135Proof70
  · exact adaptive147Third135Proof71
  · exact adaptive147Third135Proof72
  · exact adaptive147Third135Proof73
  · exact adaptive147Third135Proof74
  · exact adaptive147Third135Proof75
  · exact adaptive147Third135Proof76

#print axioms adaptive147Third135Proof49

theorem adaptive147Third135Proof0 : runCachedNode 511 130219 Adaptive147Third135Node0 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130219 Adaptive147Third135Node0 = [110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 132, 133] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive147Third135Proof1
  · exact adaptive147Third135Proof2
  · exact adaptive147Third135Proof3
  · exact adaptive147Third135Proof4
  · exact adaptive147Third135Proof5
  · exact adaptive147Third135Proof6
  · exact adaptive147Third135Proof7
  · exact adaptive147Third135Proof8
  · exact adaptive147Third135Proof9
  · exact adaptive147Third135Proof10
  · exact adaptive147Third135Proof11
  · exact adaptive147Third135Proof12
  · exact adaptive147Third135Proof13
  · exact adaptive147Third135Proof14
  · exact adaptive147Third135Proof15
  · exact adaptive147Third135Proof16
  · exact adaptive147Third135Proof17
  · exact adaptive147Third135Proof18
  · exact adaptive147Third135Proof19
  · exact adaptive147Third135Proof20
  · exact adaptive147Third135Proof21
  · exact adaptive147Third135Proof22
  · exact adaptive147Third135Proof23
  · exact adaptive147Third135Proof49

#print axioms adaptive147Third135Proof0

end NineSeparatedSubsetSums
