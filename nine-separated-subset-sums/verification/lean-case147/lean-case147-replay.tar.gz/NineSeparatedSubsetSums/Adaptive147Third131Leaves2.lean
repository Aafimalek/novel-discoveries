import NineSeparatedSubsetSums.Adaptive147Third131State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third131Proof17 : runCachedNode 511 129432 Adaptive147Third131Node17 = false := by
  decide +kernel

#print axioms adaptive147Third131Proof17

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third131Proof16 : runCachedNode 511 129432 Adaptive147Third131Node16 = false := by
  decide +kernel

#print axioms adaptive147Third131Proof16

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third131Proof14 : runCachedNode 511 129432 Adaptive147Third131Node14 = false := by
  decide +kernel

#print axioms adaptive147Third131Proof14

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third131Proof13 : runCachedNode 511 129432 Adaptive147Third131Node13 = false := by
  decide +kernel

#print axioms adaptive147Third131Proof13

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third131Proof8 : runCachedNode 511 129432 Adaptive147Third131Node8 = false := by
  decide +kernel

#print axioms adaptive147Third131Proof8

end NineSeparatedSubsetSums
