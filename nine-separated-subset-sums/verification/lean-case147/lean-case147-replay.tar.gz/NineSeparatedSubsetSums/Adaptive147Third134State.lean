import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive147Third134Node0 : CachedSearchNode :=
  ⟨4, 133, computeCenteredMask [148,147,134], 429, 61469⟩
def Adaptive147Third134Node1 : CachedSearchNode := cachedChild Adaptive147Third134Node0 110
def Adaptive147Third134Node2 : CachedSearchNode := cachedChild Adaptive147Third134Node0 111
def Adaptive147Third134Node3 : CachedSearchNode := cachedChild Adaptive147Third134Node0 112
def Adaptive147Third134Node4 : CachedSearchNode := cachedChild Adaptive147Third134Node0 113
def Adaptive147Third134Node5 : CachedSearchNode := cachedChild Adaptive147Third134Node0 114
def Adaptive147Third134Node6 : CachedSearchNode := cachedChild Adaptive147Third134Node0 115
def Adaptive147Third134Node7 : CachedSearchNode := cachedChild Adaptive147Third134Node0 116
def Adaptive147Third134Node8 : CachedSearchNode := cachedChild Adaptive147Third134Node0 117
def Adaptive147Third134Node9 : CachedSearchNode := cachedChild Adaptive147Third134Node0 118
def Adaptive147Third134Node10 : CachedSearchNode := cachedChild Adaptive147Third134Node0 119
def Adaptive147Third134Node11 : CachedSearchNode := cachedChild Adaptive147Third134Node0 120
def Adaptive147Third134Node12 : CachedSearchNode := cachedChild Adaptive147Third134Node0 121
def Adaptive147Third134Node13 : CachedSearchNode := cachedChild Adaptive147Third134Node0 122
def Adaptive147Third134Node14 : CachedSearchNode := cachedChild Adaptive147Third134Node0 123
def Adaptive147Third134Node15 : CachedSearchNode := cachedChild Adaptive147Third134Node0 124
def Adaptive147Third134Node16 : CachedSearchNode := cachedChild Adaptive147Third134Node0 125
def Adaptive147Third134Node17 : CachedSearchNode := cachedChild Adaptive147Third134Node0 126
def Adaptive147Third134Node18 : CachedSearchNode := cachedChild Adaptive147Third134Node0 127
def Adaptive147Third134Node19 : CachedSearchNode := cachedChild Adaptive147Third134Node0 128
def Adaptive147Third134Node20 : CachedSearchNode := cachedChild Adaptive147Third134Node0 129
def Adaptive147Third134Node21 : CachedSearchNode := cachedChild Adaptive147Third134Node0 130
def Adaptive147Third134Node22 : CachedSearchNode := cachedChild Adaptive147Third134Node0 131
def Adaptive147Third134Node23 : CachedSearchNode := cachedChild Adaptive147Third134Node0 132
def Adaptive147Third134Node24 : CachedSearchNode := cachedChild Adaptive147Third134Node23 104
def Adaptive147Third134Node25 : CachedSearchNode := cachedChild Adaptive147Third134Node23 105
def Adaptive147Third134Node26 : CachedSearchNode := cachedChild Adaptive147Third134Node23 106
def Adaptive147Third134Node27 : CachedSearchNode := cachedChild Adaptive147Third134Node23 107
def Adaptive147Third134Node28 : CachedSearchNode := cachedChild Adaptive147Third134Node23 108
def Adaptive147Third134Node29 : CachedSearchNode := cachedChild Adaptive147Third134Node23 109
def Adaptive147Third134Node30 : CachedSearchNode := cachedChild Adaptive147Third134Node23 110
def Adaptive147Third134Node31 : CachedSearchNode := cachedChild Adaptive147Third134Node23 111
def Adaptive147Third134Node32 : CachedSearchNode := cachedChild Adaptive147Third134Node23 112
def Adaptive147Third134Node33 : CachedSearchNode := cachedChild Adaptive147Third134Node23 113
def Adaptive147Third134Node34 : CachedSearchNode := cachedChild Adaptive147Third134Node23 114
def Adaptive147Third134Node35 : CachedSearchNode := cachedChild Adaptive147Third134Node23 115
def Adaptive147Third134Node36 : CachedSearchNode := cachedChild Adaptive147Third134Node23 116
def Adaptive147Third134Node37 : CachedSearchNode := cachedChild Adaptive147Third134Node23 117
def Adaptive147Third134Node38 : CachedSearchNode := cachedChild Adaptive147Third134Node23 120
def Adaptive147Third134Node39 : CachedSearchNode := cachedChild Adaptive147Third134Node23 121
def Adaptive147Third134Node40 : CachedSearchNode := cachedChild Adaptive147Third134Node23 122
def Adaptive147Third134Node41 : CachedSearchNode := cachedChild Adaptive147Third134Node23 123
def Adaptive147Third134Node42 : CachedSearchNode := cachedChild Adaptive147Third134Node23 124
def Adaptive147Third134Node43 : CachedSearchNode := cachedChild Adaptive147Third134Node23 125
def Adaptive147Third134Node44 : CachedSearchNode := cachedChild Adaptive147Third134Node23 126
def Adaptive147Third134Node45 : CachedSearchNode := cachedChild Adaptive147Third134Node23 127
def Adaptive147Third134Node46 : CachedSearchNode := cachedChild Adaptive147Third134Node23 128
def Adaptive147Third134Node47 : CachedSearchNode := cachedChild Adaptive147Third134Node23 129
def Adaptive147Third134Node48 : CachedSearchNode := cachedChild Adaptive147Third134Node23 130

end NineSeparatedSubsetSums
