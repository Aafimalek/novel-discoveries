import NineSeparatedSubsetSums.Adaptive147Third140State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third140Proof130 : runCachedNode 511 130945 Adaptive147Third140Node130 = false := by
  decide +kernel

#print axioms adaptive147Third140Proof130

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third140Proof46 : runCachedNode 511 130945 Adaptive147Third140Node46 = false := by
  decide +kernel

#print axioms adaptive147Third140Proof46

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third140Proof47 : runCachedNode 511 130945 Adaptive147Third140Node47 = false := by
  decide +kernel

#print axioms adaptive147Third140Proof47

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third140Proof13 : runCachedNode 511 130945 Adaptive147Third140Node13 = false := by
  decide +kernel

#print axioms adaptive147Third140Proof13

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third140Proof161 : runCachedNode 511 130945 Adaptive147Third140Node161 = false := by
  decide +kernel

#print axioms adaptive147Third140Proof161

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third140Proof191 : runCachedNode 511 130945 Adaptive147Third140Node191 = false := by
  decide +kernel

#print axioms adaptive147Third140Proof191

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third140Proof253 : runCachedNode 511 130945 Adaptive147Third140Node253 = false := by
  decide +kernel

#print axioms adaptive147Third140Proof253

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third140Proof107 : runCachedNode 511 130945 Adaptive147Third140Node107 = false := by
  decide +kernel

#print axioms adaptive147Third140Proof107

end NineSeparatedSubsetSums
