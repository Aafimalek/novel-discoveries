import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive147Third119Node0 : CachedSearchNode :=
  ⟨4, 118, computeCenteredMask [148,147,119], 414, 57674⟩

end NineSeparatedSubsetSums
