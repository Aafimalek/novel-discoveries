import NineSeparatedSubsetSums.Adaptive147Third132State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third132Proof10 : runCachedNode 511 129667 Adaptive147Third132Node10 = false := by
  decide +kernel

#print axioms adaptive147Third132Proof10

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third132Proof9 : runCachedNode 511 129667 Adaptive147Third132Node9 = false := by
  decide +kernel

#print axioms adaptive147Third132Proof9

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third132Proof8 : runCachedNode 511 129667 Adaptive147Third132Node8 = false := by
  decide +kernel

#print axioms adaptive147Third132Proof8

end NineSeparatedSubsetSums
