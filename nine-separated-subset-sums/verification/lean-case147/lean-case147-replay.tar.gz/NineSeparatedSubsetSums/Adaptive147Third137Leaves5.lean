import NineSeparatedSubsetSums.Adaptive147Third137State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third137Proof152 : runCachedNode 511 130518 Adaptive147Third137Node152 = false := by
  decide +kernel

#print axioms adaptive147Third137Proof152

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third137Proof153 : runCachedNode 511 130518 Adaptive147Third137Node153 = false := by
  decide +kernel

#print axioms adaptive147Third137Proof153

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third137Proof176 : runCachedNode 511 130518 Adaptive147Third137Node176 = false := by
  decide +kernel

#print axioms adaptive147Third137Proof176

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third137Proof178 : runCachedNode 511 130518 Adaptive147Third137Node178 = false := by
  decide +kernel

#print axioms adaptive147Third137Proof178

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third137Proof74 : runCachedNode 511 130518 Adaptive147Third137Node74 = false := by
  decide +kernel

#print axioms adaptive147Third137Proof74

end NineSeparatedSubsetSums
