import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive147Third116Node0 : CachedSearchNode :=
  ⟨4, 115, computeCenteredMask [148,147,116], 411, 56969⟩
def Adaptive147Third116Node1 : CachedSearchNode := cachedChild Adaptive147Third116Node0 99
def Adaptive147Third116Node2 : CachedSearchNode := cachedChild Adaptive147Third116Node0 100
def Adaptive147Third116Node3 : CachedSearchNode := cachedChild Adaptive147Third116Node0 101
def Adaptive147Third116Node4 : CachedSearchNode := cachedChild Adaptive147Third116Node0 102
def Adaptive147Third116Node5 : CachedSearchNode := cachedChild Adaptive147Third116Node0 103
def Adaptive147Third116Node6 : CachedSearchNode := cachedChild Adaptive147Third116Node0 104
def Adaptive147Third116Node7 : CachedSearchNode := cachedChild Adaptive147Third116Node0 105
def Adaptive147Third116Node8 : CachedSearchNode := cachedChild Adaptive147Third116Node0 106
def Adaptive147Third116Node9 : CachedSearchNode := cachedChild Adaptive147Third116Node0 107
def Adaptive147Third116Node10 : CachedSearchNode := cachedChild Adaptive147Third116Node0 108
def Adaptive147Third116Node11 : CachedSearchNode := cachedChild Adaptive147Third116Node0 109
def Adaptive147Third116Node12 : CachedSearchNode := cachedChild Adaptive147Third116Node0 110
def Adaptive147Third116Node13 : CachedSearchNode := cachedChild Adaptive147Third116Node0 111
def Adaptive147Third116Node14 : CachedSearchNode := cachedChild Adaptive147Third116Node0 112
def Adaptive147Third116Node15 : CachedSearchNode := cachedChild Adaptive147Third116Node0 113
def Adaptive147Third116Node16 : CachedSearchNode := cachedChild Adaptive147Third116Node0 114

end NineSeparatedSubsetSums
