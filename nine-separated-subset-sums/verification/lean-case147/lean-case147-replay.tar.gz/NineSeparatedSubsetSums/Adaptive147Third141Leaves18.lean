import NineSeparatedSubsetSums.Adaptive147Third141State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third141Proof161 : runCachedNode 511 131086 Adaptive147Third141Node161 = false := by
  decide +kernel

#print axioms adaptive147Third141Proof161

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third141Proof132 : runCachedNode 511 131086 Adaptive147Third141Node132 = false := by
  decide +kernel

#print axioms adaptive147Third141Proof132

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third141Proof195 : runCachedNode 511 131086 Adaptive147Third141Node195 = false := by
  decide +kernel

#print axioms adaptive147Third141Proof195

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third141Proof13 : runCachedNode 511 131086 Adaptive147Third141Node13 = false := by
  decide +kernel

#print axioms adaptive147Third141Proof13

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third141Proof138 : runCachedNode 511 131086 Adaptive147Third141Node138 = false := by
  decide +kernel

#print axioms adaptive147Third141Proof138

end NineSeparatedSubsetSums
