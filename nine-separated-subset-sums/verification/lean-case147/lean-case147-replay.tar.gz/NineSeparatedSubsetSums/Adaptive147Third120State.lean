import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive147Third120Node0 : CachedSearchNode :=
  ⟨4, 119, computeCenteredMask [148,147,120], 415, 57913⟩

end NineSeparatedSubsetSums
