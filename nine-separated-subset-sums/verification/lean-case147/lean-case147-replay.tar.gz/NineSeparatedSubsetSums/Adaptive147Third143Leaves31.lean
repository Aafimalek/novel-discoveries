import NineSeparatedSubsetSums.Adaptive147Third143State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third143Proof103 : runCachedNode 511 131344 Adaptive147Third143Node103 = false := by
  decide +kernel

#print axioms adaptive147Third143Proof103

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third143Proof47 : runCachedNode 511 131344 Adaptive147Third143Node47 = false := by
  decide +kernel

#print axioms adaptive147Third143Proof47

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third143Proof414 : runCachedNode 511 131344 Adaptive147Third143Node414 = false := by
  decide +kernel

#print axioms adaptive147Third143Proof414

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third143Proof257 : runCachedNode 511 131344 Adaptive147Third143Node257 = false := by
  decide +kernel

#print axioms adaptive147Third143Proof257

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third143Proof633 : runCachedNode 511 131344 Adaptive147Third143Node633 = false := by
  decide +kernel

#print axioms adaptive147Third143Proof633

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third143Proof100 : runCachedNode 511 131344 Adaptive147Third143Node100 = false := by
  decide +kernel

#print axioms adaptive147Third143Proof100

end NineSeparatedSubsetSums
