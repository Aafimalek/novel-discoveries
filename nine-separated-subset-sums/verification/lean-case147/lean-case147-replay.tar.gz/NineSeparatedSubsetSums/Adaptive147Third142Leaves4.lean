import NineSeparatedSubsetSums.Adaptive147Third142State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third142Proof22 : runCachedNode 511 131213 Adaptive147Third142Node22 = false := by
  decide +kernel

#print axioms adaptive147Third142Proof22

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third142Proof134 : runCachedNode 511 131213 Adaptive147Third142Node134 = false := by
  decide +kernel

#print axioms adaptive147Third142Proof134

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third142Proof52 : runCachedNode 511 131213 Adaptive147Third142Node52 = false := by
  decide +kernel

#print axioms adaptive147Third142Proof52

end NineSeparatedSubsetSums
