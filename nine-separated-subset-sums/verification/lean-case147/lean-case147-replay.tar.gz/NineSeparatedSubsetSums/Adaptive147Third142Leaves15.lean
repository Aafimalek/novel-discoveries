import NineSeparatedSubsetSums.Adaptive147Third142State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third142Proof200 : runCachedNode 511 131213 Adaptive147Third142Node200 = false := by
  decide +kernel

#print axioms adaptive147Third142Proof200

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third142Proof18 : runCachedNode 511 131213 Adaptive147Third142Node18 = false := by
  decide +kernel

#print axioms adaptive147Third142Proof18

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third142Proof263 : runCachedNode 511 131213 Adaptive147Third142Node263 = false := by
  decide +kernel

#print axioms adaptive147Third142Proof263

end NineSeparatedSubsetSums
