import NineSeparatedSubsetSums.Adaptive147Third136State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third136Proof126 : runCachedNode 511 130369 Adaptive147Third136Node126 = false := by
  decide +kernel

#print axioms adaptive147Third136Proof126

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third136Proof71 : runCachedNode 511 130369 Adaptive147Third136Node71 = false := by
  decide +kernel

#print axioms adaptive147Third136Proof71

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third136Proof43 : runCachedNode 511 130369 Adaptive147Third136Node43 = false := by
  decide +kernel

#print axioms adaptive147Third136Proof43

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third136Proof42 : runCachedNode 511 130369 Adaptive147Third136Node42 = false := by
  decide +kernel

#print axioms adaptive147Third136Proof42

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third136Proof72 : runCachedNode 511 130369 Adaptive147Third136Node72 = false := by
  decide +kernel

#print axioms adaptive147Third136Proof72

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third136Proof45 : runCachedNode 511 130369 Adaptive147Third136Node45 = false := by
  decide +kernel

#print axioms adaptive147Third136Proof45

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third136Proof9 : runCachedNode 511 130369 Adaptive147Third136Node9 = false := by
  decide +kernel

#print axioms adaptive147Third136Proof9

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third136Proof54 : runCachedNode 511 130369 Adaptive147Third136Node54 = false := by
  decide +kernel

#print axioms adaptive147Third136Proof54

end NineSeparatedSubsetSums
