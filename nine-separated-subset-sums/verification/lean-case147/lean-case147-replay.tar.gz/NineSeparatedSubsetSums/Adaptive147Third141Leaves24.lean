import NineSeparatedSubsetSums.Adaptive147Third141State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third141Proof329 : runCachedNode 511 131086 Adaptive147Third141Node329 = false := by
  decide +kernel

#print axioms adaptive147Third141Proof329

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third141Proof331 : runCachedNode 511 131086 Adaptive147Third141Node331 = false := by
  decide +kernel

#print axioms adaptive147Third141Proof331

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third141Proof224 : runCachedNode 511 131086 Adaptive147Third141Node224 = false := by
  decide +kernel

#print axioms adaptive147Third141Proof224

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third141Proof74 : runCachedNode 511 131086 Adaptive147Third141Node74 = false := by
  decide +kernel

#print axioms adaptive147Third141Proof74

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third141Proof127 : runCachedNode 511 131086 Adaptive147Third141Node127 = false := by
  decide +kernel

#print axioms adaptive147Third141Proof127

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third141Proof328 : runCachedNode 511 131086 Adaptive147Third141Node328 = false := by
  decide +kernel

#print axioms adaptive147Third141Proof328

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third141Proof259 : runCachedNode 511 131086 Adaptive147Third141Node259 = false := by
  decide +kernel

#print axioms adaptive147Third141Proof259

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third141Proof106 : runCachedNode 511 131086 Adaptive147Third141Node106 = false := by
  decide +kernel

#print axioms adaptive147Third141Proof106

end NineSeparatedSubsetSums
