import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive147Third110Node0 : CachedSearchNode :=
  ⟨4, 109, computeCenteredMask [148,147,110], 405, 55613⟩

end NineSeparatedSubsetSums
