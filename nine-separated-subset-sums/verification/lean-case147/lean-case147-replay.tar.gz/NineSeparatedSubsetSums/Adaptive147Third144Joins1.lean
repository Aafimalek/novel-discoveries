import NineSeparatedSubsetSums.Adaptive147Third144State
import NineSeparatedSubsetSums.Adaptive147Third144Leaves66
import NineSeparatedSubsetSums.Adaptive147Third144Leaves65
import NineSeparatedSubsetSums.Adaptive147Third144Leaves64
import NineSeparatedSubsetSums.Adaptive147Third144Leaves63
import NineSeparatedSubsetSums.Adaptive147Third144Leaves62
import NineSeparatedSubsetSums.Adaptive147Third144Leaves61
import NineSeparatedSubsetSums.Adaptive147Third144Leaves60
import NineSeparatedSubsetSums.Adaptive147Third144Leaves59
import NineSeparatedSubsetSums.Adaptive147Third144Leaves58
import NineSeparatedSubsetSums.Adaptive147Third144Leaves56
import NineSeparatedSubsetSums.Adaptive147Third144Leaves55
import NineSeparatedSubsetSums.Adaptive147Third144Leaves54
import NineSeparatedSubsetSums.Adaptive147Third144Leaves52
import NineSeparatedSubsetSums.Adaptive147Third144Leaves51
import NineSeparatedSubsetSums.Adaptive147Third144Leaves50
import NineSeparatedSubsetSums.Adaptive147Third144Leaves49
import NineSeparatedSubsetSums.Adaptive147Third144Leaves48
import NineSeparatedSubsetSums.Adaptive147Third144Leaves47
import NineSeparatedSubsetSums.Adaptive147Third144Leaves45
import NineSeparatedSubsetSums.Adaptive147Third144Leaves43
import NineSeparatedSubsetSums.Adaptive147Third144Leaves44
import NineSeparatedSubsetSums.Adaptive147Third144Leaves37
import NineSeparatedSubsetSums.Adaptive147Third144Leaves29
import NineSeparatedSubsetSums.Adaptive147Third144Leaves35
import NineSeparatedSubsetSums.Adaptive147Third144Leaves17
import NineSeparatedSubsetSums.Adaptive147Third144Leaves16
import NineSeparatedSubsetSums.Adaptive147Third144Leaves12
import NineSeparatedSubsetSums.Adaptive147Third144Leaves3
import NineSeparatedSubsetSums.Adaptive147Third144Leaves5
import NineSeparatedSubsetSums.Adaptive147Third144Leaves53
import NineSeparatedSubsetSums.Adaptive147Third144Leaves41
import NineSeparatedSubsetSums.Adaptive147Third144Leaves46
import NineSeparatedSubsetSums.Adaptive147Third144Leaves57
import NineSeparatedSubsetSums.Adaptive147Third144Leaves33
import NineSeparatedSubsetSums.Adaptive147Third144Leaves67
import NineSeparatedSubsetSums.Adaptive147Third144Leaves39
import NineSeparatedSubsetSums.Adaptive147Third144Leaves40
import NineSeparatedSubsetSums.Adaptive147Third144Leaves25
import NineSeparatedSubsetSums.Adaptive147Third144Leaves22
import NineSeparatedSubsetSums.Adaptive147Third144Leaves24
import NineSeparatedSubsetSums.Adaptive147Third144Leaves42
import NineSeparatedSubsetSums.Adaptive147Third144Leaves36
import NineSeparatedSubsetSums.Adaptive147Third144Leaves34
import NineSeparatedSubsetSums.Adaptive147Third144Leaves27
import NineSeparatedSubsetSums.Adaptive147Third144Leaves30
import NineSeparatedSubsetSums.Adaptive147Third144Leaves18
import NineSeparatedSubsetSums.Adaptive147Third144Leaves11
import NineSeparatedSubsetSums.Adaptive147Third144Leaves14
import NineSeparatedSubsetSums.Adaptive147Third144Leaves15
import NineSeparatedSubsetSums.Adaptive147Third144Leaves1
import NineSeparatedSubsetSums.Adaptive147Third144Leaves38
import NineSeparatedSubsetSums.Adaptive147Third144Leaves32

namespace NineSeparatedSubsetSums

theorem adaptive147Third144Proof270 : runCachedNode 511 131483 Adaptive147Third144Node270 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 131483 Adaptive147Third144Node270 = [100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 132, 133, 134, 137] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive147Third144Proof271
  · exact adaptive147Third144Proof272
  · exact adaptive147Third144Proof273
  · exact adaptive147Third144Proof274
  · exact adaptive147Third144Proof275
  · exact adaptive147Third144Proof276
  · exact adaptive147Third144Proof277
  · exact adaptive147Third144Proof278
  · exact adaptive147Third144Proof279
  · exact adaptive147Third144Proof280
  · exact adaptive147Third144Proof281
  · exact adaptive147Third144Proof282
  · exact adaptive147Third144Proof283
  · exact adaptive147Third144Proof284
  · exact adaptive147Third144Proof285
  · exact adaptive147Third144Proof286
  · exact adaptive147Third144Proof287
  · exact adaptive147Third144Proof288
  · exact adaptive147Third144Proof289
  · exact adaptive147Third144Proof290
  · exact adaptive147Third144Proof291
  · exact adaptive147Third144Proof292
  · exact adaptive147Third144Proof293
  · exact adaptive147Third144Proof294
  · exact adaptive147Third144Proof295
  · exact adaptive147Third144Proof296
  · exact adaptive147Third144Proof297
  · exact adaptive147Third144Proof298
  · exact adaptive147Third144Proof299
  · exact adaptive147Third144Proof300
  · exact adaptive147Third144Proof301
  · exact adaptive147Third144Proof302
  · exact adaptive147Third144Proof303
  · exact adaptive147Third144Proof304
  · exact adaptive147Third144Proof305
  · exact adaptive147Third144Proof306

#print axioms adaptive147Third144Proof270

theorem adaptive147Third144Proof340 : runCachedNode 511 131483 Adaptive147Third144Node340 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 131483 Adaptive147Third144Node340 = [89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 122, 123, 126, 130] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive147Third144Proof341
  · exact adaptive147Third144Proof342
  · exact adaptive147Third144Proof343
  · exact adaptive147Third144Proof344
  · exact adaptive147Third144Proof345
  · exact adaptive147Third144Proof346
  · exact adaptive147Third144Proof347
  · exact adaptive147Third144Proof348
  · exact adaptive147Third144Proof349
  · exact adaptive147Third144Proof350
  · exact adaptive147Third144Proof351
  · exact adaptive147Third144Proof352
  · exact adaptive147Third144Proof353
  · exact adaptive147Third144Proof354
  · exact adaptive147Third144Proof355
  · exact adaptive147Third144Proof356
  · exact adaptive147Third144Proof357
  · exact adaptive147Third144Proof358
  · exact adaptive147Third144Proof359
  · exact adaptive147Third144Proof360
  · exact adaptive147Third144Proof361
  · exact adaptive147Third144Proof362
  · exact adaptive147Third144Proof363
  · exact adaptive147Third144Proof364
  · exact adaptive147Third144Proof365
  · exact adaptive147Third144Proof366
  · exact adaptive147Third144Proof367
  · exact adaptive147Third144Proof368
  · exact adaptive147Third144Proof369
  · exact adaptive147Third144Proof370
  · exact adaptive147Third144Proof371
  · exact adaptive147Third144Proof372
  · exact adaptive147Third144Proof373
  · exact adaptive147Third144Proof374
  · exact adaptive147Third144Proof375
  · exact adaptive147Third144Proof376

#print axioms adaptive147Third144Proof340

theorem adaptive147Third144Proof377 : runCachedNode 511 131483 Adaptive147Third144Node377 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 131483 Adaptive147Third144Node377 = [89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 123, 124, 127, 131] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive147Third144Proof378
  · exact adaptive147Third144Proof379
  · exact adaptive147Third144Proof380
  · exact adaptive147Third144Proof381
  · exact adaptive147Third144Proof382
  · exact adaptive147Third144Proof383
  · exact adaptive147Third144Proof384
  · exact adaptive147Third144Proof385
  · exact adaptive147Third144Proof386
  · exact adaptive147Third144Proof387
  · exact adaptive147Third144Proof388
  · exact adaptive147Third144Proof389
  · exact adaptive147Third144Proof390
  · exact adaptive147Third144Proof391
  · exact adaptive147Third144Proof392
  · exact adaptive147Third144Proof393
  · exact adaptive147Third144Proof394
  · exact adaptive147Third144Proof395
  · exact adaptive147Third144Proof396
  · exact adaptive147Third144Proof397
  · exact adaptive147Third144Proof398
  · exact adaptive147Third144Proof399
  · exact adaptive147Third144Proof400
  · exact adaptive147Third144Proof401
  · exact adaptive147Third144Proof402
  · exact adaptive147Third144Proof403
  · exact adaptive147Third144Proof404
  · exact adaptive147Third144Proof405
  · exact adaptive147Third144Proof406
  · exact adaptive147Third144Proof407
  · exact adaptive147Third144Proof408
  · exact adaptive147Third144Proof409
  · exact adaptive147Third144Proof410
  · exact adaptive147Third144Proof411
  · exact adaptive147Third144Proof412
  · exact adaptive147Third144Proof413
  · exact adaptive147Third144Proof414

#print axioms adaptive147Third144Proof377

theorem adaptive147Third144Proof416 : runCachedNode 511 131483 Adaptive147Third144Node416 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 131483 Adaptive147Third144Node416 = [88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 125, 126, 129, 133] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive147Third144Proof417
  · exact adaptive147Third144Proof418
  · exact adaptive147Third144Proof419
  · exact adaptive147Third144Proof420
  · exact adaptive147Third144Proof421
  · exact adaptive147Third144Proof422
  · exact adaptive147Third144Proof423
  · exact adaptive147Third144Proof424
  · exact adaptive147Third144Proof425
  · exact adaptive147Third144Proof426
  · exact adaptive147Third144Proof427
  · exact adaptive147Third144Proof428
  · exact adaptive147Third144Proof429
  · exact adaptive147Third144Proof430
  · exact adaptive147Third144Proof431
  · exact adaptive147Third144Proof432
  · exact adaptive147Third144Proof433
  · exact adaptive147Third144Proof434
  · exact adaptive147Third144Proof435
  · exact adaptive147Third144Proof436
  · exact adaptive147Third144Proof437
  · exact adaptive147Third144Proof438
  · exact adaptive147Third144Proof439
  · exact adaptive147Third144Proof440
  · exact adaptive147Third144Proof441
  · exact adaptive147Third144Proof442
  · exact adaptive147Third144Proof443
  · exact adaptive147Third144Proof444
  · exact adaptive147Third144Proof445
  · exact adaptive147Third144Proof446
  · exact adaptive147Third144Proof447
  · exact adaptive147Third144Proof448
  · exact adaptive147Third144Proof449
  · exact adaptive147Third144Proof450
  · exact adaptive147Third144Proof451
  · exact adaptive147Third144Proof452
  · exact adaptive147Third144Proof453
  · exact adaptive147Third144Proof454
  · exact adaptive147Third144Proof455
  · exact adaptive147Third144Proof456

#print axioms adaptive147Third144Proof416

theorem adaptive147Third144Proof457 : runCachedNode 511 131483 Adaptive147Third144Node457 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 131483 Adaptive147Third144Node457 = [87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 128, 129, 132] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive147Third144Proof458
  · exact adaptive147Third144Proof459
  · exact adaptive147Third144Proof460
  · exact adaptive147Third144Proof461
  · exact adaptive147Third144Proof462
  · exact adaptive147Third144Proof463
  · exact adaptive147Third144Proof464
  · exact adaptive147Third144Proof465
  · exact adaptive147Third144Proof466
  · exact adaptive147Third144Proof467
  · exact adaptive147Third144Proof468
  · exact adaptive147Third144Proof469
  · exact adaptive147Third144Proof470
  · exact adaptive147Third144Proof471
  · exact adaptive147Third144Proof472
  · exact adaptive147Third144Proof473
  · exact adaptive147Third144Proof474
  · exact adaptive147Third144Proof475
  · exact adaptive147Third144Proof476
  · exact adaptive147Third144Proof477
  · exact adaptive147Third144Proof478
  · exact adaptive147Third144Proof479
  · exact adaptive147Third144Proof480
  · exact adaptive147Third144Proof481
  · exact adaptive147Third144Proof482
  · exact adaptive147Third144Proof483
  · exact adaptive147Third144Proof484
  · exact adaptive147Third144Proof485
  · exact adaptive147Third144Proof486
  · exact adaptive147Third144Proof487
  · exact adaptive147Third144Proof488
  · exact adaptive147Third144Proof489
  · exact adaptive147Third144Proof490
  · exact adaptive147Third144Proof491
  · exact adaptive147Third144Proof492
  · exact adaptive147Third144Proof493
  · exact adaptive147Third144Proof494
  · exact adaptive147Third144Proof495
  · exact adaptive147Third144Proof496
  · exact adaptive147Third144Proof497
  · exact adaptive147Third144Proof498
  · exact adaptive147Third144Proof499
  · exact adaptive147Third144Proof500

#print axioms adaptive147Third144Proof457

theorem adaptive147Third144Proof307 : runCachedNode 511 131483 Adaptive147Third144Node307 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 131483 Adaptive147Third144Node307 = [100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 132, 133, 134, 135, 138] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive147Third144Proof308
  · exact adaptive147Third144Proof309
  · exact adaptive147Third144Proof310
  · exact adaptive147Third144Proof311
  · exact adaptive147Third144Proof312
  · exact adaptive147Third144Proof313
  · exact adaptive147Third144Proof314
  · exact adaptive147Third144Proof315
  · exact adaptive147Third144Proof316
  · exact adaptive147Third144Proof317
  · exact adaptive147Third144Proof318
  · exact adaptive147Third144Proof319
  · exact adaptive147Third144Proof320
  · exact adaptive147Third144Proof321
  · exact adaptive147Third144Proof322
  · exact adaptive147Third144Proof323
  · exact adaptive147Third144Proof324
  · exact adaptive147Third144Proof325
  · exact adaptive147Third144Proof326
  · exact adaptive147Third144Proof327
  · exact adaptive147Third144Proof328
  · exact adaptive147Third144Proof329
  · exact adaptive147Third144Proof330
  · exact adaptive147Third144Proof331
  · exact adaptive147Third144Proof332
  · exact adaptive147Third144Proof333
  · exact adaptive147Third144Proof334
  · exact adaptive147Third144Proof335
  · exact adaptive147Third144Proof336
  · exact adaptive147Third144Proof337
  · exact adaptive147Third144Proof338
  · exact adaptive147Third144Proof339
  · exact adaptive147Third144Proof340
  · exact adaptive147Third144Proof377
  · exact adaptive147Third144Proof415
  · exact adaptive147Third144Proof416
  · exact adaptive147Third144Proof457

#print axioms adaptive147Third144Proof307

theorem adaptive147Third144Proof536 : runCachedNode 511 131483 Adaptive147Third144Node536 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 131483 Adaptive147Third144Node536 = [88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 125, 126, 129] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive147Third144Proof537
  · exact adaptive147Third144Proof538
  · exact adaptive147Third144Proof539
  · exact adaptive147Third144Proof540
  · exact adaptive147Third144Proof541
  · exact adaptive147Third144Proof542
  · exact adaptive147Third144Proof543
  · exact adaptive147Third144Proof544
  · exact adaptive147Third144Proof545
  · exact adaptive147Third144Proof546
  · exact adaptive147Third144Proof547
  · exact adaptive147Third144Proof548
  · exact adaptive147Third144Proof549
  · exact adaptive147Third144Proof550
  · exact adaptive147Third144Proof551
  · exact adaptive147Third144Proof552
  · exact adaptive147Third144Proof553
  · exact adaptive147Third144Proof554
  · exact adaptive147Third144Proof555
  · exact adaptive147Third144Proof556
  · exact adaptive147Third144Proof557
  · exact adaptive147Third144Proof558
  · exact adaptive147Third144Proof559
  · exact adaptive147Third144Proof560
  · exact adaptive147Third144Proof561
  · exact adaptive147Third144Proof562
  · exact adaptive147Third144Proof563
  · exact adaptive147Third144Proof564
  · exact adaptive147Third144Proof565
  · exact adaptive147Third144Proof566
  · exact adaptive147Third144Proof567
  · exact adaptive147Third144Proof568
  · exact adaptive147Third144Proof569
  · exact adaptive147Third144Proof570
  · exact adaptive147Third144Proof571
  · exact adaptive147Third144Proof572
  · exact adaptive147Third144Proof573
  · exact adaptive147Third144Proof574
  · exact adaptive147Third144Proof575

#print axioms adaptive147Third144Proof536

theorem adaptive147Third144Proof576 : runCachedNode 511 131483 Adaptive147Third144Node576 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 131483 Adaptive147Third144Node576 = [87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 126, 127, 130] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive147Third144Proof577
  · exact adaptive147Third144Proof578
  · exact adaptive147Third144Proof579
  · exact adaptive147Third144Proof580
  · exact adaptive147Third144Proof581
  · exact adaptive147Third144Proof582
  · exact adaptive147Third144Proof583
  · exact adaptive147Third144Proof584
  · exact adaptive147Third144Proof585
  · exact adaptive147Third144Proof586
  · exact adaptive147Third144Proof587
  · exact adaptive147Third144Proof588
  · exact adaptive147Third144Proof589
  · exact adaptive147Third144Proof590
  · exact adaptive147Third144Proof591
  · exact adaptive147Third144Proof592
  · exact adaptive147Third144Proof593
  · exact adaptive147Third144Proof594
  · exact adaptive147Third144Proof595
  · exact adaptive147Third144Proof596
  · exact adaptive147Third144Proof597
  · exact adaptive147Third144Proof598
  · exact adaptive147Third144Proof599
  · exact adaptive147Third144Proof600
  · exact adaptive147Third144Proof601
  · exact adaptive147Third144Proof602
  · exact adaptive147Third144Proof603
  · exact adaptive147Third144Proof604
  · exact adaptive147Third144Proof605
  · exact adaptive147Third144Proof606
  · exact adaptive147Third144Proof607
  · exact adaptive147Third144Proof608
  · exact adaptive147Third144Proof609
  · exact adaptive147Third144Proof610
  · exact adaptive147Third144Proof611
  · exact adaptive147Third144Proof612
  · exact adaptive147Third144Proof613
  · exact adaptive147Third144Proof614
  · exact adaptive147Third144Proof615
  · exact adaptive147Third144Proof616
  · exact adaptive147Third144Proof617

#print axioms adaptive147Third144Proof576

end NineSeparatedSubsetSums
