import NineSeparatedSubsetSums.Adaptive147Third143State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third143Proof635 : runCachedNode 511 131344 Adaptive147Third143Node635 = false := by
  decide +kernel

#print axioms adaptive147Third143Proof635

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third143Proof196 : runCachedNode 511 131344 Adaptive147Third143Node196 = false := by
  decide +kernel

#print axioms adaptive147Third143Proof196

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third143Proof199 : runCachedNode 511 131344 Adaptive147Third143Node199 = false := by
  decide +kernel

#print axioms adaptive147Third143Proof199

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third143Proof71 : runCachedNode 511 131344 Adaptive147Third143Node71 = false := by
  decide +kernel

#print axioms adaptive147Third143Proof71

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third143Proof2 : runCachedNode 511 131344 Adaptive147Third143Node2 = false := by
  decide +kernel

#print axioms adaptive147Third143Proof2

end NineSeparatedSubsetSums
