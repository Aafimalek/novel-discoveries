import NineSeparatedSubsetSums.Adaptive147Third141State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third141Proof101 : runCachedNode 511 131086 Adaptive147Third141Node101 = false := by
  decide +kernel

#print axioms adaptive147Third141Proof101

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third141Proof75 : runCachedNode 511 131086 Adaptive147Third141Node75 = false := by
  decide +kernel

#print axioms adaptive147Third141Proof75

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third141Proof125 : runCachedNode 511 131086 Adaptive147Third141Node125 = false := by
  decide +kernel

#print axioms adaptive147Third141Proof125

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third141Proof225 : runCachedNode 511 131086 Adaptive147Third141Node225 = false := by
  decide +kernel

#print axioms adaptive147Third141Proof225

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third141Proof191 : runCachedNode 511 131086 Adaptive147Third141Node191 = false := by
  decide +kernel

#print axioms adaptive147Third141Proof191

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third141Proof226 : runCachedNode 511 131086 Adaptive147Third141Node226 = false := by
  decide +kernel

#print axioms adaptive147Third141Proof226

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third141Proof207 : runCachedNode 511 131086 Adaptive147Third141Node207 = false := by
  decide +kernel

#print axioms adaptive147Third141Proof207

end NineSeparatedSubsetSums
