import NineSeparatedSubsetSums.Adaptive147Third138State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third138Proof239 : runCachedNode 511 130657 Adaptive147Third138Node239 = false := by
  decide +kernel

#print axioms adaptive147Third138Proof239

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third138Proof237 : runCachedNode 511 130657 Adaptive147Third138Node237 = false := by
  decide +kernel

#print axioms adaptive147Third138Proof237

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third138Proof1 : runCachedNode 511 130657 Adaptive147Third138Node1 = false := by
  decide +kernel

#print axioms adaptive147Third138Proof1

end NineSeparatedSubsetSums
