import NineSeparatedSubsetSums.Adaptive147Third143State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third143Proof300 : runCachedNode 511 131344 Adaptive147Third143Node300 = false := by
  decide +kernel

#print axioms adaptive147Third143Proof300

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third143Proof193 : runCachedNode 511 131344 Adaptive147Third143Node193 = false := by
  decide +kernel

#print axioms adaptive147Third143Proof193

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third143Proof1 : runCachedNode 511 131344 Adaptive147Third143Node1 = false := by
  decide +kernel

#print axioms adaptive147Third143Proof1

end NineSeparatedSubsetSums
