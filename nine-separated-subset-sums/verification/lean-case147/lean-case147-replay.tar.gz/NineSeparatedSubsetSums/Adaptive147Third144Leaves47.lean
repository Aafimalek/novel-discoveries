import NineSeparatedSubsetSums.Adaptive147Third144State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof727 : runCachedNode 511 131483 Adaptive147Third144Node727 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof727

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof11 : runCachedNode 511 131483 Adaptive147Third144Node11 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof11

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof325 : runCachedNode 511 131483 Adaptive147Third144Node325 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof325

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof614 : runCachedNode 511 131483 Adaptive147Third144Node614 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof614

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof701 : runCachedNode 511 131483 Adaptive147Third144Node701 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof701

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof125 : runCachedNode 511 131483 Adaptive147Third144Node125 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof125

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof572 : runCachedNode 511 131483 Adaptive147Third144Node572 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof572

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof292 : runCachedNode 511 131483 Adaptive147Third144Node292 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof292

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof68 : runCachedNode 511 131483 Adaptive147Third144Node68 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof68

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof224 : runCachedNode 511 131483 Adaptive147Third144Node224 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof224

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof293 : runCachedNode 511 131483 Adaptive147Third144Node293 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof293

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof570 : runCachedNode 511 131483 Adaptive147Third144Node570 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof570

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof241 : runCachedNode 511 131483 Adaptive147Third144Node241 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof241

end NineSeparatedSubsetSums
