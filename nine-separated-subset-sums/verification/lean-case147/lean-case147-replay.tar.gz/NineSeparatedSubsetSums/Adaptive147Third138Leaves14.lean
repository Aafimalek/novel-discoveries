import NineSeparatedSubsetSums.Adaptive147Third138State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third138Proof230 : runCachedNode 511 130657 Adaptive147Third138Node230 = false := by
  decide +kernel

#print axioms adaptive147Third138Proof230

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third138Proof60 : runCachedNode 511 130657 Adaptive147Third138Node60 = false := by
  decide +kernel

#print axioms adaptive147Third138Proof60

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third138Proof36 : runCachedNode 511 130657 Adaptive147Third138Node36 = false := by
  decide +kernel

#print axioms adaptive147Third138Proof36

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third138Proof198 : runCachedNode 511 130657 Adaptive147Third138Node198 = false := by
  decide +kernel

#print axioms adaptive147Third138Proof198

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third138Proof170 : runCachedNode 511 130657 Adaptive147Third138Node170 = false := by
  decide +kernel

#print axioms adaptive147Third138Proof170

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third138Proof10 : runCachedNode 511 130657 Adaptive147Third138Node10 = false := by
  decide +kernel

#print axioms adaptive147Third138Proof10

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third138Proof169 : runCachedNode 511 130657 Adaptive147Third138Node169 = false := by
  decide +kernel

#print axioms adaptive147Third138Proof169

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third138Proof171 : runCachedNode 511 130657 Adaptive147Third138Node171 = false := by
  decide +kernel

#print axioms adaptive147Third138Proof171

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third138Proof141 : runCachedNode 511 130657 Adaptive147Third138Node141 = false := by
  decide +kernel

#print axioms adaptive147Third138Proof141

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third138Proof88 : runCachedNode 511 130657 Adaptive147Third138Node88 = false := by
  decide +kernel

#print axioms adaptive147Third138Proof88

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third138Proof86 : runCachedNode 511 130657 Adaptive147Third138Node86 = false := by
  decide +kernel

#print axioms adaptive147Third138Proof86

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third138Proof114 : runCachedNode 511 130657 Adaptive147Third138Node114 = false := by
  decide +kernel

#print axioms adaptive147Third138Proof114

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third138Proof59 : runCachedNode 511 130657 Adaptive147Third138Node59 = false := by
  decide +kernel

#print axioms adaptive147Third138Proof59

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third138Proof180 : runCachedNode 511 130657 Adaptive147Third138Node180 = false := by
  decide +kernel

#print axioms adaptive147Third138Proof180

end NineSeparatedSubsetSums
