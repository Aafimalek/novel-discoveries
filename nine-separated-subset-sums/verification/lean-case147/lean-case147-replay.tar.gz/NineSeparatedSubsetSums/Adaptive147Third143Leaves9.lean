import NineSeparatedSubsetSums.Adaptive147Third143State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third143Proof20 : runCachedNode 511 131344 Adaptive147Third143Node20 = false := by
  decide +kernel

#print axioms adaptive147Third143Proof20

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third143Proof16 : runCachedNode 511 131344 Adaptive147Third143Node16 = false := by
  decide +kernel

#print axioms adaptive147Third143Proof16

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third143Proof181 : runCachedNode 511 131344 Adaptive147Third143Node181 = false := by
  decide +kernel

#print axioms adaptive147Third143Proof181

end NineSeparatedSubsetSums
