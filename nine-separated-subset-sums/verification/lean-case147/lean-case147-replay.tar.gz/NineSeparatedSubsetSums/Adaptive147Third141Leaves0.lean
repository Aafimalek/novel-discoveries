import NineSeparatedSubsetSums.Adaptive147Third141State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third141Proof22 : runCachedNode 511 131086 Adaptive147Third141Node22 = false := by
  decide +kernel

#print axioms adaptive147Third141Proof22

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third141Proof102 : runCachedNode 511 131086 Adaptive147Third141Node102 = false := by
  decide +kernel

#print axioms adaptive147Third141Proof102

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third141Proof1 : runCachedNode 511 131086 Adaptive147Third141Node1 = false := by
  decide +kernel

#print axioms adaptive147Third141Proof1

end NineSeparatedSubsetSums
