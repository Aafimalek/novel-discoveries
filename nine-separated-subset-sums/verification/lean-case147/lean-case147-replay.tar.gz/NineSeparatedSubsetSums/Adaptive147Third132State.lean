import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive147Third132Node0 : CachedSearchNode :=
  ⟨4, 131, computeCenteredMask [148,147,132], 427, 60937⟩
def Adaptive147Third132Node1 : CachedSearchNode := cachedChild Adaptive147Third132Node0 110
def Adaptive147Third132Node2 : CachedSearchNode := cachedChild Adaptive147Third132Node0 111
def Adaptive147Third132Node3 : CachedSearchNode := cachedChild Adaptive147Third132Node0 112
def Adaptive147Third132Node4 : CachedSearchNode := cachedChild Adaptive147Third132Node0 113
def Adaptive147Third132Node5 : CachedSearchNode := cachedChild Adaptive147Third132Node0 114
def Adaptive147Third132Node6 : CachedSearchNode := cachedChild Adaptive147Third132Node0 115
def Adaptive147Third132Node7 : CachedSearchNode := cachedChild Adaptive147Third132Node0 116
def Adaptive147Third132Node8 : CachedSearchNode := cachedChild Adaptive147Third132Node0 117
def Adaptive147Third132Node9 : CachedSearchNode := cachedChild Adaptive147Third132Node0 118
def Adaptive147Third132Node10 : CachedSearchNode := cachedChild Adaptive147Third132Node0 119
def Adaptive147Third132Node11 : CachedSearchNode := cachedChild Adaptive147Third132Node0 120
def Adaptive147Third132Node12 : CachedSearchNode := cachedChild Adaptive147Third132Node0 121
def Adaptive147Third132Node13 : CachedSearchNode := cachedChild Adaptive147Third132Node0 122
def Adaptive147Third132Node14 : CachedSearchNode := cachedChild Adaptive147Third132Node0 123
def Adaptive147Third132Node15 : CachedSearchNode := cachedChild Adaptive147Third132Node0 124
def Adaptive147Third132Node16 : CachedSearchNode := cachedChild Adaptive147Third132Node0 125
def Adaptive147Third132Node17 : CachedSearchNode := cachedChild Adaptive147Third132Node0 126
def Adaptive147Third132Node18 : CachedSearchNode := cachedChild Adaptive147Third132Node0 127
def Adaptive147Third132Node19 : CachedSearchNode := cachedChild Adaptive147Third132Node0 128
def Adaptive147Third132Node20 : CachedSearchNode := cachedChild Adaptive147Third132Node0 129
def Adaptive147Third132Node21 : CachedSearchNode := cachedChild Adaptive147Third132Node0 130

end NineSeparatedSubsetSums
