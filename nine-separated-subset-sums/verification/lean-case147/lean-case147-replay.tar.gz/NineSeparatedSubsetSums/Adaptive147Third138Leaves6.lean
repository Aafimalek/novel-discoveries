import NineSeparatedSubsetSums.Adaptive147Third138State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third138Proof206 : runCachedNode 511 130657 Adaptive147Third138Node206 = false := by
  decide +kernel

#print axioms adaptive147Third138Proof206

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third138Proof145 : runCachedNode 511 130657 Adaptive147Third138Node145 = false := by
  decide +kernel

#print axioms adaptive147Third138Proof145

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third138Proof66 : runCachedNode 511 130657 Adaptive147Third138Node66 = false := by
  decide +kernel

#print axioms adaptive147Third138Proof66

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third138Proof193 : runCachedNode 511 130657 Adaptive147Third138Node193 = false := by
  decide +kernel

#print axioms adaptive147Third138Proof193

end NineSeparatedSubsetSums
