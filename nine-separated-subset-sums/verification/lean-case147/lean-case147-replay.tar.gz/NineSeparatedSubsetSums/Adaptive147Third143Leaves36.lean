import NineSeparatedSubsetSums.Adaptive147Third143State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third143Proof535 : runCachedNode 511 131344 Adaptive147Third143Node535 = false := by
  decide +kernel

#print axioms adaptive147Third143Proof535

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third143Proof413 : runCachedNode 511 131344 Adaptive147Third143Node413 = false := by
  decide +kernel

#print axioms adaptive147Third143Proof413

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third143Proof254 : runCachedNode 511 131344 Adaptive147Third143Node254 = false := by
  decide +kernel

#print axioms adaptive147Third143Proof254

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third143Proof255 : runCachedNode 511 131344 Adaptive147Third143Node255 = false := by
  decide +kernel

#print axioms adaptive147Third143Proof255

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third143Proof158 : runCachedNode 511 131344 Adaptive147Third143Node158 = false := by
  decide +kernel

#print axioms adaptive147Third143Proof158

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third143Proof411 : runCachedNode 511 131344 Adaptive147Third143Node411 = false := by
  decide +kernel

#print axioms adaptive147Third143Proof411

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third143Proof223 : runCachedNode 511 131344 Adaptive147Third143Node223 = false := by
  decide +kernel

#print axioms adaptive147Third143Proof223

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third143Proof132 : runCachedNode 511 131344 Adaptive147Third143Node132 = false := by
  decide +kernel

#print axioms adaptive147Third143Proof132

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third143Proof461 : runCachedNode 511 131344 Adaptive147Third143Node461 = false := by
  decide +kernel

#print axioms adaptive147Third143Proof461

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third143Proof338 : runCachedNode 511 131344 Adaptive147Third143Node338 = false := by
  decide +kernel

#print axioms adaptive147Third143Proof338

end NineSeparatedSubsetSums
