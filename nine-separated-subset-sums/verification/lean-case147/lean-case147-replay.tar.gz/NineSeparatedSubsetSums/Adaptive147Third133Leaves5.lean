import NineSeparatedSubsetSums.Adaptive147Third133State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third133Proof7 : runCachedNode 511 129861 Adaptive147Third133Node7 = false := by
  decide +kernel

#print axioms adaptive147Third133Proof7

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third133Proof37 : runCachedNode 511 129861 Adaptive147Third133Node37 = false := by
  decide +kernel

#print axioms adaptive147Third133Proof37

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third133Proof6 : runCachedNode 511 129861 Adaptive147Third133Node6 = false := by
  decide +kernel

#print axioms adaptive147Third133Proof6

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third133Proof34 : runCachedNode 511 129861 Adaptive147Third133Node34 = false := by
  decide +kernel

#print axioms adaptive147Third133Proof34

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third133Proof5 : runCachedNode 511 129861 Adaptive147Third133Node5 = false := by
  decide +kernel

#print axioms adaptive147Third133Proof5

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third133Proof32 : runCachedNode 511 129861 Adaptive147Third133Node32 = false := by
  decide +kernel

#print axioms adaptive147Third133Proof32

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third133Proof30 : runCachedNode 511 129861 Adaptive147Third133Node30 = false := by
  decide +kernel

#print axioms adaptive147Third133Proof30

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third133Proof31 : runCachedNode 511 129861 Adaptive147Third133Node31 = false := by
  decide +kernel

#print axioms adaptive147Third133Proof31

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third133Proof29 : runCachedNode 511 129861 Adaptive147Third133Node29 = false := by
  decide +kernel

#print axioms adaptive147Third133Proof29

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third133Proof4 : runCachedNode 511 129861 Adaptive147Third133Node4 = false := by
  decide +kernel

#print axioms adaptive147Third133Proof4

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third133Proof28 : runCachedNode 511 129861 Adaptive147Third133Node28 = false := by
  decide +kernel

#print axioms adaptive147Third133Proof28

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third133Proof3 : runCachedNode 511 129861 Adaptive147Third133Node3 = false := by
  decide +kernel

#print axioms adaptive147Third133Proof3

end NineSeparatedSubsetSums
