import NineSeparatedSubsetSums.Adaptive147Third143State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third143Proof421 : runCachedNode 511 131344 Adaptive147Third143Node421 = false := by
  decide +kernel

#print axioms adaptive147Third143Proof421

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third143Proof233 : runCachedNode 511 131344 Adaptive147Third143Node233 = false := by
  decide +kernel

#print axioms adaptive147Third143Proof233

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third143Proof105 : runCachedNode 511 131344 Adaptive147Third143Node105 = false := by
  decide +kernel

#print axioms adaptive147Third143Proof105

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third143Proof27 : runCachedNode 511 131344 Adaptive147Third143Node27 = false := by
  decide +kernel

#print axioms adaptive147Third143Proof27

end NineSeparatedSubsetSums
