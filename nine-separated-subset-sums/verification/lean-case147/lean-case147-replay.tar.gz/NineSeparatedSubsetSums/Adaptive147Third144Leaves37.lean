import NineSeparatedSubsetSums.Adaptive147Third144State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof331 : runCachedNode 511 131483 Adaptive147Third144Node331 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof331

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof376 : runCachedNode 511 131483 Adaptive147Third144Node376 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof376

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof297 : runCachedNode 511 131483 Adaptive147Third144Node297 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof297

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof13 : runCachedNode 511 131483 Adaptive147Third144Node13 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof13

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof73 : runCachedNode 511 131483 Adaptive147Third144Node73 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof73

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof72 : runCachedNode 511 131483 Adaptive147Third144Node72 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof72

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof137 : runCachedNode 511 131483 Adaptive147Third144Node137 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof137

end NineSeparatedSubsetSums
