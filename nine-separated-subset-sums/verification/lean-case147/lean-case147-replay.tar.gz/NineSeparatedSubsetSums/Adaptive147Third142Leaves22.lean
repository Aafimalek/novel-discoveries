import NineSeparatedSubsetSums.Adaptive147Third142State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third142Proof235 : runCachedNode 511 131213 Adaptive147Third142Node235 = false := by
  decide +kernel

#print axioms adaptive147Third142Proof235

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third142Proof138 : runCachedNode 511 131213 Adaptive147Third142Node138 = false := by
  decide +kernel

#print axioms adaptive147Third142Proof138

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third142Proof167 : runCachedNode 511 131213 Adaptive147Third142Node167 = false := by
  decide +kernel

#print axioms adaptive147Third142Proof167

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third142Proof160 : runCachedNode 511 131213 Adaptive147Third142Node160 = false := by
  decide +kernel

#print axioms adaptive147Third142Proof160

end NineSeparatedSubsetSums
