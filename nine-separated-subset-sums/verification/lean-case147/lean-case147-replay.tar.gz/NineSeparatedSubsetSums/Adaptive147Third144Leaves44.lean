import NineSeparatedSubsetSums.Adaptive147Third144State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof100 : runCachedNode 511 131483 Adaptive147Third144Node100 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof100

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof832 : runCachedNode 511 131483 Adaptive147Third144Node832 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof832

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof702 : runCachedNode 511 131483 Adaptive147Third144Node702 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof702

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof522 : runCachedNode 511 131483 Adaptive147Third144Node522 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof522

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof262 : runCachedNode 511 131483 Adaptive147Third144Node262 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof262

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof98 : runCachedNode 511 131483 Adaptive147Third144Node98 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof98

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof296 : runCachedNode 511 131483 Adaptive147Third144Node296 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof296

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof729 : runCachedNode 511 131483 Adaptive147Third144Node729 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof729

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof99 : runCachedNode 511 131483 Adaptive147Third144Node99 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof99

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof7 : runCachedNode 511 131483 Adaptive147Third144Node7 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof7

end NineSeparatedSubsetSums
