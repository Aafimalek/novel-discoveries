import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive147Third114Node0 : CachedSearchNode :=
  ⟨4, 113, computeCenteredMask [148,147,114], 409, 56509⟩

end NineSeparatedSubsetSums
