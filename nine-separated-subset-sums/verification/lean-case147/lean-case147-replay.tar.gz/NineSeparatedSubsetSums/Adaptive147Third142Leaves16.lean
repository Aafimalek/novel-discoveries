import NineSeparatedSubsetSums.Adaptive147Third142State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third142Proof203 : runCachedNode 511 131213 Adaptive147Third142Node203 = false := by
  decide +kernel

#print axioms adaptive147Third142Proof203

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third142Proof199 : runCachedNode 511 131213 Adaptive147Third142Node199 = false := by
  decide +kernel

#print axioms adaptive147Third142Proof199

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third142Proof268 : runCachedNode 511 131213 Adaptive147Third142Node268 = false := by
  decide +kernel

#print axioms adaptive147Third142Proof268

end NineSeparatedSubsetSums
