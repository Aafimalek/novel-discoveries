import NineSeparatedSubsetSums.Adaptive147Third142State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third142Proof239 : runCachedNode 511 131213 Adaptive147Third142Node239 = false := by
  decide +kernel

#print axioms adaptive147Third142Proof239

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third142Proof434 : runCachedNode 511 131213 Adaptive147Third142Node434 = false := by
  decide +kernel

#print axioms adaptive147Third142Proof434

end NineSeparatedSubsetSums
