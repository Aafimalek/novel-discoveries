import NineSeparatedSubsetSums.Adaptive147Third110Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint147Checked

namespace NineSeparatedSubsetSums


theorem adaptive147Third110 : NoDescendingTailAfterThird 147 110 :=
  noDescendingThirdTail_of_cached 147 110 112835 (fun t ht nd => max148_second147_fourPoint_moment_bound (110::t) (by simp [ht]) nd) adaptive147Third110Proof0

#print axioms adaptive147Third110

end NineSeparatedSubsetSums
