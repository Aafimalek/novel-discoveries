import NineSeparatedSubsetSums.Adaptive147Third138State
import NineSeparatedSubsetSums.Adaptive147Third138Leaves3
import NineSeparatedSubsetSums.Adaptive147Third138Leaves19
import NineSeparatedSubsetSums.Adaptive147Third138Leaves18
import NineSeparatedSubsetSums.Adaptive147Third138Leaves15
import NineSeparatedSubsetSums.Adaptive147Third138Leaves17
import NineSeparatedSubsetSums.Adaptive147Third138Leaves16
import NineSeparatedSubsetSums.Adaptive147Third138Leaves2
import NineSeparatedSubsetSums.Adaptive147Third138Leaves14
import NineSeparatedSubsetSums.Adaptive147Third138Leaves13
import NineSeparatedSubsetSums.Adaptive147Third138Leaves9
import NineSeparatedSubsetSums.Adaptive147Third138Leaves12
import NineSeparatedSubsetSums.Adaptive147Third138Leaves6
import NineSeparatedSubsetSums.Adaptive147Third138Leaves7
import NineSeparatedSubsetSums.Adaptive147Third138Leaves0
import NineSeparatedSubsetSums.Adaptive147Third138Leaves8
import NineSeparatedSubsetSums.Adaptive147Third138Leaves11
import NineSeparatedSubsetSums.Adaptive147Third138Leaves5
import NineSeparatedSubsetSums.Adaptive147Third138Leaves10
import NineSeparatedSubsetSums.Adaptive147Third138Leaves4
import NineSeparatedSubsetSums.Adaptive147Third138Leaves1

namespace NineSeparatedSubsetSums

theorem adaptive147Third138Proof20 : runCachedNode 511 130657 Adaptive147Third138Node20 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130657 Adaptive147Third138Node20 = [104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 121, 122, 123, 124, 125, 126, 127] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive147Third138Proof21
  · exact adaptive147Third138Proof22
  · exact adaptive147Third138Proof23
  · exact adaptive147Third138Proof24
  · exact adaptive147Third138Proof25
  · exact adaptive147Third138Proof26
  · exact adaptive147Third138Proof27
  · exact adaptive147Third138Proof28
  · exact adaptive147Third138Proof29
  · exact adaptive147Third138Proof30
  · exact adaptive147Third138Proof31
  · exact adaptive147Third138Proof32
  · exact adaptive147Third138Proof33
  · exact adaptive147Third138Proof34
  · exact adaptive147Third138Proof35
  · exact adaptive147Third138Proof36
  · exact adaptive147Third138Proof37
  · exact adaptive147Third138Proof38
  · exact adaptive147Third138Proof39
  · exact adaptive147Third138Proof40
  · exact adaptive147Third138Proof41
  · exact adaptive147Third138Proof42

#print axioms adaptive147Third138Proof20

theorem adaptive147Third138Proof43 : runCachedNode 511 130657 Adaptive147Third138Node43 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130657 Adaptive147Third138Node43 = [104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 122, 123, 124, 125, 126, 127, 128] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive147Third138Proof44
  · exact adaptive147Third138Proof45
  · exact adaptive147Third138Proof46
  · exact adaptive147Third138Proof47
  · exact adaptive147Third138Proof48
  · exact adaptive147Third138Proof49
  · exact adaptive147Third138Proof50
  · exact adaptive147Third138Proof51
  · exact adaptive147Third138Proof52
  · exact adaptive147Third138Proof53
  · exact adaptive147Third138Proof54
  · exact adaptive147Third138Proof55
  · exact adaptive147Third138Proof56
  · exact adaptive147Third138Proof57
  · exact adaptive147Third138Proof58
  · exact adaptive147Third138Proof59
  · exact adaptive147Third138Proof60
  · exact adaptive147Third138Proof61
  · exact adaptive147Third138Proof62
  · exact adaptive147Third138Proof63
  · exact adaptive147Third138Proof64
  · exact adaptive147Third138Proof65
  · exact adaptive147Third138Proof66

#print axioms adaptive147Third138Proof43

theorem adaptive147Third138Proof67 : runCachedNode 511 130657 Adaptive147Third138Node67 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130657 Adaptive147Third138Node67 = [103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 123, 124, 125, 126, 127, 128, 129] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive147Third138Proof68
  · exact adaptive147Third138Proof69
  · exact adaptive147Third138Proof70
  · exact adaptive147Third138Proof71
  · exact adaptive147Third138Proof72
  · exact adaptive147Third138Proof73
  · exact adaptive147Third138Proof74
  · exact adaptive147Third138Proof75
  · exact adaptive147Third138Proof76
  · exact adaptive147Third138Proof77
  · exact adaptive147Third138Proof78
  · exact adaptive147Third138Proof79
  · exact adaptive147Third138Proof80
  · exact adaptive147Third138Proof81
  · exact adaptive147Third138Proof82
  · exact adaptive147Third138Proof83
  · exact adaptive147Third138Proof84
  · exact adaptive147Third138Proof85
  · exact adaptive147Third138Proof86
  · exact adaptive147Third138Proof87
  · exact adaptive147Third138Proof88
  · exact adaptive147Third138Proof89
  · exact adaptive147Third138Proof90
  · exact adaptive147Third138Proof91
  · exact adaptive147Third138Proof92

#print axioms adaptive147Third138Proof67

theorem adaptive147Third138Proof93 : runCachedNode 511 130657 Adaptive147Third138Node93 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130657 Adaptive147Third138Node93 = [103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 124, 125, 126, 127, 128, 129, 130] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive147Third138Proof94
  · exact adaptive147Third138Proof95
  · exact adaptive147Third138Proof96
  · exact adaptive147Third138Proof97
  · exact adaptive147Third138Proof98
  · exact adaptive147Third138Proof99
  · exact adaptive147Third138Proof100
  · exact adaptive147Third138Proof101
  · exact adaptive147Third138Proof102
  · exact adaptive147Third138Proof103
  · exact adaptive147Third138Proof104
  · exact adaptive147Third138Proof105
  · exact adaptive147Third138Proof106
  · exact adaptive147Third138Proof107
  · exact adaptive147Third138Proof108
  · exact adaptive147Third138Proof109
  · exact adaptive147Third138Proof110
  · exact adaptive147Third138Proof111
  · exact adaptive147Third138Proof112
  · exact adaptive147Third138Proof113
  · exact adaptive147Third138Proof114
  · exact adaptive147Third138Proof115
  · exact adaptive147Third138Proof116
  · exact adaptive147Third138Proof117
  · exact adaptive147Third138Proof118
  · exact adaptive147Third138Proof119

#print axioms adaptive147Third138Proof93

theorem adaptive147Third138Proof120 : runCachedNode 511 130657 Adaptive147Third138Node120 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130657 Adaptive147Third138Node120 = [103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 125, 126, 127, 128, 129, 130, 131] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive147Third138Proof121
  · exact adaptive147Third138Proof122
  · exact adaptive147Third138Proof123
  · exact adaptive147Third138Proof124
  · exact adaptive147Third138Proof125
  · exact adaptive147Third138Proof126
  · exact adaptive147Third138Proof127
  · exact adaptive147Third138Proof128
  · exact adaptive147Third138Proof129
  · exact adaptive147Third138Proof130
  · exact adaptive147Third138Proof131
  · exact adaptive147Third138Proof132
  · exact adaptive147Third138Proof133
  · exact adaptive147Third138Proof134
  · exact adaptive147Third138Proof135
  · exact adaptive147Third138Proof136
  · exact adaptive147Third138Proof137
  · exact adaptive147Third138Proof138
  · exact adaptive147Third138Proof139
  · exact adaptive147Third138Proof140
  · exact adaptive147Third138Proof141
  · exact adaptive147Third138Proof142
  · exact adaptive147Third138Proof143
  · exact adaptive147Third138Proof144
  · exact adaptive147Third138Proof145
  · exact adaptive147Third138Proof146
  · exact adaptive147Third138Proof147

#print axioms adaptive147Third138Proof120

theorem adaptive147Third138Proof148 : runCachedNode 511 130657 Adaptive147Third138Node148 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130657 Adaptive147Third138Node148 = [103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 126, 127, 128, 129, 130, 131, 132] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive147Third138Proof149
  · exact adaptive147Third138Proof150
  · exact adaptive147Third138Proof151
  · exact adaptive147Third138Proof152
  · exact adaptive147Third138Proof153
  · exact adaptive147Third138Proof154
  · exact adaptive147Third138Proof155
  · exact adaptive147Third138Proof156
  · exact adaptive147Third138Proof157
  · exact adaptive147Third138Proof158
  · exact adaptive147Third138Proof159
  · exact adaptive147Third138Proof160
  · exact adaptive147Third138Proof161
  · exact adaptive147Third138Proof162
  · exact adaptive147Third138Proof163
  · exact adaptive147Third138Proof164
  · exact adaptive147Third138Proof165
  · exact adaptive147Third138Proof166
  · exact adaptive147Third138Proof167
  · exact adaptive147Third138Proof168
  · exact adaptive147Third138Proof169
  · exact adaptive147Third138Proof170
  · exact adaptive147Third138Proof171
  · exact adaptive147Third138Proof172
  · exact adaptive147Third138Proof173
  · exact adaptive147Third138Proof174
  · exact adaptive147Third138Proof175
  · exact adaptive147Third138Proof176

#print axioms adaptive147Third138Proof148

theorem adaptive147Third138Proof177 : runCachedNode 511 130657 Adaptive147Third138Node177 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130657 Adaptive147Third138Node177 = [102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 127, 128, 129, 130, 131, 132, 133] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive147Third138Proof178
  · exact adaptive147Third138Proof179
  · exact adaptive147Third138Proof180
  · exact adaptive147Third138Proof181
  · exact adaptive147Third138Proof182
  · exact adaptive147Third138Proof183
  · exact adaptive147Third138Proof184
  · exact adaptive147Third138Proof185
  · exact adaptive147Third138Proof186
  · exact adaptive147Third138Proof187
  · exact adaptive147Third138Proof188
  · exact adaptive147Third138Proof189
  · exact adaptive147Third138Proof190
  · exact adaptive147Third138Proof191
  · exact adaptive147Third138Proof192
  · exact adaptive147Third138Proof193
  · exact adaptive147Third138Proof194
  · exact adaptive147Third138Proof195
  · exact adaptive147Third138Proof196
  · exact adaptive147Third138Proof197
  · exact adaptive147Third138Proof198
  · exact adaptive147Third138Proof199
  · exact adaptive147Third138Proof200
  · exact adaptive147Third138Proof201
  · exact adaptive147Third138Proof202
  · exact adaptive147Third138Proof203
  · exact adaptive147Third138Proof204
  · exact adaptive147Third138Proof205
  · exact adaptive147Third138Proof206
  · exact adaptive147Third138Proof207

#print axioms adaptive147Third138Proof177

theorem adaptive147Third138Proof208 : runCachedNode 511 130657 Adaptive147Third138Node208 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130657 Adaptive147Third138Node208 = [102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 128, 129, 130, 131, 132, 133, 134] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive147Third138Proof209
  · exact adaptive147Third138Proof210
  · exact adaptive147Third138Proof211
  · exact adaptive147Third138Proof212
  · exact adaptive147Third138Proof213
  · exact adaptive147Third138Proof214
  · exact adaptive147Third138Proof215
  · exact adaptive147Third138Proof216
  · exact adaptive147Third138Proof217
  · exact adaptive147Third138Proof218
  · exact adaptive147Third138Proof219
  · exact adaptive147Third138Proof220
  · exact adaptive147Third138Proof221
  · exact adaptive147Third138Proof222
  · exact adaptive147Third138Proof223
  · exact adaptive147Third138Proof224
  · exact adaptive147Third138Proof225
  · exact adaptive147Third138Proof226
  · exact adaptive147Third138Proof227
  · exact adaptive147Third138Proof228
  · exact adaptive147Third138Proof229
  · exact adaptive147Third138Proof230
  · exact adaptive147Third138Proof231
  · exact adaptive147Third138Proof232
  · exact adaptive147Third138Proof233
  · exact adaptive147Third138Proof234
  · exact adaptive147Third138Proof235
  · exact adaptive147Third138Proof236
  · exact adaptive147Third138Proof237
  · exact adaptive147Third138Proof238
  · exact adaptive147Third138Proof239

#print axioms adaptive147Third138Proof208

end NineSeparatedSubsetSums
