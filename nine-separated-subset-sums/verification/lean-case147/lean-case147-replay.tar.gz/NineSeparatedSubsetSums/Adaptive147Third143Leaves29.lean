import NineSeparatedSubsetSums.Adaptive147Third143State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third143Proof507 : runCachedNode 511 131344 Adaptive147Third143Node507 = false := by
  decide +kernel

#print axioms adaptive147Third143Proof507

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third143Proof133 : runCachedNode 511 131344 Adaptive147Third143Node133 = false := by
  decide +kernel

#print axioms adaptive147Third143Proof133

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third143Proof260 : runCachedNode 511 131344 Adaptive147Third143Node260 = false := by
  decide +kernel

#print axioms adaptive147Third143Proof260

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third143Proof342 : runCachedNode 511 131344 Adaptive147Third143Node342 = false := by
  decide +kernel

#print axioms adaptive147Third143Proof342

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third143Proof539 : runCachedNode 511 131344 Adaptive147Third143Node539 = false := by
  decide +kernel

#print axioms adaptive147Third143Proof539

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third143Proof6 : runCachedNode 511 131344 Adaptive147Third143Node6 = false := by
  decide +kernel

#print axioms adaptive147Third143Proof6

end NineSeparatedSubsetSums
