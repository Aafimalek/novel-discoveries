import NineSeparatedSubsetSums.Adaptive147Third142State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third142Proof431 : runCachedNode 511 131213 Adaptive147Third142Node431 = false := by
  decide +kernel

#print axioms adaptive147Third142Proof431

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third142Proof232 : runCachedNode 511 131213 Adaptive147Third142Node232 = false := by
  decide +kernel

#print axioms adaptive147Third142Proof232

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third142Proof46 : runCachedNode 511 131213 Adaptive147Third142Node46 = false := by
  decide +kernel

#print axioms adaptive147Third142Proof46

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third142Proof308 : runCachedNode 511 131213 Adaptive147Third142Node308 = false := by
  decide +kernel

#print axioms adaptive147Third142Proof308

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third142Proof72 : runCachedNode 511 131213 Adaptive147Third142Node72 = false := by
  decide +kernel

#print axioms adaptive147Third142Proof72

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third142Proof102 : runCachedNode 511 131213 Adaptive147Third142Node102 = false := by
  decide +kernel

#print axioms adaptive147Third142Proof102

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third142Proof307 : runCachedNode 511 131213 Adaptive147Third142Node307 = false := by
  decide +kernel

#print axioms adaptive147Third142Proof307

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third142Proof101 : runCachedNode 511 131213 Adaptive147Third142Node101 = false := by
  decide +kernel

#print axioms adaptive147Third142Proof101

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third142Proof43 : runCachedNode 511 131213 Adaptive147Third142Node43 = false := by
  decide +kernel

#print axioms adaptive147Third142Proof43

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third142Proof130 : runCachedNode 511 131213 Adaptive147Third142Node130 = false := by
  decide +kernel

#print axioms adaptive147Third142Proof130

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third142Proof350 : runCachedNode 511 131213 Adaptive147Third142Node350 = false := by
  decide +kernel

#print axioms adaptive147Third142Proof350

end NineSeparatedSubsetSums
