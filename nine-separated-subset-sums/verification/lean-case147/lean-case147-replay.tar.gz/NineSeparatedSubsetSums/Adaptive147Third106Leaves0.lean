import NineSeparatedSubsetSums.Adaptive147Third106State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third106Proof0 : runCachedNode 511 112835 Adaptive147Third106Node0 = false := by
  decide +kernel

#print axioms adaptive147Third106Proof0

end NineSeparatedSubsetSums
