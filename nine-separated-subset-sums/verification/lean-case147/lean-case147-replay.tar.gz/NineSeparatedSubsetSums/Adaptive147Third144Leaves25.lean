import NineSeparatedSubsetSums.Adaptive147Third144State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof76 : runCachedNode 511 131483 Adaptive147Third144Node76 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof76

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof456 : runCachedNode 511 131483 Adaptive147Third144Node456 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof456

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof199 : runCachedNode 511 131483 Adaptive147Third144Node199 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof199

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof67 : runCachedNode 511 131483 Adaptive147Third144Node67 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof67

end NineSeparatedSubsetSums
