import NineSeparatedSubsetSums.Adaptive147Third144State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof415 : runCachedNode 511 131483 Adaptive147Third144Node415 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof415

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof813 : runCachedNode 511 131483 Adaptive147Third144Node813 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof813

end NineSeparatedSubsetSums
