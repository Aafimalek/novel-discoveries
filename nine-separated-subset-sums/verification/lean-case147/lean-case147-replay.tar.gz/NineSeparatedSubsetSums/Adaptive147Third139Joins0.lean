import NineSeparatedSubsetSums.Adaptive147Third139State
import NineSeparatedSubsetSums.Adaptive147Third139Leaves15
import NineSeparatedSubsetSums.Adaptive147Third139Leaves12
import NineSeparatedSubsetSums.Adaptive147Third139Leaves16
import NineSeparatedSubsetSums.Adaptive147Third139Leaves22
import NineSeparatedSubsetSums.Adaptive147Third139Leaves21
import NineSeparatedSubsetSums.Adaptive147Third139Leaves20
import NineSeparatedSubsetSums.Adaptive147Third139Leaves19
import NineSeparatedSubsetSums.Adaptive147Third139Leaves17
import NineSeparatedSubsetSums.Adaptive147Third139Leaves18
import NineSeparatedSubsetSums.Adaptive147Third139Leaves7
import NineSeparatedSubsetSums.Adaptive147Third139Leaves14
import NineSeparatedSubsetSums.Adaptive147Third139Leaves13
import NineSeparatedSubsetSums.Adaptive147Third139Leaves23
import NineSeparatedSubsetSums.Adaptive147Third139Leaves1
import NineSeparatedSubsetSums.Adaptive147Third139Leaves8
import NineSeparatedSubsetSums.Adaptive147Third139Leaves6
import NineSeparatedSubsetSums.Adaptive147Third139Leaves0
import NineSeparatedSubsetSums.Adaptive147Third139Leaves11
import NineSeparatedSubsetSums.Adaptive147Third139Leaves10
import NineSeparatedSubsetSums.Adaptive147Third139Leaves4
import NineSeparatedSubsetSums.Adaptive147Third139Leaves9
import NineSeparatedSubsetSums.Adaptive147Third139Leaves2
import NineSeparatedSubsetSums.Adaptive147Third139Leaves5
import NineSeparatedSubsetSums.Adaptive147Third139Leaves3

namespace NineSeparatedSubsetSums

theorem adaptive147Third139Proof22 : runCachedNode 511 130807 Adaptive147Third139Node22 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130807 Adaptive147Third139Node22 = [104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 123, 124, 125, 126, 127, 128] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive147Third139Proof23
  · exact adaptive147Third139Proof24
  · exact adaptive147Third139Proof25
  · exact adaptive147Third139Proof26
  · exact adaptive147Third139Proof27
  · exact adaptive147Third139Proof28
  · exact adaptive147Third139Proof29
  · exact adaptive147Third139Proof30
  · exact adaptive147Third139Proof31
  · exact adaptive147Third139Proof32
  · exact adaptive147Third139Proof33
  · exact adaptive147Third139Proof34
  · exact adaptive147Third139Proof35
  · exact adaptive147Third139Proof36
  · exact adaptive147Third139Proof37
  · exact adaptive147Third139Proof38
  · exact adaptive147Third139Proof39
  · exact adaptive147Third139Proof40
  · exact adaptive147Third139Proof41
  · exact adaptive147Third139Proof42
  · exact adaptive147Third139Proof43
  · exact adaptive147Third139Proof44
  · exact adaptive147Third139Proof45

#print axioms adaptive147Third139Proof22

theorem adaptive147Third139Proof46 : runCachedNode 511 130807 Adaptive147Third139Node46 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130807 Adaptive147Third139Node46 = [103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 124, 125, 126, 127, 128, 129] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive147Third139Proof47
  · exact adaptive147Third139Proof48
  · exact adaptive147Third139Proof49
  · exact adaptive147Third139Proof50
  · exact adaptive147Third139Proof51
  · exact adaptive147Third139Proof52
  · exact adaptive147Third139Proof53
  · exact adaptive147Third139Proof54
  · exact adaptive147Third139Proof55
  · exact adaptive147Third139Proof56
  · exact adaptive147Third139Proof57
  · exact adaptive147Third139Proof58
  · exact adaptive147Third139Proof59
  · exact adaptive147Third139Proof60
  · exact adaptive147Third139Proof61
  · exact adaptive147Third139Proof62
  · exact adaptive147Third139Proof63
  · exact adaptive147Third139Proof64
  · exact adaptive147Third139Proof65
  · exact adaptive147Third139Proof66
  · exact adaptive147Third139Proof67
  · exact adaptive147Third139Proof68
  · exact adaptive147Third139Proof69
  · exact adaptive147Third139Proof70
  · exact adaptive147Third139Proof71

#print axioms adaptive147Third139Proof46

theorem adaptive147Third139Proof72 : runCachedNode 511 130807 Adaptive147Third139Node72 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130807 Adaptive147Third139Node72 = [103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 125, 126, 127, 128, 129, 130] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive147Third139Proof73
  · exact adaptive147Third139Proof74
  · exact adaptive147Third139Proof75
  · exact adaptive147Third139Proof76
  · exact adaptive147Third139Proof77
  · exact adaptive147Third139Proof78
  · exact adaptive147Third139Proof79
  · exact adaptive147Third139Proof80
  · exact adaptive147Third139Proof81
  · exact adaptive147Third139Proof82
  · exact adaptive147Third139Proof83
  · exact adaptive147Third139Proof84
  · exact adaptive147Third139Proof85
  · exact adaptive147Third139Proof86
  · exact adaptive147Third139Proof87
  · exact adaptive147Third139Proof88
  · exact adaptive147Third139Proof89
  · exact adaptive147Third139Proof90
  · exact adaptive147Third139Proof91
  · exact adaptive147Third139Proof92
  · exact adaptive147Third139Proof93
  · exact adaptive147Third139Proof94
  · exact adaptive147Third139Proof95
  · exact adaptive147Third139Proof96
  · exact adaptive147Third139Proof97
  · exact adaptive147Third139Proof98

#print axioms adaptive147Third139Proof72

theorem adaptive147Third139Proof99 : runCachedNode 511 130807 Adaptive147Third139Node99 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130807 Adaptive147Third139Node99 = [103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 126, 127, 128, 129, 130, 131] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive147Third139Proof100
  · exact adaptive147Third139Proof101
  · exact adaptive147Third139Proof102
  · exact adaptive147Third139Proof103
  · exact adaptive147Third139Proof104
  · exact adaptive147Third139Proof105
  · exact adaptive147Third139Proof106
  · exact adaptive147Third139Proof107
  · exact adaptive147Third139Proof108
  · exact adaptive147Third139Proof109
  · exact adaptive147Third139Proof110
  · exact adaptive147Third139Proof111
  · exact adaptive147Third139Proof112
  · exact adaptive147Third139Proof113
  · exact adaptive147Third139Proof114
  · exact adaptive147Third139Proof115
  · exact adaptive147Third139Proof116
  · exact adaptive147Third139Proof117
  · exact adaptive147Third139Proof118
  · exact adaptive147Third139Proof119
  · exact adaptive147Third139Proof120
  · exact adaptive147Third139Proof121
  · exact adaptive147Third139Proof122
  · exact adaptive147Third139Proof123
  · exact adaptive147Third139Proof124
  · exact adaptive147Third139Proof125
  · exact adaptive147Third139Proof126

#print axioms adaptive147Third139Proof99

theorem adaptive147Third139Proof127 : runCachedNode 511 130807 Adaptive147Third139Node127 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130807 Adaptive147Third139Node127 = [103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 127, 128, 129, 130, 131, 132] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive147Third139Proof128
  · exact adaptive147Third139Proof129
  · exact adaptive147Third139Proof130
  · exact adaptive147Third139Proof131
  · exact adaptive147Third139Proof132
  · exact adaptive147Third139Proof133
  · exact adaptive147Third139Proof134
  · exact adaptive147Third139Proof135
  · exact adaptive147Third139Proof136
  · exact adaptive147Third139Proof137
  · exact adaptive147Third139Proof138
  · exact adaptive147Third139Proof139
  · exact adaptive147Third139Proof140
  · exact adaptive147Third139Proof141
  · exact adaptive147Third139Proof142
  · exact adaptive147Third139Proof143
  · exact adaptive147Third139Proof144
  · exact adaptive147Third139Proof145
  · exact adaptive147Third139Proof146
  · exact adaptive147Third139Proof147
  · exact adaptive147Third139Proof148
  · exact adaptive147Third139Proof149
  · exact adaptive147Third139Proof150
  · exact adaptive147Third139Proof151
  · exact adaptive147Third139Proof152
  · exact adaptive147Third139Proof153
  · exact adaptive147Third139Proof154
  · exact adaptive147Third139Proof155

#print axioms adaptive147Third139Proof127

theorem adaptive147Third139Proof156 : runCachedNode 511 130807 Adaptive147Third139Node156 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130807 Adaptive147Third139Node156 = [102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 128, 129, 130, 131, 132, 133] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive147Third139Proof157
  · exact adaptive147Third139Proof158
  · exact adaptive147Third139Proof159
  · exact adaptive147Third139Proof160
  · exact adaptive147Third139Proof161
  · exact adaptive147Third139Proof162
  · exact adaptive147Third139Proof163
  · exact adaptive147Third139Proof164
  · exact adaptive147Third139Proof165
  · exact adaptive147Third139Proof166
  · exact adaptive147Third139Proof167
  · exact adaptive147Third139Proof168
  · exact adaptive147Third139Proof169
  · exact adaptive147Third139Proof170
  · exact adaptive147Third139Proof171
  · exact adaptive147Third139Proof172
  · exact adaptive147Third139Proof173
  · exact adaptive147Third139Proof174
  · exact adaptive147Third139Proof175
  · exact adaptive147Third139Proof176
  · exact adaptive147Third139Proof177
  · exact adaptive147Third139Proof178
  · exact adaptive147Third139Proof179
  · exact adaptive147Third139Proof180
  · exact adaptive147Third139Proof181
  · exact adaptive147Third139Proof182
  · exact adaptive147Third139Proof183
  · exact adaptive147Third139Proof184
  · exact adaptive147Third139Proof185
  · exact adaptive147Third139Proof186

#print axioms adaptive147Third139Proof156

theorem adaptive147Third139Proof187 : runCachedNode 511 130807 Adaptive147Third139Node187 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130807 Adaptive147Third139Node187 = [102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 129, 130, 131, 132, 133, 134] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive147Third139Proof188
  · exact adaptive147Third139Proof189
  · exact adaptive147Third139Proof190
  · exact adaptive147Third139Proof191
  · exact adaptive147Third139Proof192
  · exact adaptive147Third139Proof193
  · exact adaptive147Third139Proof194
  · exact adaptive147Third139Proof195
  · exact adaptive147Third139Proof196
  · exact adaptive147Third139Proof197
  · exact adaptive147Third139Proof198
  · exact adaptive147Third139Proof199
  · exact adaptive147Third139Proof200
  · exact adaptive147Third139Proof201
  · exact adaptive147Third139Proof202
  · exact adaptive147Third139Proof203
  · exact adaptive147Third139Proof204
  · exact adaptive147Third139Proof205
  · exact adaptive147Third139Proof206
  · exact adaptive147Third139Proof207
  · exact adaptive147Third139Proof208
  · exact adaptive147Third139Proof209
  · exact adaptive147Third139Proof210
  · exact adaptive147Third139Proof211
  · exact adaptive147Third139Proof212
  · exact adaptive147Third139Proof213
  · exact adaptive147Third139Proof214
  · exact adaptive147Third139Proof215
  · exact adaptive147Third139Proof216
  · exact adaptive147Third139Proof217
  · exact adaptive147Third139Proof218

#print axioms adaptive147Third139Proof187

theorem adaptive147Third139Proof219 : runCachedNode 511 130807 Adaptive147Third139Node219 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130807 Adaptive147Third139Node219 = [102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 130, 131, 132, 133, 134, 135] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive147Third139Proof220
  · exact adaptive147Third139Proof221
  · exact adaptive147Third139Proof222
  · exact adaptive147Third139Proof223
  · exact adaptive147Third139Proof224
  · exact adaptive147Third139Proof225
  · exact adaptive147Third139Proof226
  · exact adaptive147Third139Proof227
  · exact adaptive147Third139Proof228
  · exact adaptive147Third139Proof229
  · exact adaptive147Third139Proof230
  · exact adaptive147Third139Proof231
  · exact adaptive147Third139Proof232
  · exact adaptive147Third139Proof233
  · exact adaptive147Third139Proof234
  · exact adaptive147Third139Proof235
  · exact adaptive147Third139Proof236
  · exact adaptive147Third139Proof237
  · exact adaptive147Third139Proof238
  · exact adaptive147Third139Proof239
  · exact adaptive147Third139Proof240
  · exact adaptive147Third139Proof241
  · exact adaptive147Third139Proof242
  · exact adaptive147Third139Proof243
  · exact adaptive147Third139Proof244
  · exact adaptive147Third139Proof245
  · exact adaptive147Third139Proof246
  · exact adaptive147Third139Proof247
  · exact adaptive147Third139Proof248
  · exact adaptive147Third139Proof249
  · exact adaptive147Third139Proof250
  · exact adaptive147Third139Proof251

#print axioms adaptive147Third139Proof219

end NineSeparatedSubsetSums
