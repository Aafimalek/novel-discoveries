import NineSeparatedSubsetSums.Adaptive147Third144State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof613 : runCachedNode 511 131483 Adaptive147Third144Node613 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof613

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof225 : runCachedNode 511 131483 Adaptive147Third144Node225 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof225

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof191 : runCachedNode 511 131483 Adaptive147Third144Node191 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof191

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof368 : runCachedNode 511 131483 Adaptive147Third144Node368 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof368

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof519 : runCachedNode 511 131483 Adaptive147Third144Node519 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof519

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof324 : runCachedNode 511 131483 Adaptive147Third144Node324 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof324

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof412 : runCachedNode 511 131483 Adaptive147Third144Node412 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof412

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof408 : runCachedNode 511 131483 Adaptive147Third144Node408 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof408

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof496 : runCachedNode 511 131483 Adaptive147Third144Node496 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof496

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof726 : runCachedNode 511 131483 Adaptive147Third144Node726 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof726

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof291 : runCachedNode 511 131483 Adaptive147Third144Node291 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof291

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof787 : runCachedNode 511 131483 Adaptive147Third144Node787 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof787

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof830 : runCachedNode 511 131483 Adaptive147Third144Node830 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof830

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof82 : runCachedNode 511 131483 Adaptive147Third144Node82 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof82

end NineSeparatedSubsetSums
