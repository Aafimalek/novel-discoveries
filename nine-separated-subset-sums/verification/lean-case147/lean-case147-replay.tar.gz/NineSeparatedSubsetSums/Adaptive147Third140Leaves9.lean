import NineSeparatedSubsetSums.Adaptive147Third140State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third140Proof20 : runCachedNode 511 130945 Adaptive147Third140Node20 = false := by
  decide +kernel

#print axioms adaptive147Third140Proof20

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third140Proof263 : runCachedNode 511 130945 Adaptive147Third140Node263 = false := by
  decide +kernel

#print axioms adaptive147Third140Proof263

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third140Proof78 : runCachedNode 511 130945 Adaptive147Third140Node78 = false := by
  decide +kernel

#print axioms adaptive147Third140Proof78

end NineSeparatedSubsetSums
