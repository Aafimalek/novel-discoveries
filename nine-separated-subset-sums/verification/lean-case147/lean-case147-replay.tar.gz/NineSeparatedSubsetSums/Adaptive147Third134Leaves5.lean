import NineSeparatedSubsetSums.Adaptive147Third134State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third134Proof15 : runCachedNode 511 130034 Adaptive147Third134Node15 = false := by
  decide +kernel

#print axioms adaptive147Third134Proof15

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third134Proof13 : runCachedNode 511 130034 Adaptive147Third134Node13 = false := by
  decide +kernel

#print axioms adaptive147Third134Proof13

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third134Proof12 : runCachedNode 511 130034 Adaptive147Third134Node12 = false := by
  decide +kernel

#print axioms adaptive147Third134Proof12

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third134Proof46 : runCachedNode 511 130034 Adaptive147Third134Node46 = false := by
  decide +kernel

#print axioms adaptive147Third134Proof46

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third134Proof11 : runCachedNode 511 130034 Adaptive147Third134Node11 = false := by
  decide +kernel

#print axioms adaptive147Third134Proof11

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third134Proof44 : runCachedNode 511 130034 Adaptive147Third134Node44 = false := by
  decide +kernel

#print axioms adaptive147Third134Proof44

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third134Proof6 : runCachedNode 511 130034 Adaptive147Third134Node6 = false := by
  decide +kernel

#print axioms adaptive147Third134Proof6

end NineSeparatedSubsetSums
