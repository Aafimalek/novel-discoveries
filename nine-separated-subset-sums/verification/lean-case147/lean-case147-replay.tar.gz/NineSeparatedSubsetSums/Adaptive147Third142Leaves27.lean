import NineSeparatedSubsetSums.Adaptive147Third142State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third142Proof106 : runCachedNode 511 131213 Adaptive147Third142Node106 = false := by
  decide +kernel

#print axioms adaptive147Third142Proof106

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third142Proof14 : runCachedNode 511 131213 Adaptive147Third142Node14 = false := by
  decide +kernel

#print axioms adaptive147Third142Proof14

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third142Proof76 : runCachedNode 511 131213 Adaptive147Third142Node76 = false := by
  decide +kernel

#print axioms adaptive147Third142Proof76

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third142Proof78 : runCachedNode 511 131213 Adaptive147Third142Node78 = false := by
  decide +kernel

#print axioms adaptive147Third142Proof78

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third142Proof163 : runCachedNode 511 131213 Adaptive147Third142Node163 = false := by
  decide +kernel

#print axioms adaptive147Third142Proof163

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third142Proof376 : runCachedNode 511 131213 Adaptive147Third142Node376 = false := by
  decide +kernel

#print axioms adaptive147Third142Proof376

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third142Proof177 : runCachedNode 511 131213 Adaptive147Third142Node177 = false := by
  decide +kernel

#print axioms adaptive147Third142Proof177

end NineSeparatedSubsetSums
