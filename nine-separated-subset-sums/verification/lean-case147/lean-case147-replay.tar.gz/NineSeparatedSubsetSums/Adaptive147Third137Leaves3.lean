import NineSeparatedSubsetSums.Adaptive147Third137State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third137Proof183 : runCachedNode 511 130518 Adaptive147Third137Node183 = false := by
  decide +kernel

#print axioms adaptive147Third137Proof183

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third137Proof16 : runCachedNode 511 130518 Adaptive147Third137Node16 = false := by
  decide +kernel

#print axioms adaptive147Third137Proof16

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third137Proof174 : runCachedNode 511 130518 Adaptive147Third137Node174 = false := by
  decide +kernel

#print axioms adaptive147Third137Proof174

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third137Proof1 : runCachedNode 511 130518 Adaptive147Third137Node1 = false := by
  decide +kernel

#print axioms adaptive147Third137Proof1

end NineSeparatedSubsetSums
