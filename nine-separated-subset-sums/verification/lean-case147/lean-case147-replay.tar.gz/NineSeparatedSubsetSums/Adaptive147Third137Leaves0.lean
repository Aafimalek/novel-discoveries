import NineSeparatedSubsetSums.Adaptive147Third137State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third137Proof20 : runCachedNode 511 130518 Adaptive147Third137Node20 = false := by
  decide +kernel

#print axioms adaptive147Third137Proof20

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third137Proof181 : runCachedNode 511 130518 Adaptive147Third137Node181 = false := by
  decide +kernel

#print axioms adaptive147Third137Proof181

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third137Proof105 : runCachedNode 511 130518 Adaptive147Third137Node105 = false := by
  decide +kernel

#print axioms adaptive147Third137Proof105

end NineSeparatedSubsetSums
