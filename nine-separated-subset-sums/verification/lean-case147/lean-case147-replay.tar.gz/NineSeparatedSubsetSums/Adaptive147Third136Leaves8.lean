import NineSeparatedSubsetSums.Adaptive147Third136State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third136Proof13 : runCachedNode 511 130369 Adaptive147Third136Node13 = false := by
  decide +kernel

#print axioms adaptive147Third136Proof13

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third136Proof46 : runCachedNode 511 130369 Adaptive147Third136Node46 = false := by
  decide +kernel

#print axioms adaptive147Third136Proof46

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third136Proof69 : runCachedNode 511 130369 Adaptive147Third136Node69 = false := by
  decide +kernel

#print axioms adaptive147Third136Proof69

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third136Proof12 : runCachedNode 511 130369 Adaptive147Third136Node12 = false := by
  decide +kernel

#print axioms adaptive147Third136Proof12

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third136Proof124 : runCachedNode 511 130369 Adaptive147Third136Node124 = false := by
  decide +kernel

#print axioms adaptive147Third136Proof124

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third136Proof68 : runCachedNode 511 130369 Adaptive147Third136Node68 = false := by
  decide +kernel

#print axioms adaptive147Third136Proof68

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third136Proof95 : runCachedNode 511 130369 Adaptive147Third136Node95 = false := by
  decide +kernel

#print axioms adaptive147Third136Proof95

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third136Proof44 : runCachedNode 511 130369 Adaptive147Third136Node44 = false := by
  decide +kernel

#print axioms adaptive147Third136Proof44

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third136Proof64 : runCachedNode 511 130369 Adaptive147Third136Node64 = false := by
  decide +kernel

#print axioms adaptive147Third136Proof64

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third136Proof51 : runCachedNode 511 130369 Adaptive147Third136Node51 = false := by
  decide +kernel

#print axioms adaptive147Third136Proof51

end NineSeparatedSubsetSums
