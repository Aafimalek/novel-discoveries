import NineSeparatedSubsetSums.Adaptive147Third136State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third136Proof17 : runCachedNode 511 130369 Adaptive147Third136Node17 = false := by
  decide +kernel

#print axioms adaptive147Third136Proof17

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third136Proof18 : runCachedNode 511 130369 Adaptive147Third136Node18 = false := by
  decide +kernel

#print axioms adaptive147Third136Proof18

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third136Proof66 : runCachedNode 511 130369 Adaptive147Third136Node66 = false := by
  decide +kernel

#print axioms adaptive147Third136Proof66

end NineSeparatedSubsetSums
