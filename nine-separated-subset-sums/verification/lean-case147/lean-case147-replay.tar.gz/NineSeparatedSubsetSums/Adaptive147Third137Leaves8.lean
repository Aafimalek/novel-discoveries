import NineSeparatedSubsetSums.Adaptive147Third137State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third137Proof67 : runCachedNode 511 130518 Adaptive147Third137Node67 = false := by
  decide +kernel

#print axioms adaptive147Third137Proof67

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third137Proof122 : runCachedNode 511 130518 Adaptive147Third137Node122 = false := by
  decide +kernel

#print axioms adaptive147Third137Proof122

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third137Proof124 : runCachedNode 511 130518 Adaptive147Third137Node124 = false := by
  decide +kernel

#print axioms adaptive147Third137Proof124

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third137Proof151 : runCachedNode 511 130518 Adaptive147Third137Node151 = false := by
  decide +kernel

#print axioms adaptive147Third137Proof151

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third137Proof95 : runCachedNode 511 130518 Adaptive147Third137Node95 = false := by
  decide +kernel

#print axioms adaptive147Third137Proof95

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third137Proof10 : runCachedNode 511 130518 Adaptive147Third137Node10 = false := by
  decide +kernel

#print axioms adaptive147Third137Proof10

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third137Proof31 : runCachedNode 511 130518 Adaptive147Third137Node31 = false := by
  decide +kernel

#print axioms adaptive147Third137Proof31

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third137Proof98 : runCachedNode 511 130518 Adaptive147Third137Node98 = false := by
  decide +kernel

#print axioms adaptive147Third137Proof98

end NineSeparatedSubsetSums
