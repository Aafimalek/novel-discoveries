import NineSeparatedSubsetSums.Adaptive147Third144State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof266 : runCachedNode 511 131483 Adaptive147Third144Node266 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof266

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof233 : runCachedNode 511 131483 Adaptive147Third144Node233 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof233

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof196 : runCachedNode 511 131483 Adaptive147Third144Node196 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof196

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof54 : runCachedNode 511 131483 Adaptive147Third144Node54 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof54

end NineSeparatedSubsetSums
