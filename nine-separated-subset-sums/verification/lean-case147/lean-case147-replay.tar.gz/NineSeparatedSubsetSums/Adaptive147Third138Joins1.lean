import NineSeparatedSubsetSums.Adaptive147Third138State
import NineSeparatedSubsetSums.Adaptive147Third138Leaves1
import NineSeparatedSubsetSums.Adaptive147Third138Leaves19
import NineSeparatedSubsetSums.Adaptive147Third138Leaves4
import NineSeparatedSubsetSums.Adaptive147Third138Leaves18
import NineSeparatedSubsetSums.Adaptive147Third138Leaves17
import NineSeparatedSubsetSums.Adaptive147Third138Leaves16
import NineSeparatedSubsetSums.Adaptive147Third138Leaves15
import NineSeparatedSubsetSums.Adaptive147Third138Leaves14
import NineSeparatedSubsetSums.Adaptive147Third138Leaves13
import NineSeparatedSubsetSums.Adaptive147Third138Leaves12
import NineSeparatedSubsetSums.Adaptive147Third138Leaves11
import NineSeparatedSubsetSums.Adaptive147Third138Leaves7
import NineSeparatedSubsetSums.Adaptive147Third138Leaves5
import NineSeparatedSubsetSums.Adaptive147Third138Leaves2
import NineSeparatedSubsetSums.Adaptive147Third138Leaves0
import NineSeparatedSubsetSums.Adaptive147Third138Joins0

namespace NineSeparatedSubsetSums

theorem adaptive147Third138Proof0 : runCachedNode 511 130657 Adaptive147Third138Node0 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130657 Adaptive147Third138Node0 = [110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 132, 133, 134, 135, 136] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive147Third138Proof1
  · exact adaptive147Third138Proof2
  · exact adaptive147Third138Proof3
  · exact adaptive147Third138Proof4
  · exact adaptive147Third138Proof5
  · exact adaptive147Third138Proof6
  · exact adaptive147Third138Proof7
  · exact adaptive147Third138Proof8
  · exact adaptive147Third138Proof9
  · exact adaptive147Third138Proof10
  · exact adaptive147Third138Proof11
  · exact adaptive147Third138Proof12
  · exact adaptive147Third138Proof13
  · exact adaptive147Third138Proof14
  · exact adaptive147Third138Proof15
  · exact adaptive147Third138Proof16
  · exact adaptive147Third138Proof17
  · exact adaptive147Third138Proof18
  · exact adaptive147Third138Proof19
  · exact adaptive147Third138Proof20
  · exact adaptive147Third138Proof43
  · exact adaptive147Third138Proof67
  · exact adaptive147Third138Proof93
  · exact adaptive147Third138Proof120
  · exact adaptive147Third138Proof148
  · exact adaptive147Third138Proof177
  · exact adaptive147Third138Proof208

#print axioms adaptive147Third138Proof0

end NineSeparatedSubsetSums
