import NineSeparatedSubsetSums.Adaptive147Third143State
import NineSeparatedSubsetSums.Adaptive147Third143Leaves12
import NineSeparatedSubsetSums.Adaptive147Third143Leaves5
import NineSeparatedSubsetSums.Adaptive147Third143Leaves50
import NineSeparatedSubsetSums.Adaptive147Third143Leaves17
import NineSeparatedSubsetSums.Adaptive147Third143Leaves49
import NineSeparatedSubsetSums.Adaptive147Third143Leaves25
import NineSeparatedSubsetSums.Adaptive147Third143Leaves47
import NineSeparatedSubsetSums.Adaptive147Third143Leaves14
import NineSeparatedSubsetSums.Adaptive147Third143Leaves46
import NineSeparatedSubsetSums.Adaptive147Third143Leaves45
import NineSeparatedSubsetSums.Adaptive147Third143Leaves33
import NineSeparatedSubsetSums.Adaptive147Third143Leaves44
import NineSeparatedSubsetSums.Adaptive147Third143Leaves42
import NineSeparatedSubsetSums.Adaptive147Third143Leaves41
import NineSeparatedSubsetSums.Adaptive147Third143Leaves40
import NineSeparatedSubsetSums.Adaptive147Third143Leaves39
import NineSeparatedSubsetSums.Adaptive147Third143Leaves2
import NineSeparatedSubsetSums.Adaptive147Third143Leaves35
import NineSeparatedSubsetSums.Adaptive147Third143Leaves26
import NineSeparatedSubsetSums.Adaptive147Third143Leaves31
import NineSeparatedSubsetSums.Adaptive147Third143Leaves4
import NineSeparatedSubsetSums.Adaptive147Third143Leaves16
import NineSeparatedSubsetSums.Adaptive147Third143Leaves22
import NineSeparatedSubsetSums.Adaptive147Third143Leaves8
import NineSeparatedSubsetSums.Adaptive147Third143Leaves10
import NineSeparatedSubsetSums.Adaptive147Third143Leaves28
import NineSeparatedSubsetSums.Adaptive147Third143Leaves48
import NineSeparatedSubsetSums.Adaptive147Third143Leaves43
import NineSeparatedSubsetSums.Adaptive147Third143Leaves32
import NineSeparatedSubsetSums.Adaptive147Third143Leaves37
import NineSeparatedSubsetSums.Adaptive147Third143Leaves21
import NineSeparatedSubsetSums.Adaptive147Third143Leaves27
import NineSeparatedSubsetSums.Adaptive147Third143Leaves38
import NineSeparatedSubsetSums.Adaptive147Third143Leaves6
import NineSeparatedSubsetSums.Adaptive147Third143Leaves30
import NineSeparatedSubsetSums.Adaptive147Third143Leaves20
import NineSeparatedSubsetSums.Adaptive147Third143Leaves51
import NineSeparatedSubsetSums.Adaptive147Third143Leaves7
import NineSeparatedSubsetSums.Adaptive147Third143Leaves34
import NineSeparatedSubsetSums.Adaptive147Third143Leaves23
import NineSeparatedSubsetSums.Adaptive147Third143Leaves19
import NineSeparatedSubsetSums.Adaptive147Third143Leaves36
import NineSeparatedSubsetSums.Adaptive147Third143Leaves29
import NineSeparatedSubsetSums.Adaptive147Third143Leaves9
import NineSeparatedSubsetSums.Adaptive147Third143Leaves3
import NineSeparatedSubsetSums.Adaptive147Third143Leaves52
import NineSeparatedSubsetSums.Adaptive147Third143Leaves24
import NineSeparatedSubsetSums.Adaptive147Third143Leaves18
import NineSeparatedSubsetSums.Adaptive147Third143Leaves11
import NineSeparatedSubsetSums.Adaptive147Third143Leaves13
import NineSeparatedSubsetSums.Adaptive147Third143Leaves1

namespace NineSeparatedSubsetSums

theorem adaptive147Third143Proof23 : runCachedNode 511 131344 Adaptive147Third143Node23 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 131344 Adaptive147Third143Node23 = [103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 128, 129] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive147Third143Proof24
  · exact adaptive147Third143Proof25
  · exact adaptive147Third143Proof26
  · exact adaptive147Third143Proof27
  · exact adaptive147Third143Proof28
  · exact adaptive147Third143Proof29
  · exact adaptive147Third143Proof30
  · exact adaptive147Third143Proof31
  · exact adaptive147Third143Proof32
  · exact adaptive147Third143Proof33
  · exact adaptive147Third143Proof34
  · exact adaptive147Third143Proof35
  · exact adaptive147Third143Proof36
  · exact adaptive147Third143Proof37
  · exact adaptive147Third143Proof38
  · exact adaptive147Third143Proof39
  · exact adaptive147Third143Proof40
  · exact adaptive147Third143Proof41
  · exact adaptive147Third143Proof42
  · exact adaptive147Third143Proof43
  · exact adaptive147Third143Proof44
  · exact adaptive147Third143Proof45
  · exact adaptive147Third143Proof46
  · exact adaptive147Third143Proof47
  · exact adaptive147Third143Proof48

#print axioms adaptive147Third143Proof23

theorem adaptive147Third143Proof49 : runCachedNode 511 131344 Adaptive147Third143Node49 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 131344 Adaptive147Third143Node49 = [102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 129, 130] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive147Third143Proof50
  · exact adaptive147Third143Proof51
  · exact adaptive147Third143Proof52
  · exact adaptive147Third143Proof53
  · exact adaptive147Third143Proof54
  · exact adaptive147Third143Proof55
  · exact adaptive147Third143Proof56
  · exact adaptive147Third143Proof57
  · exact adaptive147Third143Proof58
  · exact adaptive147Third143Proof59
  · exact adaptive147Third143Proof60
  · exact adaptive147Third143Proof61
  · exact adaptive147Third143Proof62
  · exact adaptive147Third143Proof63
  · exact adaptive147Third143Proof64
  · exact adaptive147Third143Proof65
  · exact adaptive147Third143Proof66
  · exact adaptive147Third143Proof67
  · exact adaptive147Third143Proof68
  · exact adaptive147Third143Proof69
  · exact adaptive147Third143Proof70
  · exact adaptive147Third143Proof71
  · exact adaptive147Third143Proof72
  · exact adaptive147Third143Proof73
  · exact adaptive147Third143Proof74
  · exact adaptive147Third143Proof75
  · exact adaptive147Third143Proof76

#print axioms adaptive147Third143Proof49

theorem adaptive147Third143Proof77 : runCachedNode 511 131344 Adaptive147Third143Node77 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 131344 Adaptive147Third143Node77 = [102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 130, 131] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive147Third143Proof78
  · exact adaptive147Third143Proof79
  · exact adaptive147Third143Proof80
  · exact adaptive147Third143Proof81
  · exact adaptive147Third143Proof82
  · exact adaptive147Third143Proof83
  · exact adaptive147Third143Proof84
  · exact adaptive147Third143Proof85
  · exact adaptive147Third143Proof86
  · exact adaptive147Third143Proof87
  · exact adaptive147Third143Proof88
  · exact adaptive147Third143Proof89
  · exact adaptive147Third143Proof90
  · exact adaptive147Third143Proof91
  · exact adaptive147Third143Proof92
  · exact adaptive147Third143Proof93
  · exact adaptive147Third143Proof94
  · exact adaptive147Third143Proof95
  · exact adaptive147Third143Proof96
  · exact adaptive147Third143Proof97
  · exact adaptive147Third143Proof98
  · exact adaptive147Third143Proof99
  · exact adaptive147Third143Proof100
  · exact adaptive147Third143Proof101
  · exact adaptive147Third143Proof102
  · exact adaptive147Third143Proof103
  · exact adaptive147Third143Proof104
  · exact adaptive147Third143Proof105

#print axioms adaptive147Third143Proof77

theorem adaptive147Third143Proof106 : runCachedNode 511 131344 Adaptive147Third143Node106 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 131344 Adaptive147Third143Node106 = [102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 131, 132] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive147Third143Proof107
  · exact adaptive147Third143Proof108
  · exact adaptive147Third143Proof109
  · exact adaptive147Third143Proof110
  · exact adaptive147Third143Proof111
  · exact adaptive147Third143Proof112
  · exact adaptive147Third143Proof113
  · exact adaptive147Third143Proof114
  · exact adaptive147Third143Proof115
  · exact adaptive147Third143Proof116
  · exact adaptive147Third143Proof117
  · exact adaptive147Third143Proof118
  · exact adaptive147Third143Proof119
  · exact adaptive147Third143Proof120
  · exact adaptive147Third143Proof121
  · exact adaptive147Third143Proof122
  · exact adaptive147Third143Proof123
  · exact adaptive147Third143Proof124
  · exact adaptive147Third143Proof125
  · exact adaptive147Third143Proof126
  · exact adaptive147Third143Proof127
  · exact adaptive147Third143Proof128
  · exact adaptive147Third143Proof129
  · exact adaptive147Third143Proof130
  · exact adaptive147Third143Proof131
  · exact adaptive147Third143Proof132
  · exact adaptive147Third143Proof133
  · exact adaptive147Third143Proof134
  · exact adaptive147Third143Proof135

#print axioms adaptive147Third143Proof106

theorem adaptive147Third143Proof136 : runCachedNode 511 131344 Adaptive147Third143Node136 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 131344 Adaptive147Third143Node136 = [102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 132, 133] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive147Third143Proof137
  · exact adaptive147Third143Proof138
  · exact adaptive147Third143Proof139
  · exact adaptive147Third143Proof140
  · exact adaptive147Third143Proof141
  · exact adaptive147Third143Proof142
  · exact adaptive147Third143Proof143
  · exact adaptive147Third143Proof144
  · exact adaptive147Third143Proof145
  · exact adaptive147Third143Proof146
  · exact adaptive147Third143Proof147
  · exact adaptive147Third143Proof148
  · exact adaptive147Third143Proof149
  · exact adaptive147Third143Proof150
  · exact adaptive147Third143Proof151
  · exact adaptive147Third143Proof152
  · exact adaptive147Third143Proof153
  · exact adaptive147Third143Proof154
  · exact adaptive147Third143Proof155
  · exact adaptive147Third143Proof156
  · exact adaptive147Third143Proof157
  · exact adaptive147Third143Proof158
  · exact adaptive147Third143Proof159
  · exact adaptive147Third143Proof160
  · exact adaptive147Third143Proof161
  · exact adaptive147Third143Proof162
  · exact adaptive147Third143Proof163
  · exact adaptive147Third143Proof164
  · exact adaptive147Third143Proof165
  · exact adaptive147Third143Proof166

#print axioms adaptive147Third143Proof136

theorem adaptive147Third143Proof167 : runCachedNode 511 131344 Adaptive147Third143Node167 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 131344 Adaptive147Third143Node167 = [101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 133, 134] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive147Third143Proof168
  · exact adaptive147Third143Proof169
  · exact adaptive147Third143Proof170
  · exact adaptive147Third143Proof171
  · exact adaptive147Third143Proof172
  · exact adaptive147Third143Proof173
  · exact adaptive147Third143Proof174
  · exact adaptive147Third143Proof175
  · exact adaptive147Third143Proof176
  · exact adaptive147Third143Proof177
  · exact adaptive147Third143Proof178
  · exact adaptive147Third143Proof179
  · exact adaptive147Third143Proof180
  · exact adaptive147Third143Proof181
  · exact adaptive147Third143Proof182
  · exact adaptive147Third143Proof183
  · exact adaptive147Third143Proof184
  · exact adaptive147Third143Proof185
  · exact adaptive147Third143Proof186
  · exact adaptive147Third143Proof187
  · exact adaptive147Third143Proof188
  · exact adaptive147Third143Proof189
  · exact adaptive147Third143Proof190
  · exact adaptive147Third143Proof191
  · exact adaptive147Third143Proof192
  · exact adaptive147Third143Proof193
  · exact adaptive147Third143Proof194
  · exact adaptive147Third143Proof195
  · exact adaptive147Third143Proof196
  · exact adaptive147Third143Proof197
  · exact adaptive147Third143Proof198
  · exact adaptive147Third143Proof199

#print axioms adaptive147Third143Proof167

theorem adaptive147Third143Proof200 : runCachedNode 511 131344 Adaptive147Third143Node200 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 131344 Adaptive147Third143Node200 = [101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 134, 135] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive147Third143Proof201
  · exact adaptive147Third143Proof202
  · exact adaptive147Third143Proof203
  · exact adaptive147Third143Proof204
  · exact adaptive147Third143Proof205
  · exact adaptive147Third143Proof206
  · exact adaptive147Third143Proof207
  · exact adaptive147Third143Proof208
  · exact adaptive147Third143Proof209
  · exact adaptive147Third143Proof210
  · exact adaptive147Third143Proof211
  · exact adaptive147Third143Proof212
  · exact adaptive147Third143Proof213
  · exact adaptive147Third143Proof214
  · exact adaptive147Third143Proof215
  · exact adaptive147Third143Proof216
  · exact adaptive147Third143Proof217
  · exact adaptive147Third143Proof218
  · exact adaptive147Third143Proof219
  · exact adaptive147Third143Proof220
  · exact adaptive147Third143Proof221
  · exact adaptive147Third143Proof222
  · exact adaptive147Third143Proof223
  · exact adaptive147Third143Proof224
  · exact adaptive147Third143Proof225
  · exact adaptive147Third143Proof226
  · exact adaptive147Third143Proof227
  · exact adaptive147Third143Proof228
  · exact adaptive147Third143Proof229
  · exact adaptive147Third143Proof230
  · exact adaptive147Third143Proof231
  · exact adaptive147Third143Proof232
  · exact adaptive147Third143Proof233

#print axioms adaptive147Third143Proof200

theorem adaptive147Third143Proof234 : runCachedNode 511 131344 Adaptive147Third143Node234 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 131344 Adaptive147Third143Node234 = [101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 132, 135, 136] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive147Third143Proof235
  · exact adaptive147Third143Proof236
  · exact adaptive147Third143Proof237
  · exact adaptive147Third143Proof238
  · exact adaptive147Third143Proof239
  · exact adaptive147Third143Proof240
  · exact adaptive147Third143Proof241
  · exact adaptive147Third143Proof242
  · exact adaptive147Third143Proof243
  · exact adaptive147Third143Proof244
  · exact adaptive147Third143Proof245
  · exact adaptive147Third143Proof246
  · exact adaptive147Third143Proof247
  · exact adaptive147Third143Proof248
  · exact adaptive147Third143Proof249
  · exact adaptive147Third143Proof250
  · exact adaptive147Third143Proof251
  · exact adaptive147Third143Proof252
  · exact adaptive147Third143Proof253
  · exact adaptive147Third143Proof254
  · exact adaptive147Third143Proof255
  · exact adaptive147Third143Proof256
  · exact adaptive147Third143Proof257
  · exact adaptive147Third143Proof258
  · exact adaptive147Third143Proof259
  · exact adaptive147Third143Proof260
  · exact adaptive147Third143Proof261
  · exact adaptive147Third143Proof262
  · exact adaptive147Third143Proof263
  · exact adaptive147Third143Proof264
  · exact adaptive147Third143Proof265
  · exact adaptive147Third143Proof266
  · exact adaptive147Third143Proof267
  · exact adaptive147Third143Proof268

#print axioms adaptive147Third143Proof234

end NineSeparatedSubsetSums
