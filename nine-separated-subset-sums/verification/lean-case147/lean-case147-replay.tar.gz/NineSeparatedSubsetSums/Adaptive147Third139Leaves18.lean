import NineSeparatedSubsetSums.Adaptive147Third139State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third139Proof178 : runCachedNode 511 130807 Adaptive147Third139Node178 = false := by
  decide +kernel

#print axioms adaptive147Third139Proof178

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third139Proof41 : runCachedNode 511 130807 Adaptive147Third139Node41 = false := by
  decide +kernel

#print axioms adaptive147Third139Proof41

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third139Proof92 : runCachedNode 511 130807 Adaptive147Third139Node92 = false := by
  decide +kernel

#print axioms adaptive147Third139Proof92

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third139Proof151 : runCachedNode 511 130807 Adaptive147Third139Node151 = false := by
  decide +kernel

#print axioms adaptive147Third139Proof151

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third139Proof241 : runCachedNode 511 130807 Adaptive147Third139Node241 = false := by
  decide +kernel

#print axioms adaptive147Third139Proof241

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third139Proof238 : runCachedNode 511 130807 Adaptive147Third139Node238 = false := by
  decide +kernel

#print axioms adaptive147Third139Proof238

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third139Proof209 : runCachedNode 511 130807 Adaptive147Third139Node209 = false := by
  decide +kernel

#print axioms adaptive147Third139Proof209

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third139Proof146 : runCachedNode 511 130807 Adaptive147Third139Node146 = false := by
  decide +kernel

#print axioms adaptive147Third139Proof146

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third139Proof120 : runCachedNode 511 130807 Adaptive147Third139Node120 = false := by
  decide +kernel

#print axioms adaptive147Third139Proof120

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third139Proof237 : runCachedNode 511 130807 Adaptive147Third139Node237 = false := by
  decide +kernel

#print axioms adaptive147Third139Proof237

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third139Proof64 : runCachedNode 511 130807 Adaptive147Third139Node64 = false := by
  decide +kernel

#print axioms adaptive147Third139Proof64

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third139Proof240 : runCachedNode 511 130807 Adaptive147Third139Node240 = false := by
  decide +kernel

#print axioms adaptive147Third139Proof240

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third139Proof145 : runCachedNode 511 130807 Adaptive147Third139Node145 = false := by
  decide +kernel

#print axioms adaptive147Third139Proof145

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third139Proof63 : runCachedNode 511 130807 Adaptive147Third139Node63 = false := by
  decide +kernel

#print axioms adaptive147Third139Proof63

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third139Proof86 : runCachedNode 511 130807 Adaptive147Third139Node86 = false := by
  decide +kernel

#print axioms adaptive147Third139Proof86

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third139Proof48 : runCachedNode 511 130807 Adaptive147Third139Node48 = false := by
  decide +kernel

#print axioms adaptive147Third139Proof48

end NineSeparatedSubsetSums
