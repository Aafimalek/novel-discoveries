import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive147Third118Node0 : CachedSearchNode :=
  ⟨4, 117, computeCenteredMask [148,147,118], 413, 57437⟩

end NineSeparatedSubsetSums
