import NineSeparatedSubsetSums.Adaptive147Third144State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof21 : runCachedNode 511 131483 Adaptive147Third144Node21 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof21

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof790 : runCachedNode 511 131483 Adaptive147Third144Node790 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof790

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof1 : runCachedNode 511 131483 Adaptive147Third144Node1 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof1

end NineSeparatedSubsetSums
