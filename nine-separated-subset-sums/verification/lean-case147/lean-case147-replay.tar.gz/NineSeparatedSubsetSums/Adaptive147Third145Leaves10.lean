import NineSeparatedSubsetSums.Adaptive147Third145State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third145Proof20 : runCachedNode 511 131618 Adaptive147Third145Node20 = false := by
  decide +kernel

#print axioms adaptive147Third145Proof20

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third145Proof209 : runCachedNode 511 131618 Adaptive147Third145Node209 = false := by
  decide +kernel

#print axioms adaptive147Third145Proof209

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third145Proof1 : runCachedNode 511 131618 Adaptive147Third145Node1 = false := by
  decide +kernel

#print axioms adaptive147Third145Proof1

end NineSeparatedSubsetSums
