import NineSeparatedSubsetSums.Adaptive147Third129State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third129Proof18 : runCachedNode 511 129010 Adaptive147Third129Node18 = false := by
  decide +kernel

#print axioms adaptive147Third129Proof18

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third129Proof17 : runCachedNode 511 129010 Adaptive147Third129Node17 = false := by
  decide +kernel

#print axioms adaptive147Third129Proof17

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third129Proof15 : runCachedNode 511 129010 Adaptive147Third129Node15 = false := by
  decide +kernel

#print axioms adaptive147Third129Proof15

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third129Proof5 : runCachedNode 511 129010 Adaptive147Third129Node5 = false := by
  decide +kernel

#print axioms adaptive147Third129Proof5

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third129Proof4 : runCachedNode 511 129010 Adaptive147Third129Node4 = false := by
  decide +kernel

#print axioms adaptive147Third129Proof4

end NineSeparatedSubsetSums
