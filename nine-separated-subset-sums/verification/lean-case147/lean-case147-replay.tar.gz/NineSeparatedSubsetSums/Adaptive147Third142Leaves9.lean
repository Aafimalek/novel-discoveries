import NineSeparatedSubsetSums.Adaptive147Third142State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third142Proof20 : runCachedNode 511 131213 Adaptive147Third142Node20 = false := by
  decide +kernel

#print axioms adaptive147Third142Proof20

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third142Proof16 : runCachedNode 511 131213 Adaptive147Third142Node16 = false := by
  decide +kernel

#print axioms adaptive147Third142Proof16

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third142Proof348 : runCachedNode 511 131213 Adaptive147Third142Node348 = false := by
  decide +kernel

#print axioms adaptive147Third142Proof348

end NineSeparatedSubsetSums
