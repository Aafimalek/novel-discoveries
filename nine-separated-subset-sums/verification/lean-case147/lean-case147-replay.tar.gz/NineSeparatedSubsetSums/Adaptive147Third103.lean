import NineSeparatedSubsetSums.Adaptive147Third103Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint147Checked

namespace NineSeparatedSubsetSums


theorem adaptive147Third103 : NoDescendingTailAfterThird 147 103 :=
  noDescendingThirdTail_of_cached 147 103 112835 (fun t ht nd => max148_second147_fourPoint_moment_bound (103::t) (by simp [ht]) nd) adaptive147Third103Proof0

#print axioms adaptive147Third103

end NineSeparatedSubsetSums
