import NineSeparatedSubsetSums.Adaptive147Third140State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third140Proof16 : runCachedNode 511 130945 Adaptive147Third140Node16 = false := by
  decide +kernel

#print axioms adaptive147Third140Proof16

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third140Proof74 : runCachedNode 511 130945 Adaptive147Third140Node74 = false := by
  decide +kernel

#print axioms adaptive147Third140Proof74

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third140Proof71 : runCachedNode 511 130945 Adaptive147Third140Node71 = false := by
  decide +kernel

#print axioms adaptive147Third140Proof71

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third140Proof15 : runCachedNode 511 130945 Adaptive147Third140Node15 = false := by
  decide +kernel

#print axioms adaptive147Third140Proof15

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third140Proof59 : runCachedNode 511 130945 Adaptive147Third140Node59 = false := by
  decide +kernel

#print axioms adaptive147Third140Proof59

end NineSeparatedSubsetSums
