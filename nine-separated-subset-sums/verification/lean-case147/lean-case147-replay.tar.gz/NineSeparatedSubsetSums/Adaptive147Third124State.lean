import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive147Third124Node0 : CachedSearchNode :=
  ⟨4, 123, computeCenteredMask [148,147,124], 419, 58889⟩

end NineSeparatedSubsetSums
