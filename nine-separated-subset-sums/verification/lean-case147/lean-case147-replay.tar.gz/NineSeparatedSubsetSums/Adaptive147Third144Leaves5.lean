import NineSeparatedSubsetSums.Adaptive147Third144State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof306 : runCachedNode 511 131483 Adaptive147Third144Node306 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof306

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof165 : runCachedNode 511 131483 Adaptive147Third144Node165 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof165

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof81 : runCachedNode 511 131483 Adaptive147Third144Node81 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof81

end NineSeparatedSubsetSums
