import NineSeparatedSubsetSums.Adaptive147Third115State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third115Proof14 : runCachedNode 511 112835 Adaptive147Third115Node14 = false := by
  decide +kernel

#print axioms adaptive147Third115Proof14

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third115Proof13 : runCachedNode 511 112835 Adaptive147Third115Node13 = false := by
  decide +kernel

#print axioms adaptive147Third115Proof13

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third115Proof12 : runCachedNode 511 112835 Adaptive147Third115Node12 = false := by
  decide +kernel

#print axioms adaptive147Third115Proof12

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third115Proof11 : runCachedNode 511 112835 Adaptive147Third115Node11 = false := by
  decide +kernel

#print axioms adaptive147Third115Proof11

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third115Proof10 : runCachedNode 511 112835 Adaptive147Third115Node10 = false := by
  decide +kernel

#print axioms adaptive147Third115Proof10

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third115Proof9 : runCachedNode 511 112835 Adaptive147Third115Node9 = false := by
  decide +kernel

#print axioms adaptive147Third115Proof9

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third115Proof6 : runCachedNode 511 112835 Adaptive147Third115Node6 = false := by
  decide +kernel

#print axioms adaptive147Third115Proof6

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third115Proof3 : runCachedNode 511 112835 Adaptive147Third115Node3 = false := by
  decide +kernel

#print axioms adaptive147Third115Proof3

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third115Proof1 : runCachedNode 511 112835 Adaptive147Third115Node1 = false := by
  decide +kernel

#print axioms adaptive147Third115Proof1

end NineSeparatedSubsetSums
