import NineSeparatedSubsetSums.Adaptive147Third139State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third139Proof210 : runCachedNode 511 130807 Adaptive147Third139Node210 = false := by
  decide +kernel

#print axioms adaptive147Third139Proof210

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third139Proof42 : runCachedNode 511 130807 Adaptive147Third139Node42 = false := by
  decide +kernel

#print axioms adaptive147Third139Proof42

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third139Proof123 : runCachedNode 511 130807 Adaptive147Third139Node123 = false := by
  decide +kernel

#print axioms adaptive147Third139Proof123

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third139Proof13 : runCachedNode 511 130807 Adaptive147Third139Node13 = false := by
  decide +kernel

#print axioms adaptive147Third139Proof13

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third139Proof150 : runCachedNode 511 130807 Adaptive147Third139Node150 = false := by
  decide +kernel

#print axioms adaptive147Third139Proof150

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third139Proof243 : runCachedNode 511 130807 Adaptive147Third139Node243 = false := by
  decide +kernel

#print axioms adaptive147Third139Proof243

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third139Proof40 : runCachedNode 511 130807 Adaptive147Third139Node40 = false := by
  decide +kernel

#print axioms adaptive147Third139Proof40

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third139Proof11 : runCachedNode 511 130807 Adaptive147Third139Node11 = false := by
  decide +kernel

#print axioms adaptive147Third139Proof11

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third139Proof25 : runCachedNode 511 130807 Adaptive147Third139Node25 = false := by
  decide +kernel

#print axioms adaptive147Third139Proof25

end NineSeparatedSubsetSums
