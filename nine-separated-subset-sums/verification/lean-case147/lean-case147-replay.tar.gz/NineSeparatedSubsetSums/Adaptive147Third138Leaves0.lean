import NineSeparatedSubsetSums.Adaptive147Third138State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third138Proof19 : runCachedNode 511 130657 Adaptive147Third138Node19 = false := by
  decide +kernel

#print axioms adaptive147Third138Proof19

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third138Proof90 : runCachedNode 511 130657 Adaptive147Third138Node90 = false := by
  decide +kernel

#print axioms adaptive147Third138Proof90

end NineSeparatedSubsetSums
