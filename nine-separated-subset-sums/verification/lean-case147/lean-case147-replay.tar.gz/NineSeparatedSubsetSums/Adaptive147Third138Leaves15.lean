import NineSeparatedSubsetSums.Adaptive147Third138State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third138Proof38 : runCachedNode 511 130657 Adaptive147Third138Node38 = false := by
  decide +kernel

#print axioms adaptive147Third138Proof38

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third138Proof62 : runCachedNode 511 130657 Adaptive147Third138Node62 = false := by
  decide +kernel

#print axioms adaptive147Third138Proof62

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third138Proof37 : runCachedNode 511 130657 Adaptive147Third138Node37 = false := by
  decide +kernel

#print axioms adaptive147Third138Proof37

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third138Proof87 : runCachedNode 511 130657 Adaptive147Third138Node87 = false := by
  decide +kernel

#print axioms adaptive147Third138Proof87

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third138Proof61 : runCachedNode 511 130657 Adaptive147Third138Node61 = false := by
  decide +kernel

#print axioms adaptive147Third138Proof61

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third138Proof168 : runCachedNode 511 130657 Adaptive147Third138Node168 = false := by
  decide +kernel

#print axioms adaptive147Third138Proof168

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third138Proof228 : runCachedNode 511 130657 Adaptive147Third138Node228 = false := by
  decide +kernel

#print axioms adaptive147Third138Proof228

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third138Proof140 : runCachedNode 511 130657 Adaptive147Third138Node140 = false := by
  decide +kernel

#print axioms adaptive147Third138Proof140

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third138Proof112 : runCachedNode 511 130657 Adaptive147Third138Node112 = false := by
  decide +kernel

#print axioms adaptive147Third138Proof112

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third138Proof166 : runCachedNode 511 130657 Adaptive147Third138Node166 = false := by
  decide +kernel

#print axioms adaptive147Third138Proof166

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third138Proof227 : runCachedNode 511 130657 Adaptive147Third138Node227 = false := by
  decide +kernel

#print axioms adaptive147Third138Proof227

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third138Proof9 : runCachedNode 511 130657 Adaptive147Third138Node9 = false := by
  decide +kernel

#print axioms adaptive147Third138Proof9

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third138Proof197 : runCachedNode 511 130657 Adaptive147Third138Node197 = false := by
  decide +kernel

#print axioms adaptive147Third138Proof197

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third138Proof225 : runCachedNode 511 130657 Adaptive147Third138Node225 = false := by
  decide +kernel

#print axioms adaptive147Third138Proof225

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third138Proof142 : runCachedNode 511 130657 Adaptive147Third138Node142 = false := by
  decide +kernel

#print axioms adaptive147Third138Proof142

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third138Proof224 : runCachedNode 511 130657 Adaptive147Third138Node224 = false := by
  decide +kernel

#print axioms adaptive147Third138Proof224

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third138Proof85 : runCachedNode 511 130657 Adaptive147Third138Node85 = false := by
  decide +kernel

#print axioms adaptive147Third138Proof85

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third138Proof137 : runCachedNode 511 130657 Adaptive147Third138Node137 = false := by
  decide +kernel

#print axioms adaptive147Third138Proof137

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third138Proof25 : runCachedNode 511 130657 Adaptive147Third138Node25 = false := by
  decide +kernel

#print axioms adaptive147Third138Proof25

end NineSeparatedSubsetSums
