import NineSeparatedSubsetSums.Adaptive147Third143State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third143Proof301 : runCachedNode 511 131344 Adaptive147Third143Node301 = false := by
  decide +kernel

#print axioms adaptive147Third143Proof301

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third143Proof265 : runCachedNode 511 131344 Adaptive147Third143Node265 = false := by
  decide +kernel

#print axioms adaptive147Third143Proof265

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third143Proof5 : runCachedNode 511 131344 Adaptive147Third143Node5 = false := by
  decide +kernel

#print axioms adaptive147Third143Proof5

end NineSeparatedSubsetSums
