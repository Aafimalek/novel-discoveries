import NineSeparatedSubsetSums.Adaptive147Third143State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third143Proof190 : runCachedNode 511 131344 Adaptive147Third143Node190 = false := by
  decide +kernel

#print axioms adaptive147Third143Proof190

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third143Proof339 : runCachedNode 511 131344 Adaptive147Third143Node339 = false := by
  decide +kernel

#print axioms adaptive147Third143Proof339

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third143Proof504 : runCachedNode 511 131344 Adaptive147Third143Node504 = false := by
  decide +kernel

#print axioms adaptive147Third143Proof504

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third143Proof408 : runCachedNode 511 131344 Adaptive147Third143Node408 = false := by
  decide +kernel

#print axioms adaptive147Third143Proof408

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third143Proof42 : runCachedNode 511 131344 Adaptive147Third143Node42 = false := by
  decide +kernel

#print axioms adaptive147Third143Proof42

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third143Proof69 : runCachedNode 511 131344 Adaptive147Third143Node69 = false := by
  decide +kernel

#print axioms adaptive147Third143Proof69

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third143Proof286 : runCachedNode 511 131344 Adaptive147Third143Node286 = false := by
  decide +kernel

#print axioms adaptive147Third143Proof286

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third143Proof126 : runCachedNode 511 131344 Adaptive147Third143Node126 = false := by
  decide +kernel

#print axioms adaptive147Third143Proof126

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third143Proof251 : runCachedNode 511 131344 Adaptive147Third143Node251 = false := by
  decide +kernel

#print axioms adaptive147Third143Proof251

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third143Proof530 : runCachedNode 511 131344 Adaptive147Third143Node530 = false := by
  decide +kernel

#print axioms adaptive147Third143Proof530

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third143Proof98 : runCachedNode 511 131344 Adaptive147Third143Node98 = false := by
  decide +kernel

#print axioms adaptive147Third143Proof98

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third143Proof128 : runCachedNode 511 131344 Adaptive147Third143Node128 = false := by
  decide +kernel

#print axioms adaptive147Third143Proof128

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third143Proof252 : runCachedNode 511 131344 Adaptive147Third143Node252 = false := by
  decide +kernel

#print axioms adaptive147Third143Proof252

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third143Proof185 : runCachedNode 511 131344 Adaptive147Third143Node185 = false := by
  decide +kernel

#print axioms adaptive147Third143Proof185

end NineSeparatedSubsetSums
