import NineSeparatedSubsetSums.Adaptive147Third143State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third143Proof290 : runCachedNode 511 131344 Adaptive147Third143Node290 = false := by
  decide +kernel

#print axioms adaptive147Third143Proof290

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third143Proof129 : runCachedNode 511 131344 Adaptive147Third143Node129 = false := by
  decide +kernel

#print axioms adaptive147Third143Proof129

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third143Proof222 : runCachedNode 511 131344 Adaptive147Third143Node222 = false := by
  decide +kernel

#print axioms adaptive147Third143Proof222

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third143Proof256 : runCachedNode 511 131344 Adaptive147Third143Node256 = false := by
  decide +kernel

#print axioms adaptive147Third143Proof256

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third143Proof383 : runCachedNode 511 131344 Adaptive147Third143Node383 = false := by
  decide +kernel

#print axioms adaptive147Third143Proof383

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third143Proof631 : runCachedNode 511 131344 Adaptive147Third143Node631 = false := by
  decide +kernel

#print axioms adaptive147Third143Proof631

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third143Proof537 : runCachedNode 511 131344 Adaptive147Third143Node537 = false := by
  decide +kernel

#print axioms adaptive147Third143Proof537

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third143Proof160 : runCachedNode 511 131344 Adaptive147Third143Node160 = false := by
  decide +kernel

#print axioms adaptive147Third143Proof160

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third143Proof44 : runCachedNode 511 131344 Adaptive147Third143Node44 = false := by
  decide +kernel

#print axioms adaptive147Third143Proof44

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third143Proof80 : runCachedNode 511 131344 Adaptive147Third143Node80 = false := by
  decide +kernel

#print axioms adaptive147Third143Proof80

end NineSeparatedSubsetSums
