import NineSeparatedSubsetSums.Adaptive147Third140State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third140Proof227 : runCachedNode 511 130945 Adaptive147Third140Node227 = false := by
  decide +kernel

#print axioms adaptive147Third140Proof227

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third140Proof226 : runCachedNode 511 130945 Adaptive147Third140Node226 = false := by
  decide +kernel

#print axioms adaptive147Third140Proof226

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third140Proof56 : runCachedNode 511 130945 Adaptive147Third140Node56 = false := by
  decide +kernel

#print axioms adaptive147Third140Proof56

end NineSeparatedSubsetSums
