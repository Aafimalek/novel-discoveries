import NineSeparatedSubsetSums.Adaptive147Third144State
import NineSeparatedSubsetSums.Adaptive147Third144Leaves22
import NineSeparatedSubsetSums.Adaptive147Third144Leaves65
import NineSeparatedSubsetSums.Adaptive147Third144Leaves63
import NineSeparatedSubsetSums.Adaptive147Third144Leaves61
import NineSeparatedSubsetSums.Adaptive147Third144Leaves0
import NineSeparatedSubsetSums.Adaptive147Third144Leaves59
import NineSeparatedSubsetSums.Adaptive147Third144Leaves58
import NineSeparatedSubsetSums.Adaptive147Third144Leaves57
import NineSeparatedSubsetSums.Adaptive147Third144Leaves56
import NineSeparatedSubsetSums.Adaptive147Third144Leaves55
import NineSeparatedSubsetSums.Adaptive147Third144Leaves53
import NineSeparatedSubsetSums.Adaptive147Third144Leaves54
import NineSeparatedSubsetSums.Adaptive147Third144Leaves51
import NineSeparatedSubsetSums.Adaptive147Third144Leaves52
import NineSeparatedSubsetSums.Adaptive147Third144Leaves49
import NineSeparatedSubsetSums.Adaptive147Third144Leaves45
import NineSeparatedSubsetSums.Adaptive147Third144Leaves41
import NineSeparatedSubsetSums.Adaptive147Third144Leaves42
import NineSeparatedSubsetSums.Adaptive147Third144Leaves31
import NineSeparatedSubsetSums.Adaptive147Third144Leaves19
import NineSeparatedSubsetSums.Adaptive147Third144Leaves11
import NineSeparatedSubsetSums.Adaptive147Third144Leaves23
import NineSeparatedSubsetSums.Adaptive147Third144Leaves62
import NineSeparatedSubsetSums.Adaptive147Third144Leaves60
import NineSeparatedSubsetSums.Adaptive147Third144Leaves38
import NineSeparatedSubsetSums.Adaptive147Third144Leaves25
import NineSeparatedSubsetSums.Adaptive147Third144Leaves47
import NineSeparatedSubsetSums.Adaptive147Third144Leaves2
import NineSeparatedSubsetSums.Adaptive147Third144Leaves32
import NineSeparatedSubsetSums.Adaptive147Third144Leaves37
import NineSeparatedSubsetSums.Adaptive147Third144Leaves39
import NineSeparatedSubsetSums.Adaptive147Third144Leaves28
import NineSeparatedSubsetSums.Adaptive147Third144Leaves5
import NineSeparatedSubsetSums.Adaptive147Third144Leaves48
import NineSeparatedSubsetSums.Adaptive147Third144Leaves16
import NineSeparatedSubsetSums.Adaptive147Third144Leaves43
import NineSeparatedSubsetSums.Adaptive147Third144Leaves46
import NineSeparatedSubsetSums.Adaptive147Third144Leaves44
import NineSeparatedSubsetSums.Adaptive147Third144Leaves3
import NineSeparatedSubsetSums.Adaptive147Third144Leaves40
import NineSeparatedSubsetSums.Adaptive147Third144Leaves36
import NineSeparatedSubsetSums.Adaptive147Third144Leaves20
import NineSeparatedSubsetSums.Adaptive147Third144Leaves18
import NineSeparatedSubsetSums.Adaptive147Third144Leaves30
import NineSeparatedSubsetSums.Adaptive147Third144Leaves34
import NineSeparatedSubsetSums.Adaptive147Third144Leaves7
import NineSeparatedSubsetSums.Adaptive147Third144Leaves13
import NineSeparatedSubsetSums.Adaptive147Third144Leaves35
import NineSeparatedSubsetSums.Adaptive147Third144Leaves33
import NineSeparatedSubsetSums.Adaptive147Third144Leaves9
import NineSeparatedSubsetSums.Adaptive147Third144Leaves14
import NineSeparatedSubsetSums.Adaptive147Third144Leaves50
import NineSeparatedSubsetSums.Adaptive147Third144Leaves8
import NineSeparatedSubsetSums.Adaptive147Third144Leaves66
import NineSeparatedSubsetSums.Adaptive147Third144Leaves29
import NineSeparatedSubsetSums.Adaptive147Third144Leaves27
import NineSeparatedSubsetSums.Adaptive147Third144Leaves64
import NineSeparatedSubsetSums.Adaptive147Third144Leaves26
import NineSeparatedSubsetSums.Adaptive147Third144Leaves21
import NineSeparatedSubsetSums.Adaptive147Third144Leaves15

namespace NineSeparatedSubsetSums

theorem adaptive147Third144Proof23 : runCachedNode 511 131483 Adaptive147Third144Node23 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 131483 Adaptive147Third144Node23 = [103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 129] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive147Third144Proof24
  · exact adaptive147Third144Proof25
  · exact adaptive147Third144Proof26
  · exact adaptive147Third144Proof27
  · exact adaptive147Third144Proof28
  · exact adaptive147Third144Proof29
  · exact adaptive147Third144Proof30
  · exact adaptive147Third144Proof31
  · exact adaptive147Third144Proof32
  · exact adaptive147Third144Proof33
  · exact adaptive147Third144Proof34
  · exact adaptive147Third144Proof35
  · exact adaptive147Third144Proof36
  · exact adaptive147Third144Proof37
  · exact adaptive147Third144Proof38
  · exact adaptive147Third144Proof39
  · exact adaptive147Third144Proof40
  · exact adaptive147Third144Proof41
  · exact adaptive147Third144Proof42
  · exact adaptive147Third144Proof43
  · exact adaptive147Third144Proof44
  · exact adaptive147Third144Proof45
  · exact adaptive147Third144Proof46
  · exact adaptive147Third144Proof47
  · exact adaptive147Third144Proof48

#print axioms adaptive147Third144Proof23

theorem adaptive147Third144Proof49 : runCachedNode 511 131483 Adaptive147Third144Node49 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 131483 Adaptive147Third144Node49 = [102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 130] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive147Third144Proof50
  · exact adaptive147Third144Proof51
  · exact adaptive147Third144Proof52
  · exact adaptive147Third144Proof53
  · exact adaptive147Third144Proof54
  · exact adaptive147Third144Proof55
  · exact adaptive147Third144Proof56
  · exact adaptive147Third144Proof57
  · exact adaptive147Third144Proof58
  · exact adaptive147Third144Proof59
  · exact adaptive147Third144Proof60
  · exact adaptive147Third144Proof61
  · exact adaptive147Third144Proof62
  · exact adaptive147Third144Proof63
  · exact adaptive147Third144Proof64
  · exact adaptive147Third144Proof65
  · exact adaptive147Third144Proof66
  · exact adaptive147Third144Proof67
  · exact adaptive147Third144Proof68
  · exact adaptive147Third144Proof69
  · exact adaptive147Third144Proof70
  · exact adaptive147Third144Proof71
  · exact adaptive147Third144Proof72
  · exact adaptive147Third144Proof73
  · exact adaptive147Third144Proof74
  · exact adaptive147Third144Proof75
  · exact adaptive147Third144Proof76

#print axioms adaptive147Third144Proof49

theorem adaptive147Third144Proof77 : runCachedNode 511 131483 Adaptive147Third144Node77 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 131483 Adaptive147Third144Node77 = [102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 131] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive147Third144Proof78
  · exact adaptive147Third144Proof79
  · exact adaptive147Third144Proof80
  · exact adaptive147Third144Proof81
  · exact adaptive147Third144Proof82
  · exact adaptive147Third144Proof83
  · exact adaptive147Third144Proof84
  · exact adaptive147Third144Proof85
  · exact adaptive147Third144Proof86
  · exact adaptive147Third144Proof87
  · exact adaptive147Third144Proof88
  · exact adaptive147Third144Proof89
  · exact adaptive147Third144Proof90
  · exact adaptive147Third144Proof91
  · exact adaptive147Third144Proof92
  · exact adaptive147Third144Proof93
  · exact adaptive147Third144Proof94
  · exact adaptive147Third144Proof95
  · exact adaptive147Third144Proof96
  · exact adaptive147Third144Proof97
  · exact adaptive147Third144Proof98
  · exact adaptive147Third144Proof99
  · exact adaptive147Third144Proof100
  · exact adaptive147Third144Proof101
  · exact adaptive147Third144Proof102
  · exact adaptive147Third144Proof103
  · exact adaptive147Third144Proof104
  · exact adaptive147Third144Proof105

#print axioms adaptive147Third144Proof77

theorem adaptive147Third144Proof106 : runCachedNode 511 131483 Adaptive147Third144Node106 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 131483 Adaptive147Third144Node106 = [102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 132] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive147Third144Proof107
  · exact adaptive147Third144Proof108
  · exact adaptive147Third144Proof109
  · exact adaptive147Third144Proof110
  · exact adaptive147Third144Proof111
  · exact adaptive147Third144Proof112
  · exact adaptive147Third144Proof113
  · exact adaptive147Third144Proof114
  · exact adaptive147Third144Proof115
  · exact adaptive147Third144Proof116
  · exact adaptive147Third144Proof117
  · exact adaptive147Third144Proof118
  · exact adaptive147Third144Proof119
  · exact adaptive147Third144Proof120
  · exact adaptive147Third144Proof121
  · exact adaptive147Third144Proof122
  · exact adaptive147Third144Proof123
  · exact adaptive147Third144Proof124
  · exact adaptive147Third144Proof125
  · exact adaptive147Third144Proof126
  · exact adaptive147Third144Proof127
  · exact adaptive147Third144Proof128
  · exact adaptive147Third144Proof129
  · exact adaptive147Third144Proof130
  · exact adaptive147Third144Proof131
  · exact adaptive147Third144Proof132
  · exact adaptive147Third144Proof133
  · exact adaptive147Third144Proof134
  · exact adaptive147Third144Proof135

#print axioms adaptive147Third144Proof106

theorem adaptive147Third144Proof136 : runCachedNode 511 131483 Adaptive147Third144Node136 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 131483 Adaptive147Third144Node136 = [101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 133] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive147Third144Proof137
  · exact adaptive147Third144Proof138
  · exact adaptive147Third144Proof139
  · exact adaptive147Third144Proof140
  · exact adaptive147Third144Proof141
  · exact adaptive147Third144Proof142
  · exact adaptive147Third144Proof143
  · exact adaptive147Third144Proof144
  · exact adaptive147Third144Proof145
  · exact adaptive147Third144Proof146
  · exact adaptive147Third144Proof147
  · exact adaptive147Third144Proof148
  · exact adaptive147Third144Proof149
  · exact adaptive147Third144Proof150
  · exact adaptive147Third144Proof151
  · exact adaptive147Third144Proof152
  · exact adaptive147Third144Proof153
  · exact adaptive147Third144Proof154
  · exact adaptive147Third144Proof155
  · exact adaptive147Third144Proof156
  · exact adaptive147Third144Proof157
  · exact adaptive147Third144Proof158
  · exact adaptive147Third144Proof159
  · exact adaptive147Third144Proof160
  · exact adaptive147Third144Proof161
  · exact adaptive147Third144Proof162
  · exact adaptive147Third144Proof163
  · exact adaptive147Third144Proof164
  · exact adaptive147Third144Proof165
  · exact adaptive147Third144Proof166
  · exact adaptive147Third144Proof167

#print axioms adaptive147Third144Proof136

theorem adaptive147Third144Proof168 : runCachedNode 511 131483 Adaptive147Third144Node168 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 131483 Adaptive147Third144Node168 = [101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 134] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive147Third144Proof169
  · exact adaptive147Third144Proof170
  · exact adaptive147Third144Proof171
  · exact adaptive147Third144Proof172
  · exact adaptive147Third144Proof173
  · exact adaptive147Third144Proof174
  · exact adaptive147Third144Proof175
  · exact adaptive147Third144Proof176
  · exact adaptive147Third144Proof177
  · exact adaptive147Third144Proof178
  · exact adaptive147Third144Proof179
  · exact adaptive147Third144Proof180
  · exact adaptive147Third144Proof181
  · exact adaptive147Third144Proof182
  · exact adaptive147Third144Proof183
  · exact adaptive147Third144Proof184
  · exact adaptive147Third144Proof185
  · exact adaptive147Third144Proof186
  · exact adaptive147Third144Proof187
  · exact adaptive147Third144Proof188
  · exact adaptive147Third144Proof189
  · exact adaptive147Third144Proof190
  · exact adaptive147Third144Proof191
  · exact adaptive147Third144Proof192
  · exact adaptive147Third144Proof193
  · exact adaptive147Third144Proof194
  · exact adaptive147Third144Proof195
  · exact adaptive147Third144Proof196
  · exact adaptive147Third144Proof197
  · exact adaptive147Third144Proof198
  · exact adaptive147Third144Proof199
  · exact adaptive147Third144Proof200

#print axioms adaptive147Third144Proof168

theorem adaptive147Third144Proof201 : runCachedNode 511 131483 Adaptive147Third144Node201 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 131483 Adaptive147Third144Node201 = [101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 132, 135] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive147Third144Proof202
  · exact adaptive147Third144Proof203
  · exact adaptive147Third144Proof204
  · exact adaptive147Third144Proof205
  · exact adaptive147Third144Proof206
  · exact adaptive147Third144Proof207
  · exact adaptive147Third144Proof208
  · exact adaptive147Third144Proof209
  · exact adaptive147Third144Proof210
  · exact adaptive147Third144Proof211
  · exact adaptive147Third144Proof212
  · exact adaptive147Third144Proof213
  · exact adaptive147Third144Proof214
  · exact adaptive147Third144Proof215
  · exact adaptive147Third144Proof216
  · exact adaptive147Third144Proof217
  · exact adaptive147Third144Proof218
  · exact adaptive147Third144Proof219
  · exact adaptive147Third144Proof220
  · exact adaptive147Third144Proof221
  · exact adaptive147Third144Proof222
  · exact adaptive147Third144Proof223
  · exact adaptive147Third144Proof224
  · exact adaptive147Third144Proof225
  · exact adaptive147Third144Proof226
  · exact adaptive147Third144Proof227
  · exact adaptive147Third144Proof228
  · exact adaptive147Third144Proof229
  · exact adaptive147Third144Proof230
  · exact adaptive147Third144Proof231
  · exact adaptive147Third144Proof232
  · exact adaptive147Third144Proof233
  · exact adaptive147Third144Proof234

#print axioms adaptive147Third144Proof201

theorem adaptive147Third144Proof235 : runCachedNode 511 131483 Adaptive147Third144Node235 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 131483 Adaptive147Third144Node235 = [101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 132, 133, 136] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive147Third144Proof236
  · exact adaptive147Third144Proof237
  · exact adaptive147Third144Proof238
  · exact adaptive147Third144Proof239
  · exact adaptive147Third144Proof240
  · exact adaptive147Third144Proof241
  · exact adaptive147Third144Proof242
  · exact adaptive147Third144Proof243
  · exact adaptive147Third144Proof244
  · exact adaptive147Third144Proof245
  · exact adaptive147Third144Proof246
  · exact adaptive147Third144Proof247
  · exact adaptive147Third144Proof248
  · exact adaptive147Third144Proof249
  · exact adaptive147Third144Proof250
  · exact adaptive147Third144Proof251
  · exact adaptive147Third144Proof252
  · exact adaptive147Third144Proof253
  · exact adaptive147Third144Proof254
  · exact adaptive147Third144Proof255
  · exact adaptive147Third144Proof256
  · exact adaptive147Third144Proof257
  · exact adaptive147Third144Proof258
  · exact adaptive147Third144Proof259
  · exact adaptive147Third144Proof260
  · exact adaptive147Third144Proof261
  · exact adaptive147Third144Proof262
  · exact adaptive147Third144Proof263
  · exact adaptive147Third144Proof264
  · exact adaptive147Third144Proof265
  · exact adaptive147Third144Proof266
  · exact adaptive147Third144Proof267
  · exact adaptive147Third144Proof268
  · exact adaptive147Third144Proof269

#print axioms adaptive147Third144Proof235

end NineSeparatedSubsetSums
