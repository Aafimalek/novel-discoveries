import NineSeparatedSubsetSums.Adaptive147Third141State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third141Proof337 : runCachedNode 511 131086 Adaptive147Third141Node337 = false := by
  decide +kernel

#print axioms adaptive147Third141Proof337

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third141Proof103 : runCachedNode 511 131086 Adaptive147Third141Node103 = false := by
  decide +kernel

#print axioms adaptive147Third141Proof103

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third141Proof2 : runCachedNode 511 131086 Adaptive147Third141Node2 = false := by
  decide +kernel

#print axioms adaptive147Third141Proof2

end NineSeparatedSubsetSums
