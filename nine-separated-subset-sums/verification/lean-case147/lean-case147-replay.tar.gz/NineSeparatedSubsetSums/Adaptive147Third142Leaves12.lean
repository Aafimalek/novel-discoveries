import NineSeparatedSubsetSums.Adaptive147Third142State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third142Proof170 : runCachedNode 511 131213 Adaptive147Third142Node170 = false := by
  decide +kernel

#print axioms adaptive147Third142Proof170

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third142Proof137 : runCachedNode 511 131213 Adaptive147Third142Node137 = false := by
  decide +kernel

#print axioms adaptive147Third142Proof137

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third142Proof29 : runCachedNode 511 131213 Adaptive147Third142Node29 = false := by
  decide +kernel

#print axioms adaptive147Third142Proof29

end NineSeparatedSubsetSums
