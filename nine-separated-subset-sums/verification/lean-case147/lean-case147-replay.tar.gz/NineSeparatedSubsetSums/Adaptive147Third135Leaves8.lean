import NineSeparatedSubsetSums.Adaptive147Third135State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third135Proof42 : runCachedNode 511 130219 Adaptive147Third135Node42 = false := by
  decide +kernel

#print axioms adaptive147Third135Proof42

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third135Proof65 : runCachedNode 511 130219 Adaptive147Third135Node65 = false := by
  decide +kernel

#print axioms adaptive147Third135Proof65

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third135Proof7 : runCachedNode 511 130219 Adaptive147Third135Node7 = false := by
  decide +kernel

#print axioms adaptive147Third135Proof7

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third135Proof38 : runCachedNode 511 130219 Adaptive147Third135Node38 = false := by
  decide +kernel

#print axioms adaptive147Third135Proof38

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third135Proof64 : runCachedNode 511 130219 Adaptive147Third135Node64 = false := by
  decide +kernel

#print axioms adaptive147Third135Proof64

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third135Proof6 : runCachedNode 511 130219 Adaptive147Third135Node6 = false := by
  decide +kernel

#print axioms adaptive147Third135Proof6

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third135Proof36 : runCachedNode 511 130219 Adaptive147Third135Node36 = false := by
  decide +kernel

#print axioms adaptive147Third135Proof36

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third135Proof63 : runCachedNode 511 130219 Adaptive147Third135Node63 = false := by
  decide +kernel

#print axioms adaptive147Third135Proof63

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third135Proof62 : runCachedNode 511 130219 Adaptive147Third135Node62 = false := by
  decide +kernel

#print axioms adaptive147Third135Proof62

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third135Proof35 : runCachedNode 511 130219 Adaptive147Third135Node35 = false := by
  decide +kernel

#print axioms adaptive147Third135Proof35

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third135Proof61 : runCachedNode 511 130219 Adaptive147Third135Node61 = false := by
  decide +kernel

#print axioms adaptive147Third135Proof61

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third135Proof60 : runCachedNode 511 130219 Adaptive147Third135Node60 = false := by
  decide +kernel

#print axioms adaptive147Third135Proof60

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third135Proof5 : runCachedNode 511 130219 Adaptive147Third135Node5 = false := by
  decide +kernel

#print axioms adaptive147Third135Proof5

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third135Proof34 : runCachedNode 511 130219 Adaptive147Third135Node34 = false := by
  decide +kernel

#print axioms adaptive147Third135Proof34

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third135Proof59 : runCachedNode 511 130219 Adaptive147Third135Node59 = false := by
  decide +kernel

#print axioms adaptive147Third135Proof59

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third135Proof58 : runCachedNode 511 130219 Adaptive147Third135Node58 = false := by
  decide +kernel

#print axioms adaptive147Third135Proof58

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third135Proof57 : runCachedNode 511 130219 Adaptive147Third135Node57 = false := by
  decide +kernel

#print axioms adaptive147Third135Proof57

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third135Proof4 : runCachedNode 511 130219 Adaptive147Third135Node4 = false := by
  decide +kernel

#print axioms adaptive147Third135Proof4

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third135Proof33 : runCachedNode 511 130219 Adaptive147Third135Node33 = false := by
  decide +kernel

#print axioms adaptive147Third135Proof33

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third135Proof32 : runCachedNode 511 130219 Adaptive147Third135Node32 = false := by
  decide +kernel

#print axioms adaptive147Third135Proof32

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third135Proof56 : runCachedNode 511 130219 Adaptive147Third135Node56 = false := by
  decide +kernel

#print axioms adaptive147Third135Proof56

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third135Proof55 : runCachedNode 511 130219 Adaptive147Third135Node55 = false := by
  decide +kernel

#print axioms adaptive147Third135Proof55

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third135Proof3 : runCachedNode 511 130219 Adaptive147Third135Node3 = false := by
  decide +kernel

#print axioms adaptive147Third135Proof3

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third135Proof54 : runCachedNode 511 130219 Adaptive147Third135Node54 = false := by
  decide +kernel

#print axioms adaptive147Third135Proof54

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third135Proof28 : runCachedNode 511 130219 Adaptive147Third135Node28 = false := by
  decide +kernel

#print axioms adaptive147Third135Proof28

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third135Proof53 : runCachedNode 511 130219 Adaptive147Third135Node53 = false := by
  decide +kernel

#print axioms adaptive147Third135Proof53

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third135Proof27 : runCachedNode 511 130219 Adaptive147Third135Node27 = false := by
  decide +kernel

#print axioms adaptive147Third135Proof27

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third135Proof51 : runCachedNode 511 130219 Adaptive147Third135Node51 = false := by
  decide +kernel

#print axioms adaptive147Third135Proof51

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third135Proof52 : runCachedNode 511 130219 Adaptive147Third135Node52 = false := by
  decide +kernel

#print axioms adaptive147Third135Proof52

end NineSeparatedSubsetSums
