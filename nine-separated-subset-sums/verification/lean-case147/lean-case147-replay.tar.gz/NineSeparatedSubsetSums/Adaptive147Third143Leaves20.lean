import NineSeparatedSubsetSums.Adaptive147Third143State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third143Proof197 : runCachedNode 511 131344 Adaptive147Third143Node197 = false := by
  decide +kernel

#print axioms adaptive147Third143Proof197

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third143Proof230 : runCachedNode 511 131344 Adaptive147Third143Node230 = false := by
  decide +kernel

#print axioms adaptive147Third143Proof230

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third143Proof418 : runCachedNode 511 131344 Adaptive147Third143Node418 = false := by
  decide +kernel

#print axioms adaptive147Third143Proof418

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third143Proof335 : runCachedNode 511 131344 Adaptive147Third143Node335 = false := by
  decide +kernel

#print axioms adaptive147Third143Proof335

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third143Proof78 : runCachedNode 511 131344 Adaptive147Third143Node78 = false := by
  decide +kernel

#print axioms adaptive147Third143Proof78

end NineSeparatedSubsetSums
