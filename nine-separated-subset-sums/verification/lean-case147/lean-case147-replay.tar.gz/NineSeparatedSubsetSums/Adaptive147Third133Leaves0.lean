import NineSeparatedSubsetSums.Adaptive147Third133State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third133Proof21 : runCachedNode 511 129861 Adaptive147Third133Node21 = false := by
  decide +kernel

#print axioms adaptive147Third133Proof21

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third133Proof15 : runCachedNode 511 129861 Adaptive147Third133Node15 = false := by
  decide +kernel

#print axioms adaptive147Third133Proof15

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third133Proof39 : runCachedNode 511 129861 Adaptive147Third133Node39 = false := by
  decide +kernel

#print axioms adaptive147Third133Proof39

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third133Proof2 : runCachedNode 511 129861 Adaptive147Third133Node2 = false := by
  decide +kernel

#print axioms adaptive147Third133Proof2

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third133Proof1 : runCachedNode 511 129861 Adaptive147Third133Node1 = false := by
  decide +kernel

#print axioms adaptive147Third133Proof1

end NineSeparatedSubsetSums
