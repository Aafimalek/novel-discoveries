import NineSeparatedSubsetSums.Adaptive147Third141State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third141Proof338 : runCachedNode 511 131086 Adaptive147Third141Node338 = false := by
  decide +kernel

#print axioms adaptive147Third141Proof338

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third141Proof229 : runCachedNode 511 131086 Adaptive147Third141Node229 = false := by
  decide +kernel

#print axioms adaptive147Third141Proof229

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third141Proof168 : runCachedNode 511 131086 Adaptive147Third141Node168 = false := by
  decide +kernel

#print axioms adaptive147Third141Proof168

end NineSeparatedSubsetSums
