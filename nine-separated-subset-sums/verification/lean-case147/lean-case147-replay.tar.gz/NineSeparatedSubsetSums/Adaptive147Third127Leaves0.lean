import NineSeparatedSubsetSums.Adaptive147Third127State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third127Proof16 : runCachedNode 511 128514 Adaptive147Third127Node16 = false := by
  decide +kernel

#print axioms adaptive147Third127Proof16

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third127Proof15 : runCachedNode 511 128514 Adaptive147Third127Node15 = false := by
  decide +kernel

#print axioms adaptive147Third127Proof15

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third127Proof14 : runCachedNode 511 128514 Adaptive147Third127Node14 = false := by
  decide +kernel

#print axioms adaptive147Third127Proof14

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third127Proof13 : runCachedNode 511 128514 Adaptive147Third127Node13 = false := by
  decide +kernel

#print axioms adaptive147Third127Proof13

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third127Proof12 : runCachedNode 511 128514 Adaptive147Third127Node12 = false := by
  decide +kernel

#print axioms adaptive147Third127Proof12

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third127Proof8 : runCachedNode 511 128514 Adaptive147Third127Node8 = false := by
  decide +kernel

#print axioms adaptive147Third127Proof8

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third127Proof4 : runCachedNode 511 128514 Adaptive147Third127Node4 = false := by
  decide +kernel

#print axioms adaptive147Third127Proof4

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third127Proof3 : runCachedNode 511 128514 Adaptive147Third127Node3 = false := by
  decide +kernel

#print axioms adaptive147Third127Proof3

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third127Proof2 : runCachedNode 511 128514 Adaptive147Third127Node2 = false := by
  decide +kernel

#print axioms adaptive147Third127Proof2

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third127Proof1 : runCachedNode 511 128514 Adaptive147Third127Node1 = false := by
  decide +kernel

#print axioms adaptive147Third127Proof1

end NineSeparatedSubsetSums
