import NineSeparatedSubsetSums.Adaptive147Third127State
import NineSeparatedSubsetSums.Adaptive147Third127Leaves0
import NineSeparatedSubsetSums.Adaptive147Third127Leaves1

namespace NineSeparatedSubsetSums

theorem adaptive147Third127Proof0 : runCachedNode 511 128514 Adaptive147Third127Node0 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 128514 Adaptive147Third127Node0 = [110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive147Third127Proof1
  · exact adaptive147Third127Proof2
  · exact adaptive147Third127Proof3
  · exact adaptive147Third127Proof4
  · exact adaptive147Third127Proof5
  · exact adaptive147Third127Proof6
  · exact adaptive147Third127Proof7
  · exact adaptive147Third127Proof8
  · exact adaptive147Third127Proof9
  · exact adaptive147Third127Proof10
  · exact adaptive147Third127Proof11
  · exact adaptive147Third127Proof12
  · exact adaptive147Third127Proof13
  · exact adaptive147Third127Proof14
  · exact adaptive147Third127Proof15
  · exact adaptive147Third127Proof16

#print axioms adaptive147Third127Proof0

end NineSeparatedSubsetSums
