import NineSeparatedSubsetSums.Adaptive147Third144State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof742 : runCachedNode 511 131483 Adaptive147Third144Node742 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof742

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof301 : runCachedNode 511 131483 Adaptive147Third144Node301 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof301

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof374 : runCachedNode 511 131483 Adaptive147Third144Node374 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof374

end NineSeparatedSubsetSums
