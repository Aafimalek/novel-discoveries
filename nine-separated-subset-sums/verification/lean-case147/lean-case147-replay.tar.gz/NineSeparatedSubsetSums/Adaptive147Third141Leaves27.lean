import NineSeparatedSubsetSums.Adaptive147Third141State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third141Proof72 : runCachedNode 511 131086 Adaptive147Third141Node72 = false := by
  decide +kernel

#print axioms adaptive147Third141Proof72

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third141Proof298 : runCachedNode 511 131086 Adaptive147Third141Node298 = false := by
  decide +kernel

#print axioms adaptive147Third141Proof298

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third141Proof46 : runCachedNode 511 131086 Adaptive147Third141Node46 = false := by
  decide +kernel

#print axioms adaptive147Third141Proof46

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third141Proof257 : runCachedNode 511 131086 Adaptive147Third141Node257 = false := by
  decide +kernel

#print axioms adaptive147Third141Proof257

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third141Proof70 : runCachedNode 511 131086 Adaptive147Third141Node70 = false := by
  decide +kernel

#print axioms adaptive147Third141Proof70

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third141Proof11 : runCachedNode 511 131086 Adaptive147Third141Node11 = false := by
  decide +kernel

#print axioms adaptive147Third141Proof11

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third141Proof123 : runCachedNode 511 131086 Adaptive147Third141Node123 = false := by
  decide +kernel

#print axioms adaptive147Third141Proof123

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third141Proof187 : runCachedNode 511 131086 Adaptive147Third141Node187 = false := by
  decide +kernel

#print axioms adaptive147Third141Proof187

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third141Proof258 : runCachedNode 511 131086 Adaptive147Third141Node258 = false := by
  decide +kernel

#print axioms adaptive147Third141Proof258

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third141Proof222 : runCachedNode 511 131086 Adaptive147Third141Node222 = false := by
  decide +kernel

#print axioms adaptive147Third141Proof222

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third141Proof42 : runCachedNode 511 131086 Adaptive147Third141Node42 = false := by
  decide +kernel

#print axioms adaptive147Third141Proof42

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third141Proof144 : runCachedNode 511 131086 Adaptive147Third141Node144 = false := by
  decide +kernel

#print axioms adaptive147Third141Proof144

end NineSeparatedSubsetSums
