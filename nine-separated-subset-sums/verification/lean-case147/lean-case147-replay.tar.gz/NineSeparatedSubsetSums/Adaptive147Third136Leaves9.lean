import NineSeparatedSubsetSums.Adaptive147Third136State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third136Proof67 : runCachedNode 511 130369 Adaptive147Third136Node67 = false := by
  decide +kernel

#print axioms adaptive147Third136Proof67

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third136Proof121 : runCachedNode 511 130369 Adaptive147Third136Node121 = false := by
  decide +kernel

#print axioms adaptive147Third136Proof121

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third136Proof70 : runCachedNode 511 130369 Adaptive147Third136Node70 = false := by
  decide +kernel

#print axioms adaptive147Third136Proof70

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third136Proof41 : runCachedNode 511 130369 Adaptive147Third136Node41 = false := by
  decide +kernel

#print axioms adaptive147Third136Proof41

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third136Proof94 : runCachedNode 511 130369 Adaptive147Third136Node94 = false := by
  decide +kernel

#print axioms adaptive147Third136Proof94

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third136Proof98 : runCachedNode 511 130369 Adaptive147Third136Node98 = false := by
  decide +kernel

#print axioms adaptive147Third136Proof98

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third136Proof11 : runCachedNode 511 130369 Adaptive147Third136Node11 = false := by
  decide +kernel

#print axioms adaptive147Third136Proof11

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third136Proof93 : runCachedNode 511 130369 Adaptive147Third136Node93 = false := by
  decide +kernel

#print axioms adaptive147Third136Proof93

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third136Proof10 : runCachedNode 511 130369 Adaptive147Third136Node10 = false := by
  decide +kernel

#print axioms adaptive147Third136Proof10

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third136Proof120 : runCachedNode 511 130369 Adaptive147Third136Node120 = false := by
  decide +kernel

#print axioms adaptive147Third136Proof120

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third136Proof125 : runCachedNode 511 130369 Adaptive147Third136Node125 = false := by
  decide +kernel

#print axioms adaptive147Third136Proof125

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third136Proof2 : runCachedNode 511 130369 Adaptive147Third136Node2 = false := by
  decide +kernel

#print axioms adaptive147Third136Proof2

end NineSeparatedSubsetSums
