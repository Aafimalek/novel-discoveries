import NineSeparatedSubsetSums.Adaptive147Third140State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third140Proof164 : runCachedNode 511 130945 Adaptive147Third140Node164 = false := by
  decide +kernel

#print axioms adaptive147Third140Proof164

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third140Proof258 : runCachedNode 511 130945 Adaptive147Third140Node258 = false := by
  decide +kernel

#print axioms adaptive147Third140Proof258

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third140Proof180 : runCachedNode 511 130945 Adaptive147Third140Node180 = false := by
  decide +kernel

#print axioms adaptive147Third140Proof180

end NineSeparatedSubsetSums
