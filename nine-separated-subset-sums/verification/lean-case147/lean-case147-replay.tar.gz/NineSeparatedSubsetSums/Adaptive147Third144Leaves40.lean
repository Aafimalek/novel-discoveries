import NineSeparatedSubsetSums.Adaptive147Third144State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof103 : runCachedNode 511 131483 Adaptive147Third144Node103 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof103

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof195 : runCachedNode 511 131483 Adaptive147Third144Node195 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof195

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof455 : runCachedNode 511 131483 Adaptive147Third144Node455 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof455

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof703 : runCachedNode 511 131483 Adaptive147Third144Node703 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof703

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof161 : runCachedNode 511 131483 Adaptive147Third144Node161 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof161

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof615 : runCachedNode 511 131483 Adaptive147Third144Node615 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof615

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof159 : runCachedNode 511 131483 Adaptive147Third144Node159 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof159

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof207 : runCachedNode 511 131483 Adaptive147Third144Node207 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof207

end NineSeparatedSubsetSums
