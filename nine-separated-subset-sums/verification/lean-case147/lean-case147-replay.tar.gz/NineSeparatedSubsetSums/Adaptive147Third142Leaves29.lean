import NineSeparatedSubsetSums.Adaptive147Third142State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third142Proof108 : runCachedNode 511 131213 Adaptive147Third142Node108 = false := by
  decide +kernel

#print axioms adaptive147Third142Proof108

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third142Proof310 : runCachedNode 511 131213 Adaptive147Third142Node310 = false := by
  decide +kernel

#print axioms adaptive147Third142Proof310

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third142Proof476 : runCachedNode 511 131213 Adaptive147Third142Node476 = false := by
  decide +kernel

#print axioms adaptive147Third142Proof476

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third142Proof433 : runCachedNode 511 131213 Adaptive147Third142Node433 = false := by
  decide +kernel

#print axioms adaptive147Third142Proof433

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third142Proof233 : runCachedNode 511 131213 Adaptive147Third142Node233 = false := by
  decide +kernel

#print axioms adaptive147Third142Proof233

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third142Proof197 : runCachedNode 511 131213 Adaptive147Third142Node197 = false := by
  decide +kernel

#print axioms adaptive147Third142Proof197

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third142Proof471 : runCachedNode 511 131213 Adaptive147Third142Node471 = false := by
  decide +kernel

#print axioms adaptive147Third142Proof471

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third142Proof2 : runCachedNode 511 131213 Adaptive147Third142Node2 = false := by
  decide +kernel

#print axioms adaptive147Third142Proof2

end NineSeparatedSubsetSums
