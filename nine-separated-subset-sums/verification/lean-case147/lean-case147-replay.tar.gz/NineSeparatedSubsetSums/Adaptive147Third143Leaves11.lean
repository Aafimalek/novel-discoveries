import NineSeparatedSubsetSums.Adaptive147Third143State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third143Proof262 : runCachedNode 511 131344 Adaptive147Third143Node262 = false := by
  decide +kernel

#print axioms adaptive147Third143Proof262

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third143Proof508 : runCachedNode 511 131344 Adaptive147Third143Node508 = false := by
  decide +kernel

#print axioms adaptive147Third143Proof508

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third143Proof486 : runCachedNode 511 131344 Adaptive147Third143Node486 = false := by
  decide +kernel

#print axioms adaptive147Third143Proof486

end NineSeparatedSubsetSums
