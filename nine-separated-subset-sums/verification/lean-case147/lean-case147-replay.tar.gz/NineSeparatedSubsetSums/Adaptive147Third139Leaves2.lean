import NineSeparatedSubsetSums.Adaptive147Third139State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third139Proof184 : runCachedNode 511 130807 Adaptive147Third139Node184 = false := by
  decide +kernel

#print axioms adaptive147Third139Proof184

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third139Proof125 : runCachedNode 511 130807 Adaptive147Third139Node125 = false := by
  decide +kernel

#print axioms adaptive147Third139Proof125

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third139Proof168 : runCachedNode 511 130807 Adaptive147Third139Node168 = false := by
  decide +kernel

#print axioms adaptive147Third139Proof168

end NineSeparatedSubsetSums
