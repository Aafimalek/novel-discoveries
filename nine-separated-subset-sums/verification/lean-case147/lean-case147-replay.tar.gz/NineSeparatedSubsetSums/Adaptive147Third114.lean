import NineSeparatedSubsetSums.Adaptive147Third114Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint147Checked

namespace NineSeparatedSubsetSums


theorem adaptive147Third114 : NoDescendingTailAfterThird 147 114 :=
  noDescendingThirdTail_of_cached 147 114 112835 (fun t ht nd => max148_second147_fourPoint_moment_bound (114::t) (by simp [ht]) nd) adaptive147Third114Proof0

#print axioms adaptive147Third114

end NineSeparatedSubsetSums
