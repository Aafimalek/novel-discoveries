import NineSeparatedSubsetSums.Adaptive147Third140State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third140Proof255 : runCachedNode 511 130945 Adaptive147Third140Node255 = false := by
  decide +kernel

#print axioms adaptive147Third140Proof255

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third140Proof95 : runCachedNode 511 130945 Adaptive147Third140Node95 = false := by
  decide +kernel

#print axioms adaptive147Third140Proof95

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third140Proof125 : runCachedNode 511 130945 Adaptive147Third140Node125 = false := by
  decide +kernel

#print axioms adaptive147Third140Proof125

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third140Proof68 : runCachedNode 511 130945 Adaptive147Third140Node68 = false := by
  decide +kernel

#print axioms adaptive147Third140Proof68

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third140Proof67 : runCachedNode 511 130945 Adaptive147Third140Node67 = false := by
  decide +kernel

#print axioms adaptive147Third140Proof67

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third140Proof94 : runCachedNode 511 130945 Adaptive147Third140Node94 = false := by
  decide +kernel

#print axioms adaptive147Third140Proof94

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third140Proof126 : runCachedNode 511 130945 Adaptive147Third140Node126 = false := by
  decide +kernel

#print axioms adaptive147Third140Proof126

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third140Proof221 : runCachedNode 511 130945 Adaptive147Third140Node221 = false := by
  decide +kernel

#print axioms adaptive147Third140Proof221

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third140Proof11 : runCachedNode 511 130945 Adaptive147Third140Node11 = false := by
  decide +kernel

#print axioms adaptive147Third140Proof11

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third140Proof155 : runCachedNode 511 130945 Adaptive147Third140Node155 = false := by
  decide +kernel

#print axioms adaptive147Third140Proof155

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third140Proof45 : runCachedNode 511 130945 Adaptive147Third140Node45 = false := by
  decide +kernel

#print axioms adaptive147Third140Proof45

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third140Proof206 : runCachedNode 511 130945 Adaptive147Third140Node206 = false := by
  decide +kernel

#print axioms adaptive147Third140Proof206

end NineSeparatedSubsetSums
