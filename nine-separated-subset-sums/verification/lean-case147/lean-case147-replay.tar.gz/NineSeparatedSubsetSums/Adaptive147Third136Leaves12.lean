import NineSeparatedSubsetSums.Adaptive147Third136State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third136Proof77 : runCachedNode 511 130369 Adaptive147Third136Node77 = false := by
  decide +kernel

#print axioms adaptive147Third136Proof77

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third136Proof103 : runCachedNode 511 130369 Adaptive147Third136Node103 = false := by
  decide +kernel

#print axioms adaptive147Third136Proof103

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third136Proof104 : runCachedNode 511 130369 Adaptive147Third136Node104 = false := by
  decide +kernel

#print axioms adaptive147Third136Proof104

end NineSeparatedSubsetSums
