import NineSeparatedSubsetSums.Adaptive147Third142State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third142Proof391 : runCachedNode 511 131213 Adaptive147Third142Node391 = false := by
  decide +kernel

#print axioms adaptive147Third142Proof391

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third142Proof71 : runCachedNode 511 131213 Adaptive147Third142Node71 = false := by
  decide +kernel

#print axioms adaptive147Third142Proof71

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third142Proof1 : runCachedNode 511 131213 Adaptive147Third142Node1 = false := by
  decide +kernel

#print axioms adaptive147Third142Proof1

end NineSeparatedSubsetSums
