import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive147Third104Node0 : CachedSearchNode :=
  ⟨4, 103, computeCenteredMask [148,147,104], 399, 54329⟩

end NineSeparatedSubsetSums
