import NineSeparatedSubsetSums.Adaptive147Third144State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof731 : runCachedNode 511 131483 Adaptive147Third144Node731 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof731

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof12 : runCachedNode 511 131483 Adaptive147Third144Node12 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof12

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof74 : runCachedNode 511 131483 Adaptive147Third144Node74 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof74

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof616 : runCachedNode 511 131483 Adaptive147Third144Node616 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof616

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof329 : runCachedNode 511 131483 Adaptive147Third144Node329 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof329

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof47 : runCachedNode 511 131483 Adaptive147Third144Node47 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof47

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof523 : runCachedNode 511 131483 Adaptive147Third144Node523 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof523

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof260 : runCachedNode 511 131483 Adaptive147Third144Node260 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof260

end NineSeparatedSubsetSums
