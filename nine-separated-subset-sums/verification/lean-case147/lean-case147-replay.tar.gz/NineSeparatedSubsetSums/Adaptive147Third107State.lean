import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive147Third107Node0 : CachedSearchNode :=
  ⟨4, 106, computeCenteredMask [148,147,107], 402, 54962⟩

end NineSeparatedSubsetSums
