import NineSeparatedSubsetSums.Adaptive147Third140State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third140Proof228 : runCachedNode 511 130945 Adaptive147Third140Node228 = false := by
  decide +kernel

#print axioms adaptive147Third140Proof228

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third140Proof259 : runCachedNode 511 130945 Adaptive147Third140Node259 = false := by
  decide +kernel

#print axioms adaptive147Third140Proof259

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third140Proof5 : runCachedNode 511 130945 Adaptive147Third140Node5 = false := by
  decide +kernel

#print axioms adaptive147Third140Proof5

end NineSeparatedSubsetSums
