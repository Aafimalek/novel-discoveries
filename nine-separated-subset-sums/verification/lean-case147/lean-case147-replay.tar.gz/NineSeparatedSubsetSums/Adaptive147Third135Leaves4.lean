import NineSeparatedSubsetSums.Adaptive147Third135State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third135Proof18 : runCachedNode 511 130219 Adaptive147Third135Node18 = false := by
  decide +kernel

#print axioms adaptive147Third135Proof18

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third135Proof17 : runCachedNode 511 130219 Adaptive147Third135Node17 = false := by
  decide +kernel

#print axioms adaptive147Third135Proof17

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third135Proof10 : runCachedNode 511 130219 Adaptive147Third135Node10 = false := by
  decide +kernel

#print axioms adaptive147Third135Proof10

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third135Proof25 : runCachedNode 511 130219 Adaptive147Third135Node25 = false := by
  decide +kernel

#print axioms adaptive147Third135Proof25

end NineSeparatedSubsetSums
