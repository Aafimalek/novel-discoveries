import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive147Third117Node0 : CachedSearchNode :=
  ⟨4, 116, computeCenteredMask [148,147,117], 412, 57202⟩

end NineSeparatedSubsetSums
