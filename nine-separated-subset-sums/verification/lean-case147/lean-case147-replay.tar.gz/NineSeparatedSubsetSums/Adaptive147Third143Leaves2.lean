import NineSeparatedSubsetSums.Adaptive147Third143State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third143Proof267 : runCachedNode 511 131344 Adaptive147Third143Node267 = false := by
  decide +kernel

#print axioms adaptive147Third143Proof267

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third143Proof43 : runCachedNode 511 131344 Adaptive147Third143Node43 = false := by
  decide +kernel

#print axioms adaptive147Third143Proof43

end NineSeparatedSubsetSums
