import NineSeparatedSubsetSums.Adaptive147Third140State
import NineSeparatedSubsetSums.Adaptive147Third140Leaves25
import NineSeparatedSubsetSums.Adaptive147Third140Leaves28
import NineSeparatedSubsetSums.Adaptive147Third140Leaves5
import NineSeparatedSubsetSums.Adaptive147Third140Leaves24
import NineSeparatedSubsetSums.Adaptive147Third140Leaves27
import NineSeparatedSubsetSums.Adaptive147Third140Leaves18
import NineSeparatedSubsetSums.Adaptive147Third140Leaves26
import NineSeparatedSubsetSums.Adaptive147Third140Leaves19
import NineSeparatedSubsetSums.Adaptive147Third140Leaves21
import NineSeparatedSubsetSums.Adaptive147Third140Leaves23
import NineSeparatedSubsetSums.Adaptive147Third140Leaves20
import NineSeparatedSubsetSums.Adaptive147Third140Leaves29
import NineSeparatedSubsetSums.Adaptive147Third140Leaves0
import NineSeparatedSubsetSums.Adaptive147Third140Leaves6
import NineSeparatedSubsetSums.Adaptive147Third140Leaves1
import NineSeparatedSubsetSums.Adaptive147Third140Leaves13
import NineSeparatedSubsetSums.Adaptive147Third140Leaves17
import NineSeparatedSubsetSums.Adaptive147Third140Leaves11
import NineSeparatedSubsetSums.Adaptive147Third140Leaves16
import NineSeparatedSubsetSums.Adaptive147Third140Leaves9
import NineSeparatedSubsetSums.Adaptive147Third140Leaves7
import NineSeparatedSubsetSums.Adaptive147Third140Leaves2
import NineSeparatedSubsetSums.Adaptive147Third140Leaves22
import NineSeparatedSubsetSums.Adaptive147Third140Leaves14
import NineSeparatedSubsetSums.Adaptive147Third140Leaves15
import NineSeparatedSubsetSums.Adaptive147Third140Leaves3
import NineSeparatedSubsetSums.Adaptive147Third140Leaves4
import NineSeparatedSubsetSums.Adaptive147Third140Leaves8
import NineSeparatedSubsetSums.Adaptive147Third140Leaves12
import NineSeparatedSubsetSums.Adaptive147Third140Leaves10

namespace NineSeparatedSubsetSums

theorem adaptive147Third140Proof23 : runCachedNode 511 130945 Adaptive147Third140Node23 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130945 Adaptive147Third140Node23 = [103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 125, 126, 127, 128, 129] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive147Third140Proof24
  · exact adaptive147Third140Proof25
  · exact adaptive147Third140Proof26
  · exact adaptive147Third140Proof27
  · exact adaptive147Third140Proof28
  · exact adaptive147Third140Proof29
  · exact adaptive147Third140Proof30
  · exact adaptive147Third140Proof31
  · exact adaptive147Third140Proof32
  · exact adaptive147Third140Proof33
  · exact adaptive147Third140Proof34
  · exact adaptive147Third140Proof35
  · exact adaptive147Third140Proof36
  · exact adaptive147Third140Proof37
  · exact adaptive147Third140Proof38
  · exact adaptive147Third140Proof39
  · exact adaptive147Third140Proof40
  · exact adaptive147Third140Proof41
  · exact adaptive147Third140Proof42
  · exact adaptive147Third140Proof43
  · exact adaptive147Third140Proof44
  · exact adaptive147Third140Proof45
  · exact adaptive147Third140Proof46
  · exact adaptive147Third140Proof47
  · exact adaptive147Third140Proof48

#print axioms adaptive147Third140Proof23

theorem adaptive147Third140Proof49 : runCachedNode 511 130945 Adaptive147Third140Node49 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130945 Adaptive147Third140Node49 = [103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 126, 127, 128, 129, 130] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive147Third140Proof50
  · exact adaptive147Third140Proof51
  · exact adaptive147Third140Proof52
  · exact adaptive147Third140Proof53
  · exact adaptive147Third140Proof54
  · exact adaptive147Third140Proof55
  · exact adaptive147Third140Proof56
  · exact adaptive147Third140Proof57
  · exact adaptive147Third140Proof58
  · exact adaptive147Third140Proof59
  · exact adaptive147Third140Proof60
  · exact adaptive147Third140Proof61
  · exact adaptive147Third140Proof62
  · exact adaptive147Third140Proof63
  · exact adaptive147Third140Proof64
  · exact adaptive147Third140Proof65
  · exact adaptive147Third140Proof66
  · exact adaptive147Third140Proof67
  · exact adaptive147Third140Proof68
  · exact adaptive147Third140Proof69
  · exact adaptive147Third140Proof70
  · exact adaptive147Third140Proof71
  · exact adaptive147Third140Proof72
  · exact adaptive147Third140Proof73
  · exact adaptive147Third140Proof74
  · exact adaptive147Third140Proof75

#print axioms adaptive147Third140Proof49

theorem adaptive147Third140Proof76 : runCachedNode 511 130945 Adaptive147Third140Node76 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130945 Adaptive147Third140Node76 = [103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 127, 128, 129, 130, 131] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive147Third140Proof77
  · exact adaptive147Third140Proof78
  · exact adaptive147Third140Proof79
  · exact adaptive147Third140Proof80
  · exact adaptive147Third140Proof81
  · exact adaptive147Third140Proof82
  · exact adaptive147Third140Proof83
  · exact adaptive147Third140Proof84
  · exact adaptive147Third140Proof85
  · exact adaptive147Third140Proof86
  · exact adaptive147Third140Proof87
  · exact adaptive147Third140Proof88
  · exact adaptive147Third140Proof89
  · exact adaptive147Third140Proof90
  · exact adaptive147Third140Proof91
  · exact adaptive147Third140Proof92
  · exact adaptive147Third140Proof93
  · exact adaptive147Third140Proof94
  · exact adaptive147Third140Proof95
  · exact adaptive147Third140Proof96
  · exact adaptive147Third140Proof97
  · exact adaptive147Third140Proof98
  · exact adaptive147Third140Proof99
  · exact adaptive147Third140Proof100
  · exact adaptive147Third140Proof101
  · exact adaptive147Third140Proof102
  · exact adaptive147Third140Proof103

#print axioms adaptive147Third140Proof76

theorem adaptive147Third140Proof104 : runCachedNode 511 130945 Adaptive147Third140Node104 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130945 Adaptive147Third140Node104 = [102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 128, 129, 130, 131, 132] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive147Third140Proof105
  · exact adaptive147Third140Proof106
  · exact adaptive147Third140Proof107
  · exact adaptive147Third140Proof108
  · exact adaptive147Third140Proof109
  · exact adaptive147Third140Proof110
  · exact adaptive147Third140Proof111
  · exact adaptive147Third140Proof112
  · exact adaptive147Third140Proof113
  · exact adaptive147Third140Proof114
  · exact adaptive147Third140Proof115
  · exact adaptive147Third140Proof116
  · exact adaptive147Third140Proof117
  · exact adaptive147Third140Proof118
  · exact adaptive147Third140Proof119
  · exact adaptive147Third140Proof120
  · exact adaptive147Third140Proof121
  · exact adaptive147Third140Proof122
  · exact adaptive147Third140Proof123
  · exact adaptive147Third140Proof124
  · exact adaptive147Third140Proof125
  · exact adaptive147Third140Proof126
  · exact adaptive147Third140Proof127
  · exact adaptive147Third140Proof128
  · exact adaptive147Third140Proof129
  · exact adaptive147Third140Proof130
  · exact adaptive147Third140Proof131
  · exact adaptive147Third140Proof132
  · exact adaptive147Third140Proof133

#print axioms adaptive147Third140Proof104

theorem adaptive147Third140Proof134 : runCachedNode 511 130945 Adaptive147Third140Node134 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130945 Adaptive147Third140Node134 = [102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 129, 130, 131, 132, 133] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive147Third140Proof135
  · exact adaptive147Third140Proof136
  · exact adaptive147Third140Proof137
  · exact adaptive147Third140Proof138
  · exact adaptive147Third140Proof139
  · exact adaptive147Third140Proof140
  · exact adaptive147Third140Proof141
  · exact adaptive147Third140Proof142
  · exact adaptive147Third140Proof143
  · exact adaptive147Third140Proof144
  · exact adaptive147Third140Proof145
  · exact adaptive147Third140Proof146
  · exact adaptive147Third140Proof147
  · exact adaptive147Third140Proof148
  · exact adaptive147Third140Proof149
  · exact adaptive147Third140Proof150
  · exact adaptive147Third140Proof151
  · exact adaptive147Third140Proof152
  · exact adaptive147Third140Proof153
  · exact adaptive147Third140Proof154
  · exact adaptive147Third140Proof155
  · exact adaptive147Third140Proof156
  · exact adaptive147Third140Proof157
  · exact adaptive147Third140Proof158
  · exact adaptive147Third140Proof159
  · exact adaptive147Third140Proof160
  · exact adaptive147Third140Proof161
  · exact adaptive147Third140Proof162
  · exact adaptive147Third140Proof163
  · exact adaptive147Third140Proof164

#print axioms adaptive147Third140Proof134

theorem adaptive147Third140Proof165 : runCachedNode 511 130945 Adaptive147Third140Node165 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130945 Adaptive147Third140Node165 = [102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 130, 131, 132, 133, 134] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive147Third140Proof166
  · exact adaptive147Third140Proof167
  · exact adaptive147Third140Proof168
  · exact adaptive147Third140Proof169
  · exact adaptive147Third140Proof170
  · exact adaptive147Third140Proof171
  · exact adaptive147Third140Proof172
  · exact adaptive147Third140Proof173
  · exact adaptive147Third140Proof174
  · exact adaptive147Third140Proof175
  · exact adaptive147Third140Proof176
  · exact adaptive147Third140Proof177
  · exact adaptive147Third140Proof178
  · exact adaptive147Third140Proof179
  · exact adaptive147Third140Proof180
  · exact adaptive147Third140Proof181
  · exact adaptive147Third140Proof182
  · exact adaptive147Third140Proof183
  · exact adaptive147Third140Proof184
  · exact adaptive147Third140Proof185
  · exact adaptive147Third140Proof186
  · exact adaptive147Third140Proof187
  · exact adaptive147Third140Proof188
  · exact adaptive147Third140Proof189
  · exact adaptive147Third140Proof190
  · exact adaptive147Third140Proof191
  · exact adaptive147Third140Proof192
  · exact adaptive147Third140Proof193
  · exact adaptive147Third140Proof194
  · exact adaptive147Third140Proof195
  · exact adaptive147Third140Proof196

#print axioms adaptive147Third140Proof165

theorem adaptive147Third140Proof197 : runCachedNode 511 130945 Adaptive147Third140Node197 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130945 Adaptive147Third140Node197 = [102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 131, 132, 133, 134, 135] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive147Third140Proof198
  · exact adaptive147Third140Proof199
  · exact adaptive147Third140Proof200
  · exact adaptive147Third140Proof201
  · exact adaptive147Third140Proof202
  · exact adaptive147Third140Proof203
  · exact adaptive147Third140Proof204
  · exact adaptive147Third140Proof205
  · exact adaptive147Third140Proof206
  · exact adaptive147Third140Proof207
  · exact adaptive147Third140Proof208
  · exact adaptive147Third140Proof209
  · exact adaptive147Third140Proof210
  · exact adaptive147Third140Proof211
  · exact adaptive147Third140Proof212
  · exact adaptive147Third140Proof213
  · exact adaptive147Third140Proof214
  · exact adaptive147Third140Proof215
  · exact adaptive147Third140Proof216
  · exact adaptive147Third140Proof217
  · exact adaptive147Third140Proof218
  · exact adaptive147Third140Proof219
  · exact adaptive147Third140Proof220
  · exact adaptive147Third140Proof221
  · exact adaptive147Third140Proof222
  · exact adaptive147Third140Proof223
  · exact adaptive147Third140Proof224
  · exact adaptive147Third140Proof225
  · exact adaptive147Third140Proof226
  · exact adaptive147Third140Proof227
  · exact adaptive147Third140Proof228
  · exact adaptive147Third140Proof229

#print axioms adaptive147Third140Proof197

theorem adaptive147Third140Proof230 : runCachedNode 511 130945 Adaptive147Third140Node230 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130945 Adaptive147Third140Node230 = [101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 132, 133, 134, 135, 136] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive147Third140Proof231
  · exact adaptive147Third140Proof232
  · exact adaptive147Third140Proof233
  · exact adaptive147Third140Proof234
  · exact adaptive147Third140Proof235
  · exact adaptive147Third140Proof236
  · exact adaptive147Third140Proof237
  · exact adaptive147Third140Proof238
  · exact adaptive147Third140Proof239
  · exact adaptive147Third140Proof240
  · exact adaptive147Third140Proof241
  · exact adaptive147Third140Proof242
  · exact adaptive147Third140Proof243
  · exact adaptive147Third140Proof244
  · exact adaptive147Third140Proof245
  · exact adaptive147Third140Proof246
  · exact adaptive147Third140Proof247
  · exact adaptive147Third140Proof248
  · exact adaptive147Third140Proof249
  · exact adaptive147Third140Proof250
  · exact adaptive147Third140Proof251
  · exact adaptive147Third140Proof252
  · exact adaptive147Third140Proof253
  · exact adaptive147Third140Proof254
  · exact adaptive147Third140Proof255
  · exact adaptive147Third140Proof256
  · exact adaptive147Third140Proof257
  · exact adaptive147Third140Proof258
  · exact adaptive147Third140Proof259
  · exact adaptive147Third140Proof260
  · exact adaptive147Third140Proof261
  · exact adaptive147Third140Proof262
  · exact adaptive147Third140Proof263
  · exact adaptive147Third140Proof264

#print axioms adaptive147Third140Proof230

end NineSeparatedSubsetSums
