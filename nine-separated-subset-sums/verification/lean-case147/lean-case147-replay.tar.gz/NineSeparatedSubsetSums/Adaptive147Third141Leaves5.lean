import NineSeparatedSubsetSums.Adaptive147Third141State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third141Proof336 : runCachedNode 511 131086 Adaptive147Third141Node336 = false := by
  decide +kernel

#print axioms adaptive147Third141Proof336

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third141Proof104 : runCachedNode 511 131086 Adaptive147Third141Node104 = false := by
  decide +kernel

#print axioms adaptive147Third141Proof104

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third141Proof178 : runCachedNode 511 131086 Adaptive147Third141Node178 = false := by
  decide +kernel

#print axioms adaptive147Third141Proof178

end NineSeparatedSubsetSums
