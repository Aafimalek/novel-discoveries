import NineSeparatedSubsetSums.Adaptive147Third135State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third135Proof48 : runCachedNode 511 130219 Adaptive147Third135Node48 = false := by
  decide +kernel

#print axioms adaptive147Third135Proof48

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third135Proof47 : runCachedNode 511 130219 Adaptive147Third135Node47 = false := by
  decide +kernel

#print axioms adaptive147Third135Proof47

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third135Proof13 : runCachedNode 511 130219 Adaptive147Third135Node13 = false := by
  decide +kernel

#print axioms adaptive147Third135Proof13

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third135Proof73 : runCachedNode 511 130219 Adaptive147Third135Node73 = false := by
  decide +kernel

#print axioms adaptive147Third135Proof73

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third135Proof74 : runCachedNode 511 130219 Adaptive147Third135Node74 = false := by
  decide +kernel

#print axioms adaptive147Third135Proof74

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third135Proof41 : runCachedNode 511 130219 Adaptive147Third135Node41 = false := by
  decide +kernel

#print axioms adaptive147Third135Proof41

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third135Proof30 : runCachedNode 511 130219 Adaptive147Third135Node30 = false := by
  decide +kernel

#print axioms adaptive147Third135Proof30

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third135Proof26 : runCachedNode 511 130219 Adaptive147Third135Node26 = false := by
  decide +kernel

#print axioms adaptive147Third135Proof26

end NineSeparatedSubsetSums
