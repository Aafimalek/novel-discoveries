import NineSeparatedSubsetSums.Adaptive147Third143State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third143Proof463 : runCachedNode 511 131344 Adaptive147Third143Node463 = false := by
  decide +kernel

#print axioms adaptive147Third143Proof463

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third143Proof588 : runCachedNode 511 131344 Adaptive147Third143Node588 = false := by
  decide +kernel

#print axioms adaptive147Third143Proof588

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third143Proof46 : runCachedNode 511 131344 Adaptive147Third143Node46 = false := by
  decide +kernel

#print axioms adaptive147Third143Proof46

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third143Proof225 : runCachedNode 511 131344 Adaptive147Third143Node225 = false := by
  decide +kernel

#print axioms adaptive147Third143Proof225

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third143Proof505 : runCachedNode 511 131344 Adaptive147Third143Node505 = false := by
  decide +kernel

#print axioms adaptive147Third143Proof505

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third143Proof632 : runCachedNode 511 131344 Adaptive147Third143Node632 = false := by
  decide +kernel

#print axioms adaptive147Third143Proof632

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third143Proof536 : runCachedNode 511 131344 Adaptive147Third143Node536 = false := by
  decide +kernel

#print axioms adaptive147Third143Proof536

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third143Proof36 : runCachedNode 511 131344 Adaptive147Third143Node36 = false := by
  decide +kernel

#print axioms adaptive147Third143Proof36

end NineSeparatedSubsetSums
