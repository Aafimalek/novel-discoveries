import NineSeparatedSubsetSums.Adaptive147Third135State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third135Proof22 : runCachedNode 511 130219 Adaptive147Third135Node22 = false := by
  decide +kernel

#print axioms adaptive147Third135Proof22

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third135Proof9 : runCachedNode 511 130219 Adaptive147Third135Node9 = false := by
  decide +kernel

#print axioms adaptive147Third135Proof9

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third135Proof2 : runCachedNode 511 130219 Adaptive147Third135Node2 = false := by
  decide +kernel

#print axioms adaptive147Third135Proof2

end NineSeparatedSubsetSums
