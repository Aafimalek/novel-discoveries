import NineSeparatedSubsetSums.Adaptive147Third140State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third140Proof22 : runCachedNode 511 130945 Adaptive147Third140Node22 = false := by
  decide +kernel

#print axioms adaptive147Third140Proof22

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third140Proof222 : runCachedNode 511 130945 Adaptive147Third140Node222 = false := by
  decide +kernel

#print axioms adaptive147Third140Proof222

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third140Proof57 : runCachedNode 511 130945 Adaptive147Third140Node57 = false := by
  decide +kernel

#print axioms adaptive147Third140Proof57

end NineSeparatedSubsetSums
