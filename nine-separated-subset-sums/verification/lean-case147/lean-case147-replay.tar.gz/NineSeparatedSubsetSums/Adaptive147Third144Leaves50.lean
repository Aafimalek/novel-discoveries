import NineSeparatedSubsetSums.Adaptive147Third144State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof829 : runCachedNode 511 131483 Adaptive147Third144Node829 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof829

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof223 : runCachedNode 511 131483 Adaptive147Third144Node223 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof223

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof190 : runCachedNode 511 131483 Adaptive147Third144Node190 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof190

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof495 : runCachedNode 511 131483 Adaptive147Third144Node495 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof495

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof815 : runCachedNode 511 131483 Adaptive147Third144Node815 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof815

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof814 : runCachedNode 511 131483 Adaptive147Third144Node814 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof814

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof571 : runCachedNode 511 131483 Adaptive147Third144Node571 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof571

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof257 : runCachedNode 511 131483 Adaptive147Third144Node257 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof257

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof827 : runCachedNode 511 131483 Adaptive147Third144Node827 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof827

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof824 : runCachedNode 511 131483 Adaptive147Third144Node824 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof824

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof518 : runCachedNode 511 131483 Adaptive147Third144Node518 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof518

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof816 : runCachedNode 511 131483 Adaptive147Third144Node816 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof816

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof289 : runCachedNode 511 131483 Adaptive147Third144Node289 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof289

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof725 : runCachedNode 511 131483 Adaptive147Third144Node725 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof725

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof256 : runCachedNode 511 131483 Adaptive147Third144Node256 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof256

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof184 : runCachedNode 511 131483 Adaptive147Third144Node184 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof184

end NineSeparatedSubsetSums
