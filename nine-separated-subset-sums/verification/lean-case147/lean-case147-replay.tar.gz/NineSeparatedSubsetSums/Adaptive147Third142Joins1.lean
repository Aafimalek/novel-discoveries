import NineSeparatedSubsetSums.Adaptive147Third142State
import NineSeparatedSubsetSums.Adaptive147Third142Leaves44
import NineSeparatedSubsetSums.Adaptive147Third142Leaves43
import NineSeparatedSubsetSums.Adaptive147Third142Leaves42
import NineSeparatedSubsetSums.Adaptive147Third142Leaves41
import NineSeparatedSubsetSums.Adaptive147Third142Leaves40
import NineSeparatedSubsetSums.Adaptive147Third142Leaves39
import NineSeparatedSubsetSums.Adaptive147Third142Leaves38
import NineSeparatedSubsetSums.Adaptive147Third142Leaves30
import NineSeparatedSubsetSums.Adaptive147Third142Leaves23
import NineSeparatedSubsetSums.Adaptive147Third142Leaves37
import NineSeparatedSubsetSums.Adaptive147Third142Leaves9
import NineSeparatedSubsetSums.Adaptive147Third142Leaves36
import NineSeparatedSubsetSums.Adaptive147Third142Leaves34
import NineSeparatedSubsetSums.Adaptive147Third142Leaves33
import NineSeparatedSubsetSums.Adaptive147Third142Leaves24
import NineSeparatedSubsetSums.Adaptive147Third142Leaves31
import NineSeparatedSubsetSums.Adaptive147Third142Leaves35
import NineSeparatedSubsetSums.Adaptive147Third142Leaves32
import NineSeparatedSubsetSums.Adaptive147Third142Leaves29
import NineSeparatedSubsetSums.Adaptive147Third142Leaves26
import NineSeparatedSubsetSums.Adaptive147Third142Leaves19
import NineSeparatedSubsetSums.Adaptive147Third142Leaves0
import NineSeparatedSubsetSums.Adaptive147Third142Leaves45
import NineSeparatedSubsetSums.Adaptive147Third142Leaves10
import NineSeparatedSubsetSums.Adaptive147Third142Leaves27
import NineSeparatedSubsetSums.Adaptive147Third142Leaves17
import NineSeparatedSubsetSums.Adaptive147Third142Leaves18
import NineSeparatedSubsetSums.Adaptive147Third142Leaves28
import NineSeparatedSubsetSums.Adaptive147Third142Leaves25
import NineSeparatedSubsetSums.Adaptive147Third142Leaves20
import NineSeparatedSubsetSums.Adaptive147Third142Leaves8
import NineSeparatedSubsetSums.Adaptive147Third142Leaves3
import NineSeparatedSubsetSums.Adaptive147Third142Leaves6
import NineSeparatedSubsetSums.Adaptive147Third142Leaves15
import NineSeparatedSubsetSums.Adaptive147Third142Leaves4
import NineSeparatedSubsetSums.Adaptive147Third142Leaves2
import NineSeparatedSubsetSums.Adaptive147Third142Joins0

namespace NineSeparatedSubsetSums

theorem adaptive147Third142Proof315 : runCachedNode 511 131213 Adaptive147Third142Node315 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 131213 Adaptive147Third142Node315 = [88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 123, 124, 125, 126, 129] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive147Third142Proof316
  · exact adaptive147Third142Proof317
  · exact adaptive147Third142Proof318
  · exact adaptive147Third142Proof319
  · exact adaptive147Third142Proof320
  · exact adaptive147Third142Proof321
  · exact adaptive147Third142Proof322
  · exact adaptive147Third142Proof323
  · exact adaptive147Third142Proof324
  · exact adaptive147Third142Proof325
  · exact adaptive147Third142Proof326
  · exact adaptive147Third142Proof327
  · exact adaptive147Third142Proof328
  · exact adaptive147Third142Proof329
  · exact adaptive147Third142Proof330
  · exact adaptive147Third142Proof331
  · exact adaptive147Third142Proof332
  · exact adaptive147Third142Proof333
  · exact adaptive147Third142Proof334
  · exact adaptive147Third142Proof335
  · exact adaptive147Third142Proof336
  · exact adaptive147Third142Proof337
  · exact adaptive147Third142Proof338
  · exact adaptive147Third142Proof339
  · exact adaptive147Third142Proof340
  · exact adaptive147Third142Proof341
  · exact adaptive147Third142Proof342
  · exact adaptive147Third142Proof343
  · exact adaptive147Third142Proof344
  · exact adaptive147Third142Proof345
  · exact adaptive147Third142Proof346
  · exact adaptive147Third142Proof347
  · exact adaptive147Third142Proof348
  · exact adaptive147Third142Proof349
  · exact adaptive147Third142Proof350
  · exact adaptive147Third142Proof351
  · exact adaptive147Third142Proof352
  · exact adaptive147Third142Proof353
  · exact adaptive147Third142Proof354

#print axioms adaptive147Third142Proof315

theorem adaptive147Third142Proof281 : runCachedNode 511 131213 Adaptive147Third142Node281 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 131213 Adaptive147Third142Node281 = [101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 132, 135, 136, 137] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive147Third142Proof282
  · exact adaptive147Third142Proof283
  · exact adaptive147Third142Proof284
  · exact adaptive147Third142Proof285
  · exact adaptive147Third142Proof286
  · exact adaptive147Third142Proof287
  · exact adaptive147Third142Proof288
  · exact adaptive147Third142Proof289
  · exact adaptive147Third142Proof290
  · exact adaptive147Third142Proof291
  · exact adaptive147Third142Proof292
  · exact adaptive147Third142Proof293
  · exact adaptive147Third142Proof294
  · exact adaptive147Third142Proof295
  · exact adaptive147Third142Proof296
  · exact adaptive147Third142Proof297
  · exact adaptive147Third142Proof298
  · exact adaptive147Third142Proof299
  · exact adaptive147Third142Proof300
  · exact adaptive147Third142Proof301
  · exact adaptive147Third142Proof302
  · exact adaptive147Third142Proof303
  · exact adaptive147Third142Proof304
  · exact adaptive147Third142Proof305
  · exact adaptive147Third142Proof306
  · exact adaptive147Third142Proof307
  · exact adaptive147Third142Proof308
  · exact adaptive147Third142Proof309
  · exact adaptive147Third142Proof310
  · exact adaptive147Third142Proof311
  · exact adaptive147Third142Proof312
  · exact adaptive147Third142Proof313
  · exact adaptive147Third142Proof314
  · exact adaptive147Third142Proof315
  · exact adaptive147Third142Proof355

#print axioms adaptive147Third142Proof281

theorem adaptive147Third142Proof392 : runCachedNode 511 131213 Adaptive147Third142Node392 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 131213 Adaptive147Third142Node392 = [87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 125, 126, 127, 128, 133] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive147Third142Proof393
  · exact adaptive147Third142Proof394
  · exact adaptive147Third142Proof395
  · exact adaptive147Third142Proof396
  · exact adaptive147Third142Proof397
  · exact adaptive147Third142Proof398
  · exact adaptive147Third142Proof399
  · exact adaptive147Third142Proof400
  · exact adaptive147Third142Proof401
  · exact adaptive147Third142Proof402
  · exact adaptive147Third142Proof403
  · exact adaptive147Third142Proof404
  · exact adaptive147Third142Proof405
  · exact adaptive147Third142Proof406
  · exact adaptive147Third142Proof407
  · exact adaptive147Third142Proof408
  · exact adaptive147Third142Proof409
  · exact adaptive147Third142Proof410
  · exact adaptive147Third142Proof411
  · exact adaptive147Third142Proof412
  · exact adaptive147Third142Proof413
  · exact adaptive147Third142Proof414
  · exact adaptive147Third142Proof415
  · exact adaptive147Third142Proof416
  · exact adaptive147Third142Proof417
  · exact adaptive147Third142Proof418
  · exact adaptive147Third142Proof419
  · exact adaptive147Third142Proof420
  · exact adaptive147Third142Proof421
  · exact adaptive147Third142Proof422
  · exact adaptive147Third142Proof423
  · exact adaptive147Third142Proof424
  · exact adaptive147Third142Proof425
  · exact adaptive147Third142Proof426
  · exact adaptive147Third142Proof427
  · exact adaptive147Third142Proof428
  · exact adaptive147Third142Proof429
  · exact adaptive147Third142Proof430
  · exact adaptive147Third142Proof431
  · exact adaptive147Third142Proof432
  · exact adaptive147Third142Proof433
  · exact adaptive147Third142Proof434

#print axioms adaptive147Third142Proof392

theorem adaptive147Third142Proof435 : runCachedNode 511 131213 Adaptive147Third142Node435 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 131213 Adaptive147Third142Node435 = [87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 126, 127, 128, 129] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive147Third142Proof436
  · exact adaptive147Third142Proof437
  · exact adaptive147Third142Proof438
  · exact adaptive147Third142Proof439
  · exact adaptive147Third142Proof440
  · exact adaptive147Third142Proof441
  · exact adaptive147Third142Proof442
  · exact adaptive147Third142Proof443
  · exact adaptive147Third142Proof444
  · exact adaptive147Third142Proof445
  · exact adaptive147Third142Proof446
  · exact adaptive147Third142Proof447
  · exact adaptive147Third142Proof448
  · exact adaptive147Third142Proof449
  · exact adaptive147Third142Proof450
  · exact adaptive147Third142Proof451
  · exact adaptive147Third142Proof452
  · exact adaptive147Third142Proof453
  · exact adaptive147Third142Proof454
  · exact adaptive147Third142Proof455
  · exact adaptive147Third142Proof456
  · exact adaptive147Third142Proof457
  · exact adaptive147Third142Proof458
  · exact adaptive147Third142Proof459
  · exact adaptive147Third142Proof460
  · exact adaptive147Third142Proof461
  · exact adaptive147Third142Proof462
  · exact adaptive147Third142Proof463
  · exact adaptive147Third142Proof464
  · exact adaptive147Third142Proof465
  · exact adaptive147Third142Proof466
  · exact adaptive147Third142Proof467
  · exact adaptive147Third142Proof468
  · exact adaptive147Third142Proof469
  · exact adaptive147Third142Proof470
  · exact adaptive147Third142Proof471
  · exact adaptive147Third142Proof472
  · exact adaptive147Third142Proof473
  · exact adaptive147Third142Proof474
  · exact adaptive147Third142Proof475
  · exact adaptive147Third142Proof476
  · exact adaptive147Third142Proof477

#print axioms adaptive147Third142Proof435

theorem adaptive147Third142Proof356 : runCachedNode 511 131213 Adaptive147Third142Node356 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 131213 Adaptive147Third142Node356 = [100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 132, 133, 136, 137, 138] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive147Third142Proof357
  · exact adaptive147Third142Proof358
  · exact adaptive147Third142Proof359
  · exact adaptive147Third142Proof360
  · exact adaptive147Third142Proof361
  · exact adaptive147Third142Proof362
  · exact adaptive147Third142Proof363
  · exact adaptive147Third142Proof364
  · exact adaptive147Third142Proof365
  · exact adaptive147Third142Proof366
  · exact adaptive147Third142Proof367
  · exact adaptive147Third142Proof368
  · exact adaptive147Third142Proof369
  · exact adaptive147Third142Proof370
  · exact adaptive147Third142Proof371
  · exact adaptive147Third142Proof372
  · exact adaptive147Third142Proof373
  · exact adaptive147Third142Proof374
  · exact adaptive147Third142Proof375
  · exact adaptive147Third142Proof376
  · exact adaptive147Third142Proof377
  · exact adaptive147Third142Proof378
  · exact adaptive147Third142Proof379
  · exact adaptive147Third142Proof380
  · exact adaptive147Third142Proof381
  · exact adaptive147Third142Proof382
  · exact adaptive147Third142Proof383
  · exact adaptive147Third142Proof384
  · exact adaptive147Third142Proof385
  · exact adaptive147Third142Proof386
  · exact adaptive147Third142Proof387
  · exact adaptive147Third142Proof388
  · exact adaptive147Third142Proof389
  · exact adaptive147Third142Proof390
  · exact adaptive147Third142Proof391
  · exact adaptive147Third142Proof392
  · exact adaptive147Third142Proof435

#print axioms adaptive147Third142Proof356

theorem adaptive147Third142Proof0 : runCachedNode 511 131213 Adaptive147Third142Node0 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 131213 Adaptive147Third142Node0 = [109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 132, 133, 134, 135, 136, 137, 138, 139, 140] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive147Third142Proof1
  · exact adaptive147Third142Proof2
  · exact adaptive147Third142Proof3
  · exact adaptive147Third142Proof4
  · exact adaptive147Third142Proof5
  · exact adaptive147Third142Proof6
  · exact adaptive147Third142Proof7
  · exact adaptive147Third142Proof8
  · exact adaptive147Third142Proof9
  · exact adaptive147Third142Proof10
  · exact adaptive147Third142Proof11
  · exact adaptive147Third142Proof12
  · exact adaptive147Third142Proof13
  · exact adaptive147Third142Proof14
  · exact adaptive147Third142Proof15
  · exact adaptive147Third142Proof16
  · exact adaptive147Third142Proof17
  · exact adaptive147Third142Proof18
  · exact adaptive147Third142Proof19
  · exact adaptive147Third142Proof20
  · exact adaptive147Third142Proof21
  · exact adaptive147Third142Proof22
  · exact adaptive147Third142Proof23
  · exact adaptive147Third142Proof24
  · exact adaptive147Third142Proof51
  · exact adaptive147Third142Proof80
  · exact adaptive147Third142Proof110
  · exact adaptive147Third142Proof141
  · exact adaptive147Third142Proof173
  · exact adaptive147Third142Proof207
  · exact adaptive147Third142Proof281
  · exact adaptive147Third142Proof356

#print axioms adaptive147Third142Proof0

end NineSeparatedSubsetSums
