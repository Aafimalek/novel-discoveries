import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive147Third106Node0 : CachedSearchNode :=
  ⟨4, 105, computeCenteredMask [148,147,106], 401, 54749⟩

end NineSeparatedSubsetSums
