import NineSeparatedSubsetSums.Adaptive147Third140State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third140Proof103 : runCachedNode 511 130945 Adaptive147Third140Node103 = false := by
  decide +kernel

#print axioms adaptive147Third140Proof103

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third140Proof75 : runCachedNode 511 130945 Adaptive147Third140Node75 = false := by
  decide +kernel

#print axioms adaptive147Third140Proof75

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third140Proof65 : runCachedNode 511 130945 Adaptive147Third140Node65 = false := by
  decide +kernel

#print axioms adaptive147Third140Proof65

end NineSeparatedSubsetSums
