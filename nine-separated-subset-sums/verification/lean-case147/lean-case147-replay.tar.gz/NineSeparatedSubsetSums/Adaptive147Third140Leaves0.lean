import NineSeparatedSubsetSums.Adaptive147Third140State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third140Proof194 : runCachedNode 511 130945 Adaptive147Third140Node194 = false := by
  decide +kernel

#print axioms adaptive147Third140Proof194

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third140Proof188 : runCachedNode 511 130945 Adaptive147Third140Node188 = false := by
  decide +kernel

#print axioms adaptive147Third140Proof188

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third140Proof51 : runCachedNode 511 130945 Adaptive147Third140Node51 = false := by
  decide +kernel

#print axioms adaptive147Third140Proof51

end NineSeparatedSubsetSums
