import NineSeparatedSubsetSums.Adaptive147Third141State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third141Proof231 : runCachedNode 511 131086 Adaptive147Third141Node231 = false := by
  decide +kernel

#print axioms adaptive147Third141Proof231

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third141Proof228 : runCachedNode 511 131086 Adaptive147Third141Node228 = false := by
  decide +kernel

#print axioms adaptive147Third141Proof228

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third141Proof137 : runCachedNode 511 131086 Adaptive147Third141Node137 = false := by
  decide +kernel

#print axioms adaptive147Third141Proof137

end NineSeparatedSubsetSums
