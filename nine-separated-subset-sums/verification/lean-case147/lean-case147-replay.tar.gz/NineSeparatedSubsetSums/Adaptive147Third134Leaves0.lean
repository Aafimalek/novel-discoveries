import NineSeparatedSubsetSums.Adaptive147Third134State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third134Proof22 : runCachedNode 511 130034 Adaptive147Third134Node22 = false := by
  decide +kernel

#print axioms adaptive147Third134Proof22

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third134Proof39 : runCachedNode 511 130034 Adaptive147Third134Node39 = false := by
  decide +kernel

#print axioms adaptive147Third134Proof39

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third134Proof4 : runCachedNode 511 130034 Adaptive147Third134Node4 = false := by
  decide +kernel

#print axioms adaptive147Third134Proof4

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third134Proof1 : runCachedNode 511 130034 Adaptive147Third134Node1 = false := by
  decide +kernel

#print axioms adaptive147Third134Proof1

end NineSeparatedSubsetSums
