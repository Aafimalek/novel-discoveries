import NineSeparatedSubsetSums.Adaptive147Third144State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof194 : runCachedNode 511 131483 Adaptive147Third144Node194 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof194

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof192 : runCachedNode 511 131483 Adaptive147Third144Node192 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof192

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof372 : runCachedNode 511 131483 Adaptive147Third144Node372 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof372

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof732 : runCachedNode 511 131483 Adaptive147Third144Node732 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof732

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof659 : runCachedNode 511 131483 Adaptive147Third144Node659 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof659

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof328 : runCachedNode 511 131483 Adaptive147Third144Node328 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof328

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof45 : runCachedNode 511 131483 Adaptive147Third144Node45 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof45

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof369 : runCachedNode 511 131483 Adaptive147Third144Node369 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof369

end NineSeparatedSubsetSums
