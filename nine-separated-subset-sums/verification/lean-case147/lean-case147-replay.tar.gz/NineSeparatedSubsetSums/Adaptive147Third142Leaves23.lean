import NineSeparatedSubsetSums.Adaptive147Third142State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third142Proof139 : runCachedNode 511 131213 Adaptive147Third142Node139 = false := by
  decide +kernel

#print axioms adaptive147Third142Proof139

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third142Proof15 : runCachedNode 511 131213 Adaptive147Third142Node15 = false := by
  decide +kernel

#print axioms adaptive147Third142Proof15

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third142Proof386 : runCachedNode 511 131213 Adaptive147Third142Node386 = false := by
  decide +kernel

#print axioms adaptive147Third142Proof386

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third142Proof237 : runCachedNode 511 131213 Adaptive147Third142Node237 = false := by
  decide +kernel

#print axioms adaptive147Third142Proof237

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third142Proof344 : runCachedNode 511 131213 Adaptive147Third142Node344 = false := by
  decide +kernel

#print axioms adaptive147Third142Proof344

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third142Proof111 : runCachedNode 511 131213 Adaptive147Third142Node111 = false := by
  decide +kernel

#print axioms adaptive147Third142Proof111

end NineSeparatedSubsetSums
