import NineSeparatedSubsetSums.Adaptive147Third142State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third142Proof77 : runCachedNode 511 131213 Adaptive147Third142Node77 = false := by
  decide +kernel

#print axioms adaptive147Third142Proof77

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third142Proof312 : runCachedNode 511 131213 Adaptive147Third142Node312 = false := by
  decide +kernel

#print axioms adaptive147Third142Proof312

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third142Proof107 : runCachedNode 511 131213 Adaptive147Third142Node107 = false := by
  decide +kernel

#print axioms adaptive147Third142Proof107

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third142Proof477 : runCachedNode 511 131213 Adaptive147Third142Node477 = false := by
  decide +kernel

#print axioms adaptive147Third142Proof477

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third142Proof79 : runCachedNode 511 131213 Adaptive147Third142Node79 = false := by
  decide +kernel

#print axioms adaptive147Third142Proof79

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third142Proof54 : runCachedNode 511 131213 Adaptive147Third142Node54 = false := by
  decide +kernel

#print axioms adaptive147Third142Proof54

end NineSeparatedSubsetSums
