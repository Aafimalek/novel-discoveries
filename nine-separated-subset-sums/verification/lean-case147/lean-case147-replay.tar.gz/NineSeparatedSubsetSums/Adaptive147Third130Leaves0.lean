import NineSeparatedSubsetSums.Adaptive147Third130State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third130Proof19 : runCachedNode 511 129214 Adaptive147Third130Node19 = false := by
  decide +kernel

#print axioms adaptive147Third130Proof19

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third130Proof18 : runCachedNode 511 129214 Adaptive147Third130Node18 = false := by
  decide +kernel

#print axioms adaptive147Third130Proof18

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third130Proof4 : runCachedNode 511 129214 Adaptive147Third130Node4 = false := by
  decide +kernel

#print axioms adaptive147Third130Proof4

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third130Proof3 : runCachedNode 511 129214 Adaptive147Third130Node3 = false := by
  decide +kernel

#print axioms adaptive147Third130Proof3

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third130Proof2 : runCachedNode 511 129214 Adaptive147Third130Node2 = false := by
  decide +kernel

#print axioms adaptive147Third130Proof2

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third130Proof1 : runCachedNode 511 129214 Adaptive147Third130Node1 = false := by
  decide +kernel

#print axioms adaptive147Third130Proof1

end NineSeparatedSubsetSums
