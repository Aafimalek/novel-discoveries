import NineSeparatedSubsetSums.Adaptive147Third145State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third145Proof358 : runCachedNode 511 131618 Adaptive147Third145Node358 = false := by
  decide +kernel

#print axioms adaptive147Third145Proof358

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third145Proof154 : runCachedNode 511 131618 Adaptive147Third145Node154 = false := by
  decide +kernel

#print axioms adaptive147Third145Proof154

end NineSeparatedSubsetSums
