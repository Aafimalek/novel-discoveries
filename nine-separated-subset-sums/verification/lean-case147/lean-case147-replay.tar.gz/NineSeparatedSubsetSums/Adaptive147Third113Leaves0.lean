import NineSeparatedSubsetSums.Adaptive147Third113State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third113Proof0 : runCachedNode 511 112835 Adaptive147Third113Node0 = false := by
  decide +kernel

#print axioms adaptive147Third113Proof0

end NineSeparatedSubsetSums
