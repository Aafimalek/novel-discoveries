import NineSeparatedSubsetSums.Adaptive147Third139State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third139Proof17 : runCachedNode 511 130807 Adaptive147Third139Node17 = false := by
  decide +kernel

#print axioms adaptive147Third139Proof17

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third139Proof216 : runCachedNode 511 130807 Adaptive147Third139Node216 = false := by
  decide +kernel

#print axioms adaptive147Third139Proof216

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third139Proof218 : runCachedNode 511 130807 Adaptive147Third139Node218 = false := by
  decide +kernel

#print axioms adaptive147Third139Proof218

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third139Proof242 : runCachedNode 511 130807 Adaptive147Third139Node242 = false := by
  decide +kernel

#print axioms adaptive147Third139Proof242

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third139Proof74 : runCachedNode 511 130807 Adaptive147Third139Node74 = false := by
  decide +kernel

#print axioms adaptive147Third139Proof74

end NineSeparatedSubsetSums
