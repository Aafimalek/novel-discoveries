import NineSeparatedSubsetSums.Adaptive147Third106Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint147Checked

namespace NineSeparatedSubsetSums


theorem adaptive147Third106 : NoDescendingTailAfterThird 147 106 :=
  noDescendingThirdTail_of_cached 147 106 112835 (fun t ht nd => max148_second147_fourPoint_moment_bound (106::t) (by simp [ht]) nd) adaptive147Third106Proof0

#print axioms adaptive147Third106

end NineSeparatedSubsetSums
