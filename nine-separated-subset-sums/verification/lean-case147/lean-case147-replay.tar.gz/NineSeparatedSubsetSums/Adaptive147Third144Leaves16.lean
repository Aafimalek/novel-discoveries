import NineSeparatedSubsetSums.Adaptive147Third144State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof302 : runCachedNode 511 131483 Adaptive147Third144Node302 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof302

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof234 : runCachedNode 511 131483 Adaptive147Third144Node234 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof234

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof92 : runCachedNode 511 131483 Adaptive147Third144Node92 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof92

end NineSeparatedSubsetSums
