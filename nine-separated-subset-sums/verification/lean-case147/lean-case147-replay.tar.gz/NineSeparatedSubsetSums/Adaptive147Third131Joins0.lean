import NineSeparatedSubsetSums.Adaptive147Third131State
import NineSeparatedSubsetSums.Adaptive147Third131Leaves1
import NineSeparatedSubsetSums.Adaptive147Third131Leaves0
import NineSeparatedSubsetSums.Adaptive147Third131Leaves3
import NineSeparatedSubsetSums.Adaptive147Third131Leaves2

namespace NineSeparatedSubsetSums

theorem adaptive147Third131Proof0 : runCachedNode 511 129432 Adaptive147Third131Node0 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 129432 Adaptive147Third131Node0 = [110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive147Third131Proof1
  · exact adaptive147Third131Proof2
  · exact adaptive147Third131Proof3
  · exact adaptive147Third131Proof4
  · exact adaptive147Third131Proof5
  · exact adaptive147Third131Proof6
  · exact adaptive147Third131Proof7
  · exact adaptive147Third131Proof8
  · exact adaptive147Third131Proof9
  · exact adaptive147Third131Proof10
  · exact adaptive147Third131Proof11
  · exact adaptive147Third131Proof12
  · exact adaptive147Third131Proof13
  · exact adaptive147Third131Proof14
  · exact adaptive147Third131Proof15
  · exact adaptive147Third131Proof16
  · exact adaptive147Third131Proof17
  · exact adaptive147Third131Proof18
  · exact adaptive147Third131Proof19
  · exact adaptive147Third131Proof20

#print axioms adaptive147Third131Proof0

end NineSeparatedSubsetSums
