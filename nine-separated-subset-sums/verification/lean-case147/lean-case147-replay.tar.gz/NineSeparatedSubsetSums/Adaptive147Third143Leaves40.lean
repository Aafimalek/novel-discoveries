import NineSeparatedSubsetSums.Adaptive147Third143State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third143Proof586 : runCachedNode 511 131344 Adaptive147Third143Node586 = false := by
  decide +kernel

#print axioms adaptive147Third143Proof586

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third143Proof127 : runCachedNode 511 131344 Adaptive147Third143Node127 = false := by
  decide +kernel

#print axioms adaptive147Third143Proof127

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third143Proof407 : runCachedNode 511 131344 Adaptive147Third143Node407 = false := by
  decide +kernel

#print axioms adaptive147Third143Proof407

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third143Proof381 : runCachedNode 511 131344 Adaptive147Third143Node381 = false := by
  decide +kernel

#print axioms adaptive147Third143Proof381

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third143Proof529 : runCachedNode 511 131344 Adaptive147Third143Node529 = false := by
  decide +kernel

#print axioms adaptive147Third143Proof529

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third143Proof629 : runCachedNode 511 131344 Adaptive147Third143Node629 = false := by
  decide +kernel

#print axioms adaptive147Third143Proof629

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third143Proof406 : runCachedNode 511 131344 Adaptive147Third143Node406 = false := by
  decide +kernel

#print axioms adaptive147Third143Proof406

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third143Proof460 : runCachedNode 511 131344 Adaptive147Third143Node460 = false := by
  decide +kernel

#print axioms adaptive147Third143Proof460

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third143Proof125 : runCachedNode 511 131344 Adaptive147Third143Node125 = false := by
  decide +kernel

#print axioms adaptive147Third143Proof125

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third143Proof156 : runCachedNode 511 131344 Adaptive147Third143Node156 = false := by
  decide +kernel

#print axioms adaptive147Third143Proof156

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third143Proof97 : runCachedNode 511 131344 Adaptive147Third143Node97 = false := by
  decide +kernel

#print axioms adaptive147Third143Proof97

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third143Proof220 : runCachedNode 511 131344 Adaptive147Third143Node220 = false := by
  decide +kernel

#print axioms adaptive147Third143Proof220

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third143Proof503 : runCachedNode 511 131344 Adaptive147Third143Node503 = false := by
  decide +kernel

#print axioms adaptive147Third143Proof503

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third143Proof41 : runCachedNode 511 131344 Adaptive147Third143Node41 = false := by
  decide +kernel

#print axioms adaptive147Third143Proof41

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third143Proof187 : runCachedNode 511 131344 Adaptive147Third143Node187 = false := by
  decide +kernel

#print axioms adaptive147Third143Proof187

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third143Proof625 : runCachedNode 511 131344 Adaptive147Third143Node625 = false := by
  decide +kernel

#print axioms adaptive147Third143Proof625

end NineSeparatedSubsetSums
