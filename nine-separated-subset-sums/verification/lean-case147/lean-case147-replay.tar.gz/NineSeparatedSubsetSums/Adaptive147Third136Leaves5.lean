import NineSeparatedSubsetSums.Adaptive147Third136State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third136Proof129 : runCachedNode 511 130369 Adaptive147Third136Node129 = false := by
  decide +kernel

#print axioms adaptive147Third136Proof129

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third136Proof100 : runCachedNode 511 130369 Adaptive147Third136Node100 = false := by
  decide +kernel

#print axioms adaptive147Third136Proof100

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third136Proof101 : runCachedNode 511 130369 Adaptive147Third136Node101 = false := by
  decide +kernel

#print axioms adaptive147Third136Proof101

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third136Proof73 : runCachedNode 511 130369 Adaptive147Third136Node73 = false := by
  decide +kernel

#print axioms adaptive147Third136Proof73

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third136Proof32 : runCachedNode 511 130369 Adaptive147Third136Node32 = false := by
  decide +kernel

#print axioms adaptive147Third136Proof32

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third136Proof49 : runCachedNode 511 130369 Adaptive147Third136Node49 = false := by
  decide +kernel

#print axioms adaptive147Third136Proof49

end NineSeparatedSubsetSums
