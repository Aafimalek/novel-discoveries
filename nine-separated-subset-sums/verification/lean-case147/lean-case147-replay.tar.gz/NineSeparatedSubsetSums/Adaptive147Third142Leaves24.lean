import NineSeparatedSubsetSums.Adaptive147Third142State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third142Proof311 : runCachedNode 511 131213 Adaptive147Third142Node311 = false := by
  decide +kernel

#print axioms adaptive147Third142Proof311

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third142Proof136 : runCachedNode 511 131213 Adaptive147Third142Node136 = false := by
  decide +kernel

#print axioms adaptive147Third142Proof136

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third142Proof313 : runCachedNode 511 131213 Adaptive147Third142Node313 = false := by
  decide +kernel

#print axioms adaptive147Third142Proof313

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third142Proof354 : runCachedNode 511 131213 Adaptive147Third142Node354 = false := by
  decide +kernel

#print axioms adaptive147Third142Proof354

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third142Proof352 : runCachedNode 511 131213 Adaptive147Third142Node352 = false := by
  decide +kernel

#print axioms adaptive147Third142Proof352

end NineSeparatedSubsetSums
