import NineSeparatedSubsetSums.Adaptive147Third140State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third140Proof72 : runCachedNode 511 130945 Adaptive147Third140Node72 = false := by
  decide +kernel

#print axioms adaptive147Third140Proof72

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third140Proof128 : runCachedNode 511 130945 Adaptive147Third140Node128 = false := by
  decide +kernel

#print axioms adaptive147Third140Proof128

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third140Proof43 : runCachedNode 511 130945 Adaptive147Third140Node43 = false := by
  decide +kernel

#print axioms adaptive147Third140Proof43

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third140Proof44 : runCachedNode 511 130945 Adaptive147Third140Node44 = false := by
  decide +kernel

#print axioms adaptive147Third140Proof44

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third140Proof254 : runCachedNode 511 130945 Adaptive147Third140Node254 = false := by
  decide +kernel

#print axioms adaptive147Third140Proof254

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third140Proof256 : runCachedNode 511 130945 Adaptive147Third140Node256 = false := by
  decide +kernel

#print axioms adaptive147Third140Proof256

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third140Proof189 : runCachedNode 511 130945 Adaptive147Third140Node189 = false := by
  decide +kernel

#print axioms adaptive147Third140Proof189

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third140Proof69 : runCachedNode 511 130945 Adaptive147Third140Node69 = false := by
  decide +kernel

#print axioms adaptive147Third140Proof69

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third140Proof118 : runCachedNode 511 130945 Adaptive147Third140Node118 = false := by
  decide +kernel

#print axioms adaptive147Third140Proof118

end NineSeparatedSubsetSums
