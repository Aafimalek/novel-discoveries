import NineSeparatedSubsetSums.Adaptive147Third126State
import NineSeparatedSubsetSums.Adaptive147Third126Leaves1
import NineSeparatedSubsetSums.Adaptive147Third126Leaves0

namespace NineSeparatedSubsetSums

theorem adaptive147Third126Proof0 : runCachedNode 511 128211 Adaptive147Third126Node0 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 128211 Adaptive147Third126Node0 = [110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive147Third126Proof1
  · exact adaptive147Third126Proof2
  · exact adaptive147Third126Proof3
  · exact adaptive147Third126Proof4
  · exact adaptive147Third126Proof5
  · exact adaptive147Third126Proof6
  · exact adaptive147Third126Proof7
  · exact adaptive147Third126Proof8
  · exact adaptive147Third126Proof9
  · exact adaptive147Third126Proof10
  · exact adaptive147Third126Proof11
  · exact adaptive147Third126Proof12
  · exact adaptive147Third126Proof13
  · exact adaptive147Third126Proof14
  · exact adaptive147Third126Proof15

#print axioms adaptive147Third126Proof0

end NineSeparatedSubsetSums
