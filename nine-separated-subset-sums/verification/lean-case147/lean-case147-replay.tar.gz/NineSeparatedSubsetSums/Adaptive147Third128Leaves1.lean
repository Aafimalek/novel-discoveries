import NineSeparatedSubsetSums.Adaptive147Third128State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third128Proof13 : runCachedNode 511 128781 Adaptive147Third128Node13 = false := by
  decide +kernel

#print axioms adaptive147Third128Proof13

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third128Proof12 : runCachedNode 511 128781 Adaptive147Third128Node12 = false := by
  decide +kernel

#print axioms adaptive147Third128Proof12

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third128Proof11 : runCachedNode 511 128781 Adaptive147Third128Node11 = false := by
  decide +kernel

#print axioms adaptive147Third128Proof11

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third128Proof10 : runCachedNode 511 128781 Adaptive147Third128Node10 = false := by
  decide +kernel

#print axioms adaptive147Third128Proof10

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third128Proof9 : runCachedNode 511 128781 Adaptive147Third128Node9 = false := by
  decide +kernel

#print axioms adaptive147Third128Proof9

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third128Proof8 : runCachedNode 511 128781 Adaptive147Third128Node8 = false := by
  decide +kernel

#print axioms adaptive147Third128Proof8

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third128Proof7 : runCachedNode 511 128781 Adaptive147Third128Node7 = false := by
  decide +kernel

#print axioms adaptive147Third128Proof7

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third128Proof6 : runCachedNode 511 128781 Adaptive147Third128Node6 = false := by
  decide +kernel

#print axioms adaptive147Third128Proof6

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third128Proof5 : runCachedNode 511 128781 Adaptive147Third128Node5 = false := by
  decide +kernel

#print axioms adaptive147Third128Proof5

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third128Proof1 : runCachedNode 511 128781 Adaptive147Third128Node1 = false := by
  decide +kernel

#print axioms adaptive147Third128Proof1

end NineSeparatedSubsetSums
