import NineSeparatedSubsetSums.Adaptive147Third144State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof258 : runCachedNode 511 131483 Adaptive147Third144Node258 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof258

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof156 : runCachedNode 511 131483 Adaptive147Third144Node156 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof156

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof817 : runCachedNode 511 131483 Adaptive147Third144Node817 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof817

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof370 : runCachedNode 511 131483 Adaptive147Third144Node370 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof370

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof453 : runCachedNode 511 131483 Adaptive147Third144Node453 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof453

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof821 : runCachedNode 511 131483 Adaptive147Third144Node821 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof821

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof155 : runCachedNode 511 131483 Adaptive147Third144Node155 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof155

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof288 : runCachedNode 511 131483 Adaptive147Third144Node288 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof288

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof699 : runCachedNode 511 131483 Adaptive147Third144Node699 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof699

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof822 : runCachedNode 511 131483 Adaptive147Third144Node822 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof822

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof786 : runCachedNode 511 131483 Adaptive147Third144Node786 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof786

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof826 : runCachedNode 511 131483 Adaptive147Third144Node826 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof826

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof41 : runCachedNode 511 131483 Adaptive147Third144Node41 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof41

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof188 : runCachedNode 511 131483 Adaptive147Third144Node188 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof188

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof656 : runCachedNode 511 131483 Adaptive147Third144Node656 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof656

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof10 : runCachedNode 511 131483 Adaptive147Third144Node10 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof10

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof39 : runCachedNode 511 131483 Adaptive147Third144Node39 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof39

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof152 : runCachedNode 511 131483 Adaptive147Third144Node152 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof152

end NineSeparatedSubsetSums
