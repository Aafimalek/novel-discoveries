import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive147Third105Node0 : CachedSearchNode :=
  ⟨4, 104, computeCenteredMask [148,147,105], 400, 54538⟩

end NineSeparatedSubsetSums
