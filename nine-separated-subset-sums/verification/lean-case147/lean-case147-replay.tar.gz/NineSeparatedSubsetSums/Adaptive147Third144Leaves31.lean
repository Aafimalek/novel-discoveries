import NineSeparatedSubsetSums.Adaptive147Third144State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof737 : runCachedNode 511 131483 Adaptive147Third144Node737 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof737

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof48 : runCachedNode 511 131483 Adaptive147Third144Node48 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof48

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof528 : runCachedNode 511 131483 Adaptive147Third144Node528 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof528

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof660 : runCachedNode 511 131483 Adaptive147Third144Node660 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof660

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof63 : runCachedNode 511 131483 Adaptive147Third144Node63 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof63

end NineSeparatedSubsetSums
