import NineSeparatedSubsetSums.Adaptive147Third144State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof105 : runCachedNode 511 131483 Adaptive147Third144Node105 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof105

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof500 : runCachedNode 511 131483 Adaptive147Third144Node500 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof500

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof166 : runCachedNode 511 131483 Adaptive147Third144Node166 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof166

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof24 : runCachedNode 511 131483 Adaptive147Third144Node24 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof24

end NineSeparatedSubsetSums
