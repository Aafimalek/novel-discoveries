import NineSeparatedSubsetSums.Adaptive147Third141State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third141Proof134 : runCachedNode 511 131086 Adaptive147Third141Node134 = false := by
  decide +kernel

#print axioms adaptive147Third141Proof134

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third141Proof196 : runCachedNode 511 131086 Adaptive147Third141Node196 = false := by
  decide +kernel

#print axioms adaptive147Third141Proof196

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third141Proof93 : runCachedNode 511 131086 Adaptive147Third141Node93 = false := by
  decide +kernel

#print axioms adaptive147Third141Proof93

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third141Proof108 : runCachedNode 511 131086 Adaptive147Third141Node108 = false := by
  decide +kernel

#print axioms adaptive147Third141Proof108

end NineSeparatedSubsetSums
