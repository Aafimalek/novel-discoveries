import NineSeparatedSubsetSums.Adaptive147Third139State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third139Proof247 : runCachedNode 511 130807 Adaptive147Third139Node247 = false := by
  decide +kernel

#print axioms adaptive147Third139Proof247

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third139Proof126 : runCachedNode 511 130807 Adaptive147Third139Node126 = false := by
  decide +kernel

#print axioms adaptive147Third139Proof126

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third139Proof65 : runCachedNode 511 130807 Adaptive147Third139Node65 = false := by
  decide +kernel

#print axioms adaptive147Third139Proof65

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third139Proof5 : runCachedNode 511 130807 Adaptive147Third139Node5 = false := by
  decide +kernel

#print axioms adaptive147Third139Proof5

end NineSeparatedSubsetSums
