import NineSeparatedSubsetSums.Adaptive147Third132State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third132Proof20 : runCachedNode 511 129667 Adaptive147Third132Node20 = false := by
  decide +kernel

#print axioms adaptive147Third132Proof20

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third132Proof18 : runCachedNode 511 129667 Adaptive147Third132Node18 = false := by
  decide +kernel

#print axioms adaptive147Third132Proof18

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third132Proof7 : runCachedNode 511 129667 Adaptive147Third132Node7 = false := by
  decide +kernel

#print axioms adaptive147Third132Proof7

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third132Proof4 : runCachedNode 511 129667 Adaptive147Third132Node4 = false := by
  decide +kernel

#print axioms adaptive147Third132Proof4

end NineSeparatedSubsetSums
