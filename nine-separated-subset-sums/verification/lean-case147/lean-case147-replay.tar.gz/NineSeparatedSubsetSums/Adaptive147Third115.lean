import NineSeparatedSubsetSums.Adaptive147Third115Joins0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint147Checked

namespace NineSeparatedSubsetSums


theorem adaptive147Third115 : NoDescendingTailAfterThird 147 115 :=
  noDescendingThirdTail_of_cached 147 115 112835 (fun t ht nd => max148_second147_fourPoint_moment_bound (115::t) (by simp [ht]) nd) adaptive147Third115Proof0

#print axioms adaptive147Third115

end NineSeparatedSubsetSums
