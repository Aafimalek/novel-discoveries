import NineSeparatedSubsetSums.Adaptive147Third139State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third139Proof69 : runCachedNode 511 130807 Adaptive147Third139Node69 = false := by
  decide +kernel

#print axioms adaptive147Third139Proof69

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third139Proof124 : runCachedNode 511 130807 Adaptive147Third139Node124 = false := by
  decide +kernel

#print axioms adaptive147Third139Proof124

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third139Proof66 : runCachedNode 511 130807 Adaptive147Third139Node66 = false := by
  decide +kernel

#print axioms adaptive147Third139Proof66

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third139Proof44 : runCachedNode 511 130807 Adaptive147Third139Node44 = false := by
  decide +kernel

#print axioms adaptive147Third139Proof44

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third139Proof96 : runCachedNode 511 130807 Adaptive147Third139Node96 = false := by
  decide +kernel

#print axioms adaptive147Third139Proof96

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third139Proof149 : runCachedNode 511 130807 Adaptive147Third139Node149 = false := by
  decide +kernel

#print axioms adaptive147Third139Proof149

end NineSeparatedSubsetSums
