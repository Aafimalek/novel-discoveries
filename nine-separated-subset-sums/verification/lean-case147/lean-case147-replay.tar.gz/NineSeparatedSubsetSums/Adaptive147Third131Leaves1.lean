import NineSeparatedSubsetSums.Adaptive147Third131State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third131Proof19 : runCachedNode 511 129432 Adaptive147Third131Node19 = false := by
  decide +kernel

#print axioms adaptive147Third131Proof19

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third131Proof18 : runCachedNode 511 129432 Adaptive147Third131Node18 = false := by
  decide +kernel

#print axioms adaptive147Third131Proof18

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third131Proof12 : runCachedNode 511 129432 Adaptive147Third131Node12 = false := by
  decide +kernel

#print axioms adaptive147Third131Proof12

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third131Proof4 : runCachedNode 511 129432 Adaptive147Third131Node4 = false := by
  decide +kernel

#print axioms adaptive147Third131Proof4

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third131Proof1 : runCachedNode 511 129432 Adaptive147Third131Node1 = false := by
  decide +kernel

#print axioms adaptive147Third131Proof1

end NineSeparatedSubsetSums
