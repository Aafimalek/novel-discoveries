import NineSeparatedSubsetSums.Adaptive147Third142State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third142Proof21 : runCachedNode 511 131213 Adaptive147Third142Node21 = false := by
  decide +kernel

#print axioms adaptive147Third142Proof21

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third142Proof198 : runCachedNode 511 131213 Adaptive147Third142Node198 = false := by
  decide +kernel

#print axioms adaptive147Third142Proof198

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third142Proof3 : runCachedNode 511 131213 Adaptive147Third142Node3 = false := by
  decide +kernel

#print axioms adaptive147Third142Proof3

end NineSeparatedSubsetSums
