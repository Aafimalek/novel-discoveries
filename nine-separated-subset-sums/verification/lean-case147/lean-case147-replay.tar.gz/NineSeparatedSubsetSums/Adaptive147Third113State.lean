import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive147Third113Node0 : CachedSearchNode :=
  ⟨4, 112, computeCenteredMask [148,147,113], 408, 56282⟩

end NineSeparatedSubsetSums
