import NineSeparatedSubsetSums.Adaptive147Third137State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third137Proof65 : runCachedNode 511 130518 Adaptive147Third137Node65 = false := by
  decide +kernel

#print axioms adaptive147Third137Proof65

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third137Proof150 : runCachedNode 511 130518 Adaptive147Third137Node150 = false := by
  decide +kernel

#print axioms adaptive147Third137Proof150

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third137Proof11 : runCachedNode 511 130518 Adaptive147Third137Node11 = false := by
  decide +kernel

#print axioms adaptive147Third137Proof11

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third137Proof41 : runCachedNode 511 130518 Adaptive147Third137Node41 = false := by
  decide +kernel

#print axioms adaptive147Third137Proof41

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third137Proof91 : runCachedNode 511 130518 Adaptive147Third137Node91 = false := by
  decide +kernel

#print axioms adaptive147Third137Proof91

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third137Proof145 : runCachedNode 511 130518 Adaptive147Third137Node145 = false := by
  decide +kernel

#print axioms adaptive147Third137Proof145

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third137Proof117 : runCachedNode 511 130518 Adaptive147Third137Node117 = false := by
  decide +kernel

#print axioms adaptive147Third137Proof117

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third137Proof118 : runCachedNode 511 130518 Adaptive147Third137Node118 = false := by
  decide +kernel

#print axioms adaptive147Third137Proof118

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third137Proof40 : runCachedNode 511 130518 Adaptive147Third137Node40 = false := by
  decide +kernel

#print axioms adaptive147Third137Proof40

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third137Proof173 : runCachedNode 511 130518 Adaptive147Third137Node173 = false := by
  decide +kernel

#print axioms adaptive147Third137Proof173

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third137Proof144 : runCachedNode 511 130518 Adaptive147Third137Node144 = false := by
  decide +kernel

#print axioms adaptive147Third137Proof144

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third137Proof39 : runCachedNode 511 130518 Adaptive147Third137Node39 = false := by
  decide +kernel

#print axioms adaptive147Third137Proof39

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third137Proof9 : runCachedNode 511 130518 Adaptive147Third137Node9 = false := by
  decide +kernel

#print axioms adaptive147Third137Proof9

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third137Proof56 : runCachedNode 511 130518 Adaptive147Third137Node56 = false := by
  decide +kernel

#print axioms adaptive147Third137Proof56

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third137Proof126 : runCachedNode 511 130518 Adaptive147Third137Node126 = false := by
  decide +kernel

#print axioms adaptive147Third137Proof126

end NineSeparatedSubsetSums
