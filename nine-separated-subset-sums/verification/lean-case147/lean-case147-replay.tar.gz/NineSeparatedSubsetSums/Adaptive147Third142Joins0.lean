import NineSeparatedSubsetSums.Adaptive147Third142State
import NineSeparatedSubsetSums.Adaptive147Third142Leaves33
import NineSeparatedSubsetSums.Adaptive147Third142Leaves25
import NineSeparatedSubsetSums.Adaptive147Third142Leaves42
import NineSeparatedSubsetSums.Adaptive147Third142Leaves12
import NineSeparatedSubsetSums.Adaptive147Third142Leaves7
import NineSeparatedSubsetSums.Adaptive147Third142Leaves41
import NineSeparatedSubsetSums.Adaptive147Third142Leaves5
import NineSeparatedSubsetSums.Adaptive147Third142Leaves40
import NineSeparatedSubsetSums.Adaptive147Third142Leaves37
import NineSeparatedSubsetSums.Adaptive147Third142Leaves19
import NineSeparatedSubsetSums.Adaptive147Third142Leaves38
import NineSeparatedSubsetSums.Adaptive147Third142Leaves36
import NineSeparatedSubsetSums.Adaptive147Third142Leaves34
import NineSeparatedSubsetSums.Adaptive147Third142Leaves35
import NineSeparatedSubsetSums.Adaptive147Third142Leaves31
import NineSeparatedSubsetSums.Adaptive147Third142Leaves28
import NineSeparatedSubsetSums.Adaptive147Third142Leaves30
import NineSeparatedSubsetSums.Adaptive147Third142Leaves4
import NineSeparatedSubsetSums.Adaptive147Third142Leaves43
import NineSeparatedSubsetSums.Adaptive147Third142Leaves26
import NineSeparatedSubsetSums.Adaptive147Third142Leaves13
import NineSeparatedSubsetSums.Adaptive147Third142Leaves0
import NineSeparatedSubsetSums.Adaptive147Third142Leaves39
import NineSeparatedSubsetSums.Adaptive147Third142Leaves1
import NineSeparatedSubsetSums.Adaptive147Third142Leaves3
import NineSeparatedSubsetSums.Adaptive147Third142Leaves32
import NineSeparatedSubsetSums.Adaptive147Third142Leaves27
import NineSeparatedSubsetSums.Adaptive147Third142Leaves11
import NineSeparatedSubsetSums.Adaptive147Third142Leaves29
import NineSeparatedSubsetSums.Adaptive147Third142Leaves21
import NineSeparatedSubsetSums.Adaptive147Third142Leaves23
import NineSeparatedSubsetSums.Adaptive147Third142Leaves2
import NineSeparatedSubsetSums.Adaptive147Third142Leaves24
import NineSeparatedSubsetSums.Adaptive147Third142Leaves22
import NineSeparatedSubsetSums.Adaptive147Third142Leaves17
import NineSeparatedSubsetSums.Adaptive147Third142Leaves14
import NineSeparatedSubsetSums.Adaptive147Third142Leaves44
import NineSeparatedSubsetSums.Adaptive147Third142Leaves8
import NineSeparatedSubsetSums.Adaptive147Third142Leaves6
import NineSeparatedSubsetSums.Adaptive147Third142Leaves16
import NineSeparatedSubsetSums.Adaptive147Third142Leaves15
import NineSeparatedSubsetSums.Adaptive147Third142Leaves20
import NineSeparatedSubsetSums.Adaptive147Third142Leaves18
import NineSeparatedSubsetSums.Adaptive147Third142Leaves10

namespace NineSeparatedSubsetSums

theorem adaptive147Third142Proof24 : runCachedNode 511 131213 Adaptive147Third142Node24 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 131213 Adaptive147Third142Node24 = [103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 128, 129, 130] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive147Third142Proof25
  · exact adaptive147Third142Proof26
  · exact adaptive147Third142Proof27
  · exact adaptive147Third142Proof28
  · exact adaptive147Third142Proof29
  · exact adaptive147Third142Proof30
  · exact adaptive147Third142Proof31
  · exact adaptive147Third142Proof32
  · exact adaptive147Third142Proof33
  · exact adaptive147Third142Proof34
  · exact adaptive147Third142Proof35
  · exact adaptive147Third142Proof36
  · exact adaptive147Third142Proof37
  · exact adaptive147Third142Proof38
  · exact adaptive147Third142Proof39
  · exact adaptive147Third142Proof40
  · exact adaptive147Third142Proof41
  · exact adaptive147Third142Proof42
  · exact adaptive147Third142Proof43
  · exact adaptive147Third142Proof44
  · exact adaptive147Third142Proof45
  · exact adaptive147Third142Proof46
  · exact adaptive147Third142Proof47
  · exact adaptive147Third142Proof48
  · exact adaptive147Third142Proof49
  · exact adaptive147Third142Proof50

#print axioms adaptive147Third142Proof24

theorem adaptive147Third142Proof51 : runCachedNode 511 131213 Adaptive147Third142Node51 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 131213 Adaptive147Third142Node51 = [102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 129, 130, 131] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive147Third142Proof52
  · exact adaptive147Third142Proof53
  · exact adaptive147Third142Proof54
  · exact adaptive147Third142Proof55
  · exact adaptive147Third142Proof56
  · exact adaptive147Third142Proof57
  · exact adaptive147Third142Proof58
  · exact adaptive147Third142Proof59
  · exact adaptive147Third142Proof60
  · exact adaptive147Third142Proof61
  · exact adaptive147Third142Proof62
  · exact adaptive147Third142Proof63
  · exact adaptive147Third142Proof64
  · exact adaptive147Third142Proof65
  · exact adaptive147Third142Proof66
  · exact adaptive147Third142Proof67
  · exact adaptive147Third142Proof68
  · exact adaptive147Third142Proof69
  · exact adaptive147Third142Proof70
  · exact adaptive147Third142Proof71
  · exact adaptive147Third142Proof72
  · exact adaptive147Third142Proof73
  · exact adaptive147Third142Proof74
  · exact adaptive147Third142Proof75
  · exact adaptive147Third142Proof76
  · exact adaptive147Third142Proof77
  · exact adaptive147Third142Proof78
  · exact adaptive147Third142Proof79

#print axioms adaptive147Third142Proof51

theorem adaptive147Third142Proof80 : runCachedNode 511 131213 Adaptive147Third142Node80 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 131213 Adaptive147Third142Node80 = [102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 130, 131, 132] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive147Third142Proof81
  · exact adaptive147Third142Proof82
  · exact adaptive147Third142Proof83
  · exact adaptive147Third142Proof84
  · exact adaptive147Third142Proof85
  · exact adaptive147Third142Proof86
  · exact adaptive147Third142Proof87
  · exact adaptive147Third142Proof88
  · exact adaptive147Third142Proof89
  · exact adaptive147Third142Proof90
  · exact adaptive147Third142Proof91
  · exact adaptive147Third142Proof92
  · exact adaptive147Third142Proof93
  · exact adaptive147Third142Proof94
  · exact adaptive147Third142Proof95
  · exact adaptive147Third142Proof96
  · exact adaptive147Third142Proof97
  · exact adaptive147Third142Proof98
  · exact adaptive147Third142Proof99
  · exact adaptive147Third142Proof100
  · exact adaptive147Third142Proof101
  · exact adaptive147Third142Proof102
  · exact adaptive147Third142Proof103
  · exact adaptive147Third142Proof104
  · exact adaptive147Third142Proof105
  · exact adaptive147Third142Proof106
  · exact adaptive147Third142Proof107
  · exact adaptive147Third142Proof108
  · exact adaptive147Third142Proof109

#print axioms adaptive147Third142Proof80

theorem adaptive147Third142Proof110 : runCachedNode 511 131213 Adaptive147Third142Node110 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 131213 Adaptive147Third142Node110 = [102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 131, 132, 133] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive147Third142Proof111
  · exact adaptive147Third142Proof112
  · exact adaptive147Third142Proof113
  · exact adaptive147Third142Proof114
  · exact adaptive147Third142Proof115
  · exact adaptive147Third142Proof116
  · exact adaptive147Third142Proof117
  · exact adaptive147Third142Proof118
  · exact adaptive147Third142Proof119
  · exact adaptive147Third142Proof120
  · exact adaptive147Third142Proof121
  · exact adaptive147Third142Proof122
  · exact adaptive147Third142Proof123
  · exact adaptive147Third142Proof124
  · exact adaptive147Third142Proof125
  · exact adaptive147Third142Proof126
  · exact adaptive147Third142Proof127
  · exact adaptive147Third142Proof128
  · exact adaptive147Third142Proof129
  · exact adaptive147Third142Proof130
  · exact adaptive147Third142Proof131
  · exact adaptive147Third142Proof132
  · exact adaptive147Third142Proof133
  · exact adaptive147Third142Proof134
  · exact adaptive147Third142Proof135
  · exact adaptive147Third142Proof136
  · exact adaptive147Third142Proof137
  · exact adaptive147Third142Proof138
  · exact adaptive147Third142Proof139
  · exact adaptive147Third142Proof140

#print axioms adaptive147Third142Proof110

theorem adaptive147Third142Proof141 : runCachedNode 511 131213 Adaptive147Third142Node141 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 131213 Adaptive147Third142Node141 = [102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 132, 133, 134] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive147Third142Proof142
  · exact adaptive147Third142Proof143
  · exact adaptive147Third142Proof144
  · exact adaptive147Third142Proof145
  · exact adaptive147Third142Proof146
  · exact adaptive147Third142Proof147
  · exact adaptive147Third142Proof148
  · exact adaptive147Third142Proof149
  · exact adaptive147Third142Proof150
  · exact adaptive147Third142Proof151
  · exact adaptive147Third142Proof152
  · exact adaptive147Third142Proof153
  · exact adaptive147Third142Proof154
  · exact adaptive147Third142Proof155
  · exact adaptive147Third142Proof156
  · exact adaptive147Third142Proof157
  · exact adaptive147Third142Proof158
  · exact adaptive147Third142Proof159
  · exact adaptive147Third142Proof160
  · exact adaptive147Third142Proof161
  · exact adaptive147Third142Proof162
  · exact adaptive147Third142Proof163
  · exact adaptive147Third142Proof164
  · exact adaptive147Third142Proof165
  · exact adaptive147Third142Proof166
  · exact adaptive147Third142Proof167
  · exact adaptive147Third142Proof168
  · exact adaptive147Third142Proof169
  · exact adaptive147Third142Proof170
  · exact adaptive147Third142Proof171
  · exact adaptive147Third142Proof172

#print axioms adaptive147Third142Proof141

theorem adaptive147Third142Proof173 : runCachedNode 511 131213 Adaptive147Third142Node173 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 131213 Adaptive147Third142Node173 = [101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 133, 134, 135] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive147Third142Proof174
  · exact adaptive147Third142Proof175
  · exact adaptive147Third142Proof176
  · exact adaptive147Third142Proof177
  · exact adaptive147Third142Proof178
  · exact adaptive147Third142Proof179
  · exact adaptive147Third142Proof180
  · exact adaptive147Third142Proof181
  · exact adaptive147Third142Proof182
  · exact adaptive147Third142Proof183
  · exact adaptive147Third142Proof184
  · exact adaptive147Third142Proof185
  · exact adaptive147Third142Proof186
  · exact adaptive147Third142Proof187
  · exact adaptive147Third142Proof188
  · exact adaptive147Third142Proof189
  · exact adaptive147Third142Proof190
  · exact adaptive147Third142Proof191
  · exact adaptive147Third142Proof192
  · exact adaptive147Third142Proof193
  · exact adaptive147Third142Proof194
  · exact adaptive147Third142Proof195
  · exact adaptive147Third142Proof196
  · exact adaptive147Third142Proof197
  · exact adaptive147Third142Proof198
  · exact adaptive147Third142Proof199
  · exact adaptive147Third142Proof200
  · exact adaptive147Third142Proof201
  · exact adaptive147Third142Proof202
  · exact adaptive147Third142Proof203
  · exact adaptive147Third142Proof204
  · exact adaptive147Third142Proof205
  · exact adaptive147Third142Proof206

#print axioms adaptive147Third142Proof173

theorem adaptive147Third142Proof241 : runCachedNode 511 131213 Adaptive147Third142Node241 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 131213 Adaptive147Third142Node241 = [89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 122, 123, 124, 125, 128, 129, 134] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive147Third142Proof242
  · exact adaptive147Third142Proof243
  · exact adaptive147Third142Proof244
  · exact adaptive147Third142Proof245
  · exact adaptive147Third142Proof246
  · exact adaptive147Third142Proof247
  · exact adaptive147Third142Proof248
  · exact adaptive147Third142Proof249
  · exact adaptive147Third142Proof250
  · exact adaptive147Third142Proof251
  · exact adaptive147Third142Proof252
  · exact adaptive147Third142Proof253
  · exact adaptive147Third142Proof254
  · exact adaptive147Third142Proof255
  · exact adaptive147Third142Proof256
  · exact adaptive147Third142Proof257
  · exact adaptive147Third142Proof258
  · exact adaptive147Third142Proof259
  · exact adaptive147Third142Proof260
  · exact adaptive147Third142Proof261
  · exact adaptive147Third142Proof262
  · exact adaptive147Third142Proof263
  · exact adaptive147Third142Proof264
  · exact adaptive147Third142Proof265
  · exact adaptive147Third142Proof266
  · exact adaptive147Third142Proof267
  · exact adaptive147Third142Proof268
  · exact adaptive147Third142Proof269
  · exact adaptive147Third142Proof270
  · exact adaptive147Third142Proof271
  · exact adaptive147Third142Proof272
  · exact adaptive147Third142Proof273
  · exact adaptive147Third142Proof274
  · exact adaptive147Third142Proof275
  · exact adaptive147Third142Proof276
  · exact adaptive147Third142Proof277
  · exact adaptive147Third142Proof278
  · exact adaptive147Third142Proof279
  · exact adaptive147Third142Proof280

#print axioms adaptive147Third142Proof241

theorem adaptive147Third142Proof207 : runCachedNode 511 131213 Adaptive147Third142Node207 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 131213 Adaptive147Third142Node207 = [101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 134, 135, 136] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive147Third142Proof208
  · exact adaptive147Third142Proof209
  · exact adaptive147Third142Proof210
  · exact adaptive147Third142Proof211
  · exact adaptive147Third142Proof212
  · exact adaptive147Third142Proof213
  · exact adaptive147Third142Proof214
  · exact adaptive147Third142Proof215
  · exact adaptive147Third142Proof216
  · exact adaptive147Third142Proof217
  · exact adaptive147Third142Proof218
  · exact adaptive147Third142Proof219
  · exact adaptive147Third142Proof220
  · exact adaptive147Third142Proof221
  · exact adaptive147Third142Proof222
  · exact adaptive147Third142Proof223
  · exact adaptive147Third142Proof224
  · exact adaptive147Third142Proof225
  · exact adaptive147Third142Proof226
  · exact adaptive147Third142Proof227
  · exact adaptive147Third142Proof228
  · exact adaptive147Third142Proof229
  · exact adaptive147Third142Proof230
  · exact adaptive147Third142Proof231
  · exact adaptive147Third142Proof232
  · exact adaptive147Third142Proof233
  · exact adaptive147Third142Proof234
  · exact adaptive147Third142Proof235
  · exact adaptive147Third142Proof236
  · exact adaptive147Third142Proof237
  · exact adaptive147Third142Proof238
  · exact adaptive147Third142Proof239
  · exact adaptive147Third142Proof240
  · exact adaptive147Third142Proof241

#print axioms adaptive147Third142Proof207

end NineSeparatedSubsetSums
