import NineSeparatedSubsetSums.Adaptive147Third139State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third139Proof38 : runCachedNode 511 130807 Adaptive147Third139Node38 = false := by
  decide +kernel

#print axioms adaptive147Third139Proof38

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third139Proof236 : runCachedNode 511 130807 Adaptive147Third139Node236 = false := by
  decide +kernel

#print axioms adaptive147Third139Proof236

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third139Proof10 : runCachedNode 511 130807 Adaptive147Third139Node10 = false := by
  decide +kernel

#print axioms adaptive147Third139Proof10

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third139Proof147 : runCachedNode 511 130807 Adaptive147Third139Node147 = false := by
  decide +kernel

#print axioms adaptive147Third139Proof147

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third139Proof90 : runCachedNode 511 130807 Adaptive147Third139Node90 = false := by
  decide +kernel

#print axioms adaptive147Third139Proof90

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third139Proof37 : runCachedNode 511 130807 Adaptive147Third139Node37 = false := by
  decide +kernel

#print axioms adaptive147Third139Proof37

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third139Proof148 : runCachedNode 511 130807 Adaptive147Third139Node148 = false := by
  decide +kernel

#print axioms adaptive147Third139Proof148

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third139Proof116 : runCachedNode 511 130807 Adaptive147Third139Node116 = false := by
  decide +kernel

#print axioms adaptive147Third139Proof116

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third139Proof117 : runCachedNode 511 130807 Adaptive147Third139Node117 = false := by
  decide +kernel

#print axioms adaptive147Third139Proof117

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third139Proof61 : runCachedNode 511 130807 Adaptive147Third139Node61 = false := by
  decide +kernel

#print axioms adaptive147Third139Proof61

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third139Proof89 : runCachedNode 511 130807 Adaptive147Third139Node89 = false := by
  decide +kernel

#print axioms adaptive147Third139Proof89

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third139Proof176 : runCachedNode 511 130807 Adaptive147Third139Node176 = false := by
  decide +kernel

#print axioms adaptive147Third139Proof176

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third139Proof36 : runCachedNode 511 130807 Adaptive147Third139Node36 = false := by
  decide +kernel

#print axioms adaptive147Third139Proof36

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third139Proof205 : runCachedNode 511 130807 Adaptive147Third139Node205 = false := by
  decide +kernel

#print axioms adaptive147Third139Proof205

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third139Proof91 : runCachedNode 511 130807 Adaptive147Third139Node91 = false := by
  decide +kernel

#print axioms adaptive147Third139Proof91

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third139Proof87 : runCachedNode 511 130807 Adaptive147Third139Node87 = false := by
  decide +kernel

#print axioms adaptive147Third139Proof87

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third139Proof88 : runCachedNode 511 130807 Adaptive147Third139Node88 = false := by
  decide +kernel

#print axioms adaptive147Third139Proof88

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third139Proof206 : runCachedNode 511 130807 Adaptive147Third139Node206 = false := by
  decide +kernel

#print axioms adaptive147Third139Proof206

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third139Proof59 : runCachedNode 511 130807 Adaptive147Third139Node59 = false := by
  decide +kernel

#print axioms adaptive147Third139Proof59

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third139Proof118 : runCachedNode 511 130807 Adaptive147Third139Node118 = false := by
  decide +kernel

#print axioms adaptive147Third139Proof118

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third139Proof129 : runCachedNode 511 130807 Adaptive147Third139Node129 = false := by
  decide +kernel

#print axioms adaptive147Third139Proof129

end NineSeparatedSubsetSums
