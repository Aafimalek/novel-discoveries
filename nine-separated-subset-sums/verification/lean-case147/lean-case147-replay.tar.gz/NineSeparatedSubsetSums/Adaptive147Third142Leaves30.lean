import NineSeparatedSubsetSums.Adaptive147Third142State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third142Proof50 : runCachedNode 511 131213 Adaptive147Third142Node50 = false := by
  decide +kernel

#print axioms adaptive147Third142Proof50

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third142Proof194 : runCachedNode 511 131213 Adaptive147Third142Node194 = false := by
  decide +kernel

#print axioms adaptive147Third142Proof194

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third142Proof195 : runCachedNode 511 131213 Adaptive147Third142Node195 = false := by
  decide +kernel

#print axioms adaptive147Third142Proof195

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third142Proof74 : runCachedNode 511 131213 Adaptive147Third142Node74 = false := by
  decide +kernel

#print axioms adaptive147Third142Proof74

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third142Proof131 : runCachedNode 511 131213 Adaptive147Third142Node131 = false := by
  decide +kernel

#print axioms adaptive147Third142Proof131

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third142Proof196 : runCachedNode 511 131213 Adaptive147Third142Node196 = false := by
  decide +kernel

#print axioms adaptive147Third142Proof196

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third142Proof278 : runCachedNode 511 131213 Adaptive147Third142Node278 = false := by
  decide +kernel

#print axioms adaptive147Third142Proof278

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third142Proof343 : runCachedNode 511 131213 Adaptive147Third142Node343 = false := by
  decide +kernel

#print axioms adaptive147Third142Proof343

end NineSeparatedSubsetSums
