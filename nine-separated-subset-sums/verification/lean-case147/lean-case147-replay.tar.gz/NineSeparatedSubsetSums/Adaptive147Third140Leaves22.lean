import NineSeparatedSubsetSums.Adaptive147Third140State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third140Proof12 : runCachedNode 511 130945 Adaptive147Third140Node12 = false := by
  decide +kernel

#print axioms adaptive147Third140Proof12

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third140Proof96 : runCachedNode 511 130945 Adaptive147Third140Node96 = false := by
  decide +kernel

#print axioms adaptive147Third140Proof96

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third140Proof252 : runCachedNode 511 130945 Adaptive147Third140Node252 = false := by
  decide +kernel

#print axioms adaptive147Third140Proof252

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third140Proof159 : runCachedNode 511 130945 Adaptive147Third140Node159 = false := by
  decide +kernel

#print axioms adaptive147Third140Proof159

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third140Proof97 : runCachedNode 511 130945 Adaptive147Third140Node97 = false := by
  decide +kernel

#print axioms adaptive147Third140Proof97

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third140Proof93 : runCachedNode 511 130945 Adaptive147Third140Node93 = false := by
  decide +kernel

#print axioms adaptive147Third140Proof93

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third140Proof124 : runCachedNode 511 130945 Adaptive147Third140Node124 = false := by
  decide +kernel

#print axioms adaptive147Third140Proof124

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third140Proof156 : runCachedNode 511 130945 Adaptive147Third140Node156 = false := by
  decide +kernel

#print axioms adaptive147Third140Proof156

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third140Proof251 : runCachedNode 511 130945 Adaptive147Third140Node251 = false := by
  decide +kernel

#print axioms adaptive147Third140Proof251

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third140Proof89 : runCachedNode 511 130945 Adaptive147Third140Node89 = false := by
  decide +kernel

#print axioms adaptive147Third140Proof89

end NineSeparatedSubsetSums
