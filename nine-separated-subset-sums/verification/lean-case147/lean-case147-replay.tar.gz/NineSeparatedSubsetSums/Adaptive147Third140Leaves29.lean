import NineSeparatedSubsetSums.Adaptive147Third140State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third140Proof169 : runCachedNode 511 130945 Adaptive147Third140Node169 = false := by
  decide +kernel

#print axioms adaptive147Third140Proof169

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third140Proof201 : runCachedNode 511 130945 Adaptive147Third140Node201 = false := by
  decide +kernel

#print axioms adaptive147Third140Proof201

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third140Proof50 : runCachedNode 511 130945 Adaptive147Third140Node50 = false := by
  decide +kernel

#print axioms adaptive147Third140Proof50

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third140Proof105 : runCachedNode 511 130945 Adaptive147Third140Node105 = false := by
  decide +kernel

#print axioms adaptive147Third140Proof105

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third140Proof135 : runCachedNode 511 130945 Adaptive147Third140Node135 = false := by
  decide +kernel

#print axioms adaptive147Third140Proof135

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third140Proof166 : runCachedNode 511 130945 Adaptive147Third140Node166 = false := by
  decide +kernel

#print axioms adaptive147Third140Proof166

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third140Proof198 : runCachedNode 511 130945 Adaptive147Third140Node198 = false := by
  decide +kernel

#print axioms adaptive147Third140Proof198

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third140Proof199 : runCachedNode 511 130945 Adaptive147Third140Node199 = false := by
  decide +kernel

#print axioms adaptive147Third140Proof199

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third140Proof200 : runCachedNode 511 130945 Adaptive147Third140Node200 = false := by
  decide +kernel

#print axioms adaptive147Third140Proof200

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third140Proof231 : runCachedNode 511 130945 Adaptive147Third140Node231 = false := by
  decide +kernel

#print axioms adaptive147Third140Proof231

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third140Proof232 : runCachedNode 511 130945 Adaptive147Third140Node232 = false := by
  decide +kernel

#print axioms adaptive147Third140Proof232

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third140Proof233 : runCachedNode 511 130945 Adaptive147Third140Node233 = false := by
  decide +kernel

#print axioms adaptive147Third140Proof233

end NineSeparatedSubsetSums
