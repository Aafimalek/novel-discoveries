import NineSeparatedSubsetSums.Adaptive147Third142State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third142Proof314 : runCachedNode 511 131213 Adaptive147Third142Node314 = false := by
  decide +kernel

#print axioms adaptive147Third142Proof314

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third142Proof171 : runCachedNode 511 131213 Adaptive147Third142Node171 = false := by
  decide +kernel

#print axioms adaptive147Third142Proof171

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third142Proof37 : runCachedNode 511 131213 Adaptive147Third142Node37 = false := by
  decide +kernel

#print axioms adaptive147Third142Proof37

end NineSeparatedSubsetSums
