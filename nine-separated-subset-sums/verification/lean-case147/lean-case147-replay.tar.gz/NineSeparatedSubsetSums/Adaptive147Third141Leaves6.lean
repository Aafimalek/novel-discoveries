import NineSeparatedSubsetSums.Adaptive147Third141State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third141Proof165 : runCachedNode 511 131086 Adaptive147Third141Node165 = false := by
  decide +kernel

#print axioms adaptive147Third141Proof165

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third141Proof16 : runCachedNode 511 131086 Adaptive147Third141Node16 = false := by
  decide +kernel

#print axioms adaptive147Third141Proof16

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third141Proof118 : runCachedNode 511 131086 Adaptive147Third141Node118 = false := by
  decide +kernel

#print axioms adaptive147Third141Proof118

end NineSeparatedSubsetSums
