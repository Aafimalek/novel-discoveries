import NineSeparatedSubsetSums.Adaptive147Third118State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third118Proof0 : runCachedNode 511 126373 Adaptive147Third118Node0 = false := by
  decide +kernel

#print axioms adaptive147Third118Proof0

end NineSeparatedSubsetSums
