import NineSeparatedSubsetSums.Adaptive147Third141State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third141Proof332 : runCachedNode 511 131086 Adaptive147Third141Node332 = false := by
  decide +kernel

#print axioms adaptive147Third141Proof332

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third141Proof71 : runCachedNode 511 131086 Adaptive147Third141Node71 = false := by
  decide +kernel

#print axioms adaptive147Third141Proof71

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third141Proof12 : runCachedNode 511 131086 Adaptive147Third141Node12 = false := by
  decide +kernel

#print axioms adaptive147Third141Proof12

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third141Proof155 : runCachedNode 511 131086 Adaptive147Third141Node155 = false := by
  decide +kernel

#print axioms adaptive147Third141Proof155

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third141Proof44 : runCachedNode 511 131086 Adaptive147Third141Node44 = false := by
  decide +kernel

#print axioms adaptive147Third141Proof44

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third141Proof327 : runCachedNode 511 131086 Adaptive147Third141Node327 = false := by
  decide +kernel

#print axioms adaptive147Third141Proof327

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third141Proof223 : runCachedNode 511 131086 Adaptive147Third141Node223 = false := by
  decide +kernel

#print axioms adaptive147Third141Proof223

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third141Proof299 : runCachedNode 511 131086 Adaptive147Third141Node299 = false := by
  decide +kernel

#print axioms adaptive147Third141Proof299

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third141Proof98 : runCachedNode 511 131086 Adaptive147Third141Node98 = false := by
  decide +kernel

#print axioms adaptive147Third141Proof98

end NineSeparatedSubsetSums
