import NineSeparatedSubsetSums.Adaptive147Third139State
import NineSeparatedSubsetSums.Adaptive147Third139Leaves10
import NineSeparatedSubsetSums.Adaptive147Third139Leaves5
import NineSeparatedSubsetSums.Adaptive147Third139Leaves7
import NineSeparatedSubsetSums.Adaptive147Third139Leaves3
import NineSeparatedSubsetSums.Adaptive147Third139Leaves6
import NineSeparatedSubsetSums.Adaptive147Third139Leaves21
import NineSeparatedSubsetSums.Adaptive147Third139Leaves4
import NineSeparatedSubsetSums.Adaptive147Third139Leaves20
import NineSeparatedSubsetSums.Adaptive147Third139Leaves19
import NineSeparatedSubsetSums.Adaptive147Third139Leaves16
import NineSeparatedSubsetSums.Adaptive147Third139Leaves17
import NineSeparatedSubsetSums.Adaptive147Third139Leaves15
import NineSeparatedSubsetSums.Adaptive147Third139Leaves12
import NineSeparatedSubsetSums.Adaptive147Third139Leaves11
import NineSeparatedSubsetSums.Adaptive147Third139Leaves8
import NineSeparatedSubsetSums.Adaptive147Third139Leaves0
import NineSeparatedSubsetSums.Adaptive147Third139Joins0

namespace NineSeparatedSubsetSums

theorem adaptive147Third139Proof0 : runCachedNode 511 130807 Adaptive147Third139Node0 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130807 Adaptive147Third139Node0 = [109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 132, 133, 134, 135, 136, 137] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive147Third139Proof1
  · exact adaptive147Third139Proof2
  · exact adaptive147Third139Proof3
  · exact adaptive147Third139Proof4
  · exact adaptive147Third139Proof5
  · exact adaptive147Third139Proof6
  · exact adaptive147Third139Proof7
  · exact adaptive147Third139Proof8
  · exact adaptive147Third139Proof9
  · exact adaptive147Third139Proof10
  · exact adaptive147Third139Proof11
  · exact adaptive147Third139Proof12
  · exact adaptive147Third139Proof13
  · exact adaptive147Third139Proof14
  · exact adaptive147Third139Proof15
  · exact adaptive147Third139Proof16
  · exact adaptive147Third139Proof17
  · exact adaptive147Third139Proof18
  · exact adaptive147Third139Proof19
  · exact adaptive147Third139Proof20
  · exact adaptive147Third139Proof21
  · exact adaptive147Third139Proof22
  · exact adaptive147Third139Proof46
  · exact adaptive147Third139Proof72
  · exact adaptive147Third139Proof99
  · exact adaptive147Third139Proof127
  · exact adaptive147Third139Proof156
  · exact adaptive147Third139Proof187
  · exact adaptive147Third139Proof219

#print axioms adaptive147Third139Proof0

end NineSeparatedSubsetSums
