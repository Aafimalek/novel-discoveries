import NineSeparatedSubsetSums.Adaptive147Third140State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third140Proof19 : runCachedNode 511 130945 Adaptive147Third140Node19 = false := by
  decide +kernel

#print axioms adaptive147Third140Proof19

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third140Proof99 : runCachedNode 511 130945 Adaptive147Third140Node99 = false := by
  decide +kernel

#print axioms adaptive147Third140Proof99

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third140Proof160 : runCachedNode 511 130945 Adaptive147Third140Node160 = false := by
  decide +kernel

#print axioms adaptive147Third140Proof160

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third140Proof1 : runCachedNode 511 130945 Adaptive147Third140Node1 = false := by
  decide +kernel

#print axioms adaptive147Third140Proof1

end NineSeparatedSubsetSums
