import NineSeparatedSubsetSums.Adaptive147Third130State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third130Proof13 : runCachedNode 511 129214 Adaptive147Third130Node13 = false := by
  decide +kernel

#print axioms adaptive147Third130Proof13

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third130Proof12 : runCachedNode 511 129214 Adaptive147Third130Node12 = false := by
  decide +kernel

#print axioms adaptive147Third130Proof12

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third130Proof11 : runCachedNode 511 129214 Adaptive147Third130Node11 = false := by
  decide +kernel

#print axioms adaptive147Third130Proof11

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third130Proof10 : runCachedNode 511 129214 Adaptive147Third130Node10 = false := by
  decide +kernel

#print axioms adaptive147Third130Proof10

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third130Proof9 : runCachedNode 511 129214 Adaptive147Third130Node9 = false := by
  decide +kernel

#print axioms adaptive147Third130Proof9

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third130Proof8 : runCachedNode 511 129214 Adaptive147Third130Node8 = false := by
  decide +kernel

#print axioms adaptive147Third130Proof8

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third130Proof7 : runCachedNode 511 129214 Adaptive147Third130Node7 = false := by
  decide +kernel

#print axioms adaptive147Third130Proof7

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third130Proof5 : runCachedNode 511 129214 Adaptive147Third130Node5 = false := by
  decide +kernel

#print axioms adaptive147Third130Proof5

end NineSeparatedSubsetSums
