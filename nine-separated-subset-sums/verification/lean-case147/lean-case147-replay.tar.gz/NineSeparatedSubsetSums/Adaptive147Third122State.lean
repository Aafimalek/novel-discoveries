import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive147Third122Node0 : CachedSearchNode :=
  ⟨4, 121, computeCenteredMask [148,147,122], 417, 58397⟩

end NineSeparatedSubsetSums
