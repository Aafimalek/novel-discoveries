import NineSeparatedSubsetSums.Adaptive147Third137State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third137Proof15 : runCachedNode 511 130518 Adaptive147Third137Node15 = false := by
  decide +kernel

#print axioms adaptive147Third137Proof15

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third137Proof121 : runCachedNode 511 130518 Adaptive147Third137Node121 = false := by
  decide +kernel

#print axioms adaptive147Third137Proof121

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third137Proof180 : runCachedNode 511 130518 Adaptive147Third137Node180 = false := by
  decide +kernel

#print axioms adaptive147Third137Proof180

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third137Proof14 : runCachedNode 511 130518 Adaptive147Third137Node14 = false := by
  decide +kernel

#print axioms adaptive147Third137Proof14

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third137Proof147 : runCachedNode 511 130518 Adaptive147Third137Node147 = false := by
  decide +kernel

#print axioms adaptive147Third137Proof147

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third137Proof28 : runCachedNode 511 130518 Adaptive147Third137Node28 = false := by
  decide +kernel

#print axioms adaptive147Third137Proof28

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third137Proof71 : runCachedNode 511 130518 Adaptive147Third137Node71 = false := by
  decide +kernel

#print axioms adaptive147Third137Proof71

end NineSeparatedSubsetSums
