import NineSeparatedSubsetSums.Adaptive147Third142State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third142Proof23 : runCachedNode 511 131213 Adaptive147Third142Node23 = false := by
  decide +kernel

#print axioms adaptive147Third142Proof23

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third142Proof129 : runCachedNode 511 131213 Adaptive147Third142Node129 = false := by
  decide +kernel

#print axioms adaptive147Third142Proof129

end NineSeparatedSubsetSums
