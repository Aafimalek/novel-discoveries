import NineSeparatedSubsetSums.Adaptive147Third129State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third129Proof8 : runCachedNode 511 129010 Adaptive147Third129Node8 = false := by
  decide +kernel

#print axioms adaptive147Third129Proof8

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third129Proof6 : runCachedNode 511 129010 Adaptive147Third129Node6 = false := by
  decide +kernel

#print axioms adaptive147Third129Proof6

end NineSeparatedSubsetSums
