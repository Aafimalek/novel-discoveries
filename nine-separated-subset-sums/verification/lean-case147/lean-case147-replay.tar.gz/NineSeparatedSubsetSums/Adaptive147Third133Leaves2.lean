import NineSeparatedSubsetSums.Adaptive147Third133State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third133Proof19 : runCachedNode 511 129861 Adaptive147Third133Node19 = false := by
  decide +kernel

#print axioms adaptive147Third133Proof19

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third133Proof17 : runCachedNode 511 129861 Adaptive147Third133Node17 = false := by
  decide +kernel

#print axioms adaptive147Third133Proof17

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third133Proof12 : runCachedNode 511 129861 Adaptive147Third133Node12 = false := by
  decide +kernel

#print axioms adaptive147Third133Proof12

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third133Proof33 : runCachedNode 511 129861 Adaptive147Third133Node33 = false := by
  decide +kernel

#print axioms adaptive147Third133Proof33

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third133Proof23 : runCachedNode 511 129861 Adaptive147Third133Node23 = false := by
  decide +kernel

#print axioms adaptive147Third133Proof23

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third133Proof24 : runCachedNode 511 129861 Adaptive147Third133Node24 = false := by
  decide +kernel

#print axioms adaptive147Third133Proof24

end NineSeparatedSubsetSums
