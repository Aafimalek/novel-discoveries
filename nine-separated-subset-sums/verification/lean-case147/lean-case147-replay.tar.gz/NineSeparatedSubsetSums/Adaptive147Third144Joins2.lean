import NineSeparatedSubsetSums.Adaptive147Third144State
import NineSeparatedSubsetSums.Adaptive147Third144Leaves67
import NineSeparatedSubsetSums.Adaptive147Third144Leaves68
import NineSeparatedSubsetSums.Adaptive147Third144Leaves66
import NineSeparatedSubsetSums.Adaptive147Third144Leaves64
import NineSeparatedSubsetSums.Adaptive147Third144Leaves63
import NineSeparatedSubsetSums.Adaptive147Third144Leaves62
import NineSeparatedSubsetSums.Adaptive147Third144Leaves61
import NineSeparatedSubsetSums.Adaptive147Third144Leaves60
import NineSeparatedSubsetSums.Adaptive147Third144Leaves59
import NineSeparatedSubsetSums.Adaptive147Third144Leaves58
import NineSeparatedSubsetSums.Adaptive147Third144Leaves57
import NineSeparatedSubsetSums.Adaptive147Third144Leaves56
import NineSeparatedSubsetSums.Adaptive147Third144Leaves55
import NineSeparatedSubsetSums.Adaptive147Third144Leaves54
import NineSeparatedSubsetSums.Adaptive147Third144Leaves51
import NineSeparatedSubsetSums.Adaptive147Third144Leaves49
import NineSeparatedSubsetSums.Adaptive147Third144Leaves45
import NineSeparatedSubsetSums.Adaptive147Third144Leaves41
import NineSeparatedSubsetSums.Adaptive147Third144Leaves31
import NineSeparatedSubsetSums.Adaptive147Third144Leaves53
import NineSeparatedSubsetSums.Adaptive147Third144Leaves52
import NineSeparatedSubsetSums.Adaptive147Third144Leaves46
import NineSeparatedSubsetSums.Adaptive147Third144Leaves47
import NineSeparatedSubsetSums.Adaptive147Third144Leaves44
import NineSeparatedSubsetSums.Adaptive147Third144Leaves40
import NineSeparatedSubsetSums.Adaptive147Third144Leaves36
import NineSeparatedSubsetSums.Adaptive147Third144Leaves28
import NineSeparatedSubsetSums.Adaptive147Third144Leaves24
import NineSeparatedSubsetSums.Adaptive147Third144Leaves14
import NineSeparatedSubsetSums.Adaptive147Third144Leaves50
import NineSeparatedSubsetSums.Adaptive147Third144Leaves48
import NineSeparatedSubsetSums.Adaptive147Third144Leaves42
import NineSeparatedSubsetSums.Adaptive147Third144Leaves27
import NineSeparatedSubsetSums.Adaptive147Third144Leaves39
import NineSeparatedSubsetSums.Adaptive147Third144Leaves19
import NineSeparatedSubsetSums.Adaptive147Third144Leaves33
import NineSeparatedSubsetSums.Adaptive147Third144Leaves26
import NineSeparatedSubsetSums.Adaptive147Third144Leaves29
import NineSeparatedSubsetSums.Adaptive147Third144Leaves9
import NineSeparatedSubsetSums.Adaptive147Third144Leaves8
import NineSeparatedSubsetSums.Adaptive147Third144Leaves20
import NineSeparatedSubsetSums.Adaptive147Third144Leaves10
import NineSeparatedSubsetSums.Adaptive147Third144Joins1
import NineSeparatedSubsetSums.Adaptive147Third144Leaves38
import NineSeparatedSubsetSums.Adaptive147Third144Leaves4
import NineSeparatedSubsetSums.Adaptive147Third144Leaves69
import NineSeparatedSubsetSums.Adaptive147Third144Leaves65
import NineSeparatedSubsetSums.Adaptive147Third144Leaves1
import NineSeparatedSubsetSums.Adaptive147Third144Leaves18
import NineSeparatedSubsetSums.Adaptive147Third144Leaves13
import NineSeparatedSubsetSums.Adaptive147Third144Leaves43
import NineSeparatedSubsetSums.Adaptive147Third144Leaves34
import NineSeparatedSubsetSums.Adaptive147Third144Leaves6
import NineSeparatedSubsetSums.Adaptive147Third144Leaves32
import NineSeparatedSubsetSums.Adaptive147Third144Leaves17
import NineSeparatedSubsetSums.Adaptive147Third144Leaves11
import NineSeparatedSubsetSums.Adaptive147Third144Leaves2
import NineSeparatedSubsetSums.Adaptive147Third144Leaves12
import NineSeparatedSubsetSums.Adaptive147Third144Leaves35
import NineSeparatedSubsetSums.Adaptive147Third144Leaves37
import NineSeparatedSubsetSums.Adaptive147Third144Leaves21
import NineSeparatedSubsetSums.Adaptive147Third144Leaves7
import NineSeparatedSubsetSums.Adaptive147Third144Leaves0
import NineSeparatedSubsetSums.Adaptive147Third144Joins0

namespace NineSeparatedSubsetSums

theorem adaptive147Third144Proof618 : runCachedNode 511 131483 Adaptive147Third144Node618 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 131483 Adaptive147Third144Node618 = [87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 127, 128, 131] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive147Third144Proof619
  · exact adaptive147Third144Proof620
  · exact adaptive147Third144Proof621
  · exact adaptive147Third144Proof622
  · exact adaptive147Third144Proof623
  · exact adaptive147Third144Proof624
  · exact adaptive147Third144Proof625
  · exact adaptive147Third144Proof626
  · exact adaptive147Third144Proof627
  · exact adaptive147Third144Proof628
  · exact adaptive147Third144Proof629
  · exact adaptive147Third144Proof630
  · exact adaptive147Third144Proof631
  · exact adaptive147Third144Proof632
  · exact adaptive147Third144Proof633
  · exact adaptive147Third144Proof634
  · exact adaptive147Third144Proof635
  · exact adaptive147Third144Proof636
  · exact adaptive147Third144Proof637
  · exact adaptive147Third144Proof638
  · exact adaptive147Third144Proof639
  · exact adaptive147Third144Proof640
  · exact adaptive147Third144Proof641
  · exact adaptive147Third144Proof642
  · exact adaptive147Third144Proof643
  · exact adaptive147Third144Proof644
  · exact adaptive147Third144Proof645
  · exact adaptive147Third144Proof646
  · exact adaptive147Third144Proof647
  · exact adaptive147Third144Proof648
  · exact adaptive147Third144Proof649
  · exact adaptive147Third144Proof650
  · exact adaptive147Third144Proof651
  · exact adaptive147Third144Proof652
  · exact adaptive147Third144Proof653
  · exact adaptive147Third144Proof654
  · exact adaptive147Third144Proof655
  · exact adaptive147Third144Proof656
  · exact adaptive147Third144Proof657
  · exact adaptive147Third144Proof658
  · exact adaptive147Third144Proof659
  · exact adaptive147Third144Proof660

#print axioms adaptive147Third144Proof618

theorem adaptive147Third144Proof661 : runCachedNode 511 131483 Adaptive147Third144Node661 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 131483 Adaptive147Third144Node661 = [86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 130, 131, 134] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive147Third144Proof662
  · exact adaptive147Third144Proof663
  · exact adaptive147Third144Proof664
  · exact adaptive147Third144Proof665
  · exact adaptive147Third144Proof666
  · exact adaptive147Third144Proof667
  · exact adaptive147Third144Proof668
  · exact adaptive147Third144Proof669
  · exact adaptive147Third144Proof670
  · exact adaptive147Third144Proof671
  · exact adaptive147Third144Proof672
  · exact adaptive147Third144Proof673
  · exact adaptive147Third144Proof674
  · exact adaptive147Third144Proof675
  · exact adaptive147Third144Proof676
  · exact adaptive147Third144Proof677
  · exact adaptive147Third144Proof678
  · exact adaptive147Third144Proof679
  · exact adaptive147Third144Proof680
  · exact adaptive147Third144Proof681
  · exact adaptive147Third144Proof682
  · exact adaptive147Third144Proof683
  · exact adaptive147Third144Proof684
  · exact adaptive147Third144Proof685
  · exact adaptive147Third144Proof686
  · exact adaptive147Third144Proof687
  · exact adaptive147Third144Proof688
  · exact adaptive147Third144Proof689
  · exact adaptive147Third144Proof690
  · exact adaptive147Third144Proof691
  · exact adaptive147Third144Proof692
  · exact adaptive147Third144Proof693
  · exact adaptive147Third144Proof694
  · exact adaptive147Third144Proof695
  · exact adaptive147Third144Proof696
  · exact adaptive147Third144Proof697
  · exact adaptive147Third144Proof698
  · exact adaptive147Third144Proof699
  · exact adaptive147Third144Proof700
  · exact adaptive147Third144Proof701
  · exact adaptive147Third144Proof702
  · exact adaptive147Third144Proof703
  · exact adaptive147Third144Proof704
  · exact adaptive147Third144Proof705
  · exact adaptive147Third144Proof706
  · exact adaptive147Third144Proof707

#print axioms adaptive147Third144Proof661

theorem adaptive147Third144Proof501 : runCachedNode 511 131483 Adaptive147Third144Node501 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 131483 Adaptive147Third144Node501 = [100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 132, 133, 134, 135, 136, 139] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive147Third144Proof502
  · exact adaptive147Third144Proof503
  · exact adaptive147Third144Proof504
  · exact adaptive147Third144Proof505
  · exact adaptive147Third144Proof506
  · exact adaptive147Third144Proof507
  · exact adaptive147Third144Proof508
  · exact adaptive147Third144Proof509
  · exact adaptive147Third144Proof510
  · exact adaptive147Third144Proof511
  · exact adaptive147Third144Proof512
  · exact adaptive147Third144Proof513
  · exact adaptive147Third144Proof514
  · exact adaptive147Third144Proof515
  · exact adaptive147Third144Proof516
  · exact adaptive147Third144Proof517
  · exact adaptive147Third144Proof518
  · exact adaptive147Third144Proof519
  · exact adaptive147Third144Proof520
  · exact adaptive147Third144Proof521
  · exact adaptive147Third144Proof522
  · exact adaptive147Third144Proof523
  · exact adaptive147Third144Proof524
  · exact adaptive147Third144Proof525
  · exact adaptive147Third144Proof526
  · exact adaptive147Third144Proof527
  · exact adaptive147Third144Proof528
  · exact adaptive147Third144Proof529
  · exact adaptive147Third144Proof530
  · exact adaptive147Third144Proof531
  · exact adaptive147Third144Proof532
  · exact adaptive147Third144Proof533
  · exact adaptive147Third144Proof534
  · exact adaptive147Third144Proof535
  · exact adaptive147Third144Proof536
  · exact adaptive147Third144Proof576
  · exact adaptive147Third144Proof618
  · exact adaptive147Third144Proof661

#print axioms adaptive147Third144Proof501

theorem adaptive147Third144Proof746 : runCachedNode 511 131483 Adaptive147Third144Node746 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 131483 Adaptive147Third144Node746 = [86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 129, 130] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive147Third144Proof747
  · exact adaptive147Third144Proof748
  · exact adaptive147Third144Proof749
  · exact adaptive147Third144Proof750
  · exact adaptive147Third144Proof751
  · exact adaptive147Third144Proof752
  · exact adaptive147Third144Proof753
  · exact adaptive147Third144Proof754
  · exact adaptive147Third144Proof755
  · exact adaptive147Third144Proof756
  · exact adaptive147Third144Proof757
  · exact adaptive147Third144Proof758
  · exact adaptive147Third144Proof759
  · exact adaptive147Third144Proof760
  · exact adaptive147Third144Proof761
  · exact adaptive147Third144Proof762
  · exact adaptive147Third144Proof763
  · exact adaptive147Third144Proof764
  · exact adaptive147Third144Proof765
  · exact adaptive147Third144Proof766
  · exact adaptive147Third144Proof767
  · exact adaptive147Third144Proof768
  · exact adaptive147Third144Proof769
  · exact adaptive147Third144Proof770
  · exact adaptive147Third144Proof771
  · exact adaptive147Third144Proof772
  · exact adaptive147Third144Proof773
  · exact adaptive147Third144Proof774
  · exact adaptive147Third144Proof775
  · exact adaptive147Third144Proof776
  · exact adaptive147Third144Proof777
  · exact adaptive147Third144Proof778
  · exact adaptive147Third144Proof779
  · exact adaptive147Third144Proof780
  · exact adaptive147Third144Proof781
  · exact adaptive147Third144Proof782
  · exact adaptive147Third144Proof783
  · exact adaptive147Third144Proof784
  · exact adaptive147Third144Proof785
  · exact adaptive147Third144Proof786
  · exact adaptive147Third144Proof787
  · exact adaptive147Third144Proof788
  · exact adaptive147Third144Proof789
  · exact adaptive147Third144Proof790

#print axioms adaptive147Third144Proof746

theorem adaptive147Third144Proof791 : runCachedNode 511 131483 Adaptive147Third144Node791 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 131483 Adaptive147Third144Node791 = [85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 132, 133] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive147Third144Proof792
  · exact adaptive147Third144Proof793
  · exact adaptive147Third144Proof794
  · exact adaptive147Third144Proof795
  · exact adaptive147Third144Proof796
  · exact adaptive147Third144Proof797
  · exact adaptive147Third144Proof798
  · exact adaptive147Third144Proof799
  · exact adaptive147Third144Proof800
  · exact adaptive147Third144Proof801
  · exact adaptive147Third144Proof802
  · exact adaptive147Third144Proof803
  · exact adaptive147Third144Proof804
  · exact adaptive147Third144Proof805
  · exact adaptive147Third144Proof806
  · exact adaptive147Third144Proof807
  · exact adaptive147Third144Proof808
  · exact adaptive147Third144Proof809
  · exact adaptive147Third144Proof810
  · exact adaptive147Third144Proof811
  · exact adaptive147Third144Proof812
  · exact adaptive147Third144Proof813
  · exact adaptive147Third144Proof814
  · exact adaptive147Third144Proof815
  · exact adaptive147Third144Proof816
  · exact adaptive147Third144Proof817
  · exact adaptive147Third144Proof818
  · exact adaptive147Third144Proof819
  · exact adaptive147Third144Proof820
  · exact adaptive147Third144Proof821
  · exact adaptive147Third144Proof822
  · exact adaptive147Third144Proof823
  · exact adaptive147Third144Proof824
  · exact adaptive147Third144Proof825
  · exact adaptive147Third144Proof826
  · exact adaptive147Third144Proof827
  · exact adaptive147Third144Proof828
  · exact adaptive147Third144Proof829
  · exact adaptive147Third144Proof830
  · exact adaptive147Third144Proof831
  · exact adaptive147Third144Proof832
  · exact adaptive147Third144Proof833
  · exact adaptive147Third144Proof834
  · exact adaptive147Third144Proof835
  · exact adaptive147Third144Proof836
  · exact adaptive147Third144Proof837
  · exact adaptive147Third144Proof838
  · exact adaptive147Third144Proof839

#print axioms adaptive147Third144Proof791

theorem adaptive147Third144Proof708 : runCachedNode 511 131483 Adaptive147Third144Node708 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 131483 Adaptive147Third144Node708 = [100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 132, 133, 134, 135, 136, 137, 140] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive147Third144Proof709
  · exact adaptive147Third144Proof710
  · exact adaptive147Third144Proof711
  · exact adaptive147Third144Proof712
  · exact adaptive147Third144Proof713
  · exact adaptive147Third144Proof714
  · exact adaptive147Third144Proof715
  · exact adaptive147Third144Proof716
  · exact adaptive147Third144Proof717
  · exact adaptive147Third144Proof718
  · exact adaptive147Third144Proof719
  · exact adaptive147Third144Proof720
  · exact adaptive147Third144Proof721
  · exact adaptive147Third144Proof722
  · exact adaptive147Third144Proof723
  · exact adaptive147Third144Proof724
  · exact adaptive147Third144Proof725
  · exact adaptive147Third144Proof726
  · exact adaptive147Third144Proof727
  · exact adaptive147Third144Proof728
  · exact adaptive147Third144Proof729
  · exact adaptive147Third144Proof730
  · exact adaptive147Third144Proof731
  · exact adaptive147Third144Proof732
  · exact adaptive147Third144Proof733
  · exact adaptive147Third144Proof734
  · exact adaptive147Third144Proof735
  · exact adaptive147Third144Proof736
  · exact adaptive147Third144Proof737
  · exact adaptive147Third144Proof738
  · exact adaptive147Third144Proof739
  · exact adaptive147Third144Proof740
  · exact adaptive147Third144Proof741
  · exact adaptive147Third144Proof742
  · exact adaptive147Third144Proof743
  · exact adaptive147Third144Proof744
  · exact adaptive147Third144Proof745
  · exact adaptive147Third144Proof746
  · exact adaptive147Third144Proof791

#print axioms adaptive147Third144Proof708

theorem adaptive147Third144Proof0 : runCachedNode 511 131483 Adaptive147Third144Node0 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 131483 Adaptive147Third144Node0 = [109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 132, 133, 134, 135, 136, 137, 138, 139, 140, 141, 142] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive147Third144Proof1
  · exact adaptive147Third144Proof2
  · exact adaptive147Third144Proof3
  · exact adaptive147Third144Proof4
  · exact adaptive147Third144Proof5
  · exact adaptive147Third144Proof6
  · exact adaptive147Third144Proof7
  · exact adaptive147Third144Proof8
  · exact adaptive147Third144Proof9
  · exact adaptive147Third144Proof10
  · exact adaptive147Third144Proof11
  · exact adaptive147Third144Proof12
  · exact adaptive147Third144Proof13
  · exact adaptive147Third144Proof14
  · exact adaptive147Third144Proof15
  · exact adaptive147Third144Proof16
  · exact adaptive147Third144Proof17
  · exact adaptive147Third144Proof18
  · exact adaptive147Third144Proof19
  · exact adaptive147Third144Proof20
  · exact adaptive147Third144Proof21
  · exact adaptive147Third144Proof22
  · exact adaptive147Third144Proof23
  · exact adaptive147Third144Proof49
  · exact adaptive147Third144Proof77
  · exact adaptive147Third144Proof106
  · exact adaptive147Third144Proof136
  · exact adaptive147Third144Proof168
  · exact adaptive147Third144Proof201
  · exact adaptive147Third144Proof235
  · exact adaptive147Third144Proof270
  · exact adaptive147Third144Proof307
  · exact adaptive147Third144Proof501
  · exact adaptive147Third144Proof708

#print axioms adaptive147Third144Proof0

end NineSeparatedSubsetSums
