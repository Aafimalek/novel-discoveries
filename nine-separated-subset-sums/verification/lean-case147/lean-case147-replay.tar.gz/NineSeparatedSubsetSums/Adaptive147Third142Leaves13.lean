import NineSeparatedSubsetSums.Adaptive147Third142State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third142Proof240 : runCachedNode 511 131213 Adaptive147Third142Node240 = false := by
  decide +kernel

#print axioms adaptive147Third142Proof240

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third142Proof201 : runCachedNode 511 131213 Adaptive147Third142Node201 = false := by
  decide +kernel

#print axioms adaptive147Third142Proof201

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third142Proof58 : runCachedNode 511 131213 Adaptive147Third142Node58 = false := by
  decide +kernel

#print axioms adaptive147Third142Proof58

end NineSeparatedSubsetSums
