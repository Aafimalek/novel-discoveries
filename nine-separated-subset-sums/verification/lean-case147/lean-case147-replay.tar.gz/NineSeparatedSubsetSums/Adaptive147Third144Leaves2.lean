import NineSeparatedSubsetSums.Adaptive147Third144State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof745 : runCachedNode 511 131483 Adaptive147Third144Node745 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof745

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof70 : runCachedNode 511 131483 Adaptive147Third144Node70 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof70

end NineSeparatedSubsetSums
