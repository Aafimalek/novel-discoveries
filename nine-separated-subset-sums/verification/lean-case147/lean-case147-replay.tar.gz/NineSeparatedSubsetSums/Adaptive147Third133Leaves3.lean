import NineSeparatedSubsetSums.Adaptive147Third133State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third133Proof16 : runCachedNode 511 129861 Adaptive147Third133Node16 = false := by
  decide +kernel

#print axioms adaptive147Third133Proof16

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third133Proof46 : runCachedNode 511 129861 Adaptive147Third133Node46 = false := by
  decide +kernel

#print axioms adaptive147Third133Proof46

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third133Proof14 : runCachedNode 511 129861 Adaptive147Third133Node14 = false := by
  decide +kernel

#print axioms adaptive147Third133Proof14

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third133Proof45 : runCachedNode 511 129861 Adaptive147Third133Node45 = false := by
  decide +kernel

#print axioms adaptive147Third133Proof45

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third133Proof9 : runCachedNode 511 129861 Adaptive147Third133Node9 = false := by
  decide +kernel

#print axioms adaptive147Third133Proof9

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third133Proof27 : runCachedNode 511 129861 Adaptive147Third133Node27 = false := by
  decide +kernel

#print axioms adaptive147Third133Proof27

end NineSeparatedSubsetSums
