import NineSeparatedSubsetSums.Adaptive147Third143State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third143Proof264 : runCachedNode 511 131344 Adaptive147Third143Node264 = false := by
  decide +kernel

#print axioms adaptive147Third143Proof264

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third143Proof18 : runCachedNode 511 131344 Adaptive147Third143Node18 = false := by
  decide +kernel

#print axioms adaptive147Third143Proof18

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third143Proof24 : runCachedNode 511 131344 Adaptive147Third143Node24 = false := by
  decide +kernel

#print axioms adaptive147Third143Proof24

end NineSeparatedSubsetSums
