import NineSeparatedSubsetSums.Adaptive147Third143State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third143Proof545 : runCachedNode 511 131344 Adaptive147Third143Node545 = false := by
  decide +kernel

#print axioms adaptive147Third143Proof545

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third143Proof298 : runCachedNode 511 131344 Adaptive147Third143Node298 = false := by
  decide +kernel

#print axioms adaptive147Third143Proof298

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third143Proof401 : runCachedNode 511 131344 Adaptive147Third143Node401 = false := by
  decide +kernel

#print axioms adaptive147Third143Proof401

end NineSeparatedSubsetSums
