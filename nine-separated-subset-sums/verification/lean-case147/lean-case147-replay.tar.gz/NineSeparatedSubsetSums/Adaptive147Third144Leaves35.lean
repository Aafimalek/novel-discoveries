import NineSeparatedSubsetSums.Adaptive147Third144State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof300 : runCachedNode 511 131483 Adaptive147Third144Node300 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof300

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof414 : runCachedNode 511 131483 Adaptive147Third144Node414 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof414

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof499 : runCachedNode 511 131483 Adaptive147Third144Node499 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof499

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof162 : runCachedNode 511 131483 Adaptive147Third144Node162 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof162

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof299 : runCachedNode 511 131483 Adaptive147Third144Node299 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof299

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof8 : runCachedNode 511 131483 Adaptive147Third144Node8 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof8

end NineSeparatedSubsetSums
