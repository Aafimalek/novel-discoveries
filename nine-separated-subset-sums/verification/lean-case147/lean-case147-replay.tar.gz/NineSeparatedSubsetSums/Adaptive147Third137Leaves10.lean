import NineSeparatedSubsetSums.Adaptive147Third137State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third137Proof69 : runCachedNode 511 130518 Adaptive147Third137Node69 = false := by
  decide +kernel

#print axioms adaptive147Third137Proof69

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third137Proof68 : runCachedNode 511 130518 Adaptive147Third137Node68 = false := by
  decide +kernel

#print axioms adaptive147Third137Proof68

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third137Proof119 : runCachedNode 511 130518 Adaptive147Third137Node119 = false := by
  decide +kernel

#print axioms adaptive147Third137Proof119

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third137Proof175 : runCachedNode 511 130518 Adaptive147Third137Node175 = false := by
  decide +kernel

#print axioms adaptive147Third137Proof175

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third137Proof12 : runCachedNode 511 130518 Adaptive147Third137Node12 = false := by
  decide +kernel

#print axioms adaptive147Third137Proof12

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third137Proof149 : runCachedNode 511 130518 Adaptive147Third137Node149 = false := by
  decide +kernel

#print axioms adaptive147Third137Proof149

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third137Proof179 : runCachedNode 511 130518 Adaptive147Third137Node179 = false := by
  decide +kernel

#print axioms adaptive147Third137Proof179

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third137Proof113 : runCachedNode 511 130518 Adaptive147Third137Node113 = false := by
  decide +kernel

#print axioms adaptive147Third137Proof113

end NineSeparatedSubsetSums
