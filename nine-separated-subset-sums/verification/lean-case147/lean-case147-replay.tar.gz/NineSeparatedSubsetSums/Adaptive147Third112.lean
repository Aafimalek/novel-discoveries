import NineSeparatedSubsetSums.Adaptive147Third112Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint147Checked

namespace NineSeparatedSubsetSums


theorem adaptive147Third112 : NoDescendingTailAfterThird 147 112 :=
  noDescendingThirdTail_of_cached 147 112 112835 (fun t ht nd => max148_second147_fourPoint_moment_bound (112::t) (by simp [ht]) nd) adaptive147Third112Proof0

#print axioms adaptive147Third112

end NineSeparatedSubsetSums
