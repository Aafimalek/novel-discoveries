import NineSeparatedSubsetSums.Adaptive147Third127State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third127Proof11 : runCachedNode 511 128514 Adaptive147Third127Node11 = false := by
  decide +kernel

#print axioms adaptive147Third127Proof11

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third127Proof10 : runCachedNode 511 128514 Adaptive147Third127Node10 = false := by
  decide +kernel

#print axioms adaptive147Third127Proof10

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third127Proof9 : runCachedNode 511 128514 Adaptive147Third127Node9 = false := by
  decide +kernel

#print axioms adaptive147Third127Proof9

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third127Proof7 : runCachedNode 511 128514 Adaptive147Third127Node7 = false := by
  decide +kernel

#print axioms adaptive147Third127Proof7

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third127Proof6 : runCachedNode 511 128514 Adaptive147Third127Node6 = false := by
  decide +kernel

#print axioms adaptive147Third127Proof6

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third127Proof5 : runCachedNode 511 128514 Adaptive147Third127Node5 = false := by
  decide +kernel

#print axioms adaptive147Third127Proof5

end NineSeparatedSubsetSums
