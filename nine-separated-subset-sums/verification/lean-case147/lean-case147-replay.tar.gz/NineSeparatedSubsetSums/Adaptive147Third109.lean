import NineSeparatedSubsetSums.Adaptive147Third109Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint147Checked

namespace NineSeparatedSubsetSums


theorem adaptive147Third109 : NoDescendingTailAfterThird 147 109 :=
  noDescendingThirdTail_of_cached 147 109 112835 (fun t ht nd => max148_second147_fourPoint_moment_bound (109::t) (by simp [ht]) nd) adaptive147Third109Proof0

#print axioms adaptive147Third109

end NineSeparatedSubsetSums
