import NineSeparatedSubsetSums.Adaptive147Third139State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third139Proof93 : runCachedNode 511 130807 Adaptive147Third139Node93 = false := by
  decide +kernel

#print axioms adaptive147Third139Proof93

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third139Proof212 : runCachedNode 511 130807 Adaptive147Third139Node212 = false := by
  decide +kernel

#print axioms adaptive147Third139Proof212

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third139Proof14 : runCachedNode 511 130807 Adaptive147Third139Node14 = false := by
  decide +kernel

#print axioms adaptive147Third139Proof14

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third139Proof68 : runCachedNode 511 130807 Adaptive147Third139Node68 = false := by
  decide +kernel

#print axioms adaptive147Third139Proof68

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third139Proof211 : runCachedNode 511 130807 Adaptive147Third139Node211 = false := by
  decide +kernel

#print axioms adaptive147Third139Proof211

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third139Proof95 : runCachedNode 511 130807 Adaptive147Third139Node95 = false := by
  decide +kernel

#print axioms adaptive147Third139Proof95

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third139Proof239 : runCachedNode 511 130807 Adaptive147Third139Node239 = false := by
  decide +kernel

#print axioms adaptive147Third139Proof239

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third139Proof23 : runCachedNode 511 130807 Adaptive147Third139Node23 = false := by
  decide +kernel

#print axioms adaptive147Third139Proof23

end NineSeparatedSubsetSums
