import NineSeparatedSubsetSums.Adaptive147Third144State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof530 : runCachedNode 511 131483 Adaptive147Third144Node530 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof530

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof529 : runCachedNode 511 131483 Adaptive147Third144Node529 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof529

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof738 : runCachedNode 511 131483 Adaptive147Third144Node738 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof738

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof261 : runCachedNode 511 131483 Adaptive147Third144Node261 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof261

end NineSeparatedSubsetSums
