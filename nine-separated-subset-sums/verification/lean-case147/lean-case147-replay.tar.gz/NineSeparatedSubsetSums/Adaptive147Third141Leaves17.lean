import NineSeparatedSubsetSums.Adaptive147Third141State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third141Proof334 : runCachedNode 511 131086 Adaptive147Third141Node334 = false := by
  decide +kernel

#print axioms adaptive147Third141Proof334

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third141Proof17 : runCachedNode 511 131086 Adaptive147Third141Node17 = false := by
  decide +kernel

#print axioms adaptive147Third141Proof17

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third141Proof128 : runCachedNode 511 131086 Adaptive147Third141Node128 = false := by
  decide +kernel

#print axioms adaptive147Third141Proof128

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third141Proof50 : runCachedNode 511 131086 Adaptive147Third141Node50 = false := by
  decide +kernel

#print axioms adaptive147Third141Proof50

end NineSeparatedSubsetSums
