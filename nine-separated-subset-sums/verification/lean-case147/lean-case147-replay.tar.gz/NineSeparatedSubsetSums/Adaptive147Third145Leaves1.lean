import NineSeparatedSubsetSums.Adaptive147Third145State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third145Proof571 : runCachedNode 511 131618 Adaptive147Third145Node571 = false := by
  decide +kernel

#print axioms adaptive147Third145Proof571

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third145Proof8 : runCachedNode 511 131618 Adaptive147Third145Node8 = false := by
  decide +kernel

#print axioms adaptive147Third145Proof8

end NineSeparatedSubsetSums
