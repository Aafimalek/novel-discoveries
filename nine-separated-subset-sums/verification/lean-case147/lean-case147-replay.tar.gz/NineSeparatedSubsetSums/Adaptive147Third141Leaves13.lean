import NineSeparatedSubsetSums.Adaptive147Third141State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third141Proof20 : runCachedNode 511 131086 Adaptive147Third141Node20 = false := by
  decide +kernel

#print axioms adaptive147Third141Proof20

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third141Proof19 : runCachedNode 511 131086 Adaptive147Third141Node19 = false := by
  decide +kernel

#print axioms adaptive147Third141Proof19

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third141Proof79 : runCachedNode 511 131086 Adaptive147Third141Node79 = false := by
  decide +kernel

#print axioms adaptive147Third141Proof79

end NineSeparatedSubsetSums
