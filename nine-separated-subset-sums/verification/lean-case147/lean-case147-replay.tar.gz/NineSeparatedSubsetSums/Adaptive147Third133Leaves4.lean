import NineSeparatedSubsetSums.Adaptive147Third133State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third133Proof13 : runCachedNode 511 129861 Adaptive147Third133Node13 = false := by
  decide +kernel

#print axioms adaptive147Third133Proof13

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third133Proof44 : runCachedNode 511 129861 Adaptive147Third133Node44 = false := by
  decide +kernel

#print axioms adaptive147Third133Proof44

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third133Proof11 : runCachedNode 511 129861 Adaptive147Third133Node11 = false := by
  decide +kernel

#print axioms adaptive147Third133Proof11

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third133Proof10 : runCachedNode 511 129861 Adaptive147Third133Node10 = false := by
  decide +kernel

#print axioms adaptive147Third133Proof10

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third133Proof41 : runCachedNode 511 129861 Adaptive147Third133Node41 = false := by
  decide +kernel

#print axioms adaptive147Third133Proof41

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third133Proof42 : runCachedNode 511 129861 Adaptive147Third133Node42 = false := by
  decide +kernel

#print axioms adaptive147Third133Proof42

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third133Proof43 : runCachedNode 511 129861 Adaptive147Third133Node43 = false := by
  decide +kernel

#print axioms adaptive147Third133Proof43

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third133Proof40 : runCachedNode 511 129861 Adaptive147Third133Node40 = false := by
  decide +kernel

#print axioms adaptive147Third133Proof40

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third133Proof8 : runCachedNode 511 129861 Adaptive147Third133Node8 = false := by
  decide +kernel

#print axioms adaptive147Third133Proof8

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third133Proof36 : runCachedNode 511 129861 Adaptive147Third133Node36 = false := by
  decide +kernel

#print axioms adaptive147Third133Proof36

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third133Proof35 : runCachedNode 511 129861 Adaptive147Third133Node35 = false := by
  decide +kernel

#print axioms adaptive147Third133Proof35

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third133Proof38 : runCachedNode 511 129861 Adaptive147Third133Node38 = false := by
  decide +kernel

#print axioms adaptive147Third133Proof38

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third133Proof26 : runCachedNode 511 129861 Adaptive147Third133Node26 = false := by
  decide +kernel

#print axioms adaptive147Third133Proof26

end NineSeparatedSubsetSums
