import NineSeparatedSubsetSums.Adaptive147Third138State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third138Proof207 : runCachedNode 511 130657 Adaptive147Third138Node207 = false := by
  decide +kernel

#print axioms adaptive147Third138Proof207

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third138Proof146 : runCachedNode 511 130657 Adaptive147Third138Node146 = false := by
  decide +kernel

#print axioms adaptive147Third138Proof146

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third138Proof42 : runCachedNode 511 130657 Adaptive147Third138Node42 = false := by
  decide +kernel

#print axioms adaptive147Third138Proof42

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third138Proof91 : runCachedNode 511 130657 Adaptive147Third138Node91 = false := by
  decide +kernel

#print axioms adaptive147Third138Proof91

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third138Proof51 : runCachedNode 511 130657 Adaptive147Third138Node51 = false := by
  decide +kernel

#print axioms adaptive147Third138Proof51

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third138Proof94 : runCachedNode 511 130657 Adaptive147Third138Node94 = false := by
  decide +kernel

#print axioms adaptive147Third138Proof94

end NineSeparatedSubsetSums
