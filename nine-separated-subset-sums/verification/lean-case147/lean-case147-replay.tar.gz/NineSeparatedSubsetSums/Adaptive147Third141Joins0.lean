import NineSeparatedSubsetSums.Adaptive147Third141State
import NineSeparatedSubsetSums.Adaptive147Third141Leaves12
import NineSeparatedSubsetSums.Adaptive147Third141Leaves1
import NineSeparatedSubsetSums.Adaptive147Third141Leaves33
import NineSeparatedSubsetSums.Adaptive147Third141Leaves4
import NineSeparatedSubsetSums.Adaptive147Third141Leaves32
import NineSeparatedSubsetSums.Adaptive147Third141Leaves11
import NineSeparatedSubsetSums.Adaptive147Third141Leaves31
import NineSeparatedSubsetSums.Adaptive147Third141Leaves28
import NineSeparatedSubsetSums.Adaptive147Third141Leaves30
import NineSeparatedSubsetSums.Adaptive147Third141Leaves27
import NineSeparatedSubsetSums.Adaptive147Third141Leaves26
import NineSeparatedSubsetSums.Adaptive147Third141Leaves25
import NineSeparatedSubsetSums.Adaptive147Third141Leaves17
import NineSeparatedSubsetSums.Adaptive147Third141Leaves34
import NineSeparatedSubsetSums.Adaptive147Third141Leaves10
import NineSeparatedSubsetSums.Adaptive147Third141Leaves29
import NineSeparatedSubsetSums.Adaptive147Third141Leaves24
import NineSeparatedSubsetSums.Adaptive147Third141Leaves23
import NineSeparatedSubsetSums.Adaptive147Third141Leaves19
import NineSeparatedSubsetSums.Adaptive147Third141Leaves13
import NineSeparatedSubsetSums.Adaptive147Third141Leaves14
import NineSeparatedSubsetSums.Adaptive147Third141Leaves15
import NineSeparatedSubsetSums.Adaptive147Third141Leaves0
import NineSeparatedSubsetSums.Adaptive147Third141Leaves3
import NineSeparatedSubsetSums.Adaptive147Third141Leaves5
import NineSeparatedSubsetSums.Adaptive147Third141Leaves6
import NineSeparatedSubsetSums.Adaptive147Third141Leaves21
import NineSeparatedSubsetSums.Adaptive147Third141Leaves18
import NineSeparatedSubsetSums.Adaptive147Third141Leaves16
import NineSeparatedSubsetSums.Adaptive147Third141Leaves2
import NineSeparatedSubsetSums.Adaptive147Third141Leaves20
import NineSeparatedSubsetSums.Adaptive147Third141Leaves8
import NineSeparatedSubsetSums.Adaptive147Third141Leaves9
import NineSeparatedSubsetSums.Adaptive147Third141Leaves22
import NineSeparatedSubsetSums.Adaptive147Third141Leaves35

namespace NineSeparatedSubsetSums

theorem adaptive147Third141Proof23 : runCachedNode 511 131086 Adaptive147Third141Node23 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 131086 Adaptive147Third141Node23 = [103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 126, 127, 128, 129] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive147Third141Proof24
  · exact adaptive147Third141Proof25
  · exact adaptive147Third141Proof26
  · exact adaptive147Third141Proof27
  · exact adaptive147Third141Proof28
  · exact adaptive147Third141Proof29
  · exact adaptive147Third141Proof30
  · exact adaptive147Third141Proof31
  · exact adaptive147Third141Proof32
  · exact adaptive147Third141Proof33
  · exact adaptive147Third141Proof34
  · exact adaptive147Third141Proof35
  · exact adaptive147Third141Proof36
  · exact adaptive147Third141Proof37
  · exact adaptive147Third141Proof38
  · exact adaptive147Third141Proof39
  · exact adaptive147Third141Proof40
  · exact adaptive147Third141Proof41
  · exact adaptive147Third141Proof42
  · exact adaptive147Third141Proof43
  · exact adaptive147Third141Proof44
  · exact adaptive147Third141Proof45
  · exact adaptive147Third141Proof46
  · exact adaptive147Third141Proof47
  · exact adaptive147Third141Proof48

#print axioms adaptive147Third141Proof23

theorem adaptive147Third141Proof49 : runCachedNode 511 131086 Adaptive147Third141Node49 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 131086 Adaptive147Third141Node49 = [103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 127, 128, 129, 130] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive147Third141Proof50
  · exact adaptive147Third141Proof51
  · exact adaptive147Third141Proof52
  · exact adaptive147Third141Proof53
  · exact adaptive147Third141Proof54
  · exact adaptive147Third141Proof55
  · exact adaptive147Third141Proof56
  · exact adaptive147Third141Proof57
  · exact adaptive147Third141Proof58
  · exact adaptive147Third141Proof59
  · exact adaptive147Third141Proof60
  · exact adaptive147Third141Proof61
  · exact adaptive147Third141Proof62
  · exact adaptive147Third141Proof63
  · exact adaptive147Third141Proof64
  · exact adaptive147Third141Proof65
  · exact adaptive147Third141Proof66
  · exact adaptive147Third141Proof67
  · exact adaptive147Third141Proof68
  · exact adaptive147Third141Proof69
  · exact adaptive147Third141Proof70
  · exact adaptive147Third141Proof71
  · exact adaptive147Third141Proof72
  · exact adaptive147Third141Proof73
  · exact adaptive147Third141Proof74
  · exact adaptive147Third141Proof75

#print axioms adaptive147Third141Proof49

theorem adaptive147Third141Proof76 : runCachedNode 511 131086 Adaptive147Third141Node76 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 131086 Adaptive147Third141Node76 = [102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 128, 129, 130, 131] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive147Third141Proof77
  · exact adaptive147Third141Proof78
  · exact adaptive147Third141Proof79
  · exact adaptive147Third141Proof80
  · exact adaptive147Third141Proof81
  · exact adaptive147Third141Proof82
  · exact adaptive147Third141Proof83
  · exact adaptive147Third141Proof84
  · exact adaptive147Third141Proof85
  · exact adaptive147Third141Proof86
  · exact adaptive147Third141Proof87
  · exact adaptive147Third141Proof88
  · exact adaptive147Third141Proof89
  · exact adaptive147Third141Proof90
  · exact adaptive147Third141Proof91
  · exact adaptive147Third141Proof92
  · exact adaptive147Third141Proof93
  · exact adaptive147Third141Proof94
  · exact adaptive147Third141Proof95
  · exact adaptive147Third141Proof96
  · exact adaptive147Third141Proof97
  · exact adaptive147Third141Proof98
  · exact adaptive147Third141Proof99
  · exact adaptive147Third141Proof100
  · exact adaptive147Third141Proof101
  · exact adaptive147Third141Proof102
  · exact adaptive147Third141Proof103
  · exact adaptive147Third141Proof104

#print axioms adaptive147Third141Proof76

theorem adaptive147Third141Proof105 : runCachedNode 511 131086 Adaptive147Third141Node105 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 131086 Adaptive147Third141Node105 = [102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 129, 130, 131, 132] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive147Third141Proof106
  · exact adaptive147Third141Proof107
  · exact adaptive147Third141Proof108
  · exact adaptive147Third141Proof109
  · exact adaptive147Third141Proof110
  · exact adaptive147Third141Proof111
  · exact adaptive147Third141Proof112
  · exact adaptive147Third141Proof113
  · exact adaptive147Third141Proof114
  · exact adaptive147Third141Proof115
  · exact adaptive147Third141Proof116
  · exact adaptive147Third141Proof117
  · exact adaptive147Third141Proof118
  · exact adaptive147Third141Proof119
  · exact adaptive147Third141Proof120
  · exact adaptive147Third141Proof121
  · exact adaptive147Third141Proof122
  · exact adaptive147Third141Proof123
  · exact adaptive147Third141Proof124
  · exact adaptive147Third141Proof125
  · exact adaptive147Third141Proof126
  · exact adaptive147Third141Proof127
  · exact adaptive147Third141Proof128
  · exact adaptive147Third141Proof129
  · exact adaptive147Third141Proof130
  · exact adaptive147Third141Proof131
  · exact adaptive147Third141Proof132
  · exact adaptive147Third141Proof133
  · exact adaptive147Third141Proof134

#print axioms adaptive147Third141Proof105

theorem adaptive147Third141Proof135 : runCachedNode 511 131086 Adaptive147Third141Node135 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 131086 Adaptive147Third141Node135 = [102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 130, 131, 132, 133] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive147Third141Proof136
  · exact adaptive147Third141Proof137
  · exact adaptive147Third141Proof138
  · exact adaptive147Third141Proof139
  · exact adaptive147Third141Proof140
  · exact adaptive147Third141Proof141
  · exact adaptive147Third141Proof142
  · exact adaptive147Third141Proof143
  · exact adaptive147Third141Proof144
  · exact adaptive147Third141Proof145
  · exact adaptive147Third141Proof146
  · exact adaptive147Third141Proof147
  · exact adaptive147Third141Proof148
  · exact adaptive147Third141Proof149
  · exact adaptive147Third141Proof150
  · exact adaptive147Third141Proof151
  · exact adaptive147Third141Proof152
  · exact adaptive147Third141Proof153
  · exact adaptive147Third141Proof154
  · exact adaptive147Third141Proof155
  · exact adaptive147Third141Proof156
  · exact adaptive147Third141Proof157
  · exact adaptive147Third141Proof158
  · exact adaptive147Third141Proof159
  · exact adaptive147Third141Proof160
  · exact adaptive147Third141Proof161
  · exact adaptive147Third141Proof162
  · exact adaptive147Third141Proof163
  · exact adaptive147Third141Proof164
  · exact adaptive147Third141Proof165

#print axioms adaptive147Third141Proof135

theorem adaptive147Third141Proof166 : runCachedNode 511 131086 Adaptive147Third141Node166 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 131086 Adaptive147Third141Node166 = [102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 131, 132, 133, 134] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive147Third141Proof167
  · exact adaptive147Third141Proof168
  · exact adaptive147Third141Proof169
  · exact adaptive147Third141Proof170
  · exact adaptive147Third141Proof171
  · exact adaptive147Third141Proof172
  · exact adaptive147Third141Proof173
  · exact adaptive147Third141Proof174
  · exact adaptive147Third141Proof175
  · exact adaptive147Third141Proof176
  · exact adaptive147Third141Proof177
  · exact adaptive147Third141Proof178
  · exact adaptive147Third141Proof179
  · exact adaptive147Third141Proof180
  · exact adaptive147Third141Proof181
  · exact adaptive147Third141Proof182
  · exact adaptive147Third141Proof183
  · exact adaptive147Third141Proof184
  · exact adaptive147Third141Proof185
  · exact adaptive147Third141Proof186
  · exact adaptive147Third141Proof187
  · exact adaptive147Third141Proof188
  · exact adaptive147Third141Proof189
  · exact adaptive147Third141Proof190
  · exact adaptive147Third141Proof191
  · exact adaptive147Third141Proof192
  · exact adaptive147Third141Proof193
  · exact adaptive147Third141Proof194
  · exact adaptive147Third141Proof195
  · exact adaptive147Third141Proof196
  · exact adaptive147Third141Proof197

#print axioms adaptive147Third141Proof166

theorem adaptive147Third141Proof198 : runCachedNode 511 131086 Adaptive147Third141Node198 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 131086 Adaptive147Third141Node198 = [101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 132, 133, 134, 135] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive147Third141Proof199
  · exact adaptive147Third141Proof200
  · exact adaptive147Third141Proof201
  · exact adaptive147Third141Proof202
  · exact adaptive147Third141Proof203
  · exact adaptive147Third141Proof204
  · exact adaptive147Third141Proof205
  · exact adaptive147Third141Proof206
  · exact adaptive147Third141Proof207
  · exact adaptive147Third141Proof208
  · exact adaptive147Third141Proof209
  · exact adaptive147Third141Proof210
  · exact adaptive147Third141Proof211
  · exact adaptive147Third141Proof212
  · exact adaptive147Third141Proof213
  · exact adaptive147Third141Proof214
  · exact adaptive147Third141Proof215
  · exact adaptive147Third141Proof216
  · exact adaptive147Third141Proof217
  · exact adaptive147Third141Proof218
  · exact adaptive147Third141Proof219
  · exact adaptive147Third141Proof220
  · exact adaptive147Third141Proof221
  · exact adaptive147Third141Proof222
  · exact adaptive147Third141Proof223
  · exact adaptive147Third141Proof224
  · exact adaptive147Third141Proof225
  · exact adaptive147Third141Proof226
  · exact adaptive147Third141Proof227
  · exact adaptive147Third141Proof228
  · exact adaptive147Third141Proof229
  · exact adaptive147Third141Proof230
  · exact adaptive147Third141Proof231

#print axioms adaptive147Third141Proof198

theorem adaptive147Third141Proof265 : runCachedNode 511 131086 Adaptive147Third141Node265 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 131086 Adaptive147Third141Node265 = [89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 120, 121, 122, 123, 124, 127, 130] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive147Third141Proof266
  · exact adaptive147Third141Proof267
  · exact adaptive147Third141Proof268
  · exact adaptive147Third141Proof269
  · exact adaptive147Third141Proof270
  · exact adaptive147Third141Proof271
  · exact adaptive147Third141Proof272
  · exact adaptive147Third141Proof273
  · exact adaptive147Third141Proof274
  · exact adaptive147Third141Proof275
  · exact adaptive147Third141Proof276
  · exact adaptive147Third141Proof277
  · exact adaptive147Third141Proof278
  · exact adaptive147Third141Proof279
  · exact adaptive147Third141Proof280
  · exact adaptive147Third141Proof281
  · exact adaptive147Third141Proof282
  · exact adaptive147Third141Proof283
  · exact adaptive147Third141Proof284
  · exact adaptive147Third141Proof285
  · exact adaptive147Third141Proof286
  · exact adaptive147Third141Proof287
  · exact adaptive147Third141Proof288
  · exact adaptive147Third141Proof289
  · exact adaptive147Third141Proof290
  · exact adaptive147Third141Proof291
  · exact adaptive147Third141Proof292
  · exact adaptive147Third141Proof293
  · exact adaptive147Third141Proof294
  · exact adaptive147Third141Proof295
  · exact adaptive147Third141Proof296
  · exact adaptive147Third141Proof297
  · exact adaptive147Third141Proof298
  · exact adaptive147Third141Proof299
  · exact adaptive147Third141Proof300
  · exact adaptive147Third141Proof301
  · exact adaptive147Third141Proof302

#print axioms adaptive147Third141Proof265

end NineSeparatedSubsetSums
