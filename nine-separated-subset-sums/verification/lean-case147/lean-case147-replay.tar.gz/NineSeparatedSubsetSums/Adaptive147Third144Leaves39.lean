import NineSeparatedSubsetSums.Adaptive147Third144State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof498 : runCachedNode 511 131483 Adaptive147Third144Node498 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof498

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof833 : runCachedNode 511 131483 Adaptive147Third144Node833 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof833

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof525 : runCachedNode 511 131483 Adaptive147Third144Node525 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof525

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof330 : runCachedNode 511 131483 Adaptive147Third144Node330 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof330

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof229 : runCachedNode 511 131483 Adaptive147Third144Node229 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof229

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof75 : runCachedNode 511 131483 Adaptive147Third144Node75 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof75

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof454 : runCachedNode 511 131483 Adaptive147Third144Node454 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof454

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof169 : runCachedNode 511 131483 Adaptive147Third144Node169 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof169

end NineSeparatedSubsetSums
