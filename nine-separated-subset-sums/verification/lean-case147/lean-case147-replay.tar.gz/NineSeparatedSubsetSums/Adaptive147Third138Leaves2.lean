import NineSeparatedSubsetSums.Adaptive147Third138State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third138Proof18 : runCachedNode 511 130657 Adaptive147Third138Node18 = false := by
  decide +kernel

#print axioms adaptive147Third138Proof18

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third138Proof238 : runCachedNode 511 130657 Adaptive147Third138Node238 = false := by
  decide +kernel

#print axioms adaptive147Third138Proof238

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third138Proof35 : runCachedNode 511 130657 Adaptive147Third138Node35 = false := by
  decide +kernel

#print axioms adaptive147Third138Proof35

end NineSeparatedSubsetSums
