import NineSeparatedSubsetSums.Adaptive147Third142State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third142Proof382 : runCachedNode 511 131213 Adaptive147Third142Node382 = false := by
  decide +kernel

#print axioms adaptive147Third142Proof382

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third142Proof351 : runCachedNode 511 131213 Adaptive147Third142Node351 = false := by
  decide +kernel

#print axioms adaptive147Third142Proof351

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third142Proof161 : runCachedNode 511 131213 Adaptive147Third142Node161 = false := by
  decide +kernel

#print axioms adaptive147Third142Proof161

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third142Proof159 : runCachedNode 511 131213 Adaptive147Third142Node159 = false := by
  decide +kernel

#print axioms adaptive147Third142Proof159

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third142Proof474 : runCachedNode 511 131213 Adaptive147Third142Node474 = false := by
  decide +kernel

#print axioms adaptive147Third142Proof474

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third142Proof379 : runCachedNode 511 131213 Adaptive147Third142Node379 = false := by
  decide +kernel

#print axioms adaptive147Third142Proof379

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third142Proof44 : runCachedNode 511 131213 Adaptive147Third142Node44 = false := by
  decide +kernel

#print axioms adaptive147Third142Proof44

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third142Proof381 : runCachedNode 511 131213 Adaptive147Third142Node381 = false := by
  decide +kernel

#print axioms adaptive147Third142Proof381

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third142Proof229 : runCachedNode 511 131213 Adaptive147Third142Node229 = false := by
  decide +kernel

#print axioms adaptive147Third142Proof229

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third142Proof99 : runCachedNode 511 131213 Adaptive147Third142Node99 = false := by
  decide +kernel

#print axioms adaptive147Third142Proof99

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third142Proof25 : runCachedNode 511 131213 Adaptive147Third142Node25 = false := by
  decide +kernel

#print axioms adaptive147Third142Proof25

end NineSeparatedSubsetSums
