import NineSeparatedSubsetSums.Adaptive147Third139State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third139Proof249 : runCachedNode 511 130807 Adaptive147Third139Node249 = false := by
  decide +kernel

#print axioms adaptive147Third139Proof249

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third139Proof45 : runCachedNode 511 130807 Adaptive147Third139Node45 = false := by
  decide +kernel

#print axioms adaptive147Third139Proof45

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third139Proof213 : runCachedNode 511 130807 Adaptive147Third139Node213 = false := by
  decide +kernel

#print axioms adaptive147Third139Proof213

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third139Proof97 : runCachedNode 511 130807 Adaptive147Third139Node97 = false := by
  decide +kernel

#print axioms adaptive147Third139Proof97

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third139Proof177 : runCachedNode 511 130807 Adaptive147Third139Node177 = false := by
  decide +kernel

#print axioms adaptive147Third139Proof177

end NineSeparatedSubsetSums
