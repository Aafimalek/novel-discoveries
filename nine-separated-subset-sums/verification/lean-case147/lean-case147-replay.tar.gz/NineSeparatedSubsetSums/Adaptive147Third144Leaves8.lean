import NineSeparatedSubsetSums.Adaptive147Third144State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof533 : runCachedNode 511 131483 Adaptive147Third144Node533 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof533

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof200 : runCachedNode 511 131483 Adaptive147Third144Node200 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof200

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof5 : runCachedNode 511 131483 Adaptive147Third144Node5 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof5

end NineSeparatedSubsetSums
