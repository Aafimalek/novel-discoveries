import NineSeparatedSubsetSums.Adaptive147Third137State
import NineSeparatedSubsetSums.Adaptive147Third137Leaves2
import NineSeparatedSubsetSums.Adaptive147Third137Leaves14
import NineSeparatedSubsetSums.Adaptive147Third137Leaves6
import NineSeparatedSubsetSums.Adaptive147Third137Leaves13
import NineSeparatedSubsetSums.Adaptive147Third137Leaves8
import NineSeparatedSubsetSums.Adaptive147Third137Leaves12
import NineSeparatedSubsetSums.Adaptive147Third137Leaves11
import NineSeparatedSubsetSums.Adaptive147Third137Leaves9
import NineSeparatedSubsetSums.Adaptive147Third137Leaves7
import NineSeparatedSubsetSums.Adaptive147Third137Leaves15
import NineSeparatedSubsetSums.Adaptive147Third137Leaves10
import NineSeparatedSubsetSums.Adaptive147Third137Leaves4
import NineSeparatedSubsetSums.Adaptive147Third137Leaves5
import NineSeparatedSubsetSums.Adaptive147Third137Leaves0
import NineSeparatedSubsetSums.Adaptive147Third137Leaves1
import NineSeparatedSubsetSums.Adaptive147Third137Leaves3

namespace NineSeparatedSubsetSums

theorem adaptive147Third137Proof21 : runCachedNode 511 130518 Adaptive147Third137Node21 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130518 Adaptive147Third137Node21 = [104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 121, 122, 123, 124, 125, 126, 127, 128] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive147Third137Proof22
  · exact adaptive147Third137Proof23
  · exact adaptive147Third137Proof24
  · exact adaptive147Third137Proof25
  · exact adaptive147Third137Proof26
  · exact adaptive147Third137Proof27
  · exact adaptive147Third137Proof28
  · exact adaptive147Third137Proof29
  · exact adaptive147Third137Proof30
  · exact adaptive147Third137Proof31
  · exact adaptive147Third137Proof32
  · exact adaptive147Third137Proof33
  · exact adaptive147Third137Proof34
  · exact adaptive147Third137Proof35
  · exact adaptive147Third137Proof36
  · exact adaptive147Third137Proof37
  · exact adaptive147Third137Proof38
  · exact adaptive147Third137Proof39
  · exact adaptive147Third137Proof40
  · exact adaptive147Third137Proof41
  · exact adaptive147Third137Proof42
  · exact adaptive147Third137Proof43
  · exact adaptive147Third137Proof44

#print axioms adaptive147Third137Proof21

theorem adaptive147Third137Proof45 : runCachedNode 511 130518 Adaptive147Third137Node45 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130518 Adaptive147Third137Node45 = [104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 122, 123, 124, 125, 126, 127, 128, 129] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive147Third137Proof46
  · exact adaptive147Third137Proof47
  · exact adaptive147Third137Proof48
  · exact adaptive147Third137Proof49
  · exact adaptive147Third137Proof50
  · exact adaptive147Third137Proof51
  · exact adaptive147Third137Proof52
  · exact adaptive147Third137Proof53
  · exact adaptive147Third137Proof54
  · exact adaptive147Third137Proof55
  · exact adaptive147Third137Proof56
  · exact adaptive147Third137Proof57
  · exact adaptive147Third137Proof58
  · exact adaptive147Third137Proof59
  · exact adaptive147Third137Proof60
  · exact adaptive147Third137Proof61
  · exact adaptive147Third137Proof62
  · exact adaptive147Third137Proof63
  · exact adaptive147Third137Proof64
  · exact adaptive147Third137Proof65
  · exact adaptive147Third137Proof66
  · exact adaptive147Third137Proof67
  · exact adaptive147Third137Proof68
  · exact adaptive147Third137Proof69

#print axioms adaptive147Third137Proof45

theorem adaptive147Third137Proof70 : runCachedNode 511 130518 Adaptive147Third137Node70 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130518 Adaptive147Third137Node70 = [103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 123, 124, 125, 126, 127, 128, 129, 130] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive147Third137Proof71
  · exact adaptive147Third137Proof72
  · exact adaptive147Third137Proof73
  · exact adaptive147Third137Proof74
  · exact adaptive147Third137Proof75
  · exact adaptive147Third137Proof76
  · exact adaptive147Third137Proof77
  · exact adaptive147Third137Proof78
  · exact adaptive147Third137Proof79
  · exact adaptive147Third137Proof80
  · exact adaptive147Third137Proof81
  · exact adaptive147Third137Proof82
  · exact adaptive147Third137Proof83
  · exact adaptive147Third137Proof84
  · exact adaptive147Third137Proof85
  · exact adaptive147Third137Proof86
  · exact adaptive147Third137Proof87
  · exact adaptive147Third137Proof88
  · exact adaptive147Third137Proof89
  · exact adaptive147Third137Proof90
  · exact adaptive147Third137Proof91
  · exact adaptive147Third137Proof92
  · exact adaptive147Third137Proof93
  · exact adaptive147Third137Proof94
  · exact adaptive147Third137Proof95
  · exact adaptive147Third137Proof96

#print axioms adaptive147Third137Proof70

theorem adaptive147Third137Proof97 : runCachedNode 511 130518 Adaptive147Third137Node97 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130518 Adaptive147Third137Node97 = [103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 124, 125, 126, 127, 128, 129, 130, 131] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive147Third137Proof98
  · exact adaptive147Third137Proof99
  · exact adaptive147Third137Proof100
  · exact adaptive147Third137Proof101
  · exact adaptive147Third137Proof102
  · exact adaptive147Third137Proof103
  · exact adaptive147Third137Proof104
  · exact adaptive147Third137Proof105
  · exact adaptive147Third137Proof106
  · exact adaptive147Third137Proof107
  · exact adaptive147Third137Proof108
  · exact adaptive147Third137Proof109
  · exact adaptive147Third137Proof110
  · exact adaptive147Third137Proof111
  · exact adaptive147Third137Proof112
  · exact adaptive147Third137Proof113
  · exact adaptive147Third137Proof114
  · exact adaptive147Third137Proof115
  · exact adaptive147Third137Proof116
  · exact adaptive147Third137Proof117
  · exact adaptive147Third137Proof118
  · exact adaptive147Third137Proof119
  · exact adaptive147Third137Proof120
  · exact adaptive147Third137Proof121
  · exact adaptive147Third137Proof122
  · exact adaptive147Third137Proof123
  · exact adaptive147Third137Proof124

#print axioms adaptive147Third137Proof97

theorem adaptive147Third137Proof125 : runCachedNode 511 130518 Adaptive147Third137Node125 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130518 Adaptive147Third137Node125 = [103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 125, 126, 127, 128, 129, 130, 131, 132] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive147Third137Proof126
  · exact adaptive147Third137Proof127
  · exact adaptive147Third137Proof128
  · exact adaptive147Third137Proof129
  · exact adaptive147Third137Proof130
  · exact adaptive147Third137Proof131
  · exact adaptive147Third137Proof132
  · exact adaptive147Third137Proof133
  · exact adaptive147Third137Proof134
  · exact adaptive147Third137Proof135
  · exact adaptive147Third137Proof136
  · exact adaptive147Third137Proof137
  · exact adaptive147Third137Proof138
  · exact adaptive147Third137Proof139
  · exact adaptive147Third137Proof140
  · exact adaptive147Third137Proof141
  · exact adaptive147Third137Proof142
  · exact adaptive147Third137Proof143
  · exact adaptive147Third137Proof144
  · exact adaptive147Third137Proof145
  · exact adaptive147Third137Proof146
  · exact adaptive147Third137Proof147
  · exact adaptive147Third137Proof148
  · exact adaptive147Third137Proof149
  · exact adaptive147Third137Proof150
  · exact adaptive147Third137Proof151
  · exact adaptive147Third137Proof152
  · exact adaptive147Third137Proof153

#print axioms adaptive147Third137Proof125

theorem adaptive147Third137Proof154 : runCachedNode 511 130518 Adaptive147Third137Node154 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130518 Adaptive147Third137Node154 = [103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 126, 127, 128, 129, 130, 131, 132, 133] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive147Third137Proof155
  · exact adaptive147Third137Proof156
  · exact adaptive147Third137Proof157
  · exact adaptive147Third137Proof158
  · exact adaptive147Third137Proof159
  · exact adaptive147Third137Proof160
  · exact adaptive147Third137Proof161
  · exact adaptive147Third137Proof162
  · exact adaptive147Third137Proof163
  · exact adaptive147Third137Proof164
  · exact adaptive147Third137Proof165
  · exact adaptive147Third137Proof166
  · exact adaptive147Third137Proof167
  · exact adaptive147Third137Proof168
  · exact adaptive147Third137Proof169
  · exact adaptive147Third137Proof170
  · exact adaptive147Third137Proof171
  · exact adaptive147Third137Proof172
  · exact adaptive147Third137Proof173
  · exact adaptive147Third137Proof174
  · exact adaptive147Third137Proof175
  · exact adaptive147Third137Proof176
  · exact adaptive147Third137Proof177
  · exact adaptive147Third137Proof178
  · exact adaptive147Third137Proof179
  · exact adaptive147Third137Proof180
  · exact adaptive147Third137Proof181
  · exact adaptive147Third137Proof182
  · exact adaptive147Third137Proof183

#print axioms adaptive147Third137Proof154

theorem adaptive147Third137Proof0 : runCachedNode 511 130518 Adaptive147Third137Node0 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130518 Adaptive147Third137Node0 = [110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 132, 133, 134, 135] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive147Third137Proof1
  · exact adaptive147Third137Proof2
  · exact adaptive147Third137Proof3
  · exact adaptive147Third137Proof4
  · exact adaptive147Third137Proof5
  · exact adaptive147Third137Proof6
  · exact adaptive147Third137Proof7
  · exact adaptive147Third137Proof8
  · exact adaptive147Third137Proof9
  · exact adaptive147Third137Proof10
  · exact adaptive147Third137Proof11
  · exact adaptive147Third137Proof12
  · exact adaptive147Third137Proof13
  · exact adaptive147Third137Proof14
  · exact adaptive147Third137Proof15
  · exact adaptive147Third137Proof16
  · exact adaptive147Third137Proof17
  · exact adaptive147Third137Proof18
  · exact adaptive147Third137Proof19
  · exact adaptive147Third137Proof20
  · exact adaptive147Third137Proof21
  · exact adaptive147Third137Proof45
  · exact adaptive147Third137Proof70
  · exact adaptive147Third137Proof97
  · exact adaptive147Third137Proof125
  · exact adaptive147Third137Proof154

#print axioms adaptive147Third137Proof0

end NineSeparatedSubsetSums
