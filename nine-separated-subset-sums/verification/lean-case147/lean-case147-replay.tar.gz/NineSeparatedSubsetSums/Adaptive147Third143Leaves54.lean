import NineSeparatedSubsetSums.Adaptive147Third143State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third143Proof595 : runCachedNode 511 131344 Adaptive147Third143Node595 = false := by
  decide +kernel

#print axioms adaptive147Third143Proof595

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third143Proof596 : runCachedNode 511 131344 Adaptive147Third143Node596 = false := by
  decide +kernel

#print axioms adaptive147Third143Proof596

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third143Proof597 : runCachedNode 511 131344 Adaptive147Third143Node597 = false := by
  decide +kernel

#print axioms adaptive147Third143Proof597

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third143Proof598 : runCachedNode 511 131344 Adaptive147Third143Node598 = false := by
  decide +kernel

#print axioms adaptive147Third143Proof598

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third143Proof599 : runCachedNode 511 131344 Adaptive147Third143Node599 = false := by
  decide +kernel

#print axioms adaptive147Third143Proof599

end NineSeparatedSubsetSums
