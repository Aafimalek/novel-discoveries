import NineSeparatedSubsetSums.Adaptive147Third134State
import NineSeparatedSubsetSums.Adaptive147Third134Leaves1
import NineSeparatedSubsetSums.Adaptive147Third134Leaves3
import NineSeparatedSubsetSums.Adaptive147Third134Leaves2
import NineSeparatedSubsetSums.Adaptive147Third134Leaves4
import NineSeparatedSubsetSums.Adaptive147Third134Leaves6
import NineSeparatedSubsetSums.Adaptive147Third134Leaves0
import NineSeparatedSubsetSums.Adaptive147Third134Leaves5

namespace NineSeparatedSubsetSums

theorem adaptive147Third134Proof23 : runCachedNode 511 130034 Adaptive147Third134Node23 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130034 Adaptive147Third134Node23 = [104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive147Third134Proof24
  · exact adaptive147Third134Proof25
  · exact adaptive147Third134Proof26
  · exact adaptive147Third134Proof27
  · exact adaptive147Third134Proof28
  · exact adaptive147Third134Proof29
  · exact adaptive147Third134Proof30
  · exact adaptive147Third134Proof31
  · exact adaptive147Third134Proof32
  · exact adaptive147Third134Proof33
  · exact adaptive147Third134Proof34
  · exact adaptive147Third134Proof35
  · exact adaptive147Third134Proof36
  · exact adaptive147Third134Proof37
  · exact adaptive147Third134Proof38
  · exact adaptive147Third134Proof39
  · exact adaptive147Third134Proof40
  · exact adaptive147Third134Proof41
  · exact adaptive147Third134Proof42
  · exact adaptive147Third134Proof43
  · exact adaptive147Third134Proof44
  · exact adaptive147Third134Proof45
  · exact adaptive147Third134Proof46
  · exact adaptive147Third134Proof47
  · exact adaptive147Third134Proof48

#print axioms adaptive147Third134Proof23

theorem adaptive147Third134Proof0 : runCachedNode 511 130034 Adaptive147Third134Node0 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130034 Adaptive147Third134Node0 = [110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 132] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive147Third134Proof1
  · exact adaptive147Third134Proof2
  · exact adaptive147Third134Proof3
  · exact adaptive147Third134Proof4
  · exact adaptive147Third134Proof5
  · exact adaptive147Third134Proof6
  · exact adaptive147Third134Proof7
  · exact adaptive147Third134Proof8
  · exact adaptive147Third134Proof9
  · exact adaptive147Third134Proof10
  · exact adaptive147Third134Proof11
  · exact adaptive147Third134Proof12
  · exact adaptive147Third134Proof13
  · exact adaptive147Third134Proof14
  · exact adaptive147Third134Proof15
  · exact adaptive147Third134Proof16
  · exact adaptive147Third134Proof17
  · exact adaptive147Third134Proof18
  · exact adaptive147Third134Proof19
  · exact adaptive147Third134Proof20
  · exact adaptive147Third134Proof21
  · exact adaptive147Third134Proof22
  · exact adaptive147Third134Proof23

#print axioms adaptive147Third134Proof0

end NineSeparatedSubsetSums
