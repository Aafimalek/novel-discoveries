import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive147Third111Node0 : CachedSearchNode :=
  ⟨4, 110, computeCenteredMask [148,147,111], 406, 55834⟩

end NineSeparatedSubsetSums
