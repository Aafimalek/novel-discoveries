import NineSeparatedSubsetSums.Adaptive147Third139State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third139Proof71 : runCachedNode 511 130807 Adaptive147Third139Node71 = false := by
  decide +kernel

#print axioms adaptive147Third139Proof71

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third139Proof18 : runCachedNode 511 130807 Adaptive147Third139Node18 = false := by
  decide +kernel

#print axioms adaptive147Third139Proof18

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third139Proof244 : runCachedNode 511 130807 Adaptive147Third139Node244 = false := by
  decide +kernel

#print axioms adaptive147Third139Proof244

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third139Proof51 : runCachedNode 511 130807 Adaptive147Third139Node51 = false := by
  decide +kernel

#print axioms adaptive147Third139Proof51

end NineSeparatedSubsetSums
