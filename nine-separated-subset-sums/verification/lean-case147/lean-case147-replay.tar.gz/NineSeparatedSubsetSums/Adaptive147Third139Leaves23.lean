import NineSeparatedSubsetSums.Adaptive147Third139State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third139Proof132 : runCachedNode 511 130807 Adaptive147Third139Node132 = false := by
  decide +kernel

#print axioms adaptive147Third139Proof132

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third139Proof162 : runCachedNode 511 130807 Adaptive147Third139Node162 = false := by
  decide +kernel

#print axioms adaptive147Third139Proof162

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third139Proof163 : runCachedNode 511 130807 Adaptive147Third139Node163 = false := by
  decide +kernel

#print axioms adaptive147Third139Proof163

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third139Proof130 : runCachedNode 511 130807 Adaptive147Third139Node130 = false := by
  decide +kernel

#print axioms adaptive147Third139Proof130

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third139Proof131 : runCachedNode 511 130807 Adaptive147Third139Node131 = false := by
  decide +kernel

#print axioms adaptive147Third139Proof131

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third139Proof161 : runCachedNode 511 130807 Adaptive147Third139Node161 = false := by
  decide +kernel

#print axioms adaptive147Third139Proof161

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third139Proof192 : runCachedNode 511 130807 Adaptive147Third139Node192 = false := by
  decide +kernel

#print axioms adaptive147Third139Proof192

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third139Proof223 : runCachedNode 511 130807 Adaptive147Third139Node223 = false := by
  decide +kernel

#print axioms adaptive147Third139Proof223

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third139Proof128 : runCachedNode 511 130807 Adaptive147Third139Node128 = false := by
  decide +kernel

#print axioms adaptive147Third139Proof128

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third139Proof158 : runCachedNode 511 130807 Adaptive147Third139Node158 = false := by
  decide +kernel

#print axioms adaptive147Third139Proof158

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third139Proof159 : runCachedNode 511 130807 Adaptive147Third139Node159 = false := by
  decide +kernel

#print axioms adaptive147Third139Proof159

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third139Proof160 : runCachedNode 511 130807 Adaptive147Third139Node160 = false := by
  decide +kernel

#print axioms adaptive147Third139Proof160

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third139Proof191 : runCachedNode 511 130807 Adaptive147Third139Node191 = false := by
  decide +kernel

#print axioms adaptive147Third139Proof191

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third139Proof222 : runCachedNode 511 130807 Adaptive147Third139Node222 = false := by
  decide +kernel

#print axioms adaptive147Third139Proof222

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third139Proof47 : runCachedNode 511 130807 Adaptive147Third139Node47 = false := by
  decide +kernel

#print axioms adaptive147Third139Proof47

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third139Proof73 : runCachedNode 511 130807 Adaptive147Third139Node73 = false := by
  decide +kernel

#print axioms adaptive147Third139Proof73

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third139Proof100 : runCachedNode 511 130807 Adaptive147Third139Node100 = false := by
  decide +kernel

#print axioms adaptive147Third139Proof100

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third139Proof157 : runCachedNode 511 130807 Adaptive147Third139Node157 = false := by
  decide +kernel

#print axioms adaptive147Third139Proof157

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third139Proof188 : runCachedNode 511 130807 Adaptive147Third139Node188 = false := by
  decide +kernel

#print axioms adaptive147Third139Proof188

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third139Proof189 : runCachedNode 511 130807 Adaptive147Third139Node189 = false := by
  decide +kernel

#print axioms adaptive147Third139Proof189

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third139Proof190 : runCachedNode 511 130807 Adaptive147Third139Node190 = false := by
  decide +kernel

#print axioms adaptive147Third139Proof190

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third139Proof220 : runCachedNode 511 130807 Adaptive147Third139Node220 = false := by
  decide +kernel

#print axioms adaptive147Third139Proof220

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third139Proof221 : runCachedNode 511 130807 Adaptive147Third139Node221 = false := by
  decide +kernel

#print axioms adaptive147Third139Proof221

end NineSeparatedSubsetSums
