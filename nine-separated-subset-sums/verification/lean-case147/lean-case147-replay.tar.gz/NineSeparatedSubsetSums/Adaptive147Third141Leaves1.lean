import NineSeparatedSubsetSums.Adaptive147Third141State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third141Proof197 : runCachedNode 511 131086 Adaptive147Third141Node197 = false := by
  decide +kernel

#print axioms adaptive147Third141Proof197

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third141Proof45 : runCachedNode 511 131086 Adaptive147Third141Node45 = false := by
  decide +kernel

#print axioms adaptive147Third141Proof45

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third141Proof25 : runCachedNode 511 131086 Adaptive147Third141Node25 = false := by
  decide +kernel

#print axioms adaptive147Third141Proof25

end NineSeparatedSubsetSums
