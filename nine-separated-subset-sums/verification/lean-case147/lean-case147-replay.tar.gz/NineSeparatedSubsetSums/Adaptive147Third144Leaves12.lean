import NineSeparatedSubsetSums.Adaptive147Third144State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof304 : runCachedNode 511 131483 Adaptive147Third144Node304 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof304

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof303 : runCachedNode 511 131483 Adaptive147Third144Node303 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof303

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof3 : runCachedNode 511 131483 Adaptive147Third144Node3 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof3

end NineSeparatedSubsetSums
