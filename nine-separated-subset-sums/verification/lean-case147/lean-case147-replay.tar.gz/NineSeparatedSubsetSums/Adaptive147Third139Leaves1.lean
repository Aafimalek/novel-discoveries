import NineSeparatedSubsetSums.Adaptive147Third139State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third139Proof251 : runCachedNode 511 130807 Adaptive147Third139Node251 = false := by
  decide +kernel

#print axioms adaptive147Third139Proof251

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third139Proof217 : runCachedNode 511 130807 Adaptive147Third139Node217 = false := by
  decide +kernel

#print axioms adaptive147Third139Proof217

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third139Proof50 : runCachedNode 511 130807 Adaptive147Third139Node50 = false := by
  decide +kernel

#print axioms adaptive147Third139Proof50

end NineSeparatedSubsetSums
