import NineSeparatedSubsetSums.Adaptive147Third144State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof837 : runCachedNode 511 131483 Adaptive147Third144Node837 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof837

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof706 : runCachedNode 511 131483 Adaptive147Third144Node706 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof706

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof16 : runCachedNode 511 131483 Adaptive147Third144Node16 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof16

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof323 : runCachedNode 511 131483 Adaptive147Third144Node323 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof323

end NineSeparatedSubsetSums
