import NineSeparatedSubsetSums.Adaptive147Third139State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third139Proof152 : runCachedNode 511 130807 Adaptive147Third139Node152 = false := by
  decide +kernel

#print axioms adaptive147Third139Proof152

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third139Proof16 : runCachedNode 511 130807 Adaptive147Third139Node16 = false := by
  decide +kernel

#print axioms adaptive147Third139Proof16

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third139Proof214 : runCachedNode 511 130807 Adaptive147Third139Node214 = false := by
  decide +kernel

#print axioms adaptive147Third139Proof214

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third139Proof15 : runCachedNode 511 130807 Adaptive147Third139Node15 = false := by
  decide +kernel

#print axioms adaptive147Third139Proof15

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third139Proof24 : runCachedNode 511 130807 Adaptive147Third139Node24 = false := by
  decide +kernel

#print axioms adaptive147Third139Proof24

end NineSeparatedSubsetSums
