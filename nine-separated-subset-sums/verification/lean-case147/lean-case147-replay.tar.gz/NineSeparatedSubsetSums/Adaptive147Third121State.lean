import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive147Third121Node0 : CachedSearchNode :=
  ⟨4, 120, computeCenteredMask [148,147,121], 416, 58154⟩

end NineSeparatedSubsetSums
