import NineSeparatedSubsetSums.Adaptive147Third135State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third135Proof20 : runCachedNode 511 130219 Adaptive147Third135Node20 = false := by
  decide +kernel

#print axioms adaptive147Third135Proof20

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third135Proof14 : runCachedNode 511 130219 Adaptive147Third135Node14 = false := by
  decide +kernel

#print axioms adaptive147Third135Proof14

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third135Proof37 : runCachedNode 511 130219 Adaptive147Third135Node37 = false := by
  decide +kernel

#print axioms adaptive147Third135Proof37

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third135Proof24 : runCachedNode 511 130219 Adaptive147Third135Node24 = false := by
  decide +kernel

#print axioms adaptive147Third135Proof24

end NineSeparatedSubsetSums
