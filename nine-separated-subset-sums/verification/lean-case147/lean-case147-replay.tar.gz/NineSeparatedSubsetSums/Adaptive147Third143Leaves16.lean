import NineSeparatedSubsetSums.Adaptive147Third143State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third143Proof232 : runCachedNode 511 131344 Adaptive147Third143Node232 = false := by
  decide +kernel

#print axioms adaptive147Third143Proof232

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third143Proof420 : runCachedNode 511 131344 Adaptive147Third143Node420 = false := by
  decide +kernel

#print axioms adaptive147Third143Proof420

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third143Proof531 : runCachedNode 511 131344 Adaptive147Third143Node531 = false := by
  decide +kernel

#print axioms adaptive147Third143Proof531

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third143Proof50 : runCachedNode 511 131344 Adaptive147Third143Node50 = false := by
  decide +kernel

#print axioms adaptive147Third143Proof50

end NineSeparatedSubsetSums
