import NineSeparatedSubsetSums.Adaptive147Third143State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third143Proof166 : runCachedNode 511 131344 Adaptive147Third143Node166 = false := by
  decide +kernel

#print axioms adaptive147Third143Proof166

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third143Proof294 : runCachedNode 511 131344 Adaptive147Third143Node294 = false := by
  decide +kernel

#print axioms adaptive147Third143Proof294

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third143Proof164 : runCachedNode 511 131344 Adaptive147Third143Node164 = false := by
  decide +kernel

#print axioms adaptive147Third143Proof164

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third143Proof258 : runCachedNode 511 131344 Adaptive147Third143Node258 = false := by
  decide +kernel

#print axioms adaptive147Third143Proof258

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third143Proof45 : runCachedNode 511 131344 Adaptive147Third143Node45 = false := by
  decide +kernel

#print axioms adaptive147Third143Proof45

end NineSeparatedSubsetSums
