import NineSeparatedSubsetSums.Adaptive147Third140State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third140Proof162 : runCachedNode 511 130945 Adaptive147Third140Node162 = false := by
  decide +kernel

#print axioms adaptive147Third140Proof162

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third140Proof129 : runCachedNode 511 130945 Adaptive147Third140Node129 = false := by
  decide +kernel

#print axioms adaptive147Third140Proof129

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third140Proof132 : runCachedNode 511 130945 Adaptive147Third140Node132 = false := by
  decide +kernel

#print axioms adaptive147Third140Proof132

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third140Proof184 : runCachedNode 511 130945 Adaptive147Third140Node184 = false := by
  decide +kernel

#print axioms adaptive147Third140Proof184

end NineSeparatedSubsetSums
