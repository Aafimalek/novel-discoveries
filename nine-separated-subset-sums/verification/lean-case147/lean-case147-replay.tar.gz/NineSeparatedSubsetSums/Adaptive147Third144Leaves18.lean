import NineSeparatedSubsetSums.Adaptive147Third144State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof838 : runCachedNode 511 131483 Adaptive147Third144Node838 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof838

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof336 : runCachedNode 511 131483 Adaptive147Third144Node336 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof336

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof130 : runCachedNode 511 131483 Adaptive147Third144Node130 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof130

end NineSeparatedSubsetSums
