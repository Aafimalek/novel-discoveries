import NineSeparatedSubsetSums.Adaptive147Third144State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof294 : runCachedNode 511 131483 Adaptive147Third144Node294 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof294

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof327 : runCachedNode 511 131483 Adaptive147Third144Node327 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof327

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof44 : runCachedNode 511 131483 Adaptive147Third144Node44 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof44

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof658 : runCachedNode 511 131483 Adaptive147Third144Node658 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof658

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof126 : runCachedNode 511 131483 Adaptive147Third144Node126 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof126

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof411 : runCachedNode 511 131483 Adaptive147Third144Node411 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof411

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof521 : runCachedNode 511 131483 Adaptive147Third144Node521 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof521

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof46 : runCachedNode 511 131483 Adaptive147Third144Node46 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof46

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof127 : runCachedNode 511 131483 Adaptive147Third144Node127 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof127

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof407 : runCachedNode 511 131483 Adaptive147Third144Node407 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof407

end NineSeparatedSubsetSums
