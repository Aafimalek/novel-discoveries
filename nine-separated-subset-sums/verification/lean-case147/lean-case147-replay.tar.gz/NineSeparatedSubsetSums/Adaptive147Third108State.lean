import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive147Third108Node0 : CachedSearchNode :=
  ⟨4, 107, computeCenteredMask [148,147,108], 403, 55177⟩

end NineSeparatedSubsetSums
