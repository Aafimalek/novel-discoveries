import NineSeparatedSubsetSums.Adaptive147Third139State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third139Proof155 : runCachedNode 511 130807 Adaptive147Third139Node155 = false := by
  decide +kernel

#print axioms adaptive147Third139Proof155

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third139Proof215 : runCachedNode 511 130807 Adaptive147Third139Node215 = false := by
  decide +kernel

#print axioms adaptive147Third139Proof215

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third139Proof248 : runCachedNode 511 130807 Adaptive147Third139Node248 = false := by
  decide +kernel

#print axioms adaptive147Third139Proof248

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third139Proof107 : runCachedNode 511 130807 Adaptive147Third139Node107 = false := by
  decide +kernel

#print axioms adaptive147Third139Proof107

end NineSeparatedSubsetSums
