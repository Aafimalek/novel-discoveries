import NineSeparatedSubsetSums.Adaptive147Third138State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third138Proof14 : runCachedNode 511 130657 Adaptive147Third138Node14 = false := by
  decide +kernel

#print axioms adaptive147Third138Proof14

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third138Proof235 : runCachedNode 511 130657 Adaptive147Third138Node235 = false := by
  decide +kernel

#print axioms adaptive147Third138Proof235

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third138Proof204 : runCachedNode 511 130657 Adaptive147Third138Node204 = false := by
  decide +kernel

#print axioms adaptive147Third138Proof204

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third138Proof236 : runCachedNode 511 130657 Adaptive147Third138Node236 = false := by
  decide +kernel

#print axioms adaptive147Third138Proof236

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third138Proof116 : runCachedNode 511 130657 Adaptive147Third138Node116 = false := by
  decide +kernel

#print axioms adaptive147Third138Proof116

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third138Proof226 : runCachedNode 511 130657 Adaptive147Third138Node226 = false := by
  decide +kernel

#print axioms adaptive147Third138Proof226

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third138Proof121 : runCachedNode 511 130657 Adaptive147Third138Node121 = false := by
  decide +kernel

#print axioms adaptive147Third138Proof121

end NineSeparatedSubsetSums
