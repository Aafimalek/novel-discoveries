import NineSeparatedSubsetSums.Adaptive147Third140State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third140Proof127 : runCachedNode 511 130945 Adaptive147Third140Node127 = false := by
  decide +kernel

#print axioms adaptive147Third140Proof127

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third140Proof92 : runCachedNode 511 130945 Adaptive147Third140Node92 = false := by
  decide +kernel

#print axioms adaptive147Third140Proof92

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third140Proof157 : runCachedNode 511 130945 Adaptive147Third140Node157 = false := by
  decide +kernel

#print axioms adaptive147Third140Proof157

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third140Proof123 : runCachedNode 511 130945 Adaptive147Third140Node123 = false := by
  decide +kernel

#print axioms adaptive147Third140Proof123

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third140Proof42 : runCachedNode 511 130945 Adaptive147Third140Node42 = false := by
  decide +kernel

#print axioms adaptive147Third140Proof42

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third140Proof250 : runCachedNode 511 130945 Adaptive147Third140Node250 = false := by
  decide +kernel

#print axioms adaptive147Third140Proof250

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third140Proof218 : runCachedNode 511 130945 Adaptive147Third140Node218 = false := by
  decide +kernel

#print axioms adaptive147Third140Proof218

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third140Proof64 : runCachedNode 511 130945 Adaptive147Third140Node64 = false := by
  decide +kernel

#print axioms adaptive147Third140Proof64

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third140Proof187 : runCachedNode 511 130945 Adaptive147Third140Node187 = false := by
  decide +kernel

#print axioms adaptive147Third140Proof187

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third140Proof66 : runCachedNode 511 130945 Adaptive147Third140Node66 = false := by
  decide +kernel

#print axioms adaptive147Third140Proof66

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third140Proof219 : runCachedNode 511 130945 Adaptive147Third140Node219 = false := by
  decide +kernel

#print axioms adaptive147Third140Proof219

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third140Proof122 : runCachedNode 511 130945 Adaptive147Third140Node122 = false := by
  decide +kernel

#print axioms adaptive147Third140Proof122

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third140Proof154 : runCachedNode 511 130945 Adaptive147Third140Node154 = false := by
  decide +kernel

#print axioms adaptive147Third140Proof154

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third140Proof63 : runCachedNode 511 130945 Adaptive147Third140Node63 = false := by
  decide +kernel

#print axioms adaptive147Third140Proof63

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third140Proof27 : runCachedNode 511 130945 Adaptive147Third140Node27 = false := by
  decide +kernel

#print axioms adaptive147Third140Proof27

end NineSeparatedSubsetSums
