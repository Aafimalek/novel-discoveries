import NineSeparatedSubsetSums.Adaptive147Third135State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third135Proof21 : runCachedNode 511 130219 Adaptive147Third135Node21 = false := by
  decide +kernel

#print axioms adaptive147Third135Proof21

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third135Proof72 : runCachedNode 511 130219 Adaptive147Third135Node72 = false := by
  decide +kernel

#print axioms adaptive147Third135Proof72

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third135Proof8 : runCachedNode 511 130219 Adaptive147Third135Node8 = false := by
  decide +kernel

#print axioms adaptive147Third135Proof8

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third135Proof1 : runCachedNode 511 130219 Adaptive147Third135Node1 = false := by
  decide +kernel

#print axioms adaptive147Third135Proof1

end NineSeparatedSubsetSums
