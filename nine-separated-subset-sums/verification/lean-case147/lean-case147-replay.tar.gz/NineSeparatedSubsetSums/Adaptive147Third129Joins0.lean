import NineSeparatedSubsetSums.Adaptive147Third129State
import NineSeparatedSubsetSums.Adaptive147Third129Leaves1
import NineSeparatedSubsetSums.Adaptive147Third129Leaves0
import NineSeparatedSubsetSums.Adaptive147Third129Leaves2

namespace NineSeparatedSubsetSums

theorem adaptive147Third129Proof0 : runCachedNode 511 129010 Adaptive147Third129Node0 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 129010 Adaptive147Third129Node0 = [110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive147Third129Proof1
  · exact adaptive147Third129Proof2
  · exact adaptive147Third129Proof3
  · exact adaptive147Third129Proof4
  · exact adaptive147Third129Proof5
  · exact adaptive147Third129Proof6
  · exact adaptive147Third129Proof7
  · exact adaptive147Third129Proof8
  · exact adaptive147Third129Proof9
  · exact adaptive147Third129Proof10
  · exact adaptive147Third129Proof11
  · exact adaptive147Third129Proof12
  · exact adaptive147Third129Proof13
  · exact adaptive147Third129Proof14
  · exact adaptive147Third129Proof15
  · exact adaptive147Third129Proof16
  · exact adaptive147Third129Proof17
  · exact adaptive147Third129Proof18

#print axioms adaptive147Third129Proof0

end NineSeparatedSubsetSums
