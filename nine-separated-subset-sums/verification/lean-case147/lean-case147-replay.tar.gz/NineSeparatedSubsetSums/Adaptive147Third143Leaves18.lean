import NineSeparatedSubsetSums.Adaptive147Third143State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third143Proof544 : runCachedNode 511 131344 Adaptive147Third143Node544 = false := by
  decide +kernel

#print axioms adaptive147Third143Proof544

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third143Proof17 : runCachedNode 511 131344 Adaptive147Third143Node17 = false := by
  decide +kernel

#print axioms adaptive147Third143Proof17

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third143Proof259 : runCachedNode 511 131344 Adaptive147Third143Node259 = false := by
  decide +kernel

#print axioms adaptive147Third143Proof259

end NineSeparatedSubsetSums
