import NineSeparatedSubsetSums.Adaptive147Third136State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third136Proof20 : runCachedNode 511 130369 Adaptive147Third136Node20 = false := by
  decide +kernel

#print axioms adaptive147Third136Proof20

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third136Proof128 : runCachedNode 511 130369 Adaptive147Third136Node128 = false := by
  decide +kernel

#print axioms adaptive147Third136Proof128

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third136Proof30 : runCachedNode 511 130369 Adaptive147Third136Node30 = false := by
  decide +kernel

#print axioms adaptive147Third136Proof30

end NineSeparatedSubsetSums
