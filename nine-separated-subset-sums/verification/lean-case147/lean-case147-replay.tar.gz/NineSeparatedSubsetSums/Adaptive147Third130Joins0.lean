import NineSeparatedSubsetSums.Adaptive147Third130State
import NineSeparatedSubsetSums.Adaptive147Third130Leaves0
import NineSeparatedSubsetSums.Adaptive147Third130Leaves2
import NineSeparatedSubsetSums.Adaptive147Third130Leaves1

namespace NineSeparatedSubsetSums

theorem adaptive147Third130Proof0 : runCachedNode 511 129214 Adaptive147Third130Node0 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 129214 Adaptive147Third130Node0 = [110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive147Third130Proof1
  · exact adaptive147Third130Proof2
  · exact adaptive147Third130Proof3
  · exact adaptive147Third130Proof4
  · exact adaptive147Third130Proof5
  · exact adaptive147Third130Proof6
  · exact adaptive147Third130Proof7
  · exact adaptive147Third130Proof8
  · exact adaptive147Third130Proof9
  · exact adaptive147Third130Proof10
  · exact adaptive147Third130Proof11
  · exact adaptive147Third130Proof12
  · exact adaptive147Third130Proof13
  · exact adaptive147Third130Proof14
  · exact adaptive147Third130Proof15
  · exact adaptive147Third130Proof16
  · exact adaptive147Third130Proof17
  · exact adaptive147Third130Proof18
  · exact adaptive147Third130Proof19

#print axioms adaptive147Third130Proof0

end NineSeparatedSubsetSums
