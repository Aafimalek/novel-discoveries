import NineSeparatedSubsetSums.Adaptive147Third136State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third136Proof21 : runCachedNode 511 130369 Adaptive147Third136Node21 = false := by
  decide +kernel

#print axioms adaptive147Third136Proof21

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third136Proof96 : runCachedNode 511 130369 Adaptive147Third136Node96 = false := by
  decide +kernel

#print axioms adaptive147Third136Proof96

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third136Proof1 : runCachedNode 511 130369 Adaptive147Third136Node1 = false := by
  decide +kernel

#print axioms adaptive147Third136Proof1

end NineSeparatedSubsetSums
