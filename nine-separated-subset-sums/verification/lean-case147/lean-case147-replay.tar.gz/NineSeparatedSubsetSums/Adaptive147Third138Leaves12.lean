import NineSeparatedSubsetSums.Adaptive147Third138State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third138Proof201 : runCachedNode 511 130657 Adaptive147Third138Node201 = false := by
  decide +kernel

#print axioms adaptive147Third138Proof201

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third138Proof205 : runCachedNode 511 130657 Adaptive147Third138Node205 = false := by
  decide +kernel

#print axioms adaptive147Third138Proof205

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third138Proof13 : runCachedNode 511 130657 Adaptive147Third138Node13 = false := by
  decide +kernel

#print axioms adaptive147Third138Proof13

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third138Proof65 : runCachedNode 511 130657 Adaptive147Third138Node65 = false := by
  decide +kernel

#print axioms adaptive147Third138Proof65

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third138Proof12 : runCachedNode 511 130657 Adaptive147Third138Node12 = false := by
  decide +kernel

#print axioms adaptive147Third138Proof12

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third138Proof143 : runCachedNode 511 130657 Adaptive147Third138Node143 = false := by
  decide +kernel

#print axioms adaptive147Third138Proof143

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third138Proof63 : runCachedNode 511 130657 Adaptive147Third138Node63 = false := by
  decide +kernel

#print axioms adaptive147Third138Proof63

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third138Proof178 : runCachedNode 511 130657 Adaptive147Third138Node178 = false := by
  decide +kernel

#print axioms adaptive147Third138Proof178

end NineSeparatedSubsetSums
