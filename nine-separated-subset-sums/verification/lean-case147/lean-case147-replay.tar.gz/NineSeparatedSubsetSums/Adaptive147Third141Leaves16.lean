import NineSeparatedSubsetSums.Adaptive147Third141State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third141Proof133 : runCachedNode 511 131086 Adaptive147Third141Node133 = false := by
  decide +kernel

#print axioms adaptive147Third141Proof133

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third141Proof164 : runCachedNode 511 131086 Adaptive147Third141Node164 = false := by
  decide +kernel

#print axioms adaptive147Third141Proof164

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third141Proof300 : runCachedNode 511 131086 Adaptive147Third141Node300 = false := by
  decide +kernel

#print axioms adaptive147Third141Proof300

end NineSeparatedSubsetSums
