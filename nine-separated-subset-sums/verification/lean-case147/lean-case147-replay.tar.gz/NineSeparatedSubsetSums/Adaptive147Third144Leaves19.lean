import NineSeparatedSubsetSums.Adaptive147Third144State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof231 : runCachedNode 511 131483 Adaptive147Third144Node231 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof231

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof167 : runCachedNode 511 131483 Adaptive147Third144Node167 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof167

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof526 : runCachedNode 511 131483 Adaptive147Third144Node526 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof526

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof50 : runCachedNode 511 131483 Adaptive147Third144Node50 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof50

end NineSeparatedSubsetSums
