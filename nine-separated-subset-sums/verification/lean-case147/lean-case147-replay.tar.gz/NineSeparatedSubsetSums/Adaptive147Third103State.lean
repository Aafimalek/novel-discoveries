import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive147Third103Node0 : CachedSearchNode :=
  ⟨4, 102, computeCenteredMask [148,147,103], 398, 54122⟩

end NineSeparatedSubsetSums
