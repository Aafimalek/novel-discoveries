import NineSeparatedSubsetSums.Adaptive147Third142State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third142Proof383 : runCachedNode 511 131213 Adaptive147Third142Node383 = false := by
  decide +kernel

#print axioms adaptive147Third142Proof383

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third142Proof48 : runCachedNode 511 131213 Adaptive147Third142Node48 = false := by
  decide +kernel

#print axioms adaptive147Third142Proof48

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third142Proof133 : runCachedNode 511 131213 Adaptive147Third142Node133 = false := by
  decide +kernel

#print axioms adaptive147Third142Proof133

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third142Proof135 : runCachedNode 511 131213 Adaptive147Third142Node135 = false := by
  decide +kernel

#print axioms adaptive147Third142Proof135

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third142Proof279 : runCachedNode 511 131213 Adaptive147Third142Node279 = false := by
  decide +kernel

#print axioms adaptive147Third142Proof279

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third142Proof13 : runCachedNode 511 131213 Adaptive147Third142Node13 = false := by
  decide +kernel

#print axioms adaptive147Third142Proof13

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third142Proof87 : runCachedNode 511 131213 Adaptive147Third142Node87 = false := by
  decide +kernel

#print axioms adaptive147Third142Proof87

end NineSeparatedSubsetSums
