import NineSeparatedSubsetSums.Adaptive147Third137State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third137Proof66 : runCachedNode 511 130518 Adaptive147Third137Node66 = false := by
  decide +kernel

#print axioms adaptive147Third137Proof66

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third137Proof123 : runCachedNode 511 130518 Adaptive147Third137Node123 = false := by
  decide +kernel

#print axioms adaptive147Third137Proof123

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third137Proof96 : runCachedNode 511 130518 Adaptive147Third137Node96 = false := by
  decide +kernel

#print axioms adaptive147Third137Proof96

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third137Proof43 : runCachedNode 511 130518 Adaptive147Third137Node43 = false := by
  decide +kernel

#print axioms adaptive147Third137Proof43

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third137Proof120 : runCachedNode 511 130518 Adaptive147Third137Node120 = false := by
  decide +kernel

#print axioms adaptive147Third137Proof120

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third137Proof114 : runCachedNode 511 130518 Adaptive147Third137Node114 = false := by
  decide +kernel

#print axioms adaptive147Third137Proof114

end NineSeparatedSubsetSums
