import NineSeparatedSubsetSums.Adaptive147Third142State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third142Proof100 : runCachedNode 511 131213 Adaptive147Third142Node100 = false := by
  decide +kernel

#print axioms adaptive147Third142Proof100

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third142Proof45 : runCachedNode 511 131213 Adaptive147Third142Node45 = false := by
  decide +kernel

#print axioms adaptive147Third142Proof45

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third142Proof158 : runCachedNode 511 131213 Adaptive147Third142Node158 = false := by
  decide +kernel

#print axioms adaptive147Third142Proof158

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third142Proof11 : runCachedNode 511 131213 Adaptive147Third142Node11 = false := by
  decide +kernel

#print axioms adaptive147Third142Proof11

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third142Proof191 : runCachedNode 511 131213 Adaptive147Third142Node191 = false := by
  decide +kernel

#print axioms adaptive147Third142Proof191

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third142Proof305 : runCachedNode 511 131213 Adaptive147Third142Node305 = false := by
  decide +kernel

#print axioms adaptive147Third142Proof305

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third142Proof430 : runCachedNode 511 131213 Adaptive147Third142Node430 = false := by
  decide +kernel

#print axioms adaptive147Third142Proof430

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third142Proof192 : runCachedNode 511 131213 Adaptive147Third142Node192 = false := by
  decide +kernel

#print axioms adaptive147Third142Proof192

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third142Proof227 : runCachedNode 511 131213 Adaptive147Third142Node227 = false := by
  decide +kernel

#print axioms adaptive147Third142Proof227

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third142Proof377 : runCachedNode 511 131213 Adaptive147Third142Node377 = false := by
  decide +kernel

#print axioms adaptive147Third142Proof377

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third142Proof228 : runCachedNode 511 131213 Adaptive147Third142Node228 = false := by
  decide +kernel

#print axioms adaptive147Third142Proof228

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third142Proof277 : runCachedNode 511 131213 Adaptive147Third142Node277 = false := by
  decide +kernel

#print axioms adaptive147Third142Proof277

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third142Proof375 : runCachedNode 511 131213 Adaptive147Third142Node375 = false := by
  decide +kernel

#print axioms adaptive147Third142Proof375

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third142Proof127 : runCachedNode 511 131213 Adaptive147Third142Node127 = false := by
  decide +kernel

#print axioms adaptive147Third142Proof127

end NineSeparatedSubsetSums
