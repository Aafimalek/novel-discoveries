import NineSeparatedSubsetSums.Adaptive147Third139State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third139Proof98 : runCachedNode 511 130807 Adaptive147Third139Node98 = false := by
  decide +kernel

#print axioms adaptive147Third139Proof98

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third139Proof250 : runCachedNode 511 130807 Adaptive147Third139Node250 = false := by
  decide +kernel

#print axioms adaptive147Third139Proof250

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third139Proof7 : runCachedNode 511 130807 Adaptive147Third139Node7 = false := by
  decide +kernel

#print axioms adaptive147Third139Proof7

end NineSeparatedSubsetSums
