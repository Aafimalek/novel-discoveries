import NineSeparatedSubsetSums.Adaptive147Third143State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third143Proof288 : runCachedNode 511 131344 Adaptive147Third143Node288 = false := by
  decide +kernel

#print axioms adaptive147Third143Proof288

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third143Proof630 : runCachedNode 511 131344 Adaptive147Third143Node630 = false := by
  decide +kernel

#print axioms adaptive147Third143Proof630

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third143Proof73 : runCachedNode 511 131344 Adaptive147Third143Node73 = false := by
  decide +kernel

#print axioms adaptive147Third143Proof73

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third143Proof340 : runCachedNode 511 131344 Adaptive147Third143Node340 = false := by
  decide +kernel

#print axioms adaptive147Third143Proof340

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third143Proof253 : runCachedNode 511 131344 Adaptive147Third143Node253 = false := by
  decide +kernel

#print axioms adaptive147Third143Proof253

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third143Proof382 : runCachedNode 511 131344 Adaptive147Third143Node382 = false := by
  decide +kernel

#print axioms adaptive147Third143Proof382

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third143Proof534 : runCachedNode 511 131344 Adaptive147Third143Node534 = false := by
  decide +kernel

#print axioms adaptive147Third143Proof534

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third143Proof409 : runCachedNode 511 131344 Adaptive147Third143Node409 = false := by
  decide +kernel

#print axioms adaptive147Third143Proof409

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third143Proof533 : runCachedNode 511 131344 Adaptive147Third143Node533 = false := by
  decide +kernel

#print axioms adaptive147Third143Proof533

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third143Proof532 : runCachedNode 511 131344 Adaptive147Third143Node532 = false := by
  decide +kernel

#print axioms adaptive147Third143Proof532

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third143Proof287 : runCachedNode 511 131344 Adaptive147Third143Node287 = false := by
  decide +kernel

#print axioms adaptive147Third143Proof287

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third143Proof336 : runCachedNode 511 131344 Adaptive147Third143Node336 = false := by
  decide +kernel

#print axioms adaptive147Third143Proof336

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third143Proof168 : runCachedNode 511 131344 Adaptive147Third143Node168 = false := by
  decide +kernel

#print axioms adaptive147Third143Proof168

end NineSeparatedSubsetSums
