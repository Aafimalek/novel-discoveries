import NineSeparatedSubsetSums.Adaptive147Third143State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third143Proof19 : runCachedNode 511 131344 Adaptive147Third143Node19 = false := by
  decide +kernel

#print axioms adaptive147Third143Proof19

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third143Proof419 : runCachedNode 511 131344 Adaptive147Third143Node419 = false := by
  decide +kernel

#print axioms adaptive147Third143Proof419

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third143Proof31 : runCachedNode 511 131344 Adaptive147Third143Node31 = false := by
  decide +kernel

#print axioms adaptive147Third143Proof31

end NineSeparatedSubsetSums
