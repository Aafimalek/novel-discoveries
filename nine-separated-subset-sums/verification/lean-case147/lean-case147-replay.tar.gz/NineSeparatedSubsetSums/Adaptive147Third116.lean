import NineSeparatedSubsetSums.Adaptive147Third116Joins0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint147Checked

namespace NineSeparatedSubsetSums


theorem adaptive147Third116 : NoDescendingTailAfterThird 147 116 :=
  noDescendingThirdTail_of_cached 147 116 112835 (fun t ht nd => max148_second147_fourPoint_moment_bound (116::t) (by simp [ht]) nd) adaptive147Third116Proof0

#print axioms adaptive147Third116

end NineSeparatedSubsetSums
