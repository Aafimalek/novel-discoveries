import NineSeparatedSubsetSums.Adaptive147Third132State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third132Proof21 : runCachedNode 511 129667 Adaptive147Third132Node21 = false := by
  decide +kernel

#print axioms adaptive147Third132Proof21

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third132Proof6 : runCachedNode 511 129667 Adaptive147Third132Node6 = false := by
  decide +kernel

#print axioms adaptive147Third132Proof6

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third132Proof2 : runCachedNode 511 129667 Adaptive147Third132Node2 = false := by
  decide +kernel

#print axioms adaptive147Third132Proof2

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third132Proof1 : runCachedNode 511 129667 Adaptive147Third132Node1 = false := by
  decide +kernel

#print axioms adaptive147Third132Proof1

end NineSeparatedSubsetSums
