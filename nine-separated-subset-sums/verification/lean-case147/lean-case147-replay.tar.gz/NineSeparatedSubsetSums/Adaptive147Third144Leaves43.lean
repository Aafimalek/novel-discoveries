import NineSeparatedSubsetSums.Adaptive147Third144State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof375 : runCachedNode 511 131483 Adaptive147Third144Node375 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof375

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof574 : runCachedNode 511 131483 Adaptive147Third144Node574 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof574

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof573 : runCachedNode 511 131483 Adaptive147Third144Node573 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof573

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof128 : runCachedNode 511 131483 Adaptive147Third144Node128 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof128

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof158 : runCachedNode 511 131483 Adaptive147Third144Node158 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof158

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof730 : runCachedNode 511 131483 Adaptive147Third144Node730 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof730

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof160 : runCachedNode 511 131483 Adaptive147Third144Node160 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof160

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof295 : runCachedNode 511 131483 Adaptive147Third144Node295 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof295

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof94 : runCachedNode 511 131483 Adaptive147Third144Node94 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof94

end NineSeparatedSubsetSums
