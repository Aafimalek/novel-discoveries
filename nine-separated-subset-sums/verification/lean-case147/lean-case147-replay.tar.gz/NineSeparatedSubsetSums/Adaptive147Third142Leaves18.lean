import NineSeparatedSubsetSums.Adaptive147Third142State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third142Proof19 : runCachedNode 511 131213 Adaptive147Third142Node19 = false := by
  decide +kernel

#print axioms adaptive147Third142Proof19

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third142Proof236 : runCachedNode 511 131213 Adaptive147Third142Node236 = false := by
  decide +kernel

#print axioms adaptive147Third142Proof236

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third142Proof380 : runCachedNode 511 131213 Adaptive147Third142Node380 = false := by
  decide +kernel

#print axioms adaptive147Third142Proof380

end NineSeparatedSubsetSums
