import NineSeparatedSubsetSums.Adaptive147Third144State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof124 : runCachedNode 511 131483 Adaptive147Third144Node124 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof124

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof452 : runCachedNode 511 131483 Adaptive147Third144Node452 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof452

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof812 : runCachedNode 511 131483 Adaptive147Third144Node812 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof812

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof819 : runCachedNode 511 131483 Adaptive147Third144Node819 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof819

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof40 : runCachedNode 511 131483 Adaptive147Third144Node40 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof40

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof409 : runCachedNode 511 131483 Adaptive147Third144Node409 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof409

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof818 : runCachedNode 511 131483 Adaptive147Third144Node818 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof818

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof517 : runCachedNode 511 131483 Adaptive147Third144Node517 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof517

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof609 : runCachedNode 511 131483 Adaptive147Third144Node609 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof609

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof724 : runCachedNode 511 131483 Adaptive147Third144Node724 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof724

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof221 : runCachedNode 511 131483 Adaptive147Third144Node221 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof221

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof255 : runCachedNode 511 131483 Adaptive147Third144Node255 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof255

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof371 : runCachedNode 511 131483 Adaptive147Third144Node371 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof371

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof222 : runCachedNode 511 131483 Adaptive147Third144Node222 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof222

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof820 : runCachedNode 511 131483 Adaptive147Third144Node820 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof820

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof693 : runCachedNode 511 131483 Adaptive147Third144Node693 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof693

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof123 : runCachedNode 511 131483 Adaptive147Third144Node123 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof123

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof364 : runCachedNode 511 131483 Adaptive147Third144Node364 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof364

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof287 : runCachedNode 511 131483 Adaptive147Third144Node287 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof287

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof220 : runCachedNode 511 131483 Adaptive147Third144Node220 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof220

end NineSeparatedSubsetSums
