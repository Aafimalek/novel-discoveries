import NineSeparatedSubsetSums.Adaptive147Third142State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third142Proof234 : runCachedNode 511 131213 Adaptive147Third142Node234 = false := by
  decide +kernel

#print axioms adaptive147Third142Proof234

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third142Proof388 : runCachedNode 511 131213 Adaptive147Third142Node388 = false := by
  decide +kernel

#print axioms adaptive147Third142Proof388

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third142Proof384 : runCachedNode 511 131213 Adaptive147Third142Node384 = false := by
  decide +kernel

#print axioms adaptive147Third142Proof384

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third142Proof387 : runCachedNode 511 131213 Adaptive147Third142Node387 = false := by
  decide +kernel

#print axioms adaptive147Third142Proof387

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third142Proof132 : runCachedNode 511 131213 Adaptive147Third142Node132 = false := by
  decide +kernel

#print axioms adaptive147Third142Proof132

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third142Proof26 : runCachedNode 511 131213 Adaptive147Third142Node26 = false := by
  decide +kernel

#print axioms adaptive147Third142Proof26

end NineSeparatedSubsetSums
