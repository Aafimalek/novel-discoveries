import NineSeparatedSubsetSums.Adaptive147Third145State
import NineSeparatedSubsetSums.Adaptive147Third145Leaves61
import NineSeparatedSubsetSums.Adaptive147Third145Leaves60
import NineSeparatedSubsetSums.Adaptive147Third145Leaves59
import NineSeparatedSubsetSums.Adaptive147Third145Leaves58
import NineSeparatedSubsetSums.Adaptive147Third145Leaves57
import NineSeparatedSubsetSums.Adaptive147Third145Leaves56
import NineSeparatedSubsetSums.Adaptive147Third145Leaves55
import NineSeparatedSubsetSums.Adaptive147Third145Leaves53
import NineSeparatedSubsetSums.Adaptive147Third145Leaves52
import NineSeparatedSubsetSums.Adaptive147Third145Leaves51
import NineSeparatedSubsetSums.Adaptive147Third145Leaves50
import NineSeparatedSubsetSums.Adaptive147Third145Leaves49
import NineSeparatedSubsetSums.Adaptive147Third145Leaves48
import NineSeparatedSubsetSums.Adaptive147Third145Leaves47
import NineSeparatedSubsetSums.Adaptive147Third145Leaves45
import NineSeparatedSubsetSums.Adaptive147Third145Leaves42
import NineSeparatedSubsetSums.Adaptive147Third145Leaves39
import NineSeparatedSubsetSums.Adaptive147Third145Leaves35
import NineSeparatedSubsetSums.Adaptive147Third145Leaves30
import NineSeparatedSubsetSums.Adaptive147Third145Leaves21
import NineSeparatedSubsetSums.Adaptive147Third145Leaves17
import NineSeparatedSubsetSums.Adaptive147Third145Leaves15
import NineSeparatedSubsetSums.Adaptive147Third145Leaves9
import NineSeparatedSubsetSums.Adaptive147Third145Leaves8
import NineSeparatedSubsetSums.Adaptive147Third145Leaves46
import NineSeparatedSubsetSums.Adaptive147Third145Leaves24
import NineSeparatedSubsetSums.Adaptive147Third145Leaves44
import NineSeparatedSubsetSums.Adaptive147Third145Leaves26
import NineSeparatedSubsetSums.Adaptive147Third145Leaves40
import NineSeparatedSubsetSums.Adaptive147Third145Leaves38
import NineSeparatedSubsetSums.Adaptive147Third145Leaves37
import NineSeparatedSubsetSums.Adaptive147Third145Leaves3
import NineSeparatedSubsetSums.Adaptive147Third145Leaves31
import NineSeparatedSubsetSums.Adaptive147Third145Leaves11
import NineSeparatedSubsetSums.Adaptive147Third145Leaves12
import NineSeparatedSubsetSums.Adaptive147Third145Leaves7
import NineSeparatedSubsetSums.Adaptive147Third145Leaves0
import NineSeparatedSubsetSums.Adaptive147Third145Leaves62
import NineSeparatedSubsetSums.Adaptive147Third145Leaves54
import NineSeparatedSubsetSums.Adaptive147Third145Leaves41
import NineSeparatedSubsetSums.Adaptive147Third145Leaves36
import NineSeparatedSubsetSums.Adaptive147Third145Leaves43
import NineSeparatedSubsetSums.Adaptive147Third145Leaves33
import NineSeparatedSubsetSums.Adaptive147Third145Leaves34
import NineSeparatedSubsetSums.Adaptive147Third145Leaves32
import NineSeparatedSubsetSums.Adaptive147Third145Leaves28
import NineSeparatedSubsetSums.Adaptive147Third145Leaves23
import NineSeparatedSubsetSums.Adaptive147Third145Leaves13
import NineSeparatedSubsetSums.Adaptive147Third145Leaves4
import NineSeparatedSubsetSums.Adaptive147Third145Leaves63
import NineSeparatedSubsetSums.Adaptive147Third145Leaves20

namespace NineSeparatedSubsetSums

theorem adaptive147Third145Proof282 : runCachedNode 511 131618 Adaptive147Third145Node282 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 131618 Adaptive147Third145Node282 = [100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 132, 133, 134, 135, 136] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive147Third145Proof283
  · exact adaptive147Third145Proof284
  · exact adaptive147Third145Proof285
  · exact adaptive147Third145Proof286
  · exact adaptive147Third145Proof287
  · exact adaptive147Third145Proof288
  · exact adaptive147Third145Proof289
  · exact adaptive147Third145Proof290
  · exact adaptive147Third145Proof291
  · exact adaptive147Third145Proof292
  · exact adaptive147Third145Proof293
  · exact adaptive147Third145Proof294
  · exact adaptive147Third145Proof295
  · exact adaptive147Third145Proof296
  · exact adaptive147Third145Proof297
  · exact adaptive147Third145Proof298
  · exact adaptive147Third145Proof299
  · exact adaptive147Third145Proof300
  · exact adaptive147Third145Proof301
  · exact adaptive147Third145Proof302
  · exact adaptive147Third145Proof303
  · exact adaptive147Third145Proof304
  · exact adaptive147Third145Proof305
  · exact adaptive147Third145Proof306
  · exact adaptive147Third145Proof307
  · exact adaptive147Third145Proof308
  · exact adaptive147Third145Proof309
  · exact adaptive147Third145Proof310
  · exact adaptive147Third145Proof311
  · exact adaptive147Third145Proof312
  · exact adaptive147Third145Proof313
  · exact adaptive147Third145Proof314
  · exact adaptive147Third145Proof315
  · exact adaptive147Third145Proof316
  · exact adaptive147Third145Proof317
  · exact adaptive147Third145Proof318
  · exact adaptive147Third145Proof319

#print axioms adaptive147Third145Proof282

theorem adaptive147Third145Proof320 : runCachedNode 511 131618 Adaptive147Third145Node320 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 131618 Adaptive147Third145Node320 = [100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 132, 133, 134, 135, 136, 137] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive147Third145Proof321
  · exact adaptive147Third145Proof322
  · exact adaptive147Third145Proof323
  · exact adaptive147Third145Proof324
  · exact adaptive147Third145Proof325
  · exact adaptive147Third145Proof326
  · exact adaptive147Third145Proof327
  · exact adaptive147Third145Proof328
  · exact adaptive147Third145Proof329
  · exact adaptive147Third145Proof330
  · exact adaptive147Third145Proof331
  · exact adaptive147Third145Proof332
  · exact adaptive147Third145Proof333
  · exact adaptive147Third145Proof334
  · exact adaptive147Third145Proof335
  · exact adaptive147Third145Proof336
  · exact adaptive147Third145Proof337
  · exact adaptive147Third145Proof338
  · exact adaptive147Third145Proof339
  · exact adaptive147Third145Proof340
  · exact adaptive147Third145Proof341
  · exact adaptive147Third145Proof342
  · exact adaptive147Third145Proof343
  · exact adaptive147Third145Proof344
  · exact adaptive147Third145Proof345
  · exact adaptive147Third145Proof346
  · exact adaptive147Third145Proof347
  · exact adaptive147Third145Proof348
  · exact adaptive147Third145Proof349
  · exact adaptive147Third145Proof350
  · exact adaptive147Third145Proof351
  · exact adaptive147Third145Proof352
  · exact adaptive147Third145Proof353
  · exact adaptive147Third145Proof354
  · exact adaptive147Third145Proof355
  · exact adaptive147Third145Proof356
  · exact adaptive147Third145Proof357
  · exact adaptive147Third145Proof358

#print axioms adaptive147Third145Proof320

theorem adaptive147Third145Proof397 : runCachedNode 511 131618 Adaptive147Third145Node397 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 131618 Adaptive147Third145Node397 = [86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 129] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive147Third145Proof398
  · exact adaptive147Third145Proof399
  · exact adaptive147Third145Proof400
  · exact adaptive147Third145Proof401
  · exact adaptive147Third145Proof402
  · exact adaptive147Third145Proof403
  · exact adaptive147Third145Proof404
  · exact adaptive147Third145Proof405
  · exact adaptive147Third145Proof406
  · exact adaptive147Third145Proof407
  · exact adaptive147Third145Proof408
  · exact adaptive147Third145Proof409
  · exact adaptive147Third145Proof410
  · exact adaptive147Third145Proof411
  · exact adaptive147Third145Proof412
  · exact adaptive147Third145Proof413
  · exact adaptive147Third145Proof414
  · exact adaptive147Third145Proof415
  · exact adaptive147Third145Proof416
  · exact adaptive147Third145Proof417
  · exact adaptive147Third145Proof418
  · exact adaptive147Third145Proof419
  · exact adaptive147Third145Proof420
  · exact adaptive147Third145Proof421
  · exact adaptive147Third145Proof422
  · exact adaptive147Third145Proof423
  · exact adaptive147Third145Proof424
  · exact adaptive147Third145Proof425
  · exact adaptive147Third145Proof426
  · exact adaptive147Third145Proof427
  · exact adaptive147Third145Proof428
  · exact adaptive147Third145Proof429
  · exact adaptive147Third145Proof430
  · exact adaptive147Third145Proof431
  · exact adaptive147Third145Proof432
  · exact adaptive147Third145Proof433
  · exact adaptive147Third145Proof434
  · exact adaptive147Third145Proof435
  · exact adaptive147Third145Proof436
  · exact adaptive147Third145Proof437
  · exact adaptive147Third145Proof438
  · exact adaptive147Third145Proof439
  · exact adaptive147Third145Proof440

#print axioms adaptive147Third145Proof397

theorem adaptive147Third145Proof441 : runCachedNode 511 131618 Adaptive147Third145Node441 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 131618 Adaptive147Third145Node441 = [86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 130] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive147Third145Proof442
  · exact adaptive147Third145Proof443
  · exact adaptive147Third145Proof444
  · exact adaptive147Third145Proof445
  · exact adaptive147Third145Proof446
  · exact adaptive147Third145Proof447
  · exact adaptive147Third145Proof448
  · exact adaptive147Third145Proof449
  · exact adaptive147Third145Proof450
  · exact adaptive147Third145Proof451
  · exact adaptive147Third145Proof452
  · exact adaptive147Third145Proof453
  · exact adaptive147Third145Proof454
  · exact adaptive147Third145Proof455
  · exact adaptive147Third145Proof456
  · exact adaptive147Third145Proof457
  · exact adaptive147Third145Proof458
  · exact adaptive147Third145Proof459
  · exact adaptive147Third145Proof460
  · exact adaptive147Third145Proof461
  · exact adaptive147Third145Proof462
  · exact adaptive147Third145Proof463
  · exact adaptive147Third145Proof464
  · exact adaptive147Third145Proof465
  · exact adaptive147Third145Proof466
  · exact adaptive147Third145Proof467
  · exact adaptive147Third145Proof468
  · exact adaptive147Third145Proof469
  · exact adaptive147Third145Proof470
  · exact adaptive147Third145Proof471
  · exact adaptive147Third145Proof472
  · exact adaptive147Third145Proof473
  · exact adaptive147Third145Proof474
  · exact adaptive147Third145Proof475
  · exact adaptive147Third145Proof476
  · exact adaptive147Third145Proof477
  · exact adaptive147Third145Proof478
  · exact adaptive147Third145Proof479
  · exact adaptive147Third145Proof480
  · exact adaptive147Third145Proof481
  · exact adaptive147Third145Proof482
  · exact adaptive147Third145Proof483
  · exact adaptive147Third145Proof484
  · exact adaptive147Third145Proof485

#print axioms adaptive147Third145Proof441

theorem adaptive147Third145Proof486 : runCachedNode 511 131618 Adaptive147Third145Node486 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 131618 Adaptive147Third145Node486 = [85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 131] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive147Third145Proof487
  · exact adaptive147Third145Proof488
  · exact adaptive147Third145Proof489
  · exact adaptive147Third145Proof490
  · exact adaptive147Third145Proof491
  · exact adaptive147Third145Proof492
  · exact adaptive147Third145Proof493
  · exact adaptive147Third145Proof494
  · exact adaptive147Third145Proof495
  · exact adaptive147Third145Proof496
  · exact adaptive147Third145Proof497
  · exact adaptive147Third145Proof498
  · exact adaptive147Third145Proof499
  · exact adaptive147Third145Proof500
  · exact adaptive147Third145Proof501
  · exact adaptive147Third145Proof502
  · exact adaptive147Third145Proof503
  · exact adaptive147Third145Proof504
  · exact adaptive147Third145Proof505
  · exact adaptive147Third145Proof506
  · exact adaptive147Third145Proof507
  · exact adaptive147Third145Proof508
  · exact adaptive147Third145Proof509
  · exact adaptive147Third145Proof510
  · exact adaptive147Third145Proof511
  · exact adaptive147Third145Proof512
  · exact adaptive147Third145Proof513
  · exact adaptive147Third145Proof514
  · exact adaptive147Third145Proof515
  · exact adaptive147Third145Proof516
  · exact adaptive147Third145Proof517
  · exact adaptive147Third145Proof518
  · exact adaptive147Third145Proof519
  · exact adaptive147Third145Proof520
  · exact adaptive147Third145Proof521
  · exact adaptive147Third145Proof522
  · exact adaptive147Third145Proof523
  · exact adaptive147Third145Proof524
  · exact adaptive147Third145Proof525
  · exact adaptive147Third145Proof526
  · exact adaptive147Third145Proof527
  · exact adaptive147Third145Proof528
  · exact adaptive147Third145Proof529
  · exact adaptive147Third145Proof530
  · exact adaptive147Third145Proof531
  · exact adaptive147Third145Proof532

#print axioms adaptive147Third145Proof486

theorem adaptive147Third145Proof359 : runCachedNode 511 131618 Adaptive147Third145Node359 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 131618 Adaptive147Third145Node359 = [99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 132, 133, 134, 135, 136, 137, 138] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive147Third145Proof360
  · exact adaptive147Third145Proof361
  · exact adaptive147Third145Proof362
  · exact adaptive147Third145Proof363
  · exact adaptive147Third145Proof364
  · exact adaptive147Third145Proof365
  · exact adaptive147Third145Proof366
  · exact adaptive147Third145Proof367
  · exact adaptive147Third145Proof368
  · exact adaptive147Third145Proof369
  · exact adaptive147Third145Proof370
  · exact adaptive147Third145Proof371
  · exact adaptive147Third145Proof372
  · exact adaptive147Third145Proof373
  · exact adaptive147Third145Proof374
  · exact adaptive147Third145Proof375
  · exact adaptive147Third145Proof376
  · exact adaptive147Third145Proof377
  · exact adaptive147Third145Proof378
  · exact adaptive147Third145Proof379
  · exact adaptive147Third145Proof380
  · exact adaptive147Third145Proof381
  · exact adaptive147Third145Proof382
  · exact adaptive147Third145Proof383
  · exact adaptive147Third145Proof384
  · exact adaptive147Third145Proof385
  · exact adaptive147Third145Proof386
  · exact adaptive147Third145Proof387
  · exact adaptive147Third145Proof388
  · exact adaptive147Third145Proof389
  · exact adaptive147Third145Proof390
  · exact adaptive147Third145Proof391
  · exact adaptive147Third145Proof392
  · exact adaptive147Third145Proof393
  · exact adaptive147Third145Proof394
  · exact adaptive147Third145Proof395
  · exact adaptive147Third145Proof396
  · exact adaptive147Third145Proof397
  · exact adaptive147Third145Proof441
  · exact adaptive147Third145Proof486

#print axioms adaptive147Third145Proof359

theorem adaptive147Third145Proof572 : runCachedNode 511 131618 Adaptive147Third145Node572 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 131618 Adaptive147Third145Node572 = [85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 131] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive147Third145Proof573
  · exact adaptive147Third145Proof574
  · exact adaptive147Third145Proof575
  · exact adaptive147Third145Proof576
  · exact adaptive147Third145Proof577
  · exact adaptive147Third145Proof578
  · exact adaptive147Third145Proof579
  · exact adaptive147Third145Proof580
  · exact adaptive147Third145Proof581
  · exact adaptive147Third145Proof582
  · exact adaptive147Third145Proof583
  · exact adaptive147Third145Proof584
  · exact adaptive147Third145Proof585
  · exact adaptive147Third145Proof586
  · exact adaptive147Third145Proof587
  · exact adaptive147Third145Proof588
  · exact adaptive147Third145Proof589
  · exact adaptive147Third145Proof590
  · exact adaptive147Third145Proof591
  · exact adaptive147Third145Proof592
  · exact adaptive147Third145Proof593
  · exact adaptive147Third145Proof594
  · exact adaptive147Third145Proof595
  · exact adaptive147Third145Proof596
  · exact adaptive147Third145Proof597
  · exact adaptive147Third145Proof598
  · exact adaptive147Third145Proof599
  · exact adaptive147Third145Proof600
  · exact adaptive147Third145Proof601
  · exact adaptive147Third145Proof602
  · exact adaptive147Third145Proof603
  · exact adaptive147Third145Proof604
  · exact adaptive147Third145Proof605
  · exact adaptive147Third145Proof606
  · exact adaptive147Third145Proof607
  · exact adaptive147Third145Proof608
  · exact adaptive147Third145Proof609
  · exact adaptive147Third145Proof610
  · exact adaptive147Third145Proof611
  · exact adaptive147Third145Proof612
  · exact adaptive147Third145Proof613
  · exact adaptive147Third145Proof614
  · exact adaptive147Third145Proof615
  · exact adaptive147Third145Proof616
  · exact adaptive147Third145Proof617
  · exact adaptive147Third145Proof618

#print axioms adaptive147Third145Proof572

theorem adaptive147Third145Proof619 : runCachedNode 511 131618 Adaptive147Third145Node619 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 131618 Adaptive147Third145Node619 = [85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 132] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive147Third145Proof620
  · exact adaptive147Third145Proof621
  · exact adaptive147Third145Proof622
  · exact adaptive147Third145Proof623
  · exact adaptive147Third145Proof624
  · exact adaptive147Third145Proof625
  · exact adaptive147Third145Proof626
  · exact adaptive147Third145Proof627
  · exact adaptive147Third145Proof628
  · exact adaptive147Third145Proof629
  · exact adaptive147Third145Proof630
  · exact adaptive147Third145Proof631
  · exact adaptive147Third145Proof632
  · exact adaptive147Third145Proof633
  · exact adaptive147Third145Proof634
  · exact adaptive147Third145Proof635
  · exact adaptive147Third145Proof636
  · exact adaptive147Third145Proof637
  · exact adaptive147Third145Proof638
  · exact adaptive147Third145Proof639
  · exact adaptive147Third145Proof640
  · exact adaptive147Third145Proof641
  · exact adaptive147Third145Proof642
  · exact adaptive147Third145Proof643
  · exact adaptive147Third145Proof644
  · exact adaptive147Third145Proof645
  · exact adaptive147Third145Proof646
  · exact adaptive147Third145Proof647
  · exact adaptive147Third145Proof648
  · exact adaptive147Third145Proof649
  · exact adaptive147Third145Proof650
  · exact adaptive147Third145Proof651
  · exact adaptive147Third145Proof652
  · exact adaptive147Third145Proof653
  · exact adaptive147Third145Proof654
  · exact adaptive147Third145Proof655
  · exact adaptive147Third145Proof656
  · exact adaptive147Third145Proof657
  · exact adaptive147Third145Proof658
  · exact adaptive147Third145Proof659
  · exact adaptive147Third145Proof660
  · exact adaptive147Third145Proof661
  · exact adaptive147Third145Proof662
  · exact adaptive147Third145Proof663
  · exact adaptive147Third145Proof664
  · exact adaptive147Third145Proof665
  · exact adaptive147Third145Proof666

#print axioms adaptive147Third145Proof619

end NineSeparatedSubsetSums
