import NineSeparatedSubsetSums.Adaptive147Third115State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third115Proof8 : runCachedNode 511 112835 Adaptive147Third115Node8 = false := by
  decide +kernel

#print axioms adaptive147Third115Proof8

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third115Proof7 : runCachedNode 511 112835 Adaptive147Third115Node7 = false := by
  decide +kernel

#print axioms adaptive147Third115Proof7

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third115Proof5 : runCachedNode 511 112835 Adaptive147Third115Node5 = false := by
  decide +kernel

#print axioms adaptive147Third115Proof5

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third115Proof4 : runCachedNode 511 112835 Adaptive147Third115Node4 = false := by
  decide +kernel

#print axioms adaptive147Third115Proof4

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third115Proof2 : runCachedNode 511 112835 Adaptive147Third115Node2 = false := by
  decide +kernel

#print axioms adaptive147Third115Proof2

end NineSeparatedSubsetSums
