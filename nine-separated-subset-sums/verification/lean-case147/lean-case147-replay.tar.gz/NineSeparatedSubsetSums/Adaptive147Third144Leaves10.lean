import NineSeparatedSubsetSums.Adaptive147Third144State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof535 : runCachedNode 511 131483 Adaptive147Third144Node535 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof535

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof743 : runCachedNode 511 131483 Adaptive147Third144Node743 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof743

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof2 : runCachedNode 511 131483 Adaptive147Third144Node2 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof2

end NineSeparatedSubsetSums
