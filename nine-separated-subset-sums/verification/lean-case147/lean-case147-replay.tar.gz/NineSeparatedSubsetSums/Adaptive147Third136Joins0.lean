import NineSeparatedSubsetSums.Adaptive147Third136State
import NineSeparatedSubsetSums.Adaptive147Third136Leaves3
import NineSeparatedSubsetSums.Adaptive147Third136Leaves11
import NineSeparatedSubsetSums.Adaptive147Third136Leaves2
import NineSeparatedSubsetSums.Adaptive147Third136Leaves1
import NineSeparatedSubsetSums.Adaptive147Third136Leaves5
import NineSeparatedSubsetSums.Adaptive147Third136Leaves10
import NineSeparatedSubsetSums.Adaptive147Third136Leaves9
import NineSeparatedSubsetSums.Adaptive147Third136Leaves7
import NineSeparatedSubsetSums.Adaptive147Third136Leaves8
import NineSeparatedSubsetSums.Adaptive147Third136Leaves6
import NineSeparatedSubsetSums.Adaptive147Third136Leaves4
import NineSeparatedSubsetSums.Adaptive147Third136Leaves12
import NineSeparatedSubsetSums.Adaptive147Third136Leaves0

namespace NineSeparatedSubsetSums

theorem adaptive147Third136Proof22 : runCachedNode 511 130369 Adaptive147Third136Node22 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130369 Adaptive147Third136Node22 = [104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 121, 122, 123, 124, 125, 126, 127, 128, 129] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive147Third136Proof23
  · exact adaptive147Third136Proof24
  · exact adaptive147Third136Proof25
  · exact adaptive147Third136Proof26
  · exact adaptive147Third136Proof27
  · exact adaptive147Third136Proof28
  · exact adaptive147Third136Proof29
  · exact adaptive147Third136Proof30
  · exact adaptive147Third136Proof31
  · exact adaptive147Third136Proof32
  · exact adaptive147Third136Proof33
  · exact adaptive147Third136Proof34
  · exact adaptive147Third136Proof35
  · exact adaptive147Third136Proof36
  · exact adaptive147Third136Proof37
  · exact adaptive147Third136Proof38
  · exact adaptive147Third136Proof39
  · exact adaptive147Third136Proof40
  · exact adaptive147Third136Proof41
  · exact adaptive147Third136Proof42
  · exact adaptive147Third136Proof43
  · exact adaptive147Third136Proof44
  · exact adaptive147Third136Proof45
  · exact adaptive147Third136Proof46

#print axioms adaptive147Third136Proof22

theorem adaptive147Third136Proof47 : runCachedNode 511 130369 Adaptive147Third136Node47 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130369 Adaptive147Third136Node47 = [103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 122, 123, 124, 125, 126, 127, 128, 129, 130] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive147Third136Proof48
  · exact adaptive147Third136Proof49
  · exact adaptive147Third136Proof50
  · exact adaptive147Third136Proof51
  · exact adaptive147Third136Proof52
  · exact adaptive147Third136Proof53
  · exact adaptive147Third136Proof54
  · exact adaptive147Third136Proof55
  · exact adaptive147Third136Proof56
  · exact adaptive147Third136Proof57
  · exact adaptive147Third136Proof58
  · exact adaptive147Third136Proof59
  · exact adaptive147Third136Proof60
  · exact adaptive147Third136Proof61
  · exact adaptive147Third136Proof62
  · exact adaptive147Third136Proof63
  · exact adaptive147Third136Proof64
  · exact adaptive147Third136Proof65
  · exact adaptive147Third136Proof66
  · exact adaptive147Third136Proof67
  · exact adaptive147Third136Proof68
  · exact adaptive147Third136Proof69
  · exact adaptive147Third136Proof70
  · exact adaptive147Third136Proof71
  · exact adaptive147Third136Proof72
  · exact adaptive147Third136Proof73

#print axioms adaptive147Third136Proof47

theorem adaptive147Third136Proof74 : runCachedNode 511 130369 Adaptive147Third136Node74 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130369 Adaptive147Third136Node74 = [103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 123, 124, 125, 126, 127, 128, 129, 130, 131] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive147Third136Proof75
  · exact adaptive147Third136Proof76
  · exact adaptive147Third136Proof77
  · exact adaptive147Third136Proof78
  · exact adaptive147Third136Proof79
  · exact adaptive147Third136Proof80
  · exact adaptive147Third136Proof81
  · exact adaptive147Third136Proof82
  · exact adaptive147Third136Proof83
  · exact adaptive147Third136Proof84
  · exact adaptive147Third136Proof85
  · exact adaptive147Third136Proof86
  · exact adaptive147Third136Proof87
  · exact adaptive147Third136Proof88
  · exact adaptive147Third136Proof89
  · exact adaptive147Third136Proof90
  · exact adaptive147Third136Proof91
  · exact adaptive147Third136Proof92
  · exact adaptive147Third136Proof93
  · exact adaptive147Third136Proof94
  · exact adaptive147Third136Proof95
  · exact adaptive147Third136Proof96
  · exact adaptive147Third136Proof97
  · exact adaptive147Third136Proof98
  · exact adaptive147Third136Proof99
  · exact adaptive147Third136Proof100
  · exact adaptive147Third136Proof101

#print axioms adaptive147Third136Proof74

theorem adaptive147Third136Proof102 : runCachedNode 511 130369 Adaptive147Third136Node102 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130369 Adaptive147Third136Node102 = [103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 124, 125, 126, 127, 128, 129, 130, 131, 132] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive147Third136Proof103
  · exact adaptive147Third136Proof104
  · exact adaptive147Third136Proof105
  · exact adaptive147Third136Proof106
  · exact adaptive147Third136Proof107
  · exact adaptive147Third136Proof108
  · exact adaptive147Third136Proof109
  · exact adaptive147Third136Proof110
  · exact adaptive147Third136Proof111
  · exact adaptive147Third136Proof112
  · exact adaptive147Third136Proof113
  · exact adaptive147Third136Proof114
  · exact adaptive147Third136Proof115
  · exact adaptive147Third136Proof116
  · exact adaptive147Third136Proof117
  · exact adaptive147Third136Proof118
  · exact adaptive147Third136Proof119
  · exact adaptive147Third136Proof120
  · exact adaptive147Third136Proof121
  · exact adaptive147Third136Proof122
  · exact adaptive147Third136Proof123
  · exact adaptive147Third136Proof124
  · exact adaptive147Third136Proof125
  · exact adaptive147Third136Proof126
  · exact adaptive147Third136Proof127
  · exact adaptive147Third136Proof128
  · exact adaptive147Third136Proof129
  · exact adaptive147Third136Proof130

#print axioms adaptive147Third136Proof102

theorem adaptive147Third136Proof0 : runCachedNode 511 130369 Adaptive147Third136Node0 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130369 Adaptive147Third136Node0 = [110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 132, 133, 134] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive147Third136Proof1
  · exact adaptive147Third136Proof2
  · exact adaptive147Third136Proof3
  · exact adaptive147Third136Proof4
  · exact adaptive147Third136Proof5
  · exact adaptive147Third136Proof6
  · exact adaptive147Third136Proof7
  · exact adaptive147Third136Proof8
  · exact adaptive147Third136Proof9
  · exact adaptive147Third136Proof10
  · exact adaptive147Third136Proof11
  · exact adaptive147Third136Proof12
  · exact adaptive147Third136Proof13
  · exact adaptive147Third136Proof14
  · exact adaptive147Third136Proof15
  · exact adaptive147Third136Proof16
  · exact adaptive147Third136Proof17
  · exact adaptive147Third136Proof18
  · exact adaptive147Third136Proof19
  · exact adaptive147Third136Proof20
  · exact adaptive147Third136Proof21
  · exact adaptive147Third136Proof22
  · exact adaptive147Third136Proof47
  · exact adaptive147Third136Proof74
  · exact adaptive147Third136Proof102

#print axioms adaptive147Third136Proof0

end NineSeparatedSubsetSums
