import NineSeparatedSubsetSums.Adaptive147Third141State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third141Proof73 : runCachedNode 511 131086 Adaptive147Third141Node73 = false := by
  decide +kernel

#print axioms adaptive147Third141Proof73

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third141Proof95 : runCachedNode 511 131086 Adaptive147Third141Node95 = false := by
  decide +kernel

#print axioms adaptive147Third141Proof95

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third141Proof96 : runCachedNode 511 131086 Adaptive147Third141Node96 = false := by
  decide +kernel

#print axioms adaptive147Third141Proof96

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third141Proof153 : runCachedNode 511 131086 Adaptive147Third141Node153 = false := by
  decide +kernel

#print axioms adaptive147Third141Proof153

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third141Proof254 : runCachedNode 511 131086 Adaptive147Third141Node254 = false := by
  decide +kernel

#print axioms adaptive147Third141Proof254

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third141Proof325 : runCachedNode 511 131086 Adaptive147Third141Node325 = false := by
  decide +kernel

#print axioms adaptive147Third141Proof325

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third141Proof154 : runCachedNode 511 131086 Adaptive147Third141Node154 = false := by
  decide +kernel

#print axioms adaptive147Third141Proof154

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third141Proof43 : runCachedNode 511 131086 Adaptive147Third141Node43 = false := by
  decide +kernel

#print axioms adaptive147Third141Proof43

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third141Proof69 : runCachedNode 511 131086 Adaptive147Third141Node69 = false := by
  decide +kernel

#print axioms adaptive147Third141Proof69

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third141Proof326 : runCachedNode 511 131086 Adaptive147Third141Node326 = false := by
  decide +kernel

#print axioms adaptive147Third141Proof326

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third141Proof256 : runCachedNode 511 131086 Adaptive147Third141Node256 = false := by
  decide +kernel

#print axioms adaptive147Third141Proof256

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third141Proof94 : runCachedNode 511 131086 Adaptive147Third141Node94 = false := by
  decide +kernel

#print axioms adaptive147Third141Proof94

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third141Proof221 : runCachedNode 511 131086 Adaptive147Third141Node221 = false := by
  decide +kernel

#print axioms adaptive147Third141Proof221

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third141Proof37 : runCachedNode 511 131086 Adaptive147Third141Node37 = false := by
  decide +kernel

#print axioms adaptive147Third141Proof37

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third141Proof136 : runCachedNode 511 131086 Adaptive147Third141Node136 = false := by
  decide +kernel

#print axioms adaptive147Third141Proof136

end NineSeparatedSubsetSums
