import NineSeparatedSubsetSums.Adaptive147Third136State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third136Proof19 : runCachedNode 511 130369 Adaptive147Third136Node19 = false := by
  decide +kernel

#print axioms adaptive147Third136Proof19

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third136Proof15 : runCachedNode 511 130369 Adaptive147Third136Node15 = false := by
  decide +kernel

#print axioms adaptive147Third136Proof15

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third136Proof29 : runCachedNode 511 130369 Adaptive147Third136Node29 = false := by
  decide +kernel

#print axioms adaptive147Third136Proof29

end NineSeparatedSubsetSums
