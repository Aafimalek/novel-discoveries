import NineSeparatedSubsetSums.Adaptive147Third144State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof19 : runCachedNode 511 131483 Adaptive147Third144Node19 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof19

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof135 : runCachedNode 511 131483 Adaptive147Third144Node135 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof135

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof141 : runCachedNode 511 131483 Adaptive147Third144Node141 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof141

end NineSeparatedSubsetSums
