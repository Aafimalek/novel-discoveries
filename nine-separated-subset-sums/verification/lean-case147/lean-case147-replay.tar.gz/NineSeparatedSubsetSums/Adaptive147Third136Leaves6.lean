import NineSeparatedSubsetSums.Adaptive147Third136State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third136Proof14 : runCachedNode 511 130369 Adaptive147Third136Node14 = false := by
  decide +kernel

#print axioms adaptive147Third136Proof14

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third136Proof127 : runCachedNode 511 130369 Adaptive147Third136Node127 = false := by
  decide +kernel

#print axioms adaptive147Third136Proof127

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third136Proof123 : runCachedNode 511 130369 Adaptive147Third136Node123 = false := by
  decide +kernel

#print axioms adaptive147Third136Proof123

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third136Proof122 : runCachedNode 511 130369 Adaptive147Third136Node122 = false := by
  decide +kernel

#print axioms adaptive147Third136Proof122

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third136Proof99 : runCachedNode 511 130369 Adaptive147Third136Node99 = false := by
  decide +kernel

#print axioms adaptive147Third136Proof99

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third136Proof118 : runCachedNode 511 130369 Adaptive147Third136Node118 = false := by
  decide +kernel

#print axioms adaptive147Third136Proof118

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third136Proof50 : runCachedNode 511 130369 Adaptive147Third136Node50 = false := by
  decide +kernel

#print axioms adaptive147Third136Proof50

end NineSeparatedSubsetSums
