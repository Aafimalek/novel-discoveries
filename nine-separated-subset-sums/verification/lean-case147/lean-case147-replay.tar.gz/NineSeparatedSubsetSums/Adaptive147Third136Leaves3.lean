import NineSeparatedSubsetSums.Adaptive147Third136State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third136Proof130 : runCachedNode 511 130369 Adaptive147Third136Node130 = false := by
  decide +kernel

#print axioms adaptive147Third136Proof130

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third136Proof16 : runCachedNode 511 130369 Adaptive147Third136Node16 = false := by
  decide +kernel

#print axioms adaptive147Third136Proof16

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third136Proof38 : runCachedNode 511 130369 Adaptive147Third136Node38 = false := by
  decide +kernel

#print axioms adaptive147Third136Proof38

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third136Proof23 : runCachedNode 511 130369 Adaptive147Third136Node23 = false := by
  decide +kernel

#print axioms adaptive147Third136Proof23

end NineSeparatedSubsetSums
