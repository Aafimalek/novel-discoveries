import NineSeparatedSubsetSums.Adaptive147Third107Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint147Checked

namespace NineSeparatedSubsetSums


theorem adaptive147Third107 : NoDescendingTailAfterThird 147 107 :=
  noDescendingThirdTail_of_cached 147 107 112835 (fun t ht nd => max148_second147_fourPoint_moment_bound (107::t) (by simp [ht]) nd) adaptive147Third107Proof0

#print axioms adaptive147Third107

end NineSeparatedSubsetSums
