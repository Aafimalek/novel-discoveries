import NineSeparatedSubsetSums.Adaptive147Third145State
import NineSeparatedSubsetSums.Adaptive147Third145Leaves63
import NineSeparatedSubsetSums.Adaptive147Third145Leaves60
import NineSeparatedSubsetSums.Adaptive147Third145Leaves59
import NineSeparatedSubsetSums.Adaptive147Third145Leaves58
import NineSeparatedSubsetSums.Adaptive147Third145Leaves57
import NineSeparatedSubsetSums.Adaptive147Third145Leaves56
import NineSeparatedSubsetSums.Adaptive147Third145Leaves55
import NineSeparatedSubsetSums.Adaptive147Third145Leaves53
import NineSeparatedSubsetSums.Adaptive147Third145Leaves51
import NineSeparatedSubsetSums.Adaptive147Third145Leaves50
import NineSeparatedSubsetSums.Adaptive147Third145Leaves49
import NineSeparatedSubsetSums.Adaptive147Third145Leaves48
import NineSeparatedSubsetSums.Adaptive147Third145Leaves40
import NineSeparatedSubsetSums.Adaptive147Third145Leaves47
import NineSeparatedSubsetSums.Adaptive147Third145Leaves44
import NineSeparatedSubsetSums.Adaptive147Third145Leaves42
import NineSeparatedSubsetSums.Adaptive147Third145Leaves27
import NineSeparatedSubsetSums.Adaptive147Third145Leaves34
import NineSeparatedSubsetSums.Adaptive147Third145Leaves20
import NineSeparatedSubsetSums.Adaptive147Third145Leaves26
import NineSeparatedSubsetSums.Adaptive147Third145Leaves22
import NineSeparatedSubsetSums.Adaptive147Third145Leaves18
import NineSeparatedSubsetSums.Adaptive147Third145Leaves62
import NineSeparatedSubsetSums.Adaptive147Third145Leaves54
import NineSeparatedSubsetSums.Adaptive147Third145Leaves52
import NineSeparatedSubsetSums.Adaptive147Third145Leaves43
import NineSeparatedSubsetSums.Adaptive147Third145Leaves39
import NineSeparatedSubsetSums.Adaptive147Third145Leaves36
import NineSeparatedSubsetSums.Adaptive147Third145Leaves35
import NineSeparatedSubsetSums.Adaptive147Third145Leaves33
import NineSeparatedSubsetSums.Adaptive147Third145Leaves32
import NineSeparatedSubsetSums.Adaptive147Third145Leaves30
import NineSeparatedSubsetSums.Adaptive147Third145Leaves25
import NineSeparatedSubsetSums.Adaptive147Third145Leaves8
import NineSeparatedSubsetSums.Adaptive147Third145Leaves19
import NineSeparatedSubsetSums.Adaptive147Third145Leaves13
import NineSeparatedSubsetSums.Adaptive147Third145Leaves16
import NineSeparatedSubsetSums.Adaptive147Third145Leaves17
import NineSeparatedSubsetSums.Adaptive147Third145Leaves14
import NineSeparatedSubsetSums.Adaptive147Third145Leaves9
import NineSeparatedSubsetSums.Adaptive147Third145Leaves5
import NineSeparatedSubsetSums.Adaptive147Third145Leaves1
import NineSeparatedSubsetSums.Adaptive147Third145Joins1
import NineSeparatedSubsetSums.Adaptive147Third145Leaves10
import NineSeparatedSubsetSums.Adaptive147Third145Leaves4
import NineSeparatedSubsetSums.Adaptive147Third145Leaves3
import NineSeparatedSubsetSums.Adaptive147Third145Leaves12
import NineSeparatedSubsetSums.Adaptive147Third145Leaves46
import NineSeparatedSubsetSums.Adaptive147Third145Leaves45
import NineSeparatedSubsetSums.Adaptive147Third145Leaves29
import NineSeparatedSubsetSums.Adaptive147Third145Leaves24
import NineSeparatedSubsetSums.Adaptive147Third145Leaves6
import NineSeparatedSubsetSums.Adaptive147Third145Leaves2
import NineSeparatedSubsetSums.Adaptive147Third145Joins0

namespace NineSeparatedSubsetSums

theorem adaptive147Third145Proof667 : runCachedNode 511 131618 Adaptive147Third145Node667 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 131618 Adaptive147Third145Node667 = [85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 133] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive147Third145Proof668
  · exact adaptive147Third145Proof669
  · exact adaptive147Third145Proof670
  · exact adaptive147Third145Proof671
  · exact adaptive147Third145Proof672
  · exact adaptive147Third145Proof673
  · exact adaptive147Third145Proof674
  · exact adaptive147Third145Proof675
  · exact adaptive147Third145Proof676
  · exact adaptive147Third145Proof677
  · exact adaptive147Third145Proof678
  · exact adaptive147Third145Proof679
  · exact adaptive147Third145Proof680
  · exact adaptive147Third145Proof681
  · exact adaptive147Third145Proof682
  · exact adaptive147Third145Proof683
  · exact adaptive147Third145Proof684
  · exact adaptive147Third145Proof685
  · exact adaptive147Third145Proof686
  · exact adaptive147Third145Proof687
  · exact adaptive147Third145Proof688
  · exact adaptive147Third145Proof689
  · exact adaptive147Third145Proof690
  · exact adaptive147Third145Proof691
  · exact adaptive147Third145Proof692
  · exact adaptive147Third145Proof693
  · exact adaptive147Third145Proof694
  · exact adaptive147Third145Proof695
  · exact adaptive147Third145Proof696
  · exact adaptive147Third145Proof697
  · exact adaptive147Third145Proof698
  · exact adaptive147Third145Proof699
  · exact adaptive147Third145Proof700
  · exact adaptive147Third145Proof701
  · exact adaptive147Third145Proof702
  · exact adaptive147Third145Proof703
  · exact adaptive147Third145Proof704
  · exact adaptive147Third145Proof705
  · exact adaptive147Third145Proof706
  · exact adaptive147Third145Proof707
  · exact adaptive147Third145Proof708
  · exact adaptive147Third145Proof709
  · exact adaptive147Third145Proof710
  · exact adaptive147Third145Proof711
  · exact adaptive147Third145Proof712
  · exact adaptive147Third145Proof713
  · exact adaptive147Third145Proof714
  · exact adaptive147Third145Proof715

#print axioms adaptive147Third145Proof667

theorem adaptive147Third145Proof533 : runCachedNode 511 131618 Adaptive147Third145Node533 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 131618 Adaptive147Third145Node533 = [99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 132, 133, 134, 135, 136, 137, 138, 139] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive147Third145Proof534
  · exact adaptive147Third145Proof535
  · exact adaptive147Third145Proof536
  · exact adaptive147Third145Proof537
  · exact adaptive147Third145Proof538
  · exact adaptive147Third145Proof539
  · exact adaptive147Third145Proof540
  · exact adaptive147Third145Proof541
  · exact adaptive147Third145Proof542
  · exact adaptive147Third145Proof543
  · exact adaptive147Third145Proof544
  · exact adaptive147Third145Proof545
  · exact adaptive147Third145Proof546
  · exact adaptive147Third145Proof547
  · exact adaptive147Third145Proof548
  · exact adaptive147Third145Proof549
  · exact adaptive147Third145Proof550
  · exact adaptive147Third145Proof551
  · exact adaptive147Third145Proof552
  · exact adaptive147Third145Proof553
  · exact adaptive147Third145Proof554
  · exact adaptive147Third145Proof555
  · exact adaptive147Third145Proof556
  · exact adaptive147Third145Proof557
  · exact adaptive147Third145Proof558
  · exact adaptive147Third145Proof559
  · exact adaptive147Third145Proof560
  · exact adaptive147Third145Proof561
  · exact adaptive147Third145Proof562
  · exact adaptive147Third145Proof563
  · exact adaptive147Third145Proof564
  · exact adaptive147Third145Proof565
  · exact adaptive147Third145Proof566
  · exact adaptive147Third145Proof567
  · exact adaptive147Third145Proof568
  · exact adaptive147Third145Proof569
  · exact adaptive147Third145Proof570
  · exact adaptive147Third145Proof571
  · exact adaptive147Third145Proof572
  · exact adaptive147Third145Proof619
  · exact adaptive147Third145Proof667

#print axioms adaptive147Third145Proof533

theorem adaptive147Third145Proof0 : runCachedNode 511 131618 Adaptive147Third145Node0 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 131618 Adaptive147Third145Node0 = [109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 132, 133, 134, 135, 136, 137, 138, 139, 140, 141, 142, 143] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive147Third145Proof1
  · exact adaptive147Third145Proof2
  · exact adaptive147Third145Proof3
  · exact adaptive147Third145Proof4
  · exact adaptive147Third145Proof5
  · exact adaptive147Third145Proof6
  · exact adaptive147Third145Proof7
  · exact adaptive147Third145Proof8
  · exact adaptive147Third145Proof9
  · exact adaptive147Third145Proof10
  · exact adaptive147Third145Proof11
  · exact adaptive147Third145Proof12
  · exact adaptive147Third145Proof13
  · exact adaptive147Third145Proof14
  · exact adaptive147Third145Proof15
  · exact adaptive147Third145Proof16
  · exact adaptive147Third145Proof17
  · exact adaptive147Third145Proof18
  · exact adaptive147Third145Proof19
  · exact adaptive147Third145Proof20
  · exact adaptive147Third145Proof21
  · exact adaptive147Third145Proof22
  · exact adaptive147Third145Proof23
  · exact adaptive147Third145Proof24
  · exact adaptive147Third145Proof52
  · exact adaptive147Third145Proof81
  · exact adaptive147Third145Proof111
  · exact adaptive147Third145Proof143
  · exact adaptive147Third145Proof176
  · exact adaptive147Third145Proof210
  · exact adaptive147Third145Proof245
  · exact adaptive147Third145Proof282
  · exact adaptive147Third145Proof320
  · exact adaptive147Third145Proof359
  · exact adaptive147Third145Proof533

#print axioms adaptive147Third145Proof0

end NineSeparatedSubsetSums
