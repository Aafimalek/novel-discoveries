import NineSeparatedSubsetSums.Adaptive147Third138State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third138Proof16 : runCachedNode 511 130657 Adaptive147Third138Node16 = false := by
  decide +kernel

#print axioms adaptive147Third138Proof16

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third138Proof92 : runCachedNode 511 130657 Adaptive147Third138Node92 = false := by
  decide +kernel

#print axioms adaptive147Third138Proof92

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third138Proof119 : runCachedNode 511 130657 Adaptive147Third138Node119 = false := by
  decide +kernel

#print axioms adaptive147Third138Proof119

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third138Proof115 : runCachedNode 511 130657 Adaptive147Third138Node115 = false := by
  decide +kernel

#print axioms adaptive147Third138Proof115

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third138Proof68 : runCachedNode 511 130657 Adaptive147Third138Node68 = false := by
  decide +kernel

#print axioms adaptive147Third138Proof68

end NineSeparatedSubsetSums
