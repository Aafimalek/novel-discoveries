import NineSeparatedSubsetSums.Adaptive147Third144State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof333 : runCachedNode 511 131483 Adaptive147Third144Node333 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof333

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof133 : runCachedNode 511 131483 Adaptive147Third144Node133 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof133

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof736 : runCachedNode 511 131483 Adaptive147Third144Node736 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof736

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof14 : runCachedNode 511 131483 Adaptive147Third144Node14 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof14

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third144Proof733 : runCachedNode 511 131483 Adaptive147Third144Node733 = false := by
  decide +kernel

#print axioms adaptive147Third144Proof733

end NineSeparatedSubsetSums
