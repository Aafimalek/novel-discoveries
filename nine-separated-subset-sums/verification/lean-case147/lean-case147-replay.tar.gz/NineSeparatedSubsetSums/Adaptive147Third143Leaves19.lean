import NineSeparatedSubsetSums.Adaptive147Third143State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third143Proof198 : runCachedNode 511 131344 Adaptive147Third143Node198 = false := by
  decide +kernel

#print axioms adaptive147Third143Proof198

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third143Proof261 : runCachedNode 511 131344 Adaptive147Third143Node261 = false := by
  decide +kernel

#print axioms adaptive147Third143Proof261

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third143Proof295 : runCachedNode 511 131344 Adaptive147Third143Node295 = false := by
  decide +kernel

#print axioms adaptive147Third143Proof295

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive147Third143Proof116 : runCachedNode 511 131344 Adaptive147Third143Node116 = false := by
  decide +kernel

#print axioms adaptive147Third143Proof116

end NineSeparatedSubsetSums
