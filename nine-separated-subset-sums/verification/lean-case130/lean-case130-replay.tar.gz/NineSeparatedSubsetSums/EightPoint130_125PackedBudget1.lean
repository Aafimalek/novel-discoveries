import NineSeparatedSubsetSums.EightPoint130_125PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct130_125_1_budget :
    FourPointNumeric.packedBudget 20 packedOct130_125_1 392 = 84620450 := by decide +kernel

#print axioms packedOct130_125_1_budget

end NineSeparatedSubsetSums
