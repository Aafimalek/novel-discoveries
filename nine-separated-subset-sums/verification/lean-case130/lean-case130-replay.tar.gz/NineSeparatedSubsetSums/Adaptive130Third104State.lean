import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive130Third104Node0 : CachedSearchNode :=
  ⟨4, 103, computeCenteredMask [148,130,104], 382, 49620⟩

end NineSeparatedSubsetSums
