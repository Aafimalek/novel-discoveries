import NineSeparatedSubsetSums.EightPoint130_127PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint130_127PackedAnchor0Part0 :
    ∀ j : Fin 120, 2304899 ≤ FourPointNumeric.octPackedCharge 130 127 20 packedOct130_127_0
      (2*((j.val : Int)+0)+1) := by decide +kernel

end NineSeparatedSubsetSums
