import NineSeparatedSubsetSums.EightPoint130_118PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint130_118PackedAnchor1Part1 :
    ∀ j : Fin 115, 2189077 ≤ FourPointNumeric.octPackedCharge 130 118 20 packedOct130_118_1
      (2*((j.val : Int)+120)+1) := by decide +kernel

end NineSeparatedSubsetSums
