import NineSeparatedSubsetSums.EightPoint130_123PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint130_123PackedAnchor0Part0 :
    ∀ j : Fin 120, 2334567 ≤ FourPointNumeric.octPackedCharge 130 123 20 packedOct130_123_0
      (2*((j.val : Int)+0)+1) := by decide +kernel

end NineSeparatedSubsetSums
