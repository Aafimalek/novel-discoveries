import NineSeparatedSubsetSums.EightPoint130_124PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint130_124PackedAnchor0Part1 :
    ∀ j : Fin 120, 2338802 ≤ FourPointNumeric.octPackedCharge 130 124 20 packedOct130_124_0
      (2*((j.val : Int)+120)+0) := by decide +kernel

end NineSeparatedSubsetSums
