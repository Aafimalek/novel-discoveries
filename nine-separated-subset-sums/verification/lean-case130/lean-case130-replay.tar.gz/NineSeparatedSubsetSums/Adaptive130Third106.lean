import NineSeparatedSubsetSums.Adaptive130Third106Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint130Checked

namespace NineSeparatedSubsetSums


theorem adaptive130Third106 : NoDescendingTailAfterThird 130 106 :=
  noDescendingThirdTail_of_cached 130 106 109846 (fun t ht nd => max148_second130_fourPoint_moment_bound (106::t) (by simp [ht]) nd) adaptive130Third106Proof0

#print axioms adaptive130Third106

end NineSeparatedSubsetSums
