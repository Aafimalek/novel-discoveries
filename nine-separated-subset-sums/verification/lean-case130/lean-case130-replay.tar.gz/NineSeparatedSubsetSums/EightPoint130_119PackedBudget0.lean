import NineSeparatedSubsetSums.EightPoint130_119PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct130_119_0_budget :
    FourPointNumeric.packedBudget 20 packedOct130_119_0 401 = 77107837 := by decide +kernel

#print axioms packedOct130_119_0_budget

end NineSeparatedSubsetSums
