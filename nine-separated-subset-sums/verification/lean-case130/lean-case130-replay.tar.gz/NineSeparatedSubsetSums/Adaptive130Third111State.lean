import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive130Third111Node0 : CachedSearchNode :=
  ⟨4, 110, computeCenteredMask [148,130,111], 389, 51125⟩

end NineSeparatedSubsetSums
