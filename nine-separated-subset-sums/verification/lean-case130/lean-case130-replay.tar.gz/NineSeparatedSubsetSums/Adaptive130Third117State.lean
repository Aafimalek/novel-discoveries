import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive130Third117Node0 : CachedSearchNode :=
  ⟨4, 116, computeCenteredMask [148,130,117], 395, 52493⟩

end NineSeparatedSubsetSums
