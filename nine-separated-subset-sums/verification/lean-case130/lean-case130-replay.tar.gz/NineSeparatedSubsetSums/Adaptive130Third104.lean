import NineSeparatedSubsetSums.Adaptive130Third104Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint130Checked

namespace NineSeparatedSubsetSums


theorem adaptive130Third104 : NoDescendingTailAfterThird 130 104 :=
  noDescendingThirdTail_of_cached 130 104 109846 (fun t ht nd => max148_second130_fourPoint_moment_bound (104::t) (by simp [ht]) nd) adaptive130Third104Proof0

#print axioms adaptive130Third104

end NineSeparatedSubsetSums
