import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive130Third110Node0 : CachedSearchNode :=
  ⟨4, 109, computeCenteredMask [148,130,110], 388, 50904⟩

end NineSeparatedSubsetSums
