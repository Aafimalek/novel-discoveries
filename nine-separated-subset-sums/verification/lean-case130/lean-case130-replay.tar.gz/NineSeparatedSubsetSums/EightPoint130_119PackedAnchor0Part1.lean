import NineSeparatedSubsetSums.EightPoint130_119PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint130_119PackedAnchor0Part1 :
    ∀ j : Fin 115, 2193896 ≤ FourPointNumeric.octPackedCharge 130 119 20 packedOct130_119_0
      (2*((j.val : Int)+120)+1) := by decide +kernel

end NineSeparatedSubsetSums
