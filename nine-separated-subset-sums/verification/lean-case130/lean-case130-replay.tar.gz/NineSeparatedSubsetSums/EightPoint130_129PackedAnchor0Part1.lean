import NineSeparatedSubsetSums.EightPoint130_129PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint130_129PackedAnchor0Part1 :
    ∀ j : Fin 120, 2326569 ≤ FourPointNumeric.octPackedCharge 130 129 20 packedOct130_129_0
      (2*((j.val : Int)+120)+1) := by decide +kernel

end NineSeparatedSubsetSums
