import NineSeparatedSubsetSums.Adaptive130Third116Joins0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint130Checked

namespace NineSeparatedSubsetSums


theorem adaptive130Third116 : NoDescendingTailAfterThird 130 116 :=
  noDescendingThirdTail_of_cached 130 116 109846 (fun t ht nd => max148_second130_fourPoint_moment_bound (116::t) (by simp [ht]) nd) adaptive130Third116Proof0

#print axioms adaptive130Third116

end NineSeparatedSubsetSums
