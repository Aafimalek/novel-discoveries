import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive130Third112Node0 : CachedSearchNode :=
  ⟨4, 111, computeCenteredMask [148,130,112], 390, 51348⟩

end NineSeparatedSubsetSums
