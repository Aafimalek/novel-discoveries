import NineSeparatedSubsetSums.EightPoint130_126PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct130_126_1_budget :
    FourPointNumeric.packedBudget 20 packedOct130_126_1 450 = 85325858 := by decide +kernel

#print axioms packedOct130_126_1_budget

end NineSeparatedSubsetSums
