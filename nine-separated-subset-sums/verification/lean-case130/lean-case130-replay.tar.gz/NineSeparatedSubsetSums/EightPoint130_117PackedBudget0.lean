import NineSeparatedSubsetSums.EightPoint130_117PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct130_117_0_budget :
    FourPointNumeric.packedBudget 20 packedOct130_117_0 467 = 76111988 := by decide +kernel

#print axioms packedOct130_117_0_budget

end NineSeparatedSubsetSums
