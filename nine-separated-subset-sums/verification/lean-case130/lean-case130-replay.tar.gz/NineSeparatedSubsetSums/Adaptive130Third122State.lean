import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive130Third122Node0 : CachedSearchNode :=
  ⟨4, 121, computeCenteredMask [148,130,122], 400, 53688⟩

end NineSeparatedSubsetSums
