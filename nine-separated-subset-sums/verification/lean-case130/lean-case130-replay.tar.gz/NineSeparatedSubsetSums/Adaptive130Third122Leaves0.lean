import NineSeparatedSubsetSums.Adaptive130Third122State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive130Third122Proof0 : runCachedNode 511 124099 Adaptive130Third122Node0 = false := by
  decide +kernel

#print axioms adaptive130Third122Proof0

end NineSeparatedSubsetSums
