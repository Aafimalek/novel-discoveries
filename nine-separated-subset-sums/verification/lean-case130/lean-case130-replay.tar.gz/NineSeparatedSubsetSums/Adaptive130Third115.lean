import NineSeparatedSubsetSums.Adaptive130Third115Joins0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint130Checked

namespace NineSeparatedSubsetSums


theorem adaptive130Third115 : NoDescendingTailAfterThird 130 115 :=
  noDescendingThirdTail_of_cached 130 115 109846 (fun t ht nd => max148_second130_fourPoint_moment_bound (115::t) (by simp [ht]) nd) adaptive130Third115Proof0

#print axioms adaptive130Third115

end NineSeparatedSubsetSums
