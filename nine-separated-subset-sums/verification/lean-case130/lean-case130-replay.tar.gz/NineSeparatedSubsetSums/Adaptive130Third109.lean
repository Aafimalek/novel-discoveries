import NineSeparatedSubsetSums.Adaptive130Third109Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint130Checked

namespace NineSeparatedSubsetSums


theorem adaptive130Third109 : NoDescendingTailAfterThird 130 109 :=
  noDescendingThirdTail_of_cached 130 109 109846 (fun t ht nd => max148_second130_fourPoint_moment_bound (109::t) (by simp [ht]) nd) adaptive130Third109Proof0

#print axioms adaptive130Third109

end NineSeparatedSubsetSums
