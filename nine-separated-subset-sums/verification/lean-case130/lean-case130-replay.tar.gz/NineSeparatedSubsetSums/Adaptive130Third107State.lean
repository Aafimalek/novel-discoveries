import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive130Third107Node0 : CachedSearchNode :=
  ⟨4, 106, computeCenteredMask [148,130,107], 385, 50253⟩

end NineSeparatedSubsetSums
