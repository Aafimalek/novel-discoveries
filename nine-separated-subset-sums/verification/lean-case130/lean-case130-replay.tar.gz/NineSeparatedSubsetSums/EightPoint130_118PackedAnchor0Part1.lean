import NineSeparatedSubsetSums.EightPoint130_118PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint130_118PackedAnchor0Part1 :
    ∀ j : Fin 116, 2189800 ≤ FourPointNumeric.octPackedCharge 130 118 20 packedOct130_118_0
      (2*((j.val : Int)+120)+0) := by decide +kernel

end NineSeparatedSubsetSums
