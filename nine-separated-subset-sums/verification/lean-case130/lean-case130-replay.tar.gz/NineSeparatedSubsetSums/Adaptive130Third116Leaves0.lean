import NineSeparatedSubsetSums.Adaptive130Third116State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive130Third116Proof15 : runCachedNode 511 109846 Adaptive130Third116Node15 = false := by
  decide +kernel

#print axioms adaptive130Third116Proof15

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive130Third116Proof14 : runCachedNode 511 109846 Adaptive130Third116Node14 = false := by
  decide +kernel

#print axioms adaptive130Third116Proof14

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive130Third116Proof13 : runCachedNode 511 109846 Adaptive130Third116Node13 = false := by
  decide +kernel

#print axioms adaptive130Third116Proof13

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive130Third116Proof7 : runCachedNode 511 109846 Adaptive130Third116Node7 = false := by
  decide +kernel

#print axioms adaptive130Third116Proof7

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive130Third116Proof3 : runCachedNode 511 109846 Adaptive130Third116Node3 = false := by
  decide +kernel

#print axioms adaptive130Third116Proof3

end NineSeparatedSubsetSums
