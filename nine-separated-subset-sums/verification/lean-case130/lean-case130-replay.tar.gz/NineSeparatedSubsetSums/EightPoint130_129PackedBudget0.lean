import NineSeparatedSubsetSums.EightPoint130_129PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct130_129_0_budget :
    FourPointNumeric.packedBudget 20 packedOct130_129_0 435 = 84552855 := by decide +kernel

#print axioms packedOct130_129_0_budget

end NineSeparatedSubsetSums
