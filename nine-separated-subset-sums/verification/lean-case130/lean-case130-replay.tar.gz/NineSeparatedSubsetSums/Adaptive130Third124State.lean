import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive130Third124Node0 : CachedSearchNode :=
  ⟨4, 123, computeCenteredMask [148,130,124], 402, 54180⟩

end NineSeparatedSubsetSums
