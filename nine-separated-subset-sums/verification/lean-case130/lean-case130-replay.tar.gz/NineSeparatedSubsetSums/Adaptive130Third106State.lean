import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive130Third106Node0 : CachedSearchNode :=
  ⟨4, 105, computeCenteredMask [148,130,106], 384, 50040⟩

end NineSeparatedSubsetSums
