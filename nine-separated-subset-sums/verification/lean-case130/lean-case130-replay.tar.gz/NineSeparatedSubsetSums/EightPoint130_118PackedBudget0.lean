import NineSeparatedSubsetSums.EightPoint130_118PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct130_118_0_budget :
    FourPointNumeric.packedBudget 20 packedOct130_118_0 465 = 76934166 := by decide +kernel

#print axioms packedOct130_118_0_budget

end NineSeparatedSubsetSums
