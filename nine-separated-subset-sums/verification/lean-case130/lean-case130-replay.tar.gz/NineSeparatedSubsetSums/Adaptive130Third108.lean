import NineSeparatedSubsetSums.Adaptive130Third108Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint130Checked

namespace NineSeparatedSubsetSums


theorem adaptive130Third108 : NoDescendingTailAfterThird 130 108 :=
  noDescendingThirdTail_of_cached 130 108 109846 (fun t ht nd => max148_second130_fourPoint_moment_bound (108::t) (by simp [ht]) nd) adaptive130Third108Proof0

#print axioms adaptive130Third108

end NineSeparatedSubsetSums
