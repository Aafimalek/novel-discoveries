import NineSeparatedSubsetSums.Adaptive130Third114State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive130Third114Proof12 : runCachedNode 511 109846 Adaptive130Third114Node12 = false := by
  decide +kernel

#print axioms adaptive130Third114Proof12

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive130Third114Proof13 : runCachedNode 511 109846 Adaptive130Third114Node13 = false := by
  decide +kernel

#print axioms adaptive130Third114Proof13

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive130Third114Proof11 : runCachedNode 511 109846 Adaptive130Third114Node11 = false := by
  decide +kernel

#print axioms adaptive130Third114Proof11

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive130Third114Proof10 : runCachedNode 511 109846 Adaptive130Third114Node10 = false := by
  decide +kernel

#print axioms adaptive130Third114Proof10

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive130Third114Proof9 : runCachedNode 511 109846 Adaptive130Third114Node9 = false := by
  decide +kernel

#print axioms adaptive130Third114Proof9

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive130Third114Proof8 : runCachedNode 511 109846 Adaptive130Third114Node8 = false := by
  decide +kernel

#print axioms adaptive130Third114Proof8

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive130Third114Proof5 : runCachedNode 511 109846 Adaptive130Third114Node5 = false := by
  decide +kernel

#print axioms adaptive130Third114Proof5

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive130Third114Proof4 : runCachedNode 511 109846 Adaptive130Third114Node4 = false := by
  decide +kernel

#print axioms adaptive130Third114Proof4

end NineSeparatedSubsetSums
