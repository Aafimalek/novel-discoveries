import NineSeparatedSubsetSums.Adaptive130Third123State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive130Third123Proof0 : runCachedNode 511 124486 Adaptive130Third123Node0 = false := by
  decide +kernel

#print axioms adaptive130Third123Proof0

end NineSeparatedSubsetSums
