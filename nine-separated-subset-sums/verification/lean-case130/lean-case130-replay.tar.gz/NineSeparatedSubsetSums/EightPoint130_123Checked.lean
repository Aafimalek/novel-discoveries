import NineSeparatedSubsetSums.EightPointPackedGeometry
import NineSeparatedSubsetSums.EightPoint130_123PackedBudget0
import NineSeparatedSubsetSums.EightPoint130_123PackedAnchor0Part0
import NineSeparatedSubsetSums.EightPoint130_123PackedAnchor0Part1
import NineSeparatedSubsetSums.EightPoint130_123PackedAnchor0Part2
import NineSeparatedSubsetSums.EightPoint130_123PackedBudget1
import NineSeparatedSubsetSums.EightPoint130_123PackedAnchor1Part0
import NineSeparatedSubsetSums.EightPoint130_123PackedAnchor1Part1
import NineSeparatedSubsetSums.EightPoint130_123PackedAnchor1Part2

namespace NineSeparatedSubsetSums

private theorem packedOct130_123Anchor0 :
  ∀ j : Fin 489, ((j.val : Int)+130+123)%2=0 →
    2334567 ≤ FourPointNumeric.octPackedCharge 130 123 20 packedOct130_123_0 (j.val : Int) := by
  intro j hj
  let k := (j.val-1)/2
  have hk : k < 244 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+1 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint130_123PackedAnchor0Part0 z
    rwa [he,hrep] at ht
  by_cases h1 : k < 240
  · let z : Fin 120 := ⟨k-120, by omega⟩
    have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
    have ht := eightPoint130_123PackedAnchor0Part1 z
    rwa [he,hrep] at ht
  let z : Fin 4 := ⟨k-240, by omega⟩
  have he : (z.val : Int)+240 = k := by dsimp [z] <;> omega
  have ht := eightPoint130_123PackedAnchor0Part2 z
  rwa [he,hrep] at ht

private theorem packedOct130_123Anchor1 :
  ∀ j : Fin 489, ((j.val : Int)+130+123)%2=1 →
    2337446 ≤ FourPointNumeric.octPackedCharge 130 123 20 packedOct130_123_1 (j.val : Int) := by
  intro j hj
  let k := (j.val-0)/2
  have hk : k < 245 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+0 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint130_123PackedAnchor1Part0 z
    rwa [he,hrep] at ht
  by_cases h1 : k < 240
  · let z : Fin 120 := ⟨k-120, by omega⟩
    have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
    have ht := eightPoint130_123PackedAnchor1Part1 z
    rwa [he,hrep] at ht
  let z : Fin 5 := ⟨k-240, by omega⟩
  have he : (z.val : Int)+240 = k := by dsimp [z] <;> omega
  have ht := eightPoint130_123PackedAnchor1Part2 z
  rwa [he,hrep] at ht

def packedOctCertificate130_123_0 : EightPointCertificate 130 123 0 124486 :=
  eightPointCertificateOfPacked 130 123 0 124486 2334567 20 packedOct130_123_0 491 489
    (by decide +kernel) (by decide) packedOct130_123Anchor0
    (by rw [packedOct130_123_0_budget]; decide)

def packedOctCertificate130_123_1 : EightPointCertificate 130 123 1 124486 :=
  eightPointCertificateOfPacked 130 123 1 124486 2337446 20 packedOct130_123_1 490 489
    (by decide +kernel) (by decide) packedOct130_123Anchor1
    (by rw [packedOct130_123_1_budget]; decide)

theorem max148_second130_third123_eightPoint_moment_bound (tail : List ℕ) (len : tail.length=6)
    (distinct : (natSubsetSums (148::130::123::tail)).Nodup) :
    124486 ≤ ((148::130::123::tail).map (· ^ 2)).sum := by
  apply eightPointNatMomentLower 130 123 124486 tail len distinct
  intro p hp
  by_cases h : p=0
  · subst p
    exact packedOctCertificate130_123_0
  · have he : p=1 := hp.resolve_left h
    subst p
    exact packedOctCertificate130_123_1

#print axioms max148_second130_third123_eightPoint_moment_bound

end NineSeparatedSubsetSums
