import NineSeparatedSubsetSums.Adaptive130Third114Joins0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint130Checked

namespace NineSeparatedSubsetSums


theorem adaptive130Third114 : NoDescendingTailAfterThird 130 114 :=
  noDescendingThirdTail_of_cached 130 114 109846 (fun t ht nd => max148_second130_fourPoint_moment_bound (114::t) (by simp [ht]) nd) adaptive130Third114Proof0

#print axioms adaptive130Third114

end NineSeparatedSubsetSums
