import NineSeparatedSubsetSums.Adaptive130Third119State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive130Third119Proof0 : runCachedNode 511 123636 Adaptive130Third119Node0 = false := by
  decide +kernel

#print axioms adaptive130Third119Proof0

end NineSeparatedSubsetSums
