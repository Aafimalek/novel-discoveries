import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive130Third108Node0 : CachedSearchNode :=
  ⟨4, 107, computeCenteredMask [148,130,108], 386, 50468⟩

end NineSeparatedSubsetSums
