import NineSeparatedSubsetSums.Adaptive130Third117State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive130Third117Proof0 : runCachedNode 511 123271 Adaptive130Third117Node0 = false := by
  decide +kernel

#print axioms adaptive130Third117Proof0

end NineSeparatedSubsetSums
