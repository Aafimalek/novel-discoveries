import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive130Third125Node0 : CachedSearchNode :=
  ⟨4, 124, computeCenteredMask [148,130,125], 403, 54429⟩

end NineSeparatedSubsetSums
