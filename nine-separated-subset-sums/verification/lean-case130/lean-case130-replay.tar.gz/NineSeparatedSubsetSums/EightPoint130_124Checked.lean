import NineSeparatedSubsetSums.EightPointPackedGeometry
import NineSeparatedSubsetSums.EightPoint130_124PackedBudget0
import NineSeparatedSubsetSums.EightPoint130_124PackedAnchor0Part0
import NineSeparatedSubsetSums.EightPoint130_124PackedAnchor0Part1
import NineSeparatedSubsetSums.EightPoint130_124PackedAnchor0Part2
import NineSeparatedSubsetSums.EightPoint130_124PackedBudget1
import NineSeparatedSubsetSums.EightPoint130_124PackedAnchor1Part0
import NineSeparatedSubsetSums.EightPoint130_124PackedAnchor1Part1
import NineSeparatedSubsetSums.EightPoint130_124PackedAnchor1Part2

namespace NineSeparatedSubsetSums

private theorem packedOct130_124Anchor0 :
  ∀ j : Fin 489, ((j.val : Int)+130+124)%2=0 →
    2338802 ≤ FourPointNumeric.octPackedCharge 130 124 20 packedOct130_124_0 (j.val : Int) := by
  intro j hj
  let k := (j.val-0)/2
  have hk : k < 245 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+0 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint130_124PackedAnchor0Part0 z
    rwa [he,hrep] at ht
  by_cases h1 : k < 240
  · let z : Fin 120 := ⟨k-120, by omega⟩
    have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
    have ht := eightPoint130_124PackedAnchor0Part1 z
    rwa [he,hrep] at ht
  let z : Fin 5 := ⟨k-240, by omega⟩
  have he : (z.val : Int)+240 = k := by dsimp [z] <;> omega
  have ht := eightPoint130_124PackedAnchor0Part2 z
  rwa [he,hrep] at ht

private theorem packedOct130_124Anchor1 :
  ∀ j : Fin 489, ((j.val : Int)+130+124)%2=1 →
    2338374 ≤ FourPointNumeric.octPackedCharge 130 124 20 packedOct130_124_1 (j.val : Int) := by
  intro j hj
  let k := (j.val-1)/2
  have hk : k < 244 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+1 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint130_124PackedAnchor1Part0 z
    rwa [he,hrep] at ht
  by_cases h1 : k < 240
  · let z : Fin 120 := ⟨k-120, by omega⟩
    have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
    have ht := eightPoint130_124PackedAnchor1Part1 z
    rwa [he,hrep] at ht
  let z : Fin 4 := ⟨k-240, by omega⟩
  have he : (z.val : Int)+240 = k := by dsimp [z] <;> omega
  have ht := eightPoint130_124PackedAnchor1Part2 z
  rwa [he,hrep] at ht

def packedOctCertificate130_124_0 : EightPointCertificate 130 124 0 124759 :=
  eightPointCertificateOfPacked 130 124 0 124759 2338802 20 packedOct130_124_0 273 489
    (by decide +kernel) (by decide) packedOct130_124Anchor0
    (by rw [packedOct130_124_0_budget]; decide)

def packedOctCertificate130_124_1 : EightPointCertificate 130 124 1 124759 :=
  eightPointCertificateOfPacked 130 124 1 124759 2338374 20 packedOct130_124_1 456 489
    (by decide +kernel) (by decide) packedOct130_124Anchor1
    (by rw [packedOct130_124_1_budget]; decide)

theorem max148_second130_third124_eightPoint_moment_bound (tail : List ℕ) (len : tail.length=6)
    (distinct : (natSubsetSums (148::130::124::tail)).Nodup) :
    124759 ≤ ((148::130::124::tail).map (· ^ 2)).sum := by
  apply eightPointNatMomentLower 130 124 124759 tail len distinct
  intro p hp
  by_cases h : p=0
  · subst p
    exact packedOctCertificate130_124_0
  · have he : p=1 := hp.resolve_left h
    subst p
    exact packedOctCertificate130_124_1

#print axioms max148_second130_third124_eightPoint_moment_bound

end NineSeparatedSubsetSums
