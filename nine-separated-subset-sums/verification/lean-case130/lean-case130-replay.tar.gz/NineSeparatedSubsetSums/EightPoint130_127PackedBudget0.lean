import NineSeparatedSubsetSums.EightPoint130_127PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct130_127_0_budget :
    FourPointNumeric.packedBudget 20 packedOct130_127_0 389 = 83364339 := by decide +kernel

#print axioms packedOct130_127_0_budget

end NineSeparatedSubsetSums
