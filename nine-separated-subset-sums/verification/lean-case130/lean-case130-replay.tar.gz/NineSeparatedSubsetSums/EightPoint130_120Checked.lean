import NineSeparatedSubsetSums.EightPointPackedGeometry
import NineSeparatedSubsetSums.EightPoint130_120PackedBudget0
import NineSeparatedSubsetSums.EightPoint130_120PackedAnchor0Part0
import NineSeparatedSubsetSums.EightPoint130_120PackedAnchor0Part1
import NineSeparatedSubsetSums.EightPoint130_120PackedBudget1
import NineSeparatedSubsetSums.EightPoint130_120PackedAnchor1Part0
import NineSeparatedSubsetSums.EightPoint130_120PackedAnchor1Part1

namespace NineSeparatedSubsetSums

private theorem packedOct130_120Anchor0 :
  ∀ j : Fin 474, ((j.val : Int)+130+120)%2=0 →
    2215766 ≤ FourPointNumeric.octPackedCharge 130 120 20 packedOct130_120_0 (j.val : Int) := by
  intro j hj
  let k := (j.val-0)/2
  have hk : k < 237 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+0 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint130_120PackedAnchor0Part0 z
    rwa [he,hrep] at ht
  let z : Fin 117 := ⟨k-120, by omega⟩
  have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
  have ht := eightPoint130_120PackedAnchor0Part1 z
  rwa [he,hrep] at ht

private theorem packedOct130_120Anchor1 :
  ∀ j : Fin 474, ((j.val : Int)+130+120)%2=1 →
    2215517 ≤ FourPointNumeric.octPackedCharge 130 120 20 packedOct130_120_1 (j.val : Int) := by
  intro j hj
  let k := (j.val-1)/2
  have hk : k < 237 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+1 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint130_120PackedAnchor1Part0 z
    rwa [he,hrep] at ht
  let z : Fin 117 := ⟨k-120, by omega⟩
  have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
  have ht := eightPoint130_120PackedAnchor1Part1 z
  rwa [he,hrep] at ht

def packedOctCertificate130_120_0 : EightPointCertificate 130 120 0 123716 :=
  eightPointCertificateOfPacked 130 120 0 123716 2215766 20 packedOct130_120_0 381 474
    (by decide +kernel) (by decide) packedOct130_120Anchor0
    (by rw [packedOct130_120_0_budget]; decide)

def packedOctCertificate130_120_1 : EightPointCertificate 130 120 1 123716 :=
  eightPointCertificateOfPacked 130 120 1 123716 2215517 20 packedOct130_120_1 380 474
    (by decide +kernel) (by decide) packedOct130_120Anchor1
    (by rw [packedOct130_120_1_budget]; decide)

theorem max148_second130_third120_eightPoint_moment_bound (tail : List ℕ) (len : tail.length=6)
    (distinct : (natSubsetSums (148::130::120::tail)).Nodup) :
    123716 ≤ ((148::130::120::tail).map (· ^ 2)).sum := by
  apply eightPointNatMomentLower 130 120 123716 tail len distinct
  intro p hp
  by_cases h : p=0
  · subst p
    exact packedOctCertificate130_120_0
  · have he : p=1 := hp.resolve_left h
    subst p
    exact packedOctCertificate130_120_1

#print axioms max148_second130_third120_eightPoint_moment_bound

end NineSeparatedSubsetSums
