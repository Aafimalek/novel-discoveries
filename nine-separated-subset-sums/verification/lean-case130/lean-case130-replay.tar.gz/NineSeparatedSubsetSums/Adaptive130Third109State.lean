import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive130Third109Node0 : CachedSearchNode :=
  ⟨4, 108, computeCenteredMask [148,130,109], 387, 50685⟩

end NineSeparatedSubsetSums
