import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive130Third126Node0 : CachedSearchNode :=
  ⟨4, 125, computeCenteredMask [148,130,126], 404, 54680⟩

end NineSeparatedSubsetSums
