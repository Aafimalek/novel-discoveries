import NineSeparatedSubsetSums.Adaptive130Third128State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive130Third128Proof16 : runCachedNode 511 125485 Adaptive130Third128Node16 = false := by
  decide +kernel

#print axioms adaptive130Third128Proof16

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive130Third128Proof17 : runCachedNode 511 125485 Adaptive130Third128Node17 = false := by
  decide +kernel

#print axioms adaptive130Third128Proof17

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive130Third128Proof15 : runCachedNode 511 125485 Adaptive130Third128Node15 = false := by
  decide +kernel

#print axioms adaptive130Third128Proof15

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive130Third128Proof14 : runCachedNode 511 125485 Adaptive130Third128Node14 = false := by
  decide +kernel

#print axioms adaptive130Third128Proof14

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive130Third128Proof13 : runCachedNode 511 125485 Adaptive130Third128Node13 = false := by
  decide +kernel

#print axioms adaptive130Third128Proof13

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive130Third128Proof11 : runCachedNode 511 125485 Adaptive130Third128Node11 = false := by
  decide +kernel

#print axioms adaptive130Third128Proof11

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive130Third128Proof5 : runCachedNode 511 125485 Adaptive130Third128Node5 = false := by
  decide +kernel

#print axioms adaptive130Third128Proof5

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive130Third128Proof4 : runCachedNode 511 125485 Adaptive130Third128Node4 = false := by
  decide +kernel

#print axioms adaptive130Third128Proof4

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive130Third128Proof3 : runCachedNode 511 125485 Adaptive130Third128Node3 = false := by
  decide +kernel

#print axioms adaptive130Third128Proof3

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive130Third128Proof2 : runCachedNode 511 125485 Adaptive130Third128Node2 = false := by
  decide +kernel

#print axioms adaptive130Third128Proof2

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive130Third128Proof1 : runCachedNode 511 125485 Adaptive130Third128Node1 = false := by
  decide +kernel

#print axioms adaptive130Third128Proof1

end NineSeparatedSubsetSums
