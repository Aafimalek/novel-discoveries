import NineSeparatedSubsetSums.FourPoint130PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem fourPoint130PackedAnchor1Part1 :
    ∀ j : Fin 110, 1005204 ≤ FourPointNumeric.packedCharge 130 19 packedWeight130_1
      (2*((j.val : Int)+120)+1) := by decide +kernel

end NineSeparatedSubsetSums
