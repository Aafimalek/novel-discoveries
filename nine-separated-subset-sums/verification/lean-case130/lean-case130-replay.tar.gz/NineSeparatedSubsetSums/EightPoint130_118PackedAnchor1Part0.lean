import NineSeparatedSubsetSums.EightPoint130_118PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint130_118PackedAnchor1Part0 :
    ∀ j : Fin 120, 2189077 ≤ FourPointNumeric.octPackedCharge 130 118 20 packedOct130_118_1
      (2*((j.val : Int)+0)+1) := by decide +kernel

end NineSeparatedSubsetSums
