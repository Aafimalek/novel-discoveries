import NineSeparatedSubsetSums.EightPoint130_119PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint130_119PackedAnchor1Part0 :
    ∀ j : Fin 120, 2194129 ≤ FourPointNumeric.octPackedCharge 130 119 20 packedOct130_119_1
      (2*((j.val : Int)+0)+0) := by decide +kernel

end NineSeparatedSubsetSums
