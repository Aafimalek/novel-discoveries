import NineSeparatedSubsetSums.Adaptive130Third105Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint130Checked

namespace NineSeparatedSubsetSums


theorem adaptive130Third105 : NoDescendingTailAfterThird 130 105 :=
  noDescendingThirdTail_of_cached 130 105 109846 (fun t ht nd => max148_second130_fourPoint_moment_bound (105::t) (by simp [ht]) nd) adaptive130Third105Proof0

#print axioms adaptive130Third105

end NineSeparatedSubsetSums
