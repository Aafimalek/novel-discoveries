import NineSeparatedSubsetSums.EightPointPackedGeometry
import NineSeparatedSubsetSums.EightPoint130_122PackedBudget0
import NineSeparatedSubsetSums.EightPoint130_122PackedAnchor0Part0
import NineSeparatedSubsetSums.EightPoint130_122PackedAnchor0Part1
import NineSeparatedSubsetSums.EightPoint130_122PackedAnchor0Part2
import NineSeparatedSubsetSums.EightPoint130_122PackedBudget1
import NineSeparatedSubsetSums.EightPoint130_122PackedAnchor1Part0
import NineSeparatedSubsetSums.EightPoint130_122PackedAnchor1Part1
import NineSeparatedSubsetSums.EightPoint130_122PackedAnchor1Part2

namespace NineSeparatedSubsetSums

private theorem packedOct130_122Anchor0 :
  ∀ j : Fin 490, ((j.val : Int)+130+122)%2=0 →
    2348000 ≤ FourPointNumeric.octPackedCharge 130 122 20 packedOct130_122_0 (j.val : Int) := by
  intro j hj
  let k := (j.val-0)/2
  have hk : k < 245 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+0 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint130_122PackedAnchor0Part0 z
    rwa [he,hrep] at ht
  by_cases h1 : k < 240
  · let z : Fin 120 := ⟨k-120, by omega⟩
    have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
    have ht := eightPoint130_122PackedAnchor0Part1 z
    rwa [he,hrep] at ht
  let z : Fin 5 := ⟨k-240, by omega⟩
  have he : (z.val : Int)+240 = k := by dsimp [z] <;> omega
  have ht := eightPoint130_122PackedAnchor0Part2 z
  rwa [he,hrep] at ht

private theorem packedOct130_122Anchor1 :
  ∀ j : Fin 490, ((j.val : Int)+130+122)%2=1 →
    2329116 ≤ FourPointNumeric.octPackedCharge 130 122 20 packedOct130_122_1 (j.val : Int) := by
  intro j hj
  let k := (j.val-1)/2
  have hk : k < 245 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+1 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint130_122PackedAnchor1Part0 z
    rwa [he,hrep] at ht
  by_cases h1 : k < 240
  · let z : Fin 120 := ⟨k-120, by omega⟩
    have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
    have ht := eightPoint130_122PackedAnchor1Part1 z
    rwa [he,hrep] at ht
  let z : Fin 5 := ⟨k-240, by omega⟩
  have he : (z.val : Int)+240 = k := by dsimp [z] <;> omega
  have ht := eightPoint130_122PackedAnchor1Part2 z
  rwa [he,hrep] at ht

def packedOctCertificate130_122_0 : EightPointCertificate 130 122 0 124099 :=
  eightPointCertificateOfPacked 130 122 0 124099 2348000 20 packedOct130_122_0 483 490
    (by decide +kernel) (by decide) packedOct130_122Anchor0
    (by rw [packedOct130_122_0_budget]; decide)

def packedOctCertificate130_122_1 : EightPointCertificate 130 122 1 124099 :=
  eightPointCertificateOfPacked 130 122 1 124099 2329116 20 packedOct130_122_1 486 490
    (by decide +kernel) (by decide) packedOct130_122Anchor1
    (by rw [packedOct130_122_1_budget]; decide)

theorem max148_second130_third122_eightPoint_moment_bound (tail : List ℕ) (len : tail.length=6)
    (distinct : (natSubsetSums (148::130::122::tail)).Nodup) :
    124099 ≤ ((148::130::122::tail).map (· ^ 2)).sum := by
  apply eightPointNatMomentLower 130 122 124099 tail len distinct
  intro p hp
  by_cases h : p=0
  · subst p
    exact packedOctCertificate130_122_0
  · have he : p=1 := hp.resolve_left h
    subst p
    exact packedOctCertificate130_122_1

#print axioms max148_second130_third122_eightPoint_moment_bound

end NineSeparatedSubsetSums
