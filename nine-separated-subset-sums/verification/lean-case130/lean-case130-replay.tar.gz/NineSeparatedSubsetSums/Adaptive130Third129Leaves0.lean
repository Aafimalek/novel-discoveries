import NineSeparatedSubsetSums.Adaptive130Third129State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive130Third129Proof17 : runCachedNode 511 125679 Adaptive130Third129Node17 = false := by
  decide +kernel

#print axioms adaptive130Third129Proof17

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive130Third129Proof16 : runCachedNode 511 125679 Adaptive130Third129Node16 = false := by
  decide +kernel

#print axioms adaptive130Third129Proof16

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive130Third129Proof15 : runCachedNode 511 125679 Adaptive130Third129Node15 = false := by
  decide +kernel

#print axioms adaptive130Third129Proof15

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive130Third129Proof14 : runCachedNode 511 125679 Adaptive130Third129Node14 = false := by
  decide +kernel

#print axioms adaptive130Third129Proof14

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive130Third129Proof11 : runCachedNode 511 125679 Adaptive130Third129Node11 = false := by
  decide +kernel

#print axioms adaptive130Third129Proof11

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive130Third129Proof3 : runCachedNode 511 125679 Adaptive130Third129Node3 = false := by
  decide +kernel

#print axioms adaptive130Third129Proof3

end NineSeparatedSubsetSums
