import NineSeparatedSubsetSums.EightPoint130_128PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint130_128PackedAnchor1Part1 :
    ∀ j : Fin 120, 2313080 ≤ FourPointNumeric.octPackedCharge 130 128 20 packedOct130_128_1
      (2*((j.val : Int)+120)+1) := by decide +kernel

end NineSeparatedSubsetSums
