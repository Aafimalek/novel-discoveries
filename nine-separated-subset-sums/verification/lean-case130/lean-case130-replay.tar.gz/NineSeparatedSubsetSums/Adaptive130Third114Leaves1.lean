import NineSeparatedSubsetSums.Adaptive130Third114State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive130Third114Proof7 : runCachedNode 511 109846 Adaptive130Third114Node7 = false := by
  decide +kernel

#print axioms adaptive130Third114Proof7

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive130Third114Proof6 : runCachedNode 511 109846 Adaptive130Third114Node6 = false := by
  decide +kernel

#print axioms adaptive130Third114Proof6

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive130Third114Proof3 : runCachedNode 511 109846 Adaptive130Third114Node3 = false := by
  decide +kernel

#print axioms adaptive130Third114Proof3

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive130Third114Proof2 : runCachedNode 511 109846 Adaptive130Third114Node2 = false := by
  decide +kernel

#print axioms adaptive130Third114Proof2

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive130Third114Proof1 : runCachedNode 511 109846 Adaptive130Third114Node1 = false := by
  decide +kernel

#print axioms adaptive130Third114Proof1

end NineSeparatedSubsetSums
