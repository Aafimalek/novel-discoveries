import NineSeparatedSubsetSums.EightPoint130_120PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct130_120_0_budget :
    FourPointNumeric.packedBudget 20 packedOct130_120_0 381 = 78466710 := by decide +kernel

#print axioms packedOct130_120_0_budget

end NineSeparatedSubsetSums
