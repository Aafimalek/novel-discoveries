import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive130Third120Node0 : CachedSearchNode :=
  ⟨4, 119, computeCenteredMask [148,130,120], 398, 53204⟩

end NineSeparatedSubsetSums
