import NineSeparatedSubsetSums.FourPoint130PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedWeight130_1_budget :
    FourPointNumeric.packedBudget 19 packedWeight130_1 376 = 72425088 := by decide +kernel

#print axioms packedWeight130_1_budget

end NineSeparatedSubsetSums
