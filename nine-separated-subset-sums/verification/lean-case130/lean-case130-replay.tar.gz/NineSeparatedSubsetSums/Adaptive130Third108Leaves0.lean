import NineSeparatedSubsetSums.Adaptive130Third108State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive130Third108Proof0 : runCachedNode 511 109846 Adaptive130Third108Node0 = false := by
  decide +kernel

#print axioms adaptive130Third108Proof0

end NineSeparatedSubsetSums
