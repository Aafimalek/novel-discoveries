import NineSeparatedSubsetSums.Adaptive130Third113Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint130Checked

namespace NineSeparatedSubsetSums


theorem adaptive130Third113 : NoDescendingTailAfterThird 130 113 :=
  noDescendingThirdTail_of_cached 130 113 109846 (fun t ht nd => max148_second130_fourPoint_moment_bound (113::t) (by simp [ht]) nd) adaptive130Third113Proof0

#print axioms adaptive130Third113

end NineSeparatedSubsetSums
