import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive130Third119Node0 : CachedSearchNode :=
  ⟨4, 118, computeCenteredMask [148,130,119], 397, 52965⟩

end NineSeparatedSubsetSums
