import NineSeparatedSubsetSums.EightPointPackedGeometry
import NineSeparatedSubsetSums.EightPoint130_128PackedBudget0
import NineSeparatedSubsetSums.EightPoint130_128PackedAnchor0Part0
import NineSeparatedSubsetSums.EightPoint130_128PackedAnchor0Part1
import NineSeparatedSubsetSums.EightPoint130_128PackedAnchor0Part2
import NineSeparatedSubsetSums.EightPoint130_128PackedBudget1
import NineSeparatedSubsetSums.EightPoint130_128PackedAnchor1Part0
import NineSeparatedSubsetSums.EightPoint130_128PackedAnchor1Part1
import NineSeparatedSubsetSums.EightPoint130_128PackedAnchor1Part2

namespace NineSeparatedSubsetSums

private theorem packedOct130_128Anchor0 :
  ∀ j : Fin 484, ((j.val : Int)+130+128)%2=0 →
    2314880 ≤ FourPointNumeric.octPackedCharge 130 128 20 packedOct130_128_0 (j.val : Int) := by
  intro j hj
  let k := (j.val-0)/2
  have hk : k < 242 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+0 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint130_128PackedAnchor0Part0 z
    rwa [he,hrep] at ht
  by_cases h1 : k < 240
  · let z : Fin 120 := ⟨k-120, by omega⟩
    have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
    have ht := eightPoint130_128PackedAnchor0Part1 z
    rwa [he,hrep] at ht
  let z : Fin 2 := ⟨k-240, by omega⟩
  have he : (z.val : Int)+240 = k := by dsimp [z] <;> omega
  have ht := eightPoint130_128PackedAnchor0Part2 z
  rwa [he,hrep] at ht

private theorem packedOct130_128Anchor1 :
  ∀ j : Fin 484, ((j.val : Int)+130+128)%2=1 →
    2313080 ≤ FourPointNumeric.octPackedCharge 130 128 20 packedOct130_128_1 (j.val : Int) := by
  intro j hj
  let k := (j.val-1)/2
  have hk : k < 242 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+1 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint130_128PackedAnchor1Part0 z
    rwa [he,hrep] at ht
  by_cases h1 : k < 240
  · let z : Fin 120 := ⟨k-120, by omega⟩
    have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
    have ht := eightPoint130_128PackedAnchor1Part1 z
    rwa [he,hrep] at ht
  let z : Fin 2 := ⟨k-240, by omega⟩
  have he : (z.val : Int)+240 = k := by dsimp [z] <;> omega
  have ht := eightPoint130_128PackedAnchor1Part2 z
  rwa [he,hrep] at ht

def packedOctCertificate130_128_0 : EightPointCertificate 130 128 0 125485 :=
  eightPointCertificateOfPacked 130 128 0 125485 2314880 20 packedOct130_128_0 447 484
    (by decide +kernel) (by decide) packedOct130_128Anchor0
    (by rw [packedOct130_128_0_budget]; decide)

def packedOctCertificate130_128_1 : EightPointCertificate 130 128 1 125485 :=
  eightPointCertificateOfPacked 130 128 1 125485 2313080 20 packedOct130_128_1 448 484
    (by decide +kernel) (by decide) packedOct130_128Anchor1
    (by rw [packedOct130_128_1_budget]; decide)

theorem max148_second130_third128_eightPoint_moment_bound (tail : List ℕ) (len : tail.length=6)
    (distinct : (natSubsetSums (148::130::128::tail)).Nodup) :
    125485 ≤ ((148::130::128::tail).map (· ^ 2)).sum := by
  apply eightPointNatMomentLower 130 128 125485 tail len distinct
  intro p hp
  by_cases h : p=0
  · subst p
    exact packedOctCertificate130_128_0
  · have he : p=1 := hp.resolve_left h
    subst p
    exact packedOctCertificate130_128_1

#print axioms max148_second130_third128_eightPoint_moment_bound

end NineSeparatedSubsetSums
