import NineSeparatedSubsetSums.EightPoint130_124PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct130_124_0_budget :
    FourPointNumeric.packedBudget 20 packedOct130_124_0 273 = 85807053 := by decide +kernel

#print axioms packedOct130_124_0_budget

end NineSeparatedSubsetSums
