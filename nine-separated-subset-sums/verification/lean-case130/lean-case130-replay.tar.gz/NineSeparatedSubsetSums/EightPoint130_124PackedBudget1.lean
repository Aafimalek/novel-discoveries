import NineSeparatedSubsetSums.EightPoint130_124PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct130_124_1_budget :
    FourPointNumeric.packedBudget 20 packedOct130_124_1 456 = 85779516 := by decide +kernel

#print axioms packedOct130_124_1_budget

end NineSeparatedSubsetSums
