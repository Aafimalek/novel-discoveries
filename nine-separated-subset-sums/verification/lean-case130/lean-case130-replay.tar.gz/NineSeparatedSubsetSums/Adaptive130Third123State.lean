import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive130Third123Node0 : CachedSearchNode :=
  ⟨4, 122, computeCenteredMask [148,130,123], 401, 53933⟩

end NineSeparatedSubsetSums
