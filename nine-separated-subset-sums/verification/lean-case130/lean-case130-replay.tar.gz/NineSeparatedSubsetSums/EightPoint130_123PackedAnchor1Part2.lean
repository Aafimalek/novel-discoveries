import NineSeparatedSubsetSums.EightPoint130_123PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint130_123PackedAnchor1Part2 :
    ∀ j : Fin 5, 2337446 ≤ FourPointNumeric.octPackedCharge 130 123 20 packedOct130_123_1
      (2*((j.val : Int)+240)+0) := by decide +kernel

end NineSeparatedSubsetSums
