import NineSeparatedSubsetSums.FourPoint130PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem fourPoint130PackedAnchor0Part1 :
    ∀ j : Fin 111, 1005216 ≤ FourPointNumeric.packedCharge 130 19 packedWeight130_0
      (2*((j.val : Int)+120)+0) := by decide +kernel

end NineSeparatedSubsetSums
