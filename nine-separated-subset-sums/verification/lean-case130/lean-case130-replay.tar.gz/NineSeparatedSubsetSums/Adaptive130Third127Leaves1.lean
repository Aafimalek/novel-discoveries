import NineSeparatedSubsetSums.Adaptive130Third127State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive130Third127Proof6 : runCachedNode 511 125292 Adaptive130Third127Node6 = false := by
  decide +kernel

#print axioms adaptive130Third127Proof6

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive130Third127Proof5 : runCachedNode 511 125292 Adaptive130Third127Node5 = false := by
  decide +kernel

#print axioms adaptive130Third127Proof5

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive130Third127Proof4 : runCachedNode 511 125292 Adaptive130Third127Node4 = false := by
  decide +kernel

#print axioms adaptive130Third127Proof4

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive130Third127Proof3 : runCachedNode 511 125292 Adaptive130Third127Node3 = false := by
  decide +kernel

#print axioms adaptive130Third127Proof3

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive130Third127Proof2 : runCachedNode 511 125292 Adaptive130Third127Node2 = false := by
  decide +kernel

#print axioms adaptive130Third127Proof2

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive130Third127Proof1 : runCachedNode 511 125292 Adaptive130Third127Node1 = false := by
  decide +kernel

#print axioms adaptive130Third127Proof1

end NineSeparatedSubsetSums
