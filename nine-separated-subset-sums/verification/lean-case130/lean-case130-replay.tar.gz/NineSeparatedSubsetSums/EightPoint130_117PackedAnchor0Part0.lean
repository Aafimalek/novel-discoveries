import NineSeparatedSubsetSums.EightPoint130_117PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint130_117PackedAnchor0Part0 :
    ∀ j : Fin 120, 2175416 ≤ FourPointNumeric.octPackedCharge 130 117 20 packedOct130_117_0
      (2*((j.val : Int)+0)+1) := by decide +kernel

end NineSeparatedSubsetSums
