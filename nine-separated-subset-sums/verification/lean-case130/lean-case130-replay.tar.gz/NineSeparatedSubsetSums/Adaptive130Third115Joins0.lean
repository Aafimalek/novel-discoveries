import NineSeparatedSubsetSums.Adaptive130Third115State
import NineSeparatedSubsetSums.Adaptive130Third115Leaves1
import NineSeparatedSubsetSums.Adaptive130Third115Leaves0

namespace NineSeparatedSubsetSums

theorem adaptive130Third115Proof0 : runCachedNode 511 109846 Adaptive130Third115Node0 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 109846 Adaptive130Third115Node0 = [101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive130Third115Proof1
  · exact adaptive130Third115Proof2
  · exact adaptive130Third115Proof3
  · exact adaptive130Third115Proof4
  · exact adaptive130Third115Proof5
  · exact adaptive130Third115Proof6
  · exact adaptive130Third115Proof7
  · exact adaptive130Third115Proof8
  · exact adaptive130Third115Proof9
  · exact adaptive130Third115Proof10
  · exact adaptive130Third115Proof11
  · exact adaptive130Third115Proof12
  · exact adaptive130Third115Proof13
  · exact adaptive130Third115Proof14

#print axioms adaptive130Third115Proof0

end NineSeparatedSubsetSums
