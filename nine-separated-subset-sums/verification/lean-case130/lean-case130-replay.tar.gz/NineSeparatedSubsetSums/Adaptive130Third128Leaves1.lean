import NineSeparatedSubsetSums.Adaptive130Third128State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive130Third128Proof12 : runCachedNode 511 125485 Adaptive130Third128Node12 = false := by
  decide +kernel

#print axioms adaptive130Third128Proof12

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive130Third128Proof10 : runCachedNode 511 125485 Adaptive130Third128Node10 = false := by
  decide +kernel

#print axioms adaptive130Third128Proof10

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive130Third128Proof9 : runCachedNode 511 125485 Adaptive130Third128Node9 = false := by
  decide +kernel

#print axioms adaptive130Third128Proof9

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive130Third128Proof8 : runCachedNode 511 125485 Adaptive130Third128Node8 = false := by
  decide +kernel

#print axioms adaptive130Third128Proof8

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive130Third128Proof7 : runCachedNode 511 125485 Adaptive130Third128Node7 = false := by
  decide +kernel

#print axioms adaptive130Third128Proof7

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive130Third128Proof6 : runCachedNode 511 125485 Adaptive130Third128Node6 = false := by
  decide +kernel

#print axioms adaptive130Third128Proof6

end NineSeparatedSubsetSums
