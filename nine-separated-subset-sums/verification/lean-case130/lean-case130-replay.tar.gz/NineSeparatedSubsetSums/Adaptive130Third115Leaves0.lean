import NineSeparatedSubsetSums.Adaptive130Third115State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive130Third115Proof14 : runCachedNode 511 109846 Adaptive130Third115Node14 = false := by
  decide +kernel

#print axioms adaptive130Third115Proof14

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive130Third115Proof12 : runCachedNode 511 109846 Adaptive130Third115Node12 = false := by
  decide +kernel

#print axioms adaptive130Third115Proof12

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive130Third115Proof13 : runCachedNode 511 109846 Adaptive130Third115Node13 = false := by
  decide +kernel

#print axioms adaptive130Third115Proof13

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive130Third115Proof11 : runCachedNode 511 109846 Adaptive130Third115Node11 = false := by
  decide +kernel

#print axioms adaptive130Third115Proof11

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive130Third115Proof6 : runCachedNode 511 109846 Adaptive130Third115Node6 = false := by
  decide +kernel

#print axioms adaptive130Third115Proof6

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive130Third115Proof4 : runCachedNode 511 109846 Adaptive130Third115Node4 = false := by
  decide +kernel

#print axioms adaptive130Third115Proof4

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive130Third115Proof3 : runCachedNode 511 109846 Adaptive130Third115Node3 = false := by
  decide +kernel

#print axioms adaptive130Third115Proof3

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive130Third115Proof2 : runCachedNode 511 109846 Adaptive130Third115Node2 = false := by
  decide +kernel

#print axioms adaptive130Third115Proof2

end NineSeparatedSubsetSums
