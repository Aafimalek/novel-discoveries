import NineSeparatedSubsetSums.Adaptive130Third127State
import NineSeparatedSubsetSums.Adaptive130Third127Leaves1
import NineSeparatedSubsetSums.Adaptive130Third127Leaves0

namespace NineSeparatedSubsetSums

theorem adaptive130Third127Proof0 : runCachedNode 511 125292 Adaptive130Third127Node0 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 125292 Adaptive130Third127Node0 = [111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive130Third127Proof1
  · exact adaptive130Third127Proof2
  · exact adaptive130Third127Proof3
  · exact adaptive130Third127Proof4
  · exact adaptive130Third127Proof5
  · exact adaptive130Third127Proof6
  · exact adaptive130Third127Proof7
  · exact adaptive130Third127Proof8
  · exact adaptive130Third127Proof9
  · exact adaptive130Third127Proof10
  · exact adaptive130Third127Proof11
  · exact adaptive130Third127Proof12
  · exact adaptive130Third127Proof13
  · exact adaptive130Third127Proof14
  · exact adaptive130Third127Proof15
  · exact adaptive130Third127Proof16

#print axioms adaptive130Third127Proof0

end NineSeparatedSubsetSums
