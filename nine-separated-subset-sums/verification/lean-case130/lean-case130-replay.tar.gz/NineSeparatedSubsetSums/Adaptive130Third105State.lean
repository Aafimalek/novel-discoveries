import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive130Third105Node0 : CachedSearchNode :=
  ⟨4, 104, computeCenteredMask [148,130,105], 383, 49829⟩

end NineSeparatedSubsetSums
