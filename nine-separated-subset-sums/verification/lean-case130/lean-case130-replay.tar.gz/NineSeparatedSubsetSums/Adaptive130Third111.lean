import NineSeparatedSubsetSums.Adaptive130Third111Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint130Checked

namespace NineSeparatedSubsetSums


theorem adaptive130Third111 : NoDescendingTailAfterThird 130 111 :=
  noDescendingThirdTail_of_cached 130 111 109846 (fun t ht nd => max148_second130_fourPoint_moment_bound (111::t) (by simp [ht]) nd) adaptive130Third111Proof0

#print axioms adaptive130Third111

end NineSeparatedSubsetSums
