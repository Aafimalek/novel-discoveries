import NineSeparatedSubsetSums.EightPoint130_127PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint130_127PackedAnchor1Part2 :
    ∀ j : Fin 2, 2304854 ≤ FourPointNumeric.octPackedCharge 130 127 20 packedOct130_127_1
      (2*((j.val : Int)+240)+0) := by decide +kernel

end NineSeparatedSubsetSums
