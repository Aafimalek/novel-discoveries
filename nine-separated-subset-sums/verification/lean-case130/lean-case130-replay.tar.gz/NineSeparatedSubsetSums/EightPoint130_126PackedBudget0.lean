import NineSeparatedSubsetSums.EightPoint130_126PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct130_126_0_budget :
    FourPointNumeric.packedBudget 20 packedOct130_126_0 383 = 85269728 := by decide +kernel

#print axioms packedOct130_126_0_budget

end NineSeparatedSubsetSums
