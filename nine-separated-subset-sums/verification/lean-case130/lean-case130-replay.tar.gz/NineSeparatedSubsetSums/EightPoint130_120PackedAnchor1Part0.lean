import NineSeparatedSubsetSums.EightPoint130_120PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint130_120PackedAnchor1Part0 :
    ∀ j : Fin 120, 2215517 ≤ FourPointNumeric.octPackedCharge 130 120 20 packedOct130_120_1
      (2*((j.val : Int)+0)+1) := by decide +kernel

end NineSeparatedSubsetSums
