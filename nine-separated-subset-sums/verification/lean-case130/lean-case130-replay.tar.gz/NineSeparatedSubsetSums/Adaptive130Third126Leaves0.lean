import NineSeparatedSubsetSums.Adaptive130Third126State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive130Third126Proof0 : runCachedNode 511 125088 Adaptive130Third126Node0 = false := by
  decide +kernel

#print axioms adaptive130Third126Proof0

end NineSeparatedSubsetSums
