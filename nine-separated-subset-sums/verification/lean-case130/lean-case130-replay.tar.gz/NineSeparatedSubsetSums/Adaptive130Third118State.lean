import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive130Third118Node0 : CachedSearchNode :=
  ⟨4, 117, computeCenteredMask [148,130,118], 396, 52728⟩

end NineSeparatedSubsetSums
