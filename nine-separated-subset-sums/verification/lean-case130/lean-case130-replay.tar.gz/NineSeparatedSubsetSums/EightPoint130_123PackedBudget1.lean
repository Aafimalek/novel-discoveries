import NineSeparatedSubsetSums.EightPoint130_123PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct130_123_1_budget :
    FourPointNumeric.packedBudget 20 packedOct130_123_1 490 = 85860174 := by decide +kernel

#print axioms packedOct130_123_1_budget

end NineSeparatedSubsetSums
