import NineSeparatedSubsetSums.EightPoint130_125PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint130_125PackedAnchor0Part1 :
    ∀ j : Fin 120, 2321951 ≤ FourPointNumeric.octPackedCharge 130 125 20 packedOct130_125_0
      (2*((j.val : Int)+120)+1) := by decide +kernel

end NineSeparatedSubsetSums
