import NineSeparatedSubsetSums.Adaptive130Third125State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive130Third125Proof0 : runCachedNode 511 124927 Adaptive130Third125Node0 = false := by
  decide +kernel

#print axioms adaptive130Third125Proof0

end NineSeparatedSubsetSums
