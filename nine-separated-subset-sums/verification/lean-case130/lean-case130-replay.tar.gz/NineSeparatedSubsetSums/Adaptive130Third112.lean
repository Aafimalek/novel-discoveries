import NineSeparatedSubsetSums.Adaptive130Third112Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint130Checked

namespace NineSeparatedSubsetSums


theorem adaptive130Third112 : NoDescendingTailAfterThird 130 112 :=
  noDescendingThirdTail_of_cached 130 112 109846 (fun t ht nd => max148_second130_fourPoint_moment_bound (112::t) (by simp [ht]) nd) adaptive130Third112Proof0

#print axioms adaptive130Third112

end NineSeparatedSubsetSums
