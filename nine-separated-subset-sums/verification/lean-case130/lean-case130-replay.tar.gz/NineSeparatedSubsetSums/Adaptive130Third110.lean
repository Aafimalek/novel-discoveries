import NineSeparatedSubsetSums.Adaptive130Third110Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint130Checked

namespace NineSeparatedSubsetSums


theorem adaptive130Third110 : NoDescendingTailAfterThird 130 110 :=
  noDescendingThirdTail_of_cached 130 110 109846 (fun t ht nd => max148_second130_fourPoint_moment_bound (110::t) (by simp [ht]) nd) adaptive130Third110Proof0

#print axioms adaptive130Third110

end NineSeparatedSubsetSums
