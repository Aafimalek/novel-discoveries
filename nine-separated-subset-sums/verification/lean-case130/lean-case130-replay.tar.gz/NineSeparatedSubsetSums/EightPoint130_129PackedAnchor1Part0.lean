import NineSeparatedSubsetSums.EightPoint130_129PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint130_129PackedAnchor1Part0 :
    ∀ j : Fin 120, 2325969 ≤ FourPointNumeric.octPackedCharge 130 129 20 packedOct130_129_1
      (2*((j.val : Int)+0)+0) := by decide +kernel

end NineSeparatedSubsetSums
