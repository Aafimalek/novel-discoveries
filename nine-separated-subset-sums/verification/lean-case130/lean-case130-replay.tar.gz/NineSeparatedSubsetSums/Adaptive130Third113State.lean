import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive130Third113Node0 : CachedSearchNode :=
  ⟨4, 112, computeCenteredMask [148,130,113], 391, 51573⟩

end NineSeparatedSubsetSums
