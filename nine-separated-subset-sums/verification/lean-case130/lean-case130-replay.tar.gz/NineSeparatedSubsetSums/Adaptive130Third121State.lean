import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive130Third121Node0 : CachedSearchNode :=
  ⟨4, 120, computeCenteredMask [148,130,121], 399, 53445⟩

end NineSeparatedSubsetSums
