import NineSeparatedSubsetSums.EightPoint130_122PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct130_122_0_budget :
    FourPointNumeric.packedBudget 20 packedOct130_122_0 483 = 86732847 := by decide +kernel

#print axioms packedOct130_122_0_budget

end NineSeparatedSubsetSums
