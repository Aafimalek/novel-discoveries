import NineSeparatedSubsetSums.EightPoint130_120PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint130_120PackedAnchor0Part1 :
    ∀ j : Fin 117, 2215766 ≤ FourPointNumeric.octPackedCharge 130 120 20 packedOct130_120_0
      (2*((j.val : Int)+120)+0) := by decide +kernel

end NineSeparatedSubsetSums
