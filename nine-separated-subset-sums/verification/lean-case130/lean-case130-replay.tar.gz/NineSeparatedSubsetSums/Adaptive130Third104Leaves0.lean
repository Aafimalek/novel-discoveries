import NineSeparatedSubsetSums.Adaptive130Third104State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive130Third104Proof0 : runCachedNode 511 109846 Adaptive130Third104Node0 = false := by
  decide +kernel

#print axioms adaptive130Third104Proof0

end NineSeparatedSubsetSums
