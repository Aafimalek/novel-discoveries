import NineSeparatedSubsetSums.EightPoint130_125PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint130_125PackedAnchor1Part1 :
    ∀ j : Fin 120, 2321608 ≤ FourPointNumeric.octPackedCharge 130 125 20 packedOct130_125_1
      (2*((j.val : Int)+120)+0) := by decide +kernel

end NineSeparatedSubsetSums
