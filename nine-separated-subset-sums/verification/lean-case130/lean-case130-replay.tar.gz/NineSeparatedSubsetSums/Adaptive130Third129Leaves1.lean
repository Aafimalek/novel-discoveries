import NineSeparatedSubsetSums.Adaptive130Third129State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive130Third129Proof13 : runCachedNode 511 125679 Adaptive130Third129Node13 = false := by
  decide +kernel

#print axioms adaptive130Third129Proof13

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive130Third129Proof12 : runCachedNode 511 125679 Adaptive130Third129Node12 = false := by
  decide +kernel

#print axioms adaptive130Third129Proof12

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive130Third129Proof10 : runCachedNode 511 125679 Adaptive130Third129Node10 = false := by
  decide +kernel

#print axioms adaptive130Third129Proof10

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive130Third129Proof9 : runCachedNode 511 125679 Adaptive130Third129Node9 = false := by
  decide +kernel

#print axioms adaptive130Third129Proof9

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive130Third129Proof8 : runCachedNode 511 125679 Adaptive130Third129Node8 = false := by
  decide +kernel

#print axioms adaptive130Third129Proof8

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive130Third129Proof7 : runCachedNode 511 125679 Adaptive130Third129Node7 = false := by
  decide +kernel

#print axioms adaptive130Third129Proof7

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive130Third129Proof6 : runCachedNode 511 125679 Adaptive130Third129Node6 = false := by
  decide +kernel

#print axioms adaptive130Third129Proof6

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive130Third129Proof5 : runCachedNode 511 125679 Adaptive130Third129Node5 = false := by
  decide +kernel

#print axioms adaptive130Third129Proof5

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive130Third129Proof4 : runCachedNode 511 125679 Adaptive130Third129Node4 = false := by
  decide +kernel

#print axioms adaptive130Third129Proof4

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive130Third129Proof1 : runCachedNode 511 125679 Adaptive130Third129Node1 = false := by
  decide +kernel

#print axioms adaptive130Third129Proof1

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive130Third129Proof2 : runCachedNode 511 125679 Adaptive130Third129Node2 = false := by
  decide +kernel

#print axioms adaptive130Third129Proof2

end NineSeparatedSubsetSums
