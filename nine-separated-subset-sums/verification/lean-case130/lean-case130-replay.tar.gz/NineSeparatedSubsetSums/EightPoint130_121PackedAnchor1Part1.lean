import NineSeparatedSubsetSums.EightPoint130_121PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint130_121PackedAnchor1Part1 :
    ∀ j : Fin 117, 2219528 ≤ FourPointNumeric.octPackedCharge 130 121 20 packedOct130_121_1
      (2*((j.val : Int)+120)+0) := by decide +kernel

end NineSeparatedSubsetSums
