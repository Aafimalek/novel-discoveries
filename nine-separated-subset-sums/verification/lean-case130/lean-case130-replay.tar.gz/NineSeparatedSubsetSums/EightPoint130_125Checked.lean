import NineSeparatedSubsetSums.EightPointPackedGeometry
import NineSeparatedSubsetSums.EightPoint130_125PackedBudget0
import NineSeparatedSubsetSums.EightPoint130_125PackedAnchor0Part0
import NineSeparatedSubsetSums.EightPoint130_125PackedAnchor0Part1
import NineSeparatedSubsetSums.EightPoint130_125PackedAnchor0Part2
import NineSeparatedSubsetSums.EightPoint130_125PackedBudget1
import NineSeparatedSubsetSums.EightPoint130_125PackedAnchor1Part0
import NineSeparatedSubsetSums.EightPoint130_125PackedAnchor1Part1
import NineSeparatedSubsetSums.EightPoint130_125PackedAnchor1Part2

namespace NineSeparatedSubsetSums

private theorem packedOct130_125Anchor0 :
  ∀ j : Fin 486, ((j.val : Int)+130+125)%2=0 →
    2321951 ≤ FourPointNumeric.octPackedCharge 130 125 20 packedOct130_125_0 (j.val : Int) := by
  intro j hj
  let k := (j.val-1)/2
  have hk : k < 243 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+1 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint130_125PackedAnchor0Part0 z
    rwa [he,hrep] at ht
  by_cases h1 : k < 240
  · let z : Fin 120 := ⟨k-120, by omega⟩
    have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
    have ht := eightPoint130_125PackedAnchor0Part1 z
    rwa [he,hrep] at ht
  let z : Fin 3 := ⟨k-240, by omega⟩
  have he : (z.val : Int)+240 = k := by dsimp [z] <;> omega
  have ht := eightPoint130_125PackedAnchor0Part2 z
  rwa [he,hrep] at ht

private theorem packedOct130_125Anchor1 :
  ∀ j : Fin 486, ((j.val : Int)+130+125)%2=1 →
    2321608 ≤ FourPointNumeric.octPackedCharge 130 125 20 packedOct130_125_1 (j.val : Int) := by
  intro j hj
  let k := (j.val-0)/2
  have hk : k < 243 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+0 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint130_125PackedAnchor1Part0 z
    rwa [he,hrep] at ht
  by_cases h1 : k < 240
  · let z : Fin 120 := ⟨k-120, by omega⟩
    have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
    have ht := eightPoint130_125PackedAnchor1Part1 z
    rwa [he,hrep] at ht
  let z : Fin 3 := ⟨k-240, by omega⟩
  have he : (z.val : Int)+240 = k := by dsimp [z] <;> omega
  have ht := eightPoint130_125PackedAnchor1Part2 z
  rwa [he,hrep] at ht

def packedOctCertificate130_125_0 : EightPointCertificate 130 125 0 124927 :=
  eightPointCertificateOfPacked 130 125 0 124927 2321951 20 packedOct130_125_0 391 486
    (by decide +kernel) (by decide) packedOct130_125Anchor0
    (by rw [packedOct130_125_0_budget]; decide)

def packedOctCertificate130_125_1 : EightPointCertificate 130 125 1 124927 :=
  eightPointCertificateOfPacked 130 125 1 124927 2321608 20 packedOct130_125_1 392 486
    (by decide +kernel) (by decide) packedOct130_125Anchor1
    (by rw [packedOct130_125_1_budget]; decide)

theorem max148_second130_third125_eightPoint_moment_bound (tail : List ℕ) (len : tail.length=6)
    (distinct : (natSubsetSums (148::130::125::tail)).Nodup) :
    124927 ≤ ((148::130::125::tail).map (· ^ 2)).sum := by
  apply eightPointNatMomentLower 130 125 124927 tail len distinct
  intro p hp
  by_cases h : p=0
  · subst p
    exact packedOctCertificate130_125_0
  · have he : p=1 := hp.resolve_left h
    subst p
    exact packedOctCertificate130_125_1

#print axioms max148_second130_third125_eightPoint_moment_bound

end NineSeparatedSubsetSums
