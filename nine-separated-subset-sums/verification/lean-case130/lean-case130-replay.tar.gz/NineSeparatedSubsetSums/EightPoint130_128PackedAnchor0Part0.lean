import NineSeparatedSubsetSums.EightPoint130_128PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint130_128PackedAnchor0Part0 :
    ∀ j : Fin 120, 2314880 ≤ FourPointNumeric.octPackedCharge 130 128 20 packedOct130_128_0
      (2*((j.val : Int)+0)+0) := by decide +kernel

end NineSeparatedSubsetSums
