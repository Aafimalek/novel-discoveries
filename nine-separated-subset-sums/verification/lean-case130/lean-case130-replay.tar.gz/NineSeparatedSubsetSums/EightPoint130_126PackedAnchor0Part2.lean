import NineSeparatedSubsetSums.EightPoint130_126PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint130_126PackedAnchor0Part2 :
    ∀ j : Fin 4, 2333040 ≤ FourPointNumeric.octPackedCharge 130 126 20 packedOct130_126_0
      (2*((j.val : Int)+240)+0) := by decide +kernel

end NineSeparatedSubsetSums
