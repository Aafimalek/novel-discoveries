import NineSeparatedSubsetSums.Adaptive130Third121State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive130Third121Proof0 : runCachedNode 511 123739 Adaptive130Third121Node0 = false := by
  decide +kernel

#print axioms adaptive130Third121Proof0

end NineSeparatedSubsetSums
