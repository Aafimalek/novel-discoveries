import NineSeparatedSubsetSums.EightPoint130_117PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint130_117PackedAnchor1Part1 :
    ∀ j : Fin 115, 2175017 ≤ FourPointNumeric.octPackedCharge 130 117 20 packedOct130_117_1
      (2*((j.val : Int)+120)+0) := by decide +kernel

end NineSeparatedSubsetSums
