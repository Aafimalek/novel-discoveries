import NineSeparatedSubsetSums.Adaptive130Third115State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive130Third115Proof10 : runCachedNode 511 109846 Adaptive130Third115Node10 = false := by
  decide +kernel

#print axioms adaptive130Third115Proof10

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive130Third115Proof9 : runCachedNode 511 109846 Adaptive130Third115Node9 = false := by
  decide +kernel

#print axioms adaptive130Third115Proof9

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive130Third115Proof8 : runCachedNode 511 109846 Adaptive130Third115Node8 = false := by
  decide +kernel

#print axioms adaptive130Third115Proof8

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive130Third115Proof7 : runCachedNode 511 109846 Adaptive130Third115Node7 = false := by
  decide +kernel

#print axioms adaptive130Third115Proof7

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive130Third115Proof5 : runCachedNode 511 109846 Adaptive130Third115Node5 = false := by
  decide +kernel

#print axioms adaptive130Third115Proof5

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive130Third115Proof1 : runCachedNode 511 109846 Adaptive130Third115Node1 = false := by
  decide +kernel

#print axioms adaptive130Third115Proof1

end NineSeparatedSubsetSums
