import NineSeparatedSubsetSums.EightPoint130_122PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint130_122PackedAnchor0Part1 :
    ∀ j : Fin 120, 2348000 ≤ FourPointNumeric.octPackedCharge 130 122 20 packedOct130_122_0
      (2*((j.val : Int)+120)+0) := by decide +kernel

end NineSeparatedSubsetSums
