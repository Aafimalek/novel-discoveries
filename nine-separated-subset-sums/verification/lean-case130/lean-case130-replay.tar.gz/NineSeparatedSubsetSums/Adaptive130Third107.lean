import NineSeparatedSubsetSums.Adaptive130Third107Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint130Checked

namespace NineSeparatedSubsetSums


theorem adaptive130Third107 : NoDescendingTailAfterThird 130 107 :=
  noDescendingThirdTail_of_cached 130 107 109846 (fun t ht nd => max148_second130_fourPoint_moment_bound (107::t) (by simp [ht]) nd) adaptive130Third107Proof0

#print axioms adaptive130Third107

end NineSeparatedSubsetSums
