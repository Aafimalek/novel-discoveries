import NineSeparatedSubsetSums.Adaptive130Third124State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive130Third124Proof0 : runCachedNode 511 124759 Adaptive130Third124Node0 = false := by
  decide +kernel

#print axioms adaptive130Third124Proof0

end NineSeparatedSubsetSums
