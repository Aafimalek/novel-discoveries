import NineSeparatedSubsetSums.FourPointPackedGeometry
import NineSeparatedSubsetSums.FourPoint130PackedBudget0
import NineSeparatedSubsetSums.FourPoint130PackedAnchor0Part0
import NineSeparatedSubsetSums.FourPoint130PackedAnchor0Part1
import NineSeparatedSubsetSums.FourPoint130PackedBudget1
import NineSeparatedSubsetSums.FourPoint130PackedAnchor1Part0
import NineSeparatedSubsetSums.FourPoint130PackedAnchor1Part1

namespace NineSeparatedSubsetSums

private theorem packed130Anchor0 :
  ∀ j : Fin 461, ((j.val : Int)+130)%2=0 →
    1005216 ≤ FourPointNumeric.packedCharge 130 19 packedWeight130_0 (j.val : Int) := by
  intro j hj
  let k := (j.val-0)/2
  have hk : k < 231 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+0 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := fourPoint130PackedAnchor0Part0 z
    rwa [he,hrep] at ht
  let z : Fin 111 := ⟨k-120, by omega⟩
  have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
  have ht := fourPoint130PackedAnchor0Part1 z
  rwa [he,hrep] at ht

private theorem packed130Anchor1 :
  ∀ j : Fin 461, ((j.val : Int)+130)%2=1 →
    1005204 ≤ FourPointNumeric.packedCharge 130 19 packedWeight130_1 (j.val : Int) := by
  intro j hj
  let k := (j.val-1)/2
  have hk : k < 230 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+1 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := fourPoint130PackedAnchor1Part0 z
    rwa [he,hrep] at ht
  let z : Fin 110 := ⟨k-120, by omega⟩
  have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
  have ht := fourPoint130PackedAnchor1Part1 z
  rwa [he,hrep] at ht

def packedCertificate130_0 : FourPointCertificate 130 0 109846 :=
  fourPointCertificateOfPacked 130 0 109846 1005216 19 packedWeight130_0 445 461
    (by decide +kernel) (by decide) (by decide) packed130Anchor0
    (by rw [packedWeight130_0_budget]; decide)

def packedCertificate130_1 : FourPointCertificate 130 1 109846 :=
  fourPointCertificateOfPacked 130 1 109846 1005204 19 packedWeight130_1 376 461
    (by decide +kernel) (by decide) (by decide) packed130Anchor1
    (by rw [packedWeight130_1_budget]; decide)

theorem max148_second130_fourPoint_moment_bound (tail : List ℕ) (len : tail.length=7)
    (distinct : (natSubsetSums (148::130::tail)).Nodup) :
    109846 ≤ ((148::130::tail).map (· ^ 2)).sum := by
  apply fourPointNatMomentLower 130 109846 tail len distinct
  intro p hp
  by_cases h : p=0
  · subst p
    exact packedCertificate130_0
  · have he : p=1 := hp.resolve_left h
    subst p
    exact packedCertificate130_1

#print axioms max148_second130_fourPoint_moment_bound

end NineSeparatedSubsetSums
