import NineSeparatedSubsetSums.EightPoint130_123PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct130_123_0_budget :
    FourPointNumeric.packedBudget 20 packedOct130_123_0 491 = 85675789 := by decide +kernel

#print axioms packedOct130_123_0_budget

end NineSeparatedSubsetSums
