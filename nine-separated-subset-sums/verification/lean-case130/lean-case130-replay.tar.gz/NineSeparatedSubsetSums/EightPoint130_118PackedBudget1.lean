import NineSeparatedSubsetSums.EightPoint130_118PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct130_118_1_budget :
    FourPointNumeric.packedBudget 20 packedOct130_118_1 464 = 76887784 := by decide +kernel

#print axioms packedOct130_118_1_budget

end NineSeparatedSubsetSums
