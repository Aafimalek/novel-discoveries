import NineSeparatedSubsetSums.EightPoint130_124PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint130_124PackedAnchor1Part0 :
    ∀ j : Fin 120, 2338374 ≤ FourPointNumeric.octPackedCharge 130 124 20 packedOct130_124_1
      (2*((j.val : Int)+0)+1) := by decide +kernel

end NineSeparatedSubsetSums
