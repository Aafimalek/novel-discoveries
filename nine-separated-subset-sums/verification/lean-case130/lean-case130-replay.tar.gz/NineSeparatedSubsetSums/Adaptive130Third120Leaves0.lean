import NineSeparatedSubsetSums.Adaptive130Third120State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive130Third120Proof0 : runCachedNode 511 123716 Adaptive130Third120Node0 = false := by
  decide +kernel

#print axioms adaptive130Third120Proof0

end NineSeparatedSubsetSums
