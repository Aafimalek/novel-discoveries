import NineSeparatedSubsetSums.Adaptive130Third118State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive130Third118Proof0 : runCachedNode 511 123463 Adaptive130Third118Node0 = false := by
  decide +kernel

#print axioms adaptive130Third118Proof0

end NineSeparatedSubsetSums
