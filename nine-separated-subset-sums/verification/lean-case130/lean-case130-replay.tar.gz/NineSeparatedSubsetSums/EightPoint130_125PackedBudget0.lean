import NineSeparatedSubsetSums.EightPoint130_125PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct130_125_0_budget :
    FourPointNumeric.packedBudget 20 packedOct130_125_0 391 = 84642004 := by decide +kernel

#print axioms packedOct130_125_0_budget

end NineSeparatedSubsetSums
