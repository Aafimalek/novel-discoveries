import NineSeparatedSubsetSums.EightPoint123_119PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct123_119_1_budget :
    FourPointNumeric.packedBudget 20 packedOct123_119_1 500 = 77504018 := by decide +kernel

#print axioms packedOct123_119_1_budget

end NineSeparatedSubsetSums
