import NineSeparatedSubsetSums.Adaptive123Third113Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint123Checked

namespace NineSeparatedSubsetSums


theorem adaptive123Third113 : NoDescendingTailAfterThird 123 113 :=
  noDescendingThirdTail_of_cached 123 113 109206 (fun t ht nd => max148_second123_fourPoint_moment_bound (113::t) (by simp [ht]) nd) adaptive123Third113Proof0

#print axioms adaptive123Third113

end NineSeparatedSubsetSums
