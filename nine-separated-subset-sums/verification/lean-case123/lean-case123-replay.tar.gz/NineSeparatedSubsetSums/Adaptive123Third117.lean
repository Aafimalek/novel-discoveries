import NineSeparatedSubsetSums.Adaptive123Third117Joins0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint123Checked

namespace NineSeparatedSubsetSums


theorem adaptive123Third117 : NoDescendingTailAfterThird 123 117 :=
  noDescendingThirdTail_of_cached 123 117 109206 (fun t ht nd => max148_second123_fourPoint_moment_bound (117::t) (by simp [ht]) nd) adaptive123Third117Proof0

#print axioms adaptive123Third117

end NineSeparatedSubsetSums
