import NineSeparatedSubsetSums.FourPoint123PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedWeight123_0_budget :
    FourPointNumeric.packedBudget 20 packedWeight123_0 499 = 83353344 := by decide +kernel

#print axioms packedWeight123_0_budget

end NineSeparatedSubsetSums
