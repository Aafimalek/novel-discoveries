import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive123Third114Node0 : CachedSearchNode :=
  ⟨4, 113, computeCenteredMask [148,123,114], 385, 50029⟩

end NineSeparatedSubsetSums
