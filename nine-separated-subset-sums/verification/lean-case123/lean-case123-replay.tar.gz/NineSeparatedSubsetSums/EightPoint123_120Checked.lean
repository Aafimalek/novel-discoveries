import NineSeparatedSubsetSums.EightPointPackedGeometry
import NineSeparatedSubsetSums.EightPoint123_120PackedBudget0
import NineSeparatedSubsetSums.EightPoint123_120PackedAnchor0Part0
import NineSeparatedSubsetSums.EightPoint123_120PackedAnchor0Part1
import NineSeparatedSubsetSums.EightPoint123_120PackedBudget1
import NineSeparatedSubsetSums.EightPoint123_120PackedAnchor1Part0
import NineSeparatedSubsetSums.EightPoint123_120PackedAnchor1Part1

namespace NineSeparatedSubsetSums

private theorem packedOct123_120Anchor0 :
  ∀ j : Fin 478, ((j.val : Int)+123+120)%2=0 →
    2231805 ≤ FourPointNumeric.octPackedCharge 123 120 20 packedOct123_120_0 (j.val : Int) := by
  intro j hj
  let k := (j.val-1)/2
  have hk : k < 239 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+1 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint123_120PackedAnchor0Part0 z
    rwa [he,hrep] at ht
  let z : Fin 119 := ⟨k-120, by omega⟩
  have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
  have ht := eightPoint123_120PackedAnchor0Part1 z
  rwa [he,hrep] at ht

private theorem packedOct123_120Anchor1 :
  ∀ j : Fin 478, ((j.val : Int)+123+120)%2=1 →
    2230489 ≤ FourPointNumeric.octPackedCharge 123 120 20 packedOct123_120_1 (j.val : Int) := by
  intro j hj
  let k := (j.val-0)/2
  have hk : k < 239 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+0 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint123_120PackedAnchor1Part0 z
    rwa [he,hrep] at ht
  let z : Fin 119 := ⟨k-120, by omega⟩
  have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
  have ht := eightPoint123_120PackedAnchor1Part1 z
  rwa [he,hrep] at ht

def packedOctCertificate123_120_0 : EightPointCertificate 123 120 0 122360 :=
  eightPointCertificateOfPacked 123 120 0 122360 2231805 20 packedOct123_120_0 385 478
    (by decide +kernel) (by decide) packedOct123_120Anchor0
    (by rw [packedOct123_120_0_budget]; decide)

def packedOctCertificate123_120_1 : EightPointCertificate 123 120 1 122360 :=
  eightPointCertificateOfPacked 123 120 1 122360 2230489 20 packedOct123_120_1 502 478
    (by decide +kernel) (by decide) packedOct123_120Anchor1
    (by rw [packedOct123_120_1_budget]; decide)

theorem max148_second123_third120_eightPoint_moment_bound (tail : List ℕ) (len : tail.length=6)
    (distinct : (natSubsetSums (148::123::120::tail)).Nodup) :
    122360 ≤ ((148::123::120::tail).map (· ^ 2)).sum := by
  apply eightPointNatMomentLower 123 120 122360 tail len distinct
  intro p hp
  by_cases h : p=0
  · subst p
    exact packedOctCertificate123_120_0
  · have he : p=1 := hp.resolve_left h
    subst p
    exact packedOctCertificate123_120_1

#print axioms max148_second123_third120_eightPoint_moment_bound

end NineSeparatedSubsetSums
