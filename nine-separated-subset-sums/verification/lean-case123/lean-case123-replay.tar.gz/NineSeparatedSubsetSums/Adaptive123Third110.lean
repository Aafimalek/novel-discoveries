import NineSeparatedSubsetSums.Adaptive123Third110Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint123Checked

namespace NineSeparatedSubsetSums


theorem adaptive123Third110 : NoDescendingTailAfterThird 123 110 :=
  noDescendingThirdTail_of_cached 123 110 109206 (fun t ht nd => max148_second123_fourPoint_moment_bound (110::t) (by simp [ht]) nd) adaptive123Third110Proof0

#print axioms adaptive123Third110

end NineSeparatedSubsetSums
