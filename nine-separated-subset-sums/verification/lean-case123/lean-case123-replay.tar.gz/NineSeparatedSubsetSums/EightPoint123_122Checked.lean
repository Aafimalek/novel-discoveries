import NineSeparatedSubsetSums.EightPointPackedGeometry
import NineSeparatedSubsetSums.EightPoint123_122PackedBudget0
import NineSeparatedSubsetSums.EightPoint123_122PackedAnchor0Part0
import NineSeparatedSubsetSums.EightPoint123_122PackedAnchor0Part1
import NineSeparatedSubsetSums.EightPoint123_122PackedBudget1
import NineSeparatedSubsetSums.EightPoint123_122PackedAnchor1Part0
import NineSeparatedSubsetSums.EightPoint123_122PackedAnchor1Part1
import NineSeparatedSubsetSums.EightPoint123_122PackedAnchor1Part2

namespace NineSeparatedSubsetSums

private theorem packedOct123_122Anchor0 :
  ∀ j : Fin 481, ((j.val : Int)+123+122)%2=0 →
    2263117 ≤ FourPointNumeric.octPackedCharge 123 122 20 packedOct123_122_0 (j.val : Int) := by
  intro j hj
  let k := (j.val-1)/2
  have hk : k < 240 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+1 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint123_122PackedAnchor0Part0 z
    rwa [he,hrep] at ht
  let z : Fin 120 := ⟨k-120, by omega⟩
  have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
  have ht := eightPoint123_122PackedAnchor0Part1 z
  rwa [he,hrep] at ht

private theorem packedOct123_122Anchor1 :
  ∀ j : Fin 481, ((j.val : Int)+123+122)%2=1 →
    2263109 ≤ FourPointNumeric.octPackedCharge 123 122 20 packedOct123_122_1 (j.val : Int) := by
  intro j hj
  let k := (j.val-0)/2
  have hk : k < 241 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+0 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint123_122PackedAnchor1Part0 z
    rwa [he,hrep] at ht
  by_cases h1 : k < 240
  · let z : Fin 120 := ⟨k-120, by omega⟩
    have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
    have ht := eightPoint123_122PackedAnchor1Part1 z
    rwa [he,hrep] at ht
  let z : Fin 1 := ⟨k-240, by omega⟩
  have he : (z.val : Int)+240 = k := by dsimp [z] <;> omega
  have ht := eightPoint123_122PackedAnchor1Part2 z
  rwa [he,hrep] at ht

def packedOctCertificate123_122_0 : EightPointCertificate 123 122 0 122766 :=
  eightPointCertificateOfPacked 123 122 0 122766 2263117 20 packedOct123_122_0 389 481
    (by decide +kernel) (by decide) packedOct123_122Anchor0
    (by rw [packedOct123_122_0_budget]; decide)

def packedOctCertificate123_122_1 : EightPointCertificate 123 122 1 122766 :=
  eightPointCertificateOfPacked 123 122 1 122766 2263109 20 packedOct123_122_1 500 481
    (by decide +kernel) (by decide) packedOct123_122Anchor1
    (by rw [packedOct123_122_1_budget]; decide)

theorem max148_second123_third122_eightPoint_moment_bound (tail : List ℕ) (len : tail.length=6)
    (distinct : (natSubsetSums (148::123::122::tail)).Nodup) :
    122766 ≤ ((148::123::122::tail).map (· ^ 2)).sum := by
  apply eightPointNatMomentLower 123 122 122766 tail len distinct
  intro p hp
  by_cases h : p=0
  · subst p
    exact packedOctCertificate123_122_0
  · have he : p=1 := hp.resolve_left h
    subst p
    exact packedOctCertificate123_122_1

#print axioms max148_second123_third122_eightPoint_moment_bound

end NineSeparatedSubsetSums
