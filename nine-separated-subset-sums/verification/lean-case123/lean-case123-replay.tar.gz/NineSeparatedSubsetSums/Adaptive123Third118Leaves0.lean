import NineSeparatedSubsetSums.Adaptive123Third118State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive123Third118Proof0 : runCachedNode 511 122080 Adaptive123Third118Node0 = false := by
  decide +kernel

#print axioms adaptive123Third118Proof0

end NineSeparatedSubsetSums
