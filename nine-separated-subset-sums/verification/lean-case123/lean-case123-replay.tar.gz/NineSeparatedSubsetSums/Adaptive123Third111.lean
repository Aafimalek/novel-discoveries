import NineSeparatedSubsetSums.Adaptive123Third111Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint123Checked

namespace NineSeparatedSubsetSums


theorem adaptive123Third111 : NoDescendingTailAfterThird 123 111 :=
  noDescendingThirdTail_of_cached 123 111 109206 (fun t ht nd => max148_second123_fourPoint_moment_bound (111::t) (by simp [ht]) nd) adaptive123Third111Proof0

#print axioms adaptive123Third111

end NineSeparatedSubsetSums
