import NineSeparatedSubsetSums.EightPoint123_121PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct123_121_1_budget :
    FourPointNumeric.packedBudget 20 packedOct123_121_1 396 = 80995772 := by decide +kernel

#print axioms packedOct123_121_1_budget

end NineSeparatedSubsetSums
