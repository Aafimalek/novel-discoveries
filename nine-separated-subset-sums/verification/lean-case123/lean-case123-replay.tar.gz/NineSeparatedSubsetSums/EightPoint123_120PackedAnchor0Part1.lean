import NineSeparatedSubsetSums.EightPoint123_120PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint123_120PackedAnchor0Part1 :
    ∀ j : Fin 119, 2231805 ≤ FourPointNumeric.octPackedCharge 123 120 20 packedOct123_120_0
      (2*((j.val : Int)+120)+1) := by decide +kernel

end NineSeparatedSubsetSums
