import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive123Third112Node0 : CachedSearchNode :=
  ⟨4, 111, computeCenteredMask [148,123,112], 383, 49577⟩

end NineSeparatedSubsetSums
