import NineSeparatedSubsetSums.EightPoint123_118PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct123_118_0_budget :
    FourPointNumeric.packedBudget 20 packedOct123_118_0 499 = 77570766 := by decide +kernel

#print axioms packedOct123_118_0_budget

end NineSeparatedSubsetSums
