import NineSeparatedSubsetSums.EightPointPackedGeometry
import NineSeparatedSubsetSums.EightPoint123_121PackedBudget0
import NineSeparatedSubsetSums.EightPoint123_121PackedAnchor0Part0
import NineSeparatedSubsetSums.EightPoint123_121PackedAnchor0Part1
import NineSeparatedSubsetSums.EightPoint123_121PackedBudget1
import NineSeparatedSubsetSums.EightPoint123_121PackedAnchor1Part0
import NineSeparatedSubsetSums.EightPoint123_121PackedAnchor1Part1

namespace NineSeparatedSubsetSums

private theorem packedOct123_121Anchor0 :
  ∀ j : Fin 479, ((j.val : Int)+123+121)%2=0 →
    2243773 ≤ FourPointNumeric.octPackedCharge 123 121 20 packedOct123_121_0 (j.val : Int) := by
  intro j hj
  let k := (j.val-0)/2
  have hk : k < 240 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+0 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint123_121PackedAnchor0Part0 z
    rwa [he,hrep] at ht
  let z : Fin 120 := ⟨k-120, by omega⟩
  have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
  have ht := eightPoint123_121PackedAnchor0Part1 z
  rwa [he,hrep] at ht

private theorem packedOct123_121Anchor1 :
  ∀ j : Fin 479, ((j.val : Int)+123+121)%2=1 →
    2246056 ≤ FourPointNumeric.octPackedCharge 123 121 20 packedOct123_121_1 (j.val : Int) := by
  intro j hj
  let k := (j.val-1)/2
  have hk : k < 239 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+1 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint123_121PackedAnchor1Part0 z
    rwa [he,hrep] at ht
  let z : Fin 119 := ⟨k-120, by omega⟩
  have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
  have ht := eightPoint123_121PackedAnchor1Part1 z
  rwa [he,hrep] at ht

def packedOctCertificate123_121_0 : EightPointCertificate 123 121 0 122563 :=
  eightPointCertificateOfPacked 123 121 0 122563 2243773 20 packedOct123_121_0 499 479
    (by decide +kernel) (by decide) packedOct123_121Anchor0
    (by rw [packedOct123_121_0_budget]; decide)

def packedOctCertificate123_121_1 : EightPointCertificate 123 121 1 122563 :=
  eightPointCertificateOfPacked 123 121 1 122563 2246056 20 packedOct123_121_1 396 479
    (by decide +kernel) (by decide) packedOct123_121Anchor1
    (by rw [packedOct123_121_1_budget]; decide)

theorem max148_second123_third121_eightPoint_moment_bound (tail : List ℕ) (len : tail.length=6)
    (distinct : (natSubsetSums (148::123::121::tail)).Nodup) :
    122563 ≤ ((148::123::121::tail).map (· ^ 2)).sum := by
  apply eightPointNatMomentLower 123 121 122563 tail len distinct
  intro p hp
  by_cases h : p=0
  · subst p
    exact packedOctCertificate123_121_0
  · have he : p=1 := hp.resolve_left h
    subst p
    exact packedOctCertificate123_121_1

#print axioms max148_second123_third121_eightPoint_moment_bound

end NineSeparatedSubsetSums
