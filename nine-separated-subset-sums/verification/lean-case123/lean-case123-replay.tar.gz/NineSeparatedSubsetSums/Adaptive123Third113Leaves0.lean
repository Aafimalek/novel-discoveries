import NineSeparatedSubsetSums.Adaptive123Third113State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive123Third113Proof0 : runCachedNode 511 109206 Adaptive123Third113Node0 = false := by
  decide +kernel

#print axioms adaptive123Third113Proof0

end NineSeparatedSubsetSums
