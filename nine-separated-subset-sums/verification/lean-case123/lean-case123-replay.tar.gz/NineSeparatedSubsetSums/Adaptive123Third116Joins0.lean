import NineSeparatedSubsetSums.Adaptive123Third116State
import NineSeparatedSubsetSums.Adaptive123Third116Leaves1
import NineSeparatedSubsetSums.Adaptive123Third116Leaves0

namespace NineSeparatedSubsetSums

theorem adaptive123Third116Proof0 : runCachedNode 511 109206 Adaptive123Third116Node0 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 109206 Adaptive123Third116Node0 = [102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive123Third116Proof1
  · exact adaptive123Third116Proof2
  · exact adaptive123Third116Proof3
  · exact adaptive123Third116Proof4
  · exact adaptive123Third116Proof5
  · exact adaptive123Third116Proof6
  · exact adaptive123Third116Proof7
  · exact adaptive123Third116Proof8
  · exact adaptive123Third116Proof9
  · exact adaptive123Third116Proof10
  · exact adaptive123Third116Proof11
  · exact adaptive123Third116Proof12
  · exact adaptive123Third116Proof13
  · exact adaptive123Third116Proof14

#print axioms adaptive123Third116Proof0

end NineSeparatedSubsetSums
