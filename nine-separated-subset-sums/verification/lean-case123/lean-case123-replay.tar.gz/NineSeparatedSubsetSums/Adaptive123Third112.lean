import NineSeparatedSubsetSums.Adaptive123Third112Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint123Checked

namespace NineSeparatedSubsetSums


theorem adaptive123Third112 : NoDescendingTailAfterThird 123 112 :=
  noDescendingThirdTail_of_cached 123 112 109206 (fun t ht nd => max148_second123_fourPoint_moment_bound (112::t) (by simp [ht]) nd) adaptive123Third112Proof0

#print axioms adaptive123Third112

end NineSeparatedSubsetSums
