import NineSeparatedSubsetSums.EightPoint123_118PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct123_118_1_budget :
    FourPointNumeric.packedBudget 20 packedOct123_118_1 404 = 77481418 := by decide +kernel

#print axioms packedOct123_118_1_budget

end NineSeparatedSubsetSums
