import NineSeparatedSubsetSums.FourPoint123PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedWeight123_1_budget :
    FourPointNumeric.packedBudget 20 packedWeight123_1 414 = 83357376 := by decide +kernel

#print axioms packedWeight123_1_budget

end NineSeparatedSubsetSums
