import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive123Third106Node0 : CachedSearchNode :=
  ⟨4, 105, computeCenteredMask [148,123,106], 377, 48269⟩

end NineSeparatedSubsetSums
