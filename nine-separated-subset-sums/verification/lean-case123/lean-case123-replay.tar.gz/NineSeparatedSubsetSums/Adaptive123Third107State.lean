import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive123Third107Node0 : CachedSearchNode :=
  ⟨4, 106, computeCenteredMask [148,123,107], 378, 48482⟩

end NineSeparatedSubsetSums
