import NineSeparatedSubsetSums.Adaptive123Third109Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint123Checked

namespace NineSeparatedSubsetSums


theorem adaptive123Third109 : NoDescendingTailAfterThird 123 109 :=
  noDescendingThirdTail_of_cached 123 109 109206 (fun t ht nd => max148_second123_fourPoint_moment_bound (109::t) (by simp [ht]) nd) adaptive123Third109Proof0

#print axioms adaptive123Third109

end NineSeparatedSubsetSums
