import NineSeparatedSubsetSums.Adaptive123Third106Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint123Checked

namespace NineSeparatedSubsetSums


theorem adaptive123Third106 : NoDescendingTailAfterThird 123 106 :=
  noDescendingThirdTail_of_cached 123 106 109206 (fun t ht nd => max148_second123_fourPoint_moment_bound (106::t) (by simp [ht]) nd) adaptive123Third106Proof0

#print axioms adaptive123Third106

end NineSeparatedSubsetSums
