import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive123Third119Node0 : CachedSearchNode :=
  ⟨4, 118, computeCenteredMask [148,123,119], 390, 51194⟩

end NineSeparatedSubsetSums
