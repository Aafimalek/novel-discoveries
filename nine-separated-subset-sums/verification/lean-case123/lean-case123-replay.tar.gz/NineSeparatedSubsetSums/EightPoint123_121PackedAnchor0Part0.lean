import NineSeparatedSubsetSums.EightPoint123_121PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint123_121PackedAnchor0Part0 :
    ∀ j : Fin 120, 2243773 ≤ FourPointNumeric.octPackedCharge 123 121 20 packedOct123_121_0
      (2*((j.val : Int)+0)+0) := by decide +kernel

end NineSeparatedSubsetSums
