import NineSeparatedSubsetSums.Adaptive123Third107Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint123Checked

namespace NineSeparatedSubsetSums


theorem adaptive123Third107 : NoDescendingTailAfterThird 123 107 :=
  noDescendingThirdTail_of_cached 123 107 109206 (fun t ht nd => max148_second123_fourPoint_moment_bound (107::t) (by simp [ht]) nd) adaptive123Third107Proof0

#print axioms adaptive123Third107

end NineSeparatedSubsetSums
