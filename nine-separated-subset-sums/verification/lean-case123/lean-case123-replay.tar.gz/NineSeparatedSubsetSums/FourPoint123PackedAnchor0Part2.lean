import NineSeparatedSubsetSums.FourPoint123PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem fourPoint123PackedAnchor0Part2 :
    ∀ j : Fin 2, 1088024 ≤ FourPointNumeric.packedCharge 123 20 packedWeight123_0
      (2*((j.val : Int)+240)+1) := by decide +kernel

end NineSeparatedSubsetSums
