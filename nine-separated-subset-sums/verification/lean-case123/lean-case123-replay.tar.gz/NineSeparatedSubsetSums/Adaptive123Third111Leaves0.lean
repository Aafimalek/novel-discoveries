import NineSeparatedSubsetSums.Adaptive123Third111State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive123Third111Proof0 : runCachedNode 511 109206 Adaptive123Third111Node0 = false := by
  decide +kernel

#print axioms adaptive123Third111Proof0

end NineSeparatedSubsetSums
