import NineSeparatedSubsetSums.EightPoint123_120PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint123_120PackedAnchor0Part0 :
    ∀ j : Fin 120, 2231805 ≤ FourPointNumeric.octPackedCharge 123 120 20 packedOct123_120_0
      (2*((j.val : Int)+0)+1) := by decide +kernel

end NineSeparatedSubsetSums
