import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive123Third111Node0 : CachedSearchNode :=
  ⟨4, 110, computeCenteredMask [148,123,111], 382, 49354⟩

end NineSeparatedSubsetSums
