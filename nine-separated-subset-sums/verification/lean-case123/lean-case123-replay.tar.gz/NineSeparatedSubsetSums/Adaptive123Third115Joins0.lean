import NineSeparatedSubsetSums.Adaptive123Third115State
import NineSeparatedSubsetSums.Adaptive123Third115Leaves0
import NineSeparatedSubsetSums.Adaptive123Third115Leaves1

namespace NineSeparatedSubsetSums

theorem adaptive123Third115Proof0 : runCachedNode 511 109206 Adaptive123Third115Node0 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 109206 Adaptive123Third115Node0 = [102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive123Third115Proof1
  · exact adaptive123Third115Proof2
  · exact adaptive123Third115Proof3
  · exact adaptive123Third115Proof4
  · exact adaptive123Third115Proof5
  · exact adaptive123Third115Proof6
  · exact adaptive123Third115Proof7
  · exact adaptive123Third115Proof8
  · exact adaptive123Third115Proof9
  · exact adaptive123Third115Proof10
  · exact adaptive123Third115Proof11
  · exact adaptive123Third115Proof12
  · exact adaptive123Third115Proof13

#print axioms adaptive123Third115Proof0

end NineSeparatedSubsetSums
