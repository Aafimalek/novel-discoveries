import NineSeparatedSubsetSums.Adaptive123Third117State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive123Third117Proof15 : runCachedNode 511 109206 Adaptive123Third117Node15 = false := by
  decide +kernel

#print axioms adaptive123Third117Proof15

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive123Third117Proof14 : runCachedNode 511 109206 Adaptive123Third117Node14 = false := by
  decide +kernel

#print axioms adaptive123Third117Proof14

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive123Third117Proof13 : runCachedNode 511 109206 Adaptive123Third117Node13 = false := by
  decide +kernel

#print axioms adaptive123Third117Proof13

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive123Third117Proof9 : runCachedNode 511 109206 Adaptive123Third117Node9 = false := by
  decide +kernel

#print axioms adaptive123Third117Proof9

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive123Third117Proof3 : runCachedNode 511 109206 Adaptive123Third117Node3 = false := by
  decide +kernel

#print axioms adaptive123Third117Proof3

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive123Third117Proof1 : runCachedNode 511 109206 Adaptive123Third117Node1 = false := by
  decide +kernel

#print axioms adaptive123Third117Proof1

end NineSeparatedSubsetSums
