import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive123Third118Node0 : CachedSearchNode :=
  ⟨4, 117, computeCenteredMask [148,123,118], 389, 50957⟩

end NineSeparatedSubsetSums
