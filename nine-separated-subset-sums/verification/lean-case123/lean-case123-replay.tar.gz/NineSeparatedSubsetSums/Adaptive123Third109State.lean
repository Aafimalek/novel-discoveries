import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive123Third109Node0 : CachedSearchNode :=
  ⟨4, 108, computeCenteredMask [148,123,109], 380, 48914⟩

end NineSeparatedSubsetSums
