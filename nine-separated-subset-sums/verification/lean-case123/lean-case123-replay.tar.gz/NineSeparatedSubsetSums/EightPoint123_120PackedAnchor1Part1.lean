import NineSeparatedSubsetSums.EightPoint123_120PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint123_120PackedAnchor1Part1 :
    ∀ j : Fin 119, 2230489 ≤ FourPointNumeric.octPackedCharge 123 120 20 packedOct123_120_1
      (2*((j.val : Int)+120)+0) := by decide +kernel

end NineSeparatedSubsetSums
