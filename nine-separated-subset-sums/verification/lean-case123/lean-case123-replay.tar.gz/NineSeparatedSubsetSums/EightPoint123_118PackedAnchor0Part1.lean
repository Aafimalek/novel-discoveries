import NineSeparatedSubsetSums.EightPoint123_118PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint123_118PackedAnchor0Part1 :
    ∀ j : Fin 116, 2188682 ≤ FourPointNumeric.octPackedCharge 123 118 20 packedOct123_118_0
      (2*((j.val : Int)+120)+1) := by decide +kernel

end NineSeparatedSubsetSums
