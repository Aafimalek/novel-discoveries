import NineSeparatedSubsetSums.EightPoint123_119PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint123_119PackedAnchor0Part0 :
    ∀ j : Fin 120, 2188269 ≤ FourPointNumeric.octPackedCharge 123 119 20 packedOct123_119_0
      (2*((j.val : Int)+0)+0) := by decide +kernel

end NineSeparatedSubsetSums
