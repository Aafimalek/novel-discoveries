import NineSeparatedSubsetSums.EightPoint123_121PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint123_121PackedAnchor1Part1 :
    ∀ j : Fin 119, 2246056 ≤ FourPointNumeric.octPackedCharge 123 121 20 packedOct123_121_1
      (2*((j.val : Int)+120)+1) := by decide +kernel

end NineSeparatedSubsetSums
