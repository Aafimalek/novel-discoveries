import NineSeparatedSubsetSums.FourPoint123PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem fourPoint123PackedAnchor1Part0 :
    ∀ j : Fin 120, 1088052 ≤ FourPointNumeric.packedCharge 123 20 packedWeight123_1
      (2*((j.val : Int)+0)+0) := by decide +kernel

end NineSeparatedSubsetSums
