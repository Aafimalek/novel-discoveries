import NineSeparatedSubsetSums.EightPoint123_122PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint123_122PackedAnchor0Part1 :
    ∀ j : Fin 120, 2263117 ≤ FourPointNumeric.octPackedCharge 123 122 20 packedOct123_122_0
      (2*((j.val : Int)+120)+1) := by decide +kernel

end NineSeparatedSubsetSums
