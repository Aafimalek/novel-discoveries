import NineSeparatedSubsetSums.Adaptive123Third120State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive123Third120Proof0 : runCachedNode 511 122360 Adaptive123Third120Node0 = false := by
  decide +kernel

#print axioms adaptive123Third120Proof0

end NineSeparatedSubsetSums
