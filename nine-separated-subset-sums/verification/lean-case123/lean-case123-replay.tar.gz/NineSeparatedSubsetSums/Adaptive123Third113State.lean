import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive123Third113Node0 : CachedSearchNode :=
  ⟨4, 112, computeCenteredMask [148,123,113], 384, 49802⟩

end NineSeparatedSubsetSums
