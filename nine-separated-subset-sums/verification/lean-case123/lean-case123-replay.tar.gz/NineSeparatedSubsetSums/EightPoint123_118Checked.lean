import NineSeparatedSubsetSums.EightPointPackedGeometry
import NineSeparatedSubsetSums.EightPoint123_118PackedBudget0
import NineSeparatedSubsetSums.EightPoint123_118PackedAnchor0Part0
import NineSeparatedSubsetSums.EightPoint123_118PackedAnchor0Part1
import NineSeparatedSubsetSums.EightPoint123_118PackedBudget1
import NineSeparatedSubsetSums.EightPoint123_118PackedAnchor1Part0
import NineSeparatedSubsetSums.EightPoint123_118PackedAnchor1Part1

namespace NineSeparatedSubsetSums

private theorem packedOct123_118Anchor0 :
  ∀ j : Fin 472, ((j.val : Int)+123+118)%2=0 →
    2188682 ≤ FourPointNumeric.octPackedCharge 123 118 20 packedOct123_118_0 (j.val : Int) := by
  intro j hj
  let k := (j.val-1)/2
  have hk : k < 236 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+1 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint123_118PackedAnchor0Part0 z
    rwa [he,hrep] at ht
  let z : Fin 116 := ⟨k-120, by omega⟩
  have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
  have ht := eightPoint123_118PackedAnchor0Part1 z
  rwa [he,hrep] at ht

private theorem packedOct123_118Anchor1 :
  ∀ j : Fin 472, ((j.val : Int)+123+118)%2=1 →
    2187283 ≤ FourPointNumeric.octPackedCharge 123 118 20 packedOct123_118_1 (j.val : Int) := by
  intro j hj
  let k := (j.val-0)/2
  have hk : k < 236 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+0 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint123_118PackedAnchor1Part0 z
    rwa [he,hrep] at ht
  let z : Fin 116 := ⟨k-120, by omega⟩
  have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
  have ht := eightPoint123_118PackedAnchor1Part1 z
  rwa [he,hrep] at ht

def packedOctCertificate123_118_0 : EightPointCertificate 123 118 0 122080 :=
  eightPointCertificateOfPacked 123 118 0 122080 2188682 20 packedOct123_118_0 499 472
    (by decide +kernel) (by decide) packedOct123_118Anchor0
    (by rw [packedOct123_118_0_budget]; decide)

def packedOctCertificate123_118_1 : EightPointCertificate 123 118 1 122080 :=
  eightPointCertificateOfPacked 123 118 1 122080 2187283 20 packedOct123_118_1 404 472
    (by decide +kernel) (by decide) packedOct123_118Anchor1
    (by rw [packedOct123_118_1_budget]; decide)

theorem max148_second123_third118_eightPoint_moment_bound (tail : List ℕ) (len : tail.length=6)
    (distinct : (natSubsetSums (148::123::118::tail)).Nodup) :
    122080 ≤ ((148::123::118::tail).map (· ^ 2)).sum := by
  apply eightPointNatMomentLower 123 118 122080 tail len distinct
  intro p hp
  by_cases h : p=0
  · subst p
    exact packedOctCertificate123_118_0
  · have he : p=1 := hp.resolve_left h
    subst p
    exact packedOctCertificate123_118_1

#print axioms max148_second123_third118_eightPoint_moment_bound

end NineSeparatedSubsetSums
