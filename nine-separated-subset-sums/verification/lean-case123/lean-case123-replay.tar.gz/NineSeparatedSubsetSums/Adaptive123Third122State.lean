import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive123Third122Node0 : CachedSearchNode :=
  ⟨4, 121, computeCenteredMask [148,123,122], 393, 51917⟩

end NineSeparatedSubsetSums
