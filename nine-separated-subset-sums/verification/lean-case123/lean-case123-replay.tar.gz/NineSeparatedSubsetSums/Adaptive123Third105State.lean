import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive123Third105Node0 : CachedSearchNode :=
  ⟨4, 104, computeCenteredMask [148,123,105], 376, 48058⟩

end NineSeparatedSubsetSums
