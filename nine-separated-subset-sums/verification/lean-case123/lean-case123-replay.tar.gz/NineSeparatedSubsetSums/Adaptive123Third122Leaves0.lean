import NineSeparatedSubsetSums.Adaptive123Third122State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive123Third122Proof0 : runCachedNode 511 122766 Adaptive123Third122Node0 = false := by
  decide +kernel

#print axioms adaptive123Third122Proof0

end NineSeparatedSubsetSums
