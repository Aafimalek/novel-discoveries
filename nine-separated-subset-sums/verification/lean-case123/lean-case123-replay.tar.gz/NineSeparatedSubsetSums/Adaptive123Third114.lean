import NineSeparatedSubsetSums.Adaptive123Third114Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint123Checked

namespace NineSeparatedSubsetSums


theorem adaptive123Third114 : NoDescendingTailAfterThird 123 114 :=
  noDescendingThirdTail_of_cached 123 114 109206 (fun t ht nd => max148_second123_fourPoint_moment_bound (114::t) (by simp [ht]) nd) adaptive123Third114Proof0

#print axioms adaptive123Third114

end NineSeparatedSubsetSums
