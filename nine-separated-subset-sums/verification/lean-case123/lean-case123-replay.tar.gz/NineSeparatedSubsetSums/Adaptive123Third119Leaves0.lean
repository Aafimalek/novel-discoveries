import NineSeparatedSubsetSums.Adaptive123Third119State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive123Third119Proof0 : runCachedNode 511 122187 Adaptive123Third119Node0 = false := by
  decide +kernel

#print axioms adaptive123Third119Proof0

end NineSeparatedSubsetSums
