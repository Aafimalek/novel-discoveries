import NineSeparatedSubsetSums.Adaptive123Third116Joins0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint123Checked

namespace NineSeparatedSubsetSums


theorem adaptive123Third116 : NoDescendingTailAfterThird 123 116 :=
  noDescendingThirdTail_of_cached 123 116 109206 (fun t ht nd => max148_second123_fourPoint_moment_bound (116::t) (by simp [ht]) nd) adaptive123Third116Proof0

#print axioms adaptive123Third116

end NineSeparatedSubsetSums
