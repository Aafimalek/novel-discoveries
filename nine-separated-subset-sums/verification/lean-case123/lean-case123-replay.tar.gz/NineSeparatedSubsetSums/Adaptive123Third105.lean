import NineSeparatedSubsetSums.Adaptive123Third105Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint123Checked

namespace NineSeparatedSubsetSums


theorem adaptive123Third105 : NoDescendingTailAfterThird 123 105 :=
  noDescendingThirdTail_of_cached 123 105 109206 (fun t ht nd => max148_second123_fourPoint_moment_bound (105::t) (by simp [ht]) nd) adaptive123Third105Proof0

#print axioms adaptive123Third105

end NineSeparatedSubsetSums
