import NineSeparatedSubsetSums.Adaptive123Third116State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive123Third116Proof10 : runCachedNode 511 109206 Adaptive123Third116Node10 = false := by
  decide +kernel

#print axioms adaptive123Third116Proof10

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive123Third116Proof9 : runCachedNode 511 109206 Adaptive123Third116Node9 = false := by
  decide +kernel

#print axioms adaptive123Third116Proof9

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive123Third116Proof8 : runCachedNode 511 109206 Adaptive123Third116Node8 = false := by
  decide +kernel

#print axioms adaptive123Third116Proof8

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive123Third116Proof6 : runCachedNode 511 109206 Adaptive123Third116Node6 = false := by
  decide +kernel

#print axioms adaptive123Third116Proof6

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive123Third116Proof4 : runCachedNode 511 109206 Adaptive123Third116Node4 = false := by
  decide +kernel

#print axioms adaptive123Third116Proof4

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive123Third116Proof3 : runCachedNode 511 109206 Adaptive123Third116Node3 = false := by
  decide +kernel

#print axioms adaptive123Third116Proof3

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive123Third116Proof2 : runCachedNode 511 109206 Adaptive123Third116Node2 = false := by
  decide +kernel

#print axioms adaptive123Third116Proof2

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive123Third116Proof1 : runCachedNode 511 109206 Adaptive123Third116Node1 = false := by
  decide +kernel

#print axioms adaptive123Third116Proof1

end NineSeparatedSubsetSums
