import NineSeparatedSubsetSums.EightPoint123_122PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint123_122PackedAnchor1Part1 :
    ∀ j : Fin 120, 2263109 ≤ FourPointNumeric.octPackedCharge 123 122 20 packedOct123_122_1
      (2*((j.val : Int)+120)+0) := by decide +kernel

end NineSeparatedSubsetSums
