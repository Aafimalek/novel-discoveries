import NineSeparatedSubsetSums.Adaptive123Third108Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint123Checked

namespace NineSeparatedSubsetSums


theorem adaptive123Third108 : NoDescendingTailAfterThird 123 108 :=
  noDescendingThirdTail_of_cached 123 108 109206 (fun t ht nd => max148_second123_fourPoint_moment_bound (108::t) (by simp [ht]) nd) adaptive123Third108Proof0

#print axioms adaptive123Third108

end NineSeparatedSubsetSums
