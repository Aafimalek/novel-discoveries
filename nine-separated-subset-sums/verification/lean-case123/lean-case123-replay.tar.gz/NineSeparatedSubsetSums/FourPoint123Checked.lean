import NineSeparatedSubsetSums.FourPointPackedGeometry
import NineSeparatedSubsetSums.FourPoint123PackedBudget0
import NineSeparatedSubsetSums.FourPoint123PackedAnchor0Part0
import NineSeparatedSubsetSums.FourPoint123PackedAnchor0Part1
import NineSeparatedSubsetSums.FourPoint123PackedAnchor0Part2
import NineSeparatedSubsetSums.FourPoint123PackedBudget1
import NineSeparatedSubsetSums.FourPoint123PackedAnchor1Part0
import NineSeparatedSubsetSums.FourPoint123PackedAnchor1Part1
import NineSeparatedSubsetSums.FourPoint123PackedAnchor1Part2

namespace NineSeparatedSubsetSums

private theorem packed123Anchor0 :
  ∀ j : Fin 485, ((j.val : Int)+123)%2=0 →
    1088024 ≤ FourPointNumeric.packedCharge 123 20 packedWeight123_0 (j.val : Int) := by
  intro j hj
  let k := (j.val-1)/2
  have hk : k < 242 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+1 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := fourPoint123PackedAnchor0Part0 z
    rwa [he,hrep] at ht
  by_cases h1 : k < 240
  · let z : Fin 120 := ⟨k-120, by omega⟩
    have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
    have ht := fourPoint123PackedAnchor0Part1 z
    rwa [he,hrep] at ht
  let z : Fin 2 := ⟨k-240, by omega⟩
  have he : (z.val : Int)+240 = k := by dsimp [z] <;> omega
  have ht := fourPoint123PackedAnchor0Part2 z
  rwa [he,hrep] at ht

private theorem packed123Anchor1 :
  ∀ j : Fin 485, ((j.val : Int)+123)%2=1 →
    1088052 ≤ FourPointNumeric.packedCharge 123 20 packedWeight123_1 (j.val : Int) := by
  intro j hj
  let k := (j.val-0)/2
  have hk : k < 243 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+0 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := fourPoint123PackedAnchor1Part0 z
    rwa [he,hrep] at ht
  by_cases h1 : k < 240
  · let z : Fin 120 := ⟨k-120, by omega⟩
    have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
    have ht := fourPoint123PackedAnchor1Part1 z
    rwa [he,hrep] at ht
  let z : Fin 3 := ⟨k-240, by omega⟩
  have he : (z.val : Int)+240 = k := by dsimp [z] <;> omega
  have ht := fourPoint123PackedAnchor1Part2 z
  rwa [he,hrep] at ht

def packedCertificate123_0 : FourPointCertificate 123 0 109206 :=
  fourPointCertificateOfPacked 123 0 109206 1088024 20 packedWeight123_0 499 485
    (by decide +kernel) (by decide) (by decide) packed123Anchor0
    (by rw [packedWeight123_0_budget]; decide)

def packedCertificate123_1 : FourPointCertificate 123 1 109206 :=
  fourPointCertificateOfPacked 123 1 109206 1088052 20 packedWeight123_1 414 485
    (by decide +kernel) (by decide) (by decide) packed123Anchor1
    (by rw [packedWeight123_1_budget]; decide)

theorem max148_second123_fourPoint_moment_bound (tail : List ℕ) (len : tail.length=7)
    (distinct : (natSubsetSums (148::123::tail)).Nodup) :
    109206 ≤ ((148::123::tail).map (· ^ 2)).sum := by
  apply fourPointNatMomentLower 123 109206 tail len distinct
  intro p hp
  by_cases h : p=0
  · subst p
    exact packedCertificate123_0
  · have he : p=1 := hp.resolve_left h
    subst p
    exact packedCertificate123_1

#print axioms max148_second123_fourPoint_moment_bound

end NineSeparatedSubsetSums
