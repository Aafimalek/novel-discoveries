import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive123Third120Node0 : CachedSearchNode :=
  ⟨4, 119, computeCenteredMask [148,123,120], 391, 51433⟩

end NineSeparatedSubsetSums
