import NineSeparatedSubsetSums.EightPoint123_122PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct123_122_1_budget :
    FourPointNumeric.packedBudget 20 packedOct123_122_1 500 = 81983216 := by decide +kernel

#print axioms packedOct123_122_1_budget

end NineSeparatedSubsetSums
