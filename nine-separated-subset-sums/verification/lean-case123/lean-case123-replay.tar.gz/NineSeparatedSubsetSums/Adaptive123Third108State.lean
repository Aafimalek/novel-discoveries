import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive123Third108Node0 : CachedSearchNode :=
  ⟨4, 107, computeCenteredMask [148,123,108], 379, 48697⟩

end NineSeparatedSubsetSums
