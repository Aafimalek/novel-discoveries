import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive123Third110Node0 : CachedSearchNode :=
  ⟨4, 109, computeCenteredMask [148,123,110], 381, 49133⟩

end NineSeparatedSubsetSums
