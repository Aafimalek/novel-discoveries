import NineSeparatedSubsetSums.EightPoint123_118PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint123_118PackedAnchor0Part0 :
    ∀ j : Fin 120, 2188682 ≤ FourPointNumeric.octPackedCharge 123 118 20 packedOct123_118_0
      (2*((j.val : Int)+0)+1) := by decide +kernel

end NineSeparatedSubsetSums
