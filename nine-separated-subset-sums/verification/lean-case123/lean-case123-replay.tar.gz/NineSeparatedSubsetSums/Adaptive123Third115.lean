import NineSeparatedSubsetSums.Adaptive123Third115Joins0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint123Checked

namespace NineSeparatedSubsetSums


theorem adaptive123Third115 : NoDescendingTailAfterThird 123 115 :=
  noDescendingThirdTail_of_cached 123 115 109206 (fun t ht nd => max148_second123_fourPoint_moment_bound (115::t) (by simp [ht]) nd) adaptive123Third115Proof0

#print axioms adaptive123Third115

end NineSeparatedSubsetSums
