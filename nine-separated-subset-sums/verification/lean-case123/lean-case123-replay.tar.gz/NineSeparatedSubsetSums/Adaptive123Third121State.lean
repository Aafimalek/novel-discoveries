import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive123Third121Node0 : CachedSearchNode :=
  ⟨4, 120, computeCenteredMask [148,123,121], 392, 51674⟩

end NineSeparatedSubsetSums
