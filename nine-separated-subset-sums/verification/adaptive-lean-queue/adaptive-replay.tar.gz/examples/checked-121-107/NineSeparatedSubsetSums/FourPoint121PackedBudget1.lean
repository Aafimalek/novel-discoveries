import NineSeparatedSubsetSums.FourPoint121PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedWeight121_1_budget :
    FourPointNumeric.packedBudget 20 packedWeight121_1 472 = 78906112 := by decide +kernel

#print axioms packedWeight121_1_budget

end NineSeparatedSubsetSums
