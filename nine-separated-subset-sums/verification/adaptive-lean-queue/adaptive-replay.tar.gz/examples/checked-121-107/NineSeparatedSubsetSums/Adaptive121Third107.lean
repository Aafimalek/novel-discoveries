import NineSeparatedSubsetSums.Adaptive121Third107Joins0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint121Checked

namespace NineSeparatedSubsetSums


theorem adaptive121Third107 : NoDescendingTailAfterThird 121 107 :=
  noDescendingThirdTail_of_cached 121 107 108868 (fun t ht nd => max148_second121_fourPoint_moment_bound (107::t) (by simp [ht]) nd) adaptive121Third107Proof0

#print axioms adaptive121Third107

end NineSeparatedSubsetSums
