import NineSeparatedSubsetSums.Adaptive121Third107State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive121Third107Proof5 : runCachedNode 511 108868 Adaptive121Third107Node5 = false := by
  decide +kernel

#print axioms adaptive121Third107Proof5

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive121Third107Proof4 : runCachedNode 511 108868 Adaptive121Third107Node4 = false := by
  decide +kernel

#print axioms adaptive121Third107Proof4

end NineSeparatedSubsetSums
