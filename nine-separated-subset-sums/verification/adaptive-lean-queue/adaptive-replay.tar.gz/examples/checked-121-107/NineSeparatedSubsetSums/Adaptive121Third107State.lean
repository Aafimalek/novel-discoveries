import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive121Third107Node0 : CachedSearchNode :=
  ⟨4, 106, computeCenteredMask [148,121,107], 376, 47994⟩
def Adaptive121Third107Node1 : CachedSearchNode := cachedChild Adaptive121Third107Node0 104
def Adaptive121Third107Node2 : CachedSearchNode := cachedChild Adaptive121Third107Node0 105
def Adaptive121Third107Node3 : CachedSearchNode := cachedChild Adaptive121Third107Node2 102
def Adaptive121Third107Node4 : CachedSearchNode := cachedChild Adaptive121Third107Node2 103
def Adaptive121Third107Node5 : CachedSearchNode := cachedChild Adaptive121Third107Node2 104
def Adaptive121Third107Node6 : CachedSearchNode := cachedChild Adaptive121Third107Node0 106
def Adaptive121Third107Node7 : CachedSearchNode := cachedChild Adaptive121Third107Node6 102
def Adaptive121Third107Node8 : CachedSearchNode := cachedChild Adaptive121Third107Node6 103
def Adaptive121Third107Node9 : CachedSearchNode := cachedChild Adaptive121Third107Node6 104
def Adaptive121Third107Node10 : CachedSearchNode := cachedChild Adaptive121Third107Node6 105
def Adaptive121Third107Node11 : CachedSearchNode := cachedChild Adaptive121Third107Node10 100
def Adaptive121Third107Node12 : CachedSearchNode := cachedChild Adaptive121Third107Node10 101
def Adaptive121Third107Node13 : CachedSearchNode := cachedChild Adaptive121Third107Node10 102
def Adaptive121Third107Node14 : CachedSearchNode := cachedChild Adaptive121Third107Node10 103

end NineSeparatedSubsetSums
