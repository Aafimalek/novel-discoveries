import NineSeparatedSubsetSums.Adaptive121Third107State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive121Third107Proof7 : runCachedNode 511 108868 Adaptive121Third107Node7 = false := by
  decide +kernel

#print axioms adaptive121Third107Proof7

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive121Third107Proof11 : runCachedNode 511 108868 Adaptive121Third107Node11 = false := by
  decide +kernel

#print axioms adaptive121Third107Proof11

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive121Third107Proof12 : runCachedNode 511 108868 Adaptive121Third107Node12 = false := by
  decide +kernel

#print axioms adaptive121Third107Proof12

end NineSeparatedSubsetSums
