import NineSeparatedSubsetSums.FourPointPackedGeometry
import NineSeparatedSubsetSums.FourPoint121PackedBudget0
import NineSeparatedSubsetSums.FourPoint121PackedAnchor0Part0
import NineSeparatedSubsetSums.FourPoint121PackedAnchor0Part1
import NineSeparatedSubsetSums.FourPoint121PackedBudget1
import NineSeparatedSubsetSums.FourPoint121PackedAnchor1Part0
import NineSeparatedSubsetSums.FourPoint121PackedAnchor1Part1

namespace NineSeparatedSubsetSums

private theorem packed121Anchor0 :
  ∀ j : Fin 476, ((j.val : Int)+121)%2=0 →
    1051928 ≤ FourPointNumeric.packedCharge 121 20 packedWeight121_0 (j.val : Int) := by
  intro j hj
  let k := (j.val-1)/2
  have hk : k < 238 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+1 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := fourPoint121PackedAnchor0Part0 z
    rwa [he,hrep] at ht
  let z : Fin 118 := ⟨k-120, by omega⟩
  have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
  have ht := fourPoint121PackedAnchor0Part1 z
  rwa [he,hrep] at ht

private theorem packed121Anchor1 :
  ∀ j : Fin 476, ((j.val : Int)+121)%2=1 →
    1051924 ≤ FourPointNumeric.packedCharge 121 20 packedWeight121_1 (j.val : Int) := by
  intro j hj
  let k := (j.val-0)/2
  have hk : k < 238 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+0 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := fourPoint121PackedAnchor1Part0 z
    rwa [he,hrep] at ht
  let z : Fin 118 := ⟨k-120, by omega⟩
  have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
  have ht := fourPoint121PackedAnchor1Part1 z
  rwa [he,hrep] at ht

def packedCertificate121_0 : FourPointCertificate 121 0 108868 :=
  fourPointCertificateOfPacked 121 0 108868 1051928 20 packedWeight121_0 337 476
    (by decide +kernel) (by decide) (by decide) packed121Anchor0
    (by rw [packedWeight121_0_budget]; decide)

def packedCertificate121_1 : FourPointCertificate 121 1 108868 :=
  fourPointCertificateOfPacked 121 1 108868 1051924 20 packedWeight121_1 472 476
    (by decide +kernel) (by decide) (by decide) packed121Anchor1
    (by rw [packedWeight121_1_budget]; decide)

theorem max148_second121_fourPoint_moment_bound (tail : List ℕ) (len : tail.length=7)
    (distinct : (natSubsetSums (148::121::tail)).Nodup) :
    108868 ≤ ((148::121::tail).map (· ^ 2)).sum := by
  apply fourPointNatMomentLower 121 108868 tail len distinct
  intro p hp
  by_cases h : p=0
  · subst p
    exact packedCertificate121_0
  · have he : p=1 := hp.resolve_left h
    subst p
    exact packedCertificate121_1

#print axioms max148_second121_fourPoint_moment_bound

end NineSeparatedSubsetSums
