import NineSeparatedSubsetSums.FourPoint121PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem fourPoint121PackedAnchor1Part0 :
    ∀ j : Fin 120, 1051924 ≤ FourPointNumeric.packedCharge 121 20 packedWeight121_1
      (2*((j.val : Int)+0)+0) := by decide +kernel

end NineSeparatedSubsetSums
