import NineSeparatedSubsetSums.Adaptive121Third107State
import NineSeparatedSubsetSums.Adaptive121Third107Leaves0
import NineSeparatedSubsetSums.Adaptive121Third107Leaves1
import NineSeparatedSubsetSums.Adaptive121Third107Leaves4
import NineSeparatedSubsetSums.Adaptive121Third107Leaves3
import NineSeparatedSubsetSums.Adaptive121Third107Leaves2

namespace NineSeparatedSubsetSums

theorem adaptive121Third107Proof2 : runCachedNode 511 108868 Adaptive121Third107Node2 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 108868 Adaptive121Third107Node2 = [102, 103, 104] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl
  · exact adaptive121Third107Proof3
  · exact adaptive121Third107Proof4
  · exact adaptive121Third107Proof5

#print axioms adaptive121Third107Proof2

theorem adaptive121Third107Proof10 : runCachedNode 511 108868 Adaptive121Third107Node10 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 108868 Adaptive121Third107Node10 = [100, 101, 102, 103] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl
  · exact adaptive121Third107Proof11
  · exact adaptive121Third107Proof12
  · exact adaptive121Third107Proof13
  · exact adaptive121Third107Proof14

#print axioms adaptive121Third107Proof10

theorem adaptive121Third107Proof6 : runCachedNode 511 108868 Adaptive121Third107Node6 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 108868 Adaptive121Third107Node6 = [102, 103, 104, 105] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl
  · exact adaptive121Third107Proof7
  · exact adaptive121Third107Proof8
  · exact adaptive121Third107Proof9
  · exact adaptive121Third107Proof10

#print axioms adaptive121Third107Proof6

theorem adaptive121Third107Proof0 : runCachedNode 511 108868 Adaptive121Third107Node0 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 108868 Adaptive121Third107Node0 = [104, 105, 106] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl
  · exact adaptive121Third107Proof1
  · exact adaptive121Third107Proof2
  · exact adaptive121Third107Proof6

#print axioms adaptive121Third107Proof0

end NineSeparatedSubsetSums
