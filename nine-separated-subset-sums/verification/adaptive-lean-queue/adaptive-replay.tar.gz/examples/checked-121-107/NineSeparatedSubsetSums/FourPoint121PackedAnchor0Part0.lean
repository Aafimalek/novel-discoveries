import NineSeparatedSubsetSums.FourPoint121PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem fourPoint121PackedAnchor0Part0 :
    ∀ j : Fin 120, 1051928 ≤ FourPointNumeric.packedCharge 121 20 packedWeight121_0
      (2*((j.val : Int)+0)+1) := by decide +kernel

end NineSeparatedSubsetSums
