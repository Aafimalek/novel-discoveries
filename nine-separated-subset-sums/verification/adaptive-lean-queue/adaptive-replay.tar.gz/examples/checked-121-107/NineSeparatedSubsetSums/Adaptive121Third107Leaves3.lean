import NineSeparatedSubsetSums.Adaptive121Third107State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive121Third107Proof9 : runCachedNode 511 108868 Adaptive121Third107Node9 = false := by
  decide +kernel

#print axioms adaptive121Third107Proof9

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive121Third107Proof13 : runCachedNode 511 108868 Adaptive121Third107Node13 = false := by
  decide +kernel

#print axioms adaptive121Third107Proof13

end NineSeparatedSubsetSums
