import NineSeparatedSubsetSums.Adaptive121Third107State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive121Third107Proof14 : runCachedNode 511 108868 Adaptive121Third107Node14 = false := by
  decide +kernel

#print axioms adaptive121Third107Proof14

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive121Third107Proof8 : runCachedNode 511 108868 Adaptive121Third107Node8 = false := by
  decide +kernel

#print axioms adaptive121Third107Proof8

end NineSeparatedSubsetSums
