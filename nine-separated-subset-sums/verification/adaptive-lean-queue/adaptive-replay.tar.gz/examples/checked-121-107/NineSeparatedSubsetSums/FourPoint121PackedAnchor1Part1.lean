import NineSeparatedSubsetSums.FourPoint121PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem fourPoint121PackedAnchor1Part1 :
    ∀ j : Fin 118, 1051924 ≤ FourPointNumeric.packedCharge 121 20 packedWeight121_1
      (2*((j.val : Int)+120)+0) := by decide +kernel

end NineSeparatedSubsetSums
