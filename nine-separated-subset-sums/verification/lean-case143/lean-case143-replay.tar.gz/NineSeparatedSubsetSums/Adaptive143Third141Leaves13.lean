import NineSeparatedSubsetSums.Adaptive143Third141State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third141Proof224 : runCachedNode 511 130431 Adaptive143Third141Node224 = false := by
  decide +kernel

#print axioms adaptive143Third141Proof224

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third141Proof293 : runCachedNode 511 130431 Adaptive143Third141Node293 = false := by
  decide +kernel

#print axioms adaptive143Third141Proof293

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third141Proof100 : runCachedNode 511 130431 Adaptive143Third141Node100 = false := by
  decide +kernel

#print axioms adaptive143Third141Proof100

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third141Proof5 : runCachedNode 511 130431 Adaptive143Third141Node5 = false := by
  decide +kernel

#print axioms adaptive143Third141Proof5

end NineSeparatedSubsetSums
