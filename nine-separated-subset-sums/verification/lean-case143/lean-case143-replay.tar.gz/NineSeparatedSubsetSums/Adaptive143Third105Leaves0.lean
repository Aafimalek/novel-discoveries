import NineSeparatedSubsetSums.Adaptive143Third105State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third105Proof0 : runCachedNode 511 112040 Adaptive143Third105Node0 = false := by
  decide +kernel

#print axioms adaptive143Third105Proof0

end NineSeparatedSubsetSums
