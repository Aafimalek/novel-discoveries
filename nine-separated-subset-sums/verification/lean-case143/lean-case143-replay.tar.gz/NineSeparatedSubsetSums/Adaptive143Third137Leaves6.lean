import NineSeparatedSubsetSums.Adaptive143Third137State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third137Proof160 : runCachedNode 511 129784 Adaptive143Third137Node160 = false := by
  decide +kernel

#print axioms adaptive143Third137Proof160

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third137Proof16 : runCachedNode 511 129784 Adaptive143Third137Node16 = false := by
  decide +kernel

#print axioms adaptive143Third137Proof16

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third137Proof126 : runCachedNode 511 129784 Adaptive143Third137Node126 = false := by
  decide +kernel

#print axioms adaptive143Third137Proof126

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third137Proof8 : runCachedNode 511 129784 Adaptive143Third137Node8 = false := by
  decide +kernel

#print axioms adaptive143Third137Proof8

end NineSeparatedSubsetSums
