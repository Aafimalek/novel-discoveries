import NineSeparatedSubsetSums.Adaptive143Third140State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third140Proof169 : runCachedNode 511 130276 Adaptive143Third140Node169 = false := by
  decide +kernel

#print axioms adaptive143Third140Proof169

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third140Proof196 : runCachedNode 511 130276 Adaptive143Third140Node196 = false := by
  decide +kernel

#print axioms adaptive143Third140Proof196

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third140Proof67 : runCachedNode 511 130276 Adaptive143Third140Node67 = false := by
  decide +kernel

#print axioms adaptive143Third140Proof67

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third140Proof79 : runCachedNode 511 130276 Adaptive143Third140Node79 = false := by
  decide +kernel

#print axioms adaptive143Third140Proof79

end NineSeparatedSubsetSums
