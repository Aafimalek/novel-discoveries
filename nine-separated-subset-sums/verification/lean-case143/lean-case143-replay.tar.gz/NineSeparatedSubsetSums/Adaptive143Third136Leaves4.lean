import NineSeparatedSubsetSums.Adaptive143Third136State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third136Proof74 : runCachedNode 511 129643 Adaptive143Third136Node74 = false := by
  decide +kernel

#print axioms adaptive143Third136Proof74

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third136Proof18 : runCachedNode 511 129643 Adaptive143Third136Node18 = false := by
  decide +kernel

#print axioms adaptive143Third136Proof18

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third136Proof11 : runCachedNode 511 129643 Adaptive143Third136Node11 = false := by
  decide +kernel

#print axioms adaptive143Third136Proof11

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third136Proof6 : runCachedNode 511 129643 Adaptive143Third136Node6 = false := by
  decide +kernel

#print axioms adaptive143Third136Proof6

end NineSeparatedSubsetSums
