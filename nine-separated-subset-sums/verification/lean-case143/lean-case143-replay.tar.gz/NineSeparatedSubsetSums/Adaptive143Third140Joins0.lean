import NineSeparatedSubsetSums.Adaptive143Third140State
import NineSeparatedSubsetSums.Adaptive143Third140Leaves31
import NineSeparatedSubsetSums.Adaptive143Third140Leaves8
import NineSeparatedSubsetSums.Adaptive143Third140Leaves30
import NineSeparatedSubsetSums.Adaptive143Third140Leaves29
import NineSeparatedSubsetSums.Adaptive143Third140Leaves17
import NineSeparatedSubsetSums.Adaptive143Third140Leaves7
import NineSeparatedSubsetSums.Adaptive143Third140Leaves28
import NineSeparatedSubsetSums.Adaptive143Third140Leaves27
import NineSeparatedSubsetSums.Adaptive143Third140Leaves20
import NineSeparatedSubsetSums.Adaptive143Third140Leaves26
import NineSeparatedSubsetSums.Adaptive143Third140Leaves25
import NineSeparatedSubsetSums.Adaptive143Third140Leaves24
import NineSeparatedSubsetSums.Adaptive143Third140Leaves21
import NineSeparatedSubsetSums.Adaptive143Third140Leaves4
import NineSeparatedSubsetSums.Adaptive143Third140Leaves22
import NineSeparatedSubsetSums.Adaptive143Third140Leaves23
import NineSeparatedSubsetSums.Adaptive143Third140Leaves19
import NineSeparatedSubsetSums.Adaptive143Third140Leaves15
import NineSeparatedSubsetSums.Adaptive143Third140Leaves12
import NineSeparatedSubsetSums.Adaptive143Third140Leaves13
import NineSeparatedSubsetSums.Adaptive143Third140Leaves2
import NineSeparatedSubsetSums.Adaptive143Third140Leaves5
import NineSeparatedSubsetSums.Adaptive143Third140Leaves0
import NineSeparatedSubsetSums.Adaptive143Third140Leaves6
import NineSeparatedSubsetSums.Adaptive143Third140Leaves11
import NineSeparatedSubsetSums.Adaptive143Third140Leaves18
import NineSeparatedSubsetSums.Adaptive143Third140Leaves16
import NineSeparatedSubsetSums.Adaptive143Third140Leaves32
import NineSeparatedSubsetSums.Adaptive143Third140Leaves14
import NineSeparatedSubsetSums.Adaptive143Third140Leaves10
import NineSeparatedSubsetSums.Adaptive143Third140Leaves3

namespace NineSeparatedSubsetSums

theorem adaptive143Third140Proof23 : runCachedNode 511 130276 Adaptive143Third140Node23 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130276 Adaptive143Third140Node23 = [103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 125, 126, 128, 130, 131] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive143Third140Proof24
  · exact adaptive143Third140Proof25
  · exact adaptive143Third140Proof26
  · exact adaptive143Third140Proof27
  · exact adaptive143Third140Proof28
  · exact adaptive143Third140Proof29
  · exact adaptive143Third140Proof30
  · exact adaptive143Third140Proof31
  · exact adaptive143Third140Proof32
  · exact adaptive143Third140Proof33
  · exact adaptive143Third140Proof34
  · exact adaptive143Third140Proof35
  · exact adaptive143Third140Proof36
  · exact adaptive143Third140Proof37
  · exact adaptive143Third140Proof38
  · exact adaptive143Third140Proof39
  · exact adaptive143Third140Proof40
  · exact adaptive143Third140Proof41
  · exact adaptive143Third140Proof42
  · exact adaptive143Third140Proof43
  · exact adaptive143Third140Proof44
  · exact adaptive143Third140Proof45
  · exact adaptive143Third140Proof46
  · exact adaptive143Third140Proof47
  · exact adaptive143Third140Proof48
  · exact adaptive143Third140Proof49

#print axioms adaptive143Third140Proof23

theorem adaptive143Third140Proof50 : runCachedNode 511 130276 Adaptive143Third140Node50 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130276 Adaptive143Third140Node50 = [103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 126, 127, 129, 131, 132] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive143Third140Proof51
  · exact adaptive143Third140Proof52
  · exact adaptive143Third140Proof53
  · exact adaptive143Third140Proof54
  · exact adaptive143Third140Proof55
  · exact adaptive143Third140Proof56
  · exact adaptive143Third140Proof57
  · exact adaptive143Third140Proof58
  · exact adaptive143Third140Proof59
  · exact adaptive143Third140Proof60
  · exact adaptive143Third140Proof61
  · exact adaptive143Third140Proof62
  · exact adaptive143Third140Proof63
  · exact adaptive143Third140Proof64
  · exact adaptive143Third140Proof65
  · exact adaptive143Third140Proof66
  · exact adaptive143Third140Proof67
  · exact adaptive143Third140Proof68
  · exact adaptive143Third140Proof69
  · exact adaptive143Third140Proof70
  · exact adaptive143Third140Proof71
  · exact adaptive143Third140Proof72
  · exact adaptive143Third140Proof73
  · exact adaptive143Third140Proof74
  · exact adaptive143Third140Proof75
  · exact adaptive143Third140Proof76
  · exact adaptive143Third140Proof77

#print axioms adaptive143Third140Proof50

theorem adaptive143Third140Proof78 : runCachedNode 511 130276 Adaptive143Third140Node78 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130276 Adaptive143Third140Node78 = [103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 127, 128, 130, 132, 133] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive143Third140Proof79
  · exact adaptive143Third140Proof80
  · exact adaptive143Third140Proof81
  · exact adaptive143Third140Proof82
  · exact adaptive143Third140Proof83
  · exact adaptive143Third140Proof84
  · exact adaptive143Third140Proof85
  · exact adaptive143Third140Proof86
  · exact adaptive143Third140Proof87
  · exact adaptive143Third140Proof88
  · exact adaptive143Third140Proof89
  · exact adaptive143Third140Proof90
  · exact adaptive143Third140Proof91
  · exact adaptive143Third140Proof92
  · exact adaptive143Third140Proof93
  · exact adaptive143Third140Proof94
  · exact adaptive143Third140Proof95
  · exact adaptive143Third140Proof96
  · exact adaptive143Third140Proof97
  · exact adaptive143Third140Proof98
  · exact adaptive143Third140Proof99
  · exact adaptive143Third140Proof100
  · exact adaptive143Third140Proof101
  · exact adaptive143Third140Proof102
  · exact adaptive143Third140Proof103
  · exact adaptive143Third140Proof104
  · exact adaptive143Third140Proof105
  · exact adaptive143Third140Proof106

#print axioms adaptive143Third140Proof78

theorem adaptive143Third140Proof107 : runCachedNode 511 130276 Adaptive143Third140Node107 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130276 Adaptive143Third140Node107 = [102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 129, 130, 132, 134] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive143Third140Proof108
  · exact adaptive143Third140Proof109
  · exact adaptive143Third140Proof110
  · exact adaptive143Third140Proof111
  · exact adaptive143Third140Proof112
  · exact adaptive143Third140Proof113
  · exact adaptive143Third140Proof114
  · exact adaptive143Third140Proof115
  · exact adaptive143Third140Proof116
  · exact adaptive143Third140Proof117
  · exact adaptive143Third140Proof118
  · exact adaptive143Third140Proof119
  · exact adaptive143Third140Proof120
  · exact adaptive143Third140Proof121
  · exact adaptive143Third140Proof122
  · exact adaptive143Third140Proof123
  · exact adaptive143Third140Proof124
  · exact adaptive143Third140Proof125
  · exact adaptive143Third140Proof126
  · exact adaptive143Third140Proof127
  · exact adaptive143Third140Proof128
  · exact adaptive143Third140Proof129
  · exact adaptive143Third140Proof130
  · exact adaptive143Third140Proof131
  · exact adaptive143Third140Proof132
  · exact adaptive143Third140Proof133
  · exact adaptive143Third140Proof134
  · exact adaptive143Third140Proof135
  · exact adaptive143Third140Proof136
  · exact adaptive143Third140Proof137

#print axioms adaptive143Third140Proof107

theorem adaptive143Third140Proof138 : runCachedNode 511 130276 Adaptive143Third140Node138 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130276 Adaptive143Third140Node138 = [102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 130, 131, 133, 136] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive143Third140Proof139
  · exact adaptive143Third140Proof140
  · exact adaptive143Third140Proof141
  · exact adaptive143Third140Proof142
  · exact adaptive143Third140Proof143
  · exact adaptive143Third140Proof144
  · exact adaptive143Third140Proof145
  · exact adaptive143Third140Proof146
  · exact adaptive143Third140Proof147
  · exact adaptive143Third140Proof148
  · exact adaptive143Third140Proof149
  · exact adaptive143Third140Proof150
  · exact adaptive143Third140Proof151
  · exact adaptive143Third140Proof152
  · exact adaptive143Third140Proof153
  · exact adaptive143Third140Proof154
  · exact adaptive143Third140Proof155
  · exact adaptive143Third140Proof156
  · exact adaptive143Third140Proof157
  · exact adaptive143Third140Proof158
  · exact adaptive143Third140Proof159
  · exact adaptive143Third140Proof160
  · exact adaptive143Third140Proof161
  · exact adaptive143Third140Proof162
  · exact adaptive143Third140Proof163
  · exact adaptive143Third140Proof164
  · exact adaptive143Third140Proof165
  · exact adaptive143Third140Proof166
  · exact adaptive143Third140Proof167
  · exact adaptive143Third140Proof168
  · exact adaptive143Third140Proof169

#print axioms adaptive143Third140Proof138

theorem adaptive143Third140Proof202 : runCachedNode 511 130276 Adaptive143Third140Node202 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130276 Adaptive143Third140Node202 = [90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 124, 125, 127, 132] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive143Third140Proof203
  · exact adaptive143Third140Proof204
  · exact adaptive143Third140Proof205
  · exact adaptive143Third140Proof206
  · exact adaptive143Third140Proof207
  · exact adaptive143Third140Proof208
  · exact adaptive143Third140Proof209
  · exact adaptive143Third140Proof210
  · exact adaptive143Third140Proof211
  · exact adaptive143Third140Proof212
  · exact adaptive143Third140Proof213
  · exact adaptive143Third140Proof214
  · exact adaptive143Third140Proof215
  · exact adaptive143Third140Proof216
  · exact adaptive143Third140Proof217
  · exact adaptive143Third140Proof218
  · exact adaptive143Third140Proof219
  · exact adaptive143Third140Proof220
  · exact adaptive143Third140Proof221
  · exact adaptive143Third140Proof222
  · exact adaptive143Third140Proof223
  · exact adaptive143Third140Proof224
  · exact adaptive143Third140Proof225
  · exact adaptive143Third140Proof226
  · exact adaptive143Third140Proof227
  · exact adaptive143Third140Proof228
  · exact adaptive143Third140Proof229
  · exact adaptive143Third140Proof230
  · exact adaptive143Third140Proof231
  · exact adaptive143Third140Proof232
  · exact adaptive143Third140Proof233
  · exact adaptive143Third140Proof234
  · exact adaptive143Third140Proof235
  · exact adaptive143Third140Proof236
  · exact adaptive143Third140Proof237
  · exact adaptive143Third140Proof238
  · exact adaptive143Third140Proof239

#print axioms adaptive143Third140Proof202

theorem adaptive143Third140Proof240 : runCachedNode 511 130276 Adaptive143Third140Node240 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130276 Adaptive143Third140Node240 = [89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 125, 126, 128, 131] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive143Third140Proof241
  · exact adaptive143Third140Proof242
  · exact adaptive143Third140Proof243
  · exact adaptive143Third140Proof244
  · exact adaptive143Third140Proof245
  · exact adaptive143Third140Proof246
  · exact adaptive143Third140Proof247
  · exact adaptive143Third140Proof248
  · exact adaptive143Third140Proof249
  · exact adaptive143Third140Proof250
  · exact adaptive143Third140Proof251
  · exact adaptive143Third140Proof252
  · exact adaptive143Third140Proof253
  · exact adaptive143Third140Proof254
  · exact adaptive143Third140Proof255
  · exact adaptive143Third140Proof256
  · exact adaptive143Third140Proof257
  · exact adaptive143Third140Proof258
  · exact adaptive143Third140Proof259
  · exact adaptive143Third140Proof260
  · exact adaptive143Third140Proof261
  · exact adaptive143Third140Proof262
  · exact adaptive143Third140Proof263
  · exact adaptive143Third140Proof264
  · exact adaptive143Third140Proof265
  · exact adaptive143Third140Proof266
  · exact adaptive143Third140Proof267
  · exact adaptive143Third140Proof268
  · exact adaptive143Third140Proof269
  · exact adaptive143Third140Proof270
  · exact adaptive143Third140Proof271
  · exact adaptive143Third140Proof272
  · exact adaptive143Third140Proof273
  · exact adaptive143Third140Proof274
  · exact adaptive143Third140Proof275
  · exact adaptive143Third140Proof276
  · exact adaptive143Third140Proof277
  · exact adaptive143Third140Proof278
  · exact adaptive143Third140Proof279

#print axioms adaptive143Third140Proof240

theorem adaptive143Third140Proof170 : runCachedNode 511 130276 Adaptive143Third140Node170 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130276 Adaptive143Third140Node170 = [102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 131, 132, 134, 136, 137] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive143Third140Proof171
  · exact adaptive143Third140Proof172
  · exact adaptive143Third140Proof173
  · exact adaptive143Third140Proof174
  · exact adaptive143Third140Proof175
  · exact adaptive143Third140Proof176
  · exact adaptive143Third140Proof177
  · exact adaptive143Third140Proof178
  · exact adaptive143Third140Proof179
  · exact adaptive143Third140Proof180
  · exact adaptive143Third140Proof181
  · exact adaptive143Third140Proof182
  · exact adaptive143Third140Proof183
  · exact adaptive143Third140Proof184
  · exact adaptive143Third140Proof185
  · exact adaptive143Third140Proof186
  · exact adaptive143Third140Proof187
  · exact adaptive143Third140Proof188
  · exact adaptive143Third140Proof189
  · exact adaptive143Third140Proof190
  · exact adaptive143Third140Proof191
  · exact adaptive143Third140Proof192
  · exact adaptive143Third140Proof193
  · exact adaptive143Third140Proof194
  · exact adaptive143Third140Proof195
  · exact adaptive143Third140Proof196
  · exact adaptive143Third140Proof197
  · exact adaptive143Third140Proof198
  · exact adaptive143Third140Proof199
  · exact adaptive143Third140Proof200
  · exact adaptive143Third140Proof201
  · exact adaptive143Third140Proof202
  · exact adaptive143Third140Proof240

#print axioms adaptive143Third140Proof170

end NineSeparatedSubsetSums
