import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive143Third112Node0 : CachedSearchNode :=
  ⟨4, 111, computeCenteredMask [148,143,112], 403, 54897⟩

end NineSeparatedSubsetSums
