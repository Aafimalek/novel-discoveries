import NineSeparatedSubsetSums.Adaptive143Third115State
import NineSeparatedSubsetSums.Adaptive143Third115Leaves0
import NineSeparatedSubsetSums.Adaptive143Third115Leaves1

namespace NineSeparatedSubsetSums

theorem adaptive143Third115Proof0 : runCachedNode 511 112040 Adaptive143Third115Node0 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 112040 Adaptive143Third115Node0 = [100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 111, 112, 113, 114] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive143Third115Proof1
  · exact adaptive143Third115Proof2
  · exact adaptive143Third115Proof3
  · exact adaptive143Third115Proof4
  · exact adaptive143Third115Proof5
  · exact adaptive143Third115Proof6
  · exact adaptive143Third115Proof7
  · exact adaptive143Third115Proof8
  · exact adaptive143Third115Proof9
  · exact adaptive143Third115Proof10
  · exact adaptive143Third115Proof11
  · exact adaptive143Third115Proof12
  · exact adaptive143Third115Proof13
  · exact adaptive143Third115Proof14

#print axioms adaptive143Third115Proof0

end NineSeparatedSubsetSums
