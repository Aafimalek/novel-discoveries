import NineSeparatedSubsetSums.EightPoint143_124PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint143_124PackedAnchor0Part1 :
    ∀ j : Fin 120, 2340350 ≤ FourPointNumeric.octPackedCharge 143 124 20 packedOct143_124_0
      (2*((j.val : Int)+120)+1) := by decide +kernel

end NineSeparatedSubsetSums
