import NineSeparatedSubsetSums.Adaptive143Third138State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third138Proof227 : runCachedNode 511 129927 Adaptive143Third138Node227 = false := by
  decide +kernel

#print axioms adaptive143Third138Proof227

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third138Proof113 : runCachedNode 511 129927 Adaptive143Third138Node113 = false := by
  decide +kernel

#print axioms adaptive143Third138Proof113

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third138Proof212 : runCachedNode 511 129927 Adaptive143Third138Node212 = false := by
  decide +kernel

#print axioms adaptive143Third138Proof212

end NineSeparatedSubsetSums
