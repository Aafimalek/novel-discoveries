import NineSeparatedSubsetSums.Adaptive143Third137State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third137Proof14 : runCachedNode 511 129784 Adaptive143Third137Node14 = false := by
  decide +kernel

#print axioms adaptive143Third137Proof14

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third137Proof45 : runCachedNode 511 129784 Adaptive143Third137Node45 = false := by
  decide +kernel

#print axioms adaptive143Third137Proof45

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third137Proof13 : runCachedNode 511 129784 Adaptive143Third137Node13 = false := by
  decide +kernel

#print axioms adaptive143Third137Proof13

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third137Proof71 : runCachedNode 511 129784 Adaptive143Third137Node71 = false := by
  decide +kernel

#print axioms adaptive143Third137Proof71

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third137Proof43 : runCachedNode 511 129784 Adaptive143Third137Node43 = false := by
  decide +kernel

#print axioms adaptive143Third137Proof43

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third137Proof153 : runCachedNode 511 129784 Adaptive143Third137Node153 = false := by
  decide +kernel

#print axioms adaptive143Third137Proof153

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third137Proof156 : runCachedNode 511 129784 Adaptive143Third137Node156 = false := by
  decide +kernel

#print axioms adaptive143Third137Proof156

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third137Proof25 : runCachedNode 511 129784 Adaptive143Third137Node25 = false := by
  decide +kernel

#print axioms adaptive143Third137Proof25

end NineSeparatedSubsetSums
