import NineSeparatedSubsetSums.Adaptive143Third141State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third141Proof193 : runCachedNode 511 130431 Adaptive143Third141Node193 = false := by
  decide +kernel

#print axioms adaptive143Third141Proof193

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third141Proof296 : runCachedNode 511 130431 Adaptive143Third141Node296 = false := by
  decide +kernel

#print axioms adaptive143Third141Proof296

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third141Proof28 : runCachedNode 511 130431 Adaptive143Third141Node28 = false := by
  decide +kernel

#print axioms adaptive143Third141Proof28

end NineSeparatedSubsetSums
