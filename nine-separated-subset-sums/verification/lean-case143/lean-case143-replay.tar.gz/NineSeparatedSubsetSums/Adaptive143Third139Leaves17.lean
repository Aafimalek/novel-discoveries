import NineSeparatedSubsetSums.Adaptive143Third139State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third139Proof238 : runCachedNode 511 130096 Adaptive143Third139Node238 = false := by
  decide +kernel

#print axioms adaptive143Third139Proof238

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third139Proof178 : runCachedNode 511 130096 Adaptive143Third139Node178 = false := by
  decide +kernel

#print axioms adaptive143Third139Proof178

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third139Proof40 : runCachedNode 511 130096 Adaptive143Third139Node40 = false := by
  decide +kernel

#print axioms adaptive143Third139Proof40

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third139Proof12 : runCachedNode 511 130096 Adaptive143Third139Node12 = false := by
  decide +kernel

#print axioms adaptive143Third139Proof12

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third139Proof177 : runCachedNode 511 130096 Adaptive143Third139Node177 = false := by
  decide +kernel

#print axioms adaptive143Third139Proof177

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third139Proof180 : runCachedNode 511 130096 Adaptive143Third139Node180 = false := by
  decide +kernel

#print axioms adaptive143Third139Proof180

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third139Proof41 : runCachedNode 511 130096 Adaptive143Third139Node41 = false := by
  decide +kernel

#print axioms adaptive143Third139Proof41

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third139Proof236 : runCachedNode 511 130096 Adaptive143Third139Node236 = false := by
  decide +kernel

#print axioms adaptive143Third139Proof236

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third139Proof11 : runCachedNode 511 130096 Adaptive143Third139Node11 = false := by
  decide +kernel

#print axioms adaptive143Third139Proof11

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third139Proof141 : runCachedNode 511 130096 Adaptive143Third139Node141 = false := by
  decide +kernel

#print axioms adaptive143Third139Proof141

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third139Proof71 : runCachedNode 511 130096 Adaptive143Third139Node71 = false := by
  decide +kernel

#print axioms adaptive143Third139Proof71

end NineSeparatedSubsetSums
