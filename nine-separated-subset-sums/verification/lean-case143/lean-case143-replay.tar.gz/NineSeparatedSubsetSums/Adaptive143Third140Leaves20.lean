import NineSeparatedSubsetSums.Adaptive143Third140State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third140Proof103 : runCachedNode 511 130276 Adaptive143Third140Node103 = false := by
  decide +kernel

#print axioms adaptive143Third140Proof103

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third140Proof351 : runCachedNode 511 130276 Adaptive143Third140Node351 = false := by
  decide +kernel

#print axioms adaptive143Third140Proof351

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third140Proof306 : runCachedNode 511 130276 Adaptive143Third140Node306 = false := by
  decide +kernel

#print axioms adaptive143Third140Proof306

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third140Proof238 : runCachedNode 511 130276 Adaptive143Third140Node238 = false := by
  decide +kernel

#print axioms adaptive143Third140Proof238

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third140Proof309 : runCachedNode 511 130276 Adaptive143Third140Node309 = false := by
  decide +kernel

#print axioms adaptive143Third140Proof309

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third140Proof13 : runCachedNode 511 130276 Adaptive143Third140Node13 = false := by
  decide +kernel

#print axioms adaptive143Third140Proof13

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third140Proof37 : runCachedNode 511 130276 Adaptive143Third140Node37 = false := by
  decide +kernel

#print axioms adaptive143Third140Proof37

end NineSeparatedSubsetSums
