import NineSeparatedSubsetSums.Adaptive143Third142State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third142Proof441 : runCachedNode 511 130584 Adaptive143Third142Node441 = false := by
  decide +kernel

#print axioms adaptive143Third142Proof441

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third142Proof159 : runCachedNode 511 130584 Adaptive143Third142Node159 = false := by
  decide +kernel

#print axioms adaptive143Third142Proof159

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third142Proof127 : runCachedNode 511 130584 Adaptive143Third142Node127 = false := by
  decide +kernel

#print axioms adaptive143Third142Proof127

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third142Proof220 : runCachedNode 511 130584 Adaptive143Third142Node220 = false := by
  decide +kernel

#print axioms adaptive143Third142Proof220

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third142Proof366 : runCachedNode 511 130584 Adaptive143Third142Node366 = false := by
  decide +kernel

#print axioms adaptive143Third142Proof366

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third142Proof367 : runCachedNode 511 130584 Adaptive143Third142Node367 = false := by
  decide +kernel

#print axioms adaptive143Third142Proof367

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third142Proof126 : runCachedNode 511 130584 Adaptive143Third142Node126 = false := by
  decide +kernel

#print axioms adaptive143Third142Proof126

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third142Proof6 : runCachedNode 511 130584 Adaptive143Third142Node6 = false := by
  decide +kernel

#print axioms adaptive143Third142Proof6

end NineSeparatedSubsetSums
