import NineSeparatedSubsetSums.Adaptive143Third141State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third141Proof14 : runCachedNode 511 130431 Adaptive143Third141Node14 = false := by
  decide +kernel

#print axioms adaptive143Third141Proof14

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third141Proof291 : runCachedNode 511 130431 Adaptive143Third141Node291 = false := by
  decide +kernel

#print axioms adaptive143Third141Proof291

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third141Proof452 : runCachedNode 511 130431 Adaptive143Third141Node452 = false := by
  decide +kernel

#print axioms adaptive143Third141Proof452

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third141Proof189 : runCachedNode 511 130431 Adaptive143Third141Node189 = false := by
  decide +kernel

#print axioms adaptive143Third141Proof189

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third141Proof126 : runCachedNode 511 130431 Adaptive143Third141Node126 = false := by
  decide +kernel

#print axioms adaptive143Third141Proof126

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third141Proof93 : runCachedNode 511 130431 Adaptive143Third141Node93 = false := by
  decide +kernel

#print axioms adaptive143Third141Proof93

end NineSeparatedSubsetSums
