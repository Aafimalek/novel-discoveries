import NineSeparatedSubsetSums.Adaptive143Third136State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third136Proof102 : runCachedNode 511 129643 Adaptive143Third136Node102 = false := by
  decide +kernel

#print axioms adaptive143Third136Proof102

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third136Proof16 : runCachedNode 511 129643 Adaptive143Third136Node16 = false := by
  decide +kernel

#print axioms adaptive143Third136Proof16

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third136Proof46 : runCachedNode 511 129643 Adaptive143Third136Node46 = false := by
  decide +kernel

#print axioms adaptive143Third136Proof46

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third136Proof75 : runCachedNode 511 129643 Adaptive143Third136Node75 = false := by
  decide +kernel

#print axioms adaptive143Third136Proof75

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third136Proof67 : runCachedNode 511 129643 Adaptive143Third136Node67 = false := by
  decide +kernel

#print axioms adaptive143Third136Proof67

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third136Proof53 : runCachedNode 511 129643 Adaptive143Third136Node53 = false := by
  decide +kernel

#print axioms adaptive143Third136Proof53

end NineSeparatedSubsetSums
