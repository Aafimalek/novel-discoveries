import NineSeparatedSubsetSums.Adaptive143Third133State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third133Proof22 : runCachedNode 511 129127 Adaptive143Third133Node22 = false := by
  decide +kernel

#print axioms adaptive143Third133Proof22

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third133Proof17 : runCachedNode 511 129127 Adaptive143Third133Node17 = false := by
  decide +kernel

#print axioms adaptive143Third133Proof17

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third133Proof2 : runCachedNode 511 129127 Adaptive143Third133Node2 = false := by
  decide +kernel

#print axioms adaptive143Third133Proof2

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third133Proof1 : runCachedNode 511 129127 Adaptive143Third133Node1 = false := by
  decide +kernel

#print axioms adaptive143Third133Proof1

end NineSeparatedSubsetSums
