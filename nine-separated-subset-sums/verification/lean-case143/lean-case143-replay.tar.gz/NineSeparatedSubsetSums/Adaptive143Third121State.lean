import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive143Third121Node0 : CachedSearchNode :=
  ⟨4, 120, computeCenteredMask [148,143,121], 412, 56994⟩

end NineSeparatedSubsetSums
