import NineSeparatedSubsetSums.Adaptive143Third138State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third138Proof16 : runCachedNode 511 129927 Adaptive143Third138Node16 = false := by
  decide +kernel

#print axioms adaptive143Third138Proof16

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third138Proof64 : runCachedNode 511 129927 Adaptive143Third138Node64 = false := by
  decide +kernel

#print axioms adaptive143Third138Proof64

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third138Proof33 : runCachedNode 511 129927 Adaptive143Third138Node33 = false := by
  decide +kernel

#print axioms adaptive143Third138Proof33

end NineSeparatedSubsetSums
