import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive143Third134Node0 : CachedSearchNode :=
  ⟨4, 133, computeCenteredMask [148,143,134], 425, 60309⟩
def Adaptive143Third134Node1 : CachedSearchNode := cachedChild Adaptive143Third134Node0 110
def Adaptive143Third134Node2 : CachedSearchNode := cachedChild Adaptive143Third134Node0 111
def Adaptive143Third134Node3 : CachedSearchNode := cachedChild Adaptive143Third134Node0 112
def Adaptive143Third134Node4 : CachedSearchNode := cachedChild Adaptive143Third134Node0 113
def Adaptive143Third134Node5 : CachedSearchNode := cachedChild Adaptive143Third134Node0 114
def Adaptive143Third134Node6 : CachedSearchNode := cachedChild Adaptive143Third134Node0 115
def Adaptive143Third134Node7 : CachedSearchNode := cachedChild Adaptive143Third134Node0 116
def Adaptive143Third134Node8 : CachedSearchNode := cachedChild Adaptive143Third134Node0 117
def Adaptive143Third134Node9 : CachedSearchNode := cachedChild Adaptive143Third134Node0 118
def Adaptive143Third134Node10 : CachedSearchNode := cachedChild Adaptive143Third134Node0 119
def Adaptive143Third134Node11 : CachedSearchNode := cachedChild Adaptive143Third134Node0 120
def Adaptive143Third134Node12 : CachedSearchNode := cachedChild Adaptive143Third134Node0 121
def Adaptive143Third134Node13 : CachedSearchNode := cachedChild Adaptive143Third134Node0 122
def Adaptive143Third134Node14 : CachedSearchNode := cachedChild Adaptive143Third134Node0 123
def Adaptive143Third134Node15 : CachedSearchNode := cachedChild Adaptive143Third134Node0 124
def Adaptive143Third134Node16 : CachedSearchNode := cachedChild Adaptive143Third134Node0 125
def Adaptive143Third134Node17 : CachedSearchNode := cachedChild Adaptive143Third134Node0 126
def Adaptive143Third134Node18 : CachedSearchNode := cachedChild Adaptive143Third134Node0 127
def Adaptive143Third134Node19 : CachedSearchNode := cachedChild Adaptive143Third134Node0 128
def Adaptive143Third134Node20 : CachedSearchNode := cachedChild Adaptive143Third134Node0 130
def Adaptive143Third134Node21 : CachedSearchNode := cachedChild Adaptive143Third134Node0 131
def Adaptive143Third134Node22 : CachedSearchNode := cachedChild Adaptive143Third134Node0 132
def Adaptive143Third134Node23 : CachedSearchNode := cachedChild Adaptive143Third134Node0 133

end NineSeparatedSubsetSums
