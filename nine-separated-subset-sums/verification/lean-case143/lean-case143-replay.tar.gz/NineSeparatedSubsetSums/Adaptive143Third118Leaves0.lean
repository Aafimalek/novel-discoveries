import NineSeparatedSubsetSums.Adaptive143Third118State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third118Proof0 : runCachedNode 511 125693 Adaptive143Third118Node0 = false := by
  decide +kernel

#print axioms adaptive143Third118Proof0

end NineSeparatedSubsetSums
