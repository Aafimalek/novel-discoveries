import NineSeparatedSubsetSums.Adaptive143Third134State
import NineSeparatedSubsetSums.Adaptive143Third134Leaves1
import NineSeparatedSubsetSums.Adaptive143Third134Leaves3
import NineSeparatedSubsetSums.Adaptive143Third134Leaves0
import NineSeparatedSubsetSums.Adaptive143Third134Leaves4
import NineSeparatedSubsetSums.Adaptive143Third134Leaves2
import NineSeparatedSubsetSums.Adaptive143Third134Leaves5

namespace NineSeparatedSubsetSums

theorem adaptive143Third134Proof0 : runCachedNode 511 129375 Adaptive143Third134Node0 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 129375 Adaptive143Third134Node0 = [110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 130, 131, 132, 133] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive143Third134Proof1
  · exact adaptive143Third134Proof2
  · exact adaptive143Third134Proof3
  · exact adaptive143Third134Proof4
  · exact adaptive143Third134Proof5
  · exact adaptive143Third134Proof6
  · exact adaptive143Third134Proof7
  · exact adaptive143Third134Proof8
  · exact adaptive143Third134Proof9
  · exact adaptive143Third134Proof10
  · exact adaptive143Third134Proof11
  · exact adaptive143Third134Proof12
  · exact adaptive143Third134Proof13
  · exact adaptive143Third134Proof14
  · exact adaptive143Third134Proof15
  · exact adaptive143Third134Proof16
  · exact adaptive143Third134Proof17
  · exact adaptive143Third134Proof18
  · exact adaptive143Third134Proof19
  · exact adaptive143Third134Proof20
  · exact adaptive143Third134Proof21
  · exact adaptive143Third134Proof22
  · exact adaptive143Third134Proof23

#print axioms adaptive143Third134Proof0

end NineSeparatedSubsetSums
