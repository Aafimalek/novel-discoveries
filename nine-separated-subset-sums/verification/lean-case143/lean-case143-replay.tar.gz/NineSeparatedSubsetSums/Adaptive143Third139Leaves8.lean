import NineSeparatedSubsetSums.Adaptive143Third139State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third139Proof19 : runCachedNode 511 130096 Adaptive143Third139Node19 = false := by
  decide +kernel

#print axioms adaptive143Third139Proof19

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third139Proof213 : runCachedNode 511 130096 Adaptive143Third139Node213 = false := by
  decide +kernel

#print axioms adaptive143Third139Proof213

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third139Proof146 : runCachedNode 511 130096 Adaptive143Third139Node146 = false := by
  decide +kernel

#print axioms adaptive143Third139Proof146

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third139Proof249 : runCachedNode 511 130096 Adaptive143Third139Node249 = false := by
  decide +kernel

#print axioms adaptive143Third139Proof249

end NineSeparatedSubsetSums
