import NineSeparatedSubsetSums.Adaptive143Third141State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third141Proof17 : runCachedNode 511 130431 Adaptive143Third141Node17 = false := by
  decide +kernel

#print axioms adaptive143Third141Proof17

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third141Proof125 : runCachedNode 511 130431 Adaptive143Third141Node125 = false := by
  decide +kernel

#print axioms adaptive143Third141Proof125

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third141Proof158 : runCachedNode 511 130431 Adaptive143Third141Node158 = false := by
  decide +kernel

#print axioms adaptive143Third141Proof158

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third141Proof51 : runCachedNode 511 130431 Adaptive143Third141Node51 = false := by
  decide +kernel

#print axioms adaptive143Third141Proof51

end NineSeparatedSubsetSums
