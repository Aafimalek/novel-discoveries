import NineSeparatedSubsetSums.Adaptive143Third141State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third141Proof408 : runCachedNode 511 130431 Adaptive143Third141Node408 = false := by
  decide +kernel

#print axioms adaptive143Third141Proof408

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third141Proof123 : runCachedNode 511 130431 Adaptive143Third141Node123 = false := by
  decide +kernel

#print axioms adaptive143Third141Proof123

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third141Proof13 : runCachedNode 511 130431 Adaptive143Third141Node13 = false := by
  decide +kernel

#print axioms adaptive143Third141Proof13

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third141Proof409 : runCachedNode 511 130431 Adaptive143Third141Node409 = false := by
  decide +kernel

#print axioms adaptive143Third141Proof409

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third141Proof375 : runCachedNode 511 130431 Adaptive143Third141Node375 = false := by
  decide +kernel

#print axioms adaptive143Third141Proof375

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third141Proof451 : runCachedNode 511 130431 Adaptive143Third141Node451 = false := by
  decide +kernel

#print axioms adaptive143Third141Proof451

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third141Proof447 : runCachedNode 511 130431 Adaptive143Third141Node447 = false := by
  decide +kernel

#print axioms adaptive143Third141Proof447

end NineSeparatedSubsetSums
