import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive143Third118Node0 : CachedSearchNode :=
  ⟨4, 117, computeCenteredMask [148,143,118], 409, 56277⟩

end NineSeparatedSubsetSums
