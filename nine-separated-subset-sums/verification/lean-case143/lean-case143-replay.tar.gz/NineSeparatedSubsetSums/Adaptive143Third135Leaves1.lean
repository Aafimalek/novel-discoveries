import NineSeparatedSubsetSums.Adaptive143Third135State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third135Proof21 : runCachedNode 511 129468 Adaptive143Third135Node21 = false := by
  decide +kernel

#print axioms adaptive143Third135Proof21

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third135Proof13 : runCachedNode 511 129468 Adaptive143Third135Node13 = false := by
  decide +kernel

#print axioms adaptive143Third135Proof13

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third135Proof33 : runCachedNode 511 129468 Adaptive143Third135Node33 = false := by
  decide +kernel

#print axioms adaptive143Third135Proof33

end NineSeparatedSubsetSums
