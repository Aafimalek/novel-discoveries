import NineSeparatedSubsetSums.Adaptive143Third140State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third140Proof161 : runCachedNode 511 130276 Adaptive143Third140Node161 = false := by
  decide +kernel

#print axioms adaptive143Third140Proof161

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third140Proof14 : runCachedNode 511 130276 Adaptive143Third140Node14 = false := by
  decide +kernel

#print axioms adaptive143Third140Proof14

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third140Proof46 : runCachedNode 511 130276 Adaptive143Third140Node46 = false := by
  decide +kernel

#print axioms adaptive143Third140Proof46

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third140Proof391 : runCachedNode 511 130276 Adaptive143Third140Node391 = false := by
  decide +kernel

#print axioms adaptive143Third140Proof391

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third140Proof106 : runCachedNode 511 130276 Adaptive143Third140Node106 = false := by
  decide +kernel

#print axioms adaptive143Third140Proof106

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third140Proof102 : runCachedNode 511 130276 Adaptive143Third140Node102 = false := by
  decide +kernel

#print axioms adaptive143Third140Proof102

end NineSeparatedSubsetSums
