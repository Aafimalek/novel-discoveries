import NineSeparatedSubsetSums.Adaptive143Third133State
import NineSeparatedSubsetSums.Adaptive143Third133Leaves0
import NineSeparatedSubsetSums.Adaptive143Third133Leaves3
import NineSeparatedSubsetSums.Adaptive143Third133Leaves2
import NineSeparatedSubsetSums.Adaptive143Third133Leaves1

namespace NineSeparatedSubsetSums

theorem adaptive143Third133Proof0 : runCachedNode 511 129127 Adaptive143Third133Node0 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 129127 Adaptive143Third133Node0 = [110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 129, 130, 131, 132] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive143Third133Proof1
  · exact adaptive143Third133Proof2
  · exact adaptive143Third133Proof3
  · exact adaptive143Third133Proof4
  · exact adaptive143Third133Proof5
  · exact adaptive143Third133Proof6
  · exact adaptive143Third133Proof7
  · exact adaptive143Third133Proof8
  · exact adaptive143Third133Proof9
  · exact adaptive143Third133Proof10
  · exact adaptive143Third133Proof11
  · exact adaptive143Third133Proof12
  · exact adaptive143Third133Proof13
  · exact adaptive143Third133Proof14
  · exact adaptive143Third133Proof15
  · exact adaptive143Third133Proof16
  · exact adaptive143Third133Proof17
  · exact adaptive143Third133Proof18
  · exact adaptive143Third133Proof19
  · exact adaptive143Third133Proof20
  · exact adaptive143Third133Proof21
  · exact adaptive143Third133Proof22

#print axioms adaptive143Third133Proof0

end NineSeparatedSubsetSums
