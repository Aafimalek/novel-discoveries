import NineSeparatedSubsetSums.EightPoint143_128PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint143_128PackedAnchor1Part1 :
    ∀ j : Fin 120, 2400742 ≤ FourPointNumeric.octPackedCharge 143 128 20 packedOct143_128_1
      (2*((j.val : Int)+120)+0) := by decide +kernel

end NineSeparatedSubsetSums
