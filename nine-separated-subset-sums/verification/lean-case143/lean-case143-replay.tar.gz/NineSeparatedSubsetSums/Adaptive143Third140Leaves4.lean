import NineSeparatedSubsetSums.Adaptive143Third140State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third140Proof167 : runCachedNode 511 130276 Adaptive143Third140Node167 = false := by
  decide +kernel

#print axioms adaptive143Third140Proof167

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third140Proof43 : runCachedNode 511 130276 Adaptive143Third140Node43 = false := by
  decide +kernel

#print axioms adaptive143Third140Proof43

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third140Proof85 : runCachedNode 511 130276 Adaptive143Third140Node85 = false := by
  decide +kernel

#print axioms adaptive143Third140Proof85

end NineSeparatedSubsetSums
