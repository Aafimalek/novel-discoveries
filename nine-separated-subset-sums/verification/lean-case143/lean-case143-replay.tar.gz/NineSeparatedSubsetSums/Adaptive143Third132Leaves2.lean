import NineSeparatedSubsetSums.Adaptive143Third132State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third132Proof19 : runCachedNode 511 128948 Adaptive143Third132Node19 = false := by
  decide +kernel

#print axioms adaptive143Third132Proof19

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third132Proof16 : runCachedNode 511 128948 Adaptive143Third132Node16 = false := by
  decide +kernel

#print axioms adaptive143Third132Proof16

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third132Proof15 : runCachedNode 511 128948 Adaptive143Third132Node15 = false := by
  decide +kernel

#print axioms adaptive143Third132Proof15

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third132Proof8 : runCachedNode 511 128948 Adaptive143Third132Node8 = false := by
  decide +kernel

#print axioms adaptive143Third132Proof8

end NineSeparatedSubsetSums
