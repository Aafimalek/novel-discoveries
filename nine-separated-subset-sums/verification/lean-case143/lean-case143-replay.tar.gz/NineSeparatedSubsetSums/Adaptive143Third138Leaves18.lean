import NineSeparatedSubsetSums.Adaptive143Third138State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third138Proof40 : runCachedNode 511 129927 Adaptive143Third138Node40 = false := by
  decide +kernel

#print axioms adaptive143Third138Proof40

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third138Proof165 : runCachedNode 511 129927 Adaptive143Third138Node165 = false := by
  decide +kernel

#print axioms adaptive143Third138Proof165

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third138Proof258 : runCachedNode 511 129927 Adaptive143Third138Node258 = false := by
  decide +kernel

#print axioms adaptive143Third138Proof258

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third138Proof189 : runCachedNode 511 129927 Adaptive143Third138Node189 = false := by
  decide +kernel

#print axioms adaptive143Third138Proof189

end NineSeparatedSubsetSums
