import NineSeparatedSubsetSums.Adaptive143Third142State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third142Proof448 : runCachedNode 511 130584 Adaptive143Third142Node448 = false := by
  decide +kernel

#print axioms adaptive143Third142Proof448

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third142Proof446 : runCachedNode 511 130584 Adaptive143Third142Node446 = false := by
  decide +kernel

#print axioms adaptive143Third142Proof446

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third142Proof84 : runCachedNode 511 130584 Adaptive143Third142Node84 = false := by
  decide +kernel

#print axioms adaptive143Third142Proof84

end NineSeparatedSubsetSums
