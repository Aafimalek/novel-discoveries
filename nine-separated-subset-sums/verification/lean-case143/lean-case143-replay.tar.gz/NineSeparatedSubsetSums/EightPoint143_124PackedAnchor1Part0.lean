import NineSeparatedSubsetSums.EightPoint143_124PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint143_124PackedAnchor1Part0 :
    ∀ j : Fin 120, 2339600 ≤ FourPointNumeric.octPackedCharge 143 124 20 packedOct143_124_1
      (2*((j.val : Int)+0)+0) := by decide +kernel

end NineSeparatedSubsetSums
