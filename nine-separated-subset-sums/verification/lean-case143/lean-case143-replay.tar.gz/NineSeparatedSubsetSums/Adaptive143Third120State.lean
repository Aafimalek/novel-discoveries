import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive143Third120Node0 : CachedSearchNode :=
  ⟨4, 119, computeCenteredMask [148,143,120], 411, 56753⟩

end NineSeparatedSubsetSums
