import NineSeparatedSubsetSums.Adaptive143Third128State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third128Proof17 : runCachedNode 511 128085 Adaptive143Third128Node17 = false := by
  decide +kernel

#print axioms adaptive143Third128Proof17

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third128Proof16 : runCachedNode 511 128085 Adaptive143Third128Node16 = false := by
  decide +kernel

#print axioms adaptive143Third128Proof16

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third128Proof15 : runCachedNode 511 128085 Adaptive143Third128Node15 = false := by
  decide +kernel

#print axioms adaptive143Third128Proof15

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third128Proof14 : runCachedNode 511 128085 Adaptive143Third128Node14 = false := by
  decide +kernel

#print axioms adaptive143Third128Proof14

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third128Proof13 : runCachedNode 511 128085 Adaptive143Third128Node13 = false := by
  decide +kernel

#print axioms adaptive143Third128Proof13

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third128Proof5 : runCachedNode 511 128085 Adaptive143Third128Node5 = false := by
  decide +kernel

#print axioms adaptive143Third128Proof5

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third128Proof1 : runCachedNode 511 128085 Adaptive143Third128Node1 = false := by
  decide +kernel

#print axioms adaptive143Third128Proof1

end NineSeparatedSubsetSums
