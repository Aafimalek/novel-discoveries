import NineSeparatedSubsetSums.Adaptive143Third141State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third141Proof161 : runCachedNode 511 130431 Adaptive143Third141Node161 = false := by
  decide +kernel

#print axioms adaptive143Third141Proof161

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third141Proof18 : runCachedNode 511 130431 Adaptive143Third141Node18 = false := by
  decide +kernel

#print axioms adaptive143Third141Proof18

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third141Proof32 : runCachedNode 511 130431 Adaptive143Third141Node32 = false := by
  decide +kernel

#print axioms adaptive143Third141Proof32

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third141Proof133 : runCachedNode 511 130431 Adaptive143Third141Node133 = false := by
  decide +kernel

#print axioms adaptive143Third141Proof133

end NineSeparatedSubsetSums
