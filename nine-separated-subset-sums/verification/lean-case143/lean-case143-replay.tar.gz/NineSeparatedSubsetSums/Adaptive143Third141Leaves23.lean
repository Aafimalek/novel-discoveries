import NineSeparatedSubsetSums.Adaptive143Third141State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third141Proof288 : runCachedNode 511 130431 Adaptive143Third141Node288 = false := by
  decide +kernel

#print axioms adaptive143Third141Proof288

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third141Proof46 : runCachedNode 511 130431 Adaptive143Third141Node46 = false := by
  decide +kernel

#print axioms adaptive143Third141Proof46

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third141Proof101 : runCachedNode 511 130431 Adaptive143Third141Node101 = false := by
  decide +kernel

#print axioms adaptive143Third141Proof101

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third141Proof289 : runCachedNode 511 130431 Adaptive143Third141Node289 = false := by
  decide +kernel

#print axioms adaptive143Third141Proof289

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third141Proof216 : runCachedNode 511 130431 Adaptive143Third141Node216 = false := by
  decide +kernel

#print axioms adaptive143Third141Proof216

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third141Proof187 : runCachedNode 511 130431 Adaptive143Third141Node187 = false := by
  decide +kernel

#print axioms adaptive143Third141Proof187

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third141Proof261 : runCachedNode 511 130431 Adaptive143Third141Node261 = false := by
  decide +kernel

#print axioms adaptive143Third141Proof261

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third141Proof29 : runCachedNode 511 130431 Adaptive143Third141Node29 = false := by
  decide +kernel

#print axioms adaptive143Third141Proof29

end NineSeparatedSubsetSums
