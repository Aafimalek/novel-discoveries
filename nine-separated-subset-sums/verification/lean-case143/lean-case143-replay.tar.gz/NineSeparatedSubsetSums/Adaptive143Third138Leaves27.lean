import NineSeparatedSubsetSums.Adaptive143Third138State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third138Proof106 : runCachedNode 511 129927 Adaptive143Third138Node106 = false := by
  decide +kernel

#print axioms adaptive143Third138Proof106

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third138Proof222 : runCachedNode 511 129927 Adaptive143Third138Node222 = false := by
  decide +kernel

#print axioms adaptive143Third138Proof222

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third138Proof108 : runCachedNode 511 129927 Adaptive143Third138Node108 = false := by
  decide +kernel

#print axioms adaptive143Third138Proof108

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third138Proof160 : runCachedNode 511 129927 Adaptive143Third138Node160 = false := by
  decide +kernel

#print axioms adaptive143Third138Proof160

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third138Proof220 : runCachedNode 511 129927 Adaptive143Third138Node220 = false := by
  decide +kernel

#print axioms adaptive143Third138Proof220

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third138Proof32 : runCachedNode 511 129927 Adaptive143Third138Node32 = false := by
  decide +kernel

#print axioms adaptive143Third138Proof32

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third138Proof59 : runCachedNode 511 129927 Adaptive143Third138Node59 = false := by
  decide +kernel

#print axioms adaptive143Third138Proof59

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third138Proof219 : runCachedNode 511 129927 Adaptive143Third138Node219 = false := by
  decide +kernel

#print axioms adaptive143Third138Proof219

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third138Proof162 : runCachedNode 511 129927 Adaptive143Third138Node162 = false := by
  decide +kernel

#print axioms adaptive143Third138Proof162

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third138Proof58 : runCachedNode 511 129927 Adaptive143Third138Node58 = false := by
  decide +kernel

#print axioms adaptive143Third138Proof58

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third138Proof251 : runCachedNode 511 129927 Adaptive143Third138Node251 = false := by
  decide +kernel

#print axioms adaptive143Third138Proof251

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third138Proof107 : runCachedNode 511 129927 Adaptive143Third138Node107 = false := by
  decide +kernel

#print axioms adaptive143Third138Proof107

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third138Proof31 : runCachedNode 511 129927 Adaptive143Third138Node31 = false := by
  decide +kernel

#print axioms adaptive143Third138Proof31

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third138Proof124 : runCachedNode 511 129927 Adaptive143Third138Node124 = false := by
  decide +kernel

#print axioms adaptive143Third138Proof124

end NineSeparatedSubsetSums
