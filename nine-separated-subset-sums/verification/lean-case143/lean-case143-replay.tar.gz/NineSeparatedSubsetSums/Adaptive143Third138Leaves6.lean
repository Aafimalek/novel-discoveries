import NineSeparatedSubsetSums.Adaptive143Third138State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third138Proof263 : runCachedNode 511 129927 Adaptive143Third138Node263 = false := by
  decide +kernel

#print axioms adaptive143Third138Proof263

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third138Proof141 : runCachedNode 511 129927 Adaptive143Third138Node141 = false := by
  decide +kernel

#print axioms adaptive143Third138Proof141

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third138Proof74 : runCachedNode 511 129927 Adaptive143Third138Node74 = false := by
  decide +kernel

#print axioms adaptive143Third138Proof74

end NineSeparatedSubsetSums
