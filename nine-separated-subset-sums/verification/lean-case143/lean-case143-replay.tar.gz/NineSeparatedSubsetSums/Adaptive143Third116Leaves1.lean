import NineSeparatedSubsetSums.Adaptive143Third116State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third116Proof12 : runCachedNode 511 112040 Adaptive143Third116Node12 = false := by
  decide +kernel

#print axioms adaptive143Third116Proof12

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third116Proof11 : runCachedNode 511 112040 Adaptive143Third116Node11 = false := by
  decide +kernel

#print axioms adaptive143Third116Proof11

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third116Proof10 : runCachedNode 511 112040 Adaptive143Third116Node10 = false := by
  decide +kernel

#print axioms adaptive143Third116Proof10

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third116Proof9 : runCachedNode 511 112040 Adaptive143Third116Node9 = false := by
  decide +kernel

#print axioms adaptive143Third116Proof9

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third116Proof8 : runCachedNode 511 112040 Adaptive143Third116Node8 = false := by
  decide +kernel

#print axioms adaptive143Third116Proof8

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third116Proof6 : runCachedNode 511 112040 Adaptive143Third116Node6 = false := by
  decide +kernel

#print axioms adaptive143Third116Proof6

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third116Proof5 : runCachedNode 511 112040 Adaptive143Third116Node5 = false := by
  decide +kernel

#print axioms adaptive143Third116Proof5

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third116Proof4 : runCachedNode 511 112040 Adaptive143Third116Node4 = false := by
  decide +kernel

#print axioms adaptive143Third116Proof4

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third116Proof2 : runCachedNode 511 112040 Adaptive143Third116Node2 = false := by
  decide +kernel

#print axioms adaptive143Third116Proof2

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third116Proof1 : runCachedNode 511 112040 Adaptive143Third116Node1 = false := by
  decide +kernel

#print axioms adaptive143Third116Proof1

end NineSeparatedSubsetSums
