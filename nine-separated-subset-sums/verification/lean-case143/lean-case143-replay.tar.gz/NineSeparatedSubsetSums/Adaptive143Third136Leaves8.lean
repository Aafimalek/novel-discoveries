import NineSeparatedSubsetSums.Adaptive143Third136State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third136Proof72 : runCachedNode 511 129643 Adaptive143Third136Node72 = false := by
  decide +kernel

#print axioms adaptive143Third136Proof72

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third136Proof44 : runCachedNode 511 129643 Adaptive143Third136Node44 = false := by
  decide +kernel

#print axioms adaptive143Third136Proof44

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third136Proof13 : runCachedNode 511 129643 Adaptive143Third136Node13 = false := by
  decide +kernel

#print axioms adaptive143Third136Proof13

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third136Proof43 : runCachedNode 511 129643 Adaptive143Third136Node43 = false := by
  decide +kernel

#print axioms adaptive143Third136Proof43

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third136Proof12 : runCachedNode 511 129643 Adaptive143Third136Node12 = false := by
  decide +kernel

#print axioms adaptive143Third136Proof12

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third136Proof97 : runCachedNode 511 129643 Adaptive143Third136Node97 = false := by
  decide +kernel

#print axioms adaptive143Third136Proof97

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third136Proof71 : runCachedNode 511 129643 Adaptive143Third136Node71 = false := by
  decide +kernel

#print axioms adaptive143Third136Proof71

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third136Proof42 : runCachedNode 511 129643 Adaptive143Third136Node42 = false := by
  decide +kernel

#print axioms adaptive143Third136Proof42

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third136Proof9 : runCachedNode 511 129643 Adaptive143Third136Node9 = false := by
  decide +kernel

#print axioms adaptive143Third136Proof9

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third136Proof54 : runCachedNode 511 129643 Adaptive143Third136Node54 = false := by
  decide +kernel

#print axioms adaptive143Third136Proof54

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third136Proof23 : runCachedNode 511 129643 Adaptive143Third136Node23 = false := by
  decide +kernel

#print axioms adaptive143Third136Proof23

end NineSeparatedSubsetSums
