import NineSeparatedSubsetSums.EightPoint143_119PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint143_119PackedAnchor1Part1 :
    ∀ j : Fin 120, 2416431 ≤ FourPointNumeric.octPackedCharge 143 119 20 packedOct143_119_1
      (2*((j.val : Int)+120)+1) := by decide +kernel

end NineSeparatedSubsetSums
