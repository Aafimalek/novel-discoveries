import NineSeparatedSubsetSums.Adaptive143Third142State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third142Proof526 : runCachedNode 511 130584 Adaptive143Third142Node526 = false := by
  decide +kernel

#print axioms adaptive143Third142Proof526

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third142Proof11 : runCachedNode 511 130584 Adaptive143Third142Node11 = false := by
  decide +kernel

#print axioms adaptive143Third142Proof11

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third142Proof329 : runCachedNode 511 130584 Adaptive143Third142Node329 = false := by
  decide +kernel

#print axioms adaptive143Third142Proof329

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third142Proof258 : runCachedNode 511 130584 Adaptive143Third142Node258 = false := by
  decide +kernel

#print axioms adaptive143Third142Proof258

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third142Proof488 : runCachedNode 511 130584 Adaptive143Third142Node488 = false := by
  decide +kernel

#print axioms adaptive143Third142Proof488

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third142Proof531 : runCachedNode 511 130584 Adaptive143Third142Node531 = false := by
  decide +kernel

#print axioms adaptive143Third142Proof531

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third142Proof524 : runCachedNode 511 130584 Adaptive143Third142Node524 = false := by
  decide +kernel

#print axioms adaptive143Third142Proof524

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third142Proof527 : runCachedNode 511 130584 Adaptive143Third142Node527 = false := by
  decide +kernel

#print axioms adaptive143Third142Proof527

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third142Proof259 : runCachedNode 511 130584 Adaptive143Third142Node259 = false := by
  decide +kernel

#print axioms adaptive143Third142Proof259

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third142Proof213 : runCachedNode 511 130584 Adaptive143Third142Node213 = false := by
  decide +kernel

#print axioms adaptive143Third142Proof213

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third142Proof410 : runCachedNode 511 130584 Adaptive143Third142Node410 = false := by
  decide +kernel

#print axioms adaptive143Third142Proof410

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third142Proof433 : runCachedNode 511 130584 Adaptive143Third142Node433 = false := by
  decide +kernel

#print axioms adaptive143Third142Proof433

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third142Proof257 : runCachedNode 511 130584 Adaptive143Third142Node257 = false := by
  decide +kernel

#print axioms adaptive143Third142Proof257

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third142Proof360 : runCachedNode 511 130584 Adaptive143Third142Node360 = false := by
  decide +kernel

#print axioms adaptive143Third142Proof360

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third142Proof487 : runCachedNode 511 130584 Adaptive143Third142Node487 = false := by
  decide +kernel

#print axioms adaptive143Third142Proof487

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third142Proof212 : runCachedNode 511 130584 Adaptive143Third142Node212 = false := by
  decide +kernel

#print axioms adaptive143Third142Proof212

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third142Proof153 : runCachedNode 511 130584 Adaptive143Third142Node153 = false := by
  decide +kernel

#print axioms adaptive143Third142Proof153

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third142Proof3 : runCachedNode 511 130584 Adaptive143Third142Node3 = false := by
  decide +kernel

#print axioms adaptive143Third142Proof3

end NineSeparatedSubsetSums
