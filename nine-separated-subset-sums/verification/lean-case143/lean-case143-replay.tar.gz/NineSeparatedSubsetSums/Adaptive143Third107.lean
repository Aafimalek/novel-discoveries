import NineSeparatedSubsetSums.Adaptive143Third107Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint143Checked

namespace NineSeparatedSubsetSums


theorem adaptive143Third107 : NoDescendingTailAfterThird 143 107 :=
  noDescendingThirdTail_of_cached 143 107 112040 (fun t ht nd => max148_second143_fourPoint_moment_bound (107::t) (by simp [ht]) nd) adaptive143Third107Proof0

#print axioms adaptive143Third107

end NineSeparatedSubsetSums
