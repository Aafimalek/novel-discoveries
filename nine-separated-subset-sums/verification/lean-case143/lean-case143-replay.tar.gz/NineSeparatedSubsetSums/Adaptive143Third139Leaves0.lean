import NineSeparatedSubsetSums.Adaptive143Third139State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third139Proof287 : runCachedNode 511 130096 Adaptive143Third139Node287 = false := by
  decide +kernel

#print axioms adaptive143Third139Proof287

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third139Proof94 : runCachedNode 511 130096 Adaptive143Third139Node94 = false := by
  decide +kernel

#print axioms adaptive143Third139Proof94

end NineSeparatedSubsetSums
