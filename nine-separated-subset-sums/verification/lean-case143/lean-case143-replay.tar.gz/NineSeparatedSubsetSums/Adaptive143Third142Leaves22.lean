import NineSeparatedSubsetSums.Adaptive143Third142State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third142Proof16 : runCachedNode 511 130584 Adaptive143Third142Node16 = false := by
  decide +kernel

#print axioms adaptive143Third142Proof16

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third142Proof444 : runCachedNode 511 130584 Adaptive143Third142Node444 = false := by
  decide +kernel

#print axioms adaptive143Third142Proof444

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third142Proof494 : runCachedNode 511 130584 Adaptive143Third142Node494 = false := by
  decide +kernel

#print axioms adaptive143Third142Proof494

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third142Proof537 : runCachedNode 511 130584 Adaptive143Third142Node537 = false := by
  decide +kernel

#print axioms adaptive143Third142Proof537

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third142Proof32 : runCachedNode 511 130584 Adaptive143Third142Node32 = false := by
  decide +kernel

#print axioms adaptive143Third142Proof32

end NineSeparatedSubsetSums
