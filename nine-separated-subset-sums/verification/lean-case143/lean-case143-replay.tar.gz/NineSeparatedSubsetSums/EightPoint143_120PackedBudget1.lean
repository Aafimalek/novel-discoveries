import NineSeparatedSubsetSums.EightPoint143_120PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct143_120_1_budget :
    FourPointNumeric.packedBudget 20 packedOct143_120_1 362 = 86866034 := by decide +kernel

#print axioms packedOct143_120_1_budget

end NineSeparatedSubsetSums
