import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive143Third133Node0 : CachedSearchNode :=
  ⟨4, 132, computeCenteredMask [148,143,133], 424, 60042⟩
def Adaptive143Third133Node1 : CachedSearchNode := cachedChild Adaptive143Third133Node0 110
def Adaptive143Third133Node2 : CachedSearchNode := cachedChild Adaptive143Third133Node0 111
def Adaptive143Third133Node3 : CachedSearchNode := cachedChild Adaptive143Third133Node0 112
def Adaptive143Third133Node4 : CachedSearchNode := cachedChild Adaptive143Third133Node0 113
def Adaptive143Third133Node5 : CachedSearchNode := cachedChild Adaptive143Third133Node0 114
def Adaptive143Third133Node6 : CachedSearchNode := cachedChild Adaptive143Third133Node0 115
def Adaptive143Third133Node7 : CachedSearchNode := cachedChild Adaptive143Third133Node0 116
def Adaptive143Third133Node8 : CachedSearchNode := cachedChild Adaptive143Third133Node0 117
def Adaptive143Third133Node9 : CachedSearchNode := cachedChild Adaptive143Third133Node0 118
def Adaptive143Third133Node10 : CachedSearchNode := cachedChild Adaptive143Third133Node0 119
def Adaptive143Third133Node11 : CachedSearchNode := cachedChild Adaptive143Third133Node0 120
def Adaptive143Third133Node12 : CachedSearchNode := cachedChild Adaptive143Third133Node0 121
def Adaptive143Third133Node13 : CachedSearchNode := cachedChild Adaptive143Third133Node0 122
def Adaptive143Third133Node14 : CachedSearchNode := cachedChild Adaptive143Third133Node0 123
def Adaptive143Third133Node15 : CachedSearchNode := cachedChild Adaptive143Third133Node0 124
def Adaptive143Third133Node16 : CachedSearchNode := cachedChild Adaptive143Third133Node0 125
def Adaptive143Third133Node17 : CachedSearchNode := cachedChild Adaptive143Third133Node0 126
def Adaptive143Third133Node18 : CachedSearchNode := cachedChild Adaptive143Third133Node0 127
def Adaptive143Third133Node19 : CachedSearchNode := cachedChild Adaptive143Third133Node0 129
def Adaptive143Third133Node20 : CachedSearchNode := cachedChild Adaptive143Third133Node0 130
def Adaptive143Third133Node21 : CachedSearchNode := cachedChild Adaptive143Third133Node0 131
def Adaptive143Third133Node22 : CachedSearchNode := cachedChild Adaptive143Third133Node0 132

end NineSeparatedSubsetSums
