import NineSeparatedSubsetSums.Adaptive143Third142State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third142Proof371 : runCachedNode 511 130584 Adaptive143Third142Node371 = false := by
  decide +kernel

#print axioms adaptive143Third142Proof371

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third142Proof160 : runCachedNode 511 130584 Adaptive143Third142Node160 = false := by
  decide +kernel

#print axioms adaptive143Third142Proof160

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third142Proof163 : runCachedNode 511 130584 Adaptive143Third142Node163 = false := by
  decide +kernel

#print axioms adaptive143Third142Proof163

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third142Proof190 : runCachedNode 511 130584 Adaptive143Third142Node190 = false := by
  decide +kernel

#print axioms adaptive143Third142Proof190

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third142Proof30 : runCachedNode 511 130584 Adaptive143Third142Node30 = false := by
  decide +kernel

#print axioms adaptive143Third142Proof30

end NineSeparatedSubsetSums
