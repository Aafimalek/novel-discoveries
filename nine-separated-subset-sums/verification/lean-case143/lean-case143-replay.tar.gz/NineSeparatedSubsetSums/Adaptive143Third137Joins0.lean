import NineSeparatedSubsetSums.Adaptive143Third137State
import NineSeparatedSubsetSums.Adaptive143Third137Leaves1
import NineSeparatedSubsetSums.Adaptive143Third137Leaves13
import NineSeparatedSubsetSums.Adaptive143Third137Leaves8
import NineSeparatedSubsetSums.Adaptive143Third137Leaves7
import NineSeparatedSubsetSums.Adaptive143Third137Leaves0
import NineSeparatedSubsetSums.Adaptive143Third137Leaves12
import NineSeparatedSubsetSums.Adaptive143Third137Leaves11
import NineSeparatedSubsetSums.Adaptive143Third137Leaves10
import NineSeparatedSubsetSums.Adaptive143Third137Leaves9
import NineSeparatedSubsetSums.Adaptive143Third137Leaves3
import NineSeparatedSubsetSums.Adaptive143Third137Leaves2
import NineSeparatedSubsetSums.Adaptive143Third137Leaves5
import NineSeparatedSubsetSums.Adaptive143Third137Leaves4
import NineSeparatedSubsetSums.Adaptive143Third137Leaves6

namespace NineSeparatedSubsetSums

theorem adaptive143Third137Proof22 : runCachedNode 511 129784 Adaptive143Third137Node22 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 129784 Adaptive143Third137Node22 = [104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 121, 122, 123, 124, 127, 128, 129, 130] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive143Third137Proof23
  · exact adaptive143Third137Proof24
  · exact adaptive143Third137Proof25
  · exact adaptive143Third137Proof26
  · exact adaptive143Third137Proof27
  · exact adaptive143Third137Proof28
  · exact adaptive143Third137Proof29
  · exact adaptive143Third137Proof30
  · exact adaptive143Third137Proof31
  · exact adaptive143Third137Proof32
  · exact adaptive143Third137Proof33
  · exact adaptive143Third137Proof34
  · exact adaptive143Third137Proof35
  · exact adaptive143Third137Proof36
  · exact adaptive143Third137Proof37
  · exact adaptive143Third137Proof38
  · exact adaptive143Third137Proof39
  · exact adaptive143Third137Proof40
  · exact adaptive143Third137Proof41
  · exact adaptive143Third137Proof42
  · exact adaptive143Third137Proof43
  · exact adaptive143Third137Proof44
  · exact adaptive143Third137Proof45
  · exact adaptive143Third137Proof46

#print axioms adaptive143Third137Proof22

theorem adaptive143Third137Proof47 : runCachedNode 511 129784 Adaptive143Third137Node47 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 129784 Adaptive143Third137Node47 = [103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 123, 124, 125, 126, 129, 130, 131] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive143Third137Proof48
  · exact adaptive143Third137Proof49
  · exact adaptive143Third137Proof50
  · exact adaptive143Third137Proof51
  · exact adaptive143Third137Proof52
  · exact adaptive143Third137Proof53
  · exact adaptive143Third137Proof54
  · exact adaptive143Third137Proof55
  · exact adaptive143Third137Proof56
  · exact adaptive143Third137Proof57
  · exact adaptive143Third137Proof58
  · exact adaptive143Third137Proof59
  · exact adaptive143Third137Proof60
  · exact adaptive143Third137Proof61
  · exact adaptive143Third137Proof62
  · exact adaptive143Third137Proof63
  · exact adaptive143Third137Proof64
  · exact adaptive143Third137Proof65
  · exact adaptive143Third137Proof66
  · exact adaptive143Third137Proof67
  · exact adaptive143Third137Proof68
  · exact adaptive143Third137Proof69
  · exact adaptive143Third137Proof70
  · exact adaptive143Third137Proof71
  · exact adaptive143Third137Proof72
  · exact adaptive143Third137Proof73

#print axioms adaptive143Third137Proof47

theorem adaptive143Third137Proof74 : runCachedNode 511 129784 Adaptive143Third137Node74 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 129784 Adaptive143Third137Node74 = [103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 124, 125, 126, 127, 130, 131, 133] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive143Third137Proof75
  · exact adaptive143Third137Proof76
  · exact adaptive143Third137Proof77
  · exact adaptive143Third137Proof78
  · exact adaptive143Third137Proof79
  · exact adaptive143Third137Proof80
  · exact adaptive143Third137Proof81
  · exact adaptive143Third137Proof82
  · exact adaptive143Third137Proof83
  · exact adaptive143Third137Proof84
  · exact adaptive143Third137Proof85
  · exact adaptive143Third137Proof86
  · exact adaptive143Third137Proof87
  · exact adaptive143Third137Proof88
  · exact adaptive143Third137Proof89
  · exact adaptive143Third137Proof90
  · exact adaptive143Third137Proof91
  · exact adaptive143Third137Proof92
  · exact adaptive143Third137Proof93
  · exact adaptive143Third137Proof94
  · exact adaptive143Third137Proof95
  · exact adaptive143Third137Proof96
  · exact adaptive143Third137Proof97
  · exact adaptive143Third137Proof98
  · exact adaptive143Third137Proof99
  · exact adaptive143Third137Proof100
  · exact adaptive143Third137Proof101

#print axioms adaptive143Third137Proof74

theorem adaptive143Third137Proof102 : runCachedNode 511 129784 Adaptive143Third137Node102 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 129784 Adaptive143Third137Node102 = [103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 125, 126, 127, 128, 131, 133, 134] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive143Third137Proof103
  · exact adaptive143Third137Proof104
  · exact adaptive143Third137Proof105
  · exact adaptive143Third137Proof106
  · exact adaptive143Third137Proof107
  · exact adaptive143Third137Proof108
  · exact adaptive143Third137Proof109
  · exact adaptive143Third137Proof110
  · exact adaptive143Third137Proof111
  · exact adaptive143Third137Proof112
  · exact adaptive143Third137Proof113
  · exact adaptive143Third137Proof114
  · exact adaptive143Third137Proof115
  · exact adaptive143Third137Proof116
  · exact adaptive143Third137Proof117
  · exact adaptive143Third137Proof118
  · exact adaptive143Third137Proof119
  · exact adaptive143Third137Proof120
  · exact adaptive143Third137Proof121
  · exact adaptive143Third137Proof122
  · exact adaptive143Third137Proof123
  · exact adaptive143Third137Proof124
  · exact adaptive143Third137Proof125
  · exact adaptive143Third137Proof126
  · exact adaptive143Third137Proof127
  · exact adaptive143Third137Proof128
  · exact adaptive143Third137Proof129
  · exact adaptive143Third137Proof130

#print axioms adaptive143Third137Proof102

theorem adaptive143Third137Proof131 : runCachedNode 511 129784 Adaptive143Third137Node131 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 129784 Adaptive143Third137Node131 = [103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 126, 127, 128, 129, 133, 134, 135] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive143Third137Proof132
  · exact adaptive143Third137Proof133
  · exact adaptive143Third137Proof134
  · exact adaptive143Third137Proof135
  · exact adaptive143Third137Proof136
  · exact adaptive143Third137Proof137
  · exact adaptive143Third137Proof138
  · exact adaptive143Third137Proof139
  · exact adaptive143Third137Proof140
  · exact adaptive143Third137Proof141
  · exact adaptive143Third137Proof142
  · exact adaptive143Third137Proof143
  · exact adaptive143Third137Proof144
  · exact adaptive143Third137Proof145
  · exact adaptive143Third137Proof146
  · exact adaptive143Third137Proof147
  · exact adaptive143Third137Proof148
  · exact adaptive143Third137Proof149
  · exact adaptive143Third137Proof150
  · exact adaptive143Third137Proof151
  · exact adaptive143Third137Proof152
  · exact adaptive143Third137Proof153
  · exact adaptive143Third137Proof154
  · exact adaptive143Third137Proof155
  · exact adaptive143Third137Proof156
  · exact adaptive143Third137Proof157
  · exact adaptive143Third137Proof158
  · exact adaptive143Third137Proof159
  · exact adaptive143Third137Proof160

#print axioms adaptive143Third137Proof131

theorem adaptive143Third137Proof0 : runCachedNode 511 129784 Adaptive143Third137Node0 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 129784 Adaptive143Third137Node0 = [110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 133, 134, 135, 136] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive143Third137Proof1
  · exact adaptive143Third137Proof2
  · exact adaptive143Third137Proof3
  · exact adaptive143Third137Proof4
  · exact adaptive143Third137Proof5
  · exact adaptive143Third137Proof6
  · exact adaptive143Third137Proof7
  · exact adaptive143Third137Proof8
  · exact adaptive143Third137Proof9
  · exact adaptive143Third137Proof10
  · exact adaptive143Third137Proof11
  · exact adaptive143Third137Proof12
  · exact adaptive143Third137Proof13
  · exact adaptive143Third137Proof14
  · exact adaptive143Third137Proof15
  · exact adaptive143Third137Proof16
  · exact adaptive143Third137Proof17
  · exact adaptive143Third137Proof18
  · exact adaptive143Third137Proof19
  · exact adaptive143Third137Proof20
  · exact adaptive143Third137Proof21
  · exact adaptive143Third137Proof22
  · exact adaptive143Third137Proof47
  · exact adaptive143Third137Proof74
  · exact adaptive143Third137Proof102
  · exact adaptive143Third137Proof131

#print axioms adaptive143Third137Proof0

end NineSeparatedSubsetSums
