import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive143Third104Node0 : CachedSearchNode :=
  ⟨4, 103, computeCenteredMask [148,143,104], 395, 53169⟩

end NineSeparatedSubsetSums
