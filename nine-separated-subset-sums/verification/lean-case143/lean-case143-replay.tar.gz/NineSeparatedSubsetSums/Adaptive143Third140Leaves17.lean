import NineSeparatedSubsetSums.Adaptive143Third140State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third140Proof198 : runCachedNode 511 130276 Adaptive143Third140Node198 = false := by
  decide +kernel

#print axioms adaptive143Third140Proof198

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third140Proof195 : runCachedNode 511 130276 Adaptive143Third140Node195 = false := by
  decide +kernel

#print axioms adaptive143Third140Proof195

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third140Proof392 : runCachedNode 511 130276 Adaptive143Third140Node392 = false := by
  decide +kernel

#print axioms adaptive143Third140Proof392

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third140Proof76 : runCachedNode 511 130276 Adaptive143Third140Node76 = false := by
  decide +kernel

#print axioms adaptive143Third140Proof76

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third140Proof349 : runCachedNode 511 130276 Adaptive143Third140Node349 = false := by
  decide +kernel

#print axioms adaptive143Third140Proof349

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third140Proof29 : runCachedNode 511 130276 Adaptive143Third140Node29 = false := by
  decide +kernel

#print axioms adaptive143Third140Proof29

end NineSeparatedSubsetSums
