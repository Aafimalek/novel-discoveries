import NineSeparatedSubsetSums.Adaptive143Third139State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third139Proof247 : runCachedNode 511 130096 Adaptive143Third139Node247 = false := by
  decide +kernel

#print axioms adaptive143Third139Proof247

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third139Proof152 : runCachedNode 511 130096 Adaptive143Third139Node152 = false := by
  decide +kernel

#print axioms adaptive143Third139Proof152

end NineSeparatedSubsetSums
