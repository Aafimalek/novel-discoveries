import NineSeparatedSubsetSums.Adaptive143Third139State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third139Proof244 : runCachedNode 511 130096 Adaptive143Third139Node244 = false := by
  decide +kernel

#print axioms adaptive143Third139Proof244

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third139Proof18 : runCachedNode 511 130096 Adaptive143Third139Node18 = false := by
  decide +kernel

#print axioms adaptive143Third139Proof18

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third139Proof34 : runCachedNode 511 130096 Adaptive143Third139Node34 = false := by
  decide +kernel

#print axioms adaptive143Third139Proof34

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third139Proof218 : runCachedNode 511 130096 Adaptive143Third139Node218 = false := by
  decide +kernel

#print axioms adaptive143Third139Proof218

end NineSeparatedSubsetSums
