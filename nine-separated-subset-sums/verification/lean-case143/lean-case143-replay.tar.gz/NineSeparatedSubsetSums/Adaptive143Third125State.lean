import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive143Third125Node0 : CachedSearchNode :=
  ⟨4, 124, computeCenteredMask [148,143,125], 416, 57978⟩

end NineSeparatedSubsetSums
