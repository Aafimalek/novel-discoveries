import NineSeparatedSubsetSums.Adaptive143Third140State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third140Proof194 : runCachedNode 511 130276 Adaptive143Third140Node194 = false := by
  decide +kernel

#print axioms adaptive143Third140Proof194

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third140Proof16 : runCachedNode 511 130276 Adaptive143Third140Node16 = false := by
  decide +kernel

#print axioms adaptive143Third140Proof16

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third140Proof165 : runCachedNode 511 130276 Adaptive143Third140Node165 = false := by
  decide +kernel

#print axioms adaptive143Third140Proof165

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third140Proof134 : runCachedNode 511 130276 Adaptive143Third140Node134 = false := by
  decide +kernel

#print axioms adaptive143Third140Proof134

end NineSeparatedSubsetSums
