import NineSeparatedSubsetSums.Adaptive143Third136State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third136Proof21 : runCachedNode 511 129643 Adaptive143Third136Node21 = false := by
  decide +kernel

#print axioms adaptive143Third136Proof21

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third136Proof100 : runCachedNode 511 129643 Adaptive143Third136Node100 = false := by
  decide +kernel

#print axioms adaptive143Third136Proof100

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third136Proof2 : runCachedNode 511 129643 Adaptive143Third136Node2 = false := by
  decide +kernel

#print axioms adaptive143Third136Proof2

end NineSeparatedSubsetSums
