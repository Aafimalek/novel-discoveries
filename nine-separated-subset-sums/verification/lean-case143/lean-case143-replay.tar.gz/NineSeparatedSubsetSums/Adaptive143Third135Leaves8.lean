import NineSeparatedSubsetSums.Adaptive143Third135State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third135Proof52 : runCachedNode 511 129468 Adaptive143Third135Node52 = false := by
  decide +kernel

#print axioms adaptive143Third135Proof52

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third135Proof53 : runCachedNode 511 129468 Adaptive143Third135Node53 = false := by
  decide +kernel

#print axioms adaptive143Third135Proof53

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third135Proof24 : runCachedNode 511 129468 Adaptive143Third135Node24 = false := by
  decide +kernel

#print axioms adaptive143Third135Proof24

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third135Proof50 : runCachedNode 511 129468 Adaptive143Third135Node50 = false := by
  decide +kernel

#print axioms adaptive143Third135Proof50

end NineSeparatedSubsetSums
