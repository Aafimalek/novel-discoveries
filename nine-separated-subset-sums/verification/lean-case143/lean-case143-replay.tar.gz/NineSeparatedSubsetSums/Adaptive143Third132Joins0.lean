import NineSeparatedSubsetSums.Adaptive143Third132State
import NineSeparatedSubsetSums.Adaptive143Third132Leaves0
import NineSeparatedSubsetSums.Adaptive143Third132Leaves3
import NineSeparatedSubsetSums.Adaptive143Third132Leaves1
import NineSeparatedSubsetSums.Adaptive143Third132Leaves2

namespace NineSeparatedSubsetSums

theorem adaptive143Third132Proof0 : runCachedNode 511 128948 Adaptive143Third132Node0 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 128948 Adaptive143Third132Node0 = [110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 128, 129, 130, 131] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive143Third132Proof1
  · exact adaptive143Third132Proof2
  · exact adaptive143Third132Proof3
  · exact adaptive143Third132Proof4
  · exact adaptive143Third132Proof5
  · exact adaptive143Third132Proof6
  · exact adaptive143Third132Proof7
  · exact adaptive143Third132Proof8
  · exact adaptive143Third132Proof9
  · exact adaptive143Third132Proof10
  · exact adaptive143Third132Proof11
  · exact adaptive143Third132Proof12
  · exact adaptive143Third132Proof13
  · exact adaptive143Third132Proof14
  · exact adaptive143Third132Proof15
  · exact adaptive143Third132Proof16
  · exact adaptive143Third132Proof17
  · exact adaptive143Third132Proof18
  · exact adaptive143Third132Proof19
  · exact adaptive143Third132Proof20
  · exact adaptive143Third132Proof21

#print axioms adaptive143Third132Proof0

end NineSeparatedSubsetSums
