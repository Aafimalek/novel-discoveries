import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive143Third117Node0 : CachedSearchNode :=
  ⟨4, 116, computeCenteredMask [148,143,117], 408, 56042⟩

end NineSeparatedSubsetSums
