import NineSeparatedSubsetSums.Adaptive143Third139State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third139Proof239 : runCachedNode 511 130096 Adaptive143Third139Node239 = false := by
  decide +kernel

#print axioms adaptive143Third139Proof239

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third139Proof147 : runCachedNode 511 130096 Adaptive143Third139Node147 = false := by
  decide +kernel

#print axioms adaptive143Third139Proof147

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third139Proof92 : runCachedNode 511 130096 Adaptive143Third139Node92 = false := by
  decide +kernel

#print axioms adaptive143Third139Proof92

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third139Proof210 : runCachedNode 511 130096 Adaptive143Third139Node210 = false := by
  decide +kernel

#print axioms adaptive143Third139Proof210

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third139Proof211 : runCachedNode 511 130096 Adaptive143Third139Node211 = false := by
  decide +kernel

#print axioms adaptive143Third139Proof211

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third139Proof121 : runCachedNode 511 130096 Adaptive143Third139Node121 = false := by
  decide +kernel

#print axioms adaptive143Third139Proof121

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third139Proof123 : runCachedNode 511 130096 Adaptive143Third139Node123 = false := by
  decide +kernel

#print axioms adaptive143Third139Proof123

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third139Proof144 : runCachedNode 511 130096 Adaptive143Third139Node144 = false := by
  decide +kernel

#print axioms adaptive143Third139Proof144

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third139Proof79 : runCachedNode 511 130096 Adaptive143Third139Node79 = false := by
  decide +kernel

#print axioms adaptive143Third139Proof79

end NineSeparatedSubsetSums
