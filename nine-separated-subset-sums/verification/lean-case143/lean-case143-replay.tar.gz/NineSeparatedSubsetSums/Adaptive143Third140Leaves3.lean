import NineSeparatedSubsetSums.Adaptive143Third140State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third140Proof200 : runCachedNode 511 130276 Adaptive143Third140Node200 = false := by
  decide +kernel

#print axioms adaptive143Third140Proof200

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third140Proof12 : runCachedNode 511 130276 Adaptive143Third140Node12 = false := by
  decide +kernel

#print axioms adaptive143Third140Proof12

end NineSeparatedSubsetSums
