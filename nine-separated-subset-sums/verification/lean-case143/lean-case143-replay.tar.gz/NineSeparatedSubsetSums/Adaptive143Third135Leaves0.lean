import NineSeparatedSubsetSums.Adaptive143Third135State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third135Proof47 : runCachedNode 511 129468 Adaptive143Third135Node47 = false := by
  decide +kernel

#print axioms adaptive143Third135Proof47

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third135Proof41 : runCachedNode 511 129468 Adaptive143Third135Node41 = false := by
  decide +kernel

#print axioms adaptive143Third135Proof41

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third135Proof49 : runCachedNode 511 129468 Adaptive143Third135Node49 = false := by
  decide +kernel

#print axioms adaptive143Third135Proof49

end NineSeparatedSubsetSums
