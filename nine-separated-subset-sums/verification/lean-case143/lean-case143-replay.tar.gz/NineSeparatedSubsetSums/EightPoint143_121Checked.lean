import NineSeparatedSubsetSums.EightPointPackedGeometry
import NineSeparatedSubsetSums.EightPoint143_121PackedBudget0
import NineSeparatedSubsetSums.EightPoint143_121PackedAnchor0Part0
import NineSeparatedSubsetSums.EightPoint143_121PackedAnchor0Part1
import NineSeparatedSubsetSums.EightPoint143_121PackedBudget1
import NineSeparatedSubsetSums.EightPoint143_121PackedAnchor1Part0
import NineSeparatedSubsetSums.EightPoint143_121PackedAnchor1Part1

namespace NineSeparatedSubsetSums

private theorem packedOct143_121Anchor0 :
  ∀ j : Fin 480, ((j.val : Int)+143+121)%2=0 →
    2293710 ≤ FourPointNumeric.octPackedCharge 143 121 20 packedOct143_121_0 (j.val : Int) := by
  intro j hj
  let k := (j.val-0)/2
  have hk : k < 240 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+0 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint143_121PackedAnchor0Part0 z
    rwa [he,hrep] at ht
  let z : Fin 120 := ⟨k-120, by omega⟩
  have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
  have ht := eightPoint143_121PackedAnchor0Part1 z
  rwa [he,hrep] at ht

private theorem packedOct143_121Anchor1 :
  ∀ j : Fin 480, ((j.val : Int)+143+121)%2=1 →
    2294991 ≤ FourPointNumeric.octPackedCharge 143 121 20 packedOct143_121_1 (j.val : Int) := by
  intro j hj
  let k := (j.val-1)/2
  have hk : k < 240 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+1 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint143_121PackedAnchor1Part0 z
    rwa [he,hrep] at ht
  let z : Fin 120 := ⟨k-120, by omega⟩
  have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
  have ht := eightPoint143_121PackedAnchor1Part1 z
  rwa [he,hrep] at ht

def packedOctCertificate143_121_0 : EightPointCertificate 143 121 0 126221 :=
  eightPointCertificateOfPacked 143 121 0 126221 2293710 20 packedOct143_121_0 457 480
    (by decide +kernel) (by decide) packedOct143_121Anchor0
    (by rw [packedOct143_121_0_budget]; decide)

def packedOctCertificate143_121_1 : EightPointCertificate 143 121 1 126221 :=
  eightPointCertificateOfPacked 143 121 1 126221 2294991 20 packedOct143_121_1 276 480
    (by decide +kernel) (by decide) packedOct143_121Anchor1
    (by rw [packedOct143_121_1_budget]; decide)

theorem max148_second143_third121_eightPoint_moment_bound (tail : List ℕ) (len : tail.length=6)
    (distinct : (natSubsetSums (148::143::121::tail)).Nodup) :
    126221 ≤ ((148::143::121::tail).map (· ^ 2)).sum := by
  apply eightPointNatMomentLower 143 121 126221 tail len distinct
  intro p hp
  by_cases h : p=0
  · subst p
    exact packedOctCertificate143_121_0
  · have he : p=1 := hp.resolve_left h
    subst p
    exact packedOctCertificate143_121_1

#print axioms max148_second143_third121_eightPoint_moment_bound

end NineSeparatedSubsetSums
