import NineSeparatedSubsetSums.Adaptive143Third140State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third140Proof22 : runCachedNode 511 130276 Adaptive143Third140Node22 = false := by
  decide +kernel

#print axioms adaptive143Third140Proof22

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third140Proof10 : runCachedNode 511 130276 Adaptive143Third140Node10 = false := by
  decide +kernel

#print axioms adaptive143Third140Proof10

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third140Proof1 : runCachedNode 511 130276 Adaptive143Third140Node1 = false := by
  decide +kernel

#print axioms adaptive143Third140Proof1

end NineSeparatedSubsetSums
