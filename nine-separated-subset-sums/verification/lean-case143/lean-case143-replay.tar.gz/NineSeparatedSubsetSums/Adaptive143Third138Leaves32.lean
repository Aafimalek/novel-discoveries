import NineSeparatedSubsetSums.Adaptive143Third138State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third138Proof146 : runCachedNode 511 129927 Adaptive143Third138Node146 = false := by
  decide +kernel

#print axioms adaptive143Third138Proof146

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third138Proof175 : runCachedNode 511 129927 Adaptive143Third138Node175 = false := by
  decide +kernel

#print axioms adaptive143Third138Proof175

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third138Proof205 : runCachedNode 511 129927 Adaptive143Third138Node205 = false := by
  decide +kernel

#print axioms adaptive143Third138Proof205

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third138Proof236 : runCachedNode 511 129927 Adaptive143Third138Node236 = false := by
  decide +kernel

#print axioms adaptive143Third138Proof236

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third138Proof237 : runCachedNode 511 129927 Adaptive143Third138Node237 = false := by
  decide +kernel

#print axioms adaptive143Third138Proof237

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third138Proof238 : runCachedNode 511 129927 Adaptive143Third138Node238 = false := by
  decide +kernel

#print axioms adaptive143Third138Proof238

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third138Proof173 : runCachedNode 511 129927 Adaptive143Third138Node173 = false := by
  decide +kernel

#print axioms adaptive143Third138Proof173

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third138Proof174 : runCachedNode 511 129927 Adaptive143Third138Node174 = false := by
  decide +kernel

#print axioms adaptive143Third138Proof174

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third138Proof203 : runCachedNode 511 129927 Adaptive143Third138Node203 = false := by
  decide +kernel

#print axioms adaptive143Third138Proof203

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third138Proof204 : runCachedNode 511 129927 Adaptive143Third138Node204 = false := by
  decide +kernel

#print axioms adaptive143Third138Proof204

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third138Proof235 : runCachedNode 511 129927 Adaptive143Third138Node235 = false := by
  decide +kernel

#print axioms adaptive143Third138Proof235

end NineSeparatedSubsetSums
