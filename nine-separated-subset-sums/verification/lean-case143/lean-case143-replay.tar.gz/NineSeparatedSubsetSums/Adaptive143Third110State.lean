import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive143Third110Node0 : CachedSearchNode :=
  ⟨4, 109, computeCenteredMask [148,143,110], 401, 54453⟩

end NineSeparatedSubsetSums
