import NineSeparatedSubsetSums.Adaptive143Third141State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third141Proof286 : runCachedNode 511 130431 Adaptive143Third141Node286 = false := by
  decide +kernel

#print axioms adaptive143Third141Proof286

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third141Proof70 : runCachedNode 511 130431 Adaptive143Third141Node70 = false := by
  decide +kernel

#print axioms adaptive143Third141Proof70

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third141Proof407 : runCachedNode 511 130431 Adaptive143Third141Node407 = false := by
  decide +kernel

#print axioms adaptive143Third141Proof407

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third141Proof11 : runCachedNode 511 130431 Adaptive143Third141Node11 = false := by
  decide +kernel

#print axioms adaptive143Third141Proof11

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third141Proof71 : runCachedNode 511 130431 Adaptive143Third141Node71 = false := by
  decide +kernel

#print axioms adaptive143Third141Proof71

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third141Proof95 : runCachedNode 511 130431 Adaptive143Third141Node95 = false := by
  decide +kernel

#print axioms adaptive143Third141Proof95

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third141Proof44 : runCachedNode 511 130431 Adaptive143Third141Node44 = false := by
  decide +kernel

#print axioms adaptive143Third141Proof44

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third141Proof260 : runCachedNode 511 130431 Adaptive143Third141Node260 = false := by
  decide +kernel

#print axioms adaptive143Third141Proof260

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third141Proof98 : runCachedNode 511 130431 Adaptive143Third141Node98 = false := by
  decide +kernel

#print axioms adaptive143Third141Proof98

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third141Proof152 : runCachedNode 511 130431 Adaptive143Third141Node152 = false := by
  decide +kernel

#print axioms adaptive143Third141Proof152

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third141Proof154 : runCachedNode 511 130431 Adaptive143Third141Node154 = false := by
  decide +kernel

#print axioms adaptive143Third141Proof154

end NineSeparatedSubsetSums
