import NineSeparatedSubsetSums.Adaptive143Third142State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third142Proof447 : runCachedNode 511 130584 Adaptive143Third142Node447 = false := by
  decide +kernel

#print axioms adaptive143Third142Proof447

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third142Proof449 : runCachedNode 511 130584 Adaptive143Third142Node449 = false := by
  decide +kernel

#print axioms adaptive143Third142Proof449

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third142Proof2 : runCachedNode 511 130584 Adaptive143Third142Node2 = false := by
  decide +kernel

#print axioms adaptive143Third142Proof2

end NineSeparatedSubsetSums
