import NineSeparatedSubsetSums.Adaptive143Third137State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third137Proof128 : runCachedNode 511 129784 Adaptive143Third137Node128 = false := by
  decide +kernel

#print axioms adaptive143Third137Proof128

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third137Proof130 : runCachedNode 511 129784 Adaptive143Third137Node130 = false := by
  decide +kernel

#print axioms adaptive143Third137Proof130

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third137Proof15 : runCachedNode 511 129784 Adaptive143Third137Node15 = false := by
  decide +kernel

#print axioms adaptive143Third137Proof15

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third137Proof101 : runCachedNode 511 129784 Adaptive143Third137Node101 = false := by
  decide +kernel

#print axioms adaptive143Third137Proof101

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third137Proof44 : runCachedNode 511 129784 Adaptive143Third137Node44 = false := by
  decide +kernel

#print axioms adaptive143Third137Proof44

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third137Proof26 : runCachedNode 511 129784 Adaptive143Third137Node26 = false := by
  decide +kernel

#print axioms adaptive143Third137Proof26

end NineSeparatedSubsetSums
