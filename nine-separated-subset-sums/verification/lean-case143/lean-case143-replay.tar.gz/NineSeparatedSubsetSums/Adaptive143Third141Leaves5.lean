import NineSeparatedSubsetSums.Adaptive143Third141State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third141Proof264 : runCachedNode 511 130431 Adaptive143Third141Node264 = false := by
  decide +kernel

#print axioms adaptive143Third141Proof264

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third141Proof335 : runCachedNode 511 130431 Adaptive143Third141Node335 = false := by
  decide +kernel

#print axioms adaptive143Third141Proof335

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third141Proof27 : runCachedNode 511 130431 Adaptive143Third141Node27 = false := by
  decide +kernel

#print axioms adaptive143Third141Proof27

end NineSeparatedSubsetSums
