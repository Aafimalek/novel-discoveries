import NineSeparatedSubsetSums.Adaptive143Third138State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third138Proof200 : runCachedNode 511 129927 Adaptive143Third138Node200 = false := by
  decide +kernel

#print axioms adaptive143Third138Proof200

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third138Proof225 : runCachedNode 511 129927 Adaptive143Third138Node225 = false := by
  decide +kernel

#print axioms adaptive143Third138Proof225

end NineSeparatedSubsetSums
