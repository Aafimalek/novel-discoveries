import NineSeparatedSubsetSums.Adaptive143Third140State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third140Proof303 : runCachedNode 511 130276 Adaptive143Third140Node303 = false := by
  decide +kernel

#print axioms adaptive143Third140Proof303

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third140Proof130 : runCachedNode 511 130276 Adaptive143Third140Node130 = false := by
  decide +kernel

#print axioms adaptive143Third140Proof130

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third140Proof71 : runCachedNode 511 130276 Adaptive143Third140Node71 = false := by
  decide +kernel

#print axioms adaptive143Third140Proof71

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third140Proof304 : runCachedNode 511 130276 Adaptive143Third140Node304 = false := by
  decide +kernel

#print axioms adaptive143Third140Proof304

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third140Proof236 : runCachedNode 511 130276 Adaptive143Third140Node236 = false := by
  decide +kernel

#print axioms adaptive143Third140Proof236

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third140Proof40 : runCachedNode 511 130276 Adaptive143Third140Node40 = false := by
  decide +kernel

#print axioms adaptive143Third140Proof40

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third140Proof41 : runCachedNode 511 130276 Adaptive143Third140Node41 = false := by
  decide +kernel

#print axioms adaptive143Third140Proof41

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third140Proof302 : runCachedNode 511 130276 Adaptive143Third140Node302 = false := by
  decide +kernel

#print axioms adaptive143Third140Proof302

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third140Proof389 : runCachedNode 511 130276 Adaptive143Third140Node389 = false := by
  decide +kernel

#print axioms adaptive143Third140Proof389

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third140Proof188 : runCachedNode 511 130276 Adaptive143Third140Node188 = false := by
  decide +kernel

#print axioms adaptive143Third140Proof188

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third140Proof157 : runCachedNode 511 130276 Adaptive143Third140Node157 = false := by
  decide +kernel

#print axioms adaptive143Third140Proof157

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third140Proof129 : runCachedNode 511 130276 Adaptive143Third140Node129 = false := by
  decide +kernel

#print axioms adaptive143Third140Proof129

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third140Proof95 : runCachedNode 511 130276 Adaptive143Third140Node95 = false := by
  decide +kernel

#print axioms adaptive143Third140Proof95

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third140Proof203 : runCachedNode 511 130276 Adaptive143Third140Node203 = false := by
  decide +kernel

#print axioms adaptive143Third140Proof203

end NineSeparatedSubsetSums
