import NineSeparatedSubsetSums.Adaptive143Third138State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third138Proof259 : runCachedNode 511 129927 Adaptive143Third138Node259 = false := by
  decide +kernel

#print axioms adaptive143Third138Proof259

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third138Proof88 : runCachedNode 511 129927 Adaptive143Third138Node88 = false := by
  decide +kernel

#print axioms adaptive143Third138Proof88

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third138Proof245 : runCachedNode 511 129927 Adaptive143Third138Node245 = false := by
  decide +kernel

#print axioms adaptive143Third138Proof245

end NineSeparatedSubsetSums
