import NineSeparatedSubsetSums.EightPointPackedGeometry
import NineSeparatedSubsetSums.EightPoint143_122PackedBudget0
import NineSeparatedSubsetSums.EightPoint143_122PackedAnchor0Part0
import NineSeparatedSubsetSums.EightPoint143_122PackedAnchor0Part1
import NineSeparatedSubsetSums.EightPoint143_122PackedAnchor0Part2
import NineSeparatedSubsetSums.EightPoint143_122PackedBudget1
import NineSeparatedSubsetSums.EightPoint143_122PackedAnchor1Part0
import NineSeparatedSubsetSums.EightPoint143_122PackedAnchor1Part1
import NineSeparatedSubsetSums.EightPoint143_122PackedAnchor1Part2

namespace NineSeparatedSubsetSums

private theorem packedOct143_122Anchor0 :
  ∀ j : Fin 482, ((j.val : Int)+143+122)%2=0 →
    2311840 ≤ FourPointNumeric.octPackedCharge 143 122 20 packedOct143_122_0 (j.val : Int) := by
  intro j hj
  let k := (j.val-1)/2
  have hk : k < 241 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+1 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint143_122PackedAnchor0Part0 z
    rwa [he,hrep] at ht
  by_cases h1 : k < 240
  · let z : Fin 120 := ⟨k-120, by omega⟩
    have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
    have ht := eightPoint143_122PackedAnchor0Part1 z
    rwa [he,hrep] at ht
  let z : Fin 1 := ⟨k-240, by omega⟩
  have he : (z.val : Int)+240 = k := by dsimp [z] <;> omega
  have ht := eightPoint143_122PackedAnchor0Part2 z
  rwa [he,hrep] at ht

private theorem packedOct143_122Anchor1 :
  ∀ j : Fin 482, ((j.val : Int)+143+122)%2=1 →
    2311344 ≤ FourPointNumeric.octPackedCharge 143 122 20 packedOct143_122_1 (j.val : Int) := by
  intro j hj
  let k := (j.val-0)/2
  have hk : k < 241 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+0 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint143_122PackedAnchor1Part0 z
    rwa [he,hrep] at ht
  by_cases h1 : k < 240
  · let z : Fin 120 := ⟨k-120, by omega⟩
    have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
    have ht := eightPoint143_122PackedAnchor1Part1 z
    rwa [he,hrep] at ht
  let z : Fin 1 := ⟨k-240, by omega⟩
  have he : (z.val : Int)+240 = k := by dsimp [z] <;> omega
  have ht := eightPoint143_122PackedAnchor1Part2 z
  rwa [he,hrep] at ht

def packedOctCertificate143_122_0 : EightPointCertificate 143 122 0 126480 :=
  eightPointCertificateOfPacked 143 122 0 126480 2311840 20 packedOct143_122_0 367 482
    (by decide +kernel) (by decide) packedOct143_122Anchor0
    (by rw [packedOct143_122_0_budget]; decide)

def packedOctCertificate143_122_1 : EightPointCertificate 143 122 1 126480 :=
  eightPointCertificateOfPacked 143 122 1 126480 2311344 20 packedOct143_122_1 272 482
    (by decide +kernel) (by decide) packedOct143_122Anchor1
    (by rw [packedOct143_122_1_budget]; decide)

theorem max148_second143_third122_eightPoint_moment_bound (tail : List ℕ) (len : tail.length=6)
    (distinct : (natSubsetSums (148::143::122::tail)).Nodup) :
    126480 ≤ ((148::143::122::tail).map (· ^ 2)).sum := by
  apply eightPointNatMomentLower 143 122 126480 tail len distinct
  intro p hp
  by_cases h : p=0
  · subst p
    exact packedOctCertificate143_122_0
  · have he : p=1 := hp.resolve_left h
    subst p
    exact packedOctCertificate143_122_1

#print axioms max148_second143_third122_eightPoint_moment_bound

end NineSeparatedSubsetSums
