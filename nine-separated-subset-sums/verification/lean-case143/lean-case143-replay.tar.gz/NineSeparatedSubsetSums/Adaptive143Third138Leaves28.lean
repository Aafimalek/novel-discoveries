import NineSeparatedSubsetSums.Adaptive143Third138State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third138Proof57 : runCachedNode 511 129927 Adaptive143Third138Node57 = false := by
  decide +kernel

#print axioms adaptive143Third138Proof57

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third138Proof8 : runCachedNode 511 129927 Adaptive143Third138Node8 = false := by
  decide +kernel

#print axioms adaptive143Third138Proof8

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third138Proof79 : runCachedNode 511 129927 Adaptive143Third138Node79 = false := by
  decide +kernel

#print axioms adaptive143Third138Proof79

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third138Proof133 : runCachedNode 511 129927 Adaptive143Third138Node133 = false := by
  decide +kernel

#print axioms adaptive143Third138Proof133

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third138Proof30 : runCachedNode 511 129927 Adaptive143Third138Node30 = false := by
  decide +kernel

#print axioms adaptive143Third138Proof30

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third138Proof81 : runCachedNode 511 129927 Adaptive143Third138Node81 = false := by
  decide +kernel

#print axioms adaptive143Third138Proof81

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third138Proof187 : runCachedNode 511 129927 Adaptive143Third138Node187 = false := by
  decide +kernel

#print axioms adaptive143Third138Proof187

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third138Proof249 : runCachedNode 511 129927 Adaptive143Third138Node249 = false := by
  decide +kernel

#print axioms adaptive143Third138Proof249

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third138Proof132 : runCachedNode 511 129927 Adaptive143Third138Node132 = false := by
  decide +kernel

#print axioms adaptive143Third138Proof132

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third138Proof250 : runCachedNode 511 129927 Adaptive143Third138Node250 = false := by
  decide +kernel

#print axioms adaptive143Third138Proof250

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third138Proof130 : runCachedNode 511 129927 Adaptive143Third138Node130 = false := by
  decide +kernel

#print axioms adaptive143Third138Proof130

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third138Proof218 : runCachedNode 511 129927 Adaptive143Third138Node218 = false := by
  decide +kernel

#print axioms adaptive143Third138Proof218

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third138Proof29 : runCachedNode 511 129927 Adaptive143Third138Node29 = false := by
  decide +kernel

#print axioms adaptive143Third138Proof29

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third138Proof248 : runCachedNode 511 129927 Adaptive143Third138Node248 = false := by
  decide +kernel

#print axioms adaptive143Third138Proof248

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third138Proof28 : runCachedNode 511 129927 Adaptive143Third138Node28 = false := by
  decide +kernel

#print axioms adaptive143Third138Proof28

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third138Proof188 : runCachedNode 511 129927 Adaptive143Third138Node188 = false := by
  decide +kernel

#print axioms adaptive143Third138Proof188

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third138Proof158 : runCachedNode 511 129927 Adaptive143Third138Node158 = false := by
  decide +kernel

#print axioms adaptive143Third138Proof158

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third138Proof103 : runCachedNode 511 129927 Adaptive143Third138Node103 = false := by
  decide +kernel

#print axioms adaptive143Third138Proof103

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third138Proof129 : runCachedNode 511 129927 Adaptive143Third138Node129 = false := by
  decide +kernel

#print axioms adaptive143Third138Proof129

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third138Proof6 : runCachedNode 511 129927 Adaptive143Third138Node6 = false := by
  decide +kernel

#print axioms adaptive143Third138Proof6

end NineSeparatedSubsetSums
