import NineSeparatedSubsetSums.Adaptive143Third115Joins0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint143Checked

namespace NineSeparatedSubsetSums


theorem adaptive143Third115 : NoDescendingTailAfterThird 143 115 :=
  noDescendingThirdTail_of_cached 143 115 112040 (fun t ht nd => max148_second143_fourPoint_moment_bound (115::t) (by simp [ht]) nd) adaptive143Third115Proof0

#print axioms adaptive143Third115

end NineSeparatedSubsetSums
