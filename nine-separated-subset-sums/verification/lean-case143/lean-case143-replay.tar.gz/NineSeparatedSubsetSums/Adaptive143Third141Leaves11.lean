import NineSeparatedSubsetSums.Adaptive143Third141State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third141Proof19 : runCachedNode 511 130431 Adaptive143Third141Node19 = false := by
  decide +kernel

#print axioms adaptive143Third141Proof19

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third141Proof297 : runCachedNode 511 130431 Adaptive143Third141Node297 = false := by
  decide +kernel

#print axioms adaptive143Third141Proof297

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third141Proof57 : runCachedNode 511 130431 Adaptive143Third141Node57 = false := by
  decide +kernel

#print axioms adaptive143Third141Proof57

end NineSeparatedSubsetSums
