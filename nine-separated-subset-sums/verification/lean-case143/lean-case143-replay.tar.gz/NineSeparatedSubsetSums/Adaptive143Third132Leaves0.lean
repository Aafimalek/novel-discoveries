import NineSeparatedSubsetSums.Adaptive143Third132State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third132Proof21 : runCachedNode 511 128948 Adaptive143Third132Node21 = false := by
  decide +kernel

#print axioms adaptive143Third132Proof21

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third132Proof17 : runCachedNode 511 128948 Adaptive143Third132Node17 = false := by
  decide +kernel

#print axioms adaptive143Third132Proof17

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third132Proof6 : runCachedNode 511 128948 Adaptive143Third132Node6 = false := by
  decide +kernel

#print axioms adaptive143Third132Proof6

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third132Proof3 : runCachedNode 511 128948 Adaptive143Third132Node3 = false := by
  decide +kernel

#print axioms adaptive143Third132Proof3

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third132Proof1 : runCachedNode 511 128948 Adaptive143Third132Node1 = false := by
  decide +kernel

#print axioms adaptive143Third132Proof1

end NineSeparatedSubsetSums
