import NineSeparatedSubsetSums.EightPoint143_121PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct143_121_0_budget :
    FourPointNumeric.packedBudget 20 packedOct143_121_0 457 = 82172676 := by decide +kernel

#print axioms packedOct143_121_0_budget

end NineSeparatedSubsetSums
