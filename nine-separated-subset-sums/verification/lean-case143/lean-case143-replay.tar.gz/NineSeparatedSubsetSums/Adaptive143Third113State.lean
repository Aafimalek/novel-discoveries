import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive143Third113Node0 : CachedSearchNode :=
  ⟨4, 112, computeCenteredMask [148,143,113], 404, 55122⟩

end NineSeparatedSubsetSums
