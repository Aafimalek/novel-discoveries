import NineSeparatedSubsetSums.Adaptive143Third136State
import NineSeparatedSubsetSums.Adaptive143Third136Leaves8
import NineSeparatedSubsetSums.Adaptive143Third136Leaves10
import NineSeparatedSubsetSums.Adaptive143Third136Leaves9
import NineSeparatedSubsetSums.Adaptive143Third136Leaves7
import NineSeparatedSubsetSums.Adaptive143Third136Leaves3
import NineSeparatedSubsetSums.Adaptive143Third136Leaves6
import NineSeparatedSubsetSums.Adaptive143Third136Leaves1
import NineSeparatedSubsetSums.Adaptive143Third136Leaves4
import NineSeparatedSubsetSums.Adaptive143Third136Leaves5
import NineSeparatedSubsetSums.Adaptive143Third136Leaves2
import NineSeparatedSubsetSums.Adaptive143Third136Leaves0

namespace NineSeparatedSubsetSums

theorem adaptive143Third136Proof22 : runCachedNode 511 129643 Adaptive143Third136Node22 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 129643 Adaptive143Third136Node22 = [104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 121, 122, 123, 124, 126, 128, 129, 130] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive143Third136Proof23
  · exact adaptive143Third136Proof24
  · exact adaptive143Third136Proof25
  · exact adaptive143Third136Proof26
  · exact adaptive143Third136Proof27
  · exact adaptive143Third136Proof28
  · exact adaptive143Third136Proof29
  · exact adaptive143Third136Proof30
  · exact adaptive143Third136Proof31
  · exact adaptive143Third136Proof32
  · exact adaptive143Third136Proof33
  · exact adaptive143Third136Proof34
  · exact adaptive143Third136Proof35
  · exact adaptive143Third136Proof36
  · exact adaptive143Third136Proof37
  · exact adaptive143Third136Proof38
  · exact adaptive143Third136Proof39
  · exact adaptive143Third136Proof40
  · exact adaptive143Third136Proof41
  · exact adaptive143Third136Proof42
  · exact adaptive143Third136Proof43
  · exact adaptive143Third136Proof44
  · exact adaptive143Third136Proof45
  · exact adaptive143Third136Proof46

#print axioms adaptive143Third136Proof22

theorem adaptive143Third136Proof48 : runCachedNode 511 129643 Adaptive143Third136Node48 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 129643 Adaptive143Third136Node48 = [103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 123, 124, 125, 126, 128, 130, 132, 133] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive143Third136Proof49
  · exact adaptive143Third136Proof50
  · exact adaptive143Third136Proof51
  · exact adaptive143Third136Proof52
  · exact adaptive143Third136Proof53
  · exact adaptive143Third136Proof54
  · exact adaptive143Third136Proof55
  · exact adaptive143Third136Proof56
  · exact adaptive143Third136Proof57
  · exact adaptive143Third136Proof58
  · exact adaptive143Third136Proof59
  · exact adaptive143Third136Proof60
  · exact adaptive143Third136Proof61
  · exact adaptive143Third136Proof62
  · exact adaptive143Third136Proof63
  · exact adaptive143Third136Proof64
  · exact adaptive143Third136Proof65
  · exact adaptive143Third136Proof66
  · exact adaptive143Third136Proof67
  · exact adaptive143Third136Proof68
  · exact adaptive143Third136Proof69
  · exact adaptive143Third136Proof70
  · exact adaptive143Third136Proof71
  · exact adaptive143Third136Proof72
  · exact adaptive143Third136Proof73
  · exact adaptive143Third136Proof74
  · exact adaptive143Third136Proof75

#print axioms adaptive143Third136Proof48

theorem adaptive143Third136Proof76 : runCachedNode 511 129643 Adaptive143Third136Node76 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 129643 Adaptive143Third136Node76 = [103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 124, 125, 126, 127, 129, 132, 133, 134] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive143Third136Proof77
  · exact adaptive143Third136Proof78
  · exact adaptive143Third136Proof79
  · exact adaptive143Third136Proof80
  · exact adaptive143Third136Proof81
  · exact adaptive143Third136Proof82
  · exact adaptive143Third136Proof83
  · exact adaptive143Third136Proof84
  · exact adaptive143Third136Proof85
  · exact adaptive143Third136Proof86
  · exact adaptive143Third136Proof87
  · exact adaptive143Third136Proof88
  · exact adaptive143Third136Proof89
  · exact adaptive143Third136Proof90
  · exact adaptive143Third136Proof91
  · exact adaptive143Third136Proof92
  · exact adaptive143Third136Proof93
  · exact adaptive143Third136Proof94
  · exact adaptive143Third136Proof95
  · exact adaptive143Third136Proof96
  · exact adaptive143Third136Proof97
  · exact adaptive143Third136Proof98
  · exact adaptive143Third136Proof99
  · exact adaptive143Third136Proof100
  · exact adaptive143Third136Proof101
  · exact adaptive143Third136Proof102
  · exact adaptive143Third136Proof103
  · exact adaptive143Third136Proof104

#print axioms adaptive143Third136Proof76

theorem adaptive143Third136Proof0 : runCachedNode 511 129643 Adaptive143Third136Node0 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 129643 Adaptive143Third136Node0 = [110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 132, 133, 134, 135] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive143Third136Proof1
  · exact adaptive143Third136Proof2
  · exact adaptive143Third136Proof3
  · exact adaptive143Third136Proof4
  · exact adaptive143Third136Proof5
  · exact adaptive143Third136Proof6
  · exact adaptive143Third136Proof7
  · exact adaptive143Third136Proof8
  · exact adaptive143Third136Proof9
  · exact adaptive143Third136Proof10
  · exact adaptive143Third136Proof11
  · exact adaptive143Third136Proof12
  · exact adaptive143Third136Proof13
  · exact adaptive143Third136Proof14
  · exact adaptive143Third136Proof15
  · exact adaptive143Third136Proof16
  · exact adaptive143Third136Proof17
  · exact adaptive143Third136Proof18
  · exact adaptive143Third136Proof19
  · exact adaptive143Third136Proof20
  · exact adaptive143Third136Proof21
  · exact adaptive143Third136Proof22
  · exact adaptive143Third136Proof47
  · exact adaptive143Third136Proof48
  · exact adaptive143Third136Proof76

#print axioms adaptive143Third136Proof0

end NineSeparatedSubsetSums
