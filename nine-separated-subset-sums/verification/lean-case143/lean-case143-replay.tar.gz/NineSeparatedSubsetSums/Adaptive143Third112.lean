import NineSeparatedSubsetSums.Adaptive143Third112Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint143Checked

namespace NineSeparatedSubsetSums


theorem adaptive143Third112 : NoDescendingTailAfterThird 143 112 :=
  noDescendingThirdTail_of_cached 143 112 112040 (fun t ht nd => max148_second143_fourPoint_moment_bound (112::t) (by simp [ht]) nd) adaptive143Third112Proof0

#print axioms adaptive143Third112

end NineSeparatedSubsetSums
