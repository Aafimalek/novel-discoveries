import NineSeparatedSubsetSums.Adaptive143Third117State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third117Proof0 : runCachedNode 511 125488 Adaptive143Third117Node0 = false := by
  decide +kernel

#print axioms adaptive143Third117Proof0

end NineSeparatedSubsetSums
