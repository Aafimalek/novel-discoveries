import NineSeparatedSubsetSums.Adaptive143Third113Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint143Checked

namespace NineSeparatedSubsetSums


theorem adaptive143Third113 : NoDescendingTailAfterThird 143 113 :=
  noDescendingThirdTail_of_cached 143 113 112040 (fun t ht nd => max148_second143_fourPoint_moment_bound (113::t) (by simp [ht]) nd) adaptive143Third113Proof0

#print axioms adaptive143Third113

end NineSeparatedSubsetSums
