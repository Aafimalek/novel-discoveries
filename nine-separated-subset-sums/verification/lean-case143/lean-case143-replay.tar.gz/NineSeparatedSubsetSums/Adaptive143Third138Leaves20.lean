import NineSeparatedSubsetSums.Adaptive143Third138State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third138Proof199 : runCachedNode 511 129927 Adaptive143Third138Node199 = false := by
  decide +kernel

#print axioms adaptive143Third138Proof199

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third138Proof13 : runCachedNode 511 129927 Adaptive143Third138Node13 = false := by
  decide +kernel

#print axioms adaptive143Third138Proof13

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third138Proof198 : runCachedNode 511 129927 Adaptive143Third138Node198 = false := by
  decide +kernel

#print axioms adaptive143Third138Proof198

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third138Proof87 : runCachedNode 511 129927 Adaptive143Third138Node87 = false := by
  decide +kernel

#print axioms adaptive143Third138Proof87

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third138Proof4 : runCachedNode 511 129927 Adaptive143Third138Node4 = false := by
  decide +kernel

#print axioms adaptive143Third138Proof4

end NineSeparatedSubsetSums
