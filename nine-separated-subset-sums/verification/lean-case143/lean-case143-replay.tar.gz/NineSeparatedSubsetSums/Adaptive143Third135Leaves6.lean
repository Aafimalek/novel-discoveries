import NineSeparatedSubsetSums.Adaptive143Third135State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third135Proof74 : runCachedNode 511 129468 Adaptive143Third135Node74 = false := by
  decide +kernel

#print axioms adaptive143Third135Proof74

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third135Proof70 : runCachedNode 511 129468 Adaptive143Third135Node70 = false := by
  decide +kernel

#print axioms adaptive143Third135Proof70

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third135Proof46 : runCachedNode 511 129468 Adaptive143Third135Node46 = false := by
  decide +kernel

#print axioms adaptive143Third135Proof46

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third135Proof44 : runCachedNode 511 129468 Adaptive143Third135Node44 = false := by
  decide +kernel

#print axioms adaptive143Third135Proof44

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third135Proof40 : runCachedNode 511 129468 Adaptive143Third135Node40 = false := by
  decide +kernel

#print axioms adaptive143Third135Proof40

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third135Proof11 : runCachedNode 511 129468 Adaptive143Third135Node11 = false := by
  decide +kernel

#print axioms adaptive143Third135Proof11

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third135Proof10 : runCachedNode 511 129468 Adaptive143Third135Node10 = false := by
  decide +kernel

#print axioms adaptive143Third135Proof10

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third135Proof39 : runCachedNode 511 129468 Adaptive143Third135Node39 = false := by
  decide +kernel

#print axioms adaptive143Third135Proof39

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third135Proof67 : runCachedNode 511 129468 Adaptive143Third135Node67 = false := by
  decide +kernel

#print axioms adaptive143Third135Proof67

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third135Proof42 : runCachedNode 511 129468 Adaptive143Third135Node42 = false := by
  decide +kernel

#print axioms adaptive143Third135Proof42

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third135Proof9 : runCachedNode 511 129468 Adaptive143Third135Node9 = false := by
  decide +kernel

#print axioms adaptive143Third135Proof9

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third135Proof5 : runCachedNode 511 129468 Adaptive143Third135Node5 = false := by
  decide +kernel

#print axioms adaptive143Third135Proof5

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third135Proof23 : runCachedNode 511 129468 Adaptive143Third135Node23 = false := by
  decide +kernel

#print axioms adaptive143Third135Proof23

end NineSeparatedSubsetSums
