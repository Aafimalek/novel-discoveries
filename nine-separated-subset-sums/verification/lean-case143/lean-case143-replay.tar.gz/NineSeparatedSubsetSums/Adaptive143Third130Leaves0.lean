import NineSeparatedSubsetSums.Adaptive143Third130State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third130Proof19 : runCachedNode 511 128577 Adaptive143Third130Node19 = false := by
  decide +kernel

#print axioms adaptive143Third130Proof19

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third130Proof18 : runCachedNode 511 128577 Adaptive143Third130Node18 = false := by
  decide +kernel

#print axioms adaptive143Third130Proof18

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third130Proof15 : runCachedNode 511 128577 Adaptive143Third130Node15 = false := by
  decide +kernel

#print axioms adaptive143Third130Proof15

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third130Proof4 : runCachedNode 511 128577 Adaptive143Third130Node4 = false := by
  decide +kernel

#print axioms adaptive143Third130Proof4

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third130Proof1 : runCachedNode 511 128577 Adaptive143Third130Node1 = false := by
  decide +kernel

#print axioms adaptive143Third130Proof1

end NineSeparatedSubsetSums
