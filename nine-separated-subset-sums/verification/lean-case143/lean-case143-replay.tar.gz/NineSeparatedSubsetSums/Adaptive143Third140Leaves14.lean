import NineSeparatedSubsetSums.Adaptive143Third140State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third140Proof163 : runCachedNode 511 130276 Adaptive143Third140Node163 = false := by
  decide +kernel

#print axioms adaptive143Third140Proof163

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third140Proof17 : runCachedNode 511 130276 Adaptive143Third140Node17 = false := by
  decide +kernel

#print axioms adaptive143Third140Proof17

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third140Proof352 : runCachedNode 511 130276 Adaptive143Third140Node352 = false := by
  decide +kernel

#print axioms adaptive143Third140Proof352

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third140Proof148 : runCachedNode 511 130276 Adaptive143Third140Node148 = false := by
  decide +kernel

#print axioms adaptive143Third140Proof148

end NineSeparatedSubsetSums
