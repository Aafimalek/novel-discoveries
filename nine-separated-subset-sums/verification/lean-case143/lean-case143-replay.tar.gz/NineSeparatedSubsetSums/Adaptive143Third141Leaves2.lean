import NineSeparatedSubsetSums.Adaptive143Third141State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third141Proof225 : runCachedNode 511 130431 Adaptive143Third141Node225 = false := by
  decide +kernel

#print axioms adaptive143Third141Proof225

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third141Proof45 : runCachedNode 511 130431 Adaptive143Third141Node45 = false := by
  decide +kernel

#print axioms adaptive143Third141Proof45

end NineSeparatedSubsetSums
