import NineSeparatedSubsetSums.Adaptive143Third141State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third141Proof376 : runCachedNode 511 130431 Adaptive143Third141Node376 = false := by
  decide +kernel

#print axioms adaptive143Third141Proof376

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third141Proof453 : runCachedNode 511 130431 Adaptive143Third141Node453 = false := by
  decide +kernel

#print axioms adaptive143Third141Proof453

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third141Proof15 : runCachedNode 511 130431 Adaptive143Third141Node15 = false := by
  decide +kernel

#print axioms adaptive143Third141Proof15

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third141Proof334 : runCachedNode 511 130431 Adaptive143Third141Node334 = false := by
  decide +kernel

#print axioms adaptive143Third141Proof334

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third141Proof214 : runCachedNode 511 130431 Adaptive143Third141Node214 = false := by
  decide +kernel

#print axioms adaptive143Third141Proof214

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third141Proof23 : runCachedNode 511 130431 Adaptive143Third141Node23 = false := by
  decide +kernel

#print axioms adaptive143Third141Proof23

end NineSeparatedSubsetSums
