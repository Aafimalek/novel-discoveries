import NineSeparatedSubsetSums.Adaptive143Third103Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint143Checked

namespace NineSeparatedSubsetSums


theorem adaptive143Third103 : NoDescendingTailAfterThird 143 103 :=
  noDescendingThirdTail_of_cached 143 103 112040 (fun t ht nd => max148_second143_fourPoint_moment_bound (103::t) (by simp [ht]) nd) adaptive143Third103Proof0

#print axioms adaptive143Third103

end NineSeparatedSubsetSums
