import NineSeparatedSubsetSums.EightPoint143_128PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint143_128PackedAnchor0Part2 :
    ∀ j : Fin 6, 2399863 ≤ FourPointNumeric.octPackedCharge 143 128 20 packedOct143_128_0
      (2*((j.val : Int)+240)+1) := by decide +kernel

end NineSeparatedSubsetSums
