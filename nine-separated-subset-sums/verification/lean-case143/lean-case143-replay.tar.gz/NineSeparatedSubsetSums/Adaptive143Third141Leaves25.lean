import NineSeparatedSubsetSums.Adaptive143Third141State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third141Proof43 : runCachedNode 511 130431 Adaptive143Third141Node43 = false := by
  decide +kernel

#print axioms adaptive143Third141Proof43

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third141Proof68 : runCachedNode 511 130431 Adaptive143Third141Node68 = false := by
  decide +kernel

#print axioms adaptive143Third141Proof68

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third141Proof155 : runCachedNode 511 130431 Adaptive143Third141Node155 = false := by
  decide +kernel

#print axioms adaptive143Third141Proof155

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third141Proof41 : runCachedNode 511 130431 Adaptive143Third141Node41 = false := by
  decide +kernel

#print axioms adaptive143Third141Proof41

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third141Proof97 : runCachedNode 511 130431 Adaptive143Third141Node97 = false := by
  decide +kernel

#print axioms adaptive143Third141Proof97

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third141Proof287 : runCachedNode 511 130431 Adaptive143Third141Node287 = false := by
  decide +kernel

#print axioms adaptive143Third141Proof287

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third141Proof373 : runCachedNode 511 130431 Adaptive143Third141Node373 = false := by
  decide +kernel

#print axioms adaptive143Third141Proof373

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third141Proof121 : runCachedNode 511 130431 Adaptive143Third141Node121 = false := by
  decide +kernel

#print axioms adaptive143Third141Proof121

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third141Proof215 : runCachedNode 511 130431 Adaptive143Third141Node215 = false := by
  decide +kernel

#print axioms adaptive143Third141Proof215

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third141Proof212 : runCachedNode 511 130431 Adaptive143Third141Node212 = false := by
  decide +kernel

#print axioms adaptive143Third141Proof212

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third141Proof164 : runCachedNode 511 130431 Adaptive143Third141Node164 = false := by
  decide +kernel

#print axioms adaptive143Third141Proof164

end NineSeparatedSubsetSums
