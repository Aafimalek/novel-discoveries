import NineSeparatedSubsetSums.Adaptive143Third132State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third132Proof20 : runCachedNode 511 128948 Adaptive143Third132Node20 = false := by
  decide +kernel

#print axioms adaptive143Third132Proof20

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third132Proof18 : runCachedNode 511 128948 Adaptive143Third132Node18 = false := by
  decide +kernel

#print axioms adaptive143Third132Proof18

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third132Proof4 : runCachedNode 511 128948 Adaptive143Third132Node4 = false := by
  decide +kernel

#print axioms adaptive143Third132Proof4

end NineSeparatedSubsetSums
