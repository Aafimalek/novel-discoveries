import NineSeparatedSubsetSums.EightPoint143_127PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint143_127PackedAnchor0Part2 :
    ∀ j : Fin 5, 2379376 ≤ FourPointNumeric.octPackedCharge 143 127 20 packedOct143_127_0
      (2*((j.val : Int)+240)+0) := by decide +kernel

end NineSeparatedSubsetSums
