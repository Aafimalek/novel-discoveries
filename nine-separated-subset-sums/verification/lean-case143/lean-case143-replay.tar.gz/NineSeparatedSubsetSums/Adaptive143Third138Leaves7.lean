import NineSeparatedSubsetSums.Adaptive143Third138State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third138Proof17 : runCachedNode 511 129927 Adaptive143Third138Node17 = false := by
  decide +kernel

#print axioms adaptive143Third138Proof17

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third138Proof230 : runCachedNode 511 129927 Adaptive143Third138Node230 = false := by
  decide +kernel

#print axioms adaptive143Third138Proof230

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third138Proof44 : runCachedNode 511 129927 Adaptive143Third138Node44 = false := by
  decide +kernel

#print axioms adaptive143Third138Proof44

end NineSeparatedSubsetSums
