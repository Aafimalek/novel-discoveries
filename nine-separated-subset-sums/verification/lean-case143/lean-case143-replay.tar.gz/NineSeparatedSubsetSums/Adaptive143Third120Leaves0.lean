import NineSeparatedSubsetSums.Adaptive143Third120State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third120Proof0 : runCachedNode 511 126018 Adaptive143Third120Node0 = false := by
  decide +kernel

#print axioms adaptive143Third120Proof0

end NineSeparatedSubsetSums
