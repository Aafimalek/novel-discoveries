import NineSeparatedSubsetSums.Adaptive143Third137State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third137Proof17 : runCachedNode 511 129784 Adaptive143Third137Node17 = false := by
  decide +kernel

#print axioms adaptive143Third137Proof17

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third137Proof158 : runCachedNode 511 129784 Adaptive143Third137Node158 = false := by
  decide +kernel

#print axioms adaptive143Third137Proof158

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third137Proof154 : runCachedNode 511 129784 Adaptive143Third137Node154 = false := by
  decide +kernel

#print axioms adaptive143Third137Proof154

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third137Proof49 : runCachedNode 511 129784 Adaptive143Third137Node49 = false := by
  decide +kernel

#print axioms adaptive143Third137Proof49

end NineSeparatedSubsetSums
