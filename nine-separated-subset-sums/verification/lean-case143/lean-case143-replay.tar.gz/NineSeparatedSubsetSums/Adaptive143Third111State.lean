import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive143Third111Node0 : CachedSearchNode :=
  ⟨4, 110, computeCenteredMask [148,143,111], 402, 54674⟩

end NineSeparatedSubsetSums
