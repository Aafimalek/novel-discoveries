import NineSeparatedSubsetSums.Adaptive143Third113State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third113Proof0 : runCachedNode 511 112040 Adaptive143Third113Node0 = false := by
  decide +kernel

#print axioms adaptive143Third113Proof0

end NineSeparatedSubsetSums
