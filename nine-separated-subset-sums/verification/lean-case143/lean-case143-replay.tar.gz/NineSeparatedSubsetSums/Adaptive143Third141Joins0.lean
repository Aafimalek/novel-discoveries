import NineSeparatedSubsetSums.Adaptive143Third141State
import NineSeparatedSubsetSums.Adaptive143Third141Leaves19
import NineSeparatedSubsetSums.Adaptive143Third141Leaves29
import NineSeparatedSubsetSums.Adaptive143Third141Leaves34
import NineSeparatedSubsetSums.Adaptive143Third141Leaves5
import NineSeparatedSubsetSums.Adaptive143Third141Leaves7
import NineSeparatedSubsetSums.Adaptive143Third141Leaves23
import NineSeparatedSubsetSums.Adaptive143Third141Leaves33
import NineSeparatedSubsetSums.Adaptive143Third141Leaves32
import NineSeparatedSubsetSums.Adaptive143Third141Leaves6
import NineSeparatedSubsetSums.Adaptive143Third141Leaves31
import NineSeparatedSubsetSums.Adaptive143Third141Leaves30
import NineSeparatedSubsetSums.Adaptive143Third141Leaves28
import NineSeparatedSubsetSums.Adaptive143Third141Leaves27
import NineSeparatedSubsetSums.Adaptive143Third141Leaves25
import NineSeparatedSubsetSums.Adaptive143Third141Leaves26
import NineSeparatedSubsetSums.Adaptive143Third141Leaves2
import NineSeparatedSubsetSums.Adaptive143Third141Leaves36
import NineSeparatedSubsetSums.Adaptive143Third141Leaves0
import NineSeparatedSubsetSums.Adaptive143Third141Leaves14
import NineSeparatedSubsetSums.Adaptive143Third141Leaves35
import NineSeparatedSubsetSums.Adaptive143Third141Leaves11
import NineSeparatedSubsetSums.Adaptive143Third141Leaves18
import NineSeparatedSubsetSums.Adaptive143Third141Leaves21
import NineSeparatedSubsetSums.Adaptive143Third141Leaves12
import NineSeparatedSubsetSums.Adaptive143Third141Leaves16
import NineSeparatedSubsetSums.Adaptive143Third141Leaves20
import NineSeparatedSubsetSums.Adaptive143Third141Leaves24
import NineSeparatedSubsetSums.Adaptive143Third141Leaves13
import NineSeparatedSubsetSums.Adaptive143Third141Leaves22
import NineSeparatedSubsetSums.Adaptive143Third141Leaves17
import NineSeparatedSubsetSums.Adaptive143Third141Leaves10
import NineSeparatedSubsetSums.Adaptive143Third141Leaves8
import NineSeparatedSubsetSums.Adaptive143Third141Leaves1
import NineSeparatedSubsetSums.Adaptive143Third141Leaves4
import NineSeparatedSubsetSums.Adaptive143Third141Leaves9
import NineSeparatedSubsetSums.Adaptive143Third141Leaves15
import NineSeparatedSubsetSums.Adaptive143Third141Leaves37

namespace NineSeparatedSubsetSums

theorem adaptive143Third141Proof22 : runCachedNode 511 130431 Adaptive143Third141Node22 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130431 Adaptive143Third141Node22 = [104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 125, 127, 128, 130] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive143Third141Proof23
  · exact adaptive143Third141Proof24
  · exact adaptive143Third141Proof25
  · exact adaptive143Third141Proof26
  · exact adaptive143Third141Proof27
  · exact adaptive143Third141Proof28
  · exact adaptive143Third141Proof29
  · exact adaptive143Third141Proof30
  · exact adaptive143Third141Proof31
  · exact adaptive143Third141Proof32
  · exact adaptive143Third141Proof33
  · exact adaptive143Third141Proof34
  · exact adaptive143Third141Proof35
  · exact adaptive143Third141Proof36
  · exact adaptive143Third141Proof37
  · exact adaptive143Third141Proof38
  · exact adaptive143Third141Proof39
  · exact adaptive143Third141Proof40
  · exact adaptive143Third141Proof41
  · exact adaptive143Third141Proof42
  · exact adaptive143Third141Proof43
  · exact adaptive143Third141Proof44
  · exact adaptive143Third141Proof45
  · exact adaptive143Third141Proof46

#print axioms adaptive143Third141Proof22

theorem adaptive143Third141Proof47 : runCachedNode 511 130431 Adaptive143Third141Node47 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130431 Adaptive143Third141Node47 = [103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 126, 128, 129, 131] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive143Third141Proof48
  · exact adaptive143Third141Proof49
  · exact adaptive143Third141Proof50
  · exact adaptive143Third141Proof51
  · exact adaptive143Third141Proof52
  · exact adaptive143Third141Proof53
  · exact adaptive143Third141Proof54
  · exact adaptive143Third141Proof55
  · exact adaptive143Third141Proof56
  · exact adaptive143Third141Proof57
  · exact adaptive143Third141Proof58
  · exact adaptive143Third141Proof59
  · exact adaptive143Third141Proof60
  · exact adaptive143Third141Proof61
  · exact adaptive143Third141Proof62
  · exact adaptive143Third141Proof63
  · exact adaptive143Third141Proof64
  · exact adaptive143Third141Proof65
  · exact adaptive143Third141Proof66
  · exact adaptive143Third141Proof67
  · exact adaptive143Third141Proof68
  · exact adaptive143Third141Proof69
  · exact adaptive143Third141Proof70
  · exact adaptive143Third141Proof71
  · exact adaptive143Third141Proof72
  · exact adaptive143Third141Proof73

#print axioms adaptive143Third141Proof47

theorem adaptive143Third141Proof74 : runCachedNode 511 130431 Adaptive143Third141Node74 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130431 Adaptive143Third141Node74 = [103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 127, 129, 130, 132] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive143Third141Proof75
  · exact adaptive143Third141Proof76
  · exact adaptive143Third141Proof77
  · exact adaptive143Third141Proof78
  · exact adaptive143Third141Proof79
  · exact adaptive143Third141Proof80
  · exact adaptive143Third141Proof81
  · exact adaptive143Third141Proof82
  · exact adaptive143Third141Proof83
  · exact adaptive143Third141Proof84
  · exact adaptive143Third141Proof85
  · exact adaptive143Third141Proof86
  · exact adaptive143Third141Proof87
  · exact adaptive143Third141Proof88
  · exact adaptive143Third141Proof89
  · exact adaptive143Third141Proof90
  · exact adaptive143Third141Proof91
  · exact adaptive143Third141Proof92
  · exact adaptive143Third141Proof93
  · exact adaptive143Third141Proof94
  · exact adaptive143Third141Proof95
  · exact adaptive143Third141Proof96
  · exact adaptive143Third141Proof97
  · exact adaptive143Third141Proof98
  · exact adaptive143Third141Proof99
  · exact adaptive143Third141Proof100
  · exact adaptive143Third141Proof101

#print axioms adaptive143Third141Proof74

theorem adaptive143Third141Proof102 : runCachedNode 511 130431 Adaptive143Third141Node102 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130431 Adaptive143Third141Node102 = [103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 128, 130, 131, 133] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive143Third141Proof103
  · exact adaptive143Third141Proof104
  · exact adaptive143Third141Proof105
  · exact adaptive143Third141Proof106
  · exact adaptive143Third141Proof107
  · exact adaptive143Third141Proof108
  · exact adaptive143Third141Proof109
  · exact adaptive143Third141Proof110
  · exact adaptive143Third141Proof111
  · exact adaptive143Third141Proof112
  · exact adaptive143Third141Proof113
  · exact adaptive143Third141Proof114
  · exact adaptive143Third141Proof115
  · exact adaptive143Third141Proof116
  · exact adaptive143Third141Proof117
  · exact adaptive143Third141Proof118
  · exact adaptive143Third141Proof119
  · exact adaptive143Third141Proof120
  · exact adaptive143Third141Proof121
  · exact adaptive143Third141Proof122
  · exact adaptive143Third141Proof123
  · exact adaptive143Third141Proof124
  · exact adaptive143Third141Proof125
  · exact adaptive143Third141Proof126
  · exact adaptive143Third141Proof127
  · exact adaptive143Third141Proof128
  · exact adaptive143Third141Proof129
  · exact adaptive143Third141Proof130

#print axioms adaptive143Third141Proof102

theorem adaptive143Third141Proof131 : runCachedNode 511 130431 Adaptive143Third141Node131 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130431 Adaptive143Third141Node131 = [102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 129, 131, 132, 134] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive143Third141Proof132
  · exact adaptive143Third141Proof133
  · exact adaptive143Third141Proof134
  · exact adaptive143Third141Proof135
  · exact adaptive143Third141Proof136
  · exact adaptive143Third141Proof137
  · exact adaptive143Third141Proof138
  · exact adaptive143Third141Proof139
  · exact adaptive143Third141Proof140
  · exact adaptive143Third141Proof141
  · exact adaptive143Third141Proof142
  · exact adaptive143Third141Proof143
  · exact adaptive143Third141Proof144
  · exact adaptive143Third141Proof145
  · exact adaptive143Third141Proof146
  · exact adaptive143Third141Proof147
  · exact adaptive143Third141Proof148
  · exact adaptive143Third141Proof149
  · exact adaptive143Third141Proof150
  · exact adaptive143Third141Proof151
  · exact adaptive143Third141Proof152
  · exact adaptive143Third141Proof153
  · exact adaptive143Third141Proof154
  · exact adaptive143Third141Proof155
  · exact adaptive143Third141Proof156
  · exact adaptive143Third141Proof157
  · exact adaptive143Third141Proof158
  · exact adaptive143Third141Proof159
  · exact adaptive143Third141Proof160
  · exact adaptive143Third141Proof161

#print axioms adaptive143Third141Proof131

theorem adaptive143Third141Proof162 : runCachedNode 511 130431 Adaptive143Third141Node162 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130431 Adaptive143Third141Node162 = [102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 131, 133, 134] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive143Third141Proof163
  · exact adaptive143Third141Proof164
  · exact adaptive143Third141Proof165
  · exact adaptive143Third141Proof166
  · exact adaptive143Third141Proof167
  · exact adaptive143Third141Proof168
  · exact adaptive143Third141Proof169
  · exact adaptive143Third141Proof170
  · exact adaptive143Third141Proof171
  · exact adaptive143Third141Proof172
  · exact adaptive143Third141Proof173
  · exact adaptive143Third141Proof174
  · exact adaptive143Third141Proof175
  · exact adaptive143Third141Proof176
  · exact adaptive143Third141Proof177
  · exact adaptive143Third141Proof178
  · exact adaptive143Third141Proof179
  · exact adaptive143Third141Proof180
  · exact adaptive143Third141Proof181
  · exact adaptive143Third141Proof182
  · exact adaptive143Third141Proof183
  · exact adaptive143Third141Proof184
  · exact adaptive143Third141Proof185
  · exact adaptive143Third141Proof186
  · exact adaptive143Third141Proof187
  · exact adaptive143Third141Proof188
  · exact adaptive143Third141Proof189
  · exact adaptive143Third141Proof190
  · exact adaptive143Third141Proof191
  · exact adaptive143Third141Proof192
  · exact adaptive143Third141Proof193

#print axioms adaptive143Third141Proof162

theorem adaptive143Third141Proof226 : runCachedNode 511 130431 Adaptive143Third141Node226 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130431 Adaptive143Third141Node226 = [90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 124, 126, 129, 134] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive143Third141Proof227
  · exact adaptive143Third141Proof228
  · exact adaptive143Third141Proof229
  · exact adaptive143Third141Proof230
  · exact adaptive143Third141Proof231
  · exact adaptive143Third141Proof232
  · exact adaptive143Third141Proof233
  · exact adaptive143Third141Proof234
  · exact adaptive143Third141Proof235
  · exact adaptive143Third141Proof236
  · exact adaptive143Third141Proof237
  · exact adaptive143Third141Proof238
  · exact adaptive143Third141Proof239
  · exact adaptive143Third141Proof240
  · exact adaptive143Third141Proof241
  · exact adaptive143Third141Proof242
  · exact adaptive143Third141Proof243
  · exact adaptive143Third141Proof244
  · exact adaptive143Third141Proof245
  · exact adaptive143Third141Proof246
  · exact adaptive143Third141Proof247
  · exact adaptive143Third141Proof248
  · exact adaptive143Third141Proof249
  · exact adaptive143Third141Proof250
  · exact adaptive143Third141Proof251
  · exact adaptive143Third141Proof252
  · exact adaptive143Third141Proof253
  · exact adaptive143Third141Proof254
  · exact adaptive143Third141Proof255
  · exact adaptive143Third141Proof256
  · exact adaptive143Third141Proof257
  · exact adaptive143Third141Proof258
  · exact adaptive143Third141Proof259
  · exact adaptive143Third141Proof260
  · exact adaptive143Third141Proof261
  · exact adaptive143Third141Proof262
  · exact adaptive143Third141Proof263

#print axioms adaptive143Third141Proof226

theorem adaptive143Third141Proof194 : runCachedNode 511 130431 Adaptive143Third141Node194 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130431 Adaptive143Third141Node194 = [102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 132, 134, 135, 137] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive143Third141Proof195
  · exact adaptive143Third141Proof196
  · exact adaptive143Third141Proof197
  · exact adaptive143Third141Proof198
  · exact adaptive143Third141Proof199
  · exact adaptive143Third141Proof200
  · exact adaptive143Third141Proof201
  · exact adaptive143Third141Proof202
  · exact adaptive143Third141Proof203
  · exact adaptive143Third141Proof204
  · exact adaptive143Third141Proof205
  · exact adaptive143Third141Proof206
  · exact adaptive143Third141Proof207
  · exact adaptive143Third141Proof208
  · exact adaptive143Third141Proof209
  · exact adaptive143Third141Proof210
  · exact adaptive143Third141Proof211
  · exact adaptive143Third141Proof212
  · exact adaptive143Third141Proof213
  · exact adaptive143Third141Proof214
  · exact adaptive143Third141Proof215
  · exact adaptive143Third141Proof216
  · exact adaptive143Third141Proof217
  · exact adaptive143Third141Proof218
  · exact adaptive143Third141Proof219
  · exact adaptive143Third141Proof220
  · exact adaptive143Third141Proof221
  · exact adaptive143Third141Proof222
  · exact adaptive143Third141Proof223
  · exact adaptive143Third141Proof224
  · exact adaptive143Third141Proof225
  · exact adaptive143Third141Proof226
  · exact adaptive143Third141Proof264

#print axioms adaptive143Third141Proof194

end NineSeparatedSubsetSums
