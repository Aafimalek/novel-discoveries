import NineSeparatedSubsetSums.Adaptive143Third135State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third135Proof19 : runCachedNode 511 129468 Adaptive143Third135Node19 = false := by
  decide +kernel

#print axioms adaptive143Third135Proof19

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third135Proof45 : runCachedNode 511 129468 Adaptive143Third135Node45 = false := by
  decide +kernel

#print axioms adaptive143Third135Proof45

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third135Proof72 : runCachedNode 511 129468 Adaptive143Third135Node72 = false := by
  decide +kernel

#print axioms adaptive143Third135Proof72

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third135Proof60 : runCachedNode 511 129468 Adaptive143Third135Node60 = false := by
  decide +kernel

#print axioms adaptive143Third135Proof60

end NineSeparatedSubsetSums
