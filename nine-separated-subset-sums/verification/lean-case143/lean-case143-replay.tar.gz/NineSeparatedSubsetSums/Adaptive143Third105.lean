import NineSeparatedSubsetSums.Adaptive143Third105Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint143Checked

namespace NineSeparatedSubsetSums


theorem adaptive143Third105 : NoDescendingTailAfterThird 143 105 :=
  noDescendingThirdTail_of_cached 143 105 112040 (fun t ht nd => max148_second143_fourPoint_moment_bound (105::t) (by simp [ht]) nd) adaptive143Third105Proof0

#print axioms adaptive143Third105

end NineSeparatedSubsetSums
