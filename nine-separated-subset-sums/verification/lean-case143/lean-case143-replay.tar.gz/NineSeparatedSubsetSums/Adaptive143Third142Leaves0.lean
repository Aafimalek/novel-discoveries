import NineSeparatedSubsetSums.Adaptive143Third142State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third142Proof451 : runCachedNode 511 130584 Adaptive143Third142Node451 = false := by
  decide +kernel

#print axioms adaptive143Third142Proof451

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third142Proof252 : runCachedNode 511 130584 Adaptive143Third142Node252 = false := by
  decide +kernel

#print axioms adaptive143Third142Proof252

end NineSeparatedSubsetSums
