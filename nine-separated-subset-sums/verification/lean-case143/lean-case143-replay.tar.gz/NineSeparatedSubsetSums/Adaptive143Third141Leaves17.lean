import NineSeparatedSubsetSums.Adaptive143Third141State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third141Proof128 : runCachedNode 511 130431 Adaptive143Third141Node128 = false := by
  decide +kernel

#print axioms adaptive143Third141Proof128

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third141Proof16 : runCachedNode 511 130431 Adaptive143Third141Node16 = false := by
  decide +kernel

#print axioms adaptive143Third141Proof16

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third141Proof160 : runCachedNode 511 130431 Adaptive143Third141Node160 = false := by
  decide +kernel

#print axioms adaptive143Third141Proof160

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third141Proof449 : runCachedNode 511 130431 Adaptive143Third141Node449 = false := by
  decide +kernel

#print axioms adaptive143Third141Proof449

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third141Proof163 : runCachedNode 511 130431 Adaptive143Third141Node163 = false := by
  decide +kernel

#print axioms adaptive143Third141Proof163

end NineSeparatedSubsetSums
