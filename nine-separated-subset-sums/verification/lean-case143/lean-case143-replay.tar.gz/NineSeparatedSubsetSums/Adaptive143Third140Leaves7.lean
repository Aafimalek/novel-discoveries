import NineSeparatedSubsetSums.Adaptive143Third140State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third140Proof197 : runCachedNode 511 130276 Adaptive143Third140Node197 = false := by
  decide +kernel

#print axioms adaptive143Third140Proof197

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third140Proof201 : runCachedNode 511 130276 Adaptive143Third140Node201 = false := by
  decide +kernel

#print axioms adaptive143Third140Proof201

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third140Proof30 : runCachedNode 511 130276 Adaptive143Third140Node30 = false := by
  decide +kernel

#print axioms adaptive143Third140Proof30

end NineSeparatedSubsetSums
