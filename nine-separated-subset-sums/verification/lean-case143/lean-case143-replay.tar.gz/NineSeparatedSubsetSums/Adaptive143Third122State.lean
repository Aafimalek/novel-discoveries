import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive143Third122Node0 : CachedSearchNode :=
  ⟨4, 121, computeCenteredMask [148,143,122], 413, 57237⟩

end NineSeparatedSubsetSums
