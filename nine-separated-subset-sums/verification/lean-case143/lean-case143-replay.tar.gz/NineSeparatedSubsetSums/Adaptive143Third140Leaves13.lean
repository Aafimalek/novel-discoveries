import NineSeparatedSubsetSums.Adaptive143Third140State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third140Proof164 : runCachedNode 511 130276 Adaptive143Third140Node164 = false := by
  decide +kernel

#print axioms adaptive143Third140Proof164

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third140Proof279 : runCachedNode 511 130276 Adaptive143Third140Node279 = false := by
  decide +kernel

#print axioms adaptive143Third140Proof279

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third140Proof49 : runCachedNode 511 130276 Adaptive143Third140Node49 = false := by
  decide +kernel

#print axioms adaptive143Third140Proof49

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third140Proof146 : runCachedNode 511 130276 Adaptive143Third140Node146 = false := by
  decide +kernel

#print axioms adaptive143Third140Proof146

end NineSeparatedSubsetSums
