import NineSeparatedSubsetSums.EightPoint143_119PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint143_119PackedAnchor0Part2 :
    ∀ j : Fin 8, 2418013 ≤ FourPointNumeric.octPackedCharge 143 119 20 packedOct143_119_0
      (2*((j.val : Int)+240)+0) := by decide +kernel

end NineSeparatedSubsetSums
