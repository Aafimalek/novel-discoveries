import NineSeparatedSubsetSums.Adaptive143Third116Joins0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint143Checked

namespace NineSeparatedSubsetSums


theorem adaptive143Third116 : NoDescendingTailAfterThird 143 116 :=
  noDescendingThirdTail_of_cached 143 116 112040 (fun t ht nd => max148_second143_fourPoint_moment_bound (116::t) (by simp [ht]) nd) adaptive143Third116Proof0

#print axioms adaptive143Third116

end NineSeparatedSubsetSums
