import NineSeparatedSubsetSums.Adaptive143Third114State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third114Proof0 : runCachedNode 511 112040 Adaptive143Third114Node0 = false := by
  decide +kernel

#print axioms adaptive143Third114Proof0

end NineSeparatedSubsetSums
