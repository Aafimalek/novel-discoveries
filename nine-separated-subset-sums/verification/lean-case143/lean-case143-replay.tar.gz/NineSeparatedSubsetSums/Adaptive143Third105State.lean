import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive143Third105Node0 : CachedSearchNode :=
  ⟨4, 104, computeCenteredMask [148,143,105], 396, 53378⟩

end NineSeparatedSubsetSums
