import NineSeparatedSubsetSums.Adaptive143Third138State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third138Proof232 : runCachedNode 511 129927 Adaptive143Third138Node232 = false := by
  decide +kernel

#print axioms adaptive143Third138Proof232

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third138Proof142 : runCachedNode 511 129927 Adaptive143Third138Node142 = false := by
  decide +kernel

#print axioms adaptive143Third138Proof142

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third138Proof1 : runCachedNode 511 129927 Adaptive143Third138Node1 = false := by
  decide +kernel

#print axioms adaptive143Third138Proof1

end NineSeparatedSubsetSums
