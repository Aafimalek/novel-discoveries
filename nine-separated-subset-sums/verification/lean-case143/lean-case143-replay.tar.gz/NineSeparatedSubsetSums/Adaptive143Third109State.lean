import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive143Third109Node0 : CachedSearchNode :=
  ⟨4, 108, computeCenteredMask [148,143,109], 400, 54234⟩

end NineSeparatedSubsetSums
