import NineSeparatedSubsetSums.Adaptive143Third136State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third136Proof101 : runCachedNode 511 129643 Adaptive143Third136Node101 = false := by
  decide +kernel

#print axioms adaptive143Third136Proof101

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third136Proof15 : runCachedNode 511 129643 Adaptive143Third136Node15 = false := by
  decide +kernel

#print axioms adaptive143Third136Proof15

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third136Proof104 : runCachedNode 511 129643 Adaptive143Third136Node104 = false := by
  decide +kernel

#print axioms adaptive143Third136Proof104

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third136Proof95 : runCachedNode 511 129643 Adaptive143Third136Node95 = false := by
  decide +kernel

#print axioms adaptive143Third136Proof95

end NineSeparatedSubsetSums
