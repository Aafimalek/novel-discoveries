import NineSeparatedSubsetSums.Adaptive143Third106Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint143Checked

namespace NineSeparatedSubsetSums


theorem adaptive143Third106 : NoDescendingTailAfterThird 143 106 :=
  noDescendingThirdTail_of_cached 143 106 112040 (fun t ht nd => max148_second143_fourPoint_moment_bound (106::t) (by simp [ht]) nd) adaptive143Third106Proof0

#print axioms adaptive143Third106

end NineSeparatedSubsetSums
