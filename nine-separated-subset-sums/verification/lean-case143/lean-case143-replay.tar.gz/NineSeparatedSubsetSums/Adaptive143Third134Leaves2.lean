import NineSeparatedSubsetSums.Adaptive143Third134State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third134Proof21 : runCachedNode 511 129375 Adaptive143Third134Node21 = false := by
  decide +kernel

#print axioms adaptive143Third134Proof21

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third134Proof14 : runCachedNode 511 129375 Adaptive143Third134Node14 = false := by
  decide +kernel

#print axioms adaptive143Third134Proof14

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third134Proof10 : runCachedNode 511 129375 Adaptive143Third134Node10 = false := by
  decide +kernel

#print axioms adaptive143Third134Proof10

end NineSeparatedSubsetSums
