import NineSeparatedSubsetSums.Adaptive143Third138State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third138Proof37 : runCachedNode 511 129927 Adaptive143Third138Node37 = false := by
  decide +kernel

#print axioms adaptive143Third138Proof37

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third138Proof254 : runCachedNode 511 129927 Adaptive143Third138Node254 = false := by
  decide +kernel

#print axioms adaptive143Third138Proof254

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third138Proof11 : runCachedNode 511 129927 Adaptive143Third138Node11 = false := by
  decide +kernel

#print axioms adaptive143Third138Proof11

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third138Proof112 : runCachedNode 511 129927 Adaptive143Third138Node112 = false := by
  decide +kernel

#print axioms adaptive143Third138Proof112

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third138Proof167 : runCachedNode 511 129927 Adaptive143Third138Node167 = false := by
  decide +kernel

#print axioms adaptive143Third138Proof167

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third138Proof63 : runCachedNode 511 129927 Adaptive143Third138Node63 = false := by
  decide +kernel

#print axioms adaptive143Third138Proof63

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third138Proof70 : runCachedNode 511 129927 Adaptive143Third138Node70 = false := by
  decide +kernel

#print axioms adaptive143Third138Proof70

end NineSeparatedSubsetSums
