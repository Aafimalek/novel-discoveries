import NineSeparatedSubsetSums.Adaptive143Third141State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third141Proof213 : runCachedNode 511 130431 Adaptive143Third141Node213 = false := by
  decide +kernel

#print axioms adaptive143Third141Proof213

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third141Proof40 : runCachedNode 511 130431 Adaptive143Third141Node40 = false := by
  decide +kernel

#print axioms adaptive143Third141Proof40

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third141Proof186 : runCachedNode 511 130431 Adaptive143Third141Node186 = false := by
  decide +kernel

#print axioms adaptive143Third141Proof186

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third141Proof448 : runCachedNode 511 130431 Adaptive143Third141Node448 = false := by
  decide +kernel

#print axioms adaptive143Third141Proof448

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third141Proof42 : runCachedNode 511 130431 Adaptive143Third141Node42 = false := by
  decide +kernel

#print axioms adaptive143Third141Proof42

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third141Proof96 : runCachedNode 511 130431 Adaptive143Third141Node96 = false := by
  decide +kernel

#print axioms adaptive143Third141Proof96

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third141Proof285 : runCachedNode 511 130431 Adaptive143Third141Node285 = false := by
  decide +kernel

#print axioms adaptive143Third141Proof285

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third141Proof332 : runCachedNode 511 130431 Adaptive143Third141Node332 = false := by
  decide +kernel

#print axioms adaptive143Third141Proof332

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third141Proof188 : runCachedNode 511 130431 Adaptive143Third141Node188 = false := by
  decide +kernel

#print axioms adaptive143Third141Proof188

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third141Proof405 : runCachedNode 511 130431 Adaptive143Third141Node405 = false := by
  decide +kernel

#print axioms adaptive143Third141Proof405

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third141Proof185 : runCachedNode 511 130431 Adaptive143Third141Node185 = false := by
  decide +kernel

#print axioms adaptive143Third141Proof185

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third141Proof284 : runCachedNode 511 130431 Adaptive143Third141Node284 = false := by
  decide +kernel

#print axioms adaptive143Third141Proof284

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third141Proof10 : runCachedNode 511 130431 Adaptive143Third141Node10 = false := by
  decide +kernel

#print axioms adaptive143Third141Proof10

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third141Proof403 : runCachedNode 511 130431 Adaptive143Third141Node403 = false := by
  decide +kernel

#print axioms adaptive143Third141Proof403

end NineSeparatedSubsetSums
