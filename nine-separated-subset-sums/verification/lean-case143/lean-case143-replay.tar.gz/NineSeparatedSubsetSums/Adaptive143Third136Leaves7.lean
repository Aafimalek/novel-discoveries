import NineSeparatedSubsetSums.Adaptive143Third136State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third136Proof73 : runCachedNode 511 129643 Adaptive143Third136Node73 = false := by
  decide +kernel

#print axioms adaptive143Third136Proof73

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third136Proof14 : runCachedNode 511 129643 Adaptive143Third136Node14 = false := by
  decide +kernel

#print axioms adaptive143Third136Proof14

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third136Proof45 : runCachedNode 511 129643 Adaptive143Third136Node45 = false := by
  decide +kernel

#print axioms adaptive143Third136Proof45

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third136Proof103 : runCachedNode 511 129643 Adaptive143Third136Node103 = false := by
  decide +kernel

#print axioms adaptive143Third136Proof103

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third136Proof70 : runCachedNode 511 129643 Adaptive143Third136Node70 = false := by
  decide +kernel

#print axioms adaptive143Third136Proof70

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third136Proof69 : runCachedNode 511 129643 Adaptive143Third136Node69 = false := by
  decide +kernel

#print axioms adaptive143Third136Proof69

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third136Proof35 : runCachedNode 511 129643 Adaptive143Third136Node35 = false := by
  decide +kernel

#print axioms adaptive143Third136Proof35

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third136Proof1 : runCachedNode 511 129643 Adaptive143Third136Node1 = false := by
  decide +kernel

#print axioms adaptive143Third136Proof1

end NineSeparatedSubsetSums
