import NineSeparatedSubsetSums.Adaptive143Third133State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third133Proof20 : runCachedNode 511 129127 Adaptive143Third133Node20 = false := by
  decide +kernel

#print axioms adaptive143Third133Proof20

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third133Proof18 : runCachedNode 511 129127 Adaptive143Third133Node18 = false := by
  decide +kernel

#print axioms adaptive143Third133Proof18

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third133Proof15 : runCachedNode 511 129127 Adaptive143Third133Node15 = false := by
  decide +kernel

#print axioms adaptive143Third133Proof15

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third133Proof4 : runCachedNode 511 129127 Adaptive143Third133Node4 = false := by
  decide +kernel

#print axioms adaptive143Third133Proof4

end NineSeparatedSubsetSums
