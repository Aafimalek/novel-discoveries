import NineSeparatedSubsetSums.Adaptive143Third138State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third138Proof14 : runCachedNode 511 129927 Adaptive143Third138Node14 = false := by
  decide +kernel

#print axioms adaptive143Third138Proof14

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third138Proof114 : runCachedNode 511 129927 Adaptive143Third138Node114 = false := by
  decide +kernel

#print axioms adaptive143Third138Proof114

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third138Proof39 : runCachedNode 511 129927 Adaptive143Third138Node39 = false := by
  decide +kernel

#print axioms adaptive143Third138Proof39

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third138Proof145 : runCachedNode 511 129927 Adaptive143Third138Node145 = false := by
  decide +kernel

#print axioms adaptive143Third138Proof145

end NineSeparatedSubsetSums
