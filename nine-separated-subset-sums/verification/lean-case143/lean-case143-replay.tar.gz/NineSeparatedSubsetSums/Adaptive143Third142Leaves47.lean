import NineSeparatedSubsetSums.Adaptive143Third142State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third142Proof461 : runCachedNode 511 130584 Adaptive143Third142Node461 = false := by
  decide +kernel

#print axioms adaptive143Third142Proof461

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third142Proof497 : runCachedNode 511 130584 Adaptive143Third142Node497 = false := by
  decide +kernel

#print axioms adaptive143Third142Proof497

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third142Proof498 : runCachedNode 511 130584 Adaptive143Third142Node498 = false := by
  decide +kernel

#print axioms adaptive143Third142Proof498

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third142Proof499 : runCachedNode 511 130584 Adaptive143Third142Node499 = false := by
  decide +kernel

#print axioms adaptive143Third142Proof499

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third142Proof500 : runCachedNode 511 130584 Adaptive143Third142Node500 = false := by
  decide +kernel

#print axioms adaptive143Third142Proof500

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third142Proof501 : runCachedNode 511 130584 Adaptive143Third142Node501 = false := by
  decide +kernel

#print axioms adaptive143Third142Proof501

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third142Proof502 : runCachedNode 511 130584 Adaptive143Third142Node502 = false := by
  decide +kernel

#print axioms adaptive143Third142Proof502

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third142Proof503 : runCachedNode 511 130584 Adaptive143Third142Node503 = false := by
  decide +kernel

#print axioms adaptive143Third142Proof503

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third142Proof504 : runCachedNode 511 130584 Adaptive143Third142Node504 = false := by
  decide +kernel

#print axioms adaptive143Third142Proof504

end NineSeparatedSubsetSums
