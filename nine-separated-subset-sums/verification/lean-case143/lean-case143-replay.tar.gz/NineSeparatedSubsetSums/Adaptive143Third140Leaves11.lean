import NineSeparatedSubsetSums.Adaptive143Third140State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third140Proof137 : runCachedNode 511 130276 Adaptive143Third140Node137 = false := by
  decide +kernel

#print axioms adaptive143Third140Proof137

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third140Proof311 : runCachedNode 511 130276 Adaptive143Third140Node311 = false := by
  decide +kernel

#print axioms adaptive143Third140Proof311

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third140Proof122 : runCachedNode 511 130276 Adaptive143Third140Node122 = false := by
  decide +kernel

#print axioms adaptive143Third140Proof122

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third140Proof108 : runCachedNode 511 130276 Adaptive143Third140Node108 = false := by
  decide +kernel

#print axioms adaptive143Third140Proof108

end NineSeparatedSubsetSums
