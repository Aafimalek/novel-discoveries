import NineSeparatedSubsetSums.Adaptive143Third139State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third139Proof245 : runCachedNode 511 130096 Adaptive143Third139Node245 = false := by
  decide +kernel

#print axioms adaptive143Third139Proof245

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third139Proof95 : runCachedNode 511 130096 Adaptive143Third139Node95 = false := by
  decide +kernel

#print axioms adaptive143Third139Proof95

end NineSeparatedSubsetSums
