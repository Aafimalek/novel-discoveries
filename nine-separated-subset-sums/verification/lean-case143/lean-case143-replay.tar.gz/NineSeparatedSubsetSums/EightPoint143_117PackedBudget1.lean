import NineSeparatedSubsetSums.EightPoint143_117PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct143_117_1_budget :
    FourPointNumeric.packedBudget 20 packedOct143_117_1 460 = 88262164 := by decide +kernel

#print axioms packedOct143_117_1_budget

end NineSeparatedSubsetSums
