import NineSeparatedSubsetSums.Adaptive143Third138State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third138Proof110 : runCachedNode 511 129927 Adaptive143Third138Node110 = false := by
  decide +kernel

#print axioms adaptive143Third138Proof110

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third138Proof192 : runCachedNode 511 129927 Adaptive143Third138Node192 = false := by
  decide +kernel

#print axioms adaptive143Third138Proof192

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third138Proof36 : runCachedNode 511 129927 Adaptive143Third138Node36 = false := by
  decide +kernel

#print axioms adaptive143Third138Proof36

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third138Proof256 : runCachedNode 511 129927 Adaptive143Third138Node256 = false := by
  decide +kernel

#print axioms adaptive143Third138Proof256

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third138Proof111 : runCachedNode 511 129927 Adaptive143Third138Node111 = false := by
  decide +kernel

#print axioms adaptive143Third138Proof111

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third138Proof193 : runCachedNode 511 129927 Adaptive143Third138Node193 = false := by
  decide +kernel

#print axioms adaptive143Third138Proof193

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third138Proof109 : runCachedNode 511 129927 Adaptive143Third138Node109 = false := by
  decide +kernel

#print axioms adaptive143Third138Proof109

end NineSeparatedSubsetSums
