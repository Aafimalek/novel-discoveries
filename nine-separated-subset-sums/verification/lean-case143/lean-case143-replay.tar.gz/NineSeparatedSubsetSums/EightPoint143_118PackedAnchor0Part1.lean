import NineSeparatedSubsetSums.EightPoint143_118PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint143_118PackedAnchor0Part1 :
    ∀ j : Fin 120, 2398883 ≤ FourPointNumeric.octPackedCharge 143 118 20 packedOct143_118_0
      (2*((j.val : Int)+120)+1) := by decide +kernel

end NineSeparatedSubsetSums
