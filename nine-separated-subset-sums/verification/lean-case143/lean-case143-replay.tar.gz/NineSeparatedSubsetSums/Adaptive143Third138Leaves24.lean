import NineSeparatedSubsetSums.Adaptive143Third138State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third138Proof195 : runCachedNode 511 129927 Adaptive143Third138Node195 = false := by
  decide +kernel

#print axioms adaptive143Third138Proof195

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third138Proof226 : runCachedNode 511 129927 Adaptive143Third138Node226 = false := by
  decide +kernel

#print axioms adaptive143Third138Proof226

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third138Proof257 : runCachedNode 511 129927 Adaptive143Third138Node257 = false := by
  decide +kernel

#print axioms adaptive143Third138Proof257

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third138Proof255 : runCachedNode 511 129927 Adaptive143Third138Node255 = false := by
  decide +kernel

#print axioms adaptive143Third138Proof255

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third138Proof62 : runCachedNode 511 129927 Adaptive143Third138Node62 = false := by
  decide +kernel

#print axioms adaptive143Third138Proof62

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third138Proof135 : runCachedNode 511 129927 Adaptive143Third138Node135 = false := by
  decide +kernel

#print axioms adaptive143Third138Proof135

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third138Proof166 : runCachedNode 511 129927 Adaptive143Third138Node166 = false := by
  decide +kernel

#print axioms adaptive143Third138Proof166

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third138Proof82 : runCachedNode 511 129927 Adaptive143Third138Node82 = false := by
  decide +kernel

#print axioms adaptive143Third138Proof82

end NineSeparatedSubsetSums
