import NineSeparatedSubsetSums.EightPoint143_118PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct143_118_1_budget :
    FourPointNumeric.packedBudget 20 packedOct143_118_1 458 = 89205738 := by decide +kernel

#print axioms packedOct143_118_1_budget

end NineSeparatedSubsetSums
