import NineSeparatedSubsetSums.EightPoint143_123PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint143_123PackedAnchor1Part1 :
    ∀ j : Fin 120, 2324317 ≤ FourPointNumeric.octPackedCharge 143 123 20 packedOct143_123_1
      (2*((j.val : Int)+120)+1) := by decide +kernel

end NineSeparatedSubsetSums
