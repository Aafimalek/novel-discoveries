import NineSeparatedSubsetSums.Adaptive143Third138State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third138Proof260 : runCachedNode 511 129927 Adaptive143Third138Node260 = false := by
  decide +kernel

#print axioms adaptive143Third138Proof260

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third138Proof224 : runCachedNode 511 129927 Adaptive143Third138Node224 = false := by
  decide +kernel

#print axioms adaptive143Third138Proof224

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third138Proof38 : runCachedNode 511 129927 Adaptive143Third138Node38 = false := by
  decide +kernel

#print axioms adaptive143Third138Proof38

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third138Proof12 : runCachedNode 511 129927 Adaptive143Third138Node12 = false := by
  decide +kernel

#print axioms adaptive143Third138Proof12

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third138Proof9 : runCachedNode 511 129927 Adaptive143Third138Node9 = false := by
  decide +kernel

#print axioms adaptive143Third138Proof9

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third138Proof43 : runCachedNode 511 129927 Adaptive143Third138Node43 = false := by
  decide +kernel

#print axioms adaptive143Third138Proof43

end NineSeparatedSubsetSums
