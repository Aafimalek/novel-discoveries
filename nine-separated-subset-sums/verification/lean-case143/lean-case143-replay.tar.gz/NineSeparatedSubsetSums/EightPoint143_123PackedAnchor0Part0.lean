import NineSeparatedSubsetSums.EightPoint143_123PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint143_123PackedAnchor0Part0 :
    ∀ j : Fin 120, 2322454 ≤ FourPointNumeric.octPackedCharge 143 123 20 packedOct143_123_0
      (2*((j.val : Int)+0)+0) := by decide +kernel

end NineSeparatedSubsetSums
