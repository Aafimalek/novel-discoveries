import NineSeparatedSubsetSums.Adaptive143Third138State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third138Proof139 : runCachedNode 511 129927 Adaptive143Third138Node139 = false := by
  decide +kernel

#print axioms adaptive143Third138Proof139

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third138Proof170 : runCachedNode 511 129927 Adaptive143Third138Node170 = false := by
  decide +kernel

#print axioms adaptive143Third138Proof170

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third138Proof60 : runCachedNode 511 129927 Adaptive143Third138Node60 = false := by
  decide +kernel

#print axioms adaptive143Third138Proof60

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third138Proof94 : runCachedNode 511 129927 Adaptive143Third138Node94 = false := by
  decide +kernel

#print axioms adaptive143Third138Proof94

end NineSeparatedSubsetSums
