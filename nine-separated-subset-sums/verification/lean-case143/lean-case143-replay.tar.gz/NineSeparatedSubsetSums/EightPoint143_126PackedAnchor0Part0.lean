import NineSeparatedSubsetSums.EightPoint143_126PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint143_126PackedAnchor0Part0 :
    ∀ j : Fin 120, 2370258 ≤ FourPointNumeric.octPackedCharge 143 126 20 packedOct143_126_0
      (2*((j.val : Int)+0)+1) := by decide +kernel

end NineSeparatedSubsetSums
