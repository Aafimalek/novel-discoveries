import NineSeparatedSubsetSums.Adaptive143Third136State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third136Proof19 : runCachedNode 511 129643 Adaptive143Third136Node19 = false := by
  decide +kernel

#print axioms adaptive143Third136Proof19

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third136Proof17 : runCachedNode 511 129643 Adaptive143Third136Node17 = false := by
  decide +kernel

#print axioms adaptive143Third136Proof17

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third136Proof37 : runCachedNode 511 129643 Adaptive143Third136Node37 = false := by
  decide +kernel

#print axioms adaptive143Third136Proof37

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third136Proof49 : runCachedNode 511 129643 Adaptive143Third136Node49 = false := by
  decide +kernel

#print axioms adaptive143Third136Proof49

end NineSeparatedSubsetSums
