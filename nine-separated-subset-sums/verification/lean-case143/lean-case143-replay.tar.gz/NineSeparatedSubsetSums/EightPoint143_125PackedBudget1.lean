import NineSeparatedSubsetSums.EightPoint143_125PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct143_125_1_budget :
    FourPointNumeric.packedBudget 20 packedOct143_125_1 494 = 86238156 := by decide +kernel

#print axioms packedOct143_125_1_budget

end NineSeparatedSubsetSums
