import NineSeparatedSubsetSums.Adaptive143Third136State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third136Proof20 : runCachedNode 511 129643 Adaptive143Third136Node20 = false := by
  decide +kernel

#print axioms adaptive143Third136Proof20

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third136Proof96 : runCachedNode 511 129643 Adaptive143Third136Node96 = false := by
  decide +kernel

#print axioms adaptive143Third136Proof96

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third136Proof56 : runCachedNode 511 129643 Adaptive143Third136Node56 = false := by
  decide +kernel

#print axioms adaptive143Third136Proof56

end NineSeparatedSubsetSums
