import NineSeparatedSubsetSums.Adaptive143Third139State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third139Proof151 : runCachedNode 511 130096 Adaptive143Third139Node151 = false := by
  decide +kernel

#print axioms adaptive143Third139Proof151

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third139Proof240 : runCachedNode 511 130096 Adaptive143Third139Node240 = false := by
  decide +kernel

#print axioms adaptive143Third139Proof240

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third139Proof243 : runCachedNode 511 130096 Adaptive143Third139Node243 = false := by
  decide +kernel

#print axioms adaptive143Third139Proof243

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third139Proof241 : runCachedNode 511 130096 Adaptive143Third139Node241 = false := by
  decide +kernel

#print axioms adaptive143Third139Proof241

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third139Proof53 : runCachedNode 511 130096 Adaptive143Third139Node53 = false := by
  decide +kernel

#print axioms adaptive143Third139Proof53

end NineSeparatedSubsetSums
