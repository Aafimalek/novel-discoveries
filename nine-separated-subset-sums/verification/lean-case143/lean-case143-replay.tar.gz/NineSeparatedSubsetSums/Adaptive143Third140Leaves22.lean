import NineSeparatedSubsetSums.Adaptive143Third140State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third140Proof193 : runCachedNode 511 130276 Adaptive143Third140Node193 = false := by
  decide +kernel

#print axioms adaptive143Third140Proof193

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third140Proof350 : runCachedNode 511 130276 Adaptive143Third140Node350 = false := by
  decide +kernel

#print axioms adaptive143Third140Proof350

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third140Proof162 : runCachedNode 511 130276 Adaptive143Third140Node162 = false := by
  decide +kernel

#print axioms adaptive143Third140Proof162

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third140Proof132 : runCachedNode 511 130276 Adaptive143Third140Node132 = false := by
  decide +kernel

#print axioms adaptive143Third140Proof132

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third140Proof101 : runCachedNode 511 130276 Adaptive143Third140Node101 = false := by
  decide +kernel

#print axioms adaptive143Third140Proof101

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third140Proof44 : runCachedNode 511 130276 Adaptive143Third140Node44 = false := by
  decide +kernel

#print axioms adaptive143Third140Proof44

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third140Proof305 : runCachedNode 511 130276 Adaptive143Third140Node305 = false := by
  decide +kernel

#print axioms adaptive143Third140Proof305

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third140Proof158 : runCachedNode 511 130276 Adaptive143Third140Node158 = false := by
  decide +kernel

#print axioms adaptive143Third140Proof158

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third140Proof385 : runCachedNode 511 130276 Adaptive143Third140Node385 = false := by
  decide +kernel

#print axioms adaptive143Third140Proof385

end NineSeparatedSubsetSums
