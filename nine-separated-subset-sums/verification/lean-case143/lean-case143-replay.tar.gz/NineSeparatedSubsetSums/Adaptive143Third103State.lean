import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive143Third103Node0 : CachedSearchNode :=
  ⟨4, 102, computeCenteredMask [148,143,103], 394, 52962⟩

end NineSeparatedSubsetSums
