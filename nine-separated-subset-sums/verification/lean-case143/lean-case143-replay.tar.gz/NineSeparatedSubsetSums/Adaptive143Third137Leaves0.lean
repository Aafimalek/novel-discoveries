import NineSeparatedSubsetSums.Adaptive143Third137State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third137Proof21 : runCachedNode 511 129784 Adaptive143Third137Node21 = false := by
  decide +kernel

#print axioms adaptive143Third137Proof21

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third137Proof129 : runCachedNode 511 129784 Adaptive143Third137Node129 = false := by
  decide +kernel

#print axioms adaptive143Third137Proof129

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third137Proof27 : runCachedNode 511 129784 Adaptive143Third137Node27 = false := by
  decide +kernel

#print axioms adaptive143Third137Proof27

end NineSeparatedSubsetSums
