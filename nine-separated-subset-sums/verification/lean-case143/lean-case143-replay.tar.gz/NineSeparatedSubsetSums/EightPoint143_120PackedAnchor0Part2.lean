import NineSeparatedSubsetSums.EightPoint143_120PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint143_120PackedAnchor0Part2 :
    ∀ j : Fin 4, 2365745 ≤ FourPointNumeric.octPackedCharge 143 120 20 packedOct143_120_0
      (2*((j.val : Int)+240)+1) := by decide +kernel

end NineSeparatedSubsetSums
