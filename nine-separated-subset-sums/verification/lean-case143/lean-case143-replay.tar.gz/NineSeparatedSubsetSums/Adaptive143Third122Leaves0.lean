import NineSeparatedSubsetSums.Adaptive143Third122State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third122Proof0 : runCachedNode 511 126480 Adaptive143Third122Node0 = false := by
  decide +kernel

#print axioms adaptive143Third122Proof0

end NineSeparatedSubsetSums
