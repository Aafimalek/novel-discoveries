import NineSeparatedSubsetSums.EightPoint143_117PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct143_117_0_budget :
    FourPointNumeric.packedBudget 20 packedOct143_117_0 433 = 88186293 := by decide +kernel

#print axioms packedOct143_117_0_budget

end NineSeparatedSubsetSums
