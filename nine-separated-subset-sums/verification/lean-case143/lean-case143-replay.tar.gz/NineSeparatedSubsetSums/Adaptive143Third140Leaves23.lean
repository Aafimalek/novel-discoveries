import NineSeparatedSubsetSums.Adaptive143Third140State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third140Proof45 : runCachedNode 511 130276 Adaptive143Third140Node45 = false := by
  decide +kernel

#print axioms adaptive143Third140Proof45

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third140Proof390 : runCachedNode 511 130276 Adaptive143Third140Node390 = false := by
  decide +kernel

#print axioms adaptive143Third140Proof390

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third140Proof276 : runCachedNode 511 130276 Adaptive143Third140Node276 = false := by
  decide +kernel

#print axioms adaptive143Third140Proof276

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third140Proof159 : runCachedNode 511 130276 Adaptive143Third140Node159 = false := by
  decide +kernel

#print axioms adaptive143Third140Proof159

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third140Proof73 : runCachedNode 511 130276 Adaptive143Third140Node73 = false := by
  decide +kernel

#print axioms adaptive143Third140Proof73

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third140Proof237 : runCachedNode 511 130276 Adaptive143Third140Node237 = false := by
  decide +kernel

#print axioms adaptive143Third140Proof237

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third140Proof99 : runCachedNode 511 130276 Adaptive143Third140Node99 = false := by
  decide +kernel

#print axioms adaptive143Third140Proof99

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third140Proof189 : runCachedNode 511 130276 Adaptive143Third140Node189 = false := by
  decide +kernel

#print axioms adaptive143Third140Proof189

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third140Proof11 : runCachedNode 511 130276 Adaptive143Third140Node11 = false := by
  decide +kernel

#print axioms adaptive143Third140Proof11

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third140Proof190 : runCachedNode 511 130276 Adaptive143Third140Node190 = false := by
  decide +kernel

#print axioms adaptive143Third140Proof190

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third140Proof369 : runCachedNode 511 130276 Adaptive143Third140Node369 = false := by
  decide +kernel

#print axioms adaptive143Third140Proof369

end NineSeparatedSubsetSums
