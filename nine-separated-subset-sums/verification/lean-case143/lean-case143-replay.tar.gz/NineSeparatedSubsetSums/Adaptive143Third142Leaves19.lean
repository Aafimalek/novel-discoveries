import NineSeparatedSubsetSums.Adaptive143Third142State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third142Proof495 : runCachedNode 511 130584 Adaptive143Third142Node495 = false := by
  decide +kernel

#print axioms adaptive143Third142Proof495

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third142Proof538 : runCachedNode 511 130584 Adaptive143Third142Node538 = false := by
  decide +kernel

#print axioms adaptive143Third142Proof538

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third142Proof188 : runCachedNode 511 130584 Adaptive143Third142Node188 = false := by
  decide +kernel

#print axioms adaptive143Third142Proof188

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third142Proof438 : runCachedNode 511 130584 Adaptive143Third142Node438 = false := by
  decide +kernel

#print axioms adaptive143Third142Proof438

end NineSeparatedSubsetSums
