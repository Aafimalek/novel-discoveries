import NineSeparatedSubsetSums.EightPoint143_120PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint143_120PackedAnchor1Part1 :
    ∀ j : Fin 120, 2365421 ≤ FourPointNumeric.octPackedCharge 143 120 20 packedOct143_120_1
      (2*((j.val : Int)+120)+0) := by decide +kernel

end NineSeparatedSubsetSums
