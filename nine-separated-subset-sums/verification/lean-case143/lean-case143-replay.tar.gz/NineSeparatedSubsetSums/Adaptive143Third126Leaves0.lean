import NineSeparatedSubsetSums.Adaptive143Third126State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third126Proof0 : runCachedNode 511 127621 Adaptive143Third126Node0 = false := by
  decide +kernel

#print axioms adaptive143Third126Proof0

end NineSeparatedSubsetSums
