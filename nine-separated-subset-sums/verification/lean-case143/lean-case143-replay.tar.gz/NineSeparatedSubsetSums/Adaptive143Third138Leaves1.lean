import NineSeparatedSubsetSums.Adaptive143Third138State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third138Proof262 : runCachedNode 511 129927 Adaptive143Third138Node262 = false := by
  decide +kernel

#print axioms adaptive143Third138Proof262

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third138Proof134 : runCachedNode 511 129927 Adaptive143Third138Node134 = false := by
  decide +kernel

#print axioms adaptive143Third138Proof134

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third138Proof234 : runCachedNode 511 129927 Adaptive143Third138Node234 = false := by
  decide +kernel

#print axioms adaptive143Third138Proof234

end NineSeparatedSubsetSums
