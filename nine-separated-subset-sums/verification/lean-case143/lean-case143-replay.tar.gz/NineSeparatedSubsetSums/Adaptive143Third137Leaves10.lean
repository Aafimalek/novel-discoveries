import NineSeparatedSubsetSums.Adaptive143Third137State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third137Proof96 : runCachedNode 511 129784 Adaptive143Third137Node96 = false := by
  decide +kernel

#print axioms adaptive143Third137Proof96

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third137Proof41 : runCachedNode 511 129784 Adaptive143Third137Node41 = false := by
  decide +kernel

#print axioms adaptive143Third137Proof41

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third137Proof11 : runCachedNode 511 129784 Adaptive143Third137Node11 = false := by
  decide +kernel

#print axioms adaptive143Third137Proof11

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third137Proof122 : runCachedNode 511 129784 Adaptive143Third137Node122 = false := by
  decide +kernel

#print axioms adaptive143Third137Proof122

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third137Proof98 : runCachedNode 511 129784 Adaptive143Third137Node98 = false := by
  decide +kernel

#print axioms adaptive143Third137Proof98

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third137Proof152 : runCachedNode 511 129784 Adaptive143Third137Node152 = false := by
  decide +kernel

#print axioms adaptive143Third137Proof152

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third137Proof150 : runCachedNode 511 129784 Adaptive143Third137Node150 = false := by
  decide +kernel

#print axioms adaptive143Third137Proof150

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third137Proof38 : runCachedNode 511 129784 Adaptive143Third137Node38 = false := by
  decide +kernel

#print axioms adaptive143Third137Proof38

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third137Proof10 : runCachedNode 511 129784 Adaptive143Third137Node10 = false := by
  decide +kernel

#print axioms adaptive143Third137Proof10

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third137Proof123 : runCachedNode 511 129784 Adaptive143Third137Node123 = false := by
  decide +kernel

#print axioms adaptive143Third137Proof123

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third137Proof40 : runCachedNode 511 129784 Adaptive143Third137Node40 = false := by
  decide +kernel

#print axioms adaptive143Third137Proof40

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third137Proof149 : runCachedNode 511 129784 Adaptive143Third137Node149 = false := by
  decide +kernel

#print axioms adaptive143Third137Proof149

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third137Proof148 : runCachedNode 511 129784 Adaptive143Third137Node148 = false := by
  decide +kernel

#print axioms adaptive143Third137Proof148

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third137Proof151 : runCachedNode 511 129784 Adaptive143Third137Node151 = false := by
  decide +kernel

#print axioms adaptive143Third137Proof151

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third137Proof119 : runCachedNode 511 129784 Adaptive143Third137Node119 = false := by
  decide +kernel

#print axioms adaptive143Third137Proof119

end NineSeparatedSubsetSums
