import NineSeparatedSubsetSums.Adaptive143Third139State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third139Proof153 : runCachedNode 511 130096 Adaptive143Third139Node153 = false := by
  decide +kernel

#print axioms adaptive143Third139Proof153

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third139Proof69 : runCachedNode 511 130096 Adaptive143Third139Node69 = false := by
  decide +kernel

#print axioms adaptive143Third139Proof69

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third139Proof43 : runCachedNode 511 130096 Adaptive143Third139Node43 = false := by
  decide +kernel

#print axioms adaptive143Third139Proof43

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third139Proof2 : runCachedNode 511 130096 Adaptive143Third139Node2 = false := by
  decide +kernel

#print axioms adaptive143Third139Proof2

end NineSeparatedSubsetSums
