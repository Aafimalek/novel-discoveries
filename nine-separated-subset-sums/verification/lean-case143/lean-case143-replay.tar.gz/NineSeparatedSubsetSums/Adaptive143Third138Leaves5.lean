import NineSeparatedSubsetSums.Adaptive143Third138State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third138Proof228 : runCachedNode 511 129927 Adaptive143Third138Node228 = false := by
  decide +kernel

#print axioms adaptive143Third138Proof228

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third138Proof229 : runCachedNode 511 129927 Adaptive143Third138Node229 = false := by
  decide +kernel

#print axioms adaptive143Third138Proof229

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third138Proof5 : runCachedNode 511 129927 Adaptive143Third138Node5 = false := by
  decide +kernel

#print axioms adaptive143Third138Proof5

end NineSeparatedSubsetSums
