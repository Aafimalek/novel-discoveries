import NineSeparatedSubsetSums.Adaptive143Third139State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third139Proof179 : runCachedNode 511 130096 Adaptive143Third139Node179 = false := by
  decide +kernel

#print axioms adaptive143Third139Proof179

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third139Proof208 : runCachedNode 511 130096 Adaptive143Third139Node208 = false := by
  decide +kernel

#print axioms adaptive143Third139Proof208

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third139Proof66 : runCachedNode 511 130096 Adaptive143Third139Node66 = false := by
  decide +kernel

#print axioms adaptive143Third139Proof66

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third139Proof93 : runCachedNode 511 130096 Adaptive143Third139Node93 = false := by
  decide +kernel

#print axioms adaptive143Third139Proof93

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third139Proof143 : runCachedNode 511 130096 Adaptive143Third139Node143 = false := by
  decide +kernel

#print axioms adaptive143Third139Proof143

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third139Proof64 : runCachedNode 511 130096 Adaptive143Third139Node64 = false := by
  decide +kernel

#print axioms adaptive143Third139Proof64

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third139Proof67 : runCachedNode 511 130096 Adaptive143Third139Node67 = false := by
  decide +kernel

#print axioms adaptive143Third139Proof67

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third139Proof206 : runCachedNode 511 130096 Adaptive143Third139Node206 = false := by
  decide +kernel

#print axioms adaptive143Third139Proof206

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third139Proof120 : runCachedNode 511 130096 Adaptive143Third139Node120 = false := by
  decide +kernel

#print axioms adaptive143Third139Proof120

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third139Proof281 : runCachedNode 511 130096 Adaptive143Third139Node281 = false := by
  decide +kernel

#print axioms adaptive143Third139Proof281

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third139Proof233 : runCachedNode 511 130096 Adaptive143Third139Node233 = false := by
  decide +kernel

#print axioms adaptive143Third139Proof233

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third139Proof175 : runCachedNode 511 130096 Adaptive143Third139Node175 = false := by
  decide +kernel

#print axioms adaptive143Third139Proof175

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third139Proof35 : runCachedNode 511 130096 Adaptive143Third139Node35 = false := by
  decide +kernel

#print axioms adaptive143Third139Proof35

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third139Proof37 : runCachedNode 511 130096 Adaptive143Third139Node37 = false := by
  decide +kernel

#print axioms adaptive143Third139Proof37

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third139Proof234 : runCachedNode 511 130096 Adaptive143Third139Node234 = false := by
  decide +kernel

#print axioms adaptive143Third139Proof234

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third139Proof89 : runCachedNode 511 130096 Adaptive143Third139Node89 = false := by
  decide +kernel

#print axioms adaptive143Third139Proof89

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third139Proof229 : runCachedNode 511 130096 Adaptive143Third139Node229 = false := by
  decide +kernel

#print axioms adaptive143Third139Proof229

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third139Proof253 : runCachedNode 511 130096 Adaptive143Third139Node253 = false := by
  decide +kernel

#print axioms adaptive143Third139Proof253

end NineSeparatedSubsetSums
