import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive143Third107Node0 : CachedSearchNode :=
  ⟨4, 106, computeCenteredMask [148,143,107], 398, 53802⟩

end NineSeparatedSubsetSums
