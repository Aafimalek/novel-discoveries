import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive143Third106Node0 : CachedSearchNode :=
  ⟨4, 105, computeCenteredMask [148,143,106], 397, 53589⟩

end NineSeparatedSubsetSums
