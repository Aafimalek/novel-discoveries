import NineSeparatedSubsetSums.Adaptive143Third142State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third142Proof338 : runCachedNode 511 130584 Adaptive143Third142Node338 = false := by
  decide +kernel

#print axioms adaptive143Third142Proof338

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third142Proof304 : runCachedNode 511 130584 Adaptive143Third142Node304 = false := by
  decide +kernel

#print axioms adaptive143Third142Proof304

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third142Proof7 : runCachedNode 511 130584 Adaptive143Third142Node7 = false := by
  decide +kernel

#print axioms adaptive143Third142Proof7

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third142Proof24 : runCachedNode 511 130584 Adaptive143Third142Node24 = false := by
  decide +kernel

#print axioms adaptive143Third142Proof24

end NineSeparatedSubsetSums
