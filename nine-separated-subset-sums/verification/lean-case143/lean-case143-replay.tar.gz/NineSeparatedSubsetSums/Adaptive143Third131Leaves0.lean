import NineSeparatedSubsetSums.Adaptive143Third131State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third131Proof20 : runCachedNode 511 128821 Adaptive143Third131Node20 = false := by
  decide +kernel

#print axioms adaptive143Third131Proof20

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third131Proof19 : runCachedNode 511 128821 Adaptive143Third131Node19 = false := by
  decide +kernel

#print axioms adaptive143Third131Proof19

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third131Proof5 : runCachedNode 511 128821 Adaptive143Third131Node5 = false := by
  decide +kernel

#print axioms adaptive143Third131Proof5

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third131Proof1 : runCachedNode 511 128821 Adaptive143Third131Node1 = false := by
  decide +kernel

#print axioms adaptive143Third131Proof1

end NineSeparatedSubsetSums
