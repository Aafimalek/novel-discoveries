import NineSeparatedSubsetSums.Adaptive143Third141State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third141Proof192 : runCachedNode 511 130431 Adaptive143Third141Node192 = false := by
  decide +kernel

#print axioms adaptive143Third141Proof192

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third141Proof292 : runCachedNode 511 130431 Adaptive143Third141Node292 = false := by
  decide +kernel

#print axioms adaptive143Third141Proof292

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third141Proof219 : runCachedNode 511 130431 Adaptive143Third141Node219 = false := by
  decide +kernel

#print axioms adaptive143Third141Proof219

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third141Proof87 : runCachedNode 511 130431 Adaptive143Third141Node87 = false := by
  decide +kernel

#print axioms adaptive143Third141Proof87

end NineSeparatedSubsetSums
