import NineSeparatedSubsetSums.Adaptive143Third135State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third135Proof73 : runCachedNode 511 129468 Adaptive143Third135Node73 = false := by
  decide +kernel

#print axioms adaptive143Third135Proof73

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third135Proof15 : runCachedNode 511 129468 Adaptive143Third135Node15 = false := by
  decide +kernel

#print axioms adaptive143Third135Proof15

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third135Proof14 : runCachedNode 511 129468 Adaptive143Third135Node14 = false := by
  decide +kernel

#print axioms adaptive143Third135Proof14

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third135Proof75 : runCachedNode 511 129468 Adaptive143Third135Node75 = false := by
  decide +kernel

#print axioms adaptive143Third135Proof75

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third135Proof71 : runCachedNode 511 129468 Adaptive143Third135Node71 = false := by
  decide +kernel

#print axioms adaptive143Third135Proof71

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third135Proof43 : runCachedNode 511 129468 Adaptive143Third135Node43 = false := by
  decide +kernel

#print axioms adaptive143Third135Proof43

end NineSeparatedSubsetSums
