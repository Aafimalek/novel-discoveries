import NineSeparatedSubsetSums.Adaptive143Third142State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third142Proof263 : runCachedNode 511 130584 Adaptive143Third142Node263 = false := by
  decide +kernel

#print axioms adaptive143Third142Proof263

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third142Proof161 : runCachedNode 511 130584 Adaptive143Third142Node161 = false := by
  decide +kernel

#print axioms adaptive143Third142Proof161

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third142Proof189 : runCachedNode 511 130584 Adaptive143Third142Node189 = false := by
  decide +kernel

#print axioms adaptive143Third142Proof189

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third142Proof72 : runCachedNode 511 130584 Adaptive143Third142Node72 = false := by
  decide +kernel

#print axioms adaptive143Third142Proof72

end NineSeparatedSubsetSums
