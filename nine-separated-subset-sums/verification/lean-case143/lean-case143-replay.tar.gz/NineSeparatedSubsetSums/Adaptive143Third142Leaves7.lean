import NineSeparatedSubsetSums.Adaptive143Third142State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third142Proof193 : runCachedNode 511 130584 Adaptive143Third142Node193 = false := by
  decide +kernel

#print axioms adaptive143Third142Proof193

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third142Proof191 : runCachedNode 511 130584 Adaptive143Third142Node191 = false := by
  decide +kernel

#print axioms adaptive143Third142Proof191

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third142Proof144 : runCachedNode 511 130584 Adaptive143Third142Node144 = false := by
  decide +kernel

#print axioms adaptive143Third142Proof144

end NineSeparatedSubsetSums
