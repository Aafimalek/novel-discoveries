import NineSeparatedSubsetSums.Adaptive143Third140State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third140Proof21 : runCachedNode 511 130276 Adaptive143Third140Node21 = false := by
  decide +kernel

#print axioms adaptive143Third140Proof21

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third140Proof100 : runCachedNode 511 130276 Adaptive143Third140Node100 = false := by
  decide +kernel

#print axioms adaptive143Third140Proof100

end NineSeparatedSubsetSums
