import NineSeparatedSubsetSums.Adaptive143Third130State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third130Proof10 : runCachedNode 511 128577 Adaptive143Third130Node10 = false := by
  decide +kernel

#print axioms adaptive143Third130Proof10

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third130Proof9 : runCachedNode 511 128577 Adaptive143Third130Node9 = false := by
  decide +kernel

#print axioms adaptive143Third130Proof9

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third130Proof8 : runCachedNode 511 128577 Adaptive143Third130Node8 = false := by
  decide +kernel

#print axioms adaptive143Third130Proof8

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third130Proof7 : runCachedNode 511 128577 Adaptive143Third130Node7 = false := by
  decide +kernel

#print axioms adaptive143Third130Proof7

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third130Proof6 : runCachedNode 511 128577 Adaptive143Third130Node6 = false := by
  decide +kernel

#print axioms adaptive143Third130Proof6

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third130Proof5 : runCachedNode 511 128577 Adaptive143Third130Node5 = false := by
  decide +kernel

#print axioms adaptive143Third130Proof5

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third130Proof3 : runCachedNode 511 128577 Adaptive143Third130Node3 = false := by
  decide +kernel

#print axioms adaptive143Third130Proof3

end NineSeparatedSubsetSums
