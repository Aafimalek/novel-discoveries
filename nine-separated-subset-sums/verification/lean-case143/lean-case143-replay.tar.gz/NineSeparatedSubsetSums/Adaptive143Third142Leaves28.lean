import NineSeparatedSubsetSums.Adaptive143Third142State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third142Proof48 : runCachedNode 511 130584 Adaptive143Third142Node48 = false := by
  decide +kernel

#print axioms adaptive143Third142Proof48

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third142Proof492 : runCachedNode 511 130584 Adaptive143Third142Node492 = false := by
  decide +kernel

#print axioms adaptive143Third142Proof492

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third142Proof535 : runCachedNode 511 130584 Adaptive143Third142Node535 = false := by
  decide +kernel

#print axioms adaptive143Third142Proof535

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third142Proof261 : runCachedNode 511 130584 Adaptive143Third142Node261 = false := by
  decide +kernel

#print axioms adaptive143Third142Proof261

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third142Proof414 : runCachedNode 511 130584 Adaptive143Third142Node414 = false := by
  decide +kernel

#print axioms adaptive143Third142Proof414

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third142Proof46 : runCachedNode 511 130584 Adaptive143Third142Node46 = false := by
  decide +kernel

#print axioms adaptive143Third142Proof46

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third142Proof40 : runCachedNode 511 130584 Adaptive143Third142Node40 = false := by
  decide +kernel

#print axioms adaptive143Third142Proof40

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third142Proof51 : runCachedNode 511 130584 Adaptive143Third142Node51 = false := by
  decide +kernel

#print axioms adaptive143Third142Proof51

end NineSeparatedSubsetSums
