import NineSeparatedSubsetSums.Adaptive143Third138State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third138Proof89 : runCachedNode 511 129927 Adaptive143Third138Node89 = false := by
  decide +kernel

#print axioms adaptive143Third138Proof89

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third138Proof115 : runCachedNode 511 129927 Adaptive143Third138Node115 = false := by
  decide +kernel

#print axioms adaptive143Third138Proof115

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third138Proof261 : runCachedNode 511 129927 Adaptive143Third138Node261 = false := by
  decide +kernel

#print axioms adaptive143Third138Proof261

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third138Proof10 : runCachedNode 511 129927 Adaptive143Third138Node10 = false := by
  decide +kernel

#print axioms adaptive143Third138Proof10

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third138Proof118 : runCachedNode 511 129927 Adaptive143Third138Node118 = false := by
  decide +kernel

#print axioms adaptive143Third138Proof118

end NineSeparatedSubsetSums
