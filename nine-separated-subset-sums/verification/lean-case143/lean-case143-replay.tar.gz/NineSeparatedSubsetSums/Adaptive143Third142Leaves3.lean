import NineSeparatedSubsetSums.Adaptive143Third142State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third142Proof195 : runCachedNode 511 130584 Adaptive143Third142Node195 = false := by
  decide +kernel

#print axioms adaptive143Third142Proof195

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third142Proof337 : runCachedNode 511 130584 Adaptive143Third142Node337 = false := by
  decide +kernel

#print axioms adaptive143Third142Proof337

end NineSeparatedSubsetSums
