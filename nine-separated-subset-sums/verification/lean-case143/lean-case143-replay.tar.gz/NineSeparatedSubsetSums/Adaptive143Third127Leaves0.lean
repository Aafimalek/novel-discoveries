import NineSeparatedSubsetSums.Adaptive143Third127State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third127Proof15 : runCachedNode 511 127918 Adaptive143Third127Node15 = false := by
  decide +kernel

#print axioms adaptive143Third127Proof15

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third127Proof14 : runCachedNode 511 127918 Adaptive143Third127Node14 = false := by
  decide +kernel

#print axioms adaptive143Third127Proof14

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third127Proof13 : runCachedNode 511 127918 Adaptive143Third127Node13 = false := by
  decide +kernel

#print axioms adaptive143Third127Proof13

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third127Proof12 : runCachedNode 511 127918 Adaptive143Third127Node12 = false := by
  decide +kernel

#print axioms adaptive143Third127Proof12

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third127Proof11 : runCachedNode 511 127918 Adaptive143Third127Node11 = false := by
  decide +kernel

#print axioms adaptive143Third127Proof11

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third127Proof10 : runCachedNode 511 127918 Adaptive143Third127Node10 = false := by
  decide +kernel

#print axioms adaptive143Third127Proof10

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third127Proof9 : runCachedNode 511 127918 Adaptive143Third127Node9 = false := by
  decide +kernel

#print axioms adaptive143Third127Proof9

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third127Proof7 : runCachedNode 511 127918 Adaptive143Third127Node7 = false := by
  decide +kernel

#print axioms adaptive143Third127Proof7

end NineSeparatedSubsetSums
