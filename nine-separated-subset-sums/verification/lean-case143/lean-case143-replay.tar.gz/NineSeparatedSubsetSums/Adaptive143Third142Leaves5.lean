import NineSeparatedSubsetSums.Adaptive143Third142State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third142Proof192 : runCachedNode 511 130584 Adaptive143Third142Node192 = false := by
  decide +kernel

#print axioms adaptive143Third142Proof192

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third142Proof18 : runCachedNode 511 130584 Adaptive143Third142Node18 = false := by
  decide +kernel

#print axioms adaptive143Third142Proof18

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third142Proof55 : runCachedNode 511 130584 Adaptive143Third142Node55 = false := by
  decide +kernel

#print axioms adaptive143Third142Proof55

end NineSeparatedSubsetSums
