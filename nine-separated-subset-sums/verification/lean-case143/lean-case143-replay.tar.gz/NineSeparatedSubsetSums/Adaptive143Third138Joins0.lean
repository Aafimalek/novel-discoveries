import NineSeparatedSubsetSums.Adaptive143Third138State
import NineSeparatedSubsetSums.Adaptive143Third138Leaves8
import NineSeparatedSubsetSums.Adaptive143Third138Leaves31
import NineSeparatedSubsetSums.Adaptive143Third138Leaves30
import NineSeparatedSubsetSums.Adaptive143Third138Leaves29
import NineSeparatedSubsetSums.Adaptive143Third138Leaves28
import NineSeparatedSubsetSums.Adaptive143Third138Leaves27
import NineSeparatedSubsetSums.Adaptive143Third138Leaves15
import NineSeparatedSubsetSums.Adaptive143Third138Leaves26
import NineSeparatedSubsetSums.Adaptive143Third138Leaves25
import NineSeparatedSubsetSums.Adaptive143Third138Leaves23
import NineSeparatedSubsetSums.Adaptive143Third138Leaves22
import NineSeparatedSubsetSums.Adaptive143Third138Leaves21
import NineSeparatedSubsetSums.Adaptive143Third138Leaves17
import NineSeparatedSubsetSums.Adaptive143Third138Leaves18
import NineSeparatedSubsetSums.Adaptive143Third138Leaves7
import NineSeparatedSubsetSums.Adaptive143Third138Leaves16
import NineSeparatedSubsetSums.Adaptive143Third138Leaves24
import NineSeparatedSubsetSums.Adaptive143Third138Leaves6
import NineSeparatedSubsetSums.Adaptive143Third138Leaves3
import NineSeparatedSubsetSums.Adaptive143Third138Leaves20
import NineSeparatedSubsetSums.Adaptive143Third138Leaves11
import NineSeparatedSubsetSums.Adaptive143Third138Leaves19
import NineSeparatedSubsetSums.Adaptive143Third138Leaves4
import NineSeparatedSubsetSums.Adaptive143Third138Leaves14
import NineSeparatedSubsetSums.Adaptive143Third138Leaves12
import NineSeparatedSubsetSums.Adaptive143Third138Leaves9
import NineSeparatedSubsetSums.Adaptive143Third138Leaves10
import NineSeparatedSubsetSums.Adaptive143Third138Leaves1
import NineSeparatedSubsetSums.Adaptive143Third138Leaves13
import NineSeparatedSubsetSums.Adaptive143Third138Leaves0
import NineSeparatedSubsetSums.Adaptive143Third138Leaves32
import NineSeparatedSubsetSums.Adaptive143Third138Leaves2
import NineSeparatedSubsetSums.Adaptive143Third138Leaves5

namespace NineSeparatedSubsetSums

theorem adaptive143Third138Proof19 : runCachedNode 511 129927 Adaptive143Third138Node19 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 129927 Adaptive143Third138Node19 = [105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 119, 120, 121, 122, 124, 125, 126, 127] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive143Third138Proof20
  · exact adaptive143Third138Proof21
  · exact adaptive143Third138Proof22
  · exact adaptive143Third138Proof23
  · exact adaptive143Third138Proof24
  · exact adaptive143Third138Proof25
  · exact adaptive143Third138Proof26
  · exact adaptive143Third138Proof27
  · exact adaptive143Third138Proof28
  · exact adaptive143Third138Proof29
  · exact adaptive143Third138Proof30
  · exact adaptive143Third138Proof31
  · exact adaptive143Third138Proof32
  · exact adaptive143Third138Proof33
  · exact adaptive143Third138Proof34
  · exact adaptive143Third138Proof35
  · exact adaptive143Third138Proof36
  · exact adaptive143Third138Proof37
  · exact adaptive143Third138Proof38
  · exact adaptive143Third138Proof39
  · exact adaptive143Third138Proof40

#print axioms adaptive143Third138Proof19

theorem adaptive143Third138Proof41 : runCachedNode 511 129927 Adaptive143Third138Node41 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 129927 Adaptive143Third138Node41 = [104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 120, 121, 122, 123, 125, 126, 127, 128] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive143Third138Proof42
  · exact adaptive143Third138Proof43
  · exact adaptive143Third138Proof44
  · exact adaptive143Third138Proof45
  · exact adaptive143Third138Proof46
  · exact adaptive143Third138Proof47
  · exact adaptive143Third138Proof48
  · exact adaptive143Third138Proof49
  · exact adaptive143Third138Proof50
  · exact adaptive143Third138Proof51
  · exact adaptive143Third138Proof52
  · exact adaptive143Third138Proof53
  · exact adaptive143Third138Proof54
  · exact adaptive143Third138Proof55
  · exact adaptive143Third138Proof56
  · exact adaptive143Third138Proof57
  · exact adaptive143Third138Proof58
  · exact adaptive143Third138Proof59
  · exact adaptive143Third138Proof60
  · exact adaptive143Third138Proof61
  · exact adaptive143Third138Proof62
  · exact adaptive143Third138Proof63
  · exact adaptive143Third138Proof64

#print axioms adaptive143Third138Proof41

theorem adaptive143Third138Proof65 : runCachedNode 511 129927 Adaptive143Third138Node65 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 129927 Adaptive143Third138Node65 = [104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 121, 122, 123, 124, 126, 127, 128, 129] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive143Third138Proof66
  · exact adaptive143Third138Proof67
  · exact adaptive143Third138Proof68
  · exact adaptive143Third138Proof69
  · exact adaptive143Third138Proof70
  · exact adaptive143Third138Proof71
  · exact adaptive143Third138Proof72
  · exact adaptive143Third138Proof73
  · exact adaptive143Third138Proof74
  · exact adaptive143Third138Proof75
  · exact adaptive143Third138Proof76
  · exact adaptive143Third138Proof77
  · exact adaptive143Third138Proof78
  · exact adaptive143Third138Proof79
  · exact adaptive143Third138Proof80
  · exact adaptive143Third138Proof81
  · exact adaptive143Third138Proof82
  · exact adaptive143Third138Proof83
  · exact adaptive143Third138Proof84
  · exact adaptive143Third138Proof85
  · exact adaptive143Third138Proof86
  · exact adaptive143Third138Proof87
  · exact adaptive143Third138Proof88
  · exact adaptive143Third138Proof89

#print axioms adaptive143Third138Proof65

theorem adaptive143Third138Proof90 : runCachedNode 511 129927 Adaptive143Third138Node90 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 129927 Adaptive143Third138Node90 = [104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 122, 123, 124, 125, 127, 128, 129, 130] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive143Third138Proof91
  · exact adaptive143Third138Proof92
  · exact adaptive143Third138Proof93
  · exact adaptive143Third138Proof94
  · exact adaptive143Third138Proof95
  · exact adaptive143Third138Proof96
  · exact adaptive143Third138Proof97
  · exact adaptive143Third138Proof98
  · exact adaptive143Third138Proof99
  · exact adaptive143Third138Proof100
  · exact adaptive143Third138Proof101
  · exact adaptive143Third138Proof102
  · exact adaptive143Third138Proof103
  · exact adaptive143Third138Proof104
  · exact adaptive143Third138Proof105
  · exact adaptive143Third138Proof106
  · exact adaptive143Third138Proof107
  · exact adaptive143Third138Proof108
  · exact adaptive143Third138Proof109
  · exact adaptive143Third138Proof110
  · exact adaptive143Third138Proof111
  · exact adaptive143Third138Proof112
  · exact adaptive143Third138Proof113
  · exact adaptive143Third138Proof114
  · exact adaptive143Third138Proof115

#print axioms adaptive143Third138Proof90

theorem adaptive143Third138Proof116 : runCachedNode 511 129927 Adaptive143Third138Node116 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 129927 Adaptive143Third138Node116 = [104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 123, 124, 125, 126, 128, 129, 130, 131] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive143Third138Proof117
  · exact adaptive143Third138Proof118
  · exact adaptive143Third138Proof119
  · exact adaptive143Third138Proof120
  · exact adaptive143Third138Proof121
  · exact adaptive143Third138Proof122
  · exact adaptive143Third138Proof123
  · exact adaptive143Third138Proof124
  · exact adaptive143Third138Proof125
  · exact adaptive143Third138Proof126
  · exact adaptive143Third138Proof127
  · exact adaptive143Third138Proof128
  · exact adaptive143Third138Proof129
  · exact adaptive143Third138Proof130
  · exact adaptive143Third138Proof131
  · exact adaptive143Third138Proof132
  · exact adaptive143Third138Proof133
  · exact adaptive143Third138Proof134
  · exact adaptive143Third138Proof135
  · exact adaptive143Third138Proof136
  · exact adaptive143Third138Proof137
  · exact adaptive143Third138Proof138
  · exact adaptive143Third138Proof139
  · exact adaptive143Third138Proof140
  · exact adaptive143Third138Proof141
  · exact adaptive143Third138Proof142

#print axioms adaptive143Third138Proof116

theorem adaptive143Third138Proof143 : runCachedNode 511 129927 Adaptive143Third138Node143 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 129927 Adaptive143Third138Node143 = [103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 125, 126, 127, 128, 130, 131, 132] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive143Third138Proof144
  · exact adaptive143Third138Proof145
  · exact adaptive143Third138Proof146
  · exact adaptive143Third138Proof147
  · exact adaptive143Third138Proof148
  · exact adaptive143Third138Proof149
  · exact adaptive143Third138Proof150
  · exact adaptive143Third138Proof151
  · exact adaptive143Third138Proof152
  · exact adaptive143Third138Proof153
  · exact adaptive143Third138Proof154
  · exact adaptive143Third138Proof155
  · exact adaptive143Third138Proof156
  · exact adaptive143Third138Proof157
  · exact adaptive143Third138Proof158
  · exact adaptive143Third138Proof159
  · exact adaptive143Third138Proof160
  · exact adaptive143Third138Proof161
  · exact adaptive143Third138Proof162
  · exact adaptive143Third138Proof163
  · exact adaptive143Third138Proof164
  · exact adaptive143Third138Proof165
  · exact adaptive143Third138Proof166
  · exact adaptive143Third138Proof167
  · exact adaptive143Third138Proof168
  · exact adaptive143Third138Proof169
  · exact adaptive143Third138Proof170
  · exact adaptive143Third138Proof171

#print axioms adaptive143Third138Proof143

theorem adaptive143Third138Proof172 : runCachedNode 511 129927 Adaptive143Third138Node172 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 129927 Adaptive143Third138Node172 = [103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 126, 127, 128, 129, 131, 132, 134] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive143Third138Proof173
  · exact adaptive143Third138Proof174
  · exact adaptive143Third138Proof175
  · exact adaptive143Third138Proof176
  · exact adaptive143Third138Proof177
  · exact adaptive143Third138Proof178
  · exact adaptive143Third138Proof179
  · exact adaptive143Third138Proof180
  · exact adaptive143Third138Proof181
  · exact adaptive143Third138Proof182
  · exact adaptive143Third138Proof183
  · exact adaptive143Third138Proof184
  · exact adaptive143Third138Proof185
  · exact adaptive143Third138Proof186
  · exact adaptive143Third138Proof187
  · exact adaptive143Third138Proof188
  · exact adaptive143Third138Proof189
  · exact adaptive143Third138Proof190
  · exact adaptive143Third138Proof191
  · exact adaptive143Third138Proof192
  · exact adaptive143Third138Proof193
  · exact adaptive143Third138Proof194
  · exact adaptive143Third138Proof195
  · exact adaptive143Third138Proof196
  · exact adaptive143Third138Proof197
  · exact adaptive143Third138Proof198
  · exact adaptive143Third138Proof199
  · exact adaptive143Third138Proof200
  · exact adaptive143Third138Proof201

#print axioms adaptive143Third138Proof172

theorem adaptive143Third138Proof202 : runCachedNode 511 129927 Adaptive143Third138Node202 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 129927 Adaptive143Third138Node202 = [103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 127, 128, 129, 130, 132, 134, 135] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive143Third138Proof203
  · exact adaptive143Third138Proof204
  · exact adaptive143Third138Proof205
  · exact adaptive143Third138Proof206
  · exact adaptive143Third138Proof207
  · exact adaptive143Third138Proof208
  · exact adaptive143Third138Proof209
  · exact adaptive143Third138Proof210
  · exact adaptive143Third138Proof211
  · exact adaptive143Third138Proof212
  · exact adaptive143Third138Proof213
  · exact adaptive143Third138Proof214
  · exact adaptive143Third138Proof215
  · exact adaptive143Third138Proof216
  · exact adaptive143Third138Proof217
  · exact adaptive143Third138Proof218
  · exact adaptive143Third138Proof219
  · exact adaptive143Third138Proof220
  · exact adaptive143Third138Proof221
  · exact adaptive143Third138Proof222
  · exact adaptive143Third138Proof223
  · exact adaptive143Third138Proof224
  · exact adaptive143Third138Proof225
  · exact adaptive143Third138Proof226
  · exact adaptive143Third138Proof227
  · exact adaptive143Third138Proof228
  · exact adaptive143Third138Proof229
  · exact adaptive143Third138Proof230
  · exact adaptive143Third138Proof231
  · exact adaptive143Third138Proof232

#print axioms adaptive143Third138Proof202

end NineSeparatedSubsetSums
