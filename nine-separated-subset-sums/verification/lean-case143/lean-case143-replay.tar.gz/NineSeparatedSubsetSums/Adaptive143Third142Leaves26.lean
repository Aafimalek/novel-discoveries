import NineSeparatedSubsetSums.Adaptive143Third142State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third142Proof415 : runCachedNode 511 130584 Adaptive143Third142Node415 = false := by
  decide +kernel

#print axioms adaptive143Third142Proof415

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third142Proof443 : runCachedNode 511 130584 Adaptive143Third142Node443 = false := by
  decide +kernel

#print axioms adaptive143Third142Proof443

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third142Proof101 : runCachedNode 511 130584 Adaptive143Third142Node101 = false := by
  decide +kernel

#print axioms adaptive143Third142Proof101

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third142Proof335 : runCachedNode 511 130584 Adaptive143Third142Node335 = false := by
  decide +kernel

#print axioms adaptive143Third142Proof335

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third142Proof262 : runCachedNode 511 130584 Adaptive143Third142Node262 = false := by
  decide +kernel

#print axioms adaptive143Third142Proof262

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third142Proof98 : runCachedNode 511 130584 Adaptive143Third142Node98 = false := by
  decide +kernel

#print axioms adaptive143Third142Proof98

end NineSeparatedSubsetSums
