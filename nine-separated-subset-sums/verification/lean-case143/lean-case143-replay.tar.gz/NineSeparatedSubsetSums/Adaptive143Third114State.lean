import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive143Third114Node0 : CachedSearchNode :=
  ⟨4, 113, computeCenteredMask [148,143,114], 405, 55349⟩

end NineSeparatedSubsetSums
