import NineSeparatedSubsetSums.EightPoint143_122PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint143_122PackedAnchor1Part2 :
    ∀ j : Fin 1, 2311344 ≤ FourPointNumeric.octPackedCharge 143 122 20 packedOct143_122_1
      (2*((j.val : Int)+240)+0) := by decide +kernel

end NineSeparatedSubsetSums
