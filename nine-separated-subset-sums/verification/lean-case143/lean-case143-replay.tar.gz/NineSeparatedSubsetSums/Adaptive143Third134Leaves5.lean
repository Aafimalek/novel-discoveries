import NineSeparatedSubsetSums.Adaptive143Third134State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third134Proof16 : runCachedNode 511 129375 Adaptive143Third134Node16 = false := by
  decide +kernel

#print axioms adaptive143Third134Proof16

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third134Proof17 : runCachedNode 511 129375 Adaptive143Third134Node17 = false := by
  decide +kernel

#print axioms adaptive143Third134Proof17

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third134Proof13 : runCachedNode 511 129375 Adaptive143Third134Node13 = false := by
  decide +kernel

#print axioms adaptive143Third134Proof13

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third134Proof12 : runCachedNode 511 129375 Adaptive143Third134Node12 = false := by
  decide +kernel

#print axioms adaptive143Third134Proof12

end NineSeparatedSubsetSums
