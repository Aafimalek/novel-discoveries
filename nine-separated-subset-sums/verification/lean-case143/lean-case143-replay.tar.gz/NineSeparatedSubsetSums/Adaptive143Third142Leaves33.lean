import NineSeparatedSubsetSums.Adaptive143Third142State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third142Proof71 : runCachedNode 511 130584 Adaptive143Third142Node71 = false := by
  decide +kernel

#print axioms adaptive143Third142Proof71

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third142Proof490 : runCachedNode 511 130584 Adaptive143Third142Node490 = false := by
  decide +kernel

#print axioms adaptive143Third142Proof490

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third142Proof70 : runCachedNode 511 130584 Adaptive143Third142Node70 = false := by
  decide +kernel

#print axioms adaptive143Third142Proof70

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third142Proof184 : runCachedNode 511 130584 Adaptive143Third142Node184 = false := by
  decide +kernel

#print axioms adaptive143Third142Proof184

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third142Proof436 : runCachedNode 511 130584 Adaptive143Third142Node436 = false := by
  decide +kernel

#print axioms adaptive143Third142Proof436

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third142Proof412 : runCachedNode 511 130584 Adaptive143Third142Node412 = false := by
  decide +kernel

#print axioms adaptive143Third142Proof412

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third142Proof183 : runCachedNode 511 130584 Adaptive143Third142Node183 = false := by
  decide +kernel

#print axioms adaptive143Third142Proof183

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third142Proof125 : runCachedNode 511 130584 Adaptive143Third142Node125 = false := by
  decide +kernel

#print axioms adaptive143Third142Proof125

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third142Proof215 : runCachedNode 511 130584 Adaptive143Third142Node215 = false := by
  decide +kernel

#print axioms adaptive143Third142Proof215

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third142Proof182 : runCachedNode 511 130584 Adaptive143Third142Node182 = false := by
  decide +kernel

#print axioms adaptive143Third142Proof182

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third142Proof364 : runCachedNode 511 130584 Adaptive143Third142Node364 = false := by
  decide +kernel

#print axioms adaptive143Third142Proof364

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third142Proof479 : runCachedNode 511 130584 Adaptive143Third142Node479 = false := by
  decide +kernel

#print axioms adaptive143Third142Proof479

end NineSeparatedSubsetSums
