import NineSeparatedSubsetSums.Adaptive143Third133State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third133Proof21 : runCachedNode 511 129127 Adaptive143Third133Node21 = false := by
  decide +kernel

#print axioms adaptive143Third133Proof21

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third133Proof19 : runCachedNode 511 129127 Adaptive143Third133Node19 = false := by
  decide +kernel

#print axioms adaptive143Third133Proof19

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third133Proof5 : runCachedNode 511 129127 Adaptive143Third133Node5 = false := by
  decide +kernel

#print axioms adaptive143Third133Proof5

end NineSeparatedSubsetSums
