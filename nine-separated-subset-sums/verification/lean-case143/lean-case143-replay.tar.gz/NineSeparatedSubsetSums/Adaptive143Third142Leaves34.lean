import NineSeparatedSubsetSums.Adaptive143Third142State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third142Proof99 : runCachedNode 511 130584 Adaptive143Third142Node99 = false := by
  decide +kernel

#print axioms adaptive143Third142Proof99

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third142Proof41 : runCachedNode 511 130584 Adaptive143Third142Node41 = false := by
  decide +kernel

#print axioms adaptive143Third142Proof41

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third142Proof435 : runCachedNode 511 130584 Adaptive143Third142Node435 = false := by
  decide +kernel

#print axioms adaptive143Third142Proof435

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third142Proof42 : runCachedNode 511 130584 Adaptive143Third142Node42 = false := by
  decide +kernel

#print axioms adaptive143Third142Proof42

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third142Proof156 : runCachedNode 511 130584 Adaptive143Third142Node156 = false := by
  decide +kernel

#print axioms adaptive143Third142Proof156

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third142Proof362 : runCachedNode 511 130584 Adaptive143Third142Node362 = false := by
  decide +kernel

#print axioms adaptive143Third142Proof362

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third142Proof155 : runCachedNode 511 130584 Adaptive143Third142Node155 = false := by
  decide +kernel

#print axioms adaptive143Third142Proof155

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third142Proof363 : runCachedNode 511 130584 Adaptive143Third142Node363 = false := by
  decide +kernel

#print axioms adaptive143Third142Proof363

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third142Proof214 : runCachedNode 511 130584 Adaptive143Third142Node214 = false := by
  decide +kernel

#print axioms adaptive143Third142Proof214

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third142Proof489 : runCachedNode 511 130584 Adaptive143Third142Node489 = false := by
  decide +kernel

#print axioms adaptive143Third142Proof489

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third142Proof44 : runCachedNode 511 130584 Adaptive143Third142Node44 = false := by
  decide +kernel

#print axioms adaptive143Third142Proof44

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third142Proof124 : runCachedNode 511 130584 Adaptive143Third142Node124 = false := by
  decide +kernel

#print axioms adaptive143Third142Proof124

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third142Proof181 : runCachedNode 511 130584 Adaptive143Third142Node181 = false := by
  decide +kernel

#print axioms adaptive143Third142Proof181

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third142Proof522 : runCachedNode 511 130584 Adaptive143Third142Node522 = false := by
  decide +kernel

#print axioms adaptive143Third142Proof522

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third142Proof134 : runCachedNode 511 130584 Adaptive143Third142Node134 = false := by
  decide +kernel

#print axioms adaptive143Third142Proof134

end NineSeparatedSubsetSums
