import NineSeparatedSubsetSums.Adaptive143Third140State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third140Proof312 : runCachedNode 511 130276 Adaptive143Third140Node312 = false := by
  decide +kernel

#print axioms adaptive143Third140Proof312

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third140Proof166 : runCachedNode 511 130276 Adaptive143Third140Node166 = false := by
  decide +kernel

#print axioms adaptive143Third140Proof166

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third140Proof47 : runCachedNode 511 130276 Adaptive143Third140Node47 = false := by
  decide +kernel

#print axioms adaptive143Third140Proof47

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third140Proof97 : runCachedNode 511 130276 Adaptive143Third140Node97 = false := by
  decide +kernel

#print axioms adaptive143Third140Proof97

end NineSeparatedSubsetSums
