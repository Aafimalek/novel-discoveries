import NineSeparatedSubsetSums.Adaptive143Third140State
import NineSeparatedSubsetSums.Adaptive143Third140Leaves33
import NineSeparatedSubsetSums.Adaptive143Third140Leaves32
import NineSeparatedSubsetSums.Adaptive143Third140Leaves31
import NineSeparatedSubsetSums.Adaptive143Third140Leaves30
import NineSeparatedSubsetSums.Adaptive143Third140Leaves29
import NineSeparatedSubsetSums.Adaptive143Third140Leaves28
import NineSeparatedSubsetSums.Adaptive143Third140Leaves27
import NineSeparatedSubsetSums.Adaptive143Third140Leaves26
import NineSeparatedSubsetSums.Adaptive143Third140Leaves25
import NineSeparatedSubsetSums.Adaptive143Third140Leaves17
import NineSeparatedSubsetSums.Adaptive143Third140Leaves22
import NineSeparatedSubsetSums.Adaptive143Third140Leaves20
import NineSeparatedSubsetSums.Adaptive143Third140Leaves14
import NineSeparatedSubsetSums.Adaptive143Third140Leaves23
import NineSeparatedSubsetSums.Adaptive143Third140Leaves24
import NineSeparatedSubsetSums.Adaptive143Third140Leaves19
import NineSeparatedSubsetSums.Adaptive143Third140Leaves18
import NineSeparatedSubsetSums.Adaptive143Third140Leaves9
import NineSeparatedSubsetSums.Adaptive143Third140Leaves11
import NineSeparatedSubsetSums.Adaptive143Third140Leaves15
import NineSeparatedSubsetSums.Adaptive143Third140Leaves1
import NineSeparatedSubsetSums.Adaptive143Third140Leaves3
import NineSeparatedSubsetSums.Adaptive143Third140Leaves16
import NineSeparatedSubsetSums.Adaptive143Third140Leaves10
import NineSeparatedSubsetSums.Adaptive143Third140Leaves8
import NineSeparatedSubsetSums.Adaptive143Third140Leaves0
import NineSeparatedSubsetSums.Adaptive143Third140Joins0

namespace NineSeparatedSubsetSums

theorem adaptive143Third140Proof313 : runCachedNode 511 130276 Adaptive143Third140Node313 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130276 Adaptive143Third140Node313 = [89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 126, 127, 130] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive143Third140Proof314
  · exact adaptive143Third140Proof315
  · exact adaptive143Third140Proof316
  · exact adaptive143Third140Proof317
  · exact adaptive143Third140Proof318
  · exact adaptive143Third140Proof319
  · exact adaptive143Third140Proof320
  · exact adaptive143Third140Proof321
  · exact adaptive143Third140Proof322
  · exact adaptive143Third140Proof323
  · exact adaptive143Third140Proof324
  · exact adaptive143Third140Proof325
  · exact adaptive143Third140Proof326
  · exact adaptive143Third140Proof327
  · exact adaptive143Third140Proof328
  · exact adaptive143Third140Proof329
  · exact adaptive143Third140Proof330
  · exact adaptive143Third140Proof331
  · exact adaptive143Third140Proof332
  · exact adaptive143Third140Proof333
  · exact adaptive143Third140Proof334
  · exact adaptive143Third140Proof335
  · exact adaptive143Third140Proof336
  · exact adaptive143Third140Proof337
  · exact adaptive143Third140Proof338
  · exact adaptive143Third140Proof339
  · exact adaptive143Third140Proof340
  · exact adaptive143Third140Proof341
  · exact adaptive143Third140Proof342
  · exact adaptive143Third140Proof343
  · exact adaptive143Third140Proof344
  · exact adaptive143Third140Proof345
  · exact adaptive143Third140Proof346
  · exact adaptive143Third140Proof347
  · exact adaptive143Third140Proof348
  · exact adaptive143Third140Proof349
  · exact adaptive143Third140Proof350
  · exact adaptive143Third140Proof351
  · exact adaptive143Third140Proof352

#print axioms adaptive143Third140Proof313

theorem adaptive143Third140Proof353 : runCachedNode 511 130276 Adaptive143Third140Node353 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130276 Adaptive143Third140Node353 = [89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 127, 128] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive143Third140Proof354
  · exact adaptive143Third140Proof355
  · exact adaptive143Third140Proof356
  · exact adaptive143Third140Proof357
  · exact adaptive143Third140Proof358
  · exact adaptive143Third140Proof359
  · exact adaptive143Third140Proof360
  · exact adaptive143Third140Proof361
  · exact adaptive143Third140Proof362
  · exact adaptive143Third140Proof363
  · exact adaptive143Third140Proof364
  · exact adaptive143Third140Proof365
  · exact adaptive143Third140Proof366
  · exact adaptive143Third140Proof367
  · exact adaptive143Third140Proof368
  · exact adaptive143Third140Proof369
  · exact adaptive143Third140Proof370
  · exact adaptive143Third140Proof371
  · exact adaptive143Third140Proof372
  · exact adaptive143Third140Proof373
  · exact adaptive143Third140Proof374
  · exact adaptive143Third140Proof375
  · exact adaptive143Third140Proof376
  · exact adaptive143Third140Proof377
  · exact adaptive143Third140Proof378
  · exact adaptive143Third140Proof379
  · exact adaptive143Third140Proof380
  · exact adaptive143Third140Proof381
  · exact adaptive143Third140Proof382
  · exact adaptive143Third140Proof383
  · exact adaptive143Third140Proof384
  · exact adaptive143Third140Proof385
  · exact adaptive143Third140Proof386
  · exact adaptive143Third140Proof387
  · exact adaptive143Third140Proof388
  · exact adaptive143Third140Proof389
  · exact adaptive143Third140Proof390
  · exact adaptive143Third140Proof391
  · exact adaptive143Third140Proof392

#print axioms adaptive143Third140Proof353

theorem adaptive143Third140Proof280 : runCachedNode 511 130276 Adaptive143Third140Node280 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130276 Adaptive143Third140Node280 = [101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 132, 133, 137, 138] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive143Third140Proof281
  · exact adaptive143Third140Proof282
  · exact adaptive143Third140Proof283
  · exact adaptive143Third140Proof284
  · exact adaptive143Third140Proof285
  · exact adaptive143Third140Proof286
  · exact adaptive143Third140Proof287
  · exact adaptive143Third140Proof288
  · exact adaptive143Third140Proof289
  · exact adaptive143Third140Proof290
  · exact adaptive143Third140Proof291
  · exact adaptive143Third140Proof292
  · exact adaptive143Third140Proof293
  · exact adaptive143Third140Proof294
  · exact adaptive143Third140Proof295
  · exact adaptive143Third140Proof296
  · exact adaptive143Third140Proof297
  · exact adaptive143Third140Proof298
  · exact adaptive143Third140Proof299
  · exact adaptive143Third140Proof300
  · exact adaptive143Third140Proof301
  · exact adaptive143Third140Proof302
  · exact adaptive143Third140Proof303
  · exact adaptive143Third140Proof304
  · exact adaptive143Third140Proof305
  · exact adaptive143Third140Proof306
  · exact adaptive143Third140Proof307
  · exact adaptive143Third140Proof308
  · exact adaptive143Third140Proof309
  · exact adaptive143Third140Proof310
  · exact adaptive143Third140Proof311
  · exact adaptive143Third140Proof312
  · exact adaptive143Third140Proof313
  · exact adaptive143Third140Proof353

#print axioms adaptive143Third140Proof280

theorem adaptive143Third140Proof0 : runCachedNode 511 130276 Adaptive143Third140Node0 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130276 Adaptive143Third140Node0 = [110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 132, 133, 134, 136, 137, 138, 139] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive143Third140Proof1
  · exact adaptive143Third140Proof2
  · exact adaptive143Third140Proof3
  · exact adaptive143Third140Proof4
  · exact adaptive143Third140Proof5
  · exact adaptive143Third140Proof6
  · exact adaptive143Third140Proof7
  · exact adaptive143Third140Proof8
  · exact adaptive143Third140Proof9
  · exact adaptive143Third140Proof10
  · exact adaptive143Third140Proof11
  · exact adaptive143Third140Proof12
  · exact adaptive143Third140Proof13
  · exact adaptive143Third140Proof14
  · exact adaptive143Third140Proof15
  · exact adaptive143Third140Proof16
  · exact adaptive143Third140Proof17
  · exact adaptive143Third140Proof18
  · exact adaptive143Third140Proof19
  · exact adaptive143Third140Proof20
  · exact adaptive143Third140Proof21
  · exact adaptive143Third140Proof22
  · exact adaptive143Third140Proof23
  · exact adaptive143Third140Proof50
  · exact adaptive143Third140Proof78
  · exact adaptive143Third140Proof107
  · exact adaptive143Third140Proof138
  · exact adaptive143Third140Proof170
  · exact adaptive143Third140Proof280

#print axioms adaptive143Third140Proof0

end NineSeparatedSubsetSums
