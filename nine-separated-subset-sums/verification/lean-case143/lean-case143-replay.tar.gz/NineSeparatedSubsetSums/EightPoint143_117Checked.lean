import NineSeparatedSubsetSums.EightPointPackedGeometry
import NineSeparatedSubsetSums.EightPoint143_117PackedBudget0
import NineSeparatedSubsetSums.EightPoint143_117PackedAnchor0Part0
import NineSeparatedSubsetSums.EightPoint143_117PackedAnchor0Part1
import NineSeparatedSubsetSums.EightPoint143_117PackedAnchor0Part2
import NineSeparatedSubsetSums.EightPoint143_117PackedBudget1
import NineSeparatedSubsetSums.EightPoint143_117PackedAnchor1Part0
import NineSeparatedSubsetSums.EightPoint143_117PackedAnchor1Part1
import NineSeparatedSubsetSums.EightPoint143_117PackedAnchor1Part2

namespace NineSeparatedSubsetSums

private theorem packedOct143_117Anchor0 :
  ∀ j : Fin 492, ((j.val : Int)+143+117)%2=0 →
    2381812 ≤ FourPointNumeric.octPackedCharge 143 117 20 packedOct143_117_0 (j.val : Int) := by
  intro j hj
  let k := (j.val-0)/2
  have hk : k < 246 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+0 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint143_117PackedAnchor0Part0 z
    rwa [he,hrep] at ht
  by_cases h1 : k < 240
  · let z : Fin 120 := ⟨k-120, by omega⟩
    have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
    have ht := eightPoint143_117PackedAnchor0Part1 z
    rwa [he,hrep] at ht
  let z : Fin 6 := ⟨k-240, by omega⟩
  have he : (z.val : Int)+240 = k := by dsimp [z] <;> omega
  have ht := eightPoint143_117PackedAnchor0Part2 z
  rwa [he,hrep] at ht

private theorem packedOct143_117Anchor1 :
  ∀ j : Fin 492, ((j.val : Int)+143+117)%2=1 →
    2382998 ≤ FourPointNumeric.octPackedCharge 143 117 20 packedOct143_117_1 (j.val : Int) := by
  intro j hj
  let k := (j.val-1)/2
  have hk : k < 246 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+1 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint143_117PackedAnchor1Part0 z
    rwa [he,hrep] at ht
  by_cases h1 : k < 240
  · let z : Fin 120 := ⟨k-120, by omega⟩
    have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
    have ht := eightPoint143_117PackedAnchor1Part1 z
    rwa [he,hrep] at ht
  let z : Fin 6 := ⟨k-240, by omega⟩
  have he : (z.val : Int)+240 = k := by dsimp [z] <;> omega
  have ht := eightPoint143_117PackedAnchor1Part2 z
  rwa [he,hrep] at ht

def packedOctCertificate143_117_0 : EightPointCertificate 143 117 0 125488 :=
  eightPointCertificateOfPacked 143 117 0 125488 2381812 20 packedOct143_117_0 433 492
    (by decide +kernel) (by decide) packedOct143_117Anchor0
    (by rw [packedOct143_117_0_budget]; decide)

def packedOctCertificate143_117_1 : EightPointCertificate 143 117 1 125488 :=
  eightPointCertificateOfPacked 143 117 1 125488 2382998 20 packedOct143_117_1 460 492
    (by decide +kernel) (by decide) packedOct143_117Anchor1
    (by rw [packedOct143_117_1_budget]; decide)

theorem max148_second143_third117_eightPoint_moment_bound (tail : List ℕ) (len : tail.length=6)
    (distinct : (natSubsetSums (148::143::117::tail)).Nodup) :
    125488 ≤ ((148::143::117::tail).map (· ^ 2)).sum := by
  apply eightPointNatMomentLower 143 117 125488 tail len distinct
  intro p hp
  by_cases h : p=0
  · subst p
    exact packedOctCertificate143_117_0
  · have he : p=1 := hp.resolve_left h
    subst p
    exact packedOctCertificate143_117_1

#print axioms max148_second143_third117_eightPoint_moment_bound

end NineSeparatedSubsetSums
