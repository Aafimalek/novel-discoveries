import NineSeparatedSubsetSums.Adaptive143Third141State
import NineSeparatedSubsetSums.Adaptive143Third141Leaves37
import NineSeparatedSubsetSums.Adaptive143Third141Leaves36
import NineSeparatedSubsetSums.Adaptive143Third141Leaves35
import NineSeparatedSubsetSums.Adaptive143Third141Leaves34
import NineSeparatedSubsetSums.Adaptive143Third141Leaves24
import NineSeparatedSubsetSums.Adaptive143Third141Leaves33
import NineSeparatedSubsetSums.Adaptive143Third141Leaves32
import NineSeparatedSubsetSums.Adaptive143Third141Leaves31
import NineSeparatedSubsetSums.Adaptive143Third141Leaves30
import NineSeparatedSubsetSums.Adaptive143Third141Leaves28
import NineSeparatedSubsetSums.Adaptive143Third141Leaves27
import NineSeparatedSubsetSums.Adaptive143Third141Leaves19
import NineSeparatedSubsetSums.Adaptive143Third141Leaves5
import NineSeparatedSubsetSums.Adaptive143Third141Leaves10
import NineSeparatedSubsetSums.Adaptive143Third141Leaves29
import NineSeparatedSubsetSums.Adaptive143Third141Leaves25
import NineSeparatedSubsetSums.Adaptive143Third141Leaves22
import NineSeparatedSubsetSums.Adaptive143Third141Leaves15
import NineSeparatedSubsetSums.Adaptive143Third141Leaves26
import NineSeparatedSubsetSums.Adaptive143Third141Leaves23
import NineSeparatedSubsetSums.Adaptive143Third141Leaves3
import NineSeparatedSubsetSums.Adaptive143Third141Leaves20
import NineSeparatedSubsetSums.Adaptive143Third141Leaves16
import NineSeparatedSubsetSums.Adaptive143Third141Leaves13
import NineSeparatedSubsetSums.Adaptive143Third141Leaves12
import NineSeparatedSubsetSums.Adaptive143Third141Leaves7
import NineSeparatedSubsetSums.Adaptive143Third141Leaves11
import NineSeparatedSubsetSums.Adaptive143Third141Leaves38
import NineSeparatedSubsetSums.Adaptive143Third141Leaves17
import NineSeparatedSubsetSums.Adaptive143Third141Leaves18
import NineSeparatedSubsetSums.Adaptive143Third141Leaves1
import NineSeparatedSubsetSums.Adaptive143Third141Leaves0
import NineSeparatedSubsetSums.Adaptive143Third141Leaves14
import NineSeparatedSubsetSums.Adaptive143Third141Leaves6
import NineSeparatedSubsetSums.Adaptive143Third141Leaves4
import NineSeparatedSubsetSums.Adaptive143Third141Joins0

namespace NineSeparatedSubsetSums

theorem adaptive143Third141Proof298 : runCachedNode 511 130431 Adaptive143Third141Node298 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130431 Adaptive143Third141Node298 = [90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 125, 127, 129] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive143Third141Proof299
  · exact adaptive143Third141Proof300
  · exact adaptive143Third141Proof301
  · exact adaptive143Third141Proof302
  · exact adaptive143Third141Proof303
  · exact adaptive143Third141Proof304
  · exact adaptive143Third141Proof305
  · exact adaptive143Third141Proof306
  · exact adaptive143Third141Proof307
  · exact adaptive143Third141Proof308
  · exact adaptive143Third141Proof309
  · exact adaptive143Third141Proof310
  · exact adaptive143Third141Proof311
  · exact adaptive143Third141Proof312
  · exact adaptive143Third141Proof313
  · exact adaptive143Third141Proof314
  · exact adaptive143Third141Proof315
  · exact adaptive143Third141Proof316
  · exact adaptive143Third141Proof317
  · exact adaptive143Third141Proof318
  · exact adaptive143Third141Proof319
  · exact adaptive143Third141Proof320
  · exact adaptive143Third141Proof321
  · exact adaptive143Third141Proof322
  · exact adaptive143Third141Proof323
  · exact adaptive143Third141Proof324
  · exact adaptive143Third141Proof325
  · exact adaptive143Third141Proof326
  · exact adaptive143Third141Proof327
  · exact adaptive143Third141Proof328
  · exact adaptive143Third141Proof329
  · exact adaptive143Third141Proof330
  · exact adaptive143Third141Proof331
  · exact adaptive143Third141Proof332
  · exact adaptive143Third141Proof333
  · exact adaptive143Third141Proof334
  · exact adaptive143Third141Proof335

#print axioms adaptive143Third141Proof298

theorem adaptive143Third141Proof336 : runCachedNode 511 130431 Adaptive143Third141Node336 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130431 Adaptive143Third141Node336 = [88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 128, 130] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive143Third141Proof337
  · exact adaptive143Third141Proof338
  · exact adaptive143Third141Proof339
  · exact adaptive143Third141Proof340
  · exact adaptive143Third141Proof341
  · exact adaptive143Third141Proof342
  · exact adaptive143Third141Proof343
  · exact adaptive143Third141Proof344
  · exact adaptive143Third141Proof345
  · exact adaptive143Third141Proof346
  · exact adaptive143Third141Proof347
  · exact adaptive143Third141Proof348
  · exact adaptive143Third141Proof349
  · exact adaptive143Third141Proof350
  · exact adaptive143Third141Proof351
  · exact adaptive143Third141Proof352
  · exact adaptive143Third141Proof353
  · exact adaptive143Third141Proof354
  · exact adaptive143Third141Proof355
  · exact adaptive143Third141Proof356
  · exact adaptive143Third141Proof357
  · exact adaptive143Third141Proof358
  · exact adaptive143Third141Proof359
  · exact adaptive143Third141Proof360
  · exact adaptive143Third141Proof361
  · exact adaptive143Third141Proof362
  · exact adaptive143Third141Proof363
  · exact adaptive143Third141Proof364
  · exact adaptive143Third141Proof365
  · exact adaptive143Third141Proof366
  · exact adaptive143Third141Proof367
  · exact adaptive143Third141Proof368
  · exact adaptive143Third141Proof369
  · exact adaptive143Third141Proof370
  · exact adaptive143Third141Proof371
  · exact adaptive143Third141Proof372
  · exact adaptive143Third141Proof373
  · exact adaptive143Third141Proof374
  · exact adaptive143Third141Proof375
  · exact adaptive143Third141Proof376
  · exact adaptive143Third141Proof377

#print axioms adaptive143Third141Proof336

theorem adaptive143Third141Proof265 : runCachedNode 511 130431 Adaptive143Third141Node265 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130431 Adaptive143Third141Node265 = [101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 133, 135, 138] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive143Third141Proof266
  · exact adaptive143Third141Proof267
  · exact adaptive143Third141Proof268
  · exact adaptive143Third141Proof269
  · exact adaptive143Third141Proof270
  · exact adaptive143Third141Proof271
  · exact adaptive143Third141Proof272
  · exact adaptive143Third141Proof273
  · exact adaptive143Third141Proof274
  · exact adaptive143Third141Proof275
  · exact adaptive143Third141Proof276
  · exact adaptive143Third141Proof277
  · exact adaptive143Third141Proof278
  · exact adaptive143Third141Proof279
  · exact adaptive143Third141Proof280
  · exact adaptive143Third141Proof281
  · exact adaptive143Third141Proof282
  · exact adaptive143Third141Proof283
  · exact adaptive143Third141Proof284
  · exact adaptive143Third141Proof285
  · exact adaptive143Third141Proof286
  · exact adaptive143Third141Proof287
  · exact adaptive143Third141Proof288
  · exact adaptive143Third141Proof289
  · exact adaptive143Third141Proof290
  · exact adaptive143Third141Proof291
  · exact adaptive143Third141Proof292
  · exact adaptive143Third141Proof293
  · exact adaptive143Third141Proof294
  · exact adaptive143Third141Proof295
  · exact adaptive143Third141Proof296
  · exact adaptive143Third141Proof297
  · exact adaptive143Third141Proof298
  · exact adaptive143Third141Proof336

#print axioms adaptive143Third141Proof265

theorem adaptive143Third141Proof413 : runCachedNode 511 130431 Adaptive143Third141Node413 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130431 Adaptive143Third141Node413 = [88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 130] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive143Third141Proof414
  · exact adaptive143Third141Proof415
  · exact adaptive143Third141Proof416
  · exact adaptive143Third141Proof417
  · exact adaptive143Third141Proof418
  · exact adaptive143Third141Proof419
  · exact adaptive143Third141Proof420
  · exact adaptive143Third141Proof421
  · exact adaptive143Third141Proof422
  · exact adaptive143Third141Proof423
  · exact adaptive143Third141Proof424
  · exact adaptive143Third141Proof425
  · exact adaptive143Third141Proof426
  · exact adaptive143Third141Proof427
  · exact adaptive143Third141Proof428
  · exact adaptive143Third141Proof429
  · exact adaptive143Third141Proof430
  · exact adaptive143Third141Proof431
  · exact adaptive143Third141Proof432
  · exact adaptive143Third141Proof433
  · exact adaptive143Third141Proof434
  · exact adaptive143Third141Proof435
  · exact adaptive143Third141Proof436
  · exact adaptive143Third141Proof437
  · exact adaptive143Third141Proof438
  · exact adaptive143Third141Proof439
  · exact adaptive143Third141Proof440
  · exact adaptive143Third141Proof441
  · exact adaptive143Third141Proof442
  · exact adaptive143Third141Proof443
  · exact adaptive143Third141Proof444
  · exact adaptive143Third141Proof445
  · exact adaptive143Third141Proof446
  · exact adaptive143Third141Proof447
  · exact adaptive143Third141Proof448
  · exact adaptive143Third141Proof449
  · exact adaptive143Third141Proof450
  · exact adaptive143Third141Proof451
  · exact adaptive143Third141Proof452
  · exact adaptive143Third141Proof453
  · exact adaptive143Third141Proof454
  · exact adaptive143Third141Proof455

#print axioms adaptive143Third141Proof413

theorem adaptive143Third141Proof378 : runCachedNode 511 130431 Adaptive143Third141Node378 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130431 Adaptive143Third141Node378 = [101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 132, 134, 137, 139] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive143Third141Proof379
  · exact adaptive143Third141Proof380
  · exact adaptive143Third141Proof381
  · exact adaptive143Third141Proof382
  · exact adaptive143Third141Proof383
  · exact adaptive143Third141Proof384
  · exact adaptive143Third141Proof385
  · exact adaptive143Third141Proof386
  · exact adaptive143Third141Proof387
  · exact adaptive143Third141Proof388
  · exact adaptive143Third141Proof389
  · exact adaptive143Third141Proof390
  · exact adaptive143Third141Proof391
  · exact adaptive143Third141Proof392
  · exact adaptive143Third141Proof393
  · exact adaptive143Third141Proof394
  · exact adaptive143Third141Proof395
  · exact adaptive143Third141Proof396
  · exact adaptive143Third141Proof397
  · exact adaptive143Third141Proof398
  · exact adaptive143Third141Proof399
  · exact adaptive143Third141Proof400
  · exact adaptive143Third141Proof401
  · exact adaptive143Third141Proof402
  · exact adaptive143Third141Proof403
  · exact adaptive143Third141Proof404
  · exact adaptive143Third141Proof405
  · exact adaptive143Third141Proof406
  · exact adaptive143Third141Proof407
  · exact adaptive143Third141Proof408
  · exact adaptive143Third141Proof409
  · exact adaptive143Third141Proof410
  · exact adaptive143Third141Proof411
  · exact adaptive143Third141Proof412
  · exact adaptive143Third141Proof413

#print axioms adaptive143Third141Proof378

theorem adaptive143Third141Proof0 : runCachedNode 511 130431 Adaptive143Third141Node0 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130431 Adaptive143Third141Node0 = [110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 132, 133, 134, 135, 137, 138, 139, 140] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive143Third141Proof1
  · exact adaptive143Third141Proof2
  · exact adaptive143Third141Proof3
  · exact adaptive143Third141Proof4
  · exact adaptive143Third141Proof5
  · exact adaptive143Third141Proof6
  · exact adaptive143Third141Proof7
  · exact adaptive143Third141Proof8
  · exact adaptive143Third141Proof9
  · exact adaptive143Third141Proof10
  · exact adaptive143Third141Proof11
  · exact adaptive143Third141Proof12
  · exact adaptive143Third141Proof13
  · exact adaptive143Third141Proof14
  · exact adaptive143Third141Proof15
  · exact adaptive143Third141Proof16
  · exact adaptive143Third141Proof17
  · exact adaptive143Third141Proof18
  · exact adaptive143Third141Proof19
  · exact adaptive143Third141Proof20
  · exact adaptive143Third141Proof21
  · exact adaptive143Third141Proof22
  · exact adaptive143Third141Proof47
  · exact adaptive143Third141Proof74
  · exact adaptive143Third141Proof102
  · exact adaptive143Third141Proof131
  · exact adaptive143Third141Proof162
  · exact adaptive143Third141Proof194
  · exact adaptive143Third141Proof265
  · exact adaptive143Third141Proof378

#print axioms adaptive143Third141Proof0

end NineSeparatedSubsetSums
