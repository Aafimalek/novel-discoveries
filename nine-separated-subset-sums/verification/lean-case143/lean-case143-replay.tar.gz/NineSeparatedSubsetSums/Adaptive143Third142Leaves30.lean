import NineSeparatedSubsetSums.Adaptive143Third142State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third142Proof74 : runCachedNode 511 130584 Adaptive143Third142Node74 = false := by
  decide +kernel

#print axioms adaptive143Third142Proof74

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third142Proof219 : runCachedNode 511 130584 Adaptive143Third142Node219 = false := by
  decide +kernel

#print axioms adaptive143Third142Proof219

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third142Proof47 : runCachedNode 511 130584 Adaptive143Third142Node47 = false := by
  decide +kernel

#print axioms adaptive143Third142Proof47

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third142Proof218 : runCachedNode 511 130584 Adaptive143Third142Node218 = false := by
  decide +kernel

#print axioms adaptive143Third142Proof218

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third142Proof45 : runCachedNode 511 130584 Adaptive143Third142Node45 = false := by
  decide +kernel

#print axioms adaptive143Third142Proof45

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third142Proof217 : runCachedNode 511 130584 Adaptive143Third142Node217 = false := by
  decide +kernel

#print axioms adaptive143Third142Proof217

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third142Proof440 : runCachedNode 511 130584 Adaptive143Third142Node440 = false := by
  decide +kernel

#print axioms adaptive143Third142Proof440

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third142Proof66 : runCachedNode 511 130584 Adaptive143Third142Node66 = false := by
  decide +kernel

#print axioms adaptive143Third142Proof66

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third142Proof77 : runCachedNode 511 130584 Adaptive143Third142Node77 = false := by
  decide +kernel

#print axioms adaptive143Third142Proof77

end NineSeparatedSubsetSums
