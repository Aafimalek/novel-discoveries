import NineSeparatedSubsetSums.Adaptive143Third139State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third139Proof20 : runCachedNode 511 130096 Adaptive143Third139Node20 = false := by
  decide +kernel

#print axioms adaptive143Third139Proof20

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third139Proof183 : runCachedNode 511 130096 Adaptive143Third139Node183 = false := by
  decide +kernel

#print axioms adaptive143Third139Proof183

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third139Proof22 : runCachedNode 511 130096 Adaptive143Third139Node22 = false := by
  decide +kernel

#print axioms adaptive143Third139Proof22

end NineSeparatedSubsetSums
