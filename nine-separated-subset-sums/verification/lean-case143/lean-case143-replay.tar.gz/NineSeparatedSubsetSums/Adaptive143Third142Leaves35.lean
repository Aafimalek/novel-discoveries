import NineSeparatedSubsetSums.Adaptive143Third142State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third142Proof43 : runCachedNode 511 130584 Adaptive143Third142Node43 = false := by
  decide +kernel

#print axioms adaptive143Third142Proof43

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third142Proof158 : runCachedNode 511 130584 Adaptive143Third142Node158 = false := by
  decide +kernel

#print axioms adaptive143Third142Proof158

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third142Proof122 : runCachedNode 511 130584 Adaptive143Third142Node122 = false := by
  decide +kernel

#print axioms adaptive143Third142Proof122

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third142Proof332 : runCachedNode 511 130584 Adaptive143Third142Node332 = false := by
  decide +kernel

#print axioms adaptive143Third142Proof332

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third142Proof434 : runCachedNode 511 130584 Adaptive143Third142Node434 = false := by
  decide +kernel

#print axioms adaptive143Third142Proof434

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third142Proof96 : runCachedNode 511 130584 Adaptive143Third142Node96 = false := by
  decide +kernel

#print axioms adaptive143Third142Proof96

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third142Proof154 : runCachedNode 511 130584 Adaptive143Third142Node154 = false := by
  decide +kernel

#print axioms adaptive143Third142Proof154

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third142Proof330 : runCachedNode 511 130584 Adaptive143Third142Node330 = false := by
  decide +kernel

#print axioms adaptive143Third142Proof330

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third142Proof260 : runCachedNode 511 130584 Adaptive143Third142Node260 = false := by
  decide +kernel

#print axioms adaptive143Third142Proof260

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third142Proof301 : runCachedNode 511 130584 Adaptive143Third142Node301 = false := by
  decide +kernel

#print axioms adaptive143Third142Proof301

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third142Proof361 : runCachedNode 511 130584 Adaptive143Third142Node361 = false := by
  decide +kernel

#print axioms adaptive143Third142Proof361

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third142Proof411 : runCachedNode 511 130584 Adaptive143Third142Node411 = false := by
  decide +kernel

#print axioms adaptive143Third142Proof411

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third142Proof525 : runCachedNode 511 130584 Adaptive143Third142Node525 = false := by
  decide +kernel

#print axioms adaptive143Third142Proof525

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third142Proof157 : runCachedNode 511 130584 Adaptive143Third142Node157 = false := by
  decide +kernel

#print axioms adaptive143Third142Proof157

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third142Proof67 : runCachedNode 511 130584 Adaptive143Third142Node67 = false := by
  decide +kernel

#print axioms adaptive143Third142Proof67

end NineSeparatedSubsetSums
