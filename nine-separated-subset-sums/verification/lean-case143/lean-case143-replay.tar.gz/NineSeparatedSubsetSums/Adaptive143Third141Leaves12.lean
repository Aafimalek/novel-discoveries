import NineSeparatedSubsetSums.Adaptive143Third141State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third141Proof294 : runCachedNode 511 130431 Adaptive143Third141Node294 = false := by
  decide +kernel

#print axioms adaptive143Third141Proof294

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third141Proof455 : runCachedNode 511 130431 Adaptive143Third141Node455 = false := by
  decide +kernel

#print axioms adaptive143Third141Proof455

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third141Proof217 : runCachedNode 511 130431 Adaptive143Third141Node217 = false := by
  decide +kernel

#print axioms adaptive143Third141Proof217

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third141Proof83 : runCachedNode 511 130431 Adaptive143Third141Node83 = false := by
  decide +kernel

#print axioms adaptive143Third141Proof83

end NineSeparatedSubsetSums
