import NineSeparatedSubsetSums.Adaptive143Third142State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third142Proof103 : runCachedNode 511 130584 Adaptive143Third142Node103 = false := by
  decide +kernel

#print axioms adaptive143Third142Proof103

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third142Proof221 : runCachedNode 511 130584 Adaptive143Third142Node221 = false := by
  decide +kernel

#print axioms adaptive143Third142Proof221

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third142Proof162 : runCachedNode 511 130584 Adaptive143Third142Node162 = false := by
  decide +kernel

#print axioms adaptive143Third142Proof162

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third142Proof416 : runCachedNode 511 130584 Adaptive143Third142Node416 = false := by
  decide +kernel

#print axioms adaptive143Third142Proof416

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third142Proof359 : runCachedNode 511 130584 Adaptive143Third142Node359 = false := by
  decide +kernel

#print axioms adaptive143Third142Proof359

end NineSeparatedSubsetSums
