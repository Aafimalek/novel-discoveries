import NineSeparatedSubsetSums.Adaptive143Third142State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third142Proof374 : runCachedNode 511 130584 Adaptive143Third142Node374 = false := by
  decide +kernel

#print axioms adaptive143Third142Proof374

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third142Proof409 : runCachedNode 511 130584 Adaptive143Third142Node409 = false := by
  decide +kernel

#print axioms adaptive143Third142Proof409

end NineSeparatedSubsetSums
