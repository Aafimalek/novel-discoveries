import NineSeparatedSubsetSums.Adaptive143Third140State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third140Proof20 : runCachedNode 511 130276 Adaptive143Third140Node20 = false := by
  decide +kernel

#print axioms adaptive143Third140Proof20

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third140Proof168 : runCachedNode 511 130276 Adaptive143Third140Node168 = false := by
  decide +kernel

#print axioms adaptive143Third140Proof168

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third140Proof131 : runCachedNode 511 130276 Adaptive143Third140Node131 = false := by
  decide +kernel

#print axioms adaptive143Third140Proof131

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third140Proof25 : runCachedNode 511 130276 Adaptive143Third140Node25 = false := by
  decide +kernel

#print axioms adaptive143Third140Proof25

end NineSeparatedSubsetSums
