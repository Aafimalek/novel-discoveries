import NineSeparatedSubsetSums.Adaptive143Third111State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third111Proof0 : runCachedNode 511 112040 Adaptive143Third111Node0 = false := by
  decide +kernel

#print axioms adaptive143Third111Proof0

end NineSeparatedSubsetSums
