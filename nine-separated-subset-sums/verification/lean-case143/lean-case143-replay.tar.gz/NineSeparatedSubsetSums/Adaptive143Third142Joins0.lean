import NineSeparatedSubsetSums.Adaptive143Third142State
import NineSeparatedSubsetSums.Adaptive143Third142Leaves16
import NineSeparatedSubsetSums.Adaptive143Third142Leaves24
import NineSeparatedSubsetSums.Adaptive143Third142Leaves44
import NineSeparatedSubsetSums.Adaptive143Third142Leaves43
import NineSeparatedSubsetSums.Adaptive143Third142Leaves42
import NineSeparatedSubsetSums.Adaptive143Third142Leaves21
import NineSeparatedSubsetSums.Adaptive143Third142Leaves41
import NineSeparatedSubsetSums.Adaptive143Third142Leaves22
import NineSeparatedSubsetSums.Adaptive143Third142Leaves40
import NineSeparatedSubsetSums.Adaptive143Third142Leaves12
import NineSeparatedSubsetSums.Adaptive143Third142Leaves39
import NineSeparatedSubsetSums.Adaptive143Third142Leaves38
import NineSeparatedSubsetSums.Adaptive143Third142Leaves28
import NineSeparatedSubsetSums.Adaptive143Third142Leaves34
import NineSeparatedSubsetSums.Adaptive143Third142Leaves35
import NineSeparatedSubsetSums.Adaptive143Third142Leaves30
import NineSeparatedSubsetSums.Adaptive143Third142Leaves18
import NineSeparatedSubsetSums.Adaptive143Third142Leaves6
import NineSeparatedSubsetSums.Adaptive143Third142Leaves5
import NineSeparatedSubsetSums.Adaptive143Third142Leaves4
import NineSeparatedSubsetSums.Adaptive143Third142Leaves25
import NineSeparatedSubsetSums.Adaptive143Third142Leaves27
import NineSeparatedSubsetSums.Adaptive143Third142Leaves32
import NineSeparatedSubsetSums.Adaptive143Third142Leaves33
import NineSeparatedSubsetSums.Adaptive143Third142Leaves20
import NineSeparatedSubsetSums.Adaptive143Third142Leaves13
import NineSeparatedSubsetSums.Adaptive143Third142Leaves37
import NineSeparatedSubsetSums.Adaptive143Third142Leaves26
import NineSeparatedSubsetSums.Adaptive143Third142Leaves31
import NineSeparatedSubsetSums.Adaptive143Third142Leaves23
import NineSeparatedSubsetSums.Adaptive143Third142Leaves10
import NineSeparatedSubsetSums.Adaptive143Third142Leaves29
import NineSeparatedSubsetSums.Adaptive143Third142Leaves45
import NineSeparatedSubsetSums.Adaptive143Third142Leaves7
import NineSeparatedSubsetSums.Adaptive143Third142Leaves36
import NineSeparatedSubsetSums.Adaptive143Third142Leaves19
import NineSeparatedSubsetSums.Adaptive143Third142Leaves14
import NineSeparatedSubsetSums.Adaptive143Third142Leaves3
import NineSeparatedSubsetSums.Adaptive143Third142Leaves11
import NineSeparatedSubsetSums.Adaptive143Third142Leaves0
import NineSeparatedSubsetSums.Adaptive143Third142Leaves46
import NineSeparatedSubsetSums.Adaptive143Third142Leaves8

namespace NineSeparatedSubsetSums

theorem adaptive143Third142Proof23 : runCachedNode 511 130584 Adaptive143Third142Node23 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130584 Adaptive143Third142Node23 = [103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 127, 128, 129] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive143Third142Proof24
  · exact adaptive143Third142Proof25
  · exact adaptive143Third142Proof26
  · exact adaptive143Third142Proof27
  · exact adaptive143Third142Proof28
  · exact adaptive143Third142Proof29
  · exact adaptive143Third142Proof30
  · exact adaptive143Third142Proof31
  · exact adaptive143Third142Proof32
  · exact adaptive143Third142Proof33
  · exact adaptive143Third142Proof34
  · exact adaptive143Third142Proof35
  · exact adaptive143Third142Proof36
  · exact adaptive143Third142Proof37
  · exact adaptive143Third142Proof38
  · exact adaptive143Third142Proof39
  · exact adaptive143Third142Proof40
  · exact adaptive143Third142Proof41
  · exact adaptive143Third142Proof42
  · exact adaptive143Third142Proof43
  · exact adaptive143Third142Proof44
  · exact adaptive143Third142Proof45
  · exact adaptive143Third142Proof46
  · exact adaptive143Third142Proof47
  · exact adaptive143Third142Proof48

#print axioms adaptive143Third142Proof23

theorem adaptive143Third142Proof49 : runCachedNode 511 130584 Adaptive143Third142Node49 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130584 Adaptive143Third142Node49 = [103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 128, 129, 130] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive143Third142Proof50
  · exact adaptive143Third142Proof51
  · exact adaptive143Third142Proof52
  · exact adaptive143Third142Proof53
  · exact adaptive143Third142Proof54
  · exact adaptive143Third142Proof55
  · exact adaptive143Third142Proof56
  · exact adaptive143Third142Proof57
  · exact adaptive143Third142Proof58
  · exact adaptive143Third142Proof59
  · exact adaptive143Third142Proof60
  · exact adaptive143Third142Proof61
  · exact adaptive143Third142Proof62
  · exact adaptive143Third142Proof63
  · exact adaptive143Third142Proof64
  · exact adaptive143Third142Proof65
  · exact adaptive143Third142Proof66
  · exact adaptive143Third142Proof67
  · exact adaptive143Third142Proof68
  · exact adaptive143Third142Proof69
  · exact adaptive143Third142Proof70
  · exact adaptive143Third142Proof71
  · exact adaptive143Third142Proof72
  · exact adaptive143Third142Proof73
  · exact adaptive143Third142Proof74
  · exact adaptive143Third142Proof75

#print axioms adaptive143Third142Proof49

theorem adaptive143Third142Proof76 : runCachedNode 511 130584 Adaptive143Third142Node76 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130584 Adaptive143Third142Node76 = [103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 129, 130, 131] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive143Third142Proof77
  · exact adaptive143Third142Proof78
  · exact adaptive143Third142Proof79
  · exact adaptive143Third142Proof80
  · exact adaptive143Third142Proof81
  · exact adaptive143Third142Proof82
  · exact adaptive143Third142Proof83
  · exact adaptive143Third142Proof84
  · exact adaptive143Third142Proof85
  · exact adaptive143Third142Proof86
  · exact adaptive143Third142Proof87
  · exact adaptive143Third142Proof88
  · exact adaptive143Third142Proof89
  · exact adaptive143Third142Proof90
  · exact adaptive143Third142Proof91
  · exact adaptive143Third142Proof92
  · exact adaptive143Third142Proof93
  · exact adaptive143Third142Proof94
  · exact adaptive143Third142Proof95
  · exact adaptive143Third142Proof96
  · exact adaptive143Third142Proof97
  · exact adaptive143Third142Proof98
  · exact adaptive143Third142Proof99
  · exact adaptive143Third142Proof100
  · exact adaptive143Third142Proof101
  · exact adaptive143Third142Proof102
  · exact adaptive143Third142Proof103

#print axioms adaptive143Third142Proof76

theorem adaptive143Third142Proof104 : runCachedNode 511 130584 Adaptive143Third142Node104 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130584 Adaptive143Third142Node104 = [103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 130, 131, 132] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive143Third142Proof105
  · exact adaptive143Third142Proof106
  · exact adaptive143Third142Proof107
  · exact adaptive143Third142Proof108
  · exact adaptive143Third142Proof109
  · exact adaptive143Third142Proof110
  · exact adaptive143Third142Proof111
  · exact adaptive143Third142Proof112
  · exact adaptive143Third142Proof113
  · exact adaptive143Third142Proof114
  · exact adaptive143Third142Proof115
  · exact adaptive143Third142Proof116
  · exact adaptive143Third142Proof117
  · exact adaptive143Third142Proof118
  · exact adaptive143Third142Proof119
  · exact adaptive143Third142Proof120
  · exact adaptive143Third142Proof121
  · exact adaptive143Third142Proof122
  · exact adaptive143Third142Proof123
  · exact adaptive143Third142Proof124
  · exact adaptive143Third142Proof125
  · exact adaptive143Third142Proof126
  · exact adaptive143Third142Proof127
  · exact adaptive143Third142Proof128
  · exact adaptive143Third142Proof129
  · exact adaptive143Third142Proof130
  · exact adaptive143Third142Proof131
  · exact adaptive143Third142Proof132

#print axioms adaptive143Third142Proof104

theorem adaptive143Third142Proof133 : runCachedNode 511 130584 Adaptive143Third142Node133 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130584 Adaptive143Third142Node133 = [102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 131, 132, 133] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive143Third142Proof134
  · exact adaptive143Third142Proof135
  · exact adaptive143Third142Proof136
  · exact adaptive143Third142Proof137
  · exact adaptive143Third142Proof138
  · exact adaptive143Third142Proof139
  · exact adaptive143Third142Proof140
  · exact adaptive143Third142Proof141
  · exact adaptive143Third142Proof142
  · exact adaptive143Third142Proof143
  · exact adaptive143Third142Proof144
  · exact adaptive143Third142Proof145
  · exact adaptive143Third142Proof146
  · exact adaptive143Third142Proof147
  · exact adaptive143Third142Proof148
  · exact adaptive143Third142Proof149
  · exact adaptive143Third142Proof150
  · exact adaptive143Third142Proof151
  · exact adaptive143Third142Proof152
  · exact adaptive143Third142Proof153
  · exact adaptive143Third142Proof154
  · exact adaptive143Third142Proof155
  · exact adaptive143Third142Proof156
  · exact adaptive143Third142Proof157
  · exact adaptive143Third142Proof158
  · exact adaptive143Third142Proof159
  · exact adaptive143Third142Proof160
  · exact adaptive143Third142Proof161
  · exact adaptive143Third142Proof162
  · exact adaptive143Third142Proof163

#print axioms adaptive143Third142Proof133

theorem adaptive143Third142Proof164 : runCachedNode 511 130584 Adaptive143Third142Node164 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130584 Adaptive143Third142Node164 = [102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 132, 133, 134] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive143Third142Proof165
  · exact adaptive143Third142Proof166
  · exact adaptive143Third142Proof167
  · exact adaptive143Third142Proof168
  · exact adaptive143Third142Proof169
  · exact adaptive143Third142Proof170
  · exact adaptive143Third142Proof171
  · exact adaptive143Third142Proof172
  · exact adaptive143Third142Proof173
  · exact adaptive143Third142Proof174
  · exact adaptive143Third142Proof175
  · exact adaptive143Third142Proof176
  · exact adaptive143Third142Proof177
  · exact adaptive143Third142Proof178
  · exact adaptive143Third142Proof179
  · exact adaptive143Third142Proof180
  · exact adaptive143Third142Proof181
  · exact adaptive143Third142Proof182
  · exact adaptive143Third142Proof183
  · exact adaptive143Third142Proof184
  · exact adaptive143Third142Proof185
  · exact adaptive143Third142Proof186
  · exact adaptive143Third142Proof187
  · exact adaptive143Third142Proof188
  · exact adaptive143Third142Proof189
  · exact adaptive143Third142Proof190
  · exact adaptive143Third142Proof191
  · exact adaptive143Third142Proof192
  · exact adaptive143Third142Proof193
  · exact adaptive143Third142Proof194
  · exact adaptive143Third142Proof195

#print axioms adaptive143Third142Proof164

theorem adaptive143Third142Proof227 : runCachedNode 511 130584 Adaptive143Third142Node227 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130584 Adaptive143Third142Node227 = [90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 126, 127, 131] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive143Third142Proof228
  · exact adaptive143Third142Proof229
  · exact adaptive143Third142Proof230
  · exact adaptive143Third142Proof231
  · exact adaptive143Third142Proof232
  · exact adaptive143Third142Proof233
  · exact adaptive143Third142Proof234
  · exact adaptive143Third142Proof235
  · exact adaptive143Third142Proof236
  · exact adaptive143Third142Proof237
  · exact adaptive143Third142Proof238
  · exact adaptive143Third142Proof239
  · exact adaptive143Third142Proof240
  · exact adaptive143Third142Proof241
  · exact adaptive143Third142Proof242
  · exact adaptive143Third142Proof243
  · exact adaptive143Third142Proof244
  · exact adaptive143Third142Proof245
  · exact adaptive143Third142Proof246
  · exact adaptive143Third142Proof247
  · exact adaptive143Third142Proof248
  · exact adaptive143Third142Proof249
  · exact adaptive143Third142Proof250
  · exact adaptive143Third142Proof251
  · exact adaptive143Third142Proof252
  · exact adaptive143Third142Proof253
  · exact adaptive143Third142Proof254
  · exact adaptive143Third142Proof255
  · exact adaptive143Third142Proof256
  · exact adaptive143Third142Proof257
  · exact adaptive143Third142Proof258
  · exact adaptive143Third142Proof259
  · exact adaptive143Third142Proof260
  · exact adaptive143Third142Proof261
  · exact adaptive143Third142Proof262
  · exact adaptive143Third142Proof263

#print axioms adaptive143Third142Proof227

theorem adaptive143Third142Proof265 : runCachedNode 511 130584 Adaptive143Third142Node265 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130584 Adaptive143Third142Node265 = [89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 128, 129, 134] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive143Third142Proof266
  · exact adaptive143Third142Proof267
  · exact adaptive143Third142Proof268
  · exact adaptive143Third142Proof269
  · exact adaptive143Third142Proof270
  · exact adaptive143Third142Proof271
  · exact adaptive143Third142Proof272
  · exact adaptive143Third142Proof273
  · exact adaptive143Third142Proof274
  · exact adaptive143Third142Proof275
  · exact adaptive143Third142Proof276
  · exact adaptive143Third142Proof277
  · exact adaptive143Third142Proof278
  · exact adaptive143Third142Proof279
  · exact adaptive143Third142Proof280
  · exact adaptive143Third142Proof281
  · exact adaptive143Third142Proof282
  · exact adaptive143Third142Proof283
  · exact adaptive143Third142Proof284
  · exact adaptive143Third142Proof285
  · exact adaptive143Third142Proof286
  · exact adaptive143Third142Proof287
  · exact adaptive143Third142Proof288
  · exact adaptive143Third142Proof289
  · exact adaptive143Third142Proof290
  · exact adaptive143Third142Proof291
  · exact adaptive143Third142Proof292
  · exact adaptive143Third142Proof293
  · exact adaptive143Third142Proof294
  · exact adaptive143Third142Proof295
  · exact adaptive143Third142Proof296
  · exact adaptive143Third142Proof297
  · exact adaptive143Third142Proof298
  · exact adaptive143Third142Proof299
  · exact adaptive143Third142Proof300
  · exact adaptive143Third142Proof301
  · exact adaptive143Third142Proof302
  · exact adaptive143Third142Proof303
  · exact adaptive143Third142Proof304

#print axioms adaptive143Third142Proof265

end NineSeparatedSubsetSums
