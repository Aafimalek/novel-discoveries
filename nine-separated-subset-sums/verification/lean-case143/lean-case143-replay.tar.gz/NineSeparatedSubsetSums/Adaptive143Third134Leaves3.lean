import NineSeparatedSubsetSums.Adaptive143Third134State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third134Proof20 : runCachedNode 511 129375 Adaptive143Third134Node20 = false := by
  decide +kernel

#print axioms adaptive143Third134Proof20

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third134Proof15 : runCachedNode 511 129375 Adaptive143Third134Node15 = false := by
  decide +kernel

#print axioms adaptive143Third134Proof15

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third134Proof9 : runCachedNode 511 129375 Adaptive143Third134Node9 = false := by
  decide +kernel

#print axioms adaptive143Third134Proof9

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third134Proof4 : runCachedNode 511 129375 Adaptive143Third134Node4 = false := by
  decide +kernel

#print axioms adaptive143Third134Proof4

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third134Proof2 : runCachedNode 511 129375 Adaptive143Third134Node2 = false := by
  decide +kernel

#print axioms adaptive143Third134Proof2

end NineSeparatedSubsetSums
