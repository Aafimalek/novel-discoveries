import NineSeparatedSubsetSums.Adaptive143Third129State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third129Proof15 : runCachedNode 511 128295 Adaptive143Third129Node15 = false := by
  decide +kernel

#print axioms adaptive143Third129Proof15

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third129Proof14 : runCachedNode 511 128295 Adaptive143Third129Node14 = false := by
  decide +kernel

#print axioms adaptive143Third129Proof14

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third129Proof12 : runCachedNode 511 128295 Adaptive143Third129Node12 = false := by
  decide +kernel

#print axioms adaptive143Third129Proof12

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third129Proof10 : runCachedNode 511 128295 Adaptive143Third129Node10 = false := by
  decide +kernel

#print axioms adaptive143Third129Proof10

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third129Proof11 : runCachedNode 511 128295 Adaptive143Third129Node11 = false := by
  decide +kernel

#print axioms adaptive143Third129Proof11

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third129Proof9 : runCachedNode 511 128295 Adaptive143Third129Node9 = false := by
  decide +kernel

#print axioms adaptive143Third129Proof9

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third129Proof8 : runCachedNode 511 128295 Adaptive143Third129Node8 = false := by
  decide +kernel

#print axioms adaptive143Third129Proof8

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third129Proof7 : runCachedNode 511 128295 Adaptive143Third129Node7 = false := by
  decide +kernel

#print axioms adaptive143Third129Proof7

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third129Proof6 : runCachedNode 511 128295 Adaptive143Third129Node6 = false := by
  decide +kernel

#print axioms adaptive143Third129Proof6

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third129Proof5 : runCachedNode 511 128295 Adaptive143Third129Node5 = false := by
  decide +kernel

#print axioms adaptive143Third129Proof5

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third129Proof4 : runCachedNode 511 128295 Adaptive143Third129Node4 = false := by
  decide +kernel

#print axioms adaptive143Third129Proof4

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third129Proof3 : runCachedNode 511 128295 Adaptive143Third129Node3 = false := by
  decide +kernel

#print axioms adaptive143Third129Proof3

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third129Proof2 : runCachedNode 511 128295 Adaptive143Third129Node2 = false := by
  decide +kernel

#print axioms adaptive143Third129Proof2

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third129Proof1 : runCachedNode 511 128295 Adaptive143Third129Node1 = false := by
  decide +kernel

#print axioms adaptive143Third129Proof1

end NineSeparatedSubsetSums
