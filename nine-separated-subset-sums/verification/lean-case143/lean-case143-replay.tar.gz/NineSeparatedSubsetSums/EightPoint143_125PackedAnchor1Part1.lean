import NineSeparatedSubsetSums.EightPoint143_125PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint143_125PackedAnchor1Part1 :
    ∀ j : Fin 120, 2365858 ≤ FourPointNumeric.octPackedCharge 143 125 20 packedOct143_125_1
      (2*((j.val : Int)+120)+1) := by decide +kernel

end NineSeparatedSubsetSums
