import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive143Third119Node0 : CachedSearchNode :=
  ⟨4, 118, computeCenteredMask [148,143,119], 410, 56514⟩

end NineSeparatedSubsetSums
