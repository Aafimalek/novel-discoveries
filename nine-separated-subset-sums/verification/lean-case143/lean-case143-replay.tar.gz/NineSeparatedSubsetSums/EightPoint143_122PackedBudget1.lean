import NineSeparatedSubsetSums.EightPoint143_122PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct143_122_1_budget :
    FourPointNumeric.packedBudget 20 packedOct143_122_1 272 = 83168572 := by decide +kernel

#print axioms packedOct143_122_1_budget

end NineSeparatedSubsetSums
