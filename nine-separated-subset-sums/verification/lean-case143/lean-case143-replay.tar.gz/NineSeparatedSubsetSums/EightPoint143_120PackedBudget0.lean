import NineSeparatedSubsetSums.EightPoint143_120PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct143_120_0_budget :
    FourPointNumeric.packedBudget 20 packedOct143_120_0 269 = 86886391 := by decide +kernel

#print axioms packedOct143_120_0_budget

end NineSeparatedSubsetSums
