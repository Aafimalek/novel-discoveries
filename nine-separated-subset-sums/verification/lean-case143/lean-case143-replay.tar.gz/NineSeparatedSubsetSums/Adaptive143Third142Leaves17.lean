import NineSeparatedSubsetSums.Adaptive143Third142State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third142Proof19 : runCachedNode 511 130584 Adaptive143Third142Node19 = false := by
  decide +kernel

#print axioms adaptive143Third142Proof19

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third142Proof540 : runCachedNode 511 130584 Adaptive143Third142Node540 = false := by
  decide +kernel

#print axioms adaptive143Third142Proof540

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third142Proof14 : runCachedNode 511 130584 Adaptive143Third142Node14 = false := by
  decide +kernel

#print axioms adaptive143Third142Proof14

end NineSeparatedSubsetSums
