import NineSeparatedSubsetSums.Adaptive143Third131State
import NineSeparatedSubsetSums.Adaptive143Third131Leaves0
import NineSeparatedSubsetSums.Adaptive143Third131Leaves2
import NineSeparatedSubsetSums.Adaptive143Third131Leaves1

namespace NineSeparatedSubsetSums

theorem adaptive143Third131Proof0 : runCachedNode 511 128821 Adaptive143Third131Node0 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 128821 Adaptive143Third131Node0 = [110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 127, 128, 129, 130] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive143Third131Proof1
  · exact adaptive143Third131Proof2
  · exact adaptive143Third131Proof3
  · exact adaptive143Third131Proof4
  · exact adaptive143Third131Proof5
  · exact adaptive143Third131Proof6
  · exact adaptive143Third131Proof7
  · exact adaptive143Third131Proof8
  · exact adaptive143Third131Proof9
  · exact adaptive143Third131Proof10
  · exact adaptive143Third131Proof11
  · exact adaptive143Third131Proof12
  · exact adaptive143Third131Proof13
  · exact adaptive143Third131Proof14
  · exact adaptive143Third131Proof15
  · exact adaptive143Third131Proof16
  · exact adaptive143Third131Proof17
  · exact adaptive143Third131Proof18
  · exact adaptive143Third131Proof19
  · exact adaptive143Third131Proof20

#print axioms adaptive143Third131Proof0

end NineSeparatedSubsetSums
