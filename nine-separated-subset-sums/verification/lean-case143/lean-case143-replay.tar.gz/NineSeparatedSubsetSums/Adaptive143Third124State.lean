import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive143Third124Node0 : CachedSearchNode :=
  ⟨4, 123, computeCenteredMask [148,143,124], 415, 57729⟩

end NineSeparatedSubsetSums
