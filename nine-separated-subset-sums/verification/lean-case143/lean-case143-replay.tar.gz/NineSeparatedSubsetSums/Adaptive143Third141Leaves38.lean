import NineSeparatedSubsetSums.Adaptive143Third141State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third141Proof419 : runCachedNode 511 130431 Adaptive143Third141Node419 = false := by
  decide +kernel

#print axioms adaptive143Third141Proof419

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third141Proof420 : runCachedNode 511 130431 Adaptive143Third141Node420 = false := by
  decide +kernel

#print axioms adaptive143Third141Proof420

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third141Proof421 : runCachedNode 511 130431 Adaptive143Third141Node421 = false := by
  decide +kernel

#print axioms adaptive143Third141Proof421

end NineSeparatedSubsetSums
