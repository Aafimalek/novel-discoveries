import NineSeparatedSubsetSums.Adaptive143Third128State
import NineSeparatedSubsetSums.Adaptive143Third128Leaves0
import NineSeparatedSubsetSums.Adaptive143Third128Leaves1

namespace NineSeparatedSubsetSums

theorem adaptive143Third128Proof0 : runCachedNode 511 128085 Adaptive143Third128Node0 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 128085 Adaptive143Third128Node0 = [110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 124, 125, 126, 127] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive143Third128Proof1
  · exact adaptive143Third128Proof2
  · exact adaptive143Third128Proof3
  · exact adaptive143Third128Proof4
  · exact adaptive143Third128Proof5
  · exact adaptive143Third128Proof6
  · exact adaptive143Third128Proof7
  · exact adaptive143Third128Proof8
  · exact adaptive143Third128Proof9
  · exact adaptive143Third128Proof10
  · exact adaptive143Third128Proof11
  · exact adaptive143Third128Proof12
  · exact adaptive143Third128Proof13
  · exact adaptive143Third128Proof14
  · exact adaptive143Third128Proof15
  · exact adaptive143Third128Proof16
  · exact adaptive143Third128Proof17

#print axioms adaptive143Third128Proof0

end NineSeparatedSubsetSums
