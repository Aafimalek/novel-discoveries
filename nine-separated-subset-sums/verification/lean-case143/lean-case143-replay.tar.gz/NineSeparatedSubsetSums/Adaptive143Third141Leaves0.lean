import NineSeparatedSubsetSums.Adaptive143Third141State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third141Proof412 : runCachedNode 511 130431 Adaptive143Third141Node412 = false := by
  decide +kernel

#print axioms adaptive143Third141Proof412

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third141Proof156 : runCachedNode 511 130431 Adaptive143Third141Node156 = false := by
  decide +kernel

#print axioms adaptive143Third141Proof156

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third141Proof50 : runCachedNode 511 130431 Adaptive143Third141Node50 = false := by
  decide +kernel

#print axioms adaptive143Third141Proof50

end NineSeparatedSubsetSums
