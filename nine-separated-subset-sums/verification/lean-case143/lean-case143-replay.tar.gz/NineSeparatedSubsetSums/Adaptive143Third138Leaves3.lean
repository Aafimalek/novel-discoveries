import NineSeparatedSubsetSums.Adaptive143Third138State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third138Proof265 : runCachedNode 511 129927 Adaptive143Third138Node265 = false := by
  decide +kernel

#print axioms adaptive143Third138Proof265

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third138Proof140 : runCachedNode 511 129927 Adaptive143Third138Node140 = false := by
  decide +kernel

#print axioms adaptive143Third138Proof140

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third138Proof76 : runCachedNode 511 129927 Adaptive143Third138Node76 = false := by
  decide +kernel

#print axioms adaptive143Third138Proof76

end NineSeparatedSubsetSums
