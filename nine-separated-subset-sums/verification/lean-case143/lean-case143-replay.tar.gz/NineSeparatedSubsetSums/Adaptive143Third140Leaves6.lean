import NineSeparatedSubsetSums.Adaptive143Third140State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third140Proof105 : runCachedNode 511 130276 Adaptive143Third140Node105 = false := by
  decide +kernel

#print axioms adaptive143Third140Proof105

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third140Proof239 : runCachedNode 511 130276 Adaptive143Third140Node239 = false := by
  decide +kernel

#print axioms adaptive143Third140Proof239

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third140Proof123 : runCachedNode 511 130276 Adaptive143Third140Node123 = false := by
  decide +kernel

#print axioms adaptive143Third140Proof123

end NineSeparatedSubsetSums
