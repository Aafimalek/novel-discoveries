import NineSeparatedSubsetSums.Adaptive143Third142State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third142Proof339 : runCachedNode 511 130584 Adaptive143Third142Node339 = false := by
  decide +kernel

#print axioms adaptive143Third142Proof339

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third142Proof370 : runCachedNode 511 130584 Adaptive143Third142Node370 = false := by
  decide +kernel

#print axioms adaptive143Third142Proof370

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third142Proof1 : runCachedNode 511 130584 Adaptive143Third142Node1 = false := by
  decide +kernel

#print axioms adaptive143Third142Proof1

end NineSeparatedSubsetSums
