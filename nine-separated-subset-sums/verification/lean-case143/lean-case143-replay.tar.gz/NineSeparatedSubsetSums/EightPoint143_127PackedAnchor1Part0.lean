import NineSeparatedSubsetSums.EightPoint143_127PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint143_127PackedAnchor1Part0 :
    ∀ j : Fin 120, 2378323 ≤ FourPointNumeric.octPackedCharge 143 127 20 packedOct143_127_1
      (2*((j.val : Int)+0)+1) := by decide +kernel

end NineSeparatedSubsetSums
