import NineSeparatedSubsetSums.Adaptive143Third140State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third140Proof48 : runCachedNode 511 130276 Adaptive143Third140Node48 = false := by
  decide +kernel

#print axioms adaptive143Third140Proof48

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third140Proof77 : runCachedNode 511 130276 Adaptive143Third140Node77 = false := by
  decide +kernel

#print axioms adaptive143Third140Proof77

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third140Proof104 : runCachedNode 511 130276 Adaptive143Third140Node104 = false := by
  decide +kernel

#print axioms adaptive143Third140Proof104

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third140Proof262 : runCachedNode 511 130276 Adaptive143Third140Node262 = false := by
  decide +kernel

#print axioms adaptive143Third140Proof262

end NineSeparatedSubsetSums
