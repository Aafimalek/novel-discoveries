import NineSeparatedSubsetSums.EightPoint143_121PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct143_121_1_budget :
    FourPointNumeric.packedBudget 20 packedOct143_121_1 276 = 82254656 := by decide +kernel

#print axioms packedOct143_121_1_budget

end NineSeparatedSubsetSums
