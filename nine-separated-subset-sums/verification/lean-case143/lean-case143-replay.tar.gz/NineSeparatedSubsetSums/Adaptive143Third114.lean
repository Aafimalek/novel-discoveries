import NineSeparatedSubsetSums.Adaptive143Third114Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint143Checked

namespace NineSeparatedSubsetSums


theorem adaptive143Third114 : NoDescendingTailAfterThird 143 114 :=
  noDescendingThirdTail_of_cached 143 114 112040 (fun t ht nd => max148_second143_fourPoint_moment_bound (114::t) (by simp [ht]) nd) adaptive143Third114Proof0

#print axioms adaptive143Third114

end NineSeparatedSubsetSums
