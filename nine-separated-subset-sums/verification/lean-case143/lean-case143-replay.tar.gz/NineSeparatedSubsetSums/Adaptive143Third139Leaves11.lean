import NineSeparatedSubsetSums.Adaptive143Third139State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third139Proof181 : runCachedNode 511 130096 Adaptive143Third139Node181 = false := by
  decide +kernel

#print axioms adaptive143Third139Proof181

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third139Proof124 : runCachedNode 511 130096 Adaptive143Third139Node124 = false := by
  decide +kernel

#print axioms adaptive143Third139Proof124

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third139Proof17 : runCachedNode 511 130096 Adaptive143Third139Node17 = false := by
  decide +kernel

#print axioms adaptive143Third139Proof17

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third139Proof232 : runCachedNode 511 130096 Adaptive143Third139Node232 = false := by
  decide +kernel

#print axioms adaptive143Third139Proof232

end NineSeparatedSubsetSums
