import NineSeparatedSubsetSums.EightPoint143_117PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint143_117PackedAnchor1Part1 :
    ∀ j : Fin 120, 2382998 ≤ FourPointNumeric.octPackedCharge 143 117 20 packedOct143_117_1
      (2*((j.val : Int)+120)+1) := by decide +kernel

end NineSeparatedSubsetSums
