import NineSeparatedSubsetSums.Adaptive143Third137State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third137Proof18 : runCachedNode 511 129784 Adaptive143Third137Node18 = false := by
  decide +kernel

#print axioms adaptive143Third137Proof18

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third137Proof159 : runCachedNode 511 129784 Adaptive143Third137Node159 = false := by
  decide +kernel

#print axioms adaptive143Third137Proof159

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third137Proof97 : runCachedNode 511 129784 Adaptive143Third137Node97 = false := by
  decide +kernel

#print axioms adaptive143Third137Proof97

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third137Proof65 : runCachedNode 511 129784 Adaptive143Third137Node65 = false := by
  decide +kernel

#print axioms adaptive143Third137Proof65

end NineSeparatedSubsetSums
