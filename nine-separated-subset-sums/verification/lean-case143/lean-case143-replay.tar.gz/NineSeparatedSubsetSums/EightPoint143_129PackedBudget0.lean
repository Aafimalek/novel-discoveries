import NineSeparatedSubsetSums.EightPoint143_129PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct143_129_0_budget :
    FourPointNumeric.packedBudget 20 packedOct143_129_0 431 = 87779216 := by decide +kernel

#print axioms packedOct143_129_0_budget

end NineSeparatedSubsetSums
