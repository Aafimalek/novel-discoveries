import NineSeparatedSubsetSums.Adaptive143Third141State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third141Proof371 : runCachedNode 511 130431 Adaptive143Third141Node371 = false := by
  decide +kernel

#print axioms adaptive143Third141Proof371

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third141Proof372 : runCachedNode 511 130431 Adaptive143Third141Node372 = false := by
  decide +kernel

#print axioms adaptive143Third141Proof372

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third141Proof153 : runCachedNode 511 130431 Adaptive143Third141Node153 = false := by
  decide +kernel

#print axioms adaptive143Third141Proof153

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third141Proof119 : runCachedNode 511 130431 Adaptive143Third141Node119 = false := by
  decide +kernel

#print axioms adaptive143Third141Proof119

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third141Proof184 : runCachedNode 511 130431 Adaptive143Third141Node184 = false := by
  decide +kernel

#print axioms adaptive143Third141Proof184

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third141Proof404 : runCachedNode 511 130431 Adaptive143Third141Node404 = false := by
  decide +kernel

#print axioms adaptive143Third141Proof404

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third141Proof118 : runCachedNode 511 130431 Adaptive143Third141Node118 = false := by
  decide +kernel

#print axioms adaptive143Third141Proof118

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third141Proof283 : runCachedNode 511 130431 Adaptive143Third141Node283 = false := by
  decide +kernel

#print axioms adaptive143Third141Proof283

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third141Proof331 : runCachedNode 511 130431 Adaptive143Third141Node331 = false := by
  decide +kernel

#print axioms adaptive143Third141Proof331

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third141Proof38 : runCachedNode 511 130431 Adaptive143Third141Node38 = false := by
  decide +kernel

#print axioms adaptive143Third141Proof38

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third141Proof211 : runCachedNode 511 130431 Adaptive143Third141Node211 = false := by
  decide +kernel

#print axioms adaptive143Third141Proof211

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third141Proof259 : runCachedNode 511 130431 Adaptive143Third141Node259 = false := by
  decide +kernel

#print axioms adaptive143Third141Proof259

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third141Proof66 : runCachedNode 511 130431 Adaptive143Third141Node66 = false := by
  decide +kernel

#print axioms adaptive143Third141Proof66

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third141Proof210 : runCachedNode 511 130431 Adaptive143Third141Node210 = false := by
  decide +kernel

#print axioms adaptive143Third141Proof210

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third141Proof282 : runCachedNode 511 130431 Adaptive143Third141Node282 = false := by
  decide +kernel

#print axioms adaptive143Third141Proof282

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third141Proof39 : runCachedNode 511 130431 Adaptive143Third141Node39 = false := by
  decide +kernel

#print axioms adaptive143Third141Proof39

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third141Proof116 : runCachedNode 511 130431 Adaptive143Third141Node116 = false := by
  decide +kernel

#print axioms adaptive143Third141Proof116

end NineSeparatedSubsetSums
