import NineSeparatedSubsetSums.Adaptive143Third140State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third140Proof192 : runCachedNode 511 130276 Adaptive143Third140Node192 = false := by
  decide +kernel

#print axioms adaptive143Third140Proof192

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third140Proof42 : runCachedNode 511 130276 Adaptive143Third140Node42 = false := by
  decide +kernel

#print axioms adaptive143Third140Proof42

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third140Proof160 : runCachedNode 511 130276 Adaptive143Third140Node160 = false := by
  decide +kernel

#print axioms adaptive143Third140Proof160

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third140Proof135 : runCachedNode 511 130276 Adaptive143Third140Node135 = false := by
  decide +kernel

#print axioms adaptive143Third140Proof135

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third140Proof191 : runCachedNode 511 130276 Adaptive143Third140Node191 = false := by
  decide +kernel

#print axioms adaptive143Third140Proof191

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third140Proof277 : runCachedNode 511 130276 Adaptive143Third140Node277 = false := by
  decide +kernel

#print axioms adaptive143Third140Proof277

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third140Proof74 : runCachedNode 511 130276 Adaptive143Third140Node74 = false := by
  decide +kernel

#print axioms adaptive143Third140Proof74

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third140Proof154 : runCachedNode 511 130276 Adaptive143Third140Node154 = false := by
  decide +kernel

#print axioms adaptive143Third140Proof154

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third140Proof52 : runCachedNode 511 130276 Adaptive143Third140Node52 = false := by
  decide +kernel

#print axioms adaptive143Third140Proof52

end NineSeparatedSubsetSums
