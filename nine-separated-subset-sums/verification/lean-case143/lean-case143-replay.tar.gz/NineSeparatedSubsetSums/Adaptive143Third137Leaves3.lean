import NineSeparatedSubsetSums.Adaptive143Third137State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third137Proof19 : runCachedNode 511 129784 Adaptive143Third137Node19 = false := by
  decide +kernel

#print axioms adaptive143Third137Proof19

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third137Proof46 : runCachedNode 511 129784 Adaptive143Third137Node46 = false := by
  decide +kernel

#print axioms adaptive143Third137Proof46

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third137Proof145 : runCachedNode 511 129784 Adaptive143Third137Node145 = false := by
  decide +kernel

#print axioms adaptive143Third137Proof145

end NineSeparatedSubsetSums
