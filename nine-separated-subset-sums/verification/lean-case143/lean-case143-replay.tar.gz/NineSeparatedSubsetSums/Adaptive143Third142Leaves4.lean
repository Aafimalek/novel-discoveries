import NineSeparatedSubsetSums.Adaptive143Third142State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third142Proof22 : runCachedNode 511 130584 Adaptive143Third142Node22 = false := by
  decide +kernel

#print axioms adaptive143Third142Proof22

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third142Proof187 : runCachedNode 511 130584 Adaptive143Third142Node187 = false := by
  decide +kernel

#print axioms adaptive143Third142Proof187

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third142Proof57 : runCachedNode 511 130584 Adaptive143Third142Node57 = false := by
  decide +kernel

#print axioms adaptive143Third142Proof57

end NineSeparatedSubsetSums
