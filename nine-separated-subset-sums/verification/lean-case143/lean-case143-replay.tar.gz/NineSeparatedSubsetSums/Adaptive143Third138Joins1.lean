import NineSeparatedSubsetSums.Adaptive143Third138State
import NineSeparatedSubsetSums.Adaptive143Third138Leaves1
import NineSeparatedSubsetSums.Adaptive143Third138Leaves32
import NineSeparatedSubsetSums.Adaptive143Third138Leaves31
import NineSeparatedSubsetSums.Adaptive143Third138Leaves30
import NineSeparatedSubsetSums.Adaptive143Third138Leaves11
import NineSeparatedSubsetSums.Adaptive143Third138Leaves29
import NineSeparatedSubsetSums.Adaptive143Third138Leaves28
import NineSeparatedSubsetSums.Adaptive143Third138Leaves27
import NineSeparatedSubsetSums.Adaptive143Third138Leaves26
import NineSeparatedSubsetSums.Adaptive143Third138Leaves22
import NineSeparatedSubsetSums.Adaptive143Third138Leaves24
import NineSeparatedSubsetSums.Adaptive143Third138Leaves23
import NineSeparatedSubsetSums.Adaptive143Third138Leaves18
import NineSeparatedSubsetSums.Adaptive143Third138Leaves21
import NineSeparatedSubsetSums.Adaptive143Third138Leaves19
import NineSeparatedSubsetSums.Adaptive143Third138Leaves6
import NineSeparatedSubsetSums.Adaptive143Third138Leaves12
import NineSeparatedSubsetSums.Adaptive143Third138Leaves3
import NineSeparatedSubsetSums.Adaptive143Third138Leaves13
import NineSeparatedSubsetSums.Adaptive143Third138Leaves20
import NineSeparatedSubsetSums.Adaptive143Third138Leaves5
import NineSeparatedSubsetSums.Adaptive143Third138Leaves17
import NineSeparatedSubsetSums.Adaptive143Third138Leaves10
import NineSeparatedSubsetSums.Adaptive143Third138Leaves15
import NineSeparatedSubsetSums.Adaptive143Third138Leaves7
import NineSeparatedSubsetSums.Adaptive143Third138Leaves4
import NineSeparatedSubsetSums.Adaptive143Third138Joins0

namespace NineSeparatedSubsetSums

theorem adaptive143Third138Proof233 : runCachedNode 511 129927 Adaptive143Third138Node233 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 129927 Adaptive143Third138Node233 = [102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 128, 129, 130, 131, 134, 135, 136] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive143Third138Proof234
  · exact adaptive143Third138Proof235
  · exact adaptive143Third138Proof236
  · exact adaptive143Third138Proof237
  · exact adaptive143Third138Proof238
  · exact adaptive143Third138Proof239
  · exact adaptive143Third138Proof240
  · exact adaptive143Third138Proof241
  · exact adaptive143Third138Proof242
  · exact adaptive143Third138Proof243
  · exact adaptive143Third138Proof244
  · exact adaptive143Third138Proof245
  · exact adaptive143Third138Proof246
  · exact adaptive143Third138Proof247
  · exact adaptive143Third138Proof248
  · exact adaptive143Third138Proof249
  · exact adaptive143Third138Proof250
  · exact adaptive143Third138Proof251
  · exact adaptive143Third138Proof252
  · exact adaptive143Third138Proof253
  · exact adaptive143Third138Proof254
  · exact adaptive143Third138Proof255
  · exact adaptive143Third138Proof256
  · exact adaptive143Third138Proof257
  · exact adaptive143Third138Proof258
  · exact adaptive143Third138Proof259
  · exact adaptive143Third138Proof260
  · exact adaptive143Third138Proof261
  · exact adaptive143Third138Proof262
  · exact adaptive143Third138Proof263
  · exact adaptive143Third138Proof264
  · exact adaptive143Third138Proof265

#print axioms adaptive143Third138Proof233

theorem adaptive143Third138Proof0 : runCachedNode 511 129927 Adaptive143Third138Node0 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 129927 Adaptive143Third138Node0 = [110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 132, 134, 135, 136, 137] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive143Third138Proof1
  · exact adaptive143Third138Proof2
  · exact adaptive143Third138Proof3
  · exact adaptive143Third138Proof4
  · exact adaptive143Third138Proof5
  · exact adaptive143Third138Proof6
  · exact adaptive143Third138Proof7
  · exact adaptive143Third138Proof8
  · exact adaptive143Third138Proof9
  · exact adaptive143Third138Proof10
  · exact adaptive143Third138Proof11
  · exact adaptive143Third138Proof12
  · exact adaptive143Third138Proof13
  · exact adaptive143Third138Proof14
  · exact adaptive143Third138Proof15
  · exact adaptive143Third138Proof16
  · exact adaptive143Third138Proof17
  · exact adaptive143Third138Proof18
  · exact adaptive143Third138Proof19
  · exact adaptive143Third138Proof41
  · exact adaptive143Third138Proof65
  · exact adaptive143Third138Proof90
  · exact adaptive143Third138Proof116
  · exact adaptive143Third138Proof143
  · exact adaptive143Third138Proof172
  · exact adaptive143Third138Proof202
  · exact adaptive143Third138Proof233

#print axioms adaptive143Third138Proof0

end NineSeparatedSubsetSums
