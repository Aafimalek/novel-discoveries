import NineSeparatedSubsetSums.Adaptive143Third142State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third142Proof437 : runCachedNode 511 130584 Adaptive143Third142Node437 = false := by
  decide +kernel

#print axioms adaptive143Third142Proof437

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third142Proof533 : runCachedNode 511 130584 Adaptive143Third142Node533 = false := by
  decide +kernel

#print axioms adaptive143Third142Proof533

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third142Proof69 : runCachedNode 511 130584 Adaptive143Third142Node69 = false := by
  decide +kernel

#print axioms adaptive143Third142Proof69

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third142Proof68 : runCachedNode 511 130584 Adaptive143Third142Node68 = false := by
  decide +kernel

#print axioms adaptive143Third142Proof68

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third142Proof100 : runCachedNode 511 130584 Adaptive143Third142Node100 = false := by
  decide +kernel

#print axioms adaptive143Third142Proof100

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third142Proof216 : runCachedNode 511 130584 Adaptive143Third142Node216 = false := by
  decide +kernel

#print axioms adaptive143Third142Proof216

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third142Proof365 : runCachedNode 511 130584 Adaptive143Third142Node365 = false := by
  decide +kernel

#print axioms adaptive143Third142Proof365

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third142Proof97 : runCachedNode 511 130584 Adaptive143Third142Node97 = false := by
  decide +kernel

#print axioms adaptive143Third142Proof97

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third142Proof12 : runCachedNode 511 130584 Adaptive143Third142Node12 = false := by
  decide +kernel

#print axioms adaptive143Third142Proof12

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third142Proof532 : runCachedNode 511 130584 Adaptive143Third142Node532 = false := by
  decide +kernel

#print axioms adaptive143Third142Proof532

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third142Proof78 : runCachedNode 511 130584 Adaptive143Third142Node78 = false := by
  decide +kernel

#print axioms adaptive143Third142Proof78

end NineSeparatedSubsetSums
