import NineSeparatedSubsetSums.Adaptive143Third141State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third141Proof190 : runCachedNode 511 130431 Adaptive143Third141Node190 = false := by
  decide +kernel

#print axioms adaptive143Third141Proof190

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third141Proof450 : runCachedNode 511 130431 Adaptive143Third141Node450 = false := by
  decide +kernel

#print axioms adaptive143Third141Proof450

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third141Proof99 : runCachedNode 511 130431 Adaptive143Third141Node99 = false := by
  decide +kernel

#print axioms adaptive143Third141Proof99

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third141Proof120 : runCachedNode 511 130431 Adaptive143Third141Node120 = false := by
  decide +kernel

#print axioms adaptive143Third141Proof120

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third141Proof333 : runCachedNode 511 130431 Adaptive143Third141Node333 = false := by
  decide +kernel

#print axioms adaptive143Third141Proof333

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third141Proof12 : runCachedNode 511 130431 Adaptive143Third141Node12 = false := by
  decide +kernel

#print axioms adaptive143Third141Proof12

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third141Proof406 : runCachedNode 511 130431 Adaptive143Third141Node406 = false := by
  decide +kernel

#print axioms adaptive143Third141Proof406

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third141Proof374 : runCachedNode 511 130431 Adaptive143Third141Node374 = false := by
  decide +kernel

#print axioms adaptive143Third141Proof374

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third141Proof314 : runCachedNode 511 130431 Adaptive143Third141Node314 = false := by
  decide +kernel

#print axioms adaptive143Third141Proof314

end NineSeparatedSubsetSums
