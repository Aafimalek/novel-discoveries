import NineSeparatedSubsetSums.Adaptive143Third138State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third138Proof197 : runCachedNode 511 129927 Adaptive143Third138Node197 = false := by
  decide +kernel

#print axioms adaptive143Third138Proof197

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third138Proof171 : runCachedNode 511 129927 Adaptive143Third138Node171 = false := by
  decide +kernel

#print axioms adaptive143Third138Proof171

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third138Proof126 : runCachedNode 511 129927 Adaptive143Third138Node126 = false := by
  decide +kernel

#print axioms adaptive143Third138Proof126

end NineSeparatedSubsetSums
