import NineSeparatedSubsetSums.Adaptive143Third140State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third140Proof308 : runCachedNode 511 130276 Adaptive143Third140Node308 = false := by
  decide +kernel

#print axioms adaptive143Third140Proof308

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third140Proof15 : runCachedNode 511 130276 Adaptive143Third140Node15 = false := by
  decide +kernel

#print axioms adaptive143Third140Proof15

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third140Proof307 : runCachedNode 511 130276 Adaptive143Third140Node307 = false := by
  decide +kernel

#print axioms adaptive143Third140Proof307

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third140Proof278 : runCachedNode 511 130276 Adaptive143Third140Node278 = false := by
  decide +kernel

#print axioms adaptive143Third140Proof278

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third140Proof133 : runCachedNode 511 130276 Adaptive143Third140Node133 = false := by
  decide +kernel

#print axioms adaptive143Third140Proof133

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third140Proof147 : runCachedNode 511 130276 Adaptive143Third140Node147 = false := by
  decide +kernel

#print axioms adaptive143Third140Proof147

end NineSeparatedSubsetSums
