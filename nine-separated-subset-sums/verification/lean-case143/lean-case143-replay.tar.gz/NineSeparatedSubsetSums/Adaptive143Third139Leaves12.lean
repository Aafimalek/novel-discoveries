import NineSeparatedSubsetSums.Adaptive143Third139State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third139Proof214 : runCachedNode 511 130096 Adaptive143Third139Node214 = false := by
  decide +kernel

#print axioms adaptive143Third139Proof214

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third139Proof44 : runCachedNode 511 130096 Adaptive143Third139Node44 = false := by
  decide +kernel

#print axioms adaptive143Third139Proof44

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third139Proof246 : runCachedNode 511 130096 Adaptive143Third139Node246 = false := by
  decide +kernel

#print axioms adaptive143Third139Proof246

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third139Proof176 : runCachedNode 511 130096 Adaptive143Third139Node176 = false := by
  decide +kernel

#print axioms adaptive143Third139Proof176

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third139Proof251 : runCachedNode 511 130096 Adaptive143Third139Node251 = false := by
  decide +kernel

#print axioms adaptive143Third139Proof251

end NineSeparatedSubsetSums
