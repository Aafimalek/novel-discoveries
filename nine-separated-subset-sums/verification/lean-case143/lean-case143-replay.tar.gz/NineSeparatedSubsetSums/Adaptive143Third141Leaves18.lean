import NineSeparatedSubsetSums.Adaptive143Third141State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third141Proof454 : runCachedNode 511 130431 Adaptive143Third141Node454 = false := by
  decide +kernel

#print axioms adaptive143Third141Proof454

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third141Proof127 : runCachedNode 511 130431 Adaptive143Third141Node127 = false := by
  decide +kernel

#print axioms adaptive143Third141Proof127

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third141Proof262 : runCachedNode 511 130431 Adaptive143Third141Node262 = false := by
  decide +kernel

#print axioms adaptive143Third141Proof262

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third141Proof72 : runCachedNode 511 130431 Adaptive143Third141Node72 = false := by
  decide +kernel

#print axioms adaptive143Third141Proof72

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third141Proof3 : runCachedNode 511 130431 Adaptive143Third141Node3 = false := by
  decide +kernel

#print axioms adaptive143Third141Proof3

end NineSeparatedSubsetSums
