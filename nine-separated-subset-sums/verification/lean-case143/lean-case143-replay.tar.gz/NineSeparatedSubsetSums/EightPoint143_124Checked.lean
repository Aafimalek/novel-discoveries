import NineSeparatedSubsetSums.EightPointPackedGeometry
import NineSeparatedSubsetSums.EightPoint143_124PackedBudget0
import NineSeparatedSubsetSums.EightPoint143_124PackedAnchor0Part0
import NineSeparatedSubsetSums.EightPoint143_124PackedAnchor0Part1
import NineSeparatedSubsetSums.EightPoint143_124PackedAnchor0Part2
import NineSeparatedSubsetSums.EightPoint143_124PackedBudget1
import NineSeparatedSubsetSums.EightPoint143_124PackedAnchor1Part0
import NineSeparatedSubsetSums.EightPoint143_124PackedAnchor1Part1
import NineSeparatedSubsetSums.EightPoint143_124PackedAnchor1Part2

namespace NineSeparatedSubsetSums

private theorem packedOct143_124Anchor0 :
  ∀ j : Fin 485, ((j.val : Int)+143+124)%2=0 →
    2340350 ≤ FourPointNumeric.octPackedCharge 143 124 20 packedOct143_124_0 (j.val : Int) := by
  intro j hj
  let k := (j.val-1)/2
  have hk : k < 242 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+1 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint143_124PackedAnchor0Part0 z
    rwa [he,hrep] at ht
  by_cases h1 : k < 240
  · let z : Fin 120 := ⟨k-120, by omega⟩
    have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
    have ht := eightPoint143_124PackedAnchor0Part1 z
    rwa [he,hrep] at ht
  let z : Fin 2 := ⟨k-240, by omega⟩
  have he : (z.val : Int)+240 = k := by dsimp [z] <;> omega
  have ht := eightPoint143_124PackedAnchor0Part2 z
  rwa [he,hrep] at ht

private theorem packedOct143_124Anchor1 :
  ∀ j : Fin 485, ((j.val : Int)+143+124)%2=1 →
    2339600 ≤ FourPointNumeric.octPackedCharge 143 124 20 packedOct143_124_1 (j.val : Int) := by
  intro j hj
  let k := (j.val-0)/2
  have hk : k < 243 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+0 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint143_124PackedAnchor1Part0 z
    rwa [he,hrep] at ht
  by_cases h1 : k < 240
  · let z : Fin 120 := ⟨k-120, by omega⟩
    have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
    have ht := eightPoint143_124PackedAnchor1Part1 z
    rwa [he,hrep] at ht
  let z : Fin 3 := ⟨k-240, by omega⟩
  have he : (z.val : Int)+240 = k := by dsimp [z] <;> omega
  have ht := eightPoint143_124PackedAnchor1Part2 z
  rwa [he,hrep] at ht

def packedOctCertificate143_124_0 : EightPointCertificate 143 124 0 126972 :=
  eightPointCertificateOfPacked 143 124 0 126972 2340350 20 packedOct143_124_0 493 485
    (by decide +kernel) (by decide) packedOct143_124Anchor0
    (by rw [packedOct143_124_0_budget]; decide)

def packedOctCertificate143_124_1 : EightPointCertificate 143 124 1 126972 :=
  eightPointCertificateOfPacked 143 124 1 126972 2339600 20 packedOct143_124_1 490 485
    (by decide +kernel) (by decide) packedOct143_124Anchor1
    (by rw [packedOct143_124_1_budget]; decide)

theorem max148_second143_third124_eightPoint_moment_bound (tail : List ℕ) (len : tail.length=6)
    (distinct : (natSubsetSums (148::143::124::tail)).Nodup) :
    126972 ≤ ((148::143::124::tail).map (· ^ 2)).sum := by
  apply eightPointNatMomentLower 143 124 126972 tail len distinct
  intro p hp
  by_cases h : p=0
  · subst p
    exact packedOctCertificate143_124_0
  · have he : p=1 := hp.resolve_left h
    subst p
    exact packedOctCertificate143_124_1

#print axioms max148_second143_third124_eightPoint_moment_bound

end NineSeparatedSubsetSums
