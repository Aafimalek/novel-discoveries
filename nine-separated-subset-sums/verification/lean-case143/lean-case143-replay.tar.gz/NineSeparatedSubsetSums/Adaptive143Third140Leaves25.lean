import NineSeparatedSubsetSums.Adaptive143Third140State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third140Proof155 : runCachedNode 511 130276 Adaptive143Third140Node155 = false := by
  decide +kernel

#print axioms adaptive143Third140Proof155

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third140Proof156 : runCachedNode 511 130276 Adaptive143Third140Node156 = false := by
  decide +kernel

#print axioms adaptive143Third140Proof156

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third140Proof388 : runCachedNode 511 130276 Adaptive143Third140Node388 = false := by
  decide +kernel

#print axioms adaptive143Third140Proof388

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third140Proof39 : runCachedNode 511 130276 Adaptive143Third140Node39 = false := by
  decide +kernel

#print axioms adaptive143Third140Proof39

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third140Proof98 : runCachedNode 511 130276 Adaptive143Third140Node98 = false := by
  decide +kernel

#print axioms adaptive143Third140Proof98

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third140Proof187 : runCachedNode 511 130276 Adaptive143Third140Node187 = false := by
  decide +kernel

#print axioms adaptive143Third140Proof187

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third140Proof301 : runCachedNode 511 130276 Adaptive143Third140Node301 = false := by
  decide +kernel

#print axioms adaptive143Third140Proof301

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third140Proof72 : runCachedNode 511 130276 Adaptive143Third140Node72 = false := by
  decide +kernel

#print axioms adaptive143Third140Proof72

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third140Proof186 : runCachedNode 511 130276 Adaptive143Third140Node186 = false := by
  decide +kernel

#print axioms adaptive143Third140Proof186

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third140Proof96 : runCachedNode 511 130276 Adaptive143Third140Node96 = false := by
  decide +kernel

#print axioms adaptive143Third140Proof96

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third140Proof275 : runCachedNode 511 130276 Adaptive143Third140Node275 = false := by
  decide +kernel

#print axioms adaptive143Third140Proof275

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third140Proof299 : runCachedNode 511 130276 Adaptive143Third140Node299 = false := by
  decide +kernel

#print axioms adaptive143Third140Proof299

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third140Proof348 : runCachedNode 511 130276 Adaptive143Third140Node348 = false := by
  decide +kernel

#print axioms adaptive143Third140Proof348

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third140Proof127 : runCachedNode 511 130276 Adaptive143Third140Node127 = false := by
  decide +kernel

#print axioms adaptive143Third140Proof127

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third140Proof70 : runCachedNode 511 130276 Adaptive143Third140Node70 = false := by
  decide +kernel

#print axioms adaptive143Third140Proof70

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third140Proof235 : runCachedNode 511 130276 Adaptive143Third140Node235 = false := by
  decide +kernel

#print axioms adaptive143Third140Proof235

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third140Proof300 : runCachedNode 511 130276 Adaptive143Third140Node300 = false := by
  decide +kernel

#print axioms adaptive143Third140Proof300

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third140Proof234 : runCachedNode 511 130276 Adaptive143Third140Node234 = false := by
  decide +kernel

#print axioms adaptive143Third140Proof234

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third140Proof116 : runCachedNode 511 130276 Adaptive143Third140Node116 = false := by
  decide +kernel

#print axioms adaptive143Third140Proof116

end NineSeparatedSubsetSums
