import NineSeparatedSubsetSums.Adaptive143Third135State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third135Proof20 : runCachedNode 511 129468 Adaptive143Third135Node20 = false := by
  decide +kernel

#print axioms adaptive143Third135Proof20

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third135Proof17 : runCachedNode 511 129468 Adaptive143Third135Node17 = false := by
  decide +kernel

#print axioms adaptive143Third135Proof17

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third135Proof68 : runCachedNode 511 129468 Adaptive143Third135Node68 = false := by
  decide +kernel

#print axioms adaptive143Third135Proof68

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third135Proof26 : runCachedNode 511 129468 Adaptive143Third135Node26 = false := by
  decide +kernel

#print axioms adaptive143Third135Proof26

end NineSeparatedSubsetSums
