import NineSeparatedSubsetSums.Adaptive143Third142State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third142Proof15 : runCachedNode 511 130584 Adaptive143Third142Node15 = false := by
  decide +kernel

#print axioms adaptive143Third142Proof15

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third142Proof493 : runCachedNode 511 130584 Adaptive143Third142Node493 = false := by
  decide +kernel

#print axioms adaptive143Third142Proof493

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third142Proof536 : runCachedNode 511 130584 Adaptive143Third142Node536 = false := by
  decide +kernel

#print axioms adaptive143Third142Proof536

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third142Proof73 : runCachedNode 511 130584 Adaptive143Third142Node73 = false := by
  decide +kernel

#print axioms adaptive143Third142Proof73

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third142Proof130 : runCachedNode 511 130584 Adaptive143Third142Node130 = false := by
  decide +kernel

#print axioms adaptive143Third142Proof130

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third142Proof58 : runCachedNode 511 130584 Adaptive143Third142Node58 = false := by
  decide +kernel

#print axioms adaptive143Third142Proof58

end NineSeparatedSubsetSums
