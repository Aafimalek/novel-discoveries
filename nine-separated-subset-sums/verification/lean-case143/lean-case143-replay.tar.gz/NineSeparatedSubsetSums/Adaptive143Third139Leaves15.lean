import NineSeparatedSubsetSums.Adaptive143Third139State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third139Proof14 : runCachedNode 511 130096 Adaptive143Third139Node14 = false := by
  decide +kernel

#print axioms adaptive143Third139Proof14

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third139Proof283 : runCachedNode 511 130096 Adaptive143Third139Node283 = false := by
  decide +kernel

#print axioms adaptive143Third139Proof283

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third139Proof242 : runCachedNode 511 130096 Adaptive143Third139Node242 = false := by
  decide +kernel

#print axioms adaptive143Third139Proof242

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third139Proof145 : runCachedNode 511 130096 Adaptive143Third139Node145 = false := by
  decide +kernel

#print axioms adaptive143Third139Proof145

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third139Proof13 : runCachedNode 511 130096 Adaptive143Third139Node13 = false := by
  decide +kernel

#print axioms adaptive143Third139Proof13

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third139Proof68 : runCachedNode 511 130096 Adaptive143Third139Node68 = false := by
  decide +kernel

#print axioms adaptive143Third139Proof68

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third139Proof173 : runCachedNode 511 130096 Adaptive143Third139Node173 = false := by
  decide +kernel

#print axioms adaptive143Third139Proof173

end NineSeparatedSubsetSums
