import NineSeparatedSubsetSums.Adaptive143Third124State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third124Proof0 : runCachedNode 511 126972 Adaptive143Third124Node0 = false := by
  decide +kernel

#print axioms adaptive143Third124Proof0

end NineSeparatedSubsetSums
