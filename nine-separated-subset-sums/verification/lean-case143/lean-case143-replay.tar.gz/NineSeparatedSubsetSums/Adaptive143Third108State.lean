import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive143Third108Node0 : CachedSearchNode :=
  ⟨4, 107, computeCenteredMask [148,143,108], 399, 54017⟩

end NineSeparatedSubsetSums
