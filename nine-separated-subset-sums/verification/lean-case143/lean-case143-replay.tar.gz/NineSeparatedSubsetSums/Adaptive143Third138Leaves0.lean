import NineSeparatedSubsetSums.Adaptive143Third138State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third138Proof231 : runCachedNode 511 129927 Adaptive143Third138Node231 = false := by
  decide +kernel

#print axioms adaptive143Third138Proof231

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third138Proof190 : runCachedNode 511 129927 Adaptive143Third138Node190 = false := by
  decide +kernel

#print axioms adaptive143Third138Proof190

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third138Proof144 : runCachedNode 511 129927 Adaptive143Third138Node144 = false := by
  decide +kernel

#print axioms adaptive143Third138Proof144

end NineSeparatedSubsetSums
