import NineSeparatedSubsetSums.Adaptive143Third139State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third139Proof215 : runCachedNode 511 130096 Adaptive143Third139Node215 = false := by
  decide +kernel

#print axioms adaptive143Third139Proof215

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third139Proof182 : runCachedNode 511 130096 Adaptive143Third139Node182 = false := by
  decide +kernel

#print axioms adaptive143Third139Proof182

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third139Proof56 : runCachedNode 511 130096 Adaptive143Third139Node56 = false := by
  decide +kernel

#print axioms adaptive143Third139Proof56

end NineSeparatedSubsetSums
