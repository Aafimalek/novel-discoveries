import NineSeparatedSubsetSums.Adaptive143Third139State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third139Proof286 : runCachedNode 511 130096 Adaptive143Third139Node286 = false := by
  decide +kernel

#print axioms adaptive143Third139Proof286

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third139Proof216 : runCachedNode 511 130096 Adaptive143Third139Node216 = false := by
  decide +kernel

#print axioms adaptive143Third139Proof216

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third139Proof10 : runCachedNode 511 130096 Adaptive143Third139Node10 = false := by
  decide +kernel

#print axioms adaptive143Third139Proof10

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third139Proof46 : runCachedNode 511 130096 Adaptive143Third139Node46 = false := by
  decide +kernel

#print axioms adaptive143Third139Proof46

end NineSeparatedSubsetSums
