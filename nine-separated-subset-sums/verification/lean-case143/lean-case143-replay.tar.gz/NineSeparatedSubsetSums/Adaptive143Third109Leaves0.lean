import NineSeparatedSubsetSums.Adaptive143Third109State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third109Proof0 : runCachedNode 511 112040 Adaptive143Third109Node0 = false := by
  decide +kernel

#print axioms adaptive143Third109Proof0

end NineSeparatedSubsetSums
