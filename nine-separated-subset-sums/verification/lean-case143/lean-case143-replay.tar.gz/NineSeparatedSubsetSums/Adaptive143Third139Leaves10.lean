import NineSeparatedSubsetSums.Adaptive143Third139State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third139Proof149 : runCachedNode 511 130096 Adaptive143Third139Node149 = false := by
  decide +kernel

#print axioms adaptive143Third139Proof149

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third139Proof16 : runCachedNode 511 130096 Adaptive143Third139Node16 = false := by
  decide +kernel

#print axioms adaptive143Third139Proof16

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third139Proof96 : runCachedNode 511 130096 Adaptive143Third139Node96 = false := by
  decide +kernel

#print axioms adaptive143Third139Proof96

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third139Proof62 : runCachedNode 511 130096 Adaptive143Third139Node62 = false := by
  decide +kernel

#print axioms adaptive143Third139Proof62

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third139Proof250 : runCachedNode 511 130096 Adaptive143Third139Node250 = false := by
  decide +kernel

#print axioms adaptive143Third139Proof250

end NineSeparatedSubsetSums
