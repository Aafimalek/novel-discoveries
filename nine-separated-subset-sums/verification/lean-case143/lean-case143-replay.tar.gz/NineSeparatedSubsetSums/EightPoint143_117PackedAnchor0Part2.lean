import NineSeparatedSubsetSums.EightPoint143_117PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint143_117PackedAnchor0Part2 :
    ∀ j : Fin 6, 2381812 ≤ FourPointNumeric.octPackedCharge 143 117 20 packedOct143_117_0
      (2*((j.val : Int)+240)+0) := by decide +kernel

end NineSeparatedSubsetSums
