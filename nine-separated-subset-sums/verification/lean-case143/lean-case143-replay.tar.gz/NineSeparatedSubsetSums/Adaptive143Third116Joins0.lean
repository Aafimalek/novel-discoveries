import NineSeparatedSubsetSums.Adaptive143Third116State
import NineSeparatedSubsetSums.Adaptive143Third116Leaves1
import NineSeparatedSubsetSums.Adaptive143Third116Leaves0

namespace NineSeparatedSubsetSums

theorem adaptive143Third116Proof0 : runCachedNode 511 112040 Adaptive143Third116Node0 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 112040 Adaptive143Third116Node0 = [100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 112, 113, 114, 115] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive143Third116Proof1
  · exact adaptive143Third116Proof2
  · exact adaptive143Third116Proof3
  · exact adaptive143Third116Proof4
  · exact adaptive143Third116Proof5
  · exact adaptive143Third116Proof6
  · exact adaptive143Third116Proof7
  · exact adaptive143Third116Proof8
  · exact adaptive143Third116Proof9
  · exact adaptive143Third116Proof10
  · exact adaptive143Third116Proof11
  · exact adaptive143Third116Proof12
  · exact adaptive143Third116Proof13
  · exact adaptive143Third116Proof14
  · exact adaptive143Third116Proof15

#print axioms adaptive143Third116Proof0

end NineSeparatedSubsetSums
