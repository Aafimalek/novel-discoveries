import NineSeparatedSubsetSums.Adaptive143Third141State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third141Proof223 : runCachedNode 511 130431 Adaptive143Third141Node223 = false := by
  decide +kernel

#print axioms adaptive143Third141Proof223

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third141Proof130 : runCachedNode 511 130431 Adaptive143Third141Node130 = false := by
  decide +kernel

#print axioms adaptive143Third141Proof130

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third141Proof173 : runCachedNode 511 130431 Adaptive143Third141Node173 = false := by
  decide +kernel

#print axioms adaptive143Third141Proof173

end NineSeparatedSubsetSums
