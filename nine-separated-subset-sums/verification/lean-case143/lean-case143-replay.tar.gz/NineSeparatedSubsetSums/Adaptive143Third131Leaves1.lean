import NineSeparatedSubsetSums.Adaptive143Third131State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third131Proof18 : runCachedNode 511 128821 Adaptive143Third131Node18 = false := by
  decide +kernel

#print axioms adaptive143Third131Proof18

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third131Proof17 : runCachedNode 511 128821 Adaptive143Third131Node17 = false := by
  decide +kernel

#print axioms adaptive143Third131Proof17

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third131Proof16 : runCachedNode 511 128821 Adaptive143Third131Node16 = false := by
  decide +kernel

#print axioms adaptive143Third131Proof16

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third131Proof11 : runCachedNode 511 128821 Adaptive143Third131Node11 = false := by
  decide +kernel

#print axioms adaptive143Third131Proof11

end NineSeparatedSubsetSums
