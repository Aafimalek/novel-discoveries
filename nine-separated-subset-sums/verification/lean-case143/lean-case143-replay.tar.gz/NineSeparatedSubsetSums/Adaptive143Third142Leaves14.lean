import NineSeparatedSubsetSums.Adaptive143Third142State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third142Proof20 : runCachedNode 511 130584 Adaptive143Third142Node20 = false := by
  decide +kernel

#print axioms adaptive143Third142Proof20

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third142Proof194 : runCachedNode 511 130584 Adaptive143Third142Node194 = false := by
  decide +kernel

#print axioms adaptive143Third142Proof194

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third142Proof327 : runCachedNode 511 130584 Adaptive143Third142Node327 = false := by
  decide +kernel

#print axioms adaptive143Third142Proof327

end NineSeparatedSubsetSums
