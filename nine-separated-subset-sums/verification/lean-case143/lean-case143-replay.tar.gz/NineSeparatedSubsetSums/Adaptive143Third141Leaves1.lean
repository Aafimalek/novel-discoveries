import NineSeparatedSubsetSums.Adaptive143Third141State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third141Proof21 : runCachedNode 511 130431 Adaptive143Third141Node21 = false := by
  decide +kernel

#print axioms adaptive143Third141Proof21

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third141Proof410 : runCachedNode 511 130431 Adaptive143Third141Node410 = false := by
  decide +kernel

#print axioms adaptive143Third141Proof410

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third141Proof132 : runCachedNode 511 130431 Adaptive143Third141Node132 = false := by
  decide +kernel

#print axioms adaptive143Third141Proof132

end NineSeparatedSubsetSums
