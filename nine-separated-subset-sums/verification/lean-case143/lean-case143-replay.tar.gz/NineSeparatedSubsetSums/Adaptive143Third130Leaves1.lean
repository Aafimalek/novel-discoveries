import NineSeparatedSubsetSums.Adaptive143Third130State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third130Proof17 : runCachedNode 511 128577 Adaptive143Third130Node17 = false := by
  decide +kernel

#print axioms adaptive143Third130Proof17

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third130Proof16 : runCachedNode 511 128577 Adaptive143Third130Node16 = false := by
  decide +kernel

#print axioms adaptive143Third130Proof16

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third130Proof14 : runCachedNode 511 128577 Adaptive143Third130Node14 = false := by
  decide +kernel

#print axioms adaptive143Third130Proof14

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third130Proof13 : runCachedNode 511 128577 Adaptive143Third130Node13 = false := by
  decide +kernel

#print axioms adaptive143Third130Proof13

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third130Proof11 : runCachedNode 511 128577 Adaptive143Third130Node11 = false := by
  decide +kernel

#print axioms adaptive143Third130Proof11

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third130Proof12 : runCachedNode 511 128577 Adaptive143Third130Node12 = false := by
  decide +kernel

#print axioms adaptive143Third130Proof12

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third130Proof2 : runCachedNode 511 128577 Adaptive143Third130Node2 = false := by
  decide +kernel

#print axioms adaptive143Third130Proof2

end NineSeparatedSubsetSums
