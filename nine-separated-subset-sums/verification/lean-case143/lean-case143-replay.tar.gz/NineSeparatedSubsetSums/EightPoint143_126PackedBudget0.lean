import NineSeparatedSubsetSums.EightPoint143_126PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct143_126_0_budget :
    FourPointNumeric.packedBudget 20 packedOct143_126_0 487 = 86354579 := by decide +kernel

#print axioms packedOct143_126_0_budget

end NineSeparatedSubsetSums
