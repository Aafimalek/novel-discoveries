import NineSeparatedSubsetSums.Adaptive143Third141State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third141Proof20 : runCachedNode 511 130431 Adaptive143Third141Node20 = false := by
  decide +kernel

#print axioms adaptive143Third141Proof20

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third141Proof159 : runCachedNode 511 130431 Adaptive143Third141Node159 = false := by
  decide +kernel

#print axioms adaptive143Third141Proof159

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third141Proof142 : runCachedNode 511 130431 Adaptive143Third141Node142 = false := by
  decide +kernel

#print axioms adaptive143Third141Proof142

end NineSeparatedSubsetSums
