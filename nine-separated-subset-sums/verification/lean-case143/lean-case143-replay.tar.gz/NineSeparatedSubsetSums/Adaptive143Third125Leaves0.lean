import NineSeparatedSubsetSums.Adaptive143Third125State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third125Proof0 : runCachedNode 511 127299 Adaptive143Third125Node0 = false := by
  decide +kernel

#print axioms adaptive143Third125Proof0

end NineSeparatedSubsetSums
