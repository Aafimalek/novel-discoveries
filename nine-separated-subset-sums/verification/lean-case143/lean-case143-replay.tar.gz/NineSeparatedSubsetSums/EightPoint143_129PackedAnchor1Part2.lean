import NineSeparatedSubsetSums.EightPoint143_129PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint143_129PackedAnchor1Part2 :
    ∀ j : Fin 5, 2397504 ≤ FourPointNumeric.octPackedCharge 143 129 20 packedOct143_129_1
      (2*((j.val : Int)+240)+1) := by decide +kernel

end NineSeparatedSubsetSums
