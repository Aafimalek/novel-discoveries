import NineSeparatedSubsetSums.Adaptive143Third134State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third134Proof19 : runCachedNode 511 129375 Adaptive143Third134Node19 = false := by
  decide +kernel

#print axioms adaptive143Third134Proof19

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third134Proof18 : runCachedNode 511 129375 Adaptive143Third134Node18 = false := by
  decide +kernel

#print axioms adaptive143Third134Proof18

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third134Proof8 : runCachedNode 511 129375 Adaptive143Third134Node8 = false := by
  decide +kernel

#print axioms adaptive143Third134Proof8

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third134Proof6 : runCachedNode 511 129375 Adaptive143Third134Node6 = false := by
  decide +kernel

#print axioms adaptive143Third134Proof6

end NineSeparatedSubsetSums
