import NineSeparatedSubsetSums.Adaptive143Third138State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third138Proof35 : runCachedNode 511 129927 Adaptive143Third138Node35 = false := by
  decide +kernel

#print axioms adaptive143Third138Proof35

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third138Proof86 : runCachedNode 511 129927 Adaptive143Third138Node86 = false := by
  decide +kernel

#print axioms adaptive143Third138Proof86

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third138Proof221 : runCachedNode 511 129927 Adaptive143Third138Node221 = false := by
  decide +kernel

#print axioms adaptive143Third138Proof221

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third138Proof164 : runCachedNode 511 129927 Adaptive143Third138Node164 = false := by
  decide +kernel

#print axioms adaptive143Third138Proof164

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third138Proof61 : runCachedNode 511 129927 Adaptive143Third138Node61 = false := by
  decide +kernel

#print axioms adaptive143Third138Proof61

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third138Proof223 : runCachedNode 511 129927 Adaptive143Third138Node223 = false := by
  decide +kernel

#print axioms adaptive143Third138Proof223

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third138Proof137 : runCachedNode 511 129927 Adaptive143Third138Node137 = false := by
  decide +kernel

#print axioms adaptive143Third138Proof137

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third138Proof84 : runCachedNode 511 129927 Adaptive143Third138Node84 = false := by
  decide +kernel

#print axioms adaptive143Third138Proof84

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third138Proof75 : runCachedNode 511 129927 Adaptive143Third138Node75 = false := by
  decide +kernel

#print axioms adaptive143Third138Proof75

end NineSeparatedSubsetSums
