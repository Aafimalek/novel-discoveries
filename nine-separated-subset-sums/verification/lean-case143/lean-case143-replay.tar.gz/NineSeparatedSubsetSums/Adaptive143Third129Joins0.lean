import NineSeparatedSubsetSums.Adaptive143Third129State
import NineSeparatedSubsetSums.Adaptive143Third129Leaves1
import NineSeparatedSubsetSums.Adaptive143Third129Leaves0

namespace NineSeparatedSubsetSums

theorem adaptive143Third129Proof0 : runCachedNode 511 128295 Adaptive143Third129Node0 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 128295 Adaptive143Third129Node0 = [110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 125, 126, 127, 128] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive143Third129Proof1
  · exact adaptive143Third129Proof2
  · exact adaptive143Third129Proof3
  · exact adaptive143Third129Proof4
  · exact adaptive143Third129Proof5
  · exact adaptive143Third129Proof6
  · exact adaptive143Third129Proof7
  · exact adaptive143Third129Proof8
  · exact adaptive143Third129Proof9
  · exact adaptive143Third129Proof10
  · exact adaptive143Third129Proof11
  · exact adaptive143Third129Proof12
  · exact adaptive143Third129Proof13
  · exact adaptive143Third129Proof14
  · exact adaptive143Third129Proof15
  · exact adaptive143Third129Proof16
  · exact adaptive143Third129Proof17
  · exact adaptive143Third129Proof18

#print axioms adaptive143Third129Proof0

end NineSeparatedSubsetSums
