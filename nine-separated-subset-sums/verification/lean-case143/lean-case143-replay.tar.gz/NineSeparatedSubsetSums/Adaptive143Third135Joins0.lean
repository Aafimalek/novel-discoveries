import NineSeparatedSubsetSums.Adaptive143Third135State
import NineSeparatedSubsetSums.Adaptive143Third135Leaves6
import NineSeparatedSubsetSums.Adaptive143Third135Leaves8
import NineSeparatedSubsetSums.Adaptive143Third135Leaves7
import NineSeparatedSubsetSums.Adaptive143Third135Leaves2
import NineSeparatedSubsetSums.Adaptive143Third135Leaves1
import NineSeparatedSubsetSums.Adaptive143Third135Leaves0
import NineSeparatedSubsetSums.Adaptive143Third135Leaves5
import NineSeparatedSubsetSums.Adaptive143Third135Leaves4
import NineSeparatedSubsetSums.Adaptive143Third135Leaves3

namespace NineSeparatedSubsetSums

theorem adaptive143Third135Proof22 : runCachedNode 511 129468 Adaptive143Third135Node22 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 129468 Adaptive143Third135Node22 = [104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 120, 121, 122, 123, 125, 126, 128, 129, 131] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive143Third135Proof23
  · exact adaptive143Third135Proof24
  · exact adaptive143Third135Proof25
  · exact adaptive143Third135Proof26
  · exact adaptive143Third135Proof27
  · exact adaptive143Third135Proof28
  · exact adaptive143Third135Proof29
  · exact adaptive143Third135Proof30
  · exact adaptive143Third135Proof31
  · exact adaptive143Third135Proof32
  · exact adaptive143Third135Proof33
  · exact adaptive143Third135Proof34
  · exact adaptive143Third135Proof35
  · exact adaptive143Third135Proof36
  · exact adaptive143Third135Proof37
  · exact adaptive143Third135Proof38
  · exact adaptive143Third135Proof39
  · exact adaptive143Third135Proof40
  · exact adaptive143Third135Proof41
  · exact adaptive143Third135Proof42
  · exact adaptive143Third135Proof43
  · exact adaptive143Third135Proof44
  · exact adaptive143Third135Proof45
  · exact adaptive143Third135Proof46

#print axioms adaptive143Third135Proof22

theorem adaptive143Third135Proof48 : runCachedNode 511 129468 Adaptive143Third135Node48 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 129468 Adaptive143Third135Node48 = [103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 122, 123, 124, 125, 127, 128, 131, 132, 133] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive143Third135Proof49
  · exact adaptive143Third135Proof50
  · exact adaptive143Third135Proof51
  · exact adaptive143Third135Proof52
  · exact adaptive143Third135Proof53
  · exact adaptive143Third135Proof54
  · exact adaptive143Third135Proof55
  · exact adaptive143Third135Proof56
  · exact adaptive143Third135Proof57
  · exact adaptive143Third135Proof58
  · exact adaptive143Third135Proof59
  · exact adaptive143Third135Proof60
  · exact adaptive143Third135Proof61
  · exact adaptive143Third135Proof62
  · exact adaptive143Third135Proof63
  · exact adaptive143Third135Proof64
  · exact adaptive143Third135Proof65
  · exact adaptive143Third135Proof66
  · exact adaptive143Third135Proof67
  · exact adaptive143Third135Proof68
  · exact adaptive143Third135Proof69
  · exact adaptive143Third135Proof70
  · exact adaptive143Third135Proof71
  · exact adaptive143Third135Proof72
  · exact adaptive143Third135Proof73
  · exact adaptive143Third135Proof74
  · exact adaptive143Third135Proof75

#print axioms adaptive143Third135Proof48

theorem adaptive143Third135Proof0 : runCachedNode 511 129468 Adaptive143Third135Node0 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 129468 Adaptive143Third135Node0 = [110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 131, 132, 133, 134] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive143Third135Proof1
  · exact adaptive143Third135Proof2
  · exact adaptive143Third135Proof3
  · exact adaptive143Third135Proof4
  · exact adaptive143Third135Proof5
  · exact adaptive143Third135Proof6
  · exact adaptive143Third135Proof7
  · exact adaptive143Third135Proof8
  · exact adaptive143Third135Proof9
  · exact adaptive143Third135Proof10
  · exact adaptive143Third135Proof11
  · exact adaptive143Third135Proof12
  · exact adaptive143Third135Proof13
  · exact adaptive143Third135Proof14
  · exact adaptive143Third135Proof15
  · exact adaptive143Third135Proof16
  · exact adaptive143Third135Proof17
  · exact adaptive143Third135Proof18
  · exact adaptive143Third135Proof19
  · exact adaptive143Third135Proof20
  · exact adaptive143Third135Proof21
  · exact adaptive143Third135Proof22
  · exact adaptive143Third135Proof47
  · exact adaptive143Third135Proof48

#print axioms adaptive143Third135Proof0

end NineSeparatedSubsetSums
