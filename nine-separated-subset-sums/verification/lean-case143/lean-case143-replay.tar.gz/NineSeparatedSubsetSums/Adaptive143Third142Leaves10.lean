import NineSeparatedSubsetSums.Adaptive143Third142State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third142Proof264 : runCachedNode 511 130584 Adaptive143Third142Node264 = false := by
  decide +kernel

#print axioms adaptive143Third142Proof264

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third142Proof539 : runCachedNode 511 130584 Adaptive143Third142Node539 = false := by
  decide +kernel

#print axioms adaptive143Third142Proof539

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third142Proof123 : runCachedNode 511 130584 Adaptive143Third142Node123 = false := by
  decide +kernel

#print axioms adaptive143Third142Proof123

end NineSeparatedSubsetSums
