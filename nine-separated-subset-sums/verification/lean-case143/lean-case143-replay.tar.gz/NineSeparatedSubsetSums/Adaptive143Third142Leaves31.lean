import NineSeparatedSubsetSums.Adaptive143Third142State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third142Proof102 : runCachedNode 511 130584 Adaptive143Third142Node102 = false := by
  decide +kernel

#print axioms adaptive143Third142Proof102

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third142Proof13 : runCachedNode 511 130584 Adaptive143Third142Node13 = false := by
  decide +kernel

#print axioms adaptive143Third142Proof13

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third142Proof439 : runCachedNode 511 130584 Adaptive143Third142Node439 = false := by
  decide +kernel

#print axioms adaptive143Third142Proof439

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third142Proof333 : runCachedNode 511 130584 Adaptive143Third142Node333 = false := by
  decide +kernel

#print axioms adaptive143Third142Proof333

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third142Proof491 : runCachedNode 511 130584 Adaptive143Third142Node491 = false := by
  decide +kernel

#print axioms adaptive143Third142Proof491

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third142Proof534 : runCachedNode 511 130584 Adaptive143Third142Node534 = false := by
  decide +kernel

#print axioms adaptive143Third142Proof534

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third142Proof413 : runCachedNode 511 130584 Adaptive143Third142Node413 = false := by
  decide +kernel

#print axioms adaptive143Third142Proof413

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third142Proof185 : runCachedNode 511 130584 Adaptive143Third142Node185 = false := by
  decide +kernel

#print axioms adaptive143Third142Proof185

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third142Proof390 : runCachedNode 511 130584 Adaptive143Third142Node390 = false := by
  decide +kernel

#print axioms adaptive143Third142Proof390

end NineSeparatedSubsetSums
