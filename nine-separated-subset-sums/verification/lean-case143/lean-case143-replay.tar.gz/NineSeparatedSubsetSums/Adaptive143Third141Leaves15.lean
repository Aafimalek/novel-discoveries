import NineSeparatedSubsetSums.Adaptive143Third141State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third141Proof191 : runCachedNode 511 130431 Adaptive143Third141Node191 = false := by
  decide +kernel

#print axioms adaptive143Third141Proof191

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third141Proof377 : runCachedNode 511 130431 Adaptive143Third141Node377 = false := by
  decide +kernel

#print axioms adaptive143Third141Proof377

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third141Proof411 : runCachedNode 511 130431 Adaptive143Third141Node411 = false := by
  decide +kernel

#print axioms adaptive143Third141Proof411

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third141Proof1 : runCachedNode 511 130431 Adaptive143Third141Node1 = false := by
  decide +kernel

#print axioms adaptive143Third141Proof1

end NineSeparatedSubsetSums
