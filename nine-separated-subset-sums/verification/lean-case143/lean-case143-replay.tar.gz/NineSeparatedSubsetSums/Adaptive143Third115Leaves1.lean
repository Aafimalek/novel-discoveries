import NineSeparatedSubsetSums.Adaptive143Third115State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third115Proof9 : runCachedNode 511 112040 Adaptive143Third115Node9 = false := by
  decide +kernel

#print axioms adaptive143Third115Proof9

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third115Proof7 : runCachedNode 511 112040 Adaptive143Third115Node7 = false := by
  decide +kernel

#print axioms adaptive143Third115Proof7

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third115Proof6 : runCachedNode 511 112040 Adaptive143Third115Node6 = false := by
  decide +kernel

#print axioms adaptive143Third115Proof6

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third115Proof5 : runCachedNode 511 112040 Adaptive143Third115Node5 = false := by
  decide +kernel

#print axioms adaptive143Third115Proof5

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third115Proof3 : runCachedNode 511 112040 Adaptive143Third115Node3 = false := by
  decide +kernel

#print axioms adaptive143Third115Proof3

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third115Proof2 : runCachedNode 511 112040 Adaptive143Third115Node2 = false := by
  decide +kernel

#print axioms adaptive143Third115Proof2

end NineSeparatedSubsetSums
