import NineSeparatedSubsetSums.Adaptive143Third139State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third139Proof15 : runCachedNode 511 130096 Adaptive143Third139Node15 = false := by
  decide +kernel

#print axioms adaptive143Third139Proof15

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third139Proof148 : runCachedNode 511 130096 Adaptive143Third139Node148 = false := by
  decide +kernel

#print axioms adaptive143Third139Proof148

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third139Proof284 : runCachedNode 511 130096 Adaptive143Third139Node284 = false := by
  decide +kernel

#print axioms adaptive143Third139Proof284

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third139Proof122 : runCachedNode 511 130096 Adaptive143Third139Node122 = false := by
  decide +kernel

#print axioms adaptive143Third139Proof122

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third139Proof150 : runCachedNode 511 130096 Adaptive143Third139Node150 = false := by
  decide +kernel

#print axioms adaptive143Third139Proof150

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third139Proof252 : runCachedNode 511 130096 Adaptive143Third139Node252 = false := by
  decide +kernel

#print axioms adaptive143Third139Proof252

end NineSeparatedSubsetSums
