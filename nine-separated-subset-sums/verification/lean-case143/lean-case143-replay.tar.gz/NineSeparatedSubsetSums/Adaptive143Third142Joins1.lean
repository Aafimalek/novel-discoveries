import NineSeparatedSubsetSums.Adaptive143Third142State
import NineSeparatedSubsetSums.Adaptive143Third142Leaves45
import NineSeparatedSubsetSums.Adaptive143Third142Leaves44
import NineSeparatedSubsetSums.Adaptive143Third142Leaves43
import NineSeparatedSubsetSums.Adaptive143Third142Leaves42
import NineSeparatedSubsetSums.Adaptive143Third142Leaves41
import NineSeparatedSubsetSums.Adaptive143Third142Leaves40
import NineSeparatedSubsetSums.Adaptive143Third142Leaves39
import NineSeparatedSubsetSums.Adaptive143Third142Leaves38
import NineSeparatedSubsetSums.Adaptive143Third142Leaves37
import NineSeparatedSubsetSums.Adaptive143Third142Leaves36
import NineSeparatedSubsetSums.Adaptive143Third142Leaves34
import NineSeparatedSubsetSums.Adaptive143Third142Leaves33
import NineSeparatedSubsetSums.Adaptive143Third142Leaves32
import NineSeparatedSubsetSums.Adaptive143Third142Leaves30
import NineSeparatedSubsetSums.Adaptive143Third142Leaves29
import NineSeparatedSubsetSums.Adaptive143Third142Leaves23
import NineSeparatedSubsetSums.Adaptive143Third142Leaves9
import NineSeparatedSubsetSums.Adaptive143Third142Leaves11
import NineSeparatedSubsetSums.Adaptive143Third142Leaves12
import NineSeparatedSubsetSums.Adaptive143Third142Leaves8
import NineSeparatedSubsetSums.Adaptive143Third142Joins0
import NineSeparatedSubsetSums.Adaptive143Third142Leaves10
import NineSeparatedSubsetSums.Adaptive143Third142Leaves46
import NineSeparatedSubsetSums.Adaptive143Third142Leaves14
import NineSeparatedSubsetSums.Adaptive143Third142Leaves35
import NineSeparatedSubsetSums.Adaptive143Third142Leaves31
import NineSeparatedSubsetSums.Adaptive143Third142Leaves27
import NineSeparatedSubsetSums.Adaptive143Third142Leaves26
import NineSeparatedSubsetSums.Adaptive143Third142Leaves3
import NineSeparatedSubsetSums.Adaptive143Third142Leaves16
import NineSeparatedSubsetSums.Adaptive143Third142Leaves2
import NineSeparatedSubsetSums.Adaptive143Third142Leaves1
import NineSeparatedSubsetSums.Adaptive143Third142Leaves28
import NineSeparatedSubsetSums.Adaptive143Third142Leaves18
import NineSeparatedSubsetSums.Adaptive143Third142Leaves24
import NineSeparatedSubsetSums.Adaptive143Third142Leaves21
import NineSeparatedSubsetSums.Adaptive143Third142Leaves47
import NineSeparatedSubsetSums.Adaptive143Third142Leaves25
import NineSeparatedSubsetSums.Adaptive143Third142Leaves22
import NineSeparatedSubsetSums.Adaptive143Third142Leaves19
import NineSeparatedSubsetSums.Adaptive143Third142Leaves17
import NineSeparatedSubsetSums.Adaptive143Third142Leaves13
import NineSeparatedSubsetSums.Adaptive143Third142Leaves15
import NineSeparatedSubsetSums.Adaptive143Third142Leaves0
import NineSeparatedSubsetSums.Adaptive143Third142Leaves5
import NineSeparatedSubsetSums.Adaptive143Third142Leaves6
import NineSeparatedSubsetSums.Adaptive143Third142Leaves4

namespace NineSeparatedSubsetSums

theorem adaptive143Third142Proof196 : runCachedNode 511 130584 Adaptive143Third142Node196 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130584 Adaptive143Third142Node196 = [102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 134, 135, 136] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive143Third142Proof197
  · exact adaptive143Third142Proof198
  · exact adaptive143Third142Proof199
  · exact adaptive143Third142Proof200
  · exact adaptive143Third142Proof201
  · exact adaptive143Third142Proof202
  · exact adaptive143Third142Proof203
  · exact adaptive143Third142Proof204
  · exact adaptive143Third142Proof205
  · exact adaptive143Third142Proof206
  · exact adaptive143Third142Proof207
  · exact adaptive143Third142Proof208
  · exact adaptive143Third142Proof209
  · exact adaptive143Third142Proof210
  · exact adaptive143Third142Proof211
  · exact adaptive143Third142Proof212
  · exact adaptive143Third142Proof213
  · exact adaptive143Third142Proof214
  · exact adaptive143Third142Proof215
  · exact adaptive143Third142Proof216
  · exact adaptive143Third142Proof217
  · exact adaptive143Third142Proof218
  · exact adaptive143Third142Proof219
  · exact adaptive143Third142Proof220
  · exact adaptive143Third142Proof221
  · exact adaptive143Third142Proof222
  · exact adaptive143Third142Proof223
  · exact adaptive143Third142Proof224
  · exact adaptive143Third142Proof225
  · exact adaptive143Third142Proof226
  · exact adaptive143Third142Proof227
  · exact adaptive143Third142Proof264
  · exact adaptive143Third142Proof265

#print axioms adaptive143Third142Proof196

theorem adaptive143Third142Proof305 : runCachedNode 511 130584 Adaptive143Third142Node305 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130584 Adaptive143Third142Node305 = [101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 132, 135, 136] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive143Third142Proof306
  · exact adaptive143Third142Proof307
  · exact adaptive143Third142Proof308
  · exact adaptive143Third142Proof309
  · exact adaptive143Third142Proof310
  · exact adaptive143Third142Proof311
  · exact adaptive143Third142Proof312
  · exact adaptive143Third142Proof313
  · exact adaptive143Third142Proof314
  · exact adaptive143Third142Proof315
  · exact adaptive143Third142Proof316
  · exact adaptive143Third142Proof317
  · exact adaptive143Third142Proof318
  · exact adaptive143Third142Proof319
  · exact adaptive143Third142Proof320
  · exact adaptive143Third142Proof321
  · exact adaptive143Third142Proof322
  · exact adaptive143Third142Proof323
  · exact adaptive143Third142Proof324
  · exact adaptive143Third142Proof325
  · exact adaptive143Third142Proof326
  · exact adaptive143Third142Proof327
  · exact adaptive143Third142Proof328
  · exact adaptive143Third142Proof329
  · exact adaptive143Third142Proof330
  · exact adaptive143Third142Proof331
  · exact adaptive143Third142Proof332
  · exact adaptive143Third142Proof333
  · exact adaptive143Third142Proof334
  · exact adaptive143Third142Proof335
  · exact adaptive143Third142Proof336
  · exact adaptive143Third142Proof337
  · exact adaptive143Third142Proof338
  · exact adaptive143Third142Proof339

#print axioms adaptive143Third142Proof305

theorem adaptive143Third142Proof375 : runCachedNode 511 130584 Adaptive143Third142Node375 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130584 Adaptive143Third142Node375 = [88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive143Third142Proof376
  · exact adaptive143Third142Proof377
  · exact adaptive143Third142Proof378
  · exact adaptive143Third142Proof379
  · exact adaptive143Third142Proof380
  · exact adaptive143Third142Proof381
  · exact adaptive143Third142Proof382
  · exact adaptive143Third142Proof383
  · exact adaptive143Third142Proof384
  · exact adaptive143Third142Proof385
  · exact adaptive143Third142Proof386
  · exact adaptive143Third142Proof387
  · exact adaptive143Third142Proof388
  · exact adaptive143Third142Proof389
  · exact adaptive143Third142Proof390
  · exact adaptive143Third142Proof391
  · exact adaptive143Third142Proof392
  · exact adaptive143Third142Proof393
  · exact adaptive143Third142Proof394
  · exact adaptive143Third142Proof395
  · exact adaptive143Third142Proof396
  · exact adaptive143Third142Proof397
  · exact adaptive143Third142Proof398
  · exact adaptive143Third142Proof399
  · exact adaptive143Third142Proof400
  · exact adaptive143Third142Proof401
  · exact adaptive143Third142Proof402
  · exact adaptive143Third142Proof403
  · exact adaptive143Third142Proof404
  · exact adaptive143Third142Proof405
  · exact adaptive143Third142Proof406
  · exact adaptive143Third142Proof407
  · exact adaptive143Third142Proof408
  · exact adaptive143Third142Proof409
  · exact adaptive143Third142Proof410
  · exact adaptive143Third142Proof411
  · exact adaptive143Third142Proof412
  · exact adaptive143Third142Proof413
  · exact adaptive143Third142Proof414
  · exact adaptive143Third142Proof415
  · exact adaptive143Third142Proof416

#print axioms adaptive143Third142Proof375

theorem adaptive143Third142Proof340 : runCachedNode 511 130584 Adaptive143Third142Node340 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130584 Adaptive143Third142Node340 = [101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 132, 133, 136, 138] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive143Third142Proof341
  · exact adaptive143Third142Proof342
  · exact adaptive143Third142Proof343
  · exact adaptive143Third142Proof344
  · exact adaptive143Third142Proof345
  · exact adaptive143Third142Proof346
  · exact adaptive143Third142Proof347
  · exact adaptive143Third142Proof348
  · exact adaptive143Third142Proof349
  · exact adaptive143Third142Proof350
  · exact adaptive143Third142Proof351
  · exact adaptive143Third142Proof352
  · exact adaptive143Third142Proof353
  · exact adaptive143Third142Proof354
  · exact adaptive143Third142Proof355
  · exact adaptive143Third142Proof356
  · exact adaptive143Third142Proof357
  · exact adaptive143Third142Proof358
  · exact adaptive143Third142Proof359
  · exact adaptive143Third142Proof360
  · exact adaptive143Third142Proof361
  · exact adaptive143Third142Proof362
  · exact adaptive143Third142Proof363
  · exact adaptive143Third142Proof364
  · exact adaptive143Third142Proof365
  · exact adaptive143Third142Proof366
  · exact adaptive143Third142Proof367
  · exact adaptive143Third142Proof368
  · exact adaptive143Third142Proof369
  · exact adaptive143Third142Proof370
  · exact adaptive143Third142Proof371
  · exact adaptive143Third142Proof372
  · exact adaptive143Third142Proof373
  · exact adaptive143Third142Proof374
  · exact adaptive143Third142Proof375

#print axioms adaptive143Third142Proof340

theorem adaptive143Third142Proof452 : runCachedNode 511 130584 Adaptive143Third142Node452 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130584 Adaptive143Third142Node452 = [87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive143Third142Proof453
  · exact adaptive143Third142Proof454
  · exact adaptive143Third142Proof455
  · exact adaptive143Third142Proof456
  · exact adaptive143Third142Proof457
  · exact adaptive143Third142Proof458
  · exact adaptive143Third142Proof459
  · exact adaptive143Third142Proof460
  · exact adaptive143Third142Proof461
  · exact adaptive143Third142Proof462
  · exact adaptive143Third142Proof463
  · exact adaptive143Third142Proof464
  · exact adaptive143Third142Proof465
  · exact adaptive143Third142Proof466
  · exact adaptive143Third142Proof467
  · exact adaptive143Third142Proof468
  · exact adaptive143Third142Proof469
  · exact adaptive143Third142Proof470
  · exact adaptive143Third142Proof471
  · exact adaptive143Third142Proof472
  · exact adaptive143Third142Proof473
  · exact adaptive143Third142Proof474
  · exact adaptive143Third142Proof475
  · exact adaptive143Third142Proof476
  · exact adaptive143Third142Proof477
  · exact adaptive143Third142Proof478
  · exact adaptive143Third142Proof479
  · exact adaptive143Third142Proof480
  · exact adaptive143Third142Proof481
  · exact adaptive143Third142Proof482
  · exact adaptive143Third142Proof483
  · exact adaptive143Third142Proof484
  · exact adaptive143Third142Proof485
  · exact adaptive143Third142Proof486
  · exact adaptive143Third142Proof487
  · exact adaptive143Third142Proof488
  · exact adaptive143Third142Proof489
  · exact adaptive143Third142Proof490
  · exact adaptive143Third142Proof491
  · exact adaptive143Third142Proof492
  · exact adaptive143Third142Proof493
  · exact adaptive143Third142Proof494
  · exact adaptive143Third142Proof495

#print axioms adaptive143Third142Proof452

theorem adaptive143Third142Proof496 : runCachedNode 511 130584 Adaptive143Third142Node496 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130584 Adaptive143Third142Node496 = [87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive143Third142Proof497
  · exact adaptive143Third142Proof498
  · exact adaptive143Third142Proof499
  · exact adaptive143Third142Proof500
  · exact adaptive143Third142Proof501
  · exact adaptive143Third142Proof502
  · exact adaptive143Third142Proof503
  · exact adaptive143Third142Proof504
  · exact adaptive143Third142Proof505
  · exact adaptive143Third142Proof506
  · exact adaptive143Third142Proof507
  · exact adaptive143Third142Proof508
  · exact adaptive143Third142Proof509
  · exact adaptive143Third142Proof510
  · exact adaptive143Third142Proof511
  · exact adaptive143Third142Proof512
  · exact adaptive143Third142Proof513
  · exact adaptive143Third142Proof514
  · exact adaptive143Third142Proof515
  · exact adaptive143Third142Proof516
  · exact adaptive143Third142Proof517
  · exact adaptive143Third142Proof518
  · exact adaptive143Third142Proof519
  · exact adaptive143Third142Proof520
  · exact adaptive143Third142Proof521
  · exact adaptive143Third142Proof522
  · exact adaptive143Third142Proof523
  · exact adaptive143Third142Proof524
  · exact adaptive143Third142Proof525
  · exact adaptive143Third142Proof526
  · exact adaptive143Third142Proof527
  · exact adaptive143Third142Proof528
  · exact adaptive143Third142Proof529
  · exact adaptive143Third142Proof530
  · exact adaptive143Third142Proof531
  · exact adaptive143Third142Proof532
  · exact adaptive143Third142Proof533
  · exact adaptive143Third142Proof534
  · exact adaptive143Third142Proof535
  · exact adaptive143Third142Proof536
  · exact adaptive143Third142Proof537
  · exact adaptive143Third142Proof538
  · exact adaptive143Third142Proof539
  · exact adaptive143Third142Proof540

#print axioms adaptive143Third142Proof496

theorem adaptive143Third142Proof417 : runCachedNode 511 130584 Adaptive143Third142Node417 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130584 Adaptive143Third142Node417 = [101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 132, 133, 134, 138, 139] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive143Third142Proof418
  · exact adaptive143Third142Proof419
  · exact adaptive143Third142Proof420
  · exact adaptive143Third142Proof421
  · exact adaptive143Third142Proof422
  · exact adaptive143Third142Proof423
  · exact adaptive143Third142Proof424
  · exact adaptive143Third142Proof425
  · exact adaptive143Third142Proof426
  · exact adaptive143Third142Proof427
  · exact adaptive143Third142Proof428
  · exact adaptive143Third142Proof429
  · exact adaptive143Third142Proof430
  · exact adaptive143Third142Proof431
  · exact adaptive143Third142Proof432
  · exact adaptive143Third142Proof433
  · exact adaptive143Third142Proof434
  · exact adaptive143Third142Proof435
  · exact adaptive143Third142Proof436
  · exact adaptive143Third142Proof437
  · exact adaptive143Third142Proof438
  · exact adaptive143Third142Proof439
  · exact adaptive143Third142Proof440
  · exact adaptive143Third142Proof441
  · exact adaptive143Third142Proof442
  · exact adaptive143Third142Proof443
  · exact adaptive143Third142Proof444
  · exact adaptive143Third142Proof445
  · exact adaptive143Third142Proof446
  · exact adaptive143Third142Proof447
  · exact adaptive143Third142Proof448
  · exact adaptive143Third142Proof449
  · exact adaptive143Third142Proof450
  · exact adaptive143Third142Proof451
  · exact adaptive143Third142Proof452
  · exact adaptive143Third142Proof496

#print axioms adaptive143Third142Proof417

theorem adaptive143Third142Proof0 : runCachedNode 511 130584 Adaptive143Third142Node0 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130584 Adaptive143Third142Node0 = [109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 132, 133, 134, 135, 136, 138, 139, 140, 141] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive143Third142Proof1
  · exact adaptive143Third142Proof2
  · exact adaptive143Third142Proof3
  · exact adaptive143Third142Proof4
  · exact adaptive143Third142Proof5
  · exact adaptive143Third142Proof6
  · exact adaptive143Third142Proof7
  · exact adaptive143Third142Proof8
  · exact adaptive143Third142Proof9
  · exact adaptive143Third142Proof10
  · exact adaptive143Third142Proof11
  · exact adaptive143Third142Proof12
  · exact adaptive143Third142Proof13
  · exact adaptive143Third142Proof14
  · exact adaptive143Third142Proof15
  · exact adaptive143Third142Proof16
  · exact adaptive143Third142Proof17
  · exact adaptive143Third142Proof18
  · exact adaptive143Third142Proof19
  · exact adaptive143Third142Proof20
  · exact adaptive143Third142Proof21
  · exact adaptive143Third142Proof22
  · exact adaptive143Third142Proof23
  · exact adaptive143Third142Proof49
  · exact adaptive143Third142Proof76
  · exact adaptive143Third142Proof104
  · exact adaptive143Third142Proof133
  · exact adaptive143Third142Proof164
  · exact adaptive143Third142Proof196
  · exact adaptive143Third142Proof305
  · exact adaptive143Third142Proof340
  · exact adaptive143Third142Proof417

#print axioms adaptive143Third142Proof0

end NineSeparatedSubsetSums
