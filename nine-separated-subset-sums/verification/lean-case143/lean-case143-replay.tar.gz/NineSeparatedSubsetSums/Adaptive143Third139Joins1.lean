import NineSeparatedSubsetSums.Adaptive143Third139State
import NineSeparatedSubsetSums.Adaptive143Third139Leaves6
import NineSeparatedSubsetSums.Adaptive143Third139Leaves24
import NineSeparatedSubsetSums.Adaptive143Third139Leaves23
import NineSeparatedSubsetSums.Adaptive143Third139Leaves22
import NineSeparatedSubsetSums.Adaptive143Third139Leaves21
import NineSeparatedSubsetSums.Adaptive143Third139Leaves19
import NineSeparatedSubsetSums.Adaptive143Third139Leaves20
import NineSeparatedSubsetSums.Adaptive143Third139Leaves11
import NineSeparatedSubsetSums.Adaptive143Third139Leaves18
import NineSeparatedSubsetSums.Adaptive143Third139Leaves17
import NineSeparatedSubsetSums.Adaptive143Third139Leaves16
import NineSeparatedSubsetSums.Adaptive143Third139Leaves13
import NineSeparatedSubsetSums.Adaptive143Third139Leaves15
import NineSeparatedSubsetSums.Adaptive143Third139Leaves4
import NineSeparatedSubsetSums.Adaptive143Third139Leaves12
import NineSeparatedSubsetSums.Adaptive143Third139Leaves5
import NineSeparatedSubsetSums.Adaptive143Third139Joins0
import NineSeparatedSubsetSums.Adaptive143Third139Leaves7
import NineSeparatedSubsetSums.Adaptive143Third139Leaves0
import NineSeparatedSubsetSums.Adaptive143Third139Leaves9
import NineSeparatedSubsetSums.Adaptive143Third139Leaves14
import NineSeparatedSubsetSums.Adaptive143Third139Leaves10
import NineSeparatedSubsetSums.Adaptive143Third139Leaves8
import NineSeparatedSubsetSums.Adaptive143Third139Leaves1

namespace NineSeparatedSubsetSums

theorem adaptive143Third139Proof217 : runCachedNode 511 130096 Adaptive143Third139Node217 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130096 Adaptive143Third139Node217 = [102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 130, 131, 132, 135, 136, 137] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive143Third139Proof218
  · exact adaptive143Third139Proof219
  · exact adaptive143Third139Proof220
  · exact adaptive143Third139Proof221
  · exact adaptive143Third139Proof222
  · exact adaptive143Third139Proof223
  · exact adaptive143Third139Proof224
  · exact adaptive143Third139Proof225
  · exact adaptive143Third139Proof226
  · exact adaptive143Third139Proof227
  · exact adaptive143Third139Proof228
  · exact adaptive143Third139Proof229
  · exact adaptive143Third139Proof230
  · exact adaptive143Third139Proof231
  · exact adaptive143Third139Proof232
  · exact adaptive143Third139Proof233
  · exact adaptive143Third139Proof234
  · exact adaptive143Third139Proof235
  · exact adaptive143Third139Proof236
  · exact adaptive143Third139Proof237
  · exact adaptive143Third139Proof238
  · exact adaptive143Third139Proof239
  · exact adaptive143Third139Proof240
  · exact adaptive143Third139Proof241
  · exact adaptive143Third139Proof242
  · exact adaptive143Third139Proof243
  · exact adaptive143Third139Proof244
  · exact adaptive143Third139Proof245
  · exact adaptive143Third139Proof246
  · exact adaptive143Third139Proof247
  · exact adaptive143Third139Proof248
  · exact adaptive143Third139Proof286
  · exact adaptive143Third139Proof287

#print axioms adaptive143Third139Proof217

theorem adaptive143Third139Proof0 : runCachedNode 511 130096 Adaptive143Third139Node0 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130096 Adaptive143Third139Node0 = [110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 132, 133, 135, 136, 137, 138] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive143Third139Proof1
  · exact adaptive143Third139Proof2
  · exact adaptive143Third139Proof3
  · exact adaptive143Third139Proof4
  · exact adaptive143Third139Proof5
  · exact adaptive143Third139Proof6
  · exact adaptive143Third139Proof7
  · exact adaptive143Third139Proof8
  · exact adaptive143Third139Proof9
  · exact adaptive143Third139Proof10
  · exact adaptive143Third139Proof11
  · exact adaptive143Third139Proof12
  · exact adaptive143Third139Proof13
  · exact adaptive143Third139Proof14
  · exact adaptive143Third139Proof15
  · exact adaptive143Third139Proof16
  · exact adaptive143Third139Proof17
  · exact adaptive143Third139Proof18
  · exact adaptive143Third139Proof19
  · exact adaptive143Third139Proof20
  · exact adaptive143Third139Proof21
  · exact adaptive143Third139Proof45
  · exact adaptive143Third139Proof70
  · exact adaptive143Third139Proof97
  · exact adaptive143Third139Proof125
  · exact adaptive143Third139Proof154
  · exact adaptive143Third139Proof185
  · exact adaptive143Third139Proof217

#print axioms adaptive143Third139Proof0

end NineSeparatedSubsetSums
