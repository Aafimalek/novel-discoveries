import NineSeparatedSubsetSums.Adaptive143Third134State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third134Proof22 : runCachedNode 511 129375 Adaptive143Third134Node22 = false := by
  decide +kernel

#print axioms adaptive143Third134Proof22

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third134Proof7 : runCachedNode 511 129375 Adaptive143Third134Node7 = false := by
  decide +kernel

#print axioms adaptive143Third134Proof7

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third134Proof3 : runCachedNode 511 129375 Adaptive143Third134Node3 = false := by
  decide +kernel

#print axioms adaptive143Third134Proof3

end NineSeparatedSubsetSums
