import NineSeparatedSubsetSums.Adaptive143Third142State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third142Proof226 : runCachedNode 511 130584 Adaptive143Third142Node226 = false := by
  decide +kernel

#print axioms adaptive143Third142Proof226

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third142Proof222 : runCachedNode 511 130584 Adaptive143Third142Node222 = false := by
  decide +kernel

#print axioms adaptive143Third142Proof222

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third142Proof8 : runCachedNode 511 130584 Adaptive143Third142Node8 = false := by
  decide +kernel

#print axioms adaptive143Third142Proof8

end NineSeparatedSubsetSums
