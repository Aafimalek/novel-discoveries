import NineSeparatedSubsetSums.Adaptive143Third141State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third141Proof221 : runCachedNode 511 130431 Adaptive143Third141Node221 = false := by
  decide +kernel

#print axioms adaptive143Third141Proof221

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third141Proof222 : runCachedNode 511 130431 Adaptive143Third141Node222 = false := by
  decide +kernel

#print axioms adaptive143Third141Proof222

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third141Proof176 : runCachedNode 511 130431 Adaptive143Third141Node176 = false := by
  decide +kernel

#print axioms adaptive143Third141Proof176

end NineSeparatedSubsetSums
