import NineSeparatedSubsetSums.Adaptive143Third119State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third119Proof0 : runCachedNode 511 125830 Adaptive143Third119Node0 = false := by
  decide +kernel

#print axioms adaptive143Third119Proof0

end NineSeparatedSubsetSums
