import NineSeparatedSubsetSums.EightPointPackedGeometry
import NineSeparatedSubsetSums.EightPoint143_123PackedBudget0
import NineSeparatedSubsetSums.EightPoint143_123PackedAnchor0Part0
import NineSeparatedSubsetSums.EightPoint143_123PackedAnchor0Part1
import NineSeparatedSubsetSums.EightPoint143_123PackedAnchor0Part2
import NineSeparatedSubsetSums.EightPoint143_123PackedBudget1
import NineSeparatedSubsetSums.EightPoint143_123PackedAnchor1Part0
import NineSeparatedSubsetSums.EightPoint143_123PackedAnchor1Part1
import NineSeparatedSubsetSums.EightPoint143_123PackedAnchor1Part2

namespace NineSeparatedSubsetSums

private theorem packedOct143_123Anchor0 :
  ∀ j : Fin 483, ((j.val : Int)+143+123)%2=0 →
    2322454 ≤ FourPointNumeric.octPackedCharge 143 123 20 packedOct143_123_0 (j.val : Int) := by
  intro j hj
  let k := (j.val-0)/2
  have hk : k < 242 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+0 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint143_123PackedAnchor0Part0 z
    rwa [he,hrep] at ht
  by_cases h1 : k < 240
  · let z : Fin 120 := ⟨k-120, by omega⟩
    have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
    have ht := eightPoint143_123PackedAnchor0Part1 z
    rwa [he,hrep] at ht
  let z : Fin 2 := ⟨k-240, by omega⟩
  have he : (z.val : Int)+240 = k := by dsimp [z] <;> omega
  have ht := eightPoint143_123PackedAnchor0Part2 z
  rwa [he,hrep] at ht

private theorem packedOct143_123Anchor1 :
  ∀ j : Fin 483, ((j.val : Int)+143+123)%2=1 →
    2324317 ≤ FourPointNumeric.octPackedCharge 143 123 20 packedOct143_123_1 (j.val : Int) := by
  intro j hj
  let k := (j.val-1)/2
  have hk : k < 241 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+1 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint143_123PackedAnchor1Part0 z
    rwa [he,hrep] at ht
  by_cases h1 : k < 240
  · let z : Fin 120 := ⟨k-120, by omega⟩
    have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
    have ht := eightPoint143_123PackedAnchor1Part1 z
    rwa [he,hrep] at ht
  let z : Fin 1 := ⟨k-240, by omega⟩
  have he : (z.val : Int)+240 = k := by dsimp [z] <;> omega
  have ht := eightPoint143_123PackedAnchor1Part2 z
  rwa [he,hrep] at ht

def packedOctCertificate143_123_0 : EightPointCertificate 143 123 0 126697 :=
  eightPointCertificateOfPacked 143 123 0 126697 2322454 20 packedOct143_123_0 477 483
    (by decide +kernel) (by decide) packedOct143_123Anchor0
    (by rw [packedOct143_123_0_budget]; decide)

def packedOctCertificate143_123_1 : EightPointCertificate 143 123 1 126697 :=
  eightPointCertificateOfPacked 143 123 1 126697 2324317 20 packedOct143_123_1 474 483
    (by decide +kernel) (by decide) packedOct143_123Anchor1
    (by rw [packedOct143_123_1_budget]; decide)

theorem max148_second143_third123_eightPoint_moment_bound (tail : List ℕ) (len : tail.length=6)
    (distinct : (natSubsetSums (148::143::123::tail)).Nodup) :
    126697 ≤ ((148::143::123::tail).map (· ^ 2)).sum := by
  apply eightPointNatMomentLower 143 123 126697 tail len distinct
  intro p hp
  by_cases h : p=0
  · subst p
    exact packedOctCertificate143_123_0
  · have he : p=1 := hp.resolve_left h
    subst p
    exact packedOctCertificate143_123_1

#print axioms max148_second143_third123_eightPoint_moment_bound

end NineSeparatedSubsetSums
