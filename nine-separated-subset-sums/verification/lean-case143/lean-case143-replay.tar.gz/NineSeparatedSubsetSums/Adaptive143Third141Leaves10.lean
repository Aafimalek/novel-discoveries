import NineSeparatedSubsetSums.Adaptive143Third141State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third141Proof129 : runCachedNode 511 130431 Adaptive143Third141Node129 = false := by
  decide +kernel

#print axioms adaptive143Third141Proof129

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third141Proof263 : runCachedNode 511 130431 Adaptive143Third141Node263 = false := by
  decide +kernel

#print axioms adaptive143Third141Proof263

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third141Proof362 : runCachedNode 511 130431 Adaptive143Third141Node362 = false := by
  decide +kernel

#print axioms adaptive143Third141Proof362

end NineSeparatedSubsetSums
