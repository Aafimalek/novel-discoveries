import NineSeparatedSubsetSums.Adaptive143Third139State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third139Proof184 : runCachedNode 511 130096 Adaptive143Third139Node184 = false := by
  decide +kernel

#print axioms adaptive143Third139Proof184

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third139Proof285 : runCachedNode 511 130096 Adaptive143Third139Node285 = false := by
  decide +kernel

#print axioms adaptive143Third139Proof285

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third139Proof271 : runCachedNode 511 130096 Adaptive143Third139Node271 = false := by
  decide +kernel

#print axioms adaptive143Third139Proof271

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third139Proof98 : runCachedNode 511 130096 Adaptive143Third139Node98 = false := by
  decide +kernel

#print axioms adaptive143Third139Proof98

end NineSeparatedSubsetSums
