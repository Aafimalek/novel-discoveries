import NineSeparatedSubsetSums.Adaptive143Third138State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third138Proof201 : runCachedNode 511 129927 Adaptive143Third138Node201 = false := by
  decide +kernel

#print axioms adaptive143Third138Proof201

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third138Proof15 : runCachedNode 511 129927 Adaptive143Third138Node15 = false := by
  decide +kernel

#print axioms adaptive143Third138Proof15

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third138Proof128 : runCachedNode 511 129927 Adaptive143Third138Node128 = false := by
  decide +kernel

#print axioms adaptive143Third138Proof128

end NineSeparatedSubsetSums
