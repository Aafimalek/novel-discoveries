import NineSeparatedSubsetSums.Adaptive143Third137State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third137Proof100 : runCachedNode 511 129784 Adaptive143Third137Node100 = false := by
  decide +kernel

#print axioms adaptive143Third137Proof100

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third137Proof157 : runCachedNode 511 129784 Adaptive143Third137Node157 = false := by
  decide +kernel

#print axioms adaptive143Third137Proof157

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third137Proof29 : runCachedNode 511 129784 Adaptive143Third137Node29 = false := by
  decide +kernel

#print axioms adaptive143Third137Proof29

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third137Proof23 : runCachedNode 511 129784 Adaptive143Third137Node23 = false := by
  decide +kernel

#print axioms adaptive143Third137Proof23

end NineSeparatedSubsetSums
