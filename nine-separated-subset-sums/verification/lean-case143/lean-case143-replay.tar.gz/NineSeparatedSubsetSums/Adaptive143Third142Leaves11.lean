import NineSeparatedSubsetSums.Adaptive143Third142State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third142Proof223 : runCachedNode 511 130584 Adaptive143Third142Node223 = false := by
  decide +kernel

#print axioms adaptive143Third142Proof223

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third142Proof373 : runCachedNode 511 130584 Adaptive143Third142Node373 = false := by
  decide +kernel

#print axioms adaptive143Third142Proof373

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third142Proof247 : runCachedNode 511 130584 Adaptive143Third142Node247 = false := by
  decide +kernel

#print axioms adaptive143Third142Proof247

end NineSeparatedSubsetSums
