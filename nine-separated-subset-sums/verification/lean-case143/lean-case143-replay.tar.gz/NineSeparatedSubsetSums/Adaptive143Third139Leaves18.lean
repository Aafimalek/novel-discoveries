import NineSeparatedSubsetSums.Adaptive143Third139State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third139Proof39 : runCachedNode 511 130096 Adaptive143Third139Node39 = false := by
  decide +kernel

#print axioms adaptive143Third139Proof39

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third139Proof42 : runCachedNode 511 130096 Adaptive143Third139Node42 = false := by
  decide +kernel

#print axioms adaptive143Third139Proof42

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third139Proof212 : runCachedNode 511 130096 Adaptive143Third139Node212 = false := by
  decide +kernel

#print axioms adaptive143Third139Proof212

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third139Proof235 : runCachedNode 511 130096 Adaptive143Third139Node235 = false := by
  decide +kernel

#print axioms adaptive143Third139Proof235

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third139Proof118 : runCachedNode 511 130096 Adaptive143Third139Node118 = false := by
  decide +kernel

#print axioms adaptive143Third139Proof118

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third139Proof119 : runCachedNode 511 130096 Adaptive143Third139Node119 = false := by
  decide +kernel

#print axioms adaptive143Third139Proof119

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third139Proof209 : runCachedNode 511 130096 Adaptive143Third139Node209 = false := by
  decide +kernel

#print axioms adaptive143Third139Proof209

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third139Proof237 : runCachedNode 511 130096 Adaptive143Third139Node237 = false := by
  decide +kernel

#print axioms adaptive143Third139Proof237

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third139Proof65 : runCachedNode 511 130096 Adaptive143Third139Node65 = false := by
  decide +kernel

#print axioms adaptive143Third139Proof65

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third139Proof282 : runCachedNode 511 130096 Adaptive143Third139Node282 = false := by
  decide +kernel

#print axioms adaptive143Third139Proof282

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third139Proof207 : runCachedNode 511 130096 Adaptive143Third139Node207 = false := by
  decide +kernel

#print axioms adaptive143Third139Proof207

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third139Proof38 : runCachedNode 511 130096 Adaptive143Third139Node38 = false := by
  decide +kernel

#print axioms adaptive143Third139Proof38

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third139Proof169 : runCachedNode 511 130096 Adaptive143Third139Node169 = false := by
  decide +kernel

#print axioms adaptive143Third139Proof169

end NineSeparatedSubsetSums
