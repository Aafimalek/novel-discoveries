import NineSeparatedSubsetSums.Adaptive143Third142State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third142Proof372 : runCachedNode 511 130584 Adaptive143Third142Node372 = false := by
  decide +kernel

#print axioms adaptive143Third142Proof372

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third142Proof224 : runCachedNode 511 130584 Adaptive143Third142Node224 = false := by
  decide +kernel

#print axioms adaptive143Third142Proof224

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third142Proof34 : runCachedNode 511 130584 Adaptive143Third142Node34 = false := by
  decide +kernel

#print axioms adaptive143Third142Proof34

end NineSeparatedSubsetSums
