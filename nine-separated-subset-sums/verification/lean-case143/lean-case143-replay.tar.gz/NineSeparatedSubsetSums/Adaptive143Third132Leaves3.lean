import NineSeparatedSubsetSums.Adaptive143Third132State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third132Proof14 : runCachedNode 511 128948 Adaptive143Third132Node14 = false := by
  decide +kernel

#print axioms adaptive143Third132Proof14

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third132Proof13 : runCachedNode 511 128948 Adaptive143Third132Node13 = false := by
  decide +kernel

#print axioms adaptive143Third132Proof13

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third132Proof12 : runCachedNode 511 128948 Adaptive143Third132Node12 = false := by
  decide +kernel

#print axioms adaptive143Third132Proof12

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third132Proof11 : runCachedNode 511 128948 Adaptive143Third132Node11 = false := by
  decide +kernel

#print axioms adaptive143Third132Proof11

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third132Proof10 : runCachedNode 511 128948 Adaptive143Third132Node10 = false := by
  decide +kernel

#print axioms adaptive143Third132Proof10

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third132Proof9 : runCachedNode 511 128948 Adaptive143Third132Node9 = false := by
  decide +kernel

#print axioms adaptive143Third132Proof9

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third132Proof7 : runCachedNode 511 128948 Adaptive143Third132Node7 = false := by
  decide +kernel

#print axioms adaptive143Third132Proof7

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third132Proof5 : runCachedNode 511 128948 Adaptive143Third132Node5 = false := by
  decide +kernel

#print axioms adaptive143Third132Proof5

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third132Proof2 : runCachedNode 511 128948 Adaptive143Third132Node2 = false := by
  decide +kernel

#print axioms adaptive143Third132Proof2

end NineSeparatedSubsetSums
