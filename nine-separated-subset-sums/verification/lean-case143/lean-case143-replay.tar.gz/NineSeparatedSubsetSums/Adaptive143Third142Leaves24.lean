import NineSeparatedSubsetSums.Adaptive143Third142State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third142Proof368 : runCachedNode 511 130584 Adaptive143Third142Node368 = false := by
  decide +kernel

#print axioms adaptive143Third142Proof368

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third142Proof303 : runCachedNode 511 130584 Adaptive143Third142Node303 = false := by
  decide +kernel

#print axioms adaptive143Third142Proof303

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third142Proof75 : runCachedNode 511 130584 Adaptive143Third142Node75 = false := by
  decide +kernel

#print axioms adaptive143Third142Proof75

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third142Proof369 : runCachedNode 511 130584 Adaptive143Third142Node369 = false := by
  decide +kernel

#print axioms adaptive143Third142Proof369

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third142Proof442 : runCachedNode 511 130584 Adaptive143Third142Node442 = false := by
  decide +kernel

#print axioms adaptive143Third142Proof442

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third142Proof25 : runCachedNode 511 130584 Adaptive143Third142Node25 = false := by
  decide +kernel

#print axioms adaptive143Third142Proof25

end NineSeparatedSubsetSums
