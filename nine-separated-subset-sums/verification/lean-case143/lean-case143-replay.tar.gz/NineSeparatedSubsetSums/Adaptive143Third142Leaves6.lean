import NineSeparatedSubsetSums.Adaptive143Third142State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third142Proof21 : runCachedNode 511 130584 Adaptive143Third142Node21 = false := by
  decide +kernel

#print axioms adaptive143Third142Proof21

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third142Proof132 : runCachedNode 511 130584 Adaptive143Third142Node132 = false := by
  decide +kernel

#print axioms adaptive143Third142Proof132

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third142Proof54 : runCachedNode 511 130584 Adaptive143Third142Node54 = false := by
  decide +kernel

#print axioms adaptive143Third142Proof54

end NineSeparatedSubsetSums
