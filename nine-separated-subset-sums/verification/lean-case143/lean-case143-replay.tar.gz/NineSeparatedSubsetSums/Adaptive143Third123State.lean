import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive143Third123Node0 : CachedSearchNode :=
  ⟨4, 122, computeCenteredMask [148,143,123], 414, 57482⟩

end NineSeparatedSubsetSums
