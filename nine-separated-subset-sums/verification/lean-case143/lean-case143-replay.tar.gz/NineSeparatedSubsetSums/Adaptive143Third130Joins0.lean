import NineSeparatedSubsetSums.Adaptive143Third130State
import NineSeparatedSubsetSums.Adaptive143Third130Leaves0
import NineSeparatedSubsetSums.Adaptive143Third130Leaves1
import NineSeparatedSubsetSums.Adaptive143Third130Leaves2

namespace NineSeparatedSubsetSums

theorem adaptive143Third130Proof0 : runCachedNode 511 128577 Adaptive143Third130Node0 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 128577 Adaptive143Third130Node0 = [110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 126, 127, 128, 129] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive143Third130Proof1
  · exact adaptive143Third130Proof2
  · exact adaptive143Third130Proof3
  · exact adaptive143Third130Proof4
  · exact adaptive143Third130Proof5
  · exact adaptive143Third130Proof6
  · exact adaptive143Third130Proof7
  · exact adaptive143Third130Proof8
  · exact adaptive143Third130Proof9
  · exact adaptive143Third130Proof10
  · exact adaptive143Third130Proof11
  · exact adaptive143Third130Proof12
  · exact adaptive143Third130Proof13
  · exact adaptive143Third130Proof14
  · exact adaptive143Third130Proof15
  · exact adaptive143Third130Proof16
  · exact adaptive143Third130Proof17
  · exact adaptive143Third130Proof18
  · exact adaptive143Third130Proof19

#print axioms adaptive143Third130Proof0

end NineSeparatedSubsetSums
