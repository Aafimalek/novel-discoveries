import NineSeparatedSubsetSums.Adaptive143Third104Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint143Checked

namespace NineSeparatedSubsetSums


theorem adaptive143Third104 : NoDescendingTailAfterThird 143 104 :=
  noDescendingThirdTail_of_cached 143 104 112040 (fun t ht nd => max148_second143_fourPoint_moment_bound (104::t) (by simp [ht]) nd) adaptive143Third104Proof0

#print axioms adaptive143Third104

end NineSeparatedSubsetSums
