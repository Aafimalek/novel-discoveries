import NineSeparatedSubsetSums.Adaptive143Third141State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third141Proof295 : runCachedNode 511 130431 Adaptive143Third141Node295 = false := by
  decide +kernel

#print axioms adaptive143Third141Proof295

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third141Proof290 : runCachedNode 511 130431 Adaptive143Third141Node290 = false := by
  decide +kernel

#print axioms adaptive143Third141Proof290

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third141Proof2 : runCachedNode 511 130431 Adaptive143Third141Node2 = false := by
  decide +kernel

#print axioms adaptive143Third141Proof2

end NineSeparatedSubsetSums
