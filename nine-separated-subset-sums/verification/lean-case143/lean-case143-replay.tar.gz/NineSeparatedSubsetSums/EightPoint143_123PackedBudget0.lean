import NineSeparatedSubsetSums.EightPoint143_123PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct143_123_0_budget :
    FourPointNumeric.packedBudget 20 packedOct143_123_0 477 = 83768316 := by decide +kernel

#print axioms packedOct143_123_0_budget

end NineSeparatedSubsetSums
