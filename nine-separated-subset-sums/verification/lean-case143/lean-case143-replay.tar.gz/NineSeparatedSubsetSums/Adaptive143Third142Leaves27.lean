import NineSeparatedSubsetSums.Adaptive143Third142State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third142Proof302 : runCachedNode 511 130584 Adaptive143Third142Node302 = false := by
  decide +kernel

#print axioms adaptive143Third142Proof302

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third142Proof334 : runCachedNode 511 130584 Adaptive143Third142Node334 = false := by
  decide +kernel

#print axioms adaptive143Third142Proof334

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third142Proof128 : runCachedNode 511 130584 Adaptive143Third142Node128 = false := by
  decide +kernel

#print axioms adaptive143Third142Proof128

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third142Proof336 : runCachedNode 511 130584 Adaptive143Third142Node336 = false := by
  decide +kernel

#print axioms adaptive143Third142Proof336

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third142Proof129 : runCachedNode 511 130584 Adaptive143Third142Node129 = false := by
  decide +kernel

#print axioms adaptive143Third142Proof129

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third142Proof186 : runCachedNode 511 130584 Adaptive143Third142Node186 = false := by
  decide +kernel

#print axioms adaptive143Third142Proof186

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third142Proof60 : runCachedNode 511 130584 Adaptive143Third142Node60 = false := by
  decide +kernel

#print axioms adaptive143Third142Proof60

end NineSeparatedSubsetSums
