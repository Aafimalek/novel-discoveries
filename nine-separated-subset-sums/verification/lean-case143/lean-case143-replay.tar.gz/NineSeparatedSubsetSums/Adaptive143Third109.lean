import NineSeparatedSubsetSums.Adaptive143Third109Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint143Checked

namespace NineSeparatedSubsetSums


theorem adaptive143Third109 : NoDescendingTailAfterThird 143 109 :=
  noDescendingThirdTail_of_cached 143 109 112040 (fun t ht nd => max148_second143_fourPoint_moment_bound (109::t) (by simp [ht]) nd) adaptive143Third109Proof0

#print axioms adaptive143Third109

end NineSeparatedSubsetSums
