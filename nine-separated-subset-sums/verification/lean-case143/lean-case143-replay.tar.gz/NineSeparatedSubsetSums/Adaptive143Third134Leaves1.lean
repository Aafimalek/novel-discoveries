import NineSeparatedSubsetSums.Adaptive143Third134State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third134Proof23 : runCachedNode 511 129375 Adaptive143Third134Node23 = false := by
  decide +kernel

#print axioms adaptive143Third134Proof23

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third134Proof11 : runCachedNode 511 129375 Adaptive143Third134Node11 = false := by
  decide +kernel

#print axioms adaptive143Third134Proof11

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third134Proof5 : runCachedNode 511 129375 Adaptive143Third134Node5 = false := by
  decide +kernel

#print axioms adaptive143Third134Proof5

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third134Proof1 : runCachedNode 511 129375 Adaptive143Third134Node1 = false := by
  decide +kernel

#print axioms adaptive143Third134Proof1

end NineSeparatedSubsetSums
