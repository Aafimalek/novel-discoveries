import NineSeparatedSubsetSums.Adaptive143Third123State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third123Proof0 : runCachedNode 511 126697 Adaptive143Third123Node0 = false := by
  decide +kernel

#print axioms adaptive143Third123Proof0

end NineSeparatedSubsetSums
