import NineSeparatedSubsetSums.EightPoint143_121PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint143_121PackedAnchor0Part0 :
    ∀ j : Fin 120, 2293710 ≤ FourPointNumeric.octPackedCharge 143 121 20 packedOct143_121_0
      (2*((j.val : Int)+0)+0) := by decide +kernel

end NineSeparatedSubsetSums
