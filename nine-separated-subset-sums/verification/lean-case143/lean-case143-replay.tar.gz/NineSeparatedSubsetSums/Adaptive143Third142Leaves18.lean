import NineSeparatedSubsetSums.Adaptive143Third142State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third142Proof445 : runCachedNode 511 130584 Adaptive143Third142Node445 = false := by
  decide +kernel

#print axioms adaptive143Third142Proof445

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third142Proof17 : runCachedNode 511 130584 Adaptive143Third142Node17 = false := by
  decide +kernel

#print axioms adaptive143Third142Proof17

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third142Proof131 : runCachedNode 511 130584 Adaptive143Third142Node131 = false := by
  decide +kernel

#print axioms adaptive143Third142Proof131

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third142Proof358 : runCachedNode 511 130584 Adaptive143Third142Node358 = false := by
  decide +kernel

#print axioms adaptive143Third142Proof358

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third142Proof50 : runCachedNode 511 130584 Adaptive143Third142Node50 = false := by
  decide +kernel

#print axioms adaptive143Third142Proof50

end NineSeparatedSubsetSums
