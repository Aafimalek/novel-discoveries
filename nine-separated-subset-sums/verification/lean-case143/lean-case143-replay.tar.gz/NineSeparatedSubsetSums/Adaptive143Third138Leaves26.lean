import NineSeparatedSubsetSums.Adaptive143Third138State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third138Proof136 : runCachedNode 511 129927 Adaptive143Third138Node136 = false := by
  decide +kernel

#print axioms adaptive143Third138Proof136

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third138Proof253 : runCachedNode 511 129927 Adaptive143Third138Node253 = false := by
  decide +kernel

#print axioms adaptive143Third138Proof253

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third138Proof194 : runCachedNode 511 129927 Adaptive143Third138Node194 = false := by
  decide +kernel

#print axioms adaptive143Third138Proof194

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third138Proof163 : runCachedNode 511 129927 Adaptive143Third138Node163 = false := by
  decide +kernel

#print axioms adaptive143Third138Proof163

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third138Proof34 : runCachedNode 511 129927 Adaptive143Third138Node34 = false := by
  decide +kernel

#print axioms adaptive143Third138Proof34

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third138Proof85 : runCachedNode 511 129927 Adaptive143Third138Node85 = false := by
  decide +kernel

#print axioms adaptive143Third138Proof85

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third138Proof83 : runCachedNode 511 129927 Adaptive143Third138Node83 = false := by
  decide +kernel

#print axioms adaptive143Third138Proof83

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third138Proof161 : runCachedNode 511 129927 Adaptive143Third138Node161 = false := by
  decide +kernel

#print axioms adaptive143Third138Proof161

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third138Proof191 : runCachedNode 511 129927 Adaptive143Third138Node191 = false := by
  decide +kernel

#print axioms adaptive143Third138Proof191

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third138Proof252 : runCachedNode 511 129927 Adaptive143Third138Node252 = false := by
  decide +kernel

#print axioms adaptive143Third138Proof252

end NineSeparatedSubsetSums
