import NineSeparatedSubsetSums.Adaptive143Third108Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint143Checked

namespace NineSeparatedSubsetSums


theorem adaptive143Third108 : NoDescendingTailAfterThird 143 108 :=
  noDescendingThirdTail_of_cached 143 108 112040 (fun t ht nd => max148_second143_fourPoint_moment_bound (108::t) (by simp [ht]) nd) adaptive143Third108Proof0

#print axioms adaptive143Third108

end NineSeparatedSubsetSums
