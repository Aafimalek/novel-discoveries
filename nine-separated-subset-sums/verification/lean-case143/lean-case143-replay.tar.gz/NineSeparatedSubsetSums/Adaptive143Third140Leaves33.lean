import NineSeparatedSubsetSums.Adaptive143Third140State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third140Proof314 : runCachedNode 511 130276 Adaptive143Third140Node314 = false := by
  decide +kernel

#print axioms adaptive143Third140Proof314

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third140Proof315 : runCachedNode 511 130276 Adaptive143Third140Node315 = false := by
  decide +kernel

#print axioms adaptive143Third140Proof315

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third140Proof316 : runCachedNode 511 130276 Adaptive143Third140Node316 = false := by
  decide +kernel

#print axioms adaptive143Third140Proof316

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third140Proof317 : runCachedNode 511 130276 Adaptive143Third140Node317 = false := by
  decide +kernel

#print axioms adaptive143Third140Proof317

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third140Proof318 : runCachedNode 511 130276 Adaptive143Third140Node318 = false := by
  decide +kernel

#print axioms adaptive143Third140Proof318

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third140Proof319 : runCachedNode 511 130276 Adaptive143Third140Node319 = false := by
  decide +kernel

#print axioms adaptive143Third140Proof319

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third140Proof320 : runCachedNode 511 130276 Adaptive143Third140Node320 = false := by
  decide +kernel

#print axioms adaptive143Third140Proof320

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third140Proof321 : runCachedNode 511 130276 Adaptive143Third140Node321 = false := by
  decide +kernel

#print axioms adaptive143Third140Proof321

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third140Proof322 : runCachedNode 511 130276 Adaptive143Third140Node322 = false := by
  decide +kernel

#print axioms adaptive143Third140Proof322

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third140Proof354 : runCachedNode 511 130276 Adaptive143Third140Node354 = false := by
  decide +kernel

#print axioms adaptive143Third140Proof354

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third140Proof355 : runCachedNode 511 130276 Adaptive143Third140Node355 = false := by
  decide +kernel

#print axioms adaptive143Third140Proof355

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third140Proof356 : runCachedNode 511 130276 Adaptive143Third140Node356 = false := by
  decide +kernel

#print axioms adaptive143Third140Proof356

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third140Proof357 : runCachedNode 511 130276 Adaptive143Third140Node357 = false := by
  decide +kernel

#print axioms adaptive143Third140Proof357

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third140Proof358 : runCachedNode 511 130276 Adaptive143Third140Node358 = false := by
  decide +kernel

#print axioms adaptive143Third140Proof358

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third140Proof359 : runCachedNode 511 130276 Adaptive143Third140Node359 = false := by
  decide +kernel

#print axioms adaptive143Third140Proof359

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third140Proof360 : runCachedNode 511 130276 Adaptive143Third140Node360 = false := by
  decide +kernel

#print axioms adaptive143Third140Proof360

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third140Proof361 : runCachedNode 511 130276 Adaptive143Third140Node361 = false := by
  decide +kernel

#print axioms adaptive143Third140Proof361

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third140Proof362 : runCachedNode 511 130276 Adaptive143Third140Node362 = false := by
  decide +kernel

#print axioms adaptive143Third140Proof362

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third140Proof363 : runCachedNode 511 130276 Adaptive143Third140Node363 = false := by
  decide +kernel

#print axioms adaptive143Third140Proof363

end NineSeparatedSubsetSums
