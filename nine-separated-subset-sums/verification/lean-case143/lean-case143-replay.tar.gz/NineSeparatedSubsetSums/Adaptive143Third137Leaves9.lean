import NineSeparatedSubsetSums.Adaptive143Third137State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third137Proof12 : runCachedNode 511 129784 Adaptive143Third137Node12 = false := by
  decide +kernel

#print axioms adaptive143Third137Proof12

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third137Proof99 : runCachedNode 511 129784 Adaptive143Third137Node99 = false := by
  decide +kernel

#print axioms adaptive143Third137Proof99

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third137Proof125 : runCachedNode 511 129784 Adaptive143Third137Node125 = false := by
  decide +kernel

#print axioms adaptive143Third137Proof125

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third137Proof127 : runCachedNode 511 129784 Adaptive143Third137Node127 = false := by
  decide +kernel

#print axioms adaptive143Third137Proof127

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third137Proof70 : runCachedNode 511 129784 Adaptive143Third137Node70 = false := by
  decide +kernel

#print axioms adaptive143Third137Proof70

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third137Proof155 : runCachedNode 511 129784 Adaptive143Third137Node155 = false := by
  decide +kernel

#print axioms adaptive143Third137Proof155

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third137Proof42 : runCachedNode 511 129784 Adaptive143Third137Node42 = false := by
  decide +kernel

#print axioms adaptive143Third137Proof42

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third137Proof39 : runCachedNode 511 129784 Adaptive143Third137Node39 = false := by
  decide +kernel

#print axioms adaptive143Third137Proof39

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third137Proof72 : runCachedNode 511 129784 Adaptive143Third137Node72 = false := by
  decide +kernel

#print axioms adaptive143Third137Proof72

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third137Proof114 : runCachedNode 511 129784 Adaptive143Third137Node114 = false := by
  decide +kernel

#print axioms adaptive143Third137Proof114

end NineSeparatedSubsetSums
