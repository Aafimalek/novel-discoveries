import NineSeparatedSubsetSums.Adaptive143Third137State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third137Proof20 : runCachedNode 511 129784 Adaptive143Third137Node20 = false := by
  decide +kernel

#print axioms adaptive143Third137Proof20

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third137Proof73 : runCachedNode 511 129784 Adaptive143Third137Node73 = false := by
  decide +kernel

#print axioms adaptive143Third137Proof73

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third137Proof67 : runCachedNode 511 129784 Adaptive143Third137Node67 = false := by
  decide +kernel

#print axioms adaptive143Third137Proof67

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third137Proof48 : runCachedNode 511 129784 Adaptive143Third137Node48 = false := by
  decide +kernel

#print axioms adaptive143Third137Proof48

end NineSeparatedSubsetSums
