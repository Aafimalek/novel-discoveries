import NineSeparatedSubsetSums.Adaptive143Third138State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third138Proof169 : runCachedNode 511 129927 Adaptive143Third138Node169 = false := by
  decide +kernel

#print axioms adaptive143Third138Proof169

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third138Proof196 : runCachedNode 511 129927 Adaptive143Third138Node196 = false := by
  decide +kernel

#print axioms adaptive143Third138Proof196

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third138Proof20 : runCachedNode 511 129927 Adaptive143Third138Node20 = false := by
  decide +kernel

#print axioms adaptive143Third138Proof20

end NineSeparatedSubsetSums
