import NineSeparatedSubsetSums.Adaptive143Third138State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third138Proof168 : runCachedNode 511 129927 Adaptive143Third138Node168 = false := by
  decide +kernel

#print axioms adaptive143Third138Proof168

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third138Proof264 : runCachedNode 511 129927 Adaptive143Third138Node264 = false := by
  decide +kernel

#print axioms adaptive143Third138Proof264

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third138Proof117 : runCachedNode 511 129927 Adaptive143Third138Node117 = false := by
  decide +kernel

#print axioms adaptive143Third138Proof117

end NineSeparatedSubsetSums
