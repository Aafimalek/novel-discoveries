import NineSeparatedSubsetSums.Adaptive143Third139State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third139Proof188 : runCachedNode 511 130096 Adaptive143Third139Node188 = false := by
  decide +kernel

#print axioms adaptive143Third139Proof188

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third139Proof189 : runCachedNode 511 130096 Adaptive143Third139Node189 = false := by
  decide +kernel

#print axioms adaptive143Third139Proof189

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third139Proof190 : runCachedNode 511 130096 Adaptive143Third139Node190 = false := by
  decide +kernel

#print axioms adaptive143Third139Proof190

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third139Proof191 : runCachedNode 511 130096 Adaptive143Third139Node191 = false := by
  decide +kernel

#print axioms adaptive143Third139Proof191

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third139Proof257 : runCachedNode 511 130096 Adaptive143Third139Node257 = false := by
  decide +kernel

#print axioms adaptive143Third139Proof257

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third139Proof258 : runCachedNode 511 130096 Adaptive143Third139Node258 = false := by
  decide +kernel

#print axioms adaptive143Third139Proof258

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third139Proof254 : runCachedNode 511 130096 Adaptive143Third139Node254 = false := by
  decide +kernel

#print axioms adaptive143Third139Proof254

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third139Proof255 : runCachedNode 511 130096 Adaptive143Third139Node255 = false := by
  decide +kernel

#print axioms adaptive143Third139Proof255

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third139Proof256 : runCachedNode 511 130096 Adaptive143Third139Node256 = false := by
  decide +kernel

#print axioms adaptive143Third139Proof256

end NineSeparatedSubsetSums
