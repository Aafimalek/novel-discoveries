import NineSeparatedSubsetSums.Adaptive143Third140State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third140Proof18 : runCachedNode 511 130276 Adaptive143Third140Node18 = false := by
  decide +kernel

#print axioms adaptive143Third140Proof18

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third140Proof199 : runCachedNode 511 130276 Adaptive143Third140Node199 = false := by
  decide +kernel

#print axioms adaptive143Third140Proof199

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third140Proof150 : runCachedNode 511 130276 Adaptive143Third140Node150 = false := by
  decide +kernel

#print axioms adaptive143Third140Proof150

end NineSeparatedSubsetSums
