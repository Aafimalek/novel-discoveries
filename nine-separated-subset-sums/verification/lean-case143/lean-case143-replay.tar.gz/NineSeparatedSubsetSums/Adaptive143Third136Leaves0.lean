import NineSeparatedSubsetSums.Adaptive143Third136State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third136Proof47 : runCachedNode 511 129643 Adaptive143Third136Node47 = false := by
  decide +kernel

#print axioms adaptive143Third136Proof47

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third136Proof7 : runCachedNode 511 129643 Adaptive143Third136Node7 = false := by
  decide +kernel

#print axioms adaptive143Third136Proof7

end NineSeparatedSubsetSums
