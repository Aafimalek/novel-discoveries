import NineSeparatedSubsetSums.Adaptive143Third129State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third129Proof18 : runCachedNode 511 128295 Adaptive143Third129Node18 = false := by
  decide +kernel

#print axioms adaptive143Third129Proof18

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third129Proof17 : runCachedNode 511 128295 Adaptive143Third129Node17 = false := by
  decide +kernel

#print axioms adaptive143Third129Proof17

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third129Proof16 : runCachedNode 511 128295 Adaptive143Third129Node16 = false := by
  decide +kernel

#print axioms adaptive143Third129Proof16

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third129Proof13 : runCachedNode 511 128295 Adaptive143Third129Node13 = false := by
  decide +kernel

#print axioms adaptive143Third129Proof13

end NineSeparatedSubsetSums
