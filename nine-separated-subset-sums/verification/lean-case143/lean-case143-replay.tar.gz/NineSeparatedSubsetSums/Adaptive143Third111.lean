import NineSeparatedSubsetSums.Adaptive143Third111Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint143Checked

namespace NineSeparatedSubsetSums


theorem adaptive143Third111 : NoDescendingTailAfterThird 143 111 :=
  noDescendingThirdTail_of_cached 143 111 112040 (fun t ht nd => max148_second143_fourPoint_moment_bound (111::t) (by simp [ht]) nd) adaptive143Third111Proof0

#print axioms adaptive143Third111

end NineSeparatedSubsetSums
