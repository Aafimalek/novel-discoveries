import NineSeparatedSubsetSums.Adaptive143Third135State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third135Proof18 : runCachedNode 511 129468 Adaptive143Third135Node18 = false := by
  decide +kernel

#print axioms adaptive143Third135Proof18

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third135Proof16 : runCachedNode 511 129468 Adaptive143Third135Node16 = false := by
  decide +kernel

#print axioms adaptive143Third135Proof16

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third135Proof12 : runCachedNode 511 129468 Adaptive143Third135Node12 = false := by
  decide +kernel

#print axioms adaptive143Third135Proof12

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third135Proof54 : runCachedNode 511 129468 Adaptive143Third135Node54 = false := by
  decide +kernel

#print axioms adaptive143Third135Proof54

end NineSeparatedSubsetSums
