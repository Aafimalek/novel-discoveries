import NineSeparatedSubsetSums.Adaptive143Third140State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third140Proof19 : runCachedNode 511 130276 Adaptive143Third140Node19 = false := by
  decide +kernel

#print axioms adaptive143Third140Proof19

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third140Proof310 : runCachedNode 511 130276 Adaptive143Third140Node310 = false := by
  decide +kernel

#print axioms adaptive143Third140Proof310

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third140Proof2 : runCachedNode 511 130276 Adaptive143Third140Node2 = false := by
  decide +kernel

#print axioms adaptive143Third140Proof2

end NineSeparatedSubsetSums
