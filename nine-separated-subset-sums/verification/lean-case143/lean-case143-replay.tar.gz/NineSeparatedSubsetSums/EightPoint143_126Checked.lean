import NineSeparatedSubsetSums.EightPointPackedGeometry
import NineSeparatedSubsetSums.EightPoint143_126PackedBudget0
import NineSeparatedSubsetSums.EightPoint143_126PackedAnchor0Part0
import NineSeparatedSubsetSums.EightPoint143_126PackedAnchor0Part1
import NineSeparatedSubsetSums.EightPoint143_126PackedAnchor0Part2
import NineSeparatedSubsetSums.EightPoint143_126PackedBudget1
import NineSeparatedSubsetSums.EightPoint143_126PackedAnchor1Part0
import NineSeparatedSubsetSums.EightPoint143_126PackedAnchor1Part1
import NineSeparatedSubsetSums.EightPoint143_126PackedAnchor1Part2

namespace NineSeparatedSubsetSums

private theorem packedOct143_126Anchor0 :
  ∀ j : Fin 488, ((j.val : Int)+143+126)%2=0 →
    2370258 ≤ FourPointNumeric.octPackedCharge 143 126 20 packedOct143_126_0 (j.val : Int) := by
  intro j hj
  let k := (j.val-1)/2
  have hk : k < 244 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+1 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint143_126PackedAnchor0Part0 z
    rwa [he,hrep] at ht
  by_cases h1 : k < 240
  · let z : Fin 120 := ⟨k-120, by omega⟩
    have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
    have ht := eightPoint143_126PackedAnchor0Part1 z
    rwa [he,hrep] at ht
  let z : Fin 4 := ⟨k-240, by omega⟩
  have he : (z.val : Int)+240 = k := by dsimp [z] <;> omega
  have ht := eightPoint143_126PackedAnchor0Part2 z
  rwa [he,hrep] at ht

private theorem packedOct143_126Anchor1 :
  ∀ j : Fin 488, ((j.val : Int)+143+126)%2=1 →
    2370945 ≤ FourPointNumeric.octPackedCharge 143 126 20 packedOct143_126_1 (j.val : Int) := by
  intro j hj
  let k := (j.val-0)/2
  have hk : k < 244 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+0 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint143_126PackedAnchor1Part0 z
    rwa [he,hrep] at ht
  by_cases h1 : k < 240
  · let z : Fin 120 := ⟨k-120, by omega⟩
    have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
    have ht := eightPoint143_126PackedAnchor1Part1 z
    rwa [he,hrep] at ht
  let z : Fin 4 := ⟨k-240, by omega⟩
  have he : (z.val : Int)+240 = k := by dsimp [z] <;> omega
  have ht := eightPoint143_126PackedAnchor1Part2 z
  rwa [he,hrep] at ht

def packedOctCertificate143_126_0 : EightPointCertificate 143 126 0 127621 :=
  eightPointCertificateOfPacked 143 126 0 127621 2370258 20 packedOct143_126_0 487 488
    (by decide +kernel) (by decide) packedOct143_126Anchor0
    (by rw [packedOct143_126_0_budget]; decide)

def packedOctCertificate143_126_1 : EightPointCertificate 143 126 1 127621 :=
  eightPointCertificateOfPacked 143 126 1 127621 2370945 20 packedOct143_126_1 492 488
    (by decide +kernel) (by decide) packedOct143_126Anchor1
    (by rw [packedOct143_126_1_budget]; decide)

theorem max148_second143_third126_eightPoint_moment_bound (tail : List ℕ) (len : tail.length=6)
    (distinct : (natSubsetSums (148::143::126::tail)).Nodup) :
    127621 ≤ ((148::143::126::tail).map (· ^ 2)).sum := by
  apply eightPointNatMomentLower 143 126 127621 tail len distinct
  intro p hp
  by_cases h : p=0
  · subst p
    exact packedOctCertificate143_126_0
  · have he : p=1 := hp.resolve_left h
    subst p
    exact packedOctCertificate143_126_1

#print axioms max148_second143_third126_eightPoint_moment_bound

end NineSeparatedSubsetSums
