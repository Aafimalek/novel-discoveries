import NineSeparatedSubsetSums.Adaptive143Third127State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third127Proof8 : runCachedNode 511 127918 Adaptive143Third127Node8 = false := by
  decide +kernel

#print axioms adaptive143Third127Proof8

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third127Proof6 : runCachedNode 511 127918 Adaptive143Third127Node6 = false := by
  decide +kernel

#print axioms adaptive143Third127Proof6

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third127Proof5 : runCachedNode 511 127918 Adaptive143Third127Node5 = false := by
  decide +kernel

#print axioms adaptive143Third127Proof5

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third127Proof4 : runCachedNode 511 127918 Adaptive143Third127Node4 = false := by
  decide +kernel

#print axioms adaptive143Third127Proof4

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third127Proof3 : runCachedNode 511 127918 Adaptive143Third127Node3 = false := by
  decide +kernel

#print axioms adaptive143Third127Proof3

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third127Proof2 : runCachedNode 511 127918 Adaptive143Third127Node2 = false := by
  decide +kernel

#print axioms adaptive143Third127Proof2

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third127Proof1 : runCachedNode 511 127918 Adaptive143Third127Node1 = false := by
  decide +kernel

#print axioms adaptive143Third127Proof1

end NineSeparatedSubsetSums
