import NineSeparatedSubsetSums.Adaptive143Third142State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third142Proof450 : runCachedNode 511 130584 Adaptive143Third142Node450 = false := by
  decide +kernel

#print axioms adaptive143Third142Proof450

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third142Proof225 : runCachedNode 511 130584 Adaptive143Third142Node225 = false := by
  decide +kernel

#print axioms adaptive143Third142Proof225

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third142Proof291 : runCachedNode 511 130584 Adaptive143Third142Node291 = false := by
  decide +kernel

#print axioms adaptive143Third142Proof291

end NineSeparatedSubsetSums
