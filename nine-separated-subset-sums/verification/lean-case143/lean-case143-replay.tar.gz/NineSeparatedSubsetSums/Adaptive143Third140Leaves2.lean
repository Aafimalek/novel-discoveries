import NineSeparatedSubsetSums.Adaptive143Third140State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third140Proof136 : runCachedNode 511 130276 Adaptive143Third140Node136 = false := by
  decide +kernel

#print axioms adaptive143Third140Proof136

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third140Proof75 : runCachedNode 511 130276 Adaptive143Third140Node75 = false := by
  decide +kernel

#print axioms adaptive143Third140Proof75

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third140Proof51 : runCachedNode 511 130276 Adaptive143Third140Node51 = false := by
  decide +kernel

#print axioms adaptive143Third140Proof51

end NineSeparatedSubsetSums
