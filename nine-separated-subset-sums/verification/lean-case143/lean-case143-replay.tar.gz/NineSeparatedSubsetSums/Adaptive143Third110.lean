import NineSeparatedSubsetSums.Adaptive143Third110Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint143Checked

namespace NineSeparatedSubsetSums


theorem adaptive143Third110 : NoDescendingTailAfterThird 143 110 :=
  noDescendingThirdTail_of_cached 143 110 112040 (fun t ht nd => max148_second143_fourPoint_moment_bound (110::t) (by simp [ht]) nd) adaptive143Third110Proof0

#print axioms adaptive143Third110

end NineSeparatedSubsetSums
