import NineSeparatedSubsetSums.Adaptive143Third116State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third116Proof15 : runCachedNode 511 112040 Adaptive143Third116Node15 = false := by
  decide +kernel

#print axioms adaptive143Third116Proof15

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third116Proof14 : runCachedNode 511 112040 Adaptive143Third116Node14 = false := by
  decide +kernel

#print axioms adaptive143Third116Proof14

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third116Proof13 : runCachedNode 511 112040 Adaptive143Third116Node13 = false := by
  decide +kernel

#print axioms adaptive143Third116Proof13

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third116Proof7 : runCachedNode 511 112040 Adaptive143Third116Node7 = false := by
  decide +kernel

#print axioms adaptive143Third116Proof7

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third116Proof3 : runCachedNode 511 112040 Adaptive143Third116Node3 = false := by
  decide +kernel

#print axioms adaptive143Third116Proof3

end NineSeparatedSubsetSums
