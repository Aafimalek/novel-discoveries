import NineSeparatedSubsetSums.EightPoint143_118PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct143_118_0_budget :
    FourPointNumeric.packedBudget 20 packedOct143_118_0 459 = 89173615 := by decide +kernel

#print axioms packedOct143_118_0_budget

end NineSeparatedSubsetSums
