import NineSeparatedSubsetSums.Adaptive143Third138State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third138Proof18 : runCachedNode 511 129927 Adaptive143Third138Node18 = false := by
  decide +kernel

#print axioms adaptive143Third138Proof18

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third138Proof138 : runCachedNode 511 129927 Adaptive143Third138Node138 = false := by
  decide +kernel

#print axioms adaptive143Third138Proof138

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third138Proof91 : runCachedNode 511 129927 Adaptive143Third138Node91 = false := by
  decide +kernel

#print axioms adaptive143Third138Proof91

end NineSeparatedSubsetSums
