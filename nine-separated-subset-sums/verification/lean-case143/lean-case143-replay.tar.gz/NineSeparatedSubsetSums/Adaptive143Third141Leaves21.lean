import NineSeparatedSubsetSums.Adaptive143Third141State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third141Proof220 : runCachedNode 511 130431 Adaptive143Third141Node220 = false := by
  decide +kernel

#print axioms adaptive143Third141Proof220

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third141Proof124 : runCachedNode 511 130431 Adaptive143Third141Node124 = false := by
  decide +kernel

#print axioms adaptive143Third141Proof124

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third141Proof218 : runCachedNode 511 130431 Adaptive143Third141Node218 = false := by
  decide +kernel

#print axioms adaptive143Third141Proof218

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third141Proof73 : runCachedNode 511 130431 Adaptive143Third141Node73 = false := by
  decide +kernel

#print axioms adaptive143Third141Proof73

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third141Proof122 : runCachedNode 511 130431 Adaptive143Third141Node122 = false := by
  decide +kernel

#print axioms adaptive143Third141Proof122

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third141Proof157 : runCachedNode 511 130431 Adaptive143Third141Node157 = false := by
  decide +kernel

#print axioms adaptive143Third141Proof157

end NineSeparatedSubsetSums
