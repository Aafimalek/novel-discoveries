import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive143Third126Node0 : CachedSearchNode :=
  ⟨4, 125, computeCenteredMask [148,143,126], 417, 58229⟩

end NineSeparatedSubsetSums
