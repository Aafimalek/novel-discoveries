import NineSeparatedSubsetSums.Adaptive143Third121State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third121Proof0 : runCachedNode 511 126221 Adaptive143Third121Node0 = false := by
  decide +kernel

#print axioms adaptive143Third121Proof0

end NineSeparatedSubsetSums
