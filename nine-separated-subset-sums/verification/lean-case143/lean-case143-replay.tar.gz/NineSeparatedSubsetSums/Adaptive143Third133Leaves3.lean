import NineSeparatedSubsetSums.Adaptive143Third133State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third133Proof14 : runCachedNode 511 129127 Adaptive143Third133Node14 = false := by
  decide +kernel

#print axioms adaptive143Third133Proof14

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third133Proof16 : runCachedNode 511 129127 Adaptive143Third133Node16 = false := by
  decide +kernel

#print axioms adaptive143Third133Proof16

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third133Proof13 : runCachedNode 511 129127 Adaptive143Third133Node13 = false := by
  decide +kernel

#print axioms adaptive143Third133Proof13

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third133Proof12 : runCachedNode 511 129127 Adaptive143Third133Node12 = false := by
  decide +kernel

#print axioms adaptive143Third133Proof12

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third133Proof11 : runCachedNode 511 129127 Adaptive143Third133Node11 = false := by
  decide +kernel

#print axioms adaptive143Third133Proof11

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third133Proof10 : runCachedNode 511 129127 Adaptive143Third133Node10 = false := by
  decide +kernel

#print axioms adaptive143Third133Proof10

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third133Proof9 : runCachedNode 511 129127 Adaptive143Third133Node9 = false := by
  decide +kernel

#print axioms adaptive143Third133Proof9

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third133Proof8 : runCachedNode 511 129127 Adaptive143Third133Node8 = false := by
  decide +kernel

#print axioms adaptive143Third133Proof8

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third133Proof7 : runCachedNode 511 129127 Adaptive143Third133Node7 = false := by
  decide +kernel

#print axioms adaptive143Third133Proof7

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third133Proof6 : runCachedNode 511 129127 Adaptive143Third133Node6 = false := by
  decide +kernel

#print axioms adaptive143Third133Proof6

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive143Third133Proof3 : runCachedNode 511 129127 Adaptive143Third133Node3 = false := by
  decide +kernel

#print axioms adaptive143Third133Proof3

end NineSeparatedSubsetSums
