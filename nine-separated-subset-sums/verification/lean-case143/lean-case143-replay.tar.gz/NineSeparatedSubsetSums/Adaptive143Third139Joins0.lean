import NineSeparatedSubsetSums.Adaptive143Third139State
import NineSeparatedSubsetSums.Adaptive143Third139Leaves1
import NineSeparatedSubsetSums.Adaptive143Third139Leaves23
import NineSeparatedSubsetSums.Adaptive143Third139Leaves22
import NineSeparatedSubsetSums.Adaptive143Third139Leaves21
import NineSeparatedSubsetSums.Adaptive143Third139Leaves6
import NineSeparatedSubsetSums.Adaptive143Third139Leaves19
import NineSeparatedSubsetSums.Adaptive143Third139Leaves20
import NineSeparatedSubsetSums.Adaptive143Third139Leaves18
import NineSeparatedSubsetSums.Adaptive143Third139Leaves17
import NineSeparatedSubsetSums.Adaptive143Third139Leaves9
import NineSeparatedSubsetSums.Adaptive143Third139Leaves12
import NineSeparatedSubsetSums.Adaptive143Third139Leaves7
import NineSeparatedSubsetSums.Adaptive143Third139Leaves24
import NineSeparatedSubsetSums.Adaptive143Third139Leaves13
import NineSeparatedSubsetSums.Adaptive143Third139Leaves2
import NineSeparatedSubsetSums.Adaptive143Third139Leaves10
import NineSeparatedSubsetSums.Adaptive143Third139Leaves15
import NineSeparatedSubsetSums.Adaptive143Third139Leaves16
import NineSeparatedSubsetSums.Adaptive143Third139Leaves0
import NineSeparatedSubsetSums.Adaptive143Third139Leaves4
import NineSeparatedSubsetSums.Adaptive143Third139Leaves3
import NineSeparatedSubsetSums.Adaptive143Third139Leaves14
import NineSeparatedSubsetSums.Adaptive143Third139Leaves11
import NineSeparatedSubsetSums.Adaptive143Third139Leaves8
import NineSeparatedSubsetSums.Adaptive143Third139Leaves5
import NineSeparatedSubsetSums.Adaptive143Third139Leaves25

namespace NineSeparatedSubsetSums

theorem adaptive143Third139Proof21 : runCachedNode 511 130096 Adaptive143Third139Node21 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130096 Adaptive143Third139Node21 = [104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 122, 123, 124, 127, 128, 129] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive143Third139Proof22
  · exact adaptive143Third139Proof23
  · exact adaptive143Third139Proof24
  · exact adaptive143Third139Proof25
  · exact adaptive143Third139Proof26
  · exact adaptive143Third139Proof27
  · exact adaptive143Third139Proof28
  · exact adaptive143Third139Proof29
  · exact adaptive143Third139Proof30
  · exact adaptive143Third139Proof31
  · exact adaptive143Third139Proof32
  · exact adaptive143Third139Proof33
  · exact adaptive143Third139Proof34
  · exact adaptive143Third139Proof35
  · exact adaptive143Third139Proof36
  · exact adaptive143Third139Proof37
  · exact adaptive143Third139Proof38
  · exact adaptive143Third139Proof39
  · exact adaptive143Third139Proof40
  · exact adaptive143Third139Proof41
  · exact adaptive143Third139Proof42
  · exact adaptive143Third139Proof43
  · exact adaptive143Third139Proof44

#print axioms adaptive143Third139Proof21

theorem adaptive143Third139Proof45 : runCachedNode 511 130096 Adaptive143Third139Node45 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130096 Adaptive143Third139Node45 = [104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 123, 124, 125, 128, 129, 130] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive143Third139Proof46
  · exact adaptive143Third139Proof47
  · exact adaptive143Third139Proof48
  · exact adaptive143Third139Proof49
  · exact adaptive143Third139Proof50
  · exact adaptive143Third139Proof51
  · exact adaptive143Third139Proof52
  · exact adaptive143Third139Proof53
  · exact adaptive143Third139Proof54
  · exact adaptive143Third139Proof55
  · exact adaptive143Third139Proof56
  · exact adaptive143Third139Proof57
  · exact adaptive143Third139Proof58
  · exact adaptive143Third139Proof59
  · exact adaptive143Third139Proof60
  · exact adaptive143Third139Proof61
  · exact adaptive143Third139Proof62
  · exact adaptive143Third139Proof63
  · exact adaptive143Third139Proof64
  · exact adaptive143Third139Proof65
  · exact adaptive143Third139Proof66
  · exact adaptive143Third139Proof67
  · exact adaptive143Third139Proof68
  · exact adaptive143Third139Proof69

#print axioms adaptive143Third139Proof45

theorem adaptive143Third139Proof70 : runCachedNode 511 130096 Adaptive143Third139Node70 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130096 Adaptive143Third139Node70 = [103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 124, 125, 126, 129, 130, 131] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive143Third139Proof71
  · exact adaptive143Third139Proof72
  · exact adaptive143Third139Proof73
  · exact adaptive143Third139Proof74
  · exact adaptive143Third139Proof75
  · exact adaptive143Third139Proof76
  · exact adaptive143Third139Proof77
  · exact adaptive143Third139Proof78
  · exact adaptive143Third139Proof79
  · exact adaptive143Third139Proof80
  · exact adaptive143Third139Proof81
  · exact adaptive143Third139Proof82
  · exact adaptive143Third139Proof83
  · exact adaptive143Third139Proof84
  · exact adaptive143Third139Proof85
  · exact adaptive143Third139Proof86
  · exact adaptive143Third139Proof87
  · exact adaptive143Third139Proof88
  · exact adaptive143Third139Proof89
  · exact adaptive143Third139Proof90
  · exact adaptive143Third139Proof91
  · exact adaptive143Third139Proof92
  · exact adaptive143Third139Proof93
  · exact adaptive143Third139Proof94
  · exact adaptive143Third139Proof95
  · exact adaptive143Third139Proof96

#print axioms adaptive143Third139Proof70

theorem adaptive143Third139Proof97 : runCachedNode 511 130096 Adaptive143Third139Node97 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130096 Adaptive143Third139Node97 = [103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 125, 126, 127, 130, 131, 132] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive143Third139Proof98
  · exact adaptive143Third139Proof99
  · exact adaptive143Third139Proof100
  · exact adaptive143Third139Proof101
  · exact adaptive143Third139Proof102
  · exact adaptive143Third139Proof103
  · exact adaptive143Third139Proof104
  · exact adaptive143Third139Proof105
  · exact adaptive143Third139Proof106
  · exact adaptive143Third139Proof107
  · exact adaptive143Third139Proof108
  · exact adaptive143Third139Proof109
  · exact adaptive143Third139Proof110
  · exact adaptive143Third139Proof111
  · exact adaptive143Third139Proof112
  · exact adaptive143Third139Proof113
  · exact adaptive143Third139Proof114
  · exact adaptive143Third139Proof115
  · exact adaptive143Third139Proof116
  · exact adaptive143Third139Proof117
  · exact adaptive143Third139Proof118
  · exact adaptive143Third139Proof119
  · exact adaptive143Third139Proof120
  · exact adaptive143Third139Proof121
  · exact adaptive143Third139Proof122
  · exact adaptive143Third139Proof123
  · exact adaptive143Third139Proof124

#print axioms adaptive143Third139Proof97

theorem adaptive143Third139Proof125 : runCachedNode 511 130096 Adaptive143Third139Node125 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130096 Adaptive143Third139Node125 = [103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 127, 128, 129, 132, 133] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive143Third139Proof126
  · exact adaptive143Third139Proof127
  · exact adaptive143Third139Proof128
  · exact adaptive143Third139Proof129
  · exact adaptive143Third139Proof130
  · exact adaptive143Third139Proof131
  · exact adaptive143Third139Proof132
  · exact adaptive143Third139Proof133
  · exact adaptive143Third139Proof134
  · exact adaptive143Third139Proof135
  · exact adaptive143Third139Proof136
  · exact adaptive143Third139Proof137
  · exact adaptive143Third139Proof138
  · exact adaptive143Third139Proof139
  · exact adaptive143Third139Proof140
  · exact adaptive143Third139Proof141
  · exact adaptive143Third139Proof142
  · exact adaptive143Third139Proof143
  · exact adaptive143Third139Proof144
  · exact adaptive143Third139Proof145
  · exact adaptive143Third139Proof146
  · exact adaptive143Third139Proof147
  · exact adaptive143Third139Proof148
  · exact adaptive143Third139Proof149
  · exact adaptive143Third139Proof150
  · exact adaptive143Third139Proof151
  · exact adaptive143Third139Proof152
  · exact adaptive143Third139Proof153

#print axioms adaptive143Third139Proof125

theorem adaptive143Third139Proof154 : runCachedNode 511 130096 Adaptive143Third139Node154 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130096 Adaptive143Third139Node154 = [102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 128, 129, 130, 133, 135] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive143Third139Proof155
  · exact adaptive143Third139Proof156
  · exact adaptive143Third139Proof157
  · exact adaptive143Third139Proof158
  · exact adaptive143Third139Proof159
  · exact adaptive143Third139Proof160
  · exact adaptive143Third139Proof161
  · exact adaptive143Third139Proof162
  · exact adaptive143Third139Proof163
  · exact adaptive143Third139Proof164
  · exact adaptive143Third139Proof165
  · exact adaptive143Third139Proof166
  · exact adaptive143Third139Proof167
  · exact adaptive143Third139Proof168
  · exact adaptive143Third139Proof169
  · exact adaptive143Third139Proof170
  · exact adaptive143Third139Proof171
  · exact adaptive143Third139Proof172
  · exact adaptive143Third139Proof173
  · exact adaptive143Third139Proof174
  · exact adaptive143Third139Proof175
  · exact adaptive143Third139Proof176
  · exact adaptive143Third139Proof177
  · exact adaptive143Third139Proof178
  · exact adaptive143Third139Proof179
  · exact adaptive143Third139Proof180
  · exact adaptive143Third139Proof181
  · exact adaptive143Third139Proof182
  · exact adaptive143Third139Proof183
  · exact adaptive143Third139Proof184

#print axioms adaptive143Third139Proof154

theorem adaptive143Third139Proof185 : runCachedNode 511 130096 Adaptive143Third139Node185 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130096 Adaptive143Third139Node185 = [102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 129, 130, 131, 135, 136] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive143Third139Proof186
  · exact adaptive143Third139Proof187
  · exact adaptive143Third139Proof188
  · exact adaptive143Third139Proof189
  · exact adaptive143Third139Proof190
  · exact adaptive143Third139Proof191
  · exact adaptive143Third139Proof192
  · exact adaptive143Third139Proof193
  · exact adaptive143Third139Proof194
  · exact adaptive143Third139Proof195
  · exact adaptive143Third139Proof196
  · exact adaptive143Third139Proof197
  · exact adaptive143Third139Proof198
  · exact adaptive143Third139Proof199
  · exact adaptive143Third139Proof200
  · exact adaptive143Third139Proof201
  · exact adaptive143Third139Proof202
  · exact adaptive143Third139Proof203
  · exact adaptive143Third139Proof204
  · exact adaptive143Third139Proof205
  · exact adaptive143Third139Proof206
  · exact adaptive143Third139Proof207
  · exact adaptive143Third139Proof208
  · exact adaptive143Third139Proof209
  · exact adaptive143Third139Proof210
  · exact adaptive143Third139Proof211
  · exact adaptive143Third139Proof212
  · exact adaptive143Third139Proof213
  · exact adaptive143Third139Proof214
  · exact adaptive143Third139Proof215
  · exact adaptive143Third139Proof216

#print axioms adaptive143Third139Proof185

theorem adaptive143Third139Proof248 : runCachedNode 511 130096 Adaptive143Third139Node248 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 130096 Adaptive143Third139Node248 = [90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 122, 123, 124, 127, 128, 132] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive143Third139Proof249
  · exact adaptive143Third139Proof250
  · exact adaptive143Third139Proof251
  · exact adaptive143Third139Proof252
  · exact adaptive143Third139Proof253
  · exact adaptive143Third139Proof254
  · exact adaptive143Third139Proof255
  · exact adaptive143Third139Proof256
  · exact adaptive143Third139Proof257
  · exact adaptive143Third139Proof258
  · exact adaptive143Third139Proof259
  · exact adaptive143Third139Proof260
  · exact adaptive143Third139Proof261
  · exact adaptive143Third139Proof262
  · exact adaptive143Third139Proof263
  · exact adaptive143Third139Proof264
  · exact adaptive143Third139Proof265
  · exact adaptive143Third139Proof266
  · exact adaptive143Third139Proof267
  · exact adaptive143Third139Proof268
  · exact adaptive143Third139Proof269
  · exact adaptive143Third139Proof270
  · exact adaptive143Third139Proof271
  · exact adaptive143Third139Proof272
  · exact adaptive143Third139Proof273
  · exact adaptive143Third139Proof274
  · exact adaptive143Third139Proof275
  · exact adaptive143Third139Proof276
  · exact adaptive143Third139Proof277
  · exact adaptive143Third139Proof278
  · exact adaptive143Third139Proof279
  · exact adaptive143Third139Proof280
  · exact adaptive143Third139Proof281
  · exact adaptive143Third139Proof282
  · exact adaptive143Third139Proof283
  · exact adaptive143Third139Proof284
  · exact adaptive143Third139Proof285

#print axioms adaptive143Third139Proof248

end NineSeparatedSubsetSums
