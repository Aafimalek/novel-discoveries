import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive139Third125Node0 : CachedSearchNode :=
  ⟨4, 124, computeCenteredMask [148,139,125], 412, 56850⟩

end NineSeparatedSubsetSums
