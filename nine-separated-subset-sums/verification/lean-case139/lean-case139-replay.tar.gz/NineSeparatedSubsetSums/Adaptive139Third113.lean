import NineSeparatedSubsetSums.Adaptive139Third113Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint139Checked

namespace NineSeparatedSubsetSums


theorem adaptive139Third113 : NoDescendingTailAfterThird 139 113 :=
  noDescendingThirdTail_of_cached 139 113 111380 (fun t ht nd => max148_second139_fourPoint_moment_bound (113::t) (by simp [ht]) nd) adaptive139Third113Proof0

#print axioms adaptive139Third113

end NineSeparatedSubsetSums
