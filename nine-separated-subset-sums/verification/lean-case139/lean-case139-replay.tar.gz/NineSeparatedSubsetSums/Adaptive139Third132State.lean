import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive139Third132Node0 : CachedSearchNode :=
  ⟨4, 131, computeCenteredMask [148,139,132], 419, 58649⟩
def Adaptive139Third132Node1 : CachedSearchNode := cachedChild Adaptive139Third132Node0 111
def Adaptive139Third132Node2 : CachedSearchNode := cachedChild Adaptive139Third132Node0 112
def Adaptive139Third132Node3 : CachedSearchNode := cachedChild Adaptive139Third132Node0 113
def Adaptive139Third132Node4 : CachedSearchNode := cachedChild Adaptive139Third132Node0 114
def Adaptive139Third132Node5 : CachedSearchNode := cachedChild Adaptive139Third132Node0 115
def Adaptive139Third132Node6 : CachedSearchNode := cachedChild Adaptive139Third132Node0 116
def Adaptive139Third132Node7 : CachedSearchNode := cachedChild Adaptive139Third132Node0 117
def Adaptive139Third132Node8 : CachedSearchNode := cachedChild Adaptive139Third132Node0 118
def Adaptive139Third132Node9 : CachedSearchNode := cachedChild Adaptive139Third132Node0 119
def Adaptive139Third132Node10 : CachedSearchNode := cachedChild Adaptive139Third132Node0 120
def Adaptive139Third132Node11 : CachedSearchNode := cachedChild Adaptive139Third132Node0 121
def Adaptive139Third132Node12 : CachedSearchNode := cachedChild Adaptive139Third132Node0 122
def Adaptive139Third132Node13 : CachedSearchNode := cachedChild Adaptive139Third132Node0 124
def Adaptive139Third132Node14 : CachedSearchNode := cachedChild Adaptive139Third132Node0 125
def Adaptive139Third132Node15 : CachedSearchNode := cachedChild Adaptive139Third132Node0 126
def Adaptive139Third132Node16 : CachedSearchNode := cachedChild Adaptive139Third132Node0 127
def Adaptive139Third132Node17 : CachedSearchNode := cachedChild Adaptive139Third132Node0 128
def Adaptive139Third132Node18 : CachedSearchNode := cachedChild Adaptive139Third132Node0 129
def Adaptive139Third132Node19 : CachedSearchNode := cachedChild Adaptive139Third132Node0 130
def Adaptive139Third132Node20 : CachedSearchNode := cachedChild Adaptive139Third132Node19 105
def Adaptive139Third132Node21 : CachedSearchNode := cachedChild Adaptive139Third132Node19 106
def Adaptive139Third132Node22 : CachedSearchNode := cachedChild Adaptive139Third132Node19 107
def Adaptive139Third132Node23 : CachedSearchNode := cachedChild Adaptive139Third132Node19 108
def Adaptive139Third132Node24 : CachedSearchNode := cachedChild Adaptive139Third132Node19 109
def Adaptive139Third132Node25 : CachedSearchNode := cachedChild Adaptive139Third132Node19 110
def Adaptive139Third132Node26 : CachedSearchNode := cachedChild Adaptive139Third132Node19 111
def Adaptive139Third132Node27 : CachedSearchNode := cachedChild Adaptive139Third132Node19 112
def Adaptive139Third132Node28 : CachedSearchNode := cachedChild Adaptive139Third132Node19 113
def Adaptive139Third132Node29 : CachedSearchNode := cachedChild Adaptive139Third132Node19 115
def Adaptive139Third132Node30 : CachedSearchNode := cachedChild Adaptive139Third132Node19 116
def Adaptive139Third132Node31 : CachedSearchNode := cachedChild Adaptive139Third132Node19 117
def Adaptive139Third132Node32 : CachedSearchNode := cachedChild Adaptive139Third132Node19 118
def Adaptive139Third132Node33 : CachedSearchNode := cachedChild Adaptive139Third132Node19 119
def Adaptive139Third132Node34 : CachedSearchNode := cachedChild Adaptive139Third132Node19 120
def Adaptive139Third132Node35 : CachedSearchNode := cachedChild Adaptive139Third132Node19 122
def Adaptive139Third132Node36 : CachedSearchNode := cachedChild Adaptive139Third132Node19 124
def Adaptive139Third132Node37 : CachedSearchNode := cachedChild Adaptive139Third132Node19 125
def Adaptive139Third132Node38 : CachedSearchNode := cachedChild Adaptive139Third132Node19 126
def Adaptive139Third132Node39 : CachedSearchNode := cachedChild Adaptive139Third132Node19 127
def Adaptive139Third132Node40 : CachedSearchNode := cachedChild Adaptive139Third132Node19 128
def Adaptive139Third132Node41 : CachedSearchNode := cachedChild Adaptive139Third132Node19 129
def Adaptive139Third132Node42 : CachedSearchNode := cachedChild Adaptive139Third132Node0 131

end NineSeparatedSubsetSums
