import NineSeparatedSubsetSums.Adaptive139Third137State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third137Proof17 : runCachedNode 511 129004 Adaptive139Third137Node17 = false := by
  decide +kernel

#print axioms adaptive139Third137Proof17

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third137Proof188 : runCachedNode 511 129004 Adaptive139Third137Node188 = false := by
  decide +kernel

#print axioms adaptive139Third137Proof188

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third137Proof151 : runCachedNode 511 129004 Adaptive139Third137Node151 = false := by
  decide +kernel

#print axioms adaptive139Third137Proof151

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third137Proof4 : runCachedNode 511 129004 Adaptive139Third137Node4 = false := by
  decide +kernel

#print axioms adaptive139Third137Proof4

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third137Proof129 : runCachedNode 511 129004 Adaptive139Third137Node129 = false := by
  decide +kernel

#print axioms adaptive139Third137Proof129

end NineSeparatedSubsetSums
