import NineSeparatedSubsetSums.EightPoint139_131PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct139_131_1_budget :
    FourPointNumeric.packedBudget 20 packedOct139_131_1 440 = 90376226 := by decide +kernel

#print axioms packedOct139_131_1_budget

end NineSeparatedSubsetSums
