import NineSeparatedSubsetSums.EightPoint139_121PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct139_121_1_budget :
    FourPointNumeric.packedBudget 20 packedOct139_121_1 374 = 85928992 := by decide +kernel

#print axioms packedOct139_121_1_budget

end NineSeparatedSubsetSums
