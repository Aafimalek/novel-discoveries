import NineSeparatedSubsetSums.Adaptive139Third133State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third133Proof49 : runCachedNode 511 128283 Adaptive139Third133Node49 = false := by
  decide +kernel

#print axioms adaptive139Third133Proof49

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third133Proof50 : runCachedNode 511 128283 Adaptive139Third133Node50 = false := by
  decide +kernel

#print axioms adaptive139Third133Proof50

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third133Proof21 : runCachedNode 511 128283 Adaptive139Third133Node21 = false := by
  decide +kernel

#print axioms adaptive139Third133Proof21

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third133Proof46 : runCachedNode 511 128283 Adaptive139Third133Node46 = false := by
  decide +kernel

#print axioms adaptive139Third133Proof46

end NineSeparatedSubsetSums
