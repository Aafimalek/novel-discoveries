import NineSeparatedSubsetSums.Adaptive139Third134State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third134Proof64 : runCachedNode 511 128469 Adaptive139Third134Node64 = false := by
  decide +kernel

#print axioms adaptive139Third134Proof64

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third134Proof89 : runCachedNode 511 128469 Adaptive139Third134Node89 = false := by
  decide +kernel

#print axioms adaptive139Third134Proof89

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third134Proof35 : runCachedNode 511 128469 Adaptive139Third134Node35 = false := by
  decide +kernel

#print axioms adaptive139Third134Proof35

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third134Proof10 : runCachedNode 511 128469 Adaptive139Third134Node10 = false := by
  decide +kernel

#print axioms adaptive139Third134Proof10

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third134Proof38 : runCachedNode 511 128469 Adaptive139Third134Node38 = false := by
  decide +kernel

#print axioms adaptive139Third134Proof38

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third134Proof63 : runCachedNode 511 128469 Adaptive139Third134Node63 = false := by
  decide +kernel

#print axioms adaptive139Third134Proof63

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third134Proof36 : runCachedNode 511 128469 Adaptive139Third134Node36 = false := by
  decide +kernel

#print axioms adaptive139Third134Proof36

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third134Proof60 : runCachedNode 511 128469 Adaptive139Third134Node60 = false := by
  decide +kernel

#print axioms adaptive139Third134Proof60

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third134Proof88 : runCachedNode 511 128469 Adaptive139Third134Node88 = false := by
  decide +kernel

#print axioms adaptive139Third134Proof88

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third134Proof85 : runCachedNode 511 128469 Adaptive139Third134Node85 = false := by
  decide +kernel

#print axioms adaptive139Third134Proof85

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third134Proof9 : runCachedNode 511 128469 Adaptive139Third134Node9 = false := by
  decide +kernel

#print axioms adaptive139Third134Proof9

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third134Proof61 : runCachedNode 511 128469 Adaptive139Third134Node61 = false := by
  decide +kernel

#print axioms adaptive139Third134Proof61

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third134Proof62 : runCachedNode 511 128469 Adaptive139Third134Node62 = false := by
  decide +kernel

#print axioms adaptive139Third134Proof62

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third134Proof87 : runCachedNode 511 128469 Adaptive139Third134Node87 = false := by
  decide +kernel

#print axioms adaptive139Third134Proof87

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third134Proof34 : runCachedNode 511 128469 Adaptive139Third134Node34 = false := by
  decide +kernel

#print axioms adaptive139Third134Proof34

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third134Proof33 : runCachedNode 511 128469 Adaptive139Third134Node33 = false := by
  decide +kernel

#print axioms adaptive139Third134Proof33

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third134Proof32 : runCachedNode 511 128469 Adaptive139Third134Node32 = false := by
  decide +kernel

#print axioms adaptive139Third134Proof32

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third134Proof57 : runCachedNode 511 128469 Adaptive139Third134Node57 = false := by
  decide +kernel

#print axioms adaptive139Third134Proof57

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third134Proof59 : runCachedNode 511 128469 Adaptive139Third134Node59 = false := by
  decide +kernel

#print axioms adaptive139Third134Proof59

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third134Proof58 : runCachedNode 511 128469 Adaptive139Third134Node58 = false := by
  decide +kernel

#print axioms adaptive139Third134Proof58

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third134Proof6 : runCachedNode 511 128469 Adaptive139Third134Node6 = false := by
  decide +kernel

#print axioms adaptive139Third134Proof6

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third134Proof30 : runCachedNode 511 128469 Adaptive139Third134Node30 = false := by
  decide +kernel

#print axioms adaptive139Third134Proof30

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third134Proof31 : runCachedNode 511 128469 Adaptive139Third134Node31 = false := by
  decide +kernel

#print axioms adaptive139Third134Proof31

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third134Proof86 : runCachedNode 511 128469 Adaptive139Third134Node86 = false := by
  decide +kernel

#print axioms adaptive139Third134Proof86

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third134Proof28 : runCachedNode 511 128469 Adaptive139Third134Node28 = false := by
  decide +kernel

#print axioms adaptive139Third134Proof28

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third134Proof5 : runCachedNode 511 128469 Adaptive139Third134Node5 = false := by
  decide +kernel

#print axioms adaptive139Third134Proof5

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third134Proof45 : runCachedNode 511 128469 Adaptive139Third134Node45 = false := by
  decide +kernel

#print axioms adaptive139Third134Proof45

end NineSeparatedSubsetSums
