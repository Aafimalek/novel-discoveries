import NineSeparatedSubsetSums.EightPointPackedGeometry
import NineSeparatedSubsetSums.EightPoint139_126PackedBudget0
import NineSeparatedSubsetSums.EightPoint139_126PackedAnchor0Part0
import NineSeparatedSubsetSums.EightPoint139_126PackedAnchor0Part1
import NineSeparatedSubsetSums.EightPoint139_126PackedAnchor0Part2
import NineSeparatedSubsetSums.EightPoint139_126PackedBudget1
import NineSeparatedSubsetSums.EightPoint139_126PackedAnchor1Part0
import NineSeparatedSubsetSums.EightPoint139_126PackedAnchor1Part1
import NineSeparatedSubsetSums.EightPoint139_126PackedAnchor1Part2

namespace NineSeparatedSubsetSums

private theorem packedOct139_126Anchor0 :
  ∀ j : Fin 484, ((j.val : Int)+139+126)%2=0 →
    2329718 ≤ FourPointNumeric.octPackedCharge 139 126 20 packedOct139_126_0 (j.val : Int) := by
  intro j hj
  let k := (j.val-1)/2
  have hk : k < 242 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+1 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint139_126PackedAnchor0Part0 z
    rwa [he,hrep] at ht
  by_cases h1 : k < 240
  · let z : Fin 120 := ⟨k-120, by omega⟩
    have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
    have ht := eightPoint139_126PackedAnchor0Part1 z
    rwa [he,hrep] at ht
  let z : Fin 2 := ⟨k-240, by omega⟩
  have he : (z.val : Int)+240 = k := by dsimp [z] <;> omega
  have ht := eightPoint139_126PackedAnchor0Part2 z
  rwa [he,hrep] at ht

private theorem packedOct139_126Anchor1 :
  ∀ j : Fin 484, ((j.val : Int)+139+126)%2=1 →
    2329792 ≤ FourPointNumeric.octPackedCharge 139 126 20 packedOct139_126_1 (j.val : Int) := by
  intro j hj
  let k := (j.val-0)/2
  have hk : k < 242 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+0 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint139_126PackedAnchor1Part0 z
    rwa [he,hrep] at ht
  by_cases h1 : k < 240
  · let z : Fin 120 := ⟨k-120, by omega⟩
    have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
    have ht := eightPoint139_126PackedAnchor1Part1 z
    rwa [he,hrep] at ht
  let z : Fin 2 := ⟨k-240, by omega⟩
  have he : (z.val : Int)+240 = k := by dsimp [z] <;> omega
  have ht := eightPoint139_126PackedAnchor1Part2 z
  rwa [he,hrep] at ht

def packedOctCertificate139_126_0 : EightPointCertificate 139 126 0 127046 :=
  eightPointCertificateOfPacked 139 126 0 127046 2329718 20 packedOct139_126_0 353 484
    (by decide +kernel) (by decide) packedOct139_126Anchor0
    (by rw [packedOct139_126_0_budget]; decide)

def packedOctCertificate139_126_1 : EightPointCertificate 139 126 1 127046 :=
  eightPointCertificateOfPacked 139 126 1 127046 2329792 20 packedOct139_126_1 352 484
    (by decide +kernel) (by decide) packedOct139_126Anchor1
    (by rw [packedOct139_126_1_budget]; decide)

theorem max148_second139_third126_eightPoint_moment_bound (tail : List ℕ) (len : tail.length=6)
    (distinct : (natSubsetSums (148::139::126::tail)).Nodup) :
    127046 ≤ ((148::139::126::tail).map (· ^ 2)).sum := by
  apply eightPointNatMomentLower 139 126 127046 tail len distinct
  intro p hp
  by_cases h : p=0
  · subst p
    exact packedOctCertificate139_126_0
  · have he : p=1 := hp.resolve_left h
    subst p
    exact packedOctCertificate139_126_1

#print axioms max148_second139_third126_eightPoint_moment_bound

end NineSeparatedSubsetSums
