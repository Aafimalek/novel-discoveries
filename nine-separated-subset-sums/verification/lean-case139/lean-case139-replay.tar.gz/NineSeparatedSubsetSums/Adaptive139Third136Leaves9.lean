import NineSeparatedSubsetSums.Adaptive139Third136State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third136Proof145 : runCachedNode 511 128827 Adaptive139Third136Node145 = false := by
  decide +kernel

#print axioms adaptive139Third136Proof145

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third136Proof115 : runCachedNode 511 128827 Adaptive139Third136Node115 = false := by
  decide +kernel

#print axioms adaptive139Third136Proof115

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third136Proof64 : runCachedNode 511 128827 Adaptive139Third136Node64 = false := by
  decide +kernel

#print axioms adaptive139Third136Proof64

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third136Proof89 : runCachedNode 511 128827 Adaptive139Third136Node89 = false := by
  decide +kernel

#print axioms adaptive139Third136Proof89

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third136Proof88 : runCachedNode 511 128827 Adaptive139Third136Node88 = false := by
  decide +kernel

#print axioms adaptive139Third136Proof88

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third136Proof12 : runCachedNode 511 128827 Adaptive139Third136Node12 = false := by
  decide +kernel

#print axioms adaptive139Third136Proof12

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third136Proof63 : runCachedNode 511 128827 Adaptive139Third136Node63 = false := by
  decide +kernel

#print axioms adaptive139Third136Proof63

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third136Proof11 : runCachedNode 511 128827 Adaptive139Third136Node11 = false := by
  decide +kernel

#print axioms adaptive139Third136Proof11

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third136Proof87 : runCachedNode 511 128827 Adaptive139Third136Node87 = false := by
  decide +kernel

#print axioms adaptive139Third136Proof87

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third136Proof144 : runCachedNode 511 128827 Adaptive139Third136Node144 = false := by
  decide +kernel

#print axioms adaptive139Third136Proof144

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third136Proof84 : runCachedNode 511 128827 Adaptive139Third136Node84 = false := by
  decide +kernel

#print axioms adaptive139Third136Proof84

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third136Proof86 : runCachedNode 511 128827 Adaptive139Third136Node86 = false := by
  decide +kernel

#print axioms adaptive139Third136Proof86

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third136Proof81 : runCachedNode 511 128827 Adaptive139Third136Node81 = false := by
  decide +kernel

#print axioms adaptive139Third136Proof81

end NineSeparatedSubsetSums
