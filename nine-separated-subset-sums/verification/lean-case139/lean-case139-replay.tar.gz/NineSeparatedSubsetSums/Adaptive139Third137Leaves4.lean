import NineSeparatedSubsetSums.Adaptive139Third137State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third137Proof123 : runCachedNode 511 129004 Adaptive139Third137Node123 = false := by
  decide +kernel

#print axioms adaptive139Third137Proof123

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third137Proof19 : runCachedNode 511 129004 Adaptive139Third137Node19 = false := by
  decide +kernel

#print axioms adaptive139Third137Proof19

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third137Proof58 : runCachedNode 511 129004 Adaptive139Third137Node58 = false := by
  decide +kernel

#print axioms adaptive139Third137Proof58

end NineSeparatedSubsetSums
