import NineSeparatedSubsetSums.Adaptive139Third134State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third134Proof43 : runCachedNode 511 128469 Adaptive139Third134Node43 = false := by
  decide +kernel

#print axioms adaptive139Third134Proof43

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third134Proof12 : runCachedNode 511 128469 Adaptive139Third134Node12 = false := by
  decide +kernel

#print axioms adaptive139Third134Proof12

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third134Proof22 : runCachedNode 511 128469 Adaptive139Third134Node22 = false := by
  decide +kernel

#print axioms adaptive139Third134Proof22

end NineSeparatedSubsetSums
