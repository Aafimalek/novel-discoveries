import NineSeparatedSubsetSums.Adaptive139Third130State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third130Proof13 : runCachedNode 511 127774 Adaptive139Third130Node13 = false := by
  decide +kernel

#print axioms adaptive139Third130Proof13

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third130Proof12 : runCachedNode 511 127774 Adaptive139Third130Node12 = false := by
  decide +kernel

#print axioms adaptive139Third130Proof12

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third130Proof10 : runCachedNode 511 127774 Adaptive139Third130Node10 = false := by
  decide +kernel

#print axioms adaptive139Third130Proof10

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third130Proof9 : runCachedNode 511 127774 Adaptive139Third130Node9 = false := by
  decide +kernel

#print axioms adaptive139Third130Proof9

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third130Proof8 : runCachedNode 511 127774 Adaptive139Third130Node8 = false := by
  decide +kernel

#print axioms adaptive139Third130Proof8

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third130Proof7 : runCachedNode 511 127774 Adaptive139Third130Node7 = false := by
  decide +kernel

#print axioms adaptive139Third130Proof7

end NineSeparatedSubsetSums
