import NineSeparatedSubsetSums.Adaptive139Third132State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third132Proof16 : runCachedNode 511 128175 Adaptive139Third132Node16 = false := by
  decide +kernel

#print axioms adaptive139Third132Proof16

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third132Proof14 : runCachedNode 511 128175 Adaptive139Third132Node14 = false := by
  decide +kernel

#print axioms adaptive139Third132Proof14

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third132Proof15 : runCachedNode 511 128175 Adaptive139Third132Node15 = false := by
  decide +kernel

#print axioms adaptive139Third132Proof15

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third132Proof40 : runCachedNode 511 128175 Adaptive139Third132Node40 = false := by
  decide +kernel

#print axioms adaptive139Third132Proof40

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third132Proof30 : runCachedNode 511 128175 Adaptive139Third132Node30 = false := by
  decide +kernel

#print axioms adaptive139Third132Proof30

end NineSeparatedSubsetSums
