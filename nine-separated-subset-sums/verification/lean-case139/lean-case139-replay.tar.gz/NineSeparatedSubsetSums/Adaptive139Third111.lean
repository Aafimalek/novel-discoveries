import NineSeparatedSubsetSums.Adaptive139Third111Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint139Checked

namespace NineSeparatedSubsetSums


theorem adaptive139Third111 : NoDescendingTailAfterThird 139 111 :=
  noDescendingThirdTail_of_cached 139 111 111380 (fun t ht nd => max148_second139_fourPoint_moment_bound (111::t) (by simp [ht]) nd) adaptive139Third111Proof0

#print axioms adaptive139Third111

end NineSeparatedSubsetSums
