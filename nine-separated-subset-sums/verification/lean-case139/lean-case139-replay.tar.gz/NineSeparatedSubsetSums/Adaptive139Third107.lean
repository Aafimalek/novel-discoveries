import NineSeparatedSubsetSums.Adaptive139Third107Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint139Checked

namespace NineSeparatedSubsetSums


theorem adaptive139Third107 : NoDescendingTailAfterThird 139 107 :=
  noDescendingThirdTail_of_cached 139 107 111380 (fun t ht nd => max148_second139_fourPoint_moment_bound (107::t) (by simp [ht]) nd) adaptive139Third107Proof0

#print axioms adaptive139Third107

end NineSeparatedSubsetSums
