import NineSeparatedSubsetSums.Adaptive139Third133State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third133Proof39 : runCachedNode 511 128283 Adaptive139Third133Node39 = false := by
  decide +kernel

#print axioms adaptive139Third133Proof39

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third133Proof16 : runCachedNode 511 128283 Adaptive139Third133Node16 = false := by
  decide +kernel

#print axioms adaptive139Third133Proof16

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third133Proof30 : runCachedNode 511 128283 Adaptive139Third133Node30 = false := by
  decide +kernel

#print axioms adaptive139Third133Proof30

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third133Proof44 : runCachedNode 511 128283 Adaptive139Third133Node44 = false := by
  decide +kernel

#print axioms adaptive139Third133Proof44

end NineSeparatedSubsetSums
