import NineSeparatedSubsetSums.EightPoint139_128PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct139_128_1_budget :
    FourPointNumeric.packedBudget 20 packedOct139_128_1 360 = 86294320 := by decide +kernel

#print axioms packedOct139_128_1_budget

end NineSeparatedSubsetSums
