import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive139Third119Node0 : CachedSearchNode :=
  ⟨4, 118, computeCenteredMask [148,139,119], 406, 55386⟩

end NineSeparatedSubsetSums
