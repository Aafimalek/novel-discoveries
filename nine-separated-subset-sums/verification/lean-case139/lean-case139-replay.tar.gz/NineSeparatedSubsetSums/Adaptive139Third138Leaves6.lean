import NineSeparatedSubsetSums.Adaptive139Third138State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third138Proof211 : runCachedNode 511 129184 Adaptive139Third138Node211 = false := by
  decide +kernel

#print axioms adaptive139Third138Proof211

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third138Proof121 : runCachedNode 511 129184 Adaptive139Third138Node121 = false := by
  decide +kernel

#print axioms adaptive139Third138Proof121

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third138Proof86 : runCachedNode 511 129184 Adaptive139Third138Node86 = false := by
  decide +kernel

#print axioms adaptive139Third138Proof86

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third138Proof47 : runCachedNode 511 129184 Adaptive139Third138Node47 = false := by
  decide +kernel

#print axioms adaptive139Third138Proof47

end NineSeparatedSubsetSums
