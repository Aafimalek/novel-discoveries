import NineSeparatedSubsetSums.Adaptive139Third108Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint139Checked

namespace NineSeparatedSubsetSums


theorem adaptive139Third108 : NoDescendingTailAfterThird 139 108 :=
  noDescendingThirdTail_of_cached 139 108 111380 (fun t ht nd => max148_second139_fourPoint_moment_bound (108::t) (by simp [ht]) nd) adaptive139Third108Proof0

#print axioms adaptive139Third108

end NineSeparatedSubsetSums
