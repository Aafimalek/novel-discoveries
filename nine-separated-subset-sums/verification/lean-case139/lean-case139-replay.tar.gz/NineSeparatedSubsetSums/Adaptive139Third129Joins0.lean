import NineSeparatedSubsetSums.Adaptive139Third129State
import NineSeparatedSubsetSums.Adaptive139Third129Leaves1
import NineSeparatedSubsetSums.Adaptive139Third129Leaves0

namespace NineSeparatedSubsetSums

theorem adaptive139Third129Proof0 : runCachedNode 511 127504 Adaptive139Third129Node0 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 127504 Adaptive139Third129Node0 = [111, 112, 113, 114, 115, 116, 117, 118, 119, 121, 122, 123, 124, 125, 126, 127, 128] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive139Third129Proof1
  · exact adaptive139Third129Proof2
  · exact adaptive139Third129Proof3
  · exact adaptive139Third129Proof4
  · exact adaptive139Third129Proof5
  · exact adaptive139Third129Proof6
  · exact adaptive139Third129Proof7
  · exact adaptive139Third129Proof8
  · exact adaptive139Third129Proof9
  · exact adaptive139Third129Proof10
  · exact adaptive139Third129Proof11
  · exact adaptive139Third129Proof12
  · exact adaptive139Third129Proof13
  · exact adaptive139Third129Proof14
  · exact adaptive139Third129Proof15
  · exact adaptive139Third129Proof16
  · exact adaptive139Third129Proof17

#print axioms adaptive139Third129Proof0

end NineSeparatedSubsetSums
