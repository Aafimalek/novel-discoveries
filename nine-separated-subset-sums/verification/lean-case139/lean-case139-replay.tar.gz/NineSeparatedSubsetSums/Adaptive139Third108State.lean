import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive139Third108Node0 : CachedSearchNode :=
  ⟨4, 107, computeCenteredMask [148,139,108], 395, 52889⟩

end NineSeparatedSubsetSums
