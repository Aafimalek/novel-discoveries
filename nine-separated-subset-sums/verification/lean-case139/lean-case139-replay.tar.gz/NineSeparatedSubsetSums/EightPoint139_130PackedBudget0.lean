import NineSeparatedSubsetSums.EightPoint139_130PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct139_130_0_budget :
    FourPointNumeric.packedBudget 20 packedOct139_130_0 265 = 88308570 := by decide +kernel

#print axioms packedOct139_130_0_budget

end NineSeparatedSubsetSums
