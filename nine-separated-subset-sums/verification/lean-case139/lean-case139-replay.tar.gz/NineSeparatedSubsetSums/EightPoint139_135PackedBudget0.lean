import NineSeparatedSubsetSums.EightPoint139_135PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct139_135_0_budget :
    FourPointNumeric.packedBudget 20 packedOct139_135_0 397 = 92425652 := by decide +kernel

#print axioms packedOct139_135_0_budget

end NineSeparatedSubsetSums
