import NineSeparatedSubsetSums.EightPoint139_121PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint139_121PackedAnchor1Part1 :
    ∀ j : Fin 120, 2347746 ≤ FourPointNumeric.octPackedCharge 139 121 20 packedOct139_121_1
      (2*((j.val : Int)+120)+1) := by decide +kernel

end NineSeparatedSubsetSums
