import NineSeparatedSubsetSums.Adaptive139Third130State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third130Proof17 : runCachedNode 511 127774 Adaptive139Third130Node17 = false := by
  decide +kernel

#print axioms adaptive139Third130Proof17

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third130Proof14 : runCachedNode 511 127774 Adaptive139Third130Node14 = false := by
  decide +kernel

#print axioms adaptive139Third130Proof14

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third130Proof6 : runCachedNode 511 127774 Adaptive139Third130Node6 = false := by
  decide +kernel

#print axioms adaptive139Third130Proof6

end NineSeparatedSubsetSums
