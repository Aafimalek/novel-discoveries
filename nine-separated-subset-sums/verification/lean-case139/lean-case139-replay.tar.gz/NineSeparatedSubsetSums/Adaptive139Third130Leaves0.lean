import NineSeparatedSubsetSums.Adaptive139Third130State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third130Proof18 : runCachedNode 511 127774 Adaptive139Third130Node18 = false := by
  decide +kernel

#print axioms adaptive139Third130Proof18

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third130Proof11 : runCachedNode 511 127774 Adaptive139Third130Node11 = false := by
  decide +kernel

#print axioms adaptive139Third130Proof11

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third130Proof5 : runCachedNode 511 127774 Adaptive139Third130Node5 = false := by
  decide +kernel

#print axioms adaptive139Third130Proof5

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third130Proof1 : runCachedNode 511 127774 Adaptive139Third130Node1 = false := by
  decide +kernel

#print axioms adaptive139Third130Proof1

end NineSeparatedSubsetSums
