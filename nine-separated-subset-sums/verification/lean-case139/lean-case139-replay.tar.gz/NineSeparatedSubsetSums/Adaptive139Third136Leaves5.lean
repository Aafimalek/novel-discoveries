import NineSeparatedSubsetSums.Adaptive139Third136State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third136Proof15 : runCachedNode 511 128827 Adaptive139Third136Node15 = false := by
  decide +kernel

#print axioms adaptive139Third136Proof15

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third136Proof17 : runCachedNode 511 128827 Adaptive139Third136Node17 = false := by
  decide +kernel

#print axioms adaptive139Third136Proof17

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third136Proof118 : runCachedNode 511 128827 Adaptive139Third136Node118 = false := by
  decide +kernel

#print axioms adaptive139Third136Proof118

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third136Proof13 : runCachedNode 511 128827 Adaptive139Third136Node13 = false := by
  decide +kernel

#print axioms adaptive139Third136Proof13

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third136Proof22 : runCachedNode 511 128827 Adaptive139Third136Node22 = false := by
  decide +kernel

#print axioms adaptive139Third136Proof22

end NineSeparatedSubsetSums
