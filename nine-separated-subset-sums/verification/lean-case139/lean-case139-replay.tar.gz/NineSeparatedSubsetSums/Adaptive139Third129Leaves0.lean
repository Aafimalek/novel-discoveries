import NineSeparatedSubsetSums.Adaptive139Third129State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third129Proof17 : runCachedNode 511 127504 Adaptive139Third129Node17 = false := by
  decide +kernel

#print axioms adaptive139Third129Proof17

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third129Proof16 : runCachedNode 511 127504 Adaptive139Third129Node16 = false := by
  decide +kernel

#print axioms adaptive139Third129Proof16

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third129Proof15 : runCachedNode 511 127504 Adaptive139Third129Node15 = false := by
  decide +kernel

#print axioms adaptive139Third129Proof15

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third129Proof12 : runCachedNode 511 127504 Adaptive139Third129Node12 = false := by
  decide +kernel

#print axioms adaptive139Third129Proof12

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third129Proof3 : runCachedNode 511 127504 Adaptive139Third129Node3 = false := by
  decide +kernel

#print axioms adaptive139Third129Proof3

end NineSeparatedSubsetSums
