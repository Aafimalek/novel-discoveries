import NineSeparatedSubsetSums.Adaptive139Third135State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third135Proof38 : runCachedNode 511 128672 Adaptive139Third135Node38 = false := by
  decide +kernel

#print axioms adaptive139Third135Proof38

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third135Proof37 : runCachedNode 511 128672 Adaptive139Third135Node37 = false := by
  decide +kernel

#print axioms adaptive139Third135Proof37

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third135Proof10 : runCachedNode 511 128672 Adaptive139Third135Node10 = false := by
  decide +kernel

#print axioms adaptive139Third135Proof10

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third135Proof138 : runCachedNode 511 128672 Adaptive139Third135Node138 = false := by
  decide +kernel

#print axioms adaptive139Third135Proof138

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third135Proof135 : runCachedNode 511 128672 Adaptive139Third135Node135 = false := by
  decide +kernel

#print axioms adaptive139Third135Proof135

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third135Proof110 : runCachedNode 511 128672 Adaptive139Third135Node110 = false := by
  decide +kernel

#print axioms adaptive139Third135Proof110

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third135Proof139 : runCachedNode 511 128672 Adaptive139Third135Node139 = false := by
  decide +kernel

#print axioms adaptive139Third135Proof139

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third135Proof59 : runCachedNode 511 128672 Adaptive139Third135Node59 = false := by
  decide +kernel

#print axioms adaptive139Third135Proof59

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third135Proof137 : runCachedNode 511 128672 Adaptive139Third135Node137 = false := by
  decide +kernel

#print axioms adaptive139Third135Proof137

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third135Proof35 : runCachedNode 511 128672 Adaptive139Third135Node35 = false := by
  decide +kernel

#print axioms adaptive139Third135Proof35

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third135Proof9 : runCachedNode 511 128672 Adaptive139Third135Node9 = false := by
  decide +kernel

#print axioms adaptive139Third135Proof9

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third135Proof58 : runCachedNode 511 128672 Adaptive139Third135Node58 = false := by
  decide +kernel

#print axioms adaptive139Third135Proof58

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third135Proof134 : runCachedNode 511 128672 Adaptive139Third135Node134 = false := by
  decide +kernel

#print axioms adaptive139Third135Proof134

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third135Proof111 : runCachedNode 511 128672 Adaptive139Third135Node111 = false := by
  decide +kernel

#print axioms adaptive139Third135Proof111

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third135Proof34 : runCachedNode 511 128672 Adaptive139Third135Node34 = false := by
  decide +kernel

#print axioms adaptive139Third135Proof34

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third135Proof8 : runCachedNode 511 128672 Adaptive139Third135Node8 = false := by
  decide +kernel

#print axioms adaptive139Third135Proof8

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third135Proof85 : runCachedNode 511 128672 Adaptive139Third135Node85 = false := by
  decide +kernel

#print axioms adaptive139Third135Proof85

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third135Proof83 : runCachedNode 511 128672 Adaptive139Third135Node83 = false := by
  decide +kernel

#print axioms adaptive139Third135Proof83

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third135Proof136 : runCachedNode 511 128672 Adaptive139Third135Node136 = false := by
  decide +kernel

#print axioms adaptive139Third135Proof136

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third135Proof56 : runCachedNode 511 128672 Adaptive139Third135Node56 = false := by
  decide +kernel

#print axioms adaptive139Third135Proof56

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third135Proof32 : runCachedNode 511 128672 Adaptive139Third135Node32 = false := by
  decide +kernel

#print axioms adaptive139Third135Proof32

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third135Proof57 : runCachedNode 511 128672 Adaptive139Third135Node57 = false := by
  decide +kernel

#print axioms adaptive139Third135Proof57

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third135Proof82 : runCachedNode 511 128672 Adaptive139Third135Node82 = false := by
  decide +kernel

#print axioms adaptive139Third135Proof82

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third135Proof106 : runCachedNode 511 128672 Adaptive139Third135Node106 = false := by
  decide +kernel

#print axioms adaptive139Third135Proof106

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third135Proof30 : runCachedNode 511 128672 Adaptive139Third135Node30 = false := by
  decide +kernel

#print axioms adaptive139Third135Proof30

end NineSeparatedSubsetSums
