import NineSeparatedSubsetSums.Adaptive139Third138State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third138Proof212 : runCachedNode 511 129184 Adaptive139Third138Node212 = false := by
  decide +kernel

#print axioms adaptive139Third138Proof212

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third138Proof206 : runCachedNode 511 129184 Adaptive139Third138Node206 = false := by
  decide +kernel

#print axioms adaptive139Third138Proof206

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third138Proof105 : runCachedNode 511 129184 Adaptive139Third138Node105 = false := by
  decide +kernel

#print axioms adaptive139Third138Proof105

end NineSeparatedSubsetSums
