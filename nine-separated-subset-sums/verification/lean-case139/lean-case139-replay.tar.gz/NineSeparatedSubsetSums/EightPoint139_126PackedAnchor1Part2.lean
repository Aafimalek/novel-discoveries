import NineSeparatedSubsetSums.EightPoint139_126PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint139_126PackedAnchor1Part2 :
    ∀ j : Fin 2, 2329792 ≤ FourPointNumeric.octPackedCharge 139 126 20 packedOct139_126_1
      (2*((j.val : Int)+240)+0) := by decide +kernel

end NineSeparatedSubsetSums
