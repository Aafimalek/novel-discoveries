import NineSeparatedSubsetSums.EightPoint139_135PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct139_135_1_budget :
    FourPointNumeric.packedBudget 20 packedOct139_135_1 430 = 92379022 := by decide +kernel

#print axioms packedOct139_135_1_budget

end NineSeparatedSubsetSums
