import NineSeparatedSubsetSums.Adaptive139Third137State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third137Proof124 : runCachedNode 511 129004 Adaptive139Third137Node124 = false := by
  decide +kernel

#print axioms adaptive139Third137Proof124

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third137Proof18 : runCachedNode 511 129004 Adaptive139Third137Node18 = false := by
  decide +kernel

#print axioms adaptive139Third137Proof18

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third137Proof128 : runCachedNode 511 129004 Adaptive139Third137Node128 = false := by
  decide +kernel

#print axioms adaptive139Third137Proof128

end NineSeparatedSubsetSums
