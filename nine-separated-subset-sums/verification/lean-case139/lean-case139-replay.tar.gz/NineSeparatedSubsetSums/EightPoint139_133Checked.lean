import NineSeparatedSubsetSums.EightPointPackedGeometry
import NineSeparatedSubsetSums.EightPoint139_133PackedBudget0
import NineSeparatedSubsetSums.EightPoint139_133PackedAnchor0Part0
import NineSeparatedSubsetSums.EightPoint139_133PackedAnchor0Part1
import NineSeparatedSubsetSums.EightPoint139_133PackedAnchor0Part2
import NineSeparatedSubsetSums.EightPoint139_133PackedBudget1
import NineSeparatedSubsetSums.EightPoint139_133PackedAnchor1Part0
import NineSeparatedSubsetSums.EightPoint139_133PackedAnchor1Part1
import NineSeparatedSubsetSums.EightPoint139_133PackedAnchor1Part2

namespace NineSeparatedSubsetSums

private theorem packedOct139_133Anchor0 :
  ∀ j : Fin 495, ((j.val : Int)+139+133)%2=0 →
    2426723 ≤ FourPointNumeric.octPackedCharge 139 133 20 packedOct139_133_0 (j.val : Int) := by
  intro j hj
  let k := (j.val-0)/2
  have hk : k < 248 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+0 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint139_133PackedAnchor0Part0 z
    rwa [he,hrep] at ht
  by_cases h1 : k < 240
  · let z : Fin 120 := ⟨k-120, by omega⟩
    have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
    have ht := eightPoint139_133PackedAnchor0Part1 z
    rwa [he,hrep] at ht
  let z : Fin 8 := ⟨k-240, by omega⟩
  have he : (z.val : Int)+240 = k := by dsimp [z] <;> omega
  have ht := eightPoint139_133PackedAnchor0Part2 z
  rwa [he,hrep] at ht

private theorem packedOct139_133Anchor1 :
  ∀ j : Fin 495, ((j.val : Int)+139+133)%2=1 →
    2427802 ≤ FourPointNumeric.octPackedCharge 139 133 20 packedOct139_133_1 (j.val : Int) := by
  intro j hj
  let k := (j.val-1)/2
  have hk : k < 247 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+1 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint139_133PackedAnchor1Part0 z
    rwa [he,hrep] at ht
  by_cases h1 : k < 240
  · let z : Fin 120 := ⟨k-120, by omega⟩
    have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
    have ht := eightPoint139_133PackedAnchor1Part1 z
    rwa [he,hrep] at ht
  let z : Fin 7 := ⟨k-240, by omega⟩
  have he : (z.val : Int)+240 = k := by dsimp [z] <;> omega
  have ht := eightPoint139_133PackedAnchor1Part2 z
  rwa [he,hrep] at ht

def packedOctCertificate139_133_0 : EightPointCertificate 139 133 0 128283 :=
  eightPointCertificateOfPacked 139 133 0 128283 2426723 20 packedOct139_133_0 271 495
    (by decide +kernel) (by decide) packedOct139_133Anchor0
    (by rw [packedOct139_133_0_budget]; decide)

def packedOctCertificate139_133_1 : EightPointCertificate 139 133 1 128283 :=
  eightPointCertificateOfPacked 139 133 1 128283 2427802 20 packedOct139_133_1 272 495
    (by decide +kernel) (by decide) packedOct139_133Anchor1
    (by rw [packedOct139_133_1_budget]; decide)

theorem max148_second139_third133_eightPoint_moment_bound (tail : List ℕ) (len : tail.length=6)
    (distinct : (natSubsetSums (148::139::133::tail)).Nodup) :
    128283 ≤ ((148::139::133::tail).map (· ^ 2)).sum := by
  apply eightPointNatMomentLower 139 133 128283 tail len distinct
  intro p hp
  by_cases h : p=0
  · subst p
    exact packedOctCertificate139_133_0
  · have he : p=1 := hp.resolve_left h
    subst p
    exact packedOctCertificate139_133_1

#print axioms max148_second139_third133_eightPoint_moment_bound

end NineSeparatedSubsetSums
