import NineSeparatedSubsetSums.Adaptive139Third135State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third135Proof143 : runCachedNode 511 128672 Adaptive139Third135Node143 = false := by
  decide +kernel

#print axioms adaptive139Third135Proof143

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third135Proof18 : runCachedNode 511 128672 Adaptive139Third135Node18 = false := by
  decide +kernel

#print axioms adaptive139Third135Proof18

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third135Proof116 : runCachedNode 511 128672 Adaptive139Third135Node116 = false := by
  decide +kernel

#print axioms adaptive139Third135Proof116

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third135Proof75 : runCachedNode 511 128672 Adaptive139Third135Node75 = false := by
  decide +kernel

#print axioms adaptive139Third135Proof75

end NineSeparatedSubsetSums
