import NineSeparatedSubsetSums.EightPoint139_138PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint139_138PackedAnchor1Part0 :
    ∀ j : Fin 120, 2483900 ≤ FourPointNumeric.octPackedCharge 139 138 20 packedOct139_138_1
      (2*((j.val : Int)+0)+0) := by decide +kernel

end NineSeparatedSubsetSums
