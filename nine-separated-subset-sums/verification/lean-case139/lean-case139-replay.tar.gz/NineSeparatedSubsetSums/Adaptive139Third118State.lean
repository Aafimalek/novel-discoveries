import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive139Third118Node0 : CachedSearchNode :=
  ⟨4, 117, computeCenteredMask [148,139,118], 405, 55149⟩

end NineSeparatedSubsetSums
