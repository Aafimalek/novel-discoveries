import NineSeparatedSubsetSums.Adaptive139Third137State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third137Proof67 : runCachedNode 511 129004 Adaptive139Third137Node67 = false := by
  decide +kernel

#print axioms adaptive139Third137Proof67

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third137Proof120 : runCachedNode 511 129004 Adaptive139Third137Node120 = false := by
  decide +kernel

#print axioms adaptive139Third137Proof120

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third137Proof13 : runCachedNode 511 129004 Adaptive139Third137Node13 = false := by
  decide +kernel

#print axioms adaptive139Third137Proof13

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third137Proof41 : runCachedNode 511 129004 Adaptive139Third137Node41 = false := by
  decide +kernel

#print axioms adaptive139Third137Proof41

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third137Proof37 : runCachedNode 511 129004 Adaptive139Third137Node37 = false := by
  decide +kernel

#print axioms adaptive139Third137Proof37

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third137Proof93 : runCachedNode 511 129004 Adaptive139Third137Node93 = false := by
  decide +kernel

#print axioms adaptive139Third137Proof93

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third137Proof70 : runCachedNode 511 129004 Adaptive139Third137Node70 = false := by
  decide +kernel

#print axioms adaptive139Third137Proof70

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third137Proof39 : runCachedNode 511 129004 Adaptive139Third137Node39 = false := by
  decide +kernel

#print axioms adaptive139Third137Proof39

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third137Proof115 : runCachedNode 511 129004 Adaptive139Third137Node115 = false := by
  decide +kernel

#print axioms adaptive139Third137Proof115

end NineSeparatedSubsetSums
