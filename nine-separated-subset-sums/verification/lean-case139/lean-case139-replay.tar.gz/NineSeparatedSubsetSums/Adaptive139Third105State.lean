import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive139Third105Node0 : CachedSearchNode :=
  ⟨4, 104, computeCenteredMask [148,139,105], 392, 52250⟩

end NineSeparatedSubsetSums
