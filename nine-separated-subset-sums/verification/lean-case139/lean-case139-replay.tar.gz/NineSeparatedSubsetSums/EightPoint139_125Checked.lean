import NineSeparatedSubsetSums.EightPointPackedGeometry
import NineSeparatedSubsetSums.EightPoint139_125PackedBudget0
import NineSeparatedSubsetSums.EightPoint139_125PackedAnchor0Part0
import NineSeparatedSubsetSums.EightPoint139_125PackedAnchor0Part1
import NineSeparatedSubsetSums.EightPoint139_125PackedAnchor0Part2
import NineSeparatedSubsetSums.EightPoint139_125PackedBudget1
import NineSeparatedSubsetSums.EightPoint139_125PackedAnchor1Part0
import NineSeparatedSubsetSums.EightPoint139_125PackedAnchor1Part1
import NineSeparatedSubsetSums.EightPoint139_125PackedAnchor1Part2

namespace NineSeparatedSubsetSums

private theorem packedOct139_125Anchor0 :
  ∀ j : Fin 483, ((j.val : Int)+139+125)%2=0 →
    2317501 ≤ FourPointNumeric.octPackedCharge 139 125 20 packedOct139_125_0 (j.val : Int) := by
  intro j hj
  let k := (j.val-0)/2
  have hk : k < 242 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+0 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint139_125PackedAnchor0Part0 z
    rwa [he,hrep] at ht
  by_cases h1 : k < 240
  · let z : Fin 120 := ⟨k-120, by omega⟩
    have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
    have ht := eightPoint139_125PackedAnchor0Part1 z
    rwa [he,hrep] at ht
  let z : Fin 2 := ⟨k-240, by omega⟩
  have he : (z.val : Int)+240 = k := by dsimp [z] <;> omega
  have ht := eightPoint139_125PackedAnchor0Part2 z
  rwa [he,hrep] at ht

private theorem packedOct139_125Anchor1 :
  ∀ j : Fin 483, ((j.val : Int)+139+125)%2=1 →
    2317260 ≤ FourPointNumeric.octPackedCharge 139 125 20 packedOct139_125_1 (j.val : Int) := by
  intro j hj
  let k := (j.val-1)/2
  have hk : k < 241 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+1 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint139_125PackedAnchor1Part0 z
    rwa [he,hrep] at ht
  by_cases h1 : k < 240
  · let z : Fin 120 := ⟨k-120, by omega⟩
    have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
    have ht := eightPoint139_125PackedAnchor1Part1 z
    rwa [he,hrep] at ht
  let z : Fin 1 := ⟨k-240, by omega⟩
  have he : (z.val : Int)+240 = k := by dsimp [z] <;> omega
  have ht := eightPoint139_125PackedAnchor1Part2 z
  rwa [he,hrep] at ht

def packedOctCertificate139_125_0 : EightPointCertificate 139 125 0 126770 :=
  eightPointCertificateOfPacked 139 125 0 126770 2317501 20 packedOct139_125_0 467 483
    (by decide +kernel) (by decide) packedOct139_125Anchor0
    (by rw [packedOct139_125_0_budget]; decide)

def packedOctCertificate139_125_1 : EightPointCertificate 139 125 1 126770 :=
  eightPointCertificateOfPacked 139 125 1 126770 2317260 20 packedOct139_125_1 426 483
    (by decide +kernel) (by decide) packedOct139_125Anchor1
    (by rw [packedOct139_125_1_budget]; decide)

theorem max148_second139_third125_eightPoint_moment_bound (tail : List ℕ) (len : tail.length=6)
    (distinct : (natSubsetSums (148::139::125::tail)).Nodup) :
    126770 ≤ ((148::139::125::tail).map (· ^ 2)).sum := by
  apply eightPointNatMomentLower 139 125 126770 tail len distinct
  intro p hp
  by_cases h : p=0
  · subst p
    exact packedOctCertificate139_125_0
  · have he : p=1 := hp.resolve_left h
    subst p
    exact packedOctCertificate139_125_1

#print axioms max148_second139_third125_eightPoint_moment_bound

end NineSeparatedSubsetSums
