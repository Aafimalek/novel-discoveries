import NineSeparatedSubsetSums.Adaptive139Third114Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint139Checked

namespace NineSeparatedSubsetSums


theorem adaptive139Third114 : NoDescendingTailAfterThird 139 114 :=
  noDescendingThirdTail_of_cached 139 114 111380 (fun t ht nd => max148_second139_fourPoint_moment_bound (114::t) (by simp [ht]) nd) adaptive139Third114Proof0

#print axioms adaptive139Third114

end NineSeparatedSubsetSums
