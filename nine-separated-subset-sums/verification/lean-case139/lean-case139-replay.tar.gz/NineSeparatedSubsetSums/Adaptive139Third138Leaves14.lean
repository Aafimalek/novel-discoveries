import NineSeparatedSubsetSums.Adaptive139Third138State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third138Proof37 : runCachedNode 511 129184 Adaptive139Third138Node37 = false := by
  decide +kernel

#print axioms adaptive139Third138Proof37

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third138Proof12 : runCachedNode 511 129184 Adaptive139Third138Node12 = false := by
  decide +kernel

#print axioms adaptive139Third138Proof12

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third138Proof92 : runCachedNode 511 129184 Adaptive139Third138Node92 = false := by
  decide +kernel

#print axioms adaptive139Third138Proof92

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third138Proof11 : runCachedNode 511 129184 Adaptive139Third138Node11 = false := by
  decide +kernel

#print axioms adaptive139Third138Proof11

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third138Proof203 : runCachedNode 511 129184 Adaptive139Third138Node203 = false := by
  decide +kernel

#print axioms adaptive139Third138Proof203

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third138Proof201 : runCachedNode 511 129184 Adaptive139Third138Node201 = false := by
  decide +kernel

#print axioms adaptive139Third138Proof201

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third138Proof39 : runCachedNode 511 129184 Adaptive139Third138Node39 = false := by
  decide +kernel

#print axioms adaptive139Third138Proof39

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third138Proof202 : runCachedNode 511 129184 Adaptive139Third138Node202 = false := by
  decide +kernel

#print axioms adaptive139Third138Proof202

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third138Proof200 : runCachedNode 511 129184 Adaptive139Third138Node200 = false := by
  decide +kernel

#print axioms adaptive139Third138Proof200

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third138Proof117 : runCachedNode 511 129184 Adaptive139Third138Node117 = false := by
  decide +kernel

#print axioms adaptive139Third138Proof117

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third138Proof147 : runCachedNode 511 129184 Adaptive139Third138Node147 = false := by
  decide +kernel

#print axioms adaptive139Third138Proof147

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third138Proof36 : runCachedNode 511 129184 Adaptive139Third138Node36 = false := by
  decide +kernel

#print axioms adaptive139Third138Proof36

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third138Proof3 : runCachedNode 511 129184 Adaptive139Third138Node3 = false := by
  decide +kernel

#print axioms adaptive139Third138Proof3

end NineSeparatedSubsetSums
