import NineSeparatedSubsetSums.EightPoint139_137PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct139_137_0_budget :
    FourPointNumeric.packedBudget 20 packedOct139_137_0 485 = 91800130 := by decide +kernel

#print axioms packedOct139_137_0_budget

end NineSeparatedSubsetSums
