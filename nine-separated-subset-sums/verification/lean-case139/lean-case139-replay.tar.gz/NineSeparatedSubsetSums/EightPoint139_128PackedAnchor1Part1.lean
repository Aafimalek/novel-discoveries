import NineSeparatedSubsetSums.EightPoint139_128PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint139_128PackedAnchor1Part1 :
    ∀ j : Fin 120, 2366792 ≤ FourPointNumeric.octPackedCharge 139 128 20 packedOct139_128_1
      (2*((j.val : Int)+120)+0) := by decide +kernel

end NineSeparatedSubsetSums
