import NineSeparatedSubsetSums.EightPointPackedGeometry
import NineSeparatedSubsetSums.EightPoint139_130PackedBudget0
import NineSeparatedSubsetSums.EightPoint139_130PackedAnchor0Part0
import NineSeparatedSubsetSums.EightPoint139_130PackedAnchor0Part1
import NineSeparatedSubsetSums.EightPoint139_130PackedAnchor0Part2
import NineSeparatedSubsetSums.EightPoint139_130PackedBudget1
import NineSeparatedSubsetSums.EightPoint139_130PackedAnchor1Part0
import NineSeparatedSubsetSums.EightPoint139_130PackedAnchor1Part1
import NineSeparatedSubsetSums.EightPoint139_130PackedAnchor1Part2

namespace NineSeparatedSubsetSums

private theorem packedOct139_130Anchor0 :
  ∀ j : Fin 493, ((j.val : Int)+139+130)%2=0 →
    2402015 ≤ FourPointNumeric.octPackedCharge 139 130 20 packedOct139_130_0 (j.val : Int) := by
  intro j hj
  let k := (j.val-1)/2
  have hk : k < 246 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+1 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint139_130PackedAnchor0Part0 z
    rwa [he,hrep] at ht
  by_cases h1 : k < 240
  · let z : Fin 120 := ⟨k-120, by omega⟩
    have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
    have ht := eightPoint139_130PackedAnchor0Part1 z
    rwa [he,hrep] at ht
  let z : Fin 6 := ⟨k-240, by omega⟩
  have he : (z.val : Int)+240 = k := by dsimp [z] <;> omega
  have ht := eightPoint139_130PackedAnchor0Part2 z
  rwa [he,hrep] at ht

private theorem packedOct139_130Anchor1 :
  ∀ j : Fin 493, ((j.val : Int)+139+130)%2=1 →
    2402066 ≤ FourPointNumeric.octPackedCharge 139 130 20 packedOct139_130_1 (j.val : Int) := by
  intro j hj
  let k := (j.val-0)/2
  have hk : k < 247 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+0 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint139_130PackedAnchor1Part0 z
    rwa [he,hrep] at ht
  by_cases h1 : k < 240
  · let z : Fin 120 := ⟨k-120, by omega⟩
    have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
    have ht := eightPoint139_130PackedAnchor1Part1 z
    rwa [he,hrep] at ht
  let z : Fin 7 := ⟨k-240, by omega⟩
  have he : (z.val : Int)+240 = k := by dsimp [z] <;> omega
  have ht := eightPoint139_130PackedAnchor1Part2 z
  rwa [he,hrep] at ht

def packedOctCertificate139_130_0 : EightPointCertificate 139 130 0 127774 :=
  eightPointCertificateOfPacked 139 130 0 127774 2402015 20 packedOct139_130_0 265 493
    (by decide +kernel) (by decide) packedOct139_130Anchor0
    (by rw [packedOct139_130_0_budget]; decide)

def packedOctCertificate139_130_1 : EightPointCertificate 139 130 1 127774 :=
  eightPointCertificateOfPacked 139 130 1 127774 2402066 20 packedOct139_130_1 266 493
    (by decide +kernel) (by decide) packedOct139_130Anchor1
    (by rw [packedOct139_130_1_budget]; decide)

theorem max148_second139_third130_eightPoint_moment_bound (tail : List ℕ) (len : tail.length=6)
    (distinct : (natSubsetSums (148::139::130::tail)).Nodup) :
    127774 ≤ ((148::139::130::tail).map (· ^ 2)).sum := by
  apply eightPointNatMomentLower 139 130 127774 tail len distinct
  intro p hp
  by_cases h : p=0
  · subst p
    exact packedOctCertificate139_130_0
  · have he : p=1 := hp.resolve_left h
    subst p
    exact packedOctCertificate139_130_1

#print axioms max148_second139_third130_eightPoint_moment_bound

end NineSeparatedSubsetSums
