import NineSeparatedSubsetSums.EightPointPackedGeometry
import NineSeparatedSubsetSums.EightPoint139_128PackedBudget0
import NineSeparatedSubsetSums.EightPoint139_128PackedAnchor0Part0
import NineSeparatedSubsetSums.EightPoint139_128PackedAnchor0Part1
import NineSeparatedSubsetSums.EightPoint139_128PackedAnchor0Part2
import NineSeparatedSubsetSums.EightPoint139_128PackedBudget1
import NineSeparatedSubsetSums.EightPoint139_128PackedAnchor1Part0
import NineSeparatedSubsetSums.EightPoint139_128PackedAnchor1Part1
import NineSeparatedSubsetSums.EightPoint139_128PackedAnchor1Part2

namespace NineSeparatedSubsetSums

private theorem packedOct139_128Anchor0 :
  ∀ j : Fin 489, ((j.val : Int)+139+128)%2=0 →
    2366890 ≤ FourPointNumeric.octPackedCharge 139 128 20 packedOct139_128_0 (j.val : Int) := by
  intro j hj
  let k := (j.val-1)/2
  have hk : k < 244 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+1 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint139_128PackedAnchor0Part0 z
    rwa [he,hrep] at ht
  by_cases h1 : k < 240
  · let z : Fin 120 := ⟨k-120, by omega⟩
    have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
    have ht := eightPoint139_128PackedAnchor0Part1 z
    rwa [he,hrep] at ht
  let z : Fin 4 := ⟨k-240, by omega⟩
  have he : (z.val : Int)+240 = k := by dsimp [z] <;> omega
  have ht := eightPoint139_128PackedAnchor0Part2 z
  rwa [he,hrep] at ht

private theorem packedOct139_128Anchor1 :
  ∀ j : Fin 489, ((j.val : Int)+139+128)%2=1 →
    2366792 ≤ FourPointNumeric.octPackedCharge 139 128 20 packedOct139_128_1 (j.val : Int) := by
  intro j hj
  let k := (j.val-0)/2
  have hk : k < 245 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+0 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint139_128PackedAnchor1Part0 z
    rwa [he,hrep] at ht
  by_cases h1 : k < 240
  · let z : Fin 120 := ⟨k-120, by omega⟩
    have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
    have ht := eightPoint139_128PackedAnchor1Part1 z
    rwa [he,hrep] at ht
  let z : Fin 5 := ⟨k-240, by omega⟩
  have he : (z.val : Int)+240 = k := by dsimp [z] <;> omega
  have ht := eightPoint139_128PackedAnchor1Part2 z
  rwa [he,hrep] at ht

def packedOctCertificate139_128_0 : EightPointCertificate 139 128 0 127306 :=
  eightPointCertificateOfPacked 139 128 0 127306 2366890 20 packedOct139_128_0 443 489
    (by decide +kernel) (by decide) packedOct139_128Anchor0
    (by rw [packedOct139_128_0_budget]; decide)

def packedOctCertificate139_128_1 : EightPointCertificate 139 128 1 127306 :=
  eightPointCertificateOfPacked 139 128 1 127306 2366792 20 packedOct139_128_1 360 489
    (by decide +kernel) (by decide) packedOct139_128Anchor1
    (by rw [packedOct139_128_1_budget]; decide)

theorem max148_second139_third128_eightPoint_moment_bound (tail : List ℕ) (len : tail.length=6)
    (distinct : (natSubsetSums (148::139::128::tail)).Nodup) :
    127306 ≤ ((148::139::128::tail).map (· ^ 2)).sum := by
  apply eightPointNatMomentLower 139 128 127306 tail len distinct
  intro p hp
  by_cases h : p=0
  · subst p
    exact packedOctCertificate139_128_0
  · have he : p=1 := hp.resolve_left h
    subst p
    exact packedOctCertificate139_128_1

#print axioms max148_second139_third128_eightPoint_moment_bound

end NineSeparatedSubsetSums
