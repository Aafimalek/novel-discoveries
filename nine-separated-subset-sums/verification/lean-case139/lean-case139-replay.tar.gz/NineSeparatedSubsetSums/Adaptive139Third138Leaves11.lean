import NineSeparatedSubsetSums.Adaptive139Third138State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third138Proof94 : runCachedNode 511 129184 Adaptive139Third138Node94 = false := by
  decide +kernel

#print axioms adaptive139Third138Proof94

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third138Proof16 : runCachedNode 511 129184 Adaptive139Third138Node16 = false := by
  decide +kernel

#print axioms adaptive139Third138Proof16

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third138Proof122 : runCachedNode 511 129184 Adaptive139Third138Node122 = false := by
  decide +kernel

#print axioms adaptive139Third138Proof122

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third138Proof120 : runCachedNode 511 129184 Adaptive139Third138Node120 = false := by
  decide +kernel

#print axioms adaptive139Third138Proof120

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third138Proof145 : runCachedNode 511 129184 Adaptive139Third138Node145 = false := by
  decide +kernel

#print axioms adaptive139Third138Proof145

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third138Proof71 : runCachedNode 511 129184 Adaptive139Third138Node71 = false := by
  decide +kernel

#print axioms adaptive139Third138Proof71

end NineSeparatedSubsetSums
