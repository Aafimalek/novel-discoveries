import NineSeparatedSubsetSums.EightPoint139_137PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct139_137_1_budget :
    FourPointNumeric.packedBudget 20 packedOct139_137_1 486 = 91914550 := by decide +kernel

#print axioms packedOct139_137_1_budget

end NineSeparatedSubsetSums
