import NineSeparatedSubsetSums.Adaptive139Third135State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third135Proof141 : runCachedNode 511 128672 Adaptive139Third135Node141 = false := by
  decide +kernel

#print axioms adaptive139Third135Proof141

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third135Proof17 : runCachedNode 511 128672 Adaptive139Third135Node17 = false := by
  decide +kernel

#print axioms adaptive139Third135Proof17

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third135Proof89 : runCachedNode 511 128672 Adaptive139Third135Node89 = false := by
  decide +kernel

#print axioms adaptive139Third135Proof89

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third135Proof64 : runCachedNode 511 128672 Adaptive139Third135Node64 = false := by
  decide +kernel

#print axioms adaptive139Third135Proof64

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third135Proof80 : runCachedNode 511 128672 Adaptive139Third135Node80 = false := by
  decide +kernel

#print axioms adaptive139Third135Proof80

end NineSeparatedSubsetSums
