import NineSeparatedSubsetSums.Adaptive139Third132State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third132Proof6 : runCachedNode 511 128175 Adaptive139Third132Node6 = false := by
  decide +kernel

#print axioms adaptive139Third132Proof6

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third132Proof31 : runCachedNode 511 128175 Adaptive139Third132Node31 = false := by
  decide +kernel

#print axioms adaptive139Third132Proof31

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third132Proof5 : runCachedNode 511 128175 Adaptive139Third132Node5 = false := by
  decide +kernel

#print axioms adaptive139Third132Proof5

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third132Proof32 : runCachedNode 511 128175 Adaptive139Third132Node32 = false := by
  decide +kernel

#print axioms adaptive139Third132Proof32

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third132Proof29 : runCachedNode 511 128175 Adaptive139Third132Node29 = false := by
  decide +kernel

#print axioms adaptive139Third132Proof29

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third132Proof27 : runCachedNode 511 128175 Adaptive139Third132Node27 = false := by
  decide +kernel

#print axioms adaptive139Third132Proof27

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third132Proof28 : runCachedNode 511 128175 Adaptive139Third132Node28 = false := by
  decide +kernel

#print axioms adaptive139Third132Proof28

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third132Proof3 : runCachedNode 511 128175 Adaptive139Third132Node3 = false := by
  decide +kernel

#print axioms adaptive139Third132Proof3

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third132Proof26 : runCachedNode 511 128175 Adaptive139Third132Node26 = false := by
  decide +kernel

#print axioms adaptive139Third132Proof26

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third132Proof2 : runCachedNode 511 128175 Adaptive139Third132Node2 = false := by
  decide +kernel

#print axioms adaptive139Third132Proof2

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third132Proof25 : runCachedNode 511 128175 Adaptive139Third132Node25 = false := by
  decide +kernel

#print axioms adaptive139Third132Proof25

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third132Proof24 : runCachedNode 511 128175 Adaptive139Third132Node24 = false := by
  decide +kernel

#print axioms adaptive139Third132Proof24

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third132Proof23 : runCachedNode 511 128175 Adaptive139Third132Node23 = false := by
  decide +kernel

#print axioms adaptive139Third132Proof23

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third132Proof1 : runCachedNode 511 128175 Adaptive139Third132Node1 = false := by
  decide +kernel

#print axioms adaptive139Third132Proof1

end NineSeparatedSubsetSums
