import NineSeparatedSubsetSums.Adaptive139Third138State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third138Proof15 : runCachedNode 511 129184 Adaptive139Third138Node15 = false := by
  decide +kernel

#print axioms adaptive139Third138Proof15

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third138Proof95 : runCachedNode 511 129184 Adaptive139Third138Node95 = false := by
  decide +kernel

#print axioms adaptive139Third138Proof95

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third138Proof14 : runCachedNode 511 129184 Adaptive139Third138Node14 = false := by
  decide +kernel

#print axioms adaptive139Third138Proof14

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third138Proof150 : runCachedNode 511 129184 Adaptive139Third138Node150 = false := by
  decide +kernel

#print axioms adaptive139Third138Proof150

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third138Proof13 : runCachedNode 511 129184 Adaptive139Third138Node13 = false := by
  decide +kernel

#print axioms adaptive139Third138Proof13

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third138Proof41 : runCachedNode 511 129184 Adaptive139Third138Node41 = false := by
  decide +kernel

#print axioms adaptive139Third138Proof41

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third138Proof90 : runCachedNode 511 129184 Adaptive139Third138Node90 = false := by
  decide +kernel

#print axioms adaptive139Third138Proof90

end NineSeparatedSubsetSums
