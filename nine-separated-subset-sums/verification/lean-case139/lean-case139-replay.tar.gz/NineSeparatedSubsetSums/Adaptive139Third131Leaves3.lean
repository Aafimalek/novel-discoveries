import NineSeparatedSubsetSums.Adaptive139Third131State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third131Proof5 : runCachedNode 511 128014 Adaptive139Third131Node5 = false := by
  decide +kernel

#print axioms adaptive139Third131Proof5

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third131Proof31 : runCachedNode 511 128014 Adaptive139Third131Node31 = false := by
  decide +kernel

#print axioms adaptive139Third131Proof31

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third131Proof28 : runCachedNode 511 128014 Adaptive139Third131Node28 = false := by
  decide +kernel

#print axioms adaptive139Third131Proof28

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third131Proof30 : runCachedNode 511 128014 Adaptive139Third131Node30 = false := by
  decide +kernel

#print axioms adaptive139Third131Proof30

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third131Proof27 : runCachedNode 511 128014 Adaptive139Third131Node27 = false := by
  decide +kernel

#print axioms adaptive139Third131Proof27

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third131Proof29 : runCachedNode 511 128014 Adaptive139Third131Node29 = false := by
  decide +kernel

#print axioms adaptive139Third131Proof29

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third131Proof26 : runCachedNode 511 128014 Adaptive139Third131Node26 = false := by
  decide +kernel

#print axioms adaptive139Third131Proof26

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third131Proof24 : runCachedNode 511 128014 Adaptive139Third131Node24 = false := by
  decide +kernel

#print axioms adaptive139Third131Proof24

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third131Proof25 : runCachedNode 511 128014 Adaptive139Third131Node25 = false := by
  decide +kernel

#print axioms adaptive139Third131Proof25

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third131Proof23 : runCachedNode 511 128014 Adaptive139Third131Node23 = false := by
  decide +kernel

#print axioms adaptive139Third131Proof23

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third131Proof22 : runCachedNode 511 128014 Adaptive139Third131Node22 = false := by
  decide +kernel

#print axioms adaptive139Third131Proof22

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third131Proof1 : runCachedNode 511 128014 Adaptive139Third131Node1 = false := by
  decide +kernel

#print axioms adaptive139Third131Proof1

end NineSeparatedSubsetSums
