import NineSeparatedSubsetSums.EightPoint139_134PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct139_134_0_budget :
    FourPointNumeric.packedBudget 20 packedOct139_134_0 273 = 90746726 := by decide +kernel

#print axioms packedOct139_134_0_budget

end NineSeparatedSubsetSums
