import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive139Third111Node0 : CachedSearchNode :=
  ⟨4, 110, computeCenteredMask [148,139,111], 398, 53546⟩

end NineSeparatedSubsetSums
