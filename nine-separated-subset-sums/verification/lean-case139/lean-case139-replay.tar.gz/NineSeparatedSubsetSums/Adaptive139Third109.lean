import NineSeparatedSubsetSums.Adaptive139Third109Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint139Checked

namespace NineSeparatedSubsetSums


theorem adaptive139Third109 : NoDescendingTailAfterThird 139 109 :=
  noDescendingThirdTail_of_cached 139 109 111380 (fun t ht nd => max148_second139_fourPoint_moment_bound (109::t) (by simp [ht]) nd) adaptive139Third109Proof0

#print axioms adaptive139Third109

end NineSeparatedSubsetSums
