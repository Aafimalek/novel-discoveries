import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive139Third123Node0 : CachedSearchNode :=
  ⟨4, 122, computeCenteredMask [148,139,123], 410, 56354⟩

end NineSeparatedSubsetSums
