import NineSeparatedSubsetSums.EightPoint139_119PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint139_119PackedAnchor0Part0 :
    ∀ j : Fin 120, 2321244 ≤ FourPointNumeric.octPackedCharge 139 119 20 packedOct139_119_0
      (2*((j.val : Int)+0)+0) := by decide +kernel

end NineSeparatedSubsetSums
