import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive139Third117Node0 : CachedSearchNode :=
  ⟨4, 116, computeCenteredMask [148,139,117], 404, 54914⟩

end NineSeparatedSubsetSums
