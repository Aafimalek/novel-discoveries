import NineSeparatedSubsetSums.Adaptive139Third138State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third138Proof181 : runCachedNode 511 129184 Adaptive139Third138Node181 = false := by
  decide +kernel

#print axioms adaptive139Third138Proof181

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third138Proof149 : runCachedNode 511 129184 Adaptive139Third138Node149 = false := by
  decide +kernel

#print axioms adaptive139Third138Proof149

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third138Proof93 : runCachedNode 511 129184 Adaptive139Third138Node93 = false := by
  decide +kernel

#print axioms adaptive139Third138Proof93

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third138Proof24 : runCachedNode 511 129184 Adaptive139Third138Node24 = false := by
  decide +kernel

#print axioms adaptive139Third138Proof24

end NineSeparatedSubsetSums
