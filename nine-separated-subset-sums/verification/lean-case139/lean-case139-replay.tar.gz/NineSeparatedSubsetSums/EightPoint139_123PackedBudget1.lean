import NineSeparatedSubsetSums.EightPoint139_123PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct139_123_1_budget :
    FourPointNumeric.packedBudget 20 packedOct139_123_1 480 = 82122378 := by decide +kernel

#print axioms packedOct139_123_1_budget

end NineSeparatedSubsetSums
