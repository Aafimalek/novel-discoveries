import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive139Third106Node0 : CachedSearchNode :=
  ⟨4, 105, computeCenteredMask [148,139,106], 393, 52461⟩

end NineSeparatedSubsetSums
