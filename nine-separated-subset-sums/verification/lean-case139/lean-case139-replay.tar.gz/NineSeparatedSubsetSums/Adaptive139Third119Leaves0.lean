import NineSeparatedSubsetSums.Adaptive139Third119State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third119Proof0 : runCachedNode 511 125264 Adaptive139Third119Node0 = false := by
  decide +kernel

#print axioms adaptive139Third119Proof0

end NineSeparatedSubsetSums
