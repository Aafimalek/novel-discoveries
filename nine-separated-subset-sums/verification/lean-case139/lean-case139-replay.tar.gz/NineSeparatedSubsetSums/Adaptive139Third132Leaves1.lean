import NineSeparatedSubsetSums.Adaptive139Third132State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third132Proof18 : runCachedNode 511 128175 Adaptive139Third132Node18 = false := by
  decide +kernel

#print axioms adaptive139Third132Proof18

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third132Proof17 : runCachedNode 511 128175 Adaptive139Third132Node17 = false := by
  decide +kernel

#print axioms adaptive139Third132Proof17

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third132Proof41 : runCachedNode 511 128175 Adaptive139Third132Node41 = false := by
  decide +kernel

#print axioms adaptive139Third132Proof41

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third132Proof4 : runCachedNode 511 128175 Adaptive139Third132Node4 = false := by
  decide +kernel

#print axioms adaptive139Third132Proof4

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third132Proof21 : runCachedNode 511 128175 Adaptive139Third132Node21 = false := by
  decide +kernel

#print axioms adaptive139Third132Proof21

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third132Proof20 : runCachedNode 511 128175 Adaptive139Third132Node20 = false := by
  decide +kernel

#print axioms adaptive139Third132Proof20

end NineSeparatedSubsetSums
