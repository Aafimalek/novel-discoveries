import NineSeparatedSubsetSums.EightPointPackedGeometry
import NineSeparatedSubsetSums.EightPoint139_117PackedBudget0
import NineSeparatedSubsetSums.EightPoint139_117PackedAnchor0Part0
import NineSeparatedSubsetSums.EightPoint139_117PackedAnchor0Part1
import NineSeparatedSubsetSums.EightPoint139_117PackedAnchor0Part2
import NineSeparatedSubsetSums.EightPoint139_117PackedBudget1
import NineSeparatedSubsetSums.EightPoint139_117PackedAnchor1Part0
import NineSeparatedSubsetSums.EightPoint139_117PackedAnchor1Part1
import NineSeparatedSubsetSums.EightPoint139_117PackedAnchor1Part2

namespace NineSeparatedSubsetSums

private theorem packedOct139_117Anchor0 :
  ∀ j : Fin 487, ((j.val : Int)+139+117)%2=0 →
    2329471 ≤ FourPointNumeric.octPackedCharge 139 117 20 packedOct139_117_0 (j.val : Int) := by
  intro j hj
  let k := (j.val-0)/2
  have hk : k < 244 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+0 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint139_117PackedAnchor0Part0 z
    rwa [he,hrep] at ht
  by_cases h1 : k < 240
  · let z : Fin 120 := ⟨k-120, by omega⟩
    have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
    have ht := eightPoint139_117PackedAnchor0Part1 z
    rwa [he,hrep] at ht
  let z : Fin 4 := ⟨k-240, by omega⟩
  have he : (z.val : Int)+240 = k := by dsimp [z] <;> omega
  have ht := eightPoint139_117PackedAnchor0Part2 z
  rwa [he,hrep] at ht

private theorem packedOct139_117Anchor1 :
  ∀ j : Fin 487, ((j.val : Int)+139+117)%2=1 →
    2331663 ≤ FourPointNumeric.octPackedCharge 139 117 20 packedOct139_117_1 (j.val : Int) := by
  intro j hj
  let k := (j.val-1)/2
  have hk : k < 243 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+1 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint139_117PackedAnchor1Part0 z
    rwa [he,hrep] at ht
  by_cases h1 : k < 240
  · let z : Fin 120 := ⟨k-120, by omega⟩
    have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
    have ht := eightPoint139_117PackedAnchor1Part1 z
    rwa [he,hrep] at ht
  let z : Fin 3 := ⟨k-240, by omega⟩
  have he : (z.val : Int)+240 = k := by dsimp [z] <;> omega
  have ht := eightPoint139_117PackedAnchor1Part2 z
  rwa [he,hrep] at ht

def packedOctCertificate139_117_0 : EightPointCertificate 139 117 0 124859 :=
  eightPointCertificateOfPacked 139 117 0 124859 2329471 20 packedOct139_117_0 427 487
    (by decide +kernel) (by decide) packedOct139_117Anchor0
    (by rw [packedOct139_117_0_budget]; decide)

def packedOctCertificate139_117_1 : EightPointCertificate 139 117 1 124859 :=
  eightPointCertificateOfPacked 139 117 1 124859 2331663 20 packedOct139_117_1 428 487
    (by decide +kernel) (by decide) packedOct139_117Anchor1
    (by rw [packedOct139_117_1_budget]; decide)

theorem max148_second139_third117_eightPoint_moment_bound (tail : List ℕ) (len : tail.length=6)
    (distinct : (natSubsetSums (148::139::117::tail)).Nodup) :
    124859 ≤ ((148::139::117::tail).map (· ^ 2)).sum := by
  apply eightPointNatMomentLower 139 117 124859 tail len distinct
  intro p hp
  by_cases h : p=0
  · subst p
    exact packedOctCertificate139_117_0
  · have he : p=1 := hp.resolve_left h
    subst p
    exact packedOctCertificate139_117_1

#print axioms max148_second139_third117_eightPoint_moment_bound

end NineSeparatedSubsetSums
