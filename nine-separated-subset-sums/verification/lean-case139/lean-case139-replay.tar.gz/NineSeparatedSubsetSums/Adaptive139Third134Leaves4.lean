import NineSeparatedSubsetSums.Adaptive139Third134State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third134Proof16 : runCachedNode 511 128469 Adaptive139Third134Node16 = false := by
  decide +kernel

#print axioms adaptive139Third134Proof16

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third134Proof68 : runCachedNode 511 128469 Adaptive139Third134Node68 = false := by
  decide +kernel

#print axioms adaptive139Third134Proof68

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third134Proof39 : runCachedNode 511 128469 Adaptive139Third134Node39 = false := by
  decide +kernel

#print axioms adaptive139Third134Proof39

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third134Proof15 : runCachedNode 511 128469 Adaptive139Third134Node15 = false := by
  decide +kernel

#print axioms adaptive139Third134Proof15

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third134Proof14 : runCachedNode 511 128469 Adaptive139Third134Node14 = false := by
  decide +kernel

#print axioms adaptive139Third134Proof14

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third134Proof77 : runCachedNode 511 128469 Adaptive139Third134Node77 = false := by
  decide +kernel

#print axioms adaptive139Third134Proof77

end NineSeparatedSubsetSums
