import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive139Third114Node0 : CachedSearchNode :=
  ⟨4, 113, computeCenteredMask [148,139,114], 401, 54221⟩

end NineSeparatedSubsetSums
