import NineSeparatedSubsetSums.EightPoint139_135PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint139_135PackedAnchor1Part2 :
    ∀ j : Fin 10, 2472797 ≤ FourPointNumeric.octPackedCharge 139 135 20 packedOct139_135_1
      (2*((j.val : Int)+240)+1) := by decide +kernel

end NineSeparatedSubsetSums
