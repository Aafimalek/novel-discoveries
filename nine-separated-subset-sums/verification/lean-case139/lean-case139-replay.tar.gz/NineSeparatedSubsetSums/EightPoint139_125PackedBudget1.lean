import NineSeparatedSubsetSums.EightPoint139_125PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct139_125_1_budget :
    FourPointNumeric.packedBudget 20 packedOct139_125_1 426 = 83398846 := by decide +kernel

#print axioms packedOct139_125_1_budget

end NineSeparatedSubsetSums
