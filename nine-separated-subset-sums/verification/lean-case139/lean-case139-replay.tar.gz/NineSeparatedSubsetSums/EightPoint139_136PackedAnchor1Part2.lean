import NineSeparatedSubsetSums.EightPoint139_136PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint139_136PackedAnchor1Part2 :
    ∀ j : Fin 10, 2461642 ≤ FourPointNumeric.octPackedCharge 139 136 20 packedOct139_136_1
      (2*((j.val : Int)+240)+0) := by decide +kernel

end NineSeparatedSubsetSums
