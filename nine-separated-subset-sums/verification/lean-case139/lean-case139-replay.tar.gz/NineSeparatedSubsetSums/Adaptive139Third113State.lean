import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive139Third113Node0 : CachedSearchNode :=
  ⟨4, 112, computeCenteredMask [148,139,113], 400, 53994⟩

end NineSeparatedSubsetSums
