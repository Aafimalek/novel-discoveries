import NineSeparatedSubsetSums.Adaptive139Third116State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third116Proof15 : runCachedNode 511 111380 Adaptive139Third116Node15 = false := by
  decide +kernel

#print axioms adaptive139Third116Proof15

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third116Proof14 : runCachedNode 511 111380 Adaptive139Third116Node14 = false := by
  decide +kernel

#print axioms adaptive139Third116Proof14

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third116Proof13 : runCachedNode 511 111380 Adaptive139Third116Node13 = false := by
  decide +kernel

#print axioms adaptive139Third116Proof13

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third116Proof8 : runCachedNode 511 111380 Adaptive139Third116Node8 = false := by
  decide +kernel

#print axioms adaptive139Third116Proof8

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third116Proof3 : runCachedNode 511 111380 Adaptive139Third116Node3 = false := by
  decide +kernel

#print axioms adaptive139Third116Proof3

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third116Proof1 : runCachedNode 511 111380 Adaptive139Third116Node1 = false := by
  decide +kernel

#print axioms adaptive139Third116Proof1

end NineSeparatedSubsetSums
