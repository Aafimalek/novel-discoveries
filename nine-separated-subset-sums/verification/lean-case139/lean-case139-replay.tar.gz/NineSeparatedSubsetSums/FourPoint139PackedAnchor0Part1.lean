import NineSeparatedSubsetSums.FourPoint139PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem fourPoint139PackedAnchor0Part1 :
    ∀ j : Fin 117, 1063544 ≤ FourPointNumeric.packedCharge 139 20 packedWeight139_0
      (2*((j.val : Int)+120)+1) := by decide +kernel

end NineSeparatedSubsetSums
