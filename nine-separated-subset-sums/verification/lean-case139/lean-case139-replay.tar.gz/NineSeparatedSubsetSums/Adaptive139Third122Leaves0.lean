import NineSeparatedSubsetSums.Adaptive139Third122State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third122Proof0 : runCachedNode 511 125803 Adaptive139Third122Node0 = false := by
  decide +kernel

#print axioms adaptive139Third122Proof0

end NineSeparatedSubsetSums
