import NineSeparatedSubsetSums.Adaptive139Third136State
import NineSeparatedSubsetSums.Adaptive139Third136Leaves12
import NineSeparatedSubsetSums.Adaptive139Third136Leaves5
import NineSeparatedSubsetSums.Adaptive139Third136Leaves3
import NineSeparatedSubsetSums.Adaptive139Third136Leaves11
import NineSeparatedSubsetSums.Adaptive139Third136Leaves10
import NineSeparatedSubsetSums.Adaptive139Third136Leaves6
import NineSeparatedSubsetSums.Adaptive139Third136Leaves8
import NineSeparatedSubsetSums.Adaptive139Third136Leaves0
import NineSeparatedSubsetSums.Adaptive139Third136Leaves1
import NineSeparatedSubsetSums.Adaptive139Third136Leaves9
import NineSeparatedSubsetSums.Adaptive139Third136Leaves7
import NineSeparatedSubsetSums.Adaptive139Third136Leaves4
import NineSeparatedSubsetSums.Adaptive139Third136Leaves2

namespace NineSeparatedSubsetSums

theorem adaptive139Third136Proof20 : runCachedNode 511 128827 Adaptive139Third136Node20 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 128827 Adaptive139Third136Node20 = [105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 119, 120, 122, 123, 124, 125, 126, 128, 129] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive139Third136Proof21
  · exact adaptive139Third136Proof22
  · exact adaptive139Third136Proof23
  · exact adaptive139Third136Proof24
  · exact adaptive139Third136Proof25
  · exact adaptive139Third136Proof26
  · exact adaptive139Third136Proof27
  · exact adaptive139Third136Proof28
  · exact adaptive139Third136Proof29
  · exact adaptive139Third136Proof30
  · exact adaptive139Third136Proof31
  · exact adaptive139Third136Proof32
  · exact adaptive139Third136Proof33
  · exact adaptive139Third136Proof34
  · exact adaptive139Third136Proof35
  · exact adaptive139Third136Proof36
  · exact adaptive139Third136Proof37
  · exact adaptive139Third136Proof38
  · exact adaptive139Third136Proof39
  · exact adaptive139Third136Proof40
  · exact adaptive139Third136Proof41
  · exact adaptive139Third136Proof42

#print axioms adaptive139Third136Proof20

theorem adaptive139Third136Proof44 : runCachedNode 511 128827 Adaptive139Third136Node44 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 128827 Adaptive139Third136Node44 = [104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 121, 122, 124, 125, 126, 128, 130, 131] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive139Third136Proof45
  · exact adaptive139Third136Proof46
  · exact adaptive139Third136Proof47
  · exact adaptive139Third136Proof48
  · exact adaptive139Third136Proof49
  · exact adaptive139Third136Proof50
  · exact adaptive139Third136Proof51
  · exact adaptive139Third136Proof52
  · exact adaptive139Third136Proof53
  · exact adaptive139Third136Proof54
  · exact adaptive139Third136Proof55
  · exact adaptive139Third136Proof56
  · exact adaptive139Third136Proof57
  · exact adaptive139Third136Proof58
  · exact adaptive139Third136Proof59
  · exact adaptive139Third136Proof60
  · exact adaptive139Third136Proof61
  · exact adaptive139Third136Proof62
  · exact adaptive139Third136Proof63
  · exact adaptive139Third136Proof64
  · exact adaptive139Third136Proof65
  · exact adaptive139Third136Proof66
  · exact adaptive139Third136Proof67
  · exact adaptive139Third136Proof68

#print axioms adaptive139Third136Proof44

theorem adaptive139Third136Proof69 : runCachedNode 511 128827 Adaptive139Third136Node69 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 128827 Adaptive139Third136Node69 = [104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 122, 123, 125, 126, 128, 129, 131, 132] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive139Third136Proof70
  · exact adaptive139Third136Proof71
  · exact adaptive139Third136Proof72
  · exact adaptive139Third136Proof73
  · exact adaptive139Third136Proof74
  · exact adaptive139Third136Proof75
  · exact adaptive139Third136Proof76
  · exact adaptive139Third136Proof77
  · exact adaptive139Third136Proof78
  · exact adaptive139Third136Proof79
  · exact adaptive139Third136Proof80
  · exact adaptive139Third136Proof81
  · exact adaptive139Third136Proof82
  · exact adaptive139Third136Proof83
  · exact adaptive139Third136Proof84
  · exact adaptive139Third136Proof85
  · exact adaptive139Third136Proof86
  · exact adaptive139Third136Proof87
  · exact adaptive139Third136Proof88
  · exact adaptive139Third136Proof89
  · exact adaptive139Third136Proof90
  · exact adaptive139Third136Proof91
  · exact adaptive139Third136Proof92
  · exact adaptive139Third136Proof93
  · exact adaptive139Third136Proof94

#print axioms adaptive139Third136Proof69

theorem adaptive139Third136Proof95 : runCachedNode 511 128827 Adaptive139Third136Node95 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 128827 Adaptive139Third136Node95 = [104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 123, 124, 126, 128, 129, 130, 132, 133] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive139Third136Proof96
  · exact adaptive139Third136Proof97
  · exact adaptive139Third136Proof98
  · exact adaptive139Third136Proof99
  · exact adaptive139Third136Proof100
  · exact adaptive139Third136Proof101
  · exact adaptive139Third136Proof102
  · exact adaptive139Third136Proof103
  · exact adaptive139Third136Proof104
  · exact adaptive139Third136Proof105
  · exact adaptive139Third136Proof106
  · exact adaptive139Third136Proof107
  · exact adaptive139Third136Proof108
  · exact adaptive139Third136Proof109
  · exact adaptive139Third136Proof110
  · exact adaptive139Third136Proof111
  · exact adaptive139Third136Proof112
  · exact adaptive139Third136Proof113
  · exact adaptive139Third136Proof114
  · exact adaptive139Third136Proof115
  · exact adaptive139Third136Proof116
  · exact adaptive139Third136Proof117
  · exact adaptive139Third136Proof118
  · exact adaptive139Third136Proof119
  · exact adaptive139Third136Proof120
  · exact adaptive139Third136Proof121

#print axioms adaptive139Third136Proof95

theorem adaptive139Third136Proof122 : runCachedNode 511 128827 Adaptive139Third136Node122 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 128827 Adaptive139Third136Node122 = [103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 124, 125, 128, 129, 130, 131, 133, 134] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive139Third136Proof123
  · exact adaptive139Third136Proof124
  · exact adaptive139Third136Proof125
  · exact adaptive139Third136Proof126
  · exact adaptive139Third136Proof127
  · exact adaptive139Third136Proof128
  · exact adaptive139Third136Proof129
  · exact adaptive139Third136Proof130
  · exact adaptive139Third136Proof131
  · exact adaptive139Third136Proof132
  · exact adaptive139Third136Proof133
  · exact adaptive139Third136Proof134
  · exact adaptive139Third136Proof135
  · exact adaptive139Third136Proof136
  · exact adaptive139Third136Proof137
  · exact adaptive139Third136Proof138
  · exact adaptive139Third136Proof139
  · exact adaptive139Third136Proof140
  · exact adaptive139Third136Proof141
  · exact adaptive139Third136Proof142
  · exact adaptive139Third136Proof143
  · exact adaptive139Third136Proof144
  · exact adaptive139Third136Proof145
  · exact adaptive139Third136Proof146
  · exact adaptive139Third136Proof147
  · exact adaptive139Third136Proof148
  · exact adaptive139Third136Proof149
  · exact adaptive139Third136Proof150

#print axioms adaptive139Third136Proof122

theorem adaptive139Third136Proof0 : runCachedNode 511 128827 Adaptive139Third136Node0 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 128827 Adaptive139Third136Node0 = [110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 128, 129, 130, 131, 132, 133, 134, 135] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive139Third136Proof1
  · exact adaptive139Third136Proof2
  · exact adaptive139Third136Proof3
  · exact adaptive139Third136Proof4
  · exact adaptive139Third136Proof5
  · exact adaptive139Third136Proof6
  · exact adaptive139Third136Proof7
  · exact adaptive139Third136Proof8
  · exact adaptive139Third136Proof9
  · exact adaptive139Third136Proof10
  · exact adaptive139Third136Proof11
  · exact adaptive139Third136Proof12
  · exact adaptive139Third136Proof13
  · exact adaptive139Third136Proof14
  · exact adaptive139Third136Proof15
  · exact adaptive139Third136Proof16
  · exact adaptive139Third136Proof17
  · exact adaptive139Third136Proof18
  · exact adaptive139Third136Proof19
  · exact adaptive139Third136Proof20
  · exact adaptive139Third136Proof43
  · exact adaptive139Third136Proof44
  · exact adaptive139Third136Proof69
  · exact adaptive139Third136Proof95
  · exact adaptive139Third136Proof122

#print axioms adaptive139Third136Proof0

end NineSeparatedSubsetSums
