import NineSeparatedSubsetSums.Adaptive139Third138State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third138Proof247 : runCachedNode 511 129184 Adaptive139Third138Node247 = false := by
  decide +kernel

#print axioms adaptive139Third138Proof247

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third138Proof246 : runCachedNode 511 129184 Adaptive139Third138Node246 = false := by
  decide +kernel

#print axioms adaptive139Third138Proof246

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third138Proof68 : runCachedNode 511 129184 Adaptive139Third138Node68 = false := by
  decide +kernel

#print axioms adaptive139Third138Proof68

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third138Proof75 : runCachedNode 511 129184 Adaptive139Third138Node75 = false := by
  decide +kernel

#print axioms adaptive139Third138Proof75

end NineSeparatedSubsetSums
