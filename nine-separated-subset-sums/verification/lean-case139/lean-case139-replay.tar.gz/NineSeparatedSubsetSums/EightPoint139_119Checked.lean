import NineSeparatedSubsetSums.EightPointPackedGeometry
import NineSeparatedSubsetSums.EightPoint139_119PackedBudget0
import NineSeparatedSubsetSums.EightPoint139_119PackedAnchor0Part0
import NineSeparatedSubsetSums.EightPoint139_119PackedAnchor0Part1
import NineSeparatedSubsetSums.EightPoint139_119PackedAnchor0Part2
import NineSeparatedSubsetSums.EightPoint139_119PackedBudget1
import NineSeparatedSubsetSums.EightPoint139_119PackedAnchor1Part0
import NineSeparatedSubsetSums.EightPoint139_119PackedAnchor1Part1
import NineSeparatedSubsetSums.EightPoint139_119PackedAnchor1Part2

namespace NineSeparatedSubsetSums

private theorem packedOct139_119Anchor0 :
  ∀ j : Fin 485, ((j.val : Int)+139+119)%2=0 →
    2321244 ≤ FourPointNumeric.octPackedCharge 139 119 20 packedOct139_119_0 (j.val : Int) := by
  intro j hj
  let k := (j.val-0)/2
  have hk : k < 243 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+0 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint139_119PackedAnchor0Part0 z
    rwa [he,hrep] at ht
  by_cases h1 : k < 240
  · let z : Fin 120 := ⟨k-120, by omega⟩
    have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
    have ht := eightPoint139_119PackedAnchor0Part1 z
    rwa [he,hrep] at ht
  let z : Fin 3 := ⟨k-240, by omega⟩
  have he : (z.val : Int)+240 = k := by dsimp [z] <;> omega
  have ht := eightPoint139_119PackedAnchor0Part2 z
  rwa [he,hrep] at ht

private theorem packedOct139_119Anchor1 :
  ∀ j : Fin 485, ((j.val : Int)+139+119)%2=1 →
    2321418 ≤ FourPointNumeric.octPackedCharge 139 119 20 packedOct139_119_1 (j.val : Int) := by
  intro j hj
  let k := (j.val-1)/2
  have hk : k < 242 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+1 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint139_119PackedAnchor1Part0 z
    rwa [he,hrep] at ht
  by_cases h1 : k < 240
  · let z : Fin 120 := ⟨k-120, by omega⟩
    have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
    have ht := eightPoint139_119PackedAnchor1Part1 z
    rwa [he,hrep] at ht
  let z : Fin 2 := ⟨k-240, by omega⟩
  have he : (z.val : Int)+240 = k := by dsimp [z] <;> omega
  have ht := eightPoint139_119PackedAnchor1Part2 z
  rwa [he,hrep] at ht

def packedOctCertificate139_119_0 : EightPointCertificate 139 119 0 125264 :=
  eightPointCertificateOfPacked 139 119 0 125264 2321244 20 packedOct139_119_0 345 485
    (by decide +kernel) (by decide) packedOct139_119Anchor0
    (by rw [packedOct139_119_0_budget]; decide)

def packedOctCertificate139_119_1 : EightPointCertificate 139 119 1 125264 :=
  eightPointCertificateOfPacked 139 119 1 125264 2321418 20 packedOct139_119_1 346 485
    (by decide +kernel) (by decide) packedOct139_119Anchor1
    (by rw [packedOct139_119_1_budget]; decide)

theorem max148_second139_third119_eightPoint_moment_bound (tail : List ℕ) (len : tail.length=6)
    (distinct : (natSubsetSums (148::139::119::tail)).Nodup) :
    125264 ≤ ((148::139::119::tail).map (· ^ 2)).sum := by
  apply eightPointNatMomentLower 139 119 125264 tail len distinct
  intro p hp
  by_cases h : p=0
  · subst p
    exact packedOctCertificate139_119_0
  · have he : p=1 := hp.resolve_left h
    subst p
    exact packedOctCertificate139_119_1

#print axioms max148_second139_third119_eightPoint_moment_bound

end NineSeparatedSubsetSums
