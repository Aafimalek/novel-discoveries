import NineSeparatedSubsetSums.Adaptive139Third131State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third131Proof38 : runCachedNode 511 128014 Adaptive139Third131Node38 = false := by
  decide +kernel

#print axioms adaptive139Third131Proof38

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third131Proof40 : runCachedNode 511 128014 Adaptive139Third131Node40 = false := by
  decide +kernel

#print axioms adaptive139Third131Proof40

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third131Proof35 : runCachedNode 511 128014 Adaptive139Third131Node35 = false := by
  decide +kernel

#print axioms adaptive139Third131Proof35

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third131Proof39 : runCachedNode 511 128014 Adaptive139Third131Node39 = false := by
  decide +kernel

#print axioms adaptive139Third131Proof39

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third131Proof11 : runCachedNode 511 128014 Adaptive139Third131Node11 = false := by
  decide +kernel

#print axioms adaptive139Third131Proof11

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third131Proof10 : runCachedNode 511 128014 Adaptive139Third131Node10 = false := by
  decide +kernel

#print axioms adaptive139Third131Proof10

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third131Proof37 : runCachedNode 511 128014 Adaptive139Third131Node37 = false := by
  decide +kernel

#print axioms adaptive139Third131Proof37

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third131Proof9 : runCachedNode 511 128014 Adaptive139Third131Node9 = false := by
  decide +kernel

#print axioms adaptive139Third131Proof9

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third131Proof8 : runCachedNode 511 128014 Adaptive139Third131Node8 = false := by
  decide +kernel

#print axioms adaptive139Third131Proof8

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third131Proof36 : runCachedNode 511 128014 Adaptive139Third131Node36 = false := by
  decide +kernel

#print axioms adaptive139Third131Proof36

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third131Proof34 : runCachedNode 511 128014 Adaptive139Third131Node34 = false := by
  decide +kernel

#print axioms adaptive139Third131Proof34

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third131Proof7 : runCachedNode 511 128014 Adaptive139Third131Node7 = false := by
  decide +kernel

#print axioms adaptive139Third131Proof7

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third131Proof33 : runCachedNode 511 128014 Adaptive139Third131Node33 = false := by
  decide +kernel

#print axioms adaptive139Third131Proof33

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third131Proof6 : runCachedNode 511 128014 Adaptive139Third131Node6 = false := by
  decide +kernel

#print axioms adaptive139Third131Proof6

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third131Proof32 : runCachedNode 511 128014 Adaptive139Third131Node32 = false := by
  decide +kernel

#print axioms adaptive139Third131Proof32

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third131Proof2 : runCachedNode 511 128014 Adaptive139Third131Node2 = false := by
  decide +kernel

#print axioms adaptive139Third131Proof2

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third131Proof20 : runCachedNode 511 128014 Adaptive139Third131Node20 = false := by
  decide +kernel

#print axioms adaptive139Third131Proof20

end NineSeparatedSubsetSums
