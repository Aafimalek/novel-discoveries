import NineSeparatedSubsetSums.EightPoint139_132PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint139_132PackedAnchor1Part0 :
    ∀ j : Fin 120, 2428556 ≤ FourPointNumeric.octPackedCharge 139 132 20 packedOct139_132_1
      (2*((j.val : Int)+0)+0) := by decide +kernel

end NineSeparatedSubsetSums
