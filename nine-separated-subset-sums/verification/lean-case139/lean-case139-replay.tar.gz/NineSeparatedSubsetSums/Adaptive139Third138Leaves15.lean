import NineSeparatedSubsetSums.Adaptive139Third138State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third138Proof146 : runCachedNode 511 129184 Adaptive139Third138Node146 = false := by
  decide +kernel

#print axioms adaptive139Third138Proof146

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third138Proof67 : runCachedNode 511 129184 Adaptive139Third138Node67 = false := by
  decide +kernel

#print axioms adaptive139Third138Proof67

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third138Proof144 : runCachedNode 511 129184 Adaptive139Third138Node144 = false := by
  decide +kernel

#print axioms adaptive139Third138Proof144

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third138Proof64 : runCachedNode 511 129184 Adaptive139Third138Node64 = false := by
  decide +kernel

#print axioms adaptive139Third138Proof64

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third138Proof38 : runCachedNode 511 129184 Adaptive139Third138Node38 = false := by
  decide +kernel

#print axioms adaptive139Third138Proof38

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third138Proof199 : runCachedNode 511 129184 Adaptive139Third138Node199 = false := by
  decide +kernel

#print axioms adaptive139Third138Proof199

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third138Proof10 : runCachedNode 511 129184 Adaptive139Third138Node10 = false := by
  decide +kernel

#print axioms adaptive139Third138Proof10

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third138Proof65 : runCachedNode 511 129184 Adaptive139Third138Node65 = false := by
  decide +kernel

#print axioms adaptive139Third138Proof65

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third138Proof115 : runCachedNode 511 129184 Adaptive139Third138Node115 = false := by
  decide +kernel

#print axioms adaptive139Third138Proof115

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third138Proof116 : runCachedNode 511 129184 Adaptive139Third138Node116 = false := by
  decide +kernel

#print axioms adaptive139Third138Proof116

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third138Proof119 : runCachedNode 511 129184 Adaptive139Third138Node119 = false := by
  decide +kernel

#print axioms adaptive139Third138Proof119

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third138Proof198 : runCachedNode 511 129184 Adaptive139Third138Node198 = false := by
  decide +kernel

#print axioms adaptive139Third138Proof198

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third138Proof174 : runCachedNode 511 129184 Adaptive139Third138Node174 = false := by
  decide +kernel

#print axioms adaptive139Third138Proof174

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third138Proof91 : runCachedNode 511 129184 Adaptive139Third138Node91 = false := by
  decide +kernel

#print axioms adaptive139Third138Proof91

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third138Proof113 : runCachedNode 511 129184 Adaptive139Third138Node113 = false := by
  decide +kernel

#print axioms adaptive139Third138Proof113

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third138Proof245 : runCachedNode 511 129184 Adaptive139Third138Node245 = false := by
  decide +kernel

#print axioms adaptive139Third138Proof245

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third138Proof143 : runCachedNode 511 129184 Adaptive139Third138Node143 = false := by
  decide +kernel

#print axioms adaptive139Third138Proof143

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third138Proof163 : runCachedNode 511 129184 Adaptive139Third138Node163 = false := by
  decide +kernel

#print axioms adaptive139Third138Proof163

end NineSeparatedSubsetSums
