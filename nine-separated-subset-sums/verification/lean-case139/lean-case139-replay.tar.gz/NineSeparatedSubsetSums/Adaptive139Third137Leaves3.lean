import NineSeparatedSubsetSums.Adaptive139Third137State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third137Proof96 : runCachedNode 511 129004 Adaptive139Third137Node96 = false := by
  decide +kernel

#print axioms adaptive139Third137Proof96

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third137Proof155 : runCachedNode 511 129004 Adaptive139Third137Node155 = false := by
  decide +kernel

#print axioms adaptive139Third137Proof155

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third137Proof26 : runCachedNode 511 129004 Adaptive139Third137Node26 = false := by
  decide +kernel

#print axioms adaptive139Third137Proof26

end NineSeparatedSubsetSums
