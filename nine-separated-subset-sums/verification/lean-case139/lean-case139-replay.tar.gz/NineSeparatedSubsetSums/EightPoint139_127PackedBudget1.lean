import NineSeparatedSubsetSums.EightPoint139_127PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct139_127_1_budget :
    FourPointNumeric.packedBudget 20 packedOct139_127_1 444 = 85199302 := by decide +kernel

#print axioms packedOct139_127_1_budget

end NineSeparatedSubsetSums
