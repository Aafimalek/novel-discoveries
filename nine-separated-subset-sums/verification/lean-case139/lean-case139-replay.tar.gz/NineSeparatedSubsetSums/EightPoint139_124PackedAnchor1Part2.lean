import NineSeparatedSubsetSums.EightPoint139_124PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint139_124PackedAnchor1Part2 :
    ∀ j : Fin 1, 2303567 ≤ FourPointNumeric.octPackedCharge 139 124 20 packedOct139_124_1
      (2*((j.val : Int)+240)+0) := by decide +kernel

end NineSeparatedSubsetSums
