import NineSeparatedSubsetSums.EightPointPackedGeometry
import NineSeparatedSubsetSums.EightPoint139_134PackedBudget0
import NineSeparatedSubsetSums.EightPoint139_134PackedAnchor0Part0
import NineSeparatedSubsetSums.EightPoint139_134PackedAnchor0Part1
import NineSeparatedSubsetSums.EightPoint139_134PackedAnchor0Part2
import NineSeparatedSubsetSums.EightPoint139_134PackedBudget1
import NineSeparatedSubsetSums.EightPoint139_134PackedAnchor1Part0
import NineSeparatedSubsetSums.EightPoint139_134PackedAnchor1Part1
import NineSeparatedSubsetSums.EightPoint139_134PackedAnchor1Part2

namespace NineSeparatedSubsetSums

private theorem packedOct139_134Anchor0 :
  ∀ j : Fin 497, ((j.val : Int)+139+134)%2=0 →
    2445665 ≤ FourPointNumeric.octPackedCharge 139 134 20 packedOct139_134_0 (j.val : Int) := by
  intro j hj
  let k := (j.val-1)/2
  have hk : k < 248 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+1 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint139_134PackedAnchor0Part0 z
    rwa [he,hrep] at ht
  by_cases h1 : k < 240
  · let z : Fin 120 := ⟨k-120, by omega⟩
    have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
    have ht := eightPoint139_134PackedAnchor0Part1 z
    rwa [he,hrep] at ht
  let z : Fin 8 := ⟨k-240, by omega⟩
  have he : (z.val : Int)+240 = k := by dsimp [z] <;> omega
  have ht := eightPoint139_134PackedAnchor0Part2 z
  rwa [he,hrep] at ht

private theorem packedOct139_134Anchor1 :
  ∀ j : Fin 497, ((j.val : Int)+139+134)%2=1 →
    2443771 ≤ FourPointNumeric.octPackedCharge 139 134 20 packedOct139_134_1 (j.val : Int) := by
  intro j hj
  let k := (j.val-0)/2
  have hk : k < 249 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+0 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint139_134PackedAnchor1Part0 z
    rwa [he,hrep] at ht
  by_cases h1 : k < 240
  · let z : Fin 120 := ⟨k-120, by omega⟩
    have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
    have ht := eightPoint139_134PackedAnchor1Part1 z
    rwa [he,hrep] at ht
  let z : Fin 9 := ⟨k-240, by omega⟩
  have he : (z.val : Int)+240 = k := by dsimp [z] <;> omega
  have ht := eightPoint139_134PackedAnchor1Part2 z
  rwa [he,hrep] at ht

def packedOctCertificate139_134_0 : EightPointCertificate 139 134 0 128469 :=
  eightPointCertificateOfPacked 139 134 0 128469 2445665 20 packedOct139_134_0 273 497
    (by decide +kernel) (by decide) packedOct139_134Anchor0
    (by rw [packedOct139_134_0_budget]; decide)

def packedOctCertificate139_134_1 : EightPointCertificate 139 134 1 128469 :=
  eightPointCertificateOfPacked 139 134 1 128469 2443771 20 packedOct139_134_1 272 497
    (by decide +kernel) (by decide) packedOct139_134Anchor1
    (by rw [packedOct139_134_1_budget]; decide)

theorem max148_second139_third134_eightPoint_moment_bound (tail : List ℕ) (len : tail.length=6)
    (distinct : (natSubsetSums (148::139::134::tail)).Nodup) :
    128469 ≤ ((148::139::134::tail).map (· ^ 2)).sum := by
  apply eightPointNatMomentLower 139 134 128469 tail len distinct
  intro p hp
  by_cases h : p=0
  · subst p
    exact packedOctCertificate139_134_0
  · have he : p=1 := hp.resolve_left h
    subst p
    exact packedOctCertificate139_134_1

#print axioms max148_second139_third134_eightPoint_moment_bound

end NineSeparatedSubsetSums
