import NineSeparatedSubsetSums.EightPoint139_118PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint139_118PackedAnchor0Part0 :
    ∀ j : Fin 120, 2340685 ≤ FourPointNumeric.octPackedCharge 139 118 20 packedOct139_118_0
      (2*((j.val : Int)+0)+1) := by decide +kernel

end NineSeparatedSubsetSums
