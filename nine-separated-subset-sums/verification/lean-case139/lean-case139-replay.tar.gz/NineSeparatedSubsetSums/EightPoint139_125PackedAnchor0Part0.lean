import NineSeparatedSubsetSums.EightPoint139_125PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint139_125PackedAnchor0Part0 :
    ∀ j : Fin 120, 2317501 ≤ FourPointNumeric.octPackedCharge 139 125 20 packedOct139_125_0
      (2*((j.val : Int)+0)+0) := by decide +kernel

end NineSeparatedSubsetSums
