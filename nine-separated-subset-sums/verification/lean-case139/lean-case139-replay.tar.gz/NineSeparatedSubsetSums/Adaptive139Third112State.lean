import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive139Third112Node0 : CachedSearchNode :=
  ⟨4, 111, computeCenteredMask [148,139,112], 399, 53769⟩

end NineSeparatedSubsetSums
