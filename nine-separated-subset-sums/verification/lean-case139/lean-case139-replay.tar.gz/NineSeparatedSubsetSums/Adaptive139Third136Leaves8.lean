import NineSeparatedSubsetSums.Adaptive139Third136State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third136Proof117 : runCachedNode 511 128827 Adaptive139Third136Node117 = false := by
  decide +kernel

#print axioms adaptive139Third136Proof117

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third136Proof146 : runCachedNode 511 128827 Adaptive139Third136Node146 = false := by
  decide +kernel

#print axioms adaptive139Third136Proof146

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third136Proof65 : runCachedNode 511 128827 Adaptive139Third136Node65 = false := by
  decide +kernel

#print axioms adaptive139Third136Proof65

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third136Proof41 : runCachedNode 511 128827 Adaptive139Third136Node41 = false := by
  decide +kernel

#print axioms adaptive139Third136Proof41

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third136Proof42 : runCachedNode 511 128827 Adaptive139Third136Node42 = false := by
  decide +kernel

#print axioms adaptive139Third136Proof42

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third136Proof40 : runCachedNode 511 128827 Adaptive139Third136Node40 = false := by
  decide +kernel

#print axioms adaptive139Third136Proof40

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third136Proof39 : runCachedNode 511 128827 Adaptive139Third136Node39 = false := by
  decide +kernel

#print axioms adaptive139Third136Proof39

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third136Proof90 : runCachedNode 511 128827 Adaptive139Third136Node90 = false := by
  decide +kernel

#print axioms adaptive139Third136Proof90

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third136Proof137 : runCachedNode 511 128827 Adaptive139Third136Node137 = false := by
  decide +kernel

#print axioms adaptive139Third136Proof137

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third136Proof97 : runCachedNode 511 128827 Adaptive139Third136Node97 = false := by
  decide +kernel

#print axioms adaptive139Third136Proof97

end NineSeparatedSubsetSums
