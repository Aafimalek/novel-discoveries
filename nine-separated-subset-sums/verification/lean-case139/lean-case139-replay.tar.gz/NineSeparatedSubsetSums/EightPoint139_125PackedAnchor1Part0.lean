import NineSeparatedSubsetSums.EightPoint139_125PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint139_125PackedAnchor1Part0 :
    ∀ j : Fin 120, 2317260 ≤ FourPointNumeric.octPackedCharge 139 125 20 packedOct139_125_1
      (2*((j.val : Int)+0)+1) := by decide +kernel

end NineSeparatedSubsetSums
