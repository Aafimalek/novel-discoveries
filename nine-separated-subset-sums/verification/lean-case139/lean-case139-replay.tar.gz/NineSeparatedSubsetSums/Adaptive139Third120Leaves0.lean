import NineSeparatedSubsetSums.Adaptive139Third120State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third120Proof0 : runCachedNode 511 125457 Adaptive139Third120Node0 = false := by
  decide +kernel

#print axioms adaptive139Third120Proof0

end NineSeparatedSubsetSums
