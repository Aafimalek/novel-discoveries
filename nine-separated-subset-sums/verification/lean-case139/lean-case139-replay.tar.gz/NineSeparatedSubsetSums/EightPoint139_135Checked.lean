import NineSeparatedSubsetSums.EightPointPackedGeometry
import NineSeparatedSubsetSums.EightPoint139_135PackedBudget0
import NineSeparatedSubsetSums.EightPoint139_135PackedAnchor0Part0
import NineSeparatedSubsetSums.EightPoint139_135PackedAnchor0Part1
import NineSeparatedSubsetSums.EightPoint139_135PackedAnchor0Part2
import NineSeparatedSubsetSums.EightPoint139_135PackedBudget1
import NineSeparatedSubsetSums.EightPoint139_135PackedAnchor1Part0
import NineSeparatedSubsetSums.EightPoint139_135PackedAnchor1Part1
import NineSeparatedSubsetSums.EightPoint139_135PackedAnchor1Part2

namespace NineSeparatedSubsetSums

private theorem packedOct139_135Anchor0 :
  ∀ j : Fin 500, ((j.val : Int)+139+135)%2=0 →
    2473525 ≤ FourPointNumeric.octPackedCharge 139 135 20 packedOct139_135_0 (j.val : Int) := by
  intro j hj
  let k := (j.val-0)/2
  have hk : k < 250 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+0 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint139_135PackedAnchor0Part0 z
    rwa [he,hrep] at ht
  by_cases h1 : k < 240
  · let z : Fin 120 := ⟨k-120, by omega⟩
    have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
    have ht := eightPoint139_135PackedAnchor0Part1 z
    rwa [he,hrep] at ht
  let z : Fin 10 := ⟨k-240, by omega⟩
  have he : (z.val : Int)+240 = k := by dsimp [z] <;> omega
  have ht := eightPoint139_135PackedAnchor0Part2 z
  rwa [he,hrep] at ht

private theorem packedOct139_135Anchor1 :
  ∀ j : Fin 500, ((j.val : Int)+139+135)%2=1 →
    2472797 ≤ FourPointNumeric.octPackedCharge 139 135 20 packedOct139_135_1 (j.val : Int) := by
  intro j hj
  let k := (j.val-1)/2
  have hk : k < 250 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+1 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint139_135PackedAnchor1Part0 z
    rwa [he,hrep] at ht
  by_cases h1 : k < 240
  · let z : Fin 120 := ⟨k-120, by omega⟩
    have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
    have ht := eightPoint139_135PackedAnchor1Part1 z
    rwa [he,hrep] at ht
  let z : Fin 10 := ⟨k-240, by omega⟩
  have he : (z.val : Int)+240 = k := by dsimp [z] <;> omega
  have ht := eightPoint139_135PackedAnchor1Part2 z
  rwa [he,hrep] at ht

def packedOctCertificate139_135_0 : EightPointCertificate 139 135 0 128672 :=
  eightPointCertificateOfPacked 139 135 0 128672 2473525 20 packedOct139_135_0 397 500
    (by decide +kernel) (by decide) packedOct139_135Anchor0
    (by rw [packedOct139_135_0_budget]; decide)

def packedOctCertificate139_135_1 : EightPointCertificate 139 135 1 128672 :=
  eightPointCertificateOfPacked 139 135 1 128672 2472797 20 packedOct139_135_1 430 500
    (by decide +kernel) (by decide) packedOct139_135Anchor1
    (by rw [packedOct139_135_1_budget]; decide)

theorem max148_second139_third135_eightPoint_moment_bound (tail : List ℕ) (len : tail.length=6)
    (distinct : (natSubsetSums (148::139::135::tail)).Nodup) :
    128672 ≤ ((148::139::135::tail).map (· ^ 2)).sum := by
  apply eightPointNatMomentLower 139 135 128672 tail len distinct
  intro p hp
  by_cases h : p=0
  · subst p
    exact packedOctCertificate139_135_0
  · have he : p=1 := hp.resolve_left h
    subst p
    exact packedOctCertificate139_135_1

#print axioms max148_second139_third135_eightPoint_moment_bound

end NineSeparatedSubsetSums
