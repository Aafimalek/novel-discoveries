import NineSeparatedSubsetSums.Adaptive139Third105State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third105Proof0 : runCachedNode 511 111380 Adaptive139Third105Node0 = false := by
  decide +kernel

#print axioms adaptive139Third105Proof0

end NineSeparatedSubsetSums
