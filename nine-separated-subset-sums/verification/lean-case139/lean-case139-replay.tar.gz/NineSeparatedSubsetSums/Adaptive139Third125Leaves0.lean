import NineSeparatedSubsetSums.Adaptive139Third125State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third125Proof0 : runCachedNode 511 126770 Adaptive139Third125Node0 = false := by
  decide +kernel

#print axioms adaptive139Third125Proof0

end NineSeparatedSubsetSums
