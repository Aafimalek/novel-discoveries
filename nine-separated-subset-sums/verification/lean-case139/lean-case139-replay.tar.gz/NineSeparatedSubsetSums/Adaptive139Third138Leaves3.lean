import NineSeparatedSubsetSums.Adaptive139Third138State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third138Proof151 : runCachedNode 511 129184 Adaptive139Third138Node151 = false := by
  decide +kernel

#print axioms adaptive139Third138Proof151

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third138Proof210 : runCachedNode 511 129184 Adaptive139Third138Node210 = false := by
  decide +kernel

#print axioms adaptive139Third138Proof210

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third138Proof4 : runCachedNode 511 129184 Adaptive139Third138Node4 = false := by
  decide +kernel

#print axioms adaptive139Third138Proof4

end NineSeparatedSubsetSums
