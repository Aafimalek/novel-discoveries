import NineSeparatedSubsetSums.EightPoint139_131PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint139_131PackedAnchor0Part0 :
    ∀ j : Fin 120, 2436576 ≤ FourPointNumeric.octPackedCharge 139 131 20 packedOct139_131_0
      (2*((j.val : Int)+0)+0) := by decide +kernel

end NineSeparatedSubsetSums
