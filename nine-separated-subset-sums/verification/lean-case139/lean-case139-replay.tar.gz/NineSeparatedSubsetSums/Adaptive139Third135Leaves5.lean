import NineSeparatedSubsetSums.Adaptive139Third135State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third135Proof39 : runCachedNode 511 128672 Adaptive139Third135Node39 = false := by
  decide +kernel

#print axioms adaptive139Third135Proof39

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third135Proof15 : runCachedNode 511 128672 Adaptive139Third135Node15 = false := by
  decide +kernel

#print axioms adaptive139Third135Proof15

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third135Proof114 : runCachedNode 511 128672 Adaptive139Third135Node114 = false := by
  decide +kernel

#print axioms adaptive139Third135Proof114

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third135Proof13 : runCachedNode 511 128672 Adaptive139Third135Node13 = false := by
  decide +kernel

#print axioms adaptive139Third135Proof13

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third135Proof42 : runCachedNode 511 128672 Adaptive139Third135Node42 = false := by
  decide +kernel

#print axioms adaptive139Third135Proof42

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third135Proof60 : runCachedNode 511 128672 Adaptive139Third135Node60 = false := by
  decide +kernel

#print axioms adaptive139Third135Proof60

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third135Proof55 : runCachedNode 511 128672 Adaptive139Third135Node55 = false := by
  decide +kernel

#print axioms adaptive139Third135Proof55

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third135Proof118 : runCachedNode 511 128672 Adaptive139Third135Node118 = false := by
  decide +kernel

#print axioms adaptive139Third135Proof118

end NineSeparatedSubsetSums
