import NineSeparatedSubsetSums.Adaptive139Third137State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third137Proof14 : runCachedNode 511 129004 Adaptive139Third137Node14 = false := by
  decide +kernel

#print axioms adaptive139Third137Proof14

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third137Proof150 : runCachedNode 511 129004 Adaptive139Third137Node150 = false := by
  decide +kernel

#print axioms adaptive139Third137Proof150

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third137Proof154 : runCachedNode 511 129004 Adaptive139Third137Node154 = false := by
  decide +kernel

#print axioms adaptive139Third137Proof154

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third137Proof66 : runCachedNode 511 129004 Adaptive139Third137Node66 = false := by
  decide +kernel

#print axioms adaptive139Third137Proof66

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third137Proof118 : runCachedNode 511 129004 Adaptive139Third137Node118 = false := by
  decide +kernel

#print axioms adaptive139Third137Proof118

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third137Proof122 : runCachedNode 511 129004 Adaptive139Third137Node122 = false := by
  decide +kernel

#print axioms adaptive139Third137Proof122

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third137Proof121 : runCachedNode 511 129004 Adaptive139Third137Node121 = false := by
  decide +kernel

#print axioms adaptive139Third137Proof121

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third137Proof157 : runCachedNode 511 129004 Adaptive139Third137Node157 = false := by
  decide +kernel

#print axioms adaptive139Third137Proof157

end NineSeparatedSubsetSums
