import NineSeparatedSubsetSums.EightPoint139_129PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint139_129PackedAnchor0Part2 :
    ∀ j : Fin 5, 2383051 ≤ FourPointNumeric.octPackedCharge 139 129 20 packedOct139_129_0
      (2*((j.val : Int)+240)+0) := by decide +kernel

end NineSeparatedSubsetSums
