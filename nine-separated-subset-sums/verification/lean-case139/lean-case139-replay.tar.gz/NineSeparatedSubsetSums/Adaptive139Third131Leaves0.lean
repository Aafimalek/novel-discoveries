import NineSeparatedSubsetSums.Adaptive139Third131State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third131Proof18 : runCachedNode 511 128014 Adaptive139Third131Node18 = false := by
  decide +kernel

#print axioms adaptive139Third131Proof18

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third131Proof17 : runCachedNode 511 128014 Adaptive139Third131Node17 = false := by
  decide +kernel

#print axioms adaptive139Third131Proof17

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third131Proof15 : runCachedNode 511 128014 Adaptive139Third131Node15 = false := by
  decide +kernel

#print axioms adaptive139Third131Proof15

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third131Proof3 : runCachedNode 511 128014 Adaptive139Third131Node3 = false := by
  decide +kernel

#print axioms adaptive139Third131Proof3

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third131Proof21 : runCachedNode 511 128014 Adaptive139Third131Node21 = false := by
  decide +kernel

#print axioms adaptive139Third131Proof21

end NineSeparatedSubsetSums
