import NineSeparatedSubsetSums.EightPoint139_129PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint139_129PackedAnchor1Part2 :
    ∀ j : Fin 5, 2383086 ≤ FourPointNumeric.octPackedCharge 139 129 20 packedOct139_129_1
      (2*((j.val : Int)+240)+1) := by decide +kernel

end NineSeparatedSubsetSums
