import NineSeparatedSubsetSums.Adaptive139Third115Joins0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint139Checked

namespace NineSeparatedSubsetSums


theorem adaptive139Third115 : NoDescendingTailAfterThird 139 115 :=
  noDescendingThirdTail_of_cached 139 115 111380 (fun t ht nd => max148_second139_fourPoint_moment_bound (115::t) (by simp [ht]) nd) adaptive139Third115Proof0

#print axioms adaptive139Third115

end NineSeparatedSubsetSums
