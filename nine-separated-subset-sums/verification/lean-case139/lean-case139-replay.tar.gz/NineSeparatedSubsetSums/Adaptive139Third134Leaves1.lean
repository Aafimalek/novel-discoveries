import NineSeparatedSubsetSums.Adaptive139Third134State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third134Proof19 : runCachedNode 511 128469 Adaptive139Third134Node19 = false := by
  decide +kernel

#print axioms adaptive139Third134Proof19

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third134Proof67 : runCachedNode 511 128469 Adaptive139Third134Node67 = false := by
  decide +kernel

#print axioms adaptive139Third134Proof67

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third134Proof84 : runCachedNode 511 128469 Adaptive139Third134Node84 = false := by
  decide +kernel

#print axioms adaptive139Third134Proof84

end NineSeparatedSubsetSums
