import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive139Third109Node0 : CachedSearchNode :=
  ⟨4, 108, computeCenteredMask [148,139,109], 396, 53106⟩

end NineSeparatedSubsetSums
