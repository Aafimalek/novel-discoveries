import NineSeparatedSubsetSums.EightPoint139_117PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint139_117PackedAnchor0Part0 :
    ∀ j : Fin 120, 2329471 ≤ FourPointNumeric.octPackedCharge 139 117 20 packedOct139_117_0
      (2*((j.val : Int)+0)+0) := by decide +kernel

end NineSeparatedSubsetSums
