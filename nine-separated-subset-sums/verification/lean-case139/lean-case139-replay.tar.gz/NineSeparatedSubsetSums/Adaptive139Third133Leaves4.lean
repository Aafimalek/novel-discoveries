import NineSeparatedSubsetSums.Adaptive139Third133State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third133Proof13 : runCachedNode 511 128283 Adaptive139Third133Node13 = false := by
  decide +kernel

#print axioms adaptive139Third133Proof13

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third133Proof12 : runCachedNode 511 128283 Adaptive139Third133Node12 = false := by
  decide +kernel

#print axioms adaptive139Third133Proof12

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third133Proof65 : runCachedNode 511 128283 Adaptive139Third133Node65 = false := by
  decide +kernel

#print axioms adaptive139Third133Proof65

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third133Proof63 : runCachedNode 511 128283 Adaptive139Third133Node63 = false := by
  decide +kernel

#print axioms adaptive139Third133Proof63

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third133Proof11 : runCachedNode 511 128283 Adaptive139Third133Node11 = false := by
  decide +kernel

#print axioms adaptive139Third133Proof11

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third133Proof62 : runCachedNode 511 128283 Adaptive139Third133Node62 = false := by
  decide +kernel

#print axioms adaptive139Third133Proof62

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third133Proof10 : runCachedNode 511 128283 Adaptive139Third133Node10 = false := by
  decide +kernel

#print axioms adaptive139Third133Proof10

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third133Proof38 : runCachedNode 511 128283 Adaptive139Third133Node38 = false := by
  decide +kernel

#print axioms adaptive139Third133Proof38

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third133Proof8 : runCachedNode 511 128283 Adaptive139Third133Node8 = false := by
  decide +kernel

#print axioms adaptive139Third133Proof8

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third133Proof9 : runCachedNode 511 128283 Adaptive139Third133Node9 = false := by
  decide +kernel

#print axioms adaptive139Third133Proof9

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third133Proof37 : runCachedNode 511 128283 Adaptive139Third133Node37 = false := by
  decide +kernel

#print axioms adaptive139Third133Proof37

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third133Proof3 : runCachedNode 511 128283 Adaptive139Third133Node3 = false := by
  decide +kernel

#print axioms adaptive139Third133Proof3

end NineSeparatedSubsetSums
