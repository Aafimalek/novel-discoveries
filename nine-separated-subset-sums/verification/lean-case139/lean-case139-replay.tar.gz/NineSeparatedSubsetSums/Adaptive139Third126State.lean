import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive139Third126Node0 : CachedSearchNode :=
  ⟨4, 125, computeCenteredMask [148,139,126], 413, 57101⟩

end NineSeparatedSubsetSums
