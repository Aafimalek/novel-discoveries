import NineSeparatedSubsetSums.Adaptive139Third137State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third137Proof126 : runCachedNode 511 129004 Adaptive139Third137Node126 = false := by
  decide +kernel

#print axioms adaptive139Third137Proof126

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third137Proof125 : runCachedNode 511 129004 Adaptive139Third137Node125 = false := by
  decide +kernel

#print axioms adaptive139Third137Proof125

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third137Proof36 : runCachedNode 511 129004 Adaptive139Third137Node36 = false := by
  decide +kernel

#print axioms adaptive139Third137Proof36

end NineSeparatedSubsetSums
