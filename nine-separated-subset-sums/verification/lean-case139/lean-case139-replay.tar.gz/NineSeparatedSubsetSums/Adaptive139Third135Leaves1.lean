import NineSeparatedSubsetSums.Adaptive139Third135State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third135Proof90 : runCachedNode 511 128672 Adaptive139Third135Node90 = false := by
  decide +kernel

#print axioms adaptive139Third135Proof90

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third135Proof19 : runCachedNode 511 128672 Adaptive139Third135Node19 = false := by
  decide +kernel

#print axioms adaptive139Third135Proof19

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third135Proof16 : runCachedNode 511 128672 Adaptive139Third135Node16 = false := by
  decide +kernel

#print axioms adaptive139Third135Proof16

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third135Proof70 : runCachedNode 511 128672 Adaptive139Third135Node70 = false := by
  decide +kernel

#print axioms adaptive139Third135Proof70

end NineSeparatedSubsetSums
