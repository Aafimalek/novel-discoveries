import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive139Third122Node0 : CachedSearchNode :=
  ⟨4, 121, computeCenteredMask [148,139,122], 409, 56109⟩

end NineSeparatedSubsetSums
