import NineSeparatedSubsetSums.Adaptive139Third131State
import NineSeparatedSubsetSums.Adaptive139Third131Leaves2
import NineSeparatedSubsetSums.Adaptive139Third131Leaves0
import NineSeparatedSubsetSums.Adaptive139Third131Leaves3
import NineSeparatedSubsetSums.Adaptive139Third131Leaves1

namespace NineSeparatedSubsetSums

theorem adaptive139Third131Proof19 : runCachedNode 511 128014 Adaptive139Third131Node19 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 128014 Adaptive139Third131Node19 = [105, 106, 107, 108, 109, 110, 111, 112, 114, 115, 116, 117, 118, 119, 120, 123, 124, 125, 126, 127, 128, 129] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive139Third131Proof20
  · exact adaptive139Third131Proof21
  · exact adaptive139Third131Proof22
  · exact adaptive139Third131Proof23
  · exact adaptive139Third131Proof24
  · exact adaptive139Third131Proof25
  · exact adaptive139Third131Proof26
  · exact adaptive139Third131Proof27
  · exact adaptive139Third131Proof28
  · exact adaptive139Third131Proof29
  · exact adaptive139Third131Proof30
  · exact adaptive139Third131Proof31
  · exact adaptive139Third131Proof32
  · exact adaptive139Third131Proof33
  · exact adaptive139Third131Proof34
  · exact adaptive139Third131Proof35
  · exact adaptive139Third131Proof36
  · exact adaptive139Third131Proof37
  · exact adaptive139Third131Proof38
  · exact adaptive139Third131Proof39
  · exact adaptive139Third131Proof40
  · exact adaptive139Third131Proof41

#print axioms adaptive139Third131Proof19

theorem adaptive139Third131Proof0 : runCachedNode 511 128014 Adaptive139Third131Node0 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 128014 Adaptive139Third131Node0 = [111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 123, 124, 125, 126, 127, 128, 129, 130] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive139Third131Proof1
  · exact adaptive139Third131Proof2
  · exact adaptive139Third131Proof3
  · exact adaptive139Third131Proof4
  · exact adaptive139Third131Proof5
  · exact adaptive139Third131Proof6
  · exact adaptive139Third131Proof7
  · exact adaptive139Third131Proof8
  · exact adaptive139Third131Proof9
  · exact adaptive139Third131Proof10
  · exact adaptive139Third131Proof11
  · exact adaptive139Third131Proof12
  · exact adaptive139Third131Proof13
  · exact adaptive139Third131Proof14
  · exact adaptive139Third131Proof15
  · exact adaptive139Third131Proof16
  · exact adaptive139Third131Proof17
  · exact adaptive139Third131Proof18
  · exact adaptive139Third131Proof19

#print axioms adaptive139Third131Proof0

end NineSeparatedSubsetSums
