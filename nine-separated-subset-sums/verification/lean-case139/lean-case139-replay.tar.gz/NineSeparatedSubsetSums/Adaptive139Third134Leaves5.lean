import NineSeparatedSubsetSums.Adaptive139Third134State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third134Proof92 : runCachedNode 511 128469 Adaptive139Third134Node92 = false := by
  decide +kernel

#print axioms adaptive139Third134Proof92

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third134Proof66 : runCachedNode 511 128469 Adaptive139Third134Node66 = false := by
  decide +kernel

#print axioms adaptive139Third134Proof66

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third134Proof41 : runCachedNode 511 128469 Adaptive139Third134Node41 = false := by
  decide +kernel

#print axioms adaptive139Third134Proof41

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third134Proof13 : runCachedNode 511 128469 Adaptive139Third134Node13 = false := by
  decide +kernel

#print axioms adaptive139Third134Proof13

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third134Proof40 : runCachedNode 511 128469 Adaptive139Third134Node40 = false := by
  decide +kernel

#print axioms adaptive139Third134Proof40

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third134Proof65 : runCachedNode 511 128469 Adaptive139Third134Node65 = false := by
  decide +kernel

#print axioms adaptive139Third134Proof65

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third134Proof11 : runCachedNode 511 128469 Adaptive139Third134Node11 = false := by
  decide +kernel

#print axioms adaptive139Third134Proof11

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third134Proof37 : runCachedNode 511 128469 Adaptive139Third134Node37 = false := by
  decide +kernel

#print axioms adaptive139Third134Proof37

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third134Proof8 : runCachedNode 511 128469 Adaptive139Third134Node8 = false := by
  decide +kernel

#print axioms adaptive139Third134Proof8

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third134Proof21 : runCachedNode 511 128469 Adaptive139Third134Node21 = false := by
  decide +kernel

#print axioms adaptive139Third134Proof21

end NineSeparatedSubsetSums
