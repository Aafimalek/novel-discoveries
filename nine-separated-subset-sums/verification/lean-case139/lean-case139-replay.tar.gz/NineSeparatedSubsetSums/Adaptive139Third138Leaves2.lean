import NineSeparatedSubsetSums.Adaptive139Third138State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third138Proof182 : runCachedNode 511 129184 Adaptive139Third138Node182 = false := by
  decide +kernel

#print axioms adaptive139Third138Proof182

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third138Proof43 : runCachedNode 511 129184 Adaptive139Third138Node43 = false := by
  decide +kernel

#print axioms adaptive139Third138Proof43

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third138Proof21 : runCachedNode 511 129184 Adaptive139Third138Node21 = false := by
  decide +kernel

#print axioms adaptive139Third138Proof21

end NineSeparatedSubsetSums
