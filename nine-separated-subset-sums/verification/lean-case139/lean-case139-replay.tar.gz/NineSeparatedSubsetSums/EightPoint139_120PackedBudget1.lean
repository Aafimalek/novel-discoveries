import NineSeparatedSubsetSums.EightPoint139_120PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct139_120_1_budget :
    FourPointNumeric.packedBudget 20 packedOct139_120_1 272 = 85305412 := by decide +kernel

#print axioms packedOct139_120_1_budget

end NineSeparatedSubsetSums
