import NineSeparatedSubsetSums.EightPoint139_134PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint139_134PackedAnchor0Part0 :
    ∀ j : Fin 120, 2445665 ≤ FourPointNumeric.octPackedCharge 139 134 20 packedOct139_134_0
      (2*((j.val : Int)+0)+1) := by decide +kernel

end NineSeparatedSubsetSums
