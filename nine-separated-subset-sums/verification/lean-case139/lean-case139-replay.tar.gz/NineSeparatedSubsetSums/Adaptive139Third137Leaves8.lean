import NineSeparatedSubsetSums.Adaptive139Third137State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third137Proof40 : runCachedNode 511 129004 Adaptive139Third137Node40 = false := by
  decide +kernel

#print axioms adaptive139Third137Proof40

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third137Proof16 : runCachedNode 511 129004 Adaptive139Third137Node16 = false := by
  decide +kernel

#print axioms adaptive139Third137Proof16

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third137Proof97 : runCachedNode 511 129004 Adaptive139Third137Node97 = false := by
  decide +kernel

#print axioms adaptive139Third137Proof97

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third137Proof152 : runCachedNode 511 129004 Adaptive139Third137Node152 = false := by
  decide +kernel

#print axioms adaptive139Third137Proof152

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third137Proof15 : runCachedNode 511 129004 Adaptive139Third137Node15 = false := by
  decide +kernel

#print axioms adaptive139Third137Proof15

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third137Proof6 : runCachedNode 511 129004 Adaptive139Third137Node6 = false := by
  decide +kernel

#print axioms adaptive139Third137Proof6

end NineSeparatedSubsetSums
