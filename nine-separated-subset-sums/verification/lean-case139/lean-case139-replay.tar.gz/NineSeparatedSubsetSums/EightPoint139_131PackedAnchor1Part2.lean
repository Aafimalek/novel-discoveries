import NineSeparatedSubsetSums.EightPoint139_131PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint139_131PackedAnchor1Part2 :
    ∀ j : Fin 8, 2436236 ≤ FourPointNumeric.octPackedCharge 139 131 20 packedOct139_131_1
      (2*((j.val : Int)+240)+1) := by decide +kernel

end NineSeparatedSubsetSums
