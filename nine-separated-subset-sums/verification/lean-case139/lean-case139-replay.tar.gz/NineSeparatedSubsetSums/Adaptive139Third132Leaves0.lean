import NineSeparatedSubsetSums.Adaptive139Third132State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third132Proof42 : runCachedNode 511 128175 Adaptive139Third132Node42 = false := by
  decide +kernel

#print axioms adaptive139Third132Proof42

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third132Proof39 : runCachedNode 511 128175 Adaptive139Third132Node39 = false := by
  decide +kernel

#print axioms adaptive139Third132Proof39

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third132Proof22 : runCachedNode 511 128175 Adaptive139Third132Node22 = false := by
  decide +kernel

#print axioms adaptive139Third132Proof22

end NineSeparatedSubsetSums
