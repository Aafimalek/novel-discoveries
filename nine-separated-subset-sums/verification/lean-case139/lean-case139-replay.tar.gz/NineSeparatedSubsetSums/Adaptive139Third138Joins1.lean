import NineSeparatedSubsetSums.Adaptive139Third138State
import NineSeparatedSubsetSums.Adaptive139Third138Leaves1
import NineSeparatedSubsetSums.Adaptive139Third138Leaves19
import NineSeparatedSubsetSums.Adaptive139Third138Leaves14
import NineSeparatedSubsetSums.Adaptive139Third138Leaves3
import NineSeparatedSubsetSums.Adaptive139Third138Leaves17
import NineSeparatedSubsetSums.Adaptive139Third138Leaves16
import NineSeparatedSubsetSums.Adaptive139Third138Leaves15
import NineSeparatedSubsetSums.Adaptive139Third138Leaves12
import NineSeparatedSubsetSums.Adaptive139Third138Leaves11
import NineSeparatedSubsetSums.Adaptive139Third138Leaves10
import NineSeparatedSubsetSums.Adaptive139Third138Joins0
import NineSeparatedSubsetSums.Adaptive139Third138Leaves5

namespace NineSeparatedSubsetSums

theorem adaptive139Third138Proof0 : runCachedNode 511 129184 Adaptive139Third138Node0 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 129184 Adaptive139Third138Node0 = [110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 130, 131, 132, 133, 134, 135, 136, 137] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive139Third138Proof1
  · exact adaptive139Third138Proof2
  · exact adaptive139Third138Proof3
  · exact adaptive139Third138Proof4
  · exact adaptive139Third138Proof5
  · exact adaptive139Third138Proof6
  · exact adaptive139Third138Proof7
  · exact adaptive139Third138Proof8
  · exact adaptive139Third138Proof9
  · exact adaptive139Third138Proof10
  · exact adaptive139Third138Proof11
  · exact adaptive139Third138Proof12
  · exact adaptive139Third138Proof13
  · exact adaptive139Third138Proof14
  · exact adaptive139Third138Proof15
  · exact adaptive139Third138Proof16
  · exact adaptive139Third138Proof17
  · exact adaptive139Third138Proof18
  · exact adaptive139Third138Proof19
  · exact adaptive139Third138Proof20
  · exact adaptive139Third138Proof44
  · exact adaptive139Third138Proof45
  · exact adaptive139Third138Proof70
  · exact adaptive139Third138Proof96
  · exact adaptive139Third138Proof124
  · exact adaptive139Third138Proof153
  · exact adaptive139Third138Proof183

#print axioms adaptive139Third138Proof0

end NineSeparatedSubsetSums
