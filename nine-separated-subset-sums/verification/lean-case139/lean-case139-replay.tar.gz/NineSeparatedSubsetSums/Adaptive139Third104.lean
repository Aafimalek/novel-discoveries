import NineSeparatedSubsetSums.Adaptive139Third104Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint139Checked

namespace NineSeparatedSubsetSums


theorem adaptive139Third104 : NoDescendingTailAfterThird 139 104 :=
  noDescendingThirdTail_of_cached 139 104 111380 (fun t ht nd => max148_second139_fourPoint_moment_bound (104::t) (by simp [ht]) nd) adaptive139Third104Proof0

#print axioms adaptive139Third104

end NineSeparatedSubsetSums
