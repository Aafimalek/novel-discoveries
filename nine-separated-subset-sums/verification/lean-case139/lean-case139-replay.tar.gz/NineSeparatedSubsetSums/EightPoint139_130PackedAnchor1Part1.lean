import NineSeparatedSubsetSums.EightPoint139_130PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint139_130PackedAnchor1Part1 :
    ∀ j : Fin 120, 2402066 ≤ FourPointNumeric.octPackedCharge 139 130 20 packedOct139_130_1
      (2*((j.val : Int)+120)+0) := by decide +kernel

end NineSeparatedSubsetSums
