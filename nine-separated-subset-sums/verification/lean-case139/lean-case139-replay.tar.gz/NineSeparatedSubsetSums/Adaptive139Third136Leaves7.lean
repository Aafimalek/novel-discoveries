import NineSeparatedSubsetSums.Adaptive139Third136State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third136Proof16 : runCachedNode 511 128827 Adaptive139Third136Node16 = false := by
  decide +kernel

#print axioms adaptive139Third136Proof16

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third136Proof147 : runCachedNode 511 128827 Adaptive139Third136Node147 = false := by
  decide +kernel

#print axioms adaptive139Third136Proof147

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third136Proof67 : runCachedNode 511 128827 Adaptive139Third136Node67 = false := by
  decide +kernel

#print axioms adaptive139Third136Proof67

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third136Proof14 : runCachedNode 511 128827 Adaptive139Third136Node14 = false := by
  decide +kernel

#print axioms adaptive139Third136Proof14

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third136Proof66 : runCachedNode 511 128827 Adaptive139Third136Node66 = false := by
  decide +kernel

#print axioms adaptive139Third136Proof66

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third136Proof143 : runCachedNode 511 128827 Adaptive139Third136Node143 = false := by
  decide +kernel

#print axioms adaptive139Third136Proof143

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third136Proof2 : runCachedNode 511 128827 Adaptive139Third136Node2 = false := by
  decide +kernel

#print axioms adaptive139Third136Proof2

end NineSeparatedSubsetSums
