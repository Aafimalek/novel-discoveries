import NineSeparatedSubsetSums.EightPoint139_136PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint139_136PackedAnchor0Part0 :
    ∀ j : Fin 120, 2463162 ≤ FourPointNumeric.octPackedCharge 139 136 20 packedOct139_136_0
      (2*((j.val : Int)+0)+1) := by decide +kernel

end NineSeparatedSubsetSums
