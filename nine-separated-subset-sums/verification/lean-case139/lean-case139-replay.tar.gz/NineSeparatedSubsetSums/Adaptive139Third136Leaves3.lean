import NineSeparatedSubsetSums.Adaptive139Third136State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third136Proof148 : runCachedNode 511 128827 Adaptive139Third136Node148 = false := by
  decide +kernel

#print axioms adaptive139Third136Proof148

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third136Proof19 : runCachedNode 511 128827 Adaptive139Third136Node19 = false := by
  decide +kernel

#print axioms adaptive139Third136Proof19

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third136Proof24 : runCachedNode 511 128827 Adaptive139Third136Node24 = false := by
  decide +kernel

#print axioms adaptive139Third136Proof24

end NineSeparatedSubsetSums
