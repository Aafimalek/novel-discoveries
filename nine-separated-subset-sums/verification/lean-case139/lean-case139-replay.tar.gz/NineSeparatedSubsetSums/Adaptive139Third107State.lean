import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive139Third107Node0 : CachedSearchNode :=
  ⟨4, 106, computeCenteredMask [148,139,107], 394, 52674⟩

end NineSeparatedSubsetSums
