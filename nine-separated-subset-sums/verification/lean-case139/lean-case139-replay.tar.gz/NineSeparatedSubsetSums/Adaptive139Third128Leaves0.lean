import NineSeparatedSubsetSums.Adaptive139Third128State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third128Proof16 : runCachedNode 511 127306 Adaptive139Third128Node16 = false := by
  decide +kernel

#print axioms adaptive139Third128Proof16

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third128Proof15 : runCachedNode 511 127306 Adaptive139Third128Node15 = false := by
  decide +kernel

#print axioms adaptive139Third128Proof15

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third128Proof14 : runCachedNode 511 127306 Adaptive139Third128Node14 = false := by
  decide +kernel

#print axioms adaptive139Third128Proof14

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third128Proof13 : runCachedNode 511 127306 Adaptive139Third128Node13 = false := by
  decide +kernel

#print axioms adaptive139Third128Proof13

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third128Proof12 : runCachedNode 511 127306 Adaptive139Third128Node12 = false := by
  decide +kernel

#print axioms adaptive139Third128Proof12

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third128Proof8 : runCachedNode 511 127306 Adaptive139Third128Node8 = false := by
  decide +kernel

#print axioms adaptive139Third128Proof8

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third128Proof1 : runCachedNode 511 127306 Adaptive139Third128Node1 = false := by
  decide +kernel

#print axioms adaptive139Third128Proof1

end NineSeparatedSubsetSums
