import NineSeparatedSubsetSums.Adaptive139Third134State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third134Proof94 : runCachedNode 511 128469 Adaptive139Third134Node94 = false := by
  decide +kernel

#print axioms adaptive139Third134Proof94

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third134Proof18 : runCachedNode 511 128469 Adaptive139Third134Node18 = false := by
  decide +kernel

#print axioms adaptive139Third134Proof18

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third134Proof93 : runCachedNode 511 128469 Adaptive139Third134Node93 = false := by
  decide +kernel

#print axioms adaptive139Third134Proof93

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third134Proof7 : runCachedNode 511 128469 Adaptive139Third134Node7 = false := by
  decide +kernel

#print axioms adaptive139Third134Proof7

end NineSeparatedSubsetSums
