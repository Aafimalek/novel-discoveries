import NineSeparatedSubsetSums.EightPoint139_123PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint139_123PackedAnchor0Part1 :
    ∀ j : Fin 120, 2291816 ≤ FourPointNumeric.octPackedCharge 139 123 20 packedOct139_123_0
      (2*((j.val : Int)+120)+0) := by decide +kernel

end NineSeparatedSubsetSums
