import NineSeparatedSubsetSums.Adaptive139Third118State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third118Proof0 : runCachedNode 511 125056 Adaptive139Third118Node0 = false := by
  decide +kernel

#print axioms adaptive139Third118Proof0

end NineSeparatedSubsetSums
