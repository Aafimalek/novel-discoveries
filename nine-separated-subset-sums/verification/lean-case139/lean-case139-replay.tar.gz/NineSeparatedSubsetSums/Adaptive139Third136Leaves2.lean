import NineSeparatedSubsetSums.Adaptive139Third136State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third136Proof149 : runCachedNode 511 128827 Adaptive139Third136Node149 = false := by
  decide +kernel

#print axioms adaptive139Third136Proof149

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third136Proof94 : runCachedNode 511 128827 Adaptive139Third136Node94 = false := by
  decide +kernel

#print axioms adaptive139Third136Proof94

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third136Proof139 : runCachedNode 511 128827 Adaptive139Third136Node139 = false := by
  decide +kernel

#print axioms adaptive139Third136Proof139

end NineSeparatedSubsetSums
