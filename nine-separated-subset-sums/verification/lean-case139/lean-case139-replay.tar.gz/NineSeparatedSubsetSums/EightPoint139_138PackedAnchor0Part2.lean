import NineSeparatedSubsetSums.EightPoint139_138PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint139_138PackedAnchor0Part2 :
    ∀ j : Fin 10, 2485127 ≤ FourPointNumeric.octPackedCharge 139 138 20 packedOct139_138_0
      (2*((j.val : Int)+240)+1) := by decide +kernel

end NineSeparatedSubsetSums
