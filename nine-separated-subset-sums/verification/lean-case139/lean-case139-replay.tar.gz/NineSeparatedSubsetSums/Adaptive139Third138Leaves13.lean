import NineSeparatedSubsetSums.Adaptive139Third138State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third138Proof40 : runCachedNode 511 129184 Adaptive139Third138Node40 = false := by
  decide +kernel

#print axioms adaptive139Third138Proof40

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third138Proof179 : runCachedNode 511 129184 Adaptive139Third138Node179 = false := by
  decide +kernel

#print axioms adaptive139Third138Proof179

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third138Proof66 : runCachedNode 511 129184 Adaptive139Third138Node66 = false := by
  decide +kernel

#print axioms adaptive139Third138Proof66

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third138Proof118 : runCachedNode 511 129184 Adaptive139Third138Node118 = false := by
  decide +kernel

#print axioms adaptive139Third138Proof118

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third138Proof148 : runCachedNode 511 129184 Adaptive139Third138Node148 = false := by
  decide +kernel

#print axioms adaptive139Third138Proof148

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third138Proof205 : runCachedNode 511 129184 Adaptive139Third138Node205 = false := by
  decide +kernel

#print axioms adaptive139Third138Proof205

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third138Proof42 : runCachedNode 511 129184 Adaptive139Third138Node42 = false := by
  decide +kernel

#print axioms adaptive139Third138Proof42

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third138Proof176 : runCachedNode 511 129184 Adaptive139Third138Node176 = false := by
  decide +kernel

#print axioms adaptive139Third138Proof176

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third138Proof204 : runCachedNode 511 129184 Adaptive139Third138Node204 = false := by
  decide +kernel

#print axioms adaptive139Third138Proof204

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third138Proof52 : runCachedNode 511 129184 Adaptive139Third138Node52 = false := by
  decide +kernel

#print axioms adaptive139Third138Proof52

end NineSeparatedSubsetSums
