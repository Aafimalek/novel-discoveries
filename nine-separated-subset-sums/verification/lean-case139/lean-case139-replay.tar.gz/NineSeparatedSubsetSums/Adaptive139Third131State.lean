import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive139Third131Node0 : CachedSearchNode :=
  ⟨4, 130, computeCenteredMask [148,139,131], 418, 58386⟩
def Adaptive139Third131Node1 : CachedSearchNode := cachedChild Adaptive139Third131Node0 111
def Adaptive139Third131Node2 : CachedSearchNode := cachedChild Adaptive139Third131Node0 112
def Adaptive139Third131Node3 : CachedSearchNode := cachedChild Adaptive139Third131Node0 113
def Adaptive139Third131Node4 : CachedSearchNode := cachedChild Adaptive139Third131Node0 114
def Adaptive139Third131Node5 : CachedSearchNode := cachedChild Adaptive139Third131Node0 115
def Adaptive139Third131Node6 : CachedSearchNode := cachedChild Adaptive139Third131Node0 116
def Adaptive139Third131Node7 : CachedSearchNode := cachedChild Adaptive139Third131Node0 117
def Adaptive139Third131Node8 : CachedSearchNode := cachedChild Adaptive139Third131Node0 118
def Adaptive139Third131Node9 : CachedSearchNode := cachedChild Adaptive139Third131Node0 119
def Adaptive139Third131Node10 : CachedSearchNode := cachedChild Adaptive139Third131Node0 120
def Adaptive139Third131Node11 : CachedSearchNode := cachedChild Adaptive139Third131Node0 121
def Adaptive139Third131Node12 : CachedSearchNode := cachedChild Adaptive139Third131Node0 123
def Adaptive139Third131Node13 : CachedSearchNode := cachedChild Adaptive139Third131Node0 124
def Adaptive139Third131Node14 : CachedSearchNode := cachedChild Adaptive139Third131Node0 125
def Adaptive139Third131Node15 : CachedSearchNode := cachedChild Adaptive139Third131Node0 126
def Adaptive139Third131Node16 : CachedSearchNode := cachedChild Adaptive139Third131Node0 127
def Adaptive139Third131Node17 : CachedSearchNode := cachedChild Adaptive139Third131Node0 128
def Adaptive139Third131Node18 : CachedSearchNode := cachedChild Adaptive139Third131Node0 129
def Adaptive139Third131Node19 : CachedSearchNode := cachedChild Adaptive139Third131Node0 130
def Adaptive139Third131Node20 : CachedSearchNode := cachedChild Adaptive139Third131Node19 105
def Adaptive139Third131Node21 : CachedSearchNode := cachedChild Adaptive139Third131Node19 106
def Adaptive139Third131Node22 : CachedSearchNode := cachedChild Adaptive139Third131Node19 107
def Adaptive139Third131Node23 : CachedSearchNode := cachedChild Adaptive139Third131Node19 108
def Adaptive139Third131Node24 : CachedSearchNode := cachedChild Adaptive139Third131Node19 109
def Adaptive139Third131Node25 : CachedSearchNode := cachedChild Adaptive139Third131Node19 110
def Adaptive139Third131Node26 : CachedSearchNode := cachedChild Adaptive139Third131Node19 111
def Adaptive139Third131Node27 : CachedSearchNode := cachedChild Adaptive139Third131Node19 112
def Adaptive139Third131Node28 : CachedSearchNode := cachedChild Adaptive139Third131Node19 114
def Adaptive139Third131Node29 : CachedSearchNode := cachedChild Adaptive139Third131Node19 115
def Adaptive139Third131Node30 : CachedSearchNode := cachedChild Adaptive139Third131Node19 116
def Adaptive139Third131Node31 : CachedSearchNode := cachedChild Adaptive139Third131Node19 117
def Adaptive139Third131Node32 : CachedSearchNode := cachedChild Adaptive139Third131Node19 118
def Adaptive139Third131Node33 : CachedSearchNode := cachedChild Adaptive139Third131Node19 119
def Adaptive139Third131Node34 : CachedSearchNode := cachedChild Adaptive139Third131Node19 120
def Adaptive139Third131Node35 : CachedSearchNode := cachedChild Adaptive139Third131Node19 123
def Adaptive139Third131Node36 : CachedSearchNode := cachedChild Adaptive139Third131Node19 124
def Adaptive139Third131Node37 : CachedSearchNode := cachedChild Adaptive139Third131Node19 125
def Adaptive139Third131Node38 : CachedSearchNode := cachedChild Adaptive139Third131Node19 126
def Adaptive139Third131Node39 : CachedSearchNode := cachedChild Adaptive139Third131Node19 127
def Adaptive139Third131Node40 : CachedSearchNode := cachedChild Adaptive139Third131Node19 128
def Adaptive139Third131Node41 : CachedSearchNode := cachedChild Adaptive139Third131Node19 129

end NineSeparatedSubsetSums
