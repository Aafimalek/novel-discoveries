import NineSeparatedSubsetSums.EightPoint139_123PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint139_123PackedAnchor1Part1 :
    ∀ j : Fin 120, 2290642 ≤ FourPointNumeric.octPackedCharge 139 123 20 packedOct139_123_1
      (2*((j.val : Int)+120)+1) := by decide +kernel

end NineSeparatedSubsetSums
