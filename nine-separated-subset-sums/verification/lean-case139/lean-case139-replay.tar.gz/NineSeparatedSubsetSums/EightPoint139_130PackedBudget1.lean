import NineSeparatedSubsetSums.EightPoint139_130PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct139_130_1_budget :
    FourPointNumeric.packedBudget 20 packedOct139_130_1 266 = 88312092 := by decide +kernel

#print axioms packedOct139_130_1_budget

end NineSeparatedSubsetSums
