import NineSeparatedSubsetSums.Adaptive139Third138State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third138Proof208 : runCachedNode 511 129184 Adaptive139Third138Node208 = false := by
  decide +kernel

#print axioms adaptive139Third138Proof208

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third138Proof209 : runCachedNode 511 129184 Adaptive139Third138Node209 = false := by
  decide +kernel

#print axioms adaptive139Third138Proof209

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third138Proof239 : runCachedNode 511 129184 Adaptive139Third138Node239 = false := by
  decide +kernel

#print axioms adaptive139Third138Proof239

end NineSeparatedSubsetSums
