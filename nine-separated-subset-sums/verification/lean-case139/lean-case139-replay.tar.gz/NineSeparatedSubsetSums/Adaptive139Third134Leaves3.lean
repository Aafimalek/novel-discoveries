import NineSeparatedSubsetSums.Adaptive139Third134State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third134Proof42 : runCachedNode 511 128469 Adaptive139Third134Node42 = false := by
  decide +kernel

#print axioms adaptive139Third134Proof42

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third134Proof91 : runCachedNode 511 128469 Adaptive139Third134Node91 = false := by
  decide +kernel

#print axioms adaptive139Third134Proof91

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third134Proof17 : runCachedNode 511 128469 Adaptive139Third134Node17 = false := by
  decide +kernel

#print axioms adaptive139Third134Proof17

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third134Proof90 : runCachedNode 511 128469 Adaptive139Third134Node90 = false := by
  decide +kernel

#print axioms adaptive139Third134Proof90

end NineSeparatedSubsetSums
