import NineSeparatedSubsetSums.EightPoint139_124PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct139_124_0_budget :
    FourPointNumeric.packedBudget 20 packedOct139_124_0 489 = 82753866 := by decide +kernel

#print axioms packedOct139_124_0_budget

end NineSeparatedSubsetSums
