import NineSeparatedSubsetSums.EightPoint139_124PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct139_124_1_budget :
    FourPointNumeric.packedBudget 20 packedOct139_124_1 488 = 82742664 := by decide +kernel

#print axioms packedOct139_124_1_budget

end NineSeparatedSubsetSums
