import NineSeparatedSubsetSums.Adaptive139Third133State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third133Proof17 : runCachedNode 511 128283 Adaptive139Third133Node17 = false := by
  decide +kernel

#print axioms adaptive139Third133Proof17

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third133Proof15 : runCachedNode 511 128283 Adaptive139Third133Node15 = false := by
  decide +kernel

#print axioms adaptive139Third133Proof15

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third133Proof14 : runCachedNode 511 128283 Adaptive139Third133Node14 = false := by
  decide +kernel

#print axioms adaptive139Third133Proof14

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third133Proof41 : runCachedNode 511 128283 Adaptive139Third133Node41 = false := by
  decide +kernel

#print axioms adaptive139Third133Proof41

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third133Proof64 : runCachedNode 511 128283 Adaptive139Third133Node64 = false := by
  decide +kernel

#print axioms adaptive139Third133Proof64

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third133Proof45 : runCachedNode 511 128283 Adaptive139Third133Node45 = false := by
  decide +kernel

#print axioms adaptive139Third133Proof45

end NineSeparatedSubsetSums
