import NineSeparatedSubsetSums.Adaptive139Third123State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third123Proof0 : runCachedNode 511 125935 Adaptive139Third123Node0 = false := by
  decide +kernel

#print axioms adaptive139Third123Proof0

end NineSeparatedSubsetSums
