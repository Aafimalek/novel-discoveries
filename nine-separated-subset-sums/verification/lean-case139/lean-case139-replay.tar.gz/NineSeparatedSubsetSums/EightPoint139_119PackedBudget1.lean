import NineSeparatedSubsetSums.EightPoint139_119PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct139_119_1_budget :
    FourPointNumeric.packedBudget 20 packedOct139_119_1 346 = 84435856 := by decide +kernel

#print axioms packedOct139_119_1_budget

end NineSeparatedSubsetSums
