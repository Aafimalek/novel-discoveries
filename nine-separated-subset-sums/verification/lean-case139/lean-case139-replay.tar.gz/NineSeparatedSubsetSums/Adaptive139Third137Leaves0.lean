import NineSeparatedSubsetSums.Adaptive139Third137State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third137Proof43 : runCachedNode 511 129004 Adaptive139Third137Node43 = false := by
  decide +kernel

#print axioms adaptive139Third137Proof43

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third137Proof153 : runCachedNode 511 129004 Adaptive139Third137Node153 = false := by
  decide +kernel

#print axioms adaptive139Third137Proof153

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third137Proof82 : runCachedNode 511 129004 Adaptive139Third137Node82 = false := by
  decide +kernel

#print axioms adaptive139Third137Proof82

end NineSeparatedSubsetSums
