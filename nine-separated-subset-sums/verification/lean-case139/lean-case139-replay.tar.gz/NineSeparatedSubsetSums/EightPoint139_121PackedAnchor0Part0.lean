import NineSeparatedSubsetSums.EightPoint139_121PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint139_121PackedAnchor0Part0 :
    ∀ j : Fin 120, 2343968 ≤ FourPointNumeric.octPackedCharge 139 121 20 packedOct139_121_0
      (2*((j.val : Int)+0)+0) := by decide +kernel

end NineSeparatedSubsetSums
