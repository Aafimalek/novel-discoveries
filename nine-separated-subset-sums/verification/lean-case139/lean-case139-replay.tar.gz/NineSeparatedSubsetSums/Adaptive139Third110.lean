import NineSeparatedSubsetSums.Adaptive139Third110Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint139Checked

namespace NineSeparatedSubsetSums


theorem adaptive139Third110 : NoDescendingTailAfterThird 139 110 :=
  noDescendingThirdTail_of_cached 139 110 111380 (fun t ht nd => max148_second139_fourPoint_moment_bound (110::t) (by simp [ht]) nd) adaptive139Third110Proof0

#print axioms adaptive139Third110

end NineSeparatedSubsetSums
