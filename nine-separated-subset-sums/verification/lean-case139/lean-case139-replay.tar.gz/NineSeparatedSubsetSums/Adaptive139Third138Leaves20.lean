import NineSeparatedSubsetSums.Adaptive139Third138State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third138Proof125 : runCachedNode 511 129184 Adaptive139Third138Node125 = false := by
  decide +kernel

#print axioms adaptive139Third138Proof125

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third138Proof154 : runCachedNode 511 129184 Adaptive139Third138Node154 = false := by
  decide +kernel

#print axioms adaptive139Third138Proof154

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third138Proof155 : runCachedNode 511 129184 Adaptive139Third138Node155 = false := by
  decide +kernel

#print axioms adaptive139Third138Proof155

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third138Proof184 : runCachedNode 511 129184 Adaptive139Third138Node184 = false := by
  decide +kernel

#print axioms adaptive139Third138Proof184

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third138Proof214 : runCachedNode 511 129184 Adaptive139Third138Node214 = false := by
  decide +kernel

#print axioms adaptive139Third138Proof214

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third138Proof215 : runCachedNode 511 129184 Adaptive139Third138Node215 = false := by
  decide +kernel

#print axioms adaptive139Third138Proof215

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third138Proof216 : runCachedNode 511 129184 Adaptive139Third138Node216 = false := by
  decide +kernel

#print axioms adaptive139Third138Proof216

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third138Proof217 : runCachedNode 511 129184 Adaptive139Third138Node217 = false := by
  decide +kernel

#print axioms adaptive139Third138Proof217

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third138Proof218 : runCachedNode 511 129184 Adaptive139Third138Node218 = false := by
  decide +kernel

#print axioms adaptive139Third138Proof218

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third138Proof219 : runCachedNode 511 129184 Adaptive139Third138Node219 = false := by
  decide +kernel

#print axioms adaptive139Third138Proof219

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third138Proof220 : runCachedNode 511 129184 Adaptive139Third138Node220 = false := by
  decide +kernel

#print axioms adaptive139Third138Proof220

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third138Proof221 : runCachedNode 511 129184 Adaptive139Third138Node221 = false := by
  decide +kernel

#print axioms adaptive139Third138Proof221

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third138Proof222 : runCachedNode 511 129184 Adaptive139Third138Node222 = false := by
  decide +kernel

#print axioms adaptive139Third138Proof222

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third138Proof223 : runCachedNode 511 129184 Adaptive139Third138Node223 = false := by
  decide +kernel

#print axioms adaptive139Third138Proof223

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third138Proof224 : runCachedNode 511 129184 Adaptive139Third138Node224 = false := by
  decide +kernel

#print axioms adaptive139Third138Proof224

end NineSeparatedSubsetSums
