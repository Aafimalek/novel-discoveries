import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive139Third110Node0 : CachedSearchNode :=
  ⟨4, 109, computeCenteredMask [148,139,110], 397, 53325⟩

end NineSeparatedSubsetSums
