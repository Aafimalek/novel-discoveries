import NineSeparatedSubsetSums.FourPointPackedGeometry
import NineSeparatedSubsetSums.FourPoint139PackedBudget0
import NineSeparatedSubsetSums.FourPoint139PackedAnchor0Part0
import NineSeparatedSubsetSums.FourPoint139PackedAnchor0Part1
import NineSeparatedSubsetSums.FourPoint139PackedBudget1
import NineSeparatedSubsetSums.FourPoint139PackedAnchor1Part0
import NineSeparatedSubsetSums.FourPoint139PackedAnchor1Part1

namespace NineSeparatedSubsetSums

private theorem packed139Anchor0 :
  ∀ j : Fin 474, ((j.val : Int)+139)%2=0 →
    1063544 ≤ FourPointNumeric.packedCharge 139 20 packedWeight139_0 (j.val : Int) := by
  intro j hj
  let k := (j.val-1)/2
  have hk : k < 237 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+1 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := fourPoint139PackedAnchor0Part0 z
    rwa [he,hrep] at ht
  let z : Fin 117 := ⟨k-120, by omega⟩
  have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
  have ht := fourPoint139PackedAnchor0Part1 z
  rwa [he,hrep] at ht

private theorem packed139Anchor1 :
  ∀ j : Fin 474, ((j.val : Int)+139)%2=1 →
    1063540 ≤ FourPointNumeric.packedCharge 139 20 packedWeight139_1 (j.val : Int) := by
  intro j hj
  let k := (j.val-0)/2
  have hk : k < 237 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+0 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := fourPoint139PackedAnchor1Part0 z
    rwa [he,hrep] at ht
  let z : Fin 117 := ⟨k-120, by omega⟩
  have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
  have ht := fourPoint139PackedAnchor1Part1 z
  rwa [he,hrep] at ht

def packedCertificate139_0 : FourPointCertificate 139 0 111380 :=
  fourPointCertificateOfPacked 139 0 111380 1063544 20 packedWeight139_0 377 474
    (by decide +kernel) (by decide) (by decide) packed139Anchor0
    (by rw [packedWeight139_0_budget]; decide)

def packedCertificate139_1 : FourPointCertificate 139 1 111380 :=
  fourPointCertificateOfPacked 139 1 111380 1063540 20 packedWeight139_1 358 474
    (by decide +kernel) (by decide) (by decide) packed139Anchor1
    (by rw [packedWeight139_1_budget]; decide)

theorem max148_second139_fourPoint_moment_bound (tail : List ℕ) (len : tail.length=7)
    (distinct : (natSubsetSums (148::139::tail)).Nodup) :
    111380 ≤ ((148::139::tail).map (· ^ 2)).sum := by
  apply fourPointNatMomentLower 139 111380 tail len distinct
  intro p hp
  by_cases h : p=0
  · subst p
    exact packedCertificate139_0
  · have he : p=1 := hp.resolve_left h
    subst p
    exact packedCertificate139_1

#print axioms max148_second139_fourPoint_moment_bound

end NineSeparatedSubsetSums
