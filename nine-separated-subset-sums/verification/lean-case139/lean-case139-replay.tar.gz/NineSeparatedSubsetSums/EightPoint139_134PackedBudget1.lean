import NineSeparatedSubsetSums.EightPoint139_134PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct139_134_1_budget :
    FourPointNumeric.packedBudget 20 packedOct139_134_1 272 = 90625708 := by decide +kernel

#print axioms packedOct139_134_1_budget

end NineSeparatedSubsetSums
