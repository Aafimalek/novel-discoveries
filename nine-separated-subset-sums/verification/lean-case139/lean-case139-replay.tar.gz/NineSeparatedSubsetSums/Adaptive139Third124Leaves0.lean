import NineSeparatedSubsetSums.Adaptive139Third124State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third124Proof0 : runCachedNode 511 126340 Adaptive139Third124Node0 = false := by
  decide +kernel

#print axioms adaptive139Third124Proof0

end NineSeparatedSubsetSums
