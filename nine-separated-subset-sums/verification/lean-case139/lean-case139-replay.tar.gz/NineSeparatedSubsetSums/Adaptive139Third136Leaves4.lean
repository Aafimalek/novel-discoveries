import NineSeparatedSubsetSums.Adaptive139Third136State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third136Proof120 : runCachedNode 511 128827 Adaptive139Third136Node120 = false := by
  decide +kernel

#print axioms adaptive139Third136Proof120

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third136Proof18 : runCachedNode 511 128827 Adaptive139Third136Node18 = false := by
  decide +kernel

#print axioms adaptive139Third136Proof18

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third136Proof91 : runCachedNode 511 128827 Adaptive139Third136Node91 = false := by
  decide +kernel

#print axioms adaptive139Third136Proof91

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third136Proof96 : runCachedNode 511 128827 Adaptive139Third136Node96 = false := by
  decide +kernel

#print axioms adaptive139Third136Proof96

end NineSeparatedSubsetSums
