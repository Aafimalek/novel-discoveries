import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive139Third133Node0 : CachedSearchNode :=
  ⟨4, 132, computeCenteredMask [148,139,133], 420, 58914⟩
def Adaptive139Third133Node1 : CachedSearchNode := cachedChild Adaptive139Third133Node0 111
def Adaptive139Third133Node2 : CachedSearchNode := cachedChild Adaptive139Third133Node0 112
def Adaptive139Third133Node3 : CachedSearchNode := cachedChild Adaptive139Third133Node0 113
def Adaptive139Third133Node4 : CachedSearchNode := cachedChild Adaptive139Third133Node0 114
def Adaptive139Third133Node5 : CachedSearchNode := cachedChild Adaptive139Third133Node0 115
def Adaptive139Third133Node6 : CachedSearchNode := cachedChild Adaptive139Third133Node0 116
def Adaptive139Third133Node7 : CachedSearchNode := cachedChild Adaptive139Third133Node0 117
def Adaptive139Third133Node8 : CachedSearchNode := cachedChild Adaptive139Third133Node0 118
def Adaptive139Third133Node9 : CachedSearchNode := cachedChild Adaptive139Third133Node0 119
def Adaptive139Third133Node10 : CachedSearchNode := cachedChild Adaptive139Third133Node0 120
def Adaptive139Third133Node11 : CachedSearchNode := cachedChild Adaptive139Third133Node0 121
def Adaptive139Third133Node12 : CachedSearchNode := cachedChild Adaptive139Third133Node0 122
def Adaptive139Third133Node13 : CachedSearchNode := cachedChild Adaptive139Third133Node0 123
def Adaptive139Third133Node14 : CachedSearchNode := cachedChild Adaptive139Third133Node0 125
def Adaptive139Third133Node15 : CachedSearchNode := cachedChild Adaptive139Third133Node0 126
def Adaptive139Third133Node16 : CachedSearchNode := cachedChild Adaptive139Third133Node0 127
def Adaptive139Third133Node17 : CachedSearchNode := cachedChild Adaptive139Third133Node0 128
def Adaptive139Third133Node18 : CachedSearchNode := cachedChild Adaptive139Third133Node0 129
def Adaptive139Third133Node19 : CachedSearchNode := cachedChild Adaptive139Third133Node0 130
def Adaptive139Third133Node20 : CachedSearchNode := cachedChild Adaptive139Third133Node19 105
def Adaptive139Third133Node21 : CachedSearchNode := cachedChild Adaptive139Third133Node19 106
def Adaptive139Third133Node22 : CachedSearchNode := cachedChild Adaptive139Third133Node19 107
def Adaptive139Third133Node23 : CachedSearchNode := cachedChild Adaptive139Third133Node19 108
def Adaptive139Third133Node24 : CachedSearchNode := cachedChild Adaptive139Third133Node19 109
def Adaptive139Third133Node25 : CachedSearchNode := cachedChild Adaptive139Third133Node19 110
def Adaptive139Third133Node26 : CachedSearchNode := cachedChild Adaptive139Third133Node19 111
def Adaptive139Third133Node27 : CachedSearchNode := cachedChild Adaptive139Third133Node19 112
def Adaptive139Third133Node28 : CachedSearchNode := cachedChild Adaptive139Third133Node19 113
def Adaptive139Third133Node29 : CachedSearchNode := cachedChild Adaptive139Third133Node19 114
def Adaptive139Third133Node30 : CachedSearchNode := cachedChild Adaptive139Third133Node19 116
def Adaptive139Third133Node31 : CachedSearchNode := cachedChild Adaptive139Third133Node19 117
def Adaptive139Third133Node32 : CachedSearchNode := cachedChild Adaptive139Third133Node19 118
def Adaptive139Third133Node33 : CachedSearchNode := cachedChild Adaptive139Third133Node19 119
def Adaptive139Third133Node34 : CachedSearchNode := cachedChild Adaptive139Third133Node19 120
def Adaptive139Third133Node35 : CachedSearchNode := cachedChild Adaptive139Third133Node19 122
def Adaptive139Third133Node36 : CachedSearchNode := cachedChild Adaptive139Third133Node19 123
def Adaptive139Third133Node37 : CachedSearchNode := cachedChild Adaptive139Third133Node19 125
def Adaptive139Third133Node38 : CachedSearchNode := cachedChild Adaptive139Third133Node19 126
def Adaptive139Third133Node39 : CachedSearchNode := cachedChild Adaptive139Third133Node19 127
def Adaptive139Third133Node40 : CachedSearchNode := cachedChild Adaptive139Third133Node19 128
def Adaptive139Third133Node41 : CachedSearchNode := cachedChild Adaptive139Third133Node19 129
def Adaptive139Third133Node42 : CachedSearchNode := cachedChild Adaptive139Third133Node0 131
def Adaptive139Third133Node43 : CachedSearchNode := cachedChild Adaptive139Third133Node0 132
def Adaptive139Third133Node44 : CachedSearchNode := cachedChild Adaptive139Third133Node43 104
def Adaptive139Third133Node45 : CachedSearchNode := cachedChild Adaptive139Third133Node43 105
def Adaptive139Third133Node46 : CachedSearchNode := cachedChild Adaptive139Third133Node43 106
def Adaptive139Third133Node47 : CachedSearchNode := cachedChild Adaptive139Third133Node43 107
def Adaptive139Third133Node48 : CachedSearchNode := cachedChild Adaptive139Third133Node43 108
def Adaptive139Third133Node49 : CachedSearchNode := cachedChild Adaptive139Third133Node43 109
def Adaptive139Third133Node50 : CachedSearchNode := cachedChild Adaptive139Third133Node43 110
def Adaptive139Third133Node51 : CachedSearchNode := cachedChild Adaptive139Third133Node43 111
def Adaptive139Third133Node52 : CachedSearchNode := cachedChild Adaptive139Third133Node43 112
def Adaptive139Third133Node53 : CachedSearchNode := cachedChild Adaptive139Third133Node43 113
def Adaptive139Third133Node54 : CachedSearchNode := cachedChild Adaptive139Third133Node43 114
def Adaptive139Third133Node55 : CachedSearchNode := cachedChild Adaptive139Third133Node43 115
def Adaptive139Third133Node56 : CachedSearchNode := cachedChild Adaptive139Third133Node43 116
def Adaptive139Third133Node57 : CachedSearchNode := cachedChild Adaptive139Third133Node43 118
def Adaptive139Third133Node58 : CachedSearchNode := cachedChild Adaptive139Third133Node43 119
def Adaptive139Third133Node59 : CachedSearchNode := cachedChild Adaptive139Third133Node43 120
def Adaptive139Third133Node60 : CachedSearchNode := cachedChild Adaptive139Third133Node43 121
def Adaptive139Third133Node61 : CachedSearchNode := cachedChild Adaptive139Third133Node43 122
def Adaptive139Third133Node62 : CachedSearchNode := cachedChild Adaptive139Third133Node43 125
def Adaptive139Third133Node63 : CachedSearchNode := cachedChild Adaptive139Third133Node43 127
def Adaptive139Third133Node64 : CachedSearchNode := cachedChild Adaptive139Third133Node43 128
def Adaptive139Third133Node65 : CachedSearchNode := cachedChild Adaptive139Third133Node43 129
def Adaptive139Third133Node66 : CachedSearchNode := cachedChild Adaptive139Third133Node43 130
def Adaptive139Third133Node67 : CachedSearchNode := cachedChild Adaptive139Third133Node43 131

end NineSeparatedSubsetSums
