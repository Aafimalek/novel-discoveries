import NineSeparatedSubsetSums.Adaptive139Third130State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third130Proof16 : runCachedNode 511 127774 Adaptive139Third130Node16 = false := by
  decide +kernel

#print axioms adaptive139Third130Proof16

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third130Proof15 : runCachedNode 511 127774 Adaptive139Third130Node15 = false := by
  decide +kernel

#print axioms adaptive139Third130Proof15

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third130Proof4 : runCachedNode 511 127774 Adaptive139Third130Node4 = false := by
  decide +kernel

#print axioms adaptive139Third130Proof4

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third130Proof3 : runCachedNode 511 127774 Adaptive139Third130Node3 = false := by
  decide +kernel

#print axioms adaptive139Third130Proof3

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third130Proof2 : runCachedNode 511 127774 Adaptive139Third130Node2 = false := by
  decide +kernel

#print axioms adaptive139Third130Proof2

end NineSeparatedSubsetSums
