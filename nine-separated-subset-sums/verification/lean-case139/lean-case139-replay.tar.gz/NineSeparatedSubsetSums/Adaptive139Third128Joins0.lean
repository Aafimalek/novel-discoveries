import NineSeparatedSubsetSums.Adaptive139Third128State
import NineSeparatedSubsetSums.Adaptive139Third128Leaves0
import NineSeparatedSubsetSums.Adaptive139Third128Leaves1

namespace NineSeparatedSubsetSums

theorem adaptive139Third128Proof0 : runCachedNode 511 127306 Adaptive139Third128Node0 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 127306 Adaptive139Third128Node0 = [111, 112, 113, 114, 115, 116, 117, 118, 120, 121, 122, 123, 124, 125, 126, 127] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive139Third128Proof1
  · exact adaptive139Third128Proof2
  · exact adaptive139Third128Proof3
  · exact adaptive139Third128Proof4
  · exact adaptive139Third128Proof5
  · exact adaptive139Third128Proof6
  · exact adaptive139Third128Proof7
  · exact adaptive139Third128Proof8
  · exact adaptive139Third128Proof9
  · exact adaptive139Third128Proof10
  · exact adaptive139Third128Proof11
  · exact adaptive139Third128Proof12
  · exact adaptive139Third128Proof13
  · exact adaptive139Third128Proof14
  · exact adaptive139Third128Proof15
  · exact adaptive139Third128Proof16

#print axioms adaptive139Third128Proof0

end NineSeparatedSubsetSums
