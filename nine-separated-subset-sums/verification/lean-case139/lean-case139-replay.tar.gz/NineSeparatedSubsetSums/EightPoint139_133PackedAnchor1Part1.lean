import NineSeparatedSubsetSums.EightPoint139_133PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint139_133PackedAnchor1Part1 :
    ∀ j : Fin 120, 2427802 ≤ FourPointNumeric.octPackedCharge 139 133 20 packedOct139_133_1
      (2*((j.val : Int)+120)+1) := by decide +kernel

end NineSeparatedSubsetSums
