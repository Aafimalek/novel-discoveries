import NineSeparatedSubsetSums.Adaptive139Third137State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third137Proof95 : runCachedNode 511 129004 Adaptive139Third137Node95 = false := by
  decide +kernel

#print axioms adaptive139Third137Proof95

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third137Proof69 : runCachedNode 511 129004 Adaptive139Third137Node69 = false := by
  decide +kernel

#print axioms adaptive139Third137Proof69

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third137Proof42 : runCachedNode 511 129004 Adaptive139Third137Node42 = false := by
  decide +kernel

#print axioms adaptive139Third137Proof42

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third137Proof68 : runCachedNode 511 129004 Adaptive139Third137Node68 = false := by
  decide +kernel

#print axioms adaptive139Third137Proof68

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third137Proof48 : runCachedNode 511 129004 Adaptive139Third137Node48 = false := by
  decide +kernel

#print axioms adaptive139Third137Proof48

end NineSeparatedSubsetSums
