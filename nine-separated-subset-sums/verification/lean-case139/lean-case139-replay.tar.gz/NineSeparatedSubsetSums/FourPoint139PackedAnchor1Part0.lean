import NineSeparatedSubsetSums.FourPoint139PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem fourPoint139PackedAnchor1Part0 :
    ∀ j : Fin 120, 1063540 ≤ FourPointNumeric.packedCharge 139 20 packedWeight139_1
      (2*((j.val : Int)+0)+0) := by decide +kernel

end NineSeparatedSubsetSums
