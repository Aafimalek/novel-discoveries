import NineSeparatedSubsetSums.Adaptive139Third115State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third115Proof9 : runCachedNode 511 111380 Adaptive139Third115Node9 = false := by
  decide +kernel

#print axioms adaptive139Third115Proof9

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third115Proof8 : runCachedNode 511 111380 Adaptive139Third115Node8 = false := by
  decide +kernel

#print axioms adaptive139Third115Proof8

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third115Proof7 : runCachedNode 511 111380 Adaptive139Third115Node7 = false := by
  decide +kernel

#print axioms adaptive139Third115Proof7

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third115Proof6 : runCachedNode 511 111380 Adaptive139Third115Node6 = false := by
  decide +kernel

#print axioms adaptive139Third115Proof6

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third115Proof4 : runCachedNode 511 111380 Adaptive139Third115Node4 = false := by
  decide +kernel

#print axioms adaptive139Third115Proof4

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third115Proof3 : runCachedNode 511 111380 Adaptive139Third115Node3 = false := by
  decide +kernel

#print axioms adaptive139Third115Proof3

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third115Proof2 : runCachedNode 511 111380 Adaptive139Third115Node2 = false := by
  decide +kernel

#print axioms adaptive139Third115Proof2

end NineSeparatedSubsetSums
