import NineSeparatedSubsetSums.Adaptive139Third135State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third135Proof115 : runCachedNode 511 128672 Adaptive139Third135Node115 = false := by
  decide +kernel

#print axioms adaptive139Third135Proof115

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third135Proof65 : runCachedNode 511 128672 Adaptive139Third135Node65 = false := by
  decide +kernel

#print axioms adaptive139Third135Proof65

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third135Proof63 : runCachedNode 511 128672 Adaptive139Third135Node63 = false := by
  decide +kernel

#print axioms adaptive139Third135Proof63

end NineSeparatedSubsetSums
