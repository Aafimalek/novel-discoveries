import NineSeparatedSubsetSums.EightPoint139_133PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct139_133_0_budget :
    FourPointNumeric.packedBudget 20 packedOct139_133_0 271 = 89629538 := by decide +kernel

#print axioms packedOct139_133_0_budget

end NineSeparatedSubsetSums
