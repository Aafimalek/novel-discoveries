import NineSeparatedSubsetSums.EightPoint139_137PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint139_137PackedAnchor1Part1 :
    ∀ j : Fin 120, 2468196 ≤ FourPointNumeric.octPackedCharge 139 137 20 packedOct139_137_1
      (2*((j.val : Int)+120)+1) := by decide +kernel

end NineSeparatedSubsetSums
