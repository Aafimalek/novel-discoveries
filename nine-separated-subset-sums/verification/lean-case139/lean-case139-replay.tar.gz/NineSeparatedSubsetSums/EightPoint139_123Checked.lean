import NineSeparatedSubsetSums.EightPointPackedGeometry
import NineSeparatedSubsetSums.EightPoint139_123PackedBudget0
import NineSeparatedSubsetSums.EightPoint139_123PackedAnchor0Part0
import NineSeparatedSubsetSums.EightPoint139_123PackedAnchor0Part1
import NineSeparatedSubsetSums.EightPoint139_123PackedBudget1
import NineSeparatedSubsetSums.EightPoint139_123PackedAnchor1Part0
import NineSeparatedSubsetSums.EightPoint139_123PackedAnchor1Part1

namespace NineSeparatedSubsetSums

private theorem packedOct139_123Anchor0 :
  ∀ j : Fin 480, ((j.val : Int)+139+123)%2=0 →
    2291816 ≤ FourPointNumeric.octPackedCharge 139 123 20 packedOct139_123_0 (j.val : Int) := by
  intro j hj
  let k := (j.val-0)/2
  have hk : k < 240 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+0 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint139_123PackedAnchor0Part0 z
    rwa [he,hrep] at ht
  let z : Fin 120 := ⟨k-120, by omega⟩
  have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
  have ht := eightPoint139_123PackedAnchor0Part1 z
  rwa [he,hrep] at ht

private theorem packedOct139_123Anchor1 :
  ∀ j : Fin 480, ((j.val : Int)+139+123)%2=1 →
    2290642 ≤ FourPointNumeric.octPackedCharge 139 123 20 packedOct139_123_1 (j.val : Int) := by
  intro j hj
  let k := (j.val-1)/2
  have hk : k < 240 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+1 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint139_123PackedAnchor1Part0 z
    rwa [he,hrep] at ht
  let z : Fin 120 := ⟨k-120, by omega⟩
  have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
  have ht := eightPoint139_123PackedAnchor1Part1 z
  rwa [he,hrep] at ht

def packedOctCertificate139_123_0 : EightPointCertificate 139 123 0 125935 :=
  eightPointCertificateOfPacked 139 123 0 125935 2291816 20 packedOct139_123_0 481 480
    (by decide +kernel) (by decide) packedOct139_123Anchor0
    (by rw [packedOct139_123_0_budget]; decide)

def packedOctCertificate139_123_1 : EightPointCertificate 139 123 1 125935 :=
  eightPointCertificateOfPacked 139 123 1 125935 2290642 20 packedOct139_123_1 480 480
    (by decide +kernel) (by decide) packedOct139_123Anchor1
    (by rw [packedOct139_123_1_budget]; decide)

theorem max148_second139_third123_eightPoint_moment_bound (tail : List ℕ) (len : tail.length=6)
    (distinct : (natSubsetSums (148::139::123::tail)).Nodup) :
    125935 ≤ ((148::139::123::tail).map (· ^ 2)).sum := by
  apply eightPointNatMomentLower 139 123 125935 tail len distinct
  intro p hp
  by_cases h : p=0
  · subst p
    exact packedOctCertificate139_123_0
  · have he : p=1 := hp.resolve_left h
    subst p
    exact packedOctCertificate139_123_1

#print axioms max148_second139_third123_eightPoint_moment_bound

end NineSeparatedSubsetSums
