import NineSeparatedSubsetSums.EightPoint139_127PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct139_127_0_budget :
    FourPointNumeric.packedBudget 20 packedOct139_127_0 445 = 85240094 := by decide +kernel

#print axioms packedOct139_127_0_budget

end NineSeparatedSubsetSums
