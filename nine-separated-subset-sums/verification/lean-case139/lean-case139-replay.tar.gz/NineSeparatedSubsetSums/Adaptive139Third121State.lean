import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive139Third121Node0 : CachedSearchNode :=
  ⟨4, 120, computeCenteredMask [148,139,121], 408, 55866⟩

end NineSeparatedSubsetSums
