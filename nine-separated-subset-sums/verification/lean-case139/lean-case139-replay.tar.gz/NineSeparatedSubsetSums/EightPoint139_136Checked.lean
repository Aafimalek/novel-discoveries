import NineSeparatedSubsetSums.EightPointPackedGeometry
import NineSeparatedSubsetSums.EightPoint139_136PackedBudget0
import NineSeparatedSubsetSums.EightPoint139_136PackedAnchor0Part0
import NineSeparatedSubsetSums.EightPoint139_136PackedAnchor0Part1
import NineSeparatedSubsetSums.EightPoint139_136PackedAnchor0Part2
import NineSeparatedSubsetSums.EightPoint139_136PackedBudget1
import NineSeparatedSubsetSums.EightPoint139_136PackedAnchor1Part0
import NineSeparatedSubsetSums.EightPoint139_136PackedAnchor1Part1
import NineSeparatedSubsetSums.EightPoint139_136PackedAnchor1Part2

namespace NineSeparatedSubsetSums

private theorem packedOct139_136Anchor0 :
  ∀ j : Fin 499, ((j.val : Int)+139+136)%2=0 →
    2463162 ≤ FourPointNumeric.octPackedCharge 139 136 20 packedOct139_136_0 (j.val : Int) := by
  intro j hj
  let k := (j.val-1)/2
  have hk : k < 249 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+1 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint139_136PackedAnchor0Part0 z
    rwa [he,hrep] at ht
  by_cases h1 : k < 240
  · let z : Fin 120 := ⟨k-120, by omega⟩
    have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
    have ht := eightPoint139_136PackedAnchor0Part1 z
    rwa [he,hrep] at ht
  let z : Fin 9 := ⟨k-240, by omega⟩
  have he : (z.val : Int)+240 = k := by dsimp [z] <;> omega
  have ht := eightPoint139_136PackedAnchor0Part2 z
  rwa [he,hrep] at ht

private theorem packedOct139_136Anchor1 :
  ∀ j : Fin 499, ((j.val : Int)+139+136)%2=1 →
    2461642 ≤ FourPointNumeric.octPackedCharge 139 136 20 packedOct139_136_1 (j.val : Int) := by
  intro j hj
  let k := (j.val-0)/2
  have hk : k < 250 := by dsimp [k]; have h := j.isLt; omega
  have hrep : 2*(k : Int)+0 = j.val := by dsimp [k]; omega
  by_cases h0 : k < 120
  · let z : Fin 120 := ⟨k-0, by omega⟩
    have he : (z.val : Int)+0 = k := by dsimp [z] <;> omega
    have ht := eightPoint139_136PackedAnchor1Part0 z
    rwa [he,hrep] at ht
  by_cases h1 : k < 240
  · let z : Fin 120 := ⟨k-120, by omega⟩
    have he : (z.val : Int)+120 = k := by dsimp [z] <;> omega
    have ht := eightPoint139_136PackedAnchor1Part1 z
    rwa [he,hrep] at ht
  let z : Fin 10 := ⟨k-240, by omega⟩
  have he : (z.val : Int)+240 = k := by dsimp [z] <;> omega
  have ht := eightPoint139_136PackedAnchor1Part2 z
  rwa [he,hrep] at ht

def packedOctCertificate139_136_0 : EightPointCertificate 139 136 0 128827 :=
  eightPointCertificateOfPacked 139 136 0 128827 2463162 20 packedOct139_136_0 275 499
    (by decide +kernel) (by decide) packedOct139_136Anchor0
    (by rw [packedOct139_136_0_budget]; decide)

def packedOctCertificate139_136_1 : EightPointCertificate 139 136 1 128827 :=
  eightPointCertificateOfPacked 139 136 1 128827 2461642 20 packedOct139_136_1 272 499
    (by decide +kernel) (by decide) packedOct139_136Anchor1
    (by rw [packedOct139_136_1_budget]; decide)

theorem max148_second139_third136_eightPoint_moment_bound (tail : List ℕ) (len : tail.length=6)
    (distinct : (natSubsetSums (148::139::136::tail)).Nodup) :
    128827 ≤ ((148::139::136::tail).map (· ^ 2)).sum := by
  apply eightPointNatMomentLower 139 136 128827 tail len distinct
  intro p hp
  by_cases h : p=0
  · subst p
    exact packedOctCertificate139_136_0
  · have he : p=1 := hp.resolve_left h
    subst p
    exact packedOctCertificate139_136_1

#print axioms max148_second139_third136_eightPoint_moment_bound

end NineSeparatedSubsetSums
