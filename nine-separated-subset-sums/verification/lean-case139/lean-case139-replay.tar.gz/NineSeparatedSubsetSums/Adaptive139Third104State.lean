import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive139Third104Node0 : CachedSearchNode :=
  ⟨4, 103, computeCenteredMask [148,139,104], 391, 52041⟩

end NineSeparatedSubsetSums
