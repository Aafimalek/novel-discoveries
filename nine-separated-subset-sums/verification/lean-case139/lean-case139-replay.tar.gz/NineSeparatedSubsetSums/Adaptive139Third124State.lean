import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive139Third124Node0 : CachedSearchNode :=
  ⟨4, 123, computeCenteredMask [148,139,124], 411, 56601⟩

end NineSeparatedSubsetSums
