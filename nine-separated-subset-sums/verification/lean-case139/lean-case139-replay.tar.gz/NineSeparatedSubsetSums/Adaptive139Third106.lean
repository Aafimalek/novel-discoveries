import NineSeparatedSubsetSums.Adaptive139Third106Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint139Checked

namespace NineSeparatedSubsetSums


theorem adaptive139Third106 : NoDescendingTailAfterThird 139 106 :=
  noDescendingThirdTail_of_cached 139 106 111380 (fun t ht nd => max148_second139_fourPoint_moment_bound (106::t) (by simp [ht]) nd) adaptive139Third106Proof0

#print axioms adaptive139Third106

end NineSeparatedSubsetSums
