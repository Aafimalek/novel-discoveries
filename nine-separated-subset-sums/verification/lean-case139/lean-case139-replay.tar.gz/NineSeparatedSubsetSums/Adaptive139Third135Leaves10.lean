import NineSeparatedSubsetSums.Adaptive139Third135State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third135Proof1 : runCachedNode 511 128672 Adaptive139Third135Node1 = false := by
  decide +kernel

#print axioms adaptive139Third135Proof1

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third135Proof67 : runCachedNode 511 128672 Adaptive139Third135Node67 = false := by
  decide +kernel

#print axioms adaptive139Third135Proof67

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third135Proof94 : runCachedNode 511 128672 Adaptive139Third135Node94 = false := by
  decide +kernel

#print axioms adaptive139Third135Proof94

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third135Proof119 : runCachedNode 511 128672 Adaptive139Third135Node119 = false := by
  decide +kernel

#print axioms adaptive139Third135Proof119

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third135Proof120 : runCachedNode 511 128672 Adaptive139Third135Node120 = false := by
  decide +kernel

#print axioms adaptive139Third135Proof120

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third135Proof92 : runCachedNode 511 128672 Adaptive139Third135Node92 = false := by
  decide +kernel

#print axioms adaptive139Third135Proof92

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third135Proof93 : runCachedNode 511 128672 Adaptive139Third135Node93 = false := by
  decide +kernel

#print axioms adaptive139Third135Proof93

end NineSeparatedSubsetSums
