import NineSeparatedSubsetSums.Adaptive139Third130State
import NineSeparatedSubsetSums.Adaptive139Third130Leaves0
import NineSeparatedSubsetSums.Adaptive139Third130Leaves2
import NineSeparatedSubsetSums.Adaptive139Third130Leaves1
import NineSeparatedSubsetSums.Adaptive139Third130Leaves3

namespace NineSeparatedSubsetSums

theorem adaptive139Third130Proof0 : runCachedNode 511 127774 Adaptive139Third130Node0 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 127774 Adaptive139Third130Node0 = [111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 122, 123, 124, 125, 126, 127, 128, 129] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive139Third130Proof1
  · exact adaptive139Third130Proof2
  · exact adaptive139Third130Proof3
  · exact adaptive139Third130Proof4
  · exact adaptive139Third130Proof5
  · exact adaptive139Third130Proof6
  · exact adaptive139Third130Proof7
  · exact adaptive139Third130Proof8
  · exact adaptive139Third130Proof9
  · exact adaptive139Third130Proof10
  · exact adaptive139Third130Proof11
  · exact adaptive139Third130Proof12
  · exact adaptive139Third130Proof13
  · exact adaptive139Third130Proof14
  · exact adaptive139Third130Proof15
  · exact adaptive139Third130Proof16
  · exact adaptive139Third130Proof17
  · exact adaptive139Third130Proof18

#print axioms adaptive139Third130Proof0

end NineSeparatedSubsetSums
