import NineSeparatedSubsetSums.Adaptive139Third137State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third137Proof44 : runCachedNode 511 129004 Adaptive139Third137Node44 = false := by
  decide +kernel

#print axioms adaptive139Third137Proof44

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third137Proof187 : runCachedNode 511 129004 Adaptive139Third137Node187 = false := by
  decide +kernel

#print axioms adaptive139Third137Proof187

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third137Proof47 : runCachedNode 511 129004 Adaptive139Third137Node47 = false := by
  decide +kernel

#print axioms adaptive139Third137Proof47

end NineSeparatedSubsetSums
