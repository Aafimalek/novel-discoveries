import NineSeparatedSubsetSums.EightPoint139_138PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct139_138_0_budget :
    FourPointNumeric.packedBudget 20 packedOct139_138_0 273 = 92906350 := by decide +kernel

#print axioms packedOct139_138_0_budget

end NineSeparatedSubsetSums
