import NineSeparatedSubsetSums.EightPoint139_117PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct139_117_1_budget :
    FourPointNumeric.packedBudget 20 packedOct139_117_1 428 = 85298806 := by decide +kernel

#print axioms packedOct139_117_1_budget

end NineSeparatedSubsetSums
