import NineSeparatedSubsetSums.EightPoint139_130PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint139_130PackedAnchor0Part2 :
    ∀ j : Fin 6, 2402015 ≤ FourPointNumeric.octPackedCharge 139 130 20 packedOct139_130_0
      (2*((j.val : Int)+240)+1) := by decide +kernel

end NineSeparatedSubsetSums
