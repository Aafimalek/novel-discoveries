import NineSeparatedSubsetSums.Adaptive139Third138State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third138Proof44 : runCachedNode 511 129184 Adaptive139Third138Node44 = false := by
  decide +kernel

#print axioms adaptive139Third138Proof44

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third138Proof123 : runCachedNode 511 129184 Adaptive139Third138Node123 = false := by
  decide +kernel

#print axioms adaptive139Third138Proof123

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third138Proof175 : runCachedNode 511 129184 Adaptive139Third138Node175 = false := by
  decide +kernel

#print axioms adaptive139Third138Proof175

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third138Proof48 : runCachedNode 511 129184 Adaptive139Third138Node48 = false := by
  decide +kernel

#print axioms adaptive139Third138Proof48

end NineSeparatedSubsetSums
