import NineSeparatedSubsetSums.EightPoint139_136PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct139_136_1_budget :
    FourPointNumeric.packedBudget 20 packedOct139_136_1 272 = 91585644 := by decide +kernel

#print axioms packedOct139_136_1_budget

end NineSeparatedSubsetSums
