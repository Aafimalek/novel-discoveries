import NineSeparatedSubsetSums.EightPoint139_127PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint139_127PackedAnchor1Part0 :
    ∀ j : Fin 120, 2348509 ≤ FourPointNumeric.octPackedCharge 139 127 20 packedOct139_127_1
      (2*((j.val : Int)+0)+1) := by decide +kernel

end NineSeparatedSubsetSums
