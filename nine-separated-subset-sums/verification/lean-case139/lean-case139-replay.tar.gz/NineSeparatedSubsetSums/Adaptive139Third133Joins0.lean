import NineSeparatedSubsetSums.Adaptive139Third133State
import NineSeparatedSubsetSums.Adaptive139Third133Leaves2
import NineSeparatedSubsetSums.Adaptive139Third133Leaves6
import NineSeparatedSubsetSums.Adaptive139Third133Leaves5
import NineSeparatedSubsetSums.Adaptive139Third133Leaves1
import NineSeparatedSubsetSums.Adaptive139Third133Leaves4
import NineSeparatedSubsetSums.Adaptive139Third133Leaves3
import NineSeparatedSubsetSums.Adaptive139Third133Leaves0

namespace NineSeparatedSubsetSums

theorem adaptive139Third133Proof19 : runCachedNode 511 128283 Adaptive139Third133Node19 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 128283 Adaptive139Third133Node19 = [105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 116, 117, 118, 119, 120, 122, 123, 125, 126, 127, 128, 129] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive139Third133Proof20
  · exact adaptive139Third133Proof21
  · exact adaptive139Third133Proof22
  · exact adaptive139Third133Proof23
  · exact adaptive139Third133Proof24
  · exact adaptive139Third133Proof25
  · exact adaptive139Third133Proof26
  · exact adaptive139Third133Proof27
  · exact adaptive139Third133Proof28
  · exact adaptive139Third133Proof29
  · exact adaptive139Third133Proof30
  · exact adaptive139Third133Proof31
  · exact adaptive139Third133Proof32
  · exact adaptive139Third133Proof33
  · exact adaptive139Third133Proof34
  · exact adaptive139Third133Proof35
  · exact adaptive139Third133Proof36
  · exact adaptive139Third133Proof37
  · exact adaptive139Third133Proof38
  · exact adaptive139Third133Proof39
  · exact adaptive139Third133Proof40
  · exact adaptive139Third133Proof41

#print axioms adaptive139Third133Proof19

theorem adaptive139Third133Proof43 : runCachedNode 511 128283 Adaptive139Third133Node43 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 128283 Adaptive139Third133Node43 = [104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 118, 119, 120, 121, 122, 125, 127, 128, 129, 130, 131] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive139Third133Proof44
  · exact adaptive139Third133Proof45
  · exact adaptive139Third133Proof46
  · exact adaptive139Third133Proof47
  · exact adaptive139Third133Proof48
  · exact adaptive139Third133Proof49
  · exact adaptive139Third133Proof50
  · exact adaptive139Third133Proof51
  · exact adaptive139Third133Proof52
  · exact adaptive139Third133Proof53
  · exact adaptive139Third133Proof54
  · exact adaptive139Third133Proof55
  · exact adaptive139Third133Proof56
  · exact adaptive139Third133Proof57
  · exact adaptive139Third133Proof58
  · exact adaptive139Third133Proof59
  · exact adaptive139Third133Proof60
  · exact adaptive139Third133Proof61
  · exact adaptive139Third133Proof62
  · exact adaptive139Third133Proof63
  · exact adaptive139Third133Proof64
  · exact adaptive139Third133Proof65
  · exact adaptive139Third133Proof66
  · exact adaptive139Third133Proof67

#print axioms adaptive139Third133Proof43

theorem adaptive139Third133Proof0 : runCachedNode 511 128283 Adaptive139Third133Node0 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 128283 Adaptive139Third133Node0 = [111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 125, 126, 127, 128, 129, 130, 131, 132] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive139Third133Proof1
  · exact adaptive139Third133Proof2
  · exact adaptive139Third133Proof3
  · exact adaptive139Third133Proof4
  · exact adaptive139Third133Proof5
  · exact adaptive139Third133Proof6
  · exact adaptive139Third133Proof7
  · exact adaptive139Third133Proof8
  · exact adaptive139Third133Proof9
  · exact adaptive139Third133Proof10
  · exact adaptive139Third133Proof11
  · exact adaptive139Third133Proof12
  · exact adaptive139Third133Proof13
  · exact adaptive139Third133Proof14
  · exact adaptive139Third133Proof15
  · exact adaptive139Third133Proof16
  · exact adaptive139Third133Proof17
  · exact adaptive139Third133Proof18
  · exact adaptive139Third133Proof19
  · exact adaptive139Third133Proof42
  · exact adaptive139Third133Proof43

#print axioms adaptive139Third133Proof0

end NineSeparatedSubsetSums
