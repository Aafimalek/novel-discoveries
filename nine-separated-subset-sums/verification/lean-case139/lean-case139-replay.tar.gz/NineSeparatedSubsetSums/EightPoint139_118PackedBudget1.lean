import NineSeparatedSubsetSums.EightPoint139_118PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct139_118_1_budget :
    FourPointNumeric.packedBudget 20 packedOct139_118_1 444 = 85834548 := by decide +kernel

#print axioms packedOct139_118_1_budget

end NineSeparatedSubsetSums
