import NineSeparatedSubsetSums.EightPoint139_117PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint139_117PackedAnchor1Part0 :
    ∀ j : Fin 120, 2331663 ≤ FourPointNumeric.octPackedCharge 139 117 20 packedOct139_117_1
      (2*((j.val : Int)+0)+1) := by decide +kernel

end NineSeparatedSubsetSums
