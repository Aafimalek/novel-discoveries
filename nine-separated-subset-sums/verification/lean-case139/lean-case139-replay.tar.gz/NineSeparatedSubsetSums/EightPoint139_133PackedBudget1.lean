import NineSeparatedSubsetSums.EightPoint139_133PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct139_133_1_budget :
    FourPointNumeric.packedBudget 20 packedOct139_133_1 272 = 89698312 := by decide +kernel

#print axioms packedOct139_133_1_budget

end NineSeparatedSubsetSums
