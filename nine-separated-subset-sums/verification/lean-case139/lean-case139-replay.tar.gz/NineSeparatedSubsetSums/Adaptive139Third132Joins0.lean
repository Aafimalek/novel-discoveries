import NineSeparatedSubsetSums.Adaptive139Third132State
import NineSeparatedSubsetSums.Adaptive139Third132Leaves1
import NineSeparatedSubsetSums.Adaptive139Third132Leaves0
import NineSeparatedSubsetSums.Adaptive139Third132Leaves4
import NineSeparatedSubsetSums.Adaptive139Third132Leaves2
import NineSeparatedSubsetSums.Adaptive139Third132Leaves3

namespace NineSeparatedSubsetSums

theorem adaptive139Third132Proof19 : runCachedNode 511 128175 Adaptive139Third132Node19 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 128175 Adaptive139Third132Node19 = [105, 106, 107, 108, 109, 110, 111, 112, 113, 115, 116, 117, 118, 119, 120, 122, 124, 125, 126, 127, 128, 129] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive139Third132Proof20
  · exact adaptive139Third132Proof21
  · exact adaptive139Third132Proof22
  · exact adaptive139Third132Proof23
  · exact adaptive139Third132Proof24
  · exact adaptive139Third132Proof25
  · exact adaptive139Third132Proof26
  · exact adaptive139Third132Proof27
  · exact adaptive139Third132Proof28
  · exact adaptive139Third132Proof29
  · exact adaptive139Third132Proof30
  · exact adaptive139Third132Proof31
  · exact adaptive139Third132Proof32
  · exact adaptive139Third132Proof33
  · exact adaptive139Third132Proof34
  · exact adaptive139Third132Proof35
  · exact adaptive139Third132Proof36
  · exact adaptive139Third132Proof37
  · exact adaptive139Third132Proof38
  · exact adaptive139Third132Proof39
  · exact adaptive139Third132Proof40
  · exact adaptive139Third132Proof41

#print axioms adaptive139Third132Proof19

theorem adaptive139Third132Proof0 : runCachedNode 511 128175 Adaptive139Third132Node0 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 128175 Adaptive139Third132Node0 = [111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 124, 125, 126, 127, 128, 129, 130, 131] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive139Third132Proof1
  · exact adaptive139Third132Proof2
  · exact adaptive139Third132Proof3
  · exact adaptive139Third132Proof4
  · exact adaptive139Third132Proof5
  · exact adaptive139Third132Proof6
  · exact adaptive139Third132Proof7
  · exact adaptive139Third132Proof8
  · exact adaptive139Third132Proof9
  · exact adaptive139Third132Proof10
  · exact adaptive139Third132Proof11
  · exact adaptive139Third132Proof12
  · exact adaptive139Third132Proof13
  · exact adaptive139Third132Proof14
  · exact adaptive139Third132Proof15
  · exact adaptive139Third132Proof16
  · exact adaptive139Third132Proof17
  · exact adaptive139Third132Proof18
  · exact adaptive139Third132Proof19
  · exact adaptive139Third132Proof42

#print axioms adaptive139Third132Proof0

end NineSeparatedSubsetSums
