import NineSeparatedSubsetSums.EightPoint139_118PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint139_118PackedAnchor1Part1 :
    ∀ j : Fin 120, 2341611 ≤ FourPointNumeric.octPackedCharge 139 118 20 packedOct139_118_1
      (2*((j.val : Int)+120)+0) := by decide +kernel

end NineSeparatedSubsetSums
