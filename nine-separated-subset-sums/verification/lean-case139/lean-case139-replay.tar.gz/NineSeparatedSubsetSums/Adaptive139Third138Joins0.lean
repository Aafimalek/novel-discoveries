import NineSeparatedSubsetSums.Adaptive139Third138State
import NineSeparatedSubsetSums.Adaptive139Third138Leaves2
import NineSeparatedSubsetSums.Adaptive139Third138Leaves19
import NineSeparatedSubsetSums.Adaptive139Third138Leaves8
import NineSeparatedSubsetSums.Adaptive139Third138Leaves18
import NineSeparatedSubsetSums.Adaptive139Third138Leaves17
import NineSeparatedSubsetSums.Adaptive139Third138Leaves16
import NineSeparatedSubsetSums.Adaptive139Third138Leaves14
import NineSeparatedSubsetSums.Adaptive139Third138Leaves15
import NineSeparatedSubsetSums.Adaptive139Third138Leaves13
import NineSeparatedSubsetSums.Adaptive139Third138Leaves12
import NineSeparatedSubsetSums.Adaptive139Third138Leaves9
import NineSeparatedSubsetSums.Adaptive139Third138Leaves6
import NineSeparatedSubsetSums.Adaptive139Third138Leaves5
import NineSeparatedSubsetSums.Adaptive139Third138Leaves7
import NineSeparatedSubsetSums.Adaptive139Third138Leaves11
import NineSeparatedSubsetSums.Adaptive139Third138Leaves10
import NineSeparatedSubsetSums.Adaptive139Third138Leaves0
import NineSeparatedSubsetSums.Adaptive139Third138Leaves20
import NineSeparatedSubsetSums.Adaptive139Third138Leaves1
import NineSeparatedSubsetSums.Adaptive139Third138Leaves3
import NineSeparatedSubsetSums.Adaptive139Third138Leaves4

namespace NineSeparatedSubsetSums

theorem adaptive139Third138Proof20 : runCachedNode 511 129184 Adaptive139Third138Node20 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 129184 Adaptive139Third138Node20 = [104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 122, 123, 124, 125, 126, 127, 128] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive139Third138Proof21
  · exact adaptive139Third138Proof22
  · exact adaptive139Third138Proof23
  · exact adaptive139Third138Proof24
  · exact adaptive139Third138Proof25
  · exact adaptive139Third138Proof26
  · exact adaptive139Third138Proof27
  · exact adaptive139Third138Proof28
  · exact adaptive139Third138Proof29
  · exact adaptive139Third138Proof30
  · exact adaptive139Third138Proof31
  · exact adaptive139Third138Proof32
  · exact adaptive139Third138Proof33
  · exact adaptive139Third138Proof34
  · exact adaptive139Third138Proof35
  · exact adaptive139Third138Proof36
  · exact adaptive139Third138Proof37
  · exact adaptive139Third138Proof38
  · exact adaptive139Third138Proof39
  · exact adaptive139Third138Proof40
  · exact adaptive139Third138Proof41
  · exact adaptive139Third138Proof42
  · exact adaptive139Third138Proof43

#print axioms adaptive139Third138Proof20

theorem adaptive139Third138Proof45 : runCachedNode 511 129184 Adaptive139Third138Node45 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 129184 Adaptive139Third138Node45 = [104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 124, 125, 126, 127, 128, 130] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive139Third138Proof46
  · exact adaptive139Third138Proof47
  · exact adaptive139Third138Proof48
  · exact adaptive139Third138Proof49
  · exact adaptive139Third138Proof50
  · exact adaptive139Third138Proof51
  · exact adaptive139Third138Proof52
  · exact adaptive139Third138Proof53
  · exact adaptive139Third138Proof54
  · exact adaptive139Third138Proof55
  · exact adaptive139Third138Proof56
  · exact adaptive139Third138Proof57
  · exact adaptive139Third138Proof58
  · exact adaptive139Third138Proof59
  · exact adaptive139Third138Proof60
  · exact adaptive139Third138Proof61
  · exact adaptive139Third138Proof62
  · exact adaptive139Third138Proof63
  · exact adaptive139Third138Proof64
  · exact adaptive139Third138Proof65
  · exact adaptive139Third138Proof66
  · exact adaptive139Third138Proof67
  · exact adaptive139Third138Proof68
  · exact adaptive139Third138Proof69

#print axioms adaptive139Third138Proof45

theorem adaptive139Third138Proof70 : runCachedNode 511 129184 Adaptive139Third138Node70 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 129184 Adaptive139Third138Node70 = [104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 125, 126, 127, 128, 130, 131] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive139Third138Proof71
  · exact adaptive139Third138Proof72
  · exact adaptive139Third138Proof73
  · exact adaptive139Third138Proof74
  · exact adaptive139Third138Proof75
  · exact adaptive139Third138Proof76
  · exact adaptive139Third138Proof77
  · exact adaptive139Third138Proof78
  · exact adaptive139Third138Proof79
  · exact adaptive139Third138Proof80
  · exact adaptive139Third138Proof81
  · exact adaptive139Third138Proof82
  · exact adaptive139Third138Proof83
  · exact adaptive139Third138Proof84
  · exact adaptive139Third138Proof85
  · exact adaptive139Third138Proof86
  · exact adaptive139Third138Proof87
  · exact adaptive139Third138Proof88
  · exact adaptive139Third138Proof89
  · exact adaptive139Third138Proof90
  · exact adaptive139Third138Proof91
  · exact adaptive139Third138Proof92
  · exact adaptive139Third138Proof93
  · exact adaptive139Third138Proof94
  · exact adaptive139Third138Proof95

#print axioms adaptive139Third138Proof70

theorem adaptive139Third138Proof96 : runCachedNode 511 129184 Adaptive139Third138Node96 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 129184 Adaptive139Third138Node96 = [103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 126, 127, 128, 130, 131, 132] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive139Third138Proof97
  · exact adaptive139Third138Proof98
  · exact adaptive139Third138Proof99
  · exact adaptive139Third138Proof100
  · exact adaptive139Third138Proof101
  · exact adaptive139Third138Proof102
  · exact adaptive139Third138Proof103
  · exact adaptive139Third138Proof104
  · exact adaptive139Third138Proof105
  · exact adaptive139Third138Proof106
  · exact adaptive139Third138Proof107
  · exact adaptive139Third138Proof108
  · exact adaptive139Third138Proof109
  · exact adaptive139Third138Proof110
  · exact adaptive139Third138Proof111
  · exact adaptive139Third138Proof112
  · exact adaptive139Third138Proof113
  · exact adaptive139Third138Proof114
  · exact adaptive139Third138Proof115
  · exact adaptive139Third138Proof116
  · exact adaptive139Third138Proof117
  · exact adaptive139Third138Proof118
  · exact adaptive139Third138Proof119
  · exact adaptive139Third138Proof120
  · exact adaptive139Third138Proof121
  · exact adaptive139Third138Proof122
  · exact adaptive139Third138Proof123

#print axioms adaptive139Third138Proof96

theorem adaptive139Third138Proof124 : runCachedNode 511 129184 Adaptive139Third138Node124 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 129184 Adaptive139Third138Node124 = [103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 127, 128, 130, 131, 132, 133] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive139Third138Proof125
  · exact adaptive139Third138Proof126
  · exact adaptive139Third138Proof127
  · exact adaptive139Third138Proof128
  · exact adaptive139Third138Proof129
  · exact adaptive139Third138Proof130
  · exact adaptive139Third138Proof131
  · exact adaptive139Third138Proof132
  · exact adaptive139Third138Proof133
  · exact adaptive139Third138Proof134
  · exact adaptive139Third138Proof135
  · exact adaptive139Third138Proof136
  · exact adaptive139Third138Proof137
  · exact adaptive139Third138Proof138
  · exact adaptive139Third138Proof139
  · exact adaptive139Third138Proof140
  · exact adaptive139Third138Proof141
  · exact adaptive139Third138Proof142
  · exact adaptive139Third138Proof143
  · exact adaptive139Third138Proof144
  · exact adaptive139Third138Proof145
  · exact adaptive139Third138Proof146
  · exact adaptive139Third138Proof147
  · exact adaptive139Third138Proof148
  · exact adaptive139Third138Proof149
  · exact adaptive139Third138Proof150
  · exact adaptive139Third138Proof151
  · exact adaptive139Third138Proof152

#print axioms adaptive139Third138Proof124

theorem adaptive139Third138Proof153 : runCachedNode 511 129184 Adaptive139Third138Node153 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 129184 Adaptive139Third138Node153 = [103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 128, 130, 131, 132, 133, 134] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive139Third138Proof154
  · exact adaptive139Third138Proof155
  · exact adaptive139Third138Proof156
  · exact adaptive139Third138Proof157
  · exact adaptive139Third138Proof158
  · exact adaptive139Third138Proof159
  · exact adaptive139Third138Proof160
  · exact adaptive139Third138Proof161
  · exact adaptive139Third138Proof162
  · exact adaptive139Third138Proof163
  · exact adaptive139Third138Proof164
  · exact adaptive139Third138Proof165
  · exact adaptive139Third138Proof166
  · exact adaptive139Third138Proof167
  · exact adaptive139Third138Proof168
  · exact adaptive139Third138Proof169
  · exact adaptive139Third138Proof170
  · exact adaptive139Third138Proof171
  · exact adaptive139Third138Proof172
  · exact adaptive139Third138Proof173
  · exact adaptive139Third138Proof174
  · exact adaptive139Third138Proof175
  · exact adaptive139Third138Proof176
  · exact adaptive139Third138Proof177
  · exact adaptive139Third138Proof178
  · exact adaptive139Third138Proof179
  · exact adaptive139Third138Proof180
  · exact adaptive139Third138Proof181
  · exact adaptive139Third138Proof182

#print axioms adaptive139Third138Proof153

theorem adaptive139Third138Proof213 : runCachedNode 511 129184 Adaptive139Third138Node213 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 129184 Adaptive139Third138Node213 = [91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 130, 132] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive139Third138Proof214
  · exact adaptive139Third138Proof215
  · exact adaptive139Third138Proof216
  · exact adaptive139Third138Proof217
  · exact adaptive139Third138Proof218
  · exact adaptive139Third138Proof219
  · exact adaptive139Third138Proof220
  · exact adaptive139Third138Proof221
  · exact adaptive139Third138Proof222
  · exact adaptive139Third138Proof223
  · exact adaptive139Third138Proof224
  · exact adaptive139Third138Proof225
  · exact adaptive139Third138Proof226
  · exact adaptive139Third138Proof227
  · exact adaptive139Third138Proof228
  · exact adaptive139Third138Proof229
  · exact adaptive139Third138Proof230
  · exact adaptive139Third138Proof231
  · exact adaptive139Third138Proof232
  · exact adaptive139Third138Proof233
  · exact adaptive139Third138Proof234
  · exact adaptive139Third138Proof235
  · exact adaptive139Third138Proof236
  · exact adaptive139Third138Proof237
  · exact adaptive139Third138Proof238
  · exact adaptive139Third138Proof239
  · exact adaptive139Third138Proof240
  · exact adaptive139Third138Proof241
  · exact adaptive139Third138Proof242
  · exact adaptive139Third138Proof243
  · exact adaptive139Third138Proof244
  · exact adaptive139Third138Proof245
  · exact adaptive139Third138Proof246
  · exact adaptive139Third138Proof247

#print axioms adaptive139Third138Proof213

theorem adaptive139Third138Proof183 : runCachedNode 511 129184 Adaptive139Third138Node183 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 129184 Adaptive139Third138Node183 = [103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 130, 131, 132, 133, 134, 135] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive139Third138Proof184
  · exact adaptive139Third138Proof185
  · exact adaptive139Third138Proof186
  · exact adaptive139Third138Proof187
  · exact adaptive139Third138Proof188
  · exact adaptive139Third138Proof189
  · exact adaptive139Third138Proof190
  · exact adaptive139Third138Proof191
  · exact adaptive139Third138Proof192
  · exact adaptive139Third138Proof193
  · exact adaptive139Third138Proof194
  · exact adaptive139Third138Proof195
  · exact adaptive139Third138Proof196
  · exact adaptive139Third138Proof197
  · exact adaptive139Third138Proof198
  · exact adaptive139Third138Proof199
  · exact adaptive139Third138Proof200
  · exact adaptive139Third138Proof201
  · exact adaptive139Third138Proof202
  · exact adaptive139Third138Proof203
  · exact adaptive139Third138Proof204
  · exact adaptive139Third138Proof205
  · exact adaptive139Third138Proof206
  · exact adaptive139Third138Proof207
  · exact adaptive139Third138Proof208
  · exact adaptive139Third138Proof209
  · exact adaptive139Third138Proof210
  · exact adaptive139Third138Proof211
  · exact adaptive139Third138Proof212
  · exact adaptive139Third138Proof213

#print axioms adaptive139Third138Proof183

end NineSeparatedSubsetSums
