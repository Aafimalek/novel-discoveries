import NineSeparatedSubsetSums.Adaptive139Third105Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint139Checked

namespace NineSeparatedSubsetSums


theorem adaptive139Third105 : NoDescendingTailAfterThird 139 105 :=
  noDescendingThirdTail_of_cached 139 105 111380 (fun t ht nd => max148_second139_fourPoint_moment_bound (105::t) (by simp [ht]) nd) adaptive139Third105Proof0

#print axioms adaptive139Third105

end NineSeparatedSubsetSums
