import NineSeparatedSubsetSums.Adaptive139Third133State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third133Proof42 : runCachedNode 511 128283 Adaptive139Third133Node42 = false := by
  decide +kernel

#print axioms adaptive139Third133Proof42

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third133Proof66 : runCachedNode 511 128283 Adaptive139Third133Node66 = false := by
  decide +kernel

#print axioms adaptive139Third133Proof66

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third133Proof47 : runCachedNode 511 128283 Adaptive139Third133Node47 = false := by
  decide +kernel

#print axioms adaptive139Third133Proof47

end NineSeparatedSubsetSums
