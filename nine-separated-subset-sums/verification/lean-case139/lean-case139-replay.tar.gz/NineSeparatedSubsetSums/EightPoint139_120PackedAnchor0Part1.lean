import NineSeparatedSubsetSums.EightPoint139_120PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint139_120PackedAnchor0Part1 :
    ∀ j : Fin 120, 2336219 ≤ FourPointNumeric.octPackedCharge 139 120 20 packedOct139_120_0
      (2*((j.val : Int)+120)+1) := by decide +kernel

end NineSeparatedSubsetSums
