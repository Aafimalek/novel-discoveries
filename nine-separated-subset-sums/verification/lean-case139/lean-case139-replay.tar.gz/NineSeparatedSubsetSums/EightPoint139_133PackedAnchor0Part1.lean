import NineSeparatedSubsetSums.EightPoint139_133PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint139_133PackedAnchor0Part1 :
    ∀ j : Fin 120, 2426723 ≤ FourPointNumeric.octPackedCharge 139 133 20 packedOct139_133_0
      (2*((j.val : Int)+120)+0) := by decide +kernel

end NineSeparatedSubsetSums
