import NineSeparatedSubsetSums.EightPoint139_132PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct139_132_0_budget :
    FourPointNumeric.packedBudget 20 packedOct139_132_0 429 = 89793943 := by decide +kernel

#print axioms packedOct139_132_0_budget

end NineSeparatedSubsetSums
