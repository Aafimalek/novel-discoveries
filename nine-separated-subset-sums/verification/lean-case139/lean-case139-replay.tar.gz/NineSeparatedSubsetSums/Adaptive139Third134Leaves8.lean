import NineSeparatedSubsetSums.Adaptive139Third134State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third134Proof46 : runCachedNode 511 128469 Adaptive139Third134Node46 = false := by
  decide +kernel

#print axioms adaptive139Third134Proof46

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third134Proof70 : runCachedNode 511 128469 Adaptive139Third134Node70 = false := by
  decide +kernel

#print axioms adaptive139Third134Proof70

end NineSeparatedSubsetSums
