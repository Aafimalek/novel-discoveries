import NineSeparatedSubsetSums.Adaptive139Third136State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third136Proof38 : runCachedNode 511 128827 Adaptive139Third136Node38 = false := by
  decide +kernel

#print axioms adaptive139Third136Proof38

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third136Proof119 : runCachedNode 511 128827 Adaptive139Third136Node119 = false := by
  decide +kernel

#print axioms adaptive139Third136Proof119

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third136Proof68 : runCachedNode 511 128827 Adaptive139Third136Node68 = false := by
  decide +kernel

#print axioms adaptive139Third136Proof68

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third136Proof93 : runCachedNode 511 128827 Adaptive139Third136Node93 = false := by
  decide +kernel

#print axioms adaptive139Third136Proof93

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third136Proof77 : runCachedNode 511 128827 Adaptive139Third136Node77 = false := by
  decide +kernel

#print axioms adaptive139Third136Proof77

end NineSeparatedSubsetSums
