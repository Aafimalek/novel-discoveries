import NineSeparatedSubsetSums.FourPoint139PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedWeight139_0_budget :
    FourPointNumeric.packedBudget 20 packedWeight139_0 377 = 79106624 := by decide +kernel

#print axioms packedWeight139_0_budget

end NineSeparatedSubsetSums
