import NineSeparatedSubsetSums.EightPoint139_122PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint139_122PackedAnchor0Part0 :
    ∀ j : Fin 120, 2403095 ≤ FourPointNumeric.octPackedCharge 139 122 20 packedOct139_122_0
      (2*((j.val : Int)+0)+1) := by decide +kernel

end NineSeparatedSubsetSums
