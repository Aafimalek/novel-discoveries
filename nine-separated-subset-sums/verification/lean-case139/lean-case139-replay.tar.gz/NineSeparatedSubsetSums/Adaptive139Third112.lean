import NineSeparatedSubsetSums.Adaptive139Third112Leaves0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint139Checked

namespace NineSeparatedSubsetSums


theorem adaptive139Third112 : NoDescendingTailAfterThird 139 112 :=
  noDescendingThirdTail_of_cached 139 112 111380 (fun t ht nd => max148_second139_fourPoint_moment_bound (112::t) (by simp [ht]) nd) adaptive139Third112Proof0

#print axioms adaptive139Third112

end NineSeparatedSubsetSums
