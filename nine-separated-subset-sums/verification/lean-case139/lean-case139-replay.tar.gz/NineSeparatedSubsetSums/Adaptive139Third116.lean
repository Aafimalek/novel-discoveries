import NineSeparatedSubsetSums.Adaptive139Third116Joins0
import NineSeparatedSubsetSums.CachedFixedThird
import NineSeparatedSubsetSums.FourPoint139Checked

namespace NineSeparatedSubsetSums


theorem adaptive139Third116 : NoDescendingTailAfterThird 139 116 :=
  noDescendingThirdTail_of_cached 139 116 111380 (fun t ht nd => max148_second139_fourPoint_moment_bound (116::t) (by simp [ht]) nd) adaptive139Third116Proof0

#print axioms adaptive139Third116

end NineSeparatedSubsetSums
