import NineSeparatedSubsetSums.EightPoint139_126PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct139_126_0_budget :
    FourPointNumeric.packedBudget 20 packedOct139_126_0 353 = 84054642 := by decide +kernel

#print axioms packedOct139_126_0_budget

end NineSeparatedSubsetSums
