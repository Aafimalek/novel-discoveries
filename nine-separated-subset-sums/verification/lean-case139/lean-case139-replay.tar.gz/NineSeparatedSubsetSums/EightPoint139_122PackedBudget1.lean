import NineSeparatedSubsetSums.EightPoint139_122PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct139_122_1_budget :
    FourPointNumeric.packedBudget 20 packedOct139_122_1 378 = 89418014 := by decide +kernel

#print axioms packedOct139_122_1_budget

end NineSeparatedSubsetSums
