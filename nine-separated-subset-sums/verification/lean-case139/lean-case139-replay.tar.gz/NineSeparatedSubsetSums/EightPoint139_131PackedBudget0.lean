import NineSeparatedSubsetSums.EightPoint139_131PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct139_131_0_budget :
    FourPointNumeric.packedBudget 20 packedOct139_131_0 265 = 90397813 := by decide +kernel

#print axioms packedOct139_131_0_budget

end NineSeparatedSubsetSums
