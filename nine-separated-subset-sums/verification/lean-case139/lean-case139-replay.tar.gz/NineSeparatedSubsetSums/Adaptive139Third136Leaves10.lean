import NineSeparatedSubsetSums.Adaptive139Third136State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third136Proof142 : runCachedNode 511 128827 Adaptive139Third136Node142 = false := by
  decide +kernel

#print axioms adaptive139Third136Proof142

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third136Proof10 : runCachedNode 511 128827 Adaptive139Third136Node10 = false := by
  decide +kernel

#print axioms adaptive139Third136Proof10

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third136Proof85 : runCachedNode 511 128827 Adaptive139Third136Node85 = false := by
  decide +kernel

#print axioms adaptive139Third136Proof85

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third136Proof116 : runCachedNode 511 128827 Adaptive139Third136Node116 = false := by
  decide +kernel

#print axioms adaptive139Third136Proof116

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third136Proof9 : runCachedNode 511 128827 Adaptive139Third136Node9 = false := by
  decide +kernel

#print axioms adaptive139Third136Proof9

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third136Proof37 : runCachedNode 511 128827 Adaptive139Third136Node37 = false := by
  decide +kernel

#print axioms adaptive139Third136Proof37

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third136Proof112 : runCachedNode 511 128827 Adaptive139Third136Node112 = false := by
  decide +kernel

#print axioms adaptive139Third136Proof112

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third136Proof114 : runCachedNode 511 128827 Adaptive139Third136Node114 = false := by
  decide +kernel

#print axioms adaptive139Third136Proof114

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third136Proof140 : runCachedNode 511 128827 Adaptive139Third136Node140 = false := by
  decide +kernel

#print axioms adaptive139Third136Proof140

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third136Proof36 : runCachedNode 511 128827 Adaptive139Third136Node36 = false := by
  decide +kernel

#print axioms adaptive139Third136Proof36

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third136Proof62 : runCachedNode 511 128827 Adaptive139Third136Node62 = false := by
  decide +kernel

#print axioms adaptive139Third136Proof62

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third136Proof35 : runCachedNode 511 128827 Adaptive139Third136Node35 = false := by
  decide +kernel

#print axioms adaptive139Third136Proof35

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third136Proof83 : runCachedNode 511 128827 Adaptive139Third136Node83 = false := by
  decide +kernel

#print axioms adaptive139Third136Proof83

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third136Proof8 : runCachedNode 511 128827 Adaptive139Third136Node8 = false := by
  decide +kernel

#print axioms adaptive139Third136Proof8

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third136Proof82 : runCachedNode 511 128827 Adaptive139Third136Node82 = false := by
  decide +kernel

#print axioms adaptive139Third136Proof82

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third136Proof111 : runCachedNode 511 128827 Adaptive139Third136Node111 = false := by
  decide +kernel

#print axioms adaptive139Third136Proof111

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third136Proof31 : runCachedNode 511 128827 Adaptive139Third136Node31 = false := by
  decide +kernel

#print axioms adaptive139Third136Proof31

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third136Proof34 : runCachedNode 511 128827 Adaptive139Third136Node34 = false := by
  decide +kernel

#print axioms adaptive139Third136Proof34

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third136Proof60 : runCachedNode 511 128827 Adaptive139Third136Node60 = false := by
  decide +kernel

#print axioms adaptive139Third136Proof60

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third136Proof7 : runCachedNode 511 128827 Adaptive139Third136Node7 = false := by
  decide +kernel

#print axioms adaptive139Third136Proof7

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third136Proof141 : runCachedNode 511 128827 Adaptive139Third136Node141 = false := by
  decide +kernel

#print axioms adaptive139Third136Proof141

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third136Proof33 : runCachedNode 511 128827 Adaptive139Third136Node33 = false := by
  decide +kernel

#print axioms adaptive139Third136Proof33

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third136Proof113 : runCachedNode 511 128827 Adaptive139Third136Node113 = false := by
  decide +kernel

#print axioms adaptive139Third136Proof113

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third136Proof32 : runCachedNode 511 128827 Adaptive139Third136Node32 = false := by
  decide +kernel

#print axioms adaptive139Third136Proof32

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third136Proof110 : runCachedNode 511 128827 Adaptive139Third136Node110 = false := by
  decide +kernel

#print axioms adaptive139Third136Proof110

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third136Proof138 : runCachedNode 511 128827 Adaptive139Third136Node138 = false := by
  decide +kernel

#print axioms adaptive139Third136Proof138

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third136Proof80 : runCachedNode 511 128827 Adaptive139Third136Node80 = false := by
  decide +kernel

#print axioms adaptive139Third136Proof80

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third136Proof78 : runCachedNode 511 128827 Adaptive139Third136Node78 = false := by
  decide +kernel

#print axioms adaptive139Third136Proof78

end NineSeparatedSubsetSums
