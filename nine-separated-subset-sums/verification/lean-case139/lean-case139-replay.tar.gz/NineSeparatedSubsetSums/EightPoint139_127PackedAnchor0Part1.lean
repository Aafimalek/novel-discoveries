import NineSeparatedSubsetSums.EightPoint139_127PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint139_127PackedAnchor0Part1 :
    ∀ j : Fin 120, 2349148 ≤ FourPointNumeric.octPackedCharge 139 127 20 packedOct139_127_0
      (2*((j.val : Int)+120)+0) := by decide +kernel

end NineSeparatedSubsetSums
