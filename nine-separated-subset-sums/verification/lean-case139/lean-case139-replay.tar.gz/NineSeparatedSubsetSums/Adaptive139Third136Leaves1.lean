import NineSeparatedSubsetSums.Adaptive139Third136State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third136Proof121 : runCachedNode 511 128827 Adaptive139Third136Node121 = false := by
  decide +kernel

#print axioms adaptive139Third136Proof121

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third136Proof150 : runCachedNode 511 128827 Adaptive139Third136Node150 = false := by
  decide +kernel

#print axioms adaptive139Third136Proof150

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third136Proof59 : runCachedNode 511 128827 Adaptive139Third136Node59 = false := by
  decide +kernel

#print axioms adaptive139Third136Proof59

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third136Proof123 : runCachedNode 511 128827 Adaptive139Third136Node123 = false := by
  decide +kernel

#print axioms adaptive139Third136Proof123

end NineSeparatedSubsetSums
