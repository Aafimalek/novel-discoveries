import NineSeparatedSubsetSums.Adaptive139Third137State
import NineSeparatedSubsetSums.Adaptive139Third137Leaves15
import NineSeparatedSubsetSums.Adaptive139Third137Leaves14
import NineSeparatedSubsetSums.Adaptive139Third137Leaves13
import NineSeparatedSubsetSums.Adaptive139Third137Leaves3
import NineSeparatedSubsetSums.Adaptive139Third137Leaves12
import NineSeparatedSubsetSums.Adaptive139Third137Leaves11
import NineSeparatedSubsetSums.Adaptive139Third137Leaves5
import NineSeparatedSubsetSums.Adaptive139Third137Leaves10
import NineSeparatedSubsetSums.Adaptive139Third137Leaves8
import NineSeparatedSubsetSums.Adaptive139Third137Leaves7
import NineSeparatedSubsetSums.Adaptive139Third137Leaves1
import NineSeparatedSubsetSums.Adaptive139Third137Leaves4
import NineSeparatedSubsetSums.Adaptive139Third137Leaves9
import NineSeparatedSubsetSums.Adaptive139Third137Leaves0
import NineSeparatedSubsetSums.Adaptive139Third137Leaves2
import NineSeparatedSubsetSums.Adaptive139Third137Leaves6

namespace NineSeparatedSubsetSums

theorem adaptive139Third137Proof20 : runCachedNode 511 129004 Adaptive139Third137Node20 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 129004 Adaptive139Third137Node20 = [105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 120, 122, 123, 124, 125, 126, 127, 129] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive139Third137Proof21
  · exact adaptive139Third137Proof22
  · exact adaptive139Third137Proof23
  · exact adaptive139Third137Proof24
  · exact adaptive139Third137Proof25
  · exact adaptive139Third137Proof26
  · exact adaptive139Third137Proof27
  · exact adaptive139Third137Proof28
  · exact adaptive139Third137Proof29
  · exact adaptive139Third137Proof30
  · exact adaptive139Third137Proof31
  · exact adaptive139Third137Proof32
  · exact adaptive139Third137Proof33
  · exact adaptive139Third137Proof34
  · exact adaptive139Third137Proof35
  · exact adaptive139Third137Proof36
  · exact adaptive139Third137Proof37
  · exact adaptive139Third137Proof38
  · exact adaptive139Third137Proof39
  · exact adaptive139Third137Proof40
  · exact adaptive139Third137Proof41
  · exact adaptive139Third137Proof42

#print axioms adaptive139Third137Proof20

theorem adaptive139Third137Proof45 : runCachedNode 511 129004 Adaptive139Third137Node45 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 129004 Adaptive139Third137Node45 = [104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 123, 125, 126, 127, 129, 130, 132] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive139Third137Proof46
  · exact adaptive139Third137Proof47
  · exact adaptive139Third137Proof48
  · exact adaptive139Third137Proof49
  · exact adaptive139Third137Proof50
  · exact adaptive139Third137Proof51
  · exact adaptive139Third137Proof52
  · exact adaptive139Third137Proof53
  · exact adaptive139Third137Proof54
  · exact adaptive139Third137Proof55
  · exact adaptive139Third137Proof56
  · exact adaptive139Third137Proof57
  · exact adaptive139Third137Proof58
  · exact adaptive139Third137Proof59
  · exact adaptive139Third137Proof60
  · exact adaptive139Third137Proof61
  · exact adaptive139Third137Proof62
  · exact adaptive139Third137Proof63
  · exact adaptive139Third137Proof64
  · exact adaptive139Third137Proof65
  · exact adaptive139Third137Proof66
  · exact adaptive139Third137Proof67
  · exact adaptive139Third137Proof68
  · exact adaptive139Third137Proof69
  · exact adaptive139Third137Proof70

#print axioms adaptive139Third137Proof45

theorem adaptive139Third137Proof71 : runCachedNode 511 129004 Adaptive139Third137Node71 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 129004 Adaptive139Third137Node71 = [104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 124, 126, 127, 129, 130, 131, 133] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive139Third137Proof72
  · exact adaptive139Third137Proof73
  · exact adaptive139Third137Proof74
  · exact adaptive139Third137Proof75
  · exact adaptive139Third137Proof76
  · exact adaptive139Third137Proof77
  · exact adaptive139Third137Proof78
  · exact adaptive139Third137Proof79
  · exact adaptive139Third137Proof80
  · exact adaptive139Third137Proof81
  · exact adaptive139Third137Proof82
  · exact adaptive139Third137Proof83
  · exact adaptive139Third137Proof84
  · exact adaptive139Third137Proof85
  · exact adaptive139Third137Proof86
  · exact adaptive139Third137Proof87
  · exact adaptive139Third137Proof88
  · exact adaptive139Third137Proof89
  · exact adaptive139Third137Proof90
  · exact adaptive139Third137Proof91
  · exact adaptive139Third137Proof92
  · exact adaptive139Third137Proof93
  · exact adaptive139Third137Proof94
  · exact adaptive139Third137Proof95
  · exact adaptive139Third137Proof96
  · exact adaptive139Third137Proof97

#print axioms adaptive139Third137Proof71

theorem adaptive139Third137Proof98 : runCachedNode 511 129004 Adaptive139Third137Node98 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 129004 Adaptive139Third137Node98 = [103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 125, 127, 129, 130, 131, 132, 134] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive139Third137Proof99
  · exact adaptive139Third137Proof100
  · exact adaptive139Third137Proof101
  · exact adaptive139Third137Proof102
  · exact adaptive139Third137Proof103
  · exact adaptive139Third137Proof104
  · exact adaptive139Third137Proof105
  · exact adaptive139Third137Proof106
  · exact adaptive139Third137Proof107
  · exact adaptive139Third137Proof108
  · exact adaptive139Third137Proof109
  · exact adaptive139Third137Proof110
  · exact adaptive139Third137Proof111
  · exact adaptive139Third137Proof112
  · exact adaptive139Third137Proof113
  · exact adaptive139Third137Proof114
  · exact adaptive139Third137Proof115
  · exact adaptive139Third137Proof116
  · exact adaptive139Third137Proof117
  · exact adaptive139Third137Proof118
  · exact adaptive139Third137Proof119
  · exact adaptive139Third137Proof120
  · exact adaptive139Third137Proof121
  · exact adaptive139Third137Proof122
  · exact adaptive139Third137Proof123
  · exact adaptive139Third137Proof124
  · exact adaptive139Third137Proof125
  · exact adaptive139Third137Proof126

#print axioms adaptive139Third137Proof98

theorem adaptive139Third137Proof156 : runCachedNode 511 129004 Adaptive139Third137Node156 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 129004 Adaptive139Third137Node156 = [92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 122, 130, 131] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive139Third137Proof157
  · exact adaptive139Third137Proof158
  · exact adaptive139Third137Proof159
  · exact adaptive139Third137Proof160
  · exact adaptive139Third137Proof161
  · exact adaptive139Third137Proof162
  · exact adaptive139Third137Proof163
  · exact adaptive139Third137Proof164
  · exact adaptive139Third137Proof165
  · exact adaptive139Third137Proof166
  · exact adaptive139Third137Proof167
  · exact adaptive139Third137Proof168
  · exact adaptive139Third137Proof169
  · exact adaptive139Third137Proof170
  · exact adaptive139Third137Proof171
  · exact adaptive139Third137Proof172
  · exact adaptive139Third137Proof173
  · exact adaptive139Third137Proof174
  · exact adaptive139Third137Proof175
  · exact adaptive139Third137Proof176
  · exact adaptive139Third137Proof177
  · exact adaptive139Third137Proof178
  · exact adaptive139Third137Proof179
  · exact adaptive139Third137Proof180
  · exact adaptive139Third137Proof181
  · exact adaptive139Third137Proof182
  · exact adaptive139Third137Proof183
  · exact adaptive139Third137Proof184
  · exact adaptive139Third137Proof185
  · exact adaptive139Third137Proof186
  · exact adaptive139Third137Proof187
  · exact adaptive139Third137Proof188

#print axioms adaptive139Third137Proof156

theorem adaptive139Third137Proof127 : runCachedNode 511 129004 Adaptive139Third137Node127 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 129004 Adaptive139Third137Node127 = [103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 126, 129, 130, 131, 132, 133, 135] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive139Third137Proof128
  · exact adaptive139Third137Proof129
  · exact adaptive139Third137Proof130
  · exact adaptive139Third137Proof131
  · exact adaptive139Third137Proof132
  · exact adaptive139Third137Proof133
  · exact adaptive139Third137Proof134
  · exact adaptive139Third137Proof135
  · exact adaptive139Third137Proof136
  · exact adaptive139Third137Proof137
  · exact adaptive139Third137Proof138
  · exact adaptive139Third137Proof139
  · exact adaptive139Third137Proof140
  · exact adaptive139Third137Proof141
  · exact adaptive139Third137Proof142
  · exact adaptive139Third137Proof143
  · exact adaptive139Third137Proof144
  · exact adaptive139Third137Proof145
  · exact adaptive139Third137Proof146
  · exact adaptive139Third137Proof147
  · exact adaptive139Third137Proof148
  · exact adaptive139Third137Proof149
  · exact adaptive139Third137Proof150
  · exact adaptive139Third137Proof151
  · exact adaptive139Third137Proof152
  · exact adaptive139Third137Proof153
  · exact adaptive139Third137Proof154
  · exact adaptive139Third137Proof155
  · exact adaptive139Third137Proof156

#print axioms adaptive139Third137Proof127

theorem adaptive139Third137Proof0 : runCachedNode 511 129004 Adaptive139Third137Node0 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 129004 Adaptive139Third137Node0 = [110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 129, 130, 131, 132, 133, 134, 135, 136] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive139Third137Proof1
  · exact adaptive139Third137Proof2
  · exact adaptive139Third137Proof3
  · exact adaptive139Third137Proof4
  · exact adaptive139Third137Proof5
  · exact adaptive139Third137Proof6
  · exact adaptive139Third137Proof7
  · exact adaptive139Third137Proof8
  · exact adaptive139Third137Proof9
  · exact adaptive139Third137Proof10
  · exact adaptive139Third137Proof11
  · exact adaptive139Third137Proof12
  · exact adaptive139Third137Proof13
  · exact adaptive139Third137Proof14
  · exact adaptive139Third137Proof15
  · exact adaptive139Third137Proof16
  · exact adaptive139Third137Proof17
  · exact adaptive139Third137Proof18
  · exact adaptive139Third137Proof19
  · exact adaptive139Third137Proof20
  · exact adaptive139Third137Proof43
  · exact adaptive139Third137Proof44
  · exact adaptive139Third137Proof45
  · exact adaptive139Third137Proof71
  · exact adaptive139Third137Proof98
  · exact adaptive139Third137Proof127

#print axioms adaptive139Third137Proof0

end NineSeparatedSubsetSums
