import NineSeparatedSubsetSums.EightPoint139_128PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint139_128PackedAnchor0Part1 :
    ∀ j : Fin 120, 2366890 ≤ FourPointNumeric.octPackedCharge 139 128 20 packedOct139_128_0
      (2*((j.val : Int)+120)+1) := by decide +kernel

end NineSeparatedSubsetSums
