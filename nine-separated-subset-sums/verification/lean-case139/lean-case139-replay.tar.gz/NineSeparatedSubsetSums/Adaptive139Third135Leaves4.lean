import NineSeparatedSubsetSums.Adaptive139Third135State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third135Proof88 : runCachedNode 511 128672 Adaptive139Third135Node88 = false := by
  decide +kernel

#print axioms adaptive139Third135Proof88

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third135Proof140 : runCachedNode 511 128672 Adaptive139Third135Node140 = false := by
  decide +kernel

#print axioms adaptive139Third135Proof140

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third135Proof142 : runCachedNode 511 128672 Adaptive139Third135Node142 = false := by
  decide +kernel

#print axioms adaptive139Third135Proof142

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third135Proof41 : runCachedNode 511 128672 Adaptive139Third135Node41 = false := by
  decide +kernel

#print axioms adaptive139Third135Proof41

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third135Proof14 : runCachedNode 511 128672 Adaptive139Third135Node14 = false := by
  decide +kernel

#print axioms adaptive139Third135Proof14

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third135Proof71 : runCachedNode 511 128672 Adaptive139Third135Node71 = false := by
  decide +kernel

#print axioms adaptive139Third135Proof71

end NineSeparatedSubsetSums
