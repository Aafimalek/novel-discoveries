import NineSeparatedSubsetSums.Adaptive139Third135State
import NineSeparatedSubsetSums.Adaptive139Third135Leaves9
import NineSeparatedSubsetSums.Adaptive139Third135Leaves8
import NineSeparatedSubsetSums.Adaptive139Third135Leaves7
import NineSeparatedSubsetSums.Adaptive139Third135Leaves6
import NineSeparatedSubsetSums.Adaptive139Third135Leaves5
import NineSeparatedSubsetSums.Adaptive139Third135Leaves4
import NineSeparatedSubsetSums.Adaptive139Third135Leaves0
import NineSeparatedSubsetSums.Adaptive139Third135Leaves3
import NineSeparatedSubsetSums.Adaptive139Third135Leaves10
import NineSeparatedSubsetSums.Adaptive139Third135Leaves1
import NineSeparatedSubsetSums.Adaptive139Third135Leaves2

namespace NineSeparatedSubsetSums

theorem adaptive139Third135Proof20 : runCachedNode 511 128672 Adaptive139Third135Node20 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 128672 Adaptive139Third135Node20 = [105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 118, 119, 120, 122, 123, 124, 125, 127, 128, 129] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive139Third135Proof21
  · exact adaptive139Third135Proof22
  · exact adaptive139Third135Proof23
  · exact adaptive139Third135Proof24
  · exact adaptive139Third135Proof25
  · exact adaptive139Third135Proof26
  · exact adaptive139Third135Proof27
  · exact adaptive139Third135Proof28
  · exact adaptive139Third135Proof29
  · exact adaptive139Third135Proof30
  · exact adaptive139Third135Proof31
  · exact adaptive139Third135Proof32
  · exact adaptive139Third135Proof33
  · exact adaptive139Third135Proof34
  · exact adaptive139Third135Proof35
  · exact adaptive139Third135Proof36
  · exact adaptive139Third135Proof37
  · exact adaptive139Third135Proof38
  · exact adaptive139Third135Proof39
  · exact adaptive139Third135Proof40
  · exact adaptive139Third135Proof41
  · exact adaptive139Third135Proof42

#print axioms adaptive139Third135Proof20

theorem adaptive139Third135Proof43 : runCachedNode 511 128672 Adaptive139Third135Node43 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 128672 Adaptive139Third135Node43 = [105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 119, 120, 121, 123, 124, 125, 128, 129, 130] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive139Third135Proof44
  · exact adaptive139Third135Proof45
  · exact adaptive139Third135Proof46
  · exact adaptive139Third135Proof47
  · exact adaptive139Third135Proof48
  · exact adaptive139Third135Proof49
  · exact adaptive139Third135Proof50
  · exact adaptive139Third135Proof51
  · exact adaptive139Third135Proof52
  · exact adaptive139Third135Proof53
  · exact adaptive139Third135Proof54
  · exact adaptive139Third135Proof55
  · exact adaptive139Third135Proof56
  · exact adaptive139Third135Proof57
  · exact adaptive139Third135Proof58
  · exact adaptive139Third135Proof59
  · exact adaptive139Third135Proof60
  · exact adaptive139Third135Proof61
  · exact adaptive139Third135Proof62
  · exact adaptive139Third135Proof63
  · exact adaptive139Third135Proof64
  · exact adaptive139Third135Proof65

#print axioms adaptive139Third135Proof43

theorem adaptive139Third135Proof66 : runCachedNode 511 128672 Adaptive139Third135Node66 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 128672 Adaptive139Third135Node66 = [104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 120, 121, 122, 124, 125, 127, 129, 130, 131] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive139Third135Proof67
  · exact adaptive139Third135Proof68
  · exact adaptive139Third135Proof69
  · exact adaptive139Third135Proof70
  · exact adaptive139Third135Proof71
  · exact adaptive139Third135Proof72
  · exact adaptive139Third135Proof73
  · exact adaptive139Third135Proof74
  · exact adaptive139Third135Proof75
  · exact adaptive139Third135Proof76
  · exact adaptive139Third135Proof77
  · exact adaptive139Third135Proof78
  · exact adaptive139Third135Proof79
  · exact adaptive139Third135Proof80
  · exact adaptive139Third135Proof81
  · exact adaptive139Third135Proof82
  · exact adaptive139Third135Proof83
  · exact adaptive139Third135Proof84
  · exact adaptive139Third135Proof85
  · exact adaptive139Third135Proof86
  · exact adaptive139Third135Proof87
  · exact adaptive139Third135Proof88
  · exact adaptive139Third135Proof89
  · exact adaptive139Third135Proof90

#print axioms adaptive139Third135Proof66

theorem adaptive139Third135Proof91 : runCachedNode 511 128672 Adaptive139Third135Node91 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 128672 Adaptive139Third135Node91 = [104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 121, 122, 123, 125, 127, 128, 130, 131, 132] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive139Third135Proof92
  · exact adaptive139Third135Proof93
  · exact adaptive139Third135Proof94
  · exact adaptive139Third135Proof95
  · exact adaptive139Third135Proof96
  · exact adaptive139Third135Proof97
  · exact adaptive139Third135Proof98
  · exact adaptive139Third135Proof99
  · exact adaptive139Third135Proof100
  · exact adaptive139Third135Proof101
  · exact adaptive139Third135Proof102
  · exact adaptive139Third135Proof103
  · exact adaptive139Third135Proof104
  · exact adaptive139Third135Proof105
  · exact adaptive139Third135Proof106
  · exact adaptive139Third135Proof107
  · exact adaptive139Third135Proof108
  · exact adaptive139Third135Proof109
  · exact adaptive139Third135Proof110
  · exact adaptive139Third135Proof111
  · exact adaptive139Third135Proof112
  · exact adaptive139Third135Proof113
  · exact adaptive139Third135Proof114
  · exact adaptive139Third135Proof115
  · exact adaptive139Third135Proof116

#print axioms adaptive139Third135Proof91

theorem adaptive139Third135Proof117 : runCachedNode 511 128672 Adaptive139Third135Node117 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 128672 Adaptive139Third135Node117 = [104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 122, 123, 124, 127, 128, 129, 131, 132, 133] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive139Third135Proof118
  · exact adaptive139Third135Proof119
  · exact adaptive139Third135Proof120
  · exact adaptive139Third135Proof121
  · exact adaptive139Third135Proof122
  · exact adaptive139Third135Proof123
  · exact adaptive139Third135Proof124
  · exact adaptive139Third135Proof125
  · exact adaptive139Third135Proof126
  · exact adaptive139Third135Proof127
  · exact adaptive139Third135Proof128
  · exact adaptive139Third135Proof129
  · exact adaptive139Third135Proof130
  · exact adaptive139Third135Proof131
  · exact adaptive139Third135Proof132
  · exact adaptive139Third135Proof133
  · exact adaptive139Third135Proof134
  · exact adaptive139Third135Proof135
  · exact adaptive139Third135Proof136
  · exact adaptive139Third135Proof137
  · exact adaptive139Third135Proof138
  · exact adaptive139Third135Proof139
  · exact adaptive139Third135Proof140
  · exact adaptive139Third135Proof141
  · exact adaptive139Third135Proof142
  · exact adaptive139Third135Proof143

#print axioms adaptive139Third135Proof117

theorem adaptive139Third135Proof0 : runCachedNode 511 128672 Adaptive139Third135Node0 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 128672 Adaptive139Third135Node0 = [110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 127, 128, 129, 130, 131, 132, 133, 134] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive139Third135Proof1
  · exact adaptive139Third135Proof2
  · exact adaptive139Third135Proof3
  · exact adaptive139Third135Proof4
  · exact adaptive139Third135Proof5
  · exact adaptive139Third135Proof6
  · exact adaptive139Third135Proof7
  · exact adaptive139Third135Proof8
  · exact adaptive139Third135Proof9
  · exact adaptive139Third135Proof10
  · exact adaptive139Third135Proof11
  · exact adaptive139Third135Proof12
  · exact adaptive139Third135Proof13
  · exact adaptive139Third135Proof14
  · exact adaptive139Third135Proof15
  · exact adaptive139Third135Proof16
  · exact adaptive139Third135Proof17
  · exact adaptive139Third135Proof18
  · exact adaptive139Third135Proof19
  · exact adaptive139Third135Proof20
  · exact adaptive139Third135Proof43
  · exact adaptive139Third135Proof66
  · exact adaptive139Third135Proof91
  · exact adaptive139Third135Proof117

#print axioms adaptive139Third135Proof0

end NineSeparatedSubsetSums
