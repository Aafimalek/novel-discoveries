import NineSeparatedSubsetSums.Adaptive139Third137State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third137Proof92 : runCachedNode 511 129004 Adaptive139Third137Node92 = false := by
  decide +kernel

#print axioms adaptive139Third137Proof92

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third137Proof12 : runCachedNode 511 129004 Adaptive139Third137Node12 = false := by
  decide +kernel

#print axioms adaptive139Third137Proof12

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third137Proof94 : runCachedNode 511 129004 Adaptive139Third137Node94 = false := by
  decide +kernel

#print axioms adaptive139Third137Proof94

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third137Proof119 : runCachedNode 511 129004 Adaptive139Third137Node119 = false := by
  decide +kernel

#print axioms adaptive139Third137Proof119

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third137Proof116 : runCachedNode 511 129004 Adaptive139Third137Node116 = false := by
  decide +kernel

#print axioms adaptive139Third137Proof116

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third137Proof11 : runCachedNode 511 129004 Adaptive139Third137Node11 = false := by
  decide +kernel

#print axioms adaptive139Third137Proof11

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third137Proof149 : runCachedNode 511 129004 Adaptive139Third137Node149 = false := by
  decide +kernel

#print axioms adaptive139Third137Proof149

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third137Proof186 : runCachedNode 511 129004 Adaptive139Third137Node186 = false := by
  decide +kernel

#print axioms adaptive139Third137Proof186

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third137Proof10 : runCachedNode 511 129004 Adaptive139Third137Node10 = false := by
  decide +kernel

#print axioms adaptive139Third137Proof10

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third137Proof38 : runCachedNode 511 129004 Adaptive139Third137Node38 = false := by
  decide +kernel

#print axioms adaptive139Third137Proof38

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third137Proof117 : runCachedNode 511 129004 Adaptive139Third137Node117 = false := by
  decide +kernel

#print axioms adaptive139Third137Proof117

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third137Proof90 : runCachedNode 511 129004 Adaptive139Third137Node90 = false := by
  decide +kernel

#print axioms adaptive139Third137Proof90

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third137Proof35 : runCachedNode 511 129004 Adaptive139Third137Node35 = false := by
  decide +kernel

#print axioms adaptive139Third137Proof35

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third137Proof88 : runCachedNode 511 129004 Adaptive139Third137Node88 = false := by
  decide +kernel

#print axioms adaptive139Third137Proof88

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third137Proof49 : runCachedNode 511 129004 Adaptive139Third137Node49 = false := by
  decide +kernel

#print axioms adaptive139Third137Proof49

end NineSeparatedSubsetSums
