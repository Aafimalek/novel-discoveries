import NineSeparatedSubsetSums.Adaptive139Third132State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third132Proof37 : runCachedNode 511 128175 Adaptive139Third132Node37 = false := by
  decide +kernel

#print axioms adaptive139Third132Proof37

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third132Proof13 : runCachedNode 511 128175 Adaptive139Third132Node13 = false := by
  decide +kernel

#print axioms adaptive139Third132Proof13

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third132Proof12 : runCachedNode 511 128175 Adaptive139Third132Node12 = false := by
  decide +kernel

#print axioms adaptive139Third132Proof12

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third132Proof38 : runCachedNode 511 128175 Adaptive139Third132Node38 = false := by
  decide +kernel

#print axioms adaptive139Third132Proof38

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third132Proof11 : runCachedNode 511 128175 Adaptive139Third132Node11 = false := by
  decide +kernel

#print axioms adaptive139Third132Proof11

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third132Proof10 : runCachedNode 511 128175 Adaptive139Third132Node10 = false := by
  decide +kernel

#print axioms adaptive139Third132Proof10

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third132Proof9 : runCachedNode 511 128175 Adaptive139Third132Node9 = false := by
  decide +kernel

#print axioms adaptive139Third132Proof9

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third132Proof35 : runCachedNode 511 128175 Adaptive139Third132Node35 = false := by
  decide +kernel

#print axioms adaptive139Third132Proof35

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third132Proof36 : runCachedNode 511 128175 Adaptive139Third132Node36 = false := by
  decide +kernel

#print axioms adaptive139Third132Proof36

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third132Proof8 : runCachedNode 511 128175 Adaptive139Third132Node8 = false := by
  decide +kernel

#print axioms adaptive139Third132Proof8

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third132Proof34 : runCachedNode 511 128175 Adaptive139Third132Node34 = false := by
  decide +kernel

#print axioms adaptive139Third132Proof34

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third132Proof7 : runCachedNode 511 128175 Adaptive139Third132Node7 = false := by
  decide +kernel

#print axioms adaptive139Third132Proof7

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third132Proof33 : runCachedNode 511 128175 Adaptive139Third132Node33 = false := by
  decide +kernel

#print axioms adaptive139Third132Proof33

end NineSeparatedSubsetSums
