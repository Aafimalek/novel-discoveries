import NineSeparatedSubsetSums.Adaptive139Third121State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third121Proof0 : runCachedNode 511 125638 Adaptive139Third121Node0 = false := by
  decide +kernel

#print axioms adaptive139Third121Proof0

end NineSeparatedSubsetSums
