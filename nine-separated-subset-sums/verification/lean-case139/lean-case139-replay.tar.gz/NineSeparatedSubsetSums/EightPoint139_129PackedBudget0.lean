import NineSeparatedSubsetSums.EightPoint139_129PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem packedOct139_129_0_budget :
    FourPointNumeric.packedBudget 20 packedOct139_129_0 453 = 87233412 := by decide +kernel

#print axioms packedOct139_129_0_budget

end NineSeparatedSubsetSums
