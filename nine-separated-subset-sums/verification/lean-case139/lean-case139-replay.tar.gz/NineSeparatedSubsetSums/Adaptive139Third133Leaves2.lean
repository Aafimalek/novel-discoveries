import NineSeparatedSubsetSums.Adaptive139Third133State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third133Proof18 : runCachedNode 511 128283 Adaptive139Third133Node18 = false := by
  decide +kernel

#print axioms adaptive139Third133Proof18

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third133Proof67 : runCachedNode 511 128283 Adaptive139Third133Node67 = false := by
  decide +kernel

#print axioms adaptive139Third133Proof67

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third133Proof40 : runCachedNode 511 128283 Adaptive139Third133Node40 = false := by
  decide +kernel

#print axioms adaptive139Third133Proof40

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third133Proof20 : runCachedNode 511 128283 Adaptive139Third133Node20 = false := by
  decide +kernel

#print axioms adaptive139Third133Proof20

end NineSeparatedSubsetSums
