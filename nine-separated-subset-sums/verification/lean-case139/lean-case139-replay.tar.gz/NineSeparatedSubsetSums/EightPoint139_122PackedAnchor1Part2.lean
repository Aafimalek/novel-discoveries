import NineSeparatedSubsetSums.EightPoint139_122PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint139_122PackedAnchor1Part2 :
    ∀ j : Fin 8, 2403583 ≤ FourPointNumeric.octPackedCharge 139 122 20 packedOct139_122_1
      (2*((j.val : Int)+240)+0) := by decide +kernel

end NineSeparatedSubsetSums
