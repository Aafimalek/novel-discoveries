import NineSeparatedSubsetSums.Adaptive139Third127State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third127Proof5 : runCachedNode 511 127159 Adaptive139Third127Node5 = false := by
  decide +kernel

#print axioms adaptive139Third127Proof5

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third127Proof4 : runCachedNode 511 127159 Adaptive139Third127Node4 = false := by
  decide +kernel

#print axioms adaptive139Third127Proof4

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third127Proof2 : runCachedNode 511 127159 Adaptive139Third127Node2 = false := by
  decide +kernel

#print axioms adaptive139Third127Proof2

end NineSeparatedSubsetSums
