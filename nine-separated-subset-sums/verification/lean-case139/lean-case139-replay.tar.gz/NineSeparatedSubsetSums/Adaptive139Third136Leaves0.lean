import NineSeparatedSubsetSums.Adaptive139Third136State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third136Proof43 : runCachedNode 511 128827 Adaptive139Third136Node43 = false := by
  decide +kernel

#print axioms adaptive139Third136Proof43

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third136Proof92 : runCachedNode 511 128827 Adaptive139Third136Node92 = false := by
  decide +kernel

#print axioms adaptive139Third136Proof92

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third136Proof57 : runCachedNode 511 128827 Adaptive139Third136Node57 = false := by
  decide +kernel

#print axioms adaptive139Third136Proof57

end NineSeparatedSubsetSums
