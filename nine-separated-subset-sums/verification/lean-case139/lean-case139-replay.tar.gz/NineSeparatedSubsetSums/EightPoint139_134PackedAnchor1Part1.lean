import NineSeparatedSubsetSums.EightPoint139_134PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint139_134PackedAnchor1Part1 :
    ∀ j : Fin 120, 2443771 ≤ FourPointNumeric.octPackedCharge 139 134 20 packedOct139_134_1
      (2*((j.val : Int)+120)+0) := by decide +kernel

end NineSeparatedSubsetSums
