import NineSeparatedSubsetSums.Adaptive139Third134State
import NineSeparatedSubsetSums.Adaptive139Third134Leaves5
import NineSeparatedSubsetSums.Adaptive139Third134Leaves0
import NineSeparatedSubsetSums.Adaptive139Third134Leaves7
import NineSeparatedSubsetSums.Adaptive139Third134Leaves6
import NineSeparatedSubsetSums.Adaptive139Third134Leaves4
import NineSeparatedSubsetSums.Adaptive139Third134Leaves3
import NineSeparatedSubsetSums.Adaptive139Third134Leaves8
import NineSeparatedSubsetSums.Adaptive139Third134Leaves1
import NineSeparatedSubsetSums.Adaptive139Third134Leaves2

namespace NineSeparatedSubsetSums

theorem adaptive139Third134Proof20 : runCachedNode 511 128469 Adaptive139Third134Node20 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 128469 Adaptive139Third134Node20 = [105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 117, 118, 119, 120, 122, 123, 124, 126, 127, 128, 129] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive139Third134Proof21
  · exact adaptive139Third134Proof22
  · exact adaptive139Third134Proof23
  · exact adaptive139Third134Proof24
  · exact adaptive139Third134Proof25
  · exact adaptive139Third134Proof26
  · exact adaptive139Third134Proof27
  · exact adaptive139Third134Proof28
  · exact adaptive139Third134Proof29
  · exact adaptive139Third134Proof30
  · exact adaptive139Third134Proof31
  · exact adaptive139Third134Proof32
  · exact adaptive139Third134Proof33
  · exact adaptive139Third134Proof34
  · exact adaptive139Third134Proof35
  · exact adaptive139Third134Proof36
  · exact adaptive139Third134Proof37
  · exact adaptive139Third134Proof38
  · exact adaptive139Third134Proof39
  · exact adaptive139Third134Proof40
  · exact adaptive139Third134Proof41
  · exact adaptive139Third134Proof42

#print axioms adaptive139Third134Proof20

theorem adaptive139Third134Proof44 : runCachedNode 511 128469 Adaptive139Third134Node44 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 128469 Adaptive139Third134Node44 = [104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 119, 120, 121, 122, 124, 126, 128, 129, 130, 131] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive139Third134Proof45
  · exact adaptive139Third134Proof46
  · exact adaptive139Third134Proof47
  · exact adaptive139Third134Proof48
  · exact adaptive139Third134Proof49
  · exact adaptive139Third134Proof50
  · exact adaptive139Third134Proof51
  · exact adaptive139Third134Proof52
  · exact adaptive139Third134Proof53
  · exact adaptive139Third134Proof54
  · exact adaptive139Third134Proof55
  · exact adaptive139Third134Proof56
  · exact adaptive139Third134Proof57
  · exact adaptive139Third134Proof58
  · exact adaptive139Third134Proof59
  · exact adaptive139Third134Proof60
  · exact adaptive139Third134Proof61
  · exact adaptive139Third134Proof62
  · exact adaptive139Third134Proof63
  · exact adaptive139Third134Proof64
  · exact adaptive139Third134Proof65
  · exact adaptive139Third134Proof66
  · exact adaptive139Third134Proof67
  · exact adaptive139Third134Proof68

#print axioms adaptive139Third134Proof44

theorem adaptive139Third134Proof69 : runCachedNode 511 128469 Adaptive139Third134Node69 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 128469 Adaptive139Third134Node69 = [104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 120, 121, 122, 123, 126, 127, 129, 130, 131, 132] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive139Third134Proof70
  · exact adaptive139Third134Proof71
  · exact adaptive139Third134Proof72
  · exact adaptive139Third134Proof73
  · exact adaptive139Third134Proof74
  · exact adaptive139Third134Proof75
  · exact adaptive139Third134Proof76
  · exact adaptive139Third134Proof77
  · exact adaptive139Third134Proof78
  · exact adaptive139Third134Proof79
  · exact adaptive139Third134Proof80
  · exact adaptive139Third134Proof81
  · exact adaptive139Third134Proof82
  · exact adaptive139Third134Proof83
  · exact adaptive139Third134Proof84
  · exact adaptive139Third134Proof85
  · exact adaptive139Third134Proof86
  · exact adaptive139Third134Proof87
  · exact adaptive139Third134Proof88
  · exact adaptive139Third134Proof89
  · exact adaptive139Third134Proof90
  · exact adaptive139Third134Proof91
  · exact adaptive139Third134Proof92
  · exact adaptive139Third134Proof93
  · exact adaptive139Third134Proof94

#print axioms adaptive139Third134Proof69

theorem adaptive139Third134Proof0 : runCachedNode 511 128469 Adaptive139Third134Node0 = false := by
  apply runCachedNode_false_of_children
  · decide +kernel
  intro x hx
  have selected : cachedChildChoices 511 128469 Adaptive139Third134Node0 = [110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 126, 127, 128, 129, 130, 131, 132, 133] := by decide +kernel
  rw [selected] at hx
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hx
  rcases hx with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · exact adaptive139Third134Proof1
  · exact adaptive139Third134Proof2
  · exact adaptive139Third134Proof3
  · exact adaptive139Third134Proof4
  · exact adaptive139Third134Proof5
  · exact adaptive139Third134Proof6
  · exact adaptive139Third134Proof7
  · exact adaptive139Third134Proof8
  · exact adaptive139Third134Proof9
  · exact adaptive139Third134Proof10
  · exact adaptive139Third134Proof11
  · exact adaptive139Third134Proof12
  · exact adaptive139Third134Proof13
  · exact adaptive139Third134Proof14
  · exact adaptive139Third134Proof15
  · exact adaptive139Third134Proof16
  · exact adaptive139Third134Proof17
  · exact adaptive139Third134Proof18
  · exact adaptive139Third134Proof19
  · exact adaptive139Third134Proof20
  · exact adaptive139Third134Proof43
  · exact adaptive139Third134Proof44
  · exact adaptive139Third134Proof69

#print axioms adaptive139Third134Proof0

end NineSeparatedSubsetSums
