import NineSeparatedSubsetSums.Adaptive139Third138State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third138Proof18 : runCachedNode 511 129184 Adaptive139Third138Node18 = false := by
  decide +kernel

#print axioms adaptive139Third138Proof18

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third138Proof17 : runCachedNode 511 129184 Adaptive139Third138Node17 = false := by
  decide +kernel

#print axioms adaptive139Third138Proof17

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third138Proof152 : runCachedNode 511 129184 Adaptive139Third138Node152 = false := by
  decide +kernel

#print axioms adaptive139Third138Proof152

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third138Proof178 : runCachedNode 511 129184 Adaptive139Third138Node178 = false := by
  decide +kernel

#print axioms adaptive139Third138Proof178

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third138Proof81 : runCachedNode 511 129184 Adaptive139Third138Node81 = false := by
  decide +kernel

#print axioms adaptive139Third138Proof81

end NineSeparatedSubsetSums
