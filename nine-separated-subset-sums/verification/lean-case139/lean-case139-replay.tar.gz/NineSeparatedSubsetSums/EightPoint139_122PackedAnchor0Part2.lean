import NineSeparatedSubsetSums.EightPoint139_122PackedTables

namespace NineSeparatedSubsetSums

set_option maxRecDepth 32768 in
set_option maxHeartbeats 70000000 in
theorem eightPoint139_122PackedAnchor0Part2 :
    ∀ j : Fin 7, 2403095 ≤ FourPointNumeric.octPackedCharge 139 122 20 packedOct139_122_0
      (2*((j.val : Int)+240)+1) := by decide +kernel

end NineSeparatedSubsetSums
