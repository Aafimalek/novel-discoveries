import NineSeparatedSubsetSums.Adaptive139Third131State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third131Proof16 : runCachedNode 511 128014 Adaptive139Third131Node16 = false := by
  decide +kernel

#print axioms adaptive139Third131Proof16

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third131Proof41 : runCachedNode 511 128014 Adaptive139Third131Node41 = false := by
  decide +kernel

#print axioms adaptive139Third131Proof41

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third131Proof14 : runCachedNode 511 128014 Adaptive139Third131Node14 = false := by
  decide +kernel

#print axioms adaptive139Third131Proof14

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third131Proof13 : runCachedNode 511 128014 Adaptive139Third131Node13 = false := by
  decide +kernel

#print axioms adaptive139Third131Proof13

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third131Proof12 : runCachedNode 511 128014 Adaptive139Third131Node12 = false := by
  decide +kernel

#print axioms adaptive139Third131Proof12

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third131Proof4 : runCachedNode 511 128014 Adaptive139Third131Node4 = false := by
  decide +kernel

#print axioms adaptive139Third131Proof4

end NineSeparatedSubsetSums
