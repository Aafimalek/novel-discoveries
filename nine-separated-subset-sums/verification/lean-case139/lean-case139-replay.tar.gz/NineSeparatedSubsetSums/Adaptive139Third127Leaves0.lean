import NineSeparatedSubsetSums.Adaptive139Third127State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third127Proof15 : runCachedNode 511 127159 Adaptive139Third127Node15 = false := by
  decide +kernel

#print axioms adaptive139Third127Proof15

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third127Proof14 : runCachedNode 511 127159 Adaptive139Third127Node14 = false := by
  decide +kernel

#print axioms adaptive139Third127Proof14

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third127Proof13 : runCachedNode 511 127159 Adaptive139Third127Node13 = false := by
  decide +kernel

#print axioms adaptive139Third127Proof13

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third127Proof12 : runCachedNode 511 127159 Adaptive139Third127Node12 = false := by
  decide +kernel

#print axioms adaptive139Third127Proof12

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third127Proof11 : runCachedNode 511 127159 Adaptive139Third127Node11 = false := by
  decide +kernel

#print axioms adaptive139Third127Proof11

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third127Proof9 : runCachedNode 511 127159 Adaptive139Third127Node9 = false := by
  decide +kernel

#print axioms adaptive139Third127Proof9

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third127Proof10 : runCachedNode 511 127159 Adaptive139Third127Node10 = false := by
  decide +kernel

#print axioms adaptive139Third127Proof10

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third127Proof8 : runCachedNode 511 127159 Adaptive139Third127Node8 = false := by
  decide +kernel

#print axioms adaptive139Third127Proof8

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third127Proof7 : runCachedNode 511 127159 Adaptive139Third127Node7 = false := by
  decide +kernel

#print axioms adaptive139Third127Proof7

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third127Proof6 : runCachedNode 511 127159 Adaptive139Third127Node6 = false := by
  decide +kernel

#print axioms adaptive139Third127Proof6

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third127Proof3 : runCachedNode 511 127159 Adaptive139Third127Node3 = false := by
  decide +kernel

#print axioms adaptive139Third127Proof3

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third127Proof1 : runCachedNode 511 127159 Adaptive139Third127Node1 = false := by
  decide +kernel

#print axioms adaptive139Third127Proof1

end NineSeparatedSubsetSums
