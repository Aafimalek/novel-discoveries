import NineSeparatedSubsetSums.Adaptive139Third117State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third117Proof0 : runCachedNode 511 124859 Adaptive139Third117Node0 = false := by
  decide +kernel

#print axioms adaptive139Third117Proof0

end NineSeparatedSubsetSums
