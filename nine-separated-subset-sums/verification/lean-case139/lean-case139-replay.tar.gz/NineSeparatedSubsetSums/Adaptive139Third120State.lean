import NineSeparatedSubsetSums.CachedSearchTree

namespace NineSeparatedSubsetSums

def Adaptive139Third120Node0 : CachedSearchNode :=
  ⟨4, 119, computeCenteredMask [148,139,120], 407, 55625⟩

end NineSeparatedSubsetSums
