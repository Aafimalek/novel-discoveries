import NineSeparatedSubsetSums.Adaptive139Third138State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third138Proof207 : runCachedNode 511 129184 Adaptive139Third138Node207 = false := by
  decide +kernel

#print axioms adaptive139Third138Proof207

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third138Proof69 : runCachedNode 511 129184 Adaptive139Third138Node69 = false := by
  decide +kernel

#print axioms adaptive139Third138Proof69

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third138Proof180 : runCachedNode 511 129184 Adaptive139Third138Node180 = false := by
  decide +kernel

#print axioms adaptive139Third138Proof180

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third138Proof114 : runCachedNode 511 129184 Adaptive139Third138Node114 = false := by
  decide +kernel

#print axioms adaptive139Third138Proof114

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third138Proof46 : runCachedNode 511 129184 Adaptive139Third138Node46 = false := by
  decide +kernel

#print axioms adaptive139Third138Proof46

end NineSeparatedSubsetSums
