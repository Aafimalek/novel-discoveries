import NineSeparatedSubsetSums.Adaptive139Third138State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third138Proof19 : runCachedNode 511 129184 Adaptive139Third138Node19 = false := by
  decide +kernel

#print axioms adaptive139Third138Proof19

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third138Proof177 : runCachedNode 511 129184 Adaptive139Third138Node177 = false := by
  decide +kernel

#print axioms adaptive139Third138Proof177

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third138Proof137 : runCachedNode 511 129184 Adaptive139Third138Node137 = false := by
  decide +kernel

#print axioms adaptive139Third138Proof137

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third138Proof1 : runCachedNode 511 129184 Adaptive139Third138Node1 = false := by
  decide +kernel

#print axioms adaptive139Third138Proof1

end NineSeparatedSubsetSums
