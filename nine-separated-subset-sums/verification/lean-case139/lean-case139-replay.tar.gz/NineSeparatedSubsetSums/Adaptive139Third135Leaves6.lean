import NineSeparatedSubsetSums.Adaptive139Third135State

namespace NineSeparatedSubsetSums

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third135Proof113 : runCachedNode 511 128672 Adaptive139Third135Node113 = false := by
  decide +kernel

#print axioms adaptive139Third135Proof113

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third135Proof40 : runCachedNode 511 128672 Adaptive139Third135Node40 = false := by
  decide +kernel

#print axioms adaptive139Third135Proof40

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third135Proof62 : runCachedNode 511 128672 Adaptive139Third135Node62 = false := by
  decide +kernel

#print axioms adaptive139Third135Proof62

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third135Proof112 : runCachedNode 511 128672 Adaptive139Third135Node112 = false := by
  decide +kernel

#print axioms adaptive139Third135Proof112

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third135Proof87 : runCachedNode 511 128672 Adaptive139Third135Node87 = false := by
  decide +kernel

#print axioms adaptive139Third135Proof87

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third135Proof36 : runCachedNode 511 128672 Adaptive139Third135Node36 = false := by
  decide +kernel

#print axioms adaptive139Third135Proof36

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third135Proof61 : runCachedNode 511 128672 Adaptive139Third135Node61 = false := by
  decide +kernel

#print axioms adaptive139Third135Proof61

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third135Proof12 : runCachedNode 511 128672 Adaptive139Third135Node12 = false := by
  decide +kernel

#print axioms adaptive139Third135Proof12

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third135Proof109 : runCachedNode 511 128672 Adaptive139Third135Node109 = false := by
  decide +kernel

#print axioms adaptive139Third135Proof109

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third135Proof86 : runCachedNode 511 128672 Adaptive139Third135Node86 = false := by
  decide +kernel

#print axioms adaptive139Third135Proof86

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third135Proof11 : runCachedNode 511 128672 Adaptive139Third135Node11 = false := by
  decide +kernel

#print axioms adaptive139Third135Proof11

set_option maxRecDepth 47000 in
set_option maxHeartbeats 300000000 in
theorem adaptive139Third135Proof84 : runCachedNode 511 128672 Adaptive139Third135Node84 = false := by
  decide +kernel

#print axioms adaptive139Third135Proof84

end NineSeparatedSubsetSums
