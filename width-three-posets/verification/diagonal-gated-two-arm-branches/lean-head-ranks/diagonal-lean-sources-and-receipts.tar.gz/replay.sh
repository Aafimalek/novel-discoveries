#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
here=$PWD
: "${LEAN_BIN:?Set LEAN_BIN to the pinned Lean 4.36.0 executable}"
: "${LEAN_PATH:?Set LEAN_PATH to audited prerequisites and pinned Mathlib}"
[[ "$("$LEAN_BIN" --version)" == *"4.36.0"*"611c117bfaf7b7ae1cfcf246ce6fba31e8f509e9"* ]]
sha256sum -c SHA256SUMS
mkdir -p replay-logs tmp
export TMPDIR="$here/tmp" TMP="$here/tmp" TEMP="$here/tmp"
export LEAN_PATH="$here:$LEAN_PATH"
timeout -k2s 285s bash -c '
set -euo pipefail
for M in DiagonalRankArithmetic DiagonalBranchHeadDraft DiagonalHeadAudit; do
  "$LEAN_BIN" -j1 -M2450 -o "$M.olean" "$M.lean" 2>&1 | tee "replay-logs/$M.log"
  printf "%s exit=0\n" "$M" >> replay-logs/receipts.log
done
'
grep -Fq "'WidthThree.Diagonal.Labels.frequency_heads_le' depends on axioms: [propext, Classical.choice, Quot.sound]" replay-logs/DiagonalHeadAudit.log
! grep -E 'sorryAx|Lean.ofReduceBool|Lean.trustCompiler' replay-logs/*.log
