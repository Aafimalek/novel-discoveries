/- Static integration draft; not compiled. -/
import AntitonePrefixDraft

namespace WidthThree.JointPool

/-- The first n bin counts, starting at index s. -/
def seqBins (q : Nat → Nat) (s : Nat) : Nat → List Nat
  | 0 => []
  | n + 1 => q s :: seqBins q (s + 1) n

theorem seqBins_antitone (q : Nat → Nat) (hq : ∀ k, q (k + 1) ≤ q k)
    (s n : Nat) : binsAntitone (seqBins q s n) := by
  induction n generalizing s with
  | zero => trivial
  | succ n ih =>
    have ht := ih (s + 1)
    cases n with
    | zero => exact ⟨Nat.zero_le _, ht⟩
    | succ n => exact ⟨hq s, ht⟩

theorem prefix_eq_offset_seqBins (q pref : Nat → Nat)
    (step : ∀ k, pref (k + 1) = pref k + q k)
    (s k n : Nat) (hk : k ≤ n) :
    pref (s + k) = pref s + prefixCount k (seqBins q s n) := by
  induction k generalizing s n with
  | zero => simp [prefixCount]
  | succ k ih =>
    cases n with
    | zero => omega
    | succ n =>
      have hn : k ≤ n := Nat.le_of_succ_le_succ hk
      have hs : s + (k + 1) = (s + 1) + k := by omega
      rw [hs, ih (s + 1) n hn, step s]
      simp [seqBins, prefixCount, Nat.add_assoc]

theorem joint_of_prefix_step (q pref : Nat → Nat)
    (hzero : pref 0 = 0)
    (step : ∀ k, pref (k + 1) = pref k + q k)
    (hq : ∀ k, q (k + 1) ≤ q k)
    {r s d e n : Nat} (hr : r ≤ n) (hs : s ≤ n) (hd : d ≤ n) (he : e ≤ n)
    (h : r + s ≤ 2 * (d + e)) :
    pref r + pref s ≤ 2 * (pref d + pref e) := by
  let ls := seqBins q 0 n
  have eq (k : Nat) (hk : k ≤ n) : pref k = prefixCount k ls := by
    simpa [ls, hzero] using prefix_eq_offset_seqBins q pref step 0 k n hk
  rw [eq r hr, eq s hs, eq d hd, eq e he]
  exact prefixCount_joint ls (seqBins_antitone q hq 0 n) h

#print axioms joint_of_prefix_step

end WidthThree.JointPool
