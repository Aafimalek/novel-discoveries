#!/usr/bin/env bash
# Serial source replay and independent theorem audit.
set -euo pipefail
cd "$(dirname "$0")"
ROOT=$PWD
LEAN_BIN="${LEAN_BIN:-lean}"
LEAN_MEM_MB="${LEAN_MEM_MB:-2500}"
DEPS="${LEAN_PATH:-}"
if [[ "${REBUILD_PREREQS:-0}" == 1 ]]; then
  export LEAN_PATH="$ROOT:$ROOT/prereqs${DEPS:+:$DEPS}"
  cd prereqs
  for m in BranchSwap BranchOrder MultiRankStep JointCapDraft AntitonePrefixDraft; do
    "$LEAN_BIN" -j1 "-M$LEAN_MEM_MB" -o "$m.olean" "$m.lean"
  done
  cd "$ROOT"
else
  export LEAN_PATH="$ROOT${DEPS:+:$DEPS}"
fi
for m in ConditionalBinListDraft JointBranchOrderDraft JointBranchOrderAudit; do
  "$LEAN_BIN" -j1 "-M$LEAN_MEM_MB" -o "$m.olean" "$m.lean"
done
