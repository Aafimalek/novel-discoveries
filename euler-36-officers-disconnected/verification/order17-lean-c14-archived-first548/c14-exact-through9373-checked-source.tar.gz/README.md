# C14 static readiness audit and immediate next production band

No Lean or Git invoked. The previous checked checkpoint is unchanged:
Euler.C14.Production.exactArchiveThrough9241, exact sorted original
CNF plus 416 learned additions. Its official archives and all 22 proof
objects were copied into a read-only overlay snapshot through9241-baseline.
THROUGH9241.sha256 commits 104 copied files (including proof objects,
proof receipts, sources and logs). The snapshot stays independent of
the prior rolling checked directory. It is local rather than included
in this small static source package.

python3 check-prior.py matches all snapshot and live source/object/log
receipts, exact theorem, axioms and pinned files. Remaining leaves in
the already validated prior stage are [9241,9247) 808 hints,
[9247,9252) 746 hints, [9252,9276) 678 hints and [9276,9278) 5 hints.
No Lean result beyond exact416 is currently asserted. Under a separate
heavy-slot grant, resume the previous euler-c14-after9113 stage using
its original SHA256SUMS and python3 run-band.py --execute --seconds 285.
It should emit exactArchiveThrough9278 and can then be frozen with that
stage's freeze-with-dependency-note.py. Do not combine separate grants.

This new stage is conditional on an audited exactArchiveThrough9278.
Its generator reparses the archived sorted DIMACS/LRAT, as identified
by exact SHA-256 in generated/band.json. 11 further production slices
over the same permanent rowAt cover [9278,9391), 113 learned additions,
8,654 hint references, max 899 per slice, max 94 literals in a clause.
Begins [9278,9302), 548 hints, 70 earlier learned references; uses the
established ordinary driver, not the inconclusive equality-cache pilot.

Every possible stopping point has a balanced exact prefix aggregate.
The runner checks existing closure including all prior immutable proofs
and exact source hashes/liveness from generation. Its restart receipt
binds compiler/foundation pins, exact source hashes and the actual prior
through9278 aggregate receipt. The exact prior gate checks original
through9278 shape, 453 learned rows, proof objects/receipt hashes and
standard axiom audit, then rechecks latest did not change under lock.
It will refuse to run Lean without that gate. The usual serial single
pinned Lean worker locks globally, uses overlay TMPDIR, -M2450 -j1 and
warnings-as-errors, 47s/leaf and 285s overall monotone cap. It builds an
aggregate only over a contiguous settled list and leaves exact receipts
for resumption. Portability requires imported audits from the existing
pinned project environment; no full upstream cold-check is claimed.

After exact through9278 passes, on separately approved sole heavy slot:
    sha256sum --check --status SHA256SUMS && python3 run-band.py --execute --seconds 285

Execute only from this project with the earlier stage and read-only
snapshot accessible. Source/closure readiness is not a Lean theorem
beyond 416, a terminal empty derivation, nor geometry verification.
