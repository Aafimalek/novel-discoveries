import C14ExactThrough9278
import C14ProofChunk9278_9302Draft
import C14ProofChunk9302_9314Draft
import C14ProofChunk9314_9329Draft
import C14ProofChunk9329_9336Draft
import C14ProofChunk9336_9343Draft
import C14ProofChunk9343_9361Draft
import C14ProofChunk9361_9373Draft

namespace Euler.C14.Production
open Euler.C14.IndexedDraft
set_option maxRecDepth 18000
set_option maxHeartbeats 2400000

theorem bandThrough9373 (base : Sat.Fmla) : Slice base rowAt 9278 9373 :=
  (compose (compose (chunk_9278_9302 base) (compose (chunk_9302_9314 base) (chunk_9314_9329 base))) (compose (compose (chunk_9329_9336 base) (chunk_9336_9343 base)) (compose (chunk_9343_9361 base) (chunk_9361_9373 base))))

theorem exactArchiveThrough9373 : GoodBelow archivedGlobalCore rowAt 9373 :=
  bandThrough9373 archivedGlobalCore exactArchiveThrough9278

#print axioms bandThrough9373
#print axioms exactArchiveThrough9373
end Euler.C14.Production
