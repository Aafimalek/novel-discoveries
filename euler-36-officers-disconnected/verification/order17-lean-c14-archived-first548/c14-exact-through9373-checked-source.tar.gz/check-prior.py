#!/usr/bin/env python3
from pathlib import Path
import hashlib,json
H=Path(__file__).resolve().parent
P=H.parent/'euler-c14-after9113'
I=H/'through9241-baseline'
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for a in iter(lambda:f.read(1<<20),b''):h.update(a)
 return h.hexdigest()
def manifest(root,m):
 lines=m.read_text().splitlines();assert lines
 for l in lines:
  h,rel=l.split(maxsplit=1);f=(root/rel).resolve()
  assert f.is_relative_to(root.resolve()) and sha(f)==h,f
 return len(lines)
def receipts(root,prior):
 band=json.loads((root/'generated/band.json').read_text())['chunks']
 cs=band[:prior['leaf_count']]
 assert cs and cs[-1]['hi']==prior['end'] and prior['learned']==prior['end']-8825
 assert cs[-1]['final_theorem']==prior['theorem'] and cs[-1]['aggregate']==prior['archive_aggregate']
 assert all(a['hi']==b['lo'] for a,b in zip(cs,cs[1:]))
 assert prior['closure']==sha(root/'closure-pins.json')+':'+sha(root/'generated/BAND.sha256')
 mods=[c['module'] for c in cs]+[prior['archive_aggregate']]
 for m in mods:
  src,o,log,rec=(root/'generated'/f'{m}.lean',root/'generated'/f'{m}.olean',
                 root/'logs'/f'{m}.log',root/'logs'/f'{m}.json')
  assert json.loads(rec.read_text())==dict(closure=prior['closure'],source=sha(src),object=sha(o),log=sha(log)),m
 assert sha(root/'logs'/f"{mods[-1]}.json")==prior['receipt']
 ax=f"'Euler.C14.Production.{prior['theorem']}' depends on axioms: [propext, Classical.choice, Quot.sound]"
 assert ax in (root/'logs'/f"{mods[-1]}.log").read_text().splitlines()
 return mods
def main(execute=False):
 z=manifest(I,H/'THROUGH9241.sha256')
 a=json.loads((I/'logs/latest-composed.json').read_text())
 assert a['end']==9241 and a['learned']==416 and a['leaf_count']==21
 mods=receipts(I,a)
 assert (I/'checked-order.txt').read_text().splitlines()==mods
 print(f'Read-only exact416 snapshot: {z} files; {len(mods)} checked objects',flush=True)
 print('Prior static stage pinned files:',manifest(P,P/'SHA256SUMS'),flush=True)
 rolling=json.loads((P/'logs/latest-composed.json').read_text())
 assert rolling['end']>=9241
 assert len(receipts(P,rolling))==rolling['leaf_count']+1
 for m in mods:
  assert sha(P/'generated'/f'{m}.olean')==sha(I/'generated'/f'{m}.olean'),m
 remaining=[q for q in json.loads((P/'generated/band.json').read_text())['chunks'] if q['lo']>=rolling['end']]
 assert not remaining or remaining[0]['lo']==rolling['end']
 if remaining:
  assert remaining[-1]['hi']==9278 and all(a['hi']==b['lo'] for a,b in zip(remaining,remaining[1:]))
  assert all(c['hints']<=900 for c in remaining)
  print('Still ready in prior stage:',[(q['lo'],q['hi'],q['hints']) for q in remaining],flush=True)
 ready=rolling['end']==9278 and rolling['learned']==453 and rolling['theorem']=='exactArchiveThrough9278'
 if execute:
  assert ready, 'production gate: need an audited exactArchiveThrough9278 first'
 print('Exact through9278 gate:', 'READY' if ready else 'WAITING',flush=True)
 return rolling
if __name__=='__main__':main()
