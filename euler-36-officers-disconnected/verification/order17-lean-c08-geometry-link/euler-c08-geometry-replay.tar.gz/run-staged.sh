#!/usr/bin/env bash
set -euo pipefail
mkdir -p replay-logs
build () {
  local limit=$1 file=$2 module
  module=$(basename "$file" .lean)
  printf '%s Checking %s\n' "$(date -u +%T)" "$file"
  timeout -k 1s "$limit" "$LEAN_BIN" -j1 -M2500 -o "$module.olean" "$file" 2>&1 |
    tee "replay-logs/$module.log"
  printf '%s exit=0\n' "$module" >> stage-receipts.log
  sha256sum "$module.olean" >> built-objects.sha256
}
build 35s ArchiveCoreBlocks.lean
build 20s C08Codes.lean
build 30s C08SignedRows.lean
build 25s C08CoreMembers00.lean
build 185s C08RawFactored.lean
for n in $(seq -w 1 31); do build 25s "C08CoreMembers$n.lean"; done
build 40s C08Linked.lean
build 30s C08ImportAudit.lean
