import ArchiveCoreBlocks

namespace LatinGap.PairEncoding.C08Linked

def codes : List ℕ := [111,1012,1103,2220]

end LatinGap.PairEncoding.C08Linked
