import EulerBatch.FactoredDriver
namespace Euler.Batch.C04
factored_rup coreUnsat (include_str "cases/04/core.cnf") (include_str "cases/04/core.lrat")
#print axioms coreUnsat
end Euler.Batch.C04
