import ArchiveCoreBlocks

namespace LatinGap.PairEncoding.C04Linked

def codes : List ℕ := [111,1012,1201,2120]

end LatinGap.PairEncoding.C04Linked
