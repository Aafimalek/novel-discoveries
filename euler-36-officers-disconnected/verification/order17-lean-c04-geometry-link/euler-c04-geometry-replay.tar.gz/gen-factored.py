from pathlib import Path
from collections import Counter
import json
rows=json.loads(Path('plan.json').read_text())
meta=json.loads(Path('case.json').read_text())
assert len(rows)==meta['coreRows']
case=f'C{int(meta["case"]):02d}'
codes=meta['codes']
pairs=[tuple(p) for p in meta['degreeOrderPairs']]
def rename(s):
 return (s.replace('LatinGap.PairEncoding.C02Blocks', 'LatinGap.PairEncoding.C02Linked')
          .replace('C02',case).replace('c02',case.lower()))
def n(i):return str(i)
def leanrow(r):return '['+','.join(map(n,r))+']'
def satclause(row):
 s='Sat.Clause.nil'
 for l in reversed(row):
  sg='pos' if l>0 else 'neg'
  s=f'Sat.Clause.cons (Sat.Literal.{sg} {abs(l)-1}) ({s})'
 return s
def tree(start,end,leaf,node):
 if end-start==1:return leaf(start)
 mid=(start+end)//2
 return node(tree(start,mid,leaf,node),tree(mid,end,leaf,node))
parts=[]
def claimpart(a,b):
 i=len(parts);parts.append((a,b));return f'{i:02}'
def rec(a,b):
 if b-a<=48:return ('L',claimpart(a,b))
 m=(a+b)//2
 return ('N',rec(a,m),rec(m,b))
code=rec(0,len(rows))
def expand(expr,kind):
 if expr[0]=='L':return kind+expr[1]
 A=expand(expr[1],kind);B=expand(expr[2],kind)
 if kind=='chunk':return '('+A+' ++ '+B+')'
 return f'Sat.Fmla.and ({A}) ({B})'
raw='''import EulerBatch.C02Core

namespace Euler.C02RawFactored

def mapFormula (cs : List (List Int)) : Sat.Fmla :=
  cs.map (fun c => c.map Sat.Literal.ofInt)

theorem mapFormula_append (a b : List (List Int)) :
    mapFormula (a ++ b) = Sat.Fmla.and (mapFormula a) (mapFormula b) := List.map_append

'''
for i,(a,b) in enumerate(parts):
 sat=tree(a,b,lambda j:f'Sat.Fmla.one ({satclause(rows[j][0])})',lambda l,r:f'Sat.Fmla.and ({l}) ({r})')
 raw+=f'def chunk{i:02} : List (List Int) := [\n  '+',\n  '.join(leanrow(rows[j][0]) for j in range(a,b))+'\n]\n'
 raw+=f'def sat{i:02} : Sat.Fmla := {sat}\n'
 raw+=f'theorem chunk_eq{i:02} : mapFormula chunk{i:02} = sat{i:02} := by rfl\n\n'
raw+=f'def rows : List (List Int) := {expand(code,"chunk")}\n'
raw+=f'def expected : Sat.Fmla := {expand(code,"sat")}\n'
raw+='''
set_option maxRecDepth 12000 in
theorem expected_matches_checked_core : expected = Euler.Batch.C02.coreUnsat.cnf := by
  rfl

theorem rows_match_checked_core : mapFormula rows = Euler.Batch.C02.coreUnsat.cnf := by
  rw [← expected_matches_checked_core]
  simp only [rows, expected, mapFormula_append,
    '''+',\n    '.join(','.join(f'chunk_eq{i:02}' for i in range(j,min(j+6,len(parts)))) for j in range(0,len(parts),6))+''']

#print axioms expected_matches_checked_core
#print axioms rows_match_checked_core

end Euler.C02RawFactored
'''
Path(f'{case}RawFactored.lean').write_text(rename(raw))

def render(name,pa,j):
 if name in ('anchors','pins'):return f'{name} {j} rfl'
 if name=='saturation':return f'saturation {j} (by decide) rfl'
 if name=='support':return f'support {pa[0]} {j} rfl'
 if name=='degreeRow':return 'degreeRow {} {} {} {} (by decide) rfl'.format(*pa,j)
 if name=='degreeOrder':return f'degreeOrder {4*pairs.index(tuple(pa))+j} rfl'
 if name in ('projectionLo','projectionHi'):return f'{name} {pa[0]} {j} (by decide) rfl'
 if name=='excessLo':return f'{name} {pa[0]} {pa[1]} {j} (by decide) rfl'
 if name=='excessHi':return f'excessHi {pa[0]} {pa[1]} {j} (by decide) rfl'
 if name=='lex':
  g,a,k,bs=pa
  return f'lex {g} {a} {a+1} {k} {bs} {j+2} (by decide) (by decide) (by decide) rfl'
 raise AssertionError(name)
def explicit_codes(term):
 d,sep,rest=term.partition(' ')
 assert sep
 return f'ArchiveCoreBlocks.{d} (codes := codes) {rest}'
Path(f'{case}Codes.lean').write_text(rename('import ArchiveCoreBlocks\n\nnamespace LatinGap.PairEncoding.C02Blocks\n'
  +'\ndef codes : List ℕ := '+leanrow(codes)+'\n\nend LatinGap.PairEncoding.C02Blocks\n'))
shards=[list(zip(range(i,min(i+4,len(parts))),parts[i:i+4])) for i in range(0,len(parts),4)]
for s,batch in enumerate(shards):
 q='''import C02RawFactored
import C02Codes

namespace LatinGap.PairEncoding.C02Blocks
open Euler.C02RawFactored

'''
 for i,(a,b) in batch:
  q+=f'theorem chunk_mem{i:02} : ∀ c ∈ chunk{i:02}, c ∈ archiveAllUsedCNF codes := by\n  unfold chunk{i:02}\n'
  for ix in range(a,b):
   r,name,pa,j=rows[ix]
   q+=f'  refine List.forall_mem_cons.mpr ⟨{explicit_codes(render(name,pa,j))}, ?_⟩\n'
  q+='  simp\n\n'
 q+='end LatinGap.PairEncoding.C02Blocks\n'
 Path(f'{case}CoreMembers{s:02}.lean').write_text(rename(q))
def proofTree(expr):
 if expr[0]=='L':return 'chunk_mem'+expr[1]
 return '⟨'+proofTree(expr[1])+','+proofTree(expr[2])+'⟩'

proof = 'import EulerAllUsedConditionalRefutations\n'+''.join(f'import C02CoreMembers{s:02}\n' for s in range(len(shards)))+'''
set_option maxRecDepth 12000
set_option maxHeartbeats 0

namespace LatinGap.PairEncoding.C02Blocks
open Euler.C02RawFactored

theorem all_core_rows_local : ∀ c ∈ rows, c ∈ archiveAllUsedCNF codes := by
  simp only [rows, List.forall_mem_append]
  exact __MEMBERSHIP_TREE__

/-- The numbered formula emitted by the geometry for C02 has no model. -/
theorem c02_no_numbered_archive_model :
    ¬ ∃ v : ℕ → Bool, ∀ c ∈ archiveAllUsedCNF codes, NumberedHolds v c := by
  rintro ⟨v,hv⟩
  have h := numberedFormula_sat_forward v rows (fun c hc => hv c (all_core_rows_local c hc))
  change (dimacsSatValuation v).satisfies_fmla (mapFormula rows) at h
  rw [rows_match_checked_core] at h
  exact Euler.Batch.C02.coreUnsat _ h

/-- An actual all-used design must be represented by a published case other than C02. -/
theorem allUsed_geometry_except_c02 {D : Design 6} (lin : Linear D)
    (sat : Saturated D) (size : D.card=17) (min : ∀ x : Label 6, 2 ≤ freq D x)
    (allused : ∀ (i j : Coord) (a b : Fin 6), i ≠ j →
      freq D (i,a)=2 → freq D (j,b)=2 → Used D (i,a) (j,b)) :
    ∃ cs ∈ remainingAllUsedDiagrams [codes], ∃ v : ℕ → Bool,
      ∀ c ∈ archiveAllUsedCNF cs, NumberedHolds v c := by
  refine allUsed_geometry_only_remaining lin sat size min allused [codes] ?_
  intro cs hcs
  have heq : cs = codes := List.mem_singleton.mp hcs
  subst cs
  exact c02_no_numbered_archive_model

#print axioms all_core_rows_local
#print axioms c02_no_numbered_archive_model
#print axioms allUsed_geometry_except_c02
end LatinGap.PairEncoding.C02Blocks
'''.replace('__MEMBERSHIP_TREE__', proofTree(code))
Path(f'{case}Linked.lean').write_text(rename(proof))
print(len(parts),'tree-aligned chunks',len(shards),'membership shards',Counter(r[1] for r in rows))
