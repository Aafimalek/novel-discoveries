"""Independent exact integer replay of proposed local indices; not a Lean proof."""
from pathlib import Path
from itertools import combinations
from collections import Counter
import json
CODES=json.loads(Path('case.json').read_text())['codes']
P=list(combinations(range(4),2))
def digit(k,g,base=6):return k//base**(3-g)%base
def wordNum(w):return 1+sum(a*6**(3-g) for g,a in enumerate(w))
def pNum(i,j,a,b):
 if i>j:i,j,a,b=j,i,b,a
 return 1297+36*P.index((i,j))+6*a+b
def dNum(g,a,d):return 9719+7*(6*g+a)+d
def adj(g,a,b):return pNum(g,1 if g==0 else 0,a,b)
def ctrRow(m,k,base,idx,sign,r):
 l=lambda i:(-1 if sign else 1)*idx(i)
 s=lambda r,j,pos:(1 if pos else -1)*(base+(2*j+r if r<2 else k*r+j))
 out=[[l(r),s(r,0,True)]]
 for j in range(k):
  if r+1<m:out += [[s(r,j,False),s(r+1,j,True)]]
  if j+1<k:out += [[l(r+j+1),s(r,j,False),s(r,j+1,True)]]
  else:out += [[l(r+k),s(r,j,False)]]
 return out
def support(p):
 i,j=P[p//36]
 a,b=(p//6)%6,p%6
 def w(t):
  free=[g for g in range(4) if g not in (i,j)]
  w=[0]*4
  w[i]=a;w[j]=b;w[free[0]]=t//6;w[free[1]]=t%6
  return wordNum(w)
 pair=1297+p
 return [[-pair]+[w(t) for t in range(36)]]+[[-w(t),pair] for t in range(36)] + [c for r in range(35) for c in ctrRow(35,1,1513+35*p,w,True,r)]
def candidate(i):
 w=[digit(i,g) for g in range(4)]
 return [pNum(a,b,w[a],w[b]) for a,b in P]
def deg(g,a,i):
 pat=[(i>>(5-j))&1 for j in range(6)]
 cs=[(-1 if z else 1)*adj(g,a,j) for j,z in enumerate(pat)]
 m=sum(pat)
 if (m==2 if g==a==0 else m>=2):
  return [cs+[(1 if d<=m else -1)*dNum(g,a,d)] for d in range(2,7)]
 return [cs]
def lex(g,a,k,bs,d):
 b=a+1
 start=max(1,*(digit(c,g,10) for c in CODES))+1
 assert start<=a<5 and bs<2**k and 2<=d<=6
 return [-dNum(g,a,d)]+([dNum(g,b,d+1)] if d<6 else [])+[(1 if ((bs>>(k-1-i))&1)==0 else -1)*adj(g,u,i) for u in (a,b) for i in range(k)]+[-adj(g,a,k),adj(g,b,k)]
def recipe(name,p,j):
 if name=='saturation':return candidate(j)
 if name=='support':return support(p[0])[j]
 if name=='anchors':return [[1],[wordNum([0,1,1,1])]][j]
 if name=='degreeRow':return deg(*p)[j]
 if name=='degreeOrder':
  g,a,b=p
  return [-dNum(g,a,j+3),dNum(g,b,j+3)]
 if name in ('projectionLo','projectionHi'):
  r,=p
  m,k,b,sg=(17,19,9073,False) if name=='projectionLo' else (19,17,9396,True)
  return ctrRow(m,k,b,lambda u:1297+u,sg,r)[j]
 if name=='excessLo':
  g,r=p
  return ctrRow(5,19,9887+190*g,lambda u:dNum(g,(u//4)%6,3+u%4),False,r)[j]
 if name=='excessHi':
  g,r=p
  return ctrRow(19,5,9982+190*g,lambda u:dNum(g,(u//4)%6,3+u%4),True,r)[j]
 if name=='pins':
  return ([[wordNum([digit(code,g,10) for g in range(4)])] for code in CODES]+[[(1 if a else -1)*dNum(g,a,3)] for g in range(4) for a in range(6)])[j]
 if name=='lex':return lex(*p,j+2)
 raise AssertionError(name)
rows=json.loads(Path('plan.json').read_text())
for i,(c,name,p,j) in enumerate(rows):
 actual=recipe(name,p,j)
 assert actual==c,(i,name,p,j,c,actual)
print('exact recipe arithmetic: all',len(rows),'core leaf rows match independently')
print(Counter(row[1] for row in rows))
