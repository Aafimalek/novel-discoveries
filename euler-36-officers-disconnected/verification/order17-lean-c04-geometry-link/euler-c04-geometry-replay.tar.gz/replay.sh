#!/usr/bin/env bash
# Point LEAN_PATH at the matching compiled Euler and Mathlib projects.
set -euo pipefail
cd "$(dirname -- "$0")"
ROOT=$PWD
CASE="${CASE:-C04}"
DEPS="${LEAN_PATH:-}"
export LEAN_PATH="$ROOT${DEPS:+:$DEPS}"
LEAN_BIN="${LEAN_BIN:-lean}"
LEAN_MEMORY_MB="${LEAN_MEMORY_MB:-2500}"
mkdir -p replay-logs
build () {
  local source=$1
  printf 'Checking %s\n' "$source"
  "$LEAN_BIN" -j1 "-M$LEAN_MEMORY_MB" -o "${source%.lean}.olean" "$source" 2>&1 |
    tee "$ROOT/replay-logs/$(basename "${source%.lean}").log"
}
if [[ "${REBUILD_CORE:-0}" = "1" ]]; then
  export LEAN_PATH="$ROOT:$ROOT/fixtures${DEPS:+:$DEPS}"
  cd fixtures
  build EulerBatch/FactoredDriver.lean
  build "EulerBatch/${CASE}Core.lean"
  cd "$ROOT"
fi
build ArchiveCoreBlocks.lean
build "${CASE}Codes.lean"
build "${CASE}RawFactored.lean"
for file in "${CASE}"CoreMembers*.lean; do build "$file"; done
build "${CASE}Linked.lean"
build "${CASE}ImportAudit.lean"
