from collections import Counter
from pathlib import Path
import itertools,json,os
a=Path(os.environ.get("CASE_DIR","."))
def clauses(f):
 return [tuple(map(int,r.split()[:-1])) for r in (a/(f+'.cnf')).read_text().splitlines()[1:]]
orig=clauses('original'); core=clauses('core')
idx={}
for i,c in enumerate(orig): idx.setdefault(c,[]).append(i)
blocks=[]
def add(name,size,params=()):
 blocks.append((name,params,size))
def counter(name,m,k,params=()):
 for i in range(m):
  add(name,1+k*(2 if i+1<m else 1),(*params,i))
add('saturation',1296)
for p in range(216):add('support',141,(p,))
counter('projectionLo',17,19);counter('projectionHi',19,17)
add('anchors',2)
case=(a/'case.tsv').read_text().strip().split('\t')
codes=[int(x) for x in case[2].removeprefix('aus-').split('_')]
assert len(codes)==4
assert len(orig)==int(case[4]) and len(core)==int(case[5])
for g in range(4):
 for a in range(6):
  for i in range(64):
   pop=i.bit_count()
   add('degreeRow',5 if (pop==2 if g==a==0 else pop>=2) else 1,(g,a,i))
  add('degreeUnits',2,(g,a))
pairs=[]
for g in range(4):
 start=max(1,*[(c//10**(3-g))%10 for c in codes])+1
 for aa in range(max(1 if g==0 else 2,start),5):
  pairs.append((g,aa,aa+1))
 if g==1:pairs.append((g,0,1))
for g,aa,b in pairs:add('degreeOrder',4,(g,aa,b))
add('repeatSaturation',1296)
for g in range(4):
 counter('excessLo',5,19,(g,));counter('excessHi',19,5,(g,))
add('pins',28)
# Candidate rectangles: six coord pairs, two orientations, four labels.
for q,o,a,b,c,t in itertools.product(range(6),range(2),range(6),range(6),range(6),range(6)):
 add('rectangle',1,(q,o,a,b,c,t))
for g in range(4):
 start=max(1,*[(c//10**(3-g))%10 for c in codes])+1
 for a in range(start,5):
  for k in range(6):
   for bits in range(2**k):
    add('lex',5,(g,a,k,bits))
picks=[]
for name,params,size in blocks:
 picks += [(name,params,j) for j in range(size)]
assert len(picks)==len(orig)
known = {'saturation','support','anchors','degreeRow','degreeOrder','excessHi','excessLo',
         'pins','lex','projectionLo','projectionHi'}
def find_recipe(clause):
  indices=idx[clause]
  candidates=[(name,params,j,i) for i in indices for name,params,j in [picks[i]]]
  rank = lambda rec: (0 if rec[0] in known else 1, rec[3])
  return min(candidates,key=rank)[:3]
rows=[(r,*find_recipe(r)) for r in core]
print(Counter(r[1] for r in rows))
print('support unique pairs:',len({r[2][0] for r in rows if r[1]=='support'}))
print('max support idx:',max(r[3] for r in rows if r[1]=='support'))
print('example per group:')
last={}
for j,(r,n,pa,i) in enumerate(rows):
 last.setdefault(n,(j,r,pa,i))
for n,q in last.items():print(n,q)
Path("plan.json").write_text(json.dumps(rows))
Path("case.json").write_text(json.dumps(dict(case=case[0],codes=codes,degreeOrderPairs=pairs,originalRows=len(orig),coreRows=len(core)),indent=2)+'\n')
