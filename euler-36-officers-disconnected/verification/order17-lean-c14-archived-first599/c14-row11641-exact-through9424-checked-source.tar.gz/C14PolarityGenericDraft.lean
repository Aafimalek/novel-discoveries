import EulerC14IndexedDraft
import C14GlobalDirectory

namespace Euler.C14.PolarityDraft
open Euler.C14.IndexedDraft

def NegBelow (v : Sat.Valuation) (polarity : Nat → Sat.Literal) (bound : Nat) : Prop :=
  ∀ i, i < bound → v.neg (polarity i)

theorem extendNeg {v : Sat.Valuation} {p : Nat → Sat.Literal} {k : Nat}
    (step : NegBelow v p k → v.neg (p k)) :
    NegBelow v p k → NegBelow v p (k+1) := by
  intro h j hj
  by_cases hlt : j < k
  · exact h j hlt
  · have hEq : j = k := Nat.le_antisymm (Nat.le_of_lt_succ hj) (Nat.le_of_not_gt hlt)
    subst j
    exact step h

theorem forceComplement (v : Sat.Valuation) (l : Sat.Literal)
    (contra : v.neg l → False) : v.neg l.negate := by
  cases l with
  | pos i =>
    exact Classical.byContradiction contra
  | neg i =>
    exact contra

def Falsified (v : Sat.Valuation) (c : List Sat.Literal) : Prop :=
  ∀ lit ∈ c, v.neg lit

theorem satisfies_of_falsified_imp_false (v : Sat.Valuation) (c : List Sat.Literal)
    (contradiction : Falsified v c → False) : v.satisfies c := by
  induction c with
  | nil =>
    exact contradiction (fun lit h => False.elim (List.not_mem_nil h))
  | cons hd tl ih =>
    intro hhd
    apply ih
    intro htl
    apply contradiction
    intro l hl
    rcases List.mem_cons.mp hl with e | h
    · subst l
      exact hhd
    · exact htl l h

end Euler.C14.PolarityDraft
