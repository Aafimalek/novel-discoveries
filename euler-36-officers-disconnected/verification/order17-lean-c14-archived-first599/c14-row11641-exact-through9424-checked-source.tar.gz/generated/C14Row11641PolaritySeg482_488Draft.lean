import C14Row11641PolarityDataDraft
namespace Euler.C14.PolarityDraft
open Euler.C14.IndexedDraft
open Euler.C14.Production (rowAt)
set_option maxRecDepth 18000
set_option maxHeartbeats 2400000
theorem unit11641_482    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 523) : v.neg (polarity11641 523) := by
  have exactPolarity : polarity11641 523 = (Sat.Literal.neg 1353) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.pos 1353)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 704), (Sat.Literal.pos 1353)] :=
    ready 6044 (by decide) v hv
  exact satisfied (_h 522 (by decide)) missing

theorem unit11641_483    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 524) : v.neg (polarity11641 524) := by
  have exactPolarity : polarity11641 524 = (Sat.Literal.neg 1388) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.pos 1388)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 704), (Sat.Literal.pos 1388)] :=
    ready 6045 (by decide) v hv
  exact satisfied (_h 522 (by decide)) missing

theorem unit11641_484    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 525) : v.neg (polarity11641 525) := by
  have exactPolarity : polarity11641 525 = (Sat.Literal.neg 8531) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.pos 8531)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 704), (Sat.Literal.pos 8531)] :=
    ready 6051 (by decide) v hv
  exact satisfied (_h 522 (by decide)) missing

theorem unit11641_485    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 526) : v.neg (polarity11641 526) := by
  have exactPolarity : polarity11641 526 = (Sat.Literal.pos 1359) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 1359)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.pos 1335), (Sat.Literal.pos 1336), (Sat.Literal.neg 1341), (Sat.Literal.neg 1342), (Sat.Literal.pos 1347), (Sat.Literal.pos 1348), (Sat.Literal.neg 1353), (Sat.Literal.neg 1354), (Sat.Literal.neg 1359), (Sat.Literal.pos 1360)] :=
    ready 9093 (by decide) v hv
  exact satisfied (_h 161 (by decide)) (_h 162 (by decide)) (_h 221 (by decide)) (_h 224 (by decide)) (_h 330 (by decide)) (_h 303 (by decide)) (_h 523 (by decide)) (_h 31 (by decide)) missing (_h 431 (by decide))

theorem unit11641_486    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 527) : v.neg (polarity11641 527) := by
  have exactPolarity : polarity11641 527 = (Sat.Literal.neg 8532) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.pos 8532)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 8531), (Sat.Literal.pos 8532)] :=
    ready 7281 (by decide) v hv
  exact satisfied (_h 525 (by decide)) missing

theorem unit11641_487    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 528) : v.neg (polarity11641 528) := by
  have exactPolarity : polarity11641 528 = (Sat.Literal.pos 956) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 956)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 956), (Sat.Literal.pos 1359)] :=
    ready 7925 (by decide) v hv
  exact satisfied missing (_h 526 (by decide))

theorem segment11641_482_488    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base) :
    NegBelow v polarity11641 523 → NegBelow v polarity11641 529 :=
  ((((extendNeg (unit11641_487 base v ready hv)) ∘ (extendNeg (unit11641_486 base v ready hv))) ∘ (extendNeg (unit11641_485 base v ready hv))) ∘ (((extendNeg (unit11641_484 base v ready hv)) ∘ (extendNeg (unit11641_483 base v ready hv))) ∘ (extendNeg (unit11641_482 base v ready hv))))

end Euler.C14.PolarityDraft
