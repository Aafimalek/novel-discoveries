import C14Row11641PolarityDataDraft
namespace Euler.C14.PolarityDraft
open Euler.C14.IndexedDraft
open Euler.C14.Production (rowAt)
set_option maxRecDepth 18000
set_option maxHeartbeats 2400000
theorem unit11641_288    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 329) : v.neg (polarity11641 329) := by
  have exactPolarity : polarity11641 329 = (Sat.Literal.pos 641) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 641)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 641), (Sat.Literal.pos 1348)] :=
    ready 5627 (by decide) v hv
  exact satisfied missing (_h 303 (by decide))

theorem unit11641_289    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 330) : v.neg (polarity11641 330) := by
  have exactPolarity : polarity11641 330 = (Sat.Literal.pos 1347) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 1347)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.pos 1335), (Sat.Literal.pos 1336), (Sat.Literal.neg 1341), (Sat.Literal.neg 1342), (Sat.Literal.neg 1347), (Sat.Literal.pos 1348)] :=
    ready 9072 (by decide) v hv
  exact satisfied (_h 161 (by decide)) (_h 162 (by decide)) (_h 221 (by decide)) (_h 224 (by decide)) missing (_h 303 (by decide))

theorem unit11641_290    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 331) : v.neg (polarity11641 331) := by
  have exactPolarity : polarity11641 331 = (Sat.Literal.neg 1414) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.pos 1414)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.pos 1309), (Sat.Literal.pos 1348), (Sat.Literal.pos 1380), (Sat.Literal.pos 1414), (Sat.Literal.pos 1446), (Sat.Literal.pos 1500)] :=
    ready 8281 (by decide) v hv
  exact satisfied (_h 22 (by decide)) (_h 303 (by decide)) (_h 195 (by decide)) missing (_h 207 (by decide)) (_h 208 (by decide))

theorem unit11641_291    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 332) : v.neg (polarity11641 332) := by
  have exactPolarity : polarity11641 332 = (Sat.Literal.neg 1363) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.pos 1363)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.pos 1328), (Sat.Literal.pos 1363), (Sat.Literal.pos 1398), (Sat.Literal.pos 1417), (Sat.Literal.pos 1452), (Sat.Literal.pos 1482)] :=
    ready 8384 (by decide) v hv
  exact satisfied (_h 28 (by decide)) missing (_h 41 (by decide)) (_h 304 (by decide)) (_h 196 (by decide)) (_h 211 (by decide))

theorem unit11641_292    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 333) : v.neg (polarity11641 333) := by
  have exactPolarity : polarity11641 333 = (Sat.Literal.pos 315) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 315)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 315), (Sat.Literal.pos 1819)] :=
    ready 2785 (by decide) v hv
  exact satisfied missing (_h 312 (by decide))

theorem unit11641_293    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 334) : v.neg (polarity11641 334) := by
  have exactPolarity : polarity11641 334 = (Sat.Literal.neg 8594) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.pos 8594)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 8593), (Sat.Literal.pos 8594)] :=
    ready 7373 (by decide) v hv
  exact satisfied (_h 314 (by decide)) missing

theorem unit11641_294    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 335) : v.neg (polarity11641 335) := by
  have exactPolarity : polarity11641 335 = (Sat.Literal.neg 6074) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.pos 6074)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 6073), (Sat.Literal.pos 6074)] :=
    ready 5304 (by decide) v hv
  exact satisfied (_h 315 (by decide)) missing

theorem unit11641_295    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 336) : v.neg (polarity11641 336) := by
  have exactPolarity : polarity11641 336 = (Sat.Literal.neg 8769) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.pos 8769)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 8768), (Sat.Literal.pos 8769)] :=
    ready 7503 (by decide) v hv
  exact satisfied (_h 316 (by decide)) missing

theorem unit11641_296    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 337) : v.neg (polarity11641 337) := by
  have exactPolarity : polarity11641 337 = (Sat.Literal.pos 596) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 596)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 596), (Sat.Literal.pos 1347)] :=
    ready 5182 (by decide) v hv
  exact satisfied missing (_h 330 (by decide))

theorem unit11641_297    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 338) : v.neg (polarity11641 338) := by
  have exactPolarity : polarity11641 338 = (Sat.Literal.pos 599) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 599)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 599), (Sat.Literal.pos 1347)] :=
    ready 5220 (by decide) v hv
  exact satisfied missing (_h 330 (by decide))

theorem unit11641_298    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 339) : v.neg (polarity11641 339) := by
  have exactPolarity : polarity11641 339 = (Sat.Literal.pos 632) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 632)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 632), (Sat.Literal.pos 1347)] :=
    ready 5545 (by decide) v hv
  exact satisfied missing (_h 330 (by decide))

theorem unit11641_299    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 340) : v.neg (polarity11641 340) := by
  have exactPolarity : polarity11641 340 = (Sat.Literal.pos 635) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 635)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 635), (Sat.Literal.pos 1347)] :=
    ready 5586 (by decide) v hv
  exact satisfied missing (_h 330 (by decide))

theorem unit11641_300    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 341) : v.neg (polarity11641 341) := by
  have exactPolarity : polarity11641 341 = (Sat.Literal.neg 8595) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.pos 8595)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 8594), (Sat.Literal.pos 8595)] :=
    ready 7374 (by decide) v hv
  exact satisfied (_h 334 (by decide)) missing

theorem unit11641_301    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 342) : v.neg (polarity11641 342) := by
  have exactPolarity : polarity11641 342 = (Sat.Literal.neg 6075) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.pos 6075)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 6074), (Sat.Literal.pos 6075)] :=
    ready 5305 (by decide) v hv
  exact satisfied (_h 335 (by decide)) missing

theorem unit11641_302    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 343) : v.neg (polarity11641 343) := by
  have exactPolarity : polarity11641 343 = (Sat.Literal.neg 8770) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.pos 8770)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 8769), (Sat.Literal.pos 8770)] :=
    ready 7505 (by decide) v hv
  exact satisfied (_h 336 (by decide)) missing

theorem unit11641_303    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 344) : v.neg (polarity11641 344) := by
  have exactPolarity : polarity11641 344 = (Sat.Literal.neg 8596) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.pos 8596)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 8595), (Sat.Literal.pos 8596)] :=
    ready 7375 (by decide) v hv
  exact satisfied (_h 341 (by decide)) missing

theorem unit11641_304    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 345) : v.neg (polarity11641 345) := by
  have exactPolarity : polarity11641 345 = (Sat.Literal.neg 6076) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.pos 6076)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 6075), (Sat.Literal.pos 6076)] :=
    ready 5306 (by decide) v hv
  exact satisfied (_h 342 (by decide)) missing

theorem unit11641_305    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 346) : v.neg (polarity11641 346) := by
  have exactPolarity : polarity11641 346 = (Sat.Literal.neg 8771) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.pos 8771)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 8770), (Sat.Literal.pos 8771)] :=
    ready 7506 (by decide) v hv
  exact satisfied (_h 343 (by decide)) missing

theorem unit11641_306    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 347) : v.neg (polarity11641 347) := by
  have exactPolarity : polarity11641 347 = (Sat.Literal.neg 8597) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.pos 8597)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 8596), (Sat.Literal.pos 8597)] :=
    ready 7376 (by decide) v hv
  exact satisfied (_h 344 (by decide)) missing

theorem unit11641_307    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 348) : v.neg (polarity11641 348) := by
  have exactPolarity : polarity11641 348 = (Sat.Literal.neg 6077) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.pos 6077)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 6076), (Sat.Literal.pos 6077)] :=
    ready 5307 (by decide) v hv
  exact satisfied (_h 345 (by decide)) missing

theorem unit11641_308    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 349) : v.neg (polarity11641 349) := by
  have exactPolarity : polarity11641 349 = (Sat.Literal.neg 8772) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.pos 8772)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 8771), (Sat.Literal.pos 8772)] :=
    ready 7507 (by decide) v hv
  exact satisfied (_h 346 (by decide)) missing

theorem unit11641_309    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 350) : v.neg (polarity11641 350) := by
  have exactPolarity : polarity11641 350 = (Sat.Literal.neg 8598) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.pos 8598)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 8597), (Sat.Literal.pos 8598)] :=
    ready 7377 (by decide) v hv
  exact satisfied (_h 347 (by decide)) missing

theorem unit11641_310    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 351) : v.neg (polarity11641 351) := by
  have exactPolarity : polarity11641 351 = (Sat.Literal.neg 6078) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.pos 6078)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 6077), (Sat.Literal.pos 6078)] :=
    ready 5308 (by decide) v hv
  exact satisfied (_h 348 (by decide)) missing

theorem unit11641_311    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 352) : v.neg (polarity11641 352) := by
  have exactPolarity : polarity11641 352 = (Sat.Literal.neg 8773) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.pos 8773)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 8772), (Sat.Literal.pos 8773)] :=
    ready 7508 (by decide) v hv
  exact satisfied (_h 349 (by decide)) missing

theorem segment11641_288_312    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base) :
    NegBelow v polarity11641 329 → NegBelow v polarity11641 353 :=
  ((((((extendNeg (unit11641_311 base v ready hv)) ∘ (extendNeg (unit11641_310 base v ready hv))) ∘ (extendNeg (unit11641_309 base v ready hv))) ∘ (((extendNeg (unit11641_308 base v ready hv)) ∘ (extendNeg (unit11641_307 base v ready hv))) ∘ (extendNeg (unit11641_306 base v ready hv)))) ∘ ((((extendNeg (unit11641_305 base v ready hv)) ∘ (extendNeg (unit11641_304 base v ready hv))) ∘ (extendNeg (unit11641_303 base v ready hv))) ∘ (((extendNeg (unit11641_302 base v ready hv)) ∘ (extendNeg (unit11641_301 base v ready hv))) ∘ (extendNeg (unit11641_300 base v ready hv))))) ∘ (((((extendNeg (unit11641_299 base v ready hv)) ∘ (extendNeg (unit11641_298 base v ready hv))) ∘ (extendNeg (unit11641_297 base v ready hv))) ∘ (((extendNeg (unit11641_296 base v ready hv)) ∘ (extendNeg (unit11641_295 base v ready hv))) ∘ (extendNeg (unit11641_294 base v ready hv)))) ∘ ((((extendNeg (unit11641_293 base v ready hv)) ∘ (extendNeg (unit11641_292 base v ready hv))) ∘ (extendNeg (unit11641_291 base v ready hv))) ∘ (((extendNeg (unit11641_290 base v ready hv)) ∘ (extendNeg (unit11641_289 base v ready hv))) ∘ (extendNeg (unit11641_288 base v ready hv))))))

end Euler.C14.PolarityDraft
