import C14Row11641PolarityDataDraft
namespace Euler.C14.PolarityDraft
open Euler.C14.IndexedDraft
open Euler.C14.Production (rowAt)
set_option maxRecDepth 18000
set_option maxHeartbeats 2400000
theorem unit11641_312    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 353) : v.neg (polarity11641 353) := by
  have exactPolarity : polarity11641 353 = (Sat.Literal.neg 8599) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.pos 8599)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 8598), (Sat.Literal.pos 8599)] :=
    ready 7378 (by decide) v hv
  exact satisfied (_h 350 (by decide)) missing

theorem unit11641_313    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 354) : v.neg (polarity11641 354) := by
  have exactPolarity : polarity11641 354 = (Sat.Literal.neg 6079) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.pos 6079)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 6078), (Sat.Literal.pos 6079)] :=
    ready 5309 (by decide) v hv
  exact satisfied (_h 351 (by decide)) missing

theorem unit11641_314    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 355) : v.neg (polarity11641 355) := by
  have exactPolarity : polarity11641 355 = (Sat.Literal.neg 8774) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.pos 8774)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 8773), (Sat.Literal.pos 8774)] :=
    ready 7509 (by decide) v hv
  exact satisfied (_h 352 (by decide)) missing

theorem unit11641_315    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 356) : v.neg (polarity11641 356) := by
  have exactPolarity : polarity11641 356 = (Sat.Literal.neg 8600) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.pos 8600)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 8599), (Sat.Literal.pos 8600)] :=
    ready 7389 (by decide) v hv
  exact satisfied (_h 353 (by decide)) missing

theorem unit11641_316    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 357) : v.neg (polarity11641 357) := by
  have exactPolarity : polarity11641 357 = (Sat.Literal.neg 6080) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.pos 6080)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 6079), (Sat.Literal.pos 6080)] :=
    ready 5311 (by decide) v hv
  exact satisfied (_h 354 (by decide)) missing

theorem unit11641_317    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 358) : v.neg (polarity11641 358) := by
  have exactPolarity : polarity11641 358 = (Sat.Literal.neg 8775) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.pos 8775)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 8774), (Sat.Literal.pos 8775)] :=
    ready 7510 (by decide) v hv
  exact satisfied (_h 355 (by decide)) missing

theorem unit11641_318    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 359) : v.neg (polarity11641 359) := by
  have exactPolarity : polarity11641 359 = (Sat.Literal.pos 706) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 706)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 706), (Sat.Literal.neg 8600)] :=
    ready 6076 (by decide) v hv
  exact satisfied missing (_h 356 (by decide))

theorem unit11641_319    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 360) : v.neg (polarity11641 360) := by
  have exactPolarity : polarity11641 360 = (Sat.Literal.neg 8601) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.pos 8601)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 8600), (Sat.Literal.pos 8601)] :=
    ready 7390 (by decide) v hv
  exact satisfied (_h 356 (by decide)) missing

theorem unit11641_320    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 361) : v.neg (polarity11641 361) := by
  have exactPolarity : polarity11641 361 = (Sat.Literal.neg 6081) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.pos 6081)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 6080), (Sat.Literal.pos 6081)] :=
    ready 5312 (by decide) v hv
  exact satisfied (_h 357 (by decide)) missing

theorem unit11641_321    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 362) : v.neg (polarity11641 362) := by
  have exactPolarity : polarity11641 362 = (Sat.Literal.neg 8776) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.pos 8776)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 8775), (Sat.Literal.pos 8776)] :=
    ready 7511 (by decide) v hv
  exact satisfied (_h 358 (by decide)) missing

theorem unit11641_322    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 363) : v.neg (polarity11641 363) := by
  have exactPolarity : polarity11641 363 = (Sat.Literal.neg 8602) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.pos 8602)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 8601), (Sat.Literal.pos 8602)] :=
    ready 7391 (by decide) v hv
  exact satisfied (_h 360 (by decide)) missing

theorem unit11641_323    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 364) : v.neg (polarity11641 364) := by
  have exactPolarity : polarity11641 364 = (Sat.Literal.neg 6082) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.pos 6082)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 6081), (Sat.Literal.pos 6082)] :=
    ready 5313 (by decide) v hv
  exact satisfied (_h 361 (by decide)) missing

theorem unit11641_324    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 365) : v.neg (polarity11641 365) := by
  have exactPolarity : polarity11641 365 = (Sat.Literal.neg 8777) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.pos 8777)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 8776), (Sat.Literal.pos 8777)] :=
    ready 7512 (by decide) v hv
  exact satisfied (_h 362 (by decide)) missing

theorem unit11641_325    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 366) : v.neg (polarity11641 366) := by
  have exactPolarity : polarity11641 366 = (Sat.Literal.neg 8603) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.pos 8603)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 8602), (Sat.Literal.pos 8603)] :=
    ready 7392 (by decide) v hv
  exact satisfied (_h 363 (by decide)) missing

theorem unit11641_326    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 367) : v.neg (polarity11641 367) := by
  have exactPolarity : polarity11641 367 = (Sat.Literal.neg 6083) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.pos 6083)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 6082), (Sat.Literal.pos 6083)] :=
    ready 5314 (by decide) v hv
  exact satisfied (_h 364 (by decide)) missing

theorem unit11641_327    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 368) : v.neg (polarity11641 368) := by
  have exactPolarity : polarity11641 368 = (Sat.Literal.neg 8778) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.pos 8778)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 8777), (Sat.Literal.pos 8778)] :=
    ready 7513 (by decide) v hv
  exact satisfied (_h 365 (by decide)) missing

theorem unit11641_328    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 369) : v.neg (polarity11641 369) := by
  have exactPolarity : polarity11641 369 = (Sat.Literal.neg 8604) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.pos 8604)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 8603), (Sat.Literal.pos 8604)] :=
    ready 7393 (by decide) v hv
  exact satisfied (_h 366 (by decide)) missing

theorem unit11641_329    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 370) : v.neg (polarity11641 370) := by
  have exactPolarity : polarity11641 370 = (Sat.Literal.neg 6084) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.pos 6084)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 6083), (Sat.Literal.pos 6084)] :=
    ready 5315 (by decide) v hv
  exact satisfied (_h 367 (by decide)) missing

theorem unit11641_330    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 371) : v.neg (polarity11641 371) := by
  have exactPolarity : polarity11641 371 = (Sat.Literal.neg 8779) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.pos 8779)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 8778), (Sat.Literal.pos 8779)] :=
    ready 7514 (by decide) v hv
  exact satisfied (_h 368 (by decide)) missing

theorem unit11641_331    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 372) : v.neg (polarity11641 372) := by
  have exactPolarity : polarity11641 372 = (Sat.Literal.pos 850) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 850)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 850), (Sat.Literal.neg 8604)] :=
    ready 7257 (by decide) v hv
  exact satisfied missing (_h 369 (by decide))

theorem unit11641_332    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 373) : v.neg (polarity11641 373) := by
  have exactPolarity : polarity11641 373 = (Sat.Literal.neg 6085) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.pos 6085)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 6084), (Sat.Literal.pos 6085)] :=
    ready 5316 (by decide) v hv
  exact satisfied (_h 370 (by decide)) missing

theorem unit11641_333    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 374) : v.neg (polarity11641 374) := by
  have exactPolarity : polarity11641 374 = (Sat.Literal.neg 8780) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.pos 8780)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 8779), (Sat.Literal.pos 8780)] :=
    ready 7516 (by decide) v hv
  exact satisfied (_h 371 (by decide)) missing

theorem unit11641_334    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 375) : v.neg (polarity11641 375) := by
  have exactPolarity : polarity11641 375 = (Sat.Literal.neg 856) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.pos 856)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 1390), (Sat.Literal.pos 670), (Sat.Literal.pos 676), (Sat.Literal.pos 682), (Sat.Literal.pos 688), (Sat.Literal.pos 706), (Sat.Literal.pos 712), (Sat.Literal.pos 718), (Sat.Literal.pos 730), (Sat.Literal.pos 742), (Sat.Literal.pos 748), (Sat.Literal.pos 754), (Sat.Literal.pos 796), (Sat.Literal.pos 802), (Sat.Literal.pos 814), (Sat.Literal.pos 820), (Sat.Literal.pos 826), (Sat.Literal.pos 832), (Sat.Literal.pos 838), (Sat.Literal.pos 850), (Sat.Literal.pos 856), (Sat.Literal.pos 862)] :=
    ready 9160 (by decide) v hv
  exact satisfied (_h 36 (by decide)) (_h 63 (by decide)) (_h 64 (by decide)) (_h 65 (by decide)) (_h 165 (by decide)) (_h 359 (by decide)) (_h 14 (by decide)) (_h 294 (by decide)) (_h 246 (by decide)) (_h 249 (by decide)) (_h 252 (by decide)) (_h 255 (by decide)) (_h 166 (by decide)) (_h 274 (by decide)) (_h 276 (by decide)) (_h 279 (by decide)) (_h 281 (by decide)) (_h 167 (by decide)) (_h 282 (by decide)) (_h 372 (by decide)) missing (_h 318 (by decide))

theorem unit11641_335    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 376) : v.neg (polarity11641 376) := by
  have exactPolarity : polarity11641 376 = (Sat.Literal.neg 6086) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.pos 6086)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 6085), (Sat.Literal.pos 6086)] :=
    ready 5317 (by decide) v hv
  exact satisfied (_h 373 (by decide)) missing

theorem segment11641_312_336    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base) :
    NegBelow v polarity11641 353 → NegBelow v polarity11641 377 :=
  ((((((extendNeg (unit11641_335 base v ready hv)) ∘ (extendNeg (unit11641_334 base v ready hv))) ∘ (extendNeg (unit11641_333 base v ready hv))) ∘ (((extendNeg (unit11641_332 base v ready hv)) ∘ (extendNeg (unit11641_331 base v ready hv))) ∘ (extendNeg (unit11641_330 base v ready hv)))) ∘ ((((extendNeg (unit11641_329 base v ready hv)) ∘ (extendNeg (unit11641_328 base v ready hv))) ∘ (extendNeg (unit11641_327 base v ready hv))) ∘ (((extendNeg (unit11641_326 base v ready hv)) ∘ (extendNeg (unit11641_325 base v ready hv))) ∘ (extendNeg (unit11641_324 base v ready hv))))) ∘ (((((extendNeg (unit11641_323 base v ready hv)) ∘ (extendNeg (unit11641_322 base v ready hv))) ∘ (extendNeg (unit11641_321 base v ready hv))) ∘ (((extendNeg (unit11641_320 base v ready hv)) ∘ (extendNeg (unit11641_319 base v ready hv))) ∘ (extendNeg (unit11641_318 base v ready hv)))) ∘ ((((extendNeg (unit11641_317 base v ready hv)) ∘ (extendNeg (unit11641_316 base v ready hv))) ∘ (extendNeg (unit11641_315 base v ready hv))) ∘ (((extendNeg (unit11641_314 base v ready hv)) ∘ (extendNeg (unit11641_313 base v ready hv))) ∘ (extendNeg (unit11641_312 base v ready hv))))))

end Euler.C14.PolarityDraft
