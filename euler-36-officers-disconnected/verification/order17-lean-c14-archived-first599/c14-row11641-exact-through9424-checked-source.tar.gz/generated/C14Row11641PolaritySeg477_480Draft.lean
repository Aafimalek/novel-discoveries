import C14Row11641PolarityDataDraft
namespace Euler.C14.PolarityDraft
open Euler.C14.IndexedDraft
open Euler.C14.Production (rowAt)
set_option maxRecDepth 18000
set_option maxHeartbeats 2400000
theorem unit11641_477    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 518) : v.neg (polarity11641 518) := by
  have exactPolarity : polarity11641 518 = (Sat.Literal.pos 1286) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 1286)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 1286), (Sat.Literal.neg 3993)] :=
    ready 1574 (by decide) v hv
  exact satisfied missing (_h 516 (by decide))

theorem unit11641_478    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 519) : v.neg (polarity11641 519) := by
  have exactPolarity : polarity11641 519 = (Sat.Literal.pos 1502) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 1502)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 1502), (Sat.Literal.pos 98), (Sat.Literal.pos 134), (Sat.Literal.pos 170), (Sat.Literal.pos 206), (Sat.Literal.pos 494), (Sat.Literal.pos 566), (Sat.Literal.pos 602), (Sat.Literal.pos 638), (Sat.Literal.pos 710), (Sat.Literal.pos 746), (Sat.Literal.pos 818), (Sat.Literal.pos 854), (Sat.Literal.pos 926), (Sat.Literal.pos 962), (Sat.Literal.pos 998), (Sat.Literal.pos 1034), (Sat.Literal.pos 1070), (Sat.Literal.pos 1142), (Sat.Literal.pos 1178), (Sat.Literal.pos 1214), (Sat.Literal.pos 1250), (Sat.Literal.pos 1286)] :=
    ready 9246 (by decide) v hv
  exact satisfied missing (_h 154 (by decide)) (_h 130 (by decide)) (_h 100 (by decide)) (_h 117 (by decide)) (_h 238 (by decide)) (_h 325 (by decide)) (_h 326 (by decide)) (_h 328 (by decide)) (_h 13 (by decide)) (_h 250 (by decide)) (_h 277 (by decide)) (_h 388 (by decide)) (_h 257 (by decide)) (_h 443 (by decide)) (_h 384 (by decide)) (_h 438 (by decide)) (_h 442 (by decide)) (_h 435 (by decide)) (_h 267 (by decide)) (_h 477 (by decide)) (_h 496 (by decide)) (_h 518 (by decide))

theorem unit11641_479    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 520) : v.neg (polarity11641 520) := by
  have exactPolarity : polarity11641 520 = (Sat.Literal.neg 1454) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.pos 1454)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.pos 1298), (Sat.Literal.pos 1336), (Sat.Literal.pos 1370), (Sat.Literal.pos 1420), (Sat.Literal.pos 1454), (Sat.Literal.pos 1502)] :=
    ready 8226 (by decide) v hv
  exact satisfied (_h 138 (by decide)) (_h 162 (by decide)) (_h 156 (by decide)) (_h 452 (by decide)) missing (_h 519 (by decide))

theorem segment11641_477_480    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base) :
    NegBelow v polarity11641 518 → NegBelow v polarity11641 521 :=
  (((extendNeg (unit11641_479 base v ready hv)) ∘ (extendNeg (unit11641_478 base v ready hv))) ∘ (extendNeg (unit11641_477 base v ready hv)))

end Euler.C14.PolarityDraft
