import C14Row11641PolarityDataDraft
namespace Euler.C14.PolarityDraft
open Euler.C14.IndexedDraft
open Euler.C14.Production (rowAt)
set_option maxRecDepth 18000
set_option maxHeartbeats 2400000
theorem unit11641_216    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 257) : v.neg (polarity11641 257) := by
  have exactPolarity : polarity11641 257 = (Sat.Literal.pos 926) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 926)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 926), (Sat.Literal.pos 1321)] :=
    ready 7795 (by decide) v hv
  exact satisfied missing (_h 27 (by decide))

theorem unit11641_217    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 258) : v.neg (polarity11641 258) := by
  have exactPolarity : polarity11641 258 = (Sat.Literal.neg 1361) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.pos 1361)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.pos 1321), (Sat.Literal.pos 1361), (Sat.Literal.pos 1392), (Sat.Literal.pos 1415), (Sat.Literal.pos 1446), (Sat.Literal.pos 1506)] :=
    ready 8345 (by decide) v hv
  exact satisfied (_h 27 (by decide)) missing (_h 180 (by decide)) (_h 39 (by decide)) (_h 207 (by decide)) (_h 209 (by decide))

theorem unit11641_218    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 259) : v.neg (polarity11641 259) := by
  have exactPolarity : polarity11641 259 = (Sat.Literal.pos 1161) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 1161)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 1161), (Sat.Literal.pos 1328)] :=
    ready 870 (by decide) v hv
  exact satisfied missing (_h 28 (by decide))

theorem unit11641_219    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 260) : v.neg (polarity11641 260) := by
  have exactPolarity : polarity11641 260 = (Sat.Literal.pos 1162) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 1162)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 1162), (Sat.Literal.pos 1328)] :=
    ready 878 (by decide) v hv
  exact satisfied missing (_h 28 (by decide))

theorem unit11641_220    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 261) : v.neg (polarity11641 261) := by
  have exactPolarity : polarity11641 261 = (Sat.Literal.pos 1163) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 1163)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 1163), (Sat.Literal.pos 1328)] :=
    ready 885 (by decide) v hv
  exact satisfied missing (_h 28 (by decide))

theorem unit11641_221    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 262) : v.neg (polarity11641 262) := by
  have exactPolarity : polarity11641 262 = (Sat.Literal.pos 1166) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 1166)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 1166), (Sat.Literal.pos 1328)] :=
    ready 898 (by decide) v hv
  exact satisfied missing (_h 28 (by decide))

theorem unit11641_222    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 263) : v.neg (polarity11641 263) := by
  have exactPolarity : polarity11641 263 = (Sat.Literal.pos 1168) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 1168)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 1168), (Sat.Literal.pos 1328)] :=
    ready 921 (by decide) v hv
  exact satisfied missing (_h 28 (by decide))

theorem unit11641_223    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 264) : v.neg (polarity11641 264) := by
  have exactPolarity : polarity11641 264 = (Sat.Literal.pos 1169) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 1169)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 1169), (Sat.Literal.pos 1328)] :=
    ready 933 (by decide) v hv
  exact satisfied missing (_h 28 (by decide))

theorem unit11641_224    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 265) : v.neg (polarity11641 265) := by
  have exactPolarity : polarity11641 265 = (Sat.Literal.pos 1172) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 1172)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 1172), (Sat.Literal.pos 1328)] :=
    ready 946 (by decide) v hv
  exact satisfied missing (_h 28 (by decide))

theorem unit11641_225    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 266) : v.neg (polarity11641 266) := by
  have exactPolarity : polarity11641 266 = (Sat.Literal.pos 1175) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 1175)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 1175), (Sat.Literal.pos 1328)] :=
    ready 979 (by decide) v hv
  exact satisfied missing (_h 28 (by decide))

theorem unit11641_226    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 267) : v.neg (polarity11641 267) := by
  have exactPolarity : polarity11641 267 = (Sat.Literal.pos 1178) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 1178)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 1178), (Sat.Literal.pos 1328)] :=
    ready 992 (by decide) v hv
  exact satisfied missing (_h 28 (by decide))

theorem unit11641_227    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 268) : v.neg (polarity11641 268) := by
  have exactPolarity : polarity11641 268 = (Sat.Literal.pos 1179) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 1179)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 1179), (Sat.Literal.pos 1328)] :=
    ready 1004 (by decide) v hv
  exact satisfied missing (_h 28 (by decide))

theorem unit11641_228    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 269) : v.neg (polarity11641 269) := by
  have exactPolarity : polarity11641 269 = (Sat.Literal.pos 1180) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 1180)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 1180), (Sat.Literal.pos 1328)] :=
    ready 1015 (by decide) v hv
  exact satisfied missing (_h 28 (by decide))

theorem unit11641_229    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 270) : v.neg (polarity11641 270) := by
  have exactPolarity : polarity11641 270 = (Sat.Literal.pos 1181) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 1181)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 1181), (Sat.Literal.pos 1328)] :=
    ready 1025 (by decide) v hv
  exact satisfied missing (_h 28 (by decide))

theorem unit11641_230    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 271) : v.neg (polarity11641 271) := by
  have exactPolarity : polarity11641 271 = (Sat.Literal.pos 1184) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 1184)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 1184), (Sat.Literal.pos 1328)] :=
    ready 1036 (by decide) v hv
  exact satisfied missing (_h 28 (by decide))

theorem unit11641_231    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 272) : v.neg (polarity11641 272) := by
  have exactPolarity : polarity11641 272 = (Sat.Literal.pos 1187) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 1187)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 1187), (Sat.Literal.pos 1328)] :=
    ready 1064 (by decide) v hv
  exact satisfied missing (_h 28 (by decide))

theorem unit11641_232    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 273) : v.neg (polarity11641 273) := by
  have exactPolarity : polarity11641 273 = (Sat.Literal.pos 1345) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 1345)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 1345), (Sat.Literal.pos 1328), (Sat.Literal.pos 1351)] :=
    ready 9368 (by decide) v hv
  exact satisfied missing (_h 28 (by decide)) (_h 30 (by decide))

theorem unit11641_233    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 274) : v.neg (polarity11641 274) := by
  have exactPolarity : polarity11641 274 = (Sat.Literal.pos 802) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 802)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 802), (Sat.Literal.pos 1318)] :=
    ready 6846 (by decide) v hv
  exact satisfied missing (_h 26 (by decide))

theorem unit11641_234    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 275) : v.neg (polarity11641 275) := by
  have exactPolarity : polarity11641 275 = (Sat.Literal.pos 812) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 812)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 812), (Sat.Literal.pos 1318)] :=
    ready 6945 (by decide) v hv
  exact satisfied missing (_h 26 (by decide))

theorem unit11641_235    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 276) : v.neg (polarity11641 276) := by
  have exactPolarity : polarity11641 276 = (Sat.Literal.pos 814) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 814)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 814), (Sat.Literal.pos 1318)] :=
    ready 6972 (by decide) v hv
  exact satisfied missing (_h 26 (by decide))

theorem unit11641_236    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 277) : v.neg (polarity11641 277) := by
  have exactPolarity : polarity11641 277 = (Sat.Literal.pos 818) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 818)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 818), (Sat.Literal.pos 1318)] :=
    ready 7002 (by decide) v hv
  exact satisfied missing (_h 26 (by decide))

theorem unit11641_237    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 278) : v.neg (polarity11641 278) := by
  have exactPolarity : polarity11641 278 = (Sat.Literal.pos 819) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 819)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 819), (Sat.Literal.pos 1318)] :=
    ready 7015 (by decide) v hv
  exact satisfied missing (_h 26 (by decide))

theorem unit11641_238    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 279) : v.neg (polarity11641 279) := by
  have exactPolarity : polarity11641 279 = (Sat.Literal.pos 820) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 820)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 820), (Sat.Literal.pos 1318)] :=
    ready 7025 (by decide) v hv
  exact satisfied missing (_h 26 (by decide))

theorem unit11641_239    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 280) : v.neg (polarity11641 280) := by
  have exactPolarity : polarity11641 280 = (Sat.Literal.pos 824) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 824)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 824), (Sat.Literal.pos 1318)] :=
    ready 7072 (by decide) v hv
  exact satisfied missing (_h 26 (by decide))

theorem segment11641_216_240    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base) :
    NegBelow v polarity11641 257 → NegBelow v polarity11641 281 :=
  ((((((extendNeg (unit11641_239 base v ready hv)) ∘ (extendNeg (unit11641_238 base v ready hv))) ∘ (extendNeg (unit11641_237 base v ready hv))) ∘ (((extendNeg (unit11641_236 base v ready hv)) ∘ (extendNeg (unit11641_235 base v ready hv))) ∘ (extendNeg (unit11641_234 base v ready hv)))) ∘ ((((extendNeg (unit11641_233 base v ready hv)) ∘ (extendNeg (unit11641_232 base v ready hv))) ∘ (extendNeg (unit11641_231 base v ready hv))) ∘ (((extendNeg (unit11641_230 base v ready hv)) ∘ (extendNeg (unit11641_229 base v ready hv))) ∘ (extendNeg (unit11641_228 base v ready hv))))) ∘ (((((extendNeg (unit11641_227 base v ready hv)) ∘ (extendNeg (unit11641_226 base v ready hv))) ∘ (extendNeg (unit11641_225 base v ready hv))) ∘ (((extendNeg (unit11641_224 base v ready hv)) ∘ (extendNeg (unit11641_223 base v ready hv))) ∘ (extendNeg (unit11641_222 base v ready hv)))) ∘ ((((extendNeg (unit11641_221 base v ready hv)) ∘ (extendNeg (unit11641_220 base v ready hv))) ∘ (extendNeg (unit11641_219 base v ready hv))) ∘ (((extendNeg (unit11641_218 base v ready hv)) ∘ (extendNeg (unit11641_217 base v ready hv))) ∘ (extendNeg (unit11641_216 base v ready hv))))))

end Euler.C14.PolarityDraft
