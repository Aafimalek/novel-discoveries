import C14Row11641PolarityAudit
import C14ExactThrough9423

namespace Euler.C14.PolarityDraft
open Euler.C14.IndexedDraft
open Euler.C14.Production

theorem exactArchiveThrough9424 :
    GoodBelow archivedGlobalCore rowAt 9424 :=
  slice11641 archivedGlobalCore exactArchiveThrough9423

#print axioms exactArchiveThrough9424

end Euler.C14.PolarityDraft
