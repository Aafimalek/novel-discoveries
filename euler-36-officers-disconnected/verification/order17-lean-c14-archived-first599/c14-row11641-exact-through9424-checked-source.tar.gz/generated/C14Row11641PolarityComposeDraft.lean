import C14Row11641PolaritySeg000_024Draft
import C14Row11641PolaritySeg024_048Draft
import C14Row11641PolaritySeg048_072Draft
import C14Row11641PolaritySeg072_096Draft
import C14Row11641PolaritySeg096_120Draft
import C14Row11641PolaritySeg120_144Draft
import C14Row11641PolaritySeg144_168Draft
import C14Row11641PolaritySeg168_192Draft
import C14Row11641PolaritySeg192_216Draft
import C14Row11641PolaritySeg216_240Draft
import C14Row11641PolaritySeg240_264Draft
import C14Row11641PolaritySeg264_288Draft
import C14Row11641PolaritySeg288_312Draft
import C14Row11641PolaritySeg312_336Draft
import C14Row11641PolaritySeg336_360Draft
import C14Row11641PolaritySeg360_384Draft
import C14Row11641PolaritySeg384_408Draft
import C14Row11641PolaritySeg408_432Draft
import C14Row11641PolaritySeg432_456Draft
import C14Row11641PolaritySeg456_462Draft
import C14Row11641PolaritySeg462_464Draft
import C14Row11641PolaritySeg464_465Draft
import C14Row11641PolaritySeg465_471Draft
import C14Row11641PolaritySeg471_476Draft
import C14Row11641PolaritySeg476_477Draft
import C14Row11641PolaritySeg477_480Draft
import C14Row11641PolaritySeg480_481Draft
import C14Row11641PolaritySeg481_482Draft
import C14Row11641PolaritySeg482_488Draft
import C14Row11641PolaritySeg488_494Draft
import C14Row11641PolaritySeg494_500Draft
import C14Row11641PolaritySeg500_505Draft
import C14Row11641PolaritySeg505_506Draft
import C14Row11641PolaritySeg506_509Draft
import C14Row11641PolarityTerminalDraft
namespace Euler.C14.PolarityDraft
open Euler.C14.IndexedDraft
open Euler.C14.Production (rowAt)
set_option maxRecDepth 18000
set_option maxHeartbeats 2400000

theorem step11641 (base : Sat.Fmla) (ready : GoodBelow base rowAt 9423) :
    base.proof (rowAt 9423) := by
  rw [actualTarget11641]
  intro v hv
  apply satisfies_of_falsified_imp_false
  intro h
  have advance : NegBelow v polarity11641 41 → NegBelow v polarity11641 550 :=
    (((((((segment11641_506_509 base v ready hv) ∘ (segment11641_505_506 base v ready hv)) ∘ (segment11641_500_505 base v ready hv)) ∘ ((segment11641_494_500 base v ready hv) ∘ (segment11641_488_494 base v ready hv))) ∘ (((segment11641_482_488 base v ready hv) ∘ (segment11641_481_482 base v ready hv)) ∘ ((segment11641_480_481 base v ready hv) ∘ (segment11641_477_480 base v ready hv)))) ∘ ((((segment11641_476_477 base v ready hv) ∘ (segment11641_471_476 base v ready hv)) ∘ ((segment11641_465_471 base v ready hv) ∘ (segment11641_464_465 base v ready hv))) ∘ (((segment11641_462_464 base v ready hv) ∘ (segment11641_456_462 base v ready hv)) ∘ ((segment11641_432_456 base v ready hv) ∘ (segment11641_408_432 base v ready hv))))) ∘ ((((((segment11641_384_408 base v ready hv) ∘ (segment11641_360_384 base v ready hv)) ∘ (segment11641_336_360 base v ready hv)) ∘ ((segment11641_312_336 base v ready hv) ∘ (segment11641_288_312 base v ready hv))) ∘ (((segment11641_264_288 base v ready hv) ∘ (segment11641_240_264 base v ready hv)) ∘ ((segment11641_216_240 base v ready hv) ∘ (segment11641_192_216 base v ready hv)))) ∘ ((((segment11641_168_192 base v ready hv) ∘ (segment11641_144_168 base v ready hv)) ∘ ((segment11641_120_144 base v ready hv) ∘ (segment11641_96_120 base v ready hv))) ∘ (((segment11641_72_96 base v ready hv) ∘ (segment11641_48_72 base v ready hv)) ∘ ((segment11641_24_48 base v ready hv) ∘ (segment11641_0_24 base v ready hv))))))
  exact close11641 base v ready hv (advance (init11641 v h))

theorem slice11641 (base : Sat.Fmla) : Slice base rowAt 9423 9424 :=
  extend (step11641 base)

#print axioms slice11641
end Euler.C14.PolarityDraft
