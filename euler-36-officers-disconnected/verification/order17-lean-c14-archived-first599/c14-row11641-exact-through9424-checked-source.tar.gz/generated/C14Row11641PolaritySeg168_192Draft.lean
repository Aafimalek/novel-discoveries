import C14Row11641PolarityDataDraft
namespace Euler.C14.PolarityDraft
open Euler.C14.IndexedDraft
open Euler.C14.Production (rowAt)
set_option maxRecDepth 18000
set_option maxHeartbeats 2400000
theorem unit11641_168    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 209) : v.neg (polarity11641 209) := by
  have exactPolarity : polarity11641 209 = (Sat.Literal.pos 1506) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 1506)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 1506), (Sat.Literal.pos 282), (Sat.Literal.pos 318), (Sat.Literal.pos 390), (Sat.Literal.pos 426), (Sat.Literal.pos 498), (Sat.Literal.pos 606), (Sat.Literal.pos 642), (Sat.Literal.pos 930), (Sat.Literal.pos 966), (Sat.Literal.pos 1038), (Sat.Literal.pos 1074), (Sat.Literal.pos 1146), (Sat.Literal.pos 1182), (Sat.Literal.pos 1254), (Sat.Literal.pos 1290)] :=
    ready 9250 (by decide) v hv
  exact satisfied missing (_h 171 (by decide)) (_h 174 (by decide)) (_h 177 (by decide)) (_h 179 (by decide)) (_h 199 (by decide)) (_h 203 (by decide)) (_h 206 (by decide)) (_h 190 (by decide)) (_h 194 (by decide)) (_h 184 (by decide)) (_h 187 (by decide)) (_h 44 (by decide)) (_h 48 (by decide)) (_h 52 (by decide)) (_h 55 (by decide))

theorem unit11641_169    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 210) : v.neg (polarity11641 210) := by
  have exactPolarity : polarity11641 210 = (Sat.Literal.pos 1464) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 1464)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 1464), (Sat.Literal.pos 378), (Sat.Literal.pos 384), (Sat.Literal.pos 390), (Sat.Literal.pos 582), (Sat.Literal.pos 594), (Sat.Literal.pos 600), (Sat.Literal.pos 606), (Sat.Literal.pos 1014), (Sat.Literal.pos 1026), (Sat.Literal.pos 1032), (Sat.Literal.pos 1038), (Sat.Literal.pos 1230), (Sat.Literal.pos 1242), (Sat.Literal.pos 1248), (Sat.Literal.pos 1254)] :=
    ready 9216 (by decide) v hv
  exact satisfied missing (_h 175 (by decide)) (_h 176 (by decide)) (_h 177 (by decide)) (_h 200 (by decide)) (_h 201 (by decide)) (_h 202 (by decide)) (_h 203 (by decide)) (_h 181 (by decide)) (_h 182 (by decide)) (_h 183 (by decide)) (_h 184 (by decide)) (_h 49 (by decide)) (_h 50 (by decide)) (_h 51 (by decide)) (_h 52 (by decide))

theorem unit11641_170    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 211) : v.neg (polarity11641 211) := by
  have exactPolarity : polarity11641 211 = (Sat.Literal.pos 1482) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 1482)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 1482), (Sat.Literal.pos 582), (Sat.Literal.pos 618), (Sat.Literal.pos 942), (Sat.Literal.pos 1014), (Sat.Literal.pos 1050), (Sat.Literal.pos 1158), (Sat.Literal.pos 1230), (Sat.Literal.pos 1266)] :=
    ready 9230 (by decide) v hv
  exact satisfied missing (_h 200 (by decide)) (_h 204 (by decide)) (_h 191 (by decide)) (_h 181 (by decide)) (_h 185 (by decide)) (_h 45 (by decide)) (_h 49 (by decide)) (_h 53 (by decide))

theorem unit11641_171    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 212) : v.neg (polarity11641 212) := by
  have exactPolarity : polarity11641 212 = (Sat.Literal.pos 1019) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 1019)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 1019), (Sat.Literal.pos 1357)] :=
    ready 162 (by decide) v hv
  exact satisfied missing (_h 32 (by decide))

theorem unit11641_172    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 213) : v.neg (polarity11641 213) := by
  have exactPolarity : polarity11641 213 = (Sat.Literal.pos 1055) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 1055)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 1055), (Sat.Literal.pos 1357)] :=
    ready 428 (by decide) v hv
  exact satisfied missing (_h 32 (by decide))

theorem unit11641_173    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 214) : v.neg (polarity11641 214) := by
  have exactPolarity : polarity11641 214 = (Sat.Literal.pos 945) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 945)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 945), (Sat.Literal.pos 1357)] :=
    ready 7866 (by decide) v hv
  exact satisfied missing (_h 32 (by decide))

theorem unit11641_174    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 215) : v.neg (polarity11641 215) := by
  have exactPolarity : polarity11641 215 = (Sat.Literal.pos 946) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 946)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 946), (Sat.Literal.pos 1357)] :=
    ready 7871 (by decide) v hv
  exact satisfied missing (_h 32 (by decide))

theorem unit11641_175    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 216) : v.neg (polarity11641 216) := by
  have exactPolarity : polarity11641 216 = (Sat.Literal.pos 947) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 947)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 947), (Sat.Literal.pos 1357)] :=
    ready 7875 (by decide) v hv
  exact satisfied missing (_h 32 (by decide))

theorem unit11641_176    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 217) : v.neg (polarity11641 217) := by
  have exactPolarity : polarity11641 217 = (Sat.Literal.pos 983) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 983)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 983), (Sat.Literal.pos 1357)] :=
    ready 8061 (by decide) v hv
  exact satisfied missing (_h 32 (by decide))

theorem unit11641_177    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 218) : v.neg (polarity11641 218) := by
  have exactPolarity : polarity11641 218 = (Sat.Literal.pos 268) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 268)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 268), (Sat.Literal.pos 1340)] :=
    ready 2403 (by decide) v hv
  exact satisfied missing (_h 29 (by decide))

theorem unit11641_178    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 219) : v.neg (polarity11641 219) := by
  have exactPolarity : polarity11641 219 = (Sat.Literal.pos 304) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 304)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 304), (Sat.Literal.pos 1340)] :=
    ready 2690 (by decide) v hv
  exact satisfied missing (_h 29 (by decide))

theorem unit11641_179    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 220) : v.neg (polarity11641 220) := by
  have exactPolarity : polarity11641 220 = (Sat.Literal.pos 376) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 376)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 376), (Sat.Literal.pos 1340)] :=
    ready 3352 (by decide) v hv
  exact satisfied missing (_h 29 (by decide))

theorem unit11641_180    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 221) : v.neg (polarity11641 221) := by
  have exactPolarity : polarity11641 221 = (Sat.Literal.neg 1341) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.pos 1341)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 346), (Sat.Literal.pos 1341)] :=
    ready 3060 (by decide) v hv
  exact satisfied (_h 3 (by decide)) missing

theorem unit11641_181    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 222) : v.neg (polarity11641 222) := by
  have exactPolarity : polarity11641 222 = (Sat.Literal.neg 8591) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.pos 8591)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 346), (Sat.Literal.pos 8591)] :=
    ready 3063 (by decide) v hv
  exact satisfied (_h 3 (by decide)) missing

theorem unit11641_182    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 223) : v.neg (polarity11641 223) := by
  have exactPolarity : polarity11641 223 = (Sat.Literal.neg 1379) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.pos 1379)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.pos 1372), (Sat.Literal.pos 1373), (Sat.Literal.neg 1378), (Sat.Literal.pos 1379)] :=
    ready 8844 (by decide) v hv
  exact satisfied (_h 159 (by decide)) (_h 160 (by decide)) (_h 33 (by decide)) missing

theorem unit11641_183    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 224) : v.neg (polarity11641 224) := by
  have exactPolarity : polarity11641 224 = (Sat.Literal.neg 1342) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.pos 1342)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 351), (Sat.Literal.pos 1342)] :=
    ready 3116 (by decide) v hv
  exact satisfied (_h 4 (by decide)) missing

theorem unit11641_184    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 225) : v.neg (polarity11641 225) := by
  have exactPolarity : polarity11641 225 = (Sat.Literal.neg 1377) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.pos 1377)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 351), (Sat.Literal.pos 1377)] :=
    ready 3117 (by decide) v hv
  exact satisfied (_h 4 (by decide)) missing

theorem unit11641_185    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 226) : v.neg (polarity11641 226) := by
  have exactPolarity : polarity11641 226 = (Sat.Literal.neg 6071) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.pos 6071)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 351), (Sat.Literal.pos 6071)] :=
    ready 3119 (by decide) v hv
  exact satisfied (_h 4 (by decide)) missing

theorem unit11641_186    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 227) : v.neg (polarity11641 227) := by
  have exactPolarity : polarity11641 227 = (Sat.Literal.neg 8766) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.pos 8766)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 351), (Sat.Literal.pos 8766)] :=
    ready 3120 (by decide) v hv
  exact satisfied (_h 4 (by decide)) missing

theorem unit11641_187    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 228) : v.neg (polarity11641 228) := by
  have exactPolarity : polarity11641 228 = (Sat.Literal.neg 1343) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.pos 1343)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.pos 1303), (Sat.Literal.pos 1343), (Sat.Literal.pos 1374), (Sat.Literal.pos 1415), (Sat.Literal.pos 1446), (Sat.Literal.pos 1506)] :=
    ready 8255 (by decide) v hv
  exact satisfied (_h 20 (by decide)) missing (_h 168 (by decide)) (_h 39 (by decide)) (_h 207 (by decide)) (_h 209 (by decide))

theorem unit11641_188    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 229) : v.neg (polarity11641 229) := by
  have exactPolarity : polarity11641 229 = (Sat.Literal.pos 379) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 379)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 379), (Sat.Literal.pos 1306)] :=
    ready 3385 (by decide) v hv
  exact satisfied missing (_h 21 (by decide))

theorem unit11641_189    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 230) : v.neg (polarity11641 230) := by
  have exactPolarity : polarity11641 230 = (Sat.Literal.pos 385) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 385)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 385), (Sat.Literal.pos 1306)] :=
    ready 3419 (by decide) v hv
  exact satisfied missing (_h 21 (by decide))

theorem unit11641_190    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 231) : v.neg (polarity11641 231) := by
  have exactPolarity : polarity11641 231 = (Sat.Literal.pos 387) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 387)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 387), (Sat.Literal.pos 1306)] :=
    ready 3431 (by decide) v hv
  exact satisfied missing (_h 21 (by decide))

theorem unit11641_191    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 232) : v.neg (polarity11641 232) := by
  have exactPolarity : polarity11641 232 = (Sat.Literal.pos 388) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 388)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 388), (Sat.Literal.pos 1306)] :=
    ready 3446 (by decide) v hv
  exact satisfied missing (_h 21 (by decide))

theorem segment11641_168_192    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base) :
    NegBelow v polarity11641 209 → NegBelow v polarity11641 233 :=
  ((((((extendNeg (unit11641_191 base v ready hv)) ∘ (extendNeg (unit11641_190 base v ready hv))) ∘ (extendNeg (unit11641_189 base v ready hv))) ∘ (((extendNeg (unit11641_188 base v ready hv)) ∘ (extendNeg (unit11641_187 base v ready hv))) ∘ (extendNeg (unit11641_186 base v ready hv)))) ∘ ((((extendNeg (unit11641_185 base v ready hv)) ∘ (extendNeg (unit11641_184 base v ready hv))) ∘ (extendNeg (unit11641_183 base v ready hv))) ∘ (((extendNeg (unit11641_182 base v ready hv)) ∘ (extendNeg (unit11641_181 base v ready hv))) ∘ (extendNeg (unit11641_180 base v ready hv))))) ∘ (((((extendNeg (unit11641_179 base v ready hv)) ∘ (extendNeg (unit11641_178 base v ready hv))) ∘ (extendNeg (unit11641_177 base v ready hv))) ∘ (((extendNeg (unit11641_176 base v ready hv)) ∘ (extendNeg (unit11641_175 base v ready hv))) ∘ (extendNeg (unit11641_174 base v ready hv)))) ∘ ((((extendNeg (unit11641_173 base v ready hv)) ∘ (extendNeg (unit11641_172 base v ready hv))) ∘ (extendNeg (unit11641_171 base v ready hv))) ∘ (((extendNeg (unit11641_170 base v ready hv)) ∘ (extendNeg (unit11641_169 base v ready hv))) ∘ (extendNeg (unit11641_168 base v ready hv))))))

end Euler.C14.PolarityDraft
