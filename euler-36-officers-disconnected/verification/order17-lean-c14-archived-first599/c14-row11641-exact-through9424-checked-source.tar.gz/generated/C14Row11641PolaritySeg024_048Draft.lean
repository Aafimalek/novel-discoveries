import C14Row11641PolarityDataDraft
namespace Euler.C14.PolarityDraft
open Euler.C14.IndexedDraft
open Euler.C14.Production (rowAt)
set_option maxRecDepth 18000
set_option maxHeartbeats 2400000
theorem unit11641_24    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 65) : v.neg (polarity11641 65) := by
  have exactPolarity : polarity11641 65 = (Sat.Literal.pos 682) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 682)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 682), (Sat.Literal.pos 1314)] :=
    ready 5886 (by decide) v hv
  exact satisfied missing (_h 62 (by decide))

theorem unit11641_25    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 66) : v.neg (polarity11641 66) := by
  have exactPolarity : polarity11641 66 = (Sat.Literal.pos 1326) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 1326)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 1326)] :=
    ready 9275 (by decide) v hv
  exact satisfied missing

theorem unit11641_26    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 67) : v.neg (polarity11641 67) := by
  have exactPolarity : polarity11641 67 = (Sat.Literal.pos 1093) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 1093)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 1093), (Sat.Literal.pos 1326)] :=
    ready 635 (by decide) v hv
  exact satisfied missing (_h 66 (by decide))

theorem unit11641_27    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 68) : v.neg (polarity11641 68) := by
  have exactPolarity : polarity11641 68 = (Sat.Literal.pos 1095) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 1095)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 1095), (Sat.Literal.pos 1326)] :=
    ready 637 (by decide) v hv
  exact satisfied missing (_h 66 (by decide))

theorem unit11641_28    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 69) : v.neg (polarity11641 69) := by
  have exactPolarity : polarity11641 69 = (Sat.Literal.pos 1096) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 1096)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 1096), (Sat.Literal.pos 1326)] :=
    ready 638 (by decide) v hv
  exact satisfied missing (_h 66 (by decide))

theorem unit11641_29    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 70) : v.neg (polarity11641 70) := by
  have exactPolarity : polarity11641 70 = (Sat.Literal.pos 1097) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 1097)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 1097), (Sat.Literal.pos 1326)] :=
    ready 639 (by decide) v hv
  exact satisfied missing (_h 66 (by decide))

theorem unit11641_30    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 71) : v.neg (polarity11641 71) := by
  have exactPolarity : polarity11641 71 = (Sat.Literal.pos 1102) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 1102)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 1102), (Sat.Literal.pos 1326)] :=
    ready 646 (by decide) v hv
  exact satisfied missing (_h 66 (by decide))

theorem unit11641_31    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 72) : v.neg (polarity11641 72) := by
  have exactPolarity : polarity11641 72 = (Sat.Literal.pos 1108) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 1108)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 1108), (Sat.Literal.pos 1326)] :=
    ready 652 (by decide) v hv
  exact satisfied missing (_h 66 (by decide))

theorem unit11641_32    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 73) : v.neg (polarity11641 73) := by
  have exactPolarity : polarity11641 73 = (Sat.Literal.pos 1114) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 1114)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 1114), (Sat.Literal.pos 1326)] :=
    ready 659 (by decide) v hv
  exact satisfied missing (_h 66 (by decide))

theorem unit11641_33    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 74) : v.neg (polarity11641 74) := by
  have exactPolarity : polarity11641 74 = (Sat.Literal.pos 1320) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 1320)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 1320), (Sat.Literal.pos 1326)] :=
    ready 8825 (by decide) v hv
  exact satisfied missing (_h 66 (by decide))

theorem unit11641_34    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 75) : v.neg (polarity11641 75) := by
  have exactPolarity : polarity11641 75 = (Sat.Literal.pos 877) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 877)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 877), (Sat.Literal.pos 1320)] :=
    ready 7515 (by decide) v hv
  exact satisfied missing (_h 74 (by decide))

theorem unit11641_35    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 76) : v.neg (polarity11641 76) := by
  have exactPolarity : polarity11641 76 = (Sat.Literal.pos 879) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 879)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 879), (Sat.Literal.pos 1320)] :=
    ready 7530 (by decide) v hv
  exact satisfied missing (_h 74 (by decide))

theorem unit11641_36    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 77) : v.neg (polarity11641 77) := by
  have exactPolarity : polarity11641 77 = (Sat.Literal.pos 880) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 880)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 880), (Sat.Literal.pos 1320)] :=
    ready 7541 (by decide) v hv
  exact satisfied missing (_h 74 (by decide))

theorem unit11641_37    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 78) : v.neg (polarity11641 78) := by
  have exactPolarity : polarity11641 78 = (Sat.Literal.pos 881) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 881)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 881), (Sat.Literal.pos 1320)] :=
    ready 7552 (by decide) v hv
  exact satisfied missing (_h 74 (by decide))

theorem unit11641_38    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 79) : v.neg (polarity11641 79) := by
  have exactPolarity : polarity11641 79 = (Sat.Literal.pos 886) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 886)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 886), (Sat.Literal.pos 1320)] :=
    ready 7591 (by decide) v hv
  exact satisfied missing (_h 74 (by decide))

theorem unit11641_39    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 80) : v.neg (polarity11641 80) := by
  have exactPolarity : polarity11641 80 = (Sat.Literal.pos 892) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 892)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 892), (Sat.Literal.pos 1320)] :=
    ready 7598 (by decide) v hv
  exact satisfied missing (_h 74 (by decide))

theorem unit11641_40    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 81) : v.neg (polarity11641 81) := by
  have exactPolarity : polarity11641 81 = (Sat.Literal.pos 898) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 898)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 898), (Sat.Literal.pos 1320)] :=
    ready 7640 (by decide) v hv
  exact satisfied missing (_h 74 (by decide))

theorem unit11641_41    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 82) : v.neg (polarity11641 82) := by
  have exactPolarity : polarity11641 82 = (Sat.Literal.pos 1308) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 1308)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 1308), (Sat.Literal.pos 1314), (Sat.Literal.pos 1320), (Sat.Literal.pos 1326)] :=
    ready 8853 (by decide) v hv
  exact satisfied missing (_h 62 (by decide)) (_h 74 (by decide)) (_h 66 (by decide))

theorem unit11641_42    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 83) : v.neg (polarity11641 83) := by
  have exactPolarity : polarity11641 83 = (Sat.Literal.pos 447) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 447)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 447), (Sat.Literal.pos 1308)] :=
    ready 3921 (by decide) v hv
  exact satisfied missing (_h 82 (by decide))

theorem unit11641_43    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 84) : v.neg (polarity11641 84) := by
  have exactPolarity : polarity11641 84 = (Sat.Literal.pos 448) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 448)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 448), (Sat.Literal.pos 1308)] :=
    ready 3922 (by decide) v hv
  exact satisfied missing (_h 82 (by decide))

theorem unit11641_44    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 85) : v.neg (polarity11641 85) := by
  have exactPolarity : polarity11641 85 = (Sat.Literal.pos 449) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 449)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 449), (Sat.Literal.pos 1308)] :=
    ready 3933 (by decide) v hv
  exact satisfied missing (_h 82 (by decide))

theorem unit11641_45    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 86) : v.neg (polarity11641 86) := by
  have exactPolarity : polarity11641 86 = (Sat.Literal.pos 454) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 454)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 454), (Sat.Literal.pos 1308)] :=
    ready 3979 (by decide) v hv
  exact satisfied missing (_h 82 (by decide))

theorem unit11641_46    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 87) : v.neg (polarity11641 87) := by
  have exactPolarity : polarity11641 87 = (Sat.Literal.pos 460) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 460)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 460), (Sat.Literal.pos 1308)] :=
    ready 4027 (by decide) v hv
  exact satisfied missing (_h 82 (by decide))

theorem unit11641_47    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 88) : v.neg (polarity11641 88) := by
  have exactPolarity : polarity11641 88 = (Sat.Literal.pos 466) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 466)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 466), (Sat.Literal.pos 1308)] :=
    ready 4079 (by decide) v hv
  exact satisfied missing (_h 82 (by decide))

theorem segment11641_24_48    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base) :
    NegBelow v polarity11641 65 → NegBelow v polarity11641 89 :=
  ((((((extendNeg (unit11641_47 base v ready hv)) ∘ (extendNeg (unit11641_46 base v ready hv))) ∘ (extendNeg (unit11641_45 base v ready hv))) ∘ (((extendNeg (unit11641_44 base v ready hv)) ∘ (extendNeg (unit11641_43 base v ready hv))) ∘ (extendNeg (unit11641_42 base v ready hv)))) ∘ ((((extendNeg (unit11641_41 base v ready hv)) ∘ (extendNeg (unit11641_40 base v ready hv))) ∘ (extendNeg (unit11641_39 base v ready hv))) ∘ (((extendNeg (unit11641_38 base v ready hv)) ∘ (extendNeg (unit11641_37 base v ready hv))) ∘ (extendNeg (unit11641_36 base v ready hv))))) ∘ (((((extendNeg (unit11641_35 base v ready hv)) ∘ (extendNeg (unit11641_34 base v ready hv))) ∘ (extendNeg (unit11641_33 base v ready hv))) ∘ (((extendNeg (unit11641_32 base v ready hv)) ∘ (extendNeg (unit11641_31 base v ready hv))) ∘ (extendNeg (unit11641_30 base v ready hv)))) ∘ ((((extendNeg (unit11641_29 base v ready hv)) ∘ (extendNeg (unit11641_28 base v ready hv))) ∘ (extendNeg (unit11641_27 base v ready hv))) ∘ (((extendNeg (unit11641_26 base v ready hv)) ∘ (extendNeg (unit11641_25 base v ready hv))) ∘ (extendNeg (unit11641_24 base v ready hv))))))

end Euler.C14.PolarityDraft
