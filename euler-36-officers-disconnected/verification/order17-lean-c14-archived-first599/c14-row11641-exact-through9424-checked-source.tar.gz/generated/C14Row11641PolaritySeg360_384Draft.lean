import C14Row11641PolarityDataDraft
namespace Euler.C14.PolarityDraft
open Euler.C14.IndexedDraft
open Euler.C14.Production (rowAt)
set_option maxRecDepth 18000
set_option maxHeartbeats 2400000
theorem unit11641_360    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 401) : v.neg (polarity11641 401) := by
  have exactPolarity : polarity11641 401 = (Sat.Literal.neg 7770) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.pos 7770)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 7769), (Sat.Literal.pos 7770)] :=
    ready 6712 (by decide) v hv
  exact satisfied (_h 398 (by decide)) missing

theorem unit11641_361    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 402) : v.neg (polarity11641 402) := by
  have exactPolarity : polarity11641 402 = (Sat.Literal.neg 8788) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.pos 8788)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 8787), (Sat.Literal.pos 8788)] :=
    ready 7524 (by decide) v hv
  exact satisfied (_h 399 (by decide)) missing

theorem unit11641_362    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 403) : v.neg (polarity11641 403) := by
  have exactPolarity : polarity11641 403 = (Sat.Literal.pos 2337) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 2337)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 2337), (Sat.Literal.pos 2338)] :=
    ready 2178 (by decide) v hv
  exact satisfied missing (_h 400 (by decide))

theorem unit11641_363    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 404) : v.neg (polarity11641 404) := by
  have exactPolarity : polarity11641 404 = (Sat.Literal.neg 7771) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.pos 7771)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 7770), (Sat.Literal.pos 7771)] :=
    ready 6713 (by decide) v hv
  exact satisfied (_h 401 (by decide)) missing

theorem unit11641_364    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 405) : v.neg (polarity11641 405) := by
  have exactPolarity : polarity11641 405 = (Sat.Literal.neg 8789) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.pos 8789)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 8788), (Sat.Literal.pos 8789)] :=
    ready 7525 (by decide) v hv
  exact satisfied (_h 402 (by decide)) missing

theorem unit11641_365    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 406) : v.neg (polarity11641 406) := by
  have exactPolarity : polarity11641 406 = (Sat.Literal.pos 848) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 848)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 848), (Sat.Literal.pos 2337)] :=
    ready 7239 (by decide) v hv
  exact satisfied missing (_h 403 (by decide))

theorem unit11641_366    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 407) : v.neg (polarity11641 407) := by
  have exactPolarity : polarity11641 407 = (Sat.Literal.neg 7772) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.pos 7772)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 7771), (Sat.Literal.pos 7772)] :=
    ready 6714 (by decide) v hv
  exact satisfied (_h 404 (by decide)) missing

theorem unit11641_367    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 408) : v.neg (polarity11641 408) := by
  have exactPolarity : polarity11641 408 = (Sat.Literal.neg 8790) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.pos 8790)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 8789), (Sat.Literal.pos 8790)] :=
    ready 7527 (by decide) v hv
  exact satisfied (_h 405 (by decide)) missing

theorem unit11641_368    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 409) : v.neg (polarity11641 409) := by
  have exactPolarity : polarity11641 409 = (Sat.Literal.pos 1270) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 1270)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 1270), (Sat.Literal.neg 7772)] :=
    ready 1479 (by decide) v hv
  exact satisfied missing (_h 407 (by decide))

theorem unit11641_369    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 410) : v.neg (polarity11641 410) := by
  have exactPolarity : polarity11641 410 = (Sat.Literal.neg 7773) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.pos 7773)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 7772), (Sat.Literal.pos 7773)] :=
    ready 6715 (by decide) v hv
  exact satisfied (_h 407 (by decide)) missing

theorem unit11641_370    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 411) : v.neg (polarity11641 411) := by
  have exactPolarity : polarity11641 411 = (Sat.Literal.pos 1251) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 1251)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 1251), (Sat.Literal.neg 8790)] :=
    ready 1395 (by decide) v hv
  exact satisfied missing (_h 408 (by decide))

theorem unit11641_371    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 412) : v.neg (polarity11641 412) := by
  have exactPolarity : polarity11641 412 = (Sat.Literal.pos 1276) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 1276)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 1276), (Sat.Literal.neg 7773)] :=
    ready 1518 (by decide) v hv
  exact satisfied missing (_h 410 (by decide))

theorem unit11641_372    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 413) : v.neg (polarity11641 413) := by
  have exactPolarity : polarity11641 413 = (Sat.Literal.neg 1397) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.pos 1397)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.pos 1397), (Sat.Literal.pos 323), (Sat.Literal.pos 551), (Sat.Literal.pos 587), (Sat.Literal.pos 623), (Sat.Literal.pos 707), (Sat.Literal.pos 710), (Sat.Literal.pos 712), (Sat.Literal.pos 713), (Sat.Literal.pos 947), (Sat.Literal.pos 983), (Sat.Literal.pos 1019), (Sat.Literal.pos 1055), (Sat.Literal.pos 1145), (Sat.Literal.pos 1163), (Sat.Literal.pos 1169), (Sat.Literal.pos 1175), (Sat.Literal.pos 1181), (Sat.Literal.pos 1187), (Sat.Literal.pos 1303), (Sat.Literal.pos 1309), (Sat.Literal.pos 1316), (Sat.Literal.pos 1321), (Sat.Literal.pos 1351), (Sat.Literal.pos 1391), (Sat.Literal.neg 1414), (Sat.Literal.pos 1415), (Sat.Literal.pos 1417), (Sat.Literal.pos 1821), (Sat.Literal.neg 8775)] :=
    ready 9413 (by decide) v hv
  exact satisfied missing (_h 1 (by decide)) (_h 305 (by decide)) (_h 306 (by decide)) (_h 307 (by decide)) (_h 12 (by decide)) (_h 13 (by decide)) (_h 14 (by decide)) (_h 15 (by decide)) (_h 216 (by decide)) (_h 217 (by decide)) (_h 212 (by decide)) (_h 213 (by decide)) (_h 0 (by decide)) (_h 261 (by decide)) (_h 264 (by decide)) (_h 266 (by decide)) (_h 270 (by decide)) (_h 272 (by decide)) (_h 20 (by decide)) (_h 22 (by decide)) (_h 25 (by decide)) (_h 27 (by decide)) (_h 30 (by decide)) (_h 37 (by decide)) (_h 331 (by decide)) (_h 39 (by decide)) (_h 304 (by decide)) (_h 40 (by decide)) (_h 358 (by decide))

theorem unit11641_373    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 414) : v.neg (polarity11641 414) := by
  have exactPolarity : polarity11641 414 = (Sat.Literal.pos 1403) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 1403)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.pos 1373), (Sat.Literal.neg 1379), (Sat.Literal.neg 1385), (Sat.Literal.pos 1391), (Sat.Literal.neg 1397), (Sat.Literal.neg 1403)] :=
    ready 9066 (by decide) v hv
  exact satisfied (_h 160 (by decide)) (_h 223 (by decide)) (_h 35 (by decide)) (_h 37 (by decide)) (_h 413 (by decide)) missing

theorem unit11641_374    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 415) : v.neg (polarity11641 415) := by
  have exactPolarity : polarity11641 415 = (Sat.Literal.pos 1139) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 1139)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 1139), (Sat.Literal.pos 1403)] :=
    ready 757 (by decide) v hv
  exact satisfied missing (_h 414 (by decide))

theorem unit11641_375    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 416) : v.neg (polarity11641 416) := by
  have exactPolarity : polarity11641 416 = (Sat.Literal.pos 1199) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 1199)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 1199), (Sat.Literal.pos 1403)] :=
    ready 1098 (by decide) v hv
  exact satisfied missing (_h 414 (by decide))

theorem unit11641_376    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 417) : v.neg (polarity11641 417) := by
  have exactPolarity : polarity11641 417 = (Sat.Literal.pos 1211) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 1211)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 1211), (Sat.Literal.pos 1403)] :=
    ready 1144 (by decide) v hv
  exact satisfied missing (_h 414 (by decide))

theorem unit11641_377    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 418) : v.neg (polarity11641 418) := by
  have exactPolarity : polarity11641 418 = (Sat.Literal.pos 1235) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 1235)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 1235), (Sat.Literal.pos 1403)] :=
    ready 1270 (by decide) v hv
  exact satisfied missing (_h 414 (by decide))

theorem unit11641_378    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 419) : v.neg (polarity11641 419) := by
  have exactPolarity : polarity11641 419 = (Sat.Literal.pos 1241) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 1241)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 1241), (Sat.Literal.pos 1403)] :=
    ready 1314 (by decide) v hv
  exact satisfied missing (_h 414 (by decide))

theorem unit11641_379    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 420) : v.neg (polarity11641 420) := by
  have exactPolarity : polarity11641 420 = (Sat.Literal.pos 1247) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 1247)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 1247), (Sat.Literal.pos 1403)] :=
    ready 1365 (by decide) v hv
  exact satisfied missing (_h 414 (by decide))

theorem unit11641_380    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 421) : v.neg (polarity11641 421) := by
  have exactPolarity : polarity11641 421 = (Sat.Literal.pos 1253) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 1253)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 1253), (Sat.Literal.pos 1403)] :=
    ready 1416 (by decide) v hv
  exact satisfied missing (_h 414 (by decide))

theorem unit11641_381    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 422) : v.neg (polarity11641 422) := by
  have exactPolarity : polarity11641 422 = (Sat.Literal.pos 1271) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 1271)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 1271), (Sat.Literal.pos 1403)] :=
    ready 1490 (by decide) v hv
  exact satisfied missing (_h 414 (by decide))

theorem unit11641_382    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 423) : v.neg (polarity11641 423) := by
  have exactPolarity : polarity11641 423 = (Sat.Literal.pos 1283) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 1283)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 1283), (Sat.Literal.pos 1403)] :=
    ready 1564 (by decide) v hv
  exact satisfied missing (_h 414 (by decide))

theorem unit11641_383    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 424) : v.neg (polarity11641 424) := by
  have exactPolarity : polarity11641 424 = (Sat.Literal.neg 1144) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.pos 1144)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.pos 1144), (Sat.Literal.pos 343), (Sat.Literal.neg 346), (Sat.Literal.pos 379), (Sat.Literal.pos 415), (Sat.Literal.pos 484), (Sat.Literal.pos 490), (Sat.Literal.pos 494), (Sat.Literal.pos 495), (Sat.Literal.pos 496), (Sat.Literal.pos 497), (Sat.Literal.pos 707), (Sat.Literal.pos 710), (Sat.Literal.pos 712), (Sat.Literal.pos 713), (Sat.Literal.pos 811), (Sat.Literal.pos 847), (Sat.Literal.pos 1139), (Sat.Literal.pos 1145), (Sat.Literal.pos 1199), (Sat.Literal.pos 1211), (Sat.Literal.pos 1235), (Sat.Literal.pos 1247), (Sat.Literal.pos 1270), (Sat.Literal.pos 1271), (Sat.Literal.pos 1283), (Sat.Literal.pos 1303), (Sat.Literal.neg 1315), (Sat.Literal.pos 1321), (Sat.Literal.pos 1328), (Sat.Literal.pos 1348), (Sat.Literal.neg 1354), (Sat.Literal.neg 1363), (Sat.Literal.neg 1378), (Sat.Literal.pos 1384), (Sat.Literal.neg 1390), (Sat.Literal.pos 1399), (Sat.Literal.neg 1414), (Sat.Literal.pos 1415), (Sat.Literal.neg 8775)] :=
    ready 9418 (by decide) v hv
  exact satisfied missing (_h 2 (by decide)) (_h 3 (by decide)) (_h 229 (by decide)) (_h 6 (by decide)) (_h 235 (by decide)) (_h 237 (by decide)) (_h 238 (by decide)) (_h 239 (by decide)) (_h 240 (by decide)) (_h 241 (by decide)) (_h 12 (by decide)) (_h 13 (by decide)) (_h 14 (by decide)) (_h 15 (by decide)) (_h 16 (by decide)) (_h 19 (by decide)) (_h 415 (by decide)) (_h 0 (by decide)) (_h 416 (by decide)) (_h 417 (by decide)) (_h 418 (by decide)) (_h 420 (by decide)) (_h 409 (by decide)) (_h 422 (by decide)) (_h 423 (by decide)) (_h 20 (by decide)) (_h 24 (by decide)) (_h 27 (by decide)) (_h 28 (by decide)) (_h 303 (by decide)) (_h 31 (by decide)) (_h 332 (by decide)) (_h 33 (by decide)) (_h 34 (by decide)) (_h 36 (by decide)) (_h 38 (by decide)) (_h 331 (by decide)) (_h 39 (by decide)) (_h 358 (by decide))

theorem segment11641_360_384    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base) :
    NegBelow v polarity11641 401 → NegBelow v polarity11641 425 :=
  ((((((extendNeg (unit11641_383 base v ready hv)) ∘ (extendNeg (unit11641_382 base v ready hv))) ∘ (extendNeg (unit11641_381 base v ready hv))) ∘ (((extendNeg (unit11641_380 base v ready hv)) ∘ (extendNeg (unit11641_379 base v ready hv))) ∘ (extendNeg (unit11641_378 base v ready hv)))) ∘ ((((extendNeg (unit11641_377 base v ready hv)) ∘ (extendNeg (unit11641_376 base v ready hv))) ∘ (extendNeg (unit11641_375 base v ready hv))) ∘ (((extendNeg (unit11641_374 base v ready hv)) ∘ (extendNeg (unit11641_373 base v ready hv))) ∘ (extendNeg (unit11641_372 base v ready hv))))) ∘ (((((extendNeg (unit11641_371 base v ready hv)) ∘ (extendNeg (unit11641_370 base v ready hv))) ∘ (extendNeg (unit11641_369 base v ready hv))) ∘ (((extendNeg (unit11641_368 base v ready hv)) ∘ (extendNeg (unit11641_367 base v ready hv))) ∘ (extendNeg (unit11641_366 base v ready hv)))) ∘ ((((extendNeg (unit11641_365 base v ready hv)) ∘ (extendNeg (unit11641_364 base v ready hv))) ∘ (extendNeg (unit11641_363 base v ready hv))) ∘ (((extendNeg (unit11641_362 base v ready hv)) ∘ (extendNeg (unit11641_361 base v ready hv))) ∘ (extendNeg (unit11641_360 base v ready hv))))))

end Euler.C14.PolarityDraft
