import C14Row11641PolarityDataDraft
namespace Euler.C14.PolarityDraft
open Euler.C14.IndexedDraft
open Euler.C14.Production (rowAt)
set_option maxRecDepth 18000
set_option maxHeartbeats 2400000
theorem unit11641_480    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 521) : v.neg (polarity11641 521) := by
  have exactPolarity : polarity11641 521 = (Sat.Literal.pos 1245) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 1245)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 1245), (Sat.Literal.pos 1198), (Sat.Literal.pos 1199), (Sat.Literal.pos 1234), (Sat.Literal.pos 1235), (Sat.Literal.pos 1270), (Sat.Literal.pos 1271), (Sat.Literal.pos 1328), (Sat.Literal.neg 1363)] :=
    ready 9407 (by decide) v hv
  exact satisfied missing (_h 474 (by decide)) (_h 416 (by decide)) (_h 494 (by decide)) (_h 418 (by decide)) (_h 409 (by decide)) (_h 422 (by decide)) (_h 28 (by decide)) (_h 332 (by decide))

theorem segment11641_480_481    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base) :
    NegBelow v polarity11641 521 → NegBelow v polarity11641 522 :=
  (extendNeg (unit11641_480 base v ready hv))

end Euler.C14.PolarityDraft
