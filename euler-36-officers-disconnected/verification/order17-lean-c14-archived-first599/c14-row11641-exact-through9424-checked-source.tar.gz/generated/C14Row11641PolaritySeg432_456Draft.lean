import C14Row11641PolarityDataDraft
namespace Euler.C14.PolarityDraft
open Euler.C14.IndexedDraft
open Euler.C14.Production (rowAt)
set_option maxRecDepth 18000
set_option maxHeartbeats 2400000
theorem unit11641_432    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 473) : v.neg (polarity11641 473) := by
  have exactPolarity : polarity11641 473 = (Sat.Literal.neg 3981) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.pos 3981)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 3980), (Sat.Literal.pos 3981)] :=
    ready 3554 (by decide) v hv
  exact satisfied (_h 470 (by decide)) missing

theorem unit11641_433    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 474) : v.neg (polarity11641 474) := by
  have exactPolarity : polarity11641 474 = (Sat.Literal.pos 1198) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 1198)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 1198), (Sat.Literal.neg 5240)] :=
    ready 1085 (by decide) v hv
  exact satisfied missing (_h 471 (by decide))

theorem unit11641_434    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 475) : v.neg (polarity11641 475) := by
  have exactPolarity : polarity11641 475 = (Sat.Literal.neg 5241) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.pos 5241)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 5240), (Sat.Literal.pos 5241)] :=
    ready 4627 (by decide) v hv
  exact satisfied (_h 471 (by decide)) missing

theorem unit11641_435    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 476) : v.neg (polarity11641 476) := by
  have exactPolarity : polarity11641 476 = (Sat.Literal.pos 2614) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 2614)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 2614), (Sat.Literal.pos 2615)] :=
    ready 2334 (by decide) v hv
  exact satisfied missing (_h 472 (by decide))

theorem unit11641_436    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 477) : v.neg (polarity11641 477) := by
  have exactPolarity : polarity11641 477 = (Sat.Literal.pos 1214) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 1214)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 1214), (Sat.Literal.neg 3981)] :=
    ready 1158 (by decide) v hv
  exact satisfied missing (_h 473 (by decide))

theorem unit11641_437    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 478) : v.neg (polarity11641 478) := by
  have exactPolarity : polarity11641 478 = (Sat.Literal.neg 3982) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.pos 3982)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 3981), (Sat.Literal.pos 3982)] :=
    ready 3555 (by decide) v hv
  exact satisfied (_h 473 (by decide)) missing

theorem unit11641_438    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 479) : v.neg (polarity11641 479) := by
  have exactPolarity : polarity11641 479 = (Sat.Literal.neg 5242) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.pos 5242)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 5241), (Sat.Literal.pos 5242)] :=
    ready 4628 (by decide) v hv
  exact satisfied (_h 475 (by decide)) missing

theorem unit11641_439    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 480) : v.neg (polarity11641 480) := by
  have exactPolarity : polarity11641 480 = (Sat.Literal.pos 2613) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 2613)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 2613), (Sat.Literal.pos 2614)] :=
    ready 2333 (by decide) v hv
  exact satisfied missing (_h 476 (by decide))

theorem unit11641_440    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 481) : v.neg (polarity11641 481) := by
  have exactPolarity : polarity11641 481 = (Sat.Literal.neg 3983) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.pos 3983)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 3982), (Sat.Literal.pos 3983)] :=
    ready 3556 (by decide) v hv
  exact satisfied (_h 478 (by decide)) missing

theorem unit11641_441    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 482) : v.neg (polarity11641 482) := by
  have exactPolarity : polarity11641 482 = (Sat.Literal.neg 5243) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.pos 5243)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 5242), (Sat.Literal.pos 5243)] :=
    ready 4629 (by decide) v hv
  exact satisfied (_h 479 (by decide)) missing

theorem unit11641_442    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 483) : v.neg (polarity11641 483) := by
  have exactPolarity : polarity11641 483 = (Sat.Literal.pos 1132) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 1132)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 1132), (Sat.Literal.pos 2613)] :=
    ready 700 (by decide) v hv
  exact satisfied missing (_h 480 (by decide))

theorem unit11641_443    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 484) : v.neg (polarity11641 484) := by
  have exactPolarity : polarity11641 484 = (Sat.Literal.pos 2612) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 2612)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 2612), (Sat.Literal.pos 2613)] :=
    ready 2332 (by decide) v hv
  exact satisfied missing (_h 480 (by decide))

theorem unit11641_444    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 485) : v.neg (polarity11641 485) := by
  have exactPolarity : polarity11641 485 = (Sat.Literal.neg 3984) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.pos 3984)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 3983), (Sat.Literal.pos 3984)] :=
    ready 3557 (by decide) v hv
  exact satisfied (_h 481 (by decide)) missing

theorem unit11641_445    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 486) : v.neg (polarity11641 486) := by
  have exactPolarity : polarity11641 486 = (Sat.Literal.neg 5244) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.pos 5244)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 5243), (Sat.Literal.pos 5244)] :=
    ready 4630 (by decide) v hv
  exact satisfied (_h 482 (by decide)) missing

theorem unit11641_446    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 487) : v.neg (polarity11641 487) := by
  have exactPolarity : polarity11641 487 = (Sat.Literal.pos 2611) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 2611)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 2611), (Sat.Literal.pos 2612)] :=
    ready 2331 (by decide) v hv
  exact satisfied missing (_h 484 (by decide))

theorem unit11641_447    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 488) : v.neg (polarity11641 488) := by
  have exactPolarity : polarity11641 488 = (Sat.Literal.neg 3985) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.pos 3985)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 3984), (Sat.Literal.pos 3985)] :=
    ready 3558 (by decide) v hv
  exact satisfied (_h 485 (by decide)) missing

theorem unit11641_448    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 489) : v.neg (polarity11641 489) := by
  have exactPolarity : polarity11641 489 = (Sat.Literal.neg 5245) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.pos 5245)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 5244), (Sat.Literal.pos 5245)] :=
    ready 4631 (by decide) v hv
  exact satisfied (_h 486 (by decide)) missing

theorem unit11641_449    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 490) : v.neg (polarity11641 490) := by
  have exactPolarity : polarity11641 490 = (Sat.Literal.pos 1130) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 1130)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 1130), (Sat.Literal.pos 2611)] :=
    ready 683 (by decide) v hv
  exact satisfied missing (_h 487 (by decide))

theorem unit11641_450    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 491) : v.neg (polarity11641 491) := by
  have exactPolarity : polarity11641 491 = (Sat.Literal.neg 3986) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.pos 3986)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 3985), (Sat.Literal.pos 3986)] :=
    ready 3559 (by decide) v hv
  exact satisfied (_h 488 (by decide)) missing

theorem unit11641_451    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 492) : v.neg (polarity11641 492) := by
  have exactPolarity : polarity11641 492 = (Sat.Literal.neg 5246) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.pos 5246)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 5245), (Sat.Literal.pos 5246)] :=
    ready 4632 (by decide) v hv
  exact satisfied (_h 489 (by decide)) missing

theorem unit11641_452    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 493) : v.neg (polarity11641 493) := by
  have exactPolarity : polarity11641 493 = (Sat.Literal.neg 3987) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.pos 3987)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 3986), (Sat.Literal.pos 3987)] :=
    ready 3560 (by decide) v hv
  exact satisfied (_h 491 (by decide)) missing

theorem unit11641_453    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 494) : v.neg (polarity11641 494) := by
  have exactPolarity : polarity11641 494 = (Sat.Literal.pos 1234) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 1234)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 1234), (Sat.Literal.neg 5246)] :=
    ready 1259 (by decide) v hv
  exact satisfied missing (_h 492 (by decide))

theorem unit11641_454    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 495) : v.neg (polarity11641 495) := by
  have exactPolarity : polarity11641 495 = (Sat.Literal.neg 5247) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.pos 5247)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 5246), (Sat.Literal.pos 5247)] :=
    ready 4633 (by decide) v hv
  exact satisfied (_h 492 (by decide)) missing

theorem unit11641_455    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 496) : v.neg (polarity11641 496) := by
  have exactPolarity : polarity11641 496 = (Sat.Literal.pos 1250) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 1250)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 1250), (Sat.Literal.neg 3987)] :=
    ready 1381 (by decide) v hv
  exact satisfied missing (_h 493 (by decide))

theorem segment11641_432_456    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base) :
    NegBelow v polarity11641 473 → NegBelow v polarity11641 497 :=
  ((((((extendNeg (unit11641_455 base v ready hv)) ∘ (extendNeg (unit11641_454 base v ready hv))) ∘ (extendNeg (unit11641_453 base v ready hv))) ∘ (((extendNeg (unit11641_452 base v ready hv)) ∘ (extendNeg (unit11641_451 base v ready hv))) ∘ (extendNeg (unit11641_450 base v ready hv)))) ∘ ((((extendNeg (unit11641_449 base v ready hv)) ∘ (extendNeg (unit11641_448 base v ready hv))) ∘ (extendNeg (unit11641_447 base v ready hv))) ∘ (((extendNeg (unit11641_446 base v ready hv)) ∘ (extendNeg (unit11641_445 base v ready hv))) ∘ (extendNeg (unit11641_444 base v ready hv))))) ∘ (((((extendNeg (unit11641_443 base v ready hv)) ∘ (extendNeg (unit11641_442 base v ready hv))) ∘ (extendNeg (unit11641_441 base v ready hv))) ∘ (((extendNeg (unit11641_440 base v ready hv)) ∘ (extendNeg (unit11641_439 base v ready hv))) ∘ (extendNeg (unit11641_438 base v ready hv)))) ∘ ((((extendNeg (unit11641_437 base v ready hv)) ∘ (extendNeg (unit11641_436 base v ready hv))) ∘ (extendNeg (unit11641_435 base v ready hv))) ∘ (((extendNeg (unit11641_434 base v ready hv)) ∘ (extendNeg (unit11641_433 base v ready hv))) ∘ (extendNeg (unit11641_432 base v ready hv))))))

end Euler.C14.PolarityDraft
