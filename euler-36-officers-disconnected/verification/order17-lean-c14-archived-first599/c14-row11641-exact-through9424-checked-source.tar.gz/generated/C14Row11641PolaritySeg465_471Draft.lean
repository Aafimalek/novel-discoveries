import C14Row11641PolarityDataDraft
namespace Euler.C14.PolarityDraft
open Euler.C14.IndexedDraft
open Euler.C14.Production (rowAt)
set_option maxRecDepth 18000
set_option maxHeartbeats 2400000
theorem unit11641_465    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 506) : v.neg (polarity11641 506) := by
  have exactPolarity : polarity11641 506 = (Sat.Literal.neg 3991) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.pos 3991)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 3990), (Sat.Literal.pos 3991)] :=
    ready 3565 (by decide) v hv
  exact satisfied (_h 502 (by decide)) missing

theorem unit11641_466    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 507) : v.neg (polarity11641 507) := by
  have exactPolarity : polarity11641 507 = (Sat.Literal.pos 1364) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 1364)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.pos 1334), (Sat.Literal.pos 1340), (Sat.Literal.neg 1346), (Sat.Literal.neg 1358), (Sat.Literal.neg 1364)] :=
    ready 9023 (by decide) v hv
  exact satisfied (_h 157 (by decide)) (_h 29 (by decide)) (_h 503 (by decide)) (_h 504 (by decide)) missing

theorem unit11641_467    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 508) : v.neg (polarity11641 508) := by
  have exactPolarity : polarity11641 508 = (Sat.Literal.neg 1324) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.pos 1324)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.pos 1324), (Sat.Literal.pos 1360), (Sat.Literal.pos 1392), (Sat.Literal.pos 1432), (Sat.Literal.pos 1464), (Sat.Literal.pos 1500)] :=
    ready 8357 (by decide) v hv
  exact satisfied missing (_h 431 (by decide)) (_h 180 (by decide)) (_h 505 (by decide)) (_h 210 (by decide)) (_h 208 (by decide))

theorem unit11641_468    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 509) : v.neg (polarity11641 509) := by
  have exactPolarity : polarity11641 509 = (Sat.Literal.neg 1312) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.pos 1312)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.pos 1312), (Sat.Literal.pos 1348), (Sat.Literal.pos 1380), (Sat.Literal.pos 1432), (Sat.Literal.pos 1464), (Sat.Literal.pos 1500)] :=
    ready 8287 (by decide) v hv
  exact satisfied missing (_h 303 (by decide)) (_h 195 (by decide)) (_h 505 (by decide)) (_h 210 (by decide)) (_h 208 (by decide))

theorem unit11641_469    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 510) : v.neg (polarity11641 510) := by
  have exactPolarity : polarity11641 510 = (Sat.Literal.neg 3992) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.pos 3992)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 3991), (Sat.Literal.pos 3992)] :=
    ready 3566 (by decide) v hv
  exact satisfied (_h 506 (by decide)) missing

theorem unit11641_470    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 511) : v.neg (polarity11641 511) := by
  have exactPolarity : polarity11641 511 = (Sat.Literal.pos 1238) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 1238)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 1238), (Sat.Literal.pos 1364)] :=
    ready 1287 (by decide) v hv
  exact satisfied missing (_h 507 (by decide))

theorem segment11641_465_471    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base) :
    NegBelow v polarity11641 506 → NegBelow v polarity11641 512 :=
  ((((extendNeg (unit11641_470 base v ready hv)) ∘ (extendNeg (unit11641_469 base v ready hv))) ∘ (extendNeg (unit11641_468 base v ready hv))) ∘ (((extendNeg (unit11641_467 base v ready hv)) ∘ (extendNeg (unit11641_466 base v ready hv))) ∘ (extendNeg (unit11641_465 base v ready hv))))

end Euler.C14.PolarityDraft
