import C14Row11641PolarityDataDraft
namespace Euler.C14.PolarityDraft
open Euler.C14.IndexedDraft
open Euler.C14.Production (rowAt)
set_option maxRecDepth 18000
set_option maxHeartbeats 2400000
theorem unit11641_494    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 535) : v.neg (polarity11641 535) := by
  have exactPolarity : polarity11641 535 = (Sat.Literal.neg 8539) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.pos 8539)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 8538), (Sat.Literal.pos 8539)] :=
    ready 7288 (by decide) v hv
  exact satisfied (_h 534 (by decide)) missing

theorem unit11641_495    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 536) : v.neg (polarity11641 536) := by
  have exactPolarity : polarity11641 536 = (Sat.Literal.neg 8540) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.pos 8540)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 8539), (Sat.Literal.pos 8540)] :=
    ready 7296 (by decide) v hv
  exact satisfied (_h 535 (by decide)) missing

theorem unit11641_496    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 537) : v.neg (polarity11641 537) := by
  have exactPolarity : polarity11641 537 = (Sat.Literal.neg 8541) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.pos 8541)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 8540), (Sat.Literal.pos 8541)] :=
    ready 7297 (by decide) v hv
  exact satisfied (_h 536 (by decide)) missing

theorem unit11641_497    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 538) : v.neg (polarity11641 538) := by
  have exactPolarity : polarity11641 538 = (Sat.Literal.neg 8542) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.pos 8542)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 8541), (Sat.Literal.pos 8542)] :=
    ready 7298 (by decide) v hv
  exact satisfied (_h 537 (by decide)) missing

theorem unit11641_498    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 539) : v.neg (polarity11641 539) := by
  have exactPolarity : polarity11641 539 = (Sat.Literal.neg 8543) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.pos 8543)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 8542), (Sat.Literal.pos 8543)] :=
    ready 7299 (by decide) v hv
  exact satisfied (_h 538 (by decide)) missing

theorem unit11641_499    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 540) : v.neg (polarity11641 540) := by
  have exactPolarity : polarity11641 540 = (Sat.Literal.neg 8544) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.pos 8544)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 8543), (Sat.Literal.pos 8544)] :=
    ready 7300 (by decide) v hv
  exact satisfied (_h 539 (by decide)) missing

theorem segment11641_494_500    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base) :
    NegBelow v polarity11641 535 → NegBelow v polarity11641 541 :=
  ((((extendNeg (unit11641_499 base v ready hv)) ∘ (extendNeg (unit11641_498 base v ready hv))) ∘ (extendNeg (unit11641_497 base v ready hv))) ∘ (((extendNeg (unit11641_496 base v ready hv)) ∘ (extendNeg (unit11641_495 base v ready hv))) ∘ (extendNeg (unit11641_494 base v ready hv))))

end Euler.C14.PolarityDraft
