import C14Row11641PolarityDataDraft
namespace Euler.C14.PolarityDraft
open Euler.C14.IndexedDraft
open Euler.C14.Production (rowAt)
set_option maxRecDepth 18000
set_option maxHeartbeats 2400000
theorem unit11641_48    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 89) : v.neg (polarity11641 89) := by
  have exactPolarity : polarity11641 89 = (Sat.Literal.pos 1406) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 1406)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 1406), (Sat.Literal.pos 447), (Sat.Literal.pos 448), (Sat.Literal.pos 449), (Sat.Literal.pos 877), (Sat.Literal.pos 879), (Sat.Literal.pos 880), (Sat.Literal.pos 881), (Sat.Literal.pos 1093), (Sat.Literal.pos 1095), (Sat.Literal.pos 1096), (Sat.Literal.pos 1097)] :=
    ready 9166 (by decide) v hv
  exact satisfied missing (_h 83 (by decide)) (_h 84 (by decide)) (_h 85 (by decide)) (_h 75 (by decide)) (_h 76 (by decide)) (_h 77 (by decide)) (_h 78 (by decide)) (_h 67 (by decide)) (_h 68 (by decide)) (_h 69 (by decide)) (_h 70 (by decide))

theorem unit11641_49    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 90) : v.neg (polarity11641 90) := by
  have exactPolarity : polarity11641 90 = (Sat.Literal.pos 1444) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 1444)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 1444), (Sat.Literal.pos 448), (Sat.Literal.pos 454), (Sat.Literal.pos 460), (Sat.Literal.pos 466), (Sat.Literal.pos 670), (Sat.Literal.pos 676), (Sat.Literal.pos 682), (Sat.Literal.pos 880), (Sat.Literal.pos 886), (Sat.Literal.pos 892), (Sat.Literal.pos 898), (Sat.Literal.pos 1096), (Sat.Literal.pos 1102), (Sat.Literal.pos 1108), (Sat.Literal.pos 1114)] :=
    ready 9199 (by decide) v hv
  exact satisfied missing (_h 84 (by decide)) (_h 86 (by decide)) (_h 87 (by decide)) (_h 88 (by decide)) (_h 63 (by decide)) (_h 64 (by decide)) (_h 65 (by decide)) (_h 77 (by decide)) (_h 79 (by decide)) (_h 80 (by decide)) (_h 81 (by decide)) (_h 69 (by decide)) (_h 71 (by decide)) (_h 72 (by decide)) (_h 73 (by decide))

theorem unit11641_50    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 91) : v.neg (polarity11641 91) := by
  have exactPolarity : polarity11641 91 = (Sat.Literal.pos 1300) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 1300)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 1300)] :=
    ready 9279 (by decide) v hv
  exact satisfied missing

theorem unit11641_51    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 92) : v.neg (polarity11641 92) := by
  have exactPolarity : polarity11641 92 = (Sat.Literal.pos 158) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 158)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 158), (Sat.Literal.pos 1300)] :=
    ready 1742 (by decide) v hv
  exact satisfied missing (_h 91 (by decide))

theorem unit11641_52    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 93) : v.neg (polarity11641 93) := by
  have exactPolarity : polarity11641 93 = (Sat.Literal.pos 159) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 159)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 159), (Sat.Literal.pos 1300)] :=
    ready 1744 (by decide) v hv
  exact satisfied missing (_h 91 (by decide))

theorem unit11641_53    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 94) : v.neg (polarity11641 94) := by
  have exactPolarity : polarity11641 94 = (Sat.Literal.pos 160) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 160)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 160), (Sat.Literal.pos 1300)] :=
    ready 1745 (by decide) v hv
  exact satisfied missing (_h 91 (by decide))

theorem unit11641_54    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 95) : v.neg (polarity11641 95) := by
  have exactPolarity : polarity11641 95 = (Sat.Literal.pos 161) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 161)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 161), (Sat.Literal.pos 1300)] :=
    ready 1746 (by decide) v hv
  exact satisfied missing (_h 91 (by decide))

theorem unit11641_55    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 96) : v.neg (polarity11641 96) := by
  have exactPolarity : polarity11641 96 = (Sat.Literal.pos 164) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 164)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 164), (Sat.Literal.pos 1300)] :=
    ready 1749 (by decide) v hv
  exact satisfied missing (_h 91 (by decide))

theorem unit11641_56    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 97) : v.neg (polarity11641 97) := by
  have exactPolarity : polarity11641 97 = (Sat.Literal.pos 165) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 165)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 165), (Sat.Literal.pos 1300)] :=
    ready 1750 (by decide) v hv
  exact satisfied missing (_h 91 (by decide))

theorem unit11641_57    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 98) : v.neg (polarity11641 98) := by
  have exactPolarity : polarity11641 98 = (Sat.Literal.pos 166) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 166)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 166), (Sat.Literal.pos 1300)] :=
    ready 1751 (by decide) v hv
  exact satisfied missing (_h 91 (by decide))

theorem unit11641_58    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 99) : v.neg (polarity11641 99) := by
  have exactPolarity : polarity11641 99 = (Sat.Literal.pos 167) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 167)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 167), (Sat.Literal.pos 1300)] :=
    ready 1752 (by decide) v hv
  exact satisfied missing (_h 91 (by decide))

theorem unit11641_59    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 100) : v.neg (polarity11641 100) := by
  have exactPolarity : polarity11641 100 = (Sat.Literal.pos 170) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 170)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 170), (Sat.Literal.pos 1300)] :=
    ready 1756 (by decide) v hv
  exact satisfied missing (_h 91 (by decide))

theorem unit11641_60    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 101) : v.neg (polarity11641 101) := by
  have exactPolarity : polarity11641 101 = (Sat.Literal.pos 171) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 171)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 171), (Sat.Literal.pos 1300)] :=
    ready 1757 (by decide) v hv
  exact satisfied missing (_h 91 (by decide))

theorem unit11641_61    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 102) : v.neg (polarity11641 102) := by
  have exactPolarity : polarity11641 102 = (Sat.Literal.pos 172) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 172)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 172), (Sat.Literal.pos 1300)] :=
    ready 1762 (by decide) v hv
  exact satisfied missing (_h 91 (by decide))

theorem unit11641_62    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 103) : v.neg (polarity11641 103) := by
  have exactPolarity : polarity11641 103 = (Sat.Literal.pos 173) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 173)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 173), (Sat.Literal.pos 1300)] :=
    ready 1772 (by decide) v hv
  exact satisfied missing (_h 91 (by decide))

theorem unit11641_63    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 104) : v.neg (polarity11641 104) := by
  have exactPolarity : polarity11641 104 = (Sat.Literal.pos 176) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 176)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 176), (Sat.Literal.pos 1300)] :=
    ready 1792 (by decide) v hv
  exact satisfied missing (_h 91 (by decide))

theorem unit11641_64    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 105) : v.neg (polarity11641 105) := by
  have exactPolarity : polarity11641 105 = (Sat.Literal.pos 177) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 177)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 177), (Sat.Literal.pos 1300)] :=
    ready 1800 (by decide) v hv
  exact satisfied missing (_h 91 (by decide))

theorem unit11641_65    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 106) : v.neg (polarity11641 106) := by
  have exactPolarity : polarity11641 106 = (Sat.Literal.pos 178) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 178)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 178), (Sat.Literal.pos 1300)] :=
    ready 1811 (by decide) v hv
  exact satisfied missing (_h 91 (by decide))

theorem unit11641_66    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 107) : v.neg (polarity11641 107) := by
  have exactPolarity : polarity11641 107 = (Sat.Literal.pos 179) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 179)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 179), (Sat.Literal.pos 1300)] :=
    ready 1815 (by decide) v hv
  exact satisfied missing (_h 91 (by decide))

theorem unit11641_67    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 108) : v.neg (polarity11641 108) := by
  have exactPolarity : polarity11641 108 = (Sat.Literal.pos 1301) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 1301)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 1301)] :=
    ready 9281 (by decide) v hv
  exact satisfied missing

theorem unit11641_68    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 109) : v.neg (polarity11641 109) := by
  have exactPolarity : polarity11641 109 = (Sat.Literal.pos 194) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 194)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 194), (Sat.Literal.pos 1301)] :=
    ready 1892 (by decide) v hv
  exact satisfied missing (_h 108 (by decide))

theorem unit11641_69    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 110) : v.neg (polarity11641 110) := by
  have exactPolarity : polarity11641 110 = (Sat.Literal.pos 195) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 195)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 195), (Sat.Literal.pos 1301)] :=
    ready 1893 (by decide) v hv
  exact satisfied missing (_h 108 (by decide))

theorem unit11641_70    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 111) : v.neg (polarity11641 111) := by
  have exactPolarity : polarity11641 111 = (Sat.Literal.pos 196) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 196)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 196), (Sat.Literal.pos 1301)] :=
    ready 1894 (by decide) v hv
  exact satisfied missing (_h 108 (by decide))

theorem unit11641_71    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 112) : v.neg (polarity11641 112) := by
  have exactPolarity : polarity11641 112 = (Sat.Literal.pos 197) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 197)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 197), (Sat.Literal.pos 1301)] :=
    ready 1895 (by decide) v hv
  exact satisfied missing (_h 108 (by decide))

theorem segment11641_48_72    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base) :
    NegBelow v polarity11641 89 → NegBelow v polarity11641 113 :=
  ((((((extendNeg (unit11641_71 base v ready hv)) ∘ (extendNeg (unit11641_70 base v ready hv))) ∘ (extendNeg (unit11641_69 base v ready hv))) ∘ (((extendNeg (unit11641_68 base v ready hv)) ∘ (extendNeg (unit11641_67 base v ready hv))) ∘ (extendNeg (unit11641_66 base v ready hv)))) ∘ ((((extendNeg (unit11641_65 base v ready hv)) ∘ (extendNeg (unit11641_64 base v ready hv))) ∘ (extendNeg (unit11641_63 base v ready hv))) ∘ (((extendNeg (unit11641_62 base v ready hv)) ∘ (extendNeg (unit11641_61 base v ready hv))) ∘ (extendNeg (unit11641_60 base v ready hv))))) ∘ (((((extendNeg (unit11641_59 base v ready hv)) ∘ (extendNeg (unit11641_58 base v ready hv))) ∘ (extendNeg (unit11641_57 base v ready hv))) ∘ (((extendNeg (unit11641_56 base v ready hv)) ∘ (extendNeg (unit11641_55 base v ready hv))) ∘ (extendNeg (unit11641_54 base v ready hv)))) ∘ ((((extendNeg (unit11641_53 base v ready hv)) ∘ (extendNeg (unit11641_52 base v ready hv))) ∘ (extendNeg (unit11641_51 base v ready hv))) ∘ (((extendNeg (unit11641_50 base v ready hv)) ∘ (extendNeg (unit11641_49 base v ready hv))) ∘ (extendNeg (unit11641_48 base v ready hv))))))

end Euler.C14.PolarityDraft
