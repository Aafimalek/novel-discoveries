import C14Row11641PolarityDataDraft
namespace Euler.C14.PolarityDraft
open Euler.C14.IndexedDraft
open Euler.C14.Production (rowAt)
set_option maxRecDepth 18000
set_option maxHeartbeats 2400000
theorem unit11641_462    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 503) : v.neg (polarity11641 503) := by
  have exactPolarity : polarity11641 503 = (Sat.Literal.neg 1346) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.pos 1346)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.pos 1308), (Sat.Literal.pos 1346), (Sat.Literal.pos 1384), (Sat.Literal.pos 1406), (Sat.Literal.pos 1444), (Sat.Literal.pos 1492)] :=
    ready 8269 (by decide) v hv
  exact satisfied (_h 82 (by decide)) missing (_h 34 (by decide)) (_h 89 (by decide)) (_h 90 (by decide)) (_h 500 (by decide))

theorem unit11641_463    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 504) : v.neg (polarity11641 504) := by
  have exactPolarity : polarity11641 504 = (Sat.Literal.neg 1358) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.pos 1358)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.pos 1320), (Sat.Literal.pos 1358), (Sat.Literal.pos 1396), (Sat.Literal.pos 1406), (Sat.Literal.pos 1444), (Sat.Literal.pos 1492)] :=
    ready 8327 (by decide) v hv
  exact satisfied (_h 74 (by decide)) missing (_h 432 (by decide)) (_h 89 (by decide)) (_h 90 (by decide)) (_h 500 (by decide))

theorem segment11641_462_464    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base) :
    NegBelow v polarity11641 503 → NegBelow v polarity11641 505 :=
  ((extendNeg (unit11641_463 base v ready hv)) ∘ (extendNeg (unit11641_462 base v ready hv)))

end Euler.C14.PolarityDraft
