import C14Row11641PolarityDataDraft
namespace Euler.C14.PolarityDraft
open Euler.C14.IndexedDraft
open Euler.C14.Production (rowAt)
set_option maxRecDepth 18000
set_option maxHeartbeats 2400000
theorem unit11641_72    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 113) : v.neg (polarity11641 113) := by
  have exactPolarity : polarity11641 113 = (Sat.Literal.pos 200) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 200)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 200), (Sat.Literal.pos 1301)] :=
    ready 1926 (by decide) v hv
  exact satisfied missing (_h 108 (by decide))

theorem unit11641_73    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 114) : v.neg (polarity11641 114) := by
  have exactPolarity : polarity11641 114 = (Sat.Literal.pos 201) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 201)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 201), (Sat.Literal.pos 1301)] :=
    ready 1937 (by decide) v hv
  exact satisfied missing (_h 108 (by decide))

theorem unit11641_74    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 115) : v.neg (polarity11641 115) := by
  have exactPolarity : polarity11641 115 = (Sat.Literal.pos 202) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 202)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 202), (Sat.Literal.pos 1301)] :=
    ready 1948 (by decide) v hv
  exact satisfied missing (_h 108 (by decide))

theorem unit11641_75    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 116) : v.neg (polarity11641 116) := by
  have exactPolarity : polarity11641 116 = (Sat.Literal.pos 203) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 203)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 203), (Sat.Literal.pos 1301)] :=
    ready 1956 (by decide) v hv
  exact satisfied missing (_h 108 (by decide))

theorem unit11641_76    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 117) : v.neg (polarity11641 117) := by
  have exactPolarity : polarity11641 117 = (Sat.Literal.pos 206) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 206)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 206), (Sat.Literal.pos 1301)] :=
    ready 1980 (by decide) v hv
  exact satisfied missing (_h 108 (by decide))

theorem unit11641_77    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 118) : v.neg (polarity11641 118) := by
  have exactPolarity : polarity11641 118 = (Sat.Literal.pos 207) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 207)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 207), (Sat.Literal.pos 1301)] :=
    ready 1983 (by decide) v hv
  exact satisfied missing (_h 108 (by decide))

theorem unit11641_78    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 119) : v.neg (polarity11641 119) := by
  have exactPolarity : polarity11641 119 = (Sat.Literal.pos 208) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 208)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 208), (Sat.Literal.pos 1301)] :=
    ready 1992 (by decide) v hv
  exact satisfied missing (_h 108 (by decide))

theorem unit11641_79    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 120) : v.neg (polarity11641 120) := by
  have exactPolarity : polarity11641 120 = (Sat.Literal.pos 209) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 209)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 209), (Sat.Literal.pos 1301)] :=
    ready 2004 (by decide) v hv
  exact satisfied missing (_h 108 (by decide))

theorem unit11641_80    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 121) : v.neg (polarity11641 121) := by
  have exactPolarity : polarity11641 121 = (Sat.Literal.pos 212) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 212)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 212), (Sat.Literal.pos 1301)] :=
    ready 2027 (by decide) v hv
  exact satisfied missing (_h 108 (by decide))

theorem unit11641_81    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 122) : v.neg (polarity11641 122) := by
  have exactPolarity : polarity11641 122 = (Sat.Literal.pos 213) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 213)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 213), (Sat.Literal.pos 1301)] :=
    ready 2038 (by decide) v hv
  exact satisfied missing (_h 108 (by decide))

theorem unit11641_82    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 123) : v.neg (polarity11641 123) := by
  have exactPolarity : polarity11641 123 = (Sat.Literal.pos 214) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 214)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 214), (Sat.Literal.pos 1301)] :=
    ready 2041 (by decide) v hv
  exact satisfied missing (_h 108 (by decide))

theorem unit11641_83    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 124) : v.neg (polarity11641 124) := by
  have exactPolarity : polarity11641 124 = (Sat.Literal.pos 215) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 215)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 215), (Sat.Literal.pos 1301)] :=
    ready 2042 (by decide) v hv
  exact satisfied missing (_h 108 (by decide))

theorem unit11641_84    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 125) : v.neg (polarity11641 125) := by
  have exactPolarity : polarity11641 125 = (Sat.Literal.pos 1299) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 1299)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 1299)] :=
    ready 9282 (by decide) v hv
  exact satisfied missing

theorem unit11641_85    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 126) : v.neg (polarity11641 126) := by
  have exactPolarity : polarity11641 126 = (Sat.Literal.pos 128) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 128)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 128), (Sat.Literal.pos 1299)] :=
    ready 1599 (by decide) v hv
  exact satisfied missing (_h 125 (by decide))

theorem unit11641_86    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 127) : v.neg (polarity11641 127) := by
  have exactPolarity : polarity11641 127 = (Sat.Literal.pos 129) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 129)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 129), (Sat.Literal.pos 1299)] :=
    ready 1646 (by decide) v hv
  exact satisfied missing (_h 125 (by decide))

theorem unit11641_87    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 128) : v.neg (polarity11641 128) := by
  have exactPolarity : polarity11641 128 = (Sat.Literal.pos 130) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 130)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 130), (Sat.Literal.pos 1299)] :=
    ready 1647 (by decide) v hv
  exact satisfied missing (_h 125 (by decide))

theorem unit11641_88    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 129) : v.neg (polarity11641 129) := by
  have exactPolarity : polarity11641 129 = (Sat.Literal.pos 131) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 131)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 131), (Sat.Literal.pos 1299)] :=
    ready 1648 (by decide) v hv
  exact satisfied missing (_h 125 (by decide))

theorem unit11641_89    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 130) : v.neg (polarity11641 130) := by
  have exactPolarity : polarity11641 130 = (Sat.Literal.pos 134) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 134)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 134), (Sat.Literal.pos 1299)] :=
    ready 1651 (by decide) v hv
  exact satisfied missing (_h 125 (by decide))

theorem unit11641_90    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 131) : v.neg (polarity11641 131) := by
  have exactPolarity : polarity11641 131 = (Sat.Literal.pos 135) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 135)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 135), (Sat.Literal.pos 1299)] :=
    ready 1652 (by decide) v hv
  exact satisfied missing (_h 125 (by decide))

theorem unit11641_91    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 132) : v.neg (polarity11641 132) := by
  have exactPolarity : polarity11641 132 = (Sat.Literal.pos 136) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 136)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 136), (Sat.Literal.pos 1299)] :=
    ready 1653 (by decide) v hv
  exact satisfied missing (_h 125 (by decide))

theorem unit11641_92    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 133) : v.neg (polarity11641 133) := by
  have exactPolarity : polarity11641 133 = (Sat.Literal.pos 137) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 137)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 137), (Sat.Literal.pos 1299)] :=
    ready 1654 (by decide) v hv
  exact satisfied missing (_h 125 (by decide))

theorem unit11641_93    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 134) : v.neg (polarity11641 134) := by
  have exactPolarity : polarity11641 134 = (Sat.Literal.pos 140) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 140)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 140), (Sat.Literal.pos 1299)] :=
    ready 1658 (by decide) v hv
  exact satisfied missing (_h 125 (by decide))

theorem unit11641_94    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 135) : v.neg (polarity11641 135) := by
  have exactPolarity : polarity11641 135 = (Sat.Literal.pos 141) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 141)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 141), (Sat.Literal.pos 1299)] :=
    ready 1659 (by decide) v hv
  exact satisfied missing (_h 125 (by decide))

theorem unit11641_95    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 136) : v.neg (polarity11641 136) := by
  have exactPolarity : polarity11641 136 = (Sat.Literal.pos 142) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 142)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 142), (Sat.Literal.pos 1299)] :=
    ready 1660 (by decide) v hv
  exact satisfied missing (_h 125 (by decide))

theorem segment11641_72_96    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base) :
    NegBelow v polarity11641 113 → NegBelow v polarity11641 137 :=
  ((((((extendNeg (unit11641_95 base v ready hv)) ∘ (extendNeg (unit11641_94 base v ready hv))) ∘ (extendNeg (unit11641_93 base v ready hv))) ∘ (((extendNeg (unit11641_92 base v ready hv)) ∘ (extendNeg (unit11641_91 base v ready hv))) ∘ (extendNeg (unit11641_90 base v ready hv)))) ∘ ((((extendNeg (unit11641_89 base v ready hv)) ∘ (extendNeg (unit11641_88 base v ready hv))) ∘ (extendNeg (unit11641_87 base v ready hv))) ∘ (((extendNeg (unit11641_86 base v ready hv)) ∘ (extendNeg (unit11641_85 base v ready hv))) ∘ (extendNeg (unit11641_84 base v ready hv))))) ∘ (((((extendNeg (unit11641_83 base v ready hv)) ∘ (extendNeg (unit11641_82 base v ready hv))) ∘ (extendNeg (unit11641_81 base v ready hv))) ∘ (((extendNeg (unit11641_80 base v ready hv)) ∘ (extendNeg (unit11641_79 base v ready hv))) ∘ (extendNeg (unit11641_78 base v ready hv)))) ∘ ((((extendNeg (unit11641_77 base v ready hv)) ∘ (extendNeg (unit11641_76 base v ready hv))) ∘ (extendNeg (unit11641_75 base v ready hv))) ∘ (((extendNeg (unit11641_74 base v ready hv)) ∘ (extendNeg (unit11641_73 base v ready hv))) ∘ (extendNeg (unit11641_72 base v ready hv))))))

end Euler.C14.PolarityDraft
