import C14Row11641PolarityDataDraft
namespace Euler.C14.PolarityDraft
open Euler.C14.IndexedDraft
open Euler.C14.Production (rowAt)
set_option maxRecDepth 18000
set_option maxHeartbeats 2400000
theorem close11641    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 550) : False := by
  have satisfied : v.satisfies [(Sat.Literal.neg 1454), (Sat.Literal.pos 86), (Sat.Literal.pos 92), (Sat.Literal.pos 98), (Sat.Literal.pos 104), (Sat.Literal.pos 740), (Sat.Literal.pos 746), (Sat.Literal.pos 752), (Sat.Literal.pos 950), (Sat.Literal.pos 956), (Sat.Literal.pos 962), (Sat.Literal.pos 968), (Sat.Literal.pos 1166), (Sat.Literal.pos 1172), (Sat.Literal.pos 1178), (Sat.Literal.pos 1184)] :=
    ready 9207 (by decide) v hv
  exact satisfied (_h 520 (by decide)) (_h 146 (by decide)) (_h 150 (by decide)) (_h 154 (by decide)) (_h 142 (by decide)) (_h 248 (by decide)) (_h 250 (by decide)) (_h 254 (by decide)) (_h 548 (by decide)) (_h 528 (by decide)) (_h 443 (by decide)) (_h 549 (by decide)) (_h 262 (by decide)) (_h 265 (by decide)) (_h 267 (by decide)) (_h 271 (by decide))
end Euler.C14.PolarityDraft
