import C14Row11641PolarityDataDraft
namespace Euler.C14.PolarityDraft
open Euler.C14.IndexedDraft
open Euler.C14.Production (rowAt)
set_option maxRecDepth 18000
set_option maxHeartbeats 2400000
theorem unit11641_500    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 541) : v.neg (polarity11641 541) := by
  have exactPolarity : polarity11641 541 = (Sat.Literal.pos 1208) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 1208)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 1208), (Sat.Literal.neg 8544)] :=
    ready 1115 (by decide) v hv
  exact satisfied missing (_h 540 (by decide))

theorem unit11641_501    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 542) : v.neg (polarity11641 542) := by
  have exactPolarity : polarity11641 542 = (Sat.Literal.neg 8545) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.pos 8545)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 8544), (Sat.Literal.pos 8545)] :=
    ready 7301 (by decide) v hv
  exact satisfied (_h 540 (by decide)) missing

theorem unit11641_502    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 543) : v.neg (polarity11641 543) := by
  have exactPolarity : polarity11641 543 = (Sat.Literal.pos 1244) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 1244)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 1244), (Sat.Literal.neg 8545)] :=
    ready 1333 (by decide) v hv
  exact satisfied missing (_h 542 (by decide))

theorem unit11641_503    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 544) : v.neg (polarity11641 544) := by
  have exactPolarity : polarity11641 544 = (Sat.Literal.neg 8546) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.pos 8546)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 8545), (Sat.Literal.pos 8546)] :=
    ready 7302 (by decide) v hv
  exact satisfied (_h 542 (by decide)) missing

theorem unit11641_504    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 545) : v.neg (polarity11641 545) := by
  have exactPolarity : polarity11641 545 = (Sat.Literal.pos 1280) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 1280)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 1280), (Sat.Literal.neg 8546)] :=
    ready 1543 (by decide) v hv
  exact satisfied missing (_h 544 (by decide))

theorem segment11641_500_505    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base) :
    NegBelow v polarity11641 541 → NegBelow v polarity11641 546 :=
  ((((extendNeg (unit11641_504 base v ready hv)) ∘ (extendNeg (unit11641_503 base v ready hv))) ∘ (extendNeg (unit11641_502 base v ready hv))) ∘ ((extendNeg (unit11641_501 base v ready hv)) ∘ (extendNeg (unit11641_500 base v ready hv))))

end Euler.C14.PolarityDraft
