import C14Row11641PolarityDataDraft
namespace Euler.C14.PolarityDraft
open Euler.C14.IndexedDraft
open Euler.C14.Production (rowAt)
set_option maxRecDepth 18000
set_option maxHeartbeats 2400000
theorem unit11641_505    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 546) : v.neg (polarity11641 546) := by
  have exactPolarity : polarity11641 546 = (Sat.Literal.pos 1400) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 1400)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 1400), (Sat.Literal.pos 1118), (Sat.Literal.pos 1130), (Sat.Literal.pos 1136), (Sat.Literal.pos 1142), (Sat.Literal.pos 1148), (Sat.Literal.pos 1166), (Sat.Literal.pos 1172), (Sat.Literal.pos 1178), (Sat.Literal.pos 1184), (Sat.Literal.pos 1190), (Sat.Literal.pos 1208), (Sat.Literal.pos 1214), (Sat.Literal.pos 1220), (Sat.Literal.pos 1226), (Sat.Literal.pos 1238), (Sat.Literal.pos 1244), (Sat.Literal.pos 1250), (Sat.Literal.pos 1256), (Sat.Literal.pos 1262), (Sat.Literal.pos 1274), (Sat.Literal.pos 1280), (Sat.Literal.pos 1286), (Sat.Literal.pos 1292)] :=
    ready 9164 (by decide) v hv
  exact satisfied missing (_h 57 (by decide)) (_h 490 (by decide)) (_h 468 (by decide)) (_h 435 (by decide)) (_h 295 (by decide)) (_h 262 (by decide)) (_h 265 (by decide)) (_h 267 (by decide)) (_h 271 (by decide)) (_h 58 (by decide)) (_h 541 (by decide)) (_h 477 (by decide)) (_h 319 (by decide)) (_h 59 (by decide)) (_h 511 (by decide)) (_h 543 (by decide)) (_h 496 (by decide)) (_h 320 (by decide)) (_h 60 (by decide)) (_h 513 (by decide)) (_h 545 (by decide)) (_h 518 (by decide)) (_h 324 (by decide))

theorem segment11641_505_506    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base) :
    NegBelow v polarity11641 546 → NegBelow v polarity11641 547 :=
  (extendNeg (unit11641_505 base v ready hv))

end Euler.C14.PolarityDraft
