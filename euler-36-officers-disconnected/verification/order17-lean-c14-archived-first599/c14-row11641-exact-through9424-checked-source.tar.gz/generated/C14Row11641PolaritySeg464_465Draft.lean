import C14Row11641PolarityDataDraft
namespace Euler.C14.PolarityDraft
open Euler.C14.IndexedDraft
open Euler.C14.Production (rowAt)
set_option maxRecDepth 18000
set_option maxHeartbeats 2400000
theorem unit11641_464    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 505) : v.neg (polarity11641 505) := by
  have exactPolarity : polarity11641 505 = (Sat.Literal.pos 1432) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 1432)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 1432), (Sat.Literal.pos 170), (Sat.Literal.pos 171), (Sat.Literal.pos 172), (Sat.Literal.pos 173), (Sat.Literal.pos 384), (Sat.Literal.pos 385), (Sat.Literal.pos 387), (Sat.Literal.pos 388), (Sat.Literal.pos 389), (Sat.Literal.pos 600), (Sat.Literal.pos 602), (Sat.Literal.pos 603), (Sat.Literal.pos 604), (Sat.Literal.pos 605), (Sat.Literal.pos 817), (Sat.Literal.pos 818), (Sat.Literal.pos 819), (Sat.Literal.pos 820), (Sat.Literal.pos 821), (Sat.Literal.pos 1032), (Sat.Literal.pos 1033), (Sat.Literal.pos 1034), (Sat.Literal.pos 1035), (Sat.Literal.pos 1036), (Sat.Literal.pos 1037), (Sat.Literal.pos 1248), (Sat.Literal.pos 1249), (Sat.Literal.pos 1250), (Sat.Literal.pos 1251), (Sat.Literal.pos 1252), (Sat.Literal.pos 1253)] :=
    ready 9189 (by decide) v hv
  exact satisfied missing (_h 100 (by decide)) (_h 101 (by decide)) (_h 102 (by decide)) (_h 103 (by decide)) (_h 176 (by decide)) (_h 230 (by decide)) (_h 231 (by decide)) (_h 232 (by decide)) (_h 233 (by decide)) (_h 202 (by decide)) (_h 326 (by decide)) (_h 309 (by decide)) (_h 286 (by decide)) (_h 327 (by decide)) (_h 17 (by decide)) (_h 277 (by decide)) (_h 278 (by decide)) (_h 279 (by decide)) (_h 18 (by decide)) (_h 183 (by decide)) (_h 437 (by decide)) (_h 438 (by decide)) (_h 439 (by decide)) (_h 440 (by decide)) (_h 441 (by decide)) (_h 51 (by decide)) (_h 293 (by decide)) (_h 496 (by decide)) (_h 411 (by decide)) (_h 501 (by decide)) (_h 421 (by decide))

theorem segment11641_464_465    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base) :
    NegBelow v polarity11641 505 → NegBelow v polarity11641 506 :=
  (extendNeg (unit11641_464 base v ready hv))

end Euler.C14.PolarityDraft
