import C14Row11641PolarityDataDraft
namespace Euler.C14.PolarityDraft
open Euler.C14.IndexedDraft
open Euler.C14.Production (rowAt)
set_option maxRecDepth 18000
set_option maxHeartbeats 2400000
theorem unit11641_384    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 425) : v.neg (polarity11641 425) := by
  have exactPolarity : polarity11641 425 = (Sat.Literal.pos 2624) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 2624)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 1144), (Sat.Literal.neg 2624)] :=
    ready 787 (by decide) v hv
  exact satisfied (_h 424 (by decide)) missing

theorem unit11641_385    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 426) : v.neg (polarity11641 426) := by
  have exactPolarity : polarity11641 426 = (Sat.Literal.neg 1366) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.pos 1366)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 1144), (Sat.Literal.pos 1366)] :=
    ready 792 (by decide) v hv
  exact satisfied (_h 424 (by decide)) missing

theorem unit11641_386    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 427) : v.neg (polarity11641 427) := by
  have exactPolarity : polarity11641 427 = (Sat.Literal.neg 1402) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.pos 1402)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 1144), (Sat.Literal.pos 1402)] :=
    ready 793 (by decide) v hv
  exact satisfied (_h 424 (by decide)) missing

theorem unit11641_387    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 428) : v.neg (polarity11641 428) := by
  have exactPolarity : polarity11641 428 = (Sat.Literal.neg 3972) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.pos 3972)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 1144), (Sat.Literal.pos 3972)] :=
    ready 796 (by decide) v hv
  exact satisfied (_h 424 (by decide)) missing

theorem unit11641_388    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 429) : v.neg (polarity11641 429) := by
  have exactPolarity : polarity11641 429 = (Sat.Literal.neg 5232) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.pos 5232)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 1144), (Sat.Literal.pos 5232)] :=
    ready 797 (by decide) v hv
  exact satisfied (_h 424 (by decide)) missing

theorem unit11641_389    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 430) : v.neg (polarity11641 430) := by
  have exactPolarity : polarity11641 430 = (Sat.Literal.pos 2623) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 2623)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 2623), (Sat.Literal.pos 2624)] :=
    ready 2344 (by decide) v hv
  exact satisfied missing (_h 425 (by decide))

theorem unit11641_390    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 431) : v.neg (polarity11641 431) := by
  have exactPolarity : polarity11641 431 = (Sat.Literal.pos 1360) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 1360)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 1342), (Sat.Literal.neg 1354), (Sat.Literal.neg 1360), (Sat.Literal.neg 1366)] :=
    ready 9293 (by decide) v hv
  exact satisfied (_h 224 (by decide)) (_h 31 (by decide)) missing (_h 426 (by decide))

theorem unit11641_391    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 432) : v.neg (polarity11641 432) := by
  have exactPolarity : polarity11641 432 = (Sat.Literal.pos 1396) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 1396)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.pos 1372), (Sat.Literal.neg 1378), (Sat.Literal.pos 1384), (Sat.Literal.neg 1390), (Sat.Literal.neg 1396), (Sat.Literal.neg 1402)] :=
    ready 9061 (by decide) v hv
  exact satisfied (_h 159 (by decide)) (_h 33 (by decide)) (_h 34 (by decide)) (_h 36 (by decide)) missing (_h 427 (by decide))

theorem unit11641_392    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 433) : v.neg (polarity11641 433) := by
  have exactPolarity : polarity11641 433 = (Sat.Literal.neg 3973) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.pos 3973)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 3972), (Sat.Literal.pos 3973)] :=
    ready 3545 (by decide) v hv
  exact satisfied (_h 428 (by decide)) missing

theorem unit11641_393    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 434) : v.neg (polarity11641 434) := by
  have exactPolarity : polarity11641 434 = (Sat.Literal.neg 5233) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.pos 5233)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 5232), (Sat.Literal.pos 5233)] :=
    ready 4618 (by decide) v hv
  exact satisfied (_h 429 (by decide)) missing

theorem unit11641_394    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 435) : v.neg (polarity11641 435) := by
  have exactPolarity : polarity11641 435 = (Sat.Literal.pos 1142) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 1142)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 1142), (Sat.Literal.pos 2623)] :=
    ready 773 (by decide) v hv
  exact satisfied missing (_h 430 (by decide))

theorem unit11641_395    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 436) : v.neg (polarity11641 436) := by
  have exactPolarity : polarity11641 436 = (Sat.Literal.pos 2622) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 2622)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 2622), (Sat.Literal.pos 2623)] :=
    ready 2343 (by decide) v hv
  exact satisfied missing (_h 430 (by decide))

theorem unit11641_396    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 437) : v.neg (polarity11641 437) := by
  have exactPolarity : polarity11641 437 = (Sat.Literal.pos 1033) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 1033)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 1033), (Sat.Literal.pos 1360)] :=
    ready 298 (by decide) v hv
  exact satisfied missing (_h 431 (by decide))

theorem unit11641_397    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 438) : v.neg (polarity11641 438) := by
  have exactPolarity : polarity11641 438 = (Sat.Literal.pos 1034) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 1034)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 1034), (Sat.Literal.pos 1360)] :=
    ready 308 (by decide) v hv
  exact satisfied missing (_h 431 (by decide))

theorem unit11641_398    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 439) : v.neg (polarity11641 439) := by
  have exactPolarity : polarity11641 439 = (Sat.Literal.pos 1035) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 1035)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 1035), (Sat.Literal.pos 1360)] :=
    ready 316 (by decide) v hv
  exact satisfied missing (_h 431 (by decide))

theorem unit11641_399    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 440) : v.neg (polarity11641 440) := by
  have exactPolarity : polarity11641 440 = (Sat.Literal.pos 1036) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 1036)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 1036), (Sat.Literal.pos 1360)] :=
    ready 325 (by decide) v hv
  exact satisfied missing (_h 431 (by decide))

theorem unit11641_400    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 441) : v.neg (polarity11641 441) := by
  have exactPolarity : polarity11641 441 = (Sat.Literal.pos 1037) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 1037)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 1037), (Sat.Literal.pos 1360)] :=
    ready 335 (by decide) v hv
  exact satisfied missing (_h 431 (by decide))

theorem unit11641_401    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 442) : v.neg (polarity11641 442) := by
  have exactPolarity : polarity11641 442 = (Sat.Literal.pos 1070) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 1070)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 1070), (Sat.Literal.pos 1360)] :=
    ready 559 (by decide) v hv
  exact satisfied missing (_h 431 (by decide))

theorem unit11641_402    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 443) : v.neg (polarity11641 443) := by
  have exactPolarity : polarity11641 443 = (Sat.Literal.pos 962) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 962)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 962), (Sat.Literal.pos 1360)] :=
    ready 7969 (by decide) v hv
  exact satisfied missing (_h 431 (by decide))

theorem unit11641_403    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 444) : v.neg (polarity11641 444) := by
  have exactPolarity : polarity11641 444 = (Sat.Literal.pos 964) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 964)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 964), (Sat.Literal.pos 1360)] :=
    ready 7988 (by decide) v hv
  exact satisfied missing (_h 431 (by decide))

theorem unit11641_404    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 445) : v.neg (polarity11641 445) := by
  have exactPolarity : polarity11641 445 = (Sat.Literal.pos 965) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 965)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 965), (Sat.Literal.pos 1360)] :=
    ready 7996 (by decide) v hv
  exact satisfied missing (_h 431 (by decide))

theorem unit11641_405    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 446) : v.neg (polarity11641 446) := by
  have exactPolarity : polarity11641 446 = (Sat.Literal.pos 1024) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 1024)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 1024), (Sat.Literal.pos 1396)] :=
    ready 223 (by decide) v hv
  exact satisfied missing (_h 432 (by decide))

theorem unit11641_406    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 447) : v.neg (polarity11641 447) := by
  have exactPolarity : polarity11641 447 = (Sat.Literal.pos 1060) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 1060)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 1060), (Sat.Literal.pos 1396)] :=
    ready 481 (by decide) v hv
  exact satisfied missing (_h 432 (by decide))

theorem unit11641_407    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 448) : v.neg (polarity11641 448) := by
  have exactPolarity : polarity11641 448 = (Sat.Literal.pos 952) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 952)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 952), (Sat.Literal.pos 1396)] :=
    ready 7906 (by decide) v hv
  exact satisfied missing (_h 432 (by decide))

theorem segment11641_384_408    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base) :
    NegBelow v polarity11641 425 → NegBelow v polarity11641 449 :=
  ((((((extendNeg (unit11641_407 base v ready hv)) ∘ (extendNeg (unit11641_406 base v ready hv))) ∘ (extendNeg (unit11641_405 base v ready hv))) ∘ (((extendNeg (unit11641_404 base v ready hv)) ∘ (extendNeg (unit11641_403 base v ready hv))) ∘ (extendNeg (unit11641_402 base v ready hv)))) ∘ ((((extendNeg (unit11641_401 base v ready hv)) ∘ (extendNeg (unit11641_400 base v ready hv))) ∘ (extendNeg (unit11641_399 base v ready hv))) ∘ (((extendNeg (unit11641_398 base v ready hv)) ∘ (extendNeg (unit11641_397 base v ready hv))) ∘ (extendNeg (unit11641_396 base v ready hv))))) ∘ (((((extendNeg (unit11641_395 base v ready hv)) ∘ (extendNeg (unit11641_394 base v ready hv))) ∘ (extendNeg (unit11641_393 base v ready hv))) ∘ (((extendNeg (unit11641_392 base v ready hv)) ∘ (extendNeg (unit11641_391 base v ready hv))) ∘ (extendNeg (unit11641_390 base v ready hv)))) ∘ ((((extendNeg (unit11641_389 base v ready hv)) ∘ (extendNeg (unit11641_388 base v ready hv))) ∘ (extendNeg (unit11641_387 base v ready hv))) ∘ (((extendNeg (unit11641_386 base v ready hv)) ∘ (extendNeg (unit11641_385 base v ready hv))) ∘ (extendNeg (unit11641_384 base v ready hv))))))

end Euler.C14.PolarityDraft
