import C14Row11641PolarityDataDraft
namespace Euler.C14.PolarityDraft
open Euler.C14.IndexedDraft
open Euler.C14.Production (rowAt)
set_option maxRecDepth 18000
set_option maxHeartbeats 2400000
theorem unit11641_336    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 377) : v.neg (polarity11641 377) := by
  have exactPolarity : polarity11641 377 = (Sat.Literal.neg 8781) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.pos 8781)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 8780), (Sat.Literal.pos 8781)] :=
    ready 7517 (by decide) v hv
  exact satisfied (_h 374 (by decide)) missing

theorem unit11641_337    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 378) : v.neg (polarity11641 378) := by
  have exactPolarity : polarity11641 378 = (Sat.Literal.pos 2344) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 2344)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 856), (Sat.Literal.neg 2344)] :=
    ready 7338 (by decide) v hv
  exact satisfied (_h 375 (by decide)) missing

theorem unit11641_338    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 379) : v.neg (polarity11641 379) := by
  have exactPolarity : polarity11641 379 = (Sat.Literal.neg 7764) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.pos 7764)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 856), (Sat.Literal.pos 7764)] :=
    ready 7348 (by decide) v hv
  exact satisfied (_h 375 (by decide)) missing

theorem unit11641_339    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 380) : v.neg (polarity11641 380) := by
  have exactPolarity : polarity11641 380 = (Sat.Literal.neg 6087) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.pos 6087)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 6086), (Sat.Literal.pos 6087)] :=
    ready 5318 (by decide) v hv
  exact satisfied (_h 376 (by decide)) missing

theorem unit11641_340    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 381) : v.neg (polarity11641 381) := by
  have exactPolarity : polarity11641 381 = (Sat.Literal.neg 8782) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.pos 8782)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 8781), (Sat.Literal.pos 8782)] :=
    ready 7518 (by decide) v hv
  exact satisfied (_h 377 (by decide)) missing

theorem unit11641_341    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 382) : v.neg (polarity11641 382) := by
  have exactPolarity : polarity11641 382 = (Sat.Literal.pos 2343) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 2343)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 2343), (Sat.Literal.pos 2344)] :=
    ready 2185 (by decide) v hv
  exact satisfied missing (_h 378 (by decide))

theorem unit11641_342    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 383) : v.neg (polarity11641 383) := by
  have exactPolarity : polarity11641 383 = (Sat.Literal.neg 7765) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.pos 7765)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 7764), (Sat.Literal.pos 7765)] :=
    ready 6706 (by decide) v hv
  exact satisfied (_h 379 (by decide)) missing

theorem unit11641_343    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 384) : v.neg (polarity11641 384) := by
  have exactPolarity : polarity11641 384 = (Sat.Literal.pos 998) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 998)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 998), (Sat.Literal.neg 6087)] :=
    ready 8132 (by decide) v hv
  exact satisfied missing (_h 380 (by decide))

theorem unit11641_344    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 385) : v.neg (polarity11641 385) := by
  have exactPolarity : polarity11641 385 = (Sat.Literal.neg 8783) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.pos 8783)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 8782), (Sat.Literal.pos 8783)] :=
    ready 7519 (by decide) v hv
  exact satisfied (_h 381 (by decide)) missing

theorem unit11641_345    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 386) : v.neg (polarity11641 386) := by
  have exactPolarity : polarity11641 386 = (Sat.Literal.pos 963) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 963)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 963), (Sat.Literal.neg 8782)] :=
    ready 7976 (by decide) v hv
  exact satisfied missing (_h 381 (by decide))

theorem unit11641_346    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 387) : v.neg (polarity11641 387) := by
  have exactPolarity : polarity11641 387 = (Sat.Literal.pos 2342) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 2342)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 2342), (Sat.Literal.pos 2343)] :=
    ready 2184 (by decide) v hv
  exact satisfied missing (_h 382 (by decide))

theorem unit11641_347    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 388) : v.neg (polarity11641 388) := by
  have exactPolarity : polarity11641 388 = (Sat.Literal.pos 854) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 854)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 854), (Sat.Literal.pos 2343)] :=
    ready 7312 (by decide) v hv
  exact satisfied missing (_h 382 (by decide))

theorem unit11641_348    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 389) : v.neg (polarity11641 389) := by
  have exactPolarity : polarity11641 389 = (Sat.Literal.neg 7766) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.pos 7766)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 7765), (Sat.Literal.pos 7766)] :=
    ready 6707 (by decide) v hv
  exact satisfied (_h 383 (by decide)) missing

theorem unit11641_349    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 390) : v.neg (polarity11641 390) := by
  have exactPolarity : polarity11641 390 = (Sat.Literal.neg 8784) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.pos 8784)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 8783), (Sat.Literal.pos 8784)] :=
    ready 7520 (by decide) v hv
  exact satisfied (_h 385 (by decide)) missing

theorem unit11641_350    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 391) : v.neg (polarity11641 391) := by
  have exactPolarity : polarity11641 391 = (Sat.Literal.pos 2341) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 2341)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 2341), (Sat.Literal.pos 2342)] :=
    ready 2183 (by decide) v hv
  exact satisfied missing (_h 387 (by decide))

theorem unit11641_351    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 392) : v.neg (polarity11641 392) := by
  have exactPolarity : polarity11641 392 = (Sat.Literal.neg 7767) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.pos 7767)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 7766), (Sat.Literal.pos 7767)] :=
    ready 6708 (by decide) v hv
  exact satisfied (_h 389 (by decide)) missing

theorem unit11641_352    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 393) : v.neg (polarity11641 393) := by
  have exactPolarity : polarity11641 393 = (Sat.Literal.neg 8785) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.pos 8785)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 8784), (Sat.Literal.pos 8785)] :=
    ready 7521 (by decide) v hv
  exact satisfied (_h 390 (by decide)) missing

theorem unit11641_353    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 394) : v.neg (polarity11641 394) := by
  have exactPolarity : polarity11641 394 = (Sat.Literal.pos 2340) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 2340)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 2340), (Sat.Literal.pos 2341)] :=
    ready 2182 (by decide) v hv
  exact satisfied missing (_h 391 (by decide))

theorem unit11641_354    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 395) : v.neg (polarity11641 395) := by
  have exactPolarity : polarity11641 395 = (Sat.Literal.neg 7768) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.pos 7768)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 7767), (Sat.Literal.pos 7768)] :=
    ready 6709 (by decide) v hv
  exact satisfied (_h 392 (by decide)) missing

theorem unit11641_355    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 396) : v.neg (polarity11641 396) := by
  have exactPolarity : polarity11641 396 = (Sat.Literal.neg 8786) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.pos 8786)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 8785), (Sat.Literal.pos 8786)] :=
    ready 7522 (by decide) v hv
  exact satisfied (_h 393 (by decide)) missing

theorem unit11641_356    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 397) : v.neg (polarity11641 397) := by
  have exactPolarity : polarity11641 397 = (Sat.Literal.pos 2339) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 2339)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 2339), (Sat.Literal.pos 2340)] :=
    ready 2181 (by decide) v hv
  exact satisfied missing (_h 394 (by decide))

theorem unit11641_357    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 398) : v.neg (polarity11641 398) := by
  have exactPolarity : polarity11641 398 = (Sat.Literal.neg 7769) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.pos 7769)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 7768), (Sat.Literal.pos 7769)] :=
    ready 6710 (by decide) v hv
  exact satisfied (_h 395 (by decide)) missing

theorem unit11641_358    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 399) : v.neg (polarity11641 399) := by
  have exactPolarity : polarity11641 399 = (Sat.Literal.neg 8787) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.pos 8787)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 8786), (Sat.Literal.pos 8787)] :=
    ready 7523 (by decide) v hv
  exact satisfied (_h 396 (by decide)) missing

theorem unit11641_359    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 400) : v.neg (polarity11641 400) := by
  have exactPolarity : polarity11641 400 = (Sat.Literal.pos 2338) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 2338)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 2338), (Sat.Literal.pos 2339)] :=
    ready 2179 (by decide) v hv
  exact satisfied missing (_h 397 (by decide))

theorem segment11641_336_360    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base) :
    NegBelow v polarity11641 377 → NegBelow v polarity11641 401 :=
  ((((((extendNeg (unit11641_359 base v ready hv)) ∘ (extendNeg (unit11641_358 base v ready hv))) ∘ (extendNeg (unit11641_357 base v ready hv))) ∘ (((extendNeg (unit11641_356 base v ready hv)) ∘ (extendNeg (unit11641_355 base v ready hv))) ∘ (extendNeg (unit11641_354 base v ready hv)))) ∘ ((((extendNeg (unit11641_353 base v ready hv)) ∘ (extendNeg (unit11641_352 base v ready hv))) ∘ (extendNeg (unit11641_351 base v ready hv))) ∘ (((extendNeg (unit11641_350 base v ready hv)) ∘ (extendNeg (unit11641_349 base v ready hv))) ∘ (extendNeg (unit11641_348 base v ready hv))))) ∘ (((((extendNeg (unit11641_347 base v ready hv)) ∘ (extendNeg (unit11641_346 base v ready hv))) ∘ (extendNeg (unit11641_345 base v ready hv))) ∘ (((extendNeg (unit11641_344 base v ready hv)) ∘ (extendNeg (unit11641_343 base v ready hv))) ∘ (extendNeg (unit11641_342 base v ready hv)))) ∘ ((((extendNeg (unit11641_341 base v ready hv)) ∘ (extendNeg (unit11641_340 base v ready hv))) ∘ (extendNeg (unit11641_339 base v ready hv))) ∘ (((extendNeg (unit11641_338 base v ready hv)) ∘ (extendNeg (unit11641_337 base v ready hv))) ∘ (extendNeg (unit11641_336 base v ready hv))))))

end Euler.C14.PolarityDraft
