import C14Row11641PolarityDataDraft
namespace Euler.C14.PolarityDraft
open Euler.C14.IndexedDraft
open Euler.C14.Production (rowAt)
set_option maxRecDepth 18000
set_option maxHeartbeats 2400000
theorem unit11641_0    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 41) : v.neg (polarity11641 41) := by
  have exactPolarity : polarity11641 41 = (Sat.Literal.pos 1398) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 1398)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 1398)] :=
    ready 9262 (by decide) v hv
  exact satisfied missing

theorem unit11641_1    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 42) : v.neg (polarity11641 42) := by
  have exactPolarity : polarity11641 42 = (Sat.Literal.pos 1134) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 1134)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 1134), (Sat.Literal.pos 1398)] :=
    ready 712 (by decide) v hv
  exact satisfied missing (_h 41 (by decide))

theorem unit11641_2    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 43) : v.neg (polarity11641 43) := by
  have exactPolarity : polarity11641 43 = (Sat.Literal.pos 1140) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 1140)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 1140), (Sat.Literal.pos 1398)] :=
    ready 762 (by decide) v hv
  exact satisfied missing (_h 41 (by decide))

theorem unit11641_3    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 44) : v.neg (polarity11641 44) := by
  have exactPolarity : polarity11641 44 = (Sat.Literal.pos 1146) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 1146)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 1146), (Sat.Literal.pos 1398)] :=
    ready 810 (by decide) v hv
  exact satisfied missing (_h 41 (by decide))

theorem unit11641_4    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 45) : v.neg (polarity11641 45) := by
  have exactPolarity : polarity11641 45 = (Sat.Literal.pos 1158) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 1158)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 1158), (Sat.Literal.pos 1398)] :=
    ready 865 (by decide) v hv
  exact satisfied missing (_h 41 (by decide))

theorem unit11641_5    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 46) : v.neg (polarity11641 46) := by
  have exactPolarity : polarity11641 46 = (Sat.Literal.pos 1170) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 1170)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 1170), (Sat.Literal.pos 1398)] :=
    ready 939 (by decide) v hv
  exact satisfied missing (_h 41 (by decide))

theorem unit11641_6    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 47) : v.neg (polarity11641 47) := by
  have exactPolarity : polarity11641 47 = (Sat.Literal.pos 1176) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 1176)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 1176), (Sat.Literal.pos 1398)] :=
    ready 985 (by decide) v hv
  exact satisfied missing (_h 41 (by decide))

theorem unit11641_7    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 48) : v.neg (polarity11641 48) := by
  have exactPolarity : polarity11641 48 = (Sat.Literal.pos 1182) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 1182)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 1182), (Sat.Literal.pos 1398)] :=
    ready 1031 (by decide) v hv
  exact satisfied missing (_h 41 (by decide))

theorem unit11641_8    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 49) : v.neg (polarity11641 49) := by
  have exactPolarity : polarity11641 49 = (Sat.Literal.pos 1230) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 1230)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 1230), (Sat.Literal.pos 1398)] :=
    ready 1247 (by decide) v hv
  exact satisfied missing (_h 41 (by decide))

theorem unit11641_9    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 50) : v.neg (polarity11641 50) := by
  have exactPolarity : polarity11641 50 = (Sat.Literal.pos 1242) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 1242)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 1242), (Sat.Literal.pos 1398)] :=
    ready 1317 (by decide) v hv
  exact satisfied missing (_h 41 (by decide))

theorem unit11641_10    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 51) : v.neg (polarity11641 51) := by
  have exactPolarity : polarity11641 51 = (Sat.Literal.pos 1248) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 1248)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 1248), (Sat.Literal.pos 1398)] :=
    ready 1368 (by decide) v hv
  exact satisfied missing (_h 41 (by decide))

theorem unit11641_11    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 52) : v.neg (polarity11641 52) := by
  have exactPolarity : polarity11641 52 = (Sat.Literal.pos 1254) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 1254)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 1254), (Sat.Literal.pos 1398)] :=
    ready 1417 (by decide) v hv
  exact satisfied missing (_h 41 (by decide))

theorem unit11641_12    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 53) : v.neg (polarity11641 53) := by
  have exactPolarity : polarity11641 53 = (Sat.Literal.pos 1266) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 1266)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 1266), (Sat.Literal.pos 1398)] :=
    ready 1465 (by decide) v hv
  exact satisfied missing (_h 41 (by decide))

theorem unit11641_13    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 54) : v.neg (polarity11641 54) := by
  have exactPolarity : polarity11641 54 = (Sat.Literal.pos 1284) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 1284)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 1284), (Sat.Literal.pos 1398)] :=
    ready 1565 (by decide) v hv
  exact satisfied missing (_h 41 (by decide))

theorem unit11641_14    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 55) : v.neg (polarity11641 55) := by
  have exactPolarity : polarity11641 55 = (Sat.Literal.pos 1290) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 1290)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 1290), (Sat.Literal.pos 1398)] :=
    ready 1608 (by decide) v hv
  exact satisfied missing (_h 41 (by decide))

theorem unit11641_15    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 56) : v.neg (polarity11641 56) := by
  have exactPolarity : polarity11641 56 = (Sat.Literal.pos 1362) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 1362)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 1362)] :=
    ready 9267 (by decide) v hv
  exact satisfied missing

theorem unit11641_16    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 57) : v.neg (polarity11641 57) := by
  have exactPolarity : polarity11641 57 = (Sat.Literal.pos 1118) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 1118)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 1118), (Sat.Literal.pos 1362)] :=
    ready 663 (by decide) v hv
  exact satisfied missing (_h 56 (by decide))

theorem unit11641_17    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 58) : v.neg (polarity11641 58) := by
  have exactPolarity : polarity11641 58 = (Sat.Literal.pos 1190) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 1190)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 1190), (Sat.Literal.pos 1362)] :=
    ready 1072 (by decide) v hv
  exact satisfied missing (_h 56 (by decide))

theorem unit11641_18    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 59) : v.neg (polarity11641 59) := by
  have exactPolarity : polarity11641 59 = (Sat.Literal.pos 1226) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 1226)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 1226), (Sat.Literal.pos 1362)] :=
    ready 1242 (by decide) v hv
  exact satisfied missing (_h 56 (by decide))

theorem unit11641_19    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 60) : v.neg (polarity11641 60) := by
  have exactPolarity : polarity11641 60 = (Sat.Literal.pos 1262) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 1262)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 1262), (Sat.Literal.pos 1362)] :=
    ready 1461 (by decide) v hv
  exact satisfied missing (_h 56 (by decide))

theorem unit11641_20    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 61) : v.neg (polarity11641 61) := by
  have exactPolarity : polarity11641 61 = (Sat.Literal.pos 1356) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 1356)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 1356)] :=
    ready 9269 (by decide) v hv
  exact satisfied missing

theorem unit11641_21    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 62) : v.neg (polarity11641 62) := by
  have exactPolarity : polarity11641 62 = (Sat.Literal.pos 1314) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 1314)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 1314)] :=
    ready 9273 (by decide) v hv
  exact satisfied missing

theorem unit11641_22    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 63) : v.neg (polarity11641 63) := by
  have exactPolarity : polarity11641 63 = (Sat.Literal.pos 670) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 670)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 670), (Sat.Literal.pos 1314)] :=
    ready 5842 (by decide) v hv
  exact satisfied missing (_h 62 (by decide))

theorem unit11641_23    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 64) : v.neg (polarity11641 64) := by
  have exactPolarity : polarity11641 64 = (Sat.Literal.pos 676) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 676)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 676), (Sat.Literal.pos 1314)] :=
    ready 5848 (by decide) v hv
  exact satisfied missing (_h 62 (by decide))

theorem segment11641_0_24    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base) :
    NegBelow v polarity11641 41 → NegBelow v polarity11641 65 :=
  ((((((extendNeg (unit11641_23 base v ready hv)) ∘ (extendNeg (unit11641_22 base v ready hv))) ∘ (extendNeg (unit11641_21 base v ready hv))) ∘ (((extendNeg (unit11641_20 base v ready hv)) ∘ (extendNeg (unit11641_19 base v ready hv))) ∘ (extendNeg (unit11641_18 base v ready hv)))) ∘ ((((extendNeg (unit11641_17 base v ready hv)) ∘ (extendNeg (unit11641_16 base v ready hv))) ∘ (extendNeg (unit11641_15 base v ready hv))) ∘ (((extendNeg (unit11641_14 base v ready hv)) ∘ (extendNeg (unit11641_13 base v ready hv))) ∘ (extendNeg (unit11641_12 base v ready hv))))) ∘ (((((extendNeg (unit11641_11 base v ready hv)) ∘ (extendNeg (unit11641_10 base v ready hv))) ∘ (extendNeg (unit11641_9 base v ready hv))) ∘ (((extendNeg (unit11641_8 base v ready hv)) ∘ (extendNeg (unit11641_7 base v ready hv))) ∘ (extendNeg (unit11641_6 base v ready hv)))) ∘ ((((extendNeg (unit11641_5 base v ready hv)) ∘ (extendNeg (unit11641_4 base v ready hv))) ∘ (extendNeg (unit11641_3 base v ready hv))) ∘ (((extendNeg (unit11641_2 base v ready hv)) ∘ (extendNeg (unit11641_1 base v ready hv))) ∘ (extendNeg (unit11641_0 base v ready hv))))))

end Euler.C14.PolarityDraft
