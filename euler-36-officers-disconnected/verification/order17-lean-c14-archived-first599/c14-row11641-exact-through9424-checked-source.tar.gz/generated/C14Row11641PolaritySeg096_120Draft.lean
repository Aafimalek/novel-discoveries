import C14Row11641PolarityDataDraft
namespace Euler.C14.PolarityDraft
open Euler.C14.IndexedDraft
open Euler.C14.Production (rowAt)
set_option maxRecDepth 18000
set_option maxHeartbeats 2400000
theorem unit11641_96    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 137) : v.neg (polarity11641 137) := by
  have exactPolarity : polarity11641 137 = (Sat.Literal.pos 143) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 143)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 143), (Sat.Literal.pos 1299)] :=
    ready 1661 (by decide) v hv
  exact satisfied missing (_h 125 (by decide))

theorem unit11641_97    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 138) : v.neg (polarity11641 138) := by
  have exactPolarity : polarity11641 138 = (Sat.Literal.pos 1298) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 1298)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 1298), (Sat.Literal.pos 1299), (Sat.Literal.pos 1300), (Sat.Literal.pos 1301)] :=
    ready 8832 (by decide) v hv
  exact satisfied missing (_h 125 (by decide)) (_h 91 (by decide)) (_h 108 (by decide))

theorem unit11641_98    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 139) : v.neg (polarity11641 139) := by
  have exactPolarity : polarity11641 139 = (Sat.Literal.pos 99) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 99)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 99), (Sat.Literal.pos 1298)] :=
    ready 38 (by decide) v hv
  exact satisfied missing (_h 138 (by decide))

theorem unit11641_99    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 140) : v.neg (polarity11641 140) := by
  have exactPolarity : polarity11641 140 = (Sat.Literal.pos 100) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 100)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 100), (Sat.Literal.pos 1298)] :=
    ready 131 (by decide) v hv
  exact satisfied missing (_h 138 (by decide))

theorem unit11641_100    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 141) : v.neg (polarity11641 141) := by
  have exactPolarity : polarity11641 141 = (Sat.Literal.pos 101) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 101)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 101), (Sat.Literal.pos 1298)] :=
    ready 157 (by decide) v hv
  exact satisfied missing (_h 138 (by decide))

theorem unit11641_101    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 142) : v.neg (polarity11641 142) := by
  have exactPolarity : polarity11641 142 = (Sat.Literal.pos 104) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 104)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 104), (Sat.Literal.pos 1298)] :=
    ready 407 (by decide) v hv
  exact satisfied missing (_h 138 (by decide))

theorem unit11641_102    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 143) : v.neg (polarity11641 143) := by
  have exactPolarity : polarity11641 143 = (Sat.Literal.pos 105) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 105)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 105), (Sat.Literal.pos 1298)] :=
    ready 462 (by decide) v hv
  exact satisfied missing (_h 138 (by decide))

theorem unit11641_103    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 144) : v.neg (polarity11641 144) := by
  have exactPolarity : polarity11641 144 = (Sat.Literal.pos 106) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 106)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 106), (Sat.Literal.pos 1298)] :=
    ready 544 (by decide) v hv
  exact satisfied missing (_h 138 (by decide))

theorem unit11641_104    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 145) : v.neg (polarity11641 145) := by
  have exactPolarity : polarity11641 145 = (Sat.Literal.pos 107) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 107)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 107), (Sat.Literal.pos 1298)] :=
    ready 614 (by decide) v hv
  exact satisfied missing (_h 138 (by decide))

theorem unit11641_105    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 146) : v.neg (polarity11641 146) := by
  have exactPolarity : polarity11641 146 = (Sat.Literal.pos 86) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 86)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 86), (Sat.Literal.pos 1298)] :=
    ready 7470 (by decide) v hv
  exact satisfied missing (_h 138 (by decide))

theorem unit11641_106    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 147) : v.neg (polarity11641 147) := by
  have exactPolarity : polarity11641 147 = (Sat.Literal.pos 87) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 87)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 87), (Sat.Literal.pos 1298)] :=
    ready 7529 (by decide) v hv
  exact satisfied missing (_h 138 (by decide))

theorem unit11641_107    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 148) : v.neg (polarity11641 148) := by
  have exactPolarity : polarity11641 148 = (Sat.Literal.pos 88) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 88)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 88), (Sat.Literal.pos 1298)] :=
    ready 7594 (by decide) v hv
  exact satisfied missing (_h 138 (by decide))

theorem unit11641_108    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 149) : v.neg (polarity11641 149) := by
  have exactPolarity : polarity11641 149 = (Sat.Literal.pos 89) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 89)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 89), (Sat.Literal.pos 1298)] :=
    ready 7652 (by decide) v hv
  exact satisfied missing (_h 138 (by decide))

theorem unit11641_109    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 150) : v.neg (polarity11641 150) := by
  have exactPolarity : polarity11641 150 = (Sat.Literal.pos 92) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 92)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 92), (Sat.Literal.pos 1298)] :=
    ready 7822 (by decide) v hv
  exact satisfied missing (_h 138 (by decide))

theorem unit11641_110    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 151) : v.neg (polarity11641 151) := by
  have exactPolarity : polarity11641 151 = (Sat.Literal.pos 93) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 93)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 93), (Sat.Literal.pos 1298)] :=
    ready 7858 (by decide) v hv
  exact satisfied missing (_h 138 (by decide))

theorem unit11641_111    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 152) : v.neg (polarity11641 152) := by
  have exactPolarity : polarity11641 152 = (Sat.Literal.pos 94) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 94)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 94), (Sat.Literal.pos 1298)] :=
    ready 7878 (by decide) v hv
  exact satisfied missing (_h 138 (by decide))

theorem unit11641_112    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 153) : v.neg (polarity11641 153) := by
  have exactPolarity : polarity11641 153 = (Sat.Literal.pos 95) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 95)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 95), (Sat.Literal.pos 1298)] :=
    ready 7952 (by decide) v hv
  exact satisfied missing (_h 138 (by decide))

theorem unit11641_113    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 154) : v.neg (polarity11641 154) := by
  have exactPolarity : polarity11641 154 = (Sat.Literal.pos 98) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 98)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 98), (Sat.Literal.pos 1298)] :=
    ready 8077 (by decide) v hv
  exact satisfied missing (_h 138 (by decide))

theorem unit11641_114    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 155) : v.neg (polarity11641 155) := by
  have exactPolarity : polarity11641 155 = (Sat.Literal.pos 1337) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 1337)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 1337), (Sat.Literal.pos 104), (Sat.Literal.pos 105), (Sat.Literal.pos 106), (Sat.Literal.pos 107), (Sat.Literal.pos 140), (Sat.Literal.pos 141), (Sat.Literal.pos 142), (Sat.Literal.pos 143), (Sat.Literal.pos 176), (Sat.Literal.pos 177), (Sat.Literal.pos 178), (Sat.Literal.pos 179), (Sat.Literal.pos 212), (Sat.Literal.pos 213), (Sat.Literal.pos 214), (Sat.Literal.pos 215)] :=
    ready 9124 (by decide) v hv
  exact satisfied missing (_h 142 (by decide)) (_h 143 (by decide)) (_h 144 (by decide)) (_h 145 (by decide)) (_h 134 (by decide)) (_h 135 (by decide)) (_h 136 (by decide)) (_h 137 (by decide)) (_h 104 (by decide)) (_h 105 (by decide)) (_h 106 (by decide)) (_h 107 (by decide)) (_h 121 (by decide)) (_h 122 (by decide)) (_h 123 (by decide)) (_h 124 (by decide))

theorem unit11641_115    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 156) : v.neg (polarity11641 156) := by
  have exactPolarity : polarity11641 156 = (Sat.Literal.pos 1370) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 1370)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 1370), (Sat.Literal.pos 86), (Sat.Literal.pos 92), (Sat.Literal.pos 98), (Sat.Literal.pos 104), (Sat.Literal.pos 128), (Sat.Literal.pos 134), (Sat.Literal.pos 140), (Sat.Literal.pos 158), (Sat.Literal.pos 164), (Sat.Literal.pos 170), (Sat.Literal.pos 176), (Sat.Literal.pos 194), (Sat.Literal.pos 200), (Sat.Literal.pos 206), (Sat.Literal.pos 212)] :=
    ready 9145 (by decide) v hv
  exact satisfied missing (_h 146 (by decide)) (_h 150 (by decide)) (_h 154 (by decide)) (_h 142 (by decide)) (_h 126 (by decide)) (_h 130 (by decide)) (_h 134 (by decide)) (_h 92 (by decide)) (_h 96 (by decide)) (_h 100 (by decide)) (_h 104 (by decide)) (_h 109 (by decide)) (_h 113 (by decide)) (_h 117 (by decide)) (_h 121 (by decide))

theorem unit11641_116    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 157) : v.neg (polarity11641 157) := by
  have exactPolarity : polarity11641 157 = (Sat.Literal.pos 1334) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 1334)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 1334), (Sat.Literal.pos 86), (Sat.Literal.pos 87), (Sat.Literal.pos 88), (Sat.Literal.pos 89), (Sat.Literal.pos 158), (Sat.Literal.pos 159), (Sat.Literal.pos 160), (Sat.Literal.pos 161), (Sat.Literal.pos 194), (Sat.Literal.pos 195), (Sat.Literal.pos 196), (Sat.Literal.pos 197)] :=
    ready 9121 (by decide) v hv
  exact satisfied missing (_h 146 (by decide)) (_h 147 (by decide)) (_h 148 (by decide)) (_h 149 (by decide)) (_h 92 (by decide)) (_h 93 (by decide)) (_h 94 (by decide)) (_h 95 (by decide)) (_h 109 (by decide)) (_h 110 (by decide)) (_h 111 (by decide)) (_h 112 (by decide))

theorem unit11641_117    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 158) : v.neg (polarity11641 158) := by
  have exactPolarity : polarity11641 158 = (Sat.Literal.pos 1371) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 1371)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 1371), (Sat.Literal.pos 87), (Sat.Literal.pos 93), (Sat.Literal.pos 99), (Sat.Literal.pos 105), (Sat.Literal.pos 129), (Sat.Literal.pos 135), (Sat.Literal.pos 141), (Sat.Literal.pos 159), (Sat.Literal.pos 165), (Sat.Literal.pos 171), (Sat.Literal.pos 177), (Sat.Literal.pos 195), (Sat.Literal.pos 201), (Sat.Literal.pos 207), (Sat.Literal.pos 213)] :=
    ready 9146 (by decide) v hv
  exact satisfied missing (_h 147 (by decide)) (_h 151 (by decide)) (_h 139 (by decide)) (_h 143 (by decide)) (_h 127 (by decide)) (_h 131 (by decide)) (_h 135 (by decide)) (_h 93 (by decide)) (_h 97 (by decide)) (_h 101 (by decide)) (_h 105 (by decide)) (_h 110 (by decide)) (_h 114 (by decide)) (_h 118 (by decide)) (_h 122 (by decide))

theorem unit11641_118    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 159) : v.neg (polarity11641 159) := by
  have exactPolarity : polarity11641 159 = (Sat.Literal.pos 1372) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 1372)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 1372), (Sat.Literal.pos 88), (Sat.Literal.pos 94), (Sat.Literal.pos 100), (Sat.Literal.pos 106), (Sat.Literal.pos 130), (Sat.Literal.pos 136), (Sat.Literal.pos 142), (Sat.Literal.pos 160), (Sat.Literal.pos 166), (Sat.Literal.pos 172), (Sat.Literal.pos 178), (Sat.Literal.pos 196), (Sat.Literal.pos 202), (Sat.Literal.pos 208), (Sat.Literal.pos 214)] :=
    ready 9147 (by decide) v hv
  exact satisfied missing (_h 148 (by decide)) (_h 152 (by decide)) (_h 140 (by decide)) (_h 144 (by decide)) (_h 128 (by decide)) (_h 132 (by decide)) (_h 136 (by decide)) (_h 94 (by decide)) (_h 98 (by decide)) (_h 102 (by decide)) (_h 106 (by decide)) (_h 111 (by decide)) (_h 115 (by decide)) (_h 119 (by decide)) (_h 123 (by decide))

theorem unit11641_119    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 160) : v.neg (polarity11641 160) := by
  have exactPolarity : polarity11641 160 = (Sat.Literal.pos 1373) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 1373)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 1373), (Sat.Literal.pos 89), (Sat.Literal.pos 95), (Sat.Literal.pos 101), (Sat.Literal.pos 107), (Sat.Literal.pos 131), (Sat.Literal.pos 137), (Sat.Literal.pos 143), (Sat.Literal.pos 161), (Sat.Literal.pos 167), (Sat.Literal.pos 173), (Sat.Literal.pos 179), (Sat.Literal.pos 197), (Sat.Literal.pos 203), (Sat.Literal.pos 209), (Sat.Literal.pos 215)] :=
    ready 9148 (by decide) v hv
  exact satisfied missing (_h 149 (by decide)) (_h 153 (by decide)) (_h 141 (by decide)) (_h 145 (by decide)) (_h 129 (by decide)) (_h 133 (by decide)) (_h 137 (by decide)) (_h 95 (by decide)) (_h 99 (by decide)) (_h 103 (by decide)) (_h 107 (by decide)) (_h 112 (by decide)) (_h 116 (by decide)) (_h 120 (by decide)) (_h 124 (by decide))

theorem segment11641_96_120    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base) :
    NegBelow v polarity11641 137 → NegBelow v polarity11641 161 :=
  ((((((extendNeg (unit11641_119 base v ready hv)) ∘ (extendNeg (unit11641_118 base v ready hv))) ∘ (extendNeg (unit11641_117 base v ready hv))) ∘ (((extendNeg (unit11641_116 base v ready hv)) ∘ (extendNeg (unit11641_115 base v ready hv))) ∘ (extendNeg (unit11641_114 base v ready hv)))) ∘ ((((extendNeg (unit11641_113 base v ready hv)) ∘ (extendNeg (unit11641_112 base v ready hv))) ∘ (extendNeg (unit11641_111 base v ready hv))) ∘ (((extendNeg (unit11641_110 base v ready hv)) ∘ (extendNeg (unit11641_109 base v ready hv))) ∘ (extendNeg (unit11641_108 base v ready hv))))) ∘ (((((extendNeg (unit11641_107 base v ready hv)) ∘ (extendNeg (unit11641_106 base v ready hv))) ∘ (extendNeg (unit11641_105 base v ready hv))) ∘ (((extendNeg (unit11641_104 base v ready hv)) ∘ (extendNeg (unit11641_103 base v ready hv))) ∘ (extendNeg (unit11641_102 base v ready hv)))) ∘ ((((extendNeg (unit11641_101 base v ready hv)) ∘ (extendNeg (unit11641_100 base v ready hv))) ∘ (extendNeg (unit11641_99 base v ready hv))) ∘ (((extendNeg (unit11641_98 base v ready hv)) ∘ (extendNeg (unit11641_97 base v ready hv))) ∘ (extendNeg (unit11641_96 base v ready hv))))))

end Euler.C14.PolarityDraft
