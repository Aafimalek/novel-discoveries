import C14Row11641PolarityDataDraft
namespace Euler.C14.PolarityDraft
open Euler.C14.IndexedDraft
open Euler.C14.Production (rowAt)
set_option maxRecDepth 18000
set_option maxHeartbeats 2400000
theorem unit11641_240    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 281) : v.neg (polarity11641 281) := by
  have exactPolarity : polarity11641 281 = (Sat.Literal.pos 826) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 826)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 826), (Sat.Literal.pos 1318)] :=
    ready 7111 (by decide) v hv
  exact satisfied missing (_h 26 (by decide))

theorem unit11641_241    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 282) : v.neg (polarity11641 282) := by
  have exactPolarity : polarity11641 282 = (Sat.Literal.pos 838) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 838)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 838), (Sat.Literal.pos 1351)] :=
    ready 7173 (by decide) v hv
  exact satisfied missing (_h 30 (by decide))

theorem unit11641_242    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 283) : v.neg (polarity11641 283) := by
  have exactPolarity : polarity11641 283 = (Sat.Literal.pos 574) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 574)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 574), (Sat.Literal.pos 1384)] :=
    ready 5056 (by decide) v hv
  exact satisfied missing (_h 34 (by decide))

theorem unit11641_243    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 284) : v.neg (polarity11641 284) := by
  have exactPolarity : polarity11641 284 = (Sat.Literal.pos 592) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 592)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 592), (Sat.Literal.pos 1384)] :=
    ready 5161 (by decide) v hv
  exact satisfied missing (_h 34 (by decide))

theorem unit11641_244    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 285) : v.neg (polarity11641 285) := by
  have exactPolarity : polarity11641 285 = (Sat.Literal.pos 598) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 598)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 598), (Sat.Literal.pos 1384)] :=
    ready 5204 (by decide) v hv
  exact satisfied missing (_h 34 (by decide))

theorem unit11641_245    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 286) : v.neg (polarity11641 286) := by
  have exactPolarity : polarity11641 286 = (Sat.Literal.pos 604) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 604)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 604), (Sat.Literal.pos 1384)] :=
    ready 5284 (by decide) v hv
  exact satisfied missing (_h 34 (by decide))

theorem unit11641_246    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 287) : v.neg (polarity11641 287) := by
  have exactPolarity : polarity11641 287 = (Sat.Literal.pos 610) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 610)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 610), (Sat.Literal.pos 1384)] :=
    ready 5357 (by decide) v hv
  exact satisfied missing (_h 34 (by decide))

theorem unit11641_247    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 288) : v.neg (polarity11641 288) := by
  have exactPolarity : polarity11641 288 = (Sat.Literal.pos 628) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 628)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 628), (Sat.Literal.pos 1384)] :=
    ready 5493 (by decide) v hv
  exact satisfied missing (_h 34 (by decide))

theorem unit11641_248    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 289) : v.neg (polarity11641 289) := by
  have exactPolarity : polarity11641 289 = (Sat.Literal.pos 634) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 634)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 634), (Sat.Literal.pos 1384)] :=
    ready 5576 (by decide) v hv
  exact satisfied missing (_h 34 (by decide))

theorem unit11641_249    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 290) : v.neg (polarity11641 290) := by
  have exactPolarity : polarity11641 290 = (Sat.Literal.pos 640) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 640)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 640), (Sat.Literal.pos 1384)] :=
    ready 5619 (by decide) v hv
  exact satisfied missing (_h 34 (by decide))

theorem unit11641_250    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 291) : v.neg (polarity11641 291) := by
  have exactPolarity : polarity11641 291 = (Sat.Literal.pos 646) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 646)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 646), (Sat.Literal.pos 1384)] :=
    ready 5695 (by decide) v hv
  exact satisfied missing (_h 34 (by decide))

theorem unit11641_251    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 292) : v.neg (polarity11641 292) := by
  have exactPolarity : polarity11641 292 = (Sat.Literal.pos 1383) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 1383)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.pos 1371), (Sat.Literal.pos 1372), (Sat.Literal.neg 1377), (Sat.Literal.neg 1378), (Sat.Literal.neg 1383), (Sat.Literal.pos 1384)] :=
    ready 9075 (by decide) v hv
  exact satisfied (_h 158 (by decide)) (_h 159 (by decide)) (_h 225 (by decide)) (_h 33 (by decide)) missing (_h 34 (by decide))

theorem unit11641_252    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 293) : v.neg (polarity11641 293) := by
  have exactPolarity : polarity11641 293 = (Sat.Literal.pos 1249) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 1249)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 1249), (Sat.Literal.pos 1399)] :=
    ready 1376 (by decide) v hv
  exact satisfied missing (_h 38 (by decide))

theorem unit11641_253    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 294) : v.neg (polarity11641 294) := by
  have exactPolarity : polarity11641 294 = (Sat.Literal.pos 718) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 718)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 718), (Sat.Literal.pos 1415)] :=
    ready 6265 (by decide) v hv
  exact satisfied missing (_h 39 (by decide))

theorem unit11641_254    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 295) : v.neg (polarity11641 295) := by
  have exactPolarity : polarity11641 295 = (Sat.Literal.pos 1148) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 1148)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 1148), (Sat.Literal.pos 1415)] :=
    ready 819 (by decide) v hv
  exact satisfied missing (_h 39 (by decide))

theorem unit11641_255    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 296) : v.neg (polarity11641 296) := by
  have exactPolarity : polarity11641 296 = (Sat.Literal.pos 1820) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 1820)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 1820), (Sat.Literal.pos 1821)] :=
    ready 1831 (by decide) v hv
  exact satisfied missing (_h 40 (by decide))

theorem unit11641_256    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 297) : v.neg (polarity11641 297) := by
  have exactPolarity : polarity11641 297 = (Sat.Literal.pos 317) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 317)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 317), (Sat.Literal.pos 1821)] :=
    ready 2817 (by decide) v hv
  exact satisfied missing (_h 40 (by decide))

theorem unit11641_257    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 298) : v.neg (polarity11641 298) := by
  have exactPolarity : polarity11641 298 = (Sat.Literal.neg 8592) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.pos 8592)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 8591), (Sat.Literal.pos 8592)] :=
    ready 7371 (by decide) v hv
  exact satisfied (_h 222 (by decide)) missing

theorem unit11641_258    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 299) : v.neg (polarity11641 299) := by
  have exactPolarity : polarity11641 299 = (Sat.Literal.neg 6072) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.pos 6072)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 6071), (Sat.Literal.pos 6072)] :=
    ready 5302 (by decide) v hv
  exact satisfied (_h 226 (by decide)) missing

theorem unit11641_259    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 300) : v.neg (polarity11641 300) := by
  have exactPolarity : polarity11641 300 = (Sat.Literal.neg 8767) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.pos 8767)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 8766), (Sat.Literal.pos 8767)] :=
    ready 7501 (by decide) v hv
  exact satisfied (_h 227 (by decide)) missing

theorem unit11641_260    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 301) : v.neg (polarity11641 301) := by
  have exactPolarity : polarity11641 301 = (Sat.Literal.pos 1355) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 1355)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 1355), (Sat.Literal.neg 1343), (Sat.Literal.neg 1349), (Sat.Literal.neg 1361)] :=
    ready 9404 (by decide) v hv
  exact satisfied missing (_h 228 (by decide)) (_h 244 (by decide)) (_h 258 (by decide))

theorem unit11641_261    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 302) : v.neg (polarity11641 302) := by
  have exactPolarity : polarity11641 302 = (Sat.Literal.pos 1367) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 1367)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.pos 1337), (Sat.Literal.neg 1343), (Sat.Literal.neg 1349), (Sat.Literal.pos 1355), (Sat.Literal.neg 1361), (Sat.Literal.neg 1367)] :=
    ready 9042 (by decide) v hv
  exact satisfied (_h 155 (by decide)) (_h 228 (by decide)) (_h 244 (by decide)) (_h 301 (by decide)) (_h 258 (by decide)) missing

theorem unit11641_262    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 303) : v.neg (polarity11641 303) := by
  have exactPolarity : polarity11641 303 = (Sat.Literal.pos 1348) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 1348)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.pos 1336), (Sat.Literal.pos 1337), (Sat.Literal.neg 1342), (Sat.Literal.neg 1343), (Sat.Literal.neg 1348), (Sat.Literal.neg 1349), (Sat.Literal.neg 1354), (Sat.Literal.pos 1355)] :=
    ready 9084 (by decide) v hv
  exact satisfied (_h 162 (by decide)) (_h 155 (by decide)) (_h 224 (by decide)) (_h 228 (by decide)) missing (_h 244 (by decide)) (_h 31 (by decide)) (_h 301 (by decide))

theorem unit11641_263    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 304) : v.neg (polarity11641 304) := by
  have exactPolarity : polarity11641 304 = (Sat.Literal.pos 1417) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 1417)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 1417), (Sat.Literal.pos 729), (Sat.Literal.pos 730), (Sat.Literal.pos 731), (Sat.Literal.pos 942), (Sat.Literal.pos 945), (Sat.Literal.pos 946), (Sat.Literal.pos 947), (Sat.Literal.pos 1158), (Sat.Literal.pos 1161), (Sat.Literal.pos 1162), (Sat.Literal.pos 1163)] :=
    ready 9175 (by decide) v hv
  exact satisfied missing (_h 245 (by decide)) (_h 246 (by decide)) (_h 247 (by decide)) (_h 191 (by decide)) (_h 214 (by decide)) (_h 215 (by decide)) (_h 216 (by decide)) (_h 45 (by decide)) (_h 259 (by decide)) (_h 260 (by decide)) (_h 261 (by decide))

theorem segment11641_240_264    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base) :
    NegBelow v polarity11641 281 → NegBelow v polarity11641 305 :=
  ((((((extendNeg (unit11641_263 base v ready hv)) ∘ (extendNeg (unit11641_262 base v ready hv))) ∘ (extendNeg (unit11641_261 base v ready hv))) ∘ (((extendNeg (unit11641_260 base v ready hv)) ∘ (extendNeg (unit11641_259 base v ready hv))) ∘ (extendNeg (unit11641_258 base v ready hv)))) ∘ ((((extendNeg (unit11641_257 base v ready hv)) ∘ (extendNeg (unit11641_256 base v ready hv))) ∘ (extendNeg (unit11641_255 base v ready hv))) ∘ (((extendNeg (unit11641_254 base v ready hv)) ∘ (extendNeg (unit11641_253 base v ready hv))) ∘ (extendNeg (unit11641_252 base v ready hv))))) ∘ (((((extendNeg (unit11641_251 base v ready hv)) ∘ (extendNeg (unit11641_250 base v ready hv))) ∘ (extendNeg (unit11641_249 base v ready hv))) ∘ (((extendNeg (unit11641_248 base v ready hv)) ∘ (extendNeg (unit11641_247 base v ready hv))) ∘ (extendNeg (unit11641_246 base v ready hv)))) ∘ ((((extendNeg (unit11641_245 base v ready hv)) ∘ (extendNeg (unit11641_244 base v ready hv))) ∘ (extendNeg (unit11641_243 base v ready hv))) ∘ (((extendNeg (unit11641_242 base v ready hv)) ∘ (extendNeg (unit11641_241 base v ready hv))) ∘ (extendNeg (unit11641_240 base v ready hv))))))

end Euler.C14.PolarityDraft
