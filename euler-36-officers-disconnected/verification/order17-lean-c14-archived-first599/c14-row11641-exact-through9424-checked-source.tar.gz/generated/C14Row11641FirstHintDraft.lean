import C14Row11641PolarityDataDraft
namespace Euler.C14.PolarityDraft
open Euler.C14.IndexedDraft
open Euler.C14.Production (rowAt)
set_option maxRecDepth 18000
set_option maxHeartbeats 2400000
theorem firstHint11641    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 41) : v.neg (polarity11641 41) := by
  have exactPolarity : polarity11641 41 = (Sat.Literal.pos 1398) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 1398)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 1398)] :=
    ready 9262 (by decide) v hv
  exact satisfied missing
#print axioms firstHint11641
end Euler.C14.PolarityDraft
