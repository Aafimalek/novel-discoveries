import C14Row11641PolarityDataDraft
namespace Euler.C14.PolarityDraft
open Euler.C14.IndexedDraft
open Euler.C14.Production (rowAt)
set_option maxRecDepth 18000
set_option maxHeartbeats 2400000
theorem unit11641_481    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 522) : v.neg (polarity11641 522) := by
  have exactPolarity : polarity11641 522 = (Sat.Literal.neg 704) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.pos 704)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.pos 704), (Sat.Literal.pos 343), (Sat.Literal.neg 346), (Sat.Literal.pos 379), (Sat.Literal.pos 415), (Sat.Literal.pos 482), (Sat.Literal.pos 488), (Sat.Literal.pos 494), (Sat.Literal.pos 500), (Sat.Literal.pos 707), (Sat.Literal.pos 710), (Sat.Literal.pos 712), (Sat.Literal.pos 713), (Sat.Literal.pos 811), (Sat.Literal.pos 812), (Sat.Literal.pos 818), (Sat.Literal.pos 824), (Sat.Literal.pos 847), (Sat.Literal.pos 848), (Sat.Literal.pos 854), (Sat.Literal.pos 860), (Sat.Literal.pos 1130), (Sat.Literal.pos 1136), (Sat.Literal.pos 1137), (Sat.Literal.pos 1139), (Sat.Literal.pos 1142), (Sat.Literal.pos 1211), (Sat.Literal.pos 1234), (Sat.Literal.pos 1235), (Sat.Literal.pos 1238), (Sat.Literal.pos 1239), (Sat.Literal.pos 1240), (Sat.Literal.pos 1241), (Sat.Literal.pos 1245), (Sat.Literal.pos 1247), (Sat.Literal.pos 1250), (Sat.Literal.pos 1252), (Sat.Literal.pos 1253), (Sat.Literal.pos 1256), (Sat.Literal.pos 1257), (Sat.Literal.pos 1258), (Sat.Literal.pos 1259), (Sat.Literal.pos 1283), (Sat.Literal.neg 1315), (Sat.Literal.pos 1316), (Sat.Literal.pos 1321), (Sat.Literal.pos 1328), (Sat.Literal.neg 1330), (Sat.Literal.pos 1348), (Sat.Literal.neg 1354), (Sat.Literal.pos 1360), (Sat.Literal.neg 1382), (Sat.Literal.pos 1399), (Sat.Literal.pos 1415), (Sat.Literal.neg 8775)] :=
    ready 9422 (by decide) v hv
  exact satisfied missing (_h 2 (by decide)) (_h 3 (by decide)) (_h 229 (by decide)) (_h 6 (by decide)) (_h 234 (by decide)) (_h 236 (by decide)) (_h 238 (by decide)) (_h 242 (by decide)) (_h 12 (by decide)) (_h 13 (by decide)) (_h 14 (by decide)) (_h 15 (by decide)) (_h 16 (by decide)) (_h 275 (by decide)) (_h 277 (by decide)) (_h 280 (by decide)) (_h 19 (by decide)) (_h 406 (by decide)) (_h 388 (by decide)) (_h 317 (by decide)) (_h 490 (by decide)) (_h 468 (by decide)) (_h 464 (by decide)) (_h 415 (by decide)) (_h 435 (by decide)) (_h 417 (by decide)) (_h 494 (by decide)) (_h 418 (by decide)) (_h 511 (by decide)) (_h 512 (by decide)) (_h 498 (by decide)) (_h 419 (by decide)) (_h 521 (by decide)) (_h 420 (by decide)) (_h 496 (by decide)) (_h 501 (by decide)) (_h 421 (by decide)) (_h 320 (by decide)) (_h 321 (by decide)) (_h 322 (by decide)) (_h 323 (by decide)) (_h 423 (by decide)) (_h 24 (by decide)) (_h 25 (by decide)) (_h 27 (by decide)) (_h 28 (by decide)) (_h 514 (by decide)) (_h 303 (by decide)) (_h 31 (by decide)) (_h 431 (by decide)) (_h 517 (by decide)) (_h 38 (by decide)) (_h 39 (by decide)) (_h 358 (by decide))

theorem segment11641_481_482    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base) :
    NegBelow v polarity11641 522 → NegBelow v polarity11641 523 :=
  (extendNeg (unit11641_481 base v ready hv))

end Euler.C14.PolarityDraft
