import C14Row11641PolarityDataDraft
namespace Euler.C14.PolarityDraft
open Euler.C14.IndexedDraft
open Euler.C14.Production (rowAt)
set_option maxRecDepth 18000
set_option maxHeartbeats 2400000
theorem unit11641_264    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 305) : v.neg (polarity11641 305) := by
  have exactPolarity : polarity11641 305 = (Sat.Literal.pos 551) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 551)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 551), (Sat.Literal.pos 1345)] :=
    ready 4769 (by decide) v hv
  exact satisfied missing (_h 273 (by decide))

theorem unit11641_265    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 306) : v.neg (polarity11641 306) := by
  have exactPolarity : polarity11641 306 = (Sat.Literal.pos 587) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 587)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 587), (Sat.Literal.pos 1345)] :=
    ready 5128 (by decide) v hv
  exact satisfied missing (_h 273 (by decide))

theorem unit11641_266    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 307) : v.neg (polarity11641 307) := by
  have exactPolarity : polarity11641 307 = (Sat.Literal.pos 623) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 623)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 623), (Sat.Literal.pos 1345)] :=
    ready 5442 (by decide) v hv
  exact satisfied missing (_h 273 (by decide))

theorem unit11641_267    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 308) : v.neg (polarity11641 308) := by
  have exactPolarity : polarity11641 308 = (Sat.Literal.pos 597) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 597)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 597), (Sat.Literal.pos 1383)] :=
    ready 5195 (by decide) v hv
  exact satisfied missing (_h 292 (by decide))

theorem unit11641_268    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 309) : v.neg (polarity11641 309) := by
  have exactPolarity : polarity11641 309 = (Sat.Literal.pos 603) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 603)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 603), (Sat.Literal.pos 1383)] :=
    ready 5273 (by decide) v hv
  exact satisfied missing (_h 292 (by decide))

theorem unit11641_269    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 310) : v.neg (polarity11641 310) := by
  have exactPolarity : polarity11641 310 = (Sat.Literal.pos 633) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 633)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 633), (Sat.Literal.pos 1383)] :=
    ready 5564 (by decide) v hv
  exact satisfied missing (_h 292 (by decide))

theorem unit11641_270    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 311) : v.neg (polarity11641 311) := by
  have exactPolarity : polarity11641 311 = (Sat.Literal.pos 639) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 639)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 639), (Sat.Literal.pos 1383)] :=
    ready 5608 (by decide) v hv
  exact satisfied missing (_h 292 (by decide))

theorem unit11641_271    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 312) : v.neg (polarity11641 312) := by
  have exactPolarity : polarity11641 312 = (Sat.Literal.pos 1819) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 1819)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 1819), (Sat.Literal.pos 1820)] :=
    ready 1830 (by decide) v hv
  exact satisfied missing (_h 296 (by decide))

theorem unit11641_272    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 313) : v.neg (polarity11641 313) := by
  have exactPolarity : polarity11641 313 = (Sat.Literal.pos 316) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 316)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 316), (Sat.Literal.pos 1820)] :=
    ready 2797 (by decide) v hv
  exact satisfied missing (_h 296 (by decide))

theorem unit11641_273    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 314) : v.neg (polarity11641 314) := by
  have exactPolarity : polarity11641 314 = (Sat.Literal.neg 8593) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.pos 8593)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 8592), (Sat.Literal.pos 8593)] :=
    ready 7372 (by decide) v hv
  exact satisfied (_h 298 (by decide)) missing

theorem unit11641_274    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 315) : v.neg (polarity11641 315) := by
  have exactPolarity : polarity11641 315 = (Sat.Literal.neg 6073) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.pos 6073)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 6072), (Sat.Literal.pos 6073)] :=
    ready 5303 (by decide) v hv
  exact satisfied (_h 299 (by decide)) missing

theorem unit11641_275    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 316) : v.neg (polarity11641 316) := by
  have exactPolarity : polarity11641 316 = (Sat.Literal.neg 8768) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.pos 8768)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 8767), (Sat.Literal.pos 8768)] :=
    ready 7502 (by decide) v hv
  exact satisfied (_h 300 (by decide)) missing

theorem unit11641_276    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 317) : v.neg (polarity11641 317) := by
  have exactPolarity : polarity11641 317 = (Sat.Literal.pos 860) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 860)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 860), (Sat.Literal.pos 1355)] :=
    ready 7405 (by decide) v hv
  exact satisfied missing (_h 301 (by decide))

theorem unit11641_277    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 318) : v.neg (polarity11641 318) := by
  have exactPolarity : polarity11641 318 = (Sat.Literal.pos 862) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 862)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 862), (Sat.Literal.pos 1355)] :=
    ready 7433 (by decide) v hv
  exact satisfied missing (_h 301 (by decide))

theorem unit11641_278    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 319) : v.neg (polarity11641 319) := by
  have exactPolarity : polarity11641 319 = (Sat.Literal.pos 1220) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 1220)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 1220), (Sat.Literal.pos 1367)] :=
    ready 1212 (by decide) v hv
  exact satisfied missing (_h 302 (by decide))

theorem unit11641_279    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 320) : v.neg (polarity11641 320) := by
  have exactPolarity : polarity11641 320 = (Sat.Literal.pos 1256) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 1256)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 1256), (Sat.Literal.pos 1367)] :=
    ready 1432 (by decide) v hv
  exact satisfied missing (_h 302 (by decide))

theorem unit11641_280    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 321) : v.neg (polarity11641 321) := by
  have exactPolarity : polarity11641 321 = (Sat.Literal.pos 1257) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 1257)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 1257), (Sat.Literal.pos 1367)] :=
    ready 1438 (by decide) v hv
  exact satisfied missing (_h 302 (by decide))

theorem unit11641_281    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 322) : v.neg (polarity11641 322) := by
  have exactPolarity : polarity11641 322 = (Sat.Literal.pos 1258) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 1258)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 1258), (Sat.Literal.pos 1367)] :=
    ready 1447 (by decide) v hv
  exact satisfied missing (_h 302 (by decide))

theorem unit11641_282    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 323) : v.neg (polarity11641 323) := by
  have exactPolarity : polarity11641 323 = (Sat.Literal.pos 1259) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 1259)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 1259), (Sat.Literal.pos 1367)] :=
    ready 1457 (by decide) v hv
  exact satisfied missing (_h 302 (by decide))

theorem unit11641_283    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 324) : v.neg (polarity11641 324) := by
  have exactPolarity : polarity11641 324 = (Sat.Literal.pos 1292) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 1292)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 1292), (Sat.Literal.pos 1367)] :=
    ready 1623 (by decide) v hv
  exact satisfied missing (_h 302 (by decide))

theorem unit11641_284    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 325) : v.neg (polarity11641 325) := by
  have exactPolarity : polarity11641 325 = (Sat.Literal.pos 566) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 566)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 566), (Sat.Literal.pos 1348)] :=
    ready 4923 (by decide) v hv
  exact satisfied missing (_h 303 (by decide))

theorem unit11641_285    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 326) : v.neg (polarity11641 326) := by
  have exactPolarity : polarity11641 326 = (Sat.Literal.pos 602) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 602)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 602), (Sat.Literal.pos 1348)] :=
    ready 5260 (by decide) v hv
  exact satisfied missing (_h 303 (by decide))

theorem unit11641_286    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 327) : v.neg (polarity11641 327) := by
  have exactPolarity : polarity11641 327 = (Sat.Literal.pos 605) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 605)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 605), (Sat.Literal.pos 1348)] :=
    ready 5293 (by decide) v hv
  exact satisfied missing (_h 303 (by decide))

theorem unit11641_287    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 328) : v.neg (polarity11641 328) := by
  have exactPolarity : polarity11641 328 = (Sat.Literal.pos 638) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 638)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 638), (Sat.Literal.pos 1348)] :=
    ready 5597 (by decide) v hv
  exact satisfied missing (_h 303 (by decide))

theorem segment11641_264_288    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base) :
    NegBelow v polarity11641 305 → NegBelow v polarity11641 329 :=
  ((((((extendNeg (unit11641_287 base v ready hv)) ∘ (extendNeg (unit11641_286 base v ready hv))) ∘ (extendNeg (unit11641_285 base v ready hv))) ∘ (((extendNeg (unit11641_284 base v ready hv)) ∘ (extendNeg (unit11641_283 base v ready hv))) ∘ (extendNeg (unit11641_282 base v ready hv)))) ∘ ((((extendNeg (unit11641_281 base v ready hv)) ∘ (extendNeg (unit11641_280 base v ready hv))) ∘ (extendNeg (unit11641_279 base v ready hv))) ∘ (((extendNeg (unit11641_278 base v ready hv)) ∘ (extendNeg (unit11641_277 base v ready hv))) ∘ (extendNeg (unit11641_276 base v ready hv))))) ∘ (((((extendNeg (unit11641_275 base v ready hv)) ∘ (extendNeg (unit11641_274 base v ready hv))) ∘ (extendNeg (unit11641_273 base v ready hv))) ∘ (((extendNeg (unit11641_272 base v ready hv)) ∘ (extendNeg (unit11641_271 base v ready hv))) ∘ (extendNeg (unit11641_270 base v ready hv)))) ∘ ((((extendNeg (unit11641_269 base v ready hv)) ∘ (extendNeg (unit11641_268 base v ready hv))) ∘ (extendNeg (unit11641_267 base v ready hv))) ∘ (((extendNeg (unit11641_266 base v ready hv)) ∘ (extendNeg (unit11641_265 base v ready hv))) ∘ (extendNeg (unit11641_264 base v ready hv))))))

end Euler.C14.PolarityDraft
