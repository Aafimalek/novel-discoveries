import C14Row11641PolarityDataDraft
namespace Euler.C14.PolarityDraft
open Euler.C14.IndexedDraft
open Euler.C14.Production (rowAt)
set_option maxRecDepth 18000
set_option maxHeartbeats 2400000
theorem unit11641_476    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 517) : v.neg (polarity11641 517) := by
  have exactPolarity : polarity11641 517 = (Sat.Literal.neg 1382) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.pos 1382)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.pos 1382), (Sat.Literal.pos 500), (Sat.Literal.pos 503), (Sat.Literal.pos 573), (Sat.Literal.pos 574), (Sat.Literal.pos 591), (Sat.Literal.pos 592), (Sat.Literal.pos 596), (Sat.Literal.pos 597), (Sat.Literal.pos 598), (Sat.Literal.pos 599), (Sat.Literal.pos 602), (Sat.Literal.pos 603), (Sat.Literal.pos 604), (Sat.Literal.pos 605), (Sat.Literal.pos 609), (Sat.Literal.pos 610), (Sat.Literal.pos 627), (Sat.Literal.pos 628), (Sat.Literal.pos 632), (Sat.Literal.pos 633), (Sat.Literal.pos 634), (Sat.Literal.pos 635), (Sat.Literal.pos 638), (Sat.Literal.pos 639), (Sat.Literal.pos 640), (Sat.Literal.pos 641), (Sat.Literal.pos 645), (Sat.Literal.pos 646), (Sat.Literal.pos 1311), (Sat.Literal.neg 1312), (Sat.Literal.neg 1313), (Sat.Literal.pos 1345), (Sat.Literal.neg 1349), (Sat.Literal.pos 1415)] :=
    ready 9421 (by decide) v hv
  exact satisfied missing (_h 242 (by decide)) (_h 243 (by decide)) (_h 7 (by decide)) (_h 283 (by decide)) (_h 8 (by decide)) (_h 284 (by decide)) (_h 337 (by decide)) (_h 308 (by decide)) (_h 285 (by decide)) (_h 338 (by decide)) (_h 326 (by decide)) (_h 309 (by decide)) (_h 286 (by decide)) (_h 327 (by decide)) (_h 9 (by decide)) (_h 287 (by decide)) (_h 10 (by decide)) (_h 288 (by decide)) (_h 339 (by decide)) (_h 310 (by decide)) (_h 289 (by decide)) (_h 340 (by decide)) (_h 328 (by decide)) (_h 311 (by decide)) (_h 290 (by decide)) (_h 329 (by decide)) (_h 11 (by decide)) (_h 291 (by decide)) (_h 515 (by decide)) (_h 509 (by decide)) (_h 23 (by decide)) (_h 273 (by decide)) (_h 244 (by decide)) (_h 39 (by decide))

theorem segment11641_476_477    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base) :
    NegBelow v polarity11641 517 → NegBelow v polarity11641 518 :=
  (extendNeg (unit11641_476 base v ready hv))

end Euler.C14.PolarityDraft
