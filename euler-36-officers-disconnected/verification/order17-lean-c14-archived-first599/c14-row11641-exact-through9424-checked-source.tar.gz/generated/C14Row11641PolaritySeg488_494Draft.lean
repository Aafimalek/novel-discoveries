import C14Row11641PolarityDataDraft
namespace Euler.C14.PolarityDraft
open Euler.C14.IndexedDraft
open Euler.C14.Production (rowAt)
set_option maxRecDepth 18000
set_option maxHeartbeats 2400000
theorem unit11641_488    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 529) : v.neg (polarity11641 529) := by
  have exactPolarity : polarity11641 529 = (Sat.Literal.neg 8533) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.pos 8533)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 8532), (Sat.Literal.pos 8533)] :=
    ready 7282 (by decide) v hv
  exact satisfied (_h 527 (by decide)) missing

theorem unit11641_489    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 530) : v.neg (polarity11641 530) := by
  have exactPolarity : polarity11641 530 = (Sat.Literal.neg 8534) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.pos 8534)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 8533), (Sat.Literal.pos 8534)] :=
    ready 7283 (by decide) v hv
  exact satisfied (_h 529 (by decide)) missing

theorem unit11641_490    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 531) : v.neg (polarity11641 531) := by
  have exactPolarity : polarity11641 531 = (Sat.Literal.neg 8535) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.pos 8535)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 8534), (Sat.Literal.pos 8535)] :=
    ready 7284 (by decide) v hv
  exact satisfied (_h 530 (by decide)) missing

theorem unit11641_491    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 532) : v.neg (polarity11641 532) := by
  have exactPolarity : polarity11641 532 = (Sat.Literal.neg 8536) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.pos 8536)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 8535), (Sat.Literal.pos 8536)] :=
    ready 7285 (by decide) v hv
  exact satisfied (_h 531 (by decide)) missing

theorem unit11641_492    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 533) : v.neg (polarity11641 533) := by
  have exactPolarity : polarity11641 533 = (Sat.Literal.neg 8537) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.pos 8537)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 8536), (Sat.Literal.pos 8537)] :=
    ready 7286 (by decide) v hv
  exact satisfied (_h 532 (by decide)) missing

theorem unit11641_493    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 534) : v.neg (polarity11641 534) := by
  have exactPolarity : polarity11641 534 = (Sat.Literal.neg 8538) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.pos 8538)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 8537), (Sat.Literal.pos 8538)] :=
    ready 7287 (by decide) v hv
  exact satisfied (_h 533 (by decide)) missing

theorem segment11641_488_494    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base) :
    NegBelow v polarity11641 529 → NegBelow v polarity11641 535 :=
  ((((extendNeg (unit11641_493 base v ready hv)) ∘ (extendNeg (unit11641_492 base v ready hv))) ∘ (extendNeg (unit11641_491 base v ready hv))) ∘ (((extendNeg (unit11641_490 base v ready hv)) ∘ (extendNeg (unit11641_489 base v ready hv))) ∘ (extendNeg (unit11641_488 base v ready hv))))

end Euler.C14.PolarityDraft
