import C14Row11641PolarityDataDraft
namespace Euler.C14.PolarityDraft
open Euler.C14.IndexedDraft
open Euler.C14.Production (rowAt)
set_option maxRecDepth 18000
set_option maxHeartbeats 2400000
theorem unit11641_456    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 497) : v.neg (polarity11641 497) := by
  have exactPolarity : polarity11641 497 = (Sat.Literal.neg 3988) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.pos 3988)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 3987), (Sat.Literal.pos 3988)] :=
    ready 3561 (by decide) v hv
  exact satisfied (_h 493 (by decide)) missing

theorem unit11641_457    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 498) : v.neg (polarity11641 498) := by
  have exactPolarity : polarity11641 498 = (Sat.Literal.pos 1240) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 1240)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 1240), (Sat.Literal.neg 5247)] :=
    ready 1300 (by decide) v hv
  exact satisfied missing (_h 495 (by decide))

theorem unit11641_458    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 499) : v.neg (polarity11641 499) := by
  have exactPolarity : polarity11641 499 = (Sat.Literal.neg 3989) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.pos 3989)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 3988), (Sat.Literal.pos 3989)] :=
    ready 3562 (by decide) v hv
  exact satisfied (_h 497 (by decide)) missing

theorem unit11641_459    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 500) : v.neg (polarity11641 500) := by
  have exactPolarity : polarity11641 500 = (Sat.Literal.pos 1492) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 1492)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 1492), (Sat.Literal.pos 88), (Sat.Literal.pos 160), (Sat.Literal.pos 196), (Sat.Literal.pos 268), (Sat.Literal.pos 304), (Sat.Literal.pos 376), (Sat.Literal.pos 412), (Sat.Literal.pos 448), (Sat.Literal.pos 484), (Sat.Literal.pos 592), (Sat.Literal.pos 628), (Sat.Literal.pos 880), (Sat.Literal.pos 916), (Sat.Literal.pos 952), (Sat.Literal.pos 1024), (Sat.Literal.pos 1060), (Sat.Literal.pos 1096), (Sat.Literal.pos 1132), (Sat.Literal.pos 1168), (Sat.Literal.pos 1240), (Sat.Literal.pos 1276)] :=
    ready 9237 (by decide) v hv
  exact satisfied missing (_h 148 (by decide)) (_h 94 (by decide)) (_h 111 (by decide)) (_h 218 (by decide)) (_h 219 (by decide)) (_h 220 (by decide)) (_h 5 (by decide)) (_h 84 (by decide)) (_h 235 (by decide)) (_h 284 (by decide)) (_h 288 (by decide)) (_h 77 (by decide)) (_h 256 (by decide)) (_h 448 (by decide)) (_h 446 (by decide)) (_h 447 (by decide)) (_h 69 (by decide)) (_h 483 (by decide)) (_h 263 (by decide)) (_h 498 (by decide)) (_h 412 (by decide))

theorem unit11641_460    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 501) : v.neg (polarity11641 501) := by
  have exactPolarity : polarity11641 501 = (Sat.Literal.pos 1252) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 1252)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 1252), (Sat.Literal.neg 3989)] :=
    ready 1400 (by decide) v hv
  exact satisfied missing (_h 499 (by decide))

theorem unit11641_461    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 502) : v.neg (polarity11641 502) := by
  have exactPolarity : polarity11641 502 = (Sat.Literal.neg 3990) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.pos 3990)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 3989), (Sat.Literal.pos 3990)] :=
    ready 3564 (by decide) v hv
  exact satisfied (_h 499 (by decide)) missing

theorem segment11641_456_462    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base) :
    NegBelow v polarity11641 497 → NegBelow v polarity11641 503 :=
  ((((extendNeg (unit11641_461 base v ready hv)) ∘ (extendNeg (unit11641_460 base v ready hv))) ∘ (extendNeg (unit11641_459 base v ready hv))) ∘ (((extendNeg (unit11641_458 base v ready hv)) ∘ (extendNeg (unit11641_457 base v ready hv))) ∘ (extendNeg (unit11641_456 base v ready hv))))

end Euler.C14.PolarityDraft
