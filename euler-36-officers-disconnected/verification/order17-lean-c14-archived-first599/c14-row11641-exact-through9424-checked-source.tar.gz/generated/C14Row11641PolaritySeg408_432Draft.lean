import C14Row11641PolarityDataDraft
namespace Euler.C14.PolarityDraft
open Euler.C14.IndexedDraft
open Euler.C14.Production (rowAt)
set_option maxRecDepth 18000
set_option maxHeartbeats 2400000
theorem unit11641_408    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 449) : v.neg (polarity11641 449) := by
  have exactPolarity : polarity11641 449 = (Sat.Literal.neg 3974) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.pos 3974)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 3973), (Sat.Literal.pos 3974)] :=
    ready 3546 (by decide) v hv
  exact satisfied (_h 433 (by decide)) missing

theorem unit11641_409    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 450) : v.neg (polarity11641 450) := by
  have exactPolarity : polarity11641 450 = (Sat.Literal.neg 5234) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.pos 5234)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 5233), (Sat.Literal.pos 5234)] :=
    ready 4619 (by decide) v hv
  exact satisfied (_h 434 (by decide)) missing

theorem unit11641_410    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 451) : v.neg (polarity11641 451) := by
  have exactPolarity : polarity11641 451 = (Sat.Literal.pos 2621) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 2621)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 2621), (Sat.Literal.pos 2622)] :=
    ready 2342 (by decide) v hv
  exact satisfied missing (_h 436 (by decide))

theorem unit11641_411    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 452) : v.neg (polarity11641 452) := by
  have exactPolarity : polarity11641 452 = (Sat.Literal.pos 1420) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 1420)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 1420), (Sat.Literal.pos 98), (Sat.Literal.pos 99), (Sat.Literal.pos 100), (Sat.Literal.pos 101), (Sat.Literal.pos 312), (Sat.Literal.pos 315), (Sat.Literal.pos 316), (Sat.Literal.pos 317), (Sat.Literal.pos 746), (Sat.Literal.pos 747), (Sat.Literal.pos 748), (Sat.Literal.pos 749), (Sat.Literal.pos 960), (Sat.Literal.pos 962), (Sat.Literal.pos 963), (Sat.Literal.pos 964), (Sat.Literal.pos 965), (Sat.Literal.pos 1176), (Sat.Literal.pos 1178), (Sat.Literal.pos 1179), (Sat.Literal.pos 1180), (Sat.Literal.pos 1181)] :=
    ready 9178 (by decide) v hv
  exact satisfied missing (_h 154 (by decide)) (_h 139 (by decide)) (_h 140 (by decide)) (_h 141 (by decide)) (_h 173 (by decide)) (_h 333 (by decide)) (_h 313 (by decide)) (_h 297 (by decide)) (_h 250 (by decide)) (_h 251 (by decide)) (_h 252 (by decide)) (_h 253 (by decide)) (_h 193 (by decide)) (_h 443 (by decide)) (_h 386 (by decide)) (_h 444 (by decide)) (_h 445 (by decide)) (_h 47 (by decide)) (_h 267 (by decide)) (_h 268 (by decide)) (_h 269 (by decide)) (_h 270 (by decide))

theorem unit11641_412    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 453) : v.neg (polarity11641 453) := by
  have exactPolarity : polarity11641 453 = (Sat.Literal.neg 3975) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.pos 3975)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 3974), (Sat.Literal.pos 3975)] :=
    ready 3547 (by decide) v hv
  exact satisfied (_h 449 (by decide)) missing

theorem unit11641_413    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 454) : v.neg (polarity11641 454) := by
  have exactPolarity : polarity11641 454 = (Sat.Literal.neg 5235) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.pos 5235)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 5234), (Sat.Literal.pos 5235)] :=
    ready 4620 (by decide) v hv
  exact satisfied (_h 450 (by decide)) missing

theorem unit11641_414    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 455) : v.neg (polarity11641 455) := by
  have exactPolarity : polarity11641 455 = (Sat.Literal.pos 2620) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 2620)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 2620), (Sat.Literal.pos 2621)] :=
    ready 2341 (by decide) v hv
  exact satisfied missing (_h 451 (by decide))

theorem unit11641_415    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 456) : v.neg (polarity11641 456) := by
  have exactPolarity : polarity11641 456 = (Sat.Literal.neg 3976) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.pos 3976)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 3975), (Sat.Literal.pos 3976)] :=
    ready 3548 (by decide) v hv
  exact satisfied (_h 453 (by decide)) missing

theorem unit11641_416    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 457) : v.neg (polarity11641 457) := by
  have exactPolarity : polarity11641 457 = (Sat.Literal.neg 5236) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.pos 5236)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 5235), (Sat.Literal.pos 5236)] :=
    ready 4621 (by decide) v hv
  exact satisfied (_h 454 (by decide)) missing

theorem unit11641_417    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 458) : v.neg (polarity11641 458) := by
  have exactPolarity : polarity11641 458 = (Sat.Literal.pos 2619) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 2619)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 2619), (Sat.Literal.pos 2620)] :=
    ready 2340 (by decide) v hv
  exact satisfied missing (_h 455 (by decide))

theorem unit11641_418    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 459) : v.neg (polarity11641 459) := by
  have exactPolarity : polarity11641 459 = (Sat.Literal.neg 3977) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.pos 3977)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 3976), (Sat.Literal.pos 3977)] :=
    ready 3549 (by decide) v hv
  exact satisfied (_h 456 (by decide)) missing

theorem unit11641_419    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 460) : v.neg (polarity11641 460) := by
  have exactPolarity : polarity11641 460 = (Sat.Literal.neg 5237) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.pos 5237)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 5236), (Sat.Literal.pos 5237)] :=
    ready 4622 (by decide) v hv
  exact satisfied (_h 457 (by decide)) missing

theorem unit11641_420    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 461) : v.neg (polarity11641 461) := by
  have exactPolarity : polarity11641 461 = (Sat.Literal.pos 2618) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 2618)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 2618), (Sat.Literal.pos 2619)] :=
    ready 2338 (by decide) v hv
  exact satisfied missing (_h 458 (by decide))

theorem unit11641_421    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 462) : v.neg (polarity11641 462) := by
  have exactPolarity : polarity11641 462 = (Sat.Literal.neg 3978) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.pos 3978)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 3977), (Sat.Literal.pos 3978)] :=
    ready 3550 (by decide) v hv
  exact satisfied (_h 459 (by decide)) missing

theorem unit11641_422    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 463) : v.neg (polarity11641 463) := by
  have exactPolarity : polarity11641 463 = (Sat.Literal.neg 5238) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.pos 5238)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 5237), (Sat.Literal.pos 5238)] :=
    ready 4623 (by decide) v hv
  exact satisfied (_h 460 (by decide)) missing

theorem unit11641_423    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 464) : v.neg (polarity11641 464) := by
  have exactPolarity : polarity11641 464 = (Sat.Literal.pos 1137) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 1137)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 1137), (Sat.Literal.pos 2618)] :=
    ready 735 (by decide) v hv
  exact satisfied missing (_h 461 (by decide))

theorem unit11641_424    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 465) : v.neg (polarity11641 465) := by
  have exactPolarity : polarity11641 465 = (Sat.Literal.pos 2617) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 2617)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 2617), (Sat.Literal.pos 2618)] :=
    ready 2337 (by decide) v hv
  exact satisfied missing (_h 461 (by decide))

theorem unit11641_425    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 466) : v.neg (polarity11641 466) := by
  have exactPolarity : polarity11641 466 = (Sat.Literal.neg 3979) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.pos 3979)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 3978), (Sat.Literal.pos 3979)] :=
    ready 3551 (by decide) v hv
  exact satisfied (_h 462 (by decide)) missing

theorem unit11641_426    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 467) : v.neg (polarity11641 467) := by
  have exactPolarity : polarity11641 467 = (Sat.Literal.neg 5239) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.pos 5239)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 5238), (Sat.Literal.pos 5239)] :=
    ready 4624 (by decide) v hv
  exact satisfied (_h 463 (by decide)) missing

theorem unit11641_427    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 468) : v.neg (polarity11641 468) := by
  have exactPolarity : polarity11641 468 = (Sat.Literal.pos 1136) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 1136)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 1136), (Sat.Literal.pos 2617)] :=
    ready 723 (by decide) v hv
  exact satisfied missing (_h 465 (by decide))

theorem unit11641_428    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 469) : v.neg (polarity11641 469) := by
  have exactPolarity : polarity11641 469 = (Sat.Literal.pos 2616) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 2616)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 2616), (Sat.Literal.pos 2617)] :=
    ready 2336 (by decide) v hv
  exact satisfied missing (_h 465 (by decide))

theorem unit11641_429    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 470) : v.neg (polarity11641 470) := by
  have exactPolarity : polarity11641 470 = (Sat.Literal.neg 3980) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.pos 3980)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 3979), (Sat.Literal.pos 3980)] :=
    ready 3553 (by decide) v hv
  exact satisfied (_h 466 (by decide)) missing

theorem unit11641_430    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 471) : v.neg (polarity11641 471) := by
  have exactPolarity : polarity11641 471 = (Sat.Literal.neg 5240) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.pos 5240)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 5239), (Sat.Literal.pos 5240)] :=
    ready 4626 (by decide) v hv
  exact satisfied (_h 467 (by decide)) missing

theorem unit11641_431    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 472) : v.neg (polarity11641 472) := by
  have exactPolarity : polarity11641 472 = (Sat.Literal.pos 2615) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 2615)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 2615), (Sat.Literal.pos 2616)] :=
    ready 2335 (by decide) v hv
  exact satisfied missing (_h 469 (by decide))

theorem segment11641_408_432    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base) :
    NegBelow v polarity11641 449 → NegBelow v polarity11641 473 :=
  ((((((extendNeg (unit11641_431 base v ready hv)) ∘ (extendNeg (unit11641_430 base v ready hv))) ∘ (extendNeg (unit11641_429 base v ready hv))) ∘ (((extendNeg (unit11641_428 base v ready hv)) ∘ (extendNeg (unit11641_427 base v ready hv))) ∘ (extendNeg (unit11641_426 base v ready hv)))) ∘ ((((extendNeg (unit11641_425 base v ready hv)) ∘ (extendNeg (unit11641_424 base v ready hv))) ∘ (extendNeg (unit11641_423 base v ready hv))) ∘ (((extendNeg (unit11641_422 base v ready hv)) ∘ (extendNeg (unit11641_421 base v ready hv))) ∘ (extendNeg (unit11641_420 base v ready hv))))) ∘ (((((extendNeg (unit11641_419 base v ready hv)) ∘ (extendNeg (unit11641_418 base v ready hv))) ∘ (extendNeg (unit11641_417 base v ready hv))) ∘ (((extendNeg (unit11641_416 base v ready hv)) ∘ (extendNeg (unit11641_415 base v ready hv))) ∘ (extendNeg (unit11641_414 base v ready hv)))) ∘ ((((extendNeg (unit11641_413 base v ready hv)) ∘ (extendNeg (unit11641_412 base v ready hv))) ∘ (extendNeg (unit11641_411 base v ready hv))) ∘ (((extendNeg (unit11641_410 base v ready hv)) ∘ (extendNeg (unit11641_409 base v ready hv))) ∘ (extendNeg (unit11641_408 base v ready hv))))))

end Euler.C14.PolarityDraft
