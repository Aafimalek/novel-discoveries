import C14Row11641PolarityDataDraft
namespace Euler.C14.PolarityDraft
open Euler.C14.IndexedDraft
open Euler.C14.Production (rowAt)
set_option maxRecDepth 18000
set_option maxHeartbeats 2400000
theorem unit11641_120    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 161) : v.neg (polarity11641 161) := by
  have exactPolarity : polarity11641 161 = (Sat.Literal.pos 1335) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 1335)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 1335), (Sat.Literal.pos 92), (Sat.Literal.pos 93), (Sat.Literal.pos 94), (Sat.Literal.pos 95), (Sat.Literal.pos 128), (Sat.Literal.pos 129), (Sat.Literal.pos 130), (Sat.Literal.pos 131), (Sat.Literal.pos 164), (Sat.Literal.pos 165), (Sat.Literal.pos 166), (Sat.Literal.pos 167), (Sat.Literal.pos 200), (Sat.Literal.pos 201), (Sat.Literal.pos 202), (Sat.Literal.pos 203)] :=
    ready 9122 (by decide) v hv
  exact satisfied missing (_h 150 (by decide)) (_h 151 (by decide)) (_h 152 (by decide)) (_h 153 (by decide)) (_h 126 (by decide)) (_h 127 (by decide)) (_h 128 (by decide)) (_h 129 (by decide)) (_h 96 (by decide)) (_h 97 (by decide)) (_h 98 (by decide)) (_h 99 (by decide)) (_h 113 (by decide)) (_h 114 (by decide)) (_h 115 (by decide)) (_h 116 (by decide))

theorem unit11641_121    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 162) : v.neg (polarity11641 162) := by
  have exactPolarity : polarity11641 162 = (Sat.Literal.pos 1336) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 1336)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 1336), (Sat.Literal.pos 98), (Sat.Literal.pos 99), (Sat.Literal.pos 100), (Sat.Literal.pos 101), (Sat.Literal.pos 134), (Sat.Literal.pos 135), (Sat.Literal.pos 136), (Sat.Literal.pos 137), (Sat.Literal.pos 170), (Sat.Literal.pos 171), (Sat.Literal.pos 172), (Sat.Literal.pos 173), (Sat.Literal.pos 206), (Sat.Literal.pos 207), (Sat.Literal.pos 208), (Sat.Literal.pos 209)] :=
    ready 9123 (by decide) v hv
  exact satisfied missing (_h 154 (by decide)) (_h 139 (by decide)) (_h 140 (by decide)) (_h 141 (by decide)) (_h 130 (by decide)) (_h 131 (by decide)) (_h 132 (by decide)) (_h 133 (by decide)) (_h 100 (by decide)) (_h 101 (by decide)) (_h 102 (by decide)) (_h 103 (by decide)) (_h 117 (by decide)) (_h 118 (by decide)) (_h 119 (by decide)) (_h 120 (by decide))

theorem unit11641_122    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 163) : v.neg (polarity11641 163) := by
  have exactPolarity : polarity11641 163 = (Sat.Literal.pos 1338) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 1338)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 1338)] :=
    ready 9292 (by decide) v hv
  exact satisfied missing

theorem unit11641_123    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 164) : v.neg (polarity11641 164) := by
  have exactPolarity : polarity11641 164 = (Sat.Literal.pos 1350) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 1350)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.pos 1338), (Sat.Literal.neg 1350), (Sat.Literal.pos 1356), (Sat.Literal.pos 1362)] :=
    ready 8901 (by decide) v hv
  exact satisfied (_h 163 (by decide)) missing (_h 61 (by decide)) (_h 56 (by decide))

theorem unit11641_124    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 165) : v.neg (polarity11641 165) := by
  have exactPolarity : polarity11641 165 = (Sat.Literal.pos 688) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 688)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 688), (Sat.Literal.pos 1350)] :=
    ready 5928 (by decide) v hv
  exact satisfied missing (_h 164 (by decide))

theorem unit11641_125    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 166) : v.neg (polarity11641 166) := by
  have exactPolarity : polarity11641 166 = (Sat.Literal.pos 796) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 796)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 796), (Sat.Literal.pos 1350)] :=
    ready 6829 (by decide) v hv
  exact satisfied missing (_h 164 (by decide))

theorem unit11641_126    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 167) : v.neg (polarity11641 167) := by
  have exactPolarity : polarity11641 167 = (Sat.Literal.pos 832) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 832)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 832), (Sat.Literal.pos 1350)] :=
    ready 7141 (by decide) v hv
  exact satisfied missing (_h 164 (by decide))

theorem unit11641_127    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 168) : v.neg (polarity11641 168) := by
  have exactPolarity : polarity11641 168 = (Sat.Literal.pos 1374) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 1374)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 1374)] :=
    ready 9295 (by decide) v hv
  exact satisfied missing

theorem unit11641_128    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 169) : v.neg (polarity11641 169) := by
  have exactPolarity : polarity11641 169 = (Sat.Literal.pos 270) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 270)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 270), (Sat.Literal.pos 1374)] :=
    ready 2428 (by decide) v hv
  exact satisfied missing (_h 168 (by decide))

theorem unit11641_129    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 170) : v.neg (polarity11641 170) := by
  have exactPolarity : polarity11641 170 = (Sat.Literal.pos 276) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 276)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 276), (Sat.Literal.pos 1374)] :=
    ready 2498 (by decide) v hv
  exact satisfied missing (_h 168 (by decide))

theorem unit11641_130    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 171) : v.neg (polarity11641 171) := by
  have exactPolarity : polarity11641 171 = (Sat.Literal.pos 282) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 282)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 282), (Sat.Literal.pos 1374)] :=
    ready 2587 (by decide) v hv
  exact satisfied missing (_h 168 (by decide))

theorem unit11641_131    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 172) : v.neg (polarity11641 172) := by
  have exactPolarity : polarity11641 172 = (Sat.Literal.pos 306) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 306)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 306), (Sat.Literal.pos 1374)] :=
    ready 2717 (by decide) v hv
  exact satisfied missing (_h 168 (by decide))

theorem unit11641_132    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 173) : v.neg (polarity11641 173) := by
  have exactPolarity : polarity11641 173 = (Sat.Literal.pos 312) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 312)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 312), (Sat.Literal.pos 1374)] :=
    ready 2752 (by decide) v hv
  exact satisfied missing (_h 168 (by decide))

theorem unit11641_133    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 174) : v.neg (polarity11641 174) := by
  have exactPolarity : polarity11641 174 = (Sat.Literal.pos 318) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 318)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 318), (Sat.Literal.pos 1374)] :=
    ready 2831 (by decide) v hv
  exact satisfied missing (_h 168 (by decide))

theorem unit11641_134    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 175) : v.neg (polarity11641 175) := by
  have exactPolarity : polarity11641 175 = (Sat.Literal.pos 378) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 378)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 378), (Sat.Literal.pos 1374)] :=
    ready 3380 (by decide) v hv
  exact satisfied missing (_h 168 (by decide))

theorem unit11641_135    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 176) : v.neg (polarity11641 176) := by
  have exactPolarity : polarity11641 176 = (Sat.Literal.pos 384) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 384)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 384), (Sat.Literal.pos 1374)] :=
    ready 3418 (by decide) v hv
  exact satisfied missing (_h 168 (by decide))

theorem unit11641_136    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 177) : v.neg (polarity11641 177) := by
  have exactPolarity : polarity11641 177 = (Sat.Literal.pos 390) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 390)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 390), (Sat.Literal.pos 1374)] :=
    ready 3469 (by decide) v hv
  exact satisfied missing (_h 168 (by decide))

theorem unit11641_137    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 178) : v.neg (polarity11641 178) := by
  have exactPolarity : polarity11641 178 = (Sat.Literal.pos 420) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 420)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 420), (Sat.Literal.pos 1374)] :=
    ready 3728 (by decide) v hv
  exact satisfied missing (_h 168 (by decide))

theorem unit11641_138    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 179) : v.neg (polarity11641 179) := by
  have exactPolarity : polarity11641 179 = (Sat.Literal.pos 426) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 426)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 426), (Sat.Literal.pos 1374)] :=
    ready 3761 (by decide) v hv
  exact satisfied missing (_h 168 (by decide))

theorem unit11641_139    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 180) : v.neg (polarity11641 180) := by
  have exactPolarity : polarity11641 180 = (Sat.Literal.pos 1392) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 1392)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 1392)] :=
    ready 9327 (by decide) v hv
  exact satisfied missing

theorem unit11641_140    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 181) : v.neg (polarity11641 181) := by
  have exactPolarity : polarity11641 181 = (Sat.Literal.pos 1014) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 1014)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 1014), (Sat.Literal.pos 1392)] :=
    ready 137 (by decide) v hv
  exact satisfied missing (_h 180 (by decide))

theorem unit11641_141    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 182) : v.neg (polarity11641 182) := by
  have exactPolarity : polarity11641 182 = (Sat.Literal.pos 1026) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 1026)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 1026), (Sat.Literal.pos 1392)] :=
    ready 238 (by decide) v hv
  exact satisfied missing (_h 180 (by decide))

theorem unit11641_142    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 183) : v.neg (polarity11641 183) := by
  have exactPolarity : polarity11641 183 = (Sat.Literal.pos 1032) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 1032)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 1032), (Sat.Literal.pos 1392)] :=
    ready 294 (by decide) v hv
  exact satisfied missing (_h 180 (by decide))

theorem unit11641_143    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 184) : v.neg (polarity11641 184) := by
  have exactPolarity : polarity11641 184 = (Sat.Literal.pos 1038) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 1038)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 1038), (Sat.Literal.pos 1392)] :=
    ready 342 (by decide) v hv
  exact satisfied missing (_h 180 (by decide))

theorem segment11641_120_144    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base) :
    NegBelow v polarity11641 161 → NegBelow v polarity11641 185 :=
  ((((((extendNeg (unit11641_143 base v ready hv)) ∘ (extendNeg (unit11641_142 base v ready hv))) ∘ (extendNeg (unit11641_141 base v ready hv))) ∘ (((extendNeg (unit11641_140 base v ready hv)) ∘ (extendNeg (unit11641_139 base v ready hv))) ∘ (extendNeg (unit11641_138 base v ready hv)))) ∘ ((((extendNeg (unit11641_137 base v ready hv)) ∘ (extendNeg (unit11641_136 base v ready hv))) ∘ (extendNeg (unit11641_135 base v ready hv))) ∘ (((extendNeg (unit11641_134 base v ready hv)) ∘ (extendNeg (unit11641_133 base v ready hv))) ∘ (extendNeg (unit11641_132 base v ready hv))))) ∘ (((((extendNeg (unit11641_131 base v ready hv)) ∘ (extendNeg (unit11641_130 base v ready hv))) ∘ (extendNeg (unit11641_129 base v ready hv))) ∘ (((extendNeg (unit11641_128 base v ready hv)) ∘ (extendNeg (unit11641_127 base v ready hv))) ∘ (extendNeg (unit11641_126 base v ready hv)))) ∘ ((((extendNeg (unit11641_125 base v ready hv)) ∘ (extendNeg (unit11641_124 base v ready hv))) ∘ (extendNeg (unit11641_123 base v ready hv))) ∘ (((extendNeg (unit11641_122 base v ready hv)) ∘ (extendNeg (unit11641_121 base v ready hv))) ∘ (extendNeg (unit11641_120 base v ready hv))))))

end Euler.C14.PolarityDraft
