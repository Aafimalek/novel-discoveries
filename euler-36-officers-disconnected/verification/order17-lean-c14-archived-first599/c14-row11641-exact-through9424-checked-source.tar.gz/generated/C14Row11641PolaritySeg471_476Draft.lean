import C14Row11641PolarityDataDraft
namespace Euler.C14.PolarityDraft
open Euler.C14.IndexedDraft
open Euler.C14.Production (rowAt)
set_option maxRecDepth 18000
set_option maxHeartbeats 2400000
theorem unit11641_471    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 512) : v.neg (polarity11641 512) := by
  have exactPolarity : polarity11641 512 = (Sat.Literal.pos 1239) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 1239)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 1239), (Sat.Literal.pos 1364)] :=
    ready 1295 (by decide) v hv
  exact satisfied missing (_h 507 (by decide))

theorem unit11641_472    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 513) : v.neg (polarity11641 513) := by
  have exactPolarity : polarity11641 513 = (Sat.Literal.pos 1274) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 1274)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 1274), (Sat.Literal.pos 1364)] :=
    ready 1505 (by decide) v hv
  exact satisfied missing (_h 507 (by decide))

theorem unit11641_473    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 514) : v.neg (polarity11641 514) := by
  have exactPolarity : polarity11641 514 = (Sat.Literal.neg 1330) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.pos 1330)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.pos 1300), (Sat.Literal.pos 1306), (Sat.Literal.neg 1312), (Sat.Literal.pos 1318), (Sat.Literal.neg 1324), (Sat.Literal.pos 1330)] :=
    ready 8966 (by decide) v hv
  exact satisfied (_h 91 (by decide)) (_h 21 (by decide)) (_h 509 (by decide)) (_h 26 (by decide)) (_h 508 (by decide)) missing

theorem unit11641_474    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 515) : v.neg (polarity11641 515) := by
  have exactPolarity : polarity11641 515 = (Sat.Literal.pos 1311) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 1311)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.pos 1308), (Sat.Literal.pos 1309), (Sat.Literal.neg 1311), (Sat.Literal.neg 1312), (Sat.Literal.neg 1313)] :=
    ready 8988 (by decide) v hv
  exact satisfied (_h 82 (by decide)) (_h 22 (by decide)) missing (_h 509 (by decide)) (_h 23 (by decide))

theorem unit11641_475    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 516) : v.neg (polarity11641 516) := by
  have exactPolarity : polarity11641 516 = (Sat.Literal.neg 3993) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.pos 3993)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 3992), (Sat.Literal.pos 3993)] :=
    ready 3567 (by decide) v hv
  exact satisfied (_h 510 (by decide)) missing

theorem segment11641_471_476    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base) :
    NegBelow v polarity11641 512 → NegBelow v polarity11641 517 :=
  ((((extendNeg (unit11641_475 base v ready hv)) ∘ (extendNeg (unit11641_474 base v ready hv))) ∘ (extendNeg (unit11641_473 base v ready hv))) ∘ ((extendNeg (unit11641_472 base v ready hv)) ∘ (extendNeg (unit11641_471 base v ready hv))))

end Euler.C14.PolarityDraft
