import C14Row11641PolarityDataDraft
namespace Euler.C14.PolarityDraft
open Euler.C14.IndexedDraft
open Euler.C14.Production (rowAt)
set_option maxRecDepth 18000
set_option maxHeartbeats 2400000
theorem unit11641_192    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 233) : v.neg (polarity11641 233) := by
  have exactPolarity : polarity11641 233 = (Sat.Literal.pos 389) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 389)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 389), (Sat.Literal.pos 1306)] :=
    ready 3454 (by decide) v hv
  exact satisfied missing (_h 21 (by decide))

theorem unit11641_193    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 234) : v.neg (polarity11641 234) := by
  have exactPolarity : polarity11641 234 = (Sat.Literal.pos 482) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 482)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 482), (Sat.Literal.pos 1309)] :=
    ready 4199 (by decide) v hv
  exact satisfied missing (_h 22 (by decide))

theorem unit11641_194    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 235) : v.neg (polarity11641 235) := by
  have exactPolarity : polarity11641 235 = (Sat.Literal.pos 484) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 484)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 484), (Sat.Literal.pos 1309)] :=
    ready 4226 (by decide) v hv
  exact satisfied missing (_h 22 (by decide))

theorem unit11641_195    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 236) : v.neg (polarity11641 236) := by
  have exactPolarity : polarity11641 236 = (Sat.Literal.pos 488) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 488)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 488), (Sat.Literal.pos 1309)] :=
    ready 4266 (by decide) v hv
  exact satisfied missing (_h 22 (by decide))

theorem unit11641_196    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 237) : v.neg (polarity11641 237) := by
  have exactPolarity : polarity11641 237 = (Sat.Literal.pos 490) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 490)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 490), (Sat.Literal.pos 1309)] :=
    ready 4289 (by decide) v hv
  exact satisfied missing (_h 22 (by decide))

theorem unit11641_197    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 238) : v.neg (polarity11641 238) := by
  have exactPolarity : polarity11641 238 = (Sat.Literal.pos 494) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 494)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 494), (Sat.Literal.pos 1309)] :=
    ready 4327 (by decide) v hv
  exact satisfied missing (_h 22 (by decide))

theorem unit11641_198    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 239) : v.neg (polarity11641 239) := by
  have exactPolarity : polarity11641 239 = (Sat.Literal.pos 495) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 495)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 495), (Sat.Literal.pos 1309)] :=
    ready 4345 (by decide) v hv
  exact satisfied missing (_h 22 (by decide))

theorem unit11641_199    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 240) : v.neg (polarity11641 240) := by
  have exactPolarity : polarity11641 240 = (Sat.Literal.pos 496) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 496)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 496), (Sat.Literal.pos 1309)] :=
    ready 4365 (by decide) v hv
  exact satisfied missing (_h 22 (by decide))

theorem unit11641_200    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 241) : v.neg (polarity11641 241) := by
  have exactPolarity : polarity11641 241 = (Sat.Literal.pos 497) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 497)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 497), (Sat.Literal.pos 1309)] :=
    ready 4383 (by decide) v hv
  exact satisfied missing (_h 22 (by decide))

theorem unit11641_201    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 242) : v.neg (polarity11641 242) := by
  have exactPolarity : polarity11641 242 = (Sat.Literal.pos 500) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 500)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 500), (Sat.Literal.pos 1309)] :=
    ready 4421 (by decide) v hv
  exact satisfied missing (_h 22 (by decide))

theorem unit11641_202    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 243) : v.neg (polarity11641 243) := by
  have exactPolarity : polarity11641 243 = (Sat.Literal.pos 503) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 503)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 503), (Sat.Literal.pos 1309)] :=
    ready 4477 (by decide) v hv
  exact satisfied missing (_h 22 (by decide))

theorem unit11641_203    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 244) : v.neg (polarity11641 244) := by
  have exactPolarity : polarity11641 244 = (Sat.Literal.neg 1349) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.pos 1349)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.pos 1309), (Sat.Literal.pos 1349), (Sat.Literal.pos 1380), (Sat.Literal.pos 1415), (Sat.Literal.pos 1446), (Sat.Literal.pos 1506)] :=
    ready 8283 (by decide) v hv
  exact satisfied (_h 22 (by decide)) missing (_h 195 (by decide)) (_h 39 (by decide)) (_h 207 (by decide)) (_h 209 (by decide))

theorem unit11641_204    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 245) : v.neg (polarity11641 245) := by
  have exactPolarity : polarity11641 245 = (Sat.Literal.pos 729) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 729)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 729), (Sat.Literal.pos 1316)] :=
    ready 6327 (by decide) v hv
  exact satisfied missing (_h 25 (by decide))

theorem unit11641_205    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 246) : v.neg (polarity11641 246) := by
  have exactPolarity : polarity11641 246 = (Sat.Literal.pos 730) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 730)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 730), (Sat.Literal.pos 1316)] :=
    ready 6339 (by decide) v hv
  exact satisfied missing (_h 25 (by decide))

theorem unit11641_206    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 247) : v.neg (polarity11641 247) := by
  have exactPolarity : polarity11641 247 = (Sat.Literal.pos 731) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 731)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 731), (Sat.Literal.pos 1316)] :=
    ready 6350 (by decide) v hv
  exact satisfied missing (_h 25 (by decide))

theorem unit11641_207    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 248) : v.neg (polarity11641 248) := by
  have exactPolarity : polarity11641 248 = (Sat.Literal.pos 740) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 740)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 740), (Sat.Literal.pos 1316)] :=
    ready 6410 (by decide) v hv
  exact satisfied missing (_h 25 (by decide))

theorem unit11641_208    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 249) : v.neg (polarity11641 249) := by
  have exactPolarity : polarity11641 249 = (Sat.Literal.pos 742) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 742)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 742), (Sat.Literal.pos 1316)] :=
    ready 6433 (by decide) v hv
  exact satisfied missing (_h 25 (by decide))

theorem unit11641_209    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 250) : v.neg (polarity11641 250) := by
  have exactPolarity : polarity11641 250 = (Sat.Literal.pos 746) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 746)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 746), (Sat.Literal.pos 1316)] :=
    ready 6456 (by decide) v hv
  exact satisfied missing (_h 25 (by decide))

theorem unit11641_210    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 251) : v.neg (polarity11641 251) := by
  have exactPolarity : polarity11641 251 = (Sat.Literal.pos 747) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 747)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 747), (Sat.Literal.pos 1316)] :=
    ready 6470 (by decide) v hv
  exact satisfied missing (_h 25 (by decide))

theorem unit11641_211    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 252) : v.neg (polarity11641 252) := by
  have exactPolarity : polarity11641 252 = (Sat.Literal.pos 748) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 748)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 748), (Sat.Literal.pos 1316)] :=
    ready 6492 (by decide) v hv
  exact satisfied missing (_h 25 (by decide))

theorem unit11641_212    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 253) : v.neg (polarity11641 253) := by
  have exactPolarity : polarity11641 253 = (Sat.Literal.pos 749) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 749)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 749), (Sat.Literal.pos 1316)] :=
    ready 6510 (by decide) v hv
  exact satisfied missing (_h 25 (by decide))

theorem unit11641_213    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 254) : v.neg (polarity11641 254) := by
  have exactPolarity : polarity11641 254 = (Sat.Literal.pos 752) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 752)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 752), (Sat.Literal.pos 1316)] :=
    ready 6539 (by decide) v hv
  exact satisfied missing (_h 25 (by decide))

theorem unit11641_214    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 255) : v.neg (polarity11641 255) := by
  have exactPolarity : polarity11641 255 = (Sat.Literal.pos 754) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 754)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 754), (Sat.Literal.pos 1316)] :=
    ready 6568 (by decide) v hv
  exact satisfied missing (_h 25 (by decide))

theorem unit11641_215    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 256) : v.neg (polarity11641 256) := by
  have exactPolarity : polarity11641 256 = (Sat.Literal.pos 916) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 916)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 916), (Sat.Literal.pos 1321)] :=
    ready 7734 (by decide) v hv
  exact satisfied missing (_h 27 (by decide))

theorem segment11641_192_216    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base) :
    NegBelow v polarity11641 233 → NegBelow v polarity11641 257 :=
  ((((((extendNeg (unit11641_215 base v ready hv)) ∘ (extendNeg (unit11641_214 base v ready hv))) ∘ (extendNeg (unit11641_213 base v ready hv))) ∘ (((extendNeg (unit11641_212 base v ready hv)) ∘ (extendNeg (unit11641_211 base v ready hv))) ∘ (extendNeg (unit11641_210 base v ready hv)))) ∘ ((((extendNeg (unit11641_209 base v ready hv)) ∘ (extendNeg (unit11641_208 base v ready hv))) ∘ (extendNeg (unit11641_207 base v ready hv))) ∘ (((extendNeg (unit11641_206 base v ready hv)) ∘ (extendNeg (unit11641_205 base v ready hv))) ∘ (extendNeg (unit11641_204 base v ready hv))))) ∘ (((((extendNeg (unit11641_203 base v ready hv)) ∘ (extendNeg (unit11641_202 base v ready hv))) ∘ (extendNeg (unit11641_201 base v ready hv))) ∘ (((extendNeg (unit11641_200 base v ready hv)) ∘ (extendNeg (unit11641_199 base v ready hv))) ∘ (extendNeg (unit11641_198 base v ready hv)))) ∘ ((((extendNeg (unit11641_197 base v ready hv)) ∘ (extendNeg (unit11641_196 base v ready hv))) ∘ (extendNeg (unit11641_195 base v ready hv))) ∘ (((extendNeg (unit11641_194 base v ready hv)) ∘ (extendNeg (unit11641_193 base v ready hv))) ∘ (extendNeg (unit11641_192 base v ready hv))))))

end Euler.C14.PolarityDraft
