import C14Row11641PolarityDataDraft
namespace Euler.C14.PolarityDraft
open Euler.C14.IndexedDraft
open Euler.C14.Production (rowAt)
set_option maxRecDepth 18000
set_option maxHeartbeats 2400000
theorem unit11641_144    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 185) : v.neg (polarity11641 185) := by
  have exactPolarity : polarity11641 185 = (Sat.Literal.pos 1050) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 1050)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 1050), (Sat.Literal.pos 1392)] :=
    ready 409 (by decide) v hv
  exact satisfied missing (_h 180 (by decide))

theorem unit11641_145    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 186) : v.neg (polarity11641 186) := by
  have exactPolarity : polarity11641 186 = (Sat.Literal.pos 1068) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 1068)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 1068), (Sat.Literal.pos 1392)] :=
    ready 543 (by decide) v hv
  exact satisfied missing (_h 180 (by decide))

theorem unit11641_146    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 187) : v.neg (polarity11641 187) := by
  have exactPolarity : polarity11641 187 = (Sat.Literal.pos 1074) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 1074)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 1074), (Sat.Literal.pos 1392)] :=
    ready 583 (by decide) v hv
  exact satisfied missing (_h 180 (by decide))

theorem unit11641_147    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 188) : v.neg (polarity11641 188) := by
  have exactPolarity : polarity11641 188 = (Sat.Literal.pos 918) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 918)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 918), (Sat.Literal.pos 1392)] :=
    ready 7744 (by decide) v hv
  exact satisfied missing (_h 180 (by decide))

theorem unit11641_148    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 189) : v.neg (polarity11641 189) := by
  have exactPolarity : polarity11641 189 = (Sat.Literal.pos 924) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 924)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 924), (Sat.Literal.pos 1392)] :=
    ready 7791 (by decide) v hv
  exact satisfied missing (_h 180 (by decide))

theorem unit11641_149    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 190) : v.neg (polarity11641 190) := by
  have exactPolarity : polarity11641 190 = (Sat.Literal.pos 930) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 930)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 930), (Sat.Literal.pos 1392)] :=
    ready 7832 (by decide) v hv
  exact satisfied missing (_h 180 (by decide))

theorem unit11641_150    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 191) : v.neg (polarity11641 191) := by
  have exactPolarity : polarity11641 191 = (Sat.Literal.pos 942) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 942)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 942), (Sat.Literal.pos 1392)] :=
    ready 7862 (by decide) v hv
  exact satisfied missing (_h 180 (by decide))

theorem unit11641_151    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 192) : v.neg (polarity11641 192) := by
  have exactPolarity : polarity11641 192 = (Sat.Literal.pos 954) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 954)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 954), (Sat.Literal.pos 1392)] :=
    ready 7917 (by decide) v hv
  exact satisfied missing (_h 180 (by decide))

theorem unit11641_152    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 193) : v.neg (polarity11641 193) := by
  have exactPolarity : polarity11641 193 = (Sat.Literal.pos 960) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 960)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 960), (Sat.Literal.pos 1392)] :=
    ready 7963 (by decide) v hv
  exact satisfied missing (_h 180 (by decide))

theorem unit11641_153    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 194) : v.neg (polarity11641 194) := by
  have exactPolarity : polarity11641 194 = (Sat.Literal.pos 966) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 966)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 966), (Sat.Literal.pos 1392)] :=
    ready 8000 (by decide) v hv
  exact satisfied missing (_h 180 (by decide))

theorem unit11641_154    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 195) : v.neg (polarity11641 195) := by
  have exactPolarity : polarity11641 195 = (Sat.Literal.pos 1380) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 1380)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 1380), (Sat.Literal.pos 1392)] :=
    ready 9263 (by decide) v hv
  exact satisfied missing (_h 180 (by decide))

theorem unit11641_155    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 196) : v.neg (polarity11641 196) := by
  have exactPolarity : polarity11641 196 = (Sat.Literal.pos 1452) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 1452)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 1452), (Sat.Literal.pos 306), (Sat.Literal.pos 312), (Sat.Literal.pos 318), (Sat.Literal.pos 942), (Sat.Literal.pos 954), (Sat.Literal.pos 960), (Sat.Literal.pos 966), (Sat.Literal.pos 1158), (Sat.Literal.pos 1170), (Sat.Literal.pos 1176), (Sat.Literal.pos 1182)] :=
    ready 9206 (by decide) v hv
  exact satisfied missing (_h 172 (by decide)) (_h 173 (by decide)) (_h 174 (by decide)) (_h 191 (by decide)) (_h 192 (by decide)) (_h 193 (by decide)) (_h 194 (by decide)) (_h 45 (by decide)) (_h 46 (by decide)) (_h 47 (by decide)) (_h 48 (by decide))

theorem unit11641_156    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 197) : v.neg (polarity11641 197) := by
  have exactPolarity : polarity11641 197 = (Sat.Literal.pos 486) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 486)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 486), (Sat.Literal.pos 1380)] :=
    ready 4260 (by decide) v hv
  exact satisfied missing (_h 195 (by decide))

theorem unit11641_157    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 198) : v.neg (polarity11641 198) := by
  have exactPolarity : polarity11641 198 = (Sat.Literal.pos 492) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 492)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 492), (Sat.Literal.pos 1380)] :=
    ready 4312 (by decide) v hv
  exact satisfied missing (_h 195 (by decide))

theorem unit11641_158    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 199) : v.neg (polarity11641 199) := by
  have exactPolarity : polarity11641 199 = (Sat.Literal.pos 498) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 498)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 498), (Sat.Literal.pos 1380)] :=
    ready 4395 (by decide) v hv
  exact satisfied missing (_h 195 (by decide))

theorem unit11641_159    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 200) : v.neg (polarity11641 200) := by
  have exactPolarity : polarity11641 200 = (Sat.Literal.pos 582) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 582)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 582), (Sat.Literal.pos 1380)] :=
    ready 5103 (by decide) v hv
  exact satisfied missing (_h 195 (by decide))

theorem unit11641_160    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 201) : v.neg (polarity11641 201) := by
  have exactPolarity : polarity11641 201 = (Sat.Literal.pos 594) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 594)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 594), (Sat.Literal.pos 1380)] :=
    ready 5176 (by decide) v hv
  exact satisfied missing (_h 195 (by decide))

theorem unit11641_161    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 202) : v.neg (polarity11641 202) := by
  have exactPolarity : polarity11641 202 = (Sat.Literal.pos 600) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 600)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 600), (Sat.Literal.pos 1380)] :=
    ready 5238 (by decide) v hv
  exact satisfied missing (_h 195 (by decide))

theorem unit11641_162    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 203) : v.neg (polarity11641 203) := by
  have exactPolarity : polarity11641 203 = (Sat.Literal.pos 606) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 606)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 606), (Sat.Literal.pos 1380)] :=
    ready 5301 (by decide) v hv
  exact satisfied missing (_h 195 (by decide))

theorem unit11641_163    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 204) : v.neg (polarity11641 204) := by
  have exactPolarity : polarity11641 204 = (Sat.Literal.pos 618) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 618)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 618), (Sat.Literal.pos 1380)] :=
    ready 5399 (by decide) v hv
  exact satisfied missing (_h 195 (by decide))

theorem unit11641_164    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 205) : v.neg (polarity11641 205) := by
  have exactPolarity : polarity11641 205 = (Sat.Literal.pos 636) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 636)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 636), (Sat.Literal.pos 1380)] :=
    ready 5591 (by decide) v hv
  exact satisfied missing (_h 195 (by decide))

theorem unit11641_165    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 206) : v.neg (polarity11641 206) := by
  have exactPolarity : polarity11641 206 = (Sat.Literal.pos 642) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 642)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 642), (Sat.Literal.pos 1380)] :=
    ready 5639 (by decide) v hv
  exact satisfied missing (_h 195 (by decide))

theorem unit11641_166    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 207) : v.neg (polarity11641 207) := by
  have exactPolarity : polarity11641 207 = (Sat.Literal.pos 1446) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 1446)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 1446), (Sat.Literal.pos 270), (Sat.Literal.pos 276), (Sat.Literal.pos 282), (Sat.Literal.pos 486), (Sat.Literal.pos 492), (Sat.Literal.pos 498), (Sat.Literal.pos 918), (Sat.Literal.pos 924), (Sat.Literal.pos 930), (Sat.Literal.pos 1134), (Sat.Literal.pos 1140), (Sat.Literal.pos 1146)] :=
    ready 9201 (by decide) v hv
  exact satisfied missing (_h 169 (by decide)) (_h 170 (by decide)) (_h 171 (by decide)) (_h 197 (by decide)) (_h 198 (by decide)) (_h 199 (by decide)) (_h 188 (by decide)) (_h 189 (by decide)) (_h 190 (by decide)) (_h 42 (by decide)) (_h 43 (by decide)) (_h 44 (by decide))

theorem unit11641_167    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 208) : v.neg (polarity11641 208) := by
  have exactPolarity : polarity11641 208 = (Sat.Literal.pos 1500) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 1500)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 1500), (Sat.Literal.pos 276), (Sat.Literal.pos 312), (Sat.Literal.pos 384), (Sat.Literal.pos 420), (Sat.Literal.pos 492), (Sat.Literal.pos 600), (Sat.Literal.pos 636), (Sat.Literal.pos 924), (Sat.Literal.pos 960), (Sat.Literal.pos 1032), (Sat.Literal.pos 1068), (Sat.Literal.pos 1140), (Sat.Literal.pos 1176), (Sat.Literal.pos 1248), (Sat.Literal.pos 1284)] :=
    ready 9244 (by decide) v hv
  exact satisfied missing (_h 170 (by decide)) (_h 173 (by decide)) (_h 176 (by decide)) (_h 178 (by decide)) (_h 198 (by decide)) (_h 202 (by decide)) (_h 205 (by decide)) (_h 189 (by decide)) (_h 193 (by decide)) (_h 183 (by decide)) (_h 186 (by decide)) (_h 43 (by decide)) (_h 47 (by decide)) (_h 51 (by decide)) (_h 54 (by decide))

theorem segment11641_144_168    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base) :
    NegBelow v polarity11641 185 → NegBelow v polarity11641 209 :=
  ((((((extendNeg (unit11641_167 base v ready hv)) ∘ (extendNeg (unit11641_166 base v ready hv))) ∘ (extendNeg (unit11641_165 base v ready hv))) ∘ (((extendNeg (unit11641_164 base v ready hv)) ∘ (extendNeg (unit11641_163 base v ready hv))) ∘ (extendNeg (unit11641_162 base v ready hv)))) ∘ ((((extendNeg (unit11641_161 base v ready hv)) ∘ (extendNeg (unit11641_160 base v ready hv))) ∘ (extendNeg (unit11641_159 base v ready hv))) ∘ (((extendNeg (unit11641_158 base v ready hv)) ∘ (extendNeg (unit11641_157 base v ready hv))) ∘ (extendNeg (unit11641_156 base v ready hv))))) ∘ (((((extendNeg (unit11641_155 base v ready hv)) ∘ (extendNeg (unit11641_154 base v ready hv))) ∘ (extendNeg (unit11641_153 base v ready hv))) ∘ (((extendNeg (unit11641_152 base v ready hv)) ∘ (extendNeg (unit11641_151 base v ready hv))) ∘ (extendNeg (unit11641_150 base v ready hv)))) ∘ ((((extendNeg (unit11641_149 base v ready hv)) ∘ (extendNeg (unit11641_148 base v ready hv))) ∘ (extendNeg (unit11641_147 base v ready hv))) ∘ (((extendNeg (unit11641_146 base v ready hv)) ∘ (extendNeg (unit11641_145 base v ready hv))) ∘ (extendNeg (unit11641_144 base v ready hv))))))

end Euler.C14.PolarityDraft
