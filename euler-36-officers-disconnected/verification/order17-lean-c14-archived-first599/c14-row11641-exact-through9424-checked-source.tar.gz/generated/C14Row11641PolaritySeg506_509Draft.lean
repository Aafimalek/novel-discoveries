import C14Row11641PolarityDataDraft
namespace Euler.C14.PolarityDraft
open Euler.C14.IndexedDraft
open Euler.C14.Production (rowAt)
set_option maxRecDepth 18000
set_option maxHeartbeats 2400000
theorem unit11641_506    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 547) : v.neg (polarity11641 547) := by
  have exactPolarity : polarity11641 547 = (Sat.Literal.pos 1394) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 1394)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.pos 1370), (Sat.Literal.neg 1382), (Sat.Literal.neg 1388), (Sat.Literal.neg 1394), (Sat.Literal.pos 1400)] :=
    ready 9046 (by decide) v hv
  exact satisfied (_h 156 (by decide)) (_h 517 (by decide)) (_h 524 (by decide)) missing (_h 546 (by decide))

theorem unit11641_507    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 548) : v.neg (polarity11641 548) := by
  have exactPolarity : polarity11641 548 = (Sat.Literal.pos 950) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 950)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 950), (Sat.Literal.pos 1394)] :=
    ready 7885 (by decide) v hv
  exact satisfied missing (_h 547 (by decide))

theorem unit11641_508    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base)
    (_h : NegBelow v polarity11641 549) : v.neg (polarity11641 549) := by
  have exactPolarity : polarity11641 549 = (Sat.Literal.pos 968) := rfl
  rw [exactPolarity]
  apply forceComplement v (Sat.Literal.neg 968)
  intro missing
  have satisfied : v.satisfies [(Sat.Literal.neg 968), (Sat.Literal.pos 1394)] :=
    ready 8005 (by decide) v hv
  exact satisfied missing (_h 547 (by decide))

theorem segment11641_506_509    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt 9423) (hv : v.satisfies_fmla base) :
    NegBelow v polarity11641 547 → NegBelow v polarity11641 550 :=
  (((extendNeg (unit11641_508 base v ready hv)) ∘ (extendNeg (unit11641_507 base v ready hv))) ∘ (extendNeg (unit11641_506 base v ready hv)))

end Euler.C14.PolarityDraft
