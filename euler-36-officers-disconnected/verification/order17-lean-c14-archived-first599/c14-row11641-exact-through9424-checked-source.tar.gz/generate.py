#!/usr/bin/env python3
"""Stage ordinary kernel-checkable straight-line RUP polarity segments; no Lean."""
import argparse,gzip,json,hashlib
from pathlib import Path
p=argparse.ArgumentParser()
p.add_argument('cnf',type=Path);p.add_argument('lrat',type=Path)
p.add_argument('out',type=Path);p.add_argument('--slot',type=int,default=9423)
a=p.parse_args()
a.out.mkdir(exist_ok=True,parents=True)
core=a.cnf.read_bytes(); trace=a.lrat.read_bytes()
sha=lambda data:hashlib.sha256(data).hexdigest()
assert sha(core)=='1250abf3c7bab4709e3c5d22c4c57b0beb833052bf308092690668e7346ceb50'
assert sha(trace)=='bc70268e380895a051d8a6c2b354a3af0dd39318d2e4595b321563d85257b101'
head,*lines=core.splitlines()
assert head.split()==[b'p',b'cnf',b'10646',b'8825'] and len(lines)==8825
rows=[list(map(int,x.split()))[:-1] for x in lines]
ids={i+1:i for i in range(len(rows))}
live=set(ids); target=None; begin=0
for ln in trace.splitlines(keepends=True):
 end=begin+len(ln);tokens=ln.split()
 if tokens[1]==b'd':
  dd=list(map(int,tokens[2:])); assert dd[-1]==0 and set(dd[:-1])<=live
  live.difference_update(dd[:-1])
 else:
  t=list(map(int,tokens));zero=t.index(0)
  i=t[0]; cl=t[1:zero]; hints=t[zero+1:-1]
  assert i not in ids and t[-1]==0 and all(h in live for h in hints)
  if len(rows)==a.slot:
   target=(i,cl,hints,begin,end);break
  ids[i]=len(rows);rows.append(cl);live.add(i)
 begin=end
assert target is not None
raw,cl,hs,begin,end=target
assert (raw,len(cl),len(hs))==(11641,41,510)
def lit(i):return f'(Sat.Literal.{"neg" if i<0 else "pos"} {abs(i)-1})'
def lc(xs):return '['+', '.join(map(lit,xs))+']'
def emit(n,s):(a.out/(n+'.lean')).write_text(s.rstrip()+'\n')
prefix='''namespace Euler.C14.PolarityDraft
open Euler.C14.IndexedDraft
open Euler.C14.Production (rowAt)
set_option maxRecDepth 18000
set_option maxHeartbeats 2400000
'''
assign=list(cl);known={i:k for k,i in enumerate(assign)}
units=[]; used={}
for j,h in enumerate(hs):
 slot=ids[h]; src=rows[slot]
 unk=[l for l in src if l not in known]
 assert len(unk)==(0 if j+1==len(hs) else 1)
 idxs=[known.get(l) for l in src]
 assert all(k is None or k<len(assign) for k in idxs)
 units.append(dict(hint_index=j,original_id=h,earlier_slot=slot,
                   bound=len(assign),clause=src,known_indexes=idxs,unit=unk[0] if unk else None))
 if unk:
  assign.append(-unk[0])
  known[-unk[0]]=len(assign)-1
assert len(assign)==550
emit('C14Row11641PolarityDataDraft','import C14PolarityGenericDraft\n'+prefix+
  f'def target11641 : List Sat.Literal := {lc(cl)}\n'+
  'def propagated11641 : Array Sat.Literal := #[\n  '+
  ',\n  '.join(map(lit,assign[len(cl):]))+'\n]\n'+
  f'''def polarity11641 (i : Nat) : Sat.Literal :=
  if i < {len(cl)} then target11641[i]?.getD (Sat.Literal.pos 0)
  else propagated11641[i - {len(cl)}]?.getD (Sat.Literal.pos 0)

theorem actualTarget11641 : rowAt {a.slot} = target11641 := rfl

theorem init11641 (v : Sat.Valuation) (h : Falsified v target11641) :
    NegBelow v polarity11641 {len(cl)} := by
  intro i hi
  have hlen : target11641.length = {len(cl)} := rfl
  have within : i < target11641.length := hlen.symm ▸ hi
  rw [polarity11641, ite_eq_left hi, List.getElem?_eq_getElem within]
  exact h _ (List.getElem_mem within)

end Euler.C14.PolarityDraft''')
bridge=f'''    (base : Sat.Fmla) (v : Sat.Valuation)
    (ready : GoodBelow base rowAt {a.slot}) (hv : v.satisfies_fmla base)'''
def gen_unit(step):
 j,k=step['hint_index'],step['bound']; z=step['unit']; src=step['clause']
 args=' '.join('missing' if q is None else f'(_h {q} (by decide))' for q in step['known_indexes'])
 lookup=f'''  have satisfied : v.satisfies {lc(src)} :=
    ready {step['earlier_slot']} (by decide) v hv\n'''
 if z is None:
  return f'''theorem close11641{bridge}
    (_h : NegBelow v polarity11641 {k}) : False := by
{lookup}  exact satisfied {args}
'''
 return f'''theorem unit11641_{j}{bridge}
    (_h : NegBelow v polarity11641 {k}) : v.neg (polarity11641 {k}) := by
  have exactPolarity : polarity11641 {k} = {lit(-z)} := rfl
  rw [exactPolarity]
  apply forceComplement v {lit(z)}
  intro missing
{lookup}  exact satisfied {args}
'''
def balanced(ts):
 if len(ts)==1:return ts[0]
 mid=len(ts)//2
 return f'({balanced(ts[mid:])} ∘ {balanced(ts[:mid])})'
segments=[]
kept=[(lo,lo+24) for lo in range(0,456,24)]
def step_proxy(u):
 # Count explicit literal arguments plus additional 64-slot blocks
 # reached by each normalized propagated polarity index.
 return len(u['clause']) + sum(max(0,j-41)//64 for j in u['known_indexes'] if j is not None)
def isolate(u):
 return len(u['clause'])>=30 or step_proxy(u)>=110
late=[]
lo=456
while lo<509:
 hi=lo; cost=0
 while hi<509 and hi-lo<6:
  u=units[hi]; w=step_proxy(u)
  if hi>lo and (isolate(u) or cost+w>150):break
  hi+=1; cost+=w
  if isolate(u):break
 assert hi>lo
 late.append((lo,hi))
 lo=hi
for lo,hi in kept+late:
 mod=f'C14Row11641PolaritySeg{lo:03}_{hi:03}Draft'
 steps=units[lo:hi]
 source='import C14Row11641PolarityDataDraft\n'+prefix
 source+='\n'.join(gen_unit(q) for q in steps)
 comps=[f'(extendNeg (unit11641_{q} base v ready hv))' for q in range(lo,hi)]
 source+=f'''\ntheorem segment11641_{lo}_{hi}{bridge} :
    NegBelow v polarity11641 {41+lo} → NegBelow v polarity11641 {41+hi} :=
  {balanced(comps)}

end Euler.C14.PolarityDraft
'''
 emit(mod,source)
 segments.append(dict(module=mod,lo=lo,hi=hi,theorem=f'segment11641_{lo}_{hi}',
                     premise_literals=sum(len(u['clause']) for u in steps),
                     polarity_index_proxy=sum(step_proxy(u) for u in steps)))
emit('C14Row11641PolarityTerminalDraft','import C14Row11641PolarityDataDraft\n'+prefix+
     gen_unit(units[-1])+'end Euler.C14.PolarityDraft')
lead=''.join('import '+s['module']+'\n' for s in segments)+'import C14Row11641PolarityTerminalDraft\n'
ct=balanced([f"({s['theorem']} base v ready hv)" for s in segments])
emit('C14Row11641PolarityComposeDraft',lead+prefix+f'''
theorem step11641 (base : Sat.Fmla) (ready : GoodBelow base rowAt {a.slot}) :
    base.proof (rowAt {a.slot}) := by
  rw [actualTarget11641]
  intro v hv
  apply satisfies_of_falsified_imp_false
  intro h
  have advance : NegBelow v polarity11641 41 → NegBelow v polarity11641 550 :=
    {ct}
  exact close11641 base v ready hv (advance (init11641 v h))

theorem slice11641 (base : Sat.Fmla) : Slice base rowAt {a.slot} {a.slot+1} :=
  extend (step11641 base)

#print axioms slice11641
end Euler.C14.PolarityDraft''')
# Tiny genuine module: exactly first hint, same production rowAt and prefix; not an asserted full split.
emit('C14Row11641FirstHintDraft','import C14Row11641PolarityDataDraft\n'+prefix+
     gen_unit(units[0]).replace('unit11641_0','firstHint11641')+
     '#print axioms firstHint11641\nend Euler.C14.PolarityDraft')
meta=dict(core_sha256=sha(core),trace_sha256=sha(trace),raw_id=raw,slot=a.slot,
          archived_span=[begin,end],target_literals=cl,hints=len(hs),segments=segments,
          assignments=assign,units=units)
(a.out/'row11641.json').write_text(json.dumps(meta,indent=2)+'\n')
(a.out/'compile-order.txt').write_text('\n'.join(['C14Row11641PolarityDataDraft','C14Row11641FirstHintDraft',
                  *[s['module'] for s in segments],'C14Row11641PolarityTerminalDraft','C14Row11641PolarityComposeDraft'])+'\n')
print('Preserved',len(kept),'old segments and generated',len(late),'late segments plus 1 exact terminal conflict, raw ID',raw)
