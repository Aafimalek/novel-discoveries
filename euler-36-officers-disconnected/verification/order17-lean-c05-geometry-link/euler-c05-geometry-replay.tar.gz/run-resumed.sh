#!/usr/bin/env bash
set -euo pipefail
mkdir -p replay-logs
build () {
  local limit=$1 file=$2 name
  name=$(basename "$file" .lean)
  printf 'Checking %s\n' "$file"
  timeout -k 1s "$limit" "$LEAN_BIN" -j1 -M2500 -o "$name.olean" "$file" 2>&1 |
    tee "replay-logs/$name.log"
  printf '%s exit=0\n' "$name" >> stage-receipts.log
}
build 40s CheckpointAudit.lean
for n in $(seq -w 16 31); do build 25s "C05CoreMembers$n.lean"; done
build 35s C05Linked.lean
build 35s C05ImportAudit.lean
