import ArchiveCoreBlocks

namespace LatinGap.PairEncoding.C05Linked

def codes : List ℕ := [111,1012,2201,3120]

end LatinGap.PairEncoding.C05Linked
