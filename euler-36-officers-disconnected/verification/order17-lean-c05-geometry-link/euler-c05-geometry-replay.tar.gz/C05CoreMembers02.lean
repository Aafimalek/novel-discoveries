import C05RawFactored
import C05Codes

namespace LatinGap.PairEncoding.C05Linked
open Euler.C05RawFactored

theorem chunk_mem08 : ∀ c ∈ chunk08, c ∈ archiveAllUsedCNF codes := by
  unfold chunk08
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 64 135 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 29 28 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 178 120 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 29 29 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 29 121 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 209 123 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 29 30 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 96 36 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 29 129 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 65 129 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 143 111 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 29 32 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 65 32 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 97 36 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 29 132 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 65 132 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 29 33 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 29 135 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 65 135 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 29 34 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 99 36 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 143 120 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 178 123 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 214 123 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 29 35 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 65 35 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 2 36 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 65 140 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 143 123 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 179 123 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 29 36 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 65 36 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 101 36 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 181 126 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 146 126 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 108 135 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 108 138 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 108 140 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 109 126 rfl, ?_⟩
  simp

theorem chunk_mem09 : ∀ c ∈ chunk09, c ∈ archiveAllUsedCNF codes := by
  unfold chunk09
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 109 129 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 180 45 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 109 135 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 109 138 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 109 140 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 192 126 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 30 14 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 146 132 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 30 16 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 30 17 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 30 18 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 144 135 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 37 49 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 73 90 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 30 20 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 146 135 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 30 22 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 30 23 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 30 24 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 144 138 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 30 26 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 146 138 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 30 28 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 30 29 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 36 96 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 30 30 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 144 140 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 30 32 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 146 140 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 30 34 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 30 35 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 30 36 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 150 126 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 181 129 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 66 9 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 36 99 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 66 10 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 66 11 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 66 12 rfl, ?_⟩
  simp

theorem chunk_mem10 : ∀ c ∈ chunk10, c ∈ archiveAllUsedCNF codes := by
  unfold chunk10
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 150 129 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 115 129 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 188 129 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 115 135 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 115 138 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 115 140 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 116 126 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 36 102 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 116 129 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 116 132 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 116 135 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 116 138 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 116 140 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 150 135 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 151 135 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 31 21 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 104 10 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 201 129 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 31 22 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 69 10 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 105 10 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 31 100 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 69 64 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 105 64 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 31 23 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 106 64 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 36 105 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 31 24 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 107 10 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 107 64 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 150 138 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 151 138 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 31 114 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 31 27 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 104 11 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 31 28 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 70 10 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 105 11 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 153 35 rfl, ?_⟩
  simp

theorem chunk_mem11 : ∀ c ∈ chunk11, c ∈ archiveAllUsedCNF codes := by
  unfold chunk11
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 31 118 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 70 64 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 105 67 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 31 29 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 106 67 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 31 30 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 107 11 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 107 67 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 150 140 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 151 140 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 31 132 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 31 33 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 104 12 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 37 90 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 31 34 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 71 10 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 105 12 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 31 136 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 71 64 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 105 70 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 31 138 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 31 35 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 106 70 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 31 140 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 31 36 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 107 12 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 107 70 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 120 126 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 120 129 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 120 132 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 120 135 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 120 138 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 120 140 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 102 14 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 187 45 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 157 129 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 188 132 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 105 75 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 32 10 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 67 16 rfl, ?_⟩
  simp

end LatinGap.PairEncoding.C05Linked
