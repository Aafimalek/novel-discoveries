import gzip,json
from pathlib import Path
src=Path('../euler-c14-whole-trace-static/out')
with gzip.open(src/'exact-cone.json.gz','rt') as f: data=json.load(f)
selected=data['learned'][:24]
selected_ids={r['id'] for r in selected}
used=sorted(set(x for r in selected for x in r['hints'])-selected_ids)
orig=[(i,r) for i,r in data['orig'] if i in set(used)]
assert [i for i,r in orig]==used and len(orig)==135
clauses=[r for i,r in orig]+[r['clause'] for r in selected]
def array(items):return '#['+', '.join(map(str,items))+']'
def lit(x):return ('Sat.Literal.neg ' if x<0 else 'Sat.Literal.pos ')+str(abs(x)-1)
def cl(xs):return '['+', '.join(map(lit,xs))+']'
def branch(a,b):
 if b==a+1:return 'c'+str(a)
 m=(a+b)//2
 return f'(if n < {m} then {branch(a,m)} else {branch(m,b)})'
lines=['import EulerC14IndexedDriver','namespace Euler.C14.IndexedDraft','set_option maxHeartbeats 2000000','set_option maxRecDepth 10000']
lines.extend(f'def c{i} : Sat.Clause := {cl(xs)}' for i,xs in enumerate(clauses))
lines += [f'def rowAt (n : Nat) : Sat.Clause := {branch(0,len(clauses))}',
          'def base : Sat.Fmla := ['+', '.join(f'c{i}' for i in range(len(orig)))+']']
lines += ['indexed_rup base rowAt first24','#['+',\n'.join(f'({i}, {array(xs)})' for i,xs in orig)+']',
          '#['+',\n'.join(f"({r['id']}, {array(r['clause'])}, {array(r['hints'])})" for r in selected)+']',
          '#print axioms first24','end Euler.C14.IndexedDraft','']
Path('EulerC14IndexedPilot.lean').write_text('\n'.join(lines))
