#!/usr/bin/env bash
# Run only with an exclusive Lean slot. The exact prior SAT checker is a dependency.
# Usage: replay.sh prepared-directory basename
set -eo pipefail
BASE=$(cd "$(dirname "$0")" && pwd)
CASE_DIR=$(cd "$1" && pwd)
CASE=$2
cd "$CASE_DIR"
export LEAN_PATH="$CASE_DIR:$BASE:$LEAN_PATH"
test -n "$LEAN_BIN" || LEAN_BIN=lean
test -n "$LEAN_MEMORY_MB" || LEAN_MEMORY_MB=2500
set -u
if [[ ! -f ArchiveCoreBlocks.lean ]]; then cp "$BASE/ArchiveCoreBlocks.lean" .; fi
mkdir -p replay-logs
build () {
  local source=$1 module
  module=$(basename "$source" .lean)
  printf 'Checking %s\n' "$source"
  "$LEAN_BIN" -j1 "-M$LEAN_MEMORY_MB" -o "$module.olean" "$source" 2>&1 |
    tee "replay-logs/$module.log"
}
build ArchiveCoreBlocks.lean
build "$CASE"Codes.lean
build "$CASE"SignedRows.lean
build "$CASE"RawFactored.lean
for file in "$CASE"CoreMembers*.lean; do build "$file"; done
build "$CASE"Linked.lean
build "$CASE"ImportAudit.lean
