"""Optional source-only separation of signed rows from the SAT checker import."""
import argparse
from pathlib import Path
import re
import shutil

p=argparse.ArgumentParser(description=__doc__)
p.add_argument('target',type=Path)
a=p.parse_args()
base=Path(__file__).resolve().parent
target=a.target.resolve()
assert target!=base
target.mkdir(parents=True,exist_ok=False)
for f in base.glob('C09*.lean'):
    shutil.copy2(f,target/f.name)
for f in ('ArchiveCoreBlocks.lean','replay.sh'):
    shutil.copy2(base/f,target/f)
raw=target/'C09RawFactored.lean'
old=raw.read_text()
row_pat=re.compile(r'^def chunk[0-9]+ : List \(List Int\) := \[\n[\s\S]*?^\]\n',re.M)
allrows_pat=re.compile(r'^def rows : List \(List Int\) := [^\n]+\n',re.M)
chunks=row_pat.findall(old)
rows=allrows_pat.findall(old)
assert len(chunks)==128 and len(rows)==1
signed=("import Init\n\nnamespace Euler.C09RawFactored\n\n"
       +"\n".join(chunks+rows)+"\nend Euler.C09RawFactored\n")
(target/'C09SignedRows.lean').write_text(signed)
reduced=allrows_pat.sub('',row_pat.sub('',old))
header='import EulerBatch.C09CoreSorted\n'
assert reduced.startswith(header)
new=reduced.replace(header,header+'import C09SignedRows\n',1)
raw.write_text(new)
assert 'theorem rows_match_checked_core' in new
members=sorted(target.glob('C09CoreMembers*.lean'))
assert len(members)==32
for f in members:
    before=f.read_text()
    assert before.startswith('import C09RawFactored\n')
    f.write_text(before.replace('import C09RawFactored\n','import C09SignedRows\n',1))
link=target/'C09Linked.lean'
link.write_text('import C09RawFactored\n'+link.read_text())
replay=target/'replay.sh'
lines=replay.read_text()
preamble='build "$CASE"RawFactored.lean\n'
assert lines.count(preamble)==1
replay.write_text(lines.replace(preamble,'build "$CASE"SignedRows.lean\n'+preamble))
print('Moved all 128 unchanged signed chunk definitions plus rows into an Init-only module.')
print('Existing geometry proof bodies unchanged; only their import line changed.')
print('SAT equality proof text unchanged; final linkage now imports it directly.')
print('This optional source variant has not been compiled.')
