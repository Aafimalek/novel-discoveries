import ArchiveCoreBlocks

namespace LatinGap.PairEncoding.C09Linked

def codes : List ℕ := [111,1012,1203,2120]

end LatinGap.PairEncoding.C09Linked
