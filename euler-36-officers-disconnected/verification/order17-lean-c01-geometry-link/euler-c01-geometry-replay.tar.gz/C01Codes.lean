import ArchiveCoreBlocks

namespace LatinGap.PairEncoding.C01Linked

def codes : List ℕ := [111,1012,1103,1220]

end LatinGap.PairEncoding.C01Linked
