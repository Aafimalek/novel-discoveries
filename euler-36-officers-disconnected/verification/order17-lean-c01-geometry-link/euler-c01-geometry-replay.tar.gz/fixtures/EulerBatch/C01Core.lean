import EulerBatch.FactoredDriver
namespace Euler.Batch.C01
factored_rup coreUnsat (include_str "cases/01/core.cnf") (include_str "cases/01/core.lrat")
#print axioms coreUnsat
end Euler.Batch.C01
