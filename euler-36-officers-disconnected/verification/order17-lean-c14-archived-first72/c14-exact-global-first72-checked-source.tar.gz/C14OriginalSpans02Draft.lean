import C14OriginalExactArchiveDraft
import C14OriginalGenericDraft
namespace Euler.C14.Production
set_option maxRecDepth 18000
set_option maxHeartbeats 2400000

theorem blockContent16 : originalBlock16 = block16 := rfl
theorem blockSize16 : originalBlock16.size = 128 := rfl
attribute [local irreducible] originalBlock16 block16
theorem originalSpan16 : ProvedSpan archivedGlobalCore rowAt 2048 2176 := by
  intro j hlo hhi
  have p0 : j < 6912 := by omega
  have p1 : j < 3456 := by omega
  have p2 : ¬ j < 1664 := by omega
  have p3 : j < 2560 := by omega
  have p4 : ¬ j < 2048 := by omega
  have p5 : j < 2304 := by omega
  have p6 : j < 2176 := by omega
  rw [rowAt, ite_eq_left p0, ite_eq_left p1, ite_eq_right p2, ite_eq_left p3, ite_eq_right p4, ite_eq_left p5, ite_eq_left p6]
  have hj : j - 2048 < 128 := by omega
  have hk : j - 2048 < originalBlock16.size := blockSize16.symm ▸ hj
  have result : archivedGlobalCore.proof ((originalBlock16[j - 2048]?).getD Sat.Clause.nil) :=
    @originalArrayRow archivedGlobalCore originalBlock16 (j - 2048) originalSubsumes16 hk
  have concrete : archivedGlobalCore.proof ((block16[j - 2048]?).getD Sat.Clause.nil) :=
    @transportArrayProof archivedGlobalCore originalBlock16 block16 (j - 2048) blockContent16 result
  exact concrete

theorem blockContent17 : originalBlock17 = block17 := rfl
theorem blockSize17 : originalBlock17.size = 128 := rfl
attribute [local irreducible] originalBlock17 block17
theorem originalSpan17 : ProvedSpan archivedGlobalCore rowAt 2176 2304 := by
  intro j hlo hhi
  have p0 : j < 6912 := by omega
  have p1 : j < 3456 := by omega
  have p2 : ¬ j < 1664 := by omega
  have p3 : j < 2560 := by omega
  have p4 : ¬ j < 2048 := by omega
  have p5 : j < 2304 := by omega
  have p6 : ¬ j < 2176 := by omega
  rw [rowAt, ite_eq_left p0, ite_eq_left p1, ite_eq_right p2, ite_eq_left p3, ite_eq_right p4, ite_eq_left p5, ite_eq_right p6]
  have hj : j - 2176 < 128 := by omega
  have hk : j - 2176 < originalBlock17.size := blockSize17.symm ▸ hj
  have result : archivedGlobalCore.proof ((originalBlock17[j - 2176]?).getD Sat.Clause.nil) :=
    @originalArrayRow archivedGlobalCore originalBlock17 (j - 2176) originalSubsumes17 hk
  have concrete : archivedGlobalCore.proof ((block17[j - 2176]?).getD Sat.Clause.nil) :=
    @transportArrayProof archivedGlobalCore originalBlock17 block17 (j - 2176) blockContent17 result
  exact concrete

theorem blockContent18 : originalBlock18 = block18 := rfl
theorem blockSize18 : originalBlock18.size = 128 := rfl
attribute [local irreducible] originalBlock18 block18
theorem originalSpan18 : ProvedSpan archivedGlobalCore rowAt 2304 2432 := by
  intro j hlo hhi
  have p0 : j < 6912 := by omega
  have p1 : j < 3456 := by omega
  have p2 : ¬ j < 1664 := by omega
  have p3 : j < 2560 := by omega
  have p4 : ¬ j < 2048 := by omega
  have p5 : ¬ j < 2304 := by omega
  have p6 : j < 2432 := by omega
  rw [rowAt, ite_eq_left p0, ite_eq_left p1, ite_eq_right p2, ite_eq_left p3, ite_eq_right p4, ite_eq_right p5, ite_eq_left p6]
  have hj : j - 2304 < 128 := by omega
  have hk : j - 2304 < originalBlock18.size := blockSize18.symm ▸ hj
  have result : archivedGlobalCore.proof ((originalBlock18[j - 2304]?).getD Sat.Clause.nil) :=
    @originalArrayRow archivedGlobalCore originalBlock18 (j - 2304) originalSubsumes18 hk
  have concrete : archivedGlobalCore.proof ((block18[j - 2304]?).getD Sat.Clause.nil) :=
    @transportArrayProof archivedGlobalCore originalBlock18 block18 (j - 2304) blockContent18 result
  exact concrete

theorem blockContent19 : originalBlock19 = block19 := rfl
theorem blockSize19 : originalBlock19.size = 128 := rfl
attribute [local irreducible] originalBlock19 block19
theorem originalSpan19 : ProvedSpan archivedGlobalCore rowAt 2432 2560 := by
  intro j hlo hhi
  have p0 : j < 6912 := by omega
  have p1 : j < 3456 := by omega
  have p2 : ¬ j < 1664 := by omega
  have p3 : j < 2560 := by omega
  have p4 : ¬ j < 2048 := by omega
  have p5 : ¬ j < 2304 := by omega
  have p6 : ¬ j < 2432 := by omega
  rw [rowAt, ite_eq_left p0, ite_eq_left p1, ite_eq_right p2, ite_eq_left p3, ite_eq_right p4, ite_eq_right p5, ite_eq_right p6]
  have hj : j - 2432 < 128 := by omega
  have hk : j - 2432 < originalBlock19.size := blockSize19.symm ▸ hj
  have result : archivedGlobalCore.proof ((originalBlock19[j - 2432]?).getD Sat.Clause.nil) :=
    @originalArrayRow archivedGlobalCore originalBlock19 (j - 2432) originalSubsumes19 hk
  have concrete : archivedGlobalCore.proof ((block19[j - 2432]?).getD Sat.Clause.nil) :=
    @transportArrayProof archivedGlobalCore originalBlock19 block19 (j - 2432) blockContent19 result
  exact concrete

theorem blockContent20 : originalBlock20 = block20 := rfl
theorem blockSize20 : originalBlock20.size = 128 := rfl
attribute [local irreducible] originalBlock20 block20
theorem originalSpan20 : ProvedSpan archivedGlobalCore rowAt 2560 2688 := by
  intro j hlo hhi
  have p0 : j < 6912 := by omega
  have p1 : j < 3456 := by omega
  have p2 : ¬ j < 1664 := by omega
  have p3 : ¬ j < 2560 := by omega
  have p4 : j < 2944 := by omega
  have p5 : j < 2688 := by omega
  rw [rowAt, ite_eq_left p0, ite_eq_left p1, ite_eq_right p2, ite_eq_right p3, ite_eq_left p4, ite_eq_left p5]
  have hj : j - 2560 < 128 := by omega
  have hk : j - 2560 < originalBlock20.size := blockSize20.symm ▸ hj
  have result : archivedGlobalCore.proof ((originalBlock20[j - 2560]?).getD Sat.Clause.nil) :=
    @originalArrayRow archivedGlobalCore originalBlock20 (j - 2560) originalSubsumes20 hk
  have concrete : archivedGlobalCore.proof ((block20[j - 2560]?).getD Sat.Clause.nil) :=
    @transportArrayProof archivedGlobalCore originalBlock20 block20 (j - 2560) blockContent20 result
  exact concrete

theorem blockContent21 : originalBlock21 = block21 := rfl
theorem blockSize21 : originalBlock21.size = 128 := rfl
attribute [local irreducible] originalBlock21 block21
theorem originalSpan21 : ProvedSpan archivedGlobalCore rowAt 2688 2816 := by
  intro j hlo hhi
  have p0 : j < 6912 := by omega
  have p1 : j < 3456 := by omega
  have p2 : ¬ j < 1664 := by omega
  have p3 : ¬ j < 2560 := by omega
  have p4 : j < 2944 := by omega
  have p5 : ¬ j < 2688 := by omega
  have p6 : j < 2816 := by omega
  rw [rowAt, ite_eq_left p0, ite_eq_left p1, ite_eq_right p2, ite_eq_right p3, ite_eq_left p4, ite_eq_right p5, ite_eq_left p6]
  have hj : j - 2688 < 128 := by omega
  have hk : j - 2688 < originalBlock21.size := blockSize21.symm ▸ hj
  have result : archivedGlobalCore.proof ((originalBlock21[j - 2688]?).getD Sat.Clause.nil) :=
    @originalArrayRow archivedGlobalCore originalBlock21 (j - 2688) originalSubsumes21 hk
  have concrete : archivedGlobalCore.proof ((block21[j - 2688]?).getD Sat.Clause.nil) :=
    @transportArrayProof archivedGlobalCore originalBlock21 block21 (j - 2688) blockContent21 result
  exact concrete

theorem blockContent22 : originalBlock22 = block22 := rfl
theorem blockSize22 : originalBlock22.size = 128 := rfl
attribute [local irreducible] originalBlock22 block22
theorem originalSpan22 : ProvedSpan archivedGlobalCore rowAt 2816 2944 := by
  intro j hlo hhi
  have p0 : j < 6912 := by omega
  have p1 : j < 3456 := by omega
  have p2 : ¬ j < 1664 := by omega
  have p3 : ¬ j < 2560 := by omega
  have p4 : j < 2944 := by omega
  have p5 : ¬ j < 2688 := by omega
  have p6 : ¬ j < 2816 := by omega
  rw [rowAt, ite_eq_left p0, ite_eq_left p1, ite_eq_right p2, ite_eq_right p3, ite_eq_left p4, ite_eq_right p5, ite_eq_right p6]
  have hj : j - 2816 < 128 := by omega
  have hk : j - 2816 < originalBlock22.size := blockSize22.symm ▸ hj
  have result : archivedGlobalCore.proof ((originalBlock22[j - 2816]?).getD Sat.Clause.nil) :=
    @originalArrayRow archivedGlobalCore originalBlock22 (j - 2816) originalSubsumes22 hk
  have concrete : archivedGlobalCore.proof ((block22[j - 2816]?).getD Sat.Clause.nil) :=
    @transportArrayProof archivedGlobalCore originalBlock22 block22 (j - 2816) blockContent22 result
  exact concrete

theorem blockContent23 : originalBlock23 = block23 := rfl
theorem blockSize23 : originalBlock23.size = 128 := rfl
attribute [local irreducible] originalBlock23 block23
theorem originalSpan23 : ProvedSpan archivedGlobalCore rowAt 2944 3072 := by
  intro j hlo hhi
  have p0 : j < 6912 := by omega
  have p1 : j < 3456 := by omega
  have p2 : ¬ j < 1664 := by omega
  have p3 : ¬ j < 2560 := by omega
  have p4 : ¬ j < 2944 := by omega
  have p5 : j < 3200 := by omega
  have p6 : j < 3072 := by omega
  rw [rowAt, ite_eq_left p0, ite_eq_left p1, ite_eq_right p2, ite_eq_right p3, ite_eq_right p4, ite_eq_left p5, ite_eq_left p6]
  have hj : j - 2944 < 128 := by omega
  have hk : j - 2944 < originalBlock23.size := blockSize23.symm ▸ hj
  have result : archivedGlobalCore.proof ((originalBlock23[j - 2944]?).getD Sat.Clause.nil) :=
    @originalArrayRow archivedGlobalCore originalBlock23 (j - 2944) originalSubsumes23 hk
  have concrete : archivedGlobalCore.proof ((block23[j - 2944]?).getD Sat.Clause.nil) :=
    @transportArrayProof archivedGlobalCore originalBlock23 block23 (j - 2944) blockContent23 result
  exact concrete

end Euler.C14.Production
