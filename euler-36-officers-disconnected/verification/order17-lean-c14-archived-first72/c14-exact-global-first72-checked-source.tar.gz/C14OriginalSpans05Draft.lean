import C14OriginalExactArchiveDraft
import C14OriginalGenericDraft
namespace Euler.C14.Production
set_option maxRecDepth 18000
set_option maxHeartbeats 2400000

theorem blockContent40 : originalBlock40 = block40 := rfl
theorem blockSize40 : originalBlock40.size = 128 := rfl
attribute [local irreducible] originalBlock40 block40
theorem originalSpan40 : ProvedSpan archivedGlobalCore rowAt 5120 5248 := by
  intro j hlo hhi
  have p0 : j < 6912 := by omega
  have p1 : ¬ j < 3456 := by omega
  have p2 : ¬ j < 5120 := by omega
  have p3 : j < 6016 := by omega
  have p4 : j < 5504 := by omega
  have p5 : j < 5248 := by omega
  rw [rowAt, ite_eq_left p0, ite_eq_right p1, ite_eq_right p2, ite_eq_left p3, ite_eq_left p4, ite_eq_left p5]
  have hj : j - 5120 < 128 := by omega
  have hk : j - 5120 < originalBlock40.size := blockSize40.symm ▸ hj
  have result : archivedGlobalCore.proof ((originalBlock40[j - 5120]?).getD Sat.Clause.nil) :=
    @originalArrayRow archivedGlobalCore originalBlock40 (j - 5120) originalSubsumes40 hk
  have concrete : archivedGlobalCore.proof ((block40[j - 5120]?).getD Sat.Clause.nil) :=
    @transportArrayProof archivedGlobalCore originalBlock40 block40 (j - 5120) blockContent40 result
  exact concrete

theorem blockContent41 : originalBlock41 = block41 := rfl
theorem blockSize41 : originalBlock41.size = 128 := rfl
attribute [local irreducible] originalBlock41 block41
theorem originalSpan41 : ProvedSpan archivedGlobalCore rowAt 5248 5376 := by
  intro j hlo hhi
  have p0 : j < 6912 := by omega
  have p1 : ¬ j < 3456 := by omega
  have p2 : ¬ j < 5120 := by omega
  have p3 : j < 6016 := by omega
  have p4 : j < 5504 := by omega
  have p5 : ¬ j < 5248 := by omega
  have p6 : j < 5376 := by omega
  rw [rowAt, ite_eq_left p0, ite_eq_right p1, ite_eq_right p2, ite_eq_left p3, ite_eq_left p4, ite_eq_right p5, ite_eq_left p6]
  have hj : j - 5248 < 128 := by omega
  have hk : j - 5248 < originalBlock41.size := blockSize41.symm ▸ hj
  have result : archivedGlobalCore.proof ((originalBlock41[j - 5248]?).getD Sat.Clause.nil) :=
    @originalArrayRow archivedGlobalCore originalBlock41 (j - 5248) originalSubsumes41 hk
  have concrete : archivedGlobalCore.proof ((block41[j - 5248]?).getD Sat.Clause.nil) :=
    @transportArrayProof archivedGlobalCore originalBlock41 block41 (j - 5248) blockContent41 result
  exact concrete

theorem blockContent42 : originalBlock42 = block42 := rfl
theorem blockSize42 : originalBlock42.size = 128 := rfl
attribute [local irreducible] originalBlock42 block42
theorem originalSpan42 : ProvedSpan archivedGlobalCore rowAt 5376 5504 := by
  intro j hlo hhi
  have p0 : j < 6912 := by omega
  have p1 : ¬ j < 3456 := by omega
  have p2 : ¬ j < 5120 := by omega
  have p3 : j < 6016 := by omega
  have p4 : j < 5504 := by omega
  have p5 : ¬ j < 5248 := by omega
  have p6 : ¬ j < 5376 := by omega
  rw [rowAt, ite_eq_left p0, ite_eq_right p1, ite_eq_right p2, ite_eq_left p3, ite_eq_left p4, ite_eq_right p5, ite_eq_right p6]
  have hj : j - 5376 < 128 := by omega
  have hk : j - 5376 < originalBlock42.size := blockSize42.symm ▸ hj
  have result : archivedGlobalCore.proof ((originalBlock42[j - 5376]?).getD Sat.Clause.nil) :=
    @originalArrayRow archivedGlobalCore originalBlock42 (j - 5376) originalSubsumes42 hk
  have concrete : archivedGlobalCore.proof ((block42[j - 5376]?).getD Sat.Clause.nil) :=
    @transportArrayProof archivedGlobalCore originalBlock42 block42 (j - 5376) blockContent42 result
  exact concrete

theorem blockContent43 : originalBlock43 = block43 := rfl
theorem blockSize43 : originalBlock43.size = 128 := rfl
attribute [local irreducible] originalBlock43 block43
theorem originalSpan43 : ProvedSpan archivedGlobalCore rowAt 5504 5632 := by
  intro j hlo hhi
  have p0 : j < 6912 := by omega
  have p1 : ¬ j < 3456 := by omega
  have p2 : ¬ j < 5120 := by omega
  have p3 : j < 6016 := by omega
  have p4 : ¬ j < 5504 := by omega
  have p5 : j < 5760 := by omega
  have p6 : j < 5632 := by omega
  rw [rowAt, ite_eq_left p0, ite_eq_right p1, ite_eq_right p2, ite_eq_left p3, ite_eq_right p4, ite_eq_left p5, ite_eq_left p6]
  have hj : j - 5504 < 128 := by omega
  have hk : j - 5504 < originalBlock43.size := blockSize43.symm ▸ hj
  have result : archivedGlobalCore.proof ((originalBlock43[j - 5504]?).getD Sat.Clause.nil) :=
    @originalArrayRow archivedGlobalCore originalBlock43 (j - 5504) originalSubsumes43 hk
  have concrete : archivedGlobalCore.proof ((block43[j - 5504]?).getD Sat.Clause.nil) :=
    @transportArrayProof archivedGlobalCore originalBlock43 block43 (j - 5504) blockContent43 result
  exact concrete

theorem blockContent44 : originalBlock44 = block44 := rfl
theorem blockSize44 : originalBlock44.size = 128 := rfl
attribute [local irreducible] originalBlock44 block44
theorem originalSpan44 : ProvedSpan archivedGlobalCore rowAt 5632 5760 := by
  intro j hlo hhi
  have p0 : j < 6912 := by omega
  have p1 : ¬ j < 3456 := by omega
  have p2 : ¬ j < 5120 := by omega
  have p3 : j < 6016 := by omega
  have p4 : ¬ j < 5504 := by omega
  have p5 : j < 5760 := by omega
  have p6 : ¬ j < 5632 := by omega
  rw [rowAt, ite_eq_left p0, ite_eq_right p1, ite_eq_right p2, ite_eq_left p3, ite_eq_right p4, ite_eq_left p5, ite_eq_right p6]
  have hj : j - 5632 < 128 := by omega
  have hk : j - 5632 < originalBlock44.size := blockSize44.symm ▸ hj
  have result : archivedGlobalCore.proof ((originalBlock44[j - 5632]?).getD Sat.Clause.nil) :=
    @originalArrayRow archivedGlobalCore originalBlock44 (j - 5632) originalSubsumes44 hk
  have concrete : archivedGlobalCore.proof ((block44[j - 5632]?).getD Sat.Clause.nil) :=
    @transportArrayProof archivedGlobalCore originalBlock44 block44 (j - 5632) blockContent44 result
  exact concrete

theorem blockContent45 : originalBlock45 = block45 := rfl
theorem blockSize45 : originalBlock45.size = 128 := rfl
attribute [local irreducible] originalBlock45 block45
theorem originalSpan45 : ProvedSpan archivedGlobalCore rowAt 5760 5888 := by
  intro j hlo hhi
  have p0 : j < 6912 := by omega
  have p1 : ¬ j < 3456 := by omega
  have p2 : ¬ j < 5120 := by omega
  have p3 : j < 6016 := by omega
  have p4 : ¬ j < 5504 := by omega
  have p5 : ¬ j < 5760 := by omega
  have p6 : j < 5888 := by omega
  rw [rowAt, ite_eq_left p0, ite_eq_right p1, ite_eq_right p2, ite_eq_left p3, ite_eq_right p4, ite_eq_right p5, ite_eq_left p6]
  have hj : j - 5760 < 128 := by omega
  have hk : j - 5760 < originalBlock45.size := blockSize45.symm ▸ hj
  have result : archivedGlobalCore.proof ((originalBlock45[j - 5760]?).getD Sat.Clause.nil) :=
    @originalArrayRow archivedGlobalCore originalBlock45 (j - 5760) originalSubsumes45 hk
  have concrete : archivedGlobalCore.proof ((block45[j - 5760]?).getD Sat.Clause.nil) :=
    @transportArrayProof archivedGlobalCore originalBlock45 block45 (j - 5760) blockContent45 result
  exact concrete

theorem blockContent46 : originalBlock46 = block46 := rfl
theorem blockSize46 : originalBlock46.size = 128 := rfl
attribute [local irreducible] originalBlock46 block46
theorem originalSpan46 : ProvedSpan archivedGlobalCore rowAt 5888 6016 := by
  intro j hlo hhi
  have p0 : j < 6912 := by omega
  have p1 : ¬ j < 3456 := by omega
  have p2 : ¬ j < 5120 := by omega
  have p3 : j < 6016 := by omega
  have p4 : ¬ j < 5504 := by omega
  have p5 : ¬ j < 5760 := by omega
  have p6 : ¬ j < 5888 := by omega
  rw [rowAt, ite_eq_left p0, ite_eq_right p1, ite_eq_right p2, ite_eq_left p3, ite_eq_right p4, ite_eq_right p5, ite_eq_right p6]
  have hj : j - 5888 < 128 := by omega
  have hk : j - 5888 < originalBlock46.size := blockSize46.symm ▸ hj
  have result : archivedGlobalCore.proof ((originalBlock46[j - 5888]?).getD Sat.Clause.nil) :=
    @originalArrayRow archivedGlobalCore originalBlock46 (j - 5888) originalSubsumes46 hk
  have concrete : archivedGlobalCore.proof ((block46[j - 5888]?).getD Sat.Clause.nil) :=
    @transportArrayProof archivedGlobalCore originalBlock46 block46 (j - 5888) blockContent46 result
  exact concrete

theorem blockContent47 : originalBlock47 = block47 := rfl
theorem blockSize47 : originalBlock47.size = 128 := rfl
attribute [local irreducible] originalBlock47 block47
theorem originalSpan47 : ProvedSpan archivedGlobalCore rowAt 6016 6144 := by
  intro j hlo hhi
  have p0 : j < 6912 := by omega
  have p1 : ¬ j < 3456 := by omega
  have p2 : ¬ j < 5120 := by omega
  have p3 : ¬ j < 6016 := by omega
  have p4 : j < 6400 := by omega
  have p5 : j < 6144 := by omega
  rw [rowAt, ite_eq_left p0, ite_eq_right p1, ite_eq_right p2, ite_eq_right p3, ite_eq_left p4, ite_eq_left p5]
  have hj : j - 6016 < 128 := by omega
  have hk : j - 6016 < originalBlock47.size := blockSize47.symm ▸ hj
  have result : archivedGlobalCore.proof ((originalBlock47[j - 6016]?).getD Sat.Clause.nil) :=
    @originalArrayRow archivedGlobalCore originalBlock47 (j - 6016) originalSubsumes47 hk
  have concrete : archivedGlobalCore.proof ((block47[j - 6016]?).getD Sat.Clause.nil) :=
    @transportArrayProof archivedGlobalCore originalBlock47 block47 (j - 6016) blockContent47 result
  exact concrete

end Euler.C14.Production
