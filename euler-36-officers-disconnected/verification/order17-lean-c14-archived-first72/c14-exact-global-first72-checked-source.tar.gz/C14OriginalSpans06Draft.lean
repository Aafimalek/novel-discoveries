import C14OriginalExactArchiveDraft
import C14OriginalGenericDraft
namespace Euler.C14.Production
set_option maxRecDepth 18000
set_option maxHeartbeats 2400000

theorem blockContent48 : originalBlock48 = block48 := rfl
theorem blockSize48 : originalBlock48.size = 128 := rfl
attribute [local irreducible] originalBlock48 block48
theorem originalSpan48 : ProvedSpan archivedGlobalCore rowAt 6144 6272 := by
  intro j hlo hhi
  have p0 : j < 6912 := by omega
  have p1 : ¬ j < 3456 := by omega
  have p2 : ¬ j < 5120 := by omega
  have p3 : ¬ j < 6016 := by omega
  have p4 : j < 6400 := by omega
  have p5 : ¬ j < 6144 := by omega
  have p6 : j < 6272 := by omega
  rw [rowAt, ite_eq_left p0, ite_eq_right p1, ite_eq_right p2, ite_eq_right p3, ite_eq_left p4, ite_eq_right p5, ite_eq_left p6]
  have hj : j - 6144 < 128 := by omega
  have hk : j - 6144 < originalBlock48.size := blockSize48.symm ▸ hj
  have result : archivedGlobalCore.proof ((originalBlock48[j - 6144]?).getD Sat.Clause.nil) :=
    @originalArrayRow archivedGlobalCore originalBlock48 (j - 6144) originalSubsumes48 hk
  have concrete : archivedGlobalCore.proof ((block48[j - 6144]?).getD Sat.Clause.nil) :=
    @transportArrayProof archivedGlobalCore originalBlock48 block48 (j - 6144) blockContent48 result
  exact concrete

theorem blockContent49 : originalBlock49 = block49 := rfl
theorem blockSize49 : originalBlock49.size = 128 := rfl
attribute [local irreducible] originalBlock49 block49
theorem originalSpan49 : ProvedSpan archivedGlobalCore rowAt 6272 6400 := by
  intro j hlo hhi
  have p0 : j < 6912 := by omega
  have p1 : ¬ j < 3456 := by omega
  have p2 : ¬ j < 5120 := by omega
  have p3 : ¬ j < 6016 := by omega
  have p4 : j < 6400 := by omega
  have p5 : ¬ j < 6144 := by omega
  have p6 : ¬ j < 6272 := by omega
  rw [rowAt, ite_eq_left p0, ite_eq_right p1, ite_eq_right p2, ite_eq_right p3, ite_eq_left p4, ite_eq_right p5, ite_eq_right p6]
  have hj : j - 6272 < 128 := by omega
  have hk : j - 6272 < originalBlock49.size := blockSize49.symm ▸ hj
  have result : archivedGlobalCore.proof ((originalBlock49[j - 6272]?).getD Sat.Clause.nil) :=
    @originalArrayRow archivedGlobalCore originalBlock49 (j - 6272) originalSubsumes49 hk
  have concrete : archivedGlobalCore.proof ((block49[j - 6272]?).getD Sat.Clause.nil) :=
    @transportArrayProof archivedGlobalCore originalBlock49 block49 (j - 6272) blockContent49 result
  exact concrete

theorem blockContent50 : originalBlock50 = block50 := rfl
theorem blockSize50 : originalBlock50.size = 128 := rfl
attribute [local irreducible] originalBlock50 block50
theorem originalSpan50 : ProvedSpan archivedGlobalCore rowAt 6400 6528 := by
  intro j hlo hhi
  have p0 : j < 6912 := by omega
  have p1 : ¬ j < 3456 := by omega
  have p2 : ¬ j < 5120 := by omega
  have p3 : ¬ j < 6016 := by omega
  have p4 : ¬ j < 6400 := by omega
  have p5 : j < 6656 := by omega
  have p6 : j < 6528 := by omega
  rw [rowAt, ite_eq_left p0, ite_eq_right p1, ite_eq_right p2, ite_eq_right p3, ite_eq_right p4, ite_eq_left p5, ite_eq_left p6]
  have hj : j - 6400 < 128 := by omega
  have hk : j - 6400 < originalBlock50.size := blockSize50.symm ▸ hj
  have result : archivedGlobalCore.proof ((originalBlock50[j - 6400]?).getD Sat.Clause.nil) :=
    @originalArrayRow archivedGlobalCore originalBlock50 (j - 6400) originalSubsumes50 hk
  have concrete : archivedGlobalCore.proof ((block50[j - 6400]?).getD Sat.Clause.nil) :=
    @transportArrayProof archivedGlobalCore originalBlock50 block50 (j - 6400) blockContent50 result
  exact concrete

theorem blockContent51 : originalBlock51 = block51 := rfl
theorem blockSize51 : originalBlock51.size = 128 := rfl
attribute [local irreducible] originalBlock51 block51
theorem originalSpan51 : ProvedSpan archivedGlobalCore rowAt 6528 6656 := by
  intro j hlo hhi
  have p0 : j < 6912 := by omega
  have p1 : ¬ j < 3456 := by omega
  have p2 : ¬ j < 5120 := by omega
  have p3 : ¬ j < 6016 := by omega
  have p4 : ¬ j < 6400 := by omega
  have p5 : j < 6656 := by omega
  have p6 : ¬ j < 6528 := by omega
  rw [rowAt, ite_eq_left p0, ite_eq_right p1, ite_eq_right p2, ite_eq_right p3, ite_eq_right p4, ite_eq_left p5, ite_eq_right p6]
  have hj : j - 6528 < 128 := by omega
  have hk : j - 6528 < originalBlock51.size := blockSize51.symm ▸ hj
  have result : archivedGlobalCore.proof ((originalBlock51[j - 6528]?).getD Sat.Clause.nil) :=
    @originalArrayRow archivedGlobalCore originalBlock51 (j - 6528) originalSubsumes51 hk
  have concrete : archivedGlobalCore.proof ((block51[j - 6528]?).getD Sat.Clause.nil) :=
    @transportArrayProof archivedGlobalCore originalBlock51 block51 (j - 6528) blockContent51 result
  exact concrete

theorem blockContent52 : originalBlock52 = block52 := rfl
theorem blockSize52 : originalBlock52.size = 128 := rfl
attribute [local irreducible] originalBlock52 block52
theorem originalSpan52 : ProvedSpan archivedGlobalCore rowAt 6656 6784 := by
  intro j hlo hhi
  have p0 : j < 6912 := by omega
  have p1 : ¬ j < 3456 := by omega
  have p2 : ¬ j < 5120 := by omega
  have p3 : ¬ j < 6016 := by omega
  have p4 : ¬ j < 6400 := by omega
  have p5 : ¬ j < 6656 := by omega
  have p6 : j < 6784 := by omega
  rw [rowAt, ite_eq_left p0, ite_eq_right p1, ite_eq_right p2, ite_eq_right p3, ite_eq_right p4, ite_eq_right p5, ite_eq_left p6]
  have hj : j - 6656 < 128 := by omega
  have hk : j - 6656 < originalBlock52.size := blockSize52.symm ▸ hj
  have result : archivedGlobalCore.proof ((originalBlock52[j - 6656]?).getD Sat.Clause.nil) :=
    @originalArrayRow archivedGlobalCore originalBlock52 (j - 6656) originalSubsumes52 hk
  have concrete : archivedGlobalCore.proof ((block52[j - 6656]?).getD Sat.Clause.nil) :=
    @transportArrayProof archivedGlobalCore originalBlock52 block52 (j - 6656) blockContent52 result
  exact concrete

theorem blockContent53 : originalBlock53 = block53 := rfl
theorem blockSize53 : originalBlock53.size = 128 := rfl
attribute [local irreducible] originalBlock53 block53
theorem originalSpan53 : ProvedSpan archivedGlobalCore rowAt 6784 6912 := by
  intro j hlo hhi
  have p0 : j < 6912 := by omega
  have p1 : ¬ j < 3456 := by omega
  have p2 : ¬ j < 5120 := by omega
  have p3 : ¬ j < 6016 := by omega
  have p4 : ¬ j < 6400 := by omega
  have p5 : ¬ j < 6656 := by omega
  have p6 : ¬ j < 6784 := by omega
  rw [rowAt, ite_eq_left p0, ite_eq_right p1, ite_eq_right p2, ite_eq_right p3, ite_eq_right p4, ite_eq_right p5, ite_eq_right p6]
  have hj : j - 6784 < 128 := by omega
  have hk : j - 6784 < originalBlock53.size := blockSize53.symm ▸ hj
  have result : archivedGlobalCore.proof ((originalBlock53[j - 6784]?).getD Sat.Clause.nil) :=
    @originalArrayRow archivedGlobalCore originalBlock53 (j - 6784) originalSubsumes53 hk
  have concrete : archivedGlobalCore.proof ((block53[j - 6784]?).getD Sat.Clause.nil) :=
    @transportArrayProof archivedGlobalCore originalBlock53 block53 (j - 6784) blockContent53 result
  exact concrete

theorem blockContent54 : originalBlock54 = block54 := rfl
theorem blockSize54 : originalBlock54.size = 128 := rfl
attribute [local irreducible] originalBlock54 block54
theorem originalSpan54 : ProvedSpan archivedGlobalCore rowAt 6912 7040 := by
  intro j hlo hhi
  have p0 : ¬ j < 6912 := by omega
  have p1 : j < 10368 := by omega
  have p2 : j < 8576 := by omega
  have p3 : j < 7680 := by omega
  have p4 : j < 7296 := by omega
  have p5 : j < 7040 := by omega
  rw [rowAt, ite_eq_right p0, ite_eq_left p1, ite_eq_left p2, ite_eq_left p3, ite_eq_left p4, ite_eq_left p5]
  have hj : j - 6912 < 128 := by omega
  have hk : j - 6912 < originalBlock54.size := blockSize54.symm ▸ hj
  have result : archivedGlobalCore.proof ((originalBlock54[j - 6912]?).getD Sat.Clause.nil) :=
    @originalArrayRow archivedGlobalCore originalBlock54 (j - 6912) originalSubsumes54 hk
  have concrete : archivedGlobalCore.proof ((block54[j - 6912]?).getD Sat.Clause.nil) :=
    @transportArrayProof archivedGlobalCore originalBlock54 block54 (j - 6912) blockContent54 result
  exact concrete

theorem blockContent55 : originalBlock55 = block55 := rfl
theorem blockSize55 : originalBlock55.size = 128 := rfl
attribute [local irreducible] originalBlock55 block55
theorem originalSpan55 : ProvedSpan archivedGlobalCore rowAt 7040 7168 := by
  intro j hlo hhi
  have p0 : ¬ j < 6912 := by omega
  have p1 : j < 10368 := by omega
  have p2 : j < 8576 := by omega
  have p3 : j < 7680 := by omega
  have p4 : j < 7296 := by omega
  have p5 : ¬ j < 7040 := by omega
  have p6 : j < 7168 := by omega
  rw [rowAt, ite_eq_right p0, ite_eq_left p1, ite_eq_left p2, ite_eq_left p3, ite_eq_left p4, ite_eq_right p5, ite_eq_left p6]
  have hj : j - 7040 < 128 := by omega
  have hk : j - 7040 < originalBlock55.size := blockSize55.symm ▸ hj
  have result : archivedGlobalCore.proof ((originalBlock55[j - 7040]?).getD Sat.Clause.nil) :=
    @originalArrayRow archivedGlobalCore originalBlock55 (j - 7040) originalSubsumes55 hk
  have concrete : archivedGlobalCore.proof ((block55[j - 7040]?).getD Sat.Clause.nil) :=
    @transportArrayProof archivedGlobalCore originalBlock55 block55 (j - 7040) blockContent55 result
  exact concrete

end Euler.C14.Production
