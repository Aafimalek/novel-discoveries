import C14OriginalExactArchiveDraft
import C14OriginalGenericDraft
namespace Euler.C14.Production
set_option maxRecDepth 18000
set_option maxHeartbeats 2400000

theorem blockContent8 : originalBlock8 = block8 := rfl
theorem blockSize8 : originalBlock8.size = 128 := rfl
attribute [local irreducible] originalBlock8 block8
theorem originalSpan8 : ProvedSpan archivedGlobalCore rowAt 1024 1152 := by
  intro j hlo hhi
  have p0 : j < 6912 := by omega
  have p1 : j < 3456 := by omega
  have p2 : j < 1664 := by omega
  have p3 : ¬ j < 768 := by omega
  have p4 : j < 1152 := by omega
  have p5 : ¬ j < 896 := by omega
  have p6 : ¬ j < 1024 := by omega
  rw [rowAt, ite_eq_left p0, ite_eq_left p1, ite_eq_left p2, ite_eq_right p3, ite_eq_left p4, ite_eq_right p5, ite_eq_right p6]
  have hj : j - 1024 < 128 := by omega
  have hk : j - 1024 < originalBlock8.size := blockSize8.symm ▸ hj
  have result : archivedGlobalCore.proof ((originalBlock8[j - 1024]?).getD Sat.Clause.nil) :=
    @originalArrayRow archivedGlobalCore originalBlock8 (j - 1024) originalSubsumes8 hk
  have concrete : archivedGlobalCore.proof ((block8[j - 1024]?).getD Sat.Clause.nil) :=
    @transportArrayProof archivedGlobalCore originalBlock8 block8 (j - 1024) blockContent8 result
  exact concrete

theorem blockContent9 : originalBlock9 = block9 := rfl
theorem blockSize9 : originalBlock9.size = 128 := rfl
attribute [local irreducible] originalBlock9 block9
theorem originalSpan9 : ProvedSpan archivedGlobalCore rowAt 1152 1280 := by
  intro j hlo hhi
  have p0 : j < 6912 := by omega
  have p1 : j < 3456 := by omega
  have p2 : j < 1664 := by omega
  have p3 : ¬ j < 768 := by omega
  have p4 : ¬ j < 1152 := by omega
  have p5 : j < 1408 := by omega
  have p6 : j < 1280 := by omega
  rw [rowAt, ite_eq_left p0, ite_eq_left p1, ite_eq_left p2, ite_eq_right p3, ite_eq_right p4, ite_eq_left p5, ite_eq_left p6]
  have hj : j - 1152 < 128 := by omega
  have hk : j - 1152 < originalBlock9.size := blockSize9.symm ▸ hj
  have result : archivedGlobalCore.proof ((originalBlock9[j - 1152]?).getD Sat.Clause.nil) :=
    @originalArrayRow archivedGlobalCore originalBlock9 (j - 1152) originalSubsumes9 hk
  have concrete : archivedGlobalCore.proof ((block9[j - 1152]?).getD Sat.Clause.nil) :=
    @transportArrayProof archivedGlobalCore originalBlock9 block9 (j - 1152) blockContent9 result
  exact concrete

theorem blockContent10 : originalBlock10 = block10 := rfl
theorem blockSize10 : originalBlock10.size = 128 := rfl
attribute [local irreducible] originalBlock10 block10
theorem originalSpan10 : ProvedSpan archivedGlobalCore rowAt 1280 1408 := by
  intro j hlo hhi
  have p0 : j < 6912 := by omega
  have p1 : j < 3456 := by omega
  have p2 : j < 1664 := by omega
  have p3 : ¬ j < 768 := by omega
  have p4 : ¬ j < 1152 := by omega
  have p5 : j < 1408 := by omega
  have p6 : ¬ j < 1280 := by omega
  rw [rowAt, ite_eq_left p0, ite_eq_left p1, ite_eq_left p2, ite_eq_right p3, ite_eq_right p4, ite_eq_left p5, ite_eq_right p6]
  have hj : j - 1280 < 128 := by omega
  have hk : j - 1280 < originalBlock10.size := blockSize10.symm ▸ hj
  have result : archivedGlobalCore.proof ((originalBlock10[j - 1280]?).getD Sat.Clause.nil) :=
    @originalArrayRow archivedGlobalCore originalBlock10 (j - 1280) originalSubsumes10 hk
  have concrete : archivedGlobalCore.proof ((block10[j - 1280]?).getD Sat.Clause.nil) :=
    @transportArrayProof archivedGlobalCore originalBlock10 block10 (j - 1280) blockContent10 result
  exact concrete

theorem blockContent11 : originalBlock11 = block11 := rfl
theorem blockSize11 : originalBlock11.size = 128 := rfl
attribute [local irreducible] originalBlock11 block11
theorem originalSpan11 : ProvedSpan archivedGlobalCore rowAt 1408 1536 := by
  intro j hlo hhi
  have p0 : j < 6912 := by omega
  have p1 : j < 3456 := by omega
  have p2 : j < 1664 := by omega
  have p3 : ¬ j < 768 := by omega
  have p4 : ¬ j < 1152 := by omega
  have p5 : ¬ j < 1408 := by omega
  have p6 : j < 1536 := by omega
  rw [rowAt, ite_eq_left p0, ite_eq_left p1, ite_eq_left p2, ite_eq_right p3, ite_eq_right p4, ite_eq_right p5, ite_eq_left p6]
  have hj : j - 1408 < 128 := by omega
  have hk : j - 1408 < originalBlock11.size := blockSize11.symm ▸ hj
  have result : archivedGlobalCore.proof ((originalBlock11[j - 1408]?).getD Sat.Clause.nil) :=
    @originalArrayRow archivedGlobalCore originalBlock11 (j - 1408) originalSubsumes11 hk
  have concrete : archivedGlobalCore.proof ((block11[j - 1408]?).getD Sat.Clause.nil) :=
    @transportArrayProof archivedGlobalCore originalBlock11 block11 (j - 1408) blockContent11 result
  exact concrete

theorem blockContent12 : originalBlock12 = block12 := rfl
theorem blockSize12 : originalBlock12.size = 128 := rfl
attribute [local irreducible] originalBlock12 block12
theorem originalSpan12 : ProvedSpan archivedGlobalCore rowAt 1536 1664 := by
  intro j hlo hhi
  have p0 : j < 6912 := by omega
  have p1 : j < 3456 := by omega
  have p2 : j < 1664 := by omega
  have p3 : ¬ j < 768 := by omega
  have p4 : ¬ j < 1152 := by omega
  have p5 : ¬ j < 1408 := by omega
  have p6 : ¬ j < 1536 := by omega
  rw [rowAt, ite_eq_left p0, ite_eq_left p1, ite_eq_left p2, ite_eq_right p3, ite_eq_right p4, ite_eq_right p5, ite_eq_right p6]
  have hj : j - 1536 < 128 := by omega
  have hk : j - 1536 < originalBlock12.size := blockSize12.symm ▸ hj
  have result : archivedGlobalCore.proof ((originalBlock12[j - 1536]?).getD Sat.Clause.nil) :=
    @originalArrayRow archivedGlobalCore originalBlock12 (j - 1536) originalSubsumes12 hk
  have concrete : archivedGlobalCore.proof ((block12[j - 1536]?).getD Sat.Clause.nil) :=
    @transportArrayProof archivedGlobalCore originalBlock12 block12 (j - 1536) blockContent12 result
  exact concrete

theorem blockContent13 : originalBlock13 = block13 := rfl
theorem blockSize13 : originalBlock13.size = 128 := rfl
attribute [local irreducible] originalBlock13 block13
theorem originalSpan13 : ProvedSpan archivedGlobalCore rowAt 1664 1792 := by
  intro j hlo hhi
  have p0 : j < 6912 := by omega
  have p1 : j < 3456 := by omega
  have p2 : ¬ j < 1664 := by omega
  have p3 : j < 2560 := by omega
  have p4 : j < 2048 := by omega
  have p5 : j < 1792 := by omega
  rw [rowAt, ite_eq_left p0, ite_eq_left p1, ite_eq_right p2, ite_eq_left p3, ite_eq_left p4, ite_eq_left p5]
  have hj : j - 1664 < 128 := by omega
  have hk : j - 1664 < originalBlock13.size := blockSize13.symm ▸ hj
  have result : archivedGlobalCore.proof ((originalBlock13[j - 1664]?).getD Sat.Clause.nil) :=
    @originalArrayRow archivedGlobalCore originalBlock13 (j - 1664) originalSubsumes13 hk
  have concrete : archivedGlobalCore.proof ((block13[j - 1664]?).getD Sat.Clause.nil) :=
    @transportArrayProof archivedGlobalCore originalBlock13 block13 (j - 1664) blockContent13 result
  exact concrete

theorem blockContent14 : originalBlock14 = block14 := rfl
theorem blockSize14 : originalBlock14.size = 128 := rfl
attribute [local irreducible] originalBlock14 block14
theorem originalSpan14 : ProvedSpan archivedGlobalCore rowAt 1792 1920 := by
  intro j hlo hhi
  have p0 : j < 6912 := by omega
  have p1 : j < 3456 := by omega
  have p2 : ¬ j < 1664 := by omega
  have p3 : j < 2560 := by omega
  have p4 : j < 2048 := by omega
  have p5 : ¬ j < 1792 := by omega
  have p6 : j < 1920 := by omega
  rw [rowAt, ite_eq_left p0, ite_eq_left p1, ite_eq_right p2, ite_eq_left p3, ite_eq_left p4, ite_eq_right p5, ite_eq_left p6]
  have hj : j - 1792 < 128 := by omega
  have hk : j - 1792 < originalBlock14.size := blockSize14.symm ▸ hj
  have result : archivedGlobalCore.proof ((originalBlock14[j - 1792]?).getD Sat.Clause.nil) :=
    @originalArrayRow archivedGlobalCore originalBlock14 (j - 1792) originalSubsumes14 hk
  have concrete : archivedGlobalCore.proof ((block14[j - 1792]?).getD Sat.Clause.nil) :=
    @transportArrayProof archivedGlobalCore originalBlock14 block14 (j - 1792) blockContent14 result
  exact concrete

theorem blockContent15 : originalBlock15 = block15 := rfl
theorem blockSize15 : originalBlock15.size = 128 := rfl
attribute [local irreducible] originalBlock15 block15
theorem originalSpan15 : ProvedSpan archivedGlobalCore rowAt 1920 2048 := by
  intro j hlo hhi
  have p0 : j < 6912 := by omega
  have p1 : j < 3456 := by omega
  have p2 : ¬ j < 1664 := by omega
  have p3 : j < 2560 := by omega
  have p4 : j < 2048 := by omega
  have p5 : ¬ j < 1792 := by omega
  have p6 : ¬ j < 1920 := by omega
  rw [rowAt, ite_eq_left p0, ite_eq_left p1, ite_eq_right p2, ite_eq_left p3, ite_eq_left p4, ite_eq_right p5, ite_eq_right p6]
  have hj : j - 1920 < 128 := by omega
  have hk : j - 1920 < originalBlock15.size := blockSize15.symm ▸ hj
  have result : archivedGlobalCore.proof ((originalBlock15[j - 1920]?).getD Sat.Clause.nil) :=
    @originalArrayRow archivedGlobalCore originalBlock15 (j - 1920) originalSubsumes15 hk
  have concrete : archivedGlobalCore.proof ((block15[j - 1920]?).getD Sat.Clause.nil) :=
    @transportArrayProof archivedGlobalCore originalBlock15 block15 (j - 1920) blockContent15 result
  exact concrete

end Euler.C14.Production
