import C14OriginalExactArchiveDraft
import C14OriginalGenericDraft
namespace Euler.C14.Production
set_option maxRecDepth 18000
set_option maxHeartbeats 2400000

theorem blockContent24 : originalBlock24 = block24 := rfl
theorem blockSize24 : originalBlock24.size = 128 := rfl
attribute [local irreducible] originalBlock24 block24
theorem originalSpan24 : ProvedSpan archivedGlobalCore rowAt 3072 3200 := by
  intro j hlo hhi
  have p0 : j < 6912 := by omega
  have p1 : j < 3456 := by omega
  have p2 : ¬ j < 1664 := by omega
  have p3 : ¬ j < 2560 := by omega
  have p4 : ¬ j < 2944 := by omega
  have p5 : j < 3200 := by omega
  have p6 : ¬ j < 3072 := by omega
  rw [rowAt, ite_eq_left p0, ite_eq_left p1, ite_eq_right p2, ite_eq_right p3, ite_eq_right p4, ite_eq_left p5, ite_eq_right p6]
  have hj : j - 3072 < 128 := by omega
  have hk : j - 3072 < originalBlock24.size := blockSize24.symm ▸ hj
  have result : archivedGlobalCore.proof ((originalBlock24[j - 3072]?).getD Sat.Clause.nil) :=
    @originalArrayRow archivedGlobalCore originalBlock24 (j - 3072) originalSubsumes24 hk
  have concrete : archivedGlobalCore.proof ((block24[j - 3072]?).getD Sat.Clause.nil) :=
    @transportArrayProof archivedGlobalCore originalBlock24 block24 (j - 3072) blockContent24 result
  exact concrete

theorem blockContent25 : originalBlock25 = block25 := rfl
theorem blockSize25 : originalBlock25.size = 128 := rfl
attribute [local irreducible] originalBlock25 block25
theorem originalSpan25 : ProvedSpan archivedGlobalCore rowAt 3200 3328 := by
  intro j hlo hhi
  have p0 : j < 6912 := by omega
  have p1 : j < 3456 := by omega
  have p2 : ¬ j < 1664 := by omega
  have p3 : ¬ j < 2560 := by omega
  have p4 : ¬ j < 2944 := by omega
  have p5 : ¬ j < 3200 := by omega
  have p6 : j < 3328 := by omega
  rw [rowAt, ite_eq_left p0, ite_eq_left p1, ite_eq_right p2, ite_eq_right p3, ite_eq_right p4, ite_eq_right p5, ite_eq_left p6]
  have hj : j - 3200 < 128 := by omega
  have hk : j - 3200 < originalBlock25.size := blockSize25.symm ▸ hj
  have result : archivedGlobalCore.proof ((originalBlock25[j - 3200]?).getD Sat.Clause.nil) :=
    @originalArrayRow archivedGlobalCore originalBlock25 (j - 3200) originalSubsumes25 hk
  have concrete : archivedGlobalCore.proof ((block25[j - 3200]?).getD Sat.Clause.nil) :=
    @transportArrayProof archivedGlobalCore originalBlock25 block25 (j - 3200) blockContent25 result
  exact concrete

theorem blockContent26 : originalBlock26 = block26 := rfl
theorem blockSize26 : originalBlock26.size = 128 := rfl
attribute [local irreducible] originalBlock26 block26
theorem originalSpan26 : ProvedSpan archivedGlobalCore rowAt 3328 3456 := by
  intro j hlo hhi
  have p0 : j < 6912 := by omega
  have p1 : j < 3456 := by omega
  have p2 : ¬ j < 1664 := by omega
  have p3 : ¬ j < 2560 := by omega
  have p4 : ¬ j < 2944 := by omega
  have p5 : ¬ j < 3200 := by omega
  have p6 : ¬ j < 3328 := by omega
  rw [rowAt, ite_eq_left p0, ite_eq_left p1, ite_eq_right p2, ite_eq_right p3, ite_eq_right p4, ite_eq_right p5, ite_eq_right p6]
  have hj : j - 3328 < 128 := by omega
  have hk : j - 3328 < originalBlock26.size := blockSize26.symm ▸ hj
  have result : archivedGlobalCore.proof ((originalBlock26[j - 3328]?).getD Sat.Clause.nil) :=
    @originalArrayRow archivedGlobalCore originalBlock26 (j - 3328) originalSubsumes26 hk
  have concrete : archivedGlobalCore.proof ((block26[j - 3328]?).getD Sat.Clause.nil) :=
    @transportArrayProof archivedGlobalCore originalBlock26 block26 (j - 3328) blockContent26 result
  exact concrete

theorem blockContent27 : originalBlock27 = block27 := rfl
theorem blockSize27 : originalBlock27.size = 128 := rfl
attribute [local irreducible] originalBlock27 block27
theorem originalSpan27 : ProvedSpan archivedGlobalCore rowAt 3456 3584 := by
  intro j hlo hhi
  have p0 : j < 6912 := by omega
  have p1 : ¬ j < 3456 := by omega
  have p2 : j < 5120 := by omega
  have p3 : j < 4224 := by omega
  have p4 : j < 3840 := by omega
  have p5 : j < 3584 := by omega
  rw [rowAt, ite_eq_left p0, ite_eq_right p1, ite_eq_left p2, ite_eq_left p3, ite_eq_left p4, ite_eq_left p5]
  have hj : j - 3456 < 128 := by omega
  have hk : j - 3456 < originalBlock27.size := blockSize27.symm ▸ hj
  have result : archivedGlobalCore.proof ((originalBlock27[j - 3456]?).getD Sat.Clause.nil) :=
    @originalArrayRow archivedGlobalCore originalBlock27 (j - 3456) originalSubsumes27 hk
  have concrete : archivedGlobalCore.proof ((block27[j - 3456]?).getD Sat.Clause.nil) :=
    @transportArrayProof archivedGlobalCore originalBlock27 block27 (j - 3456) blockContent27 result
  exact concrete

theorem blockContent28 : originalBlock28 = block28 := rfl
theorem blockSize28 : originalBlock28.size = 128 := rfl
attribute [local irreducible] originalBlock28 block28
theorem originalSpan28 : ProvedSpan archivedGlobalCore rowAt 3584 3712 := by
  intro j hlo hhi
  have p0 : j < 6912 := by omega
  have p1 : ¬ j < 3456 := by omega
  have p2 : j < 5120 := by omega
  have p3 : j < 4224 := by omega
  have p4 : j < 3840 := by omega
  have p5 : ¬ j < 3584 := by omega
  have p6 : j < 3712 := by omega
  rw [rowAt, ite_eq_left p0, ite_eq_right p1, ite_eq_left p2, ite_eq_left p3, ite_eq_left p4, ite_eq_right p5, ite_eq_left p6]
  have hj : j - 3584 < 128 := by omega
  have hk : j - 3584 < originalBlock28.size := blockSize28.symm ▸ hj
  have result : archivedGlobalCore.proof ((originalBlock28[j - 3584]?).getD Sat.Clause.nil) :=
    @originalArrayRow archivedGlobalCore originalBlock28 (j - 3584) originalSubsumes28 hk
  have concrete : archivedGlobalCore.proof ((block28[j - 3584]?).getD Sat.Clause.nil) :=
    @transportArrayProof archivedGlobalCore originalBlock28 block28 (j - 3584) blockContent28 result
  exact concrete

theorem blockContent29 : originalBlock29 = block29 := rfl
theorem blockSize29 : originalBlock29.size = 128 := rfl
attribute [local irreducible] originalBlock29 block29
theorem originalSpan29 : ProvedSpan archivedGlobalCore rowAt 3712 3840 := by
  intro j hlo hhi
  have p0 : j < 6912 := by omega
  have p1 : ¬ j < 3456 := by omega
  have p2 : j < 5120 := by omega
  have p3 : j < 4224 := by omega
  have p4 : j < 3840 := by omega
  have p5 : ¬ j < 3584 := by omega
  have p6 : ¬ j < 3712 := by omega
  rw [rowAt, ite_eq_left p0, ite_eq_right p1, ite_eq_left p2, ite_eq_left p3, ite_eq_left p4, ite_eq_right p5, ite_eq_right p6]
  have hj : j - 3712 < 128 := by omega
  have hk : j - 3712 < originalBlock29.size := blockSize29.symm ▸ hj
  have result : archivedGlobalCore.proof ((originalBlock29[j - 3712]?).getD Sat.Clause.nil) :=
    @originalArrayRow archivedGlobalCore originalBlock29 (j - 3712) originalSubsumes29 hk
  have concrete : archivedGlobalCore.proof ((block29[j - 3712]?).getD Sat.Clause.nil) :=
    @transportArrayProof archivedGlobalCore originalBlock29 block29 (j - 3712) blockContent29 result
  exact concrete

theorem blockContent30 : originalBlock30 = block30 := rfl
theorem blockSize30 : originalBlock30.size = 128 := rfl
attribute [local irreducible] originalBlock30 block30
theorem originalSpan30 : ProvedSpan archivedGlobalCore rowAt 3840 3968 := by
  intro j hlo hhi
  have p0 : j < 6912 := by omega
  have p1 : ¬ j < 3456 := by omega
  have p2 : j < 5120 := by omega
  have p3 : j < 4224 := by omega
  have p4 : ¬ j < 3840 := by omega
  have p5 : j < 3968 := by omega
  rw [rowAt, ite_eq_left p0, ite_eq_right p1, ite_eq_left p2, ite_eq_left p3, ite_eq_right p4, ite_eq_left p5]
  have hj : j - 3840 < 128 := by omega
  have hk : j - 3840 < originalBlock30.size := blockSize30.symm ▸ hj
  have result : archivedGlobalCore.proof ((originalBlock30[j - 3840]?).getD Sat.Clause.nil) :=
    @originalArrayRow archivedGlobalCore originalBlock30 (j - 3840) originalSubsumes30 hk
  have concrete : archivedGlobalCore.proof ((block30[j - 3840]?).getD Sat.Clause.nil) :=
    @transportArrayProof archivedGlobalCore originalBlock30 block30 (j - 3840) blockContent30 result
  exact concrete

theorem blockContent31 : originalBlock31 = block31 := rfl
theorem blockSize31 : originalBlock31.size = 128 := rfl
attribute [local irreducible] originalBlock31 block31
theorem originalSpan31 : ProvedSpan archivedGlobalCore rowAt 3968 4096 := by
  intro j hlo hhi
  have p0 : j < 6912 := by omega
  have p1 : ¬ j < 3456 := by omega
  have p2 : j < 5120 := by omega
  have p3 : j < 4224 := by omega
  have p4 : ¬ j < 3840 := by omega
  have p5 : ¬ j < 3968 := by omega
  have p6 : j < 4096 := by omega
  rw [rowAt, ite_eq_left p0, ite_eq_right p1, ite_eq_left p2, ite_eq_left p3, ite_eq_right p4, ite_eq_right p5, ite_eq_left p6]
  have hj : j - 3968 < 128 := by omega
  have hk : j - 3968 < originalBlock31.size := blockSize31.symm ▸ hj
  have result : archivedGlobalCore.proof ((originalBlock31[j - 3968]?).getD Sat.Clause.nil) :=
    @originalArrayRow archivedGlobalCore originalBlock31 (j - 3968) originalSubsumes31 hk
  have concrete : archivedGlobalCore.proof ((block31[j - 3968]?).getD Sat.Clause.nil) :=
    @transportArrayProof archivedGlobalCore originalBlock31 block31 (j - 3968) blockContent31 result
  exact concrete

end Euler.C14.Production
