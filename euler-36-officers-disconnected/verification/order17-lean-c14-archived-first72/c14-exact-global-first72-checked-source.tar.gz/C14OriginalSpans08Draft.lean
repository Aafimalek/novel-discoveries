import C14OriginalExactArchiveDraft
import C14OriginalGenericDraft
namespace Euler.C14.Production
set_option maxRecDepth 18000
set_option maxHeartbeats 2400000

theorem blockContent64 : originalBlock64 = block64 := rfl
theorem blockSize64 : originalBlock64.size = 128 := rfl
attribute [local irreducible] originalBlock64 block64
theorem originalSpan64 : ProvedSpan archivedGlobalCore rowAt 8192 8320 := by
  intro j hlo hhi
  have p0 : ¬ j < 6912 := by omega
  have p1 : j < 10368 := by omega
  have p2 : j < 8576 := by omega
  have p3 : ¬ j < 7680 := by omega
  have p4 : ¬ j < 8064 := by omega
  have p5 : j < 8320 := by omega
  have p6 : ¬ j < 8192 := by omega
  rw [rowAt, ite_eq_right p0, ite_eq_left p1, ite_eq_left p2, ite_eq_right p3, ite_eq_right p4, ite_eq_left p5, ite_eq_right p6]
  have hj : j - 8192 < 128 := by omega
  have hk : j - 8192 < originalBlock64.size := blockSize64.symm ▸ hj
  have result : archivedGlobalCore.proof ((originalBlock64[j - 8192]?).getD Sat.Clause.nil) :=
    @originalArrayRow archivedGlobalCore originalBlock64 (j - 8192) originalSubsumes64 hk
  have concrete : archivedGlobalCore.proof ((block64[j - 8192]?).getD Sat.Clause.nil) :=
    @transportArrayProof archivedGlobalCore originalBlock64 block64 (j - 8192) blockContent64 result
  exact concrete

theorem blockContent65 : originalBlock65 = block65 := rfl
theorem blockSize65 : originalBlock65.size = 128 := rfl
attribute [local irreducible] originalBlock65 block65
theorem originalSpan65 : ProvedSpan archivedGlobalCore rowAt 8320 8448 := by
  intro j hlo hhi
  have p0 : ¬ j < 6912 := by omega
  have p1 : j < 10368 := by omega
  have p2 : j < 8576 := by omega
  have p3 : ¬ j < 7680 := by omega
  have p4 : ¬ j < 8064 := by omega
  have p5 : ¬ j < 8320 := by omega
  have p6 : j < 8448 := by omega
  rw [rowAt, ite_eq_right p0, ite_eq_left p1, ite_eq_left p2, ite_eq_right p3, ite_eq_right p4, ite_eq_right p5, ite_eq_left p6]
  have hj : j - 8320 < 128 := by omega
  have hk : j - 8320 < originalBlock65.size := blockSize65.symm ▸ hj
  have result : archivedGlobalCore.proof ((originalBlock65[j - 8320]?).getD Sat.Clause.nil) :=
    @originalArrayRow archivedGlobalCore originalBlock65 (j - 8320) originalSubsumes65 hk
  have concrete : archivedGlobalCore.proof ((block65[j - 8320]?).getD Sat.Clause.nil) :=
    @transportArrayProof archivedGlobalCore originalBlock65 block65 (j - 8320) blockContent65 result
  exact concrete

theorem blockContent66 : originalBlock66 = block66 := rfl
theorem blockSize66 : originalBlock66.size = 128 := rfl
attribute [local irreducible] originalBlock66 block66
theorem originalSpan66 : ProvedSpan archivedGlobalCore rowAt 8448 8576 := by
  intro j hlo hhi
  have p0 : ¬ j < 6912 := by omega
  have p1 : j < 10368 := by omega
  have p2 : j < 8576 := by omega
  have p3 : ¬ j < 7680 := by omega
  have p4 : ¬ j < 8064 := by omega
  have p5 : ¬ j < 8320 := by omega
  have p6 : ¬ j < 8448 := by omega
  rw [rowAt, ite_eq_right p0, ite_eq_left p1, ite_eq_left p2, ite_eq_right p3, ite_eq_right p4, ite_eq_right p5, ite_eq_right p6]
  have hj : j - 8448 < 128 := by omega
  have hk : j - 8448 < originalBlock66.size := blockSize66.symm ▸ hj
  have result : archivedGlobalCore.proof ((originalBlock66[j - 8448]?).getD Sat.Clause.nil) :=
    @originalArrayRow archivedGlobalCore originalBlock66 (j - 8448) originalSubsumes66 hk
  have concrete : archivedGlobalCore.proof ((block66[j - 8448]?).getD Sat.Clause.nil) :=
    @transportArrayProof archivedGlobalCore originalBlock66 block66 (j - 8448) blockContent66 result
  exact concrete

theorem blockContent67 : originalBlock67 = block67 := rfl
theorem blockSize67 : originalBlock67.size = 128 := rfl
attribute [local irreducible] originalBlock67 block67
theorem originalSpan67 : ProvedSpan archivedGlobalCore rowAt 8576 8704 := by
  intro j hlo hhi
  have p0 : ¬ j < 6912 := by omega
  have p1 : j < 10368 := by omega
  have p2 : ¬ j < 8576 := by omega
  have p3 : j < 9472 := by omega
  have p4 : j < 8960 := by omega
  have p5 : j < 8704 := by omega
  rw [rowAt, ite_eq_right p0, ite_eq_left p1, ite_eq_right p2, ite_eq_left p3, ite_eq_left p4, ite_eq_left p5]
  have hj : j - 8576 < 128 := by omega
  have hk : j - 8576 < originalBlock67.size := blockSize67.symm ▸ hj
  have result : archivedGlobalCore.proof ((originalBlock67[j - 8576]?).getD Sat.Clause.nil) :=
    @originalArrayRow archivedGlobalCore originalBlock67 (j - 8576) originalSubsumes67 hk
  have concrete : archivedGlobalCore.proof ((block67[j - 8576]?).getD Sat.Clause.nil) :=
    @transportArrayProof archivedGlobalCore originalBlock67 block67 (j - 8576) blockContent67 result
  exact concrete

theorem blockContent68 : originalBlock68 = (block68.extract 0 121) := rfl
theorem blockSize68 : originalBlock68.size = 121 := rfl
theorem finalBlockSize : block68.size = 128 := rfl
attribute [local irreducible] originalBlock68 block68
theorem originalSpan68 : ProvedSpan archivedGlobalCore rowAt 8704 8825 := by
  intro j hlo hhi
  have p0 : ¬ j < 6912 := by omega
  have p1 : j < 10368 := by omega
  have p2 : ¬ j < 8576 := by omega
  have p3 : j < 9472 := by omega
  have p4 : j < 8960 := by omega
  have p5 : ¬ j < 8704 := by omega
  have p6 : j < 8832 := by omega
  rw [rowAt, ite_eq_right p0, ite_eq_left p1, ite_eq_right p2, ite_eq_left p3, ite_eq_left p4, ite_eq_right p5, ite_eq_left p6]
  have hj : j - 8704 < 121 := by omega
  have hk : j - 8704 < originalBlock68.size := blockSize68.symm ▸ hj
  have result : archivedGlobalCore.proof ((originalBlock68[j - 8704]?).getD Sat.Clause.nil) :=
    @originalArrayRow archivedGlobalCore originalBlock68 (j - 8704) originalSubsumes68 hk
  have concrete : archivedGlobalCore.proof (((block68.extract 0 121)[j - 8704]?).getD Sat.Clause.nil) :=
    @transportArrayProof archivedGlobalCore originalBlock68 (block68.extract 0 121) (j - 8704) blockContent68 result
  have hb : j - 8704 < min 121 128 - 0 := hj
  rwa [Array.getElem?_extract, Nat.zero_add, finalBlockSize, ite_eq_left hb] at concrete

end Euler.C14.Production
