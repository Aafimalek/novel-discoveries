import C14OriginalExactArchiveDraft
import C14OriginalGenericDraft
namespace Euler.C14.Production
set_option maxRecDepth 18000
set_option maxHeartbeats 2400000

theorem blockContent0 : originalBlock0 = block0 := rfl
theorem blockSize0 : originalBlock0.size = 128 := rfl
attribute [local irreducible] originalBlock0 block0
theorem originalSpan0 : ProvedSpan archivedGlobalCore rowAt 0 128 := by
  intro j hlo hhi
  have p0 : j < 6912 := by omega
  have p1 : j < 3456 := by omega
  have p2 : j < 1664 := by omega
  have p3 : j < 768 := by omega
  have p4 : j < 384 := by omega
  have p5 : j < 128 := by omega
  rw [rowAt, ite_eq_left p0, ite_eq_left p1, ite_eq_left p2, ite_eq_left p3, ite_eq_left p4, ite_eq_left p5]
  have hj : j - 0 < 128 := by omega
  have hk : j - 0 < originalBlock0.size := blockSize0.symm ▸ hj
  have result : archivedGlobalCore.proof ((originalBlock0[j - 0]?).getD Sat.Clause.nil) :=
    @originalArrayRow archivedGlobalCore originalBlock0 (j - 0) originalSubsumes0 hk
  have concrete : archivedGlobalCore.proof ((block0[j - 0]?).getD Sat.Clause.nil) :=
    @transportArrayProof archivedGlobalCore originalBlock0 block0 (j - 0) blockContent0 result
  exact concrete

theorem blockContent1 : originalBlock1 = block1 := rfl
theorem blockSize1 : originalBlock1.size = 128 := rfl
attribute [local irreducible] originalBlock1 block1
theorem originalSpan1 : ProvedSpan archivedGlobalCore rowAt 128 256 := by
  intro j hlo hhi
  have p0 : j < 6912 := by omega
  have p1 : j < 3456 := by omega
  have p2 : j < 1664 := by omega
  have p3 : j < 768 := by omega
  have p4 : j < 384 := by omega
  have p5 : ¬ j < 128 := by omega
  have p6 : j < 256 := by omega
  rw [rowAt, ite_eq_left p0, ite_eq_left p1, ite_eq_left p2, ite_eq_left p3, ite_eq_left p4, ite_eq_right p5, ite_eq_left p6]
  have hj : j - 128 < 128 := by omega
  have hk : j - 128 < originalBlock1.size := blockSize1.symm ▸ hj
  have result : archivedGlobalCore.proof ((originalBlock1[j - 128]?).getD Sat.Clause.nil) :=
    @originalArrayRow archivedGlobalCore originalBlock1 (j - 128) originalSubsumes1 hk
  have concrete : archivedGlobalCore.proof ((block1[j - 128]?).getD Sat.Clause.nil) :=
    @transportArrayProof archivedGlobalCore originalBlock1 block1 (j - 128) blockContent1 result
  exact concrete

theorem blockContent2 : originalBlock2 = block2 := rfl
theorem blockSize2 : originalBlock2.size = 128 := rfl
attribute [local irreducible] originalBlock2 block2
theorem originalSpan2 : ProvedSpan archivedGlobalCore rowAt 256 384 := by
  intro j hlo hhi
  have p0 : j < 6912 := by omega
  have p1 : j < 3456 := by omega
  have p2 : j < 1664 := by omega
  have p3 : j < 768 := by omega
  have p4 : j < 384 := by omega
  have p5 : ¬ j < 128 := by omega
  have p6 : ¬ j < 256 := by omega
  rw [rowAt, ite_eq_left p0, ite_eq_left p1, ite_eq_left p2, ite_eq_left p3, ite_eq_left p4, ite_eq_right p5, ite_eq_right p6]
  have hj : j - 256 < 128 := by omega
  have hk : j - 256 < originalBlock2.size := blockSize2.symm ▸ hj
  have result : archivedGlobalCore.proof ((originalBlock2[j - 256]?).getD Sat.Clause.nil) :=
    @originalArrayRow archivedGlobalCore originalBlock2 (j - 256) originalSubsumes2 hk
  have concrete : archivedGlobalCore.proof ((block2[j - 256]?).getD Sat.Clause.nil) :=
    @transportArrayProof archivedGlobalCore originalBlock2 block2 (j - 256) blockContent2 result
  exact concrete

theorem blockContent3 : originalBlock3 = block3 := rfl
theorem blockSize3 : originalBlock3.size = 128 := rfl
attribute [local irreducible] originalBlock3 block3
theorem originalSpan3 : ProvedSpan archivedGlobalCore rowAt 384 512 := by
  intro j hlo hhi
  have p0 : j < 6912 := by omega
  have p1 : j < 3456 := by omega
  have p2 : j < 1664 := by omega
  have p3 : j < 768 := by omega
  have p4 : ¬ j < 384 := by omega
  have p5 : j < 512 := by omega
  rw [rowAt, ite_eq_left p0, ite_eq_left p1, ite_eq_left p2, ite_eq_left p3, ite_eq_right p4, ite_eq_left p5]
  have hj : j - 384 < 128 := by omega
  have hk : j - 384 < originalBlock3.size := blockSize3.symm ▸ hj
  have result : archivedGlobalCore.proof ((originalBlock3[j - 384]?).getD Sat.Clause.nil) :=
    @originalArrayRow archivedGlobalCore originalBlock3 (j - 384) originalSubsumes3 hk
  have concrete : archivedGlobalCore.proof ((block3[j - 384]?).getD Sat.Clause.nil) :=
    @transportArrayProof archivedGlobalCore originalBlock3 block3 (j - 384) blockContent3 result
  exact concrete

theorem blockContent4 : originalBlock4 = block4 := rfl
theorem blockSize4 : originalBlock4.size = 128 := rfl
attribute [local irreducible] originalBlock4 block4
theorem originalSpan4 : ProvedSpan archivedGlobalCore rowAt 512 640 := by
  intro j hlo hhi
  have p0 : j < 6912 := by omega
  have p1 : j < 3456 := by omega
  have p2 : j < 1664 := by omega
  have p3 : j < 768 := by omega
  have p4 : ¬ j < 384 := by omega
  have p5 : ¬ j < 512 := by omega
  have p6 : j < 640 := by omega
  rw [rowAt, ite_eq_left p0, ite_eq_left p1, ite_eq_left p2, ite_eq_left p3, ite_eq_right p4, ite_eq_right p5, ite_eq_left p6]
  have hj : j - 512 < 128 := by omega
  have hk : j - 512 < originalBlock4.size := blockSize4.symm ▸ hj
  have result : archivedGlobalCore.proof ((originalBlock4[j - 512]?).getD Sat.Clause.nil) :=
    @originalArrayRow archivedGlobalCore originalBlock4 (j - 512) originalSubsumes4 hk
  have concrete : archivedGlobalCore.proof ((block4[j - 512]?).getD Sat.Clause.nil) :=
    @transportArrayProof archivedGlobalCore originalBlock4 block4 (j - 512) blockContent4 result
  exact concrete

theorem blockContent5 : originalBlock5 = block5 := rfl
theorem blockSize5 : originalBlock5.size = 128 := rfl
attribute [local irreducible] originalBlock5 block5
theorem originalSpan5 : ProvedSpan archivedGlobalCore rowAt 640 768 := by
  intro j hlo hhi
  have p0 : j < 6912 := by omega
  have p1 : j < 3456 := by omega
  have p2 : j < 1664 := by omega
  have p3 : j < 768 := by omega
  have p4 : ¬ j < 384 := by omega
  have p5 : ¬ j < 512 := by omega
  have p6 : ¬ j < 640 := by omega
  rw [rowAt, ite_eq_left p0, ite_eq_left p1, ite_eq_left p2, ite_eq_left p3, ite_eq_right p4, ite_eq_right p5, ite_eq_right p6]
  have hj : j - 640 < 128 := by omega
  have hk : j - 640 < originalBlock5.size := blockSize5.symm ▸ hj
  have result : archivedGlobalCore.proof ((originalBlock5[j - 640]?).getD Sat.Clause.nil) :=
    @originalArrayRow archivedGlobalCore originalBlock5 (j - 640) originalSubsumes5 hk
  have concrete : archivedGlobalCore.proof ((block5[j - 640]?).getD Sat.Clause.nil) :=
    @transportArrayProof archivedGlobalCore originalBlock5 block5 (j - 640) blockContent5 result
  exact concrete

theorem blockContent6 : originalBlock6 = block6 := rfl
theorem blockSize6 : originalBlock6.size = 128 := rfl
attribute [local irreducible] originalBlock6 block6
theorem originalSpan6 : ProvedSpan archivedGlobalCore rowAt 768 896 := by
  intro j hlo hhi
  have p0 : j < 6912 := by omega
  have p1 : j < 3456 := by omega
  have p2 : j < 1664 := by omega
  have p3 : ¬ j < 768 := by omega
  have p4 : j < 1152 := by omega
  have p5 : j < 896 := by omega
  rw [rowAt, ite_eq_left p0, ite_eq_left p1, ite_eq_left p2, ite_eq_right p3, ite_eq_left p4, ite_eq_left p5]
  have hj : j - 768 < 128 := by omega
  have hk : j - 768 < originalBlock6.size := blockSize6.symm ▸ hj
  have result : archivedGlobalCore.proof ((originalBlock6[j - 768]?).getD Sat.Clause.nil) :=
    @originalArrayRow archivedGlobalCore originalBlock6 (j - 768) originalSubsumes6 hk
  have concrete : archivedGlobalCore.proof ((block6[j - 768]?).getD Sat.Clause.nil) :=
    @transportArrayProof archivedGlobalCore originalBlock6 block6 (j - 768) blockContent6 result
  exact concrete

theorem blockContent7 : originalBlock7 = block7 := rfl
theorem blockSize7 : originalBlock7.size = 128 := rfl
attribute [local irreducible] originalBlock7 block7
theorem originalSpan7 : ProvedSpan archivedGlobalCore rowAt 896 1024 := by
  intro j hlo hhi
  have p0 : j < 6912 := by omega
  have p1 : j < 3456 := by omega
  have p2 : j < 1664 := by omega
  have p3 : ¬ j < 768 := by omega
  have p4 : j < 1152 := by omega
  have p5 : ¬ j < 896 := by omega
  have p6 : j < 1024 := by omega
  rw [rowAt, ite_eq_left p0, ite_eq_left p1, ite_eq_left p2, ite_eq_right p3, ite_eq_left p4, ite_eq_right p5, ite_eq_left p6]
  have hj : j - 896 < 128 := by omega
  have hk : j - 896 < originalBlock7.size := blockSize7.symm ▸ hj
  have result : archivedGlobalCore.proof ((originalBlock7[j - 896]?).getD Sat.Clause.nil) :=
    @originalArrayRow archivedGlobalCore originalBlock7 (j - 896) originalSubsumes7 hk
  have concrete : archivedGlobalCore.proof ((block7[j - 896]?).getD Sat.Clause.nil) :=
    @transportArrayProof archivedGlobalCore originalBlock7 block7 (j - 896) blockContent7 result
  exact concrete

end Euler.C14.Production
