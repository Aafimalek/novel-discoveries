import C14GlobalDirectory

open Lean Elab Command Term Meta
open Mathlib.Tactic.Sat

namespace Euler.C14.Production

private partial def buildBlockConj (xs : Array Expr) (lo hi : Nat) : Expr :=
  if hi - lo = 1 then xs[lo]!
  else
    let m := lo + (hi - lo) / 2
    mkApp2 (Lean.mkConst ``Sat.Fmla.and) (buildBlockConj xs lo m) (buildBlockConj xs m hi)

private partial def blockProof (core tree proof : Expr) (lo hi i : Nat) : Expr :=
  if hi - lo = 1 then proof
  else
    let m := lo + (hi-lo)/2
    let l := tree.appFn!.appArg!
    let r := tree.appArg!
    if i < m then
      blockProof core l (mkApp4 (Lean.mkConst ``Sat.Fmla.subsumes_left) core l r proof) lo m i
    else
      blockProof core r (mkApp4 (Lean.mkConst ``Sat.Fmla.subsumes_right) core l r proof) m hi i

/-- Parse every original archived row and declare one typed array per
    original block, a canonical formula, and proofs of block inclusion
    using balanced binary routes. Pure ordinary kernel declarations. -/
elab "original_blocks " cnf:term:max : command => do
  let ns ← getCurrNamespace
  liftTermElabM do
    let text ← unsafe evalTerm String (Lean.mkConst ``String) cnf
    let .success stop (nv, clauses) := Parser.parseDimacs ⟨_, text.startPos⟩
      | throwError "archive DIMACS failure"
    unless nv == 10646 && clauses.size == 8825 && decide stop.2.IsAtEnd do
      throwError "archive DIMACS dimensions/EOF"
    let c := Lean.mkConst ``Sat.Clause
    let mut lists : Array Expr := #[]
    for b in [:69] do
      let begin := 128*b
      let past := min (begin+128) 8825
      let vals := (clauses.extract begin past).toList.map buildClause
      let list ← mkListLit c vals
      let value := mkApp2 (Lean.mkConst ``List.toArray [Level.zero]) c list
      let name := ns ++ Name.mkSimple s!"originalBlock{b}"
      addDecl <| .defnDecl {
        name := name
        levelParams := []
        type := mkApp (Lean.mkConst ``Array [Level.zero]) c
        value := value
        hints := .regular 0
        safety := .safe
      }
      lists := lists.push (mkApp2 (Lean.mkConst ``Array.toList [Level.zero]) c (Lean.mkConst name))
    let name := ns ++ `archivedGlobalCore
    let core := Lean.mkConst name
    let tree := buildBlockConj lists 0 lists.size
    addDecl <| .defnDecl {
      name := name
      levelParams := []
      type := Lean.mkConst ``Sat.Fmla
      value := tree
      hints := .regular 0
      safety := .safe
    }
    let root := mkApp (Lean.mkConst ``Sat.Fmla.subsumes_self) core
    for b in [:lists.size] do
      let name := ns ++ Name.mkSimple s!"originalSubsumes{b}"
      addDecl <| .thmDecl {
        name := name
        levelParams := []
        type := mkApp2 (Lean.mkConst ``Sat.Fmla.subsumes) core lists[b]!
        value := blockProof core tree root 0 lists.size b
      }

end Euler.C14.Production
