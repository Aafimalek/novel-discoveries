#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
: "${LEAN_BIN:?Set absolute pinned Lean 4.36 binary}"
: "${GLOBAL_C14_DIR:?Set absolute extracted and built c14-global-first48 source directory}"
: "${LEAN_MATHLIB_PATH:?Set colon-separated pinned dependency olean roots}"
export LEAN_PATH="$PWD:$GLOBAL_C14_DIR:$GLOBAL_C14_DIR/generated:$LEAN_MATHLIB_PATH"
mkdir -p "$PWD/tmp"
export TMPDIR="$PWD/tmp"
while IFS= read -r f; do
  timeout 73 "$LEAN_BIN" -j1 -M2450 -DwarningAsError=true -R "$PWD" -o "$f.olean" "$PWD/$f.lean"
done < checked-order.txt
