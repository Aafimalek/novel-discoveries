# C14: global original-prefix installation, static draft only

No Lean or Git ran. This package builds on the already checked shared
directory and conditional first48, at fixed original slots 0–8824.
It stages an exact archived-CNF bridge, not a digest-based theorem.

1. original_blocks consumes the included actual sorted DIMACS file via
   Mathlib parseDimacs, checks dimensions and EOF, and makes 69 original
   kernel-visible arrays: 68 full 128-clause leaves and a final 121-clause
   leaf. It declares archivedGlobalCore as a balanced concatenation of these
   arrays' lists in archive row order and constructs one structural
   subsumption derivation per leaf (depth at most 7). This exact typed
   archive is a new constant, regrouped from the same raw bytes; this
   package does not assert equality to the *older* clause-by-clause
   archivedSortedCore constant. No source SHA stands in for membership.
2. The unchanged known shared rowAt is routed by the same 109-block
   cutoff map. There is one exact kernel conversion equality per original
   leaf, matching the independently parsed DIMACS leaf against the existing
   production array (last leaf only equals extract 0 121). Each symbolic
   range theorem handles any position in that block, using arithmetic
   bounds, the balanced directory path, and Array.getElem_mem_toList.
   Thus there are 69 array content equalities/membership paths, not 8,825
   individually generated indexed positions or repeated chunk membership.
3. Join adjacent symbolic ranges in a balanced expression to get
   exactSortedArchiveInitial : GoodBelow archivedGlobalCore rowAt 8825.
   Apply the existing checked shared-directory first48 to get an
   unconditional-from-core first48_fromExactGlobalArchive at bound 8873.
   Both theorem names are draft, not actual verified milestones.

Compile order for the next specifically authorized wave: reuse all frozen
global directory objects and generic prefix object, set LEAN_PATH to both
that directory's generated/ and the main directory, plus this project and
the pinned dependency paths. Set overlay TMPDIR and one strict Lean 4.36
worker -j1 -M2450 -DwarningAsError=true. First check BlockDriver and
Generic; exact archive module separately (try ≤70 s); then only the
first span module and final-span module to measure ordinary/partial leaf
conversion before all nine. Check independent source/object/log receipts
after each; overall next guarded wave ≤5 min. Never call native_decide.
Then compile the assembled prefix and check axioms. If exact archive
elaboration peaks, split parser-derived arrays into named groups (same
content), rather than adding an assumption or unbounded conversion.

Separate scalable proof generation: plan-chunks.py gives 649 fresh slices
(5,037 additions, 815,721 hints) after checked 48, always same shared rowAt
and only generic driver imports. Cuts ≤24 rows and ≤1800 hints; single rows
with ≥550 hints stand alone. Starter modules are next [8873,8897) and
first cross-learned-dependency challenge [9254,9278). The latter has 43
prior learned imports and demonstrates why previous-prefix semantics
are required. An independent balanced composer should check that every
adjacent bound matches, stage a checked receipt per compiled module, and
roll back no prior correct objects when a chunk needs subdividing. First
measure these two small sample slices and one worst single-row case;
then consider tuning hint cap from measured proof terms, not number of
rows alone. No large compilation or full-proof claim follows from the
generated plan. The eventual explicit empty row still needs a separate
typed extraction and archive-to-geometry proof.
