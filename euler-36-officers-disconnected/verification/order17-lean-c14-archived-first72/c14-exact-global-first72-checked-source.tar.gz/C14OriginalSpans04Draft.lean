import C14OriginalExactArchiveDraft
import C14OriginalGenericDraft
namespace Euler.C14.Production
set_option maxRecDepth 18000
set_option maxHeartbeats 2400000

theorem blockContent32 : originalBlock32 = block32 := rfl
theorem blockSize32 : originalBlock32.size = 128 := rfl
attribute [local irreducible] originalBlock32 block32
theorem originalSpan32 : ProvedSpan archivedGlobalCore rowAt 4096 4224 := by
  intro j hlo hhi
  have p0 : j < 6912 := by omega
  have p1 : ¬ j < 3456 := by omega
  have p2 : j < 5120 := by omega
  have p3 : j < 4224 := by omega
  have p4 : ¬ j < 3840 := by omega
  have p5 : ¬ j < 3968 := by omega
  have p6 : ¬ j < 4096 := by omega
  rw [rowAt, ite_eq_left p0, ite_eq_right p1, ite_eq_left p2, ite_eq_left p3, ite_eq_right p4, ite_eq_right p5, ite_eq_right p6]
  have hj : j - 4096 < 128 := by omega
  have hk : j - 4096 < originalBlock32.size := blockSize32.symm ▸ hj
  have result : archivedGlobalCore.proof ((originalBlock32[j - 4096]?).getD Sat.Clause.nil) :=
    @originalArrayRow archivedGlobalCore originalBlock32 (j - 4096) originalSubsumes32 hk
  have concrete : archivedGlobalCore.proof ((block32[j - 4096]?).getD Sat.Clause.nil) :=
    @transportArrayProof archivedGlobalCore originalBlock32 block32 (j - 4096) blockContent32 result
  exact concrete

theorem blockContent33 : originalBlock33 = block33 := rfl
theorem blockSize33 : originalBlock33.size = 128 := rfl
attribute [local irreducible] originalBlock33 block33
theorem originalSpan33 : ProvedSpan archivedGlobalCore rowAt 4224 4352 := by
  intro j hlo hhi
  have p0 : j < 6912 := by omega
  have p1 : ¬ j < 3456 := by omega
  have p2 : j < 5120 := by omega
  have p3 : ¬ j < 4224 := by omega
  have p4 : j < 4608 := by omega
  have p5 : j < 4352 := by omega
  rw [rowAt, ite_eq_left p0, ite_eq_right p1, ite_eq_left p2, ite_eq_right p3, ite_eq_left p4, ite_eq_left p5]
  have hj : j - 4224 < 128 := by omega
  have hk : j - 4224 < originalBlock33.size := blockSize33.symm ▸ hj
  have result : archivedGlobalCore.proof ((originalBlock33[j - 4224]?).getD Sat.Clause.nil) :=
    @originalArrayRow archivedGlobalCore originalBlock33 (j - 4224) originalSubsumes33 hk
  have concrete : archivedGlobalCore.proof ((block33[j - 4224]?).getD Sat.Clause.nil) :=
    @transportArrayProof archivedGlobalCore originalBlock33 block33 (j - 4224) blockContent33 result
  exact concrete

theorem blockContent34 : originalBlock34 = block34 := rfl
theorem blockSize34 : originalBlock34.size = 128 := rfl
attribute [local irreducible] originalBlock34 block34
theorem originalSpan34 : ProvedSpan archivedGlobalCore rowAt 4352 4480 := by
  intro j hlo hhi
  have p0 : j < 6912 := by omega
  have p1 : ¬ j < 3456 := by omega
  have p2 : j < 5120 := by omega
  have p3 : ¬ j < 4224 := by omega
  have p4 : j < 4608 := by omega
  have p5 : ¬ j < 4352 := by omega
  have p6 : j < 4480 := by omega
  rw [rowAt, ite_eq_left p0, ite_eq_right p1, ite_eq_left p2, ite_eq_right p3, ite_eq_left p4, ite_eq_right p5, ite_eq_left p6]
  have hj : j - 4352 < 128 := by omega
  have hk : j - 4352 < originalBlock34.size := blockSize34.symm ▸ hj
  have result : archivedGlobalCore.proof ((originalBlock34[j - 4352]?).getD Sat.Clause.nil) :=
    @originalArrayRow archivedGlobalCore originalBlock34 (j - 4352) originalSubsumes34 hk
  have concrete : archivedGlobalCore.proof ((block34[j - 4352]?).getD Sat.Clause.nil) :=
    @transportArrayProof archivedGlobalCore originalBlock34 block34 (j - 4352) blockContent34 result
  exact concrete

theorem blockContent35 : originalBlock35 = block35 := rfl
theorem blockSize35 : originalBlock35.size = 128 := rfl
attribute [local irreducible] originalBlock35 block35
theorem originalSpan35 : ProvedSpan archivedGlobalCore rowAt 4480 4608 := by
  intro j hlo hhi
  have p0 : j < 6912 := by omega
  have p1 : ¬ j < 3456 := by omega
  have p2 : j < 5120 := by omega
  have p3 : ¬ j < 4224 := by omega
  have p4 : j < 4608 := by omega
  have p5 : ¬ j < 4352 := by omega
  have p6 : ¬ j < 4480 := by omega
  rw [rowAt, ite_eq_left p0, ite_eq_right p1, ite_eq_left p2, ite_eq_right p3, ite_eq_left p4, ite_eq_right p5, ite_eq_right p6]
  have hj : j - 4480 < 128 := by omega
  have hk : j - 4480 < originalBlock35.size := blockSize35.symm ▸ hj
  have result : archivedGlobalCore.proof ((originalBlock35[j - 4480]?).getD Sat.Clause.nil) :=
    @originalArrayRow archivedGlobalCore originalBlock35 (j - 4480) originalSubsumes35 hk
  have concrete : archivedGlobalCore.proof ((block35[j - 4480]?).getD Sat.Clause.nil) :=
    @transportArrayProof archivedGlobalCore originalBlock35 block35 (j - 4480) blockContent35 result
  exact concrete

theorem blockContent36 : originalBlock36 = block36 := rfl
theorem blockSize36 : originalBlock36.size = 128 := rfl
attribute [local irreducible] originalBlock36 block36
theorem originalSpan36 : ProvedSpan archivedGlobalCore rowAt 4608 4736 := by
  intro j hlo hhi
  have p0 : j < 6912 := by omega
  have p1 : ¬ j < 3456 := by omega
  have p2 : j < 5120 := by omega
  have p3 : ¬ j < 4224 := by omega
  have p4 : ¬ j < 4608 := by omega
  have p5 : j < 4864 := by omega
  have p6 : j < 4736 := by omega
  rw [rowAt, ite_eq_left p0, ite_eq_right p1, ite_eq_left p2, ite_eq_right p3, ite_eq_right p4, ite_eq_left p5, ite_eq_left p6]
  have hj : j - 4608 < 128 := by omega
  have hk : j - 4608 < originalBlock36.size := blockSize36.symm ▸ hj
  have result : archivedGlobalCore.proof ((originalBlock36[j - 4608]?).getD Sat.Clause.nil) :=
    @originalArrayRow archivedGlobalCore originalBlock36 (j - 4608) originalSubsumes36 hk
  have concrete : archivedGlobalCore.proof ((block36[j - 4608]?).getD Sat.Clause.nil) :=
    @transportArrayProof archivedGlobalCore originalBlock36 block36 (j - 4608) blockContent36 result
  exact concrete

theorem blockContent37 : originalBlock37 = block37 := rfl
theorem blockSize37 : originalBlock37.size = 128 := rfl
attribute [local irreducible] originalBlock37 block37
theorem originalSpan37 : ProvedSpan archivedGlobalCore rowAt 4736 4864 := by
  intro j hlo hhi
  have p0 : j < 6912 := by omega
  have p1 : ¬ j < 3456 := by omega
  have p2 : j < 5120 := by omega
  have p3 : ¬ j < 4224 := by omega
  have p4 : ¬ j < 4608 := by omega
  have p5 : j < 4864 := by omega
  have p6 : ¬ j < 4736 := by omega
  rw [rowAt, ite_eq_left p0, ite_eq_right p1, ite_eq_left p2, ite_eq_right p3, ite_eq_right p4, ite_eq_left p5, ite_eq_right p6]
  have hj : j - 4736 < 128 := by omega
  have hk : j - 4736 < originalBlock37.size := blockSize37.symm ▸ hj
  have result : archivedGlobalCore.proof ((originalBlock37[j - 4736]?).getD Sat.Clause.nil) :=
    @originalArrayRow archivedGlobalCore originalBlock37 (j - 4736) originalSubsumes37 hk
  have concrete : archivedGlobalCore.proof ((block37[j - 4736]?).getD Sat.Clause.nil) :=
    @transportArrayProof archivedGlobalCore originalBlock37 block37 (j - 4736) blockContent37 result
  exact concrete

theorem blockContent38 : originalBlock38 = block38 := rfl
theorem blockSize38 : originalBlock38.size = 128 := rfl
attribute [local irreducible] originalBlock38 block38
theorem originalSpan38 : ProvedSpan archivedGlobalCore rowAt 4864 4992 := by
  intro j hlo hhi
  have p0 : j < 6912 := by omega
  have p1 : ¬ j < 3456 := by omega
  have p2 : j < 5120 := by omega
  have p3 : ¬ j < 4224 := by omega
  have p4 : ¬ j < 4608 := by omega
  have p5 : ¬ j < 4864 := by omega
  have p6 : j < 4992 := by omega
  rw [rowAt, ite_eq_left p0, ite_eq_right p1, ite_eq_left p2, ite_eq_right p3, ite_eq_right p4, ite_eq_right p5, ite_eq_left p6]
  have hj : j - 4864 < 128 := by omega
  have hk : j - 4864 < originalBlock38.size := blockSize38.symm ▸ hj
  have result : archivedGlobalCore.proof ((originalBlock38[j - 4864]?).getD Sat.Clause.nil) :=
    @originalArrayRow archivedGlobalCore originalBlock38 (j - 4864) originalSubsumes38 hk
  have concrete : archivedGlobalCore.proof ((block38[j - 4864]?).getD Sat.Clause.nil) :=
    @transportArrayProof archivedGlobalCore originalBlock38 block38 (j - 4864) blockContent38 result
  exact concrete

theorem blockContent39 : originalBlock39 = block39 := rfl
theorem blockSize39 : originalBlock39.size = 128 := rfl
attribute [local irreducible] originalBlock39 block39
theorem originalSpan39 : ProvedSpan archivedGlobalCore rowAt 4992 5120 := by
  intro j hlo hhi
  have p0 : j < 6912 := by omega
  have p1 : ¬ j < 3456 := by omega
  have p2 : j < 5120 := by omega
  have p3 : ¬ j < 4224 := by omega
  have p4 : ¬ j < 4608 := by omega
  have p5 : ¬ j < 4864 := by omega
  have p6 : ¬ j < 4992 := by omega
  rw [rowAt, ite_eq_left p0, ite_eq_right p1, ite_eq_left p2, ite_eq_right p3, ite_eq_right p4, ite_eq_right p5, ite_eq_right p6]
  have hj : j - 4992 < 128 := by omega
  have hk : j - 4992 < originalBlock39.size := blockSize39.symm ▸ hj
  have result : archivedGlobalCore.proof ((originalBlock39[j - 4992]?).getD Sat.Clause.nil) :=
    @originalArrayRow archivedGlobalCore originalBlock39 (j - 4992) originalSubsumes39 hk
  have concrete : archivedGlobalCore.proof ((block39[j - 4992]?).getD Sat.Clause.nil) :=
    @transportArrayProof archivedGlobalCore originalBlock39 block39 (j - 4992) blockContent39 result
  exact concrete

end Euler.C14.Production
