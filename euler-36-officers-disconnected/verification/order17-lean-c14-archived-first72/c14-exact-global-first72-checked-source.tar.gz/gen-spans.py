from pathlib import Path
n=8825;width=128;blocks=109
def route(lo,hi,b):
 if hi-lo==1:return []
 m=(lo+hi)//2
 return [(m*width,b<m),*route(lo,m,b)] if b<m else [(m*width,False),*route(m,hi,b)]
def joined(lo,hi):
 if hi-lo==1:return f'originalSpan{lo}'
 m=(lo+hi)//2
 return f'(spanJoin {joined(lo,m)} {joined(m,hi)})'
archive=['import C14OriginalBlockDriverDraft','namespace Euler.C14.Production',
         'set_option maxRecDepth 18000','set_option maxHeartbeats 2600000',
         'original_blocks (include_str "c14-sorted-core.cnf")','attribute [irreducible] archivedGlobalCore','end Euler.C14.Production']
Path('C14OriginalExactArchiveDraft.lean').write_text('\n'.join(archive)+'\n')
for section in range(9):
 names=list(range(section*8,min((section+1)*8,69)))
 out=['import C14OriginalExactArchiveDraft','import C14OriginalGenericDraft',
      'namespace Euler.C14.Production','set_option maxRecDepth 18000',
      'set_option maxHeartbeats 2400000','']
 for b in names:
  lo=width*b;hi=min(lo+width,n)
  target=f'block{b}' if b<68 else f'(block68.extract 0 121)'
  out += [f'theorem blockContent{b} : originalBlock{b} = {target} := rfl',
          f'theorem blockSize{b} : originalBlock{b}.size = {hi-lo} := rfl',
          *( ['theorem finalBlockSize : block68.size = 128 := rfl'] if b == 68 else [] ),
          f'attribute [local irreducible] originalBlock{b} block{b}',
          f'theorem originalSpan{b} : ProvedSpan archivedGlobalCore rowAt {lo} {hi} := by',
          '  intro j hlo hhi']
  r=route(0,blocks,b)
  for i,(cut,left) in enumerate(r):
    ty=f'j < {cut}' if left else f'¬ j < {cut}'
    out.append(f'  have p{i} : {ty} := by omega')
  out.append('  rw [rowAt, '+', '.join(f'ite_eq_{"left" if left else "right"} p{i}' for i,(_,left) in enumerate(r))+']')
  out.append(f'  have hj : j - {lo} < {hi-lo} := by omega')
  out.append(f'  have hk : j - {lo} < originalBlock{b}.size := blockSize{b}.symm ▸ hj')
  out.append(f'  have result : archivedGlobalCore.proof ((originalBlock{b}[j - {lo}]?).getD Sat.Clause.nil) :=')
  out.append(f'    @originalArrayRow archivedGlobalCore originalBlock{b} (j - {lo}) originalSubsumes{b} hk')
  out.append(f'  have concrete : archivedGlobalCore.proof (({target}[j - {lo}]?).getD Sat.Clause.nil) :=')
  out.append(f'    @transportArrayProof archivedGlobalCore originalBlock{b} {target} (j - {lo}) blockContent{b} result')
  if b==68:
   out += ['  have hb : j - 8704 < min 121 128 - 0 := hj', '  rwa [Array.getElem?_extract, Nat.zero_add, finalBlockSize, ite_eq_left hb] at concrete']
  else: out.append('  exact concrete')
  out.append('')
 out.append('end Euler.C14.Production')
 Path(f'C14OriginalSpans{section:02}Draft.lean').write_text('\n'.join(out)+'\n')
out=[*[f'import C14OriginalSpans{i:02}Draft' for i in range(9)],
     'import C14GlobalFirstTwoDraft','namespace Euler.C14.Production',
     'open Euler.C14.IndexedDraft','set_option maxRecDepth 18000',
     'theorem exactSortedArchiveInitial : GoodBelow archivedGlobalCore rowAt 8825 :=',
     f'  prefixOfZeroSpan {joined(0,69)}',
     'theorem first48_fromExactGlobalArchive : GoodBelow archivedGlobalCore rowAt 8873 :=',
     '  first48 archivedGlobalCore exactSortedArchiveInitial',
     '#print axioms exactSortedArchiveInitial','#print axioms first48_fromExactGlobalArchive',
     'end Euler.C14.Production']
Path('C14OriginalPrefixDraft.lean').write_text('\n'.join(out)+'\n')
