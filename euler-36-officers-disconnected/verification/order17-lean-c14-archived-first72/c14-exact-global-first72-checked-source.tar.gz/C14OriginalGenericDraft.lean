import EulerC14IndexedDraft
import Lean.Elab.Tactic.Omega

namespace Euler.C14.Production
open Euler.C14.IndexedDraft

theorem originalArrayRow {core : Sat.Fmla} {xs : Array Sat.Clause} {i : Nat}
    (hblock : core.subsumes xs.toList) (hi : i < xs.size) :
    core.proof ((xs[i]?).getD Sat.Clause.nil) := by
  rw [Array.getElem?_eq_getElem hi]
  intro v hv
  exact hv.1 _ (hblock.1 _ (Array.getElem_mem_toList hi))

theorem transportArrayProof {core : Sat.Fmla} {xs ys : Array Sat.Clause} {i : Nat}
    (h : xs = ys) (p : core.proof ((xs[i]?).getD Sat.Clause.nil)) :
    core.proof ((ys[i]?).getD Sat.Clause.nil) := h ▸ p

def ProvedSpan (core : Sat.Fmla) (lookup : ClauseAt) (lo hi : Nat) : Prop :=
  ∀ i, lo ≤ i → i < hi → core.proof (lookup i)

theorem spanJoin {core : Sat.Fmla} {lookup : ClauseAt} {lo mid hi : Nat}
    (left : ProvedSpan core lookup lo mid) (right : ProvedSpan core lookup mid hi) :
    ProvedSpan core lookup lo hi := by
  intro i hlo hhi
  by_cases hmid : i < mid
  · exact left i hlo hmid
  · exact right i (Nat.le_of_not_gt hmid) hhi

theorem prefixOfZeroSpan {core : Sat.Fmla} {lookup : ClauseAt} {hi : Nat}
    (span : ProvedSpan core lookup 0 hi) :
    GoodBelow core lookup hi :=
  fun i hi => span i (Nat.zero_le i) hi

end Euler.C14.Production
