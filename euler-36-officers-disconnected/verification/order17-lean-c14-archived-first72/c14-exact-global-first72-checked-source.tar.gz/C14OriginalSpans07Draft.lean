import C14OriginalExactArchiveDraft
import C14OriginalGenericDraft
namespace Euler.C14.Production
set_option maxRecDepth 18000
set_option maxHeartbeats 2400000

theorem blockContent56 : originalBlock56 = block56 := rfl
theorem blockSize56 : originalBlock56.size = 128 := rfl
attribute [local irreducible] originalBlock56 block56
theorem originalSpan56 : ProvedSpan archivedGlobalCore rowAt 7168 7296 := by
  intro j hlo hhi
  have p0 : ¬ j < 6912 := by omega
  have p1 : j < 10368 := by omega
  have p2 : j < 8576 := by omega
  have p3 : j < 7680 := by omega
  have p4 : j < 7296 := by omega
  have p5 : ¬ j < 7040 := by omega
  have p6 : ¬ j < 7168 := by omega
  rw [rowAt, ite_eq_right p0, ite_eq_left p1, ite_eq_left p2, ite_eq_left p3, ite_eq_left p4, ite_eq_right p5, ite_eq_right p6]
  have hj : j - 7168 < 128 := by omega
  have hk : j - 7168 < originalBlock56.size := blockSize56.symm ▸ hj
  have result : archivedGlobalCore.proof ((originalBlock56[j - 7168]?).getD Sat.Clause.nil) :=
    @originalArrayRow archivedGlobalCore originalBlock56 (j - 7168) originalSubsumes56 hk
  have concrete : archivedGlobalCore.proof ((block56[j - 7168]?).getD Sat.Clause.nil) :=
    @transportArrayProof archivedGlobalCore originalBlock56 block56 (j - 7168) blockContent56 result
  exact concrete

theorem blockContent57 : originalBlock57 = block57 := rfl
theorem blockSize57 : originalBlock57.size = 128 := rfl
attribute [local irreducible] originalBlock57 block57
theorem originalSpan57 : ProvedSpan archivedGlobalCore rowAt 7296 7424 := by
  intro j hlo hhi
  have p0 : ¬ j < 6912 := by omega
  have p1 : j < 10368 := by omega
  have p2 : j < 8576 := by omega
  have p3 : j < 7680 := by omega
  have p4 : ¬ j < 7296 := by omega
  have p5 : j < 7424 := by omega
  rw [rowAt, ite_eq_right p0, ite_eq_left p1, ite_eq_left p2, ite_eq_left p3, ite_eq_right p4, ite_eq_left p5]
  have hj : j - 7296 < 128 := by omega
  have hk : j - 7296 < originalBlock57.size := blockSize57.symm ▸ hj
  have result : archivedGlobalCore.proof ((originalBlock57[j - 7296]?).getD Sat.Clause.nil) :=
    @originalArrayRow archivedGlobalCore originalBlock57 (j - 7296) originalSubsumes57 hk
  have concrete : archivedGlobalCore.proof ((block57[j - 7296]?).getD Sat.Clause.nil) :=
    @transportArrayProof archivedGlobalCore originalBlock57 block57 (j - 7296) blockContent57 result
  exact concrete

theorem blockContent58 : originalBlock58 = block58 := rfl
theorem blockSize58 : originalBlock58.size = 128 := rfl
attribute [local irreducible] originalBlock58 block58
theorem originalSpan58 : ProvedSpan archivedGlobalCore rowAt 7424 7552 := by
  intro j hlo hhi
  have p0 : ¬ j < 6912 := by omega
  have p1 : j < 10368 := by omega
  have p2 : j < 8576 := by omega
  have p3 : j < 7680 := by omega
  have p4 : ¬ j < 7296 := by omega
  have p5 : ¬ j < 7424 := by omega
  have p6 : j < 7552 := by omega
  rw [rowAt, ite_eq_right p0, ite_eq_left p1, ite_eq_left p2, ite_eq_left p3, ite_eq_right p4, ite_eq_right p5, ite_eq_left p6]
  have hj : j - 7424 < 128 := by omega
  have hk : j - 7424 < originalBlock58.size := blockSize58.symm ▸ hj
  have result : archivedGlobalCore.proof ((originalBlock58[j - 7424]?).getD Sat.Clause.nil) :=
    @originalArrayRow archivedGlobalCore originalBlock58 (j - 7424) originalSubsumes58 hk
  have concrete : archivedGlobalCore.proof ((block58[j - 7424]?).getD Sat.Clause.nil) :=
    @transportArrayProof archivedGlobalCore originalBlock58 block58 (j - 7424) blockContent58 result
  exact concrete

theorem blockContent59 : originalBlock59 = block59 := rfl
theorem blockSize59 : originalBlock59.size = 128 := rfl
attribute [local irreducible] originalBlock59 block59
theorem originalSpan59 : ProvedSpan archivedGlobalCore rowAt 7552 7680 := by
  intro j hlo hhi
  have p0 : ¬ j < 6912 := by omega
  have p1 : j < 10368 := by omega
  have p2 : j < 8576 := by omega
  have p3 : j < 7680 := by omega
  have p4 : ¬ j < 7296 := by omega
  have p5 : ¬ j < 7424 := by omega
  have p6 : ¬ j < 7552 := by omega
  rw [rowAt, ite_eq_right p0, ite_eq_left p1, ite_eq_left p2, ite_eq_left p3, ite_eq_right p4, ite_eq_right p5, ite_eq_right p6]
  have hj : j - 7552 < 128 := by omega
  have hk : j - 7552 < originalBlock59.size := blockSize59.symm ▸ hj
  have result : archivedGlobalCore.proof ((originalBlock59[j - 7552]?).getD Sat.Clause.nil) :=
    @originalArrayRow archivedGlobalCore originalBlock59 (j - 7552) originalSubsumes59 hk
  have concrete : archivedGlobalCore.proof ((block59[j - 7552]?).getD Sat.Clause.nil) :=
    @transportArrayProof archivedGlobalCore originalBlock59 block59 (j - 7552) blockContent59 result
  exact concrete

theorem blockContent60 : originalBlock60 = block60 := rfl
theorem blockSize60 : originalBlock60.size = 128 := rfl
attribute [local irreducible] originalBlock60 block60
theorem originalSpan60 : ProvedSpan archivedGlobalCore rowAt 7680 7808 := by
  intro j hlo hhi
  have p0 : ¬ j < 6912 := by omega
  have p1 : j < 10368 := by omega
  have p2 : j < 8576 := by omega
  have p3 : ¬ j < 7680 := by omega
  have p4 : j < 8064 := by omega
  have p5 : j < 7808 := by omega
  rw [rowAt, ite_eq_right p0, ite_eq_left p1, ite_eq_left p2, ite_eq_right p3, ite_eq_left p4, ite_eq_left p5]
  have hj : j - 7680 < 128 := by omega
  have hk : j - 7680 < originalBlock60.size := blockSize60.symm ▸ hj
  have result : archivedGlobalCore.proof ((originalBlock60[j - 7680]?).getD Sat.Clause.nil) :=
    @originalArrayRow archivedGlobalCore originalBlock60 (j - 7680) originalSubsumes60 hk
  have concrete : archivedGlobalCore.proof ((block60[j - 7680]?).getD Sat.Clause.nil) :=
    @transportArrayProof archivedGlobalCore originalBlock60 block60 (j - 7680) blockContent60 result
  exact concrete

theorem blockContent61 : originalBlock61 = block61 := rfl
theorem blockSize61 : originalBlock61.size = 128 := rfl
attribute [local irreducible] originalBlock61 block61
theorem originalSpan61 : ProvedSpan archivedGlobalCore rowAt 7808 7936 := by
  intro j hlo hhi
  have p0 : ¬ j < 6912 := by omega
  have p1 : j < 10368 := by omega
  have p2 : j < 8576 := by omega
  have p3 : ¬ j < 7680 := by omega
  have p4 : j < 8064 := by omega
  have p5 : ¬ j < 7808 := by omega
  have p6 : j < 7936 := by omega
  rw [rowAt, ite_eq_right p0, ite_eq_left p1, ite_eq_left p2, ite_eq_right p3, ite_eq_left p4, ite_eq_right p5, ite_eq_left p6]
  have hj : j - 7808 < 128 := by omega
  have hk : j - 7808 < originalBlock61.size := blockSize61.symm ▸ hj
  have result : archivedGlobalCore.proof ((originalBlock61[j - 7808]?).getD Sat.Clause.nil) :=
    @originalArrayRow archivedGlobalCore originalBlock61 (j - 7808) originalSubsumes61 hk
  have concrete : archivedGlobalCore.proof ((block61[j - 7808]?).getD Sat.Clause.nil) :=
    @transportArrayProof archivedGlobalCore originalBlock61 block61 (j - 7808) blockContent61 result
  exact concrete

theorem blockContent62 : originalBlock62 = block62 := rfl
theorem blockSize62 : originalBlock62.size = 128 := rfl
attribute [local irreducible] originalBlock62 block62
theorem originalSpan62 : ProvedSpan archivedGlobalCore rowAt 7936 8064 := by
  intro j hlo hhi
  have p0 : ¬ j < 6912 := by omega
  have p1 : j < 10368 := by omega
  have p2 : j < 8576 := by omega
  have p3 : ¬ j < 7680 := by omega
  have p4 : j < 8064 := by omega
  have p5 : ¬ j < 7808 := by omega
  have p6 : ¬ j < 7936 := by omega
  rw [rowAt, ite_eq_right p0, ite_eq_left p1, ite_eq_left p2, ite_eq_right p3, ite_eq_left p4, ite_eq_right p5, ite_eq_right p6]
  have hj : j - 7936 < 128 := by omega
  have hk : j - 7936 < originalBlock62.size := blockSize62.symm ▸ hj
  have result : archivedGlobalCore.proof ((originalBlock62[j - 7936]?).getD Sat.Clause.nil) :=
    @originalArrayRow archivedGlobalCore originalBlock62 (j - 7936) originalSubsumes62 hk
  have concrete : archivedGlobalCore.proof ((block62[j - 7936]?).getD Sat.Clause.nil) :=
    @transportArrayProof archivedGlobalCore originalBlock62 block62 (j - 7936) blockContent62 result
  exact concrete

theorem blockContent63 : originalBlock63 = block63 := rfl
theorem blockSize63 : originalBlock63.size = 128 := rfl
attribute [local irreducible] originalBlock63 block63
theorem originalSpan63 : ProvedSpan archivedGlobalCore rowAt 8064 8192 := by
  intro j hlo hhi
  have p0 : ¬ j < 6912 := by omega
  have p1 : j < 10368 := by omega
  have p2 : j < 8576 := by omega
  have p3 : ¬ j < 7680 := by omega
  have p4 : ¬ j < 8064 := by omega
  have p5 : j < 8320 := by omega
  have p6 : j < 8192 := by omega
  rw [rowAt, ite_eq_right p0, ite_eq_left p1, ite_eq_left p2, ite_eq_right p3, ite_eq_right p4, ite_eq_left p5, ite_eq_left p6]
  have hj : j - 8064 < 128 := by omega
  have hk : j - 8064 < originalBlock63.size := blockSize63.symm ▸ hj
  have result : archivedGlobalCore.proof ((originalBlock63[j - 8064]?).getD Sat.Clause.nil) :=
    @originalArrayRow archivedGlobalCore originalBlock63 (j - 8064) originalSubsumes63 hk
  have concrete : archivedGlobalCore.proof ((block63[j - 8064]?).getD Sat.Clause.nil) :=
    @transportArrayProof archivedGlobalCore originalBlock63 block63 (j - 8064) blockContent63 result
  exact concrete

end Euler.C14.Production
