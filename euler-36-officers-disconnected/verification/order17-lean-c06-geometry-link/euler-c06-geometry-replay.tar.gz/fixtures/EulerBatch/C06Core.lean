import EulerBatch.FactoredDriver
namespace Euler.Batch.C06
factored_rup coreUnsat (include_str "cases/06/core.cnf") (include_str "cases/06/core.lrat")
#print axioms coreUnsat
end Euler.Batch.C06
