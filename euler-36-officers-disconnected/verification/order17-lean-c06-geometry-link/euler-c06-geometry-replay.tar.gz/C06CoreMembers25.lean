import C06RawFactored
import C06Codes

namespace LatinGap.PairEncoding.C06Linked
open Euler.C06RawFactored

theorem chunk_mem100 : ∀ c ∈ chunk100, c ∈ archiveAllUsedCNF codes := by
  unfold chunk100
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 59 97 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 92 106 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 37 72 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 59 99 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 59 22 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 59 100 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 93 106 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 131 100 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 165 106 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 59 102 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 59 23 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 94 24 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 59 103 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 94 106 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 131 103 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 166 106 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 215 99 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 180 102 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 181 102 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 54 27 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 54 28 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 54 29 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 54 30 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 90 26 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 187 37 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 187 42 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 187 102 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 188 102 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 55 28 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 55 118 rfl, ?_⟩
  simp

theorem chunk_mem101 : ∀ c ∈ chunk101, c ∈ archiveAllUsedCNF codes := by
  unfold chunk101
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 55 29 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 55 121 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 55 30 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 55 124 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 192 102 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 187 41 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 91 114 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 91 27 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 91 115 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 187 44 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 187 47 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 187 50 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 187 53 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 187 56 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 187 59 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 187 62 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 187 65 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 187 68 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 187 71 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 187 74 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 187 77 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 187 80 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 187 83 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 187 86 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 187 89 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 187 92 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 187 95 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 187 98 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 187 101 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 93 114 rfl, ?_⟩
  simp

theorem chunk_mem102 : ∀ c ∈ chunk102, c ∈ archiveAllUsedCNF codes := by
  unfold chunk102
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 187 104 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 187 107 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 187 110 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 187 113 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 187 116 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 187 119 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 187 122 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 187 125 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 187 128 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 187 131 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 94 114 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 187 134 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 187 137 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 188 44 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 188 47 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 188 50 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 188 56 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 188 43 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 188 59 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 188 62 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 188 65 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 188 68 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 188 71 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 188 74 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 188 77 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 188 80 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 188 83 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 188 86 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 90 28 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 188 89 rfl, ?_⟩
  simp

theorem chunk_mem103 : ∀ c ∈ chunk103, c ∈ archiveAllUsedCNF codes := by
  unfold chunk103
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 188 92 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 188 95 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 188 98 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 188 101 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 188 104 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 188 107 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 188 110 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 188 113 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 188 116 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 91 117 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 91 28 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 91 118 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 188 119 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 188 122 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 188 125 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 188 128 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 188 131 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 188 134 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 188 137 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 93 117 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 94 117 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 90 29 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 91 120 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 91 29 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 91 121 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 37 81 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 93 120 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 94 120 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 90 30 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 192 47 rfl, ?_⟩
  simp

end LatinGap.PairEncoding.C06Linked
