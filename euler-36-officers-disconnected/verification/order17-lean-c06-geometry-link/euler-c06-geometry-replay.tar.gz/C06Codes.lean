import ArchiveCoreBlocks

namespace LatinGap.PairEncoding.C06Linked

def codes : List ℕ := [111,1012,2201,1220]

end LatinGap.PairEncoding.C06Linked
