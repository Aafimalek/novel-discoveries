#!/usr/bin/env python3
"""Plan exact ordered signed-row witnesses for a size-17 all-used core."""
import argparse
from collections import Counter
from itertools import product
from pathlib import Path
import gzip
import json
import re

p = argparse.ArgumentParser(description=__doc__)
p.add_argument('--original', required=True, type=Path)
p.add_argument('--core', required=True, type=Path)
p.add_argument('--codes', required=True, help='Comma-separated four decimal diagram codes')
p.add_argument('--bridge', required=True, help='Lean bridge basename, e.g. C05 or Pilot')
p.add_argument('--core-module', required=True, help='Exact existing checker module')
p.add_argument('--core-theorem', required=True, help='Exact UNSAT identifier with .cnf companion')
p.add_argument('--out', required=True, type=Path)
a = p.parse_args()

lean_name = re.compile(r'[A-Za-z_][A-Za-z_0-9]*(\.[A-Za-z_][A-Za-z_0-9]*)*\Z')
for key in (a.bridge, a.core_module, a.core_theorem):
    if not lean_name.fullmatch(key):
        p.error(f'invalid Lean name {key!r}')
if '.' in a.bridge:
    p.error('--bridge must be an unqualified Lean basename')
codes = [int(x) for x in a.codes.split(',')]
if len(codes)!=4 or any(c<0 or c>=6000 or any(int(d)>5 for d in str(c)) for c in codes):
    p.error('codes must be four decimal words on the symbols 0..5')

def read_dimacs(path):
    op = gzip.open if path.suffix=='.gz' else open
    with op(path,'rt',encoding='ascii') as source:
        header=None
        pending=[]
        clauses=[]
        for line in source:
            fields=line.split()
            if not fields or fields[0]=='c':
                continue
            if fields[0]=='p':
                assert header is None and len(fields)==4 and fields[1]=='cnf', (path,line)
                header=tuple(map(int,fields[2:]))
                continue
            assert header is not None,(path,'clause before header')
            for token in fields:
                lit=int(token)
                assert abs(lit)<=header[0],(path,'literal exceeds variable bound', lit)
                if lit==0:
                    clauses.append(tuple(pending))
                    pending=[]
                else:
                    pending.append(lit)
        assert not pending and header is not None and len(clauses)==header[1], (path,header)
        return header,clauses

original_header, original = read_dimacs(a.original)
core_header, core = read_dimacs(a.core)
if original_header[0] != 10646 or core_header[0] != original_header[0]:
    p.error('not the size-17 all-used 10646-variable numbering')

recipes=[]
def block(name,size,*params):
    recipes.extend((name,params,j) for j in range(size))
def counter(name,m,k,*params):
    for i in range(m):
        block(name,1+k*(2 if i+1<m else 1),*params,i)

def prefix(g):
    return max(1,*(c//10**(3-g)%10 for c in codes))+1

degree_pairs=[]
block('saturation',1296)
for pair in range(216):
    block('support',141,pair)
counter('projectionLo',17,19)
counter('projectionHi',19,17)
block('anchors',2)
for g, label in product(range(4),range(6)):
    for bits in range(64):
        count=bits.bit_count()
        block('degreeRow',5 if (count==2 if g==label==0 else count>=2) else 1,g,label,bits)
    block('degreeUnits',2,g,label)
for g in range(4):
    degree_pairs.extend((g,l,l+1) for l in range(max(1 if g==0 else 2,prefix(g)),5))
    if g==1: degree_pairs.append((g,0,1))
for pair in degree_pairs:
    block('degreeOrder',4,*pair)
block('saturation',1296)
for g in range(4):
    counter('excessLo',5,19,g)
    counter('excessHi',19,5,g)
block('pins',28)
for rec in product(range(6),range(2),range(6),range(6),range(6),range(6)):
    block('rectangle',1,*rec)
for g in range(4):
    for label in range(prefix(g),5):
        for k in range(6):
            for bits in range(2**k):
                block('lex',5,g,label,k,bits)
if len(recipes)!=len(original):
    p.error(f'diagram codes predict {len(recipes)} original rows, found {len(original)}')

known={'saturation','support','anchors','degreeRow','degreeOrder','excessHi','excessLo',
       'pins','lex','projectionLo','projectionHi'}
by_exact={}
for pos,(clause,rec) in enumerate(zip(original,recipes)):
    if clause not in by_exact:
        by_exact[clause]=pos
    elif rec[0] in known and recipes[by_exact[clause]][0] not in known:
        by_exact[clause]=pos
rows=[]
unresolved=[]
for j,clause in enumerate(core):
    i=by_exact.get(clause)
    if i is None:
        unresolved.append((j,'no exact ordered original row'))
        continue
    name,params,idx=recipes[i]
    if name not in known:
        unresolved.append((j,name))
        continue
    rows.append((clause,name,params,idx,original[i],i))
if unresolved:
    p.error(f'{len(unresolved)} unresolved rows: {dict(Counter(k for _,k in unresolved))}; first {unresolved[:8]}')
a.out.mkdir(parents=True,exist_ok=True)
(a.out/'plan.json').write_text(json.dumps(rows)+'\n')
(a.out/'case.json').write_text(json.dumps(dict(bridgeName=a.bridge,coreModule=a.core_module,
    coreTheorem=a.core_theorem,codes=codes,degreeOrderPairs=degree_pairs,
    originalRows=len(original),coreRows=len(core)),indent=2)+'\n')
print(f'{a.bridge}: {len(rows)} of {len(core)} ordered signed rows; {dict(Counter(r[1] for r in rows))}')
