#!/usr/bin/env bash
# All arguments go to plan.py; include --out DIR.
set -euo pipefail
BASE=$(cd "$(dirname "$0")" && pwd)
out=
last=
for word; do
  if [[ "$last" == --out ]]; then out=$word; fi
  last=$word
done
[[ -n "$out" ]] || { echo 'Pass --out DIR (a separate argument)' >&2; exit 2; }
python3 "$BASE/plan.py" "$@"
cd "$out"
python3 "$BASE/verify-recipe-arithmetic.py"
python3 "$BASE/gen-factored.py"
