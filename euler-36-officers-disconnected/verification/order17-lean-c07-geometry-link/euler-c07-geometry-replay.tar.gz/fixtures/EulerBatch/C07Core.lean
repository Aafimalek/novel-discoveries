import EulerBatch.FactoredDriver
namespace Euler.Batch.C07
factored_rup coreUnsat (include_str "cases/07/core.cnf") (include_str "cases/07/core.lrat")
#print axioms coreUnsat
end Euler.Batch.C07
