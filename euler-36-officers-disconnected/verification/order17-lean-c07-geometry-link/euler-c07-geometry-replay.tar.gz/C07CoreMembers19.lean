import C07RawFactored
import C07Codes

namespace LatinGap.PairEncoding.C07Linked
open Euler.C07RawFactored

theorem chunk_mem76 : ∀ c ∈ chunk76, c ∈ archiveAllUsedCNF codes := by
  unfold chunk76
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 96 12 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 96 14 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 96 16 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 96 17 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 96 18 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 96 26 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 96 28 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 96 29 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 96 30 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 96 32 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 96 34 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 96 35 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 96 36 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 97 22 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 97 23 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 97 24 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 97 27 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 97 28 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 97 29 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 97 30 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 97 33 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 97 34 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 97 35 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 97 36 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 97 100 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 97 101 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 97 103 rfl, ?_⟩
  simp

theorem chunk_mem77 : ∀ c ∈ chunk77, c ∈ archiveAllUsedCNF codes := by
  unfold chunk77
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 97 104 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 97 105 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 97 106 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 97 107 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 97 110 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 97 113 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 97 114 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 97 115 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 97 116 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 97 117 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 97 118 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 97 119 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 97 120 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 97 121 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 97 122 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 97 123 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 97 124 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 97 125 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 97 128 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 97 131 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 97 132 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 97 133 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 97 134 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 97 135 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 97 136 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 97 137 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 97 138 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 97 140 rfl, ?_⟩
  simp

theorem chunk_mem78 : ∀ c ∈ chunk78, c ∈ archiveAllUsedCNF codes := by
  unfold chunk78
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 99 118 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 99 120 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 101 118 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 101 120 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 102 10 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 102 11 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 102 12 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 102 14 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 102 16 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 102 17 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 102 18 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 102 26 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 102 28 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 102 29 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 102 30 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 102 32 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 102 34 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 102 35 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 102 36 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 103 22 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 103 23 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 103 24 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 103 27 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 103 28 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 103 29 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 103 30 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 103 33 rfl, ?_⟩
  simp

theorem chunk_mem79 : ∀ c ∈ chunk79, c ∈ archiveAllUsedCNF codes := by
  unfold chunk79
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 103 34 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 103 35 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 103 36 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 103 100 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 103 101 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 103 103 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 103 104 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 103 105 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 103 106 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 103 107 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 103 110 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 103 113 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 103 114 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 103 115 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 103 116 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 103 117 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 103 118 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 103 119 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 103 120 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 103 121 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 103 122 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 103 123 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 103 124 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 103 125 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 103 128 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 103 131 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 103 132 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 103 133 rfl, ?_⟩
  simp

end LatinGap.PairEncoding.C07Linked
