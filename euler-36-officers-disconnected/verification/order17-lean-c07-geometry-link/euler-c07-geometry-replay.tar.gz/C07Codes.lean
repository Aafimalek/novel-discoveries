import ArchiveCoreBlocks

namespace LatinGap.PairEncoding.C07Linked

def codes : List ℕ := [111,1012,1201,2320]

end LatinGap.PairEncoding.C07Linked
