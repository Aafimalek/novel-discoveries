import C02RawFactored
import C02Blocks

namespace LatinGap.PairEncoding.C02Blocks
open Euler.C02RawFactored

theorem chunk_mem16 : ∀ c ∈ chunk16, c ∈ archiveAllUsedCNF codes := by
  unfold chunk16
  refine List.forall_mem_cons.mpr ⟨support 157 74 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 157 75 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 157 77 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 157 80 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 157 83 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 157 86 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 157 89 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 157 92 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 157 93 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 157 95 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 157 98 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 157 101 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 157 104 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 157 107 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 157 110 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 157 111 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 157 113 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 157 116 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 157 119 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 157 122 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 157 125 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 157 129 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 162 0 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 168 0 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 174 0 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 180 37 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 180 38 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 180 41 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 180 42 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 180 44 rfl, ?_⟩
  simp

theorem chunk_mem17 : ∀ c ∈ chunk17, c ∈ archiveAllUsedCNF codes := by
  unfold chunk17
  refine List.forall_mem_cons.mpr ⟨support 180 45 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 180 47 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 180 48 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 180 50 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 180 51 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 180 53 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 180 56 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 180 59 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 180 62 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 180 65 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 180 66 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 180 68 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 180 69 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 180 71 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 180 74 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 180 77 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 180 80 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 180 81 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 180 83 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 180 84 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 180 86 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 180 87 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 180 89 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 180 92 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 180 95 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 180 98 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 180 99 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 180 101 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 180 102 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 180 104 rfl, ?_⟩
  simp

theorem chunk_mem18 : ∀ c ∈ chunk18, c ∈ archiveAllUsedCNF codes := by
  unfold chunk18
  refine List.forall_mem_cons.mpr ⟨support 180 105 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 180 107 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 180 110 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 180 113 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 180 116 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 180 117 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 180 119 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 180 120 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 180 122 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 180 123 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 180 125 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 180 128 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 180 131 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 180 134 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 180 135 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 180 137 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 180 138 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 180 140 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 186 0 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 187 40 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 187 41 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 187 42 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 187 44 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 187 45 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 187 47 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 187 48 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 187 50 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 187 51 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 187 53 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 187 56 rfl, ?_⟩
  simp

theorem chunk_mem19 : ∀ c ∈ chunk19, c ∈ archiveAllUsedCNF codes := by
  unfold chunk19
  refine List.forall_mem_cons.mpr ⟨support 187 59 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 187 62 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 187 65 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 187 66 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 187 68 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 187 69 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 187 71 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 187 74 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 187 77 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 187 80 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 187 81 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 187 83 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 187 84 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 187 86 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 187 87 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 187 89 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 187 92 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 187 95 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 187 98 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 187 99 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 187 101 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 187 102 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 187 104 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 187 105 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 187 107 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 187 110 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 187 113 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 187 116 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 187 117 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 187 119 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 187 120 rfl, ?_⟩
  simp

end LatinGap.PairEncoding.C02Blocks
