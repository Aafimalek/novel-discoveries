import C02RawFactored
import C02Blocks

namespace LatinGap.PairEncoding.C02Blocks
open Euler.C02RawFactored

theorem chunk_mem00 : ∀ c ∈ chunk00, c ∈ archiveAllUsedCNF codes := by
  unfold chunk00
  refine List.forall_mem_cons.mpr ⟨saturation 726 (by decide) rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨saturation 942 (by decide) rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨saturation 978 (by decide) rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨saturation 1014 (by decide) rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨saturation 1158 (by decide) rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨saturation 1230 (by decide) rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 0 1 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 1 8 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 1 55 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 1 57 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 6 9 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 6 55 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 6 56 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 6 60 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 7 13 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 8 2 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 8 37 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 8 39 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 8 40 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 8 41 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 8 44 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 8 47 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 8 50 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 8 53 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 8 54 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 8 56 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 8 59 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 8 62 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 8 63 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 8 65 rfl, ?_⟩
  simp

theorem chunk_mem01 : ∀ c ∈ chunk01, c ∈ archiveAllUsedCNF codes := by
  unfold chunk01
  refine List.forall_mem_cons.mpr ⟨support 8 66 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 8 69 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 14 7 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 14 10 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 14 11 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 14 12 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 14 19 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 14 25 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 14 31 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 20 10 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 20 11 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 20 12 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 21 10 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 21 11 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 21 12 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 37 8 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 37 58 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 37 59 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 37 62 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 37 65 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 37 68 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 37 71 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 37 72 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 37 74 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 37 77 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 37 80 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 37 81 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 37 83 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 37 84 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 37 86 rfl, ?_⟩
  simp

theorem chunk_mem02 : ∀ c ∈ chunk02, c ∈ archiveAllUsedCNF codes := by
  unfold chunk02
  refine List.forall_mem_cons.mpr ⟨support 37 87 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 37 89 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 37 90 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 37 92 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 37 95 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 37 98 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 37 99 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 37 101 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 37 102 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 37 104 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 37 105 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 37 107 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 37 108 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 37 110 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 37 113 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 37 116 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 37 117 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 37 119 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 37 120 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 37 122 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 37 123 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 37 125 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 37 126 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 37 128 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 37 131 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 37 134 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 37 135 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 37 137 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 37 138 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 37 140 rfl, ?_⟩
  simp

theorem chunk_mem03 : ∀ c ∈ chunk03, c ∈ archiveAllUsedCNF codes := by
  unfold chunk03
  refine List.forall_mem_cons.mpr ⟨support 42 76 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 42 77 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 42 80 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 42 83 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 42 86 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 42 90 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 43 3 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 43 43 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 43 44 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 43 47 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 43 50 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 43 53 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 43 56 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 43 59 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 43 62 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 43 65 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 43 68 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 43 71 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 43 74 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 43 77 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 43 80 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 43 83 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 43 86 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 43 89 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 43 92 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 43 95 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 43 98 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 43 99 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 43 101 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 43 102 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 43 104 rfl, ?_⟩
  simp

end LatinGap.PairEncoding.C02Blocks
