import EulerAllUsedFullGeometry

set_option maxRecDepth 12000
set_option maxHeartbeats 0
namespace LatinGap.PairEncoding.C02Blocks

def codes : List ℕ := [111,1012,1201,1120]

private theorem inNonLex {c : List ℤ} (h : c ∈ archiveAllUsedNonLex codes) :
    c ∈ archiveAllUsedCNF codes := List.mem_append.mpr (.inl h)

private theorem inLex {c : List ℤ} (h : c ∈ archiveAllUsedLex codes) :
    c ∈ archiveAllUsedCNF codes := List.mem_append.mpr (.inr h)

private theorem inSupportPrefix {c : List ℤ} (h : c ∈ archivedSupportPrefix) :
    c ∈ archiveAllUsedCNF codes := by
  apply inNonLex
  simp only [archiveAllUsedNonLex,List.mem_append]
  tauto

def pairAt (p : ℕ) : PairKey 6 :=
  let ij := (archivedCoordPairs[p/36]?).getD ⟨(0,1),by decide⟩
  ⟨ij.val.1,ij.val.2,ij.prop,⟨p/6%6,by omega⟩,⟨p%6,by omega⟩⟩

private theorem pairAt_mem (p : ℕ) : pairAt p ∈ archivedPairKeys := by
  let ij := (archivedCoordPairs[p/36]?).getD ⟨(0,1),by decide⟩
  let a : Fin 6 := ⟨p/6%6,by omega⟩
  let b : Fin 6 := ⟨p%6,by omega⟩
  apply List.mem_flatMap.mpr
  refine ⟨ij,archivedCoordPairs_complete ij,?_⟩
  apply List.mem_flatMap.mpr
  refine ⟨a,List.mem_ofFn.mpr ⟨a,rfl⟩,?_⟩
  exact List.mem_map.mpr ⟨b,List.mem_ofFn.mpr ⟨b,rfl⟩,rfl⟩

theorem support {c : List ℤ} (p j : ℕ)
    (e : (archiveSupportBlock (pairAt p))[j]? = some c) :
    c ∈ archiveAllUsedCNF codes := by
  apply inSupportPrefix
  exact List.mem_append.mpr (.inr (List.mem_flatMap.mpr
    ⟨pairAt p,pairAt_mem p,List.mem_of_getElem? e⟩))

theorem saturation {c : List ℤ} (i : ℕ) (hi : i < 1296)
    (e : archivedCandidateNumbered (wordAtOrdinal i) = c) : c ∈ archiveAllUsedCNF codes := by
  apply inSupportPrefix
  exact List.mem_append.mpr (.inl (List.mem_map.mpr ⟨i,List.mem_range.mpr hi,e⟩))

theorem anchors {c : List ℤ} (j : ℕ)
    (e : archiveAllUsedAnchorUnits[j]? = some c) : c ∈ archiveAllUsedCNF codes := by
  apply inNonLex
  have h := List.mem_of_getElem? e
  simp only [archiveAllUsedNonLex,List.mem_append]
  tauto

theorem pins {c : List ℤ} (j : ℕ)
    (e : (archiveAllUsedPinProfile codes)[j]? = some c) : c ∈ archiveAllUsedCNF codes := by
  apply inNonLex
  have h := List.mem_of_getElem? e
  simp only [archiveAllUsedNonLex,List.mem_append]
  tauto

theorem degreeOrder {c : List ℤ} (j : ℕ)
    (e : (archiveAllUsedDegreeOrder codes)[j]? = some c) : c ∈ archiveAllUsedCNF codes := by
  apply inNonLex
  have h := List.mem_of_getElem? e
  simp only [archiveAllUsedNonLex,List.mem_append]
  tauto

theorem degreeRow {c : List ℤ} (g : Coord) (a : Fin 6) (p j : ℕ) (hp : p < 64)
    (e : (LatinGap.PairEncoding.degreeRow 2 g a (degreePattern p))[j]? = some c) :
    c ∈ archiveAllUsedCNF codes := by
  have hrow : c ∈ degreeBlock 2 g a := List.mem_append.mpr (.inl
    (List.mem_flatMap.mpr ⟨p,List.mem_range.mpr hp,List.mem_of_getElem? e⟩))
  have hd : c ∈ archiveAllUsedDegreeBlock := List.mem_flatMap.mpr
    ⟨g,List.mem_ofFn.mpr ⟨g,rfl⟩,
      List.mem_flatMap.mpr ⟨a,List.mem_ofFn.mpr ⟨a,rfl⟩,hrow⟩⟩
  apply inNonLex
  simp only [archiveAllUsedNonLex,List.mem_append]
  tauto

def counterRow (m k base : ℕ) (idx : ℕ → ℕ) (sign : Bool) (r : ℕ) : List (List ℤ) :=
  let l (i : ℕ) := literal (idx i) (!sign)
  let s (u j : ℕ) (sg : Bool) := literal (numericStateNumber base k u j) sg
  [l r, s r 0 true] ::
    ((List.range k).flatMap fun j =>
      (if r+1<m then [[s r j false, s (r+1) j true]] else []) ++
      if j+1<k then [[l (r+j+1), s r j false, s r (j+1) true]]
      else [[l (r+k), s r j false]])

theorem excessHi {c : List ℤ} (g : Coord) (r j : ℕ) (hr : r < 19)
    (e : (counterRow 19 5 (9982+190*g.val) (degreeExcessCounterId g) true r)[j]? = some c) :
    c ∈ archiveAllUsedCNF codes := by
  have hcnt : c ∈ numericSequentialBlock 19 5 (9982+190*g.val) (degreeExcessCounterId g) true :=
    List.mem_flatMap.mpr ⟨r,List.mem_range.mpr hr,List.mem_of_getElem? e⟩
  have he : c ∈ ((List.ofFn fun g : Coord => g).flatMap archiveDegreeExcessCountBlock) :=
    List.mem_flatMap.mpr ⟨g,List.mem_ofFn.mpr ⟨g,rfl⟩,List.mem_append.mpr (.inr hcnt)⟩
  apply inNonLex
  simp only [archiveAllUsedNonLex,List.mem_append]
  tauto

theorem lex {c : List ℤ} (g : Coord) (a b k : Fin 6) (bits : ℕ) (d : Fin 7)
    (ab : (a,b) ∈ archiveLexLabelPairs codes g) (hb : bits < 2 ^ k.val)
    (hd : 2 ≤ d.val) (e : archiveMinTwoLexClause g a b k bits d = c) :
    c ∈ archiveAllUsedCNF codes := by
  apply inLex
  apply List.mem_flatMap.mpr
  refine ⟨g,List.mem_ofFn.mpr ⟨g,rfl⟩,?_⟩
  apply List.mem_flatMap.mpr
  refine ⟨(a,b),ab,?_⟩
  apply List.mem_flatMap.mpr
  refine ⟨k,List.mem_ofFn.mpr ⟨k,rfl⟩,?_⟩
  apply List.mem_flatMap.mpr
  refine ⟨bits,List.mem_range.mpr hb,?_⟩
  apply List.mem_map.mpr
  refine ⟨d,?_,e⟩
  exact List.mem_filter.mpr ⟨List.mem_ofFn.mpr ⟨d,rfl⟩,decide_eq_true hd⟩

/-- Representative literal checks for each of the eight needed clause families. -/
theorem testSat : [1317,1352,1387,1418,1453,1483] ∈ archiveAllUsedCNF codes :=
  saturation 726 (by decide) rfl
theorem testSupport : [-1,1297] ∈ archiveAllUsedCNF codes := support 0 1 rfl
theorem testSupportLate : [-192,-2842] ∈ archiveAllUsedCNF codes := support 37 140 rfl
theorem testDegreeOrder : [-9765,9772] ∈ archiveAllUsedCNF codes := degreeOrder 21 rfl
theorem testAnchor : [1] ∈ archiveAllUsedCNF codes := anchors 0 rfl
theorem testDegree : [-1297,-1298,1299,1300,1301,-1302] ∈ archiveAllUsedCNF codes :=
  degreeRow 0 0 49 0 (by decide) rfl
theorem testExcess : [-9729,10002] ∈ archiveAllUsedCNF codes :=
  excessHi 0 4 0 (by decide) rfl
theorem testPins : [225] ∈ archiveAllUsedCNF codes := pins 1 rfl
theorem testLex : [-9736,9744,-1309,1315] ∈ archiveAllUsedCNF codes :=
  lex 0 2 3 0 0 3 (by decide) (by decide) (by decide) rfl

#print axioms support
#print axioms testExcess
#print axioms testLex

end LatinGap.PairEncoding.C02Blocks
