#!/usr/bin/env bash
# Set LEAN_BIN and LEAN_PATH to the matching Lean, Mathlib, and Euler project.
# The existing Euler dependency layout needs all its transitive .oleans.
set -euo pipefail
cd "$(dirname -- "$0")"
ROOT=$PWD
export LEAN_PATH="$ROOT:$ROOT/fixtures${LEAN_PATH:+:$LEAN_PATH}"
LEAN_BIN="${LEAN_BIN:-lean}"
LEAN_MEMORY_MB="${LEAN_MEMORY_MB:-2500}"
mkdir -p replay-logs
build () {
  local source=$1
  printf 'Checking %s\n' "$source"
  "$LEAN_BIN" -j1 "-M$LEAN_MEMORY_MB" -o "${source%.lean}.olean" "$source" 2>&1 |
    tee "$ROOT/replay-logs/$(basename "${source%.lean}").log"
}
if [[ "${REBUILD_C02_CORE:-0}" = "1" ]]; then
  cd fixtures
  build EulerBatch/FactoredDriver.lean
  build EulerBatch/C02Core.lean
  cd "$ROOT"
fi
build C02RawFactored.lean
build C02Blocks.lean
for file in C02CoreMembers??.lean; do build "$file"; done
build C02Linked.lean
build ImportAudit.lean
