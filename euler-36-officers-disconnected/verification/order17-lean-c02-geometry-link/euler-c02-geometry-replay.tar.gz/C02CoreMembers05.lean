import C02RawFactored
import C02Blocks

namespace LatinGap.PairEncoding.C02Blocks
open Euler.C02RawFactored

theorem chunk_mem20 : ∀ c ∈ chunk20, c ∈ archiveAllUsedCNF codes := by
  unfold chunk20
  refine List.forall_mem_cons.mpr ⟨support 187 122 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 187 123 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 187 125 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 187 128 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 187 131 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 187 134 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 187 135 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 187 137 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 187 138 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 187 140 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 188 43 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 188 44 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 188 46 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 188 47 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 188 49 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 188 50 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 188 52 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 188 54 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 188 55 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 188 56 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 188 59 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 188 60 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 188 62 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 188 63 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 188 65 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 188 66 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 188 68 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 188 69 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 188 71 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 188 74 rfl, ?_⟩
  simp

theorem chunk_mem21 : ∀ c ∈ chunk21, c ∈ archiveAllUsedCNF codes := by
  unfold chunk21
  refine List.forall_mem_cons.mpr ⟨support 188 77 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 188 78 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 188 80 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 188 81 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 188 83 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 188 84 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 188 86 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 188 87 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 188 89 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 188 92 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 188 95 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 188 96 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 188 98 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 188 99 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 188 101 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 188 102 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 188 104 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 188 105 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 188 107 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 188 110 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 188 113 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 188 114 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 188 116 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 188 117 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 188 119 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 188 120 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 188 122 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 188 123 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 188 125 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 188 128 rfl, ?_⟩
  simp

theorem chunk_mem22 : ∀ c ∈ chunk22, c ∈ archiveAllUsedCNF codes := by
  unfold chunk22
  refine List.forall_mem_cons.mpr ⟨support 188 131 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 188 132 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 188 134 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 188 135 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 188 137 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 188 138 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 188 140 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 192 43 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 192 44 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 192 46 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 192 47 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 192 49 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 192 50 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 192 52 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 192 53 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 192 57 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 192 58 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 192 59 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 192 60 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 192 62 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 192 63 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 192 65 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 192 66 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 192 68 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 192 69 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 192 71 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 192 74 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 192 77 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 192 78 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 192 80 rfl, ?_⟩
  simp

theorem chunk_mem23 : ∀ c ∈ chunk23, c ∈ archiveAllUsedCNF codes := by
  unfold chunk23
  refine List.forall_mem_cons.mpr ⟨support 192 81 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 192 83 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 192 84 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 192 86 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 192 87 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 192 89 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 192 92 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 192 95 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 192 96 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 192 98 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 192 99 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 192 101 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 192 102 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 192 104 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 192 105 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 192 107 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 192 110 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 192 113 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 192 114 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 192 116 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 192 117 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 192 119 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 192 120 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 192 122 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 192 123 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 192 125 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 192 128 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 192 131 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 192 132 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 192 134 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 192 135 rfl, ?_⟩
  simp

end LatinGap.PairEncoding.C02Blocks
