import C02RawFactored
import C02Blocks

namespace LatinGap.PairEncoding.C02Blocks
open Euler.C02RawFactored

theorem chunk_mem12 : ∀ c ∈ chunk12, c ∈ archiveAllUsedCNF codes := by
  unfold chunk12
  refine List.forall_mem_cons.mpr ⟨support 96 18 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 96 20 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 96 22 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 96 23 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 96 24 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 96 26 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 96 28 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 96 29 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 96 30 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 96 32 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 96 34 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 96 35 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 96 36 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 102 14 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 102 16 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 102 17 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 102 18 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 102 20 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 102 22 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 102 23 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 102 24 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 102 26 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 102 28 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 102 29 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 102 30 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 102 32 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 102 34 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 102 35 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 102 36 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 109 61 rfl, ?_⟩
  simp

theorem chunk_mem13 : ∀ c ∈ chunk13, c ∈ archiveAllUsedCNF codes := by
  unfold chunk13
  refine List.forall_mem_cons.mpr ⟨support 109 62 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 109 65 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 109 68 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 109 71 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 109 72 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 109 74 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 109 77 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 109 80 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 109 83 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 109 86 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 109 89 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 109 90 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 109 92 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 109 95 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 109 98 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 109 101 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 109 104 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 109 107 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 109 108 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 109 110 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 109 113 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 109 116 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 109 119 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 109 122 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 109 126 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 120 58 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 120 59 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 120 62 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 120 65 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 120 68 rfl, ?_⟩
  simp

theorem chunk_mem14 : ∀ c ∈ chunk14, c ∈ archiveAllUsedCNF codes := by
  unfold chunk14
  refine List.forall_mem_cons.mpr ⟨support 120 71 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 120 72 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 120 74 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 120 77 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 120 80 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 120 83 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 120 86 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 120 89 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 120 90 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 120 92 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 120 95 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 120 98 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 120 101 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 120 104 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 120 107 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 120 108 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 120 110 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 120 113 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 120 116 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 120 119 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 120 122 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 120 126 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 121 0 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 127 0 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 133 0 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 139 0 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 150 61 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 150 62 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 150 65 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 150 68 rfl, ?_⟩
  simp

theorem chunk_mem15 : ∀ c ∈ chunk15, c ∈ archiveAllUsedCNF codes := by
  unfold chunk15
  refine List.forall_mem_cons.mpr ⟨support 150 71 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 150 74 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 150 75 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 150 77 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 150 80 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 150 83 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 150 86 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 150 89 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 150 92 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 150 93 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 150 95 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 150 98 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 150 101 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 150 104 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 150 107 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 150 110 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 150 111 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 150 113 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 150 116 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 150 119 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 150 122 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 150 125 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 150 129 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 156 0 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 157 55 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 157 56 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 157 59 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 157 62 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 157 65 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 157 68 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 157 71 rfl, ?_⟩
  simp

end LatinGap.PairEncoding.C02Blocks
