import C02RawFactored
import C02Blocks

namespace LatinGap.PairEncoding.C02Blocks
open Euler.C02RawFactored

theorem chunk_mem24 : ∀ c ∈ chunk24, c ∈ archiveAllUsedCNF codes := by
  unfold chunk24
  refine List.forall_mem_cons.mpr ⟨support 192 137 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 192 138 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 192 140 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨anchors 0 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨anchors 1 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨degreeRow 0 0 49 0 (by decide) rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨degreeRow 0 0 51 0 (by decide) rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨degreeRow 0 0 55 0 (by decide) rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨degreeRow 0 0 56 0 (by decide) rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨degreeRow 0 0 57 0 (by decide) rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨degreeRow 0 0 59 0 (by decide) rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨degreeRow 0 0 63 0 (by decide) rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨degreeRow 0 1 57 2 (by decide) rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨degreeRow 0 1 58 2 (by decide) rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨degreeRow 0 1 59 2 (by decide) rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨degreeRow 0 1 60 2 (by decide) rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨degreeRow 0 1 61 3 (by decide) rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨degreeRow 0 1 62 2 (by decide) rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨degreeRow 0 1 63 4 (by decide) rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨degreeRow 0 2 0 0 (by decide) rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨degreeRow 0 2 1 0 (by decide) rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨degreeRow 0 2 3 1 (by decide) rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨degreeRow 0 3 0 0 (by decide) rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨degreeRow 0 3 1 0 (by decide) rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨degreeRow 0 3 3 1 (by decide) rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨degreeRow 0 3 8 0 (by decide) rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨degreeRow 0 3 9 1 (by decide) rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨degreeRow 0 3 15 2 (by decide) rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨degreeRow 0 4 8 0 (by decide) rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨degreeRow 0 4 9 1 (by decide) rfl, ?_⟩
  simp

theorem chunk_mem25 : ∀ c ∈ chunk25, c ∈ archiveAllUsedCNF codes := by
  unfold chunk25
  refine List.forall_mem_cons.mpr ⟨degreeRow 0 4 15 2 (by decide) rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨degreeRow 0 5 16 0 (by decide) rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨degreeRow 0 5 17 1 (by decide) rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨degreeRow 0 5 23 2 (by decide) rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨degreeRow 1 0 49 1 (by decide) rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨degreeRow 1 0 51 1 (by decide) rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨degreeRow 1 0 55 2 (by decide) rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨degreeRow 1 0 63 3 (by decide) rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨degreeRow 1 1 48 1 (by decide) rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨degreeRow 1 1 51 2 (by decide) rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨degreeRow 1 1 55 3 (by decide) rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨degreeRow 1 1 57 2 (by decide) rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨degreeRow 1 1 59 2 (by decide) rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨degreeRow 1 1 63 4 (by decide) rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨degreeRow 1 2 17 1 (by decide) rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨degreeRow 1 2 23 2 (by decide) rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨degreeRow 1 2 30 2 (by decide) rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨degreeRow 1 2 31 2 (by decide) rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨degreeRow 1 3 15 2 (by decide) rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨degreeRow 1 4 12 1 (by decide) rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨degreeRow 1 4 15 2 (by decide) rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨degreeRow 2 1 51 2 (by decide) rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨degreeRow 2 1 53 2 (by decide) rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨degreeRow 2 1 54 2 (by decide) rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨degreeRow 2 1 55 3 (by decide) rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨degreeRow 2 1 57 2 (by decide) rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨degreeRow 2 1 58 2 (by decide) rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨degreeRow 2 1 59 3 (by decide) rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨degreeRow 2 1 60 2 (by decide) rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨degreeRow 2 1 61 3 (by decide) rfl, ?_⟩
  simp

theorem chunk_mem26 : ∀ c ∈ chunk26, c ∈ archiveAllUsedCNF codes := by
  unfold chunk26
  refine List.forall_mem_cons.mpr ⟨degreeRow 2 1 62 3 (by decide) rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨degreeRow 2 1 63 3 (by decide) rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨degreeRow 3 0 49 1 (by decide) rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨degreeRow 3 0 50 1 (by decide) rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨degreeRow 3 0 51 2 (by decide) rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨degreeRow 3 0 52 1 (by decide) rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨degreeRow 3 0 53 1 (by decide) rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨degreeRow 3 0 54 1 (by decide) rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨degreeRow 3 0 55 3 (by decide) rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨degreeRow 3 0 56 1 (by decide) rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨degreeRow 3 0 57 1 (by decide) rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨degreeRow 3 0 58 1 (by decide) rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨degreeRow 3 0 59 2 (by decide) rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨degreeRow 3 0 60 1 (by decide) rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨degreeRow 3 0 61 3 (by decide) rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨degreeRow 3 0 62 2 (by decide) rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨degreeRow 3 0 63 3 (by decide) rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨degreeOrder 21 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨degreeOrder 22 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨saturation 510 (by decide) rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨saturation 762 (by decide) rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨saturation 1194 (by decide) rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨saturation 1266 (by decide) rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨excessHi 0 4 0 (by decide) rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨excessHi 0 4 1 (by decide) rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨excessHi 0 4 2 (by decide) rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨excessHi 0 4 3 (by decide) rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨excessHi 0 5 1 (by decide) rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨excessHi 0 5 2 (by decide) rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨excessHi 0 5 3 (by decide) rfl, ?_⟩
  simp

theorem chunk_mem27 : ∀ c ∈ chunk27, c ∈ archiveAllUsedCNF codes := by
  unfold chunk27
  refine List.forall_mem_cons.mpr ⟨excessHi 0 6 1 (by decide) rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨excessHi 0 6 2 (by decide) rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨excessHi 0 6 4 (by decide) rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨excessHi 0 6 5 (by decide) rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨excessHi 0 7 2 (by decide) rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨excessHi 0 7 3 (by decide) rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨excessHi 0 7 5 (by decide) rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨excessHi 0 8 3 (by decide) rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨excessHi 0 8 5 (by decide) rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨excessHi 0 9 3 (by decide) rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨excessHi 0 9 6 (by decide) rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨excessHi 0 9 7 (by decide) rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨excessHi 0 10 4 (by decide) rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨excessHi 0 10 5 (by decide) rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨excessHi 0 10 6 (by decide) rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨excessHi 0 10 7 (by decide) rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨excessHi 0 11 5 (by decide) rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨excessHi 0 11 7 (by decide) rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨excessHi 0 12 5 (by decide) rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨excessHi 0 12 8 (by decide) rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨excessHi 0 12 9 (by decide) rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨excessHi 0 13 6 (by decide) rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨excessHi 0 13 7 (by decide) rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨excessHi 0 13 8 (by decide) rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨excessHi 0 13 9 (by decide) rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨excessHi 0 14 7 (by decide) rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨excessHi 0 14 9 (by decide) rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨excessHi 0 15 7 (by decide) rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨excessHi 0 15 10 (by decide) rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨excessHi 0 16 8 (by decide) rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨excessHi 0 16 10 (by decide) rfl, ?_⟩
  simp

end LatinGap.PairEncoding.C02Blocks
