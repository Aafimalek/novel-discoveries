import C02RawFactored
import C02Blocks

namespace LatinGap.PairEncoding.C02Blocks
open Euler.C02RawFactored

theorem chunk_mem28 : ∀ c ∈ chunk28, c ∈ archiveAllUsedCNF codes := by
  unfold chunk28
  refine List.forall_mem_cons.mpr ⟨excessHi 1 4 0 (by decide) rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨excessHi 1 4 1 (by decide) rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨excessHi 1 4 2 (by decide) rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨excessHi 1 4 3 (by decide) rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨excessHi 1 5 1 (by decide) rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨excessHi 1 5 2 (by decide) rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨excessHi 1 5 3 (by decide) rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨excessHi 1 6 1 (by decide) rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨excessHi 1 6 2 (by decide) rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨excessHi 1 6 4 (by decide) rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨excessHi 1 6 5 (by decide) rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨excessHi 1 7 2 (by decide) rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨excessHi 1 7 3 (by decide) rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨excessHi 1 7 4 (by decide) rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨excessHi 1 7 5 (by decide) rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨excessHi 1 8 3 (by decide) rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨excessHi 1 8 5 (by decide) rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨excessHi 1 9 3 (by decide) rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨excessHi 1 9 6 (by decide) rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨excessHi 1 9 7 (by decide) rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨excessHi 1 10 4 (by decide) rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨excessHi 1 10 5 (by decide) rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨excessHi 1 10 6 (by decide) rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨excessHi 1 10 7 (by decide) rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨excessHi 1 11 5 (by decide) rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨excessHi 1 11 7 (by decide) rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨excessHi 1 12 5 (by decide) rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨excessHi 1 12 8 (by decide) rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨excessHi 1 12 9 (by decide) rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨excessHi 1 13 6 (by decide) rfl, ?_⟩
  simp

theorem chunk_mem29 : ∀ c ∈ chunk29, c ∈ archiveAllUsedCNF codes := by
  unfold chunk29
  refine List.forall_mem_cons.mpr ⟨excessHi 1 13 7 (by decide) rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨excessHi 1 13 8 (by decide) rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨excessHi 1 13 9 (by decide) rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨excessHi 1 14 7 (by decide) rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨excessHi 1 14 9 (by decide) rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨excessHi 1 15 7 (by decide) rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨excessHi 1 15 10 (by decide) rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨excessHi 1 16 8 (by decide) rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨excessHi 1 16 10 (by decide) rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨excessHi 2 4 0 (by decide) rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨excessHi 2 4 1 (by decide) rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨excessHi 2 4 2 (by decide) rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨excessHi 2 4 3 (by decide) rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨excessHi 2 5 2 (by decide) rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨excessHi 2 5 3 (by decide) rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨excessHi 2 6 4 (by decide) rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨excessHi 2 6 5 (by decide) rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨excessHi 2 7 5 (by decide) rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨excessHi 2 8 5 (by decide) rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨excessHi 2 9 6 (by decide) rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨excessHi 2 9 7 (by decide) rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨excessHi 2 10 7 (by decide) rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨excessHi 2 11 7 (by decide) rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨excessHi 2 12 8 (by decide) rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨excessHi 2 12 9 (by decide) rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨excessHi 2 13 9 (by decide) rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨excessHi 2 14 9 (by decide) rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨excessHi 2 15 10 (by decide) rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨excessHi 3 1 0 (by decide) rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨excessHi 3 1 1 (by decide) rfl, ?_⟩
  simp

theorem chunk_mem30 : ∀ c ∈ chunk30, c ∈ archiveAllUsedCNF codes := by
  unfold chunk30
  refine List.forall_mem_cons.mpr ⟨excessHi 3 2 0 (by decide) rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨excessHi 3 2 1 (by decide) rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨excessHi 3 3 2 (by decide) rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨excessHi 3 3 3 (by decide) rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨excessHi 3 4 3 (by decide) rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨excessHi 3 5 3 (by decide) rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨excessHi 3 6 4 (by decide) rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨excessHi 3 6 5 (by decide) rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨excessHi 3 7 5 (by decide) rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨excessHi 3 8 5 (by decide) rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨excessHi 3 9 6 (by decide) rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨excessHi 3 9 7 (by decide) rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨excessHi 3 10 7 (by decide) rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨excessHi 3 11 7 (by decide) rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨excessHi 3 12 8 (by decide) rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨excessHi 3 12 9 (by decide) rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨excessHi 3 13 9 (by decide) rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨excessHi 3 14 9 (by decide) rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨excessHi 3 15 10 (by decide) rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨pins 1 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨pins 2 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨pins 3 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨pins 5 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨pins 6 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨pins 7 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨pins 8 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨pins 9 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨pins 10 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨pins 11 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨pins 12 rfl, ?_⟩
  simp

theorem chunk_mem31 : ∀ c ∈ chunk31, c ∈ archiveAllUsedCNF codes := by
  unfold chunk31
  refine List.forall_mem_cons.mpr ⟨pins 13 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨pins 14 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨pins 15 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨pins 17 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨pins 18 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨pins 19 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨pins 20 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨pins 21 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨pins 22 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨pins 23 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨pins 24 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨pins 25 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨pins 26 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨pins 27 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨lex 0 2 3 0 0 3 (by decide) (by decide) (by decide) rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨lex 0 2 3 1 0 3 (by decide) (by decide) (by decide) rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨lex 0 2 3 2 0 3 (by decide) (by decide) (by decide) rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨lex 0 3 4 0 0 3 (by decide) (by decide) (by decide) rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨lex 0 3 4 1 0 3 (by decide) (by decide) (by decide) rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨lex 0 3 4 2 0 3 (by decide) (by decide) (by decide) rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨lex 0 3 4 3 0 3 (by decide) (by decide) (by decide) rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨lex 0 4 5 0 0 3 (by decide) (by decide) (by decide) rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨lex 0 4 5 1 0 3 (by decide) (by decide) (by decide) rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨lex 1 3 4 0 0 3 (by decide) (by decide) (by decide) rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨lex 1 3 4 2 0 3 (by decide) (by decide) (by decide) rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨lex 1 3 4 3 1 3 (by decide) (by decide) (by decide) rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨lex 1 3 4 4 3 3 (by decide) (by decide) (by decide) rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨lex 1 4 5 0 0 3 (by decide) (by decide) (by decide) rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨lex 1 4 5 2 0 3 (by decide) (by decide) (by decide) rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨lex 1 4 5 3 1 3 (by decide) (by decide) (by decide) rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨lex 1 4 5 4 3 3 (by decide) (by decide) (by decide) rfl, ?_⟩
  simp

end LatinGap.PairEncoding.C02Blocks
