import C02RawFactored
import C02Blocks

namespace LatinGap.PairEncoding.C02Blocks
open Euler.C02RawFactored

theorem chunk_mem04 : ∀ c ∈ chunk04, c ∈ archiveAllUsedCNF codes := by
  unfold chunk04
  refine List.forall_mem_cons.mpr ⟨support 43 105 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 43 107 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 43 110 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 43 113 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 43 116 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 43 117 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 43 119 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 43 120 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 43 122 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 43 123 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 43 125 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 43 128 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 43 131 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 43 134 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 43 135 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 43 137 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 43 138 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 43 140 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 49 22 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 49 23 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 49 24 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 49 28 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 49 29 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 49 30 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 49 34 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 49 35 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 49 36 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 55 16 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 55 17 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 55 18 rfl, ?_⟩
  simp

theorem chunk_mem05 : ∀ c ∈ chunk05, c ∈ archiveAllUsedCNF codes := by
  unfold chunk05
  refine List.forall_mem_cons.mpr ⟨support 55 22 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 55 23 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 55 24 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 55 28 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 55 29 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 55 30 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 55 118 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 55 119 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 55 121 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 55 122 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 55 124 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 55 125 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 55 128 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 55 131 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 55 134 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 55 135 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 55 137 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 55 138 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 55 140 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 61 16 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 61 17 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 61 18 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 61 22 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 61 23 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 61 24 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 61 28 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 61 29 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 61 30 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 61 34 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 61 35 rfl, ?_⟩
  simp

theorem chunk_mem06 : ∀ c ∈ chunk06, c ∈ archiveAllUsedCNF codes := by
  unfold chunk06
  refine List.forall_mem_cons.mpr ⟨support 61 36 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 61 82 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 61 83 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 61 85 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 61 86 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 61 88 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 61 89 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 61 92 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 61 95 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 61 98 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 61 99 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 61 101 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 61 102 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 61 104 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 61 105 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 61 107 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 61 110 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 61 113 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 61 116 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 61 117 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 61 119 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 61 120 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 61 123 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 67 16 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 67 17 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 67 18 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 67 22 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 67 23 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 67 24 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 67 28 rfl, ?_⟩
  simp

theorem chunk_mem07 : ∀ c ∈ chunk07, c ∈ archiveAllUsedCNF codes := by
  unfold chunk07
  refine List.forall_mem_cons.mpr ⟨support 67 29 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 67 30 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 67 34 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 67 35 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 67 36 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 67 82 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 67 83 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 67 85 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 67 86 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 67 88 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 67 89 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 67 92 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 67 95 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 67 98 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 67 99 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 67 101 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 67 102 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 67 105 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 72 1 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 72 37 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 72 38 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 72 39 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 72 41 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 72 44 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 72 47 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 72 50 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 72 53 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 72 56 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 72 59 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 72 62 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 72 65 rfl, ?_⟩
  simp

end LatinGap.PairEncoding.C02Blocks
