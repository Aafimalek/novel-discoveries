import C02RawFactored
import C02Blocks

namespace LatinGap.PairEncoding.C02Blocks
open Euler.C02RawFactored

theorem chunk_mem08 : ∀ c ∈ chunk08, c ∈ archiveAllUsedCNF codes := by
  unfold chunk08
  refine List.forall_mem_cons.mpr ⟨support 72 68 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 72 71 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 72 74 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 72 77 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 72 80 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 72 81 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 72 83 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 72 84 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 72 86 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 72 87 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 72 89 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 72 92 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 72 95 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 72 98 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 72 99 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 72 101 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 72 102 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 72 104 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 72 105 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 72 107 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 72 110 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 72 113 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 72 116 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 72 117 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 72 119 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 72 120 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 72 122 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 72 123 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 72 125 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 72 128 rfl, ?_⟩
  simp

theorem chunk_mem09 : ∀ c ∈ chunk09, c ∈ archiveAllUsedCNF codes := by
  unfold chunk09
  refine List.forall_mem_cons.mpr ⟨support 72 131 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 72 134 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 72 135 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 72 137 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 72 138 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 72 140 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 78 9 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 78 58 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 78 60 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 78 61 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 78 62 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 78 65 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 78 68 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 78 71 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 78 74 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 78 77 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 78 80 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 78 81 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 78 83 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 78 84 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 78 86 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 78 87 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 78 89 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 78 92 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 78 93 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 78 95 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 78 98 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 78 99 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 78 101 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 78 102 rfl, ?_⟩
  simp

theorem chunk_mem10 : ∀ c ∈ chunk10, c ∈ archiveAllUsedCNF codes := by
  unfold chunk10
  refine List.forall_mem_cons.mpr ⟨support 78 104 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 78 105 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 78 107 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 78 110 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 78 111 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 78 113 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 78 116 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 78 117 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 78 119 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 78 120 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 78 122 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 78 123 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 78 125 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 78 128 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 78 129 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 78 131 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 78 134 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 78 135 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 78 137 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 78 138 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 78 140 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 79 73 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 79 74 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 79 75 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 79 77 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 79 80 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 79 83 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 79 86 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 79 89 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 79 93 rfl, ?_⟩
  simp

theorem chunk_mem11 : ∀ c ∈ chunk11, c ∈ archiveAllUsedCNF codes := by
  unfold chunk11
  refine List.forall_mem_cons.mpr ⟨support 84 20 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 84 22 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 84 23 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 84 24 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 84 26 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 84 28 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 84 29 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 84 30 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 84 32 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 84 34 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 84 35 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 84 36 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 90 14 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 90 16 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 90 17 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 90 18 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 90 20 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 90 22 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 90 23 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 90 24 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 90 26 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 90 28 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 90 29 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 90 30 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 90 32 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 90 34 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 90 35 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 90 36 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 96 14 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 96 16 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨support 96 17 rfl, ?_⟩
  simp

end LatinGap.PairEncoding.C02Blocks
