import ArchiveCoreBlocks

namespace LatinGap.PairEncoding.C13Linked

def codes : List ℕ := [111,1012,2203,2320]

end LatinGap.PairEncoding.C13Linked
