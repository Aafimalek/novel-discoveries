#!/usr/bin/env bash
set -euo pipefail
export C13_PHASE=identity
./run-checkpoint.sh run-builds
cp stage-receipts.log identity-stage-receipts.log
cp built-objects.sha256 identity-objects.sha256
sha256sum -c identity-objects.sha256 > identity-object-check.log
export C13_PHASE=all
./run-checkpoint.sh run-builds
