#!/usr/bin/env bash
# Run only on a separately authorized exclusive Lean slot.
# The caller supplies the checked Euler and Mathlib directories on LEAN_PATH.
# This script does not regenerate, download, or invoke a SAT solver.
set -euo pipefail
[[ "${EULER_C13_LEAN_SLOT:-}" == approved ]] || { echo 'Explicit exclusive C13 slot approval required' >&2; exit 2; }
here=$(cd "$(dirname "$0")" && pwd)
cd "$here"
case "$PWD" in
  /workspace/*) ;;
  *) echo 'Run from a workspace-overlay copy, not tmpfs' >&2; exit 2;;
esac
mkdir -p tmp replay-logs interrupted-artifacts
export TMPDIR="$PWD/tmp" TMP="$PWD/tmp" TEMP="$PWD/tmp"
export LEAN_PATH="$PWD:$LEAN_PATH"
export LEAN_BIN
sha256sum -c SHA256SUMS > replay-logs/frozen-source-check.log
if [[ -s built-objects.sha256 ]]; then
  sha256sum -c built-objects.sha256 > replay-logs/prior-object-check.log
fi
core_obj=
while IFS= read -r dir; do
  path="$dir/EulerBatch/C13CoreSorted"
  if [[ -e "$path.olean" ]]; then core_obj="$path.olean"; break; fi
  if [[ -e "$path.lean" ]]; then
    echo "Source without compiled core shadows fallback: $path.lean" >&2
    exit 2
  fi
done < <(printf '%s\n' "$LEAN_PATH" | tr : '\n')
[[ -n "$core_obj" ]] || { echo 'Cannot find C13CoreSorted.olean on LEAN_PATH' >&2; exit 2; }
actual=$(sha256sum "$core_obj" | cut -d' ' -f1)
expected=$(cut -d' ' -f1 logs/prior-core-object.sha256)
printf 'resolved-object-sha=%s\nfrozen-object-sha=%s\n' "$actual" "$expected" > replay-logs/prior-core-object-check.log
if [[ "$actual" != "$expected" && "$(printenv C13_CORE_REBUILT || true)" != 1 ]]; then
  echo 'Resolved prior core digest differs from historical object; check the dependency' >&2
  exit 2
fi
version=$("$LEAN_BIN" --version)
if [[ "$version" != *"4.36.0"* || "$version" != *"611c117bfaf7b7ae1cfcf246ce6fba31e8f509e9"* ]]; then
  echo 'Unexpected Lean version' >&2; exit 2
fi
if [[ "$#" == 0 ]]; then
  set +e
  timeout -k 2s 355s "$0" run-builds 2>&1 | tee -a replay-logs/session.log
  status=$?
  set -e
  printf 'exit=%s\n' "$status" | tee -a replay-logs/session-receipts.log
  exit "$status"
fi
[[ "$#" == 1 && "$1" == run-builds ]] || exit 2
phase=$(printenv C13_PHASE || true)
test -n "$phase" || phase=all
case "$phase" in
  all|identity|geometry) ;;
  *) echo "Invalid C13_PHASE $phase" >&2; exit 2 ;;
esac
signed_s=$(printenv C13_SIGNED_SECONDS || true)
test -n "$signed_s" || signed_s=110
raw_s=$(printenv C13_RAW_SECONDS || true)
test -n "$raw_s" || raw_s=200
[[ "$signed_s" =~ ^[1-9][0-9]{0,2}$ && "$raw_s" =~ ^[1-9][0-9]{0,2}$ ]] || exit 2
(( signed_s <= 180 && raw_s <= 250 )) || exit 2
build () {
  local limit=$1 module=$2
  if [[ -e stage-receipts.log ]] && grep -qx "$module exit=0" stage-receipts.log; then
    [[ -s "$module.olean" ]]
    grep -E "  $module[.]olean$" built-objects.sha256 | sha256sum -c -
    echo "Reusing checked $module"
    return
  fi
  if [[ -e "$module.olean" ]]; then
    mv "$module.olean" "interrupted-artifacts/$module.$(date -u +%s%N).olean"
  fi
  if [[ -e "replay-logs/$module.log" ]]; then
    mv "replay-logs/$module.log" "interrupted-artifacts/$module.$(date -u +%s%N).log"
  fi
  printf '%s Checking %s\n' "$(date -u +%T)" "$module"
  timeout -k 1s "$limit" "$LEAN_BIN" -j1 -M2500 -o "$module.olean" "$module.lean" \
    2>&1 | tee "replay-logs/$module.log"
  sha256sum "$module.olean" >> built-objects.sha256
  printf '%s exit=0\n' "$module" >> stage-receipts.log
}
build 35s ArchiveCoreBlocks
build 20s C13Codes
build "$signed_s"s C13SignedRows
build 25s C13CoreMembers00
build "$raw_s"s C13RawFactored
if [[ "$phase" == identity ]]; then
  echo 'phase=identity complete (no geometric exclusion)' | tee -a replay-logs/phase-receipts.log
  exit 0
fi
for n in $(seq -w 1 63); do build 25s "C13CoreMembers$n"; done
if [[ "$phase" == geometry ]]; then
  echo 'phase=geometry membership complete (final linkage still unchecked)' | tee -a replay-logs/phase-receipts.log
  exit 0
fi
build 40s C13Linked
build 30s C13ImportAudit
grep -Fq "'LatinGap.PairEncoding.C13Linked.allUsed_geometry_except_c13' depends on axioms: [propext, Classical.choice, Quot.sound]" replay-logs/C13ImportAudit.log
! grep -Eq 'sorryAx|Lean[.]ofReduceBool|Lean[.]trustCompiler|error:' replay-logs/C13ImportAudit.log
sha256sum -c built-objects.sha256 > replay-logs/final-object-check.log
echo 'phase=all complete (final fresh audit passed)' | tee -a replay-logs/phase-receipts.log
