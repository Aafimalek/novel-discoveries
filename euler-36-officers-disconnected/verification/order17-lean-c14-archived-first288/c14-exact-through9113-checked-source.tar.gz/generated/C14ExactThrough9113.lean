import C14OriginalFirst72Draft
import C14ProofChunk8897_8921Draft
import C14ProofChunk8921_8945Draft
import C14ProofChunk8945_8969Draft
import C14ProofChunk8969_8993Draft
import C14ProofChunk8993_9017Draft
import C14ProofChunk9017_9041Draft
import C14ProofChunk9041_9065Draft
import C14ProofChunk9065_9089Draft
import C14ProofChunk9089_9113Draft

namespace Euler.C14.Production
open Euler.C14.IndexedDraft
set_option maxRecDepth 18000
set_option maxHeartbeats 2400000

theorem bandThrough9113 (base : Sat.Fmla) : Slice base rowAt 8897 9113 :=
  (compose (compose (compose (chunk_8897_8921 base) (chunk_8921_8945 base)) (compose (chunk_8945_8969 base) (chunk_8969_8993 base))) (compose (compose (chunk_8993_9017 base) (chunk_9017_9041 base)) (compose (chunk_9041_9065 base) (compose (chunk_9065_9089 base) (chunk_9089_9113 base)))))

theorem exactArchiveThrough9113 : GoodBelow archivedGlobalCore rowAt 9113 :=
  bandThrough9113 archivedGlobalCore first72_fromExactGlobalArchive

#print axioms bandThrough9113
#print axioms exactArchiveThrough9113
end Euler.C14.Production
