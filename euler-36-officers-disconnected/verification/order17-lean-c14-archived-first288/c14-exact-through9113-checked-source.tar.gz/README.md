# C14 proof wave: first contiguous band beyond 72
This is a static staged package. No Lean was invoked to prepare it. It
preserves the fully checked exact archive prefix through 72 additions
(slot bound 8897), using it as its nonnegotiable base.

Generated target: 23 new contiguous typed slices over immutable shared
rowAt, slot interval [8897,9326), 429 new additions and 26,964 hints.
The biggest slices have 1,800 hints. Target would reach 501 total learned
additions if all pass; it is a stage target, not a result. Every nonempty
checked prefix has a matching generated balanced aggregator that imports
exactly that prefix (and first72); interruptions don't require a new
code generator or changing rowAt. The known separately checked
cross-learned leaf's emitted bytes are independently matched. This
package stages/regenerates that leaf like all others instead of assuming
its previous receipt under a different closure.

generate-band.py reparses the exact raw sorted archived CNF and LRAT
and asserts their frozen SHA-256, row counts and literal/hint ID shapes;
it checks every raw deletion's liveness, bound adjacency, exact sampled
metadata, and retained prior learned slots. It emits exact literal arrays
for all chosen hints and additions; existing Lean driver must prove their
typed lookup at the actual immutable rowAt and the genuine RUP step.
The two raw archive files are not duplicated in this package. See their
full identities in generated/band.json.

python3 run-band.py is static-only by default. It verifies compiler hash,
pinned original sources and objects, both manifest hashes plus all of
their project-visible source/object entries (65 sources/49 objects),
explicit SAT and Omega upstream import roots, 47 newly generated files,
adjacent bounds, and the shared cross-learned leaf bytes. It does not
rebuild upstream Lean/Mathlib or claim every upstream olean was independently
source-cold checked. Compiler/dependency checkout are those already pinned
in the global first48 and exact first72 release packages. The build uses
explicit controlled LEAN_PATH, not a user's inherited path.

Only upon a new grant of the sole heavy slot, from the staged directory:
    python3 run-band.py --execute --seconds 285

The worker uses the shared exclusive lock, exactly one strict ordinary
Lean 4.36 process at a time with -j1 -M2450, TMPDIR on scratch, max 47 s
per unfinished leaf, monotone deadline of at most 285 s including
prechecks, and reserves time for assembly. On an unfinished leaf or
timeout it advances no boundary and aggregates only the previously
verified contiguous prefix if one exists. A restart verifies compiled
object, exact source, dependency closure and axiom log hashes before
skipping a leaf; failed outputs do not create receipts. Logs stay in logs/.
A successful aggregate writes latest-composed.json with the exact new
boundary, learned count and receipt identity; mere leaf presence is not
the exact archived-global theorem. Port to a different installed directory
only by configuring paths and regenerating pinned object manifests after
rebuilding and auditing the dependency sources. No full LRAT/full Euler
claim follows from this particular band's success.
