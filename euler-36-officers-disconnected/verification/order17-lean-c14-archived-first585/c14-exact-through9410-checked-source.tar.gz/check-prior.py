#!/usr/bin/env python3
from pathlib import Path
import hashlib,json
H=Path(__file__).resolve().parent
I=H/'through9373-baseline'
W=H.parent
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for a in iter(lambda:f.read(1<<20),b''):h.update(a)
 return h.hexdigest()
def manifest(root,m):
 lines=m.read_text().splitlines();assert lines
 for l in lines:
  h,rel=l.split(maxsplit=1);f=(root/rel).resolve()
  assert f.is_relative_to(root.resolve()) and sha(f)==h,f
 return len(lines)
def main(_execute=False):
 z=manifest(I,H/'THROUGH9373.sha256')
 a=json.loads((I/'logs/latest-composed.json').read_text())
 assert a['end']==9373 and a['learned']==548 and a['leaf_count']==7
 assert a['theorem']=='exactArchiveThrough9373' and a['archive_aggregate']=='C14ExactThrough9373'
 Q=W/'euler-c14-after9113'
 manifest(Q,Q/'CHECKED-SOURCE.sha256');manifest(Q,Q/'CHECKED-AUDIT.sha256')
 pred=json.loads((Q/'logs/latest-composed.json').read_text())
 assert pred['end']==9278 and pred['learned']==453 and pred['theorem']=='exactArchiveThrough9278'
 assert sha(Q/'logs/C14ExactThrough9278.json')==pred['receipt']
 for m in (Q/'checked-order.txt').read_text().splitlines():
  rec=json.loads((Q/'logs'/f'{m}.json').read_text())
  assert rec['closure']==pred['closure']
  assert rec['source']==sha(Q/'generated'/f'{m}.lean')
  assert rec['object']==sha(Q/'generated'/f'{m}.olean')
  assert rec['log']==sha(Q/'logs'/f'{m}.log')
 assert a['closure']==sha(I/'closure-pins.json')+':'+sha(I/'generated/BAND.sha256')+':'+pred['receipt']
 cs=json.loads((I/'generated/band.json').read_text())['chunks'][:7]
 assert cs[0]['lo']==9278 and cs[-1]['hi']==a['end'] and cs[-1]['final_theorem']==a['theorem']
 assert all(x['hi']==y['lo'] for x,y in zip(cs,cs[1:]))
 mods=[c['module'] for c in cs]+[a['archive_aggregate']]
 assert (I/'checked-order.txt').read_text().splitlines()==mods
 for m in mods:
  src,o,log,rec=(I/'generated'/f'{m}.lean',I/'generated'/f'{m}.olean',
                 I/'logs'/f'{m}.log',I/'logs'/f'{m}.json')
  assert json.loads(rec.read_text())==dict(closure=a['closure'],source=sha(src),object=sha(o),log=sha(log)),m
 assert a['receipt']==sha(I/'logs/C14ExactThrough9373.json')
 ax="'Euler.C14.Production.exactArchiveThrough9373' depends on axioms: [propext, Classical.choice, Quot.sound]"
 assert ax in (I/'logs/C14ExactThrough9373.log').read_text().splitlines()
 print(f'Read-only exact548 snapshot: {z} files; {len(mods)} checked objects; exact 9278 dependency validated',flush=True)
 return a
if __name__=='__main__':main()
