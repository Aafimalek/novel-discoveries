# C14 literal-aware recut after exact through9373

Static staging only: no Lean was invoked and the verified archive bound
remains 548 learned rows (slot 9373). Older through9373 proof packages
and live proof sources were not changed. The new stage has an independent
read-only exact archive snapshot and all eight actual theorem objects;
THROUGH9373.sha256 pins its 49 files. Source/audit and exact dependency
through9278 receipts are checked in the default preflight.

The failed old [9373,9379) leaf had maxima of 369 hints and 91 output
literals, but those maxima are distinct learned rows. The new first leaf
[9373,9374) isolates raw ID11583 (369 hints, 81 output literals); it
names 1,049 Unicode-free signed literal occurrences in its actual hint
premises. Separately isolate [9376,9377), raw ID11586 (169 hints,
91 output literals), and [9378,9379), raw ID11588 (174 hints,
87 output literals). This covers the old failed interval in five
independent leaves. Subsequent 91–94 literal rows are also isolated.

The deterministic planner reparses exact archived raw CNF/LRAT and
preserves the same proven production driver and shared rowAt. For each
row, define work = sum of hint-clause widths + 3*hint count +
6*output width. Isolate any row with >=300 hints, >=75 output literals
or work >1850. Cap grouped leaves at 560 hints, 1850 work, and 18 rows.
These weights are engineering proxies, not runtime or truth claims.
The target is [9373,9410): 27 adjacent leaves, 37 added learned clauses
and 5,298 hints. It has all 27 possible balanced prefix aggregates from
exactArchiveThrough9373 and binds the precise baseline proof receipt.
Raw exact hashes and row/cost metadata live in generated/band.json.

Default run (static only): python3 run-band.py.
Only with a new sole heavy slot grant:
    sha256sum --check --status SHA256SUMS && python3 run-band.py --execute --seconds 285

This opens the existing nonblocking shared lock and uses one ordinary
pinned Lean 4.36 process at any moment, overlay TMPDIR, -M2450 -j1 and
warning-as-error, up to 47s per leaf and 285s entire deadline. Stop on
first timeout, record no failed receipt, and compose only verified
contiguous earlier leaves with time set aside. Restart checks original
and copied manifests, exact source/object/log receipts, and precise
baseline closure. The old lookup A/B had no compelling benefit and is
not imported. Pinned proof closure checks are not a new full upstream
Mathlib source build. If the isolated first row still times out,
splitting into gold-prefix RUP semantic continuations or testing a
longer single-row budget may be needed; do not claim refutation.
