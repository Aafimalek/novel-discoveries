import C14ExactThrough9373
import C14ProofChunk9373_9374Draft
import C14ProofChunk9374_9376Draft
import C14ProofChunk9376_9377Draft
import C14ProofChunk9377_9378Draft
import C14ProofChunk9378_9379Draft
import C14ProofChunk9379_9380Draft
import C14ProofChunk9380_9381Draft
import C14ProofChunk9381_9382Draft
import C14ProofChunk9382_9383Draft
import C14ProofChunk9383_9384Draft
import C14ProofChunk9384_9385Draft
import C14ProofChunk9385_9386Draft
import C14ProofChunk9386_9387Draft
import C14ProofChunk9387_9388Draft
import C14ProofChunk9388_9389Draft
import C14ProofChunk9389_9390Draft
import C14ProofChunk9390_9391Draft
import C14ProofChunk9391_9392Draft
import C14ProofChunk9392_9393Draft
import C14ProofChunk9393_9394Draft
import C14ProofChunk9394_9396Draft
import C14ProofChunk9396_9397Draft
import C14ProofChunk9397_9398Draft
import C14ProofChunk9398_9400Draft
import C14ProofChunk9400_9402Draft
import C14ProofChunk9402_9406Draft
import C14ProofChunk9406_9410Draft

namespace Euler.C14.Production
open Euler.C14.IndexedDraft
set_option maxRecDepth 18000
set_option maxHeartbeats 2400000

theorem bandThrough9410 (base : Sat.Fmla) : Slice base rowAt 9373 9410 :=
  (compose (compose (compose (compose (chunk_9373_9374 base) (compose (chunk_9374_9376 base) (chunk_9376_9377 base))) (compose (chunk_9377_9378 base) (compose (chunk_9378_9379 base) (chunk_9379_9380 base)))) (compose (compose (chunk_9380_9381 base) (compose (chunk_9381_9382 base) (chunk_9382_9383 base))) (compose (compose (chunk_9383_9384 base) (chunk_9384_9385 base)) (compose (chunk_9385_9386 base) (chunk_9386_9387 base))))) (compose (compose (compose (chunk_9387_9388 base) (compose (chunk_9388_9389 base) (chunk_9389_9390 base))) (compose (compose (chunk_9390_9391 base) (chunk_9391_9392 base)) (compose (chunk_9392_9393 base) (chunk_9393_9394 base)))) (compose (compose (chunk_9394_9396 base) (compose (chunk_9396_9397 base) (chunk_9397_9398 base))) (compose (compose (chunk_9398_9400 base) (chunk_9400_9402 base)) (compose (chunk_9402_9406 base) (chunk_9406_9410 base))))))

theorem exactArchiveThrough9410 : GoodBelow archivedGlobalCore rowAt 9410 :=
  bandThrough9410 archivedGlobalCore exactArchiveThrough9373

#print axioms bandThrough9410
#print axioms exactArchiveThrough9410
end Euler.C14.Production
