#!/usr/bin/env python3
"""Freeze any actually completed contiguous aggregate; never run Lean."""
import hashlib,json,tarfile
from pathlib import Path
d=Path(__file__).resolve().parent
g=d/'generated';l=d/'logs'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
latest=json.loads((l/'latest-composed.json').read_text())
band=json.loads((g/'band.json').read_text()); cs=band['chunks']
k=latest['leaf_count']; n=latest['end']; mods=[c['module'] for c in cs[:k]]+[latest['archive_aggregate']]
assert k>0 and cs[k-1]['hi']==n and latest['learned']==n-8825
assert cs[k-1]['aggregate']==latest['archive_aggregate'] and cs[k-1]['final_theorem']==latest['theorem']
assert sha(l/(mods[-1]+'.json'))==latest['receipt']
prev=json.loads((d/'through9373-baseline/logs/latest-composed.json').read_text())
assert prev['end']==9373
assert latest['closure']==sha(d/'closure-pins.json')+':'+sha(g/'BAND.sha256')+':'+prev['receipt']
source=[d/'README.md',d/'closure-pins.json',d/'generate-band.py',d/'run-band.py',d/'check-prior.py',d/'THROUGH9373.sha256',d/'freeze-with-dependency-note.py',
        d/'static-preflight.log',g/'band.json',g/'BAND.sha256']
audit=[l/'latest-composed.json',l/'events.tsv']
order=d/'checked-order.txt';order.write_text('\n'.join(mods)+'\n')
summary=d/'CHECKED.md';summary.write_text(
 '# C14 exact sorted archive contiguous prefix\n\n'
 f'Ordinary pinned Lean 4.36 with strict warnings checked the exact archive through slot bound {n}. '
 f'This is {n-8825} learned rows inclusive of the earlier 548, not the full 5085-row proof. '
 f'The final learned raw ID is {cs[k-1]["last_id"]}. The additional {k} adjacent slices used '
 f'{sum(x["hints"] for x in cs[:k])} exact hint references.\n\n'
 f'Top theorem: Euler.C14.Production.{latest["theorem"]}, '
 f'GoodBelow archivedGlobalCore rowAt {n}, using propext, Classical.choice and Quot.sound. '
 'Each new slice and the conditional balanced band aggregate use propext only. '
 'This proves neither a terminal contradiction nor any geometry link.\n\n'
 'Dependency source packages: c14-global-first48 SHA fa85e3a37ddd08a3697f956b58f11d7b712220357e7881d8b6544dfe39c4ad3e and '
 'c14-exact-global-first72 SHA a520bd17616bbe12a25c69770903e6e3ce39e2a2ca137968afd32a839a2ddbdc. '
 'The aggregate directly imports checked exactArchiveThrough9373, source archive SHA 0608ab4996f498b97536ecf2a25e5ab3a1b754b267958d3c45c03e2fa0eedff8. '
 'Pin ordinary Lean 4.36 and the same Mathlib dependencies. Checked order is in checked-order.txt. '
 'The separate original stage tar contains remaining source for the incremental runner; this smaller freeze '
 'includes only sources necessary to rebuild this checked prefix and its exact aggregate.\n')
source.extend([order,summary,d/'replay-checked.sh'])
for m in mods:
 s=g/(m+'.lean');o=g/(m+'.olean');log=l/(m+'.log');r=l/(m+'.json')
 evidence=json.loads(r.read_text())
 assert evidence==dict(closure=latest['closure'],source=sha(s),object=sha(o),log=sha(log))
 source.append(s);audit.extend([log,r])
def package(tag,files):
 manifest=d/f'CHECKED-{tag.upper()}.sha256'
 manifest.write_text(''.join(f'{sha(p)}  {p.relative_to(d)}\n' for p in files))
 dest=d/f'c14-exact-through{n}-checked-{tag}.tar.gz'
 with tarfile.open(dest,'w:gz') as ar:
  for f in [*files,manifest]:ar.add(f,arcname=f.relative_to(d))
 print(sha(dest),dest)
package('source',source);package('audit',audit)
