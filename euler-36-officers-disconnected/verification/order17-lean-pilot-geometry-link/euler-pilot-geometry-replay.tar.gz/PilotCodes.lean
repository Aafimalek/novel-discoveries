import ArchiveCoreBlocks

namespace LatinGap.PairEncoding.PilotLinked

def codes : List ℕ := [111,1012,1203,1320]

end LatinGap.PairEncoding.PilotLinked
