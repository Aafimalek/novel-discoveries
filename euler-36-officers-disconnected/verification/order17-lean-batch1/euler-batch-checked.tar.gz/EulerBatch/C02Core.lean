import EulerBatch.FactoredDriver
namespace Euler.Batch.C02
factored_rup coreUnsat (include_str "cases/02/core.cnf") (include_str "cases/02/core.lrat")
#print axioms coreUnsat
end Euler.Batch.C02
