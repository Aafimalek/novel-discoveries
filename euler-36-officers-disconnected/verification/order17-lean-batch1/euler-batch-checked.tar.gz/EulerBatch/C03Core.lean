import EulerBatch.FactoredDriver
namespace Euler.Batch.C03
factored_rup coreUnsat (include_str "cases/03/core.cnf") (include_str "cases/03/core.lrat")
#print axioms coreUnsat
end Euler.Batch.C03
