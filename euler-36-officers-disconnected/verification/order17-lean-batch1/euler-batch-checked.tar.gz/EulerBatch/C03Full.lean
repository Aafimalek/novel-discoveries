import EulerBatch.ContainmentDriver
import EulerBatch.C03Core
namespace Euler.Batch.C03
prove_numbered_containment branchFullFormula branchContainsCore branchFullUnsat coreUnsat
  10646 60886 2139 (include_str "cases/03/original.cnf") (include_str "cases/03/core.cnf")

theorem branchNoAssignment :
    ¬ ∃ v : Sat.Valuation, v.satisfies_fmla branchFullFormula := by
  rintro ⟨v,hv⟩
  exact branchFullUnsat v hv
#print axioms branchNoAssignment
#print axioms branchContainsCore
#print axioms branchFullUnsat
end Euler.Batch.C03
