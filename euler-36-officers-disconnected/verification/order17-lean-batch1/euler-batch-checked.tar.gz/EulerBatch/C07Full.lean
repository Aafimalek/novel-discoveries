import EulerBatch.ContainmentDriver
import EulerBatch.C07Core
namespace Euler.Batch.C07
prove_numbered_containment branchFullFormula branchContainsCore branchFullUnsat coreUnsat
  10646 60567 3501 (include_str "cases/07/original.cnf") (include_str "cases/07/core.cnf")

theorem branchNoAssignment :
    ¬ ∃ v : Sat.Valuation, v.satisfies_fmla branchFullFormula := by
  rintro ⟨v,hv⟩
  exact branchFullUnsat v hv
#print axioms branchNoAssignment
#print axioms branchContainsCore
#print axioms branchFullUnsat
end Euler.Batch.C07
