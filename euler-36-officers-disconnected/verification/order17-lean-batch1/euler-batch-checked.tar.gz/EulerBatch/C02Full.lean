import EulerBatch.ContainmentDriver
import EulerBatch.C02Core
namespace Euler.Batch.C02
prove_numbered_containment branchFullFormula branchContainsCore branchFullUnsat coreUnsat
  10646 61205 968 (include_str "cases/02/original.cnf") (include_str "cases/02/core.cnf")

theorem branchNoAssignment :
    ¬ ∃ v : Sat.Valuation, v.satisfies_fmla branchFullFormula := by
  rintro ⟨v,hv⟩
  exact branchFullUnsat v hv
#print axioms branchNoAssignment
#print axioms branchContainsCore
#print axioms branchFullUnsat
end Euler.Batch.C02
