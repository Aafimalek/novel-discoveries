import EulerBatch.ContainmentDriver
import EulerBatch.C01Core
namespace Euler.Batch.C01
prove_numbered_containment branchFullFormula branchContainsCore branchFullUnsat coreUnsat
  10646 60886 2215 (include_str "cases/01/original.cnf") (include_str "cases/01/core.cnf")

theorem branchNoAssignment :
    ¬ ∃ v : Sat.Valuation, v.satisfies_fmla branchFullFormula := by
  rintro ⟨v,hv⟩
  exact branchFullUnsat v hv
#print axioms branchNoAssignment
#print axioms branchContainsCore
#print axioms branchFullUnsat
end Euler.Batch.C01
