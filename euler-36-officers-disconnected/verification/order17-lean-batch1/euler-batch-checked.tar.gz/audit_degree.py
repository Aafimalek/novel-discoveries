"""Byte-level question: which physical clauses are described by NumberedDegree?"""
from itertools import product
from pathlib import Path
import sys

def neighbor(g,a,b):
    return 1297+6*a+b if g==0 else 1297+36*(g-1)+6*b+a
def threshold(g,a,k):
    return 9719+42*g+7*a+k
def clauses():
    out=[]
    for g,a in product(range(4),range(6)):
        for bits in product((0,1),repeat=6):
            t=sum(bits)
            block=[(-1 if z else 1)*neighbor(g,a,b) for b,z in enumerate(bits)]
            if t<2 or ((g,a)==(0,0) and t!=2):
                out.append(tuple(block))
            else:
                for k in range(2,7):
                    out.append(tuple(block+[(1 if k<=t else -1)*threshold(g,a,k)]))
        for k in range(2):
            out.append((threshold(g,a,k),))
    return out
want=clauses()
assert len(want)==6888
for file in map(Path,sys.argv[1:]):
    rows=file.read_text('ascii').splitlines()[1:]
    got=[tuple(map(int,s.split()[:-1])) for s in rows[33046:33046+len(want)]]
    assert got==want,(file,next(i+33047 for i,(x,y) in enumerate(zip(got,want)) if x!=y))
    print(file,'degree unary clauses 33047..39934 exact',len(got))
