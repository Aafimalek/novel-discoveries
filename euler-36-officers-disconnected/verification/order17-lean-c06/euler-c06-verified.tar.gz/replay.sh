#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")"
export LEAN_PATH="$PWD${LEAN_PATH:+:$LEAN_PATH}"
LEAN=${LEAN:-lean}
memory=${LEAN_MEMORY:-3200}
for n in FactoredDriver ContainmentDriver; do
  "$LEAN" -j1 -M"$memory" -R . -o "EulerBatch/$n.olean" "EulerBatch/$n.lean"
done
while IFS=$'\t' read -r idx family label variables clauses core; do
  dir="EulerBatch/cases/$idx"
  (cd "$dir"; gzip -dc original.cnf.gz > original.cnf; sha256sum -c SHA256SUMS)
  for part in Core Full; do
    n="EulerBatch/C${idx}${part}"
    "$LEAN" -j1 -M"$memory" -R . -o "$n.olean" "$n.lean"
  done
done < checked.tsv
if [[ "${WITH_NUMBERED:-0}" == 1 ]]; then
  "$LEAN" -j1 -M"$memory" -R . -o EulerBatch/NumberedSemantics.olean EulerBatch/NumberedSemantics.lean
  if [[ -f EulerBatch/SymbolicToKernel.lean ]]; then
    "$LEAN" -j1 -M"$memory" -R . -o EulerBatch/SymbolicToKernel.olean EulerBatch/SymbolicToKernel.lean
  fi
fi
