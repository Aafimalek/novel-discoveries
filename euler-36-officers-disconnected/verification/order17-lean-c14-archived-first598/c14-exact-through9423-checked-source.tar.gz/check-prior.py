#!/usr/bin/env python3
from pathlib import Path
import hashlib,json
H=Path(__file__).resolve().parent;W=H.parent
I=H/'through9410-baseline'
R=W/'euler-c14-after9373'
J=R/'through9373-baseline'
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for a in iter(lambda:f.read(1<<20),b''):h.update(a)
 return h.hexdigest()
def manifest(root,m):
 lines=m.read_text().splitlines();assert lines
 for l in lines:
  h,rel=l.split(maxsplit=1);f=(root/rel).resolve()
  assert f.is_relative_to(root.resolve()) and sha(f)==h,f
 return len(lines)
def validate(root,start,end,k,previous_receipt):
 a=json.loads((root/'logs/latest-composed.json').read_text())
 assert (a['end'],a['learned'],a['leaf_count'])==(end,end-8825,k)
 assert a['theorem']==f'exactArchiveThrough{end}' and a['archive_aggregate']==f'C14ExactThrough{end}'
 assert a['closure']==sha(root/'closure-pins.json')+':'+sha(root/'generated/BAND.sha256')+':'+previous_receipt
 cs=json.loads((root/'generated/band.json').read_text())['chunks'][:k]
 assert cs[0]['lo']==start and cs[-1]['hi']==end and cs[-1]['final_theorem']==a['theorem']
 assert all(x['hi']==y['lo'] for x,y in zip(cs,cs[1:]))
 mods=[c['module'] for c in cs]+[a['archive_aggregate']]
 assert (root/'checked-order.txt').read_text().splitlines()==mods
 for m in mods:
  src,o,log,rec=(root/'generated'/f'{m}.lean',root/'generated'/f'{m}.olean',
                 root/'logs'/f'{m}.log',root/'logs'/f'{m}.json')
  assert json.loads(rec.read_text())==dict(closure=a['closure'],source=sha(src),object=sha(o),log=sha(log)),m
 assert a['receipt']==sha(root/'logs'/f"C14ExactThrough{end}.json")
 ax=f"'Euler.C14.Production.exactArchiveThrough{end}' depends on axioms: [propext, Classical.choice, Quot.sound]"
 assert ax in (root/'logs'/f'C14ExactThrough{end}.log').read_text().splitlines()
 return a
def main(_execute=False):
 z=manifest(I,H/'THROUGH9410.sha256')
 manifest(J,R/'THROUGH9373.sha256')
 Q=W/'euler-c14-after9113'
 manifest(Q,Q/'CHECKED-SOURCE.sha256');manifest(Q,Q/'CHECKED-AUDIT.sha256')
 p=json.loads((Q/'logs/latest-composed.json').read_text())
 assert p['end']==9278 and sha(Q/'logs/C14ExactThrough9278.json')==p['receipt']
 for m in (Q/'checked-order.txt').read_text().splitlines():
  rec=json.loads((Q/'logs'/f'{m}.json').read_text())
  assert rec['closure']==p['closure']
  assert rec['source']==sha(Q/'generated'/f'{m}.lean')
  assert rec['object']==sha(Q/'generated'/f'{m}.olean')
  assert rec['log']==sha(Q/'logs'/f'{m}.log')
 prev=validate(J,9278,9373,7,p['receipt'])
 a=validate(I,9373,9410,27,prev['receipt'])
 assert a['receipt']=='4b0eb3c36cdb58a97eb8746dab1389f9217e02661728a699971db979fcbde8c8'
 print(f'Read-only exact585 snapshot: {z} files; 28 checked objects; exact 9373/9278 dependencies validated',flush=True)
 return a
if __name__=='__main__':main()
