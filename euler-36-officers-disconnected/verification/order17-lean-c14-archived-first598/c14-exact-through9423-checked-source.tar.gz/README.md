# C14 small literal-aware continuation after exact through9410
Static only. The immutable checked baseline exactArchiveThrough9410,
GoodBelow archivedGlobalCore rowAt 9410, remains 585 learned rows.
A read-only extracted copy preserves 129 files and 28 actual Lean
objects; preflight verifies exact object/source/log receipts and their
through9373/9278 predecessor identities, not merely archive SHA strings.

The next staged interval [9410,9429) has 19 actual learned additions,
13 leaves and 3,075 exact hint references. Bound 9429 would be 604
learned rows, not currently proved. Exact raw sorted CNF/LRAT bytes are
reparsed with verified SHA, dimensions, row numbering and deletion
liveness. No trusted check: the same original driver establishes all
actual literal-clause lookups and RUP terms against one permanent rowAt.
There are 13 adjacent balanced prefix aggregators, one per breakpoint.
Group caps are 560 hints / 1850 work / 18 rows; work is summed hint
clause widths + 3 per hint + 6 per output literal. Isolate a row with
>=300 hints, >=75 output literals or work >1850.

Known performance risk, not a runtime assertion: ID11641 at [9423,9424)
has 510 hints/41 output literals and work 3408. It is already isolated;
previous 437-hint row ID11609 checked in 32.64s, so a stricter 47s
per-leaf cap might clip ID11641. If it times out, stop/replay only prior
settled leaves and keep the largest contiguous aggregate; do not raise
the cap or silently retry. A pending segment is not a checked result.

Viable fallback (design only): factor the actual single-row RUP check at
unit-hint index 255, preserving same exact current slot and prior proof
hypotheses. For arbitrary v satisfying the common base, assume all target
literals are false. The first subtheorem establishes the exact needed
falsified literal polarities after the initial 255 ordered hints; the
second uses those plus the target assumption, remaining 255 hints, and
exact later premise clauses to derive False. Compose and convert this
refutation to v.satisfies target by induction on the target clause.
The static optional-row11641-frontier.json lists only prefix-derived
polarities actually consumed by the suffix and their producing hint
indices. The decoder independently validates their use and final
conflict; no Lean implementation of the split is claimed. This changes
proof factoring only, not formula/axioms or branch semantics. The
closed clause and both generic continuations still require kernel proofs.

Default python3 run-band.py is static. Only with a new sole heavy grant:
    sha256sum --check --status SHA256SUMS && python3 run-band.py --execute --seconds 285

Original strict pinned Lean 4.36, one process at a time under global lock,
overlay TMPDIR, -j1 -M2450, warning-as-error, unchanged max 47s/leaf, 285s
monotone overall. Receipts bind source/object/log and exact immutable
prior aggregate, reserve time to compose the largest contiguous prefix.
No Lean or Git ran in preparation, and this is not complete C14 or
Euler geometry.
