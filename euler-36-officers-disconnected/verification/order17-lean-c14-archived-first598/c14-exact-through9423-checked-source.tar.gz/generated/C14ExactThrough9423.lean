import C14ExactThrough9410
import C14ProofChunk9410_9411Draft
import C14ProofChunk9411_9412Draft
import C14ProofChunk9412_9413Draft
import C14ProofChunk9413_9416Draft
import C14ProofChunk9416_9417Draft
import C14ProofChunk9417_9418Draft
import C14ProofChunk9418_9419Draft
import C14ProofChunk9419_9422Draft
import C14ProofChunk9422_9423Draft

namespace Euler.C14.Production
open Euler.C14.IndexedDraft
set_option maxRecDepth 18000
set_option maxHeartbeats 2400000

theorem bandThrough9423 (base : Sat.Fmla) : Slice base rowAt 9410 9423 :=
  (compose (compose (compose (chunk_9410_9411 base) (chunk_9411_9412 base)) (compose (chunk_9412_9413 base) (chunk_9413_9416 base))) (compose (compose (chunk_9416_9417 base) (chunk_9417_9418 base)) (compose (chunk_9418_9419 base) (compose (chunk_9419_9422 base) (chunk_9422_9423 base)))))

theorem exactArchiveThrough9423 : GoodBelow archivedGlobalCore rowAt 9423 :=
  bandThrough9423 archivedGlobalCore exactArchiveThrough9410

#print axioms bandThrough9423
#print axioms exactArchiveThrough9423
end Euler.C14.Production
