import ArchiveCoreBlocks

namespace LatinGap.PairEncoding.C11Linked

def codes : List ℕ := [111,1012,2201,1320]

end LatinGap.PairEncoding.C11Linked
