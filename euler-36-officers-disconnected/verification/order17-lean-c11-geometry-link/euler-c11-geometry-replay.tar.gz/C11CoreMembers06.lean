import C11SignedRows
import C11Codes

namespace LatinGap.PairEncoding.C11Linked
open Euler.C11RawFactored

theorem chunk_mem24 : ∀ c ∈ chunk24, c ∈ archiveAllUsedCNF codes := by
  unfold chunk24
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 73 43 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 73 105 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 3 33 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 3 34 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 3 35 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 3 36 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 180 48 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 181 49 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 36 114 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 36 117 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 36 120 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 146 43 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 36 123 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 37 108 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 0 38 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 0 41 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 0 44 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 0 47 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 0 50 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 0 53 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 0 56 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 187 48 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 0 59 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 0 62 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 0 65 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 0 68 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 0 71 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 0 74 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 0 77 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 0 80 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 0 83 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 0 86 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 188 49 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 0 89 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 0 92 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 0 95 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 0 98 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 0 101 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 0 104 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 0 107 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 0 110 rfl, ?_⟩
  simp

theorem chunk_mem25 : ∀ c ∈ chunk25, c ∈ archiveAllUsedCNF codes := by
  unfold chunk25
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 0 113 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 0 116 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 37 117 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 0 119 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 0 122 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 0 125 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 0 128 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 0 131 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 0 134 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 0 137 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 37 120 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 1 44 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 1 47 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 1 50 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 1 53 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 1 59 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 1 62 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 1 65 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 1 68 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 1 71 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 37 123 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 1 74 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 1 77 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 1 80 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 1 83 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 1 86 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 1 89 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 1 92 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 1 95 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 1 98 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 1 101 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 192 49 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 1 104 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 1 107 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 1 110 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 1 113 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 1 116 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 1 119 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 1 122 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 1 125 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 1 128 rfl, ?_⟩
  simp

theorem chunk_mem26 : ∀ c ∈ chunk26, c ∈ archiveAllUsedCNF codes := by
  unfold chunk26
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 1 131 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 73 114 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 1 134 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 1 137 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 4 15 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 0 81 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 4 16 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 4 17 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 4 18 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 72 117 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 73 117 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 4 21 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 4 22 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 4 23 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 4 24 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 72 120 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 0 84 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 73 120 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 4 27 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 4 28 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 6 47 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 6 50 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 6 53 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 6 56 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 4 29 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 6 62 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 6 65 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 6 68 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 6 71 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 6 74 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 6 77 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 6 80 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 6 83 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 6 86 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 4 30 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 6 89 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 6 92 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 6 95 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 6 98 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 6 101 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 6 104 rfl, ?_⟩
  simp

theorem chunk_mem27 : ∀ c ∈ chunk27, c ∈ archiveAllUsedCNF codes := by
  unfold chunk27
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 6 107 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 6 110 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 6 113 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 6 116 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 72 123 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 6 119 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 6 122 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 6 125 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 6 128 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 6 131 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 6 134 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 6 137 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 73 123 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 4 33 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 4 34 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 7 119 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 7 122 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 7 125 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 7 128 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 7 131 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 4 35 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 7 134 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 7 137 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 0 87 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 4 36 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 180 51 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 8 107 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 8 110 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 8 113 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 8 116 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 181 52 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 8 122 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 8 125 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 8 128 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 8 131 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 8 134 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 8 137 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 36 132 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 9 44 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 9 47 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 9 50 rfl, ?_⟩
  simp

end LatinGap.PairEncoding.C11Linked
