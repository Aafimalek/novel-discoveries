#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
: "${LEAN_BIN:?Set absolute pinned Lean 4.36 compiler}"
: "${LEAN_MATHLIB_PATH:?Set colon-separated Lean/mathlib dependency .olean roots}"
export LEAN_PATH="$PWD/generated:$PWD:$LEAN_MATHLIB_PATH"
mkdir -p "$PWD/tmp"
export TMPDIR="$PWD/tmp"
while IFS= read -r mod; do
  src="generated/$mod.lean"
  [[ -f $src ]] || src="$mod.lean"
  root=$(dirname "$src")
  timeout 75 "$LEAN_BIN" -j1 -M2450 -DwarningAsError=true -R "$PWD/$root" -o "$root/$mod.olean" "$PWD/$src"
done < checked-order.txt
