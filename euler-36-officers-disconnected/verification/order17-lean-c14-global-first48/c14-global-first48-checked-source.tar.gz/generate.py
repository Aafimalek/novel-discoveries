#!/usr/bin/env python3
"""Scaffold stable C14 global slots and exact initial-two-slice data. No Lean."""
import argparse,gzip,hashlib,json,math
from pathlib import Path
p=argparse.ArgumentParser()
p.add_argument('core',type=Path);p.add_argument('cone',type=Path);p.add_argument('out',type=Path)
a=p.parse_args(); a.out.mkdir(exist_ok=True,parents=True)

bs=a.core.read_bytes()
assert hashlib.sha256(bs).hexdigest()=='1250abf3c7bab4709e3c5d22c4c57b0beb833052bf308092690668e7346ceb50'
header,*body=bs.splitlines()
assert header.split()==[b'p',b'cnf',b'10646',b'8825'] and len(body)==8825
original=[]
for x in body:
 xs=list(map(int,x.split()));assert xs[-1]==0 and all(0<abs(l)<=10646 for l in xs[:-1])
 original.append(xs[:-1])
with gzip.open(a.cone,'rt') as f:data=json.load(f)
learned=data['learned'];n=len(original);m=len(learned)
assert (n,m)==(8825,5085) and learned[-1]['id']==17658 and learned[-1]['clause']==[]
for i,r in data['orig']:assert original[i-1]==r
assert [x['original_ordinal'] for x in learned]==list(range(1,m+1))
id2slot={i+1:i for i in range(n)}
for k,r in enumerate(learned):
 assert r['id'] not in id2slot and all(h in id2slot for h in r['hints'])
 id2slot[r['id']]=n+k

def lit(x):return f'Sat.Literal.{"neg" if x<0 else "pos"} {abs(x)-1}'
def clause(xs):return '['+', '.join(map(lit,xs))+']'
def ar(xs):return '#['+', '.join(map(str,xs))+']'
def emit(name, s): (a.out/(name+'.lean')).write_text(s.rstrip()+'\n')
namespace='Euler.C14.Production'
width=128
allrows=original+[x['clause'] for x in learned]
clmods=[]
blocks=0
# fixed 128 clauses per data array, 4 arrays per small source module
for i in range(0,len(allrows),width*4):
 mod=f'C14GlobalRows{len(clmods):02}'
 clmods.append(mod)
 s=['import Mathlib.Tactic.Sat.FromLRAT',f'namespace {namespace}']
 if len(clmods)>17: s.append('set_option maxRecDepth 18000')
 for base in range(i,min(len(allrows),i+width*4),width):
  s += [f'def block{blocks} : Array Sat.Clause := #[',',\n'.join('  '+clause(r) for r in allrows[base:base+width]),']']
  blocks+=1
 s.append(f'end {namespace}')
 emit(mod,'\n'.join(s))

def directory(lo,hi):
 if hi-lo==1:return f'(block{lo}[slot - {lo*width}]?).getD Sat.Clause.nil'
 mid=(lo+hi)//2
 return f'(if slot < {mid*width} then {directory(lo,mid)} else {directory(mid,hi)})'
emit('C14GlobalDirectory','\n'.join([*['import '+m for m in clmods],
  f'namespace {namespace}',f'def rowAt (slot : Nat) : Sat.Clause := {directory(0,blocks)}',
  f'end {namespace}']))

def chunk(lo,hi):
 selected=learned[lo:hi];bind=[]
 for k,r in enumerate(selected,lo):
  hints=[(id2slot[h],allrows[id2slot[h]]) for h in r['hints']]
  assert all(slot<n+k for slot,_ in hints)
  bind.append((r['id'],n+k,r['clause'],hints))
 name=f'C14GlobalChunkData{lo:04}_{hi:04}'
 lines=[f'namespace {namespace}',
        'abbrev RawRow := Nat × Nat × Array Int × Array (Nat × Array Int)' if lo==0 else '',
        f'def rows{lo}_{hi} : Array RawRow := #[']
 lines += [',\n'.join(f'  ({i}, {slot}, {ar(cl)}, #['+
  ', '.join(f'({h}, {ar(r)})' for h,r in hints)+'])' for i,slot,cl,hints in bind)]
 lines+= [']',f'end {namespace}']
 if lo!=0:lines.insert(0,'import C14GlobalChunkData0000_0024')
 emit(name,'\n'.join(lines))
 return dict(lo=n+lo,hi=n+hi,first_id=selected[0]['id'],last_id=selected[-1]['id'],
             hints=sum(len(r['hints']) for r in selected), distinct_prior_hints=len(set(
             h for r in selected for h in r['hints'] if id2slot[h]<n+lo)))
chunks=[chunk(0,24),chunk(24,48)]
summary=dict(core_rows=n,learned_rows=m,slots=n+m,empty_slot=n+m-1,
             data_modules=len(clmods),data_blocks=blocks,clauses_per_block=width,chunks=chunks)
(a.out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
(a.out/'compile-order.txt').write_text('\n'.join([*clmods,'C14GlobalDirectory',
                'C14GlobalChunkData0000_0024','C14GlobalChunkData0024_0048'])+'\n')
print(json.dumps(summary,indent=2))
