import C12SignedRows
import C12Codes

namespace LatinGap.PairEncoding.C12Linked
open Euler.C12RawFactored

theorem chunk_mem108 : ∀ c ∈ chunk108, c ∈ archiveAllUsedCNF codes := by
  unfold chunk108
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 78 35 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 11 26 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 46 32 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 11 112 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 80 138 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 81 138 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 11 29 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 46 35 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 11 121 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 11 30 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 46 36 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 11 124 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 78 36 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 11 129 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 11 32 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 47 32 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 79 36 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 143 58 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 175 70 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 211 70 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 80 140 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 1 55 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 81 140 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 11 138 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 11 35 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 47 35 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 82 36 rfl, ?_⟩
  simp

theorem chunk_mem109 : ∀ c ∈ chunk109, c ∈ archiveAllUsedCNF codes := by
  unfold chunk109
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 143 67 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 214 70 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 80 41 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 80 44 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 80 47 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 80 50 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 80 53 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 80 56 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 11 140 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 11 36 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 47 36 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 83 36 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 143 70 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 215 70 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 80 59 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 80 62 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 80 65 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 80 68 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 80 71 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 80 74 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 80 77 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 80 80 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 80 83 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 80 86 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 80 89 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 80 92 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 80 95 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 80 98 rfl, ?_⟩
  simp

theorem chunk_mem110 : ∀ c ∈ chunk110, c ∈ archiveAllUsedCNF codes := by
  unfold chunk110
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 80 101 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 80 104 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 80 107 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 80 110 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 80 113 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 80 116 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 108 75 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 80 119 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 80 122 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 80 125 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 80 128 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 80 131 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 80 134 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 80 137 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 146 72 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 81 47 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 81 50 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 81 53 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 81 56 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 81 59 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 81 62 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 81 65 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 81 68 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 183 72 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 81 74 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 81 77 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 81 80 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 81 83 rfl, ?_⟩
  simp

theorem chunk_mem111 : ∀ c ∈ chunk111, c ∈ archiveAllUsedCNF codes := by
  unfold chunk111
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 81 86 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 81 89 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 81 92 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 81 95 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 81 98 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 81 101 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 108 84 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 81 104 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 81 107 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 81 110 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 81 113 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 81 116 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 81 119 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 81 122 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 81 125 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 81 128 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 81 131 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 108 87 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 81 134 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 81 137 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 109 72 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 1 57 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 37 57 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 73 57 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 187 39 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 1 8 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 37 8 rfl, ?_⟩
  refine List.forall_mem_cons.mpr ⟨ArchiveCoreBlocks.support (codes := codes) 73 8 rfl, ?_⟩
  simp

end LatinGap.PairEncoding.C12Linked
