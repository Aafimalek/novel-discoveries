import ArchiveCoreBlocks

namespace LatinGap.PairEncoding.C12Linked

def codes : List ℕ := [111,1012,1203,2320]

end LatinGap.PairEncoding.C12Linked
