import ArchiveCoreBlocks

namespace LatinGap.PairEncoding.C03Linked

def codes : List ℕ := [111,1012,1201,1320]

end LatinGap.PairEncoding.C03Linked
