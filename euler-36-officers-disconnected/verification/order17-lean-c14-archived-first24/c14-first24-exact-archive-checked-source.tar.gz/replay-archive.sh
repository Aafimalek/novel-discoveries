#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
: "${LEAN_BIN:?Set LEAN_BIN to absolute pinned Lean 4.36 binary}"
: "${LEAN_MATHLIB_PATH:?Set LEAN_MATHLIB_PATH to colon-separated dependency .olean roots}"
export LEAN_PATH="$PWD:$LEAN_MATHLIB_PATH"
mkdir -p "$PWD/tmp"
export TMPDIR="$PWD/tmp"
for f in EulerC14IndexedDraft EulerC14IndexedDriver EulerC14IndexedPilot EulerC14IndexedInitialize \
  EulerC14ArchivedDriver EulerC14ArchivedFirst24; do
  timeout 75 "$LEAN_BIN" -j1 -M2450 -DwarningAsError=true -R "$PWD" -o "$f.olean" "$PWD/$f.lean"
done
