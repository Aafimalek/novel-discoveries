import EulerC14IndexedDriver
namespace Euler.C14.IndexedDraft
set_option maxHeartbeats 2000000
set_option maxRecDepth 10000
def c0 : Sat.Clause := [Sat.Literal.neg 9763]
def c1 : Sat.Clause := [Sat.Literal.pos 0]
def c2 : Sat.Clause := [Sat.Literal.pos 224]
def c3 : Sat.Clause := [Sat.Literal.pos 43]
def c4 : Sat.Clause := [Sat.Literal.pos 505]
def c5 : Sat.Clause := [Sat.Literal.pos 768]
def c6 : Sat.Clause := [Sat.Literal.pos 9728]
def c7 : Sat.Clause := [Sat.Literal.pos 9735]
def c8 : Sat.Clause := [Sat.Literal.pos 9742]
def c9 : Sat.Clause := [Sat.Literal.pos 9749]
def c10 : Sat.Clause := [Sat.Literal.pos 9756]
def c11 : Sat.Clause := [Sat.Literal.pos 9770]
def c12 : Sat.Clause := [Sat.Literal.pos 9777]
def c13 : Sat.Clause := [Sat.Literal.pos 9784]
def c14 : Sat.Clause := [Sat.Literal.pos 9791]
def c15 : Sat.Clause := [Sat.Literal.pos 9798]
def c16 : Sat.Clause := [Sat.Literal.pos 9812]
def c17 : Sat.Clause := [Sat.Literal.pos 9819]
def c18 : Sat.Clause := [Sat.Literal.pos 9826]
def c19 : Sat.Clause := [Sat.Literal.pos 9833]
def c20 : Sat.Clause := [Sat.Literal.pos 9840]
def c21 : Sat.Clause := [Sat.Literal.pos 9854]
def c22 : Sat.Clause := [Sat.Literal.pos 9861]
def c23 : Sat.Clause := [Sat.Literal.pos 9868]
def c24 : Sat.Clause := [Sat.Literal.pos 9875]
def c25 : Sat.Clause := [Sat.Literal.pos 9882]
def c26 : Sat.Clause := [Sat.Literal.neg 0, Sat.Literal.pos 1296]
def c27 : Sat.Clause := [Sat.Literal.neg 10001, Sat.Literal.pos 10006]
def c28 : Sat.Clause := [Sat.Literal.neg 10006, Sat.Literal.pos 10011]
def c29 : Sat.Clause := [Sat.Literal.neg 10011, Sat.Literal.pos 10016]
def c30 : Sat.Clause := [Sat.Literal.neg 10017, Sat.Literal.pos 10022]
def c31 : Sat.Clause := [Sat.Literal.neg 10022, Sat.Literal.pos 10027]
def c32 : Sat.Clause := [Sat.Literal.neg 10027, Sat.Literal.pos 10032]
def c33 : Sat.Clause := [Sat.Literal.neg 10033, Sat.Literal.pos 10038]
def c34 : Sat.Clause := [Sat.Literal.neg 10038, Sat.Literal.pos 10043]
def c35 : Sat.Clause := [Sat.Literal.neg 10043, Sat.Literal.pos 10048]
def c36 : Sat.Clause := [Sat.Literal.neg 10049, Sat.Literal.pos 10054]
def c37 : Sat.Clause := [Sat.Literal.neg 10054, Sat.Literal.pos 10059]
def c38 : Sat.Clause := [Sat.Literal.neg 10059, Sat.Literal.pos 10064]
def c39 : Sat.Clause := [Sat.Literal.neg 10191, Sat.Literal.pos 10196]
def c40 : Sat.Clause := [Sat.Literal.neg 10196, Sat.Literal.pos 10201]
def c41 : Sat.Clause := [Sat.Literal.neg 10201, Sat.Literal.pos 10206]
def c42 : Sat.Clause := [Sat.Literal.neg 10207, Sat.Literal.pos 10212]
def c43 : Sat.Clause := [Sat.Literal.neg 10212, Sat.Literal.pos 10217]
def c44 : Sat.Clause := [Sat.Literal.neg 10217, Sat.Literal.pos 10222]
def c45 : Sat.Clause := [Sat.Literal.neg 10223, Sat.Literal.pos 10228]
def c46 : Sat.Clause := [Sat.Literal.neg 10228, Sat.Literal.pos 10233]
def c47 : Sat.Clause := [Sat.Literal.neg 10233, Sat.Literal.pos 10238]
def c48 : Sat.Clause := [Sat.Literal.neg 10239, Sat.Literal.pos 10244]
def c49 : Sat.Clause := [Sat.Literal.neg 10244, Sat.Literal.pos 10249]
def c50 : Sat.Clause := [Sat.Literal.neg 10249, Sat.Literal.pos 10254]
def c51 : Sat.Clause := [Sat.Literal.neg 10381, Sat.Literal.pos 10386]
def c52 : Sat.Clause := [Sat.Literal.neg 10386, Sat.Literal.pos 10391]
def c53 : Sat.Clause := [Sat.Literal.neg 10391, Sat.Literal.pos 10396]
def c54 : Sat.Clause := [Sat.Literal.neg 10397, Sat.Literal.pos 10402]
def c55 : Sat.Clause := [Sat.Literal.neg 10402, Sat.Literal.pos 10407]
def c56 : Sat.Clause := [Sat.Literal.neg 10407, Sat.Literal.pos 10412]
def c57 : Sat.Clause := [Sat.Literal.neg 10413, Sat.Literal.pos 10418]
def c58 : Sat.Clause := [Sat.Literal.neg 10418, Sat.Literal.pos 10423]
def c59 : Sat.Clause := [Sat.Literal.neg 10423, Sat.Literal.pos 10428]
def c60 : Sat.Clause := [Sat.Literal.neg 10429, Sat.Literal.pos 10434]
def c61 : Sat.Clause := [Sat.Literal.neg 10430, Sat.Literal.pos 10435]
def c62 : Sat.Clause := [Sat.Literal.neg 10434, Sat.Literal.pos 10439]
def c63 : Sat.Clause := [Sat.Literal.neg 10435, Sat.Literal.pos 10440]
def c64 : Sat.Clause := [Sat.Literal.neg 10439, Sat.Literal.pos 10444]
def c65 : Sat.Clause := [Sat.Literal.neg 10571, Sat.Literal.pos 10576]
def c66 : Sat.Clause := [Sat.Literal.neg 10576, Sat.Literal.pos 10581]
def c67 : Sat.Clause := [Sat.Literal.neg 10581, Sat.Literal.pos 10586]
def c68 : Sat.Clause := [Sat.Literal.neg 10587, Sat.Literal.pos 10592]
def c69 : Sat.Clause := [Sat.Literal.neg 10592, Sat.Literal.pos 10597]
def c70 : Sat.Clause := [Sat.Literal.neg 10597, Sat.Literal.pos 10602]
def c71 : Sat.Clause := [Sat.Literal.neg 10603, Sat.Literal.pos 10608]
def c72 : Sat.Clause := [Sat.Literal.neg 10608, Sat.Literal.pos 10613]
def c73 : Sat.Clause := [Sat.Literal.neg 10613, Sat.Literal.pos 10618]
def c74 : Sat.Clause := [Sat.Literal.neg 10619, Sat.Literal.pos 10624]
def c75 : Sat.Clause := [Sat.Literal.neg 10620, Sat.Literal.pos 10625]
def c76 : Sat.Clause := [Sat.Literal.neg 10624, Sat.Literal.pos 10629]
def c77 : Sat.Clause := [Sat.Literal.neg 10625, Sat.Literal.pos 10630]
def c78 : Sat.Clause := [Sat.Literal.neg 10629, Sat.Literal.pos 10634]
def c79 : Sat.Clause := [Sat.Literal.neg 224, Sat.Literal.pos 1302]
def c80 : Sat.Clause := [Sat.Literal.neg 43, Sat.Literal.pos 1297]
def c81 : Sat.Clause := [Sat.Literal.neg 505, Sat.Literal.pos 1310]
def c82 : Sat.Clause := [Sat.Literal.neg 768, Sat.Literal.pos 1317]
def c83 : Sat.Clause := [Sat.Literal.neg 9728, Sat.Literal.pos 10001]
def c84 : Sat.Clause := [Sat.Literal.neg 9757, Sat.Literal.neg 10065]
def c85 : Sat.Clause := [Sat.Literal.neg 9770, Sat.Literal.pos 10191]
def c86 : Sat.Clause := [Sat.Literal.neg 9799, Sat.Literal.neg 10255]
def c87 : Sat.Clause := [Sat.Literal.neg 9812, Sat.Literal.pos 10381]
def c88 : Sat.Clause := [Sat.Literal.neg 9840, Sat.Literal.neg 10440]
def c89 : Sat.Clause := [Sat.Literal.neg 9841, Sat.Literal.neg 10445]
def c90 : Sat.Clause := [Sat.Literal.neg 9854, Sat.Literal.pos 10571]
def c91 : Sat.Clause := [Sat.Literal.neg 9882, Sat.Literal.neg 10630]
def c92 : Sat.Clause := [Sat.Literal.neg 9883, Sat.Literal.neg 10635]
def c93 : Sat.Clause := [Sat.Literal.neg 9735, Sat.Literal.neg 10016, Sat.Literal.pos 10017]
def c94 : Sat.Clause := [Sat.Literal.neg 9742, Sat.Literal.neg 10032, Sat.Literal.pos 10033]
def c95 : Sat.Clause := [Sat.Literal.neg 9749, Sat.Literal.neg 10048, Sat.Literal.pos 10049]
def c96 : Sat.Clause := [Sat.Literal.neg 9756, Sat.Literal.neg 10064, Sat.Literal.pos 10065]
def c97 : Sat.Clause := [Sat.Literal.neg 9777, Sat.Literal.neg 10206, Sat.Literal.pos 10207]
def c98 : Sat.Clause := [Sat.Literal.neg 9784, Sat.Literal.neg 10222, Sat.Literal.pos 10223]
def c99 : Sat.Clause := [Sat.Literal.neg 9791, Sat.Literal.neg 10238, Sat.Literal.pos 10239]
def c100 : Sat.Clause := [Sat.Literal.neg 9798, Sat.Literal.neg 10254, Sat.Literal.pos 10255]
def c101 : Sat.Clause := [Sat.Literal.neg 9819, Sat.Literal.neg 10396, Sat.Literal.pos 10397]
def c102 : Sat.Clause := [Sat.Literal.neg 9826, Sat.Literal.neg 10412, Sat.Literal.pos 10413]
def c103 : Sat.Clause := [Sat.Literal.neg 9833, Sat.Literal.neg 10428, Sat.Literal.pos 10429]
def c104 : Sat.Clause := [Sat.Literal.neg 9834, Sat.Literal.neg 10429, Sat.Literal.pos 10430]
def c105 : Sat.Clause := [Sat.Literal.neg 9840, Sat.Literal.neg 10444, Sat.Literal.pos 10445]
def c106 : Sat.Clause := [Sat.Literal.neg 9861, Sat.Literal.neg 10586, Sat.Literal.pos 10587]
def c107 : Sat.Clause := [Sat.Literal.neg 9868, Sat.Literal.neg 10602, Sat.Literal.pos 10603]
def c108 : Sat.Clause := [Sat.Literal.neg 9875, Sat.Literal.neg 10618, Sat.Literal.pos 10619]
def c109 : Sat.Clause := [Sat.Literal.neg 9876, Sat.Literal.neg 10619, Sat.Literal.pos 10620]
def c110 : Sat.Clause := [Sat.Literal.neg 9882, Sat.Literal.neg 10634, Sat.Literal.pos 10635]
def c111 : Sat.Clause := [Sat.Literal.neg 9749, Sat.Literal.pos 9757, Sat.Literal.neg 1320, Sat.Literal.pos 1326]
def c112 : Sat.Clause := [Sat.Literal.neg 9791, Sat.Literal.pos 9799, Sat.Literal.neg 1300, Sat.Literal.pos 1301]
def c113 : Sat.Clause := [Sat.Literal.neg 1296, Sat.Literal.neg 1297, Sat.Literal.neg 1298, Sat.Literal.neg 1299, Sat.Literal.neg 1300, Sat.Literal.neg 1301]
def c114 : Sat.Clause := [Sat.Literal.neg 1296, Sat.Literal.neg 1297, Sat.Literal.neg 1298, Sat.Literal.neg 1299, Sat.Literal.pos 1300, Sat.Literal.neg 1301]
def c115 : Sat.Clause := [Sat.Literal.neg 1296, Sat.Literal.neg 1297, Sat.Literal.neg 1298, Sat.Literal.neg 1299, Sat.Literal.pos 1300, Sat.Literal.pos 1301]
def c116 : Sat.Clause := [Sat.Literal.neg 1296, Sat.Literal.neg 1297, Sat.Literal.neg 1298, Sat.Literal.pos 1299, Sat.Literal.neg 1300, Sat.Literal.neg 1301]
def c117 : Sat.Clause := [Sat.Literal.neg 1296, Sat.Literal.neg 1297, Sat.Literal.neg 1298, Sat.Literal.pos 1299, Sat.Literal.pos 1300, Sat.Literal.neg 1301]
def c118 : Sat.Clause := [Sat.Literal.neg 1296, Sat.Literal.neg 1297, Sat.Literal.neg 1298, Sat.Literal.pos 1299, Sat.Literal.pos 1300, Sat.Literal.pos 1301]
def c119 : Sat.Clause := [Sat.Literal.neg 1296, Sat.Literal.neg 1297, Sat.Literal.pos 1298, Sat.Literal.neg 1299, Sat.Literal.neg 1300, Sat.Literal.neg 1301]
def c120 : Sat.Clause := [Sat.Literal.neg 1296, Sat.Literal.neg 1297, Sat.Literal.pos 1298, Sat.Literal.neg 1299, Sat.Literal.pos 1300, Sat.Literal.neg 1301]
def c121 : Sat.Clause := [Sat.Literal.neg 1296, Sat.Literal.neg 1297, Sat.Literal.pos 1298, Sat.Literal.neg 1299, Sat.Literal.pos 1300, Sat.Literal.pos 1301]
def c122 : Sat.Clause := [Sat.Literal.neg 1296, Sat.Literal.neg 1297, Sat.Literal.pos 1298, Sat.Literal.pos 1299, Sat.Literal.neg 1300, Sat.Literal.neg 1301]
def c123 : Sat.Clause := [Sat.Literal.neg 1296, Sat.Literal.neg 1297, Sat.Literal.pos 1298, Sat.Literal.pos 1299, Sat.Literal.pos 1300, Sat.Literal.neg 1301]
def c124 : Sat.Clause := [Sat.Literal.neg 1302, Sat.Literal.pos 1303, Sat.Literal.pos 1304, Sat.Literal.pos 1305, Sat.Literal.pos 1306, Sat.Literal.pos 1307]
def c125 : Sat.Clause := [Sat.Literal.neg 9749, Sat.Literal.pos 9757, Sat.Literal.pos 1320, Sat.Literal.pos 1326, Sat.Literal.neg 1321, Sat.Literal.pos 1327]
def c126 : Sat.Clause := [Sat.Literal.neg 9791, Sat.Literal.pos 9799, Sat.Literal.pos 1300, Sat.Literal.pos 1301, Sat.Literal.neg 1306, Sat.Literal.pos 1307]
def c127 : Sat.Clause := [Sat.Literal.neg 9826, Sat.Literal.pos 9834, Sat.Literal.pos 1335, Sat.Literal.pos 1336, Sat.Literal.neg 1341, Sat.Literal.pos 1342]
def c128 : Sat.Clause := [Sat.Literal.neg 9833, Sat.Literal.pos 9841, Sat.Literal.pos 1336, Sat.Literal.pos 1337, Sat.Literal.neg 1342, Sat.Literal.pos 1343]
def c129 : Sat.Clause := [Sat.Literal.neg 9868, Sat.Literal.pos 9876, Sat.Literal.pos 1371, Sat.Literal.pos 1372, Sat.Literal.neg 1377, Sat.Literal.pos 1378]
def c130 : Sat.Clause := [Sat.Literal.neg 9875, Sat.Literal.pos 9883, Sat.Literal.pos 1372, Sat.Literal.pos 1373, Sat.Literal.neg 1378, Sat.Literal.pos 1379]
def c131 : Sat.Clause := [Sat.Literal.pos 1299, Sat.Literal.pos 1305, Sat.Literal.pos 1311, Sat.Literal.neg 1317, Sat.Literal.pos 1323, Sat.Literal.pos 1329]
def c132 : Sat.Clause := [Sat.Literal.pos 1308, Sat.Literal.pos 1309, Sat.Literal.neg 1310, Sat.Literal.pos 1311, Sat.Literal.pos 1312, Sat.Literal.pos 1313]
def c133 : Sat.Clause := [Sat.Literal.pos 1314, Sat.Literal.pos 1315, Sat.Literal.pos 1316, Sat.Literal.neg 1317, Sat.Literal.pos 1318, Sat.Literal.pos 1319]
def c134 : Sat.Clause := [Sat.Literal.neg 1296, Sat.Literal.neg 1302, Sat.Literal.neg 1308, Sat.Literal.neg 1314, Sat.Literal.neg 1320, Sat.Literal.neg 1326, Sat.Literal.pos 9763]
def c135 : Sat.Clause := [Sat.Literal.neg 1320, Sat.Literal.pos 1326]
def c136 : Sat.Clause := [Sat.Literal.neg 1300, Sat.Literal.pos 1301]
def c137 : Sat.Clause := [Sat.Literal.neg 1298, Sat.Literal.neg 1299, Sat.Literal.neg 1300, Sat.Literal.neg 1301]
def c138 : Sat.Clause := [Sat.Literal.neg 1298, Sat.Literal.neg 1299, Sat.Literal.pos 1300, Sat.Literal.neg 1301]
def c139 : Sat.Clause := [Sat.Literal.neg 1298, Sat.Literal.neg 1299, Sat.Literal.pos 1300, Sat.Literal.pos 1301]
def c140 : Sat.Clause := [Sat.Literal.neg 1298, Sat.Literal.pos 1299, Sat.Literal.neg 1300, Sat.Literal.neg 1301]
def c141 : Sat.Clause := [Sat.Literal.neg 1298, Sat.Literal.pos 1299, Sat.Literal.pos 1300, Sat.Literal.neg 1301]
def c142 : Sat.Clause := [Sat.Literal.neg 1298, Sat.Literal.pos 1299, Sat.Literal.pos 1300, Sat.Literal.pos 1301]
def c143 : Sat.Clause := [Sat.Literal.pos 1298, Sat.Literal.neg 1299, Sat.Literal.neg 1300, Sat.Literal.neg 1301]
def c144 : Sat.Clause := [Sat.Literal.pos 1298, Sat.Literal.neg 1299, Sat.Literal.pos 1300, Sat.Literal.neg 1301]
def c145 : Sat.Clause := [Sat.Literal.pos 1298, Sat.Literal.neg 1299, Sat.Literal.pos 1300, Sat.Literal.pos 1301]
def c146 : Sat.Clause := [Sat.Literal.pos 1298, Sat.Literal.pos 1299, Sat.Literal.neg 1300, Sat.Literal.neg 1301]
def c147 : Sat.Clause := [Sat.Literal.pos 1298, Sat.Literal.pos 1299, Sat.Literal.pos 1300, Sat.Literal.neg 1301]
def c148 : Sat.Clause := [Sat.Literal.pos 1303, Sat.Literal.pos 1304, Sat.Literal.pos 1305, Sat.Literal.pos 1306, Sat.Literal.pos 1307]
def c149 : Sat.Clause := [Sat.Literal.pos 1320, Sat.Literal.neg 1321, Sat.Literal.pos 1326, Sat.Literal.pos 1327]
def c150 : Sat.Clause := [Sat.Literal.pos 1300, Sat.Literal.pos 1301, Sat.Literal.neg 1306, Sat.Literal.pos 1307]
def c151 : Sat.Clause := [Sat.Literal.pos 1335, Sat.Literal.pos 1336, Sat.Literal.neg 1341, Sat.Literal.pos 1342]
def c152 : Sat.Clause := [Sat.Literal.pos 1336, Sat.Literal.pos 1337, Sat.Literal.neg 1342, Sat.Literal.pos 1343]
def c153 : Sat.Clause := [Sat.Literal.pos 1371, Sat.Literal.pos 1372, Sat.Literal.neg 1377, Sat.Literal.pos 1378]
def c154 : Sat.Clause := [Sat.Literal.pos 1372, Sat.Literal.pos 1373, Sat.Literal.neg 1378, Sat.Literal.pos 1379]
def c155 : Sat.Clause := [Sat.Literal.pos 1299, Sat.Literal.pos 1305, Sat.Literal.pos 1311, Sat.Literal.pos 1323, Sat.Literal.pos 1329]
def c156 : Sat.Clause := [Sat.Literal.pos 1308, Sat.Literal.pos 1309, Sat.Literal.pos 1311, Sat.Literal.pos 1312, Sat.Literal.pos 1313]
def c157 : Sat.Clause := [Sat.Literal.pos 1314, Sat.Literal.pos 1315, Sat.Literal.pos 1316, Sat.Literal.pos 1318, Sat.Literal.pos 1319]
def c158 : Sat.Clause := [Sat.Literal.neg 1308, Sat.Literal.neg 1314, Sat.Literal.neg 1320, Sat.Literal.neg 1326]
def rowAt (n : Nat) : Sat.Clause := (if n < 79 then (if n < 39 then (if n < 19 then (if n < 9 then (if n < 4 then (if n < 2 then (if n < 1 then c0 else c1) else (if n < 3 then c2 else c3)) else (if n < 6 then (if n < 5 then c4 else c5) else (if n < 7 then c6 else (if n < 8 then c7 else c8)))) else (if n < 14 then (if n < 11 then (if n < 10 then c9 else c10) else (if n < 12 then c11 else (if n < 13 then c12 else c13))) else (if n < 16 then (if n < 15 then c14 else c15) else (if n < 17 then c16 else (if n < 18 then c17 else c18))))) else (if n < 29 then (if n < 24 then (if n < 21 then (if n < 20 then c19 else c20) else (if n < 22 then c21 else (if n < 23 then c22 else c23))) else (if n < 26 then (if n < 25 then c24 else c25) else (if n < 27 then c26 else (if n < 28 then c27 else c28)))) else (if n < 34 then (if n < 31 then (if n < 30 then c29 else c30) else (if n < 32 then c31 else (if n < 33 then c32 else c33))) else (if n < 36 then (if n < 35 then c34 else c35) else (if n < 37 then c36 else (if n < 38 then c37 else c38)))))) else (if n < 59 then (if n < 49 then (if n < 44 then (if n < 41 then (if n < 40 then c39 else c40) else (if n < 42 then c41 else (if n < 43 then c42 else c43))) else (if n < 46 then (if n < 45 then c44 else c45) else (if n < 47 then c46 else (if n < 48 then c47 else c48)))) else (if n < 54 then (if n < 51 then (if n < 50 then c49 else c50) else (if n < 52 then c51 else (if n < 53 then c52 else c53))) else (if n < 56 then (if n < 55 then c54 else c55) else (if n < 57 then c56 else (if n < 58 then c57 else c58))))) else (if n < 69 then (if n < 64 then (if n < 61 then (if n < 60 then c59 else c60) else (if n < 62 then c61 else (if n < 63 then c62 else c63))) else (if n < 66 then (if n < 65 then c64 else c65) else (if n < 67 then c66 else (if n < 68 then c67 else c68)))) else (if n < 74 then (if n < 71 then (if n < 70 then c69 else c70) else (if n < 72 then c71 else (if n < 73 then c72 else c73))) else (if n < 76 then (if n < 75 then c74 else c75) else (if n < 77 then c76 else (if n < 78 then c77 else c78))))))) else (if n < 119 then (if n < 99 then (if n < 89 then (if n < 84 then (if n < 81 then (if n < 80 then c79 else c80) else (if n < 82 then c81 else (if n < 83 then c82 else c83))) else (if n < 86 then (if n < 85 then c84 else c85) else (if n < 87 then c86 else (if n < 88 then c87 else c88)))) else (if n < 94 then (if n < 91 then (if n < 90 then c89 else c90) else (if n < 92 then c91 else (if n < 93 then c92 else c93))) else (if n < 96 then (if n < 95 then c94 else c95) else (if n < 97 then c96 else (if n < 98 then c97 else c98))))) else (if n < 109 then (if n < 104 then (if n < 101 then (if n < 100 then c99 else c100) else (if n < 102 then c101 else (if n < 103 then c102 else c103))) else (if n < 106 then (if n < 105 then c104 else c105) else (if n < 107 then c106 else (if n < 108 then c107 else c108)))) else (if n < 114 then (if n < 111 then (if n < 110 then c109 else c110) else (if n < 112 then c111 else (if n < 113 then c112 else c113))) else (if n < 116 then (if n < 115 then c114 else c115) else (if n < 117 then c116 else (if n < 118 then c117 else c118)))))) else (if n < 139 then (if n < 129 then (if n < 124 then (if n < 121 then (if n < 120 then c119 else c120) else (if n < 122 then c121 else (if n < 123 then c122 else c123))) else (if n < 126 then (if n < 125 then c124 else c125) else (if n < 127 then c126 else (if n < 128 then c127 else c128)))) else (if n < 134 then (if n < 131 then (if n < 130 then c129 else c130) else (if n < 132 then c131 else (if n < 133 then c132 else c133))) else (if n < 136 then (if n < 135 then c134 else c135) else (if n < 137 then c136 else (if n < 138 then c137 else c138))))) else (if n < 149 then (if n < 144 then (if n < 141 then (if n < 140 then c139 else c140) else (if n < 142 then c141 else (if n < 143 then c142 else c143))) else (if n < 146 then (if n < 145 then c144 else c145) else (if n < 147 then c146 else (if n < 148 then c147 else c148)))) else (if n < 154 then (if n < 151 then (if n < 150 then c149 else c150) else (if n < 152 then c151 else (if n < 153 then c152 else c153))) else (if n < 156 then (if n < 155 then c154 else c155) else (if n < 157 then c156 else (if n < 158 then c157 else c158))))))))
def base : Sat.Fmla := [c0, c1, c2, c3, c4, c5, c6, c7, c8, c9, c10, c11, c12, c13, c14, c15, c16, c17, c18, c19, c20, c21, c22, c23, c24, c25, c26, c27, c28, c29, c30, c31, c32, c33, c34, c35, c36, c37, c38, c39, c40, c41, c42, c43, c44, c45, c46, c47, c48, c49, c50, c51, c52, c53, c54, c55, c56, c57, c58, c59, c60, c61, c62, c63, c64, c65, c66, c67, c68, c69, c70, c71, c72, c73, c74, c75, c76, c77, c78, c79, c80, c81, c82, c83, c84, c85, c86, c87, c88, c89, c90, c91, c92, c93, c94, c95, c96, c97, c98, c99, c100, c101, c102, c103, c104, c105, c106, c107, c108, c109, c110, c111, c112, c113, c114, c115, c116, c117, c118, c119, c120, c121, c122, c123, c124, c125, c126, c127, c128, c129, c130, c131, c132, c133, c134]
indexed_rup base rowAt first24
#[(1, #[-9764]),
(4, #[1]),
(5, #[225]),
(6, #[44]),
(7, #[506]),
(8, #[769]),
(9, #[9729]),
(10, #[9736]),
(11, #[9743]),
(12, #[9750]),
(13, #[9757]),
(14, #[9771]),
(15, #[9778]),
(16, #[9785]),
(17, #[9792]),
(18, #[9799]),
(19, #[9813]),
(20, #[9820]),
(21, #[9827]),
(22, #[9834]),
(23, #[9841]),
(24, #[9855]),
(25, #[9862]),
(26, #[9869]),
(27, #[9876]),
(28, #[9883]),
(29, #[-1, 1297]),
(49, #[-10002, 10007]),
(51, #[-10007, 10012]),
(61, #[-10012, 10017]),
(63, #[-10018, 10023]),
(72, #[-10023, 10028]),
(74, #[-10028, 10033]),
(77, #[-10034, 10039]),
(79, #[-10039, 10044]),
(91, #[-10044, 10049]),
(101, #[-10050, 10055]),
(103, #[-10055, 10060]),
(114, #[-10060, 10065]),
(154, #[-10192, 10197]),
(156, #[-10197, 10202]),
(166, #[-10202, 10207]),
(168, #[-10208, 10213]),
(171, #[-10213, 10218]),
(173, #[-10218, 10223]),
(184, #[-10224, 10229]),
(186, #[-10229, 10234]),
(201, #[-10234, 10239]),
(214, #[-10240, 10245]),
(216, #[-10245, 10250]),
(228, #[-10250, 10255]),
(339, #[-10382, 10387]),
(341, #[-10387, 10392]),
(344, #[-10392, 10397]),
(346, #[-10398, 10403]),
(359, #[-10403, 10408]),
(361, #[-10408, 10413]),
(373, #[-10414, 10419]),
(375, #[-10419, 10424]),
(384, #[-10424, 10429]),
(391, #[-10430, 10435]),
(392, #[-10431, 10436]),
(393, #[-10435, 10440]),
(394, #[-10436, 10441]),
(401, #[-10440, 10445]),
(435, #[-10572, 10577]),
(437, #[-10577, 10582]),
(446, #[-10582, 10587]),
(448, #[-10588, 10593]),
(460, #[-10593, 10598]),
(462, #[-10598, 10603]),
(473, #[-10604, 10609]),
(475, #[-10609, 10614]),
(485, #[-10614, 10619]),
(494, #[-10620, 10625]),
(495, #[-10621, 10626]),
(496, #[-10625, 10630]),
(497, #[-10626, 10631]),
(499, #[-10630, 10635]),
(2095, #[-225, 1303]),
(3862, #[-44, 1298]),
(4503, #[-506, 1311]),
(6639, #[-769, 1318]),
(8027, #[-9729, 10002]),
(8032, #[-9758, -10066]),
(8038, #[-9771, 10192]),
(8044, #[-9800, -10256]),
(8049, #[-9813, 10382]),
(8064, #[-9841, -10441]),
(8065, #[-9842, -10446]),
(8070, #[-9855, 10572]),
(8074, #[-9883, -10631]),
(8075, #[-9884, -10636]),
(8145, #[-9736, -10017, 10018]),
(8148, #[-9743, -10033, 10034]),
(8152, #[-9750, -10049, 10050]),
(8154, #[-9757, -10065, 10066]),
(8158, #[-9778, -10207, 10208]),
(8162, #[-9785, -10223, 10224]),
(8166, #[-9792, -10239, 10240]),
(8168, #[-9799, -10255, 10256]),
(8174, #[-9820, -10397, 10398]),
(8177, #[-9827, -10413, 10414]),
(8181, #[-9834, -10429, 10430]),
(8182, #[-9835, -10430, 10431]),
(8184, #[-9841, -10445, 10446]),
(8190, #[-9862, -10587, 10588]),
(8193, #[-9869, -10603, 10604]),
(8197, #[-9876, -10619, 10620]),
(8198, #[-9877, -10620, 10621]),
(8200, #[-9883, -10635, 10636]),
(8201, #[-9750, 9758, -1321, 1327]),
(8202, #[-9792, 9800, -1301, 1302]),
(8203, #[-1297, -1298, -1299, -1300, -1301, -1302]),
(8204, #[-1297, -1298, -1299, -1300, 1301, -1302]),
(8205, #[-1297, -1298, -1299, -1300, 1301, 1302]),
(8206, #[-1297, -1298, -1299, 1300, -1301, -1302]),
(8207, #[-1297, -1298, -1299, 1300, 1301, -1302]),
(8208, #[-1297, -1298, -1299, 1300, 1301, 1302]),
(8209, #[-1297, -1298, 1299, -1300, -1301, -1302]),
(8210, #[-1297, -1298, 1299, -1300, 1301, -1302]),
(8211, #[-1297, -1298, 1299, -1300, 1301, 1302]),
(8212, #[-1297, -1298, 1299, 1300, -1301, -1302]),
(8213, #[-1297, -1298, 1299, 1300, 1301, -1302]),
(8214, #[-1303, 1304, 1305, 1306, 1307, 1308]),
(8215, #[-9750, 9758, 1321, 1327, -1322, 1328]),
(8216, #[-9792, 9800, 1301, 1302, -1307, 1308]),
(8217, #[-9827, 9835, 1336, 1337, -1342, 1343]),
(8218, #[-9834, 9842, 1337, 1338, -1343, 1344]),
(8219, #[-9869, 9877, 1372, 1373, -1378, 1379]),
(8220, #[-9876, 9884, 1373, 1374, -1379, 1380]),
(8233, #[1300, 1306, 1312, -1318, 1324, 1330]),
(8268, #[1309, 1310, -1311, 1312, 1313, 1314]),
(8294, #[1315, 1316, 1317, -1318, 1319, 1320]),
(8402, #[-1297, -1303, -1309, -1315, -1321, -1327, 9764])]
#[(10716, #[-1321, 1327], #[9, 10, 11, 12, 13, 8027, 49, 51, 61, 8145, 63, 72, 74, 8148, 77, 79, 91, 8152, 101, 103, 114, 8154, 8032, 8201]),
(10717, #[-1301, 1302], #[14, 15, 16, 17, 18, 8038, 154, 156, 166, 8158, 168, 171, 173, 8162, 184, 186, 201, 8166, 214, 216, 228, 8168, 8044, 8202]),
(10718, #[-1299, -1300, -1301, -1302], #[4, 6, 29, 3862, 8203]),
(10719, #[-1299, -1300, 1301, -1302], #[4, 6, 29, 3862, 8204]),
(10720, #[-1299, -1300, 1301, 1302], #[4, 6, 29, 3862, 8205]),
(10721, #[-1299, 1300, -1301, -1302], #[4, 6, 29, 3862, 8206]),
(10722, #[-1299, 1300, 1301, -1302], #[4, 6, 29, 3862, 8207]),
(10723, #[-1299, 1300, 1301, 1302], #[4, 6, 29, 3862, 8208]),
(10724, #[1299, -1300, -1301, -1302], #[4, 6, 29, 3862, 8209]),
(10725, #[1299, -1300, 1301, -1302], #[4, 6, 29, 3862, 8210]),
(10726, #[1299, -1300, 1301, 1302], #[4, 6, 29, 3862, 8211]),
(10727, #[1299, 1300, -1301, -1302], #[4, 6, 29, 3862, 8212]),
(10728, #[1299, 1300, 1301, -1302], #[4, 6, 29, 3862, 8213]),
(10729, #[1304, 1305, 1306, 1307, 1308], #[5, 2095, 8214]),
(10730, #[1321, -1322, 1327, 1328], #[9, 10, 11, 12, 13, 8027, 49, 51, 61, 8145, 63, 72, 74, 8148, 77, 79, 91, 8152, 101, 103, 114, 8154, 8032, 8215]),
(10731, #[1301, 1302, -1307, 1308], #[14, 15, 16, 17, 18, 8038, 154, 156, 166, 8158, 168, 171, 173, 8162, 184, 186, 201, 8166, 214, 216, 228, 8168, 8044, 8216]),
(10732, #[1336, 1337, -1342, 1343], #[19, 20, 21, 22, 23, 8049, 8064, 339, 394, 341, 392, 344, 8174, 346, 359, 361, 8177, 373, 375, 384, 8181, 8182, 8217]),
(10733, #[1337, 1338, -1343, 1344], #[19, 20, 21, 22, 23, 8049, 339, 341, 344, 8174, 346, 359, 361, 8177, 373, 375, 384, 8181, 391, 393, 401, 8184, 8065, 8218]),
(10734, #[1372, 1373, -1378, 1379], #[24, 25, 26, 27, 28, 8070, 8074, 435, 497, 437, 495, 446, 8190, 448, 460, 462, 8193, 473, 475, 485, 8197, 8198, 8219]),
(10735, #[1373, 1374, -1379, 1380], #[24, 25, 26, 27, 28, 8070, 435, 437, 446, 8190, 448, 460, 462, 8193, 473, 475, 485, 8197, 494, 496, 499, 8200, 8075, 8220]),
(10736, #[1300, 1306, 1312, 1324, 1330], #[8, 6639, 8233]),
(10737, #[1309, 1310, 1312, 1313, 1314], #[7, 4503, 8268]),
(10738, #[1315, 1316, 1317, 1319, 1320], #[8, 6639, 8294]),
(10739, #[-1309, -1315, -1321, -1327], #[1, 4, 5, 29, 2095, 8402])]
#print axioms first24
end Euler.C14.IndexedDraft
