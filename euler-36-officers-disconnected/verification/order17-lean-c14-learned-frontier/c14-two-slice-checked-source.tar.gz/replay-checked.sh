#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
: "${LEAN_BIN:?Set LEAN_BIN to ordinary Lean 4.36.0}"
: "${MATHLIB_LEAN_PATH:?Set MATHLIB_LEAN_PATH to pinned upstream build/lib/lean directories}"
export LEAN_PATH="$PWD:$MATHLIB_LEAN_PATH"
mkdir -p replay-tmp replay-logs
export TMPDIR="$PWD/replay-tmp"
if [[ -n "${EULER_REPLAY_SHARED_LOCK:-}" ]]; then
  exec 9>"$EULER_REPLAY_SHARED_LOCK"; flock -n 9
fi
sha256sum --strict -c CHECKED-SOURCE.sha256
while IFS= read -r module; do
  timeout --foreground --kill-after=4 37 "$LEAN_BIN" -j1 -M2300 -DwarningAsError=true \
    -R "$PWD" -o "$module.olean" "$PWD/$module.lean" 2>&1 | tee "replay-logs/$module.log"
  ! grep -Eq 'sorryAx|ofReduceBool|trustCompiler' "replay-logs/$module.log"
done < compile-order.txt
