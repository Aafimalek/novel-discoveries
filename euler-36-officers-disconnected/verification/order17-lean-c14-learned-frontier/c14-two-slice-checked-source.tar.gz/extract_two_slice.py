#!/usr/bin/env python3
"""Bounded audit of C14's first learned dependency in the selected sorted LRAT."""
import argparse, hashlib, json
from pathlib import Path
p=argparse.ArgumentParser()
p.add_argument('core',type=Path);p.add_argument('trace',type=Path);p.add_argument('out',type=Path)
p.add_argument('--cap',type=int,default=196608)
a=p.parse_args()
assert 1<=a.cap<=262144
a.out.mkdir(parents=True,exist_ok=True)

def sha(b):return hashlib.sha256(b).hexdigest()

with a.core.open('rb') as f:
    header=f.readline().split()
assert header==[b'p',b'cnf',b'10646',b'8825'],header
v,N=map(int,header[2:]);live=set(range(1,N+1));known=set(live)
events=[]; additions={}; end=0; count=0
with a.trace.open('rb') as f:
    while end<a.cap:
        b=f.readline(a.cap-end)
        if not b or not b.endswith(b'\n'):break
        begin=end;end+=len(b)
        ts=b.split()
        if ts[1]==b'd':
            dd=list(map(int,ts[2:]))
            assert dd[-1]==0 and set(dd[:-1])<=live
            live.difference_update(dd[:-1])
            events.append((begin,end,b,None))
            continue
        part=list(map(int,ts)); z=part.index(0)
        iid=part[0]; row=part[1:z]; hints=part[z+1:-1]
        assert iid>N and iid not in known and part[-1]==0
        assert all(x in live for x in hints) and all(0<abs(x)<=v for x in row), (iid,hints)
        count+=1
        adds=dict(id=iid,clause=row,hints=hints,addition_number=count,
                  byte_begin=begin,byte_end=end,event_index=len(events))
        additions[iid]=adds;events.append((begin,end,b,iid));known.add(iid);live.add(iid)
        if any(h>N for h in hints):
            consumer=adds;break
    else: raise RuntimeError('No dependency before byte cap')
assert 'consumer' in locals()
boundary=consumer['hints']
assert consumer['id']==11163 and consumer['addition_number']==432
assert boundary==[10801,10802],boundary
prod=[additions[x] for x in boundary]
assert [x['addition_number'] for x in prod]==[85,86]
assert all(all(0<j<=N for j in k['hints']) for k in prod)
ids=set(x for k in prod for x in k['hints'])
actual={}
with a.core.open('rb') as f:
    next(f)
    for i,b in enumerate(f,1):
        if i in ids:
            ns=list(map(int,b.split()));assert ns[-1]==0 and all(0<abs(x)<=v for x in ns[:-1])
            actual[i]=ns[:-1]
        if i==max(ids):break
assert set(actual)==ids

def rup(k):
    known_false=set(k['clause']); steps=[]
    for j,h in enumerate(k['hints']):
        source=actual[h] if h<=N else additions[h]['clause']
        remain=[x for x in source if x not in known_false]
        if j+1==len(k['hints']):
            assert not remain,(k['id'],h,remain)
            steps.append(dict(row=h,conflict=True))
        else:
            assert len(remain)==1,(k['id'],h,remain)
            steps.append(dict(row=h,unit=remain[0]))
            known_false.add(-remain[0])
    return steps
for k in [*prod,consumer]:k['rup']=rup(k)
A=b''.join(x[2] for x in events[prod[0]['event_index']:prod[-1]['event_index']+1])
B=events[consumer['event_index']][2]
# The A bytes are a contiguous raw interval. B is one raw addition at a
# later position; liveness and exact contents are checked across the gap.
assert [x[3] for x in events[prod[0]['event_index']:prod[-1]['event_index']+1] if x[3] is not None]==boundary
assert len(A)<32768 and len(B)<32768
def manifest(k):
    return [(j,additions[j]['clause']) for j in k]
ain=list(actual.items());mid=manifest(boundary);bout=manifest([consumer['id']])
(a.out/'producer.lrat').write_bytes(A)
(a.out/'consumer.lrat').write_bytes(B)
meta=dict(trace_scan_cap=a.cap,bytes_read=end,scanned_additions=count,
          sorted_core_sha256=sha(a.core.read_bytes()), producer_sha256=sha(A),
          consumer_sha256=sha(B),inputsA=ain,boundary=mid,outputsB=bout,
          producer_rows=prod,consumer=consumer, skipped_additions=consumer['addition_number']-prod[-1]['addition_number']-1,
          all_boundary_rows_live_at_consumer=all(i in live for i in boundary))
(a.out/'exact-two-slice.json').write_text(json.dumps(meta,indent=2)+'\n')
def lit(xs): return '['+', '.join(map(str,xs))+']'
def show(rows): return '['+',\n  '.join(f'({i}, {lit(c)})' for i,c in rows)+']'
def outfile(n,s): (a.out/n).write_text(s)
outfile('EulerC14FrontierData.lean',f'''import EulerRupFrontier
namespace Euler.RupFrontier.C14

def signedRows (rows : List (Nat × List Int)) : Frontier :=
  rows.map (fun r => (r.1,r.2.map Sat.Literal.ofInt))

def rawInputs : List (Nat × List Int) := {show(ain)}
def rawBoundary : List (Nat × List Int) := {show(mid)}
def rawOutput : List (Nat × List Int) := {show(bout)}

def inputs : Frontier := signedRows rawInputs
def boundary : Frontier := signedRows rawBoundary
def output : Frontier := signedRows rawOutput

end Euler.RupFrontier.C14
''')
def emit_slice(label,count,rawIn,highIn,highOut,rawOut,file,rows):
    src=f'''import EulerRupSliceDriver
import EulerC14FrontierData
namespace Euler.RupFrontier.C14.{label}

frontier_rup checked {count} {rawIn} (include_str "{file}")

theorem exact_input_formula : checked.cnf = frontierFormula {highIn} := by rfl

theorem step : Transformer {highIn} {highOut} := by
  intro row hm
  simp only [{highOut},{rawOut},signedRows,List.map_cons,List.map_nil,
    List.mem_cons,List.mem_nil_iff,or_false] at hm
'''
    if len(rows)>1:
        src+=f"  rcases hm with {' | '.join(['rfl']*len(rows))}\n"
        pre='· '
    else:
        src+='  subst row\n';pre=''
    for i,c in rows:
        src+=f'''  {pre}rw [← exact_input_formula]
  {'  ' if pre else ''}exact checked.row_{i}
'''
    src+=f'''\n#print axioms exact_input_formula
#print axioms step
end Euler.RupFrontier.C14.{label}
'''
    outfile(f'EulerC14{label}.lean',src)
emit_slice('Producer',2,'rawInputs','inputs','boundary','rawBoundary','producer.lrat',mid)
emit_slice('Consumer',1,'rawBoundary','boundary','output','rawOutput','consumer.lrat',bout)
outfile('EulerC14Compose.lean','''import EulerC14Producer
import EulerC14Consumer

namespace Euler.RupFrontier.C14

/-- Exact learned clauses proved in one independently compiled slice
provide the entire typed input of the next. -/
theorem composed : Transformer inputs output :=
  transformer_comp Producer.step Consumer.step

theorem fromCommonBase (f : Sat.Fmla) (ready : Derived f inputs) :
    Derived f output :=
  apply_transformer composed ready

#print axioms composed
#print axioms fromCommonBase
end Euler.RupFrontier.C14
''')
print(f'Lookahead {end} bytes, {count} additions; producer {boundary}, consumer {consumer["id"]}')
print(f'Producer 2 additions, {len(A)} raw bytes, {len(ain)} exact original live-ins and 2 learned outputs')
print(f'Consumer 1 addition, {len(B)} raw bytes, 2 learned live-ins (exact shared boundary), 1 nonempty learned output')
print(f'{meta["skipped_additions"]} unrelated or unused learned additions between producer and consumer; producer rows both live')
