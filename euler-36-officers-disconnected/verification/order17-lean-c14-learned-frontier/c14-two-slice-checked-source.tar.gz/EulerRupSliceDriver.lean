/- Uses Mathlib's RUP term builder, as the archived FactoredDriver does.
   This bounded pilot is a draft, not a completed C10 archive proof. -/
import EulerRupFrontier

open Lean Elab Command Term
open Mathlib.Tactic.Sat

namespace Euler.RupFrontier

set_option maxHeartbeats 900000
set_option maxRecDepth 8000

/-- Elaborate one small positive-hint RUP slice against its explicit live-in
    rows only. Creates ordinary kernel-checked learned-row theorems, not
    assumed proof rows. A separate exact transformer packages selected outputs. -/
elab "frontier_rup " name:ident arity:num ppSpace rows:term:max ppSpace trace:term:max : command => do
  let ns ← getCurrNamespace
  liftTermElabM do
    let root := ns ++ name.getId
    let inTy ← Term.elabType (← `(List (Nat × List Int)))
    let input ← unsafe evalTerm (List (Nat × List Int)) inTy rows
    let cert ← unsafe evalTerm String (Lean.mkConst ``String) trace
    let .success finish steps := Parser.parseLRAT ⟨_,cert.startPos⟩
      | throwError "slice LRAT rejected"
    unless decide finish.2.IsAtEnd do throwError "unparsed suffix in bounded slice"
    let expected := arity.getNat
    unless 1 ≤ expected ∧ expected ≤ 24 ∧ 0 < input.length ∧ input.length ≤ 80 ∧ cert.utf8ByteSize ≤ 32768 do
      throwError "slice exceeds explicit pilot bounds"
    let raw := input.toArray
    let data : Array (Array Int) := raw.map (fun row => row.2.toArray)
    let ctxName := root ++ `cnf
    let ctx := Lean.mkConst ctxName
    let ctxVal := buildConj data 0 data.size
    addDecl <| .defnDecl {
      name := ctxName, levelParams := [], type := Lean.mkConst ``Sat.Fmla,
      value := ctxVal, hints := .regular 0, safety := .safe
    }
    let start := mkApp (Lean.mkConst ``Sat.Fmla.subsumes_self) ctx
    let core := (buildClauses data ctx 0 data.size ctxVal start default).2
    let mut db : Std.HashMap Nat Mathlib.Tactic.Sat.Clause := {}
    let mut used : Std.HashSet Nat := {}
    for k in [:raw.size] do
      let (id, lits) := raw[k]!
      unless id > 0 && !used.contains id && lits.all (fun i => i != 0) do
        throwError "invalid initial frontier ID or zero literal"
      let some row := core[k+1]? | throwError "internal input position not found"
      db := db.insert id row
      used := used.insert id
    let mut count := 0
    for step in steps do
      match step with
      | .del ids => db := ids.foldl (·.erase ·) db
      | .add id lits hints =>
        unless count < expected && id > 0 && !used.contains id &&
          hints.size ≤ 64 && lits.size ≤ 32 && hints.all (fun h => h > 0) do
          throwError "addition exceeds pilot bounds, has a nonpositive hint, or repeats an ID"
        let row := buildClause lits
        let .ok proof := buildProofStep db lits hints ctx row
          | throwError "checked RUP term construction failed for row {id}"
        let thm := root ++ Name.mkSimple s!"row_{id}"
        addDecl <| .thmDecl {
          name := thm, levelParams := [],
          type := mkApp2 (Lean.mkConst ``Sat.Fmla.proof) ctx row, value := proof
        }
        used := used.insert id
        db := db.insert id { lits := lits, expr := row, proof := Lean.mkConst thm }
        count := count+1
    unless count == expected do throwError "wrong addition count: {count}"

end Euler.RupFrontier
