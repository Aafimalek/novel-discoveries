import C14ExactThrough9113
import C14ProofChunk9113_9120Draft
import C14ProofChunk9120_9126Draft
import C14ProofChunk9126_9134Draft
import C14ProofChunk9134_9141Draft
import C14ProofChunk9141_9147Draft
import C14ProofChunk9147_9154Draft
import C14ProofChunk9154_9160Draft
import C14ProofChunk9160_9166Draft
import C14ProofChunk9166_9172Draft
import C14ProofChunk9172_9179Draft
import C14ProofChunk9179_9185Draft
import C14ProofChunk9185_9191Draft
import C14ProofChunk9191_9196Draft
import C14ProofChunk9196_9201Draft
import C14ProofChunk9201_9208Draft
import C14ProofChunk9208_9214Draft
import C14ProofChunk9214_9220Draft
import C14ProofChunk9220_9226Draft
import C14ProofChunk9226_9230Draft
import C14ProofChunk9230_9235Draft
import C14ProofChunk9235_9241Draft
import C14ProofChunk9241_9247Draft
import C14ProofChunk9247_9252Draft
import C14ProofChunk9252_9276Draft
import C14ProofChunk9276_9278Draft

namespace Euler.C14.Production
open Euler.C14.IndexedDraft
set_option maxRecDepth 18000
set_option maxHeartbeats 2400000

theorem bandThrough9278 (base : Sat.Fmla) : Slice base rowAt 9113 9278 :=
  (compose (compose (compose (compose (chunk_9113_9120 base) (compose (chunk_9120_9126 base) (chunk_9126_9134 base))) (compose (chunk_9134_9141 base) (compose (chunk_9141_9147 base) (chunk_9147_9154 base)))) (compose (compose (chunk_9154_9160 base) (compose (chunk_9160_9166 base) (chunk_9166_9172 base))) (compose (chunk_9172_9179 base) (compose (chunk_9179_9185 base) (chunk_9185_9191 base))))) (compose (compose (compose (chunk_9191_9196 base) (compose (chunk_9196_9201 base) (chunk_9201_9208 base))) (compose (chunk_9208_9214 base) (compose (chunk_9214_9220 base) (chunk_9220_9226 base)))) (compose (compose (chunk_9226_9230 base) (compose (chunk_9230_9235 base) (chunk_9235_9241 base))) (compose (compose (chunk_9241_9247 base) (chunk_9247_9252 base)) (compose (chunk_9252_9276 base) (chunk_9276_9278 base))))))

theorem exactArchiveThrough9278 : GoodBelow archivedGlobalCore rowAt 9278 :=
  bandThrough9278 archivedGlobalCore exactArchiveThrough9113

#print axioms bandThrough9278
#print axioms exactArchiveThrough9278
end Euler.C14.Production
