import C14GlobalDriverDraft
namespace Euler.C14.Production
set_option maxRecDepth 18000
set_option maxHeartbeats 2400000
def fields_chunk_9276_9278 : Array (Nat × Nat × Array Int × Array (Nat × Array Int)) := #[
  (11311, 9276, #[-1328, -1329, -1331, -1332], #[(9275, #[-1327]), (9011, #[1327, -1328, -1329, 1330, -1331, -1332]), (9008, #[1327, -1328, -1329, -1330, -1331, -1332])]),
  (11313, 9277, #[-1308, -1304, -1306, -1307], #[(8874, #[-1304, -1305, -1306, -1307, -1308]), (8879, #[-1304, 1305, -1306, -1307, -1308])])
]
global_rup chunk_9276_9278 9276 fields_chunk_9276_9278
#print axioms chunk_9276_9278
end Euler.C14.Production
