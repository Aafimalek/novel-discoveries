import C14Row11641ExactArchive9424
import C14ProofChunk9424_9425Draft
import C14ProofChunk9425_9427Draft
import C14ProofChunk9427_9429Draft

namespace Euler.C14.Production
open Euler.C14.IndexedDraft

theorem band9424Through9429 (base : Sat.Fmla) : Slice base rowAt 9424 9429 :=
  compose (chunk_9424_9425 base) (compose (chunk_9425_9427 base) (chunk_9427_9429 base))

theorem exactArchiveThrough9429ViaPolarity : GoodBelow archivedGlobalCore rowAt 9429 :=
  band9424Through9429 archivedGlobalCore Euler.C14.PolarityDraft.exactArchiveThrough9424

#print axioms band9424Through9429
#print axioms exactArchiveThrough9429ViaPolarity
end Euler.C14.Production
