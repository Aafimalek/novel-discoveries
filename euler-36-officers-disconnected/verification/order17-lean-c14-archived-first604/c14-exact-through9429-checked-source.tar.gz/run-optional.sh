#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
sha256sum --check --status SHA256SUMS
[[ ${1:-} == --execute ]] || exit 0
root=$(cd .. && pwd)
prior="$root/euler-c14-polarity-late-run"
grep -Fxq "'Euler.C14.PolarityDraft.exactArchiveThrough9424' depends on axioms: [propext, Classical.choice, Quot.sound]" "$prior/logs/C14Row11641ExactArchive9424.log"
python3 - "$prior" <<'PY_CHECK'
import hashlib,json,sys
from pathlib import Path
d=Path(sys.argv[1])
raw=(d/'CHECKED-9424.json').read_bytes()
assert hashlib.sha256(raw).hexdigest()=='a35a263881ad2d6d518fa503b3f69fba611c251b1d34e27f25dbfc0a72fe1e55'
r=json.loads(raw)
assert r['slot']==9424 and r['learned']==599
assert len(r['module_records'])==40
for o in r['module_records'].values():
    assert o['origin'] in ('frozen456','current')
    origin=(d/'frozen456' if o['origin']=='frozen456' else d).resolve()
    for name,h in o['files'].items():
        p=(origin/name).resolve()
        assert p.is_relative_to(origin) and hashlib.sha256(p.read_bytes()).hexdigest()==h,p
print('Exact archived 599-prefix receipts validated across all 40 source/object/log records.')
PY_CHECK
exec flock -n /tmp/nine-149-next/.adaptive-sequential-124-127.lock timeout 160 bash -s -- "$root" "$prior" <<'INNER'
set -euo pipefail
W=$1; P=$2; ML="$W/.lean-check/mathlib4"
L="$W/.lean-check/lean-4.36.0-linux/bin/lean"
export LEAN_PATH="$PWD:$P:$P/generated:$P/frozen456:$P/frozen456/generated:$W/euler-c14-index-production:$W/euler-c14-index-production/generated:$W/euler-c14-indexed-check"
for q in   "$W/euler-c14-after9410/generated" "$W/euler-c14-after9410/through9410-baseline/generated"   "$W/euler-c14-after9373/through9373-baseline/generated" "$W/euler-c14-after9113/generated"   "$W/euler-c14-next-band/generated" "$W/euler-c14-original-prefix-draft"   "$ML/.lake/build/lib/lean" "$ML"/.lake/packages/*/.lake/build/lib/lean; do
  LEAN_PATH="$LEAN_PATH:$q"
done
export TMPDIR="$PWD/tmp"
mkdir -p tmp logs
for m in C14ProofChunk9424_9425Draft C14ProofChunk9425_9427Draft C14ProofChunk9427_9429Draft C14ExactThrough9429ViaPolarity; do
  timeout 47 "$L" -j1 -M2450 -DwarningAsError=true -R "$PWD" -o "$m.olean" "$m.lean" >"logs/$m.log" 2>&1
  cat "logs/$m.log"
  sha256sum "$m.lean" "$m.olean" "logs/$m.log" >"logs/$m.receipt"
done
grep -Fxq "'Euler.C14.Production.exactArchiveThrough9429ViaPolarity' depends on axioms: [propext, Classical.choice, Quot.sound]" logs/C14ExactThrough9429ViaPolarity.log
INNER
