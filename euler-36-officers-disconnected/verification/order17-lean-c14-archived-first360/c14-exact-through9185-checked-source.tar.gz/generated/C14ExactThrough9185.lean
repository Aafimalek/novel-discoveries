import C14ExactThrough9113
import C14ProofChunk9113_9120Draft
import C14ProofChunk9120_9126Draft
import C14ProofChunk9126_9134Draft
import C14ProofChunk9134_9141Draft
import C14ProofChunk9141_9147Draft
import C14ProofChunk9147_9154Draft
import C14ProofChunk9154_9160Draft
import C14ProofChunk9160_9166Draft
import C14ProofChunk9166_9172Draft
import C14ProofChunk9172_9179Draft
import C14ProofChunk9179_9185Draft

namespace Euler.C14.Production
open Euler.C14.IndexedDraft
set_option maxRecDepth 18000
set_option maxHeartbeats 2400000

theorem bandThrough9185 (base : Sat.Fmla) : Slice base rowAt 9113 9185 :=
  (compose (compose (compose (chunk_9113_9120 base) (chunk_9120_9126 base)) (compose (chunk_9126_9134 base) (compose (chunk_9134_9141 base) (chunk_9141_9147 base)))) (compose (compose (chunk_9147_9154 base) (compose (chunk_9154_9160 base) (chunk_9160_9166 base))) (compose (chunk_9166_9172 base) (compose (chunk_9172_9179 base) (chunk_9179_9185 base)))))

theorem exactArchiveThrough9185 : GoodBelow archivedGlobalCore rowAt 9185 :=
  bandThrough9185 archivedGlobalCore exactArchiveThrough9113

#print axioms bandThrough9185
#print axioms exactArchiveThrough9185
end Euler.C14.Production
