# C14 bounded static recut immediately after exact bound 9113
No Lean was invoked. This directory is a separate static stage; the
previous checked state in euler-c14-next-band is unchanged. The exact
baseline is theorem Euler.C14.Production.exactArchiveThrough9113,
GoodBelow archivedGlobalCore rowAt 9113 (288 learned additions).

The old [9113,9127) slice had 1,800 hints and timed out in 47 seconds.
The same initial proof is now covered by [9113,9120) /820 hints,
[9120,9126) /882 hints and the first part of [9126,9134) /843 hints.
The generated target [9113,9278) comprises 25 adjacent slices, 165
additional learned clauses and 19,694 exact archived hint references.
Each slice has at most 900 hints and 24 additions (rows with >=550
hints are isolated in the planner). The largest actual slice has 893
hints; no row in this target violates the cap. A terminal target here
would verify 453 learned additions, but none are claimed until Lean
succeeds. There is a balanced prefix aggregate for each of the 25
possible stopping endpoints, with the same checked rowAt and archive.

generate-band.py takes raw sorted archived 1.cnf and 1.lrat and verifies
their hashes, expected dimensions, every row and original-deletion
liveness and exact ID positions. Slice literals and hints come from
those bytes. Import is by typed ordinary Lean proof of actual indexed
clauses, not a trusted hash. Both archive hashes are in generated/band.json.

Run python3 run-band.py for the default static preflight. It verifies
the frozen Lean binary hash, key pinned SAT/Omega imports, all prior
global/original source and object manifests, all ten immutable objects
(including aggregate) from through9113 against the accepted original
receipts and source/log hashes, and endpoints/known axiom line, then
all generated source and plan hashes and adjacency. This is a pinned
project-visible closure check, not an independent full source rebuild of
upstream Mathlib. Use the sealed static package checksums as a precheck.

Only after sole heavy slot is granted:
    sha256sum --check --status SHA256SUMS && python3 run-band.py --execute --seconds 285

The worker uses the shared nonblocking exclusive lock, overlay TMPDIR,
one ordinary Lean 4.36 process at a time, -j1 -M2450, strict warnings
and a monotone 285s total deadline (<=47s per leaf). Unfinished leaves
get no receipt. Every receipt commits source, actual object, expected
axiom log, and full pinned closure. A restart uses only valid receipts.
It reserves time to build the last continuous prefix's own balanced
aggregate instead of citing isolated leaves. After finish, use
python3 freeze-checked.py only when logs/latest-composed.json exists.
The frozen result proof and audit packages leave this original static
plan separately available for continuing work. No whole C14 refutation,
core containment, or geometric closure follows from this partial band.
