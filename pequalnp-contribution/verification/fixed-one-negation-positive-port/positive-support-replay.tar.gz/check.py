#!/usr/bin/env python3
"""Statically add only the proved raw-positive-port use clause, no SAT run."""
from pathlib import Path
from base import edge_value
from strong import Strong, normal, witness

def patch(E):
    old = tuple(k for g in E.gates for j in (0, 8) for k in (g.left[j], g.right[j]))
    new = tuple(k for g in E.gates for k in (g.left[0], g.right[0]))
    hits = [i for i, row in enumerate(E.rows) if tuple(row) == old]
    assert len(hits) == 1
    before = tuple(map(tuple,E.rows))
    E.rows[hits[0]] = new
    after = tuple(map(tuple,E.rows))
    assert len(before) == len(after)
    assert sum(a != b for a,b in zip(before,after)) == 1
    assert len(new) == E.n * 2 and set(new) < set(old)
    return hits[0] + 1

def main():
    pivots = [y for y in range(0,256,2) if not edge_value(y) and edge_value(y+1)]
    assert pivots and all(not edge_value(y) or edge_value(y+1) for y in range(0,256,2))
    print(f"Exact x0 target pivots among 128 settings: {len(pivots)} {pivots}.")
    E = Strong(14)
    row = patch(E)
    E.dimacs(Path("raw_x0_14_positive_support.cnf"))
    print(f"{E.num_vars} variables, {len(E.rows)} clauses, {sum(map(len,E.rows))} literals.")
    print(f"Only clause {row} changed: 56 raw x0-or-b literals became 28 raw x0 literals.")
    control = Strong(17)
    patch(control)
    dag, used = normal(witness(),17)
    assert control.check_model(control.stitch_normal(dag,used)) == dag
    print(f"Known positive control retained: {used} active gates, exact DAG/256 tests.")
    print("No SAT or UNSAT result for the 14-gate instance.")
if __name__ == "__main__":
    main()
