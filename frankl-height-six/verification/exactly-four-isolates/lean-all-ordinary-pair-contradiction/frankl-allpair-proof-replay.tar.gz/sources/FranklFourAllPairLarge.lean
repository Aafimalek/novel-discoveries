import FranklFourAllPairHoleInter

/- Direct Lean-checked all-pair d=0 branch and supporting lemmas. -/
namespace FranklForcingFiber
variable {α : Type*} [DecidableEq α]

theorem exact_four_allPair_full_atoms {G : Finset (Finset α)} {p q : α}
    (hG : NoStrictMajority G) (hm : WeakMinimalGround G)
    (hI : (isolated G).card = 4) (hB : AllOrdinaryStarPairs G)
    (hk : 3 ≤ (sources G).card)
    (hp : p ∈ sources G) (hq : q ∈ sources G) (hpq : p ≠ q) :
    missingPairIsolates G p q = ∅ ∧
    FranklRankTwoAtoms.atoms (starPairTrueComplement G p q) =
      (ground (compressedStarPair G p q)).image (fun x => ({x} : Finset α)) := by
  classical
  have ex (r : α) (hr : r ∈ sources G) :=
    exact_four_allPair_one_mixed_each_source hG hm hI hB hk hr
  let H (r : α) : Finset (Finset α) :=
    if hr : r ∈ sources G then {Classical.choose (ex r hr)} else ∅
  have hH : ∀ r ∈ (sources G \ {p,q}), ∀ J ∈ H r,
      J ⊆ isolated G ∧ J.Nonempty ∧ mixedStarOmission G r J ∈ G := by
    intro r hr J hJ
    have hrS := (Finset.mem_sdiff.mp hr).1
    simp only [H,dite_eq_left hrS,Finset.mem_singleton] at hJ
    subst J
    exact Classical.choose_spec (ex r hrS)
  have hHc : ∀ r ∈ (sources G \ {p,q}), 1 ≤ (H r).card := by
    intro r hr
    simp [H,(Finset.mem_sdiff.mp hr).1]
  have hlo := exact_four_allPair_avoidance_lower_lists hG hm hI hB hp hq hpq H hH hHc
  let U := ground (compressedStarPair G p q)
  let D := starPairTrueComplement G p q
  let A := FranklRankTwoAtoms.atoms D
  let k := (sources G).card
  obtain ⟨_,hD,_,hU⟩ := starPairTrueComplement_rankTwo hG hm hp hq hpq
  have hs := trueSupport_card_and_missing_eq_four hG hm hI hB hp hq hpq
  change U.card + (missingPairIsolates G p q).card = k + 2 at hs
  have hu := leafPairAvoidance_card_le_trueSupport_atoms hG hm hp hq hpq
  change _ ≤ 1 + U.card + A.card.choose 2 at hu
  have hAc : A.card ≤ U.card := (FranklRankTwoAtoms.atoms_card_le_covered hD).trans
    (Finset.card_le_card (FranklRankTwoAtoms.covered_subset_support hU))
  have ha : A.card = k + 2 := by
    by_contra hn
    have hAle : A.card ≤ k + 1 := by omega
    have hCh := Nat.choose_le_choose 2 hAle
    have hPas : (k + 1).choose 2 = k + k.choose 2 := by
      simpa using (Nat.choose_succ_succ' k 1)
    change k.choose 2 + k + 6 + (k - 2) * 1 ≤ _ at hlo
    change 3 ≤ k at hk
    omega
  have hM : (missingPairIsolates G p q).card = 0 := by omega
  have hAU : A.card = U.card := by omega
  exact ⟨Finset.card_eq_zero.mp hM,
    FranklRankTwoAtoms.atoms_eq_singletons_of_card_eq_support hD hU hAU⟩

theorem exact_four_allPair_all_singleton_holes {G : Finset (Finset α)} {p q x : α}
    (hG : NoStrictMajority G) (hm : WeakMinimalGround G)
    (hI : (isolated G).card = 4) (hB : AllOrdinaryStarPairs G)
    (hk : 3 ≤ (sources G).card)
    (hp : p ∈ sources G) (hq : q ∈ sources G) (hpq : p ≠ q)
    (hx : x ∈ isolated G) : AllowedPairIsolateHole G p q {x} := by
  obtain ⟨hM,hAtoms⟩ := exact_four_allPair_full_atoms hG hm hI hB hk hp hq hpq
  have hxT : x ∈ starPairMax G p q := by
    by_contra hn
    have hxM : x ∈ missingPairIsolates G p q := Finset.mem_sdiff.mpr ⟨hx,hn⟩
    simp [hM] at hxM
  have hxU := (isolate_mem_trueSupport_iff_present hG hm hp hq hpq hx).mpr hxT
  have hxA : ({x} : Finset α) ∈ FranklRankTwoAtoms.atoms (starPairTrueComplement G p q) :=
    hAtoms.symm ▸ Finset.mem_image.mpr ⟨x,hxU,rfl⟩
  refine ⟨{x},Finset.singleton_subset_iff.mpr hx,(FranklRankTwoAtoms.mem_atoms.mp hxA).1,?_⟩
  change missingPairIsolates G p q ∪ {x} = {x}
  simp [hM]

theorem exact_four_allPair_mixed_singleton_each_source {G : Finset (Finset α)} {r x : α}
    (hG : NoStrictMajority G) (hm : WeakMinimalGround G)
    (hI : (isolated G).card = 4) (hB : AllOrdinaryStarPairs G)
    (hk : 3 ≤ (sources G).card) (hr : r ∈ sources G)
    (hx : x ∈ isolated G) : mixedStarOmission G r {x} ∈ G := by
  obtain ⟨a,ha,b,hb,hra,hrb,hab⟩ := two_other_sources_of_three hk hr
  have hmixed := mixedStarOmission_mem_of_allowed_inter hG hm hI hB hr ha hb hra hrb hab
    (exact_four_allPair_all_singleton_holes hG hm hI hB hk hr ha hra hx)
    (exact_four_allPair_all_singleton_holes hG hm hI hB hk hr hb hrb hx)
  simpa using hmixed

/-- Large counting contradiction; the k=3 equality/saturation and k=2
small-support branches are deliberately separate. -/
theorem exact_four_allPair_not_four_le_sources {G : Finset (Finset α)}
    (hG : NoStrictMajority G) (hm : WeakMinimalGround G)
    (hI : (isolated G).card = 4) (hB : AllOrdinaryStarPairs G)
    (hk : 4 ≤ (sources G).card) : False := by
  let k := (sources G).card
  change 4 ≤ k at hk
  obtain ⟨p,hp,q,hq,hpq⟩ := Finset.one_lt_card.mp (show 1 < k by omega)
  let H (_ : α) := (isolated G).image (fun x => ({x} : Finset α))
  have hH : ∀ r ∈ (sources G \ {p,q}), ∀ J ∈ H r,
      J ⊆ isolated G ∧ J.Nonempty ∧ mixedStarOmission G r J ∈ G := by
    intro r hr J hJ
    have hrS := (Finset.mem_sdiff.mp hr).1
    obtain ⟨x,hx,rfl⟩ := Finset.mem_image.mp hJ
    exact ⟨Finset.singleton_subset_iff.mpr hx,⟨x,Finset.mem_singleton_self _⟩,
      exact_four_allPair_mixed_singleton_each_source hG hm hI hB (by omega) hrS hx⟩
  have hHc : ∀ r ∈ (sources G \ {p,q}), 4 ≤ (H r).card := by
    intro r _
    change 4 ≤ ((isolated G).image (fun x => ({x} : Finset α))).card
    rw [Finset.card_image_of_injOn (fun _ _ _ _ he => Finset.singleton_inj.mp he),hI]
  have hlo := exact_four_allPair_avoidance_lower_lists hG hm hI hB hp hq hpq H hH hHc
  change k.choose 2 + k + 6 + (k - 2) * 4 ≤ _ at hlo
  have hu := cross_pair_actual_upper_of_omitted hG hm hp hq hpq
  dsimp at hu
  rw [omittedStars_eq_pair_of_allPairBlocks hp hq hpq hB,hI] at hu
  have hpc : ({p,q} : Finset α).card = 2 := by simp [hpq]
  rw [hpc] at hu
  have he : 4 + ((sources G).card - 2) = k + 2 := by omega
  rw [he] at hu
  have h₁ : (k + 1).choose 2 = k + k.choose 2 := by
    simpa using (Nat.choose_succ_succ' k 1)
  have h₂ : (k + 2).choose 2 = (k + 1) + (k + 1).choose 2 := by
    simpa [Nat.add_assoc] using (Nat.choose_succ_succ' (k + 1) 1)
  omega

#print axioms exact_four_allPair_full_atoms
#print axioms exact_four_allPair_mixed_singleton_each_source
#print axioms exact_four_allPair_not_four_le_sources
end FranklForcingFiber
