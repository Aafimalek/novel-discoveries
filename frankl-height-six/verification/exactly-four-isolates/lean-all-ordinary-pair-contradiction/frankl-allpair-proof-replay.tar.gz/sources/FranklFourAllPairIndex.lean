import FranklFourAllPairBaseline

/- Direct Lean-checked all-pair d=0 branch and supporting lemmas. -/
open scoped BigOperators
namespace FranklForcingFiber
variable {α : Type*} [DecidableEq α]

/-- Independent finite lists of certified isolate holes, over each exterior
source. Pairing with the source keeps collisions between lists impossible. -/
noncomputable def allPairMixedIndices (G : Finset (Finset α)) (p q : α)
    (H : α → Finset (Finset α)) : Finset (α × Finset α) :=
  ((sources G) \ {p,q}).biUnion (fun r => (H r).image (Prod.mk r))

theorem mem_allPairMixedIndices {G : Finset (Finset α)} {p q r : α}
    {H : α → Finset (Finset α)} {J : Finset α} :
    (r,J) ∈ allPairMixedIndices G p q H ↔ r ∈ (sources G \ {p,q}) ∧ J ∈ H r := by
  change (r,J) ∈ ((sources G \ {p,q}).biUnion
    (fun v => (H v).image (Prod.mk v))) ↔ _
  constructor
  · intro hz
    obtain ⟨v,hv,hJ⟩ := Finset.mem_biUnion.mp hz
    obtain ⟨T,hT,he⟩ := Finset.mem_image.mp hJ
    have hvr : v = r := congrArg Prod.fst he
    have hTJ : T = J := congrArg Prod.snd he
    subst v
    subst T
    exact ⟨hv,hT⟩
  · rintro ⟨hr,hJ⟩
    exact Finset.mem_biUnion.mpr ⟨r,hr,Finset.mem_image.mpr ⟨J,hJ,rfl⟩⟩

theorem allPairMixedIndices_card (G : Finset (Finset α)) (p q : α)
    (H : α → Finset (Finset α)) :
    (allPairMixedIndices G p q H).card =
      ∑ r ∈ (sources G \ {p,q}), (H r).card := by
  classical
  unfold allPairMixedIndices
  rw [Finset.card_biUnion]
  · apply Finset.sum_congr rfl
    intro r _
    exact Finset.card_image_of_injOn (fun _ _ _ _ he => congrArg Prod.snd he)
  · intro r _ v _ hne
    apply Finset.disjoint_left.mpr
    intro z hz hw
    obtain ⟨J,_,hJ⟩ := Finset.mem_image.mp hz
    obtain ⟨T,_,hT⟩ := Finset.mem_image.mp hw
    exact hne (congrArg Prod.fst (hJ.trans hT.symm))

theorem exact_four_allPair_avoidance_lower_lists {G : Finset (Finset α)} {p q : α}
    (hG : NoStrictMajority G) (hm : WeakMinimalGround G)
    (hI : (isolated G).card = 4) (hB : AllOrdinaryStarPairs G)
    (hp : p ∈ sources G) (hq : q ∈ sources G) (hpq : p ≠ q)
    (H : α → Finset (Finset α))
    (hH : ∀ r ∈ (sources G \ {p,q}), ∀ J ∈ H r,
      J ⊆ isolated G ∧ J.Nonempty ∧ mixedStarOmission G r J ∈ G)
    {a : ℕ} (ha : ∀ r ∈ (sources G \ {p,q}), a ≤ (H r).card) :
    (sources G).card.choose 2 + (sources G).card + 6 +
      ((sources G).card - 2) * a ≤
      (avoidBoth G (starLeaf G p) (starLeaf G q)).card := by
  classical
  let K := allPairMixedIndices G p q H
  have hK : ∀ z ∈ K, z.1 ∈ sources G ∧ z.1 ≠ p ∧ z.1 ≠ q ∧
      z.2 ⊆ isolated G ∧ z.2.Nonempty ∧ mixedStarOmission G z.1 z.2 ∈ G := by
    rintro ⟨r,J⟩ hz
    obtain ⟨hr,hJ⟩ := mem_allPairMixedIndices.mp hz
    obtain ⟨hrS,hrN⟩ := Finset.mem_sdiff.mp hr
    exact ⟨hrS,(fun e => hrN (Finset.mem_insert.mpr (Or.inl e))),(fun e => hrN (Finset.mem_insert_of_mem (Finset.mem_singleton.mpr e))),hH r hr J hJ⟩
  have hl := exact_four_allPair_avoidance_lower hG hm hI hB hp hq hpq K hK
  have hc : ((sources G).card - 2) * a ≤ K.card := by
    rw [show K.card = ∑ r ∈ (sources G \ {p,q}), (H r).card from
      allPairMixedIndices_card G p q H, ← sources_sdiff_pair_card hp hq hpq]
    simpa using (Finset.sum_le_sum (s := sources G \ {p,q}) (f := fun _ => a)
      (g := fun r => (H r).card) ha)
  omega

#print axioms allPairMixedIndices_card
#print axioms exact_four_allPair_avoidance_lower_lists
end FranklForcingFiber
