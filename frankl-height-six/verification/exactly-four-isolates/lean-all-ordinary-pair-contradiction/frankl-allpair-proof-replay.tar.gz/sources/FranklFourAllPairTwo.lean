import FranklFourAllPairBaseline

/- Direct Lean-checked all-pair d=0 branch and supporting lemmas. -/
namespace FranklForcingFiber
variable {α : Type*} [DecidableEq α]

/-- With exactly two unary sources, their raw avoidance maximum has at
most four points: it misses both disjoint two-point stars. The checked
small-support bound counts at most five actual old family members,
whereas the all-pair baseline requires nine. -/
theorem exact_four_allPair_not_two_sources {G : Finset (Finset α)}
    (hG : NoStrictMajority G) (hm : WeakMinimalGround G)
    (hI : (isolated G).card = 4) (hB : AllOrdinaryStarPairs G)
    (hk : (sources G).card = 2) : False := by
  classical
  obtain ⟨p,hp,q,hq,hpq⟩ := Finset.one_lt_card.mp
    (show 1 < (sources G).card by omega)
  let U := ground G
  let T := starPairMax G p q
  let S := chosenStarPoints G p ∪ chosenStarPoints G q
  have hU : U.card = 8 := by
    have h := exact_four_unary_ground_card hG hm hI (show 2 ≤ (sources G).card by omega)
    change U.card = 2 * (sources G).card + 4 at h
    omega
  have hSc : S.card = 4 := by
    change (chosenStarPoints G p ∪ chosenStarPoints G q).card = 4
    rw [Finset.card_union_of_disjoint (chosenStarPoints_disjoint_of_sources hG hm hp hq hpq)]
    have hP : (chosenStarPoints G p).card = 2 := by
      simp [chosenStarPoints,(starLeaf_spec hp).1]
    have hQ : (chosenStarPoints G q).card = 2 := by
      simp [chosenStarPoints,(starLeaf_spec hq).1]
    omega
  have hOrd := omittedStars_eq_pair_of_allPairBlocks hp hq hpq hB
  have hCompl := ground_sdiff_starPairMax_of_ordinary_pair hG hm hp hq hpq
    (exact_four_unaryAtChosenLeaf hG hm hI (show 2 ≤ (sources G).card by omega) hp)
    (exact_four_unaryAtChosenLeaf hG hm hI (show 2 ≤ (sources G).card by omega) hq) hOrd
  change U \ T = S ∪ (isolated G \ T) at hCompl
  have hSsub : S ⊆ U \ T := by
    rw [hCompl]
    exact Finset.subset_union_left
  have hTc : T.card ≤ 4 := by
    have hTs : T ⊆ U := subset_ground (starPairMax_mem_family hG hm hp hq hpq)
    have h := Finset.card_sdiff_add_card_eq_card hTs
    have hh := Finset.card_le_card hSsub
    omega
  have hCap := weak_four_support_card_le_five hG
    (E := avoidBoth G (starLeaf G p) (starLeaf G q)) (Finset.filter_subset _ _) hTc
    (fun _ ha => subset_ground ha)
  have hlo := exact_four_allPair_avoidance_lower hG hm hI hB hp hq hpq
    (∅ : Finset (α × Finset α)) (by simp)
  rw [hk] at hlo
  have hChoose : (2 : ℕ).choose 2 = 1 := by decide
  rw [hChoose,Finset.card_empty] at hlo
  omega

#print axioms exact_four_allPair_not_two_sources
end FranklForcingFiber
