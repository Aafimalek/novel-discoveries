import FranklFourAllPairSupport

/- Direct Lean-checked all-pair d=0 branch and supporting lemmas. -/
namespace FranklForcingFiber
variable {α : Type*} [DecidableEq α]

/-- The absolute isolate hole of a pair-fiber member obtained by a relative
omission not involving any representative center. -/
def AllowedPairIsolateHole (G : Finset (Finset α)) (p q : α) (A : Finset α) : Prop :=
  ∃ J ⊆ isolated G, J ∈ starPairTrueComplement G p q ∧ pairIsolateHole G p q J = A

/-- Only the availability promised by each type is asserted; a fiber can
have additional holes and can satisfy more than one type. -/
def GoodFourHoleType (G : Finset (Finset α)) (p q : α) : Prop :=
  (∃ E ⊆ isolated G, 3 ≤ E.card ∧ ∀ x ∈ E, AllowedPairIsolateHole G p q {x}) ∨
  (∃ E ⊆ isolated G, E.card = 2 ∧ AllowedPairIsolateHole G p q E ∧
    ∀ x ∈ isolated G \ E, AllowedPairIsolateHole G p q {x}) ∨
  (∃ z ∈ isolated G, AllowedPairIsolateHole G p q {z} ∧
    ∀ x ∈ (isolated G).erase z, AllowedPairIsolateHole G p q {z,x})

theorem exact_four_allPair_holeTypes {G : Finset (Finset α)} {p q : α}
    (hG : NoStrictMajority G) (hm : WeakMinimalGround G)
    (hI : (isolated G).card = 4) (hB : AllOrdinaryStarPairs G)
    (hp : p ∈ sources G) (hq : q ∈ sources G) (hpq : p ≠ q) :
    GoodFourHoleType G p q := by
  classical
  let I := isolated G
  let U := ground (compressedStarPair G p q)
  let D := starPairTrueComplement G p q
  let M := missingPairIsolates G p q
  obtain ⟨h0,hD,_,hU⟩ := starPairTrueComplement_rankTwo hG hm hp hq hpq
  have hs := trueSupport_card_and_missing_eq_four hG hm hI hB hp hq hpq
  obtain ⟨ha,_⟩ := exact_four_allPair_nearMax hG hm hI hB hp hq hpq
  have hNear : U.card ≤ (FranklRankTwoAtoms.atoms D).card + 1 := by
    change U.card + M.card = (sources G).card + 2 at hs
    change (sources G).card + 1 ≤ (FranklRankTwoAtoms.atoms D).card at ha
    omega
  by_cases hempty : M = ∅
  · have hFull : I ⊆ U := by
      intro x hx
      apply (isolate_mem_trueSupport_iff_present hG hm hp hq hpq hx).mpr
      by_contra hn
      have hxM : x ∈ M := Finset.mem_sdiff.mpr ⟨hx,hn⟩
      simp [hempty] at hxM
    have allowed {J : Finset α} (hJI : J ⊆ I) (hJD : J ∈ D) :
        AllowedPairIsolateHole G p q J := by
      refine ⟨J,hJI,hJD,?_⟩
      change M ∪ J = J
      simp [hempty]
    let Bad : Finset α := I.filter (fun x => ({x} : Finset α) ∉ FranklRankTwoAtoms.atoms D)
    have hBadI : Bad ⊆ I := fun _ h => (Finset.mem_filter.mp h).1
    have chooseA (hsmall : Bad.card ≤ 1) : GoodFourHoleType G p q := by
      left
      refine ⟨I \ Bad,Finset.sdiff_subset,?_,?_⟩
      · have hc := Finset.card_sdiff_add_card_eq_card hBadI
        change I.card = 4 at hI
        omega
      · intro x hx
        obtain ⟨hxI,hxBad⟩ := Finset.mem_sdiff.mp hx
        have hAtom : ({x} : Finset α) ∈ FranklRankTwoAtoms.atoms D := by
          by_contra hn
          exact hxBad (Finset.mem_filter.mpr ⟨hxI,hn⟩)
        exact allowed (Finset.singleton_subset_iff.mpr hxI) (FranklRankTwoAtoms.mem_atoms.mp hAtom).1
    rcases FranklRankTwoAtoms.nearMaxAtoms_geometry hD hU hNear with ⟨hone,hGap⟩ |
      ⟨B,hBAtom,hBcard,hCov,hRest⟩
    · apply chooseA
      have hsub : Bad ⊆ U \ FranklRankTwoAtoms.covered D := by
        intro x hx
        obtain ⟨hxI,hn⟩ := Finset.mem_filter.mp hx
        refine Finset.mem_sdiff.mpr ⟨hFull hxI,?_⟩
        intro hxc
        exact hn (FranklRankTwoAtoms.support_point_singleton_of_atomCover hxc (fun A hA _ => hone A hA))
      exact (Finset.card_le_card hsub).trans hGap
    · by_cases hbc : Bad.card ≤ 1
      · exact chooseA hbc
      · have hsubB : Bad ⊆ B := by
          intro x hx
          obtain ⟨hxI,hn⟩ := Finset.mem_filter.mp hx
          by_contra hxB
          have hxc : x ∈ FranklRankTwoAtoms.covered D := hCov.symm ▸ hFull hxI
          exact hn (FranklRankTwoAtoms.support_point_singleton_of_atomCover hxc (by
            intro A hA hxA
            exact hRest A hA (fun e => hxB (e ▸ hxA))))
        have hce := Finset.card_le_card hsubB
        have hEq : Bad = B := Finset.eq_of_subset_of_card_le hsubB (by omega)
        have hBI : B ⊆ I := hEq ▸ hBadI
        right
        left
        refine ⟨B,hBI,hBcard,allowed hBI (FranklRankTwoAtoms.mem_atoms.mp hBAtom).1,?_⟩
        intro x hx
        obtain ⟨hxI,hxB⟩ := Finset.mem_sdiff.mp hx
        have hAtom : ({x} : Finset α) ∈ FranklRankTwoAtoms.atoms D := by
          by_contra hn
          exact hxB (hEq ▸ Finset.mem_filter.mpr ⟨hxI,hn⟩)
        exact allowed (Finset.singleton_subset_iff.mpr hxI) (FranklRankTwoAtoms.mem_atoms.mp hAtom).1
  · have hn : M.Nonempty := Finset.nonempty_iff_ne_empty.mpr hempty
    obtain ⟨hm1,hAtoms⟩ := exact_four_allPair_missing_implies_all_atoms hG hm hI hB hp hq hpq hn
    obtain ⟨z,hz⟩ := Finset.card_eq_one.mp hm1
    change M = {z} at hz
    have hMz : z ∈ M := hz.symm ▸ (Finset.mem_singleton_self z)
    have hzI : z ∈ I := (Finset.mem_sdiff.mp hMz).1
    right
    right
    refine ⟨z,hzI,⟨∅,Finset.empty_subset I,h0,?_⟩,?_⟩
    · change M ∪ ∅ = {z}
      simpa using hz
    · intro x hx
      obtain ⟨hxz,hxI⟩ := Finset.mem_erase.mp hx
      have hxT : x ∈ starPairMax G p q := by
        by_contra hnT
        have hxM : x ∈ M := Finset.mem_sdiff.mpr ⟨hxI,hnT⟩
        exact hxz (Finset.mem_singleton.mp (hz ▸ hxM))
      have hxU := (isolate_mem_trueSupport_iff_present hG hm hp hq hpq hxI).mpr hxT
      have hAtom : ({x} : Finset α) ∈ FranklRankTwoAtoms.atoms D :=
        hAtoms.symm ▸ Finset.mem_image.mpr ⟨x,hxU,rfl⟩
      refine ⟨{x},Finset.singleton_subset_iff.mpr hxI,(FranklRankTwoAtoms.mem_atoms.mp hAtom).1,?_⟩
      change M ∪ {x} = {z,x}
      rw [hz]
      ext y
      simp

#print axioms exact_four_allPair_holeTypes
end FranklForcingFiber
