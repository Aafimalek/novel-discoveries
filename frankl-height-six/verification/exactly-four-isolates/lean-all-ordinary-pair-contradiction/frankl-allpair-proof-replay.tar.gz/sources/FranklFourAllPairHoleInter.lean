import FranklFourAllPairHoleTypes
import FranklFourAllPairIndex

/- Direct Lean-checked all-pair d=0 branch and supporting lemmas. -/
namespace FranklForcingFiber
variable {α : Type*} [DecidableEq α]

theorem allowedPairIsolateHole_subset {G : Finset (Finset α)} {p q : α} {A : Finset α}
    (hA : AllowedPairIsolateHole G p q A) : A ⊆ isolated G := by
  obtain ⟨J,hJ,_,rfl⟩ := hA
  exact Finset.union_subset Finset.sdiff_subset hJ

/-- The listed holes cover at least three of the four isolate coordinates.
This is enough to make two independently classified pairs intersect. -/
theorem goodFourHoleType_covered {G : Finset (Finset α)} {p q : α}
    (hI : (isolated G).card = 4) (hT : GoodFourHoleType G p q) :
    ∃ C ⊆ isolated G, 3 ≤ C.card ∧
      ∀ x ∈ C, ∃ J, AllowedPairIsolateHole G p q J ∧ x ∈ J := by
  rcases hT with ⟨E,hE,hEc,hEa⟩ | ⟨E,hE,hEc,hEa,hEs⟩ | ⟨z,hz,hza,hze⟩
  · exact ⟨E,hE,hEc,fun x hx => ⟨{x},hEa x hx,Finset.mem_singleton_self _⟩⟩
  · refine ⟨isolated G,Finset.Subset.rfl,by omega,?_⟩
    intro x hx
    by_cases hn : x ∈ E
    · exact ⟨E,hEa,hn⟩
    · exact ⟨{x},hEs x (Finset.mem_sdiff.mpr ⟨hx,hn⟩),Finset.mem_singleton_self _⟩
  · refine ⟨isolated G,Finset.Subset.rfl,by omega,?_⟩
    intro x hx
    by_cases hn : x = z
    · subst x
      exact ⟨{z},hza,Finset.mem_singleton_self _⟩
    · exact ⟨{z,x},hze x (Finset.mem_erase.mpr ⟨hn,hx⟩),
        Finset.mem_insert_of_mem (Finset.mem_singleton_self _)⟩

theorem two_goodFourHoleTypes_inter {G : Finset (Finset α)} {p q r s : α}
    (hI : (isolated G).card = 4) (hA : GoodFourHoleType G p q) (hB : GoodFourHoleType G r s) :
    ∃ J K, AllowedPairIsolateHole G p q J ∧ AllowedPairIsolateHole G r s K ∧
      (J ∩ K).Nonempty := by
  obtain ⟨C,hC,hCc,hCa⟩ := goodFourHoleType_covered hI hA
  obtain ⟨D,hD,hDc,hDa⟩ := goodFourHoleType_covered hI hB
  have hc := Finset.card_le_card (Finset.union_subset hC hD)
  have hd := Finset.card_union_add_card_inter C D
  obtain ⟨x,hx⟩ := Finset.card_pos.mp (show 0 < (C ∩ D).card by omega)
  obtain ⟨J,hJ,hxJ⟩ := hCa x (Finset.mem_inter.mp hx).1
  obtain ⟨K,hK,hxK⟩ := hDa x (Finset.mem_inter.mp hx).2
  exact ⟨J,K,hJ,hK,x,Finset.mem_inter.mpr ⟨hxJ,hxK⟩⟩

theorem mixedStarOmission_mem_of_allowed_inter {G : Finset (Finset α)}
    {r a b : α} {J K : Finset α}
    (hG : NoStrictMajority G) (hm : WeakMinimalGround G)
    (hI : (isolated G).card = 4) (hB : AllOrdinaryStarPairs G)
    (hr : r ∈ sources G) (ha : a ∈ sources G) (hb : b ∈ sources G)
    (hra : r ≠ a) (hrb : r ≠ b) (hab : a ≠ b)
    (hJ : AllowedPairIsolateHole G r a J) (hK : AllowedPairIsolateHole G r b K) :
    mixedStarOmission G r (J ∩ K) ∈ G := by
  obtain ⟨J',hJ'I,hJ'D,rfl⟩ := hJ
  obtain ⟨K',hK'I,hK'D,rfl⟩ := hK
  have hk : 2 ≤ (sources G).card := Finset.one_lt_card.mpr ⟨r,hr,a,ha,hra⟩
  have un {x : α} (hx : x ∈ sources G) := exact_four_unaryAtChosenLeaf hG hm hI hk hx
  exact mixedStarOmission_mem_of_two_ordinary_pair_omissions hG hm hr ha hb hra hrb hab
    (un hr) (un ha) (un hb)
    (omittedStars_eq_pair_of_allPairBlocks hr ha hra hB)
    (omittedStars_eq_pair_of_allPairBlocks hr hb hrb hB) hJ'I hK'I hJ'D hK'D

theorem two_other_sources_of_three {G : Finset (Finset α)} {r : α}
    (hk : 3 ≤ (sources G).card) (hr : r ∈ sources G) :
    ∃ a ∈ sources G, ∃ b ∈ sources G, r ≠ a ∧ r ≠ b ∧ a ≠ b := by
  have hc := Finset.card_erase_add_one hr
  obtain ⟨a,ha,b,hb,hab⟩ := Finset.one_lt_card.mp
    (show 1 < ((sources G).erase r).card by omega)
  obtain ⟨har,haS⟩ := Finset.mem_erase.mp ha
  obtain ⟨hbr,hbS⟩ := Finset.mem_erase.mp hb
  exact ⟨a,haS,b,hbS,har.symm,hbr.symm,hab⟩

theorem exact_four_allPair_one_mixed_each_source {G : Finset (Finset α)} {r : α}
    (hG : NoStrictMajority G) (hm : WeakMinimalGround G)
    (hI : (isolated G).card = 4) (hB : AllOrdinaryStarPairs G)
    (hk : 3 ≤ (sources G).card) (hr : r ∈ sources G) :
    ∃ J ⊆ isolated G, J.Nonempty ∧ mixedStarOmission G r J ∈ G := by
  obtain ⟨a,ha,b,hb,hra,hrb,hab⟩ := two_other_sources_of_three hk hr
  obtain ⟨J,K,hJ,hK,hn⟩ := two_goodFourHoleTypes_inter hI
    (exact_four_allPair_holeTypes hG hm hI hB hr ha hra)
    (exact_four_allPair_holeTypes hG hm hI hB hr hb hrb)
  have hJI := allowedPairIsolateHole_subset hJ
  exact ⟨J ∩ K,(Finset.inter_subset_left).trans hJI,hn,
    mixedStarOmission_mem_of_allowed_inter hG hm hI hB hr ha hb hra hrb hab hJ hK⟩

#print axioms goodFourHoleType_covered
#print axioms exact_four_allPair_one_mixed_each_source
end FranklForcingFiber
