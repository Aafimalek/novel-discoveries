import FranklFourAllPairLarge
import FranklRankTwoPairSaturation

/- Direct Lean-checked all-pair d=0 branch and supporting lemmas. -/
namespace FranklForcingFiber
variable {α : Type*} [DecidableEq α]

/-- Four singleton holes for the sole exterior source saturate the
three-source fiber, at cardinality exactly sixteen. -/
theorem exact_four_allPair_three_fiber_card {G : Finset (Finset α)} {p q : α}
    (hG : NoStrictMajority G) (hm : WeakMinimalGround G)
    (hI : (isolated G).card = 4) (hB : AllOrdinaryStarPairs G)
    (hk : (sources G).card = 3)
    (hp : p ∈ sources G) (hq : q ∈ sources G) (hpq : p ≠ q) :
    (avoidBoth G (starLeaf G p) (starLeaf G q)).card = 16 := by
  classical
  let H (_ : α) := (isolated G).powersetCard 1
  have hH : ∀ r ∈ (sources G \ {p,q}), ∀ J ∈ H r,
      J ⊆ isolated G ∧ J.Nonempty ∧ mixedStarOmission G r J ∈ G := by
    intro r hr J hJ
    have hrS := (Finset.mem_sdiff.mp hr).1
    obtain ⟨hJI,hJC⟩ : J ⊆ isolated G ∧ J.card = 1 := Finset.mem_powersetCard.mp hJ
    obtain ⟨x,rfl⟩ := Finset.card_eq_one.mp hJC
    exact ⟨hJI,⟨x,Finset.mem_singleton_self x⟩,
      exact_four_allPair_mixed_singleton_each_source hG hm hI hB
        (show 3 ≤ (sources G).card by omega) hrS (hJI (Finset.mem_singleton_self x))⟩
  have hHc : ∀ r ∈ (sources G \ {p,q}), 4 ≤ (H r).card := by
    intro r _
    change 4 ≤ ((isolated G).powersetCard 1).card
    rw [Finset.card_powersetCard,hI]
    decide
  have hlo := exact_four_allPair_avoidance_lower_lists hG hm hI hB hp hq hpq H hH hHc
  have hu := cross_pair_actual_upper_of_omitted hG hm hp hq hpq
  dsimp at hu
  rw [omittedStars_eq_pair_of_allPairBlocks hp hq hpq hB,hI,hk] at hu
  have hpc : ({p,q} : Finset α).card = 2 := by simp [hpq]
  rw [hpc] at hu
  rw [hk] at hlo
  have hL : (3 : ℕ).choose 2 + 3 + 6 + (3 - 2) * 4 = 16 := by decide
  have hU : 1 + (4 + (3 - 2)) + (4 + (3 - 2)).choose 2 = 16 := by decide
  rw [hL] at hlo
  rw [hU] at hu
  exact Nat.le_antisymm hu hlo

/-- Once the true-support rank-two bound is saturated with singleton
atoms, any two isolates form an allowed absolute hole. -/
theorem exact_four_allPair_three_double_hole {G : Finset (Finset α)} {p q : α}
    {R : Finset α}
    (hG : NoStrictMajority G) (hm : WeakMinimalGround G)
    (hI : (isolated G).card = 4) (hB : AllOrdinaryStarPairs G)
    (hk : (sources G).card = 3)
    (hp : p ∈ sources G) (hq : q ∈ sources G) (hpq : p ≠ q)
    (hRI : R ⊆ isolated G) (hRc : R.card = 2) :
    AllowedPairIsolateHole G p q R := by
  let U := ground (compressedStarPair G p q)
  let D := starPairTrueComplement G p q
  obtain ⟨hM,hAtoms⟩ := exact_four_allPair_full_atoms hG hm hI hB
    (show 3 ≤ (sources G).card by omega) hp hq hpq
  have hsize := trueSupport_card_and_missing_eq_four hG hm hI hB hp hq hpq
  rw [hM,Finset.card_empty,hk,Nat.add_zero] at hsize
  have hUc : U.card = 5 := hsize
  have hIU : isolated G ⊆ U := by
    intro x hx
    apply (isolate_mem_trueSupport_iff_present hG hm hp hq hpq hx).mpr
    by_contra hN
    have h : x ∈ missingPairIsolates G p q := Finset.mem_sdiff.mpr ⟨hx,hN⟩
    simp [hM] at h
  obtain ⟨h0,hInter,hRank,hDsub⟩ := starPairTrueComplement_rankTwo hG hm hp hq hpq
  have hSing : ∀ x ∈ U, ({x} : Finset α) ∈ D := by
    intro x hx
    have hAtom : ({x} : Finset α) ∈ FranklRankTwoAtoms.atoms D :=
      hAtoms.symm ▸ Finset.mem_image.mpr ⟨x,hx,rfl⟩
    exact (FranklRankTwoAtoms.mem_atoms.mp hAtom).1
  have hDc : D.card = 1 + U.card + U.card.choose 2 := by
    change (starPairTrueComplement G p q).card = _
    rw [starPairTrueComplement_card hG hm hp hq hpq,
      exact_four_allPair_three_fiber_card hG hm hI hB hk hp hq hpq,hUc]
    decide
  have hRd : R ∈ D := FranklRankTwoAtoms.pair_mem_of_quadratic_card_eq
    h0 hInter hRank hDsub hSing hDc (hRI.trans hIU) hRc
  refine ⟨R,hRI,hRd,?_⟩
  change missingPairIsolates G p q ∪ R = R
  simp [hM]

/-- An identical two-isolate hole in each of two incident fibers yields
one extra witness, disjoint by size from the four singleton witnesses. -/
theorem exact_four_allPair_not_three_sources {G : Finset (Finset α)}
    (hG : NoStrictMajority G) (hm : WeakMinimalGround G)
    (hI : (isolated G).card = 4) (hB : AllOrdinaryStarPairs G)
    (hk : (sources G).card = 3) : False := by
  classical
  obtain ⟨p,hp,q,hq,hpq⟩ := Finset.one_lt_card.mp
    (show 1 < (sources G).card by omega)
  obtain ⟨x,hx,y,hy,hxy⟩ := Finset.one_lt_card.mp
    (show 1 < (isolated G).card by omega)
  let R : Finset α := {x,y}
  have hRI : R ⊆ isolated G :=
    Finset.insert_subset_iff.mpr ⟨hx,Finset.singleton_subset_iff.mpr hy⟩
  have hRc : R.card = 2 := by simp [R,hxy]
  let H (_ : α) := insert R ((isolated G).powersetCard 1)
  have hH : ∀ r ∈ (sources G \ {p,q}), ∀ J ∈ H r,
      J ⊆ isolated G ∧ J.Nonempty ∧ mixedStarOmission G r J ∈ G := by
    intro r hr J hJ
    obtain ⟨hrS,hrn⟩ := Finset.mem_sdiff.mp hr
    have hrp : r ≠ p := fun e => hrn (by simp [e])
    have hrq : r ≠ q := fun e => hrn (by simp [e])
    change J ∈ insert R ((isolated G).powersetCard 1) at hJ
    rcases Finset.mem_insert.mp hJ with he | hJ
    · subst J
      have hA := exact_four_allPair_three_double_hole hG hm hI hB hk hrS hp hrp hRI hRc
      have hB' := exact_four_allPair_three_double_hole hG hm hI hB hk hrS hq hrq hRI hRc
      have hMem := mixedStarOmission_mem_of_allowed_inter hG hm hI hB hrS hp hq hrp hrq hpq hA hB'
      exact ⟨hRI,Finset.card_pos.mp (by omega),by simpa using hMem⟩
    · obtain ⟨hJI,hJC⟩ := Finset.mem_powersetCard.mp hJ
      obtain ⟨z,rfl⟩ := Finset.card_eq_one.mp hJC
      exact ⟨hJI,⟨z,Finset.mem_singleton_self z⟩,
        exact_four_allPair_mixed_singleton_each_source hG hm hI hB
          (show 3 ≤ (sources G).card by omega) hrS (hJI (Finset.mem_singleton_self z))⟩
  have hHc : ∀ r ∈ (sources G \ {p,q}), 5 ≤ (H r).card := by
    intro r _
    change 5 ≤ (insert R ((isolated G).powersetCard 1)).card
    have hRn : R ∉ (isolated G).powersetCard 1 := by
      intro h
      have hC := (Finset.mem_powersetCard.mp h).2
      omega
    rw [Finset.card_insert_of_notMem hRn,Finset.card_powersetCard,hI]
    decide
  have hlo := exact_four_allPair_avoidance_lower_lists hG hm hI hB hp hq hpq H hH hHc
  have hcap := exact_four_allPair_three_fiber_card hG hm hI hB hk hp hq hpq
  rw [hk,hcap] at hlo
  have h17 : (3 : ℕ).choose 2 + 3 + 6 + (3 - 2) * 5 = 17 := by decide
  rw [h17] at hlo
  omega

#print axioms exact_four_allPair_three_fiber_card
#print axioms exact_four_allPair_three_double_hole
#print axioms exact_four_allPair_not_three_sources
end FranklForcingFiber
