import FranklRankTwoAtomCounting

/- Direct Lean-checked all-pair d=0 branch and supporting lemmas. -/
open scoped BigOperators
namespace FranklRankTwoAtoms
variable {α : Type*} [DecidableEq α]

/-- With at most one spare coordinate, either every atom is a singleton and
at most one point is uncovered, or exactly one atom is double and the atoms
cover the support. No rank bound is needed beyond disjointness of atoms. -/
theorem nearMaxAtoms_geometry {D : Finset (Finset α)} {U : Finset α}
    (hD : InterClosed D) (hU : ∀ ⦃A⦄, A ∈ D → A ⊆ U)
    (hNear : U.card ≤ (atoms D).card + 1) :
    ((∀ A ∈ atoms D, A.card = 1) ∧ (U \ covered D).card ≤ 1) ∨
    ∃ B ∈ atoms D, B.card = 2 ∧ covered D = U ∧
      ∀ A ∈ atoms D, A ≠ B → A.card = 1 := by
  classical
  let V := atoms D
  have hpos {A : Finset α} (ha : A ∈ V) : 1 ≤ A.card :=
    Finset.card_pos.mpr (mem_atoms.mp ha).2.1
  have hS := covered_subset_support hU
  have hc := Finset.card_le_card hS
  have hC := covered_card_eq_sum hD
  have hsum : (∑ A ∈ V, A.card) ≤ U.card := by simpa [V, ← hC] using hc
  by_cases hs : ∀ A ∈ V, A.card = 1
  · left
    refine ⟨hs,?_⟩
    have ha := atoms_card_le_covered hD
    have he := Finset.card_sdiff_add_card_eq_card hS
    omega
  · right
    push Not at hs
    obtain ⟨B,hB,hBne⟩ := hs
    have hb := hpos hB
    have hB2 : 2 ≤ B.card := by omega
    have hEcard := Finset.card_erase_add_one hB
    have hSplit := Finset.sum_erase_add V (fun A => A.card) hB
    have hLow : (V.erase B).card ≤ ∑ A ∈ V.erase B, A.card := by
      rw [Finset.card_eq_sum_ones]
      exact Finset.sum_le_sum (fun C hc => hpos (Finset.mem_erase.mp hc).2)
    have hNear' : U.card ≤ V.card + 1 := hNear
    have hBexact : B.card = 2 := by omega
    have hSumEq : (∑ A ∈ V, A.card) = U.card := by omega
    have hCover : covered D = U := by
      apply Finset.eq_of_subset_of_card_le hS
      rw [hC]
      exact hSumEq.ge
    refine ⟨B,hB,hBexact,hCover,?_⟩
    intro A hA hne
    have hAe : A ∈ V.erase B := Finset.mem_erase.mpr ⟨hne,hA⟩
    have hAp := hpos hA
    by_contra hn
    have hAL : 1 < A.card := by omega
    have hStrict : (∑ _C ∈ V.erase B, 1) < ∑ C ∈ V.erase B, C.card :=
      Finset.sum_lt_sum (fun _ hc => hpos (Finset.mem_erase.mp hc).2) ⟨A,hAe,hAL⟩
    rw [← Finset.card_eq_sum_ones] at hStrict
    omega

theorem support_point_singleton_of_atomCover {D : Finset (Finset α)} {x : α}
    (hx : x ∈ covered D)
    (h : ∀ A ∈ atoms D, x ∈ A → A.card = 1) :
    ({x} : Finset α) ∈ atoms D := by
  obtain ⟨A,ha,hxa⟩ := Finset.mem_biUnion.mp hx
  obtain ⟨y,rfl⟩ := Finset.card_eq_one.mp (h A ha hxa)
  exact (Finset.mem_singleton.mp hxa).symm ▸ ha

#print axioms nearMaxAtoms_geometry
#print axioms support_point_singleton_of_atomCover
end FranklRankTwoAtoms
