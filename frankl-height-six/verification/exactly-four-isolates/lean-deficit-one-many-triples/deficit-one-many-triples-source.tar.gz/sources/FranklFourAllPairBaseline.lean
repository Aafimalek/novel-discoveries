import FranklPairMixedCounting
import FranklFourSupportUnary
import FranklMultipleSourceTraceObstruction

/- Direct Lean-checked all-pair d=0 branch and supporting lemmas. -/
namespace FranklForcingFiber
variable {α : Type*} [DecidableEq α]

def AllOrdinaryStarPairs (G : Finset (Finset α)) : Prop :=
  ∀ B ∈ starBlocks G, B.card = 2

theorem allOrdinaryStarPairs_blocks_eq {G : Finset (Finset α)}
    (hG : NoStrictMajority G) (hm : WeakMinimalGround G)
    (hB : AllOrdinaryStarPairs G) :
    starBlocks G = (sources G).powersetCard 2 := by
  classical
  have hD := starBlocks_pairDesign hG hm
  ext A
  constructor
  · intro ha
    exact Finset.mem_powersetCard.mpr ⟨(hD.1 A ha).1,hB A ha⟩
  · intro ha
    obtain ⟨hAs,hAc⟩ := Finset.mem_powersetCard.mp ha
    obtain ⟨p,hp,q,hq,hne⟩ := Finset.one_lt_card.mp (show 1 < A.card by omega)
    obtain ⟨B,⟨hBmem,hpB,hqB⟩,_⟩ := hD.2 p (hAs hp) q (hAs hq) hne
    have hAB : ({p,q} : Finset α) ⊆ B := by
      intro x hx
      simp only [Finset.mem_insert,Finset.mem_singleton] at hx
      exact hx.elim (fun he => he.symm ▸ hpB) (fun he => he.symm ▸ hqB)
    have hAA : ({p,q} : Finset α) ⊆ A := by
      intro x hx
      simp only [Finset.mem_insert,Finset.mem_singleton] at hx
      exact hx.elim (fun he => he.symm ▸ hp) (fun he => he.symm ▸ hq)
    have hpc : ({p,q} : Finset α).card = 2 := by simp [hne]
    have hbEq := Finset.eq_of_subset_of_card_le hAB (by rw [hB B hBmem,hpc])
    have haEq := Finset.eq_of_subset_of_card_le hAA (by rw [hAc,hpc])
    exact (hbEq.symm.trans haEq) ▸ hBmem

theorem sources_sdiff_pair_card {G : Finset (Finset α)} {p q : α}
    (hp : p ∈ sources G) (hq : q ∈ sources G) (hpq : p ≠ q) :
    ((sources G) \ {p,q}).card = (sources G).card - 2 := by
  have hs : ({p,q} : Finset α) ⊆ sources G := by
    intro x hx
    simp only [Finset.mem_insert,Finset.mem_singleton] at hx
    exact hx.elim (fun he => he.symm ▸ hp) (fun he => he.symm ▸ hq)
  rw [Finset.card_sdiff_of_subset hs]
  simp [hpq]

theorem allOrdinaryStarPairs_away_card {G : Finset (Finset α)} {p q : α}
    (hG : NoStrictMajority G) (hm : WeakMinimalGround G)
    (hB : AllOrdinaryStarPairs G)
    (hp : p ∈ sources G) (hq : q ∈ sources G) (hpq : p ≠ q) :
    (FranklBlockIncidence.away (starBlocks G) p q).card =
      ((sources G).card - 2).choose 2 := by
  have he : FranklBlockIncidence.away (starBlocks G) p q =
      ((sources G) \ {p,q}).powersetCard 2 := by
    rw [allOrdinaryStarPairs_blocks_eq hG hm hB]
    ext A
    rw [FranklBlockIncidence.mem_away,Finset.mem_powersetCard,Finset.mem_powersetCard]
    constructor
    · rintro ⟨⟨hs,hc⟩,hnp,hnq⟩
      refine ⟨fun x hx => Finset.mem_sdiff.mpr ⟨hs hx,?_⟩,hc⟩
      simp only [Finset.mem_insert,Finset.mem_singleton]
      exact fun h => h.elim (fun e => hnp (e ▸ hx)) (fun e => hnq (e ▸ hx))
    · rintro ⟨hs,hc⟩
      exact ⟨⟨fun x hx => (Finset.mem_sdiff.mp (hs hx)).1,hc⟩,
        (fun hx => (Finset.mem_sdiff.mp (hs hx)).2 (by simp)),
        (fun hx => (Finset.mem_sdiff.mp (hs hx)).2 (by simp))⟩
  rw [he,Finset.card_powersetCard,sources_sdiff_pair_card hp hq hpq]

theorem exact_four_unaryAtChosenLeaf {G : Finset (Finset α)} {p : α}
    (hG : NoStrictMajority G) (hm : WeakMinimalGround G)
    (hI : (isolated G).card = 4) (hk : 2 ≤ (sources G).card)
    (hp : p ∈ sources G) : UnaryAtChosenLeaf G p := by
  intro x hpx hFx
  exact exact_four_proper_forcing_successor_unique hG hm hI hk hp hpx
    (starLeaf_spec hp).1 hFx (starLeaf_spec hp).2

theorem exact_four_unary_ground_card {G : Finset (Finset α)}
    (hG : NoStrictMajority G) (hm : WeakMinimalGround G)
    (hI : (isolated G).card = 4) (hk : 2 ≤ (sources G).card) :
    (ground G).card = 2 * (sources G).card + 4 := by
  have he : (sources G).image (starLeaf G) = leaves G := by
    ext x
    constructor
    · intro hx
      obtain ⟨r,hr,rfl⟩ := Finset.mem_image.mp hx
      have hrG := (mem_sources.mp hr).1
      obtain ⟨hn,hF⟩ := starLeaf_spec hr
      exact mem_leaves.mpr ⟨mem_ground_of_forces hrG hF,r,hrG,hn,hF⟩
    · intro hx
      obtain ⟨_,r,hr,hn,hF⟩ := mem_leaves.mp hx
      have hrS := mem_sources.mpr ⟨hr,x,hn,hF⟩
      exact Finset.mem_image.mpr ⟨r,hrS,(exact_four_unaryAtChosenLeaf hG hm hI hk hrS hn hF).symm⟩
  have hLc : (leaves G).card = (sources G).card := by
    rw [← he]
    exact Finset.card_image_of_injOn (starLeaf_injOn_sources hG hm)
  have h := partition_card hG hm
  omega

theorem choose_two_split_two {k : ℕ} (hk : 2 ≤ k) :
    k.choose 2 + 3 = (k - 2).choose 2 + 2 * k := by
  have h₁ : (k - 2 + 1).choose 2 = (k - 2) + (k - 2).choose 2 := by
    simpa using (Nat.choose_succ_succ' (k - 2) 1)
  have h₂ : (k - 2 + 1 + 1).choose 2 = (k - 2 + 1) + (k - 2 + 1).choose 2 := by
    simpa using (Nat.choose_succ_succ' (k - 2 + 1) 1)
  have he : k - 2 + 1 + 1 = k := by omega
  rw [he] at h₂
  omega

theorem exact_four_allPair_avoidance_lower {G : Finset (Finset α)} {p q : α}
    (hG : NoStrictMajority G) (hm : WeakMinimalGround G)
    (hI : (isolated G).card = 4) (hB : AllOrdinaryStarPairs G)
    (hp : p ∈ sources G) (hq : q ∈ sources G) (hpq : p ≠ q)
    (K : Finset (α × Finset α))
    (hK : ∀ z ∈ K, z.1 ∈ sources G ∧ z.1 ≠ p ∧ z.1 ≠ q ∧
      z.2 ⊆ isolated G ∧ z.2.Nonempty ∧ mixedStarOmission G z.1 z.2 ∈ G) :
    (sources G).card.choose 2 + (sources G).card + 6 + K.card ≤
      (avoidBoth G (starLeaf G p) (starLeaf G q)).card := by
  have hk : 2 ≤ (sources G).card := Finset.one_lt_card.mpr ⟨p,hp,q,hq,hpq⟩
  have hn := exact_four_unary_ground_card hG hm hI hk
  have hW := allOrdinaryStarPairs_away_card hG hm hB hp hq hpq
  have hl := leaf_pair_count_with_blocks_and_mixed hG hm hp hq hpq K hK
  have hQ := choose_two_split_two hk
  omega

#print axioms allOrdinaryStarPairs_away_card
#print axioms exact_four_unary_ground_card
#print axioms exact_four_allPair_avoidance_lower
end FranklForcingFiber
