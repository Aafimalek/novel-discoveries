import FranklFourAllPairBaseline
import FranklNearMaxAtoms

/- Direct Lean-checked all-pair d=0 branch and supporting lemmas. -/
namespace FranklForcingFiber
variable {α : Type*} [DecidableEq α]

noncomputable def missingPairIsolates (G : Finset (Finset α)) (p q : α) : Finset α :=
  isolated G \ starPairMax G p q

theorem trueSupport_card_and_missing_eq_four {G : Finset (Finset α)} {p q : α}
    (hG : NoStrictMajority G) (hm : WeakMinimalGround G)
    (hI : (isolated G).card = 4) (hB : AllOrdinaryStarPairs G)
    (hp : p ∈ sources G) (hq : q ∈ sources G) (hpq : p ≠ q) :
    (ground (compressedStarPair G p q)).card + (missingPairIsolates G p q).card =
      (sources G).card + 2 := by
  have hk : 2 ≤ (sources G).card := Finset.one_lt_card.mpr ⟨p,hp,q,hq,hpq⟩
  rw [compressedStarPair_ground_eq_centers_union_present_isolates hG hm hp hq hpq,
    omittedStars_eq_pair_of_allPairBlocks hp hq hpq hB]
  have hDis : Disjoint (sources G \ {p,q}) (isolated G ∩ starPairMax G p q) := by
    apply Finset.disjoint_left.mpr
    intro x hx hy
    exact (Finset.mem_sdiff.mp (Finset.mem_inter.mp hy).1).2 (Finset.mem_sdiff.mp hx).1
  rw [Finset.card_union_of_disjoint hDis,sources_sdiff_pair_card hp hq hpq]
  have hsplit : (isolated G ∩ starPairMax G p q).card +
      (missingPairIsolates G p q).card = (isolated G).card := by
    have he : isolated G \ (isolated G ∩ starPairMax G p q) = missingPairIsolates G p q := by
      exact Finset.sdiff_inter_self_left _ _
    rw [← he, Nat.add_comm]
    exact Finset.card_sdiff_add_card_eq_card Finset.inter_subset_left
  omega

/-- Atom lower bound and at most one missing physical isolate, independently
of any additional mixed witnesses. -/
theorem exact_four_allPair_nearMax {G : Finset (Finset α)} {p q : α}
    (hG : NoStrictMajority G) (hm : WeakMinimalGround G)
    (hI : (isolated G).card = 4) (hB : AllOrdinaryStarPairs G)
    (hp : p ∈ sources G) (hq : q ∈ sources G) (hpq : p ≠ q) :
    (sources G).card + 1 ≤ (FranklRankTwoAtoms.atoms (starPairTrueComplement G p q)).card ∧
      (missingPairIsolates G p q).card ≤ 1 := by
  classical
  have hsize := trueSupport_card_and_missing_eq_four hG hm hI hB hp hq hpq
  have hl := exact_four_allPair_avoidance_lower hG hm hI hB hp hq hpq
    (∅ : Finset (α × Finset α)) (by simp)
  simp only [Finset.card_empty,Nat.add_zero] at hl
  have hu := leafPairAvoidance_card_le_trueSupport_atoms hG hm hp hq hpq
  obtain ⟨_,hD,_,hU⟩ := starPairTrueComplement_rankTwo hG hm hp hq hpq
  have hac := (FranklRankTwoAtoms.atoms_card_le_covered hD).trans
    (Finset.card_le_card (FranklRankTwoAtoms.covered_subset_support hU))
  have ha : (sources G).card + 1 ≤ (FranklRankTwoAtoms.atoms (starPairTrueComplement G p q)).card := by
    by_contra! hn
    have hle : (FranklRankTwoAtoms.atoms (starPairTrueComplement G p q)).card ≤ (sources G).card := by omega
    have hc := Nat.choose_le_choose 2 hle
    omega
  exact ⟨ha,by omega⟩

theorem isolate_mem_trueSupport_iff_present {G : Finset (Finset α)} {p q x : α}
    (hG : NoStrictMajority G) (hm : WeakMinimalGround G)
    (hp : p ∈ sources G) (hq : q ∈ sources G) (hpq : p ≠ q)
    (hx : x ∈ isolated G) :
    x ∈ ground (compressedStarPair G p q) ↔ x ∈ starPairMax G p q := by
  rw [compressedStarPair_ground_eq_centers_union_present_isolates hG hm hp hq hpq]
  constructor
  · intro hx'
    rcases Finset.mem_union.mp hx' with hs | hi
    · exact False.elim ((Finset.mem_sdiff.mp hx).2 (Finset.mem_sdiff.mp hs).1)
    · exact (Finset.mem_inter.mp hi).2
  · intro h
    exact Finset.mem_union_right _ (Finset.mem_inter.mpr ⟨hx,h⟩)

theorem exact_four_allPair_missing_implies_all_atoms {G : Finset (Finset α)} {p q : α}
    (hG : NoStrictMajority G) (hm : WeakMinimalGround G)
    (hI : (isolated G).card = 4) (hB : AllOrdinaryStarPairs G)
    (hp : p ∈ sources G) (hq : q ∈ sources G) (hpq : p ≠ q)
    (hn : (missingPairIsolates G p q).Nonempty) :
    (missingPairIsolates G p q).card = 1 ∧
    FranklRankTwoAtoms.atoms (starPairTrueComplement G p q) =
      (ground (compressedStarPair G p q)).image (fun x => ({x} : Finset α)) := by
  have hEq := trueSupport_card_and_missing_eq_four hG hm hI hB hp hq hpq
  obtain ⟨ha,hm1⟩ := exact_four_allPair_nearMax hG hm hI hB hp hq hpq
  have hpos := Finset.card_pos.mpr hn
  obtain ⟨_,hD,_,hU⟩ := starPairTrueComplement_rankTwo hG hm hp hq hpq
  have hac := (FranklRankTwoAtoms.atoms_card_le_covered hD).trans
    (Finset.card_le_card (FranklRankTwoAtoms.covered_subset_support hU))
  exact ⟨by omega,FranklRankTwoAtoms.atoms_eq_singletons_of_card_eq_support hD hU (by omega)⟩

#print axioms trueSupport_card_and_missing_eq_four
#print axioms exact_four_allPair_nearMax
#print axioms exact_four_allPair_missing_implies_all_atoms
end FranklForcingFiber
