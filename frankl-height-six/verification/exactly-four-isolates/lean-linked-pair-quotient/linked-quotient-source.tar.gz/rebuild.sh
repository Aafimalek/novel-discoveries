#!/usr/bin/env bash
set -euo pipefail
BUNDLE="$(cd "$(dirname "$0")" && pwd)"
cd "$BUNDLE"
: "${MATHLIB_ROOT:?Set MATHLIB_ROOT to a cache-built checkout of the pinned Mathlib revision}"
MATHLIB_ROOT="$(cd "$MATHLIB_ROOT" && pwd)"
LEAN_BIN="${LEAN_BIN:-lean}"
if [[ "$LEAN_BIN" == */* ]]; then LEAN_BIN="$(realpath "$LEAN_BIN")"; fi
ver="$("$LEAN_BIN" --version)"
printf '%s\n' "$ver"
[[ "$ver" == *"version 4.36.0"* && "$ver" == *"611c117bfaf7b7ae1cfcf246ce6fba31e8f509e9"* ]]
[[ "$(cat "$MATHLIB_ROOT/lean-toolchain")" == "$(cat "$BUNDLE/lean-toolchain")" ]]
sha256sum --check "$BUNDLE/sources.sha256"
mkdir -p "$BUNDLE/build" "$BUNDLE/compiler-tmp"
export TMPDIR="$BUNDLE/compiler-tmp" TMP="$BUNDLE/compiler-tmp" TEMP="$BUNDLE/compiler-tmp"
export LEAN_PATH="$BUNDLE/build:$MATHLIB_ROOT/.lake/build/lib/lean$(printf ':%s' "$MATHLIB_ROOT"/.lake/packages/*/.lake/build/lib/lean)"
cd "$BUNDLE/sources"
while IFS= read -r mod; do
  echo "=== $mod ==="
  flags=()
  if grep -qxF "$mod" "$BUNDLE/warning-as-error-modules.txt"; then flags=(-DwarningAsError=true); fi
  timeout --kill-after=5s 175s "$LEAN_BIN" -j1 -M2500 "${flags[@]}" -o "$BUNDLE/build/$mod.olean" "$mod.lean"
done < "$BUNDLE/dependency-order.txt"
echo 'exit=0'
